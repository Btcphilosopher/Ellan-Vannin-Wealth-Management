package com.example.features.checkin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Booking
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun CheckInScreen(
    viewModel: MainViewModel,
    booking: Booking,
    onCheckInCompleted: () -> Unit
) {
    var checkInStep by remember { mutableStateOf(1) } // 1..6
    var isNationalChileRuleVerified by remember { mutableStateOf(true) }
    val isNationalRoute = booking.originCode == "SCL" && booking.destinationCode != "LIM" && booking.destinationCode != "MAD"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "PREPARA TU VIAJE • PASO $checkInStep DE 6",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "CHECK-IN DIGITAL",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        LinearProgressIndicator(
            progress = { checkInStep / 6f },
            modifier = Modifier.fillMaxWidth(),
            color = LatamRed,
            trackColor = LatamNavyLight
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Chile Sept 2026 Regulatory Notice Banner
            if (isNationalRoute) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = LatamGoldLight),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = LatamNavy)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Normativa Chile (1 Sept 2026): Validación de documentación de identidad actualizada requerida para embarque nacional.",
                            style = MaterialTheme.typography.bodySmall.copy(color = LatamNavy, fontWeight = FontWeight.Medium)
                        )
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    when (checkInStep) {
                        1 -> {
                            Text(text = "1. CONFIRMAR PASAJERO", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "Pasajero: ${booking.passengerName}", style = MaterialTheme.typography.bodyLarge)
                            Text(text = "PNR: ${booking.pnrCode}", style = MaterialTheme.typography.bodyMedium.copy(color = LatamTextSecondary))
                        }
                        2 -> {
                            Text(text = "2. DOCUMENTACIÓN FICTICIA", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "RUT / Documento: 18.492.012-K (Verificado ficticiamente)", style = MaterialTheme.typography.bodyMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = isNationalChileRuleVerified,
                                    onCheckedChange = { isNationalChileRuleVerified = it }
                                )
                                Text(text = "Declaro que la documentación cumple con las normas de aviación chilena.")
                            }
                        }
                        3 -> {
                            Text(text = "3. DATOS DEL VUELO", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "Vuelo: ${booking.flightNumber}", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                            Text(text = "Origen: ${booking.originCity} (${booking.originCode}) • Terminal: ${booking.terminal}")
                            Text(text = "Destino: ${booking.destinationCity} (${booking.destinationCode})")
                        }
                        4 -> {
                            Text(text = "4. SELECCIONAR ASIENTO", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "Asiento asignado: ${booking.seatNumber}", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = LatamRed))
                        }
                        5 -> {
                            Text(text = "5. CONFIRMAR CHECK-IN", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "Al presionar confirmar se generará tu tarjeta de embarque de demostración.")
                        }
                        else -> {
                            Text(text = "6. TARJETA DE EMBARQUE GENERADA", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = StatusGreen))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "¡Check-in completado con éxito!")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (checkInStep < 6) {
                Button(
                    onClick = {
                        if (checkInStep == 5) {
                            viewModel.performCheckIn(booking)
                            checkInStep = 6
                        } else {
                            checkInStep++
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("checkin_next_step_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = LatamRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (checkInStep == 5) "CONFIRMAR Y GENERAR TARJETA" else "SIGUIENTE PASO",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            } else {
                Button(
                    onClick = onCheckInCompleted,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LatamNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("VER TARJETA DE EMBARQUE")
                }
            }
        }
    }
}
