package com.example.core.model

import androidx.room.Entity
import androidx.room.PrimaryKey

data class Airport(
    val code: String,
    val name: String,
    val city: String,
    val country: String,
    val terminal: String = "T1"
)

enum class CabinClass(val displayName: String) {
    ECONOMY("Económica"),
    PREMIUM_ECONOMY("Premium Economy"),
    BUSINESS("Ejecutiva")
}

enum class FlightStatusEnum(val displayName: String) {
    PROGRAMADO("Programado"),
    A_TIEMPO("A tiempo"),
    EMBARCANDO("Embarcando"),
    ULTIMA_LLAMADA("Última llamada"),
    DESPEGADO("Despegado"),
    EN_VUELO("En vuelo"),
    ATERRIZADO("Aterrizado"),
    RETRASADO("Retrasado"),
    CANCELADO("Cancelado"),
    DESVIADO("Desviado")
}

data class FlightSegment(
    val id: String,
    val flightNumber: String,
    val originCode: String,
    val originCity: String,
    val originTerminal: String,
    val destinationCode: String,
    val destinationCity: String,
    val destinationTerminal: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val aircraftType: String = "Boeing 787-9 Dreamliner"
)

data class Fare(
    val cabinClass: CabinClass,
    val priceClp: Int,
    val baggageIncluded: String,
    val flexCondition: String,
    val pointsEarned: Int
)

data class Flight(
    val flightNumber: String,
    val origin: Airport,
    val destination: Airport,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val stopsCount: Int,
    val aircraft: String,
    val fares: Map<CabinClass, Fare>,
    val ecoEmissionsKg: Int = 112,
    var currentStatus: FlightStatusEnum = FlightStatusEnum.A_TIEMPO,
    var gate: String = "B12",
    var terminal: String = "T2 Nacional"
)

data class Passenger(
    val id: String,
    val firstName: String,
    val lastName: String,
    val documentType: String = "RUT / Pasaporte Ficticio",
    val documentNumber: String = "18.492.012-K",
    val nationality: String = "Chile",
    val latamPassNumber: String = "749201938",
    val documentValidated: Boolean = true
)

enum class BookingStatus(val displayName: String) {
    BORRADOR("Borrador"),
    PENDIENTE_DE_PAGO("Pendiente de pago"),
    PAGO_SIMULADO("Pago simulado"),
    CONFIRMADA("Confirmada"),
    CANCELADA("Cancelada")
}

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey val pnrCode: String,
    val flightNumber: String,
    val originCode: String,
    val originCity: String,
    val destinationCode: String,
    val destinationCity: String,
    val departureDate: String,
    val departureTime: String,
    val arrivalTime: String,
    val passengerName: String,
    val cabinClass: String,
    val status: String,
    val seatNumber: String = "14A",
    val checkedBaggageCount: Int = 1,
    val totalPriceClp: Int = 189990,
    val gate: String = "B12",
    val terminal: String = "T2 Nacional",
    val checkInCompleted: Boolean = false,
    val createdAtTimestamp: Long = System.currentTimeMillis()
)

enum class SeatAvailability {
    DISPONIBLE,
    SELECCIONADO,
    OCUPADO,
    BLOQUEADO,
    PRECIO_ADICIONAL
}

enum class SeatPreference {
    VENTANA,
    PASILLO,
    CUALQUIERA
}

data class Seat(
    val code: String,
    val row: Int,
    val column: Char,
    val cabinClass: CabinClass,
    val status: SeatAvailability,
    val extraLegroom: Boolean = false,
    val extraPriceClp: Int = 0,
    val restrictionText: String? = null
)

enum class BaggageStatus {
    NO_INCLUIDO,
    INCLUIDO,
    SELECCIONADO,
    PAGADO_DEMO,
    REGISTRADO_DEMO
}

data class BaggageItem(
    val id: String,
    val type: String, // "Carry-on 10kg", "Bodega 23kg", "Especial"
    val weightKg: Int,
    val priceClp: Int,
    val status: BaggageStatus
)

enum class BoardingPassStatus {
    GENERANDO,
    VALIDA_DEMO,
    UTILIZADA_DEMO,
    EXPIRADA,
    CANCELADA
}

@Entity(tableName = "boarding_passes")
data class BoardingPass(
    @PrimaryKey val id: String,
    val pnrCode: String,
    val flightNumber: String,
    val originCity: String,
    val originCode: String,
    val destinationCity: String,
    val destinationCode: String,
    val departureDate: String,
    val departureTime: String,
    val passengerName: String,
    val seatNumber: String,
    val boardingGroup: String,
    val gate: String,
    val terminal: String,
    val cabinClass: String,
    val status: String,
    val qrCodePayload: String
)

enum class CheckInStatus {
    NO_DISPONIBLE,
    DISPONIBLE,
    EN_PROCESO,
    DOCUMENTACION_PENDIENTE,
    COMPLETADO,
    BLOQUEADO
}

data class CheckInSession(
    val pnrCode: String,
    val passenger: Passenger,
    val flight: Flight,
    val isNationalChile: Boolean,
    val requireUpdatedDocRuleSept2026: Boolean = true,
    val status: CheckInStatus = CheckInStatus.DISPONIBLE
)

data class AirportFacility(
    val id: String,
    val name: String,
    val category: String, // Check-in, Seguridad, Puerta, VIP, Restorán, Transport
    val locationDescription: String,
    val xPercent: Float,
    val yPercent: Float,
    val iconName: String
)

enum class NotificationType {
    CHECKIN_REMINDER,
    GATE_CHANGE,
    DELAY,
    BOARDING_STARTED,
    SCHEDULE_UPDATE,
    BAGGAGE_UPDATE,
    BOOKING_UPDATE,
    DOC_REMINDER
}

enum class NotificationPriority {
    ALTA,
    MEDIA,
    INFORMATIVA
}

@Entity(tableName = "notifications")
data class NotificationItem(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val type: String,
    val priority: String,
    val timestampFormatted: String,
    val isRead: Boolean = false,
    val relatedPnr: String? = null
)

enum class PassCategory(val displayName: String, val minPoints: Int) {
    PROMO("Promo", 0),
    GOLD("Gold", 15000),
    PLATINUM("Platinum", 30000),
    BLACK("Black", 60000),
    BLACK_SIGNATURE("Black Signature", 100000)
}

@Entity(tableName = "latam_pass")
data class LatamPassAccount(
    @PrimaryKey val accountId: String = "LP_CHILE_101",
    val memberName: String = "Tomás Valenzuela",
    val availableMiles: Int = 42850,
    val expiringMiles: Int = 3200,
    val qualifyingPoints: Int = 18400,
    val category: String = "Gold"
)

data class MilesTransaction(
    val id: String,
    val dateFormatted: String,
    val description: String,
    val milesAmount: Int, // Positive for earned, negative for spent
    val isEarned: Boolean
)

data class TravelExtra(
    val id: String,
    val title: String,
    val category: String,
    val description: String,
    val priceClp: Int,
    val isDemoOnly: Boolean = true
)

@Entity(tableName = "dev_logs")
data class DevLogEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val eventType: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
