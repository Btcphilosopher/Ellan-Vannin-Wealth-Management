package com.example

import com.example.core.currency.CurrencyUtils
import com.example.data.json.SeedData
import com.example.data.providers.DemoBookingProvider
import org.junit.Assert.*
import org.junit.Test

class LatamBusinessLogicTest {

    @Test
    fun testCurrencyFormat() {
        val formatted = CurrencyUtils.formatClp(189990)
        assertTrue("Formatted currency should contain CLP symbol or CLP prefix", formatted.contains("CLP") || formatted.contains("$"))
        assertTrue(formatted.contains("189"))
    }

    @Test
    fun testSeedFlights() {
        val flights = SeedData.DemoFlights
        assertTrue("Seed data should contain flights", flights.isNotEmpty())
        val sclLim = flights.firstOrNull { it.origin.code == "SCL" && it.destination.code == "LIM" }
        assertNotNull("Should contain SCL -> LIM flight LA 640", sclLim)
    }

    @Test
    fun testPnrGeneration() {
        val pnr = DemoBookingProvider.generatePnr()
        assertTrue("PNR should start with LA", pnr.startsWith("LA"))
        assertEquals("PNR should be 6 characters long", 6, pnr.length)
    }
}
