package com.example.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// Favourites Entity
@Entity(tableName = "favourites")
data class FavouriteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val label: String, // e.g. "Zuhause", "Arbeit", "Universität"
    val stationId: String,
    val stationName: String
)

// Journey History Entity
@Entity(tableName = "journey_history")
data class JourneyHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fromStationId: String,
    val fromStationName: String,
    val toStationId: String,
    val toStationName: String,
    val timestamp: Long = System.currentTimeMillis()
)

// Tickets Entity
@Entity(tableName = "purchased_tickets")
data class TicketEntity(
    @PrimaryKey val ticketId: String,
    val title: String, // e.g. "24-Stunden-Karte"
    val zone: String,  // e.g. "Berlin AB"
    val price: String, // e.g. "11.50 € DEMO"
    val purchaseTimestamp: Long = System.currentTimeMillis(),
    val validFromTimestamp: Long,
    val validToTimestamp: Long,
    val isActive: Boolean = true
)

@Dao
interface UbahnDao {
    // Favourites
    @Query("SELECT * FROM favourites ORDER BY id ASC")
    fun getAllFavourites(): Flow<List<FavouriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavourite(favourite: FavouriteEntity)

    @Query("DELETE FROM favourites WHERE id = :id")
    suspend fun deleteFavourite(id: Int)

    // Journey History
    @Query("SELECT * FROM journey_history ORDER BY timestamp DESC LIMIT 20")
    fun getJourneyHistory(): Flow<List<JourneyHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourneyHistory(journey: JourneyHistoryEntity)

    // Tickets
    @Query("SELECT * FROM purchased_tickets ORDER BY purchaseTimestamp DESC")
    fun getAllTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Query("UPDATE purchased_tickets SET isActive = :isActive WHERE ticketId = :ticketId")
    suspend fun updateTicketStatus(ticketId: String, isActive: Boolean)
}

@Database(
    entities = [FavouriteEntity::class, JourneyHistoryEntity::class, TicketEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun ubahnDao(): UbahnDao
}
