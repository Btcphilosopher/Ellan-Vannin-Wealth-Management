package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NetworkData
import com.example.domain.Disruption
import com.example.domain.DisruptionType
import com.example.ui.UbahnViewModel

@Composable
fun DisruptionsScreen(
    viewModel: UbahnViewModel,
    modifier: Modifier = Modifier
) {
    val activeDisruptions by viewModel.activeDisruptions.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "STÖRUNGSZENTRALE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "Meldungen & Störungssimulator",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }

        // 1. DISRUPTION SIMULATOR INJECTOR PANEL
        item {
            Column {
                Text(
                    text = "DISRUPTION SIMULATOR (STEUERUNG)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Aktiviere Störungsszenarien, um die dynamische Strecken-Neuberechnung zu testen:",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )

                        // Trigger 1: U2 Streckensperrung
                        SimulatorToggleRow(
                            title = "U2 Sperrung (Alexanderplatz ↔ Senefelderplatz)",
                            checked = activeDisruptions.any { it.id == "u2_closure" },
                            onCheckedChange = { viewModel.toggleDisruption("u2_closure") },
                            testTag = "toggle_disruption_u2"
                        )

                        // Trigger 2: U6 Teilsperrung
                        SimulatorToggleRow(
                            title = "U6 Teilsperrung (Wedding ↔ Friedrichstraße)",
                            checked = activeDisruptions.any { it.id == "u6_partial" },
                            onCheckedChange = { viewModel.toggleDisruption("u6_partial") },
                            testTag = "toggle_disruption_u6"
                        )

                        // Trigger 3: U7 Signalstörung (Delay 10 min)
                        SimulatorToggleRow(
                            title = "U7 Signalstörung (Verspätungen Spandau)",
                            checked = activeDisruptions.any { it.id == "u7_delay" },
                            onCheckedChange = { viewModel.toggleDisruption("u7_delay") },
                            testTag = "toggle_disruption_u7"
                        )

                        // Trigger 4: U8 Signalstörung (Alexanderplatz ↔ Kottbusser Tor)
                        SimulatorToggleRow(
                            title = "U8 Signalstörung (Segment geschlossen)",
                            checked = activeDisruptions.any { it.id == "u8_signal" },
                            onCheckedChange = { viewModel.toggleDisruption("u8_signal") },
                            testTag = "toggle_disruption_u8"
                        )
                    }
                }
            }
        }

        // 2. ACTIVE VERKERSMELDUNGEN
        item {
            Text(
                text = "AKTUELLE BETRIEBSMELDUNGEN (BVG MONITOR)",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 4.dp)
            )

            if (activeDisruptions.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    activeDisruptions.forEach { disruption ->
                        DisruptionWarningCard(disruption = disruption)
                    }
                }
            } else {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Info, contentDescription = "Normal", tint = Color(0xFF4CD964), modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "Keine Störungen aktiv", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = "Alle U-Bahn-Linien fahren planmäßig.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }
    }
}

@Composable
fun SimulatorToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange, modifier = Modifier.testTag(testTag))
    }
}

@Composable
fun DisruptionWarningCard(disruption: Disruption) {
    val line = NetworkData.lineMap[disruption.lineId]!!
    val accentColor = when (disruption.type) {
        DisruptionType.AUSFALL, DisruptionType.STOERUNG -> Color.Red
        DisruptionType.VERSPAETUNG -> Color(0xFFFF9500)
        else -> Color.Gray
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, accentColor, RoundedCornerShape(0.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(0.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Line Badge
                    Box(
                        modifier = Modifier
                            .background(line.color)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(text = line.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = when (disruption.type) {
                            DisruptionType.AUSFALL -> "AUSFALL / SPERRUNG"
                            DisruptionType.STOERUNG -> "BETRIEBSSTÖRUNG"
                            DisruptionType.VERSPAETUNG -> "VERZPÖGERUNGEN"
                            else -> "BAUSTELLE"
                        },
                        color = accentColor,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp
                    )
                }

                Text(
                    text = "Aktualisiert: ${disruption.timestamp}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(text = disruption.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(
                text = disruption.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(top = 4.dp)
            )

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, contentDescription = "Alternative", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Die Verbindungssuche berechnet automatisch Alternativen um diese Sperrung herum.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}
