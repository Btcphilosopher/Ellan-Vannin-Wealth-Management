package com.example.routing

import com.example.data.NetworkData
import com.example.domain.*

object RoutingEngine {

    // Representation of a graph node in a transit network
    data class GraphNode(val stationId: String, val lineId: String)

    data class Edge(val target: GraphNode, val weight: Double, val lineId: String, val isTransfer: Boolean)

    fun findRoute(
        startStationId: String,
        endStationId: String,
        config: SearchConfig,
        activeDisruptions: List<Disruption> = emptyList()
    ): Journey? {
        if (startStationId == endStationId) return null

        val startStation = NetworkData.stationMap[startStationId] ?: return null
        val endStation = NetworkData.stationMap[endStationId] ?: return null

        // Create adjacency list
        val adj = mutableMapOf<GraphNode, MutableList<Edge>>()

        // Build edges based on line segments
        for (line in NetworkData.lines) {
            val stationsOnLine = line.stations
            for (i in 0 until stationsOnLine.size - 1) {
                val s1 = stationsOnLine[i]
                val s2 = stationsOnLine[i + 1]

                // Check if this segment is closed by a disruption
                val isSegmentDisrupted = activeDisruptions.any { disruption ->
                    disruption.lineId == line.id &&
                    (disruption.type == DisruptionType.AUSFALL || disruption.type == DisruptionType.STOERUNG) &&
                    ((disruption.startStationId == s1 && disruption.endStationId == s2) ||
                     (disruption.startStationId == s2 && disruption.endStationId == s1))
                }

                if (isSegmentDisrupted) {
                    continue // Skip adding this edge (routing around it!)
                }

                val node1 = GraphNode(s1, line.id)
                val node2 = GraphNode(s2, line.id)

                // Check accessibility
                val isS1Accessible = NetworkData.stationMap[s1]?.isAccessible ?: true
                val isS2Accessible = NetworkData.stationMap[s2]?.isAccessible ?: true

                if (config.isAccessibleRequired) {
                    if (!isS1Accessible || !isS2Accessible) {
                        continue // Omit edges that rely on non-accessible stations
                    }
                }

                // Normal travel time between consecutive stations is approx 2 minutes
                val baseWeight = 2.0
                adj.getOrPut(node1) { mutableListOf() }.add(Edge(node2, baseWeight, line.id, false))
                adj.getOrPut(node2) { mutableListOf() }.add(Edge(node1, baseWeight, line.id, false))
            }
        }

        // Add transfer edges between different lines at the same station
        for (station in NetworkData.stations) {
            if (config.isAccessibleRequired && !station.isAccessible) {
                continue // Skip transfer station completely if not accessible
            }

            val stationLines = station.lines
            for (i in stationLines.indices) {
                for (j in stationLines.indices) {
                    if (i != j) {
                        val node1 = GraphNode(station.id, stationLines[i])
                        val node2 = GraphNode(station.id, stationLines[j])
                        
                        // Transfer penalty: higher if user prefers few transfers
                        val transferPenalty = if (config.preferFewTransfers) 8.0 else 4.0
                        adj.getOrPut(node1) { mutableListOf() }.add(Edge(node2, transferPenalty, "WALK", true))
                    }
                }
            }
        }

        // Run Dijkstra
        val distances = mutableMapOf<GraphNode, Double>()
        val previous = mutableMapOf<GraphNode, Pair<GraphNode, Edge>>()

        val pq = java.util.PriorityQueue<Pair<GraphNode, Double>>(compareBy { it.second })

        // Initialize start nodes
        for (lineId in startStation.lines) {
            val startNode = GraphNode(startStationId, lineId)
            distances[startNode] = 0.0
            pq.add(startNode to 0.0)
        }

        var targetNodeReached: GraphNode? = null
        val visited = mutableSetOf<GraphNode>()

        while (pq.isNotEmpty()) {
            val (current, dist) = pq.poll() ?: break

            if (current.stationId == endStationId) {
                targetNodeReached = current
                break
            }

            if (current in visited) continue
            visited.add(current)

            val neighbors = adj[current] ?: continue
            for (edge in neighbors) {
                val newDist = dist + edge.weight
                val oldDist = distances[edge.target] ?: Double.MAX_VALUE
                if (newDist < oldDist) {
                    distances[edge.target] = newDist
                    previous[edge.target] = current to edge
                    pq.add(edge.target to newDist)
                }
            }
        }

        if (targetNodeReached == null) return null

        // Reconstruct path
        val pathEdges = mutableListOf<Pair<GraphNode, Edge>>()
        var curr: GraphNode = targetNodeReached!!
        while (true) {
            val prevInfo = previous[curr] ?: break
            pathEdges.add(curr to prevInfo.second)
            curr = prevInfo.first
        }
        pathEdges.reverse()

        // Group path into journey legs
        val legs = mutableListOf<JourneyLeg>()
        if (pathEdges.isEmpty()) return null

        var currentLegStartNode: GraphNode = curr
        var currentLegLineId = pathEdges.first().second.lineId
        var currentLegDuration = 0.0
        val currentLegStations = mutableListOf<String>()
        currentLegStations.add(NetworkData.stationMap[currentLegStartNode.stationId]?.name ?: "")

        for (item in pathEdges) {
            val nextNode = item.first
            val edge = item.second

            if (edge.isTransfer) {
                if (currentLegLineId != "WALK" && currentLegStations.size > 1) {
                    val lineObj = NetworkData.lineMap[currentLegLineId]!!
                    legs.add(
                        JourneyLeg(
                            lineId = currentLegLineId,
                            lineName = lineObj.name,
                            colorHex = lineObj.colorHex,
                            startStationId = currentLegStartNode.stationId,
                            startStationName = NetworkData.stationMap[currentLegStartNode.stationId]?.name ?: "",
                            endStationId = nextNode.stationId,
                            endStationName = NetworkData.stationMap[nextNode.stationId]?.name ?: "",
                            direction = getDirectionForLeg(currentLegLineId, currentLegStartNode.stationId, nextNode.stationId),
                            intermediateStationsCount = currentLegStations.size - 2,
                            durationMinutes = currentLegDuration.toInt(),
                            stationNames = currentLegStations.toList()
                        )
                    )
                }
                currentLegStartNode = nextNode
                currentLegLineId = "WALK"
                currentLegDuration = 0.0
                currentLegStations.clear()
                currentLegStations.add(NetworkData.stationMap[nextNode.stationId]?.name ?: "")
            } else {
                if (currentLegLineId == "WALK") {
                    currentLegLineId = edge.lineId
                    currentLegStartNode = curr
                }
                currentLegDuration += edge.weight
                currentLegStations.add(NetworkData.stationMap[nextNode.stationId]?.name ?: "")
            }
            curr = nextNode
        }

        // Add final leg
        if (currentLegLineId != "WALK" && currentLegStations.size > 1) {
            val lineObj = NetworkData.lineMap[currentLegLineId]!!
            legs.add(
                JourneyLeg(
                    lineId = currentLegLineId,
                    lineName = lineObj.name,
                    colorHex = lineObj.colorHex,
                    startStationId = currentLegStartNode.stationId,
                    startStationName = NetworkData.stationMap[currentLegStartNode.stationId]?.name ?: "",
                    endStationId = curr.stationId,
                    endStationName = NetworkData.stationMap[curr.stationId]?.name ?: "",
                    direction = getDirectionForLeg(currentLegLineId, currentLegStartNode.stationId, curr.stationId),
                    intermediateStationsCount = currentLegStations.size - 2,
                    durationMinutes = currentLegDuration.toInt(),
                    stationNames = currentLegStations.toList()
                )
            )
        }

        val totalDuration = distances[targetNodeReached]?.toInt() ?: 15
        val transfersCount = legs.size - 1

        val depTime = "10:42"
        val arrTime = calculateTimeSum(depTime, totalDuration)

        return Journey(
            fromStationId = startStationId,
            toStationId = endStationId,
            fromStationName = startStation.name,
            toStationName = endStation.name,
            departureTime = depTime,
            arrivalTime = arrTime,
            durationMinutes = totalDuration,
            transfersCount = if (transfersCount < 0) 0 else transfersCount,
            legs = legs
        )
    }

    private fun getDirectionForLeg(lineId: String, startId: String, endId: String): String {
        val line = NetworkData.lineMap[lineId] ?: return "Unbekannt"
        val startIndex = line.stations.indexOf(startId)
        val endIndex = line.stations.indexOf(endId)
        return if (startIndex <= endIndex) line.direction1 else line.direction2
    }

    private fun calculateTimeSum(startTime: String, addMinutes: Int): String {
        val parts = startTime.split(":")
        val hrs = parts[0].toIntOrNull() ?: 10
        val mins = parts[1].toIntOrNull() ?: 42
        val totalMins = hrs * 60 + mins + addMinutes
        val finalHrs = (totalMins / 60) % 24
        val finalMins = totalMins % 60
        return String.format("%02d:%02d", finalHrs, finalMins)
    }
}
