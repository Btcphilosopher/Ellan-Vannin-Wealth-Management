package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NetworkData
import com.example.domain.Station
import com.example.ui.Screen
import com.example.ui.UbahnViewModel
import com.example.ui.theme.BvgYellow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: UbahnViewModel,
    modifier: Modifier = Modifier
) {
    val clockTime by viewModel.clockTime.collectAsState()
    val startSt by viewModel.startStation.collectAsState()
    val destSt by viewModel.destStation.collectAsState()
    val favs by viewModel.favourites.collectAsState()
    val activeDisruptions by viewModel.activeDisruptions.collectAsState()

    var showStartPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }

    val homeStation = NetworkData.stations.find { it.id == "alexanderplatz" }!!
    val homeDepartures = remember(clockTime, activeDisruptions) {
        viewModel.getSimulatedDepartures(homeStation).take(3)
    }

    // Greeting based on hour
    val greeting = remember(clockTime) {
        val hour = clockTime.split(":").firstOrNull()?.toIntOrNull() ?: 10
        when (hour) {
            in 4..11 -> "Guten Morgen."
            in 12..17 -> "Guten Tag."
            else -> "Guten Abend."
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Title Header & Clock
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BERLIN",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "U-BAHN.OS",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Deine Fahrt durch Berlin.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = clockTime,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }
        }

        // Greeting
        item {
            Text(
                text = greeting,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        // Connection Selector Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(0.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "WOHIN MÖCHTEST DU?",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Start Picker Input
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showStartPicker = true }
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp))
                            .background(MaterialTheme.colorScheme.background)
                            .padding(12.dp)
                            .testTag("start_picker_trigger")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TripOrigin, contentDescription = "Start", tint = BvgYellow, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = startSt?.name ?: "Startstation wählen...",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (startSt != null) FontWeight.Bold else FontWeight.Normal,
                                color = if (startSt != null) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Destination Picker Input
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showDestPicker = true }
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp))
                            .background(MaterialTheme.colorScheme.background)
                            .padding(12.dp)
                            .testTag("dest_picker_trigger")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Place, contentDescription = "Ziel", tint = Color.Red, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = destSt?.name ?: "Zielstation wählen...",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (destSt != null) FontWeight.Bold else FontWeight.Normal,
                                color = if (destSt != null) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Find Connection Button
                    Button(
                        onClick = {
                            if (startSt != null && destSt != null) {
                                viewModel.searchConnection()
                                viewModel.setScreen(Screen.Search)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_connection_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(0.dp),
                        enabled = startSt != null && destSt != null
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("→ Verbindung suchen", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }

        // Nächste Abfahrten Section
        item {
            Column {
                Text(
                    text = "NÄCHSTE ABFAHRTEN (${homeStation.name})",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        homeDepartures.forEach { departure ->
                            val line = NetworkData.lineMap[departure.lineId]!!
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Line Badge
                                    Box(
                                        modifier = Modifier
                                            .background(line.color)
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                            .widthIn(min = 36.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = line.name,
                                            color = Color.White,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = departure.destination,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = if (departure.status == com.example.domain.DepartureStatus.FAELLT_AUS) "fällt aus" else "${departure.minutesAway} min",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (departure.status == com.example.domain.DepartureStatus.FAELLT_AUS) Color.Red else MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                        Divider(modifier = Modifier.padding(vertical = 4.dp))
                        Text(
                            text = "DEMO / SIMULATIONSDATEN",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }
            }
        }

        // Active Notices (Aktuelle Hinweise)
        item {
            val alerts = activeDisruptions.filter { it.type == com.example.domain.DisruptionType.AUSFALL || it.type == com.example.domain.DisruptionType.STOERUNG }
            Column {
                Text(
                    text = "AKTUELLE HINWEISE",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (alerts.isNotEmpty()) Color.Red else MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        if (alerts.isNotEmpty()) {
                            alerts.take(2).forEach { alert ->
                                Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(bottom = 8.dp)) {
                                    Icon(Icons.Default.Warning, contentDescription = "Störung", tint = Color.Red, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(text = alert.title, fontWeight = FontWeight.Bold, color = Color.Red, fontSize = 14.sp)
                                        Text(text = alert.description, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                            Text(
                                text = "Tippe im Hauptmenü auf 'Störungen' für Details.",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Normalbetrieb", tint = Color(0xFF4CD964), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(text = "Normalbetrieb auf allen Linien", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(text = "Aktuell liegen keine Streckensperrungen vor.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Meine Orte (Saved Favourites)
        item {
            Column {
                Text(
                    text = "MEINE ORTE",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        if (favs.isNotEmpty()) {
                            favs.forEach { fav ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            // Quick set start or destination
                                            val station = NetworkData.stationMap[fav.stationId]
                                            if (station != null) {
                                                if (startSt == null) {
                                                    viewModel.startStation.value = station
                                                } else if (destSt == null && destSt?.id != station.id) {
                                                    viewModel.destStation.value = station
                                                } else {
                                                    viewModel.startStation.value = station
                                                }
                                            }
                                        }
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = when (fav.label) {
                                                "Zuhause" -> Icons.Default.Home
                                                "Arbeit" -> Icons.Default.Work
                                                else -> Icons.Default.Favorite
                                            },
                                            contentDescription = fav.label,
                                            tint = MaterialTheme.colorScheme.secondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(text = fav.label, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text(text = fav.stationName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                                        }
                                    }
                                    Icon(Icons.Default.ArrowForwardIos, contentDescription = "Wählen", tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(12.dp))
                                }
                            }
                        } else {
                            Text(
                                text = "Keine Orte gespeichert.",
                                modifier = Modifier.padding(12.dp),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal Sheet Station Selectors
    if (showStartPicker) {
        StationPickerDialog(
            title = "Startstation wählen",
            onDismiss = { showStartPicker = false },
            onSelect = {
                viewModel.startStation.value = it
                showStartPicker = false
            }
        )
    }

    if (showDestPicker) {
        StationPickerDialog(
            title = "Zielstation wählen",
            onDismiss = { showDestPicker = false },
            onSelect = {
                viewModel.destStation.value = it
                showDestPicker = false
            }
        )
    }
}

@Composable
fun StationPickerDialog(
    title: String,
    onDismiss: () -> Unit,
    onSelect: (Station) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Abbrechen", color = MaterialTheme.colorScheme.onBackground)
            }
        },
        title = { Text(text = title, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
        text = {
            Box(modifier = Modifier.height(300.dp)) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(NetworkData.stations.sortedBy { it.name }) { station ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(station) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
                            shape = RoundedCornerShape(0.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = station.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    station.lines.forEach { lineId ->
                                        val line = NetworkData.lineMap[lineId]!!
                                        Box(
                                            modifier = Modifier
                                                .background(line.color)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = line.name,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        shape = RoundedCornerShape(0.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )
}
