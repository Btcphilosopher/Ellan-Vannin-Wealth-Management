package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NetworkData
import com.example.domain.Station
import com.example.ui.Screen
import com.example.ui.UbahnViewModel
import kotlin.math.sqrt

@OptIn(ExperimentalTextApi::class)
@Composable
fun NetworkMapScreen(
    viewModel: UbahnViewModel,
    modifier: Modifier = Modifier
) {
    val results by viewModel.searchResults.collectAsState()

    // Transform states for zoom & pan
    var scale by remember { mutableStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.5f, 4.0f)
        offset += offsetChange
    }

    val textMeasurer = rememberTextMeasurer()

    // Set up path highlight set if a searched route is active
    val highlightedStationIds = remember(results) {
        val set = mutableSetOf<String>()
        results?.legs?.forEach { leg ->
            set.add(leg.startStationId)
            set.add(leg.endStationId)
            leg.stationNames.forEach { name ->
                val id = NetworkData.stations.find { it.name == name }?.id
                if (id != null) set.add(id)
            }
        }
        set
    }

    val highlightedLineIds = remember(results) {
        results?.legs?.map { it.lineId }?.toSet() ?: emptySet()
    }

    val isPathHighlightActive = highlightedStationIds.isNotEmpty()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Map header panel
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NETZPLAN",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "Interaktives U-Bahn-Netz",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            // Reset Button
            TextButton(
                onClick = {
                    scale = 1.0f
                    offset = Offset.Zero
                },
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Zentrieren", fontWeight = FontWeight.Bold)
            }
        }

        if (isPathHighlightActive) {
            // Highlighting info banner
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0x224CD964)),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Info, contentDescription = "Highlight", tint = Color(0xFF4CD964), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Routen-Hervorhebung aktiv. Andere Abschnitte sind gedimmt.",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color(0xFF4CD964)
                    )
                }
            }
        }

        // Canvas container box with gesture support
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF0F0F11))
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp))
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { tapOffset ->
                            // Calculate which station is tapped
                            // Transform the tap coordinate back into the map's normalized grid space
                            val canvasWidth = size.width.toFloat()
                            val canvasHeight = size.height.toFloat()

                            val actualX = (tapOffset.x - offset.x) / scale
                            val actualY = (tapOffset.y - offset.y) / scale

                            var closestStation: Station? = null
                            var minDistance = Float.MAX_VALUE

                            NetworkData.stations.forEach { station ->
                                val xGrid = (station.latitude / 100.0) * canvasWidth
                                val yGrid = (station.longitude / 100.0) * canvasHeight
                                val distance = sqrt((actualX - xGrid) * (actualX - xGrid) + (actualY - yGrid) * (actualY - yGrid))
                                if (distance < 40.dp.toPx() && distance < minDistance) {
                                    minDistance = distance.toFloat()
                                    closestStation = station
                                }
                            }

                            if (closestStation != null) {
                                viewModel.selectedStation.value = closestStation!!
                                viewModel.setScreen(Screen.Station)
                            }
                        }
                    )
                }
                .transformable(state = state)
                .testTag("network_map_canvas_box")
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // 1. Draw Network Connections (Lines)
                NetworkData.lines.forEach { line ->
                    val stationsOnLine = line.stations
                    val isLineHighlighted = highlightedLineIds.contains(line.id)
                    val lineOpacity = if (isPathHighlightActive) {
                        if (isLineHighlighted) 1.0f else 0.15f
                    } else 1.0f

                    for (i in 0 until stationsOnLine.size - 1) {
                        val s1 = NetworkData.stationMap[stationsOnLine[i]] ?: continue
                        val s2 = NetworkData.stationMap[stationsOnLine[i + 1]] ?: continue

                        // Check if both consecutive stations are highlighted to confirm this specific leg segment is active
                        val isSegmentHighlighted = highlightedStationIds.contains(s1.id) && highlightedStationIds.contains(s2.id)
                        val segmentOpacity = if (isPathHighlightActive) {
                            if (isSegmentHighlighted) 1.0f else 0.12f
                        } else 1.0f

                        val startX = ((s1.latitude / 100.0) * canvasWidth).toFloat()
                        val startY = ((s1.longitude / 100.0) * canvasHeight).toFloat()
                        val endX = ((s2.latitude / 100.0) * canvasWidth).toFloat()
                        val endY = ((s2.longitude / 100.0) * canvasHeight).toFloat()

                        drawLine(
                            color = line.color,
                            start = Offset(startX, startY),
                            end = Offset(endX, endY),
                            strokeWidth = 4.dp.toPx(),
                            alpha = segmentOpacity
                        )
                    }
                }

                // 2. Draw Station Nodes
                NetworkData.stations.forEach { station ->
                    val isStationHighlighted = highlightedStationIds.contains(station.id)
                    val nodeOpacity = if (isPathHighlightActive) {
                        if (isStationHighlighted) 1.0f else 0.15f
                    } else 1.0f

                    val cx = ((station.latitude / 100.0) * canvasWidth).toFloat()
                    val cy = ((station.longitude / 100.0) * canvasHeight).toFloat()

                    // Draw outer border (Main line color or default white)
                    val borderClr = if (station.lines.isNotEmpty()) {
                        NetworkData.lineMap[station.lines.first()]?.color ?: Color.White
                    } else Color.White

                    // Inner circle
                    drawCircle(
                        color = borderClr,
                        radius = 7.dp.toPx(),
                        center = Offset(cx, cy),
                        alpha = nodeOpacity
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 4.dp.toPx(),
                        center = Offset(cx, cy),
                        alpha = nodeOpacity
                    )

                    // Draw station name labels (small text)
                    if (scale >= 1.2f || isStationHighlighted) {
                        val textStyle = TextStyle(
                            color = Color.White,
                            fontSize = (8 / scale).coerceAtLeast(7f).sp,
                            fontWeight = if (isStationHighlighted) FontWeight.Bold else FontWeight.Medium
                        )
                        val textResult = textMeasurer.measure(station.name, textStyle)
                        drawText(
                            textLayoutResult = textResult,
                            topLeft = Offset(cx + 10.dp.toPx(), cy - 6.dp.toPx()),
                            alpha = nodeOpacity
                        )
                    }
                }
            }

            // Zoom In / Out Buttons Float Overlay
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FloatingActionButton(
                    onClick = { scale = (scale * 1.3f).coerceIn(0.5f, 4.0f) },
                    containerColor = Color.Black,
                    contentColor = MaterialTheme.colorScheme.primary,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Zoom in", modifier = Modifier.size(18.dp))
                }
                FloatingActionButton(
                    onClick = { scale = (scale / 1.3f).coerceIn(0.5f, 4.0f) },
                    containerColor = Color.Black,
                    contentColor = MaterialTheme.colorScheme.primary,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Zoom out", modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
