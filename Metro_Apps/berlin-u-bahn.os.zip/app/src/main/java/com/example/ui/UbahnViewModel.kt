package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.NetworkData
import com.example.database.AppDatabase
import com.example.database.FavouriteEntity
import com.example.database.JourneyHistoryEntity
import com.example.database.TicketEntity
import com.example.domain.*
import com.example.routing.RoutingEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class UbahnViewModel(application: Application) : AndroidViewModel(application) {

    // Database Initialization
    private val db = Room.databaseBuilder(
        application,
        AppDatabase::class.java, "berlin-ubahn-os-db"
    ).fallbackToDestructiveMigration().build()

    private val dao = db.ubahnDao()

    // UI Screen State
    private val _currentScreen = MutableStateFlow(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Clock state (HH:MM:SS)
    private val _clockTime = MutableStateFlow("10:42:00")
    val clockTime: StateFlow<String> = _clockTime.asStateFlow()

    private var clockJob: Job? = null
    private var secondCounter = 0

    // Favourites & Journey History from Room
    val favourites: StateFlow<List<FavouriteEntity>> = dao.getAllFavourites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val journeyHistory: StateFlow<List<JourneyHistoryEntity>> = dao.getJourneyHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchasedTickets: StateFlow<List<TicketEntity>> = dao.getAllTickets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Disruptions in the simulation
    private val _activeDisruptions = MutableStateFlow<List<Disruption>>(emptyList())
    val activeDisruptions: StateFlow<List<Disruption>> = _activeDisruptions.asStateFlow()

    // Connection search state
    val startStation = MutableStateFlow<Station?>(null)
    val destStation = MutableStateFlow<Station?>(null)
    val searchConfig = MutableStateFlow(SearchConfig())
    
    private val _searchResults = MutableStateFlow<Journey?>(null)
    val searchResults: StateFlow<Journey?> = _searchResults.asStateFlow()

    // Used for the disruption demo (old route vs. new route)
    private val _oldRouteBeforeDisruption = MutableStateFlow<Journey?>(null)
    val oldRouteBeforeDisruption: StateFlow<Journey?> = _oldRouteBeforeDisruption.asStateFlow()
    
    private val _showDisruptionRerouteInfo = MutableStateFlow(false)
    val showDisruptionRerouteInfo: StateFlow<Boolean> = _showDisruptionRerouteInfo.asStateFlow()

    // Selected Station for Departure Board & Wayfinding
    val selectedStation = MutableStateFlow<Station>(NetworkData.stations.first())
    
    // Active Journey Mode (Reisebegleitung)
    private val _activeJourney = MutableStateFlow<Journey?>(null)
    val activeJourney: StateFlow<Journey?> = _activeJourney.asStateFlow()

    private val _currentLegIndex = MutableStateFlow(0)
    val currentLegIndex: StateFlow<Int> = _currentLegIndex.asStateFlow()

    private val _currentStationIndex = MutableStateFlow(0) // Index within the current leg's stations
    val currentStationIndex: StateFlow<Int> = _currentStationIndex.asStateFlow()

    private val _secondsToNextStop = MutableStateFlow(15) // Dynamic countdown
    val secondsToNextStop: StateFlow<Int> = _secondsToNextStop.asStateFlow()

    private val _isJourneyCompleted = MutableStateFlow(false)
    val isJourneyCompleted: StateFlow<Boolean> = _isJourneyCompleted.asStateFlow()

    private var journeySimulationJob: Job? = null

    // Ticket Purchase state
    val selectedFareProduct = MutableStateFlow<FareProduct?>(null)
    val selectedFareZone = MutableStateFlow(FareZone.AB)
    val selectedPaymentMethod = MutableStateFlow(PaymentMethod.APPLE_PAY)
    
    private val _isPaymentProcessing = MutableStateFlow(false)
    val isPaymentProcessing: StateFlow<Boolean> = _isPaymentProcessing.asStateFlow()

    private val _purchasedTicketDetails = MutableStateFlow<TicketEntity?>(null)
    val purchasedTicketDetails: StateFlow<TicketEntity?> = _purchasedTicketDetails.asStateFlow()

    // List of standard products
    val fareProducts = listOf(
        FareProduct("einzel", "Einzelfahrschein", "Einzelfahrt für 120 Min in eine Richtung.", 3.50, 4.40),
        FareProduct("kurz", "Kurzstrecke", "Max. 3 Stationen mit der U-Bahn.", 2.40, 3.20),
        FareProduct("karte4", "4-Fahrten-Karte", "Vier Einzelfahrscheine im Paket.", 10.80, 14.20),
        FareProduct("std24", "24-Stunden-Karte", "Beliebig viele Fahrten für 24 Stunden.", 9.90, 11.50),
        FareProduct("tage7", "7-Tage-Karte", "7 Tage Mobilität im Tarifbereich.", 41.50, 49.00),
        FareProduct("monat", "Monatskarte", "Persönliches Monatsticket (Gleitend).", 99.00, 114.00),
        FareProduct("d_ticket", "Deutschlandticket", "Bundesweit gültiges Nahverkehrsticket.", 49.00, 49.00)
    )

    init {
        // Start simulated system clock
        startClock()
        // Pre-populate Database with default Favourites & Tickets to feel production-ready immediately
        prepopulateDatabase()
    }

    private fun startClock() {
        clockJob?.cancel()
        clockJob = viewModelScope.launch {
            var hr = 10
            var min = 42
            var sec = 0
            while (true) {
                delay(1000)
                sec++
                if (sec >= 60) {
                    sec = 0
                    min++
                    if (min >= 60) {
                        min = 0
                        hr++
                        if (hr >= 24) {
                            hr = 0
                        }
                    }
                }
                _clockTime.value = String.format("%02d:%02d:%02d", hr, min, sec)
                
                // Decrement journey countdown if traveling
                if (_activeJourney.value != null && !_isJourneyCompleted.value) {
                    val currentVal = _secondsToNextStop.value
                    if (currentVal > 1) {
                        _secondsToNextStop.value = currentVal - 1
                    } else {
                        // Advance stop
                        advanceJourneyStop()
                    }
                }
            }
        }
    }

    private fun prepopulateDatabase() {
        viewModelScope.launch {
            // Check if database is empty
            val currentFavs = dao.getAllFavourites().first()
            if (currentFavs.isEmpty()) {
                dao.insertFavourite(FavouriteEntity(label = "Zuhause", stationId = "alexanderplatz", stationName = "Alexanderplatz"))
                dao.insertFavourite(FavouriteEntity(label = "Arbeit", stationId = "zoologischer_garten", stationName = "Zoologischer Garten"))
                dao.insertFavourite(FavouriteEntity(label = "Universität", stationId = "hauptbahnhof", stationName = "Hauptbahnhof"))
            }

            val currentTickets = dao.getAllTickets().first()
            if (currentTickets.isEmpty()) {
                // Insert a realistic expired ticket as the "Vergangene Tickets" requirement
                val now = System.currentTimeMillis()
                val oneDayMs = 24 * 60 * 60 * 1000L
                dao.insertTicket(
                    TicketEntity(
                        ticketId = "TCK-${UUID.randomUUID().toString().take(8).uppercase()}",
                        title = "Einzelfahrschein",
                        zone = "Berlin AB",
                        price = "3,50 €",
                        purchaseTimestamp = now - oneDayMs * 2,
                        validFromTimestamp = now - oneDayMs * 2,
                        validToTimestamp = now - oneDayMs * 2 + (2 * 60 * 60 * 1000L),
                        isActive = false
                    )
                )
            }
        }
    }

    fun setScreen(screen: Screen) {
        _currentScreen.value = screen
    }

    // Toggle simulated disruption triggers
    fun toggleDisruption(scenarioId: String) {
        val current = _activeDisruptions.value.toMutableList()
        val exists = current.find { it.id == scenarioId }
        
        if (exists != null) {
            current.remove(exists)
        } else {
            val newDisruption = when (scenarioId) {
                "u2_closure" -> Disruption(
                    id = "u2_closure",
                    type = DisruptionType.AUSFALL,
                    lineId = "U2",
                    title = "U2 Streckensperrung",
                    description = "Gleissperrung wegen Bauarbeiten. Kein Zugverkehr zwischen Alexanderplatz und Senefelderplatz.",
                    startStationId = "alexanderplatz",
                    endStationId = "rosa_luxemburg_platz"
                )
                "u6_partial" -> Disruption(
                    id = "u6_partial",
                    type = DisruptionType.AUSFALL,
                    lineId = "U6",
                    title = "U6 Teilsperrung",
                    description = "Weichenstörung. Einschränkungen und unregelmäßiger Zugverkehr zwischen Wedding und Friedrichstraße.",
                    startStationId = "wedding",
                    endStationId = "friedrichstrasse"
                )
                "u7_delay" -> Disruption(
                    id = "u7_delay",
                    type = DisruptionType.VERSPAETUNG,
                    lineId = "U7",
                    title = "U7 Signalstörung",
                    description = "Signalstörung im Bereich Bismarckstraße. Rechnen Sie mit Verspätungen von ca. 10 Minuten.",
                    startStationId = "spandau",
                    endStationId = "bismarckstrasse"
                )
                "u8_signal" -> Disruption(
                    id = "u8_signal",
                    type = DisruptionType.AUSFALL,
                    lineId = "U8",
                    title = "U8 Signalstörung",
                    description = "Signalstörung. Streckenabschnitt gesperrt zwischen Alexanderplatz und Kottbusser Tor.",
                    startStationId = "alexanderplatz",
                    endStationId = "kottbusser_tor"
                )
                else -> null
            }
            if (newDisruption != null) {
                current.add(newDisruption)
            }
        }
        
        _activeDisruptions.value = current
        
        // Retrigger routing calculation if we have active endpoints
        recalculateActiveSearch()
    }

    // Trigger Connection Search
    fun searchConnection() {
        val start = startStation.value ?: return
        val dest = destStation.value ?: return
        
        val route = RoutingEngine.findRoute(
            startStationId = start.id,
            endStationId = dest.id,
            config = searchConfig.value,
            activeDisruptions = _activeDisruptions.value
        )

        // Save to local journey history Room database
        viewModelScope.launch {
            dao.insertJourneyHistory(
                JourneyHistoryEntity(
                    fromStationId = start.id,
                    fromStationName = start.name,
                    toStationId = dest.id,
                    toStationName = dest.name
                )
            )
        }

        _searchResults.value = route
        _showDisruptionRerouteInfo.value = false
    }

    private fun recalculateActiveSearch() {
        val start = startStation.value ?: return
        val dest = destStation.value ?: return

        // Compute route without disruptions first to demonstrate old vs new
        val oldRoute = RoutingEngine.findRoute(
            startStationId = start.id,
            endStationId = dest.id,
            config = searchConfig.value,
            activeDisruptions = emptyList() // No disruptions
        )

        val newRoute = RoutingEngine.findRoute(
            startStationId = start.id,
            endStationId = dest.id,
            config = searchConfig.value,
            activeDisruptions = _activeDisruptions.value // With disruptions
        )

        if (oldRoute != null && newRoute != null && oldRoute.legs != newRoute.legs) {
            _oldRouteBeforeDisruption.value = oldRoute
            _searchResults.value = newRoute
            _showDisruptionRerouteInfo.value = true
        } else {
            _searchResults.value = newRoute
            _showDisruptionRerouteInfo.value = false
        }
    }

    // Start Reise-Modus (Journey Progress companion)
    fun startJourney(journey: Journey) {
        _activeJourney.value = journey
        _currentLegIndex.value = 0
        _currentStationIndex.value = 0
        _secondsToNextStop.value = 15 // Start with 15-second countdown to next stop
        _isJourneyCompleted.value = false
        setScreen(Screen.Journey)
    }

    fun stopJourney() {
        _activeJourney.value = null
        _isJourneyCompleted.value = false
        setScreen(Screen.Home)
    }

    private fun advanceJourneyStop() {
        val journey = _activeJourney.value ?: return
        val legIdx = _currentLegIndex.value
        val leg = journey.legs.getOrNull(legIdx) ?: return
        val statIdx = _currentStationIndex.value

        // If there are more stations in this leg, advance
        if (statIdx < leg.stationNames.size - 1) {
            _currentStationIndex.value = statIdx + 1
            _secondsToNextStop.value = 15
        } else {
            // We reached the end of this leg
            if (legIdx < journey.legs.size - 1) {
                // Switch to next leg (Transfer!)
                _currentLegIndex.value = legIdx + 1
                _currentStationIndex.value = 0
                _secondsToNextStop.value = 15
            } else {
                // Completed entire journey
                _isJourneyCompleted.value = true
            }
        }
    }

    // Purchase Sandbox Ticket
    fun purchaseTicket() {
        val fare = selectedFareProduct.value ?: return
        val zone = selectedFareZone.value
        val priceDouble = if (zone == FareZone.AB) fare.basePriceAB else fare.basePriceABC
        val priceStr = String.format("%.2f € DEMO", priceDouble).replace(".", ",")

        _isPaymentProcessing.value = true
        viewModelScope.launch {
            delay(1500) // Simulate payment authorization
            
            val now = System.currentTimeMillis()
            val expiryMs = when (fare.id) {
                "einzel", "kurz" -> 2 * 60 * 60 * 1000L
                "std24" -> 24 * 60 * 60 * 1000L
                "tage7" -> 7 * 24 * 60 * 60 * 1000L
                else -> 30 * 24 * 60 * 60 * 1000L
            }

            val newTicket = TicketEntity(
                ticketId = "TCK-${UUID.randomUUID().toString().take(8).uppercase()}",
                title = fare.title,
                zone = "Berlin ${zone.name}",
                price = priceStr,
                purchaseTimestamp = now,
                validFromTimestamp = now,
                validToTimestamp = now + expiryMs,
                isActive = true
            )

            dao.insertTicket(newTicket)
            _purchasedTicketDetails.value = newTicket
            _isPaymentProcessing.value = false
            setScreen(Screen.Tickets)
        }
    }

    fun selectFareProductToPurchase(fare: FareProduct) {
        selectedFareProduct.value = fare
        // Reset defaults
        selectedFareZone.value = FareZone.AB
        selectedPaymentMethod.value = PaymentMethod.APPLE_PAY
    }

    // Helper to get simulated upcoming departures for selected station
    fun getSimulatedDepartures(station: Station): List<Departure> {
        val departures = mutableListOf<Departure>()
        // Generate deterministic, authentic upcoming departures based on station lines
        station.lines.forEachIndexed { index, lineId ->
            val line = NetworkData.lineMap[lineId] ?: return@forEachIndexed
            
            // Check if there is an active delay or disruption on this line
            val hasDelay = _activeDisruptions.value.any { it.lineId == lineId && it.type == DisruptionType.VERSPAETUNG }
            val isClosed = _activeDisruptions.value.any { it.lineId == lineId && it.type == DisruptionType.AUSFALL }
            
            if (isClosed) {
                departures.add(
                    Departure(
                        lineId = lineId,
                        destination = line.direction1,
                        minutesAway = 0,
                        status = DepartureStatus.FAELLT_AUS,
                        platform = "Gleis ${index + 1}"
                    )
                )
            } else {
                val delayOffset = if (hasDelay) 10 else 0
                val min1 = ((index * 3 + secondCounter / 10) % 8 + 2) + delayOffset
                val min2 = min1 + 6
                
                departures.add(
                    Departure(
                        lineId = lineId,
                        destination = line.direction1,
                        minutesAway = min1,
                        status = if (hasDelay) DepartureStatus.VERSPAETET else DepartureStatus.PLANMAESSIG,
                        platform = "Gleis ${index + 1}"
                    )
                )
                departures.add(
                    Departure(
                        lineId = lineId,
                        destination = line.direction2,
                        minutesAway = min2,
                        status = DepartureStatus.PLANMAESSIG,
                        platform = "Gleis ${index + 2}"
                    )
                )
            }
        }
        return departures.sortedBy { it.minutesAway }
    }

    // Toggle favourite
    fun toggleFavouriteStation(station: Station) {
        viewModelScope.launch {
            val current = favourites.value.find { it.stationId == station.id }
            if (current != null) {
                dao.deleteFavourite(current.id)
            } else {
                dao.insertFavourite(
                    FavouriteEntity(
                        label = station.name,
                        stationId = station.id,
                        stationName = station.name
                    )
                )
            }
        }
    }

    // Live Train Simulation data for lines screen
    fun getSimulatedTrainsForLine(lineId: String): List<Pair<String, Int>> {
        // Returns list of (StationID, ProgressPercentage 0..100)
        val line = NetworkData.lineMap[lineId] ?: return emptyList()
        val stationsCount = line.stations.size
        if (stationsCount < 2) return emptyList()

        val results = mutableListOf<Pair<String, Int>>()
        // Simulate 2 trains moving back and forth based on clock second counter
        val progressPercent1 = (secondCounter * 4) % 100
        val stationIndex1 = (secondCounter / 25) % (stationsCount - 1)
        val currentStationId1 = line.stations[stationIndex1]
        results.add(currentStationId1 to progressPercent1)

        val progressPercent2 = (100 - (secondCounter * 4) % 100)
        val stationIndex2 = (stationsCount - 1) - (secondCounter / 25) % (stationsCount - 1)
        val currentStationId2 = line.stations[stationIndex2]
        results.add(currentStationId2 to progressPercent2)

        return results
    }

    fun incrementSecondCounter() {
        secondCounter = (secondCounter + 1) % 3000
    }
}

// Navigation screen enum
enum class Screen(val label: String) {
    Home("Fahrten"),
    Search("Verbindungen"),
    Journey("Reise"),
    Station("Haltestellen"),
    Lines("Linien"),
    Network("Netzplan"),
    Tickets("Tickets"),
    Disruptions("Störungen"),
    Settings("Mehr")
}
