package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BvgYellow = Color(0xFFF0CA00)
val BvgYellowDark = Color(0xFFD0AE00)
val BvgBlack = Color(0xFF121212)
val BvgDarkGrey = Color(0xFF1C1C1E)
val BvgLightGrey = Color(0xFFF4F4F4)
val BvgBorderGrey = Color(0xFFD1D1D6)
val BvgMediumGrey = Color(0xFF8E8E93)
val BvgWhite = Color(0xFFFFFFFF)

// U-Bahn Line Colors
val ColorU1 = Color(0xFF7DBB26)
val ColorU2 = Color(0xFFDA421E)
val ColorU3 = Color(0xFF007A5E)
val ColorU4 = Color(0xFFF0CA00)
val ColorU5 = Color(0xFF7E5330)
val ColorU6 = Color(0xFF8C5695)
val ColorU7 = Color(0xFF009DDF)
val ColorU8 = Color(0xFF1F5294)
val ColorU9 = Color(0xFFF17500)
