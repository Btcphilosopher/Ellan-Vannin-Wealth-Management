package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.TicketEntity
import com.example.domain.FareProduct
import com.example.domain.FareZone
import com.example.domain.PaymentMethod
import com.example.ui.UbahnViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TicketsScreen(
    viewModel: UbahnViewModel,
    modifier: Modifier = Modifier
) {
    val purchasedTickets by viewModel.purchasedTickets.collectAsState()
    val activeSelection by viewModel.selectedFareProduct.collectAsState()
    val activeZone by viewModel.selectedFareZone.collectAsState()
    val activePayment by viewModel.selectedPaymentMethod.collectAsState()
    val isProcessing by viewModel.isPaymentProcessing.collectAsState()

    var showDetailTicket by remember { mutableStateOf<TicketEntity?>(null) }

    val activeList = remember(purchasedTickets) { purchasedTickets.filter { it.isActive } }
    val expiredList = remember(purchasedTickets) { purchasedTickets.filter { !it.isActive } }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tickets Title Header
        item {
            Column {
                Text(
                    text = "FAHRKARTEN",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "BVG Ticket-Shop",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }

        if (activeSelection == null) {
            // VIEW A: Ticket Catalog & Wallet Lists
            
            // 1. MEINE TICKETS (Active wallet)
            item {
                Text(
                    text = "MEINE AKTIVEN TICKETS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )

                if (activeList.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        activeList.forEach { ticket ->
                            ActiveTicketCard(ticket = ticket, onInspect = { showDetailTicket = ticket })
                        }
                    }
                } else {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(0.dp)
                    ) {
                        Text(
                            text = "Keine aktiven Tickets vorhanden. Kaufe ein Ticket aus der Liste unten.",
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // 2. Ticket Products Catalog (TICKET AUSWÄHLEN)
            item {
                Text(
                    text = "TICKET AUSWÄHLEN",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    viewModel.fareProducts.forEach { fare ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp))
                                .clickable { viewModel.selectFareProductToPurchase(fare) }
                                .testTag("select_fare_product_${fare.id}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(0.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = fare.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text(text = fare.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    text = String.format("ab %.2f €", fare.basePriceAB).replace(".", ","),
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }

            // 3. Vergangene Tickets (Past archival)
            item {
                Text(
                    text = "VERGANGENE TICKETS (ARCHIV)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )

                if (expiredList.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        expiredList.forEach { ticket ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surface)
                                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp))
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = ticket.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.secondary)
                                    Text(text = ticket.zone, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                                }
                                Text(text = "Abgelaufen", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            }
                        }
                    }
                }
            }

        } else {
            // VIEW B: Checkout Sandbox payment panel
            val fare = activeSelection!!
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.selectedFareProduct.value = null }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Zurück")
                    }
                    Text(text = "Fahrkarte kaufen", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                }
            }

            // Fare details
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = fare.title, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text(text = fare.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }

            // TARIFBEREICH Select
            item {
                Column {
                    Text(text = "TARIFBEREICH WÄHLEN", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(bottom = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .border(
                                    width = 1.dp,
                                    color = if (activeZone == FareZone.AB) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    shape = RoundedCornerShape(0.dp)
                                )
                                .clickable { viewModel.selectedFareZone.value = FareZone.AB },
                            colors = CardDefaults.cardColors(containerColor = if (activeZone == FareZone.AB) Color(0x11F0CA00) else MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(0.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "Berlin AB", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                Text(text = String.format("%.2f €", fare.basePriceAB).replace(".", ","), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                            }
                        }

                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .border(
                                    width = 1.dp,
                                    color = if (activeZone == FareZone.ABC) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    shape = RoundedCornerShape(0.dp)
                                )
                                .clickable { viewModel.selectedFareZone.value = FareZone.ABC },
                            colors = CardDefaults.cardColors(containerColor = if (activeZone == FareZone.ABC) Color(0x11F0CA00) else MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(0.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "Berlin ABC", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                Text(text = String.format("%.2f €", fare.basePriceABC).replace(".", ","), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }

            // ZAHLUNGSMETHODE SELECT
            item {
                Column {
                    Text(text = "ZAHLUNGSMETHODE", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(bottom = 6.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(0.dp)
                    ) {
                        Column {
                            PaymentMethodRow(method = PaymentMethod.APPLE_PAY, active = activePayment, onSelect = { viewModel.selectedPaymentMethod.value = it })
                            PaymentMethodRow(method = PaymentMethod.GOOGLE_PAY, active = activePayment, onSelect = { viewModel.selectedPaymentMethod.value = it })
                            PaymentMethodRow(method = PaymentMethod.KREDITKARTE, active = activePayment, onSelect = { viewModel.selectedPaymentMethod.value = it })
                            PaymentMethodRow(method = PaymentMethod.PAYPAL, active = activePayment, onSelect = { viewModel.selectedPaymentMethod.value = it })
                            PaymentMethodRow(method = PaymentMethod.SEPA, active = activePayment, onSelect = { viewModel.selectedPaymentMethod.value = it })
                        }
                    }
                }
            }

            // Kaufen Trigger button with payment indicator
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.purchaseTicket() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("buy_ticket_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.Black),
                        shape = RoundedCornerShape(0.dp),
                        enabled = !isProcessing
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.Black, strokeWidth = 2.dp)
                        } else {
                            val price = if (activeZone == FareZone.AB) fare.basePriceAB else fare.basePriceABC
                            val priceText = String.format("%.2f €", price).replace(".", ",")
                            Text(text = "KOSTENPFLICHTIG KAUFEN ($priceText)", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "HINWEIS: Dies ist eine sichere Sandbox-Simulation. Es finden keine echten Zahlungen statt und es wird kein echtes Ticket erworben.",
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.LightGray,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }

    // INSPECT FULL DETAIL QR TICKET SHEET DIALOG
    if (showDetailTicket != null) {
        val ticket = showDetailTicket!!
        AlertDialog(
            onDismissRequest = { showDetailTicket = null },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showDetailTicket = null }) {
                    Text("Schließen", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Text(text = "DEIN TICKET", fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            },
            text = {
                val dateFormat = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMAN) }
                val startStr = dateFormat.format(Date(ticket.validFromTimestamp))
                val endStr = dateFormat.format(Date(ticket.validToTimestamp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Card background with BVG Yellow Border Accent
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White)
                            .border(3.dp, MaterialTheme.colorScheme.primary)
                            .padding(16.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Title
                            Text(text = ticket.title.uppercase(), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color.Black)
                            Text(text = ticket.zone, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.Black)

                            Divider(color = Color.Black, modifier = Modifier.padding(vertical = 4.dp))

                            // Details
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Ticket ID:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray, fontWeight = FontWeight.Bold)
                                Text(text = ticket.ticketId, fontSize = 12.sp, color = Color.Black, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Gültig ab:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray, fontWeight = FontWeight.Bold)
                                Text(text = startStr, fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Gültig bis:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray, fontWeight = FontWeight.Bold)
                                Text(text = endStr, fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                            }

                            Divider(color = Color.Black, modifier = Modifier.padding(vertical = 8.dp))

                            // Schematic Mock QR Code
                            Box(
                                modifier = Modifier
                                    .size(160.dp)
                                    .background(Color.White)
                                    .border(1.dp, Color.Black)
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    // Draw simulated checker grid QR code
                                    val sizePx = size.width
                                    val count = 21
                                    val squareSize = sizePx / count
                                    val random = java.util.Random(ticket.ticketId.hashCode().toLong())

                                    for (x in 0 until count) {
                                        for (y in 0 until count) {
                                            // Make borders solid anchors
                                            val isAnchor = (x < 7 && y < 7) || (x > count - 8 && y < 7) || (x < 7 && y > count - 8)
                                            if (isAnchor) {
                                                val isBorder = x == 0 || x == 6 || y == 0 || y == 6 || (x > count - 8 && (x == count - 1 || x == count - 7)) || (y > count - 8 && (y == count - 1 || y == count - 7))
                                                val isHole = x in 2..4 && y in 2..4 || (x > count - 6 && x < count - 2 && y in 2..4) || (x in 2..4 && y > count - 6 && y < count - 2)
                                                if (isBorder || isHole) {
                                                    drawRect(
                                                        color = Color.Black,
                                                        topLeft = Offset(x * squareSize, y * squareSize),
                                                        size = androidx.compose.ui.geometry.Size(squareSize, squareSize)
                                                    )
                                                }
                                            } else {
                                                // Random pixels
                                                if (random.nextBoolean()) {
                                                    drawRect(
                                                        color = Color.Black,
                                                        topLeft = Offset(x * squareSize, y * squareSize),
                                                        size = androidx.compose.ui.geometry.Size(squareSize, squareSize)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // DEMO Label Banner overlay
                                Box(
                                    modifier = Modifier
                                        .background(Color.Red)
                                        .padding(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Text(text = "DEMO", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            },
            shape = RoundedCornerShape(0.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

@Composable
fun ActiveTicketCard(
    ticket: TicketEntity,
    onInspect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(0.dp))
            .clickable { onInspect() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(0.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.QrCode, contentDescription = "Active Ticket", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(text = ticket.title, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text(text = ticket.zone, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                }
            }
            Box(
                modifier = Modifier
                    .background(Color(0xFF4CD964))
                    .padding(horizontal = 10.dp, vertical = 2.dp)
            ) {
                Text(text = "AKTIV", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun PaymentMethodRow(
    method: PaymentMethod,
    active: PaymentMethod,
    onSelect: (PaymentMethod) -> Unit
) {
    val title = when (method) {
        PaymentMethod.APPLE_PAY -> "Apple Pay"
        PaymentMethod.GOOGLE_PAY -> "Google Pay"
        PaymentMethod.KREDITKARTE -> "Kreditkarte"
        PaymentMethod.PAYPAL -> "PayPal"
        PaymentMethod.SEPA -> "SEPA Lastschrift"
    }

    val icon = when (method) {
        PaymentMethod.APPLE_PAY, PaymentMethod.GOOGLE_PAY -> Icons.Default.Smartphone
        PaymentMethod.KREDITKARTE -> Icons.Default.CreditCard
        PaymentMethod.PAYPAL, PaymentMethod.SEPA -> Icons.Default.AccountBalanceWallet
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect(method) }
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        RadioButton(selected = active == method, onClick = { onSelect(method) })
    }
}
