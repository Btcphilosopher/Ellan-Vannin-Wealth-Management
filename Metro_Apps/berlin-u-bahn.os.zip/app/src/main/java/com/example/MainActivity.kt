package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.Screen
import com.example.ui.UbahnViewModel
import com.example.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: UbahnViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Persistent standard M3 Navigation Bar with active pills
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp,
                            modifier = Modifier.testTag("persistent_navigation_bar")
                        ) {
                            // Tab 1: Fahrten (Home / Search / Journey)
                            NavigationBarItem(
                                selected = currentScreen == Screen.Home || currentScreen == Screen.Search || currentScreen == Screen.Journey,
                                onClick = { viewModel.setScreen(Screen.Home) },
                                icon = { Icon(Icons.Default.DirectionsTransit, contentDescription = "Fahrten") },
                                label = { Text("Fahrten", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary
                                )
                            )

                            // Tab 2: Abfahrten (Station View)
                            NavigationBarItem(
                                selected = currentScreen == Screen.Station,
                                onClick = { viewModel.setScreen(Screen.Station) },
                                icon = { Icon(Icons.Default.LocationOn, contentDescription = "Haltestellen") },
                                label = { Text("Abfahrten", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary
                                )
                            )

                            // Tab 3: Tickets
                            NavigationBarItem(
                                selected = currentScreen == Screen.Tickets,
                                onClick = { viewModel.setScreen(Screen.Tickets) },
                                icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Tickets") },
                                label = { Text("Tickets", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary
                                )
                            )

                            // Tab 4: Netzplan
                            NavigationBarItem(
                                selected = currentScreen == Screen.Network,
                                onClick = { viewModel.setScreen(Screen.Network) },
                                icon = { Icon(Icons.Default.Map, contentDescription = "Netzplan") },
                                label = { Text("Netzplan", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary
                                )
                            )

                            // Tab 5: Mehr (Grouped index submenus)
                            NavigationBarItem(
                                selected = currentScreen == Screen.Settings || currentScreen == Screen.Lines || currentScreen == Screen.Disruptions,
                                onClick = { viewModel.setScreen(Screen.Settings) },
                                icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "Mehr") },
                                label = { Text("Mehr", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    },
                    contentWindowInsets = WindowInsets.safeDrawing // Prevent camera notch or navigation bars collision
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                            .padding(innerPadding)
                    ) {
                        // Core Screen Switcher
                        when (currentScreen) {
                            Screen.Home -> HomeScreen(viewModel = viewModel)
                            Screen.Search -> SearchScreen(viewModel = viewModel)
                            Screen.Journey -> JourneyScreen(viewModel = viewModel)
                            Screen.Station -> StationScreen(viewModel = viewModel)
                            Screen.Lines -> LinesScreen(viewModel = viewModel)
                            Screen.Network -> NetworkMapScreen(viewModel = viewModel)
                            Screen.Tickets -> TicketsScreen(viewModel = viewModel)
                            Screen.Disruptions -> DisruptionsScreen(viewModel = viewModel)
                            Screen.Settings -> SettingsIndexScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

// Submenu Tab "Mehr"
@Composable
fun SettingsIndexScreen(
    viewModel: UbahnViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = "BERLIN U-BAHN.OS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                text = "Weitere Dienste",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold
            )
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(0.dp)
        ) {
            Column {
                // Item 1: U-Bahn Linien
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.setScreen(Screen.Lines) }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AltRoute, contentDescription = "Linien", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(text = "U-Bahn Linien", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(text = "Streckenprofile & Live-Zugpositionen.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                    Icon(Icons.Default.ArrowForwardIos, contentDescription = "Go", tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(12.dp))
                }

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

                // Item 2: Störungen
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.setScreen(Screen.Disruptions) }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = "Störungszentrum", tint = Color.Red)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(text = "Störungszentrum & Simulator", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(text = "Aktuelle Warnungen & Strecken-Simulator.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                    Icon(Icons.Default.ArrowForwardIos, contentDescription = "Go", tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(12.dp))
                }
            }
        }

        // About the project Design Log Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(0.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "ÜBER BERLIN U-BAHN.OS",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Dieses System wurde im Berliner industriellen Modernismus gestaltet – angelehnt an die authentische Bahnhofsinfrastruktur der Berliner Verkehrsbetriebe (BVG).",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Justify
                )
                Text(
                    text = "Mit modernster Jetpack Compose Softwaretechnik, Dijkstra-Graphen-Routenberechnung und sicheren lokalen Room-Datenspeichern für Fährten, Favoriten und Fahrscheine.",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Justify,
                    color = MaterialTheme.colorScheme.secondary
                )
                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "Entwicklungsversion:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                    Text(text = "v3.5 - 2026 Edition", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}
