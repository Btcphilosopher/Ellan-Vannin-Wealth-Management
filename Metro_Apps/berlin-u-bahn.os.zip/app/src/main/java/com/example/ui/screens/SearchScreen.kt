package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NetworkData
import com.example.domain.Journey
import com.example.domain.SearchConfig
import com.example.ui.Screen
import com.example.ui.UbahnViewModel

@Composable
fun SearchScreen(
    viewModel: UbahnViewModel,
    modifier: Modifier = Modifier
) {
    val startSt by viewModel.startStation.collectAsState()
    val destSt by viewModel.destStation.collectAsState()
    val searchConfig by viewModel.searchConfig.collectAsState()
    val results by viewModel.searchResults.collectAsState()
    val oldRoute by viewModel.oldRouteBeforeDisruption.collectAsState()
    val showRerouteInfo by viewModel.showDisruptionRerouteInfo.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Search Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.setScreen(Screen.Home) }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Zurück")
                }
                Text(
                    text = "Verbindungssuche",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }

        // Connection Summary Inputs
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(0.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TripOrigin, contentDescription = "Von", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = "Von: ", fontWeight = FontWeight.Normal, color = MaterialTheme.colorScheme.secondary, fontSize = 14.sp)
                        Text(text = startSt?.name ?: "Nicht gewählt", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Place, contentDescription = "Nach", tint = Color.Red, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = "Nach: ", fontWeight = FontWeight.Normal, color = MaterialTheme.colorScheme.secondary, fontSize = 14.sp)
                        Text(text = destSt?.name ?: "Nicht gewählt", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        // Search Filter Options Block
        item {
            Column {
                Text(
                    text = "PREFERENZEN",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Schnellste Option
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Schnellste Verbindung", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Switch(
                                checked = searchConfig.preferFastest,
                                onCheckedChange = {
                                    viewModel.searchConfig.value = searchConfig.copy(preferFastest = it)
                                    viewModel.searchConnection()
                                }
                            )
                        }

                        // Wenige Umstiege Option
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Wenige Umstiege", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Switch(
                                checked = searchConfig.preferFewTransfers,
                                onCheckedChange = {
                                    viewModel.searchConfig.value = searchConfig.copy(preferFewTransfers = it)
                                    viewModel.searchConnection()
                                }
                            )
                        }

                        // Barrierefrei Option
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Accessible, contentDescription = "Barrierefrei", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "Barrierefrei (Nur Aufzüge)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Switch(
                                checked = searchConfig.isAccessibleRequired,
                                onCheckedChange = {
                                    viewModel.searchConfig.value = searchConfig.copy(isAccessibleRequired = it)
                                    viewModel.searchConnection()
                                },
                                modifier = Modifier.testTag("accessibility_switch")
                            )
                        }
                    }
                }
            }
        }

        // Disruption Reroute Warning
        if (showRerouteInfo && oldRoute != null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.Red, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color(0x11FF0000)),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AltRoute, contentDescription = "Umfahrung", tint = Color.Red, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "VERBINDUNG REKULIERT",
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.Red,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Grund: Streckenabschnitt gesperrt",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Eine Betriebsstörung blockiert deinen ursprünglichen Weg. Das System führt dich barrierefrei oder störungsfrei außen herum.",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                        )

                        // Old Path Summary
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "ALTE ROUTE: ", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                            oldRoute?.legs?.forEachIndexed { index, leg ->
                                if (index > 0) Text(" → ", fontSize = 11.sp)
                                Box(
                                    modifier = Modifier
                                        .background(Color(android.graphics.Color.parseColor(leg.colorHex)))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text(text = leg.lineName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Search Results Section
        val currentJourney = results
        if (currentJourney != null) {
            item {
                Text(
                    text = "EMPFOHLENE ROUTE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Journey Meta Banner
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${currentJourney.departureTime} – ${currentJourney.arrivalTime}",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                                Text(
                                    text = "Dauer: ${currentJourney.durationMinutes} Min. | Umstiege: ${currentJourney.transfersCount}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }

                            // Reisemodus Trigger
                            Button(
                                onClick = { viewModel.startJourney(currentJourney) },
                                modifier = Modifier.testTag("start_journey_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(0.dp)
                            ) {
                                Text("Reise starten", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 16.dp))

                        // Vertical Path Visualizer
                        VerticalPathMap(journey = currentJourney)
                    }
                }
            }
        } else {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Info, contentDescription = "Info", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "KEINE VERBINDUNG GEFUNDEN",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Versuche einen anderen Start- oder Zielbahnhof oder deaktiviere die Barrierefreiheit, falls Stationen eingeschränkt sind.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VerticalPathMap(journey: Journey) {
    Column {
        journey.legs.forEachIndexed { index, leg ->
            // Start Station Point
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .background(Color.White, RoundedCornerShape(6.dp))
                        .border(3.dp, Color(android.graphics.Color.parseColor(leg.colorHex)), RoundedCornerShape(6.dp))
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(text = leg.startStationName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            // Route Leg Line & Information block
            Row(modifier = Modifier.fillMaxWidth()) {
                // Vertical Line
                Box(
                    modifier = Modifier
                        .padding(start = 5.dp)
                        .width(3.dp)
                        .height(80.dp)
                        .background(Color(android.graphics.Color.parseColor(leg.colorHex)))
                )
                Spacer(modifier = Modifier.width(20.dp))
                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(Color(android.graphics.Color.parseColor(leg.colorHex)))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = leg.lineName, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = "Richtung ${leg.direction}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Text(
                        text = "${leg.intermediateStationsCount + 1} Stationen (${leg.durationMinutes} Min.)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            // Transfer Steps description
            if (index < journey.legs.size - 1) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(Color.White, RoundedCornerShape(6.dp))
                            .border(3.dp, Color.Black, RoundedCornerShape(6.dp))
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(text = leg.endStationName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                            Icon(Icons.Default.DirectionsWalk, contentDescription = "Umsteigen", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Umsteigen", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                // Transfer line connector
                Box(
                    modifier = Modifier
                        .padding(start = 5.dp)
                        .width(3.dp)
                        .height(30.dp)
                        .background(Color.Black)
                )
            } else {
                // End Station Point
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(Color.White, RoundedCornerShape(6.dp))
                            .border(3.dp, Color(android.graphics.Color.parseColor(leg.colorHex)), RoundedCornerShape(6.dp))
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(text = leg.endStationName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}
