package com.example.data

import com.example.domain.Station
import com.example.domain.Line

object NetworkData {

    // Unique station definitions with stylized grid coordinates (x, y range 0..100) for schematic drawing
    val stations = listOf(
        Station(
            id = "alexanderplatz",
            name = "Alexanderplatz",
            latitude = 65.0,
            longitude = 35.0,
            lines = listOf("U2", "U5", "U8"),
            isAccessible = true,
            exits = listOf("Ausgang A (Alexanderstraße)", "Ausgang B (Dircksenstraße)", "Ausgang C (Rathausstraße)"),
            equipment = listOf("Aufzug", "Rolltreppe", "WC", "Fahrrad")
        ),
        Station(
            id = "wittenbergplatz",
            name = "Wittenbergplatz",
            latitude = 28.0,
            longitude = 45.0,
            lines = listOf("U1", "U2", "U3"),
            isAccessible = true,
            exits = listOf("Ausgang A (Tauentzienstraße)", "Ausgang B (Bayreuther Straße)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "zoologischer_garten",
            name = "Zoologischer Garten",
            latitude = 20.0,
            longitude = 45.0,
            lines = listOf("U2", "U3", "U9"), // U3 simulated connection for the demo journey
            isAccessible = true,
            exits = listOf("Ausgang A (Hardenbergplatz)", "Ausgang B (Jebensstraße)"),
            equipment = listOf("Aufzug", "Rolltreppe", "WC", "Fahrrad")
        ),
        Station(
            id = "pankow",
            name = "Pankow",
            latitude = 65.0,
            longitude = 10.0,
            lines = listOf("U2"),
            isAccessible = true,
            exits = listOf("Ausgang A (Florastraße)", "Ausgang B (Berliner Straße)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "ruhleben",
            name = "Ruhleben",
            latitude = 5.0,
            longitude = 35.0,
            lines = listOf("U2"),
            isAccessible = false, // Not fully accessible in demo to test filter
            exits = listOf("Ausgang A (Ruhlebener Straße)"),
            equipment = listOf("Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "hauptbahnhof",
            name = "Hauptbahnhof",
            latitude = 35.0,
            longitude = 35.0,
            lines = listOf("U5"),
            isAccessible = true,
            exits = listOf("Ausgang A (Europaplatz)", "Ausgang B (Washingtonplatz)"),
            equipment = listOf("Aufzug", "Rolltreppe", "WC", "Fahrrad")
        ),
        Station(
            id = "hoenow",
            name = "Hönow",
            latitude = 95.0,
            longitude = 20.0,
            lines = listOf("U5"),
            isAccessible = true,
            exits = listOf("Ausgang A (Mahlsdorfer Straße)"),
            equipment = listOf("Aufzug", "Fahrrad")
        ),
        Station(
            id = "hermannstrasse",
            name = "Hermannstraße",
            latitude = 75.0,
            longitude = 85.0,
            lines = listOf("U8"),
            isAccessible = true,
            exits = listOf("Ausgang A (Hermannstraße)", "Ausgang B (S-Bahnhof)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "stadtmitte",
            name = "Stadtmitte",
            latitude = 50.0,
            longitude = 45.0,
            lines = listOf("U2", "U6"),
            isAccessible = true,
            exits = listOf("Ausgang A (Friedrichstraße)", "Ausgang B (Mohrenstraße)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "potsdamer_platz",
            name = "Potsdamer Platz",
            latitude = 45.0,
            longitude = 45.0,
            lines = listOf("U2"),
            isAccessible = true,
            exits = listOf("Ausgang A (Potsdamer Platz)", "Ausgang B (Leipziger Platz)"),
            equipment = listOf("Aufzug", "Rolltreppe", "WC", "Fahrrad")
        ),
        Station(
            id = "schonhauser_allee",
            name = "Schönhauser Allee",
            latitude = 65.0,
            longitude = 20.0,
            lines = listOf("U2"),
            isAccessible = true,
            exits = listOf("Ausgang A (Schönhauser Allee)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "hallesches_tor",
            name = "Hallesches Tor",
            latitude = 50.0,
            longitude = 55.0,
            lines = listOf("U1", "U3", "U6"),
            isAccessible = true,
            exits = listOf("Ausgang A (Hallesches Ufer)", "Ausgang B (Mehringplatz)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "kottbusser_tor",
            name = "Kottbusser Tor",
            latitude = 70.0,
            longitude = 55.0,
            lines = listOf("U1", "U3", "U8"),
            isAccessible = false, // Under construction / escalators only in demo
            exits = listOf("Ausgang A (Kottbusser Platz)", "Ausgang B (Reichenberger Str)"),
            equipment = listOf("Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "hermannplatz",
            name = "Hermannplatz",
            latitude = 75.0,
            longitude = 65.0,
            lines = listOf("U7", "U8"),
            isAccessible = true,
            exits = listOf("Ausgang A (Karl-Marx-Straße)", "Ausgang B (Hermannplatz)"),
            equipment = listOf("Aufzug", "Rolltreppe", "WC", "Fahrrad")
        ),
        Station(
            id = "warschauer_strasse",
            name = "Warschauer Straße",
            latitude = 85.0,
            longitude = 55.0,
            lines = listOf("U1", "U3"),
            isAccessible = true,
            exits = listOf("Ausgang A (Warschauer Straße)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "nollendorfplatz",
            name = "Nollendorfplatz",
            latitude = 33.0,
            longitude = 45.0,
            lines = listOf("U1", "U2", "U3", "U4"),
            isAccessible = true,
            exits = listOf("Ausgang A (Motzstraße)", "Ausgang B (Nollendorfplatz)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "kurfurstendamm",
            name = "Kurfürstendamm",
            latitude = 20.0,
            longitude = 52.0,
            lines = listOf("U1", "U9"),
            isAccessible = true,
            exits = listOf("Ausgang A (Kurfürstendamm)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "spandau",
            name = "Rathaus Spandau",
            latitude = 5.0,
            longitude = 15.0,
            lines = listOf("U7"),
            isAccessible = true,
            exits = listOf("Ausgang A (Altstädter Ring)"),
            equipment = listOf("Aufzug", "Rolltreppe", "WC", "Fahrrad")
        ),
        Station(
            id = "rudow",
            name = "Rudow",
            latitude = 95.0,
            longitude = 85.0,
            lines = listOf("U7"),
            isAccessible = true,
            exits = listOf("Ausgang A (Neuköllner Straße)"),
            equipment = listOf("Aufzug", "Fahrrad")
        ),
        Station(
            id = "wedding",
            name = "Wedding",
            latitude = 50.0,
            longitude = 25.0,
            lines = listOf("U6"),
            isAccessible = true,
            exits = listOf("Ausgang A (Müllerstraße)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "friedrichstrasse",
            name = "Friedrichstraße",
            latitude = 50.0,
            longitude = 32.0,
            lines = listOf("U6"),
            isAccessible = true,
            exits = listOf("Ausgang A (Georgengeis)", "Ausgang B (Friedrichstraße)"),
            equipment = listOf("Aufzug", "Rolltreppe", "WC", "Fahrrad")
        ),
        Station(
            id = "alt_mariendorf",
            name = "Alt-Mariendorf",
            latitude = 50.0,
            longitude = 85.0,
            lines = listOf("U6"),
            isAccessible = true,
            exits = listOf("Ausgang A (Reiherdamm)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "wittenau",
            name = "Wittenau",
            latitude = 55.0,
            longitude = 10.0,
            lines = listOf("U8"),
            isAccessible = true,
            exits = listOf("Ausgang A (Wilhelmsruher Damm)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "steglitz",
            name = "Rathaus Steglitz",
            latitude = 20.0,
            longitude = 85.0,
            lines = listOf("U9"),
            isAccessible = true,
            exits = listOf("Ausgang A (Schloßstraße)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        Station(
            id = "osloer_strasse",
            name = "Osloer Straße",
            latitude = 50.0,
            longitude = 15.0,
            lines = listOf("U8", "U9"),
            isAccessible = true,
            exits = listOf("Ausgang A (Osloer Straße)", "Ausgang B (Schwedenstraße)"),
            equipment = listOf("Aufzug", "Rolltreppe", "Fahrrad")
        ),
        // Intermediate stations for route completeness
        Station(id = "bundestag", name = "Bundestag", latitude = 40.0, longitude = 35.0, lines = listOf("U5"), isAccessible = true, exits = listOf("Ausgang A"), equipment = listOf("Aufzug", "Rolltreppe")),
        Station(id = "brandenburger_tor", name = "Brandenburger Tor", latitude = 45.0, longitude = 35.0, lines = listOf("U5"), isAccessible = true, exits = listOf("Ausgang A"), equipment = listOf("Aufzug", "Rolltreppe")),
        Station(id = "unter_den_linden", name = "Unter den Linden", latitude = 50.0, longitude = 35.0, lines = listOf("U5", "U6"), isAccessible = true, exits = listOf("Ausgang A"), equipment = listOf("Aufzug", "Rolltreppe")),
        Station(id = "rosa_luxemburg_platz", name = "Rosa-Luxemburg-Platz", latitude = 65.0, longitude = 28.0, lines = listOf("U2"), isAccessible = true, exits = listOf("Ausgang A"), equipment = listOf("Aufzug", "Rolltreppe")),
        Station(id = "bismarckstrasse", name = "Bismarckstraße", latitude = 10.0, longitude = 45.0, lines = listOf("U2", "U7"), isAccessible = true, exits = listOf("Ausgang A"), equipment = listOf("Aufzug", "Rolltreppe"))
    )

    val lines = listOf(
        Line(
            id = "U1",
            name = "U1",
            colorHex = "#7DBB26",
            stations = listOf("wittenbergplatz", "nollendorfplatz", "hallesches_tor", "kottbusser_tor", "warschauer_strasse"),
            direction1 = "Warschauer Straße",
            direction2 = "Uhlandstraße"
        ),
        Line(
            id = "U2",
            name = "U2",
            colorHex = "#DA421E",
            stations = listOf("ruhleben", "bismarckstrasse", "zoologischer_garten", "wittenbergplatz", "nollendorfplatz", "potsdamer_platz", "stadtmitte", "alexanderplatz", "rosa_luxemburg_platz", "schonhauser_allee", "pankow"),
            direction1 = "Pankow",
            direction2 = "Ruhleben"
        ),
        Line(
            id = "U3",
            name = "U3",
            colorHex = "#007A5E",
            stations = listOf("zoologischer_garten", "wittenbergplatz", "nollendorfplatz", "hallesches_tor", "kottbusser_tor", "warschauer_strasse"), // Simulated direct connect for Demo 1
            direction1 = "Warschauer Straße",
            direction2 = "Krumme Lanke"
        ),
        Line(
            id = "U4",
            name = "U4",
            colorHex = "#F0CA00",
            stations = listOf("nollendorfplatz"), // Short feeder
            direction1 = "Innsbrucker Platz",
            direction2 = "Nollendorfplatz"
        ),
        Line(
            id = "U5",
            name = "U5",
            colorHex = "#7E5330",
            stations = listOf("hauptbahnhof", "bundestag", "brandenburger_tor", "unter_den_linden", "alexanderplatz", "hoenow"),
            direction1 = "Hönow",
            direction2 = "Hauptbahnhof"
        ),
        Line(
            id = "U6",
            name = "U6",
            colorHex = "#8C5695",
            stations = listOf("wedding", "friedrichstrasse", "unter_den_linden", "stadtmitte", "hallesches_tor", "alt_mariendorf"),
            direction1 = "Alt-Mariendorf",
            direction2 = "Alt-Tegel"
        ),
        Line(
            id = "U7",
            name = "U7",
            colorHex = "#009DDF",
            stations = listOf("spandau", "bismarckstrasse", "hermannplatz", "rudow"),
            direction1 = "Rudow",
            direction2 = "Rathaus Spandau"
        ),
        Line(
            id = "U8",
            name = "U8",
            colorHex = "#1F5294",
            stations = listOf("wittenau", "osloer_strasse", "alexanderplatz", "kottbusser_tor", "hermannplatz", "hermannstrasse"),
            direction1 = "Hermannstraße",
            direction2 = "Wittenau"
        ),
        Line(
            id = "U9",
            name = "U9",
            colorHex = "#F17500",
            stations = listOf("steglitz", "kurfurstendamm", "zoologischer_garten", "osloer_strasse"),
            direction1 = "Osloer Straße",
            direction2 = "Rathaus Steglitz"
        )
    )

    // Quick map helper
    val stationMap = stations.associateBy { it.id }
    val lineMap = lines.associateBy { it.id }
}
