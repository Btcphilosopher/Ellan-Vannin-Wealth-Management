package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NetworkData
import com.example.domain.DepartureStatus
import com.example.domain.Station
import com.example.ui.UbahnViewModel
import com.example.ui.theme.BvgBorderGrey

@Composable
fun StationScreen(
    viewModel: UbahnViewModel,
    modifier: Modifier = Modifier
) {
    val selectedSt by viewModel.selectedStation.collectAsState()
    val clockTime by viewModel.clockTime.collectAsState()
    val activeDisruptions by viewModel.activeDisruptions.collectAsState()

    var wayfindingActive by remember { mutableStateOf(false) }

    val stationDepartures = remember(selectedSt, clockTime, activeDisruptions) {
        viewModel.getSimulatedDepartures(selectedSt)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Selector Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "HALTESTELLEN-INFOS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = selectedSt.name,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.testTag("station_title")
                    )
                }
                
                // Station select button
                var showStationSelector by remember { mutableStateOf(false) }
                Button(
                    onClick = { showStationSelector = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Text("Wechseln", fontWeight = FontWeight.Bold)
                }

                if (showStationSelector) {
                    StationPickerDialog(
                        title = "Station wählen",
                        onDismiss = { showStationSelector = false },
                        onSelect = {
                            viewModel.selectedStation.value = it
                            showStationSelector = false
                        }
                    )
                }
            }
        }

        // Line Badges Row
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                selectedSt.lines.forEach { lineId ->
                    val line = NetworkData.lineMap[lineId]!!
                    Box(
                        modifier = Modifier
                            .background(line.color)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = line.name,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Toggle Wayfinding Mode (Wegweisungs-Modus)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = if (wayfindingActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        shape = RoundedCornerShape(0.dp)
                    ),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .clickable { wayfindingActive = !wayfindingActive }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Directions,
                            contentDescription = "Wayfinding",
                            tint = if (wayfindingActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(text = "Station Wegweisungs-Modus", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(text = "Aktiviere die schematische Innen-Navigation.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                    Switch(checked = wayfindingActive, onCheckedChange = { wayfindingActive = it })
                }
            }
        }

        // WAYFINDING CONTENT
        if (wayfindingActive) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "WEGWEISUNG: ${selectedSt.name.uppercase()}",
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 12.sp,
                            letterSpacing = 1.sp
                        )

                        // Current Position Node
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Adjust, contentDescription = "Current location", tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = "Du befindest dich hier.", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        }

                        // Waypoint 1: Escalator to platform
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = "Down", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                val firstLine = selectedSt.lines.first()
                                val lineObj = NetworkData.lineMap[firstLine]!!
                                Text(text = "Bahnsteig ${lineObj.name}", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text(text = "Richtung ${lineObj.direction1} (3 Min.)", style = MaterialTheme.typography.bodySmall, color = BvgBorderGrey)
                            }
                        }

                        // Waypoint 2: Lift / Elevator directions
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "Right", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = "Aufzug (Barrierefrei)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text(text = "In 90 m rechts abbiegen.", style = MaterialTheme.typography.bodySmall, color = BvgBorderGrey)
                            }
                        }

                        // Waypoint 3: Exit directions
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = "Up", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                val exit = selectedSt.exits.firstOrNull() ?: "Ausgang A"
                                Text(text = exit, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text(text = "In 250 m geradeaus.", style = MaterialTheme.typography.bodySmall, color = BvgBorderGrey)
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 4.dp))
                        Text(
                            text = "Hinweis: Schematische Angabe. Entfernungen sind Näherungswerte.",
                            style = MaterialTheme.typography.labelSmall,
                            color = BvgBorderGrey
                        )
                    }
                }
            }
        }

        // DEPARTURE BOARD SECTION
        item {
            Text(
                text = "ABFAHRTEN DISPLAY (BERLIN OS)",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color.Black, RoundedCornerShape(0.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                shape = RoundedCornerShape(0.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header row of the display
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Linie", fontWeight = FontWeight.Bold, color = Color(0xFFFF9500), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "Ziel", fontWeight = FontWeight.Bold, color = Color(0xFFFF9500), fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f).padding(start = 32.dp))
                        Text(text = "Abfahrt", fontWeight = FontWeight.Bold, color = Color(0xFFFF9500), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }

                    if (stationDepartures.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            stationDepartures.forEach { dep ->
                                val line = NetworkData.lineMap[dep.lineId]!!
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Line Badge
                                    Box(
                                        modifier = Modifier
                                            .background(line.color)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                            .width(40.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = line.name,
                                            color = Color.White,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp
                                        )
                                    }

                                    // Destination Name
                                    Text(
                                        text = dep.destination,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(start = 16.dp)
                                    )

                                    // Minutes left
                                    Text(
                                        text = if (dep.status == DepartureStatus.FAELLT_AUS) "FÄLLT AUS" else "${dep.minutesAway} min",
                                        color = if (dep.status == DepartureStatus.FAELLT_AUS) Color.Red else Color(0xFF4CD964),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "Derzeit keine Abfahrten geplant.",
                            color = Color(0xFFFF9500),
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 12.dp))
                    Text(
                        text = "BVG LIVE MONITOR – SIMULIERTE ECHTZEITDATEN",
                        color = Color.Gray,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                }
            }
        }

        // AUSGÄNGE SECTION
        item {
            Column {
                Text(
                    text = "AUSGÄNGE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        selectedSt.exits.forEachIndexed { idx, exit ->
                            val exitLetter = when (idx) {
                                0 -> "A"
                                1 -> "B"
                                2 -> "C"
                                else -> "D"
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(Color.Black)
                                        .border(1.dp, MaterialTheme.colorScheme.primary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = exitLetter,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(text = exit, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
        }

        // AUSSTATTUNG (Equipment) SECTION
        item {
            Column {
                Text(
                    text = "AUSSTATTUNG",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        selectedSt.equipment.forEach { item ->
                            val icon = when (item) {
                                "Aufzug" -> Icons.Default.Elevator
                                "Rolltreppe" -> Icons.Default.Escalator
                                "WC" -> Icons.Default.Wc
                                "Fahrrad" -> Icons.Default.DirectionsBike
                                else -> Icons.Default.Info
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Icon(icon, contentDescription = item, tint = MaterialTheme.colorScheme.onBackground)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = item, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
