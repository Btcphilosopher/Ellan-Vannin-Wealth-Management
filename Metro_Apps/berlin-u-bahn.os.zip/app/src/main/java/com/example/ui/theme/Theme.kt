package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BvgYellow,
    onPrimary = Color.Black,
    secondary = BvgMediumGrey,
    onSecondary = Color.White,
    background = BvgBlack,
    onBackground = Color.White,
    surface = BvgDarkGrey,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF2C2C2E),
    onSurfaceVariant = Color.White,
    outline = BvgBorderGrey
)

private val LightColorScheme = lightColorScheme(
    primary = BvgYellowDark,
    onPrimary = Color.Black,
    secondary = BvgMediumGrey,
    onSecondary = Color.Black,
    background = BvgLightGrey,
    onBackground = Color.Black,
    surface = BvgWhite,
    onSurface = Color.Black,
    surfaceVariant = Color(0xFFE5E5EA),
    onSurfaceVariant = Color.Black,
    outline = BvgBorderGrey
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
