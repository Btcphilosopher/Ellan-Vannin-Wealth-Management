package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NetworkData
import com.example.domain.Line
import com.example.ui.UbahnViewModel

@Composable
fun LinesScreen(
    viewModel: UbahnViewModel,
    modifier: Modifier = Modifier
) {
    val activeDisruptions by viewModel.activeDisruptions.collectAsState()
    val clockTime by viewModel.clockTime.collectAsState()

    var selectedLineId by remember { mutableStateOf("U2") }
    val selectedLine = remember(selectedLineId) { NetworkData.lineMap[selectedLineId]!! }

    // Trigger state increment to animate train movement on clock tick
    LaunchedEffect(clockTime) {
        viewModel.incrementSecondCounter()
    }

    val simulatedTrains = remember(selectedLineId, clockTime) {
        viewModel.getSimulatedTrainsForLine(selectedLineId)
    }

    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Interactive Lines List selector (U1-U9)
        LazyColumn(
            modifier = Modifier
                .width(80.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(NetworkData.lines) { line ->
                val isSelected = line.id == selectedLineId
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = if (isSelected) line.color else Color.Transparent,
                        )
                        .border(
                            width = 1.dp,
                            color = if (isSelected) line.color else MaterialTheme.colorScheme.outline
                        )
                        .clickable { selectedLineId = line.id }
                        .padding(vertical = 12.dp)
                        .testTag("line_badge_${line.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = line.name,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp
                    )
                }
            }
        }

        // Right Column: Detail Sequential Stop profile and Live Train Simulator
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Line Header Information Block
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(0.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "LINIE ${selectedLine.name}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = selectedLine.color
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${selectedLine.direction2} ⇄ ${selectedLine.direction1}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "Fahrzeit ca. ${selectedLine.stations.size * 2} Min. | ${selectedLine.stations.size} Bahnhöfe",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    
                    // Disruptions Warnings on this specific line
                    val lineDisruptions = activeDisruptions.filter { it.lineId == selectedLineId }
                    if (lineDisruptions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = "Warnung", tint = Color.Red, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "STÖRUNG GEMELDET",
                                color = Color.Red,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // Disclaimer Warning
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0x11F0CA00)),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "LIVEDATEN SIND SIMULIERT (DEMO-MODUS)",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 0.5.sp
                )
            }

            // Sequential Stops list containing Moving Train Dot Simulator
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(0.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(0.dp)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    itemsIndexed(selectedLine.stations) { idx, stationId ->
                        val station = NetworkData.stationMap[stationId]!!
                        
                        // Check if a simulated train is currently at or traveling near this station
                        val isTrainNear = simulatedTrains.any { it.first == stationId }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Stop Visual Marker Connector
                            Box(
                                modifier = Modifier.width(36.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isTrainNear) {
                                    // Simulated moving train icon
                                    Icon(
                                        imageVector = Icons.Default.DirectionsSubway,
                                        contentDescription = "Train simulated location",
                                        tint = selectedLine.color,
                                        modifier = Modifier.size(24.dp)
                                    )
                                } else {
                                    // Static station node dot
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .background(Color.White, RoundedCornerShape(6.dp))
                                            .border(3.dp, selectedLine.color, RoundedCornerShape(6.dp))
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            // Station Info Text
                            Column {
                                Text(
                                    text = station.name,
                                    fontSize = 15.sp,
                                    fontWeight = if (isTrainNear) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isTrainNear) selectedLine.color else MaterialTheme.colorScheme.onBackground
                                )
                                if (station.lines.size > 1) {
                                    Text(
                                        text = "Umsteigen: " + station.lines.filter { it != selectedLineId }.joinToString(", "),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.secondary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
