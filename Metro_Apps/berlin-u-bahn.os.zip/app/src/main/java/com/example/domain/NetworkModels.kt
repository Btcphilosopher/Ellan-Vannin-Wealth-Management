package com.example.domain

import androidx.compose.ui.graphics.Color

// Station representation
data class Station(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val lines: List<String>, // e.g. ["U2", "U5", "U8"]
    val isAccessible: Boolean, // Barrierefreiheit flag
    val exits: List<String>, // e.g. ["Ausgang A (Alexanderstraße)", "Ausgang B (Dircksenstraße)"]
    val equipment: List<String> // e.g. ["Aufzug", "Rolltreppe", "WC", "Fahrrad"]
)

// U-Bahn Line representation
data class Line(
    val id: String, // e.g. "U2"
    val name: String,
    val colorHex: String, // e.g. "#DA421E"
    val stations: List<String>, // List of station IDs in order
    val direction1: String, // Destination in direction 1 (e.g. "Pankow")
    val direction2: String  // Destination in direction 2 (e.g. "Ruhleben")
) {
    val color: Color get() = Color(android.graphics.Color.parseColor(colorHex))
}

// Departure prediction
data class Departure(
    val lineId: String,
    val destination: String,
    val minutesAway: Int,
    val status: DepartureStatus = DepartureStatus.PLANMAESSIG,
    val platform: String = "Gleis 1"
)

enum class DepartureStatus {
    PLANMAESSIG, // Planmäßig
    VERSPAETET,   // Verspätet
    FAELLT_AUS    // Fällt aus
}

// Disruption representation
data class Disruption(
    val id: String,
    val type: DisruptionType,
    val lineId: String,
    val title: String,
    val description: String,
    val startStationId: String,
    val endStationId: String,
    val timestamp: String = "10:34"
)

enum class DisruptionType {
    VERSPAETUNG,
    STOERUNG,
    AUSFALL,
    BAUSTELLE,
    ERSATZVERKEHR
}

// Connection search configuration
data class SearchConfig(
    val isAccessibleRequired: Boolean = false,
    val preferFewTransfers: Boolean = false,
    val preferFastest: Boolean = true
)

// Journey structure returned by Routing Engine
data class Journey(
    val fromStationId: String,
    val toStationId: String,
    val fromStationName: String,
    val toStationName: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val transfersCount: Int,
    val legs: List<JourneyLeg>
)

data class JourneyLeg(
    val lineId: String,
    val lineName: String,
    val colorHex: String,
    val startStationId: String,
    val startStationName: String,
    val endStationId: String,
    val endStationName: String,
    val direction: String,
    val intermediateStationsCount: Int,
    val durationMinutes: Int,
    val stationNames: List<String> = emptyList()
)

// Ticketing structures
data class FareProduct(
    val id: String,
    val title: String, // e.g. "24-Stunden-Karte"
    val description: String,
    val basePriceAB: Double,
    val basePriceABC: Double
)

enum class FareZone {
    AB,
    ABC
}

enum class PaymentMethod {
    APPLE_PAY,
    GOOGLE_PAY,
    KREDITKARTE,
    PAYPAL,
    SEPA
}
