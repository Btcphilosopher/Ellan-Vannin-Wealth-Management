package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class BookingStatus {
    CONFIRMED,
    CHECKED_IN,
    BOARDED,
    FLOWN,
    CANCELLED,
    REFUNDED
}

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey
    val bookingId: String, // e.g. "BS7K4P" (PNR)
    val eTicketNumber: String, // e.g. "125-9840283412"
    val flightNumber: String, // e.g. "BS241"
    val fareType: String, // "LIGHT", "STANDARD", "FLEX"
    val createdTimestamp: Long = System.currentTimeMillis(),
    val totalAmountPence: Int, // Total in minor units
    val paymentMethod: String = "Card ending in 4092",
    val status: BookingStatus = BookingStatus.CONFIRMED,
    val passengersJson: String, // JSON list of Passengers
    val seatsJson: String, // JSON map passengerId -> seatNumber
    val baggageJson: String, // JSON list of BaggageSelection
    val addOnsJson: String = "[]", // JSON fast track, lounge, etc.
    val boardingTime: String = "06:40",
    val checkInCompleted: Boolean = false
) {
    val isCheckedIn: Boolean
        get() = checkInCompleted || status == BookingStatus.CHECKED_IN || status == BookingStatus.BOARDED
}
