package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Passenger
import com.example.data.model.Seat
import com.example.ui.components.SkySeatMap
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy

@Composable
fun SeatSelectionScreen(
    passengers: List<Passenger>,
    allSeats: List<Seat>,
    onSeatsConfirmed: (seatAssignments: Map<String, String>, seatTotalPence: Int) -> Unit,
    onBack: () -> Unit
) {
    var activePassengerIndex by remember { mutableStateOf(0) }
    val assignedSeats = remember { mutableStateMapOf<String, Seat>() }

    // Initial seat pre-selected
    if (assignedSeats.isEmpty() && passengers.isNotEmpty()) {
        val defaultSeat = allSeats.find { it.number == "12A" } ?: allSeats.first()
        assignedSeats[passengers.first().id] = defaultSeat
    }

    val currentPassenger = passengers.getOrNull(activePassengerIndex) ?: passengers.first()
    val currentSelectedSeat = assignedSeats[currentPassenger.id]

    val totalSeatCostPence = assignedSeats.values.sumOf { it.pricePence }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MidnightNavy)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "SEAT ASSIGNMENT",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = Color.Gray)
                )
                Text(
                    text = "Select Seat for ${currentPassenger.fullName}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Passengers Row Selector
        if (passengers.size > 1) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                passengers.forEachIndexed { idx, p ->
                    val isCurrent = idx == activePassengerIndex
                    val seatAssigned = assignedSeats[p.id]?.number ?: "None"

                    Surface(
                        onClick = { activePassengerIndex = idx },
                        color = if (isCurrent) AviationBlue else Color.White,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = p.firstName,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCurrent) Color.White else MidnightNavy
                                )
                            )
                            Text(
                                text = "Seat: $seatAssigned",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    color = if (isCurrent) Color.White.copy(alpha = 0.8f) else Color.Gray
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Sky Interactive Seat Map
        SkySeatMap(
            seats = allSeats,
            selectedSeatNumber = currentSelectedSeat?.number,
            onSeatSelected = { seat ->
                assignedSeats[currentPassenger.id] = seat
            }
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Selected Seat Breakdown Summary
        Surface(
            color = Color.White,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SELECTED SEAT: ${currentSelectedSeat?.number ?: "12A"}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = MidnightNavy
                        )
                    )
                    Text(
                        text = "${currentSelectedSeat?.type ?: "STANDARD"} • ${currentSelectedSeat?.priceFormatted ?: "£12"}",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                    )
                }

                Text(
                    text = "Total: £${totalSeatCostPence / 100}",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = AviationBlue
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                val map = assignedSeats.mapValues { it.value.number }
                onSeatsConfirmed(map, totalSeatCostPence)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("confirm_seat_selection_button"),
            colors = ButtonDefaults.buttonColors(containerColor = AviationBlue),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("CONFIRM SEATS & CONTINUE TO BAGGAGE")
        }
    }
}
