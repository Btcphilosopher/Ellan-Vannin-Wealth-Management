package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Flight
import com.example.data.model.FlightStatus
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.WarningAmber

@Composable
fun FlightStatusScreen(
    flights: List<Flight>
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredFlights = flights.filter { f ->
        f.flightNumber.contains(searchQuery, ignoreCase = true) ||
        f.originCode.contains(searchQuery, ignoreCase = true) ||
        f.destinationCode.contains(searchQuery, ignoreCase = true) ||
        f.originCity.contains(searchQuery, ignoreCase = true) ||
        f.destinationCity.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
    ) {
        Text(
            text = "LIVE TIMETABLE & STATUS",
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = MidnightNavy,
                letterSpacing = 1.5.sp
            )
        )

        Text(
            text = "British Sky Flight Operations",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MidnightNavy
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search flight number e.g. BS241 or EDI...") },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = AviationBlue) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("status_search_input"),
            shape = RoundedCornerShape(8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filteredFlights) { flight ->
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("status_card_${flight.flightNumber}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(color = MidnightNavy, shape = RoundedCornerShape(4.dp)) {
                                    Text(
                                        text = flight.flightNumber,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${flight.originCode} → ${flight.destinationCode}",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MidnightNavy
                                    )
                                )
                            }

                            // Status Pill
                            val (bgColor, textColor, label) = when (flight.status) {
                                FlightStatus.DELAYED -> Triple(WarningAmber.copy(alpha = 0.15f), WarningAmber, "DELAYED +${flight.delayMinutes}m")
                                FlightStatus.CHECK_IN_OPEN -> Triple(StatusGreen.copy(alpha = 0.15f), StatusGreen, "CHECK-IN OPEN")
                                FlightStatus.BOARDING -> Triple(AviationBlue.copy(alpha = 0.15f), AviationBlue, "BOARDING GATE ${flight.gate}")
                                else -> Triple(Color(0xFFE2E8F0), MidnightNavy, flight.status.name)
                            }

                            Surface(color = bgColor, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = label,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = textColor
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Dep: ${flight.displayDepartureTime} (Gate ${flight.gate})",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                            )
                            Text(
                                text = "Arr: ${flight.displayArrivalTime}",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                            )
                        }
                    }
                }
            }
        }
    }
}
