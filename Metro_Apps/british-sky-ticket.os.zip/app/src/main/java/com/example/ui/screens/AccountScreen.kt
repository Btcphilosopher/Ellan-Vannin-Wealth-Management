package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Passenger
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy

@Composable
fun AccountScreen(
    passengers: List<Passenger>
) {
    var biometricsEnabled by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "MY BRITISH SKY",
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = MidnightNavy,
                letterSpacing = 1.5.sp
            )
        )

        Text(
            text = "Account & Preferences",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MidnightNavy
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Profile Summary
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = AviationBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "PRIMARY PASSENGER PROFILE", style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MidnightNavy))
                }

                Spacer(modifier = Modifier.height(10.dp))

                val primary = passengers.find { it.isPrimary } ?: passengers.firstOrNull()
                Text(text = primary?.fullName ?: "MR TOM LOVEITT", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
                Text(text = "Passport: GB984029102 • British Citizen", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                Text(text = "Email: tom.loveitt@example.co.uk", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Biometrics Security Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null, tint = AviationBlue)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(text = "Biometric Lock (Face ID)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
                        Text(text = "Secure boarding pass access", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                    }
                }

                Switch(
                    checked = biometricsEnabled,
                    onCheckedChange = { biometricsEnabled = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = AviationBlue),
                    modifier = Modifier.testTag("biometric_switch")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Privacy Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "PRIVACY & DATA CONTROLS", style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = MidnightNavy))
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Compliant with UK GDPR standards. Personal data is encrypted.", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth().testTag("download_data_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Download Personal Travel Archive")
                }
            }
        }
    }
}
