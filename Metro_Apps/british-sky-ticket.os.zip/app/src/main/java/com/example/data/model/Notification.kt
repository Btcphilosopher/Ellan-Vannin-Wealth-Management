package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class NotificationType {
    GATE_CHANGE,
    BOARDING_OPEN,
    FLIGHT_DELAY,
    CHECK_IN_REMINDER,
    SYSTEM
}

@Entity(tableName = "notifications")
data class NotificationItem(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val bookingId: String = "",
    val title: String,
    val message: String,
    val timeFormatted: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: NotificationType = NotificationType.SYSTEM,
    val isRead: Boolean = false
)
