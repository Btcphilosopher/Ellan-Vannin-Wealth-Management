package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.Passenger
import kotlinx.coroutines.flow.Flow

@Dao
interface PassengerDao {
    @Query("SELECT * FROM passengers ORDER BY isPrimary DESC, lastName ASC")
    fun getAllPassengers(): Flow<List<Passenger>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPassenger(passenger: Passenger)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllPassengers(passengers: List<Passenger>)

    @Query("DELETE FROM passengers WHERE id = :id")
    suspend fun deletePassenger(id: String)
}
