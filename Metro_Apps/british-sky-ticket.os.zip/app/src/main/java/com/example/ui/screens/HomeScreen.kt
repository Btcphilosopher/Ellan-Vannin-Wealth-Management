package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.LocalAirport
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Booking
import com.example.data.model.Flight
import com.example.ui.components.SkyTicket
import com.example.ui.components.SkyTimeline
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.WarningAmber

@Composable
fun HomeScreen(
    primaryBooking: Booking?,
    primaryFlight: Flight?,
    passengerName: String,
    seatNumber: String,
    activeDisruptionText: String?,
    onNavigateToSearch: () -> Unit,
    onNavigateToTicketDetail: (String) -> Unit,
    onNavigateToBoardingPass: () -> Unit,
    onNavigateToCheckIn: (String) -> Unit,
    onNavigateToStatus: () -> Unit,
    onNavigateToWallet: () -> Unit,
    onNavigateToAirportGuide: () -> Unit,
    onNavigateToDisruption: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Passenger Greeting Banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "GOOD MORNING",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray,
                        letterSpacing = 1.5.sp
                    )
                )
                Text(
                    text = passengerName,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = MidnightNavy
                    )
                )
            }

            Surface(
                color = AviationBlue.copy(alpha = 0.1f),
                shape = CircleShape
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "TL",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AviationBlue,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active Disruption Alert Callout if present
        AnimatedVisibility(visible = activeDisruptionText != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToDisruption() }
                    .testTag("disruption_alert_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = WarningAmber.copy(alpha = 0.15f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Warning",
                        tint = WarningAmber,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "FLIGHT DISRUPTION NOTICE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MidnightNavy,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                        Text(
                            text = activeDisruptionText ?: "",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Medium,
                                color = MidnightNavy
                            )
                        )
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "View Options",
                        tint = MidnightNavy
                    )
                }
            }
        }

        if (activeDisruptionText != null) {
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: YOUR NEXT JOURNEY
        Text(
            text = "YOUR NEXT JOURNEY",
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = MidnightNavy,
                letterSpacing = 1.sp
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (primaryBooking != null && primaryFlight != null) {
            // Display Sky Digital Ticket
            SkyTicket(
                booking = primaryBooking,
                flight = primaryFlight,
                passengerName = passengerName,
                seatNumber = seatNumber,
                onViewBoardingPass = onNavigateToBoardingPass,
                onCheckIn = { onNavigateToCheckIn(primaryBooking.bookingId) },
                onManageJourney = { onNavigateToTicketDetail(primaryBooking.bookingId) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Live Timeline Progression Card
            SkyTimeline(
                isCheckedIn = primaryBooking.isCheckedIn,
                flightStatus = primaryFlight.status,
                gate = primaryFlight.gate
            )
        } else {
            // No Active Booking State
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.FlightTakeoff,
                        contentDescription = null,
                        tint = AviationBlue,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "WHERE WILL YOU GO?",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MidnightNavy
                        )
                    )
                    Text(
                        text = "Search domestic British Sky flights across London, Edinburgh, Glasgow, Manchester and more.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onNavigateToSearch,
                        colors = ButtonDefaults.buttonColors(containerColor = AviationBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_search_flights_button")
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SEARCH FLIGHTS")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Quick Access Actions Grid
        Text(
            text = "SYSTEM ACTIONS",
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = MidnightNavy,
                letterSpacing = 1.sp
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ActionTile(
                title = "BOOK A FLIGHT",
                subtitle = "Search & reserve",
                icon = Icons.Default.Search,
                modifier = Modifier
                    .weight(1f)
                    .testTag("action_book_flight"),
                onClick = onNavigateToSearch
            )

            ActionTile(
                title = "TRAVEL WALLET",
                subtitle = "Passes & receipts",
                icon = Icons.Default.ConfirmationNumber,
                modifier = Modifier
                    .weight(1f)
                    .testTag("action_travel_wallet"),
                onClick = onNavigateToWallet
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ActionTile(
                title = "FLIGHT STATUS",
                subtitle = "Live timetable",
                icon = Icons.Default.Flight,
                modifier = Modifier
                    .weight(1f)
                    .testTag("action_flight_status"),
                onClick = onNavigateToStatus
            )

            ActionTile(
                title = "AIRPORT GUIDE",
                subtitle = "Wayfinding & maps",
                icon = Icons.Default.LocalAirport,
                modifier = Modifier
                    .weight(1f)
                    .testTag("action_airport_guide"),
                onClick = onNavigateToAirportGuide
            )
        }
    }
}

@Composable
private fun ActionTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = AviationBlue, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MidnightNavy
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                )
            }
        }
    }
}
