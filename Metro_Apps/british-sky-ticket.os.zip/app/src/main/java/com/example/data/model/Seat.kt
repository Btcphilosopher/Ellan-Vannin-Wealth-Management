package com.example.data.model

enum class SeatType {
    STANDARD,
    EXTRA_LEGROOM,
    EXIT_ROW
}

data class Seat(
    val row: Int,
    val letter: String, // "A", "B", "C", "D", "E", "F"
    val type: SeatType = SeatType.STANDARD,
    val pricePence: Int = 1200, // £12.00
    val isOccupied: Boolean = false,
    val isSelectedByPassengerId: String? = null
) {
    val number: String
        get() = "$row$letter"

    val priceFormatted: String
        get() = if (pricePence == 0) "Included" else "£${pricePence / 100}"
}
