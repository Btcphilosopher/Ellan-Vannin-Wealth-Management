package com.example.data.model

data class DisruptionInfo(
    val flightNumber: String,
    val headline: String,
    val description: String,
    val originalTime: String,
    val newTime: String,
    val gate: String,
    val alternativeFlights: List<Flight> = emptyList()
)
