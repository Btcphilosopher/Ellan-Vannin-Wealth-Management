package com.example.data.model

data class ReceiptLineItem(
    val description: String,
    val amountPence: Int
) {
    val amountFormatted: String
        get() = "£${"%.2f".format(amountPence / 100.0)}"
}

data class Receipt(
    val receiptId: String, // e.g. "REC-884910"
    val bookingReference: String,
    val dateIssued: String,
    val passengerName: String,
    val lineItems: List<ReceiptLineItem>,
    val totalPence: Int,
    val vatPence: Int = 0 // UK domestic passenger transport is zero-rated VAT
) {
    val totalFormatted: String
        get() = "£${"%.2f".format(totalPence / 100.0)}"
}
