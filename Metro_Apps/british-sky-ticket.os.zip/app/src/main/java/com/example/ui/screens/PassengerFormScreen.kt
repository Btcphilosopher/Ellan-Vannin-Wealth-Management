package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Passenger
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.StatusGreen

@Composable
fun PassengerFormScreen(
    savedPassengers: List<Passenger>,
    onContinueToSeats: (selectedPassengers: List<Passenger>) -> Unit,
    onBack: () -> Unit
) {
    var title by remember { mutableStateOf("MR") }
    var firstName by remember { mutableStateOf("TOM") }
    var lastName by remember { mutableStateOf("LOVEITT") }
    var email by remember { mutableStateOf("tom.loveitt@example.co.uk") }
    var phone by remember { mutableStateOf("+44 7700 900123") }

    val selectedSavedPassengers = remember { mutableStateListOf<Passenger>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MidnightNavy)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "PASSENGER DETAILS",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = Color.Gray)
                )
                Text(
                    text = "Lead Passenger Information",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Select Saved Passengers ("MY PASSENGERS")
        if (savedPassengers.isNotEmpty()) {
            Text(
                text = "MY SAVED PASSENGERS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = MidnightNavy
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            savedPassengers.forEach { p ->
                val isSelected = selectedSavedPassengers.any { it.id == p.id } || (p.isPrimary && selectedSavedPassengers.isEmpty())

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable {
                            if (isSelected && !p.isPrimary) {
                                selectedSavedPassengers.removeAll { it.id == p.id }
                            } else if (!isSelected) {
                                selectedSavedPassengers.add(p)
                            }
                        }
                        .testTag("saved_passenger_${p.id}"),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) AviationBlue.copy(alpha = 0.1f) else Color.White
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = p.fullName,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MidnightNavy
                                )
                            )
                            Text(
                                text = if (p.isPrimary) "Primary Traveller" else "Family / Guest",
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontSize = 10.sp)
                            )
                        }

                        if (isSelected) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = "Selected", tint = StatusGreen)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Form Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "PRIMARY PASSENGER FORM",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MidnightNavy
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("TITLE") },
                        modifier = Modifier.width(80.dp).testTag("passenger_title_input"),
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        label = { Text("FIRST NAME") },
                        modifier = Modifier.weight(1f).testTag("passenger_firstname_input"),
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = lastName,
                    onValueChange = { lastName = it },
                    label = { Text("LAST NAME") },
                    modifier = Modifier.fillMaxWidth().testTag("passenger_lastname_input"),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("CONTACT EMAIL") },
                    modifier = Modifier.fillMaxWidth().testTag("passenger_email_input"),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("MOBILE PHONE") },
                    modifier = Modifier.fillMaxWidth().testTag("passenger_phone_input"),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                val primary = Passenger(
                    id = "P1",
                    title = title.uppercase(),
                    firstName = firstName.uppercase(),
                    lastName = lastName.uppercase(),
                    contactEmail = email,
                    contactPhone = phone,
                    isPrimary = true
                )
                val resultList = mutableListOf(primary)
                resultList.addAll(selectedSavedPassengers.filter { it.id != "P1" })
                onContinueToSeats(resultList)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("continue_to_seats_button"),
            colors = ButtonDefaults.buttonColors(containerColor = AviationBlue),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("CONTINUE TO SEAT SELECTION")
        }
    }
}
