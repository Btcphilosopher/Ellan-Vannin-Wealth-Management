package com.example.data.model

data class BoardingPass(
    val boardingPassId: String,
    val bookingReference: String, // PNR e.g. "BS7K4P"
    val passengerName: String,
    val flightNumber: String,
    val originCode: String,
    val originCity: String,
    val originTerminal: String,
    val destinationCode: String,
    val destinationCity: String,
    val departureTime: String,
    val departureDate: String,
    val boardingTime: String,
    val gate: String,
    val seat: String,
    val zone: String = "GROUP 2",
    val barcodeData: String = "M1LOVEITT/TOM      EBS7K4P LHR EDI BS 0241 291Y012A0001 147"
)
