package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AssignmentReturn
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalAirport
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Booking
import com.example.data.model.Flight
import com.example.data.model.Receipt
import com.example.ui.components.SkyTicket
import com.example.ui.components.SkyTimeline
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy

@Composable
fun TicketDetailScreen(
    booking: Booking,
    flight: Flight,
    passengerName: String,
    seatNumber: String,
    receipt: Receipt,
    onViewBoardingPass: () -> Unit,
    onCheckIn: () -> Unit,
    onNavigateToSeatSelection: () -> Unit,
    onNavigateToAirportGuide: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MidnightNavy)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "MANAGE JOURNEY",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = Color.Gray)
                )
                Text(
                    text = "Ticket Reference: ${booking.bookingId}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Main Digital Ticket
        SkyTicket(
            booking = booking,
            flight = flight,
            passengerName = passengerName,
            seatNumber = seatNumber,
            onViewBoardingPass = onViewBoardingPass,
            onCheckIn = onCheckIn,
            onManageJourney = {}
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Timeline
        SkyTimeline(
            isCheckedIn = booking.isCheckedIn,
            flightStatus = flight.status,
            gate = flight.gate
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Management Options Grid Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "JOURNEY SERVICES & TICKET CONTROLS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MidnightNavy
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onNavigateToSeatSelection,
                        modifier = Modifier.weight(1f).testTag("change_seat_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Change Seat", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = onNavigateToAirportGuide,
                        modifier = Modifier.weight(1f).testTag("airport_guide_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.LocalAirport, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Airport Guide", fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Receipt Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Receipt, contentDescription = null, tint = AviationBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "RECEIPT & TAX INVOICE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = MidnightNavy
                            )
                        )
                    }

                    Text(
                        text = receipt.totalFormatted,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = MidnightNavy
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                receipt.lineItems.forEach { line ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = line.description, style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                        Text(text = line.amountFormatted, style = MaterialTheme.typography.bodySmall.copy(color = MidnightNavy, fontWeight = FontWeight.Medium))
                    }
                }
            }
        }
    }
}
