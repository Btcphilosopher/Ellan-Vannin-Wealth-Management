package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.BaggageSelection
import com.example.data.model.Booking
import com.example.data.model.Flight
import com.example.data.model.FlightStatus
import com.example.data.model.NotificationItem
import com.example.data.model.Passenger
import com.example.data.model.Seat
import com.example.data.repository.TicketRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TicketViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TicketRepository(AppDatabase.getDatabase(application))

    val bookings: StateFlow<List<Booking>> = repository.allBookings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val passengers: StateFlow<List<Passenger>> = repository.allPassengers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationItem>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val flights: StateFlow<List<Flight>> = repository.allFlights
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isOfflineMode: StateFlow<Boolean> = repository.isOfflineMode
    val activeDisruptionBanner: StateFlow<String?> = repository.activeDisruptionBanner

    // Active Booking Search & Flow Draft State
    val draftSelectedFlight = MutableStateFlow<Flight?>(null)
    val draftFareType = MutableStateFlow("STANDARD")
    val draftFarePricePence = MutableStateFlow(10400)
    val draftPassengers = MutableStateFlow<List<Passenger>>(emptyList())
    val draftSeatsMap = MutableStateFlow<Map<String, String>>(emptyMap())
    val draftSeatsPricePence = MutableStateFlow(1200)
    val draftBaggageList = MutableStateFlow<List<BaggageSelection>>(emptyList())
    val draftBaggagePricePence = MutableStateFlow(3500)
    val draftAddOnsPricePence = MutableStateFlow(0)

    val generatedSeatsList: List<Seat> by lazy {
        repository.generateSeatMapForAircraft()
    }

    fun setOfflineMode(offline: Boolean) {
        repository.setOfflineMode(offline)
    }

    fun checkIn(bookingId: String, updatedSeat: String) {
        viewModelScope.launch {
            repository.performCheckIn(bookingId, updatedSeat)
        }
    }

    fun createBookingFromDraft(paymentMethod: String, totalPence: Int, onComplete: (String) -> Unit) {
        viewModelScope.launch {
            val flightNo = draftSelectedFlight.value?.flightNumber ?: "BS241"
            val fare = draftFareType.value
            val passengersList = if (draftPassengers.value.isNotEmpty()) draftPassengers.value else passengers.value.take(1)
            val seats = if (draftSeatsMap.value.isNotEmpty()) draftSeatsMap.value else mapOf("P1" to "12A")
            val bags = draftBaggageList.value

            val pnr = repository.createBooking(
                flightNumber = flightNo,
                fareType = fare,
                selectedPassengers = passengersList,
                selectedSeats = seats,
                baggageList = bags,
                totalPence = totalPence,
                paymentMethodName = paymentMethod
            )
            onComplete(pnr)
        }
    }

    fun injectDisruption(flightNo: String, delayMins: Int, newGate: String) {
        viewModelScope.launch {
            repository.injectDisruption(flightNo, delayMins, newGate)
        }
    }

    fun updateGate(flightNo: String, gate: String) {
        viewModelScope.launch {
            repository.updateGate(flightNo, gate)
        }
    }

    fun setFlightStatus(flightNo: String, status: FlightStatus) {
        viewModelScope.launch {
            repository.setFlightStatus(flightNo, status)
        }
    }

    fun rebookFlight(bookingId: String, newFlightNo: String) {
        viewModelScope.launch {
            repository.rebookFlight(bookingId, newFlightNo)
        }
    }

    // Signature Demo 1 Trigger: Full Journey Search -> Book -> Pay -> Ticket -> Check-In -> Boarding Pass
    fun triggerDemo1FullJourney(onComplete: (pnr: String) -> Unit) {
        viewModelScope.launch {
            val allP = passengers.value
            val pnr = repository.createBooking(
                flightNumber = "BS241",
                fareType = "STANDARD",
                selectedPassengers = if (allP.isNotEmpty()) listOf(allP.first()) else emptyList(),
                selectedSeats = mapOf("P1" to "12A"),
                baggageList = listOf(BaggageSelection("P1", 1, 1)),
                totalPence = 12900,
                paymentMethodName = "Apple Pay"
            )
            onComplete(pnr)
        }
    }

    // Signature Demo 2 Trigger: Inject 35 Min Delay + Rebook Engine
    fun triggerDemo2Disruption() {
        viewModelScope.launch {
            repository.injectDisruption("BS241", 35, "C14")
        }
    }

    // Signature Demo 3 Trigger: Multi-Passenger (Family) Booking
    fun triggerDemo3MultiPassenger(onComplete: (pnr: String) -> Unit) {
        viewModelScope.launch {
            val allP = passengers.value
            val pnr = repository.createBooking(
                flightNumber = "BS243",
                fareType = "STANDARD",
                selectedPassengers = allP,
                selectedSeats = mapOf("P1" to "12A", "P2" to "12B", "P3" to "12C"),
                baggageList = allP.map { BaggageSelection(it.id, 1, 1) },
                totalPence = 35400,
                paymentMethodName = "Apple Pay"
            )
            onComplete(pnr)
        }
    }

    fun parsePassengers(json: String): List<Passenger> = repository.parsePassengers(json)
    fun parseSeats(json: String): Map<String, String> = repository.parseSeats(json)
    fun getAirportInfo(code: String) = repository.getAirportInfo(code)
    fun generateReceipt(booking: Booking, flight: Flight) = repository.generateReceipt(booking, flight)
}
