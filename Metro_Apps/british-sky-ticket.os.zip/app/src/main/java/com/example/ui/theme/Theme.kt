package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AviationBlue,
    onPrimary = Color.White,
    primaryContainer = NavyContainer,
    onPrimaryContainer = WarmWhite,
    secondary = SkyBlue,
    onSecondary = Color.White,
    tertiary = Silver,
    background = MidnightNavy,
    onBackground = WarmWhite,
    surface = NavyContainer,
    onSurface = WarmWhite,
    surfaceVariant = Graphite,
    onSurfaceVariant = Silver,
    outline = Silver.copy(alpha = 0.5f),
    error = CriticalRed
)

private val LightColorScheme = lightColorScheme(
    primary = MidnightNavy,
    onPrimary = Color.White,
    primaryContainer = AviationBlue,
    onPrimaryContainer = Color.White,
    secondary = SkyBlue,
    onSecondary = Color.White,
    secondaryContainer = SkyBlueContainer,
    onSecondaryContainer = MidnightNavy,
    tertiary = Graphite,
    background = WarmWhite,
    onBackground = MidnightNavy,
    surface = Color.White,
    onSurface = MidnightNavy,
    surfaceVariant = SoftGrey,
    onSurfaceVariant = Graphite,
    outline = Silver,
    error = CriticalRed
)

@Composable
fun BritishSkyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep signature British Sky identity
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
