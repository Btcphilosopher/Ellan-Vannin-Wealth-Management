package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Flight
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.WarningAmber

@Composable
fun DisruptionRebookScreen(
    currentFlight: Flight,
    alternativeFlights: List<Flight>,
    onRebookSelected: (newFlightNo: String) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MidnightNavy)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "DISRUPTION MANAGEMENT",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = Color.Gray)
                )
                Text(
                    text = "Flight ${currentFlight.flightNumber} Delayed",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Disruption Alert Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = WarningAmber.copy(alpha = 0.15f))
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = "OPERATIONAL DELAY NOTICE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MidnightNavy))
                    Text(text = "Flight ${currentFlight.flightNumber} to ${currentFlight.destinationCode} is delayed by ${currentFlight.delayMinutes} mins. New estimated departure is ${currentFlight.displayDepartureTime} from Gate ${currentFlight.gate}.", style = MaterialTheme.typography.bodySmall.copy(color = MidnightNavy))
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "COMPLIMENTARY ALTERNATIVE FLIGHTS",
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = MidnightNavy
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        alternativeFlights.forEach { alt ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .testTag("rebook_alt_${alt.flightNumber}"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = MidnightNavy, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = alt.flightNumber,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "${alt.scheduledDeparture} → ${alt.scheduledArrival}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "£0 Fare Difference • Guaranteed Transfer", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                    }

                    Button(
                        onClick = { onRebookSelected(alt.flightNumber) },
                        colors = ButtonDefaults.buttonColors(containerColor = AviationBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("confirm_rebook_${alt.flightNumber}")
                    ) {
                        Text("REBOOK")
                    }
                }
            }
        }
    }
}
