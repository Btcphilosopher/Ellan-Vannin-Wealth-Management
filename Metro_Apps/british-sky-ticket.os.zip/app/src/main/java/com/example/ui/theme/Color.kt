package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MidnightNavy = Color(0xFF0B1326)
val NavyContainer = Color(0xFF111827)
val AviationBlue = Color(0xFF1D4ED8)
val AviationBlueHover = Color(0xFF1E40AF)
val SkyBlue = Color(0xFF0284C7)
val SkyBlueContainer = Color(0xFFE0F2FE)
val WarmWhite = Color(0xFFF8FAFC)
val Graphite = Color(0xFF1E293B)
val SoftGrey = Color(0xFFE2E8F0)
val Silver = Color(0xFF94A3B8)
val TicketBg = Color(0xFFFFFFFF)

// Status Colors
val StatusGreen = Color(0xFF059669)
val StatusGreenBg = Color(0xFFD1FAE5)
val WarningAmber = Color(0xFFD97706)
val WarningAmberBg = Color(0xFFFEF3C7)
val CriticalRed = Color(0xFFDC2626)
val CriticalRedBg = Color(0xFFFEE2E2)
