package com.example.data.model

data class WayfindingStep(
    val stepOrder: Int,
    val title: String,
    val subtitle: String,
    val isCompleted: Boolean = false
)

data class Airport(
    val iataCode: String, // "LHR"
    val name: String, // "London Heathrow Airport"
    val city: String, // "London"
    val terminal: String, // "Terminal 5"
    val routeSteps: List<WayfindingStep>,
    val facilities: List<String>, // ["British Sky Lounge (A Gates)", "Fast Track Security", "Baggage Drop Zone B", "Family Care Room"]
    val groundTransportOptions: List<String> // ["Heathrow Express (15m to Paddington)", "Elizabeth Line", "Piccadilly Line Underground", "Taxi & Rideshare Stand 4"]
)
