package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.FlightLand
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy

@Composable
fun SearchScreen(
    onSearchExecuted: (origin: String, destination: String, date: String) -> Unit
) {
    var origin by remember { mutableStateOf("LHR (London Heathrow)") }
    var destination by remember { mutableStateOf("EDI (Edinburgh Airport)") }
    var departureDate by remember { mutableStateOf("18 Oct 2026") }
    var passengerCount by remember { mutableStateOf("1 Passenger") }

    var originExpanded by remember { mutableStateOf(false) }
    var destinationExpanded by remember { mutableStateOf(false) }

    val originOptions = listOf(
        "LHR (London Heathrow)",
        "LGW (London Gatwick)",
        "LCY (London City)",
        "ALL (All London Airports)",
        "MAN (Manchester Airport)",
        "BHX (Birmingham Airport)"
    )

    val destOptions = listOf(
        "EDI (Edinburgh Airport)",
        "GLA (Glasgow Airport)",
        "MAN (Manchester Airport)",
        "NCL (Newcastle Airport)",
        "ABZ (Aberdeen Airport)",
        "BHD (Belfast City)"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "FLIGHT SEARCH",
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = MidnightNavy,
                letterSpacing = 1.5.sp
            )
        )

        Text(
            text = "Find Domestic British Sky Flights",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MidnightNavy
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {

                // Origin Dropdown
                Text(
                    text = "FROM",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                )
                Box {
                    OutlinedTextField(
                        value = origin,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { originExpanded = true }
                            .testTag("origin_select_input"),
                        leadingIcon = { Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = AviationBlue) },
                        shape = RoundedCornerShape(8.dp)
                    )
                    DropdownMenu(
                        expanded = originExpanded,
                        onDismissRequest = { originExpanded = false }
                    ) {
                        originOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    origin = option
                                    originExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Destination Dropdown
                Text(
                    text = "TO",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                )
                Box {
                    OutlinedTextField(
                        value = destination,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { destinationExpanded = true }
                            .testTag("destination_select_input"),
                        leadingIcon = { Icon(Icons.Default.FlightLand, contentDescription = null, tint = AviationBlue) },
                        shape = RoundedCornerShape(8.dp)
                    )
                    DropdownMenu(
                        expanded = destinationExpanded,
                        onDismissRequest = { destinationExpanded = false }
                    ) {
                        destOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    destination = option
                                    destinationExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Date & Passengers Row
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "DATE", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold))
                        OutlinedTextField(
                            value = departureDate,
                            onValueChange = { departureDate = it },
                            leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, tint = AviationBlue) },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("date_input")
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "PASSENGERS", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold))
                        OutlinedTextField(
                            value = passengerCount,
                            onValueChange = { passengerCount = it },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = AviationBlue) },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("passengers_input")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        val originCode = if (origin.contains("(")) origin.substring(0, 3) else "LHR"
                        val destCode = if (destination.contains("(")) destination.substring(0, 3) else "EDI"
                        onSearchExecuted(originCode, destCode, departureDate)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("execute_search_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = AviationBlue),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("SEARCH FLIGHTS", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
