package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BaggageSelection
import com.example.data.model.Passenger
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.StatusGreen

@Composable
fun BaggageAddonsScreen(
    passengers: List<Passenger>,
    onContinueToPayment: (baggageList: List<BaggageSelection>, baggageTotalPence: Int, addOnsTotalPence: Int) -> Unit,
    onBack: () -> Unit
) {
    var checkedBagsCount by remember { mutableIntStateOf(1) } // Default 1 20kg bag
    var fastTrackSelected by remember { mutableStateOf(false) } // £15
    var loungeSelected by remember { mutableStateOf(false) } // £30

    val baggageTotalPence = checkedBagsCount * 3500
    val addOnsTotalPence = (if (fastTrackSelected) 1500 else 0) + (if (loungeSelected) 3000 else 0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MidnightNavy)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "BAGGAGE & ADD-ONS",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = Color.Gray)
                )
                Text(
                    text = "Customise Your Journey",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Baggage Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "BAGGAGE ALLOWANCE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MidnightNavy
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Cabin bag included
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.BusinessCenter, contentDescription = null, tint = AviationBlue)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = "Cabin Under-Seat Bag", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
                            Text(text = "Max 40 x 30 x 15 cm", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                        }
                    }

                    Surface(color = StatusGreen.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp)) {
                        Text(text = "INCLUDED", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall.copy(color = StatusGreen, fontWeight = FontWeight.Bold))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Checked Bag Counter
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Luggage, contentDescription = null, tint = AviationBlue)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = "20kg Checked Bag", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
                            Text(text = "£35 per bag", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { if (checkedBagsCount > 0) checkedBagsCount-- },
                            modifier = Modifier.testTag("remove_bag_button")
                        ) {
                            Icon(imageVector = Icons.Default.Remove, contentDescription = "Remove")
                        }
                        Text(
                            text = checkedBagsCount.toString(),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = MidnightNavy
                            )
                        )
                        IconButton(
                            onClick = { checkedBagsCount++ },
                            modifier = Modifier.testTag("add_bag_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Add-ons Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "AIRPORT ADD-ONS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MidnightNavy
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Fast Track
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { fastTrackSelected = !fastTrackSelected }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = fastTrackSelected,
                            onCheckedChange = { fastTrackSelected = it },
                            colors = CheckboxDefaults.colors(checkedColor = AviationBlue),
                            modifier = Modifier.testTag("fast_track_checkbox")
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(text = "Fast Track Security", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
                            Text(text = "Priority security queue at Heathrow T5", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                        }
                    }

                    Text(text = "+£15", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = AviationBlue))
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Lounge Access
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { loungeSelected = !loungeSelected }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = loungeSelected,
                            onCheckedChange = { loungeSelected = it },
                            colors = CheckboxDefaults.colors(checkedColor = AviationBlue),
                            modifier = Modifier.testTag("lounge_checkbox")
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(text = "British Sky Lounge Access", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
                            Text(text = "Galleries lounge entry with complimentary dining", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                        }
                    }

                    Text(text = "+£30", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = AviationBlue))
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                val baggageList = passengers.map { p ->
                    BaggageSelection(
                        passengerId = p.id,
                        cabinBagsCount = 1,
                        checkedBagsCount = checkedBagsCount
                    )
                }
                onContinueToPayment(baggageList, baggageTotalPence, addOnsTotalPence)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("continue_to_payment_button"),
            colors = ButtonDefaults.buttonColors(containerColor = AviationBlue),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("CONTINUE TO PAYMENT")
        }
    }
}
