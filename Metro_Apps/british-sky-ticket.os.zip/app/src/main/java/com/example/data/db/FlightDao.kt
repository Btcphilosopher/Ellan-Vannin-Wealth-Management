package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Flight
import kotlinx.coroutines.flow.Flow

@Dao
interface FlightDao {
    @Query("SELECT * FROM flight_statuses ORDER BY scheduledDeparture ASC")
    fun getAllFlights(): Flow<List<Flight>>

    @Query("SELECT * FROM flight_statuses WHERE flightNumber = :flightNumber LIMIT 1")
    fun getFlightByNumber(flightNumber: String): Flow<Flight?>

    @Query("SELECT * FROM flight_statuses WHERE flightNumber = :flightNumber LIMIT 1")
    suspend fun getFlightByNumberSync(flightNumber: String): Flight?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlight(flight: Flight)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllFlights(flights: List<Flight>)

    @Update
    suspend fun updateFlight(flight: Flight)
}
