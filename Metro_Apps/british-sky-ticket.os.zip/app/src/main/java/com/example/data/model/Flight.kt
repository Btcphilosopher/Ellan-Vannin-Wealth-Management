package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class FlightStatus {
    SCHEDULED,
    CHECK_IN_OPEN,
    BOARDING,
    GATE_OPEN,
    FINAL_CALL,
    DEPARTED,
    AIRBORNE,
    ARRIVING,
    LANDED,
    DELAYED,
    CANCELLED,
    DIVERTED
}

@Entity(tableName = "flight_statuses")
data class Flight(
    @PrimaryKey
    val flightNumber: String, // e.g. "BS241"
    val carrierName: String = "British Sky Airways",
    val carrierCode: String = "BS",
    val originCode: String, // "LHR"
    val originName: String, // "London Heathrow"
    val originCity: String, // "London"
    val originTerminal: String, // "Terminal 5"
    val destinationCode: String, // "EDI"
    val destinationName: String, // "Edinburgh Airport"
    val destinationCity: String, // "Edinburgh"
    val destinationTerminal: String = "Main Terminal",
    val scheduledDeparture: String, // "07:20"
    val scheduledArrival: String, // "08:45"
    val estimatedDeparture: String = "", // e.g. "07:55" if delayed
    val estimatedArrival: String = "",
    val departureDate: String, // "18 Oct 2026"
    val duration: String = "1h 25m",
    val aircraft: String = "Airbus A320neo",
    val status: FlightStatus = FlightStatus.SCHEDULED,
    val gate: String = "B32",
    val delayMinutes: Int = 0,
    val lightPricePence: Int = 8200, // £82.00
    val standardPricePence: Int = 10400, // £104.00
    val flexPricePence: Int = 14200 // £142.00
) {
    val displayDepartureTime: String
        get() = if (delayMinutes > 0 && estimatedDeparture.isNotEmpty()) estimatedDeparture else scheduledDeparture

    val displayArrivalTime: String
        get() = if (delayMinutes > 0 && estimatedArrival.isNotEmpty()) estimatedArrival else scheduledArrival
}
