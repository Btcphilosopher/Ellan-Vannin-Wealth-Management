package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Booking
import com.example.data.model.Flight
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.StatusGreen

@Composable
fun CheckInScreen(
    booking: Booking,
    flight: Flight,
    passengerName: String,
    seatNumber: String,
    onCheckInCompleted: (updatedSeat: String) -> Unit,
    onBack: () -> Unit
) {
    var isHazmatAccepted by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MidnightNavy)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "DIGITAL CHECK-IN",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = Color.Gray)
                )
                Text(
                    text = "Flight ${flight.flightNumber} • ${flight.originCode} → ${flight.destinationCode}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Confirmation Details Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "PASSENGER & SEAT CONFIRMATION",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MidnightNavy
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "PASSENGER", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                        Text(text = passengerName, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "ASSIGNED SEAT", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                        Text(text = seatNumber, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = AviationBlue))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "TERMINAL", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                        Text(text = flight.originTerminal, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "GATE", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                        Text(text = flight.gate, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Safety Declaration Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "AVIATION SAFETY DECLARATION",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MidnightNavy
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "I confirm that I am not carrying dangerous goods or restricted items in my cabin baggage or checked luggage as required by UK CAA guidelines.",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isHazmatAccepted,
                        onCheckedChange = { isHazmatAccepted = it },
                        colors = CheckboxDefaults.colors(checkedColor = AviationBlue),
                        modifier = Modifier.testTag("safety_declaration_checkbox")
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "I accept and confirm safety requirements",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { onCheckInCompleted(seatNumber) },
            enabled = isHazmatAccepted,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("complete_checkin_button"),
            colors = ButtonDefaults.buttonColors(containerColor = StatusGreen),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(imageVector = Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
            Text("COMPLETE CHECK-IN & ISSUE BOARDING PASS", fontWeight = FontWeight.Bold)
        }
    }
}
