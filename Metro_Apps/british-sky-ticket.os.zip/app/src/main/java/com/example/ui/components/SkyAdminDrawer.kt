package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FlightStatus
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.WarningAmber

@Composable
fun SkyAdminDialog(
    isOfflineMode: Boolean,
    onToggleOfflineMode: (Boolean) -> Unit,
    onInjectDisruption: (flightNo: String, delayMins: Int, newGate: String) -> Unit,
    onUpdateGate: (flightNo: String, gate: String) -> Unit,
    onSetFlightStatus: (flightNo: String, status: FlightStatus) -> Unit,
    onTriggerDemoFullJourney: () -> Unit,
    onTriggerDemoDisruption: () -> Unit,
    onTriggerDemoMultiPassenger: () -> Unit,
    onClose: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hq_admin_dialog"),
        color = MidnightNavy,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = WarningAmber, shape = RoundedCornerShape(4.dp)) {
                            Text(
                                text = "HQ",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MidnightNavy,
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "BRITISH SKY TICKET HQ",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 1.sp
                            )
                        )
                    }
                    Text(
                        text = "Deterministic Synthetic Airline Operations Engine",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 10.sp
                        )
                    )
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.testTag("close_admin_dialog_button")
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(16.dp))

            // Signature Demo Presets Section
            Text(
                text = "PRESET SIGNATURE DEMONSTRATIONS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = WarningAmber,
                    letterSpacing = 1.sp
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Demo 1
            Button(
                onClick = {
                    onTriggerDemoFullJourney()
                    onClose()
                },
                modifier = Modifier.fillMaxWidth().testTag("trigger_demo_full_journey"),
                colors = ButtonDefaults.buttonColors(containerColor = AviationBlue),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("DEMO 1: FULL JOURNEY (LHR → EDI)")
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Demo 2
            Button(
                onClick = {
                    onTriggerDemoDisruption()
                    onClose()
                },
                modifier = Modifier.fillMaxWidth().testTag("trigger_demo_disruption"),
                colors = ButtonDefaults.buttonColors(containerColor = WarningAmber),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = MidnightNavy)
                Spacer(modifier = Modifier.width(8.dp))
                Text("DEMO 2: DISRUPTION & REBOOKING", color = MidnightNavy, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Demo 3
            OutlinedButton(
                onClick = {
                    onTriggerDemoMultiPassenger()
                    onClose()
                },
                modifier = Modifier.fillMaxWidth().testTag("trigger_demo_multi_passenger"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("DEMO 3: MULTI-PASSENGER (FAMILY)")
            }

            Spacer(modifier = Modifier.height(20.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(16.dp))

            // Real-time Operations Controls
            Text(
                text = "FLIGHT BS241 LIVE DISRUPTION & GATE INJECTOR",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onInjectDisruption("BS241", 35, "C14") },
                    modifier = Modifier.weight(1f).testTag("inject_delay_35m"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("+35m Delay", fontSize = 11.sp)
                }

                Button(
                    onClick = { onUpdateGate("BS241", "C14") },
                    modifier = Modifier.weight(1f).testTag("change_gate_c14"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Gate C14", fontSize = 11.sp)
                }

                Button(
                    onClick = { onSetFlightStatus("BS241", FlightStatus.BOARDING) },
                    modifier = Modifier.weight(1f).testTag("status_boarding"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Boarding", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(16.dp))

            // Offline Mode Toggle (Demo 4)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SIMULATE OFFLINE MODE",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "Tests offline boarding pass & ticket cache",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.LightGray,
                            fontSize = 10.sp
                        )
                    )
                }

                Switch(
                    checked = isOfflineMode,
                    onCheckedChange = onToggleOfflineMode,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = WarningAmber,
                        checkedTrackColor = WarningAmber.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.testTag("toggle_offline_switch")
                )
            }
        }
    }
}
