package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.model.Airport
import com.example.data.model.BaggageSelection
import com.example.data.model.BoardingPass
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.Flight
import com.example.data.model.FlightStatus
import com.example.data.model.NotificationItem
import com.example.data.model.NotificationType
import com.example.data.model.Passenger
import com.example.data.model.Receipt
import com.example.data.model.ReceiptLineItem
import com.example.data.model.Seat
import com.example.data.model.SeatType
import com.example.data.model.WayfindingStep
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class TicketRepository(private val db: AppDatabase) {

    private val scope = CoroutineScope(Dispatchers.IO)

    val allBookings: Flow<List<Booking>> = db.bookingDao().getAllBookings()
    val allPassengers: Flow<List<Passenger>> = db.passengerDao().getAllPassengers()
    val allNotifications: Flow<List<NotificationItem>> = db.notificationDao().getAllNotifications()
    val allFlights: Flow<List<Flight>> = db.flightDao().getAllFlights()

    // Offline mode simulation state
    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    // Active flight delay/disruption banner state
    private val _activeDisruptionBanner = MutableStateFlow<String?>(null)
    val activeDisruptionBanner: StateFlow<String?> = _activeDisruptionBanner.asStateFlow()

    init {
        scope.launch {
            seedInitialDataIfNeeded()
        }
    }

    fun setOfflineMode(offline: Boolean) {
        _isOfflineMode.value = offline
    }

    private suspend fun seedInitialDataIfNeeded() {
        // Seed Flights
        val existingFlights = db.flightDao().getAllFlights().first()
        if (existingFlights.isEmpty()) {
            val sampleFlights = listOf(
                Flight(
                    flightNumber = "BS241",
                    originCode = "LHR",
                    originName = "London Heathrow",
                    originCity = "London",
                    originTerminal = "Terminal 5",
                    destinationCode = "EDI",
                    destinationName = "Edinburgh Airport",
                    destinationCity = "Edinburgh",
                    scheduledDeparture = "07:20",
                    scheduledArrival = "08:45",
                    departureDate = "18 Oct 2026",
                    duration = "1h 25m",
                    aircraft = "Airbus A320neo",
                    status = FlightStatus.CHECK_IN_OPEN,
                    gate = "B32",
                    lightPricePence = 8200,
                    standardPricePence = 10400,
                    flexPricePence = 14200
                ),
                Flight(
                    flightNumber = "BS243",
                    originCode = "LHR",
                    originName = "London Heathrow",
                    originCity = "London",
                    originTerminal = "Terminal 5",
                    destinationCode = "EDI",
                    destinationName = "Edinburgh Airport",
                    destinationCity = "Edinburgh",
                    scheduledDeparture = "10:15",
                    scheduledArrival = "11:40",
                    departureDate = "18 Oct 2026",
                    duration = "1h 25m",
                    aircraft = "Airbus A320neo",
                    status = FlightStatus.SCHEDULED,
                    gate = "A12",
                    lightPricePence = 9500,
                    standardPricePence = 11800,
                    flexPricePence = 15500
                ),
                Flight(
                    flightNumber = "BS247",
                    originCode = "LHR",
                    originName = "London Heathrow",
                    originCity = "London",
                    originTerminal = "Terminal 5",
                    destinationCode = "EDI",
                    destinationName = "Edinburgh Airport",
                    destinationCity = "Edinburgh",
                    scheduledDeparture = "14:30",
                    scheduledArrival = "15:55",
                    departureDate = "18 Oct 2026",
                    duration = "1h 25m",
                    aircraft = "Airbus A320neo",
                    status = FlightStatus.SCHEDULED,
                    gate = "B18",
                    lightPricePence = 8800,
                    standardPricePence = 11000,
                    flexPricePence = 14800
                ),
                Flight(
                    flightNumber = "BS108",
                    originCode = "LHR",
                    originName = "London Heathrow",
                    originCity = "London",
                    originTerminal = "Terminal 5",
                    destinationCode = "GLA",
                    destinationName = "Glasgow Airport",
                    destinationCity = "Glasgow",
                    scheduledDeparture = "08:10",
                    scheduledArrival = "09:30",
                    departureDate = "18 Oct 2026",
                    duration = "1h 20m",
                    aircraft = "Airbus A320neo",
                    status = FlightStatus.SCHEDULED,
                    gate = "A8",
                    lightPricePence = 7900,
                    standardPricePence = 9900,
                    flexPricePence = 13900
                ),
                Flight(
                    flightNumber = "BS417",
                    originCode = "LHR",
                    originName = "London Heathrow",
                    originCity = "London",
                    originTerminal = "Terminal 5",
                    destinationCode = "MAN",
                    destinationName = "Manchester Airport",
                    destinationCity = "Manchester",
                    scheduledDeparture = "09:00",
                    scheduledArrival = "10:00",
                    departureDate = "18 Oct 2026",
                    duration = "1h 00m",
                    aircraft = "Airbus A320neo",
                    status = FlightStatus.SCHEDULED,
                    gate = "A15",
                    lightPricePence = 6500,
                    standardPricePence = 8500,
                    flexPricePence = 12000
                )
            )
            db.flightDao().insertAllFlights(sampleFlights)
        }

        // Seed Primary Passenger
        val existingPassengers = db.passengerDao().getAllPassengers().first()
        if (existingPassengers.isEmpty()) {
            val primaryPassenger = Passenger(
                id = "P1",
                title = "MR",
                firstName = "TOM",
                lastName = "LOVEITT",
                dateOfBirth = "1992-04-12",
                passportNumber = "GB984029102",
                nationality = "British",
                contactEmail = "tom.loveitt@example.co.uk",
                contactPhone = "+44 7700 900123",
                isPrimary = true
            )
            val familyPassenger1 = Passenger(
                id = "P2",
                title = "MRS",
                firstName = "SARAH",
                lastName = "LOVEITT",
                dateOfBirth = "1994-08-22",
                passportNumber = "GB883019283",
                nationality = "British",
                contactEmail = "sarah.loveitt@example.co.uk",
                contactPhone = "+44 7700 900124",
                isPrimary = false
            )
            val familyPassenger2 = Passenger(
                id = "P3",
                title = "MSTR",
                firstName = "JAMES",
                lastName = "LOVEITT",
                dateOfBirth = "2020-03-10",
                passportNumber = "GB771029384",
                nationality = "British",
                contactEmail = "tom.loveitt@example.co.uk",
                contactPhone = "+44 7700 900123",
                isPrimary = false
            )
            db.passengerDao().insertAllPassengers(listOf(primaryPassenger, familyPassenger1, familyPassenger2))
        }

        // Seed Default Sample Booking (BS7K4P for Tom Loveitt)
        val existingBookings = db.bookingDao().getAllBookings().first()
        if (existingBookings.isEmpty()) {
            val pnr = "BS7K4P"
            val passengersJson = JSONArray().apply {
                put(JSONObject().apply {
                    put("id", "P1")
                    put("title", "MR")
                    put("firstName", "TOM")
                    put("lastName", "LOVEITT")
                })
            }.toString()

            val seatsJson = JSONObject().apply {
                put("P1", "12A")
            }.toString()

            val baggageJson = JSONArray().apply {
                put(JSONObject().apply {
                    put("passengerId", "P1")
                    put("cabinBagsCount", 1)
                    put("checkedBagsCount", 1)
                    put("extraBagsCount", 0)
                })
            }.toString()

            val defaultBooking = Booking(
                bookingId = pnr,
                eTicketNumber = "125-9840283412",
                flightNumber = "BS241",
                fareType = "STANDARD",
                totalAmountPence = 12900, // £82 + £12 seat + £35 bag = £129
                paymentMethod = "Apple Pay (Visa •••• 4092)",
                status = BookingStatus.CONFIRMED,
                passengersJson = passengersJson,
                seatsJson = seatsJson,
                baggageJson = baggageJson,
                checkInCompleted = false
            )
            db.bookingDao().insertBooking(defaultBooking)

            // Initial Welcome Notification
            db.notificationDao().insertNotification(
                NotificationItem(
                    bookingId = pnr,
                    title = "Check-in Now Open",
                    message = "Flight BS241 to Edinburgh is ready for digital check-in. Select your seat and get your boarding pass.",
                    timeFormatted = "06:00",
                    type = NotificationType.CHECK_IN_REMINDER
                )
            )
        }
    }

    // Helper functions for Seats Map
    fun generateSeatMapForAircraft(): List<Seat> {
        val list = mutableListOf<Seat>()
        for (row in 1..24) {
            val seatType = when (row) {
                1 -> SeatType.EXTRA_LEGROOM
                12, 13 -> SeatType.EXIT_ROW
                else -> SeatType.STANDARD
            }
            val price = when (seatType) {
                SeatType.EXTRA_LEGROOM -> 2500
                SeatType.EXIT_ROW -> 1800
                SeatType.STANDARD -> 1200
            }
            // Some occupied seats for visual realism
            val occupiedCols = when (row) {
                2 -> listOf("B", "E")
                5 -> listOf("A", "C", "D")
                8 -> listOf("F")
                14 -> listOf("A", "B", "C")
                18 -> listOf("D", "E")
                else -> emptyList()
            }
            for (col in listOf("A", "B", "C", "D", "E", "F")) {
                list.add(
                    Seat(
                        row = row,
                        letter = col,
                        type = seatType,
                        pricePence = price,
                        isOccupied = occupiedCols.contains(col)
                    )
                )
            }
        }
        return list
    }

    // Wayfinding Airport Data
    fun getAirportInfo(code: String): Airport {
        return if (code == "EDI") {
            Airport(
                iataCode = "EDI",
                name = "Edinburgh Airport",
                city = "Edinburgh",
                terminal = "Main Terminal",
                routeSteps = listOf(
                    WayfindingStep(1, "Arrivals Hall & Luggage Claim", "Baggage Carousel 4", true),
                    WayfindingStep(2, "Exit & Ground Transport Hub", "Tram, Bus & Taxi interchange", false)
                ),
                facilities = listOf("British Sky Lounge", "Tram Terminal", "Edinburgh Airport Plaza"),
                groundTransportOptions = listOf(
                    "Edinburgh Trams (St Andrew Square - 30 mins)",
                    "Airlink 100 Express Bus (Waverley Station - 25 mins)",
                    "Official Airport Taxi Rank"
                )
            )
        } else {
            Airport(
                iataCode = "LHR",
                name = "London Heathrow Airport",
                city = "London",
                terminal = "Terminal 5",
                routeSteps = listOf(
                    WayfindingStep(1, "Main Terminal Entrance", "Check-in Zone B & Sky Priority", true),
                    WayfindingStep(2, "Baggage Drop", "Self-service Bag Drop Counters 12-20", false),
                    WayfindingStep(3, "North Security Search", "Fast Track & Standard Lanes", false),
                    WayfindingStep(4, "Gate B32 Departure Lounge", "Transit Shuttle to Satellite Terminal B", false)
                ),
                facilities = listOf(
                    "British Sky Galleries Lounge (T5 North)",
                    "Fast Track Security Lane 1",
                    "Self-Service Bag Drop Zone B",
                    "Aviation Quiet Room & Work Suites"
                ),
                groundTransportOptions = listOf(
                    "Heathrow Express (Non-stop to London Paddington - 15 mins)",
                    "Elizabeth Line (Direct to West End & City)",
                    "Piccadilly Line Underground",
                    "Terminal 5 Chauffeur & Taxi Plaza"
                )
            )
        }
    }

    // Actions
    suspend fun performCheckIn(bookingId: String, updatedSeat: String) {
        val booking = db.bookingDao().getBookingByIdSync(bookingId) ?: return
        val currentSeats = JSONObject(booking.seatsJson)
        currentSeats.put("P1", updatedSeat)

        val updatedBooking = booking.copy(
            seatsJson = currentSeats.toString(),
            status = BookingStatus.CHECKED_IN,
            checkInCompleted = true
        )
        db.bookingDao().updateBooking(updatedBooking)

        // Add Notification
        db.notificationDao().insertNotification(
            NotificationItem(
                bookingId = bookingId,
                title = "Check-In Complete",
                message = "Boarding pass issued for $updatedSeat. Gate B32 is scheduled.",
                timeFormatted = "06:15",
                type = NotificationType.BOARDING_OPEN
            )
        )
    }

    suspend fun createBooking(
        flightNumber: String,
        fareType: String,
        selectedPassengers: List<Passenger>,
        selectedSeats: Map<String, String>,
        baggageList: List<BaggageSelection>,
        totalPence: Int,
        paymentMethodName: String
    ): String {
        val pnr = "BS" + (1000..9999).random() + listOf("P", "K", "X", "M", "T").random()
        val eTicket = "125-" + (1000000000..9999999999).random()

        val passengersArray = JSONArray()
        selectedPassengers.forEach { p ->
            passengersArray.put(JSONObject().apply {
                put("id", p.id)
                put("title", p.title)
                put("firstName", p.firstName)
                put("lastName", p.lastName)
            })
        }

        val seatsObj = JSONObject()
        selectedSeats.forEach { (pid, seatNo) ->
            seatsObj.put(pid, seatNo)
        }

        val bagArray = JSONArray()
        baggageList.forEach { b ->
            bagArray.put(JSONObject().apply {
                put("passengerId", b.passengerId)
                put("cabinBagsCount", b.cabinBagsCount)
                put("checkedBagsCount", b.checkedBagsCount)
                put("extraBagsCount", b.extraBagsCount)
            })
        }

        val newBooking = Booking(
            bookingId = pnr,
            eTicketNumber = eTicket,
            flightNumber = flightNumber,
            fareType = fareType,
            totalAmountPence = totalPence,
            paymentMethod = paymentMethodName,
            status = BookingStatus.CONFIRMED,
            passengersJson = passengersArray.toString(),
            seatsJson = seatsObj.toString(),
            baggageJson = bagArray.toString(),
            checkInCompleted = false
        )

        db.bookingDao().insertBooking(newBooking)

        db.notificationDao().insertNotification(
            NotificationItem(
                bookingId = pnr,
                title = "Booking Confirmed ($pnr)",
                message = "Your British Sky journey on flight $flightNumber has been ticketed.",
                timeFormatted = "06:30",
                type = NotificationType.SYSTEM
            )
        )

        return pnr
    }

    // HQ Operations & Disruption Injections (Demo Trigger 2)
    suspend fun injectDisruption(flightNumber: String, delayMinutes: Int, newGate: String) {
        val flight = db.flightDao().getFlightByNumberSync(flightNumber) ?: return
        val updatedFlight = flight.copy(
            status = FlightStatus.DELAYED,
            delayMinutes = delayMinutes,
            estimatedDeparture = "07:55",
            gate = newGate
        )
        db.flightDao().updateFlight(updatedFlight)

        _activeDisruptionBanner.value = "FLIGHT BS241 DELAYED BY $delayMinutes MINS • NEW GATE $newGate"

        db.notificationDao().insertNotification(
            NotificationItem(
                bookingId = "BS7K4P",
                title = "Flight Delayed by $delayMinutes Mins",
                message = "BS241 to EDI is now estimated to depart at 07:55 from Gate $newGate.",
                timeFormatted = "06:45",
                type = NotificationType.FLIGHT_DELAY
            )
        )
    }

    suspend fun updateGate(flightNumber: String, gate: String) {
        val flight = db.flightDao().getFlightByNumberSync(flightNumber) ?: return
        val updated = flight.copy(gate = gate)
        db.flightDao().updateFlight(updated)

        db.notificationDao().insertNotification(
            NotificationItem(
                bookingId = "BS7K4P",
                title = "Gate Assigned: Gate $gate",
                message = "Boarding for $flightNumber will take place at Terminal 5 Gate $gate.",
                timeFormatted = "06:40",
                type = NotificationType.GATE_CHANGE
            )
        )
    }

    suspend fun setFlightStatus(flightNumber: String, status: FlightStatus) {
        val flight = db.flightDao().getFlightByNumberSync(flightNumber) ?: return
        val updated = flight.copy(status = status)
        db.flightDao().updateFlight(updated)
    }

    suspend fun rebookFlight(bookingId: String, newFlightNumber: String) {
        val booking = db.bookingDao().getBookingByIdSync(bookingId) ?: return
        val updatedBooking = booking.copy(
            flightNumber = newFlightNumber,
            checkInCompleted = false,
            status = BookingStatus.CONFIRMED
        )
        db.bookingDao().updateBooking(updatedBooking)
        _activeDisruptionBanner.value = null

        db.notificationDao().insertNotification(
            NotificationItem(
                bookingId = bookingId,
                title = "Flight Rebooked to $newFlightNumber",
                message = "Your ticket $bookingId has been reissued for flight $newFlightNumber.",
                timeFormatted = "07:05",
                type = NotificationType.SYSTEM
            )
        )
    }

    fun parsePassengers(json: String): List<Passenger> {
        val list = mutableListOf<Passenger>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    Passenger(
                        id = obj.optString("id", "P$i"),
                        title = obj.optString("title", "MR"),
                        firstName = obj.optString("firstName", "PASSENGER"),
                        lastName = obj.optString("lastName", "GUEST")
                    )
                )
            }
        } catch (e: Exception) {
            list.add(Passenger("P1", "MR", "TOM", "LOVEITT"))
        }
        return list
    }

    fun parseSeats(json: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        try {
            val obj = JSONObject(json)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                map[key] = obj.getString(key)
            }
        } catch (e: Exception) {
            map["P1"] = "12A"
        }
        return map
    }

    fun generateReceipt(booking: Booking, flight: Flight): Receipt {
        val items = mutableListOf<ReceiptLineItem>()
        val fareCost = when (booking.fareType) {
            "LIGHT" -> flight.lightPricePence
            "FLEX" -> flight.flexPricePence
            else -> flight.standardPricePence
        }
        items.add(ReceiptLineItem("British Sky Air Fare (${flight.flightNumber} ${flight.originCode}-${flight.destinationCode})", fareCost))
        items.add(ReceiptLineItem("Allocated Seat Assignment", 1200))
        items.add(ReceiptLineItem("20kg Checked Baggage Allowance", 3500))

        return Receipt(
            receiptId = "REC-" + booking.bookingId,
            bookingReference = booking.bookingId,
            dateIssued = flight.departureDate,
            passengerName = parsePassengers(booking.passengersJson).firstOrNull()?.fullName ?: "TOM LOVEITT",
            lineItems = items,
            totalPence = booking.totalAmountPence
        )
    }
}
