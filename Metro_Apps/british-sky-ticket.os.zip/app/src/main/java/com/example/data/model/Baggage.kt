package com.example.data.model

enum class BaggageType {
    CABIN_BAG,
    CHECKED_20KG,
    EXTRA_20KG
}

data class BaggageSelection(
    val passengerId: String,
    val cabinBagsCount: Int = 1, // 1 included
    val checkedBagsCount: Int = 0, // 20kg each (£35)
    val extraBagsCount: Int = 0 // £45 each
) {
    val totalBaggageCostPence: Int
        get() = (checkedBagsCount * 3500) + (extraBagsCount * 4500)
}
