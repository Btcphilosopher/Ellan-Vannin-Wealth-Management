package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneIphone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy

@Composable
fun PaymentScreen(
    flightPricePence: Int,
    seatsPricePence: Int,
    baggagePricePence: Int,
    addOnsPricePence: Int,
    onPayConfirmed: (paymentMethodName: String, totalPence: Int) -> Unit,
    onBack: () -> Unit
) {
    val totalPence = flightPricePence + seatsPricePence + baggagePricePence + addOnsPricePence
    val totalFormatted = "£${"%.2f".format(totalPence / 100.0)}"

    var selectedPaymentMethod by remember { mutableStateOf("Apple Pay") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MidnightNavy)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "PAYMENT & ISSUANCE",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = Color.Gray)
                )
                Text(
                    text = "Checkout Breakdown",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Price Breakdown Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ITEMISED SUMMARY",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MidnightNavy
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                PriceRow("British Sky Flight Fare", flightPricePence)
                PriceRow("Seat Allocation", seatsPricePence)
                PriceRow("Checked Baggage", baggagePricePence)
                if (addOnsPricePence > 0) {
                    PriceRow("Airport Add-ons", addOnsPricePence)
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Color(0xFFE2E8F0))
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL DUE",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = MidnightNavy
                        )
                    )
                    Text(
                        text = totalFormatted,
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = AviationBlue
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Payment Method Selection Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SELECT PAYMENT METHOD",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = MidnightNavy
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                PaymentOptionRow(
                    title = "Apple Pay",
                    subtitle = "Touch ID / Face ID Express Checkout",
                    isSelected = selectedPaymentMethod == "Apple Pay",
                    onClick = { selectedPaymentMethod = "Apple Pay" },
                    testTag = "pay_method_apple"
                )

                PaymentOptionRow(
                    title = "Google Pay",
                    subtitle = "Stored Payment Pass",
                    isSelected = selectedPaymentMethod == "Google Pay",
                    onClick = { selectedPaymentMethod = "Google Pay" },
                    testTag = "pay_method_google"
                )

                PaymentOptionRow(
                    title = "Credit / Debit Card",
                    subtitle = "Visa ending in •••• 4092",
                    isSelected = selectedPaymentMethod == "Card",
                    onClick = { selectedPaymentMethod = "Card" },
                    testTag = "pay_method_card"
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { onPayConfirmed(selectedPaymentMethod, totalPence) },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("pay_now_button"),
            colors = ButtonDefaults.buttonColors(containerColor = MidnightNavy),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
            Text("PAY $totalFormatted & ISSUE TICKET", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PriceRow(label: String, pricePence: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(color = MidnightNavy))
        Text(
            text = "£${"%.2f".format(pricePence / 100.0)}",
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MidnightNavy
            )
        )
    }
}

@Composable
private fun PaymentOptionRow(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 6.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = isSelected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = AviationBlue)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy))
            Text(text = subtitle, style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontSize = 10.sp))
        }
    }
}
