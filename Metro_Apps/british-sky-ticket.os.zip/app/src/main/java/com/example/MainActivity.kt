package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import com.example.data.model.Booking
import com.example.data.model.FlightStatus
import com.example.ui.components.SkyAdminDialog
import com.example.ui.components.SkyBoardingPass
import com.example.ui.components.SkyHeader
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.AirportGuideScreen
import com.example.ui.screens.BaggageAddonsScreen
import com.example.ui.screens.CheckInScreen
import com.example.ui.screens.ConfirmationScreen
import com.example.ui.screens.DisruptionRebookScreen
import com.example.ui.screens.FareSelectionScreen
import com.example.ui.screens.FlightResultsScreen
import com.example.ui.screens.FlightStatusScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PassengerFormScreen
import com.example.ui.screens.PaymentScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SeatSelectionScreen
import com.example.ui.screens.TicketDetailScreen
import com.example.ui.screens.TravelWalletScreen
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.BritishSkyTheme
import com.example.ui.theme.MidnightNavy

sealed class Screen {
    object Home : Screen()
    object Search : Screen()
    object Results : Screen()
    object Fare : Screen()
    object PassengerForm : Screen()
    object Seats : Screen()
    object Baggage : Screen()
    object Payment : Screen()
    data class Confirmation(val pnr: String) : Screen()
    data class TicketDetail(val bookingId: String) : Screen()
    data class BoardingPass(val bookingId: String) : Screen()
    data class CheckIn(val bookingId: String) : Screen()
    object Status : Screen()
    object Disruption : Screen()
    object AirportGuide : Screen()
    object Wallet : Screen()
    object Account : Screen()
}

class MainActivity : ComponentActivity() {

    private val viewModel: TicketViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            BritishSkyTheme {
                MainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainApp(viewModel: TicketViewModel) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }
    var showAdminDialog by remember { mutableStateOf(false) }

    val bookings by viewModel.bookings.collectAsState()
    val passengers by viewModel.passengers.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val flights by viewModel.flights.collectAsState()
    val isOfflineMode by viewModel.isOfflineMode.collectAsState()
    val activeDisruptionBanner by viewModel.activeDisruptionBanner.collectAsState()

    val flightsMap = remember(flights) { flights.associateBy { it.flightNumber } }

    val primaryBooking = bookings.firstOrNull()
    val primaryFlight = primaryBooking?.let { flightsMap[it.flightNumber] } ?: flights.find { it.flightNumber == "BS241" }
    val primaryPassengers = primaryBooking?.let { viewModel.parsePassengers(it.passengersJson) } ?: passengers
    val primaryPassengerName = primaryPassengers.firstOrNull()?.fullName ?: "TOM LOVEITT"
    val primarySeats = primaryBooking?.let { viewModel.parseSeats(it.seatsJson) } ?: emptyMap()
    val primarySeatNumber = primarySeats["P1"] ?: "12A"

    val unreadNotificationsCount = notifications.count { !it.isRead }

    // Handle Back Press for secondary screens
    if (currentScreen != Screen.Home) {
        BackHandler {
            currentScreen = when (currentScreen) {
                is Screen.Results, is Screen.Fare, is Screen.PassengerForm, is Screen.Seats, is Screen.Baggage, is Screen.Payment -> Screen.Search
                is Screen.Confirmation, is Screen.TicketDetail, is Screen.BoardingPass, is Screen.CheckIn, is Screen.Disruption -> Screen.Home
                else -> Screen.Home
            }
        }
    }

    Scaffold(
        topBar = {
            SkyHeader(
                isOfflineMode = isOfflineMode,
                unreadNotificationCount = unreadNotificationsCount,
                activeDisruptionText = activeDisruptionBanner,
                onNotificationClick = { currentScreen = Screen.Wallet },
                onAdminClick = { showAdminDialog = true }
            )
        },
        bottomBar = {
            if (currentScreen !is Screen.BoardingPass && currentScreen !is Screen.Confirmation) {
                NavigationBar(
                    containerColor = MidnightNavy,
                    contentColor = Color.White,
                    modifier = Modifier.navigationBarsPadding().testTag("main_navigation_bar")
                ) {
                    NavigationBarItem(
                        selected = currentScreen is Screen.Home,
                        onClick = { currentScreen = Screen.Home },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("HOME", fontSize = 9.sp, fontFamily = FontFamily.Monospace) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            indicatorColor = AviationBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_home")
                    )

                    NavigationBarItem(
                        selected = currentScreen is Screen.Search || currentScreen is Screen.Results || currentScreen is Screen.Fare,
                        onClick = { currentScreen = Screen.Search },
                        icon = { Icon(Icons.Default.Search, contentDescription = "Book") },
                        label = { Text("BOOK", fontSize = 9.sp, fontFamily = FontFamily.Monospace) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            indicatorColor = AviationBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_book")
                    )

                    NavigationBarItem(
                        selected = currentScreen is Screen.Wallet || currentScreen is Screen.TicketDetail,
                        onClick = { currentScreen = Screen.Wallet },
                        icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Journeys") },
                        label = { Text("JOURNEYS", fontSize = 9.sp, fontFamily = FontFamily.Monospace) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            indicatorColor = AviationBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_journeys")
                    )

                    NavigationBarItem(
                        selected = currentScreen is Screen.Status,
                        onClick = { currentScreen = Screen.Status },
                        icon = { Icon(Icons.Default.Flight, contentDescription = "Status") },
                        label = { Text("STATUS", fontSize = 9.sp, fontFamily = FontFamily.Monospace) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            indicatorColor = AviationBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_status")
                    )

                    NavigationBarItem(
                        selected = currentScreen is Screen.Account,
                        onClick = { currentScreen = Screen.Account },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Account") },
                        label = { Text("ACCOUNT", fontSize = 9.sp, fontFamily = FontFamily.Monospace) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            indicatorColor = AviationBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_account")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val screen = currentScreen) {
                is Screen.Home -> {
                    HomeScreen(
                        primaryBooking = primaryBooking,
                        primaryFlight = primaryFlight,
                        passengerName = primaryPassengerName,
                        seatNumber = primarySeatNumber,
                        activeDisruptionText = activeDisruptionBanner,
                        onNavigateToSearch = { currentScreen = Screen.Search },
                        onNavigateToTicketDetail = { currentScreen = Screen.TicketDetail(it) },
                        onNavigateToBoardingPass = {
                            primaryBooking?.let { currentScreen = Screen.BoardingPass(it.bookingId) }
                        },
                        onNavigateToCheckIn = { currentScreen = Screen.CheckIn(it) },
                        onNavigateToStatus = { currentScreen = Screen.Status },
                        onNavigateToWallet = { currentScreen = Screen.Wallet },
                        onNavigateToAirportGuide = { currentScreen = Screen.AirportGuide },
                        onNavigateToDisruption = { currentScreen = Screen.Disruption }
                    )
                }

                is Screen.Search -> {
                    SearchScreen(
                        onSearchExecuted = { origin, dest, date ->
                            currentScreen = Screen.Results
                        }
                    )
                }

                is Screen.Results -> {
                    FlightResultsScreen(
                        origin = "LHR",
                        destination = "EDI",
                        date = "18 Oct 2026",
                        flights = flights,
                        onSelectFlight = { flight ->
                            viewModel.draftSelectedFlight.value = flight
                            currentScreen = Screen.Fare
                        },
                        onBack = { currentScreen = Screen.Search }
                    )
                }

                is Screen.Fare -> {
                    val targetFlight = viewModel.draftSelectedFlight.value ?: flights.first()
                    FareSelectionScreen(
                        flight = targetFlight,
                        onFareSelected = { fareType, pricePence ->
                            viewModel.draftFareType.value = fareType
                            viewModel.draftFarePricePence.value = pricePence
                            currentScreen = Screen.PassengerForm
                        },
                        onBack = { currentScreen = Screen.Results }
                    )
                }

                is Screen.PassengerForm -> {
                    PassengerFormScreen(
                        savedPassengers = passengers,
                        onContinueToSeats = { selected ->
                            viewModel.draftPassengers.value = selected
                            currentScreen = Screen.Seats
                        },
                        onBack = { currentScreen = Screen.Fare }
                    )
                }

                is Screen.Seats -> {
                    SeatSelectionScreen(
                        passengers = if (viewModel.draftPassengers.value.isNotEmpty()) viewModel.draftPassengers.value else passengers.take(1),
                        allSeats = viewModel.generatedSeatsList,
                        onSeatsConfirmed = { seatMap, totalPence ->
                            viewModel.draftSeatsMap.value = seatMap
                            viewModel.draftSeatsPricePence.value = totalPence
                            currentScreen = Screen.Baggage
                        },
                        onBack = { currentScreen = Screen.PassengerForm }
                    )
                }

                is Screen.Baggage -> {
                    BaggageAddonsScreen(
                        passengers = if (viewModel.draftPassengers.value.isNotEmpty()) viewModel.draftPassengers.value else passengers.take(1),
                        onContinueToPayment = { baggageList, bagTotal, addOnsTotal ->
                            viewModel.draftBaggageList.value = baggageList
                            viewModel.draftBaggagePricePence.value = bagTotal
                            viewModel.draftAddOnsPricePence.value = addOnsTotal
                            currentScreen = Screen.Payment
                        },
                        onBack = { currentScreen = Screen.Seats }
                    )
                }

                is Screen.Payment -> {
                    PaymentScreen(
                        flightPricePence = viewModel.draftFarePricePence.value,
                        seatsPricePence = viewModel.draftSeatsPricePence.value,
                        baggagePricePence = viewModel.draftBaggagePricePence.value,
                        addOnsPricePence = viewModel.draftAddOnsPricePence.value,
                        onPayConfirmed = { methodName, totalPence ->
                            viewModel.createBookingFromDraft(methodName, totalPence) { pnr ->
                                currentScreen = Screen.Confirmation(pnr)
                            }
                        },
                        onBack = { currentScreen = Screen.Baggage }
                    )
                }

                is Screen.Confirmation -> {
                    ConfirmationScreen(
                        pnr = screen.pnr,
                        onViewTicket = { pnr ->
                            currentScreen = Screen.TicketDetail(pnr)
                        }
                    )
                }

                is Screen.TicketDetail -> {
                    val booking = bookings.find { it.bookingId == screen.bookingId } ?: primaryBooking
                    val flight = booking?.let { flightsMap[it.flightNumber] } ?: primaryFlight ?: flights.first()
                    val passengerName = booking?.let { viewModel.parsePassengers(it.passengersJson).firstOrNull()?.fullName } ?: primaryPassengerName
                    val seatNumber = booking?.let { viewModel.parseSeats(it.seatsJson)["P1"] } ?: primarySeatNumber
                    val receipt = booking?.let { viewModel.generateReceipt(it, flight) } ?: viewModel.generateReceipt(primaryBooking ?: Booking("BS7K4P", "125-9840283412", "BS241", "STANDARD", totalAmountPence = 12900, passengersJson = "[]", seatsJson = "{}", baggageJson = "[]"), flight)

                    if (booking != null) {
                        TicketDetailScreen(
                            booking = booking,
                            flight = flight,
                            passengerName = passengerName,
                            seatNumber = seatNumber,
                            receipt = receipt,
                            onViewBoardingPass = { currentScreen = Screen.BoardingPass(booking.bookingId) },
                            onCheckIn = { currentScreen = Screen.CheckIn(booking.bookingId) },
                            onNavigateToSeatSelection = { currentScreen = Screen.Seats },
                            onNavigateToAirportGuide = { currentScreen = Screen.AirportGuide },
                            onBack = { currentScreen = Screen.Home }
                        )
                    }
                }

                is Screen.BoardingPass -> {
                    val booking = bookings.find { it.bookingId == screen.bookingId } ?: primaryBooking
                    val flight = booking?.let { flightsMap[it.flightNumber] } ?: primaryFlight ?: flights.first()
                    val passengerName = booking?.let { viewModel.parsePassengers(it.passengersJson).firstOrNull()?.fullName } ?: primaryPassengerName
                    val seatNumber = booking?.let { viewModel.parseSeats(it.seatsJson)["P1"] } ?: primarySeatNumber

                    if (booking != null) {
                        SkyBoardingPass(
                            booking = booking,
                            flight = flight,
                            passengerName = passengerName,
                            seatNumber = seatNumber,
                            onClose = { currentScreen = Screen.Home }
                        )
                    }
                }

                is Screen.CheckIn -> {
                    val booking = bookings.find { it.bookingId == screen.bookingId } ?: primaryBooking
                    val flight = booking?.let { flightsMap[it.flightNumber] } ?: primaryFlight ?: flights.first()
                    val passengerName = booking?.let { viewModel.parsePassengers(it.passengersJson).firstOrNull()?.fullName } ?: primaryPassengerName
                    val seatNumber = booking?.let { viewModel.parseSeats(it.seatsJson)["P1"] } ?: primarySeatNumber

                    if (booking != null) {
                        CheckInScreen(
                            booking = booking,
                            flight = flight,
                            passengerName = passengerName,
                            seatNumber = seatNumber,
                            onCheckInCompleted = { updatedSeat ->
                                viewModel.checkIn(booking.bookingId, updatedSeat)
                                currentScreen = Screen.BoardingPass(booking.bookingId)
                            },
                            onBack = { currentScreen = Screen.Home }
                        )
                    }
                }

                is Screen.Status -> {
                    FlightStatusScreen(flights = flights)
                }

                is Screen.Disruption -> {
                    val flight = primaryFlight ?: flights.first()
                    DisruptionRebookScreen(
                        currentFlight = flight,
                        alternativeFlights = flights.filter { it.flightNumber != flight.flightNumber },
                        onRebookSelected = { newFlightNo ->
                            primaryBooking?.let { viewModel.rebookFlight(it.bookingId, newFlightNo) }
                            currentScreen = Screen.Home
                        },
                        onBack = { currentScreen = Screen.Home }
                    )
                }

                is Screen.AirportGuide -> {
                    val airport = viewModel.getAirportInfo("LHR")
                    AirportGuideScreen(
                        airport = airport,
                        gate = primaryFlight?.gate ?: "B32",
                        onBack = { currentScreen = Screen.Home }
                    )
                }

                is Screen.Wallet -> {
                    TravelWalletScreen(
                        bookings = bookings,
                        flightsMap = flightsMap,
                        onSelectBooking = { bookingId ->
                            currentScreen = Screen.TicketDetail(bookingId)
                        }
                    )
                }

                is Screen.Account -> {
                    AccountScreen(passengers = passengers)
                }
            }

            // HQ Admin Modal Overlay
            if (showAdminDialog) {
                SkyAdminDialog(
                    isOfflineMode = isOfflineMode,
                    onToggleOfflineMode = { viewModel.setOfflineMode(it) },
                    onInjectDisruption = { flightNo, delayMins, newGate ->
                        viewModel.injectDisruption(flightNo, delayMins, newGate)
                    },
                    onUpdateGate = { flightNo, gate ->
                        viewModel.updateGate(flightNo, gate)
                    },
                    onSetFlightStatus = { flightNo, status ->
                        viewModel.setFlightStatus(flightNo, status)
                    },
                    onTriggerDemoFullJourney = {
                        viewModel.triggerDemo1FullJourney { pnr ->
                            currentScreen = Screen.Confirmation(pnr)
                        }
                    },
                    onTriggerDemoDisruption = {
                        viewModel.triggerDemo2Disruption()
                        currentScreen = Screen.Disruption
                    },
                    onTriggerDemoMultiPassenger = {
                        viewModel.triggerDemo3MultiPassenger { pnr ->
                            currentScreen = Screen.Confirmation(pnr)
                        }
                    },
                    onClose = { showAdminDialog = false }
                )
            }
        }
    }
}
