package com.example.data.model

enum class FareType {
    LIGHT,
    STANDARD,
    FLEX
}

data class FareOption(
    val type: FareType,
    val name: String,
    val pricePence: Int,
    val cabinBagIncluded: Boolean,
    val checkedBagWeightKg: Int,
    val seatSelectionIncluded: Boolean,
    val changesAllowed: String,
    val refundAllowed: Boolean,
    val priorityBoarding: Boolean
) {
    val priceFormatted: String
        get() = "£${pricePence / 100}"
}
