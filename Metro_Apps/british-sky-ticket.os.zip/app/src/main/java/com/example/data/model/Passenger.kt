package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "passengers")
data class Passenger(
    @PrimaryKey
    val id: String,
    val title: String = "MR",
    val firstName: String,
    val lastName: String,
    val dateOfBirth: String = "1990-05-15",
    val passportNumber: String = "",
    val nationality: String = "British",
    val contactEmail: String = "",
    val contactPhone: String = "",
    val isPrimary: Boolean = false
) {
    val fullName: String
        get() = "$title $firstName $lastName".uppercase()
}
