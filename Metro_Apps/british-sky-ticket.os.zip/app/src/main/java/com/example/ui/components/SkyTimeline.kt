package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FlightStatus
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.StatusGreen

@Composable
fun SkyTimeline(
    isCheckedIn: Boolean,
    flightStatus: FlightStatus,
    gate: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "JOURNEY PROGRESSION",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MidnightNavy,
                    letterSpacing = 1.sp
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            val steps = listOf(
                TimelineStep("Booked", isPassed = true, isCurrent = false),
                TimelineStep("Check-In", isPassed = isCheckedIn, isCurrent = !isCheckedIn),
                TimelineStep("Security", isPassed = isCheckedIn, isCurrent = isCheckedIn && flightStatus == FlightStatus.CHECK_IN_OPEN),
                TimelineStep("Gate $gate", isPassed = flightStatus == FlightStatus.BOARDING || flightStatus == FlightStatus.DEPARTED, isCurrent = flightStatus == FlightStatus.GATE_OPEN),
                TimelineStep("Airborne", isPassed = flightStatus == FlightStatus.AIRBORNE || flightStatus == FlightStatus.LANDED, isCurrent = flightStatus == FlightStatus.AIRBORNE),
                TimelineStep("Arrival", isPassed = flightStatus == FlightStatus.LANDED, isCurrent = flightStatus == FlightStatus.ARRIVING)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                steps.forEachIndexed { index, step ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        // Node Icon
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(
                                    when {
                                        step.isPassed -> StatusGreen
                                        step.isCurrent -> AviationBlue
                                        else -> Color(0xFFE2E8F0)
                                    },
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (step.isPassed) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(
                                            if (step.isCurrent) Color.White else Color.Gray,
                                            shape = CircleShape
                                        )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = step.title,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (step.isCurrent) FontWeight.Bold else FontWeight.Normal,
                                color = if (step.isCurrent) AviationBlue else MidnightNavy,
                                fontSize = 9.sp
                            )
                        )
                    }

                    if (index < steps.size - 1) {
                        HorizontalDivider(
                            modifier = Modifier
                                .weight(0.5f)
                                .padding(bottom = 16.dp),
                            color = if (steps[index + 1].isPassed) StatusGreen else Color(0xFFE2E8F0)
                        )
                    }
                }
            }
        }
    }
}

private data class TimelineStep(
    val title: String,
    val isPassed: Boolean,
    val isCurrent: Boolean
)
