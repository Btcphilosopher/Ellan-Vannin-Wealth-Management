package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Seat
import com.example.data.model.SeatType
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SoftGrey
import com.example.ui.theme.StatusGreen

@Composable
fun SkySeatMap(
    seats: List<Seat>,
    selectedSeatNumber: String?,
    onSeatSelected: (Seat) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sky_seat_map"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "AIRBUS A320neo SEAT SELECTION",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    color = MidnightNavy
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Legend Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                LegendItem("Available", SoftGrey, MidnightNavy)
                LegendItem("Selected", AviationBlue, Color.White)
                LegendItem("Occupied", Color.LightGray, Color.DarkGray)
                LegendItem("Exit Row", Color(0xFFFEF3C7), Color(0xFFD97706))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Fuselage Nose
            Surface(
                color = MidnightNavy,
                shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                modifier = Modifier
                    .width(220.dp)
                    .height(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "FRONT / COCKPIT",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    )
                }
            }

            // Aircraft Body Container
            Box(
                modifier = Modifier
                    .width(280.dp)
                    .height(380.dp)
                    .background(Color(0xFFF8FAFC))
                    .border(2.dp, MidnightNavy.copy(alpha = 0.3f))
                    .padding(vertical = 12.dp, horizontal = 8.dp)
                    .verticalScroll(rememberScrollState()),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // Column Letters
                    Row(
                        modifier = Modifier.width(260.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("A", "B", "C", "", "D", "E", "F").forEach { letter ->
                            Box(
                                modifier = Modifier.size(28.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = letter,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Seat Rows 1..24
                    val seatsByRow = seats.groupBy { it.row }
                    seatsByRow.keys.sorted().forEach { rowNum ->
                        val rowSeats = seatsByRow[rowNum] ?: emptyList()

                        Row(
                            modifier = Modifier
                                .width(260.dp)
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left side: A, B, C
                            val seatA = rowSeats.find { it.letter == "A" }
                            val seatB = rowSeats.find { it.letter == "B" }
                            val seatC = rowSeats.find { it.letter == "C" }

                            seatA?.let { SeatCell(it, selectedSeatNumber, onSeatSelected) }
                            seatB?.let { SeatCell(it, selectedSeatNumber, onSeatSelected) }
                            seatC?.let { SeatCell(it, selectedSeatNumber, onSeatSelected) }

                            // Row Number in Aisle
                            Box(
                                modifier = Modifier.size(28.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = rowNum.toString(),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color.Gray,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp
                                    )
                                )
                            }

                            // Right side: D, E, F
                            val seatD = rowSeats.find { it.letter == "D" }
                            val seatE = rowSeats.find { it.letter == "E" }
                            val seatF = rowSeats.find { it.letter == "F" }

                            seatD?.let { SeatCell(it, selectedSeatNumber, onSeatSelected) }
                            seatE?.let { SeatCell(it, selectedSeatNumber, onSeatSelected) }
                            seatF?.let { SeatCell(it, selectedSeatNumber, onSeatSelected) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SeatCell(
    seat: Seat,
    selectedSeatNumber: String?,
    onSeatSelected: (Seat) -> Unit
) {
    val isSelected = seat.number == selectedSeatNumber
    val isOccupied = seat.isOccupied

    val bgColor = when {
        isOccupied -> Color(0xFFE2E8F0)
        isSelected -> AviationBlue
        seat.type == SeatType.EXTRA_LEGROOM -> Color(0xFFE0F2FE)
        seat.type == SeatType.EXIT_ROW -> Color(0xFFFEF3C7)
        else -> Color.White
    }

    val textColor = when {
        isOccupied -> Color.Gray
        isSelected -> Color.White
        else -> MidnightNavy
    }

    val borderStroke = if (isSelected) 2.dp else 1.dp
    val borderColor = if (isSelected) AviationBlue else Color.LightGray

    Box(
        modifier = Modifier
            .size(30.dp)
            .background(bgColor, RoundedCornerShape(6.dp))
            .border(borderStroke, borderColor, RoundedCornerShape(6.dp))
            .clickable(enabled = !isOccupied) { onSeatSelected(seat) }
            .testTag("seat_${seat.number}"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = seat.letter,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                fontFamily = FontFamily.Monospace,
                color = textColor,
                fontSize = 10.sp
            )
        )
    }
}

@Composable
private fun LegendItem(label: String, bg: Color, border: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(bg, RoundedCornerShape(3.dp))
                .border(1.dp, border, RoundedCornerShape(3.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp))
    }
}
