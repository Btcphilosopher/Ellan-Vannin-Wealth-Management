package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Flight
import com.example.ui.theme.AviationBlue
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.StatusGreen

@Composable
fun FareSelectionScreen(
    flight: Flight,
    onFareSelected: (fareType: String, farePricePence: Int) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MidnightNavy)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "SELECT FARE FAMILY",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = Color.Gray)
                )
                Text(
                    text = "${flight.flightNumber} • ${flight.originCode} → ${flight.destinationCode}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MidnightNavy)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Fare Family Cards
        FareCard(
            title = "LIGHT",
            pricePence = flight.lightPricePence,
            tag = "ESSENTIAL TRAVEL",
            features = listOf(
                "1 Under-seat cabin bag included" to true,
                "20kg Checked bag allowance" to false,
                "Seat selection" to false,
                "Flight changes allowed (+ fee)" to true,
                "Refundable ticket" to false
            ),
            onSelect = { onFareSelected("LIGHT", flight.lightPricePence) }
        )

        Spacer(modifier = Modifier.height(12.dp))

        FareCard(
            title = "STANDARD",
            pricePence = flight.standardPricePence,
            tag = "MOST POPULAR",
            isPopular = true,
            features = listOf(
                "1 Cabin bag + small personal item" to true,
                "20kg Checked bag included" to true,
                "Standard seat selection included" to true,
                "Reduced flight change fee" to true,
                "Refundable ticket" to false
            ),
            onSelect = { onFareSelected("STANDARD", flight.standardPricePence) }
        )

        Spacer(modifier = Modifier.height(12.dp))

        FareCard(
            title = "FLEX",
            pricePence = flight.flexPricePence,
            tag = "FULL FLEXIBILITY",
            features = listOf(
                "1 Cabin bag + small personal item" to true,
                "20kg Checked bag included" to true,
                "Extra Legroom / Exit Row seat included" to true,
                "FREE unlimited flight changes" to true,
                "100% Refundable ticket" to true
            ),
            onSelect = { onFareSelected("FLEX", flight.flexPricePence) }
        )
    }
}

@Composable
private fun FareCard(
    title: String,
    pricePence: Int,
    tag: String,
    isPopular: Boolean = false,
    features: List<Pair<String, Boolean>>,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isPopular) 2.dp else 1.dp,
                color = if (isPopular) AviationBlue else Color(0xFFE2E8F0),
                shape = RoundedCornerShape(12.dp)
            )
            .testTag("fare_card_$title"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Surface(
                        color = if (isPopular) AviationBlue else Color(0xFFE2E8F0),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = tag,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isPopular) Color.White else MidnightNavy,
                                fontSize = 9.sp
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = MidnightNavy
                        )
                    )
                }

                Text(
                    text = "£${pricePence / 100}",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = AviationBlue
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            features.forEach { (feature, isIncluded) ->
                Row(
                    modifier = Modifier.padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isIncluded) Icons.Default.Check else Icons.Default.Close,
                        contentDescription = null,
                        tint = if (isIncluded) StatusGreen else Color.LightGray,
                        modifier = Modifier.width(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = feature,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (isIncluded) MidnightNavy else Color.Gray,
                            fontWeight = if (isIncluded) FontWeight.Medium else FontWeight.Normal
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onSelect,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isPopular) AviationBlue else MidnightNavy
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("select_fare_$title")
            ) {
                Text("SELECT $title FARE")
            }
        }
    }
}
