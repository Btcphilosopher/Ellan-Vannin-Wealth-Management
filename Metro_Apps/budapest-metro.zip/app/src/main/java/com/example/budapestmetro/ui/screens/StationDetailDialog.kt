package com.example.budapestmetro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.budapestmetro.model.Station
import com.example.budapestmetro.viewmodel.MetroViewModel

@Composable
fun StationDetailDialog(
  station: Station,
  viewModel: MetroViewModel,
  onDismiss: () -> Unit,
  onPlanFromHere: () -> Unit,
  onPlanToHere: () -> Unit
) {
  val departures by viewModel.stationDepartures.collectAsState()

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column {
          Text(station.name, fontWeight = FontWeight.Bold, fontSize = 20.sp)
          Text("Zone: ${station.zone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (station.isAccessible) {
          Icon(Icons.Default.Accessible, contentDescription = "Accessible", tint = MaterialTheme.colorScheme.primary)
        }
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth().height(350.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          station.lineIds.forEach { line ->
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = when (line) {
                "M1" -> Color(0xFFFFD400)
                "M2" -> Color(0xFFE30613)
                "M3" -> Color(0xFF00539F)
                "M4" -> Color(0xFF00A651)
                else -> MaterialTheme.colorScheme.primary
              }
            ) {
              Text(
                text = line,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                fontWeight = FontWeight.Bold,
                color = if (line == "M1") Color.Black else Color.White
              )
            }
          }
        }

        Text("Facilities & Infrastructure:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text(station.facilities.joinToString(" • "), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Text("Upcoming Departures:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
          items(departures) { dep ->
            Card(
              shape = RoundedCornerShape(8.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("To ${dep.destination}", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                Text(dep.scheduledTime, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = {
          viewModel.setOrigin(station)
          onPlanFromHere()
        }) {
          Text("Plan From Here")
        }
        Button(onClick = {
          viewModel.setDestination(station)
          onPlanToHere()
        }) {
          Text("Plan To Here")
        }
      }
    }
  )
}
