package com.example.budapestmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.budapestmetro.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: MetroViewModel) {
  val preference by viewModel.userPreference.collectAsState()

  var currentLang by remember(preference) { mutableStateOf(preference?.language ?: "en") }
  var isDark by remember(preference) { mutableStateOf(preference?.isDarkMode ?: false) }

  Scaffold(
    topBar = {
      TopAppBar(title = { Text("Preferences & Settings") })
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .background(MaterialTheme.colorScheme.background)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Language / Nyelv", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              Button(
                onClick = {
                  currentLang = "en"
                  viewModel.updateLanguage("en")
                },
                colors = ButtonDefaults.buttonColors(
                  containerColor = if (currentLang == "en") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                )
              ) {
                Text("English", color = if (currentLang == "en") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Button(
                onClick = {
                  currentLang = "hu"
                  viewModel.updateLanguage("hu")
                },
                colors = ButtonDefaults.buttonColors(
                  containerColor = if (currentLang == "hu") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                )
              ) {
                Text("Magyar", color = if (currentLang == "hu") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }

            Divider()

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("Dark Mode", fontWeight = FontWeight.Bold)
                Text("Historic deep iron theme", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Switch(
                checked = isDark,
                onCheckedChange = {
                  isDark = it
                  viewModel.updateTheme(it)
                }
              )
            }

            Divider()

            Column {
              Text("Offline Dataset Information", fontWeight = FontWeight.Bold)
              Spacer(modifier = Modifier.height(4.dp))
              Text("Version: BKK Metro 2030.1.4\nLast verified: November 2026\nStatus: Fully synced for offline routing", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      }
    }
  }
}
