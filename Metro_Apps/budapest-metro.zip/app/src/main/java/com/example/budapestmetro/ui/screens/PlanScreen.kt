package com.example.budapestmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.budapestmetro.model.Station
import com.example.budapestmetro.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanScreen(viewModel: MetroViewModel) {
  val stations by viewModel.stations.collectAsState()
  val origin by viewModel.selectedOrigin.collectAsState()
  val destination by viewModel.selectedDestination.collectAsState()
  val journeyResult by viewModel.currentJourneyResult.collectAsState()
  val isLoading by viewModel.isLoadingRoute.collectAsState()

  var showOriginPicker by remember { mutableStateOf(false) }
  var showDestPicker by remember { mutableStateOf(false) }
  var stepFreeOnly by remember { mutableStateOf(false) }
  var savedSuccess by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Journey Planner") },
        actions = {
          IconButton(onClick = { viewModel.planJourney(stepFreeOnly) }) {
            Icon(Icons.Default.Refresh, contentDescription = "Recalculate")
          }
        }
      )
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .background(MaterialTheme.colorScheme.background)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { showOriginPicker = true }
                .padding(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.MyLocation, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text("From Station", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(origin?.name ?: "Select origin", fontWeight = FontWeight.Bold, fontSize = 16.sp)
              }
              Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }

            Divider()

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { showDestPicker = true }
                .padding(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.error)
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text("To Station", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(destination?.name ?: "Select destination", fontWeight = FontWeight.Bold, fontSize = 16.sp)
              }
              Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
          }
        }
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = stepFreeOnly, onCheckedChange = { stepFreeOnly = it })
            Spacer(modifier = Modifier.width(8.dp))
            Text("Step-free accessible route only", fontWeight = FontWeight.Medium)
          }

          Button(
            onClick = { viewModel.planJourney(stepFreeOnly) },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
          ) {
            Text("Route")
          }
        }
      }

      if (isLoading) {
        item {
          Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
          }
        }
      }

      journeyResult?.let { result ->
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(
                    text = "${result.totalDurationMinutes} mins",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                  )
                  Text(
                    text = "${result.departureTime} ➔ ${result.arrivalTime} • ${result.totalTransfers} transfer(s)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                  )
                }

                IconButton(onClick = {
                  viewModel.saveCurrentJourney()
                  savedSuccess = true
                }) {
                  Icon(Icons.Default.BookmarkBorder, contentDescription = "Save Journey", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
              }

              if (savedSuccess) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Journey saved successfully!", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }

        item {
          Text("Journey Segments", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        items(result.segments) { segment ->
          Card(
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              segment.lineId?.let { lId ->
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = when (lId) {
                    "M1" -> Color(0xFFFFD400)
                    "M2" -> Color(0xFFE30613)
                    "M3" -> Color(0xFF00539F)
                    "M4" -> Color(0xFF00A651)
                    else -> MaterialTheme.colorScheme.primary
                  },
                  modifier = Modifier.size(36.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Text(lId, fontWeight = FontWeight.Bold, color = if (lId == "M1") Color.Black else Color.White)
                  }
                }
                Spacer(modifier = Modifier.width(12.dp))
              }

              Column(modifier = Modifier.weight(1f)) {
                Text(segment.instruction, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("${segment.originName} to ${segment.destName} • ${segment.durationMinutes} mins", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }
    }
  }

  if (showOriginPicker) {
    AlertDialog(
      onDismissRequest = { showOriginPicker = false },
      title = { Text("Select Origin Station") },
      text = {
        LazyColumn(modifier = Modifier.height(300.dp)) {
          items(stations) { st ->
            TextButton(
              onClick = {
                viewModel.setOrigin(st)
                showOriginPicker = false
              },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(st.name, modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Medium)
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showOriginPicker = false }) { Text("Close") }
      }
    )
  }

  if (showDestPicker) {
    AlertDialog(
      onDismissRequest = { showDestPicker = false },
      title = { Text("Select Destination Station") },
      text = {
        LazyColumn(modifier = Modifier.height(300.dp)) {
          items(stations) { st ->
            TextButton(
              onClick = {
                viewModel.setDestination(st)
                showDestPicker = false
              },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(st.name, modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Medium)
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showDestPicker = false }) { Text("Close") }
      }
    )
  }
}
