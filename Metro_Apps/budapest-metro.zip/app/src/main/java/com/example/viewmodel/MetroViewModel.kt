package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.EntityPreference
import com.example.data.MetroRepository
import com.example.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MetroViewModel(application: Application) : AndroidViewModel(application) {
  private val repository = MetroRepository(application)

  val lines: List<Line> = repository.lines
  val alerts: List<ServiceAlert> = repository.alerts
  val fareProducts: List<FareProduct> = repository.fareProducts

  private val _stations = MutableStateFlow<List<Station>>(emptyList())
  val stations: StateFlow<List<Station>> = _stations.asStateFlow()

  private val _savedJourneys = MutableStateFlow<List<SavedJourney>>(emptyList())
  val savedJourneys: StateFlow<List<SavedJourney>> = _savedJourneys.asStateFlow()

  private val _userPreference = MutableStateFlow<EntityPreference?>(null)
  val userPreference: StateFlow<EntityPreference?> = _userPreference.asStateFlow()

  private val _selectedOrigin = MutableStateFlow<Station?>(null)
  val selectedOrigin: StateFlow<Station?> = _selectedOrigin.asStateFlow()

  private val _selectedDestination = MutableStateFlow<Station?>(null)
  val selectedDestination: StateFlow<Station?> = _selectedDestination.asStateFlow()

  private val _currentJourneyResult = MutableStateFlow<JourneyResult?>(null)
  val currentJourneyResult: StateFlow<JourneyResult?> = _currentJourneyResult.asStateFlow()

  private val _selectedStationForDetail = MutableStateFlow<Station?>(null)
  val selectedStationForDetail: StateFlow<Station?> = _selectedStationForDetail.asStateFlow()

  private val _stationDepartures = MutableStateFlow<List<DepartureItem>>(emptyList())
  val stationDepartures: StateFlow<List<DepartureItem>> = _stationDepartures.asStateFlow()

  private val _isLoadingRoute = MutableStateFlow(false)
  val isLoadingRoute: StateFlow<Boolean> = _isLoadingRoute.asStateFlow()

  init {
    viewModelScope.launch {
      repository.ensureInitialized()
      repository.observeStations().collect { list ->
        _stations.value = list
        if (_selectedOrigin.value == null && list.isNotEmpty()) {
          _selectedOrigin.value = list.find { it.id == "m2_szell" } ?: list[0]
        }
        if (_selectedDestination.value == null && list.size > 1) {
          _selectedDestination.value = list.find { it.id == "m3_kalvin" } ?: list[1]
        }
      }
    }
    viewModelScope.launch {
      repository.observeSavedJourneys().collect { list ->
        _savedJourneys.value = list
      }
    }
    viewModelScope.launch {
      repository.observePreference().collect { pref ->
        _userPreference.value = pref
      }
    }
  }

  fun setOrigin(station: Station) {
    _selectedOrigin.value = station
  }

  fun setDestination(station: Station) {
    _selectedDestination.value = station
  }

  fun selectStationForDetail(station: Station?) {
    _selectedStationForDetail.value = station
    if (station != null) {
      viewModelScope.launch {
        _stationDepartures.value = repository.getDepartures(station.id)
      }
    }
  }

  fun planJourney(stepFree: Boolean) {
    val orig = _selectedOrigin.value ?: return
    val dest = _selectedDestination.value ?: return
    viewModelScope.launch {
      _isLoadingRoute.value = true
      val res = repository.calculateRoute(orig.id, dest.id, stepFree)
      _currentJourneyResult.value = res
      _isLoadingRoute.value = false
    }
  }

  fun saveCurrentJourney() {
    val res = _currentJourneyResult.value ?: return
    val orig = _selectedOrigin.value ?: return
    val dest = _selectedDestination.value ?: return
    viewModelScope.launch {
      repository.saveJourney(orig.id, orig.name, dest.id, dest.name)
    }
  }

  fun deleteSavedJourney(id: String) {
    viewModelScope.launch {
      repository.deleteSavedJourney(id)
    }
  }

  fun updateLanguage(lang: String) {
    val current = _userPreference.value ?: return
    viewModelScope.launch {
      repository.updatePreference(current.copy(language = lang))
    }
  }

  fun updateTheme(isDark: Boolean) {
    val current = _userPreference.value ?: return
    viewModelScope.launch {
      repository.updatePreference(current.copy(isDarkMode = isDark))
    }
  }
}
