package com.example.budapestmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.budapestmetro.model.Station
import com.example.budapestmetro.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeparturesScreen(
  viewModel: MetroViewModel,
  onStationSelected: (Station) -> Unit
) {
  val stations by viewModel.stations.collectAsState()
  val selectedStationForDetail by viewModel.selectedStationForDetail.collectAsState()
  val departures by viewModel.stationDepartures.collectAsState()

  var selectedStationId by remember { mutableStateOf("m1_deak") }

  LaunchedEffect(selectedStationId, stations) {
    val st = stations.find { it.id == selectedStationId } ?: stations.firstOrNull()
    if (st != null) {
      viewModel.selectStationForDetail(st)
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(title = { Text("Live & Scheduled Departures") })
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .background(MaterialTheme.colorScheme.background)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Text("Select Station", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

      ScrollableTabRow(
        selectedTabIndex = stations.indexOfFirst { it.id == selectedStationId }.coerceAtLeast(0),
        edgePadding = 0.dp
      ) {
        stations.take(12).forEach { station ->
          Tab(
            selected = station.id == selectedStationId,
            onClick = { selectedStationId = station.id },
            text = { Text(station.name) }
          )
        }
      }

      selectedStationForDetail?.let { st ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(st.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text("Lines: ${st.lineIds.joinToString(", ")} • Zone: ${st.zone}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
          }
        }
      }

      Text("Upcoming Departures", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

      if (departures.isEmpty()) {
        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
          CircularProgressIndicator()
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          items(departures) { dep ->
            Card(
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth(),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (dep.lineId) {
                      "M1" -> Color(0xFFFFD400)
                      "M2" -> Color(0xFFE30613)
                      "M3" -> Color(0xFF00539F)
                      "M4" -> Color(0xFF00A651)
                      else -> MaterialTheme.colorScheme.primary
                    },
                    modifier = Modifier.size(36.dp)
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Text(dep.lineCode, fontWeight = FontWeight.Bold, color = if (dep.lineId == "M1") Color.Black else Color.White)
                    }
                  }
                  Spacer(modifier = Modifier.width(12.dp))
                  Column {
                    Text("To ${dep.destination}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(dep.platform, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text(dep.scheduledTime, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                  Badge(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                    Text("On time", fontSize = 10.sp, modifier = Modifier.padding(3.dp))
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
