package com.example.budapestmetro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.budapestmetro.ui.screens.*
import com.example.budapestmetro.ui.theme.MyApplicationTheme
import com.example.budapestmetro.viewmodel.MetroViewModel

class MainActivity : ComponentActivity() {
  private val viewModel: MetroViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val preference by viewModel.userPreference.collectAsState()
      val darkTheme = preference?.isDarkMode ?: false

      MyApplicationTheme(darkTheme = darkTheme) {
        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route ?: "home"

        val selectedStationForDetail by viewModel.selectedStationForDetail.collectAsState()

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          bottomBar = {
            NavigationBar(
              containerColor = MaterialTheme.colorScheme.surface
            ) {
              NavigationBarItem(
                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                label = { Text("Home") },
                selected = currentRoute == "home",
                onClick = { navController.navigate("home") { popUpTo(navController.graph.findStartDestination().id) { saveState = true } ; launchSingleTop = true; restoreState = true } }
              )
              NavigationBarItem(
                icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                label = { Text("Map") },
                selected = currentRoute == "map",
                onClick = { navController.navigate("map") { popUpTo(navController.graph.findStartDestination().id) { saveState = true } ; launchSingleTop = true; restoreState = true } }
              )
              NavigationBarItem(
                icon = { Icon(Icons.Default.Route, contentDescription = "Plan") },
                label = { Text("Plan") },
                selected = currentRoute == "plan",
                onClick = { navController.navigate("plan") { popUpTo(navController.graph.findStartDestination().id) { saveState = true } ; launchSingleTop = true; restoreState = true } }
              )
              NavigationBarItem(
                icon = { Icon(Icons.Default.Schedule, contentDescription = "Departures") },
                label = { Text("Departures") },
                selected = currentRoute == "departures",
                onClick = { navController.navigate("departures") { popUpTo(navController.graph.findStartDestination().id) { saveState = true } ; launchSingleTop = true; restoreState = true } }
              )
              NavigationBarItem(
                icon = { Icon(Icons.Default.Bookmark, contentDescription = "Saved") },
                label = { Text("Saved") },
                selected = currentRoute == "saved",
                onClick = { navController.navigate("saved") { popUpTo(navController.graph.findStartDestination().id) { saveState = true } ; launchSingleTop = true; restoreState = true } }
              )
            }
          }
        ) { innerPadding ->
          NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
          ) {
            composable("home") {
              HomeScreen(
                viewModel = viewModel,
                onNavigateToMap = { navController.navigate("map") },
                onNavigateToPlan = { navController.navigate("plan") },
                onStationSelected = { station -> viewModel.selectStationForDetail(station) }
              )
            }
            composable("map") {
              MapScreen(
                viewModel = viewModel,
                onStationSelected = { station -> viewModel.selectStationForDetail(station) }
              )
            }
            composable("plan") {
              PlanScreen(viewModel = viewModel)
            }
            composable("departures") {
              DeparturesScreen(
                viewModel = viewModel,
                onStationSelected = { station -> viewModel.selectStationForDetail(station) }
              )
            }
            composable("saved") {
              SavedScreen(
                viewModel = viewModel,
                onNavigateToPlan = { navController.navigate("plan") }
              )
            }
            composable("tickets") {
              TicketsScreen(viewModel = viewModel)
            }
            composable("settings") {
              SettingsScreen(viewModel = viewModel)
            }
          }

          // Station Detail Dialog modal
          selectedStationForDetail?.let { station ->
            StationDetailDialog(
              station = station,
              viewModel = viewModel,
              onDismiss = { viewModel.selectStationForDetail(null) },
              onPlanFromHere = {
                viewModel.selectStationForDetail(null)
                navController.navigate("plan")
              },
              onPlanToHere = {
                viewModel.selectStationForDetail(null)
                navController.navigate("plan")
              }
            )
          }
        }
      }
    }
  }
}
