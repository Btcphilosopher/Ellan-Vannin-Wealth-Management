package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class EntityStation(
  @PrimaryKey val id: String,
  val name: String,
  val lineIdsCsv: String,
  val latitude: Double,
  val longitude: Double,
  val isAccessible: Boolean,
  val facilitiesCsv: String,
  val entrancesCsv: String,
  val zone: String
)

@Entity(tableName = "saved_journeys")
data class EntitySavedJourney(
  @PrimaryKey val id: String,
  val originId: String,
  val originName: String,
  val destId: String,
  val destName: String,
  val createdAt: Long
)

@Entity(tableName = "user_preferences")
data class EntityPreference(
  @PrimaryKey val id: Int = 1,
  val homeStationId: String,
  val workStationId: String,
  val walkingSpeed: String,
  val language: String,
  val isDarkMode: Boolean,
  val notificationsEnabled: Boolean
)
