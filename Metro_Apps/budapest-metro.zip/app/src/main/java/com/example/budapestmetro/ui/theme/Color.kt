package com.example.budapestmetro.ui.theme

import androidx.compose.ui.graphics.Color

val IvoryBackground = Color(0xFFFBF9F5)
val IvorySurface = Color(0xFFF3EFEA)
val SageGreen = Color(0xFF364D40)
val SageGreenLight = Color(0xFF4A6B5D)
val SageContainer = Color(0xFFD4E2D8)
val CharcoalText = Color(0xFF1D201E)
val CharcoalMuted = Color(0xFF5A635E)
val BrassAccent = Color(0xFFC5A880)
val BrassDark = Color(0xFF9E835E)

val M1Yellow = Color(0xFFFFD400)
val M2Red = Color(0xFFE30613)
val M3Blue = Color(0xFF00539F)
val M4Green = Color(0xFF00A651)

val DarkBackground = Color(0xFF121614)
val DarkSurface = Color(0xFF1A211D)
val DarkPrimary = Color(0xFF8BAE9B)
val DarkOnPrimary = Color(0xFF112217)
