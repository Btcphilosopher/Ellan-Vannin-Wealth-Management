package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Station
import com.example.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  viewModel: MetroViewModel,
  onNavigateToMap: () -> Unit,
  onNavigateToPlan: () -> Unit,
  onStationSelected: (Station) -> Unit
) {
  val stations by viewModel.stations.collectAsState()
  val savedJourneys by viewModel.savedJourneys.collectAsState()
  val alerts = viewModel.alerts
  var searchQuery by remember { mutableStateOf("") }

  val filteredStations = remember(searchQuery, stations) {
    if (searchQuery.isBlank()) stations.take(6)
    else stations.filter { it.name.contains(searchQuery, ignoreCase = true) || it.lineIds.any { l -> l.contains(searchQuery, ignoreCase = true) } }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header & Data Status
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "Budapest Metro",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
              Text(
                text = "M1, M2, M3, M4 Official Network",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
              )
            }
            Badge(containerColor = MaterialTheme.colorScheme.secondary) {
              Text("LIVE / OFFLINE", color = MaterialTheme.colorScheme.onSecondary, modifier = Modifier.padding(4.dp))
            }
          }
          Spacer(modifier = Modifier.height(12.dp))
          Button(
            onClick = onNavigateToPlan,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(Icons.Default.Route, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Plan a Journey")
          }
        }
      }
    }

    // Search Bar
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search station (e.g., Deák Ferenc tér)...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Clear, contentDescription = null)
            }
          }
        },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        singleLine = true
      )
    }

    // Service Alerts Banner
    if (alerts.isNotEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = alerts[0].title,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onErrorContainer,
                fontSize = 14.sp
              )
              Text(
                text = alerts[0].description,
                color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f),
                fontSize = 12.sp
              )
            }
          }
        }
      }
    }

    // Quick Actions / Map Card
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Card(
          modifier = Modifier
            .weight(1f)
            .clickable { onNavigateToMap() },
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(Icons.Default.Map, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text("Interactive Map", fontWeight = FontWeight.SemiBold)
          }
        }
        Card(
          modifier = Modifier
            .weight(1f)
            .clickable { onNavigateToPlan() },
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text("Timetables & Planner", fontWeight = FontWeight.SemiBold)
          }
        }
      }
    }

    // Saved / Recent Journeys
    if (savedJourneys.isNotEmpty()) {
      item {
        Text("Saved Journeys", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      }
      items(savedJourneys.take(3)) { j ->
        Card(
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigateToPlan() },
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("${j.originName} ➔ ${j.destName}", fontWeight = FontWeight.Medium)
              Text("Saved route", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null)
          }
        }
      }
    }

    // Stations List Header
    item {
      Text(
        text = if (searchQuery.isBlank()) "Nearby & Major Stations" else "Search Results",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    items(filteredStations) { station ->
      Card(
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onStationSelected(station) },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(station.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              station.lineIds.forEach { line ->
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = when (line) {
                    "M1" -> Color(0xFFFFD400)
                    "M2" -> Color(0xFFE30613)
                    "M3" -> Color(0xFF00539F)
                    "M4" -> Color(0xFF00A651)
                    else -> MaterialTheme.colorScheme.primary
                  }
                ) {
                  Text(
                    text = line,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (line == "M1") Color.Black else Color.White
                  )
                }
              }
            }
          }
          if (station.isAccessible) {
            Icon(Icons.Default.Accessible, contentDescription = "Accessible", tint = MaterialTheme.colorScheme.primary)
          }
        }
      }
    }
  }
}
