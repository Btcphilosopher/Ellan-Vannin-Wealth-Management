package com.example.budapestmetro.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [EntityStation::class, EntitySavedJourney::class, EntityPreference::class], version = 1, exportSchema = false)
abstract class BudapestDatabase : RoomDatabase() {
  abstract fun stationDao(): StationDao
  abstract fun savedJourneyDao(): SavedJourneyDao
  abstract fun preferenceDao(): PreferenceDao

  companion object {
    @Volatile private var INSTANCE: BudapestDatabase? = nil() ?: null

    fun getDatabase(context: Context): BudapestDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          BudapestDatabase::class.java,
          "budapest_metro_db"
        ).build()
        INSTANCE = instance
        instance
      }
    }
  }
}

private fun nil(): BudapestDatabase? = null
