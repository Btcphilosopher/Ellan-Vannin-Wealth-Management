package com.example.budapestmetro.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.budapestmetro.model.Station
import com.example.budapestmetro.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
  viewModel: MetroViewModel,
  onStationSelected: (Station) -> Unit
) {
  val stations by viewModel.stations.collectAsState()
  var isListView by remember { mutableStateOf(false) }
  var selectedLineFilter by remember { mutableStateOf("ALL") }

  var zoom by remember { mutableStateOf(1f) }
  var offset by remember { mutableStateOf(Offset.Zero) }

  val filteredStations = remember(selectedLineFilter, stations) {
    if (selectedLineFilter == "ALL") stations
    else stations.filter { it.lineIds.contains(selectedLineFilter) }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Budapest Metro Network Map") },
        actions = {
          IconButton(onClick = { isListView = !isListView }) {
            Icon(if (isListView) Icons.Default.Map else Icons.Default.List, contentDescription = "Toggle View")
          }
        }
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .background(MaterialTheme.colorScheme.background)
    ) {
      ScrollableTabRow(
        selectedTabIndex = when (selectedLineFilter) {
          "ALL" -> 0
          "M1" -> 1
          "M2" -> 2
          "M3" -> 3
          "M4" -> 4
          else -> 0
        },
        edgePadding = 16.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Tab(selected = selectedLineFilter == "ALL", onClick = { selectedLineFilter = "ALL" }) {
          Text("All Lines", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
        }
        Tab(selected = selectedLineFilter == "M1", onClick = { selectedLineFilter = "M1" }) {
          Text("M1 (Yellow)", modifier = Modifier.padding(12.dp), color = Color(0xFFC79F00), fontWeight = FontWeight.Bold)
        }
        Tab(selected = selectedLineFilter == "M2", onClick = { selectedLineFilter = "M2" }) {
          Text("M2 (Red)", modifier = Modifier.padding(12.dp), color = Color(0xFFE30613), fontWeight = FontWeight.Bold)
        }
        Tab(selected = selectedLineFilter == "M3", onClick = { selectedLineFilter = "M3" }) {
          Text("M3 (Blue)", modifier = Modifier.padding(12.dp), color = Color(0xFF00539F), fontWeight = FontWeight.Bold)
        }
        Tab(selected = selectedLineFilter == "M4", onClick = { selectedLineFilter = "M4" }) {
          Text("M4 (Green)", modifier = Modifier.padding(12.dp), color = Color(0xFF00A651), fontWeight = FontWeight.Bold)
        }
      }

      if (isListView) {
        LazyColumn(
          modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(filteredStations) { station ->
            Card(
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onStationSelected(station) }
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(station.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                  Text("Zone: ${station.zone} • Lines: ${station.lineIds.joinToString(", ")}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (station.isAccessible) {
                  Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                    Text("Step-free", modifier = Modifier.padding(4.dp), fontSize = 10.sp)
                  }
                }
              }
            }
          }
        }
      } else {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
              detectTransformGestures { _, pan, zoomChange, _ ->
                zoom = (zoom * zoomChange).coerceIn(0.8f, 4f)
                offset += pan
              }
            }
            .padding(16.dp)
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            val m1Color = Color(0xFFFFD400)
            val m2Color = Color(0xFFE30613)
            val m3Color = Color(0xFF00539F)
            val m4Color = Color(0xFF00A651)

            drawLine(
              color = m1Color,
              start = Offset(canvasWidth * 0.3f, canvasHeight * 0.4f),
              end = Offset(canvasWidth * 0.7f, canvasHeight * 0.4f),
              strokeWidth = 10f * zoom
            )
            drawLine(
              color = m2Color,
              start = Offset(canvasWidth * 0.2f, canvasHeight * 0.5f),
              end = Offset(canvasWidth * 0.8f, canvasHeight * 0.5f),
              strokeWidth = 10f * zoom
            )
            drawLine(
              color = m3Color,
              start = Offset(canvasWidth * 0.5f, canvasHeight * 0.15f),
              end = Offset(canvasWidth * 0.5f, canvasHeight * 0.85f),
              strokeWidth = 10f * zoom
            )
            drawLine(
              color = m4Color,
              start = Offset(canvasWidth * 0.3f, canvasHeight * 0.7f),
              end = Offset(canvasWidth * 0.75f, canvasHeight * 0.5f),
              strokeWidth = 10f * zoom
            )

            drawCircle(
              color = Color.Black,
              radius = 12f * zoom,
              center = Offset(canvasWidth * 0.5f + offset.x, canvasHeight * 0.5f + offset.y)
            )
            drawCircle(
              color = Color.White,
              radius = 8f * zoom,
              center = Offset(canvasWidth * 0.5f + offset.x, canvasHeight * 0.5f + offset.y)
            )
          }

          Column(
            modifier = Modifier
              .align(Alignment.BottomCenter)
              .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
            ) {
              Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Pinch to zoom, pan to explore", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Tap any station from the list view for departures & accessibility", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }
    }
  }
}
