package com.example.model

data class Station(
  val id: String,
  val name: String,
  val lineIds: List<String>,
  val latitude: Double,
  val longitude: Double,
  val isAccessible: Boolean,
  val facilities: List<String>,
  val entrances: List<String>,
  val zone: String = "Budapest"
)

data class Line(
  val id: String,
  val name: String,
  val code: String,
  val colorHex: String,
  val textColorHex: String,
  val termini: String
)

data class ServiceAlert(
  val id: String,
  val title: String,
  val description: String,
  val affectedLines: List<String>,
  val severity: String,
  val publishedAt: String
)

data class FareProduct(
  val id: String,
  val name: String,
  val priceHuf: Int,
  val validity: String,
  val description: String,
  val purchaseUrl: String
)

data class SavedJourney(
  val id: String,
  val originId: String,
  val originName: String,
  val destId: String,
  val destName: String,
  val createdAt: Long = System.currentTimeMillis()
)

data class JourneySegment(
  val type: SegmentType,
  val lineId: String?,
  val lineName: String?,
  val lineColorHex: String?,
  val originName: String,
  val destName: String,
  val durationMinutes: Int,
  val stopsCount: Int,
  val instruction: String
)

enum class SegmentType {
  WALK, METRO_RIDE, TRANSFER
}

data class JourneyResult(
  val id: String,
  val originName: String,
  val destName: String,
  val totalDurationMinutes: Int,
  val totalTransfers: Int,
  val walkingTimeMinutes: Int,
  val isAccessible: Boolean,
  val departureTime: String,
  val arrivalTime: String,
  val segments: List<JourneySegment>,
  val isLive: Boolean = true
)

data class DepartureItem(
  val stationId: String,
  val stationName: String,
  val lineId: String,
  val lineCode: String,
  val lineColorHex: String,
  val destination: String,
  val platform: String,
  val scheduledTime: String,
  val predictedTime: String?,
  val delayMinutes: Int,
  val isCancelled: Boolean,
  val isLive: Boolean
)
