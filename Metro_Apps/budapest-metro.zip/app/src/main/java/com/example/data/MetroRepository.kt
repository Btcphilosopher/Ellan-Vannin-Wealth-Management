package com.example.data

import android.content.Context
import com.example.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.*

class MetroRepository(context: Context) {
  private val db = BudapestDatabase.getDatabase(context)
  private val stationDao = db.stationDao()
  private val savedJourneyDao = db.savedJourneyDao()
  private val preferenceDao = db.preferenceDao()

  val lines = listOf(
    Line("M1", "Millennium Underground", "M1", "#FFD400", "#1D201E", "Vörösmarty tér ⟷ Mexikói út"),
    Line("M2", "East-West Metro", "M2", "#E30613", "#FFFFFF", "Déli pályaudvar ⟷ Örs vezér tere"),
    Line("M3", "North-South Metro", "M3", "#00539F", "#FFFFFF", "Kőbánya-Kispest ⟷ Újpest-központ"),
    Line("M4", "Green Metro Line", "M4", "#00A651", "#FFFFFF", "Kelenföld vasútállomás ⟷ Keleti pályaudvar")
  )

  val seedStations = listOf(
    // M1 Stations
    EntityStation("m1_vorosmarty", "Vörösmarty tér", "M1", 47.4979, 19.0503, false, "Ticket machine, Customer center", "Vörösmarty tér exit", "Central"),
    EntityStation("m1_deak", "Deák Ferenc tér", "M1,M2,M3", 47.4975, 19.0540, true, "Lifts, Escalators, Customer Service, BKK Hub", "Deák tér, Erzsébet tér", "Central"),
    EntityStation("m1_bajcsy", "Bajcsy-Zsilinszky út", "M1", 47.4996, 19.0545, false, "Ticket machine", "Andrássy út exit", "Central"),
    EntityStation("m1_oktogon", "Oktogon", "M1", 47.5034, 19.0630, false, "Tram 4-6 interchange, Ticket machine", "Nagymező utca, Teréz körút", "Central"),
    EntityStation("m1_vorosmartyu", "Vörösmarty utca", "M1", 47.5065, 19.0690, false, "Ticket machine", "Izabella utca exit", "Central"),
    EntityStation("m1_kodaly", "Kodály körönd", "M1", 47.5097, 19.0735, false, "Historic statuary station", "Andrássy út exit", "Central"),
    EntityStation("m1_bajza", "Bajza utca", "M1", 47.5123, 19.0768, false, "Ticket machine", "Bajza utca exit", "Central"),
    EntityStation("m1_hosok", "Hősök tere", "M1", 47.5152, 19.0784, false, "Museum of Fine Arts, City Park", "Heroes' Square exit", "Central"),
    EntityStation("m1_szechenyi", "Széchenyi fürdő", "M1", 47.5185, 19.0825, true, "Thermal baths access, Lift", "Zoo and Baths exit", "Central"),
    EntityStation("m1_mexikoi", "Mexikói út", "M1", 47.5221, 19.0880, true, "Bus and tram terminal, Lift", "Mexikói út surface", "Central"),

    // M2 Stations
    EntityStation("m2_deli", "Déli pályaudvar", "M2", 47.4977, 19.0234, true, "Railway station, Lifts, Ticket office", "Alkotás utca, Krisztina körút", "Central"),
    EntityStation("m2_szell", "Széll Kálmán tér", "M2", 47.5085, 19.0270, true, "Bus hub, Mammut mall, Lifts", "Széll Kálmán tér exits", "Central"),
    EntityStation("m2_batthyany", "Batthyány tér", "M2", 47.5074, 19.0416, true, "Danube view, HÉV interchange, Lift", "Fő utca exit", "Central"),
    EntityStation("m2_kossuth", "Kossuth Lajos tér", "M2", 47.5076, 19.0478, true, "Hungarian Parliament, Lift", "Parliament exit", "Central"),
    EntityStation("m2_astoria", "Astoria", "M2", 47.4939, 19.0592, false, "Rákóczi út hub, University nearby", "Károly körút exit", "Central"),
    EntityStation("m2_blaha", "Blaha Lujza tér", "M2", 47.4984, 19.0714, true, "Tram 4-6 interchange, Lifts", "Rákóczi út, Nagykörút", "Central"),
    EntityStation("m2_keleti", "Keleti pályaudvar", "M2,M4", 47.5002, 19.0828, true, "International railway, Lifts, Customer center", "Baross tér exits", "Central"),
    EntityStation("m2_puskas", "Puskás Ferenc Stadion", "M2", 47.5015, 19.0983, true, "Arena Budapest, Bus station, Lift", "Kerepesi út exit", "Central"),
    EntityStation("m2_pillango", "Pillangó utca", "M2", 47.5032, 19.1132, false, "Surface station, Ticket machines", "Pillangó utca exit", "Central"),
    EntityStation("m2_ors", "Örs vezér tere", "M2", 47.5016, 19.1352, true, "Árkád mall, HÉV Gödöllő line, Lifts", "Örs vezér tere plaza", "Central"),

    // M3 Stations
    EntityStation("m3_ujpest_kozpont", "Újpest-központ", "M3", 47.5612, 19.0924, true, "Bus terminal, Lifts", "Árpád út exit", "Northern"),
    EntityStation("m3_ujpest_varoskapu", "Újpest-városkapu", "M3", 47.5540, 19.0905, true, "Intercity bus station, Train station, Lifts", "Váci út exit", "Northern"),
    EntityStation("m3_gyongyosi", "Gyöngyösi utca", "M3", 47.5458, 19.0872, true, "Duna Plaza, Lift", "Váci út exit", "Northern"),
    EntityStation("m3_forgach", "Forgách utca", "M3", 47.5385, 19.0838, true, "Office district, Lift", "Váci út exit", "Northern"),
    EntityStation("m3_goncz", "Göncz Árpád városközpont", "M3", 47.5312, 19.0805, true, "Tram hub, Bus station, Lifts", "Róbert Károly körút", "Central"),
    EntityStation("m3_dozsa", "Dózsa György út", "M3", 47.5235, 19.0762, false, "Lehel csarnok nearby", "Váci út exit", "Central"),
    EntityStation("m3_lehel", "Lehel tér", "M3", 47.5178, 19.0632, true, "Market hall, Lifts", "Váci út exit", "Central"),
    EntityStation("m3_nyugati", "Nyugati pályaudvar", "M3", 47.5082, 19.0560, true, "Railway station, WestEnd mall, Lifts", "Nyugati tér exits", "Central"),
    EntityStation("m3_arany", "Arany János utca", "M3", 47.5015, 19.0538, false, "Bajcsy-Zsilinszky út", "Bajcsy-Zsilinszky út", "Central"),
    EntityStation("m3_ferenciek", "Ferenciek tere", "M3", 47.4925, 19.0558, true, "Erzsébet bridge, Lifts", "Kossuth Lajos utca", "Central"),
    EntityStation("m3_kalvin", "Kálvin tér", "M3,M4", 47.4888, 19.0583, true, "Museum boulevard, Lifts, Interchange", "Üllői út, Kálvin tér", "Central"),
    EntityStation("m3_corvin", "Corvin-negyed", "M3", 47.4852, 19.0664, true, "Corvin Plaza, Cinema, Lifts", "Üllői út / Grand Boulevard", "Central"),
    EntityStation("m3_semmelweis", "Semmelweis Klinikák", "M3", 47.4812, 19.0725, true, "Medical university hospital, Lifts", "Üllői út exit", "Central"),
    EntityStation("m3_nagyvarad", "Nagyvárad tér", "M3", 47.4765, 19.0792, true, "Groupama Arena, Medical complex, Lifts", "Üllői út exit", "Southern"),
    EntityStation("m3_nepliget", "Népliget", "M3", 47.4721, 19.0910, true, "International bus terminal, Park, Lifts", "Könyves Kálmán körút", "Southern"),
    EntityStation("m3_ecseri", "Ecseri út", "M3", 47.4705, 19.1032, false, "Üllői út surface", "Ecseri út exit", "Southern"),
    EntityStation("m3_pottyos", "Pöttyös utca", "M3", 47.4682, 19.1102, false, "Residential area", "Pöttyös utca exit", "Southern"),
    EntityStation("m3_hatar", "Határ út", "M3", 47.4632, 19.1175, true, "Shopping center, Bus hub, Lift", "Határ út exit", "Southern"),
    EntityStation("m3_kobanya", "Kőbánya-Kispest", "M3", 47.4582, 19.1465, true, "Railway station, KöKi Terminal mall, Lifts", "KÖKI terminal plaza", "Southern"),

    // M4 Stations
    EntityStation("m4_kelenfold", "Kelenföld vasútállomás", "M4", 47.4645, 19.0195, true, "Railway hub, P+R, Lifts, Terminal", "Etele tér exit", "Southern"),
    EntityStation("m4_bikas", "Bikas park", "M4", 47.4735, 19.0305, true, "Park, Tram interchange, Lifts", "Tétényi út exit", "Southern"),
    EntityStation("m4_ujbuda", "Újbuda-központ", "M4", 47.4782, 19.0382, true, "Allee shopping mall, Lifts", "Bártfai utca exit", "Southern"),
    EntityStation("m4_moricz", "Móricz Zsigmond körtér", "M4", 47.4815, 19.0435, true, "Tram hub, University area, Lifts", "Villányi út exit", "Central"),
    EntityStation("m4_szent_gellert", "Szent Gellért tér - Műegyetem", "M4", 47.4835, 19.0522, true, "Technical University, Danubius Hotel, Lifts", "Műegyetem rakpart", "Central"),
    EntityStation("m4_fovam", "Fővám tér", "M4", 47.4862, 19.0555, true, "Great Market Hall, Corvinus University, Lifts", "Vámház körút", "Central"),
    EntityStation("m4_rakoczi", "Rákóczi tér", "M4", 47.4912, 19.0665, true, "Market hall, Lifts", "Rákóczi tér", "Central"),
    EntityStation("m4_janos", "II. János Pál pápa tér", "M4", 47.4952, 19.0765, true, "Park, Lifts", "Népszínház utca", "Central")
  )

  val alerts = listOf(
    ServiceAlert(
      "alt_1",
      "Scheduled Maintenance on M3",
      "Buses replace metro between Lehel tér and Újpest-központ during late night hours for track upkeep.",
      listOf("M3"),
      "INFO",
      "Today, 22:00"
    ),
    ServiceAlert(
      "alt_2",
      "Elevator Modernization at Deák Ferenc tér",
      "The elevator connecting M1 and M2 platforms is undergoing scheduled safety certification. Accessible interchange via surface level available.",
      listOf("M1", "M2", "M3"),
      "WARNING",
      "Ongoing"
    )
  )

  val fareProducts = listOf(
    FareProduct(
      "ticket_single",
      "Single Ticket (Vonaljegy)",
      450,
      "Single journey with continuous travel, max 90 minutes.",
      "Standard paper or digital single ticket. Must be validated immediately upon boarding.",
      "https://bkk.hu/jegyek-es-berletek/vonaljegyek/vonaljegy-450-ft.html"
    ),
    FareProduct(
      "ticket_24h",
      "Budapest 24-hour Travelcard",
      2500,
      "Valid for 24 hours from indicated start time across all BKK lines.",
      "Unlimited travel within Budapest administrative boundaries.",
      "https://bkk.hu/jegyek-es-berletek/budapesti-24-oras-jegy.html"
    ),
    FareProduct(
      "ticket_72h",
      "Budapest 72-hour Travelcard",
      5500,
      "Valid for 72 hours across Budapest.",
      "Ideal for weekend visitors exploring all metro lines and landmarks.",
      "https://bkk.hu/jegyek-es-berletek/budapesti-72-oras-jegy.html"
    ),
    FareProduct(
      "ticket_monthly",
      "Budapest Monthly Pass (Havijegy)",
      9500,
      "Valid for 30 consecutive calendar days.",
      "Requires ID card number or BudapestGO account linkage.",
      "https://bkk.hu/jegyek-es-berletek/budapesti-havi-berlet.html"
    )
  )

  suspend fun ensureInitialized() {
    if (stationDao.getAllStations().isEmpty()) {
      stationDao.insertStations(seedStations)
    }
    if (preferenceDao.getPreference() == null) {
      preferenceDao.insertPreference(
        EntityPreference(
          id = 1,
          homeStationId = "m2_szell",
          workStationId = "m3_kalvin",
          walkingSpeed = "NORMAL",
          language = "en",
          isDarkMode = false,
          notificationsEnabled = true
        )
      )
    }
  }

  fun observeStations(): Flow<List<Station>> {
    return stationDao.observeStations().map { entities ->
      entities.map { e ->
        Station(
          id = e.id,
          name = e.name,
          lineIds = e.lineIdsCsv.split(",").map { it.trim() },
          latitude = e.latitude,
          longitude = e.longitude,
          isAccessible = e.isAccessible,
          facilities = e.facilitiesCsv.split(",").map { it.trim() },
          entrances = e.entrancesCsv.split(",").map { it.trim() },
          zone = e.zone
        )
      }
    }
  }

  fun observeSavedJourneys(): Flow<List<SavedJourney>> {
    return savedJourneyDao.observeSavedJourneys().map { list ->
      list.map {
        SavedJourney(it.id, it.originId, it.originName, it.destId, it.destName, it.createdAt)
      }
    }
  }

  suspend fun saveJourney(originId: String, originName: String, destId: String, destName: String) {
    val id = "j_${System.currentTimeMillis()}"
    savedJourneyDao.insertJourney(EntitySavedJourney(id, originId, originName, destId, destName, System.currentTimeMillis()))
  }

  suspend fun deleteSavedJourney(id: String) {
    savedJourneyDao.deleteJourney(id)
  }

  fun observePreference(): Flow<EntityPreference?> {
    return preferenceDao.observePreference()
  }

  suspend fun updatePreference(pref: EntityPreference) {
    preferenceDao.insertPreference(pref)
  }

  suspend fun calculateRoute(originId: String, destId: String, stepFree: Boolean): JourneyResult? {
    val stations = stationDao.getAllStations()
    val orig = stations.find { it.id == originId } ?: return null
    val dest = stations.find { it.id == destId } ?: return null

    if (orig.id == dest.id) return null

    val origLines = orig.lineIdsCsv.split(",").map { it.trim() }
    val destLines = dest.lineIdsCsv.split(",").map { it.trim() }

    val commonLine = origLines.find { destLines.contains(it) }

    val segments = mutableListOf<JourneySegment>()
    val now = Calendar.getInstance()
    val depFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    val depTimeStr = depFormat.format(now.time)
    now.add(Calendar.MINUTE, 22)
    val arrTimeStr = depFormat.format(now.time)

    if (commonLine != null) {
      val lineObj = lines.find { it.id == commonLine }
      segments.add(
        JourneySegment(
          type = SegmentType.METRO_RIDE,
          lineId = commonLine,
          lineName = lineObj?.name ?: commonLine,
          lineColorHex = lineObj?.colorHex ?: "#364D40",
          originName = orig.name,
          destName = dest.name,
          durationMinutes = 14,
          stopsCount = 5,
          instruction = "Board line $commonLine towards ${lineObj?.termini ?: ""}"
        )
      )
      return JourneyResult(
        id = "route_${System.currentTimeMillis()}",
        originName = orig.name,
        destName = dest.name,
        totalDurationMinutes = 18,
        totalTransfers = 0,
        walkingTimeMinutes = 4,
        isAccessible = orig.isAccessible && dest.isAccessible,
        departureTime = depTimeStr,
        arrivalTime = arrTimeStr,
        segments = segments,
        isLive = true
      )
    } else {
      val hub = stations.find { it.id == "m1_deak" }!!
      val firstLine = origLines.firstOrNull() ?: "M2"
      val secondLine = destLines.firstOrNull() ?: "M3"
      val line1Obj = lines.find { it.id == firstLine }
      val line2Obj = lines.find { it.id == secondLine }

      segments.add(
        JourneySegment(
          type = SegmentType.METRO_RIDE,
          lineId = firstLine,
          lineName = line1Obj?.name ?: firstLine,
          lineColorHex = line1Obj?.colorHex ?: "#364D40",
          originName = orig.name,
          destName = hub.name,
          durationMinutes = 8,
          stopsCount = 3,
          instruction = "Board line $firstLine at ${orig.name}"
        )
      )
      segments.add(
        JourneySegment(
          type = SegmentType.TRANSFER,
          lineId = null,
          lineName = "Interchange",
          lineColorHex = "#C5A880",
          originName = hub.name,
          destName = hub.name,
          durationMinutes = 3,
          stopsCount = 0,
          instruction = "Transfer at ${hub.name}"
        )
      )
      segments.add(
        JourneySegment(
          type = SegmentType.METRO_RIDE,
          lineId = secondLine,
          lineName = line2Obj?.name ?: secondLine,
          lineColorHex = line2Obj?.colorHex ?: "#00539F",
          originName = hub.name,
          destName = dest.name,
          durationMinutes = 10,
          stopsCount = 4,
          instruction = "Board line $secondLine towards ${line2Obj?.termini ?: ""}"
        )
      )

      return JourneyResult(
        id = "route_${System.currentTimeMillis()}",
        originName = orig.name,
        destName = dest.name,
        totalDurationMinutes = 25,
        totalTransfers = 1,
        walkingTimeMinutes = 4,
        isAccessible = orig.isAccessible && dest.isAccessible && hub.isAccessible,
        departureTime = depTimeStr,
        arrivalTime = arrTimeStr,
        segments = segments,
        isLive = true
      )
    }
  }

  suspend fun getDepartures(stationId: String): List<DepartureItem> {
    val st = stationDao.getStationById(stationId) ?: return emptyList()
    val lineIds = st.lineIdsCsv.split(",").map { it.trim() }
    val results = mutableListOf<DepartureItem>()
    val cal = Calendar.getInstance()
    val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    for (lId in lineIds) {
      val lineObj = lines.find { it.id == lId } ?: continue
      cal.add(Calendar.MINUTE, 3)
      val sch1 = fmt.format(cal.time)
      cal.add(Calendar.MINUTE, 7)
      val sch2 = fmt.format(cal.time)

      results.add(
        DepartureItem(
          stationId = st.id,
          stationName = st.name,
          lineId = lId,
          lineCode = lineObj.code,
          lineColorHex = lineObj.colorHex,
          destination = lineObj.termini.split("⟷").last().trim(),
          platform = "Platform 1",
          scheduledTime = sch1,
          predictedTime = sch1,
          delayMinutes = 0,
          isCancelled = false,
          isLive = true
        )
      )
      results.add(
        DepartureItem(
          stationId = st.id,
          stationName = st.name,
          lineId = lId,
          lineCode = lineObj.code,
          lineColorHex = lineObj.colorHex,
          destination = lineObj.termini.split("⟷").first().trim(),
          platform = "Platform 2",
          scheduledTime = sch2,
          predictedTime = sch2,
          delayMinutes = 1,
          isCancelled = false,
          isLive = true
        )
      )
    }
    return results
  }
}
