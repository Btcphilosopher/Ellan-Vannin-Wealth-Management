package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme =
  lightColorScheme(
    primary = SageGreen,
    onPrimary = Color.White,
    primaryContainer = SageContainer,
    onPrimaryContainer = CharcoalText,
    secondary = BrassAccent,
    onSecondary = CharcoalText,
    secondaryContainer = Color(0xFFF2EADF),
    onSecondaryContainer = CharcoalText,
    background = IvoryBackground,
    onBackground = CharcoalText,
    surface = IvorySurface,
    onSurface = CharcoalText,
    error = M2Red,
    onError = Color.White,
  )

private val DarkColorScheme =
  darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = Color(0xFF26382E),
    onPrimaryContainer = Color(0xFFD4E2D8),
    secondary = BrassAccent,
    onSecondary = Color(0xFF1D201E),
    secondaryContainer = Color(0xFF332D23),
    onSecondaryContainer = Color(0xFFE6DCB8),
    background = DarkBackground,
    onBackground = Color(0xFFE2E8E4),
    surface = DarkSurface,
    onSurface = Color(0xFFE2E8E4),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Use custom Budapest Metro palette
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
