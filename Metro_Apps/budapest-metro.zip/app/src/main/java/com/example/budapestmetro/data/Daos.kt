package com.example.budapestmetro.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface StationDao {
  @Query("SELECT * FROM stations")
  suspend fun getAllStations(): List<EntityStation>

  @Query("SELECT * FROM stations")
  fun observeStations(): Flow<List<EntityStation>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertStations(stations: List<EntityStation>)

  @Query("SELECT * FROM stations WHERE id = :stationId")
  suspend fun getStationById(stationId: String): EntityStation?
}

@Dao
interface SavedJourneyDao {
  @Query("SELECT * FROM saved_journeys ORDER BY createdAt DESC")
  fun observeSavedJourneys(): Flow<List<EntitySavedJourney>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertJourney(journey: EntitySavedJourney)

  @Query("DELETE FROM saved_journeys WHERE id = :id")
  suspend fun deleteJourney(id: String)
}

@Dao
interface PreferenceDao {
  @Query("SELECT * FROM user_preferences WHERE id = 1")
  fun observePreference(): Flow<EntityPreference?>

  @Query("SELECT * FROM user_preferences WHERE id = 1")
  suspend fun getPreference(): EntityPreference?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPreference(pref: EntityPreference)
}
