package com.example.ui.map

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.design.LineBadge
import com.example.core.design.StationRow
import com.example.core.model.Station
import com.example.core.renderer.MetroMapRenderer
import com.example.ui.MainViewModel

@Composable
fun MapScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedLineId by viewModel.selectedLineId.collectAsState()
    val activeTrains by viewModel.activeTrains.collectAsState()
    var selectedStationOnMap by remember { mutableStateOf<Station?>(null) }

    val allLines = listOf("ALL", "RED", "BLUE", "BROWN", "GREEN", "ORANGE", "PINK", "PURPLE", "YELLOW")

    Box(modifier = modifier.fillMaxSize()) {
        // Render Canvas Transit Map
        MetroMapRenderer(
            selectedLineFilter = selectedLineId,
            selectedStation = selectedStationOnMap,
            onStationSelected = { selectedStationOnMap = it },
            activeTrains = activeTrains,
            modifier = Modifier.fillMaxSize()
        )

        // Top Overlay: Line Filters
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xDD0F172A)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "CHICAGO SCHEMATIC TRANSIT MAP",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(allLines) { line ->
                            val isSelected = (line == "ALL" && selectedLineId == null) || (line == selectedLineId)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    viewModel.selectLine(if (line == "ALL") "" else line)
                                },
                                label = {
                                    if (line == "ALL") Text("ALL") else LineBadge(lineId = line)
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                                ),
                                modifier = Modifier.testTag("map_filter_$line")
                            )
                        }
                    }
                }
            }
        }

        // Bottom Overlay: Station Info card when tapped
        val station = selectedStationOnMap
        if (station != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
                    .fillMaxWidth()
            ) {
                StationRow(
                    station = station,
                    onClick = { viewModel.selectStation(station) }
                )
            }
        }
    }
}
