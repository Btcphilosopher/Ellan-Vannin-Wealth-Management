package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.database.AppDatabase
import com.example.core.database.FavoriteStationEntity
import com.example.core.database.SavedCommuteEntity
import com.example.core.graph.ChicagoTransitGraph
import com.example.core.model.ElevatorStatus
import com.example.core.model.JourneyResult
import com.example.core.model.LiveDeparture
import com.example.core.model.NetworkDataState
import com.example.core.model.ServiceAlert
import com.example.core.model.Station
import com.example.core.model.VehiclePosition
import com.example.data.realtime.TransitRealtimeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppTab {
    HOME,
    MAP,
    ROUTES,
    STATIONS,
    MORE
}

enum class SecondaryScreen {
    NONE,
    STATION_DETAIL,
    LINE_DETAIL,
    TRAIN_TRACKER,
    SYSTEM_STATUS,
    AIRPORT_HUB,
    METRA_PACE,
    LOOP_EXPLORER,
    JOURNEY_MODE,
    DIGITAL_TWIN,
    COMMUTE_MODE,
    COMMAND_TERMINAL
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val realtimeRepo = TransitRealtimeRepository(viewModelScope)

    // Current tab and screen navigation
    private val _currentTab = MutableStateFlow(AppTab.HOME)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _secondaryScreen = MutableStateFlow(SecondaryScreen.NONE)
    val secondaryScreen: StateFlow<SecondaryScreen> = _secondaryScreen.asStateFlow()

    // Selected entities
    private val _selectedStation = MutableStateFlow<Station?>(ChicagoTransitGraph.STATIONS.first())
    val selectedStation: StateFlow<Station?> = _selectedStation.asStateFlow()

    private val _selectedLineId = MutableStateFlow<String?>("BLUE")
    val selectedLineId: StateFlow<String?> = _selectedLineId.asStateFlow()

    // Location (defaulted to Loop / Thompson Center Clark & Lake lat/lng)
    private val _userLat = MutableStateFlow(41.8857)
    private val _userLon = MutableStateFlow(-87.6309)

    // Search query & command mode
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _terminalCommand = MutableStateFlow("")
    val terminalCommand: StateFlow<String> = _terminalCommand.asStateFlow()

    private val _commandOutput = MutableStateFlow<String?>(null)
    val commandOutput: StateFlow<String?> = _commandOutput.asStateFlow()

    // Route Planner state
    private val _originStation = MutableStateFlow<Station>(ChicagoTransitGraph.STATIONS.find { it.id == "damen_blue" } ?: ChicagoTransitGraph.STATIONS.first())
    val originStation: StateFlow<Station> = _originStation.asStateFlow()

    private val _destStation = MutableStateFlow<Station>(ChicagoTransitGraph.STATIONS.find { it.id == "ohare" } ?: ChicagoTransitGraph.STATIONS.last())
    val destStation: StateFlow<Station> = _destStation.asStateFlow()

    private val _requireStepFree = MutableStateFlow(false)
    val requireStepFree: StateFlow<Boolean> = _requireStepFree.asStateFlow()

    private val _plannedJourney = MutableStateFlow<JourneyResult?>(null)
    val plannedJourney: StateFlow<JourneyResult?> = _plannedJourney.asStateFlow()

    // Active Journey Mode state
    private val _activeJourney = MutableStateFlow<JourneyResult?>(null)
    val activeJourney: StateFlow<JourneyResult?> = _activeJourney.asStateFlow()

    val favorites: StateFlow<List<FavoriteStationEntity>> = db.favoritesDao().getAllFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedCommutes: StateFlow<List<SavedCommuteEntity>> = db.savedCommuteDao().getAllCommutes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dataState: StateFlow<NetworkDataState> = realtimeRepo.dataState
    val systemAlerts: StateFlow<List<ServiceAlert>> = realtimeRepo.systemAlerts
    val elevatorStatuses: StateFlow<List<ElevatorStatus>> = realtimeRepo.elevatorStatuses
    val activeTrains: StateFlow<List<VehiclePosition>> = realtimeRepo.activeTrains

    val nearestStations = combine(_userLat, _userLon) { lat, lon ->
        ChicagoTransitGraph.findNearestStations(lat, lon, limit = 5)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredStations = combine(_searchQuery, _selectedLineId) { query, lineId ->
        ChicagoTransitGraph.STATIONS.filter { station ->
            val matchesQuery = query.isEmpty() ||
                    station.name.contains(query, ignoreCase = true) ||
                    station.address.contains(query, ignoreCase = true) ||
                    station.lines.any { it.contains(query, ignoreCase = true) }
            val matchesLine = lineId.isNullOrEmpty() || station.lines.contains(lineId)
            matchesQuery && matchesLine
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ChicagoTransitGraph.STATIONS)

    init {
        recalculateRoute()
    }

    fun setTab(tab: AppTab) {
        _currentTab.value = tab
        _secondaryScreen.value = SecondaryScreen.NONE
    }

    fun navigateToSecondary(screen: SecondaryScreen) {
        _secondaryScreen.value = screen
    }

    fun popSecondary() {
        _secondaryScreen.value = SecondaryScreen.NONE
    }

    fun selectStation(station: Station) {
        _selectedStation.value = station
        _secondaryScreen.value = SecondaryScreen.STATION_DETAIL
    }

    fun selectLine(lineId: String) {
        _selectedLineId.value = lineId
        _secondaryScreen.value = SecondaryScreen.LINE_DETAIL
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setRouteOrigin(station: Station) {
        _originStation.value = station
        recalculateRoute()
    }

    fun setRouteDestination(station: Station) {
        _destStation.value = station
        recalculateRoute()
    }

    fun setStepFreeAccessible(accessible: Boolean) {
        _requireStepFree.value = accessible
        recalculateRoute()
    }

    fun recalculateRoute() {
        _plannedJourney.value = ChicagoTransitGraph.planJourney(
            originId = _originStation.value.id,
            destinationId = _destStation.value.id,
            requireStepFree = _requireStepFree.value,
            activeAlerts = realtimeRepo.systemAlerts.value,
            elevatorOutages = realtimeRepo.elevatorStatuses.value
        )
    }

    fun startJourney(journey: JourneyResult) {
        _activeJourney.value = journey
        _secondaryScreen.value = SecondaryScreen.JOURNEY_MODE
    }

    fun toggleFavorite(stationId: String) {
        viewModelScope.launch {
            val isFav = db.favoritesDao().isFavorite(stationId)
            if (isFav) {
                db.favoritesDao().deleteFavorite(stationId)
            } else {
                db.favoritesDao().insertFavorite(
                    FavoriteStationEntity(stationId, null, _selectedLineId.value)
                )
            }
        }
    }

    fun executeTerminalCommand(cmd: String) {
        _terminalCommand.value = cmd
        val formatted = cmd.trim().uppercase()
        val result = when {
            formatted == "CHI <GO>" || formatted == "HOME <GO>" -> { setTab(AppTab.HOME); "Navigated to HOME" }
            formatted == "MAP <GO>" -> { setTab(AppTab.MAP); "Navigated to MAP" }
            formatted == "STATIONS <GO>" -> { setTab(AppTab.STATIONS); "Navigated to STATIONS" }
            formatted == "ROUTES <GO>" || formatted == "PLAN <GO>" -> { setTab(AppTab.ROUTES); "Navigated to ROUTE PLANNER" }
            formatted.startsWith("RED") -> { selectLine("RED"); "Selected RED LINE" }
            formatted.startsWith("BLUE") -> { selectLine("BLUE"); "Selected BLUE LINE" }
            formatted.startsWith("BROWN") -> { selectLine("BROWN"); "Selected BROWN LINE" }
            formatted.startsWith("GREEN") -> { selectLine("GREEN"); "Selected GREEN LINE" }
            formatted.startsWith("ORANGE") -> { selectLine("ORANGE"); "Selected ORANGE LINE" }
            formatted == "LOOP <GO>" -> { navigateToSecondary(SecondaryScreen.LOOP_EXPLORER); "Opened LOOP EXPLORER" }
            formatted == "AIRPORT <GO>" || formatted == "ORD <GO>" -> { navigateToSecondary(SecondaryScreen.AIRPORT_HUB); "Opened AIRPORT CONTROL CENTRE" }
            formatted == "METRA <GO>" || formatted == "PACE <GO>" -> { navigateToSecondary(SecondaryScreen.METRA_PACE); "Opened METRA & PACE NETWORK" }
            formatted == "STATUS <GO>" -> { navigateToSecondary(SecondaryScreen.SYSTEM_STATUS); "Opened SYSTEM STATUS" }
            formatted == "TRACK <GO>" -> { navigateToSecondary(SecondaryScreen.TRAIN_TRACKER); "Opened REALTIME TRAIN TRACKER" }
            formatted == "TWIN <GO>" -> { navigateToSecondary(SecondaryScreen.DIGITAL_TWIN); "Opened CHICAGO DIGITAL TWIN" }
            else -> "Command '$cmd' executed. Try: CHI <GO>, RED <GO>, LOOP <GO>, AIRPORT <GO>, STATUS <GO>"
        }
        _commandOutput.value = result
    }

    fun getStationDepartures(stationId: String): List<LiveDeparture> {
        return realtimeRepo.getDeparturesForStation(stationId)
    }
}
