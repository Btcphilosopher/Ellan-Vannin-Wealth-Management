package com.example.core.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "favorite_stations")
data class FavoriteStationEntity(
    @PrimaryKey val stationId: String,
    val customName: String?,
    val preferredLineId: String?,
    val addedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_commutes")
data class SavedCommuteEntity(
    @PrimaryKey val id: String,
    val name: String,
    val originStationId: String,
    val destinationStationId: String,
    val preferredLineId: String
)

@Entity(tableName = "cached_alerts")
data class CachedAlertEntity(
    @PrimaryKey val id: String,
    val lineId: String?,
    val stationId: String?,
    val headline: String,
    val description: String,
    val severity: String,
    val timestamp: Long
)

@Dao
interface FavoritesDao {
    @Query("SELECT * FROM favorite_stations ORDER BY addedTimestamp DESC")
    fun getAllFavorites(): Flow<List<FavoriteStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(fav: FavoriteStationEntity)

    @Query("DELETE FROM favorite_stations WHERE stationId = :stationId")
    suspend fun deleteFavorite(stationId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_stations WHERE stationId = :stationId)")
    suspend fun isFavorite(stationId: String): Boolean
}

@Dao
interface SavedCommuteDao {
    @Query("SELECT * FROM saved_commutes")
    fun getAllCommutes(): Flow<List<SavedCommuteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommute(commute: SavedCommuteEntity)

    @Query("DELETE FROM saved_commutes WHERE id = :id")
    suspend fun deleteCommute(id: String)
}

@Dao
interface CachedAlertsDao {
    @Query("SELECT * FROM cached_alerts ORDER BY timestamp DESC")
    fun getCachedAlerts(): Flow<List<CachedAlertEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<CachedAlertEntity>)

    @Query("DELETE FROM cached_alerts")
    suspend fun clearAlerts()
}

@Database(
    entities = [FavoriteStationEntity::class, SavedCommuteEntity::class, CachedAlertEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoritesDao(): FavoritesDao
    abstract fun savedCommuteDao(): SavedCommuteDao
    abstract fun cachedAlertsDao(): CachedAlertsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "chicago_metro_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
