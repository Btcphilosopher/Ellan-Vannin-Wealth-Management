package com.example.core.renderer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.core.graph.ChicagoTransitGraph
import com.example.core.model.LineColor
import com.example.core.model.Station
import com.example.core.model.VehiclePosition

/**
 * Interactive Schematic & Geographic CTA Transit Map Renderer with Jetpack Compose Canvas.
 * Supports pan, zoom, line filtering, station tap selection, and live moving train markers.
 */
@Composable
fun MetroMapRenderer(
    selectedLineFilter: String?,
    selectedStation: Station?,
    onStationSelected: (Station) -> Unit,
    activeTrains: List<VehiclePosition>,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1.0f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val textMeasurer = rememberTextMeasurer()

    // Bounding box mapping Chicago Lat/Lng to Canvas pixels
    val minLat = 41.7200
    val maxLat = 42.0400
    val minLon = -87.9100
    val maxLon = -87.6000

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.5f, 5.0f)
                    offsetX += pan.x
                    offsetY += pan.y
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            fun latLngToPixel(lat: Double, lon: Double): Offset {
                val xNorm = ((lon - minLon) / (maxLon - minLon)).toFloat()
                val yNorm = (1f - ((lat - minLat) / (maxLat - minLat))).toFloat()
                return Offset(xNorm * width, yNorm * height)
            }

            translate(left = offsetX, top = offsetY) {
                scale(scale, pivot = Offset(width / 2f, height / 2f)) {

                    // 1. Draw Lake Michigan background water feature on right
                    val lakePath = Path().apply {
                        val p1 = latLngToPixel(42.04, -87.66)
                        val p2 = latLngToPixel(41.88, -87.61)
                        val p3 = latLngToPixel(41.72, -87.58)
                        moveTo(p1.x, p1.y)
                        lineTo(p2.x, p2.y)
                        lineTo(p3.x, p3.y)
                        lineTo(width, height)
                        lineTo(width, 0f)
                        close()
                    }
                    drawPath(
                        path = lakePath,
                        color = Color(0xFF0F2238) // Deep Chicago Lake Michigan dark blue
                    )

                    // 2. Draw CTA Transit Lines
                    val linesToDraw = if (selectedLineFilter.isNullOrEmpty()) {
                        listOf("RED", "BLUE", "BROWN", "GREEN", "ORANGE", "PINK", "PURPLE", "YELLOW")
                    } else {
                        listOf(selectedLineFilter)
                    }

                    linesToDraw.forEach { lineId ->
                        val lineColorHex = LineColor.fromId(lineId).hex
                        val color = Color(android.graphics.Color.parseColor(lineColorHex))

                        val stationsForLine = ChicagoTransitGraph.STATIONS.filter { it.lines.contains(lineId) }
                        if (stationsForLine.size >= 2) {
                            val linePath = Path()
                            val firstPixel = latLngToPixel(stationsForLine.first().latitude, stationsForLine.first().longitude)
                            linePath.moveTo(firstPixel.x, firstPixel.y)

                            for (i in 1 until stationsForLine.size) {
                                val pix = latLngToPixel(stationsForLine[i].latitude, stationsForLine[i].longitude)
                                linePath.lineTo(pix.x, pix.y)
                            }

                            drawPath(
                                path = linePath,
                                color = color,
                                style = Stroke(
                                    width = 8f / scale.coerceAtLeast(0.8f),
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                            )
                        }
                    }

                    // 3. Draw Stations
                    ChicagoTransitGraph.STATIONS.forEach { station ->
                        val pos = latLngToPixel(station.latitude, station.longitude)
                        val isSelected = selectedStation?.id == station.id

                        val radius = if (isSelected) 10f else if (station.isLoopStation) 7f else 5f
                        val stationColor = if (isSelected) Color(0xFFFFD700) else Color.White

                        drawCircle(
                            color = Color.Black,
                            radius = (radius + 3f) / scale.coerceAtLeast(0.8f),
                            center = pos
                        )
                        drawCircle(
                            color = stationColor,
                            radius = radius / scale.coerceAtLeast(0.8f),
                            center = pos
                        )

                        // Station name label at higher zoom level or selected
                        if (scale >= 1.8f || isSelected || station.isLoopStation || station.id == "ohare" || station.id == "midway") {
                            drawText(
                                textMeasurer = textMeasurer,
                                text = station.name.take(18),
                                topLeft = Offset(pos.x + 8f, pos.y - 12f),
                                style = TextStyle(
                                    color = Color.White,
                                    fontSize = (10f / scale.coerceAtLeast(1f)).sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        }
                    }

                    // 4. Draw Active Moving Train Markers
                    activeTrains.forEach { train ->
                        val trainPos = latLngToPixel(train.latitude, train.longitude)
                        val lineHex = LineColor.fromId(train.routeId).hex
                        val trainColor = Color(android.graphics.Color.parseColor(lineHex))

                        drawCircle(
                            color = Color.White,
                            radius = 9f / scale.coerceAtLeast(0.8f),
                            center = trainPos
                        )
                        drawCircle(
                            color = trainColor,
                            radius = 6f / scale.coerceAtLeast(0.8f),
                            center = trainPos
                        )
                    }
                }
            }
        }
    }
}
