package com.example.core.model

import java.time.Instant

/**
 * Core domain models for Chicago Metro ('L', CTA, Metra, Pace).
 * Models transport topology:
 * CITY -> NETWORK -> LINES -> STATIONS -> ENTRANCES -> PLATFORMS -> TRACKS -> TRANSFERS -> TRAINS -> JOURNEYS
 */

enum class LineColor(val hex: String, val displayName: String) {
    RED("#C60C30", "Red Line"),
    BLUE("#00A1DE", "Blue Line"),
    BROWN("#62361B", "Brown Line"),
    GREEN("#009B3A", "Green Line"),
    ORANGE("#F9461C", "Orange Line"),
    PINK("#E27EA6", "Pink Line"),
    PURPLE("#522398", "Purple Line"),
    YELLOW("#F9E300", "Yellow Line"),
    METRA("#003366", "Metra Commuter"),
    PACE("#00A859", "Pace Bus");

    companion object {
        fun fromId(id: String): LineColor = when (id.uppercase()) {
            "RED", "R" -> RED
            "BLUE", "BLUE_LINE" -> BLUE
            "BROWN", "BRN" -> BROWN
            "GREEN", "G" -> GREEN
            "ORG", "ORANGE" -> ORANGE
            "PINK" -> PINK
            "PURPLE", "P", "PEXP" -> PURPLE
            "YELLOW", "Y" -> YELLOW
            "METRA" -> METRA
            "PACE" -> PACE
            else -> BLUE
        }
    }
}

enum class AlertSeverity {
    INFO,
    WARNING,
    SEVERE,
    CRITICAL
}

data class ServiceAlert(
    val id: String,
    val lineId: String?,
    val stationId: String?,
    val headline: String,
    val description: String,
    val severity: AlertSeverity,
    val impactedLines: List<String> = emptyList(),
    val isElevatorAlert: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class StationEntrance(
    val id: String,
    val name: String,
    val street: String,
    val latitude: Double,
    val longitude: Double,
    val isAccessible: Boolean,
    val hasElevator: Boolean,
    val hasEscalator: Boolean,
    val hasStairs: Boolean,
    val hoursDescription: String = "24/7"
)

data class Platform(
    val id: String,
    val stationId: String,
    val name: String,
    val direction: String, // e.g. "Howard-bound", "95th-bound", "Loop-bound", "O'Hare-bound"
    val lines: List<String>,
    val isAccessible: Boolean,
    val boardingPositions: List<String> = listOf("Front", "Middle", "Rear")
)

data class Station(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val lines: List<String>,
    val isAccessible: Boolean = true,
    val hasElevator: Boolean = true,
    val hasParkAndRide: Boolean = false,
    val isLoopStation: Boolean = false,
    val address: String = "Chicago, IL",
    val busConnections: List<String> = emptyList(),
    val metraConnections: List<String> = emptyList(),
    val entrances: List<StationEntrance> = emptyList(),
    val platforms: List<Platform> = emptyList()
)

data class LoopSegment(
    val fromStationId: String,
    val toStationId: String,
    val direction: LoopDirection,
    val travelTimeSeconds: Int
)

enum class LoopDirection {
    CLOCKWISE,
    COUNTER_CLOCKWISE
}

enum class DepartureStatus {
    REALTIME,
    SCHEDULED,
    DELAYED,
    APPROACHING,
    DUE
}

data class LiveDeparture(
    val id: String,
    val stationId: String,
    val routeId: String,
    val destination: String,
    val etaMinutes: Int,
    val scheduledArrival: String,
    val vehicleId: String? = null,
    val direction: String,
    val status: DepartureStatus = DepartureStatus.REALTIME,
    val isApproaching: Boolean = false,
    val isDelayed: Boolean = false,
    val runNumber: String? = null,
    val dataAgeSeconds: Int = 12
)

data class VehiclePosition(
    val vehicleId: String,
    val routeId: String,
    val currentStationId: String?,
    val nextStationId: String,
    val latitude: Double,
    val longitude: Double,
    val destination: String,
    val speedMph: Double,
    val heading: Double,
    val lastUpdated: Long = System.currentTimeMillis()
)

data class ElevatorStatus(
    val stationId: String,
    val stationName: String,
    val elevatorName: String,
    val isOperational: Boolean,
    val impactDescription: String,
    val estimatedRestoration: String? = null
)

data class RouteStep(
    val stepIndex: Int,
    val mode: String, // "WALK", "CTA_TRAIN", "METRA_TRAIN", "PACE_BUS", "TRANSFER"
    val lineId: String?,
    val fromStationName: String,
    val toStationName: String,
    val durationMinutes: Int,
    val distanceMiles: Double,
    val instructions: String,
    val entranceName: String? = null,
    val platformInfo: String? = null,
    val stopsCount: Int = 0,
    val intermediateStops: List<String> = emptyList(),
    val isAccessible: Boolean = true
)

data class JourneyResult(
    val id: String,
    val originName: String,
    val destinationName: String,
    val totalDurationMinutes: Int,
    val walkDurationMinutes: Int,
    val transferCount: Int,
    val departureTime: String,
    val arrivalTime: String,
    val fareEstimate: String = "$2.50",
    val isStepFreeAccessible: Boolean = true,
    val steps: List<RouteStep>
)

data class FavoriteStation(
    val stationId: String,
    val customName: String?,
    val preferredLineId: String?,
    val timestamp: Long = System.currentTimeMillis()
)

data class SavedCommute(
    val id: String,
    val name: String, // e.g. "Morning Commute", "Airport Express"
    val originStationId: String,
    val destinationStationId: String,
    val preferredLineId: String
)

data class MetraLine(
    val id: String,
    val name: String, // e.g. "BNSF Railway", "Union Pacific North"
    val code: String,
    val terminal: String,
    val stations: List<String>
)

data class PaceRoute(
    val routeNumber: String,
    val name: String,
    val majorDestinations: List<String>
)

enum class DataSourceType {
    LIVE_CTA_API,
    CACHED_SCHEDULE,
    DEMO_SIMULATION
}

data class NetworkDataState(
    val sourceType: DataSourceType = DataSourceType.LIVE_CTA_API,
    val lastUpdatedText: String = "Just now",
    val isOffline: Boolean = false
)
