package com.example.ui.metra

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsRailway
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel

data class MetraLineInfo(val code: String, val name: String, val terminal: String)
data class PaceRouteInfo(val routeNum: String, val name: String)

@Composable
fun MetraPaceScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val metraLines = listOf(
        MetraLineInfo("BNSF", "BNSF Railway", "Union Station → Aurora"),
        MetraLineInfo("UP-N", "Union Pacific North", "Ogilvie OTC → Kenosha"),
        MetraLineInfo("UP-NW", "Union Pacific Northwest", "Ogilvie OTC → Harvard"),
        MetraLineInfo("UP-W", "Union Pacific West", "Ogilvie OTC → Elburn"),
        MetraLineInfo("MD-N", "Milwaukee District North", "Union Station → Fox Lake"),
        MetraLineInfo("MD-W", "Milwaukee District West", "Union Station → Elgin"),
        MetraLineInfo("ME", "Metra Electric", "Millennium Station → University Park")
    )

    val paceRoutes = listOf(
        PaceRouteInfo("Pace 250", "Dempster Street (O'Hare → Evanston)"),
        PaceRouteInfo("Pace 290", "Touhy Avenue (Howard → Cumberland)"),
        PaceRouteInfo("Pace 352", "Halsted (95th/Dan Ryan → Chicago Heights)"),
        PaceRouteInfo("Pace 379", "Midway Airport → Orland Park")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.popSecondary() },
                modifier = Modifier.testTag("metra_back_btn")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "METRA & PACE CONNECTIONS",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "REGIONAL COMMUTER RAIL & SUBURBAN BUS",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                Text(text = "METRA COMMUTER RAIL LINES", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }

            items(metraLines) { m ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DirectionsRailway, contentDescription = null, tint = Color(0xFF0284C7))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = "${m.code} • ${m.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(text = m.terminal, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "PACE SUBURBAN BUS ROUTES", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }

            items(paceRoutes) { p ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DirectionsBus, contentDescription = null, tint = Color(0xFF10B981))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = p.routeNum, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(text = p.name, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
