package com.example.ui.lines

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.design.LineBadge
import com.example.core.design.StatusBadge
import com.example.core.graph.ChicagoTransitGraph
import com.example.core.model.AlertSeverity
import com.example.core.model.LineColor
import com.example.ui.MainViewModel

data class LineSummary(
    val id: String,
    val name: String,
    val term1: String,
    val term2: String,
    val stationCount: Int
)

@Composable
fun LinesScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lineSummaries = listOf(
        LineSummary("RED", "Red Line", "Howard", "95th/Dan Ryan", 33),
        LineSummary("BLUE", "Blue Line", "O'Hare Airport", "Forest Park", 33),
        LineSummary("BROWN", "Brown Line", "Kimball", "Loop (Elevated)", 27),
        LineSummary("GREEN", "Green Line", "Harlem/Lake", "Ashland/63rd & Cottage Grove", 30),
        LineSummary("ORANGE", "Orange Line", "Midway Airport", "Loop (Elevated)", 17),
        LineSummary("PINK", "Pink Line", "54th/Cermak", "Loop (Elevated)", 22),
        LineSummary("PURPLE", "Purple Line", "Linden", "Loop Express", 26),
        LineSummary("YELLOW", "Yellow Line (Skokie Swift)", "Dempster-Skokie", "Howard", 3)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "CTA 'L' RAIL LINES",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Select a line to view station sequence, next trains, and real-time status",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(lineSummaries) { line ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectLine(line.id) }
                        .testTag("line_card_${line.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LineBadge(lineId = line.id)
                            StatusBadge(severity = AlertSeverity.INFO, statusText = "NORMAL")
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "${line.term1} ↔ ${line.term2}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "${line.stationCount} Stations • Avg Headway 6-8 min",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
