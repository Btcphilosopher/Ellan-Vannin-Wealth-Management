package com.example.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplaneTicket
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsRailway
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.design.AlertBanner
import com.example.core.design.DepartureRow
import com.example.core.design.LineBadge
import com.example.core.design.StationRow
import com.example.core.design.StatusBadge
import com.example.core.model.AlertSeverity
import com.example.core.model.LineColor
import com.example.ui.AppTab
import com.example.ui.MainViewModel
import com.example.ui.SecondaryScreen

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val searchQuery by viewModel.searchQuery.collectAsState()
    val nearestStations by viewModel.nearestStations.collectAsState()
    val systemAlerts by viewModel.systemAlerts.collectAsState()
    val dataState by viewModel.dataState.collectAsState()

    val nearestPair = nearestStations.firstOrNull()
    val nearestStation = nearestPair?.first
    val distanceMiles = nearestPair?.second ?: 0.3
    val nearestDepartures = nearestStation?.let { viewModel.getStationDepartures(it.id) } ?: emptyList()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header & Title
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.chicago_l_banner_1793050647027),
                    contentDescription = "Chicago Elevated Train",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xAA0F172A))
                        .padding(16.dp),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "CHICAGO METRO",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "THE 'L' IN YOUR HAND",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                        }
                        Text(
                            text = dataState.lastUpdatedText,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }

        // Search Destination Box
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("Where are you going in Chicago? (e.g., Clark/Lake, O'Hare)...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search_input")
            )
        }

        // Primary Quick Action Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "QUICK ACTIONS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.setTab(AppTab.ROUTES) },
                        modifier = Modifier.weight(1f).testTag("action_plan"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(imageVector = Icons.Default.Navigation, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PLAN")
                    }

                    Button(
                        onClick = { viewModel.setTab(AppTab.MAP) },
                        modifier = Modifier.weight(1f).testTag("action_map"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(imageVector = Icons.Default.Map, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("MAP", color = MaterialTheme.colorScheme.onSurface)
                    }

                    Button(
                        onClick = { viewModel.navigateToSecondary(SecondaryScreen.LOOP_EXPLORER) },
                        modifier = Modifier.weight(1f).testTag("action_loop"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(imageVector = Icons.Default.Train, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("LOOP", color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }

        // Nearest Station Card
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "NEAREST STATION",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "GPS ACTIVE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF10B981)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                if (nearestStation != null) {
                    StationRow(
                        station = nearestStation,
                        distanceMiles = distanceMiles,
                        onClick = { viewModel.selectStation(nearestStation) }
                    )
                }
            }
        }

        // Live Next Departures at Nearest Station
        if (nearestDepartures.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "NEXT DEPARTURES (${nearestStation?.name ?: "Local"})",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    nearestDepartures.take(2).forEach { departure ->
                        DepartureRow(departure = departure)
                    }
                }
            }
        }

        // Secondary Transit Network Modes (Metra, Pace, Airports, Tracker, Status)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "NETWORK SYSTEMS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        QuickSystemChip(
                            icon = Icons.Default.FlightTakeoff,
                            label = "Airports Hub",
                            subLabel = "O'Hare & Midway",
                            onClick = { viewModel.navigateToSecondary(SecondaryScreen.AIRPORT_HUB) }
                        )
                    }
                    item {
                        QuickSystemChip(
                            icon = Icons.Default.DirectionsRailway,
                            label = "Metra Rail",
                            subLabel = "11 Commuter Lines",
                            onClick = { viewModel.navigateToSecondary(SecondaryScreen.METRA_PACE) }
                        )
                    }
                    item {
                        QuickSystemChip(
                            icon = Icons.Default.DirectionsBus,
                            label = "Pace Bus",
                            subLabel = "Suburban Connections",
                            onClick = { viewModel.navigateToSecondary(SecondaryScreen.METRA_PACE) }
                        )
                    }
                    item {
                        QuickSystemChip(
                            icon = Icons.Default.Train,
                            label = "Train Tracker",
                            subLabel = "Live Moving Trains",
                            onClick = { viewModel.navigateToSecondary(SecondaryScreen.TRAIN_TRACKER) }
                        )
                    }
                    item {
                        QuickSystemChip(
                            icon = Icons.Default.Terminal,
                            label = "Command Mode",
                            subLabel = "Transport Terminal",
                            onClick = { viewModel.navigateToSecondary(SecondaryScreen.COMMAND_TERMINAL) }
                        )
                    }
                }
            }
        }

        // Service Alerts
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SERVICE ALERTS",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    StatusBadge(
                        severity = if (systemAlerts.any { it.severity == AlertSeverity.WARNING }) AlertSeverity.WARNING else AlertSeverity.INFO,
                        statusText = "${systemAlerts.size} ALERTS ACTIVE"
                    )
                }

                systemAlerts.take(2).forEach { alert ->
                    AlertBanner(alert = alert)
                }
            }
        }
    }
}

@Composable
fun QuickSystemChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    subLabel: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(150.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subLabel,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp
            )
        }
    }
}
