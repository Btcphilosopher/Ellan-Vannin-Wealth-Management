package com.example.core.design

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Elevator
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.AlertSeverity
import com.example.core.model.DepartureStatus
import com.example.core.model.LineColor
import com.example.core.model.LiveDeparture
import com.example.core.model.ServiceAlert
import com.example.core.model.Station

@Composable
fun LineBadge(
    lineId: String,
    modifier: Modifier = Modifier
) {
    val lc = LineColor.fromId(lineId)
    val color = Color(android.graphics.Color.parseColor(lc.hex))

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = lc.displayName.replace(" Line", "").uppercase(),
            color = if (lc == LineColor.YELLOW) Color.Black else Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun StatusBadge(
    severity: AlertSeverity,
    statusText: String = "NORMAL",
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = when (severity) {
        AlertSeverity.INFO -> Color(0xFF065F46) to Color(0xFF34D399)
        AlertSeverity.WARNING -> Color(0xFF854D0E) to Color(0xFFFDE047)
        AlertSeverity.SEVERE, AlertSeverity.CRITICAL -> Color(0xFF991B1B) to Color(0xFFFCA5A5)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = "● $statusText",
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DepartureRow(
    departure: LiveDeparture,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("departure_row_${departure.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                LineBadge(lineId = departure.routeId)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = departure.destination,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${departure.direction} • ${departure.vehicleId ?: "CTA Run"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = if (departure.isApproaching) "Due" else "${departure.etaMinutes} min",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (departure.isApproaching) Color(0xFF22C55E) else MaterialTheme.colorScheme.primary
                )
                Text(
                    text = if (departure.status == DepartureStatus.REALTIME) "LIVE" else "SCHEDULED",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun StationRow(
    station: Station,
    distanceMiles: Double? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("station_row_${station.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = station.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (distanceMiles != null) {
                    val walkMin = (distanceMiles * 18).toInt().coerceAtLeast(1)
                    Text(
                        text = "${distanceMiles.toString().take(4)} mi • $walkMin min walk",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                station.lines.forEach { lineId ->
                    LineBadge(lineId = lineId)
                }
                if (station.isAccessible) {
                    Icon(
                        imageVector = Icons.Default.Accessible,
                        contentDescription = "Accessible Station",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                if (station.hasElevator) {
                    Icon(
                        imageVector = Icons.Default.Elevator,
                        contentDescription = "Has Elevator",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AlertBanner(
    alert: ServiceAlert,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("alert_banner_${alert.id}"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF451A03)),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Alert",
                tint = Color(0xFFF59E0B),
                modifier = Modifier
                    .size(22.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = alert.headline,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFDE047)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = alert.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFFEF3C7)
                )
            }
        }
    }
}
