package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.ui.airports.AirportHubScreen
import com.example.ui.command.CommandTerminalScreen
import com.example.ui.digitaltwin.DigitalTwinScreen
import com.example.ui.home.HomeScreen
import com.example.ui.journey.JourneyModeScreen
import com.example.ui.lines.LineDetailScreen
import com.example.ui.lines.LinesScreen
import com.example.ui.loop.LoopExplorerScreen
import com.example.ui.map.MapScreen
import com.example.ui.metra.MetraPaceScreen
import com.example.ui.planner.RoutePlannerScreen
import com.example.ui.stations.StationDetailScreen
import com.example.ui.stations.StationsScreen
import com.example.ui.status.SystemStatusScreen
import com.example.ui.tracker.TrainTrackerScreen

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val secondaryScreen by viewModel.secondaryScreen.collectAsState()
    val selectedStation by viewModel.selectedStation.collectAsState()
    val selectedLineId by viewModel.selectedLineId.collectAsState()

    Scaffold(
        bottomBar = {
            if (secondaryScreen == SecondaryScreen.NONE) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    NavigationBarItem(
                        selected = currentTab == AppTab.HOME,
                        onClick = { viewModel.setTab(AppTab.HOME) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("HOME") },
                        modifier = Modifier.testTag("tab_home")
                    )
                    NavigationBarItem(
                        selected = currentTab == AppTab.MAP,
                        onClick = { viewModel.setTab(AppTab.MAP) },
                        icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                        label = { Text("MAP") },
                        modifier = Modifier.testTag("tab_map")
                    )
                    NavigationBarItem(
                        selected = currentTab == AppTab.ROUTES,
                        onClick = { viewModel.setTab(AppTab.ROUTES) },
                        icon = { Icon(Icons.Default.Navigation, contentDescription = "Routes") },
                        label = { Text("PLAN") },
                        modifier = Modifier.testTag("tab_routes")
                    )
                    NavigationBarItem(
                        selected = currentTab == AppTab.STATIONS,
                        onClick = { viewModel.setTab(AppTab.STATIONS) },
                        icon = { Icon(Icons.Default.Place, contentDescription = "Stations") },
                        label = { Text("STATIONS") },
                        modifier = Modifier.testTag("tab_stations")
                    )
                    NavigationBarItem(
                        selected = currentTab == AppTab.MORE,
                        onClick = { viewModel.setTab(AppTab.MORE) },
                        icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "More") },
                        label = { Text("MORE") },
                        modifier = Modifier.testTag("tab_more")
                    )
                }
            }
        },
        modifier = modifier
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (secondaryScreen != SecondaryScreen.NONE) {
                when (secondaryScreen) {
                    SecondaryScreen.STATION_DETAIL -> {
                        selectedStation?.let { st ->
                            StationDetailScreen(station = st, viewModel = viewModel)
                        }
                    }
                    SecondaryScreen.LINE_DETAIL -> {
                        selectedLineId?.let { lineId ->
                            LineDetailScreen(lineId = lineId, viewModel = viewModel)
                        }
                    }
                    SecondaryScreen.TRAIN_TRACKER -> TrainTrackerScreen(viewModel = viewModel)
                    SecondaryScreen.SYSTEM_STATUS -> SystemStatusScreen(viewModel = viewModel)
                    SecondaryScreen.AIRPORT_HUB -> AirportHubScreen(viewModel = viewModel)
                    SecondaryScreen.METRA_PACE -> MetraPaceScreen(viewModel = viewModel)
                    SecondaryScreen.LOOP_EXPLORER -> LoopExplorerScreen(viewModel = viewModel)
                    SecondaryScreen.JOURNEY_MODE -> JourneyModeScreen(viewModel = viewModel)
                    SecondaryScreen.DIGITAL_TWIN -> DigitalTwinScreen(viewModel = viewModel)
                    SecondaryScreen.COMMAND_TERMINAL -> CommandTerminalScreen(viewModel = viewModel)
                    else -> HomeScreen(viewModel = viewModel)
                }
            } else {
                when (currentTab) {
                    AppTab.HOME -> HomeScreen(viewModel = viewModel)
                    AppTab.MAP -> MapScreen(viewModel = viewModel)
                    AppTab.ROUTES -> RoutePlannerScreen(viewModel = viewModel)
                    AppTab.STATIONS -> StationsScreen(viewModel = viewModel)
                    AppTab.MORE -> LinesScreen(viewModel = viewModel)
                }
            }
        }
    }
}
