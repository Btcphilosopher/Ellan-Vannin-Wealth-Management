package com.example.ui.airports

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FlightLand
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.design.DepartureRow
import com.example.core.design.LineBadge
import com.example.core.graph.ChicagoTransitGraph
import com.example.ui.AppTab
import com.example.ui.MainViewModel

@Composable
fun AirportHubScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val ohareStation = ChicagoTransitGraph.getStation("ohare")
    val midwayStation = ChicagoTransitGraph.getStation("midway")

    val ohareDepartures = ohareStation?.let { viewModel.getStationDepartures(it.id) } ?: emptyList()
    val midwayDepartures = midwayStation?.let { viewModel.getStationDepartures(it.id) } ?: emptyList()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.popSecondary() },
                modifier = Modifier.testTag("airport_back_btn")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "AIRPORT CONTROL CENTRE",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "O'HARE (ORD) & MIDWAY (MDW) RAPID TRANSIT",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // O'Hare Airport Hub Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FlightTakeoff, contentDescription = "O'Hare", tint = Color(0xFF00A1DE))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("O'HARE INTERNATIONAL (ORD)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            LineBadge(lineId = "BLUE")
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Direct 24/7 service on Blue Line from Downtown Loop to Terminals 1, 2, 3 (Pedway walk to T5 ATS shuttle).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                ohareStation?.let {
                                    viewModel.setRouteDestination(it)
                                    viewModel.setTab(AppTab.ROUTES)
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("route_ohare_btn")
                        ) {
                            Icon(Icons.Default.Navigation, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ROUTE TO O'HARE FROM CURRENT LOCATION")
                        }
                    }
                }
            }

            if (ohareDepartures.isNotEmpty()) {
                item {
                    Text(text = "O'HARE NEXT DEPARTURES", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                item {
                    DepartureRow(departure = ohareDepartures.first())
                }
            }

            // Midway Airport Hub Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FlightLand, contentDescription = "Midway", tint = Color(0xFFF9461C))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("MIDWAY INTERNATIONAL (MDW)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            LineBadge(lineId = "ORANGE")
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Direct Orange Line service to Downtown Loop in ~25 min. Covered enclosed walkway from station to airport terminal.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                midwayStation?.let {
                                    viewModel.setRouteDestination(it)
                                    viewModel.setTab(AppTab.ROUTES)
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("route_midway_btn")
                        ) {
                            Icon(Icons.Default.Navigation, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ROUTE TO MIDWAY FROM CURRENT LOCATION")
                        }
                    }
                }
            }

            if (midwayDepartures.isNotEmpty()) {
                item {
                    Text(text = "MIDWAY NEXT DEPARTURES", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                item {
                    DepartureRow(departure = midwayDepartures.first())
                }
            }
        }
    }
}
