package com.example.ui.status

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.design.AlertBanner
import com.example.core.design.LineBadge
import com.example.core.design.StatusBadge
import com.example.core.model.AlertSeverity
import com.example.ui.MainViewModel

@Composable
fun SystemStatusScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val systemAlerts by viewModel.systemAlerts.collectAsState()
    val elevatorStatuses by viewModel.elevatorStatuses.collectAsState()

    val lines = listOf("RED", "BLUE", "BROWN", "GREEN", "ORANGE", "PINK", "PURPLE", "YELLOW")

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.popSecondary() },
                modifier = Modifier.testTag("status_back_btn")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "SYSTEM STATUS & DISRUPTIONS",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "CTA RAIL NETWORK OPERATIONAL MONITOR",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                Text(text = "LINE STATUS OVERVIEW", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }

            items(lines) { lineId ->
                val hasAlert = systemAlerts.any { it.lineId == lineId }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LineBadge(lineId = lineId)
                        StatusBadge(
                            severity = if (hasAlert) AlertSeverity.WARNING else AlertSeverity.INFO,
                            statusText = if (hasAlert) "SERVICE CHANGE" else "NORMAL SERVICE"
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "ACTIVE DISRUPTIONS & ALERTS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }

            items(systemAlerts) { alert ->
                AlertBanner(alert = alert)
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "ELEVATOR OUTAGE MONITOR", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }

            items(elevatorStatuses) { el ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (el.isOperational) Color(0xFF064E3B) else Color(0xFF7F1D1D)
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "${el.stationName} - ${el.elevatorName}",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = el.impactDescription,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
