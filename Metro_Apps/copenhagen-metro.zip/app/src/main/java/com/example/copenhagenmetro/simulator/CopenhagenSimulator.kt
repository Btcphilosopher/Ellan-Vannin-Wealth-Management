package com.example.copenhagenmetro.simulator

import com.example.copenhagenmetro.data.mock.CopenhagenNetworkData
import com.example.copenhagenmetro.domain.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Random

enum class SimulationScenario(val labelDa: String, val labelEn: String) {
    NORMAL_DAY("Normal Drift", "Normal Service"),
    RUSH_HOUR("Myldretid (2 min frekvens)", "Rush Hour (2-min headway)"),
    M3_CIRCLE("M3 Cityringen Fokus", "M3 Circle Loop Active"),
    AIRPORT_FLOW("Lufthavnen / CPH Flow", "Airport High Capacity"),
    METRO_DELAY("Metro Signalfejl (Forsinkelse)", "Metro Signal Delay"),
    S_TRAIN_DELAY("S-tog Sporskiftefejl", "S-train Track Disruption"),
    LIFT_FAILURE("Elevatordefekt Nørreport", "Lift Outage Nørreport"),
    WINTER_WEATHER("Vintervejr / Sne", "Winter Weather Conditions"),
    NETWORK_OUTAGE("Netværksnedbrud (Offline)", "Network Offline")
}

data class SimulatedVehicle(
    val id: String,
    val lineCode: String,
    val colorHex: String,
    val currentStationName: String,
    val nextStationName: String,
    val progressFraction: Float, // 0.0 to 1.0 between stations
    val directionLabel: String,
    val speedKmh: Int = 45
)

object CopenhagenSimulator {

    private val _activeScenario = MutableStateFlow(SimulationScenario.NORMAL_DAY)
    val activeScenario = _activeScenario.asStateFlow()

    private val _simulatedVehicles = MutableStateFlow<List<SimulatedVehicle>>(emptyList())
    val simulatedVehicles = _simulatedVehicles.asStateFlow()

    private val random = Random()

    fun setScenario(scenario: SimulationScenario) {
        _activeScenario.value = scenario
    }

    fun getDeparturesForStation(stationName: String): List<TransportDeparture> {
        val station = CopenhagenNetworkData.STATIONS_MAP.values.find {
            it.name.equals(stationName, ignoreCase = true)
        } ?: return emptyList()

        val list = mutableListOf<TransportDeparture>()
        val currentScenario = _activeScenario.value

        if (currentScenario == SimulationScenario.NETWORK_OUTAGE) {
            return emptyList()
        }

        station.servingLines.forEach { line ->
            when (line) {
                "M1" -> {
                    val delayMins = if (currentScenario == SimulationScenario.METRO_DELAY) 6 else 0
                    list.add(
                        TransportDeparture(
                            routeId = "M1",
                            lineCode = "M1",
                            lineColorHex = "#00843D",
                            destinationName = "Vestamager",
                            scheduledTimeMinutes = 2 + delayMins,
                            relativeMinutes = 2 + delayMins,
                            realtimeState = if (delayMins > 0) RealtimeState.ESTIMATED else RealtimeState.LIVE,
                            platform = "Spor 1",
                            directionLabel = "VESTAMAGER",
                            delayMinutes = delayMins
                        )
                    )
                    list.add(
                        TransportDeparture(
                            routeId = "M1",
                            lineCode = "M1",
                            lineColorHex = "#00843D",
                            destinationName = "Vanløse",
                            scheduledTimeMinutes = 6,
                            relativeMinutes = 6,
                            realtimeState = RealtimeState.LIVE,
                            platform = "Spor 2",
                            directionLabel = "VANLØSE"
                        )
                    )
                }
                "M2" -> {
                    val headway = if (currentScenario == SimulationScenario.AIRPORT_FLOW) 2 else 4
                    list.add(
                        TransportDeparture(
                            routeId = "M2",
                            lineCode = "M2",
                            lineColorHex = "#F2A900",
                            destinationName = "Lufthavnen (CPH)",
                            scheduledTimeMinutes = headway,
                            relativeMinutes = headway,
                            realtimeState = RealtimeState.LIVE,
                            platform = "Spor 1",
                            directionLabel = "LUFTHAVNEN"
                        )
                    )
                    list.add(
                        TransportDeparture(
                            routeId = "M2",
                            lineCode = "M2",
                            lineColorHex = "#F2A900",
                            destinationName = "Vanløse",
                            scheduledTimeMinutes = headway + 4,
                            relativeMinutes = headway + 4,
                            realtimeState = RealtimeState.LIVE,
                            platform = "Spor 2",
                            directionLabel = "VANLØSE"
                        )
                    )
                }
                "M3" -> {
                    list.add(
                        TransportDeparture(
                            routeId = "M3",
                            lineCode = "M3",
                            lineColorHex = "#C8102E",
                            destinationName = "København H (Inderring)",
                            scheduledTimeMinutes = 3,
                            relativeMinutes = 3,
                            realtimeState = RealtimeState.LIVE,
                            platform = "Spor 1",
                            directionLabel = "INDERring (Med uret)",
                            m3Direction = M3Direction.CLOCKWISE
                        )
                    )
                    list.add(
                        TransportDeparture(
                            routeId = "M3",
                            lineCode = "M3",
                            lineColorHex = "#C8102E",
                            destinationName = "Østerport (Yderring)",
                            scheduledTimeMinutes = 5,
                            relativeMinutes = 5,
                            realtimeState = RealtimeState.LIVE,
                            platform = "Spor 2",
                            directionLabel = "YDERring (Mod uret)",
                            m3Direction = M3Direction.COUNTERCLOCKWISE
                        )
                    )
                }
                "M4" -> {
                    list.add(
                        TransportDeparture(
                            routeId = "M4",
                            lineCode = "M4",
                            lineColorHex = "#00A3E0",
                            destinationName = "København Syd",
                            scheduledTimeMinutes = 4,
                            relativeMinutes = 4,
                            realtimeState = RealtimeState.LIVE,
                            platform = "Spor 1",
                            directionLabel = "KØBENHAVN SYD"
                        )
                    )
                    list.add(
                        TransportDeparture(
                            routeId = "M4",
                            lineCode = "M4",
                            lineColorHex = "#00A3E0",
                            destinationName = "Orientkaj",
                            scheduledTimeMinutes = 8,
                            relativeMinutes = 8,
                            realtimeState = RealtimeState.LIVE,
                            platform = "Spor 2",
                            directionLabel = "ORIENTKAJ"
                        )
                    )
                }
                "S_A", "S_B", "S_C", "S_F" -> {
                    val isCancelled = currentScenario == SimulationScenario.S_TRAIN_DELAY && line == "S_A"
                    list.add(
                        TransportDeparture(
                            routeId = line,
                            lineCode = line.replace("S_", "S-"),
                            lineColorHex = "#E30613",
                            destinationName = if (line == "S_A") "Hillerød" else "Farum",
                            scheduledTimeMinutes = 5,
                            relativeMinutes = 5,
                            realtimeState = if (isCancelled) RealtimeState.CANCELLED else RealtimeState.LIVE,
                            platform = "Spor 9",
                            directionLabel = "NORD",
                            delayMinutes = if (isCancelled) 15 else 0
                        )
                    )
                }
                "BUS_5C" -> {
                    list.add(
                        TransportDeparture(
                            routeId = "BUS_5C",
                            lineCode = "5C",
                            lineColorHex = "#FFB300",
                            destinationName = "Husum Torv",
                            scheduledTimeMinutes = 3,
                            relativeMinutes = 3,
                            realtimeState = RealtimeState.LIVE,
                            platform = "Buskaj A",
                            directionLabel = "HUSUM TORV"
                        )
                    )
                }
                "HB_991" -> {
                    list.add(
                        TransportDeparture(
                            routeId = "HB_991",
                            lineCode = "991",
                            lineColorHex = "#003366",
                            destinationName = "Refshaleøen",
                            scheduledTimeMinutes = 12,
                            relativeMinutes = 12,
                            realtimeState = RealtimeState.LIVE,
                            platform = "Bro 1",
                            directionLabel = "REFSHALEØEN"
                        )
                    )
                }
            }
        }

        return list.sortedBy { it.relativeMinutes }
    }
}
