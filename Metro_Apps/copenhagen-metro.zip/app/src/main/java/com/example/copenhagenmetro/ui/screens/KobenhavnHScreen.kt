package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.components.DepartureRowItem
import com.example.copenhagenmetro.ui.components.LineBadge
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.CoolGrey
import com.example.ui.theme.DanishRed
import com.example.ui.theme.MutedText

@Composable
fun KobenhavnHScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onBack: () -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    val departures = viewModel.repository.getDeparturesForStation("København H")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = "KØBENHAVN H",
            subtitle = if (isDanish) "Centralstation Transportstyring" else "Central Station Control Hub",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Mode Badges Header
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("cph_central_modes_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isDanish) "KØBENHAVN H INTEGRERET NETVÆRK" else "INTEGRATED TRANSPORT NETWORK",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            LineBadge("M3")
                            LineBadge("M4")
                            LineBadge("S-A")
                            LineBadge("S-B")
                            LineBadge("S-C")
                            LineBadge("RE")
                            LineBadge("5C")
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (isDanish) "Hovedbanegården forbinder Metro (M3/M4), S-tog, Regionaltog, InterCity og Busser under ét tag."
                            else "Central Station connects Metro (M3/M4), S-train, Regional Rail, InterCity and Buses under one roof.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Platforms & Wayfinding Guide
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isDanish) "SPOR & SKIFT" else "PLATFORMS & TRANSFERS",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        WayfindingRow("Metro M3/M4", "Underjordisk hal (Deep Underground)", "2-3 min gang")
                        WayfindingRow("S-tog Spor 9-12", "Hovedhal Spor 9-12", "1-2 min gang")
                        WayfindingRow("Regional/InterCity Spor 1-8", "Hovedhal Spor 1-8", "1-2 min gang")
                        WayfindingRow("Bus 5C / Bybusser", "Bernstorffsgade Udenfor", "2 min gang")
                    }
                }
            }

            // Live Departures
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("cph_central_departures_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isDanish) "LIVE AFGANGETAVLE - KØBENHAVN H" else "LIVE DEPARTURE BOARD - KØBENHAVN H",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        departures.forEach { departure ->
                            DepartureRowItem(departure = departure, onClick = {})
                            HorizontalDivider(color = CoolGrey.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WayfindingRow(title: String, location: String, walkTime: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(text = location, fontSize = 11.sp, color = MutedText)
        }
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = CoolGrey.copy(alpha = 0.5f)
        ) {
            Text(
                text = walkTime,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}
