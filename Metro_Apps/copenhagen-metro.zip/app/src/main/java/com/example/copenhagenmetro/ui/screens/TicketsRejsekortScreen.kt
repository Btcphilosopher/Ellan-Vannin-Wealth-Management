package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.domain.model.FareProduct
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.*

@Composable
fun TicketsRejsekortScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onBack: () -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    val activeTickets by viewModel.activeTickets.collectAsState()
    val fareProducts = viewModel.repository.getFareProducts()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = if (isDanish) "BILLETTER & REJSEKORT" else "TICKETS & REJSEKORT",
            subtitle = "DOT | Rejsebillet & Zoneberegner",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Rejsekort 1-Swipe Card Simulation
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(3.dp),
                    modifier = Modifier.fillMaxWidth().testTag("rejsekort_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CreditCard, contentDescription = null, tint = DanishRed)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "REJSEKORT 1-SWIPE",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (uiState.isRejsekortCheckedIn) LiveGreen.copy(alpha = 0.2f) else CoolGrey.copy(alpha = 0.5f)
                            ) {
                                Text(
                                    text = if (uiState.isRejsekortCheckedIn) "✔ TJEKKET IND" else "TJEKKET UD",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (uiState.isRejsekortCheckedIn) LiveGreen else MutedText,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (uiState.isRejsekortCheckedIn) {
                            Text(
                                text = "Aktiv Rejse: ${uiState.rejsekortCheckInStation ?: "Nørreport"} (${uiState.rejsekortCheckInTime})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = LiveGreen
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.toggleRejsekortCheckIn() },
                                colors = ButtonDefaults.buttonColors(containerColor = DanishRed),
                                modifier = Modifier.fillMaxWidth().testTag("rejsekort_checkout_btn")
                            ) {
                                Text("TJEK UD (CHECK OUT)")
                            }
                        } else {
                            Text(
                                text = if (isDanish) "Én swipe til at tjekke ind på Metro, S-tog, bus og havnebus." else "One swipe to check in across Metro, S-train, bus and harbour bus.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.toggleRejsekortCheckIn("Nørreport") },
                                colors = ButtonDefaults.buttonColors(containerColor = LiveGreen),
                                modifier = Modifier.fillMaxWidth().testTag("rejsekort_checkin_btn")
                            ) {
                                Text("TJEK IND PÅ NØRREPORT")
                            }
                        }
                    }
                }
            }

            // Ticket Wallet (Active Tickets)
            item {
                Text(
                    text = if (isDanish) "AKTIVE BILLETTER" else "ACTIVE TICKETS",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(6.dp))

                if (activeTickets.isEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                            Text(
                                text = if (isDanish) "Ingen aktive digitalbilletter i punget." else "No active digital tickets in wallet.",
                                fontSize = 12.sp,
                                color = MutedText
                            )
                        }
                    }
                } else {
                    activeTickets.forEach { ticket ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(2.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).testTag("active_ticket_card")
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = ticket.productName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(text = "VALID", fontWeight = FontWeight.ExtraBold, color = LiveGreen, fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "QR Code: ${ticket.qrCodeData}", fontSize = 10.sp, color = MutedText)
                                Text(text = "Pris: ${ticket.priceDkk} DKK", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Available Products & Ticket Purchases
            item {
                Text(
                    text = if (isDanish) "KØB REJSEBILLET" else "PURCHASE REJSEBILLET",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(6.dp))

                fareProducts.forEach { product ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(1.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isDanish) product.nameDa else product.nameEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = product.validZonesDescription,
                                    fontSize = 11.sp,
                                    color = MutedText
                                )
                            }
                            Button(
                                onClick = { viewModel.buyTicket(product.nameDa, product.priceDkk) },
                                colors = ButtonDefaults.buttonColors(containerColor = DanishRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("buy_ticket_btn_${product.id}")
                            ) {
                                Text("${product.priceDkk.toInt()} DKK", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
