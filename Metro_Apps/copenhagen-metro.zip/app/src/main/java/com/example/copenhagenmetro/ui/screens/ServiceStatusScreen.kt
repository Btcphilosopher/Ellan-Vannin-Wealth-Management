package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.components.LineBadge
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.*

@Composable
fun ServiceStatusScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onBack: () -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    val alerts = viewModel.repository.getSystemAlerts()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = if (isDanish) "NETVÆRKSDRIFT & ALERTER" else "NETWORK SERVICE STATUS",
            subtitle = if (isDanish) "Sanntid Status for Metronettet & DSB" else "Realtime Metro & Transit Health",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Line Health Overview Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("line_health_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isDanish) "LINJEOVERSIGT" else "LINE STATUS OVERVIEW",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        LineStatusRow("M1", "Vanløse - Vestamager", "Normal drift", true)
                        LineStatusRow("M2", "Vanløse - Lufthavnen", "Normal drift", true)
                        LineStatusRow("M3", "Cityringen Loop", "Normal drift", true)
                        LineStatusRow("M4", "Orientkaj - København Syd", "Normal drift", true)
                        LineStatusRow("S-tog", "A, B, C, F, H", "Elevatordefekt Nørreport", false)
                        LineStatusRow("Havnebus", "991 / 992", "Normal sommerdrift", true)
                    }
                }
            }

            // System Alerts Feed
            item {
                Text(
                    text = if (isDanish) "AKTIVE DRIFTSMEDDELELSER" else "ACTIVE SERVICE ALERTS",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(6.dp))

                alerts.forEach { alert ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(1.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).testTag("service_alert_item")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = AlertWarningOrange)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isDanish) alert.titleDa else alert.titleEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isDanish) alert.descriptionDa else alert.descriptionEn,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                alert.affectedLines.forEach { line ->
                                    LineBadge(line)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LineStatusRow(code: String, routeName: String, statusText: String, isOk: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LineBadge(code)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = code, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(text = routeName, fontSize = 11.sp, color = MutedText)
            }
        }
        Text(
            text = "● $statusText",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (isOk) LiveGreen else AlertWarningOrange
        )
    }
}
