package com.example.copenhagenmetro.routing

import com.example.copenhagenmetro.data.mock.CopenhagenNetworkData
import com.example.copenhagenmetro.domain.model.*
import java.util.Calendar

data class JourneyFilterOptions(
    val preferMetro: Boolean = false,
    val preferTrain: Boolean = false,
    val stepFreeOnly: Boolean = false,
    val withBicycle: Boolean = false,
    val fewestTransfers: Boolean = false,
    val leastWalking: Boolean = false
)

object JourneyPlanner {

    fun planJourney(
        originName: String,
        destinationName: String,
        filterOptions: JourneyFilterOptions = JourneyFilterOptions()
    ): List<Journey> {
        val origin = CopenhagenNetworkData.STATIONS_MAP.values.find {
            it.name.equals(originName, ignoreCase = true) || it.id.equals(originName, ignoreCase = true)
        } ?: CopenhagenNetworkData.STATIONS_MAP["Nørreport"]!!

        val destination = CopenhagenNetworkData.STATIONS_MAP.values.find {
            it.name.equals(destinationName, ignoreCase = true) || it.id.equals(destinationName, ignoreCase = true)
        } ?: CopenhagenNetworkData.STATIONS_MAP["Lufthavnen"]!!

        val results = mutableListOf<Journey>()

        // 1. Check direct Metro options
        val directMetroLine = findDirectMetroLine(origin.name, destination.name)
        if (directMetroLine != null) {
            val m3Result = if (directMetroLine == "M3") {
                M3CircleCalculator.calculateM3Route(origin.name, destination.name)
            } else null

            val duration = m3Result?.bestMinutes ?: calculateEstimatedMinutes(origin.name, destination.name, directMetroLine)
            val routeColor = getRouteColor(directMetroLine)

            val leg = JourneyLeg(
                mode = TransportMode.METRO,
                routeCode = directMetroLine,
                routeColorHex = routeColor,
                fromStationName = origin.name,
                toStationName = destination.name,
                departureTime = "14:02",
                arrivalTime = formatTimePlusMinutes("14:02", duration),
                durationMinutes = duration,
                intermediateStopsCount = getIntermediateStopCount(origin.name, destination.name, directMetroLine),
                platform = getPlatform(origin.name, directMetroLine),
                m3DirectionNotice = m3Result?.recommendationMessageEn
            )

            val zones = calculateZones(origin.zoneId, destination.zoneId)
            val price = calculatePrice(zones.size)

            results.add(
                Journey(
                    originStation = origin.name,
                    destinationStation = destination.name,
                    departureTimeFormatted = "14:02",
                    arrivalTimeFormatted = formatTimePlusMinutes("14:02", duration),
                    totalDurationMinutes = duration,
                    transfersCount = 0,
                    walkingMinutes = 3,
                    fareZones = zones,
                    priceDkk = price,
                    legs = listOf(leg),
                    isStepFreeAccessible = origin.facilities.isStepFree && destination.facilities.isStepFree,
                    bikeAllowed = true,
                    m3Recommendation = m3Result?.recommendationMessageEn
                )
            )
        }

        // 2. Check 1-transfer Metro option (e.g. Nørrebro -> Kongens Nytorv (M3) -> Lufthavnen (M2))
        if (results.size < 3) {
            val transferHub = if (origin.name != "Kongens Nytorv" && destination.name != "Kongens Nytorv") "Kongens Nytorv" else "Frederiksberg"
            val leg1Duration = calculateEstimatedMinutes(origin.name, transferHub, "M3")
            val leg2Duration = calculateEstimatedMinutes(transferHub, destination.name, "M2")
            val transferWalkingMinutes = 3

            val leg1 = JourneyLeg(
                mode = TransportMode.METRO,
                routeCode = if (origin.servingLines.contains("M3")) "M3" else "M1",
                routeColorHex = if (origin.servingLines.contains("M3")) "#C8102E" else "#00843D",
                fromStationName = origin.name,
                toStationName = transferHub,
                departureTime = "14:04",
                arrivalTime = formatTimePlusMinutes("14:04", leg1Duration),
                durationMinutes = leg1Duration,
                intermediateStopsCount = 4,
                platform = "Spor 1"
            )

            val legTransfer = JourneyLeg(
                mode = TransportMode.WALKING,
                routeCode = "GANG",
                routeColorHex = "#757575",
                fromStationName = transferHub,
                toStationName = transferHub,
                departureTime = formatTimePlusMinutes("14:04", leg1Duration),
                arrivalTime = formatTimePlusMinutes("14:04", leg1Duration + transferWalkingMinutes),
                durationMinutes = transferWalkingMinutes,
                intermediateStopsCount = 0,
                platform = "Skift platform",
                isTransfer = true
            )

            val leg2 = JourneyLeg(
                mode = TransportMode.METRO,
                routeCode = if (destination.servingLines.contains("M2")) "M2" else "M4",
                routeColorHex = if (destination.servingLines.contains("M2")) "#F2A900" else "#00A3E0",
                fromStationName = transferHub,
                toStationName = destination.name,
                departureTime = formatTimePlusMinutes("14:04", leg1Duration + transferWalkingMinutes),
                arrivalTime = formatTimePlusMinutes("14:04", leg1Duration + transferWalkingMinutes + leg2Duration),
                durationMinutes = leg2Duration,
                intermediateStopsCount = 6,
                platform = "Spor 2"
            )

            val totalDuration = leg1Duration + transferWalkingMinutes + leg2Duration
            val zones = calculateZones(origin.zoneId, destination.zoneId)
            val price = calculatePrice(zones.size)

            results.add(
                Journey(
                    originStation = origin.name,
                    destinationStation = destination.name,
                    departureTimeFormatted = "14:04",
                    arrivalTimeFormatted = formatTimePlusMinutes("14:04", totalDuration),
                    totalDurationMinutes = totalDuration,
                    transfersCount = 1,
                    walkingMinutes = 5,
                    fareZones = zones,
                    priceDkk = price,
                    legs = listOf(leg1, legTransfer, leg2),
                    isStepFreeAccessible = origin.facilities.isElevatorInService && destination.facilities.isElevatorInService,
                    bikeAllowed = true
                )
            )
        }

        // 3. Check S-tog or Regional option (especially for København H / Airport / Roskilde)
        if (origin.isMajorHub || destination.isMajorHub || origin.name.contains("Roskilde") || destination.name.contains("Airport") || destination.name.contains("Lufthavnen")) {
            val isAirport = destination.name.contains("Airport") || destination.name.contains("Lufthavnen") || origin.name.contains("Lufthavnen")
            val lineCode = if (isAirport) "RE" else "S-A"
            val mode = if (isAirport) TransportMode.REGIONAL_RAIL else TransportMode.S_TOG
            val duration = if (isAirport) 13 else 18

            val leg = JourneyLeg(
                mode = mode,
                routeCode = lineCode,
                routeColorHex = if (isAirport) "#005587" else "#E30613",
                fromStationName = origin.name,
                toStationName = destination.name,
                departureTime = "14:10",
                arrivalTime = formatTimePlusMinutes("14:10", duration),
                durationMinutes = duration,
                intermediateStopsCount = if (isAirport) 2 else 5,
                platform = if (isAirport) "Spor 5" else "Spor 9-10"
            )

            val zones = calculateZones(origin.zoneId, destination.zoneId)

            results.add(
                Journey(
                    originStation = origin.name,
                    destinationStation = destination.name,
                    departureTimeFormatted = "14:10",
                    arrivalTimeFormatted = formatTimePlusMinutes("14:10", duration),
                    totalDurationMinutes = duration,
                    transfersCount = 0,
                    walkingMinutes = 2,
                    fareZones = zones,
                    priceDkk = calculatePrice(zones.size),
                    legs = listOf(leg),
                    isStepFreeAccessible = true,
                    bikeAllowed = true
                )
            )
        }

        // Apply filters if stepFree or bicycle requested
        return results.filter { journey ->
            if (filterOptions.stepFreeOnly && !journey.isStepFreeAccessible) false
            else if (filterOptions.withBicycle && !journey.bikeAllowed) false
            else true
        }.sortedBy { it.totalDurationMinutes }
    }

    private fun findDirectMetroLine(from: String, to: String): String? {
        val fromLines = CopenhagenNetworkData.STATIONS_MAP[from]?.servingLines ?: emptyList()
        val toLines = CopenhagenNetworkData.STATIONS_MAP[to]?.servingLines ?: emptyList()

        val commonMetro = fromLines.intersect(toLines.toSet()).filter { it.startsWith("M") }
        return commonMetro.firstOrNull()
    }

    private fun calculateEstimatedMinutes(from: String, to: String, line: String): Int {
        val list = when (line) {
            "M1" -> CopenhagenNetworkData.M1_STATION_NAMES
            "M2" -> CopenhagenNetworkData.M2_STATION_NAMES
            "M3" -> CopenhagenNetworkData.M3_STATION_NAMES
            "M4" -> CopenhagenNetworkData.M4_STATION_NAMES
            else -> emptyList()
        }
        val i1 = list.indexOf(from)
        val i2 = list.indexOf(to)
        if (i1 != -1 && i2 != -1) {
            val dist = Math.abs(i1 - i2)
            return (dist * 2).coerceAtLeast(3)
        }
        return 12
    }

    private fun getIntermediateStopCount(from: String, to: String, line: String): Int {
        val list = when (line) {
            "M1" -> CopenhagenNetworkData.M1_STATION_NAMES
            "M2" -> CopenhagenNetworkData.M2_STATION_NAMES
            "M3" -> CopenhagenNetworkData.M3_STATION_NAMES
            "M4" -> CopenhagenNetworkData.M4_STATION_NAMES
            else -> emptyList()
        }
        val i1 = list.indexOf(from)
        val i2 = list.indexOf(to)
        return if (i1 != -1 && i2 != -1) (Math.abs(i1 - i2) - 1).coerceAtLeast(0) else 2
    }

    private fun getRouteColor(line: String): String {
        return when (line) {
            "M1" -> "#00843D"
            "M2" -> "#F2A900"
            "M3" -> "#C8102E"
            "M4" -> "#00A3E0"
            else -> "#005587"
        }
    }

    private fun getPlatform(station: String, line: String): String {
        return when (line) {
            "M3", "M4" -> "Spor 1 (M3/M4)"
            "M1", "M2" -> "Spor 2 (M1/M2)"
            else -> "Spor 1"
        }
    }

    fun calculateZones(originZone: Int, destinationZone: Int): List<Int> {
        val minZone = Math.min(originZone, destinationZone)
        val maxZone = Math.max(originZone, destinationZone)
        return (minZone..maxZone).toList().ifEmpty { listOf(1, 2) }
    }

    fun calculatePrice(zoneCount: Int): Int {
        return when (zoneCount) {
            1, 2 -> 24
            3 -> 36
            4 -> 48
            else -> 60
        }
    }

    private fun formatTimePlusMinutes(timeStr: String, minsToAdd: Int): String {
        val parts = timeStr.split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: 14
        val m = parts.getOrNull(1)?.toIntOrNull() ?: 0

        val totalM = h * 60 + m + minsToAdd
        val newH = (totalM / 60) % 24
        val newM = totalM % 60
        return String.format("%02d:%02d", newH, newM)
    }
}
