package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Attractions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.Screen
import com.example.copenhagenmetro.ui.components.LineBadge
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.CoolGrey
import com.example.ui.theme.DanishRed
import com.example.ui.theme.MutedText

data class TouristSpot(
    val name: String,
    val nearestStation: String,
    val lineCode: String,
    val description: String
)

val COPENHAGEN_SPOTS = listOf(
    TouristSpot("Nyhavn", "Kongens Nytorv", "M1/M2/M3/M4", "Historic harbour houses, restaurants & canal tours"),
    TouristSpot("Tivoli Gardens", "København H", "M3/M4", "World famous amusement park in city center"),
    TouristSpot("The Little Mermaid", "Østerport", "M3/M4", "Iconic bronze statue by Langelinie promenade"),
    TouristSpot("Reffen Street Food", "Refshaleøen", "HB_991", "Waterfront street food hub via Harbour Bus 991"),
    TouristSpot("Freetown Christiania", "Christianshavn", "M1/M2", "Unique autonomous borough & green ramparts"),
    TouristSpot("DR Koncerthuset", "DR Byen", "M1", "Architectural concert hall designed by Jean Nouvel"),
    TouristSpot("Louisiana Museum", "Humlebæk (RE)", "RE", "World-renowned modern art museum on the coast")
)

@Composable
fun VisitorTouristScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onNavigate: (Screen) -> Unit
) {
    val isDanish = uiState.isDanishLanguage

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = if (isDanish) "BESØGS- & SEVÆRDIGHEDSGUIDE" else "VISITOR & TOURIST GUIDE",
            subtitle = if (isDanish) "Find Metroen til Københavns Højdepunkter" else "Metro Transport to Top Landmarks",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(COPENHAGEN_SPOTS) { spot ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("tourist_spot_card_${spot.name}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = spot.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            LineBadge(spot.lineCode)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = spot.description, fontSize = 12.sp, color = MutedText)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Nærmeste station: ${spot.nearestStation}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                viewModel.setDestination(spot.nearestStation)
                                viewModel.planJourney()
                                onNavigate(Screen.JOURNEY_PLANNER)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DanishRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("route_to_spot_btn_${spot.name}")
                        ) {
                            Text(if (isDanish) "FIND RUTE HERTIL" else "ROUTE HERE")
                        }
                    }
                }
            }
        }
    }
}
