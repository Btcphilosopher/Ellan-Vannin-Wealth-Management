package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.Screen
import com.example.copenhagenmetro.ui.components.LineBadge
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.CoolGrey
import com.example.ui.theme.DanishRed
import com.example.ui.theme.LiveGreen
import com.example.ui.theme.MutedText

@Composable
fun CommuteModeScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onNavigate: (Screen) -> Unit
) {
    val isDanish = uiState.isDanishLanguage

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = if (isDanish) "PENDLERMODE" else "COMMUTE MODE",
            subtitle = if (isDanish) "Hjem ↔ Arbejde Hurtigrute" else "Home ↔ Work Instant Route",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Morning Commute Card (Home -> Work)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth().testTag("morning_commute_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Home, contentDescription = null, tint = DanishRed)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Nørrebro → Kongens Nytorv", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                        }
                        LineBadge("M3")
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isDanish) "Næste afgang om 3 min (M3 Yderring mod Østerport)" else "Next departure in 3 min (M3 Counterclockwise via Østerport)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiveGreen
                    )
                    Text(
                        text = "Ankomst kl. 08:41 (Samlet rejsetid: 10 min)",
                        fontSize = 12.sp,
                        color = MutedText
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.setOrigin("Nørrebro")
                            viewModel.setDestination("Kongens Nytorv")
                            viewModel.planJourney()
                            onNavigate(Screen.JOURNEY_PLANNER)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DanishRed),
                        modifier = Modifier.fillMaxWidth().testTag("start_morning_commute_btn")
                    ) {
                        Text(if (isDanish) "START MORGENPENDLE" else "START MORNING COMMUTE")
                    }
                }
            }

            // Evening Commute Card (Work -> Home)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth().testTag("evening_commute_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Work, contentDescription = null, tint = DanishRed)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Kongens Nytorv → Nørrebro", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                        }
                        LineBadge("M3")
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isDanish) "Næste afgang om 2 min (M3 Inderring mod Nørrebro)" else "Next departure in 2 min (M3 Clockwise via Nørrebro)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiveGreen
                    )
                    Text(
                        text = "Ankomst kl. 16:42 (Samlet rejsetid: 10 min)",
                        fontSize = 12.sp,
                        color = MutedText
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.setOrigin("Kongens Nytorv")
                            viewModel.setDestination("Nørrebro")
                            viewModel.planJourney()
                            onNavigate(Screen.JOURNEY_PLANNER)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DanishRed),
                        modifier = Modifier.fillMaxWidth().testTag("start_evening_commute_btn")
                    ) {
                        Text(if (isDanish) "START AFTENPENDLE" else "START EVENING COMMUTE")
                    }
                }
            }
        }
    }
}
