package com.example.copenhagenmetro.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CopenhagenDao {

    // Saved Places
    @Query("SELECT * FROM saved_places")
    fun getAllSavedPlaces(): Flow<List<SavedPlaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedPlace(place: SavedPlaceEntity)

    @Delete
    suspend fun deleteSavedPlace(place: SavedPlaceEntity)

    // Favourite Departures
    @Query("SELECT * FROM favourite_departures")
    fun getFavouriteDepartures(): Flow<List<FavouriteDepartureEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavouriteDeparture(favourite: FavouriteDepartureEntity)

    @Query("DELETE FROM favourite_departures WHERE id = :id")
    suspend fun deleteFavouriteDeparture(id: String)

    // Tickets
    @Query("SELECT * FROM active_tickets ORDER BY expiryTimestamp DESC")
    fun getActiveTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    // Journey History
    @Query("SELECT * FROM journey_history ORDER BY timestamp DESC LIMIT 20")
    fun getJourneyHistory(): Flow<List<JourneyHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourneyHistory(journey: JourneyHistoryEntity)
}
