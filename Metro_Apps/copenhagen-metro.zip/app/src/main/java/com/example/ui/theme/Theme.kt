package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = DanishRed,
    onPrimary = CleanWhite,
    primaryContainer = CoolGrey,
    onPrimaryContainer = Charcoal,
    secondary = RegionalBlue,
    onSecondary = CleanWhite,
    background = OffWhite,
    onBackground = Charcoal,
    surface = CleanWhite,
    onSurface = Charcoal,
    surfaceVariant = CoolGrey,
    onSurfaceVariant = MutedText,
    outline = Color(0xFFD1D1D6)
)

private val DarkColorScheme = darkColorScheme(
    primary = DanishRed,
    onPrimary = CleanWhite,
    primaryContainer = Color(0xFF2C2C2E),
    onPrimaryContainer = CleanWhite,
    secondary = MetroM4Blue,
    onSecondary = CleanWhite,
    background = Color(0xFF121212),
    onBackground = CleanWhite,
    surface = Color(0xFF1C1C1E),
    onSurface = CleanWhite,
    surfaceVariant = Color(0xFF2C2C2E),
    onSurfaceVariant = Color(0xFFA1A1A6),
    outline = Color(0xFF3A3A3C)
)

@Composable
fun CopenhagenMetroTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
