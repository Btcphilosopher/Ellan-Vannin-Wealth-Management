package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.data.mock.CopenhagenNetworkData
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.components.LineBadge
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.*

@Composable
fun MapScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onBack: () -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    var activeTab by remember { mutableStateOf(0) } // 0: Geographic, 1: Schematic Line Diagram
    var filterMode by remember { mutableStateOf("ALL") } // ALL, METRO, STOG, RAIL, HARBOUR

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = if (isDanish) "KØBENHAVNS TRANSPORTKORT" else "COPENHAGEN TRANSPORT MAP",
            subtitle = if (activeTab == 0) "Geografisk Netværkskort" else "Schematisk Linjediagram",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        // Tab Selector
        TabRow(selectedTabIndex = activeTab, modifier = Modifier.fillMaxWidth()) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text(if (isDanish) "Geografisk Kort" else "Geographic Map") }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text(if (isDanish) "Schematisk Diagram" else "Schematic Diagram") }
            )
        }

        // Layer Filter Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filterMode == "ALL",
                onClick = { filterMode = "ALL" },
                label = { Text("Alle Linjer") }
            )
            FilterChip(
                selected = filterMode == "METRO",
                onClick = { filterMode = "METRO" },
                label = { Text("🚇 Metro (M1-M4)") }
            )
            FilterChip(
                selected = filterMode == "STOG",
                onClick = { filterMode = "STOG" },
                label = { Text("🚆 S-tog") }
            )
            FilterChip(
                selected = filterMode == "HARBOUR",
                onClick = { filterMode = "HARBOUR" },
                label = { Text("🚢 Havnebus") }
            )
        }

        // Canvas Map Render Area
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .testTag("transport_map_canvas_box")
        ) {
            if (activeTab == 0) {
                GeographicTransportMapCanvas(filterMode = filterMode)
            } else {
                SchematicTransportDiagramCanvas(filterMode = filterMode)
            }

            // Legend Overlay Card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LineBadge("M1")
                    LineBadge("M2")
                    LineBadge("M3")
                    LineBadge("M4")
                    LineBadge("S-A")
                }
            }
        }
    }
}

@Composable
fun GeographicTransportMapCanvas(filterMode: String) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.8f, 3.0f)
                    offset += pan
                }
            }
    ) {
        val width = size.width
        val height = size.height

        val minLat = 55.61
        val maxLat = 55.71
        val minLon = 12.48
        val maxLon = 12.66

        fun toOffset(lat: Double, lon: Double): Offset {
            val x = ((lon - minLon) / (maxLon - minLon) * width).toFloat()
            val y = ((maxLat - lat) / (maxLat - minLat) * height).toFloat()
            return Offset(x * scale + offset.x, y * scale + offset.y)
        }

        // Draw Water backdrop (Øresund / Harbour)
        drawCircle(color = Color(0xFFE3F2FD), radius = width * 0.6f, center = Offset(width * 0.9f, height * 0.4f))

        // 1. Draw M1 Line
        if (filterMode == "ALL" || filterMode == "METRO") {
            val m1Points = CopenhagenNetworkData.M1_STATION_NAMES.mapNotNull {
                CopenhagenNetworkData.STATIONS_MAP[it]
            }.map { toOffset(it.latitude, it.longitude) }

            val pathM1 = Path()
            m1Points.forEachIndexed { i, pt ->
                if (i == 0) pathM1.moveTo(pt.x, pt.y) else pathM1.lineTo(pt.x, pt.y)
            }
            drawPath(pathM1, color = MetroM1Green, style = Stroke(width = 10f * scale))
        }

        // 2. Draw M2 Line
        if (filterMode == "ALL" || filterMode == "METRO") {
            val m2Points = CopenhagenNetworkData.M2_STATION_NAMES.mapNotNull {
                CopenhagenNetworkData.STATIONS_MAP[it]
            }.map { toOffset(it.latitude, it.longitude) }

            val pathM2 = Path()
            m2Points.forEachIndexed { i, pt ->
                if (i == 0) pathM2.moveTo(pt.x, pt.y) else pathM2.lineTo(pt.x, pt.y)
            }
            drawPath(pathM2, color = MetroM2Yellow, style = Stroke(width = 10f * scale))
        }

        // 3. Draw M3 Cityringen Circle
        if (filterMode == "ALL" || filterMode == "METRO") {
            val m3Points = CopenhagenNetworkData.M3_STATION_NAMES.mapNotNull {
                CopenhagenNetworkData.STATIONS_MAP[it]
            }.map { toOffset(it.latitude, it.longitude) }

            val pathM3 = Path()
            m3Points.forEachIndexed { i, pt ->
                if (i == 0) pathM3.moveTo(pt.x, pt.y) else pathM3.lineTo(pt.x, pt.y)
            }
            if (m3Points.isNotEmpty()) pathM3.close()
            drawPath(pathM3, color = MetroM3Red, style = Stroke(width = 10f * scale))
        }

        // 4. Draw M4 Line
        if (filterMode == "ALL" || filterMode == "METRO") {
            val m4Points = CopenhagenNetworkData.M4_STATION_NAMES.mapNotNull {
                CopenhagenNetworkData.STATIONS_MAP[it]
            }.map { toOffset(it.latitude, it.longitude) }

            val pathM4 = Path()
            m4Points.forEachIndexed { i, pt ->
                if (i == 0) pathM4.moveTo(pt.x, pt.y) else pathM4.lineTo(pt.x, pt.y)
            }
            drawPath(pathM4, color = MetroM4Blue, style = Stroke(width = 10f * scale))
        }

        // 5. Draw Station Dots
        CopenhagenNetworkData.getAllStationsList().forEach { station ->
            val pt = toOffset(station.latitude, station.longitude)
            drawCircle(
                color = if (station.isMajorHub) DanishRed else Color.White,
                radius = if (station.isMajorHub) 8f * scale else 5f * scale,
                center = pt
            )
            drawCircle(
                color = Charcoal,
                radius = if (station.isMajorHub) 8f * scale else 5f * scale,
                center = pt,
                style = Stroke(width = 2f)
            )
        }
    }
}

@Composable
fun SchematicTransportDiagramCanvas(filterMode: String) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // M3 Loop Schematic Center Circle
        val center = Offset(w * 0.5f, h * 0.45f)
        val radius = w * 0.32f

        // Draw M3 Ring
        drawCircle(
            color = MetroM3Red,
            radius = radius,
            center = center,
            style = Stroke(width = 16f)
        )

        // Draw M1/M2 Diagonal Spine (Vanløse -> Christianshavn -> Ørestad/Lufthavnen)
        drawLine(
            color = MetroM1Green,
            start = Offset(w * 0.1f, h * 0.15f),
            end = Offset(w * 0.85f, h * 0.85f),
            strokeWidth = 14f
        )
        drawLine(
            color = MetroM2Yellow,
            start = Offset(w * 0.1f, h * 0.15f),
            end = Offset(w * 0.9f, h * 0.7f),
            strokeWidth = 14f
        )

        // Draw M4 North-South Spine
        drawLine(
            color = MetroM4Blue,
            start = Offset(w * 0.7f, h * 0.1f),
            end = Offset(w * 0.3f, h * 0.85f),
            strokeWidth = 14f
        )

        // Major Interchange Nodes
        listOf(
            Offset(w * 0.5f, h * 0.45f - radius) to "Østerport",
            Offset(w * 0.5f + radius, h * 0.45f) to "Kongens Nytorv",
            Offset(w * 0.5f, h * 0.45f + radius) to "København H",
            Offset(w * 0.5f - radius, h * 0.45f) to "Frederiksberg"
        ).forEach { (pos, name) ->
            drawCircle(color = Color.White, radius = 12f, center = pos)
            drawCircle(color = Charcoal, radius = 12f, center = pos, style = Stroke(width = 4f))
        }
    }
}
