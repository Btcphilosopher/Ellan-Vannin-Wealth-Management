package com.example.copenhagenmetro.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.copenhagenmetro.data.database.CopenhagenDatabase
import com.example.copenhagenmetro.data.database.TicketEntity
import com.example.copenhagenmetro.data.repository.TransportRepository
import com.example.copenhagenmetro.domain.model.*
import com.example.copenhagenmetro.routing.JourneyFilterOptions
import com.example.copenhagenmetro.routing.M3CircleResult
import com.example.copenhagenmetro.simulator.SimulationScenario
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Screen {
    HOME,
    JOURNEY_PLANNER,
    LIVE_DEPARTURES,
    STATION_DETAIL,
    KOBENHAVN_H,
    AIRPORT_MODE,
    MAP,
    M3_CIRCLE_MAP,
    TICKETS_REJSEKORT,
    SERVICE_STATUS,
    SIMULATOR_OPERATIONS,
    VISITOR_TOURIST,
    COMMUTE_MODE
}

data class UiState(
    val currentScreen: Screen = Screen.HOME,
    val isDanishLanguage: Boolean = true,
    val originInput: String = "Nørreport",
    val destinationInput: String = "Lufthavnen",
    val selectedStationName: String = "Nørreport",
    val journeyResults: List<Journey> = emptyList(),
    val m3CircleResult: M3CircleResult? = null,
    val activeFilterOptions: JourneyFilterOptions = JourneyFilterOptions(),
    val activeScenario: SimulationScenario = SimulationScenario.NORMAL_DAY,
    val isRejsekortCheckedIn: Boolean = false,
    val rejsekortCheckInStation: String? = null,
    val rejsekortCheckInTime: String? = null,
    val searchQuery: String = "",
    val activeTabMap: Int = 0 // 0: Geographic, 1: Schematic Line Diagram, 2: M3 Circle Loop
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = CopenhagenDatabase.getDatabase(application)
    val repository = TransportRepository(db.copenhagenDao())

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    val savedPlaces = repository.savedPlaces.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val favouriteDepartures = repository.favouriteDepartures.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val activeTickets = repository.activeTickets.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    init {
        // Run initial journey planning for default query
        planJourney()

        viewModelScope.launch {
            repository.getActiveScenario().collect { scenario ->
                _uiState.update { it.copy(activeScenario = scenario) }
            }
        }
    }

    fun navigateTo(screen: Screen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun toggleLanguage() {
        _uiState.update { it.copy(isDanishLanguage = !it.isDanishLanguage) }
    }

    fun setOrigin(origin: String) {
        _uiState.update { it.copy(originInput = origin) }
    }

    fun setDestination(destination: String) {
        _uiState.update { it.copy(destinationInput = destination) }
    }

    fun swapOriginDestination() {
        _uiState.update {
            it.copy(originInput = it.destinationInput, destinationInput = it.originInput)
        }
        planJourney()
    }

    fun selectStation(stationName: String) {
        _uiState.update {
            it.copy(selectedStationName = stationName, currentScreen = Screen.STATION_DETAIL)
        }
    }

    fun planJourney() {
        val origin = _uiState.value.originInput
        val dest = _uiState.value.destinationInput
        val filters = _uiState.value.activeFilterOptions

        val journeys = repository.planJourney(origin, dest, filters)
        val m3Result = repository.calculateM3Route(origin, dest)

        _uiState.update {
            it.copy(
                journeyResults = journeys,
                m3CircleResult = m3Result
            )
        }
    }

    fun updateFilters(filters: JourneyFilterOptions) {
        _uiState.update { it.copy(activeFilterOptions = filters) }
        planJourney()
    }

    fun setSimulationScenario(scenario: SimulationScenario) {
        repository.setSimulationScenario(scenario)
    }

    fun toggleRejsekortCheckIn(stationName: String = "Nørreport") {
        val currentCheckedIn = _uiState.value.isRejsekortCheckedIn
        if (!currentCheckedIn) {
            val nowStr = "14:15"
            _uiState.update {
                it.copy(
                    isRejsekortCheckedIn = true,
                    rejsekortCheckInStation = stationName,
                    rejsekortCheckInTime = nowStr
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    isRejsekortCheckedIn = false,
                    rejsekortCheckInStation = null,
                    rejsekortCheckInTime = null
                )
            }
        }
    }

    fun buyTicket(productName: String, price: Double) {
        viewModelScope.launch {
            repository.purchaseTicket(productName, price)
        }
    }

    fun toggleFavouriteDeparture(stationId: String, stationName: String, lineCode: String, dest: String) {
        viewModelScope.launch {
            val id = "${stationId}_${lineCode}"
            val existing = favouriteDepartures.value.find { it.id == id }
            if (existing != null) {
                repository.removeFavouriteDeparture(id)
            } else {
                repository.addFavouriteDeparture(id, stationId, stationName, lineCode, dest)
            }
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setMapTab(tabIndex: Int) {
        _uiState.update { it.copy(activeTabMap = tabIndex) }
    }
}
