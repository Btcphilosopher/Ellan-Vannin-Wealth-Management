package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.copenhagenmetro.domain.model.TransportDeparture
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.Screen
import com.example.copenhagenmetro.ui.components.LineBadge
import com.example.copenhagenmetro.ui.components.DepartureRowItem
import com.example.copenhagenmetro.ui.components.RealtimeStateBadge
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onNavigate: (Screen) -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    val nextDepartures = viewModel.repository.getDeparturesForStation(uiState.selectedStationName)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = "COPENHAGEN METRO",
            subtitle = if (isDanish) "Københavns Metronet & Transport" else "Copenhagen Metro Network",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() },
            onNotificationClick = { onNavigate(Screen.SERVICE_STATUS) }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // Hero City Banner Graphic
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .testTag("hero_banner_card")
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Image(
                            painter = painterResource(id = R.drawable.cph_banner_1793103621011),
                            contentDescription = "Copenhagen Cityscape",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.25f))
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = if (isDanish) "KØBENHAVN METRO" else "COPENHAGEN METRO",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = if (isDanish) "Dansk Funktionelt Transportnet" else "Danish Unified Transport Platform",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Where are you going? Search Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("journey_search_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isDanish) "Hvor vil du hen?" else "Where are you going?",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Origin Field
                        OutlinedTextField(
                            value = uiState.originInput,
                            onValueChange = { viewModel.setOrigin(it) },
                            label = { Text(if (isDanish) "Fra (Afgangsstation)" else "From") },
                            leadingIcon = { Icon(Icons.Default.TripOrigin, contentDescription = null, tint = DanishRed) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("origin_input_field")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Destination Field
                        OutlinedTextField(
                            value = uiState.destinationInput,
                            onValueChange = { viewModel.setDestination(it) },
                            label = { Text(if (isDanish) "Til (Destination)" else "To") },
                            leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = RegionalBlue) },
                            trailingIcon = {
                                IconButton(onClick = { viewModel.swapOriginDestination() }) {
                                    Icon(Icons.Default.SwapVert, contentDescription = "Swap")
                                }
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("destination_input_field")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                viewModel.planJourney()
                                onNavigate(Screen.JOURNEY_PLANNER)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DanishRed),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("plan_journey_btn")
                        ) {
                            Text(
                                text = if (isDanish) "FIND REJSE" else "FIND ROUTE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null)
                        }
                    }
                }
            }

            // Quick Navigation Hub
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    QuickActionChip(
                        icon = Icons.Default.FlightTakeoff,
                        label = "Airport / CPH",
                        onClick = { onNavigate(Screen.AIRPORT_MODE) },
                        badgeColor = MetroM2Yellow
                    )
                    QuickActionChip(
                        icon = Icons.Default.DirectionsTransit,
                        label = "M3 Loop",
                        onClick = { onNavigate(Screen.M3_CIRCLE_MAP) },
                        badgeColor = MetroM3Red
                    )
                    QuickActionChip(
                        icon = Icons.Default.Map,
                        label = if (isDanish) "Kort" else "Map",
                        onClick = { onNavigate(Screen.MAP) },
                        badgeColor = MetroM4Blue
                    )
                    QuickActionChip(
                        icon = Icons.Default.ConfirmationNumber,
                        label = if (isDanish) "Billet" else "Tickets",
                        onClick = { onNavigate(Screen.TICKETS_REJSEKORT) },
                        badgeColor = STrainRed
                    )
                }
            }

            // Live Departures snippet
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Schedule, contentDescription = null, tint = DanishRed)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${if (isDanish) "NæSTE AFGANGE" else "NEXT DEPARTURES"}: ${uiState.selectedStationName.uppercase()}",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            TextTextButton(
                                text = if (isDanish) "Se alle" else "See all",
                                onClick = { onNavigate(Screen.LIVE_DEPARTURES) }
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        nextDepartures.take(4).forEach { departure ->
                            DepartureRowItem(departure = departure, onClick = {
                                viewModel.selectStation(uiState.selectedStationName)
                            })
                            HorizontalDivider(color = CoolGrey.copy(alpha = 0.5f))
                        }
                    }
                }
            }

            // MY PLACES
            item {
                Text(
                    text = if (isDanish) "MINE STEDER" else "MY PLACES",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PlaceChip(
                        icon = Icons.Default.Home,
                        title = if (isDanish) "Hjem" else "Home",
                        station = "Nørrebro",
                        onClick = {
                            viewModel.setDestination("Nørrebro")
                            viewModel.planJourney()
                            onNavigate(Screen.JOURNEY_PLANNER)
                        }
                    )
                    PlaceChip(
                        icon = Icons.Default.Work,
                        title = if (isDanish) "Arbejde" else "Work",
                        station = "Kongens Nytorv",
                        onClick = {
                            viewModel.setDestination("Kongens Nytorv")
                            viewModel.planJourney()
                            onNavigate(Screen.JOURNEY_PLANNER)
                        }
                    )
                    PlaceChip(
                        icon = Icons.Default.Train,
                        title = "København H",
                        station = "København H",
                        onClick = { onNavigate(Screen.KOBENHAVN_H) }
                    )
                    PlaceChip(
                        icon = Icons.Default.LocalAirport,
                        title = if (isDanish) "Lufthavn" else "Airport",
                        station = "Lufthavnen",
                        onClick = { onNavigate(Screen.AIRPORT_MODE) }
                    )
                }
            }

            // NETWORK SERVICE STATUS CARD
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = LiveGreen.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate(Screen.SERVICE_STATUS) }
                        .testTag("network_status_card")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(LiveGreen)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isDanish) "DRIFTSTATUS: NORMAL DRIFT" else "SERVICE STATUS: NORMAL",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isDanish) "M1, M2, M3, M4, S-tog og busser kører efter planen" else "M1, M2, M3, M4, S-trains & buses operating normally",
                                fontSize = 11.sp,
                                color = MutedText
                            )
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MutedText)
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    badgeColor: Color
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .width(80.dp)
            .height(72.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PlaceChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    station: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, CoolGrey)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = DanishRed)
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TextTextButton(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        color = DanishRed,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = Modifier.clickable(onClick = onClick)
    )
}
