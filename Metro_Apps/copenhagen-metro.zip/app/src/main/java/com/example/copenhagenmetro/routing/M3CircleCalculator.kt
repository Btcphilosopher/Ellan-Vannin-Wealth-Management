package com.example.copenhagenmetro.routing

import com.example.copenhagenmetro.data.mock.CopenhagenNetworkData
import com.example.copenhagenmetro.domain.model.M3Direction

data class M3CircleResult(
    val fromStation: String,
    val toStation: String,
    val clockwiseStops: Int,
    val counterClockwiseStops: Int,
    val clockwiseMinutes: Int,
    val counterClockwiseMinutes: Int,
    val bestDirection: M3Direction,
    val bestMinutes: Int,
    val recommendationMessageDa: String,
    val recommendationMessageEn: String
)

object M3CircleCalculator {

    private val m3Stations = CopenhagenNetworkData.M3_STATION_NAMES
    private val totalStations = m3Stations.size // 17

    fun calculateM3Route(fromStation: String, toStation: String): M3CircleResult? {
        val fromIdx = m3Stations.indexOfFirst { it.equals(fromStation, ignoreCase = true) }
        val toIdx = m3Stations.indexOfFirst { it.equals(toStation, ignoreCase = true) }

        if (fromIdx == -1 || toIdx == -1 || fromIdx == toIdx) {
            return null
        }

        // Clockwise moves forward in list: (toIdx - fromIdx + total) % total
        val clockwiseStops = (toIdx - fromIdx + totalStations) % totalStations

        // Counterclockwise moves backward in list: (fromIdx - toIdx + total) % total
        val counterClockwiseStops = (fromIdx - toIdx + totalStations) % totalStations

        // Average dwell + tunnel time per stop is approx 1.4 minutes
        val clockwiseMinutes = (clockwiseStops * 1.4 + 0.5).toInt().coerceAtLeast(1)
        val counterClockwiseMinutes = (counterClockwiseStops * 1.4 + 0.5).toInt().coerceAtLeast(1)

        val bestDirection = if (clockwiseStops <= counterClockwiseStops) {
            M3Direction.CLOCKWISE
        } else {
            M3Direction.COUNTERCLOCKWISE
        }

        val bestMinutes = if (bestDirection == M3Direction.CLOCKWISE) clockwiseMinutes else counterClockwiseMinutes

        val dirLabelDa = if (bestDirection == M3Direction.CLOCKWISE) "Inderring (Med uret)" else "Yderring (Mod uret)"
        val dirLabelEn = if (bestDirection == M3Direction.CLOCKWISE) "Clockwise" else "Counterclockwise"

        val msgDa = "Vælg $dirLabelDa: $bestMinutes min ($clockwiseStops vs $counterClockwiseStops stop)"
        val msgEn = "Take $dirLabelEn: $bestMinutes min ($bestMinutes min vs ${if (bestDirection == M3Direction.CLOCKWISE) counterClockwiseMinutes else clockwiseMinutes} min)"

        return M3CircleResult(
            fromStation = m3Stations[fromIdx],
            toStation = m3Stations[toIdx],
            clockwiseStops = clockwiseStops,
            counterClockwiseStops = counterClockwiseStops,
            clockwiseMinutes = clockwiseMinutes,
            counterClockwiseMinutes = counterClockwiseMinutes,
            bestDirection = bestDirection,
            bestMinutes = bestMinutes,
            recommendationMessageDa = msgDa,
            recommendationMessageEn = msgEn
        )
    }
}
