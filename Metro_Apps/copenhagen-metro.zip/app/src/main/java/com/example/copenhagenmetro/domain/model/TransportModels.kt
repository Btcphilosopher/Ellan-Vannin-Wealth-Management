package com.example.copenhagenmetro.domain.model

import java.util.UUID

enum class TransportMode(val displayNameDa: String, val displayNameEn: String) {
    METRO("Metro", "Metro"),
    S_TOG("S-tog", "S-Train"),
    REGIONAL_RAIL("Regionaltog", "Regional Rail"),
    INTERCITY("InterCity", "InterCity Rail"),
    BUS("Bybus", "City Bus"),
    REGIONAL_BUS("Rutebil", "Regional Bus"),
    HARBOUR_BUS("Havnebus", "Harbour Bus"),
    LIGHT_RAIL("Letbane", "Light Rail"),
    WALKING("Gang", "Walking"),
    CYCLING("Cykling", "Cycling")
}

enum class RealtimeState {
    SCHEDULED, ESTIMATED, LIVE, CANCELLED
}

enum class M3Direction(val labelDa: String, val labelEn: String) {
    CLOCKWISE("Inderring (Med uret)", "Clockwise"),
    COUNTERCLOCKWISE("Yderring (Mod uret)", "Counterclockwise")
}

data class TransportAgency(
    val id: String,
    val name: String,
    val mode: TransportMode,
    val websiteUrl: String = "https://dinoffentligetransport.dk"
)

data class TransportRoute(
    val id: String,
    val agencyId: String,
    val shortName: String,
    val longName: String,
    val mode: TransportMode,
    val colorHex: String,
    val textColorHex: String = "#FFFFFF",
    val isCircular: Boolean = false
)

data class StationFacility(
    val hasElevator: Boolean = true,
    val hasEscalator: Boolean = true,
    val isStepFree: Boolean = true,
    val hasBikeParking: Boolean = true,
    val hasTicketMachine: Boolean = true,
    val hasToilets: Boolean = false,
    val isElevatorInService: Boolean = true
)

data class TransportStation(
    val id: String,
    val name: String,
    val zoneId: Int,
    val latitude: Double,
    val longitude: Double,
    val servingLines: List<String>,
    val facilities: StationFacility = StationFacility(),
    val isAirport: Boolean = false,
    val isMajorHub: Boolean = false,
    val description: String = ""
)

data class TransportDeparture(
    val id: String = UUID.randomUUID().toString(),
    val routeId: String,
    val lineCode: String,
    val lineColorHex: String,
    val destinationName: String,
    val scheduledTimeMinutes: Int, // minutes from midnight or relative
    val relativeMinutes: Int,
    val realtimeState: RealtimeState = RealtimeState.LIVE,
    val platform: String,
    val directionLabel: String = "",
    val m3Direction: M3Direction? = null,
    val delayMinutes: Int = 0
)

data class JourneyLeg(
    val id: String = UUID.randomUUID().toString(),
    val mode: TransportMode,
    val routeCode: String,
    val routeColorHex: String,
    val fromStationName: String,
    val toStationName: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val intermediateStopsCount: Int,
    val platform: String,
    val isTransfer: Boolean = false,
    val realtimeState: RealtimeState = RealtimeState.LIVE,
    val walkDistanceMeters: Int = 0,
    val m3DirectionNotice: String? = null
)

data class Journey(
    val id: String = UUID.randomUUID().toString(),
    val originStation: String,
    val destinationStation: String,
    val departureTimeFormatted: String,
    val arrivalTimeFormatted: String,
    val totalDurationMinutes: Int,
    val transfersCount: Int,
    val walkingMinutes: Int,
    val fareZones: List<Int>,
    val priceDkk: Int,
    val legs: List<JourneyLeg>,
    val isStepFreeAccessible: Boolean = true,
    val bikeAllowed: Boolean = true,
    val m3Recommendation: String? = null
)

enum class AlertSeverity {
    INFO, WARNING, CRITICAL
}

data class TransportAlert(
    val id: String,
    val severity: AlertSeverity,
    val titleDa: String,
    val titleEn: String,
    val descriptionDa: String,
    val descriptionEn: String,
    val affectedLines: List<String>,
    val affectedStations: List<String> = emptyList(),
    val timestampFormatted: String = "Lige nu"
)

data class FareProduct(
    val id: String,
    val nameDa: String,
    val nameEn: String,
    val priceDkk: Double,
    val validZonesDescription: String,
    val category: String
)

data class SavedPlace(
    val id: String,
    val name: String,
    val stationId: String,
    val iconName: String
)
