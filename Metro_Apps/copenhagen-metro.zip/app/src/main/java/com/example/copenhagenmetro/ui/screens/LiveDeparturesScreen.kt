package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.components.DepartureRowItem
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.CoolGrey

@Composable
fun LiveDeparturesScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onBack: () -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    val stations = viewModel.repository.getStations()
    var selectedStation by remember { mutableStateOf(uiState.selectedStationName) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredStations = stations.filter {
        it.name.contains(searchQuery, ignoreCase = true)
    }

    val departures = viewModel.repository.getDeparturesForStation(selectedStation)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = if (isDanish) "REALTIDSAFGANGETAVLE" else "LIVE DEPARTURE BOARD",
            subtitle = selectedStation,
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        Column(modifier = Modifier.padding(16.dp)) {
            // Station Search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(if (isDanish) "Søg station..." else "Search station...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("station_search_bar")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Station Quick Select Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(if (searchQuery.isNotEmpty()) filteredStations else stations.take(12)) { station ->
                    FilterChip(
                        selected = selectedStation == station.name,
                        onClick = {
                            selectedStation = station.name
                            viewModel.selectStation(station.name)
                        },
                        label = { Text(station.name, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Departures Board
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("departures_board_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "${selectedStation.uppercase()} - ${if (isDanish) "AFGANGETAVLE" else "DEPARTURES"}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (departures.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isDanish) "Ingen afgange fundet på denne station." else "No departures found for this station.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn {
                            items(departures) { departure ->
                                DepartureRowItem(departure = departure, onClick = {})
                                HorizontalDivider(color = CoolGrey.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
            }
        }
    }
}
