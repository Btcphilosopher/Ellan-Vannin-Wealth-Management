package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.components.DepartureRowItem
import com.example.copenhagenmetro.ui.components.LineBadge
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.CoolGrey
import com.example.ui.theme.DanishRed
import com.example.ui.theme.LiveGreen
import com.example.ui.theme.MutedText

@Composable
fun StationDetailScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onBack: () -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    val station = viewModel.repository.getStation(uiState.selectedStationName)
        ?: viewModel.repository.getStation("Nørreport")!!

    val departures = viewModel.repository.getDeparturesForStation(station.name)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = station.name.uppercase(),
            subtitle = "Zone ${station.zoneId} • ${if (isDanish) "Stationstop" else "Transit Hub"}",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Station Lines
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("station_lines_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isDanish) "LINJER PÅ STATIONEN" else "LINES SERVING STATION",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            station.servingLines.forEach { line ->
                                LineBadge(code = line)
                            }
                        }
                        if (station.description.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = station.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }

            // Accessibility & Facilities
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("station_facilities_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isDanish) "FACILITETER & TILGÆNGELIGHED" else "FACILITIES & ACCESSIBILITY",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            FacilityStatusItem(
                                icon = Icons.Default.Elevator,
                                label = if (isDanish) "Elevator" else "Elevator",
                                active = station.facilities.isElevatorInService
                            )
                            FacilityStatusItem(
                                icon = Icons.Default.Escalator,
                                label = if (isDanish) "Rulletrappe" else "Escalator",
                                active = station.facilities.hasEscalator
                            )
                            FacilityStatusItem(
                                icon = Icons.Default.Accessible,
                                label = if (isDanish) "Niveaufri" else "Step-free",
                                active = station.facilities.isStepFree
                            )
                            FacilityStatusItem(
                                icon = Icons.Default.PedalBike,
                                label = if (isDanish) "Cykler" else "Bikes",
                                active = station.facilities.hasBikeParking
                            )
                        }
                    }
                }
            }

            // Next Departures
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("station_departures_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isDanish) "NÆSTE AFGANGETAVLE" else "NEXT DEPARTURES",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        departures.forEach { departure ->
                            DepartureRowItem(departure = departure, onClick = {})
                            HorizontalDivider(color = CoolGrey.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FacilityStatusItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            icon,
            contentDescription = null,
            tint = if (active) LiveGreen else DanishRed,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (active) MaterialTheme.colorScheme.onSurface else DanishRed
        )
        Text(
            text = if (active) "OK" else "FEJL",
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (active) LiveGreen else DanishRed
        )
    }
}
