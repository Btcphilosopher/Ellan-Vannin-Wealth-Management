package com.example.copenhagenmetro.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SavedPlaceEntity::class,
        FavouriteDepartureEntity::class,
        TicketEntity::class,
        JourneyHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CopenhagenDatabase : RoomDatabase() {

    abstract fun copenhagenDao(): CopenhagenDao

    companion object {
        @Volatile
        private var INSTANCE: CopenhagenDatabase? = null

        fun getDatabase(context: Context): CopenhagenDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CopenhagenDatabase::class.java,
                    "copenhagen_metro_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
