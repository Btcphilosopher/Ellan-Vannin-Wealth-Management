package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.simulator.SimulationScenario
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.DanishRed
import com.example.ui.theme.MutedText

@Composable
fun OperationsSimulatorScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onBack: () -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    val activeScenario = uiState.activeScenario

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = "METRO OPERATIONS CONTROL",
            subtitle = if (isDanish) "Simulerings- & Styringscenter" else "Network Engineering Simulation Center",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Warning Banner
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DanishRed.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("simulation_warning_card")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Engineering, contentDescription = null, tint = DanishRed)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = "METRO SIMULATOR CONTROL", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(
                                text = if (isDanish) "Aktivér scenarier for at teste sanntidsafgange og ruteomlægninger."
                                else "Activate scenarios to test real-time headway shifts and route recalculations.",
                                fontSize = 11.sp,
                                color = MutedText
                            )
                        }
                    }
                }
            }

            // Scenario Selection List
            item {
                Text(
                    text = if (isDanish) "VÆLG SIMULERINGSSCENARIE" else "SELECT SIMULATION SCENARIO",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(6.dp))

                SimulationScenario.entries.forEach { scenario ->
                    val isSelected = activeScenario == scenario
                    Card(
                        onClick = { viewModel.setSimulationScenario(scenario) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) DanishRed.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, DanishRed) else null,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).testTag("scenario_btn_${scenario.name}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (isDanish) scenario.labelDa else scenario.labelEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = scenario.name,
                                    fontSize = 10.sp,
                                    color = MutedText
                                )
                            }
                            if (isSelected) {
                                Text("✔ AKTIV", fontWeight = FontWeight.ExtraBold, color = DanishRed, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
