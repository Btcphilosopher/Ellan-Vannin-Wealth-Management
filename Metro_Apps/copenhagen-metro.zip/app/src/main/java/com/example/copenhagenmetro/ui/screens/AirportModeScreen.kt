package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.Screen
import com.example.copenhagenmetro.ui.components.DepartureRowItem
import com.example.copenhagenmetro.ui.components.LineBadge
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.*

@Composable
fun AirportModeScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onNavigate: (Screen) -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    val departures = viewModel.repository.getDeparturesForStation("Lufthavnen")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = "COPENHAGEN AIRPORT",
            subtitle = if (isDanish) "CPH Lufthavnen Terminal 3 Integration" else "CPH Airport Direct Metro M2 Hub",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Fast Airport Express Banner
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MetroM2Yellow.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("airport_banner_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LineBadge("M2")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isDanish) "Metro M2 Direkte til Indre By" else "Metro M2 Direct to City Center",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isDanish) "Metroen afgår direkte for enden af Terminal 3 hvert 4. minut. 13 minutter til Kongens Nytorv."
                            else "Metro departs directly inside Terminal 3 every 4 minutes. Only 13 minutes to Kongens Nytorv.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Quick Routes from Airport
            item {
                Text(
                    text = if (isDanish) "HURTIGE RUTER FRA LUFTHAVNEN" else "EXPRESS ROUTES FROM AIRPORT",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AirportRouteButton(
                        destination = "Kongens Nytorv (City)",
                        line = "M2",
                        duration = "13 min",
                        transfers = "0 skift",
                        onClick = {
                            viewModel.setOrigin("Lufthavnen")
                            viewModel.setDestination("Kongens Nytorv")
                            viewModel.planJourney()
                            onNavigate(Screen.JOURNEY_PLANNER)
                        }
                    )
                    AirportRouteButton(
                        destination = "København H (Central)",
                        line = "RE",
                        duration = "13 min",
                        transfers = "0 skift (Regionaltog)",
                        onClick = {
                            viewModel.setOrigin("Lufthavnen")
                            viewModel.setDestination("København H")
                            viewModel.planJourney()
                            onNavigate(Screen.JOURNEY_PLANNER)
                        }
                    )
                    AirportRouteButton(
                        destination = "Nørrebro",
                        line = "M2 → M3",
                        duration = "22 min",
                        transfers = "1 skift (Kongens Nytorv)",
                        onClick = {
                            viewModel.setOrigin("Lufthavnen")
                            viewModel.setDestination("Nørrebro")
                            viewModel.planJourney()
                            onNavigate(Screen.JOURNEY_PLANNER)
                        }
                    )
                    AirportRouteButton(
                        destination = "Frederiksberg",
                        line = "M2",
                        duration = "20 min",
                        transfers = "0 skift",
                        onClick = {
                            viewModel.setOrigin("Lufthavnen")
                            viewModel.setDestination("Frederiksberg")
                            viewModel.planJourney()
                            onNavigate(Screen.JOURNEY_PLANNER)
                        }
                    )
                }
            }

            // Terminal Walking & Check-in Guidance
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isDanish) "TERMINAL GUDE & GANGTIDER" else "TERMINAL GUIDE & WALKING TIMES",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        WayfindingRow("Metro Station M2", "Terminal 3 (1. sal)", "0 min (I bygningen)")
                        WayfindingRow("Regionaltog (Spor 1/2)", "Terminal 3 (Understue)", "1 min gang")
                        WayfindingRow("Terminal 2 Baggage Drop", "Terminal 2", "4 min gang")
                        WayfindingRow("CPH Express Security", "Terminal 3", "2 min gang")
                    }
                }
            }

            // Next Departures from Airport
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("airport_departures_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isDanish) "AFGANGE FRA CPH LUFTHAVNEN" else "DEPARTURES FROM CPH AIRPORT",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        departures.forEach { departure ->
                            DepartureRowItem(departure = departure, onClick = {})
                            HorizontalDivider(color = CoolGrey.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AirportRouteButton(
    destination: String,
    line: String,
    duration: String,
    transfers: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, CoolGrey)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LineBadge(line)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = destination, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(text = transfers, fontSize = 11.sp, color = MutedText)
                }
            }
            Text(text = duration, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = DanishRed)
        }
    }
}
