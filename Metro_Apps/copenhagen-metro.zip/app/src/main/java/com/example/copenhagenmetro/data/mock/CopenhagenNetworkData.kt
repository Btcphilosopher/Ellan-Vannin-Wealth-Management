package com.example.copenhagenmetro.data.mock

import com.example.copenhagenmetro.domain.model.*

object CopenhagenNetworkData {

    // Lines & Routes
    val M1_ROUTE = TransportRoute(
        id = "M1",
        agencyId = "METRO",
        shortName = "M1",
        longName = "Vanløse - Vestamager",
        mode = TransportMode.METRO,
        colorHex = "#00843D" // Green
    )

    val M2_ROUTE = TransportRoute(
        id = "M2",
        agencyId = "METRO",
        shortName = "M2",
        longName = "Vanløse - Lufthavnen",
        mode = TransportMode.METRO,
        colorHex = "#F2A900" // Yellow
    )

    val M3_ROUTE = TransportRoute(
        id = "M3",
        agencyId = "METRO",
        shortName = "M3",
        longName = "Cityringen",
        mode = TransportMode.METRO,
        colorHex = "#C8102E", // Metro Crimson Red
        isCircular = true
    )

    val M4_ROUTE = TransportRoute(
        id = "M4",
        agencyId = "METRO",
        shortName = "M4",
        longName = "Orientkaj - København Syd",
        mode = TransportMode.METRO,
        colorHex = "#00A3E0" // Blue
    )

    val S_TOG_A = TransportRoute("S_A", "DSB", "A", "Hillerød - Hundige / Køge", TransportMode.S_TOG, "#E30613")
    val S_TOG_B = TransportRoute("S_B", "DSB", "B", "Farum - Høje Taastrup", TransportMode.S_TOG, "#E30613")
    val S_TOG_C = TransportRoute("S_C", "DSB", "C", "Klampenborg - Frederikssund", TransportMode.S_TOG, "#E30613")
    val S_TOG_F = TransportRoute("S_F", "DSB", "F", "Ryparken - København Syd (Ringbanen)", TransportMode.S_TOG, "#FFC72C", "#000000")

    val REGIONAL_RE = TransportRoute("RE_ZEALAND", "DSB", "RE", "København H - Roskilde - Odense / Ringsted", TransportMode.REGIONAL_RAIL, "#005587")
    val BUS_5C = TransportRoute("BUS_5C", "DOT", "5C", "Husum Torv - CPH Lufthavn", TransportMode.BUS, "#FFB300", "#000000")
    val BUS_1A = TransportRoute("BUS_1A", "DOT", "1A", "Hellerup - Avedøre Holme", TransportMode.BUS, "#E30613")
    val HARBOUR_BUS_991 = TransportRoute("HB_991", "DOT", "991", "Refshaleøen - Teglholmen", TransportMode.HARBOUR_BUS, "#003366")
    val LIGHT_RAIL_L1 = TransportRoute("L1", "LETBANE", "L1", "Ishøj - Lyngby", TransportMode.LIGHT_RAIL, "#FF6F00")

    val ALL_ROUTES = listOf(
        M1_ROUTE, M2_ROUTE, M3_ROUTE, M4_ROUTE,
        S_TOG_A, S_TOG_B, S_TOG_C, S_TOG_F,
        REGIONAL_RE, BUS_5C, BUS_1A, HARBOUR_BUS_991, LIGHT_RAIL_L1
    )

    // Order of M1 stations (15)
    val M1_STATION_NAMES = listOf(
        "Vanløse", "Flintholm", "Lindevang", "Fasanvej", "Frederiksberg",
        "Forum", "Nørreport", "Kongens Nytorv", "Christianshavn", "Islands Brygge",
        "DR Byen", "Sundby", "Bella Center", "Ørestad", "Vestamager"
    )

    // Order of M2 stations (16)
    val M2_STATION_NAMES = listOf(
        "Vanløse", "Flintholm", "Lindevang", "Fasanvej", "Frederiksberg",
        "Forum", "Nørreport", "Kongens Nytorv", "Christianshavn", "Amagerbro",
        "Lergravsparken", "Øresund", "Amager Strand", "Femøren", "Kastrup", "Lufthavnen"
    )

    // Order of M3 Cityringen stations (17 circular)
    val M3_STATION_NAMES = listOf(
        "København H", "Rådhuspladsen", "Gammel Strand", "Kongens Nytorv",
        "Marmorkirken", "Østerport", "Trianglen", "Poul Henningsens Plads",
        "Vibenshus Runddel", "Skjolds Plads", "Nørrebro", "Nørrebros Runddel",
        "Nuuks Plads", "Aksel Møllers Have", "Frederiksberg", "Frederiksberg Allé",
        "Enghave Plads"
    )

    // Order of M4 stations (12)
    val M4_STATION_NAMES = listOf(
        "Orientkaj", "Nordhavn", "Østerport", "Marmorkirken", "Kongens Nytorv",
        "Gammel Strand", "Rådhuspladsen", "København H", "Enghave Brygge",
        "Sluseholmen", "Mozarts Plads", "København Syd"
    )

    // Master list of all stations with geographic coordinates and zones
    val STATIONS_MAP = mapOf(
        "Vanløse" to TransportStation("vanlose", "Vanløse", 2, 55.6869, 12.4925, listOf("M1", "M2", "S_C", "S_H"), isMajorHub = true),
        "Flintholm" to TransportStation("flintholm", "Flintholm", 2, 55.6861, 12.5003, listOf("M1", "M2", "S_C", "S_F", "S_H"), isMajorHub = true),
        "Lindevang" to TransportStation("lindevang", "Lindevang", 2, 55.6836, 12.5122, listOf("M1", "M2")),
        "Fasanvej" to TransportStation("fasanvej", "Fasanvej", 2, 55.6817, 12.5239, listOf("M1", "M2")),
        "Frederiksberg" to TransportStation("frederiksberg", "Frederiksberg", 2, 55.6811, 12.5336, listOf("M1", "M2", "M3"), isMajorHub = true),
        "Forum" to TransportStation("forum", "Forum", 1, 55.6817, 12.5531, listOf("M1", "M2")),
        "Nørreport" to TransportStation("norreport", "Nørreport", 1, 55.6833, 12.5717, listOf("M1", "M2", "S_A", "S_B", "S_C", "RE_ZEALAND", "BUS_5C"), isMajorHub = true, description = "Denmark's busiest station"),
        "Kongens Nytorv" to TransportStation("kongens_nytorv", "Kongens Nytorv", 1, 55.6800, 12.5861, listOf("M1", "M2", "M3", "M4"), isMajorHub = true, description = "4-line Metro interchange hub"),
        "Christianshavn" to TransportStation("christianshavn", "Christianshavn", 1, 55.6722, 12.5914, listOf("M1", "M2")),
        "Islands Brygge" to TransportStation("islands_brygge", "Islands Brygge", 1, 55.6631, 12.5858, listOf("M1")),
        "DR Byen" to TransportStation("dr_byen", "DR Byen", 1, 55.6583, 12.5892, listOf("M1")),
        "Sundby" to TransportStation("sundby", "Sundby", 3, 55.6458, 12.5972, listOf("M1")),
        "Bella Center" to TransportStation("bella_center", "Bella Center", 3, 55.6378, 12.5808, listOf("M1")),
        "Ørestad" to TransportStation("orestad", "Ørestad", 3, 55.6292, 12.5794, listOf("M1", "RE_ZEALAND"), isMajorHub = true),
        "Vestamager" to TransportStation("vestamager", "Vestamager", 3, 55.6183, 12.5714, listOf("M1")),
        "Amagerbro" to TransportStation("amagerbro", "Amagerbro", 1, 55.6639, 12.6033, listOf("M2")),
        "Lergravsparken" to TransportStation("lergravsparken", "Lergravsparken", 1, 55.6625, 12.6161, listOf("M2")),
        "Øresund" to TransportStation("oresund", "Øresund", 3, 55.6617, 12.6289, listOf("M2")),
        "Amager Strand" to TransportStation("amager_strand", "Amager Strand", 3, 55.6561, 12.6322, listOf("M2")),
        "Femøren" to TransportStation("femoren", "Femøren", 3, 55.6458, 12.6381, listOf("M2")),
        "Kastrup" to TransportStation("kastrup", "Kastrup", 4, 55.6367, 12.6367, listOf("M2")),
        "Lufthavnen" to TransportStation("lufthavnen", "Lufthavnen (CPH Airport)", 4, 55.6297, 12.6489, listOf("M2", "RE_ZEALAND", "BUS_5C"), isAirport = true, isMajorHub = true, description = "Direct connection to Terminal 3"),
        "København H" to TransportStation("kobenhavn_h", "København H (Central Station)", 1, 55.6728, 12.5647, listOf("M3", "M4", "S_A", "S_B", "S_C", "RE_ZEALAND", "BUS_5C"), isMajorHub = true, description = "Copenhagen Central Station"),
        "Rådhuspladsen" to TransportStation("radhuspladsen", "Rådhuspladsen", 1, 55.6761, 12.5689, listOf("M3", "M4")),
        "Gammel Strand" to TransportStation("gammel_strand", "Gammel Strand", 1, 55.6778, 12.5786, listOf("M3", "M4")),
        "Marmorkirken" to TransportStation("marmorkirken", "Marmorkirken", 1, 55.6853, 12.5892, listOf("M3", "M4")),
        "Østerport" to TransportStation("osterport", "Østerport", 1, 55.6928, 12.5878, listOf("M3", "M4", "S_A", "S_B", "S_C", "RE_ZEALAND"), isMajorHub = true),
        "Trianglen" to TransportStation("trianglen", "Trianglen", 1, 55.6992, 12.5781, listOf("M3")),
        "Poul Henningsens Plads" to TransportStation("poul_henningsens_plads", "Poul Henningsens Plads", 1, 55.7089, 12.5772, listOf("M3")),
        "Vibenshus Runddel" to TransportStation("vibenshus_runddel", "Vibenshus Runddel", 2, 55.7067, 12.5639, listOf("M3")),
        "Skjolds Plads" to TransportStation("skjolds_plads", "Skjolds Plads", 2, 55.7028, 12.5519, listOf("M3")),
        "Nørrebro" to TransportStation("norrebro", "Nørrebro", 2, 55.6997, 12.5378, listOf("M3", "S_F", "BUS_5C"), isMajorHub = true),
        "Nørrebros Runddel" to TransportStation("norrebros_runddel", "Nørrebros Runddel", 2, 55.6942, 12.5489, listOf("M3", "BUS_5C")),
        "Nuuks Plads" to TransportStation("nuuks_plads", "Nuuks Plads", 2, 55.6883, 12.5408, listOf("M3")),
        "Aksel Møllers Have" to TransportStation("aksel_mollers_have", "Aksel Møllers Have", 2, 55.6856, 12.5328, listOf("M3")),
        "Frederiksberg Allé" to TransportStation("frederiksberg_alle", "Frederiksberg Allé", 1, 55.6739, 12.5439, listOf("M3")),
        "Enghave Plads" to TransportStation("enghave_plads", "Enghave Plads", 1, 55.6672, 12.5444, listOf("M3")),
        "Orientkaj" to TransportStation("orientkaj", "Orientkaj", 1, 55.7086, 12.5972, listOf("M4")),
        "Nordhavn" to TransportStation("nordhavn", "Nordhavn", 1, 55.7064, 12.5900, listOf("M4", "S_A", "S_B", "S_C")),
        "Enghave Brygge" to TransportStation("enghave_brygge", "Enghave Brygge", 1, 55.6578, 12.5519, listOf("M4")),
        "Sluseholmen" to TransportStation("sluseholmen", "Sluseholmen", 1, 55.6483, 12.5489, listOf("M4")),
        "Mozarts Plads" to TransportStation("mozarts_plads", "Mozarts Plads", 2, 55.6489, 12.5344, listOf("M4")),
        "København Syd" to TransportStation("kobenhavn_syd", "København Syd", 2, 55.6511, 12.5139, listOf("M4", "S_A", "S_F", "RE_ZEALAND"), isMajorHub = true, description = "Major Southern interchange hub"),
        // Regional destinations outside central zone
        "Roskilde" to TransportStation("roskilde", "Roskilde Station", 8, 55.6417, 12.0878, listOf("RE_ZEALAND"), isMajorHub = true),
        "Helsingør" to TransportStation("helsingor", "Helsingør Station", 9, 56.0333, 12.6139, listOf("RE_ZEALAND"), isMajorHub = true),
        "Hillerød" to TransportStation("hillerod", "Hillerød Station", 9, 55.9278, 12.3111, listOf("S_A"), isMajorHub = true),
        "Refshaleøen" to TransportStation("refshaleoen", "Refshaleøen (Harbour)", 2, 55.6936, 12.6083, listOf("HB_991")),
        "Nyhavn" to TransportStation("nyhavn", "Nyhavn (Harbour)", 1, 55.6797, 12.5911, listOf("HB_991"))
    )

    fun getAllStationsList(): List<TransportStation> = STATIONS_MAP.values.toList()

    val SYSTEM_ALERTS = listOf(
        TransportAlert(
            id = "ALT_1",
            severity = AlertSeverity.INFO,
            titleDa = "Normal drift på hele Metronettet",
            titleEn = "Normal service across the Metro network",
            descriptionDa = "M1, M2, M3 og M4 kører med normal tæt frekvens. Ingen driftsforstyrrelser.",
            descriptionEn = "M1, M2, M3 and M4 operate with normal high frequency. No service disruptions.",
            affectedLines = listOf("M1", "M2", "M3", "M4")
        ),
        TransportAlert(
            id = "ALT_2",
            severity = AlertSeverity.WARNING,
            titleDa = "Elevator midlertidigt ude af drift på Nørreport",
            titleEn = "Elevator temporarily out of service at Nørreport",
            descriptionDa = "Elevator til spor 1 er under reparation. Brug rulletrapper eller rampen ved Nørre Voldgade.",
            descriptionEn = "Elevator to platform 1 is under maintenance. Use escalators or step-free ramp at Nørre Voldgade.",
            affectedLines = listOf("M1", "M2", "S_A"),
            affectedStations = listOf("Nørreport")
        ),
        TransportAlert(
            id = "ALT_3",
            severity = AlertSeverity.INFO,
            titleDa = "Havnebus 991/992 sejler på sommerfartplan",
            titleEn = "Harbour bus operating on normal timetable",
            descriptionDa = "Afgange hvert 20. minut mellem Refshaleøen og Teglholmen.",
            descriptionEn = "Departures every 20 minutes between Refshaleøen and Teglholmen.",
            affectedLines = listOf("HB_991")
        )
    )

    val FARE_PRODUCTS = listOf(
        FareProduct("FP_SINGLE_2Z", "2-Zoners Enkeltbillet", "2-Zone Single Ticket", 24.0, "Zone 1-2 (valid 1 hour)", "Single"),
        FareProduct("FP_SINGLE_3Z", "3-Zoners Enkeltbillet", "3-Zone Single Ticket", 36.0, "Zone 1-3 (Airport/Vestamager)", "Single"),
        FareProduct("FP_SINGLE_4Z", "4-Zoners Enkeltbillet", "4-Zone Single Ticket", 48.0, "Zone 1-4 (Kastrup/Suburbs)", "Single"),
        FareProduct("FP_CITYPASS_S_24", "City Pass Small 24H", "City Pass Small 24 Hours", 90.0, "Unlimited Metro, Bus & Train in Zones 1-4 (includes Airport)", "City Pass"),
        FareProduct("FP_CITYPASS_S_72", "City Pass Small 72H", "City Pass Small 72 Hours", 220.0, "Unlimited Metro, Bus & Train in Zones 1-4 for 3 Days", "City Pass"),
        FareProduct("FP_REJSEKORT", "Rejsekort Check-In Rate", "Rejsekort 1-Swipe Check-In", 18.50, "Automated zone calculation with off-peak discount", "Rejsekort")
    )
}
