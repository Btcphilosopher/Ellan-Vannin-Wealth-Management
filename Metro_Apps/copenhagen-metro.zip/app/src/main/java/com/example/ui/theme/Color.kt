package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DanishRed = Color(0xFFC8102E)
val Charcoal = Color(0xFF1C1C1E)
val CoolGrey = Color(0xFFE5E5EA)
val OffWhite = Color(0xFFF7F7F8)
val CleanWhite = Color(0xFFFFFFFF)
val MutedText = Color(0xFF6E6E73)

// Metro Line Badges
val MetroM1Green = Color(0xFF00843D)
val MetroM2Yellow = Color(0xFFF2A900)
val MetroM3Red = Color(0xFFC8102E)
val MetroM4Blue = Color(0xFF00A3E0)
val STrainRed = Color(0xFFE30613)
val RegionalBlue = Color(0xFF005587)
val HarbourBusNavy = Color(0xFF003366)
val BusAmber = Color(0xFFFFB300)
val LightRailOrange = Color(0xFFFF6F00)

val LiveGreen = Color(0xFF34C759)
val AlertWarningOrange = Color(0xFFFF9500)
val AlertErrorRed = Color(0xFFFF3B30)
