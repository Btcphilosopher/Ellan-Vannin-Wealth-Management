package com.example.copenhagenmetro.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_places")
data class SavedPlaceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val stationId: String,
    val stationName: String,
    val iconName: String
)

@Entity(tableName = "favourite_departures")
data class FavouriteDepartureEntity(
    @PrimaryKey val id: String,
    val stationId: String,
    val stationName: String,
    val lineCode: String,
    val destinationName: String
)

@Entity(tableName = "active_tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val productName: String,
    val purchaseTimestamp: Long,
    val expiryTimestamp: Long,
    val priceDkk: Double,
    val qrCodeData: String,
    val isValid: Boolean = true
)

@Entity(tableName = "journey_history")
data class JourneyHistoryEntity(
    @PrimaryKey val id: String,
    val originName: String,
    val destinationName: String,
    val timestamp: Long,
    val durationMinutes: Int
)
