package com.example.copenhagenmetro.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.data.mock.CopenhagenNetworkData
import com.example.copenhagenmetro.domain.model.M3Direction
import com.example.copenhagenmetro.routing.M3CircleCalculator
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.components.LineBadge
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun M3CircleMapScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onBack: () -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    val m3Stations = CopenhagenNetworkData.M3_STATION_NAMES

    var selectedFrom by remember { mutableStateOf("Nørrebro") }
    var selectedTo by remember { mutableStateOf("Kongens Nytorv") }

    val circleResult = remember(selectedFrom, selectedTo) {
        M3CircleCalculator.calculateM3Route(selectedFrom, selectedTo)
    }

    // Animation for moving trains along loop
    val infiniteTransition = rememberInfiniteTransition(label = "m3_train_loop")
    val angleClockwise by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "clockwise_angle"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = "M3 CITYRINGEN LOOP",
            subtitle = if (isDanish) "Cirkulær Linje-Intelligens" else "Circular Loop Intelligence",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Direction Comparison Card
            if (circleResult != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier.fillMaxWidth().testTag("m3_comparison_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                LineBadge("M3")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${circleResult.fromStation} → ${circleResult.toStation}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                DirectionChoiceCard(
                                    title = if (isDanish) "Med uret (Inderring)" else "Clockwise",
                                    time = "${circleResult.clockwiseMinutes} min",
                                    stops = "${circleResult.clockwiseStops} stop",
                                    isBest = circleResult.bestDirection == M3Direction.CLOCKWISE,
                                    modifier = Modifier.weight(1f)
                                )

                                Spacer(modifier = Modifier.width(10.dp))

                                DirectionChoiceCard(
                                    title = if (isDanish) "Mod uret (Yderring)" else "Counterclockwise",
                                    time = "${circleResult.counterClockwiseMinutes} min",
                                    stops = "${circleResult.counterClockwiseStops} stop",
                                    isBest = circleResult.bestDirection == M3Direction.COUNTERCLOCKWISE,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // Interactive M3 Circle Ring Diagram
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .testTag("m3_circle_canvas_card")
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            val center = Offset(w * 0.5f, h * 0.5f)
                            val radius = (w.coerceAtMost(h) * 0.38f)

                            // 1. Base Ring
                            drawCircle(
                                color = MetroM3Red,
                                radius = radius,
                                center = center,
                                style = Stroke(width = 16f)
                            )

                            // 2. Station dots on ring
                            val total = m3Stations.size
                            m3Stations.forEachIndexed { idx, name ->
                                val angleRad = Math.toRadians((idx * (360.0 / total) - 90.0))
                                val x = center.x + radius * cos(angleRad).toFloat()
                                val y = center.y + radius * sin(angleRad).toFloat()

                                val isSelected = name == selectedFrom || name == selectedTo
                                drawCircle(
                                    color = if (isSelected) LiveGreen else Color.White,
                                    radius = if (isSelected) 10f else 6f,
                                    center = Offset(x, y)
                                )
                                drawCircle(
                                    color = Charcoal,
                                    radius = if (isSelected) 10f else 6f,
                                    center = Offset(x, y),
                                    style = Stroke(width = 3f)
                                )
                            }

                            // 3. Moving Train 01 (Clockwise)
                            val train1AngleRad = Math.toRadians(angleClockwise.toDouble() - 90.0)
                            val t1X = center.x + radius * cos(train1AngleRad).toFloat()
                            val t1Y = center.y + radius * sin(train1AngleRad).toFloat()

                            drawCircle(color = MetroM3Red, radius = 12f, center = Offset(t1X, t1Y))
                            drawCircle(color = Color.White, radius = 6f, center = Offset(t1X, t1Y))

                            // 4. Moving Train 02 (Counterclockwise)
                            val train2AngleRad = Math.toRadians(-angleClockwise.toDouble() - 90.0)
                            val t2X = center.x + radius * cos(train2AngleRad).toFloat()
                            val t2Y = center.y + radius * sin(train2AngleRad).toFloat()

                            drawCircle(color = DanishRed, radius = 12f, center = Offset(t2X, t2Y))
                            drawCircle(color = Color.White, radius = 6f, center = Offset(t2X, t2Y))
                        }

                        // Center Label
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "M3",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 28.sp,
                                color = MetroM3Red
                            )
                            Text(
                                text = "CITYRINGEN",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MutedText
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DirectionChoiceCard(
    title: String,
    time: String,
    stops: String,
    isBest: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isBest) LiveGreen.copy(alpha = 0.15f) else CoolGrey.copy(alpha = 0.5f),
        border = if (isBest) androidx.compose.foundation.BorderStroke(2.dp, LiveGreen) else null,
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                if (isBest) {
                    Text(text = "✓ HURTIGST", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = LiveGreen)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = time, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = if (isBest) LiveGreen else MaterialTheme.colorScheme.onSurface)
            Text(text = stops, fontSize = 11.sp, color = MutedText)
        }
    }
}
