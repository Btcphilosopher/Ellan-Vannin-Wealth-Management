package com.example.copenhagenmetro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.domain.model.Journey
import com.example.copenhagenmetro.domain.model.JourneyLeg
import com.example.copenhagenmetro.domain.model.TransportMode
import com.example.copenhagenmetro.routing.JourneyFilterOptions
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.components.LineBadge
import com.example.copenhagenmetro.ui.components.M3CircleRecommendationCard
import com.example.copenhagenmetro.ui.components.TopBarHeader
import com.example.ui.theme.*

@Composable
fun JourneyPlannerScreen(
    viewModel: MainViewModel,
    uiState: com.example.copenhagenmetro.ui.UiState,
    onBack: () -> Unit
) {
    val isDanish = uiState.isDanishLanguage
    val journeys = uiState.journeyResults
    val m3Result = uiState.m3CircleResult

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopBarHeader(
            title = if (isDanish) "REJSEPLANLÆGGER" else "JOURNEY PLANNER",
            subtitle = "${uiState.originInput} → ${uiState.destinationInput}",
            isDanish = isDanish,
            onLanguageToggle = { viewModel.toggleLanguage() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Filter Toggles
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = uiState.activeFilterOptions.stepFreeOnly,
                        onClick = {
                            val curr = uiState.activeFilterOptions
                            viewModel.updateFilters(curr.copy(stepFreeOnly = !curr.stepFreeOnly))
                        },
                        label = { Text("♿ ${if (isDanish) "Niveaufri (Elevator)" else "Step-free"}") }
                    )
                    FilterChip(
                        selected = uiState.activeFilterOptions.withBicycle,
                        onClick = {
                            val curr = uiState.activeFilterOptions
                            viewModel.updateFilters(curr.copy(withBicycle = !curr.withBicycle))
                        },
                        label = { Text("🚲 ${if (isDanish) "Cykel" else "Bicycle"}") }
                    )
                    FilterChip(
                        selected = uiState.activeFilterOptions.preferMetro,
                        onClick = {
                            val curr = uiState.activeFilterOptions
                            viewModel.updateFilters(curr.copy(preferMetro = !curr.preferMetro))
                        },
                        label = { Text("🚇 Metro") }
                    )
                }
            }

            // M3 Circle Recommendation Banner
            if (m3Result != null) {
                item {
                    M3CircleRecommendationCard(m3Result = m3Result, isDanish = isDanish)
                }
            }

            // Journey Results List
            if (journeys.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isDanish) "Ingen ruter fundet med valgte filtre." else "No routes found matching selected filters.",
                            color = MutedText
                        )
                    }
                }
            } else {
                items(journeys) { journey ->
                    JourneyCard(journey = journey, isDanish = isDanish)
                }
            }
        }
    }
}

@Composable
fun JourneyCard(journey: Journey, isDanish: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("journey_result_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${journey.departureTimeFormatted} → ${journey.arrivalTimeFormatted}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "(${journey.totalDurationMinutes} min)",
                        fontSize = 13.sp,
                        color = DanishRed,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CoolGrey.copy(alpha = 0.5f)
                ) {
                    Text(
                        text = "${journey.priceDkk} DKK (${journey.fareZones.size} ${if (isDanish) "zoner" else "zones"})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Legs timeline
            journey.legs.forEachIndexed { idx, leg ->
                LegTimelineItem(leg = leg, isLast = idx == journey.legs.size - 1)
            }

            // Notice
            if (journey.m3Recommendation != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "💡 ${journey.m3Recommendation}",
                    fontSize = 11.sp,
                    color = MetroM3Red,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun LegTimelineItem(leg: JourneyLeg, isLast: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            LineBadge(code = leg.routeCode, backgroundColorHex = leg.routeColorHex)
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(24.dp)
                        .background(CoolGrey)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${leg.fromStationName} → ${leg.toStationName}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Text(
                    text = "${leg.durationMinutes} min",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MutedText
                )
            }

            if (leg.isTransfer) {
                Text(
                    text = "🚶‍♂️ Skift pa station (${leg.platform})",
                    fontSize = 11.sp,
                    color = MutedText
                )
            } else {
                Text(
                    text = "${leg.platform} • ${leg.intermediateStopsCount} stop",
                    fontSize = 11.sp,
                    color = MutedText
                )
            }
        }
    }
}
