package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.copenhagenmetro.ui.MainViewModel
import com.example.copenhagenmetro.ui.Screen
import com.example.copenhagenmetro.ui.screens.*
import com.example.ui.theme.CopenhagenMetroTheme
import com.example.ui.theme.DanishRed

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            CopenhagenMetroTheme {
                val uiState by viewModel.uiState.collectAsState()

                // Intercept back button when on sub-screens
                if (uiState.currentScreen != Screen.HOME) {
                    BackHandler {
                        viewModel.navigateTo(Screen.HOME)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        BottomNavigationBar(
                            currentScreen = uiState.currentScreen,
                            onNavigate = { viewModel.navigateTo(it) },
                            isDanish = uiState.isDanishLanguage
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (uiState.currentScreen) {
                            Screen.HOME -> HomeScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                            Screen.JOURNEY_PLANNER -> JourneyPlannerScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onBack = { viewModel.navigateTo(Screen.HOME) }
                            )
                            Screen.LIVE_DEPARTURES -> LiveDeparturesScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onBack = { viewModel.navigateTo(Screen.HOME) }
                            )
                            Screen.STATION_DETAIL -> StationDetailScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onBack = { viewModel.navigateTo(Screen.HOME) }
                            )
                            Screen.KOBENHAVN_H -> KobenhavnHScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onBack = { viewModel.navigateTo(Screen.HOME) }
                            )
                            Screen.AIRPORT_MODE -> AirportModeScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                            Screen.MAP -> MapScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onBack = { viewModel.navigateTo(Screen.HOME) }
                            )
                            Screen.M3_CIRCLE_MAP -> M3CircleMapScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onBack = { viewModel.navigateTo(Screen.HOME) }
                            )
                            Screen.TICKETS_REJSEKORT -> TicketsRejsekortScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onBack = { viewModel.navigateTo(Screen.HOME) }
                            )
                            Screen.SERVICE_STATUS -> ServiceStatusScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onBack = { viewModel.navigateTo(Screen.HOME) }
                            )
                            Screen.SIMULATOR_OPERATIONS -> OperationsSimulatorScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onBack = { viewModel.navigateTo(Screen.HOME) }
                            )
                            Screen.VISITOR_TOURIST -> VisitorTouristScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                            Screen.COMMUTE_MODE -> CommuteModeScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BottomNavigationBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    isDanish: Boolean
) {
    NavigationBar(
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("bottom_navigation_bar")
    ) {
        NavigationBarItem(
            selected = currentScreen == Screen.HOME,
            onClick = { onNavigate(Screen.HOME) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text(if (isDanish) "Hjem" else "Home") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = DanishRed)
        )
        NavigationBarItem(
            selected = currentScreen == Screen.LIVE_DEPARTURES,
            onClick = { onNavigate(Screen.LIVE_DEPARTURES) },
            icon = { Icon(Icons.Default.Schedule, contentDescription = "Departures") },
            label = { Text(if (isDanish) "Afgange" else "Live") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = DanishRed)
        )
        NavigationBarItem(
            selected = currentScreen == Screen.MAP || currentScreen == Screen.M3_CIRCLE_MAP,
            onClick = { onNavigate(Screen.MAP) },
            icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
            label = { Text(if (isDanish) "Kort" else "Map") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = DanishRed)
        )
        NavigationBarItem(
            selected = currentScreen == Screen.TICKETS_REJSEKORT,
            onClick = { onNavigate(Screen.TICKETS_REJSEKORT) },
            icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Tickets") },
            label = { Text(if (isDanish) "Billet" else "Tickets") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = DanishRed)
        )
        NavigationBarItem(
            selected = currentScreen == Screen.SIMULATOR_OPERATIONS,
            onClick = { onNavigate(Screen.SIMULATOR_OPERATIONS) },
            icon = { Icon(Icons.Default.Engineering, contentDescription = "Ops") },
            label = { Text("Ops") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = DanishRed)
        )
    }
}
