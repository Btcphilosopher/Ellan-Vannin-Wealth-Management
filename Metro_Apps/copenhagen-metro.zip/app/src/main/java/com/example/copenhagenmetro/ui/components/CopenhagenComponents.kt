package com.example.copenhagenmetro.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.copenhagenmetro.domain.model.M3Direction
import com.example.copenhagenmetro.domain.model.RealtimeState
import com.example.copenhagenmetro.domain.model.TransportDeparture
import com.example.copenhagenmetro.routing.M3CircleResult
import com.example.ui.theme.*

@Composable
fun TopBarHeader(
    title: String,
    subtitle: String = "DOT | Københavns Transport",
    isDanish: Boolean = true,
    onLanguageToggle: () -> Unit = {},
    onNotificationClick: () -> Unit = {}
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(DanishRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("M", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(
                    onClick = onLanguageToggle,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("lang_toggle_btn")
                ) {
                    Text(if (isDanish) "DA" else "EN", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onNotificationClick,
                    modifier = Modifier.testTag("notification_btn")
                ) {
                    Icon(Icons.Default.NotificationsNone, contentDescription = "Alerts")
                }
            }
        }
    }
}

@Composable
fun LineBadge(
    code: String,
    modifier: Modifier = Modifier,
    backgroundColorHex: String? = null
) {
    val bg = when (code) {
        "M1" -> MetroM1Green
        "M2" -> MetroM2Yellow
        "M3" -> MetroM3Red
        "M4" -> MetroM4Blue
        "S-A", "S-B", "S-C", "S-F", "S-H", "S-TOG" -> STrainRed
        "RE", "REGIONAL" -> RegionalBlue
        "5C", "1A", "BUS" -> BusAmber
        "991", "992", "HAVNEBUS" -> HarbourBusNavy
        "L1", "LETBANE" -> LightRailOrange
        else -> if (backgroundColorHex != null) {
            try { Color(android.graphics.Color.parseColor(backgroundColorHex)) } catch (e: Exception) { DanishRed }
        } else DanishRed
    }

    val textColor = if (code == "5C" || code == "M2" || code == "S-F") Color.Black else Color.White

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = code,
            color = textColor,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 12.sp
        )
    }
}

@Composable
fun RealtimeStateBadge(state: RealtimeState, delayMins: Int = 0) {
    val (label, color) = when (state) {
        RealtimeState.LIVE -> "LIVE" to LiveGreen
        RealtimeState.ESTIMATED -> "+${delayMins}m" to AlertWarningOrange
        RealtimeState.CANCELLED -> "AFLYST" to AlertErrorRed
        RealtimeState.SCHEDULED -> "PLANLAGT" to MutedText
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun M3CircleRecommendationCard(m3Result: M3CircleResult, isDanish: Boolean = true) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MetroM3Red.copy(alpha = 0.08f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("m3_recommendation_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LineBadge("M3")
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isDanish) "Cityringen Anbefaling" else "Cityringen Intelligence",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MetroM3Red
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isDanish) m3Result.recommendationMessageDa else m3Result.recommendationMessageEn,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (m3Result.bestDirection == M3Direction.CLOCKWISE) "✓ Inderring: ${m3Result.clockwiseMinutes} min (${m3Result.clockwiseStops} stop)"
                    else "Inderring: ${m3Result.clockwiseMinutes} min (${m3Result.clockwiseStops} stop)",
                    fontSize = 12.sp,
                    color = if (m3Result.bestDirection == M3Direction.CLOCKWISE) LiveGreen else MutedText,
                    fontWeight = if (m3Result.bestDirection == M3Direction.CLOCKWISE) FontWeight.Bold else FontWeight.Normal
                )
                Text(
                    text = if (m3Result.bestDirection == M3Direction.COUNTERCLOCKWISE) "✓ Yderring: ${m3Result.counterClockwiseMinutes} min (${m3Result.counterClockwiseStops} stop)"
                    else "Yderring: ${m3Result.counterClockwiseMinutes} min (${m3Result.counterClockwiseStops} stop)",
                    fontSize = 12.sp,
                    color = if (m3Result.bestDirection == M3Direction.COUNTERCLOCKWISE) LiveGreen else MutedText,
                    fontWeight = if (m3Result.bestDirection == M3Direction.COUNTERCLOCKWISE) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
fun DepartureRowItem(departure: TransportDeparture, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LineBadge(code = departure.lineCode, backgroundColorHex = departure.lineColorHex)
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = departure.destinationName,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp
            )
            Text(
                text = "${departure.platform} • ${departure.directionLabel}",
                fontSize = 11.sp,
                color = MutedText
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "${departure.relativeMinutes} min",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp,
                color = DanishRed
            )
            RealtimeStateBadge(state = departure.realtimeState, delayMins = departure.delayMinutes)
        }
    }
}
