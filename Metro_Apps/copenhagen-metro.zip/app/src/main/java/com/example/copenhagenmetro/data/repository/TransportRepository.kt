package com.example.copenhagenmetro.data.repository

import com.example.copenhagenmetro.data.database.*
import com.example.copenhagenmetro.data.mock.CopenhagenNetworkData
import com.example.copenhagenmetro.domain.model.*
import com.example.copenhagenmetro.routing.JourneyFilterOptions
import com.example.copenhagenmetro.routing.JourneyPlanner
import com.example.copenhagenmetro.routing.M3CircleCalculator
import com.example.copenhagenmetro.routing.M3CircleResult
import com.example.copenhagenmetro.simulator.CopenhagenSimulator
import com.example.copenhagenmetro.simulator.SimulationScenario
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class TransportRepository(private val dao: CopenhagenDao) {

    fun getStations(): List<TransportStation> = CopenhagenNetworkData.getAllStationsList()

    fun getStation(nameOrId: String): TransportStation? {
        return CopenhagenNetworkData.STATIONS_MAP.values.find {
            it.id.equals(nameOrId, ignoreCase = true) || it.name.equals(nameOrId, ignoreCase = true)
        }
    }

    fun getDeparturesForStation(stationName: String): List<TransportDeparture> {
        return CopenhagenSimulator.getDeparturesForStation(stationName)
    }

    fun planJourney(origin: String, destination: String, filters: JourneyFilterOptions = JourneyFilterOptions()): List<Journey> {
        return JourneyPlanner.planJourney(origin, destination, filters)
    }

    fun calculateM3Route(from: String, to: String): M3CircleResult? {
        return M3CircleCalculator.calculateM3Route(from, to)
    }

    fun getSystemAlerts(): List<TransportAlert> = CopenhagenNetworkData.SYSTEM_ALERTS

    fun getFareProducts(): List<FareProduct> = CopenhagenNetworkData.FARE_PRODUCTS

    fun setSimulationScenario(scenario: SimulationScenario) {
        CopenhagenSimulator.setScenario(scenario)
    }

    fun getActiveScenario() = CopenhagenSimulator.activeScenario

    // Room Database Saved Places
    val savedPlaces: Flow<List<SavedPlaceEntity>> = dao.getAllSavedPlaces()

    suspend fun savePlace(id: String, name: String, stationId: String, stationName: String, icon: String) {
        dao.insertSavedPlace(SavedPlaceEntity(id, name, stationId, stationName, icon))
    }

    suspend fun deleteSavedPlace(id: String, name: String, stationId: String, stationName: String, icon: String) {
        dao.deleteSavedPlace(SavedPlaceEntity(id, name, stationId, stationName, icon))
    }

    // Favourites
    val favouriteDepartures: Flow<List<FavouriteDepartureEntity>> = dao.getFavouriteDepartures()

    suspend fun addFavouriteDeparture(id: String, stationId: String, stationName: String, lineCode: String, dest: String) {
        dao.insertFavouriteDeparture(FavouriteDepartureEntity(id, stationId, stationName, lineCode, dest))
    }

    suspend fun removeFavouriteDeparture(id: String) {
        dao.deleteFavouriteDeparture(id)
    }

    // Active Tickets
    val activeTickets: Flow<List<TicketEntity>> = dao.getActiveTickets()

    suspend fun purchaseTicket(productName: String, price: Double) {
        val now = System.currentTimeMillis()
        val ticket = TicketEntity(
            id = "TCK-${now.toString().takeLast(6)}",
            productName = productName,
            purchaseTimestamp = now,
            expiryTimestamp = now + (90 * 60 * 1000), // 90 minutes
            priceDkk = price,
            qrCodeData = "CPH-METRO-REJSEBILLET-VALID-${now}"
        )
        dao.insertTicket(ticket)
    }
}
