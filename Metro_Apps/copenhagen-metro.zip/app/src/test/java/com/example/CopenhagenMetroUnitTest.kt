package com.example

import com.example.copenhagenmetro.data.mock.CopenhagenNetworkData
import com.example.copenhagenmetro.domain.model.M3Direction
import com.example.copenhagenmetro.routing.JourneyPlanner
import com.example.copenhagenmetro.routing.M3CircleCalculator
import com.example.copenhagenmetro.simulator.CopenhagenSimulator
import com.example.copenhagenmetro.simulator.SimulationScenario
import org.junit.Assert.*
import org.junit.Test

class CopenhagenMetroUnitTest {

    @Test
    fun m3CircleCalculator_NorrebroToKongensNytorv_selectsCounterClockwise() {
        // Nørrebro to Kongens Nytorv on M3 Cityringen loop
        val result = M3CircleCalculator.calculateM3Route("Nørrebro", "Kongens Nytorv")
        assertNotNull(result)

        // Counterclockwise is 7 stops vs 10 stops clockwise
        assertEquals(M3Direction.COUNTERCLOCKWISE, result!!.bestDirection)
        assertTrue(result.counterClockwiseStops < result.clockwiseStops)
        assertEquals(7, result.counterClockwiseStops)
        assertEquals(10, result.clockwiseStops)
    }

    @Test
    fun m3CircleCalculator_KongensNytorvToNorrebro_selectsClockwise() {
        // Kongens Nytorv to Nørrebro on M3 Cityringen loop
        val result = M3CircleCalculator.calculateM3Route("Kongens Nytorv", "Nørrebro")
        assertNotNull(result)

        // Clockwise is 7 stops vs 10 stops counterclockwise
        assertEquals(M3Direction.CLOCKWISE, result!!.bestDirection)
        assertEquals(7, result.clockwiseStops)
        assertEquals(10, result.counterClockwiseStops)
    }

    @Test
    fun journeyPlanner_NørreportToLufthavnen_returnsDirectM2() {
        val journeys = JourneyPlanner.planJourney("Nørreport", "Lufthavnen")
        assertTrue(journeys.isNotEmpty())

        val topJourney = journeys.first()
        assertEquals("Nørreport", topJourney.originStation)
        assertEquals("Lufthavnen (CPH Airport)", topJourney.destinationStation)
        assertEquals(0, topJourney.transfersCount)
        assertEquals("M2", topJourney.legs.first().routeCode)
    }

    @Test
    fun fareCalculation_zoneRanges_correctPricing() {
        val price2Zones = JourneyPlanner.calculatePrice(2)
        val price3Zones = JourneyPlanner.calculatePrice(3)
        val price4Zones = JourneyPlanner.calculatePrice(4)

        assertEquals(24, price2Zones)
        assertEquals(36, price3Zones)
        assertEquals(48, price4Zones)
    }

    @Test
    fun simulator_getDepartures_NorreportContainsM1M2M3() {
        CopenhagenSimulator.setScenario(SimulationScenario.NORMAL_DAY)
        val departures = CopenhagenSimulator.getDeparturesForStation("Nørreport")

        assertTrue(departures.isNotEmpty())
        val lines = departures.map { it.lineCode }.toSet()
        assertTrue(lines.contains("M1"))
        assertTrue(lines.contains("M2"))
    }
}
