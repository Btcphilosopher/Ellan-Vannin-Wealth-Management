package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.MetroDatabase
import com.example.data.model.*
import com.example.data.repository.MetroRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class MetroTab {
    NETWORK, OPERATIONS, STATIONS, FLEET, INCIDENTS, PASSENGERS, ANALYTICS, AUDIT
}

class MetroViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MetroRepository

    init {
        val database = MetroDatabase.getDatabase(application)
        repository = MetroRepository(database.metroDao())
        
        // Initialize/Seed Database
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
        
        // Start Simulation Ticker
        startSimulationLoop()
    }

    // State Flows from DB
    val stations: StateFlow<List<StationEntity>> = repository.allStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trains: StateFlow<List<TrainEntity>> = repository.allTrains
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val incidents: StateFlow<List<IncidentEntity>> = repository.allIncidents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val passengerMessages: StateFlow<List<PassengerMessageEntity>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditEvents: StateFlow<List<AuditEventEntity>> = repository.allAuditEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Interactive States
    private val _currentTab = MutableStateFlow(MetroTab.NETWORK)
    val currentTab: StateFlow<MetroTab> = _currentTab.asStateFlow()

    private val _isArabic = MutableStateFlow(true) // Default to Arabic as requested!
    val isArabic: StateFlow<Boolean> = _isArabic.asStateFlow()

    private val _selectedStationId = MutableStateFlow<String?>("S_MSH")
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    private val _selectedTrainId = MutableStateFlow<String?>("T_R1")
    val selectedTrainId: StateFlow<String?> = _selectedTrainId.asStateFlow()

    private val _selectedIncidentId = MutableStateFlow<Int?>(null)
    val selectedIncidentId: StateFlow<Int?> = _selectedIncidentId.asStateFlow()

    // Simulation Controls
    private val _isSimulating = MutableStateFlow(true)
    val isSimulating: StateFlow<Boolean> = _isSimulating.asStateFlow()

    private val _timeMultiplier = MutableStateFlow(1.0f) // 1x, 2x, 5x speed
    val timeMultiplier: StateFlow<Float> = _timeMultiplier.asStateFlow()

    // Peak Demand Multiplier
    private val _isPeakDemand = MutableStateFlow(false)
    val isPeakDemand: StateFlow<Boolean> = _isPeakDemand.asStateFlow()

    private val _outdoorTemp = MutableStateFlow(42.0f) // Default extreme summer Doha temp!
    val outdoorTemp: StateFlow<Float> = _outdoorTemp.asStateFlow()

    // Simulation Ticker Job
    private var simJob: Job? = null

    // Navigation and Language Switches
    fun setTab(tab: MetroTab) {
        _currentTab.value = tab
    }

    fun toggleLanguage() {
        _isArabic.value = !_isArabic.value
    }

    fun selectStation(id: String?) {
        _selectedStationId.value = id
    }

    fun selectTrain(id: String?) {
        _selectedTrainId.value = id
    }

    fun selectIncident(id: Int?) {
        _selectedIncidentId.value = id
    }

    fun toggleSimulation() {
        _isSimulating.value = !_isSimulating.value
        logAudit(
            if (_isSimulating.value) "تم استئناف محاكاة شبكة مترو الدوحة" else "تم إيقاف محاكاة شبكة مترو الدوحة مؤقتاً",
            if (_isSimulating.value) "Resumed Doha Metro network simulation" else "Paused Doha Metro network simulation",
            "SIMULATION"
        )
    }

    fun setTimeMultiplier(mult: Float) {
        _timeMultiplier.value = mult
        logAudit(
            "تم تغيير مضاعف سرعة المحاكاة إلى ${mult}x",
            "Changed simulation speed multiplier to ${mult}x",
            "SIMULATION"
        )
    }

    fun setPeakDemand(isPeak: Boolean) {
        _isPeakDemand.value = isPeak
        logAudit(
            if (isPeak) "تفعيل وضع ذروة الطلب الجماهيري" else "تعطيل وضع ذروة الطلب الجماهيري والعودة للخدمة العادية",
            if (isPeak) "Activated peak passenger demand mode" else "Deactivated peak demand mode, returned to regular service",
            "OPERATIONS"
        )
    }

    fun setOutdoorTemp(temp: Float) {
        _outdoorTemp.value = temp
    }

    // Interactive Action triggers
    fun injectDelay(trainId: String, minutes: Int) {
        viewModelScope.launch {
            val trainList = trains.value
            val target = trainList.find { it.id == trainId }
            if (target != null) {
                val updated = target.copy(
                    status = "DELAYED",
                    delayedMinutes = minutes,
                    speed = 0f
                )
                repository.updateTrain(updated)
                
                // Add Audit Log
                logAudit(
                    "حقن تأخير قدره $minutes دقائق للقطار ${trainId} على الخط ${target.lineId}",
                    "Injected $minutes-minute operational delay on train ${trainId} (${target.lineId} Line)",
                    "OPERATIONS"
                )

                // Propagate delay to trailing trains on the same line
                trainList.forEach { other ->
                    if (other.id != trainId && other.lineId == target.lineId && other.status == "RUNNING") {
                        // Trailing trains on same line get minor delayed/held state
                        val trailingUpdated = other.copy(
                            status = "DELAYED",
                            delayedMinutes = (minutes / 2).coerceAtLeast(1),
                            speed = other.speed * 0.4f
                        )
                        repository.updateTrain(trailingUpdated)
                    }
                }

                // Auto Create Incident!
                val newIncident = IncidentEntity(
                    titleAr = "تأخير تشغيلي للقطار ${trainId} على الخط ${target.lineId}",
                    titleEn = "Operational delay for Train ${trainId} on ${target.lineId} Line",
                    severity = if (minutes >= 5) "MAJOR" else "MINOR",
                    locationAr = "بين محطة ${target.currentStationId} ومحطة ${target.nextStationId}",
                    locationEn = "Between stations ${target.currentStationId} and ${target.nextStationId}",
                    lineId = target.lineId,
                    status = "DETECTED",
                    owner = "Control Room Operator",
                    detectedTime = System.currentTimeMillis(),
                    descriptionAr = "تم حقن تأخير تشغيلي قدره $minutes دقائق. جاري مراقبة الفواصل الزمنية لتجنب تراكم القطارات.",
                    descriptionEn = "Operational delay of $minutes minutes injected. Monitoring headway separation to avoid train bunching."
                )
                val incId = repository.insertIncident(newIncident)
                selectIncident(incId.toInt())
            }
        }
    }

    fun holdTrain(trainId: String) {
        viewModelScope.launch {
            val target = trains.value.find { it.id == trainId }
            if (target != null) {
                val isHeld = target.status == "HELD"
                val updated = target.copy(
                    status = if (isHeld) "RUNNING" else "HELD",
                    speed = 0f
                )
                repository.updateTrain(updated)
                logAudit(
                    if (isHeld) "إلغاء حجز القطار $trainId في المحطة وإعادته للخدمة" else "حجز القطار $trainId في المحطة لأسباب تشغيلية",
                    if (isHeld) "Released Train $trainId from station hold" else "Placed Train $trainId on operational station hold",
                    "OPERATIONS"
                )
            }
        }
    }

    fun restoreService(trainId: String) {
        viewModelScope.launch {
            val target = trains.value.find { it.id == trainId }
            if (target != null) {
                val updated = target.copy(
                    status = "RUNNING",
                    delayedMinutes = 0,
                    speed = 68.0f
                )
                repository.updateTrain(updated)
                logAudit(
                    "استعادة الخدمة المنتظمة بالكامل للقطار $trainId",
                    "Restored full regular service for Train $trainId",
                    "OPERATIONS"
                )
            }
        }
    }

    fun simulateStationCrowding(stationId: String) {
        viewModelScope.launch {
            val target = stations.value.find { it.id == stationId }
            if (target != null) {
                val updated = target.copy(
                    status = "CROWDED",
                    occupancy = target.occupancy + 800,
                    concourseDensity = "HIGH"
                )
                repository.updateStation(updated)
                logAudit(
                    "محاكاة ازدحام وتدفق جماهيري مفاجئ بمحطة ${target.nameAr}",
                    "Simulated sudden passenger surge at ${target.nameEn} Station",
                    "STATIONS"
                )
            }
        }
    }

    fun toggleEscalator(stationId: String) {
        viewModelScope.launch {
            val target = stations.value.find { it.id == stationId }
            if (target != null) {
                val updated = target.copy(
                    escalatorOk = !target.escalatorOk,
                    status = if (!target.escalatorOk) "MAINTENANCE" else "OPEN"
                )
                repository.updateStation(updated)
                logAudit(
                    if (updated.escalatorOk) "إعادة تشغيل السلم الكهربائي بمحطة ${target.nameAr}" else "توقف السلم الكهربائي بمحطة ${target.nameAr} لأعمال الصيانة",
                    if (updated.escalatorOk) "Restored escalator operation at ${target.nameEn} Station" else "Escalator stoppage at ${target.nameEn} Station for maintenance",
                    "STATIONS"
                )
            }
        }
    }

    // Incident workflow actions
    fun advanceIncidentStatus(incidentId: Int, currentStatus: String) {
        viewModelScope.launch {
            val target = incidents.value.find { it.id == incidentId }
            if (target != null) {
                val nextStatus = when (currentStatus) {
                    "DETECTED" -> "ACKNOWLEDGED"
                    "ACKNOWLEDGED" -> "RESPONSE_INITIATED"
                    "RESPONSE_INITIATED" -> "RECOVERY"
                    "RECOVERY" -> "CLOSED"
                    else -> "CLOSED"
                }
                val updated = target.copy(status = nextStatus)
                repository.updateIncident(updated)
                logAudit(
                    "تحديث حالة الحادث #${incidentId} إلى: ${translateIncidentStatusAr(nextStatus)}",
                    "Updated incident #${incidentId} status to: $nextStatus",
                    "INCIDENT"
                )
            }
        }
    }

    fun createCustomIncident(titleAr: String, titleEn: String, severity: String, locationAr: String, locationEn: String, lineId: String, descriptionAr: String, descriptionEn: String) {
        viewModelScope.launch {
            val newInc = IncidentEntity(
                titleAr = titleAr,
                titleEn = titleEn,
                severity = severity,
                locationAr = locationAr,
                locationEn = locationEn,
                lineId = lineId,
                status = "DETECTED",
                owner = "Console Operator",
                detectedTime = System.currentTimeMillis(),
                descriptionAr = descriptionAr,
                descriptionEn = descriptionEn
            )
            val incId = repository.insertIncident(newInc)
            selectIncident(incId.toInt())
            logAudit(
                "تم تسجيل حادث تشغيلي جديد: $titleAr",
                "New operational incident registered: $titleEn",
                "INCIDENT"
            )
        }
    }

    // Bilingual Passenger Announcement Action
    fun publishPassengerMessage(titleAr: String, titleEn: String, bodyAr: String, bodyEn: String, priority: String, line: String) {
        viewModelScope.launch {
            val message = PassengerMessageEntity(
                titleAr = titleAr,
                titleEn = titleEn,
                bodyAr = bodyAr,
                bodyEn = bodyEn,
                priority = priority,
                targetLineId = line,
                targetStationId = "ALL",
                publishTime = System.currentTimeMillis(),
                isApproved = true
            )
            repository.insertMessage(message)
            logAudit(
                "نشر إعلان ثنائي اللغة للركاب: $titleAr",
                "Published bilingual passenger announcement: $titleEn",
                "PIS"
            )
        }
    }

    fun logAudit(actionAr: String, actionEn: String, category: String) {
        viewModelScope.launch {
            repository.insertAuditEvent(
                AuditEventEntity(
                    actionAr = actionAr,
                    actionEn = actionEn,
                    category = category,
                    timestamp = System.currentTimeMillis(),
                    operator = "CONSOLE_ENG"
                )
            )
        }
    }

    // Line Route definitions for deterministic train pathing
    private val redLineStations = listOf("S_LUS", "S_KAT", "S_WBY", "S_MSH", "S_HIA", "S_WAK")
    private val greenLineStations = listOf("S_RIF", "S_EDC", "S_HMC", "S_MSH", "S_MAN")
    private val goldLineStations = listOf("S_AZI", "S_SUQ", "S_MSH", "S_NMQ", "S_RBA")

    // Real-time Simulation Engine Loop
    private fun startSimulationLoop() {
        simJob?.cancel()
        simJob = viewModelScope.launch {
            while (true) {
                delay(2000) // Ticks every 2 seconds
                if (_isSimulating.value) {
                    val activeMult = _timeMultiplier.value
                    
                    // 1. Advance Train Positions
                    val currentTrains = trains.value
                    val currentStations = stations.value

                    currentTrains.forEach { train ->
                        if (train.status == "RUNNING") {
                            // Increment progress
                            val newProgress = train.progress + (0.04f * activeMult)
                            if (newProgress >= 1.0f) {
                                // Arrive at destination station!
                                val arrivedStationId = train.nextStationId
                                val lineStations = when (train.lineId) {
                                    "RED" -> redLineStations
                                    "GREEN" -> greenLineStations
                                    else -> goldLineStations
                                }
                                
                                val currIdx = lineStations.indexOf(arrivedStationId)
                                var nextIdx = currIdx
                                var nextDirection = train.direction

                                if (train.direction == "NORTHBOUND" || train.direction == "WESTBOUND") {
                                    if (currIdx == 0) {
                                        nextIdx = 1
                                        nextDirection = if (train.lineId == "GOLD") "EASTBOUND" else "SOUTHBOUND"
                                    } else {
                                        nextIdx = currIdx - 1
                                    }
                                } else { // SOUTHBOUND or EASTBOUND
                                    if (currIdx == lineStations.size - 1) {
                                        nextIdx = lineStations.size - 2
                                        nextDirection = if (train.lineId == "GOLD") "WESTBOUND" else "NORTHBOUND"
                                    } else {
                                        nextIdx = currIdx + 1
                                    }
                                }

                                val resolvedNextStationId = lineStations.getOrNull(nextIdx) ?: arrivedStationId

                                val updatedTrain = train.copy(
                                    currentStationId = arrivedStationId,
                                    nextStationId = resolvedNextStationId,
                                    progress = 0.0f,
                                    doorOpen = true,
                                    speed = 0f,
                                    direction = nextDirection
                                )
                                repository.updateTrain(updatedTrain)
                            } else {
                                // Mid transit speed is constant approx 70km/h
                                val speedVar = 65f + Random.nextFloat() * 10f
                                val updatedTrain = train.copy(
                                    progress = newProgress,
                                    doorOpen = false,
                                    speed = speedVar
                                )
                                repository.updateTrain(updatedTrain)
                            }
                        } else if (train.doorOpen) {
                            // Close doors and resume running after 1 tick
                            val updatedTrain = train.copy(
                                doorOpen = false,
                                speed = 68.0f,
                                status = "RUNNING"
                            )
                            repository.updateTrain(updatedTrain)
                        } else if (train.status == "DELAYED") {
                            // Slowly count down delays or maintain delayed speed
                            if (Random.nextFloat() < 0.1f) {
                                val remainingDelay = (train.delayedMinutes - 1).coerceAtLeast(0)
                                val resolvedStatus = if (remainingDelay == 0) "RUNNING" else "DELAYED"
                                val updatedTrain = train.copy(
                                    delayedMinutes = remainingDelay,
                                    status = resolvedStatus,
                                    speed = if (remainingDelay == 0) 65.0f else 0.0f
                                )
                                repository.updateTrain(updatedTrain)
                                if (remainingDelay == 0) {
                                    logAudit(
                                        "القطار ${train.id} استأنف مساره بعد انقضاء التأخير",
                                        "Train ${train.id} resumed track after delay cleared",
                                        "OPERATIONS"
                                    )
                                }
                            }
                        }
                    }

                    // 2. Fluctuating station passenger flows and demand
                    val isPeak = _isPeakDemand.value
                    currentStations.forEach { station ->
                        val baseChange = if (isPeak) Random.nextInt(15, 60) else Random.nextInt(-10, 20)
                        val multiplier = if (station.id == "S_MSH") 2.5f else 1.0f // Msheireb is busy!
                        val finalChange = (baseChange * multiplier).toInt()
                        
                        val newOccupancy = (station.occupancy + finalChange).coerceIn(100, 3000)
                        val density = when {
                            newOccupancy > 1500 -> "HIGH"
                            newOccupancy > 800 -> "MED"
                            else -> "LOW"
                        }
                        
                        val status = if (newOccupancy > 1800) "CROWDED" else station.status
                        
                        val updatedStation = station.copy(
                            occupancy = newOccupancy,
                            concourseDensity = density,
                            status = status
                        )
                        repository.updateStation(updatedStation)
                    }
                }
            }
        }
    }

    private fun translateIncidentStatusAr(status: String): String {
        return when (status) {
            "DETECTED" -> "تم الرصد"
            "ACKNOWLEDGED" -> "مؤكد / معترف به"
            "RESPONSE_INITIATED" -> "بدء الاستجابة"
            "RECOVERY" -> "في مرحلة الاستعادة"
            "CLOSED" -> "تم الإغلاق"
            else -> status
        }
    }

    override fun onCleared() {
        super.onCleared()
        simJob?.cancel()
    }
}
