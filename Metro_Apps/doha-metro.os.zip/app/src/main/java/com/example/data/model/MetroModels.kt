package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val nameAr: String,
    val nameEn: String,
    val lineId: String,
    val isInterchange: Boolean,
    val status: String, // "OPEN", "REDUCED", "CROWDED", "MAINTENANCE", "CLOSED"
    val occupancy: Int, // Simulated current people count
    val escalatorOk: Boolean,
    val liftOk: Boolean,
    val concourseDensity: String // "LOW", "MED", "HIGH"
)

@Entity(tableName = "trains")
data class TrainEntity(
    @PrimaryKey val id: String,
    val lineId: String,
    val status: String, // "RUNNING", "DELAYED", "HELD", "STOPPED", "DEPOT"
    val currentStationId: String,
    val direction: String, // "NORTHBOUND", "SOUTHBOUND", "EASTBOUND", "WESTBOUND"
    val speed: Float, // km/h
    val passengerLoad: Int, // percentage 0-100
    val doorOpen: Boolean,
    val hvacTemp: Float, // Celsius
    val delayedMinutes: Int,
    val headwaySeconds: Int,
    val progress: Float, // 0.0 to 1.0 of transit to next station
    val nextStationId: String
)

@Entity(tableName = "incidents")
data class IncidentEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val titleAr: String,
    val titleEn: String,
    val severity: String, // "CRITICAL", "MAJOR", "MINOR", "INFO"
    val locationAr: String,
    val locationEn: String,
    val lineId: String, // "RED", "GREEN", "GOLD", "ALL"
    val status: String, // "DETECTED", "ACKNOWLEDGED", "RESPONSE_INITIATED", "RECOVERY", "CLOSED"
    val owner: String,
    val detectedTime: Long,
    val descriptionAr: String,
    val descriptionEn: String
)

@Entity(tableName = "passenger_messages")
data class PassengerMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val titleAr: String,
    val titleEn: String,
    val bodyAr: String,
    val bodyEn: String,
    val priority: String, // "HIGH", "MEDIUM", "LOW"
    val targetLineId: String, // "ALL", "RED", "GREEN", "GOLD"
    val targetStationId: String, // "ALL", or Station ID
    val publishTime: Long,
    val isApproved: Boolean
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val actionAr: String,
    val actionEn: String,
    val category: String, // "SYSTEM", "SIMULATION", "OPERATIONS", "INCIDENT", "PIS"
    val timestamp: Long,
    val operator: String
)
