package com.example.data.repository

import com.example.data.local.MetroDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class MetroRepository(private val metroDao: MetroDao) {

    val allStations: Flow<List<StationEntity>> = metroDao.getAllStations()
    val allTrains: Flow<List<TrainEntity>> = metroDao.getAllTrains()
    val allIncidents: Flow<List<IncidentEntity>> = metroDao.getAllIncidents()
    val allMessages: Flow<List<PassengerMessageEntity>> = metroDao.getAllMessages()
    val allAuditEvents: Flow<List<AuditEventEntity>> = metroDao.getAllAuditEvents()

    suspend fun updateStation(station: StationEntity) = metroDao.updateStation(station)
    suspend fun updateTrain(train: TrainEntity) = metroDao.updateTrain(train)
    suspend fun insertIncident(incident: IncidentEntity): Long = metroDao.insertIncident(incident)
    suspend fun updateIncident(incident: IncidentEntity) = metroDao.updateIncident(incident)
    suspend fun insertMessage(message: PassengerMessageEntity) = metroDao.insertMessage(message)
    suspend fun updateMessage(message: PassengerMessageEntity) = metroDao.updateMessage(message)
    suspend fun insertAuditEvent(event: AuditEventEntity) = metroDao.insertAuditEvent(event)

    suspend fun seedDatabaseIfEmpty() {
        // Only seed if empty
        val stations = allStations.first()
        if (stations.isEmpty()) {
            // 1. Seed Stations
            val initialStations = listOf(
                // Red Line
                StationEntity("S_LUS", "لوسيل", "Lusail QIPCO", "RED", false, "OPEN", 240, true, true, "LOW"),
                StationEntity("S_KAT", "كتارا", "Katara", "RED", false, "OPEN", 310, true, true, "MED"),
                StationEntity("S_WBY", "الخليج الغربي", "West Bay QIC", "RED", false, "CROWDED", 750, true, true, "HIGH"),
                StationEntity("S_MSH", "مشيرب", "Msheireb", "RED", true, "OPEN", 1250, true, true, "HIGH"), // Central Interchange
                StationEntity("S_HIA", "مطار حمد الدولي", "Hamad Intl Airport", "RED", false, "OPEN", 890, true, true, "HIGH"),
                StationEntity("S_WAK", "الوكرة", "Al Wakra", "RED", false, "OPEN", 410, true, true, "MED"),

                // Green Line
                StationEntity("S_RIF", "الرفاع - قطر مول", "Al Riffa (Mall of Qatar)", "GREEN", false, "OPEN", 180, true, true, "LOW"),
                StationEntity("S_EDC", "المدينة التعليمية", "Education City", "GREEN", false, "OPEN", 340, true, true, "LOW"),
                StationEntity("S_HMC", "مستشفى حمد", "Hamad Hospital", "GREEN", false, "OPEN", 290, true, true, "LOW"),
                // Msheireb is also on Green
                StationEntity("S_MAN", "المنصورة", "Al Mansoura", "GREEN", false, "OPEN", 480, true, true, "MED"),

                // Gold Line
                StationEntity("S_AZI", "العزيزية", "Al Aziziyah", "GOLD", false, "OPEN", 220, true, true, "LOW"),
                StationEntity("S_SUQ", "سوق واقف", "Souq Waqif", "GOLD", false, "OPEN", 510, true, true, "MED"),
                // Msheireb is also on Gold
                StationEntity("S_NMQ", "متحف قطر الوطني", "National Museum", "GOLD", false, "OPEN", 430, true, true, "LOW"),
                StationEntity("S_RBA", "راس بو عبود", "Ras Bu Abboud", "GOLD", false, "OPEN", 150, true, true, "LOW")
            )
            metroDao.insertStations(initialStations)

            // 2. Seed Trains
            val initialTrains = listOf(
                TrainEntity("T_R1", "RED", "RUNNING", "S_WAK", "NORTHBOUND", 72.0f, 45, false, 21.5f, 0, 180, 0.2f, "S_HIA"),
                TrainEntity("T_R2", "RED", "RUNNING", "S_LUS", "SOUTHBOUND", 68.0f, 70, false, 22.0f, 0, 180, 0.7f, "S_KAT"),
                TrainEntity("T_R3", "RED", "RUNNING", "S_WBY", "SOUTHBOUND", 0.0f, 85, true, 21.0f, 0, 240, 0.0f, "S_MSH"),
                TrainEntity("T_G1", "GREEN", "HELD", "S_RIF", "EASTBOUND", 0.0f, 15, true, 22.5f, 5, 300, 0.0f, "S_EDC"),
                TrainEntity("T_G2", "GREEN", "RUNNING", "S_MAN", "WESTBOUND", 65.0f, 55, false, 20.8f, 0, 300, 0.4f, "S_MSH"),
                TrainEntity("T_Y1", "GOLD", "RUNNING", "S_AZI", "EASTBOUND", 70.0f, 30, false, 21.2f, 0, 360, 0.8f, "S_SUQ"),
                TrainEntity("T_Y2", "GOLD", "DEPOT", "S_RBA", "WESTBOUND", 0.0f, 0, false, 24.0f, 0, 0, 0.0f, "S_NMQ")
            )
            metroDao.insertTrains(initialTrains)

            // 3. Seed active default incident
            val initialIncident = IncidentEntity(
                titleAr = "عطل مؤقت في السلم المتحرك بمحطة مشيرب",
                titleEn = "Temporary escalator outage at Msheireb Station",
                severity = "MINOR",
                locationAr = "رصيف الخط الأحمر - مشيرب",
                locationEn = "Red Line Platform - Msheireb",
                lineId = "RED",
                status = "RESPONSE_INITIATED",
                owner = "Eng. Ahmed Al-Sada",
                detectedTime = System.currentTimeMillis() - 1800000, // 30 mins ago
                descriptionAr = "تم رصد توقف مفاجئ في السلم الكهربائي المؤدي لرصيف الخط الأحمر. جاري العمل على الصيانة من قبل الفريق الفني المعني.",
                descriptionEn = "A sudden stoppage was detected on escalator E-204 leading to the Red Line platform. Technical maintenance team is currently working on resolution."
            )
            metroDao.insertIncident(initialIncident)

            // 4. Seed default passenger announcement message
            val initialMessage = PassengerMessageEntity(
                titleAr = "حالة الخدمة: انتظام حركة القطارات",
                titleEn = "Service Status: Regular Operations",
                bodyAr = "نود إعلام السادة الركاب بأن جميع خطوط مترو الدوحة تعمل بشكل طبيعي ومنتظم. نتمنى لكم رحلة سعيدة.",
                bodyEn = "We would like to inform our passengers that all Doha Metro lines are operating normally and with regular headways. Have a pleasant journey.",
                priority = "LOW",
                targetLineId = "ALL",
                targetStationId = "ALL",
                publishTime = System.currentTimeMillis(),
                isApproved = true
            )
            metroDao.insertMessage(initialMessage)

            // 5. Seed Audit Events
            val initEvents = listOf(
                AuditEventEntity(
                    actionAr = "تم تهيئة نظام تشغيل مترو الدوحة بالكامل",
                    actionEn = "Doha Metro.OS system initialized fully",
                    category = "SYSTEM",
                    timestamp = System.currentTimeMillis() - 3600000,
                    operator = "SYS_ADMIN"
                ),
                AuditEventEntity(
                    actionAr = "تم تحميل بيانات البنية التحتية الافتراضية ومواقع المحطات",
                    actionEn = "Default infrastructure and station spatial models loaded",
                    category = "SYSTEM",
                    timestamp = System.currentTimeMillis() - 3500000,
                    operator = "SYS_ADMIN"
                ),
                AuditEventEntity(
                    actionAr = "تم تفعيل محاكي حركة القطارات وحسابات الفواصل الزمنية",
                    actionEn = "Train movement and headway spacing simulators started",
                    category = "SIMULATION",
                    timestamp = System.currentTimeMillis() - 3400000,
                    operator = "SYS_SIM"
                )
            )
            for (ev in initEvents) {
                metroDao.insertAuditEvent(ev)
            }
        }
    }
}
