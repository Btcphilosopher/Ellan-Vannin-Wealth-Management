package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Colors
val QatarMaroon = Color(0xFF8A1538)
val WarmSand = Color(0xFFDCC2A9)
val SandLight = Color(0xFFFAF8F5)
val DesertSand = Color(0xFFE6D5C3)

// Base Grays
val Graphite = Color(0xFF1E1F22)
val DeepCharcoal = Color(0xFF121315)
val StainlessSteel = Color(0xFFE2E8F0)
val SlateGrey = Color(0xFF64748B)

// Operational Signals
val SignalRed = Color(0xFFEF4444)
val OperationalGreen = Color(0xFF10B981)
val TechnicalBlue = Color(0xFF3B82F6)

// Line Specific Colors
val MetroRedLine = Color(0xFFE11D48)
val MetroGreenLine = Color(0xFF059669)
val MetroGoldLine = Color(0xFFD97706)
val MetroInterchange = Color(0xFF7C3AED)
