package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = QatarMaroon,
    secondary = WarmSand,
    tertiary = SlateGrey,
    background = DeepCharcoal,
    surface = Graphite,
    onPrimary = Color.White,
    onSecondary = DeepCharcoal,
    onTertiary = Color.White,
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9),
    error = SignalRed
)

private val LightColorScheme = lightColorScheme(
    primary = QatarMaroon,
    secondary = DesertSand,
    tertiary = SlateGrey,
    background = SandLight,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = DeepCharcoal,
    onTertiary = Color.White,
    onBackground = DeepCharcoal,
    onSurface = DeepCharcoal,
    error = SignalRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
