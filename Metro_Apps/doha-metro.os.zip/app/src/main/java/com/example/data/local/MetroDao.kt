package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {

    // Station operations
    @Query("SELECT * FROM stations")
    fun getAllStations(): Flow<List<StationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)

    @Update
    suspend fun updateStation(station: StationEntity)

    @Query("UPDATE stations SET status = :status WHERE id = :stationId")
    suspend fun updateStationStatus(stationId: String, status: String)

    @Query("UPDATE stations SET occupancy = :occupancy WHERE id = :stationId")
    suspend fun updateStationOccupancy(stationId: String, occupancy: Int)

    // Train operations
    @Query("SELECT * FROM trains")
    fun getAllTrains(): Flow<List<TrainEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrains(trains: List<TrainEntity>)

    @Update
    suspend fun updateTrain(train: TrainEntity)

    @Query("UPDATE trains SET delayedMinutes = :delayMinutes, status = :status WHERE id = :trainId")
    suspend fun updateTrainDelay(trainId: String, delayMinutes: Int, status: String)

    // Incident operations
    @Query("SELECT * FROM incidents ORDER BY detectedTime DESC")
    fun getAllIncidents(): Flow<List<IncidentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncident(incident: IncidentEntity): Long

    @Update
    suspend fun updateIncident(incident: IncidentEntity)

    // Passenger message operations
    @Query("SELECT * FROM passenger_messages ORDER BY publishTime DESC")
    fun getAllMessages(): Flow<List<PassengerMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: PassengerMessageEntity)

    @Update
    suspend fun updateMessage(message: PassengerMessageEntity)

    // Audit operations
    @Query("SELECT * FROM audit_events ORDER BY timestamp DESC")
    fun getAllAuditEvents(): Flow<List<AuditEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditEvent(event: AuditEventEntity)
}
