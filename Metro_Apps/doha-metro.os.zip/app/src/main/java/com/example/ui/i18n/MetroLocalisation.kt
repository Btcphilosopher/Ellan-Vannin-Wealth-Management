package com.example.ui.i18n

object MetroLocalisation {

    private val translations = mapOf(
        "app_title" to Pair("نظام تشغيل مترو الدوحة", "DOHA METRO.OS"),
        "subtitle" to Pair("مؤسسة سكك الحديد القطرية (الريل) • بيئة تشغيل تجريبية افتراضية", "Qatar Rail • Synthetic Demonstration Environment"),
        "lang_switch" to Pair("العربية | English", "English | العربية"),
        "tab_network" to Pair("نظرة عامة على الشبكة", "Network Overview"),
        "tab_operations" to Pair("مركز التحكم بالعمليات", "Operations Control"),
        "tab_stations" to Pair("التوأم الرقمي للمحطة", "Station Twin"),
        "tab_fleet" to Pair("تشخيص الأسطول", "Fleet Diagnostics"),
        "tab_incidents" to Pair("مركز الحوادث التشغيلية", "Incident Centre"),
        "tab_passengers" to Pair("إرشادات الركاب والرحلات", "Passenger Info"),
        "tab_analytics" to Pair("التحليلات والأداء", "Analytics & Stats"),
        "tab_audit" to Pair("سجل التدقيق الأمني", "Audit Log"),

        // Service Status Terms
        "status_good" to Pair("الخدمة منتظمة", "Good Service"),
        "status_minor" to Pair("تأخير بسيط", "Minor Delay"),
        "status_major" to Pair("اضطراب كبير", "Major Disruption"),
        "status_suspended" to Pair("الخدمة متوقفة", "Service Suspended"),

        // Operational stats
        "active_trains" to Pair("القطارات النشطة", "Active Trains"),
        "trains_depot" to Pair("القطارات بالمستودع", "Trains in Depot"),
        "stations_operational" to Pair("المحطات المشغلة", "Stations Operational"),
        "sim_demand" to Pair("طلب الركاب الحالي", "Current Demand"),
        "avg_headway" to Pair("متوسط التقاطر", "Average Headway"),
        "open_incidents" to Pair("الحوادث النشطة", "Open Incidents"),
        "fleet_avail" to Pair("جاهزية الأسطول", "Fleet Availability"),
        "energy_demand" to Pair("الطلب على الطاقة", "Energy Demand"),
        "escalator_avail" to Pair("جاهزية السلالم المتحركة", "Escalator Availability"),
        "lift_avail" to Pair("جاهزية المصاعد", "Lift Availability"),
        "planned_engineering" to Pair("الأعمال الهندسية المخططة", "Planned Engineering"),
        "system_health" to Pair("سلامة النظام الرئيسي", "System Health"),
        
        // Control room controls
        "sim_controls" to Pair("أدوات التحكم بالمحاكاة", "Simulation Controls"),
        "sim_start" to Pair("تشغيل المحاكاة", "Start Simulation"),
        "sim_pause" to Pair("إيقاف مؤقت", "Pause Simulation"),
        "sim_reset" to Pair("إعادة تعيين", "Reset Simulation"),
        "time_multiplier" to Pair("مضاعف وقت المحاكاة", "Time Multiplier"),
        "inject_delay" to Pair("حقن تأخير تشغيلي", "Inject Delay"),
        "hold_train" to Pair("حجز القطار بالمحطة", "Hold Train"),
        "release_train" to Pair("إلغاء حجز القطار", "Release Train"),
        "restore_service" to Pair("استعادة انتظام الخدمة", "Restore Service"),
        "simulate_surge" to Pair("محاكاة تدفق جماهيري", "Simulate Crowd Surge"),
        "toggle_escalator" to Pair("عطل/تشغيل السلم المتحرك", "Toggle Escalator"),
        "peak_mode" to Pair("وضع ذروة الركاب", "Peak Demand Mode"),
        "non_peak" to Pair("الخدمة العادية خارج الذروة", "Off-Peak Service"),

        // Metadata labels
        "synthetic_data" to Pair("بيانات تشغيلية افتراضية وافتراضات المحاكاة نشطة", "SYNTHETIC OPERATIONAL DATA & SIMULATION MODEL ACTIVE"),
        "classification" to Pair("التصنيف الرئيسي للمعلومات: داخلي - للاستخدام التجريبي فقط", "Source Classification: Internal - Demo Use Only"),
        "timestamp" to Pair("طابع التاريخ والوقت", "Data Timestamp"),
        "definition" to Pair("التعريف الفني للأصل", "Technical Definition"),
        
        // Station details
        "station_id" to Pair("معرف المحطة", "Station ID"),
        "lines_served" to Pair("الخطوط التي تخدمها", "Lines Served"),
        "interchange_status" to Pair("حالة التقاطع/التبادل", "Interchange Station"),
        "platforms" to Pair("الأرصفة المتاحة", "Platforms"),
        "facilities" to Pair("مرافق المحطة", "Station Facilities"),
        "occupancy" to Pair("نسبة الإشغال المقدرة", "Simulated Occupancy"),
        "concourse_density" to Pair("كثافة صالة الركاب", "Concourse Density"),
        
        // Train / Fleet terms
        "train_id" to Pair("معرف القطار", "Train ID"),
        "fleet_class" to Pair("فئة الأسطول", "Fleet Class"),
        "formation" to Pair("تكوين القطار", "Train Formation"),
        "carriage_count" to Pair("عدد العربات", "Carriage Count"),
        "capacity_assumption" to Pair("السعة المقدرة", "Design Capacity"),
        "status" to Pair("الحالة التشغيلية", "Operational Status"),
        "current_loc" to Pair("الموقع الحالي", "Current Position"),
        "mileage" to Pair("إجمالي الكيلومترات المقطوعة", "Odometer Estimate"),
        "hvac_status" to Pair("تكييف الهواء HVAC", "HVAC Temp Controller"),
        "doors" to Pair("حالة الأبواب", "Door Status"),
        "battery_power" to Pair("البطارية المساعدة", "Auxiliary Battery"),
        "brake_status" to Pair("نظام الفرامل الميكانيكي", "Braking System Indicator"),

        // Incidents Management
        "severity" to Pair("مستوى الخطورة", "Severity Level"),
        "owner" to Pair("مسؤول الاستجابة المعين", "Incident Response Owner"),
        "detection_time" to Pair("وقت رصد الحادث", "Detection Timestamp"),
        "operational_impact" to Pair("الأثر التشغيلي على الشبكة", "Network Operational Impact"),
        "pis_status" to Pair("حالة لوحات معلومات الركاب", "PIS Status"),
        "timeline" to Pair("المسار الزمني للإجراءات", "Incident Action Timeline"),
        "advance_status" to Pair("تصعيد حالة الاستجابة", "Advance Action Status"),
        "create_incident" to Pair("تسجيل حادث تشغيلي جديد", "Register New Incident"),
        "location" to Pair("الموقع الجغرافي", "Location"),
        "description" to Pair("الوصف التفصيلي للحادث", "Detailed Description"),
        "announcement_draft" to Pair("مسودة إعلان الركاب", "Draft Announcement for Passengers"),
        "announcement_body" to Pair("نص الإعلان (ثنائي اللغة)", "Announcement Text (Bilingual)"),
        "publish" to Pair("نشر الإعلان على اللوحات", "Publish Announcement"),

        // Journey Planner & Ticketing
        "origin" to Pair("محطة الانطلاق", "Origin Station"),
        "destination" to Pair("محطة الوصول", "Destination Station"),
        "find_route" to Pair("تخطيط الرحلة والمسار", "Plan Journey"),
        "duration" to Pair("المدة الزمنية المقدرة", "Estimated Duration"),
        "fare" to Pair("تعرفة الرحلة (افتراضية)", "Fictional Fare Rate"),
        "smart_card" to Pair("بطاقة رحلات المترو الذكية", "Doha Metro Travel Card"),
        "balance" to Pair("الرصيد المتاح", "Card Balance"),
        "route_steps" to Pair("خطوات وتفاصيل المسار الموصى به", "Recommended Route Details"),

        // Analytics
        "punctuality" to Pair("معدل انتظام المواعيد الدقيقة", "On-Time Punctuality Index"),
        "reliability" to Pair("معدل موثوقية الشبكة الإجمالي", "Overall Network Reliability"),
        "energy_eff" to Pair("كفاءة استهلاك طاقة الجر", "Traction Energy Efficiency"),
        "energy_consumption_label" to Pair("استهلاك طاقة الجر (ميجاوات ساعة)", "Traction Energy Consumption (MWh)"),
        "environmental_lab" to Pair("مختبر البيئة ومحاكاة الحرارة العظمى", "Environmental Scenario Laboratory"),

        // Audit Log
        "time" to Pair("التوقيت", "Time"),
        "operator" to Pair("المشغل المسؤول", "Operator"),
        "action" to Pair("الإجراء المتخذ والحدث التشغيلي", "Recorded Event / Operator Action"),
        "category" to Pair("الفئة", "Category")
    )

    fun translate(key: String, isArabic: Boolean): String {
        val entry = translations[key] ?: return key
        return if (isArabic) entry.first else entry.second
    }

    fun translateLine(lineId: String, isArabic: Boolean): String {
        return when (lineId) {
            "RED" -> if (isArabic) "الخط الأحمر" else "Red Line"
            "GREEN" -> if (isArabic) "الخط الأخضر" else "Green Line"
            "GOLD" -> if (isArabic) "الخط الذهبي" else "Gold Line"
            "ALL" -> if (isArabic) "جميع الخطوط" else "All Lines"
            else -> lineId
        }
    }

    fun translateSeverity(severity: String, isArabic: Boolean): String {
        return when (severity) {
            "CRITICAL" -> if (isArabic) "حرجة للغاية" else "CRITICAL"
            "MAJOR" -> if (isArabic) "خطيرة / كبرى" else "MAJOR"
            "MINOR" -> if (isArabic) "بسيطة / صغرى" else "MINOR"
            "INFO" -> if (isArabic) "معلومات عامة" else "INFORMATION"
            else -> severity
        }
    }

    fun translateStatus(status: String, isArabic: Boolean): String {
        return when (status) {
            "OPEN" -> if (isArabic) "مفتوحة ومتاحة" else "Open & Active"
            "REDUCED" -> if (isArabic) "خدمة مخفضة" else "Reduced Service"
            "CROWDED" -> if (isArabic) "مزدحمة للغاية" else "Extremely Crowded"
            "MAINTENANCE" -> if (isArabic) "تحت أعمال الصيانة" else "Maintenance Active"
            "CLOSED" -> if (isArabic) "مغلقة مؤقتاً" else "Temporarily Closed"
            
            "RUNNING" -> if (isArabic) "يسير بانتظام" else "Running Normally"
            "DELAYED" -> if (isArabic) "متأخر تشغيلياً" else "Delayed"
            "HELD" -> if (isArabic) "محتجز مؤقتاً" else "Held at Station"
            "STOPPED" -> if (isArabic) "متوقف بالكامل" else "Stopped on Track"
            "DEPOT" -> if (isArabic) "في المستودع (خارج الخدمة)" else "In Depot"
            else -> status
        }
    }

    fun translateIncidentStatus(status: String, isArabic: Boolean): String {
        return when (status) {
            "DETECTED" -> if (isArabic) "تم رصد الحادث" else "Detected"
            "ACKNOWLEDGED" -> if (isArabic) "تم التأكيد والمراجعة" else "Acknowledged"
            "RESPONSE_INITIATED" -> if (isArabic) "تم إطلاق الاستجابة" else "Response Initiated"
            "RECOVERY" -> if (isArabic) "في مرحلة الاستعادة والتعافي" else "Recovery Mode"
            "CLOSED" -> if (isArabic) "تم إغلاق الحادث وحله" else "Incident Closed"
            else -> status
        }
    }
}
