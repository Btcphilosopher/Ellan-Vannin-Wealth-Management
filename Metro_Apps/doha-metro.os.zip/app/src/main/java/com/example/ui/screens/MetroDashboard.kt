package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.*
import com.example.ui.MetroTab
import com.example.ui.MetroViewModel
import com.example.ui.i18n.MetroLocalisation
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetroDashboard(viewModel: MetroViewModel) {
    val isArabic by viewModel.isArabic.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()

    val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = MetroLocalisation.translate("app_title", isArabic),
                                color = QatarMaroon,
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp,
                                fontFamily = FontFamily.SansSerif
                            )
                            Text(
                                text = MetroLocalisation.translate("subtitle", isArabic),
                                color = SlateGrey,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    actions = {
                        // Language switcher
                        Button(
                            onClick = { viewModel.toggleLanguage() },
                            colors = ButtonDefaults.buttonColors(containerColor = QatarMaroon),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.Language, contentDescription = "Language")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = MetroLocalisation.translate("lang_switch", isArabic),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DeepCharcoal
                    )
                )
            },
            containerColor = DeepCharcoal
        ) { paddingValues ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(DeepCharcoal)
            ) {
                // Sidebar / Navigation Rail (RTL aware automatically)
                NavigationSidebar(
                    currentTab = currentTab,
                    isArabic = isArabic,
                    onTabSelected = { viewModel.setTab(it) }
                )

                VerticalDivider(color = Graphite, thickness = 1.dp)

                // Main Content Viewport
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .background(DeepCharcoal)
                        .padding(16.dp)
                ) {
                    when (currentTab) {
                        MetroTab.NETWORK -> NetworkOverviewTab(viewModel, isArabic)
                        MetroTab.OPERATIONS -> OperationsTab(viewModel, isArabic)
                        MetroTab.STATIONS -> StationsTab(viewModel, isArabic)
                        MetroTab.FLEET -> FleetTab(viewModel, isArabic)
                        MetroTab.INCIDENTS -> IncidentsTab(viewModel, isArabic)
                        MetroTab.PASSENGERS -> PassengersTab(viewModel, isArabic)
                        MetroTab.ANALYTICS -> AnalyticsTab(viewModel, isArabic)
                        MetroTab.AUDIT -> AuditTab(viewModel, isArabic)
                    }
                }
            }
        }
    }
}

@Composable
fun NavigationSidebar(
    currentTab: MetroTab,
    isArabic: Boolean,
    onTabSelected: (MetroTab) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(220.dp)
            .background(DeepCharcoal)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        val menuItems = listOf(
            Triple(MetroTab.NETWORK, Icons.Default.GridOn, "tab_network"),
            Triple(MetroTab.OPERATIONS, Icons.Default.SettingsInputAntenna, "tab_operations"),
            Triple(MetroTab.STATIONS, Icons.Default.Storefront, "tab_stations"),
            Triple(MetroTab.FLEET, Icons.Default.DirectionsSubway, "tab_fleet"),
            Triple(MetroTab.INCIDENTS, Icons.Default.NewReleases, "tab_incidents"),
            Triple(MetroTab.PASSENGERS, Icons.Default.Campaign, "tab_passengers"),
            Triple(MetroTab.ANALYTICS, Icons.Default.BarChart, "tab_analytics"),
            Triple(MetroTab.AUDIT, Icons.Default.History, "tab_audit")
        )

        menuItems.forEach { (tab, icon, labelKey) ->
            val isSelected = currentTab == tab
            val bg = if (isSelected) QatarMaroon else Color.Transparent
            val fg = if (isSelected) Color.White else SlateGrey

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(bg)
                    .clickable { onTabSelected(tab) }
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = fg,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = MetroLocalisation.translate(labelKey, isArabic),
                    color = fg,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Operating System Identity footer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Graphite)
                .padding(10.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "DOHA METRO.OS",
                    color = WarmSand,
                    fontWeight = FontWeight.Black,
                    fontSize = 10.sp
                )
                Text(
                    text = "VER 3.6.48-SECURE",
                    color = SlateGrey,
                    fontWeight = FontWeight.Bold,
                    fontSize = 8.sp
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(OperationalGreen, CircleShape)
                    )
                    Text(
                        text = if (isArabic) "اتصال مؤمن" else "SECURE LINK",
                        color = OperationalGreen,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ----------------- SUB-TABS IMPLEMENTATION -----------------

@Composable
fun NetworkOverviewTab(viewModel: MetroViewModel, isArabic: Boolean) {
    val stations by viewModel.stations.collectAsStateWithLifecycle()
    val trains by viewModel.trains.collectAsStateWithLifecycle()
    val incidents by viewModel.incidents.collectAsStateWithLifecycle()
    val isSimulating by viewModel.isSimulating.collectAsStateWithLifecycle()
    val isPeak by viewModel.isPeakDemand.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Warning Banner
        SyntheticBanner(isArabic)

        // KPI Highlights
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val totalDemand = stations.sumOf { it.occupancy }
            val activeTrainsCount = trains.filter { it.status == "RUNNING" || it.status == "DELAYED" }.size
            val openIncCount = incidents.filter { it.status != "CLOSED" }.size

            KpiCard(
                title = MetroLocalisation.translate("status_good", isArabic),
                subtitle = if (isArabic) "جميع الخطوط تعمل بانتظام" else "All Lines Operating Normally",
                value = if (isArabic) "الخدمة منتظمة" else "GOOD SERVICE",
                color = OperationalGreen,
                icon = Icons.Default.CheckCircle,
                modifier = Modifier.weight(1f)
            )
            KpiCard(
                title = MetroLocalisation.translate("active_trains", isArabic),
                subtitle = if (isArabic) "على شبكة السكك الحديدية" else "Active on Guideway",
                value = "$activeTrainsCount / ${trains.size}",
                color = TechnicalBlue,
                icon = Icons.Default.DirectionsSubway,
                modifier = Modifier.weight(1f)
            )
            KpiCard(
                title = MetroLocalisation.translate("sim_demand", isArabic),
                subtitle = if (isArabic) "ركاب في المحطات والقطارات" else "Aggregated Network Load",
                value = "$totalDemand",
                color = WarmSand,
                icon = Icons.Default.People,
                modifier = Modifier.weight(1f)
            )
            KpiCard(
                title = MetroLocalisation.translate("open_incidents", isArabic),
                subtitle = if (isArabic) "قيد المعالجة التشغيلية" else "Under Control Room Management",
                value = "$openIncCount",
                color = if (openIncCount > 0) SignalRed else SlateGrey,
                icon = Icons.Default.NewReleases,
                modifier = Modifier.weight(1f)
            )
        }

        // Mid Panel with Simulation Controller & Interactive Metro Map
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Interactive Controls Side
            Card(
                colors = CardDefaults.cardColors(containerColor = Graphite),
                modifier = Modifier
                    .width(300.dp)
                    .fillMaxHeight(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = MetroLocalisation.translate("sim_controls", isArabic),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    // Sim Play/Pause Button
                    Button(
                        onClick = { viewModel.toggleSimulation() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSimulating) QatarMaroon else OperationalGreen
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isSimulating) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSimulating)
                                MetroLocalisation.translate("sim_pause", isArabic)
                            else
                                MetroLocalisation.translate("sim_start", isArabic),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    HorizontalDivider(color = DeepCharcoal)

                    // Multipliers
                    Text(
                        text = MetroLocalisation.translate("time_multiplier", isArabic),
                        color = SlateGrey,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    val multipliers = listOf(1.0f, 2.0f, 5.0f)
                    val activeMult by viewModel.timeMultiplier.collectAsStateWithLifecycle()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        multipliers.forEach { m ->
                            OutlinedButton(
                                onClick = { viewModel.setTimeMultiplier(m) },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = if (activeMult == m) WarmSand else SlateGrey,
                                    containerColor = if (activeMult == m) QatarMaroon else Color.Transparent
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (activeMult == m) QatarMaroon else SlateGrey
                                ),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(text = "${m.toInt()}x", fontSize = 11.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }

                    HorizontalDivider(color = DeepCharcoal)

                    // Operational regime selector
                    Text(
                        text = if (isArabic) "وضع الخدمة والطلب" else "Service Demands Regime",
                        color = SlateGrey,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = MetroLocalisation.translate("non_peak", isArabic),
                            color = if (isPeak) SlateGrey else Color.White,
                            fontSize = 11.sp,
                            fontWeight = if (!isPeak) FontWeight.Bold else FontWeight.Normal
                        )
                        Switch(
                            checked = isPeak,
                            onCheckedChange = { viewModel.setPeakDemand(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = QatarMaroon,
                                checkedTrackColor = WarmSand
                            )
                        )
                        Text(
                            text = MetroLocalisation.translate("peak_mode", isArabic),
                            color = if (isPeak) Color.White else SlateGrey,
                            fontSize = 11.sp,
                            fontWeight = if (isPeak) FontWeight.Bold else FontWeight.Normal
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // System Specs Information
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DeepCharcoal)
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "SYSTEM INTEGRITY STATS",
                                color = SlateGrey,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = MetroLocalisation.translate("system_health", isArabic),
                                    color = Color.White,
                                    fontSize = 10.sp
                                )
                                Text(text = "99.98%", color = OperationalGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = MetroLocalisation.translate("fleet_avail", isArabic),
                                    color = Color.White,
                                    fontSize = 10.sp
                                )
                                Text(text = "100%", color = OperationalGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Interactive Schematic Metro Network Map Block
            Card(
                colors = CardDefaults.cardColors(containerColor = Graphite),
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isArabic) "خريطة الشبكة الرقمية التفاعلية" else "Interactive Digital Network Map",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (isArabic) "تحديث فوري لتمثيل حركات القطارات التقاطعية" else "Real-time interactive spatial twin schematic layout",
                                color = SlateGrey,
                                fontSize = 10.sp
                            )
                        }
                        // Legend
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LegendDot("RED", MetroRedLine)
                            LegendDot("GREEN", MetroGreenLine)
                            LegendDot("GOLD", MetroGoldLine)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Stylized map drawing canvas!
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .border(1.dp, DeepCharcoal, RoundedCornerShape(8.dp))
                            .background(DeepCharcoal)
                    ) {
                        MetroInteractiveCanvas(stations, trains, viewModel, isArabic)
                    }
                }
            }
        }
    }
}

@Composable
fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(color, CircleShape)
        )
        Text(text = label, color = SlateGrey, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MetroInteractiveCanvas(
    stations: List<StationEntity>,
    trains: List<TrainEntity>,
    viewModel: MetroViewModel,
    isArabic: Boolean
) {
    // Dynamic coordinate mapping helper
    fun getCoords(stationId: String): Offset {
        return when (stationId) {
            "S_RIF" -> Offset(0.12f, 0.25f)
            "S_EDC" -> Offset(0.32f, 0.32f)
            "S_HMC" -> Offset(0.48f, 0.38f)
            "S_MSH" -> Offset(0.58f, 0.50f) // Central Interchange
            "S_MAN" -> Offset(0.68f, 0.60f)

            "S_LUS" -> Offset(0.58f, 0.08f)
            "S_KAT" -> Offset(0.58f, 0.20f)
            "S_WBY" -> Offset(0.58f, 0.34f)
            "S_HIA" -> Offset(0.82f, 0.68f)
            "S_WAK" -> Offset(0.58f, 0.88f)

            "S_AZI" -> Offset(0.12f, 0.72f)
            "S_SUQ" -> Offset(0.38f, 0.58f)
            "S_NMQ" -> Offset(0.72f, 0.50f)
            "S_RBA" -> Offset(0.88f, 0.50f)
            else -> Offset(0.5f, 0.5f)
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()
        val density = androidx.compose.ui.platform.LocalDensity.current.density

        Canvas(modifier = Modifier.fillMaxSize()) {
            // 1. Draw Network Track lines
            // Red Line (Lusail to Al Wakra & branch to HIA)
            val redPoints = listOf("S_LUS", "S_KAT", "S_WBY", "S_MSH", "S_WAK")
            for (i in 0 until redPoints.size - 1) {
                val p1 = getCoords(redPoints[i])
                val p2 = getCoords(redPoints[i + 1])
                drawLine(
                    color = MetroRedLine,
                    start = Offset(p1.x * width, p1.y * height),
                    end = Offset(p2.x * width, p2.y * height),
                    strokeWidth = 6f
                )
            }
            // Branch to airport from Msheireb
            val pMsh = getCoords("S_MSH")
            val pHia = getCoords("S_HIA")
            drawLine(
                color = MetroRedLine,
                start = Offset(pMsh.x * width, pMsh.y * height),
                end = Offset(pHia.x * width, pHia.y * height),
                strokeWidth = 6f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
            )

            // Green Line
            val greenPoints = listOf("S_RIF", "S_EDC", "S_HMC", "S_MSH", "S_MAN")
            for (i in 0 until greenPoints.size - 1) {
                val p1 = getCoords(greenPoints[i])
                val p2 = getCoords(greenPoints[i + 1])
                drawLine(
                    color = MetroGreenLine,
                    start = Offset(p1.x * width, p1.y * height),
                    end = Offset(p2.x * width, p2.y * height),
                    strokeWidth = 6f
                )
            }

            // Gold Line
            val goldPoints = listOf("S_AZI", "S_SUQ", "S_MSH", "S_NMQ", "S_RBA")
            for (i in 0 until goldPoints.size - 1) {
                val p1 = getCoords(goldPoints[i])
                val p2 = getCoords(goldPoints[i + 1])
                drawLine(
                    color = MetroGoldLine,
                    start = Offset(p1.x * width, p1.y * height),
                    end = Offset(p2.x * width, p2.y * height),
                    strokeWidth = 6f
                )
            }
        }

        // 2. Overlay clickable Station Node markers
        stations.forEach { station ->
            val relPos = getCoords(station.id)
            val leftOffset = relPos.x * width
            val topOffset = relPos.y * height

            val markerColor = when (station.status) {
                "CROWDED" -> SignalRed
                "MAINTENANCE" -> MetroGoldLine
                else -> Color.White
            }

            val size = if (station.isInterchange) 18.dp else 12.dp

            Box(
                modifier = Modifier
                    .offset(
                        x = (leftOffset / density - (size.value / 2)).dp,
                        y = (topOffset / density - (size.value / 2)).dp
                    )
                    .size(size)
                    .clip(CircleShape)
                    .background(DeepCharcoal)
                    .border(
                        width = if (station.isInterchange) 3.dp else 2.dp,
                        color = markerColor,
                        shape = CircleShape
                    )
                    .clickable {
                        viewModel.selectStation(station.id)
                        viewModel.setTab(MetroTab.STATIONS)
                    }
            )

            // Text Label
            Box(
                modifier = Modifier
                    .offset(
                        x = (leftOffset / density + (size.value / 1.5f)).dp,
                        y = (topOffset / density - 6).dp
                    )
            ) {
                Text(
                    text = if (isArabic) station.nameAr else station.nameEn,
                    color = StainlessSteel,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier
                        .background(DeepCharcoal.copy(alpha = 0.75f), RoundedCornerShape(2.dp))
                        .padding(horizontal = 2.dp, vertical = 1.dp)
                )
            }
        }

        // 3. Draw active Train Positions dynamically!
        trains.forEach { train ->
            if (train.status != "DEPOT") {
                val pCurr = getCoords(train.currentStationId)
                val pNext = getCoords(train.nextStationId)
                
                // Linear interpolation based on progress
                val tx = pCurr.x + (pNext.x - pCurr.x) * train.progress
                val ty = pCurr.y + (pNext.y - pCurr.y) * train.progress

                val trainColor = when (train.lineId) {
                    "RED" -> MetroRedLine
                    "GREEN" -> MetroGreenLine
                    else -> MetroGoldLine
                }

                Box(
                    modifier = Modifier
                        .offset(
                            x = ((tx * width) / density - 6).dp,
                            y = ((ty * height) / density - 6).dp
                        )
                        .size(12.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(trainColor)
                        .border(1.dp, Color.White, RoundedCornerShape(3.dp))
                        .clickable {
                            viewModel.selectTrain(train.id)
                            viewModel.setTab(MetroTab.OPERATIONS)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = train.id.replace("T_", ""),
                        color = Color.White,
                        fontSize = 6.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}


@Composable
fun OperationsTab(viewModel: MetroViewModel, isArabic: Boolean) {
    val trains by viewModel.trains.collectAsStateWithLifecycle()
    val selectedTrainId by viewModel.selectedTrainId.collectAsStateWithLifecycle()
    val stations by viewModel.stations.collectAsStateWithLifecycle()

    val activeTrain = trains.find { it.id == selectedTrainId } ?: trains.firstOrNull()

    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        // Left Side: Active trains list
        Card(
            colors = CardDefaults.cardColors(containerColor = Graphite),
            modifier = Modifier
                .width(360.dp)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isArabic) "شاشات المراقبة والتحكم بالقطارات" else "Train Control Monitoring",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(trains) { train ->
                        val isSelected = train.id == activeTrain?.id
                        val borderCol = if (isSelected) QatarMaroon else Color.Transparent

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(DeepCharcoal)
                                .border(1.5.dp, borderCol, RoundedCornerShape(8.dp))
                                .clickable { viewModel.selectTrain(train.id) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Line indicator circle
                            val lineCol = when (train.lineId) {
                                "RED" -> MetroRedLine
                                "GREEN" -> MetroGreenLine
                                else -> MetroGoldLine
                            }
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(lineCol, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${MetroLocalisation.translate("train_id", isArabic)} ${train.id}",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${MetroLocalisation.translateLine(train.lineId, isArabic)} • ${train.direction}",
                                    color = SlateGrey,
                                    fontSize = 10.sp
                                )
                            }

                            // Speed indicator
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${train.speed.toInt()} km/h",
                                    color = WarmSand,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = MetroLocalisation.translateStatus(train.status, isArabic),
                                    color = if (train.status == "DELAYED") SignalRed else OperationalGreen,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Right Side: Details and action controls
        Card(
            colors = CardDefaults.cardColors(containerColor = Graphite),
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (activeTrain != null) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${MetroLocalisation.translate("train_id", isArabic)} ${activeTrain.id}",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "${MetroLocalisation.translateLine(activeTrain.lineId, isArabic)} • ${activeTrain.direction}",
                                color = WarmSand,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Current Status Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (activeTrain.status == "DELAYED") SignalRed.copy(alpha = 0.2f) else OperationalGreen.copy(alpha = 0.2f))
                                .border(1.dp, if (activeTrain.status == "DELAYED") SignalRed else OperationalGreen, RoundedCornerShape(6.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = MetroLocalisation.translateStatus(activeTrain.status, isArabic),
                                color = if (activeTrain.status == "DELAYED") SignalRed else OperationalGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    // Simulated Schematic alignment track animation
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepCharcoal, RoundedCornerShape(8.dp))
                            .padding(16.dp)
                    ) {
                        Text(
                            text = if (isArabic) "مسار التقدم الفوري بين المحطات" else "Real-time Inter-station Guideway Transit",
                            color = SlateGrey,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        val currStat = stations.find { it.id == activeTrain.currentStationId }
                        val nextStat = stations.find { it.id == activeTrain.nextStationId }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Current Station node
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(0.2f)) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(QatarMaroon, CircleShape)
                                        .border(2.dp, Color.White, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Storefront, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (currStat != null) (if (isArabic) currStat.nameAr else currStat.nameEn) else activeTrain.currentStationId,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }

                            // Dynamic Transit line with moving train indicator
                            Box(
                                modifier = Modifier
                                    .weight(0.6f)
                                    .height(30.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                // Background guideway line
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .background(SlateGrey)
                                )

                                // Moving train dot overlay
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth(activeTrain.progress)
                                        .fillMaxHeight(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .background(WarmSand, RoundedCornerShape(4.dp))
                                            .border(1.5.dp, QatarMaroon, RoundedCornerShape(4.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.DirectionsSubway, contentDescription = null, tint = QatarMaroon, modifier = Modifier.size(10.dp))
                                    }
                                }
                            }

                            // Next Station node
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(0.2f)) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(DeepCharcoal, CircleShape)
                                        .border(2.dp, SlateGrey, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Storefront, contentDescription = null, tint = SlateGrey, modifier = Modifier.size(12.dp))
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (nextStat != null) (if (isArabic) nextStat.nameAr else nextStat.nameEn) else activeTrain.nextStationId,
                                    color = SlateGrey,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    // Diagnostics Info Block
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        InfoStatBlock(
                            label = MetroLocalisation.translate("capacity_assumption", isArabic),
                            value = "${activeTrain.passengerLoad}%",
                            color = if (activeTrain.passengerLoad > 80) SignalRed else WarmSand,
                            modifier = Modifier.weight(1f)
                        )
                        InfoStatBlock(
                            label = MetroLocalisation.translate("hvac_status", isArabic),
                            value = "${String.format("%.1f", activeTrain.hvacTemp)} °C",
                            color = TechnicalBlue,
                            modifier = Modifier.weight(1f)
                        )
                        InfoStatBlock(
                            label = if (isArabic) "معدل التقاطر المجدول" else "Scheduled Headway",
                            value = "${activeTrain.headwaySeconds} sec",
                            color = StainlessSteel,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    HorizontalDivider(color = DeepCharcoal)

                    // Intervention Commands
                    Text(
                        text = if (isArabic) "أوامر التدخل الفوري لمركز التحكم" else "Control Room Immediate Interventions",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { viewModel.injectDelay(activeTrain.id, 5) },
                            colors = ButtonDefaults.buttonColors(containerColor = SignalRed),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Timer, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = MetroLocalisation.translate("inject_delay", isArabic), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.holdTrain(activeTrain.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = MetroGoldLine),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = if (activeTrain.status == "HELD") Icons.Default.PlayArrow else Icons.Default.Pause,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (activeTrain.status == "HELD")
                                    MetroLocalisation.translate("release_train", isArabic)
                                else
                                    MetroLocalisation.translate("hold_train", isArabic),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { viewModel.restoreService(activeTrain.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = OperationalGreen),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = MetroLocalisation.translate("restore_service", isArabic), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun StationsTab(viewModel: MetroViewModel, isArabic: Boolean) {
    val stations by viewModel.stations.collectAsStateWithLifecycle()
    val selectedStationId by viewModel.selectedStationId.collectAsStateWithLifecycle()

    val activeStation = stations.find { it.id == selectedStationId } ?: stations.firstOrNull()

    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        // Left Panel: Stations list
        Card(
            colors = CardDefaults.cardColors(containerColor = Graphite),
            modifier = Modifier
                .width(320.dp)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isArabic) "البنية التحتية والمحطات" else "Station Infrastructures",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(stations) { station ->
                        val isSelected = station.id == activeStation?.id
                        val borderCol = if (isSelected) QatarMaroon else Color.Transparent

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(DeepCharcoal)
                                .border(1.5.dp, borderCol, RoundedCornerShape(8.dp))
                                .clickable { viewModel.selectStation(station.id) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isArabic) station.nameAr else station.nameEn,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${MetroLocalisation.translateLine(station.lineId, isArabic)} • ${station.id}",
                                    color = SlateGrey,
                                    fontSize = 10.sp
                                )
                            }

                            // Status badge
                            val badgeColor = when (station.status) {
                                "CROWDED" -> SignalRed
                                "MAINTENANCE" -> MetroGoldLine
                                else -> OperationalGreen
                            }
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(badgeColor.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = MetroLocalisation.translateStatus(station.status, isArabic),
                                    color = badgeColor,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }
        }

        // Right Panel: Digital Twin details and simulation triggers
        Card(
            colors = CardDefaults.cardColors(containerColor = Graphite),
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (activeStation != null) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isArabic) activeStation.nameAr else activeStation.nameEn,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp
                            )
                            Text(
                                text = "Station Twin ID: ${activeStation.id} • ${MetroLocalisation.translateLine(activeStation.lineId, isArabic)}",
                                color = WarmSand,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Central interchange flag
                        if (activeStation.isInterchange) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MetroInterchange.copy(alpha = 0.2f))
                                    .border(1.dp, MetroInterchange, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (isArabic) "محطة تبادل رئيسية" else "INTERCHANGE",
                                    color = MetroInterchange,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }

                    // Station Twin SVG diagram drawn via compose Canvas
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(DeepCharcoal, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = if (isArabic) "التخطيط الهيكلي والمنظور الثلاثي الداخلي" else "Physical Twin Spatial Layout & Facilities",
                            color = SlateGrey,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .border(1.dp, Graphite, RoundedCornerShape(6.dp))
                                .background(DeepCharcoal)
                        ) {
                            StationDigitalTwinCanvas(activeStation, isArabic)
                        }
                    }

                    // Station stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        InfoStatBlock(
                            label = MetroLocalisation.translate("concourse_density", isArabic),
                            value = activeStation.concourseDensity,
                            color = when (activeStation.concourseDensity) {
                                "HIGH" -> SignalRed
                                "MED" -> MetroGoldLine
                                else -> OperationalGreen
                            },
                            modifier = Modifier.weight(1f)
                        )
                        InfoStatBlock(
                            label = MetroLocalisation.translate("escalator_avail", isArabic),
                            value = if (activeStation.escalatorOk) "100%" else "50% MAINT",
                            color = if (activeStation.escalatorOk) OperationalGreen else MetroGoldLine,
                            modifier = Modifier.weight(1f)
                        )
                        InfoStatBlock(
                            label = MetroLocalisation.translate("lift_avail", isArabic),
                            value = if (activeStation.liftOk) "100%" else "OFFLINE",
                            color = if (activeStation.liftOk) OperationalGreen else SignalRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Interactive Station Sim Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { viewModel.simulateStationCrowding(activeStation.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = QatarMaroon),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.People, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = MetroLocalisation.translate("simulate_surge", isArabic), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.toggleEscalator(activeStation.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = SlateGrey),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Build, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = MetroLocalisation.translate("toggle_escalator", isArabic), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StationDigitalTwinCanvas(station: StationEntity, isArabic: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // 1. Draw outer boundary walls
        drawRoundRect(
            color = SlateGrey,
            topLeft = Offset(w * 0.05f, h * 0.1f),
            size = androidx.compose.ui.geometry.Size(w * 0.9f, h * 0.8f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(15f, 15f),
            style = Stroke(width = 3f)
        )

        // 2. Draw interior spatial zones (Concourse / Platforms)
        // Concourse Zone (Top half)
        drawRect(
            color = SlateGrey.copy(alpha = 0.1f),
            topLeft = Offset(w * 0.05f, h * 0.1f),
            size = androidx.compose.ui.geometry.Size(w * 0.9f, h * 0.35f)
        )

        // Platform 1 Zone (Bottom Red/Green stripe)
        val stripeColor = when (station.lineId) {
            "RED" -> MetroRedLine
            "GREEN" -> MetroGreenLine
            else -> MetroGoldLine
        }

        drawRect(
            color = stripeColor.copy(alpha = 0.15f),
            topLeft = Offset(w * 0.05f, h * 0.55f),
            size = androidx.compose.ui.geometry.Size(w * 0.9f, h * 0.35f)
        )

        // Separating guideway rail lines
        drawLine(
            color = stripeColor,
            start = Offset(w * 0.05f, h * 0.72f),
            end = Offset(w * 0.95f, h * 0.72f),
            strokeWidth = 4f
        )

        // Draw Ticket Gates (Concourse entrance)
        drawRect(
            color = OperationalGreen,
            topLeft = Offset(w * 0.45f, h * 0.12f),
            size = androidx.compose.ui.geometry.Size(w * 0.1f, h * 0.02f)
        )

        // 3. Draw Escalator icons (Simple geometric representation)
        val escColor = if (station.escalatorOk) OperationalGreen else SignalRed
        drawRect(
            color = escColor,
            topLeft = Offset(w * 0.25f, h * 0.3f),
            size = androidx.compose.ui.geometry.Size(w * 0.08f, h * 0.08f)
        )
        // Escalator incline diagonal line
        drawLine(
            color = Color.White,
            start = Offset(w * 0.25f, h * 0.38f),
            end = Offset(w * 0.33f, h * 0.3f),
            strokeWidth = 3f
        )

        // Draw Lift elevator icon
        val liftColor = if (station.liftOk) OperationalGreen else SignalRed
        drawRect(
            color = liftColor,
            topLeft = Offset(w * 0.65f, h * 0.3f),
            size = androidx.compose.ui.geometry.Size(w * 0.08f, h * 0.08f)
        )
    }

    // Overlay descriptive texts over the custom twin canvas
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        val density = androidx.compose.ui.platform.LocalDensity.current.density

        Box(modifier = Modifier.offset(x = (w * 0.07f / density).dp, y = (h * 0.12f / density).dp)) {
            Text(text = if (isArabic) "صالة الركاب الرئيسية" else "Main Concourse", color = SlateGrey, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }

        Box(modifier = Modifier.offset(x = (w * 0.43f / density).dp, y = (h * 0.07f / density).dp)) {
            Text(text = if (isArabic) "بوابات التذاكر" else "Ticket Gates", color = OperationalGreen, fontSize = 8.sp, fontWeight = FontWeight.Black)
        }

        Box(modifier = Modifier.offset(x = (w * 0.23f / density).dp, y = (h * 0.4f / density).dp)) {
            Text(text = if (isArabic) "سلم كهربائي" else "Escalator E-1", color = if (station.escalatorOk) Color.White else SignalRed, fontSize = 8.sp)
        }

        Box(modifier = Modifier.offset(x = (w * 0.65f / density).dp, y = (h * 0.4f / density).dp)) {
            Text(text = if (isArabic) "مصعد L-1" else "Elevator L-1", color = if (station.liftOk) Color.White else SignalRed, fontSize = 8.sp)
        }

        Box(modifier = Modifier.offset(x = (w * 0.07f / density).dp, y = (h * 0.58f / density).dp)) {
            Text(text = if (isArabic) "رصيف رقم ١" else "Platform 1", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}


@Composable
fun FleetTab(viewModel: MetroViewModel, isArabic: Boolean) {
    val trains by viewModel.trains.collectAsStateWithLifecycle()
    val selectedTrainId by viewModel.selectedTrainId.collectAsStateWithLifecycle()

    val activeTrain = trains.find { it.id == selectedTrainId } ?: trains.firstOrNull()

    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        // Left Column: Fleet Overview list
        Card(
            colors = CardDefaults.cardColors(containerColor = Graphite),
            modifier = Modifier
                .width(320.dp)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = MetroLocalisation.translate("fleet_avail", isArabic),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(trains) { train ->
                        val isSelected = train.id == activeTrain?.id
                        val borderCol = if (isSelected) QatarMaroon else Color.Transparent

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(DeepCharcoal)
                                .border(1.5.dp, borderCol, RoundedCornerShape(8.dp))
                                .clickable { viewModel.selectTrain(train.id) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${MetroLocalisation.translate("train_id", isArabic)} ${train.id}",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Class: Q-Grade • Status: ${train.status}",
                                    color = SlateGrey,
                                    fontSize = 10.sp
                                )
                            }
                            // Battery/Diagnostic Status
                            Icon(
                                imageVector = Icons.Default.BatteryChargingFull,
                                contentDescription = null,
                                tint = OperationalGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Right Column: Advanced Diagnostics & Door States Schematic
        Card(
            colors = CardDefaults.cardColors(containerColor = Graphite),
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (activeTrain != null) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        text = "${MetroLocalisation.translate("fleet_avail", isArabic)} • Diagnostic Terminal",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    // Diagnostic Metrics Table
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepCharcoal, RoundedCornerShape(8.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        DiagnosticRow(MetroLocalisation.translate("fleet_class", isArabic), "Alstom Metropolis Qatar Edition", isArabic)
                        DiagnosticRow(MetroLocalisation.translate("formation", isArabic), "3 Car Set (M1-T-M2)", isArabic)
                        DiagnosticRow(MetroLocalisation.translate("carriage_count", isArabic), "3 Carriages", isArabic)
                        DiagnosticRow(MetroLocalisation.translate("capacity_assumption", isArabic), "596 Passengers (Fully loaded)", isArabic)
                        DiagnosticRow(MetroLocalisation.translate("mileage", isArabic), "42,850 km", isArabic)
                    }

                    HorizontalDivider(color = DeepCharcoal)

                    // Train Car schematic with interactive Doors state
                    Text(
                        text = if (isArabic) "حالة الأبواب والمؤشرات لكل عربة" else "Carriages Door States & Auxiliary Systems",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CarriageBlock("Car 1 (A-Cab)", activeTrain.doorOpen, isArabic, modifier = Modifier.weight(1f))
                        CarriageBlock("Car 2 (Trailer)", activeTrain.doorOpen, isArabic, modifier = Modifier.weight(1f))
                        CarriageBlock("Car 3 (B-Cab)", activeTrain.doorOpen, isArabic, modifier = Modifier.weight(1f))
                    }

                    // More Diagnostic Telemetry
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        InfoStatBlock(
                            label = MetroLocalisation.translate("battery_power", isArabic),
                            value = "110V DC / OK",
                            color = OperationalGreen,
                            modifier = Modifier.weight(1f)
                        )
                        InfoStatBlock(
                            label = MetroLocalisation.translate("brake_status", isArabic),
                            value = "Pneumatic / NORMAL",
                            color = OperationalGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DiagnosticRow(label: String, value: String, isArabic: Boolean) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text = label, color = SlateGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = StainlessSteel, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun CarriageBlock(carName: String, doorsOpen: Boolean, isArabic: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DeepCharcoal)
            .border(1.dp, Graphite, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = carName, color = WarmSand, fontSize = 10.sp, fontWeight = FontWeight.Black)

            // Schematic Car representation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(35.dp)
                    .background(SlateGrey.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .border(1.dp, SlateGrey, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    DoorIndicator(doorsOpen)
                    DoorIndicator(doorsOpen)
                }
            }

            Text(
                text = if (doorsOpen)
                    MetroLocalisation.translate("doors", isArabic) + ": " + (if (isArabic) "مفتوحة" else "OPEN")
                else
                    MetroLocalisation.translate("doors", isArabic) + ": " + (if (isArabic) "مغلقة" else "CLOSED"),
                color = if (doorsOpen) SignalRed else OperationalGreen,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun DoorIndicator(isOpen: Boolean) {
    Box(
        modifier = Modifier
            .size(10.dp)
            .background(if (isOpen) SignalRed else OperationalGreen, RoundedCornerShape(2.dp))
    )
}


@Composable
fun IncidentsTab(viewModel: MetroViewModel, isArabic: Boolean) {
    val incidents by viewModel.incidents.collectAsStateWithLifecycle()
    val selectedIncidentId by viewModel.selectedIncidentId.collectAsStateWithLifecycle()

    val activeIncident = incidents.find { it.id == selectedIncidentId } ?: incidents.firstOrNull()

    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        // Left Column: Active Incidents Registry
        Card(
            colors = CardDefaults.cardColors(containerColor = Graphite),
            modifier = Modifier
                .width(360.dp)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = MetroLocalisation.translate("open_incidents", isArabic),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(incidents) { inc ->
                        val isSelected = inc.id == activeIncident?.id
                        val borderCol = if (isSelected) QatarMaroon else Color.Transparent

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(DeepCharcoal)
                                .border(1.5.dp, borderCol, RoundedCornerShape(8.dp))
                                .clickable { viewModel.selectIncident(inc.id) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isArabic) inc.titleAr else inc.titleEn,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                Text(
                                    text = "Severity: ${inc.severity} • Status: ${inc.status}",
                                    color = SlateGrey,
                                    fontSize = 10.sp
                                )
                            }
                            // Alert Dot
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(if (inc.status == "CLOSED") OperationalGreen else SignalRed, CircleShape)
                            )
                        }
                    }
                }
            }
        }

        // Right Column: Incident Operations Details and Workflow Advancing
        Card(
            colors = CardDefaults.cardColors(containerColor = Graphite),
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (activeIncident != null) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isArabic) activeIncident.titleAr else activeIncident.titleEn,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Incident REF ID: #${activeIncident.id} • Detected via SCADA",
                                color = SlateGrey,
                                fontSize = 11.sp
                            )
                        }
                        // Severity badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(SignalRed.copy(alpha = 0.2f))
                                .border(1.dp, SignalRed, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = MetroLocalisation.translateSeverity(activeIncident.severity, isArabic),
                                color = SignalRed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    HorizontalDivider(color = DeepCharcoal)

                    // Key parameters
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        IncidentDetailRow(MetroLocalisation.translate("location", isArabic), if (isArabic) activeIncident.locationAr else activeIncident.locationEn)
                        IncidentDetailRow(MetroLocalisation.translate("owner", isArabic), activeIncident.owner)
                        IncidentDetailRow(
                            MetroLocalisation.translate("detection_time", isArabic),
                            SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.ENGLISH).format(Date(activeIncident.detectedTime))
                        )
                        IncidentDetailRow(
                            MetroLocalisation.translate("description", isArabic),
                            if (isArabic) activeIncident.descriptionAr else activeIncident.descriptionEn
                        )
                    }

                    HorizontalDivider(color = DeepCharcoal)

                    // Current progress workflow
                    Text(
                        text = MetroLocalisation.translate("timeline", isArabic),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    // Visual Progress Tracker
                    val workflowStages = listOf("DETECTED", "ACKNOWLEDGED", "RESPONSE_INITIATED", "RECOVERY", "CLOSED")
                    val currentIdx = workflowStages.indexOf(activeIncident.status)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepCharcoal, RoundedCornerShape(6.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        workflowStages.forEachIndexed { idx, stage ->
                            val isActive = idx <= currentIdx
                            val stageCol = if (isActive) OperationalGreen else SlateGrey

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .background(if (isActive) stageCol else Color.Transparent, CircleShape)
                                        .border(2.dp, stageCol, CircleShape)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = MetroLocalisation.translateIncidentStatus(stage, isArabic),
                                    color = stageCol,
                                    fontSize = 8.sp,
                                    fontWeight = if (idx == currentIdx) FontWeight.Black else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Action buttons (Advance workflow, publish draft broadcast)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (activeIncident.status != "CLOSED") {
                            Button(
                                onClick = { viewModel.advanceIncidentStatus(activeIncident.id, activeIncident.status) },
                                colors = ButtonDefaults.buttonColors(containerColor = OperationalGreen),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.ArrowUpward, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = MetroLocalisation.translate("advance_status", isArabic), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Auto Draft Bilingual PIS message based on incident!
                        Button(
                            onClick = {
                                viewModel.publishPassengerMessage(
                                    titleAr = "تنبيه تشغيلي: تحديثات الخدمة",
                                    titleEn = "Operational Notice: Service Updates",
                                    bodyAr = "نود إعلامكم بـ: ${activeIncident.titleAr} في ${activeIncident.locationAr}. نعمل لحل المسألة سريعاً.",
                                    bodyEn = "We would like to inform you regarding: ${activeIncident.titleEn} at ${activeIncident.locationEn}. Maintenance is active.",
                                    priority = "HIGH",
                                    line = activeIncident.lineId
                                )
                                viewModel.setTab(MetroTab.PASSENGERS)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = QatarMaroon),
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Campaign, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = MetroLocalisation.translate("publish", isArabic), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IncidentDetailRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Text(text = "$label: ", color = SlateGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(130.dp))
        Text(text = value, color = StainlessSteel, fontSize = 11.sp, modifier = Modifier.weight(1f))
    }
}


@Composable
fun PassengersTab(viewModel: MetroViewModel, isArabic: Boolean) {
    val messages by viewModel.passengerMessages.collectAsStateWithLifecycle()

    var customTitleAr by remember { mutableStateOf("") }
    var customTitleEn by remember { mutableStateOf("") }
    var customBodyAr by remember { mutableStateOf("") }
    var customBodyEn by remember { mutableStateOf("") }

    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        // Left Column: Custom Broadcast Form and Platform previews
        Card(
            colors = CardDefaults.cardColors(containerColor = Graphite),
            modifier = Modifier
                .width(420.dp)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = if (isArabic) "إرسال إعلان ثنائي اللغة فوري" else "Publish Bilingual Board Announcement",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                OutlinedTextField(
                    value = customTitleAr,
                    onValueChange = { customTitleAr = it },
                    label = { Text("العنوان بالعربية", fontSize = 11.sp, color = SlateGrey) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 12.sp)
                )

                OutlinedTextField(
                    value = customTitleEn,
                    onValueChange = { customTitleEn = it },
                    label = { Text("Title in English", fontSize = 11.sp, color = SlateGrey) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 12.sp)
                )

                OutlinedTextField(
                    value = customBodyAr,
                    onValueChange = { customBodyAr = it },
                    label = { Text("المحتوى بالعربية", fontSize = 11.sp, color = SlateGrey) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 12.sp)
                )

                OutlinedTextField(
                    value = customBodyEn,
                    onValueChange = { customBodyEn = it },
                    label = { Text("Body in English", fontSize = 11.sp, color = SlateGrey) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 12.sp)
                )

                Button(
                    onClick = {
                        if (customTitleAr.isNotBlank() && customTitleEn.isNotBlank()) {
                            viewModel.publishPassengerMessage(
                                customTitleAr, customTitleEn, customBodyAr, customBodyEn, "HIGH", "ALL"
                            )
                            customTitleAr = ""
                            customTitleEn = ""
                            customBodyAr = ""
                            customBodyEn = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = QatarMaroon),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = MetroLocalisation.translate("publish", isArabic), fontWeight = FontWeight.Bold)
                }

                HorizontalDivider(color = DeepCharcoal)

                // Platform scroll board preview simulation! High fidelity LED scroll simulation.
                Text(
                    text = if (isArabic) "نموذج محاكاة لوحة رصيف المحطة LED" else "Platform LED Display Live Preview",
                    color = SlateGrey,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                val displayMsg = messages.firstOrNull()
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .background(Color.Black, RoundedCornerShape(4.dp))
                        .border(1.5.dp, QatarMaroon, RoundedCornerShape(4.dp))
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (displayMsg != null) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "::: BROADCAST PREVIEW :::",
                                color = Color(0xFFE2B007), // Golden LED color
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = if (isArabic) displayMsg.bodyAr else displayMsg.bodyEn,
                                color = Color(0xFFFF9900), // Rich orange LED color
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Text(
                            text = "NO SERVICE ALERTS ACTIVE",
                            color = Color(0xFF00FF00),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Right Column: Broadcast History Registry list
        Card(
            colors = CardDefaults.cardColors(containerColor = Graphite),
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isArabic) "سجل الإعلانات المذاعة للجمهور" else "Public Announcements Broadcast Registry",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { msg ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(DeepCharcoal)
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (isArabic) msg.titleAr else msg.titleEn,
                                        color = WarmSand,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = SimpleDateFormat("HH:mm:ss", Locale.ENGLISH).format(Date(msg.publishTime)),
                                        color = SlateGrey,
                                        fontSize = 10.sp
                                    )
                                }
                                Text(
                                    text = if (isArabic) msg.bodyAr else msg.bodyEn,
                                    color = Color.White,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun AnalyticsTab(viewModel: MetroViewModel, isArabic: Boolean) {
    val outdoorTemp by viewModel.outdoorTemp.collectAsStateWithLifecycle()
    val trains by viewModel.trains.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SyntheticBanner(isArabic)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Environment Simulator Left controls
            Card(
                colors = CardDefaults.cardColors(containerColor = Graphite),
                modifier = Modifier
                    .width(320.dp)
                    .fillMaxHeight(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = MetroLocalisation.translate("environmental_lab", isArabic),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Text(
                        text = if (isArabic) "درجة الحرارة الخارجية للبيئة الصحراوية" else "Ambient Desert Outdoor Temperature",
                        color = SlateGrey,
                        fontSize = 11.sp
                    )

                    // Numeric Temperature Gauge
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp)
                            .background(DeepCharcoal, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${outdoorTemp.roundToInt()} °C",
                            color = if (outdoorTemp > 40) SignalRed else WarmSand,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Slider(
                        value = outdoorTemp,
                        onValueChange = { viewModel.setOutdoorTemp(it) },
                        valueRange = 20.0f..50.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = QatarMaroon,
                            activeTrackColor = WarmSand
                        )
                    )

                    HorizontalDivider(color = DeepCharcoal)

                    // Computed HVAC energy multiplier info
                    val hvacMultiplier = 1.0f + ((outdoorTemp - 24f).coerceAtLeast(0f) * 0.08f)
                    Text(
                        text = "HVAC ENERGY IMPACT MODULE",
                        color = SlateGrey,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = if (isArabic) "مضاعف استهلاك التبريد" else "Cooling Load Coefficient", color = Color.White, fontSize = 11.sp)
                        Text(text = "${String.format("%.2f", hvacMultiplier)}x", color = SignalRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // Dynamically calculate actual simulated power demand
                    val baseTrainPower = trains.size * 1.2f // 1.2 MW base per train
                    val totalPowerDemand = baseTrainPower + (trains.size * hvacMultiplier * 0.4f)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = if (isArabic) "إجمالي حمل الطاقة التقريبي" else "Est. Total Network Power", color = Color.White, fontSize = 11.sp)
                        Text(text = "${String.format("%.2f", totalPowerDemand)} MW", color = WarmSand, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Custom Analytics Visualizing Panel drawing beautiful pure compose charts!
            Card(
                colors = CardDefaults.cardColors(containerColor = Graphite),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isArabic) "لوحة قياس كفاءة استهلاك الطاقة والانتظام" else "Power Consumption and Regularity Metrics",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DeepCharcoal, RoundedCornerShape(8.dp))
                            .padding(16.dp)
                    ) {
                        AnalyticsChartsCanvas(outdoorTemp)
                    }
                }
            }
        }
    }
}

@Composable
fun AnalyticsChartsCanvas(temp: Float) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Draw grid lines
        for (i in 1..4) {
            val yPos = h * (i / 5f)
            drawLine(
                color = SlateGrey.copy(alpha = 0.2f),
                start = Offset(0f, yPos),
                end = Offset(w, yPos),
                strokeWidth = 2f
            )
        }

        // Draw Energy efficiency curve based on temperature dynamically!
        // Curve gets higher as temperature rises
        val barCount = 10
        val barWidth = w / (barCount * 1.5f)
        val spacing = w / (barCount * 4f)

        for (i in 0 until barCount) {
            // Compute base height and heat factor
            val baseVal = h * 0.4f
            val heatFactor = (temp - 20) * (i * 0.8f + 2f)
            val barHeight = (baseVal + heatFactor).coerceIn(50f, h * 0.9f)

            val xPos = i * (barWidth + spacing) + spacing * 2

            // Custom beautiful vertical gradient bar
            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(QatarMaroon, WarmSand)
                ),
                topLeft = Offset(xPos, h - barHeight),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
            )
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()

        Box(modifier = Modifier.offset(x = 10.dp, y = 10.dp)) {
            Text(text = "MW / Hour peak load timeline", color = SlateGrey, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
    }
}


@Composable
fun AuditTab(viewModel: MetroViewModel, isArabic: Boolean) {
    val events by viewModel.auditEvents.collectAsStateWithLifecycle()

    Card(
        colors = CardDefaults.cardColors(containerColor = Graphite),
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = MetroLocalisation.translate("tab_audit", isArabic),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = if (isArabic) "الأنشطة والتدخلات المسجلة بقاعدة بيانات الأمن التشغيلي" else "Direct operator intervention logs recorded in primary SQLite ledger",
                        color = SlateGrey,
                        fontSize = 11.sp
                    )
                }

                // Clear or export report label
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(WarmSand.copy(alpha = 0.15f))
                        .border(1.dp, WarmSand, RoundedCornerShape(4.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (isArabic) "سجل آمن غير قابل للتعديل" else "IMMUTABLE AUDIT LEDGER",
                        color = WarmSand,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Audit events log table
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DeepCharcoal, RoundedCornerShape(6.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(events) { ev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Graphite)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(0.7f)) {
                            Text(
                                text = if (isArabic) ev.actionAr else ev.actionEn,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = "OP: ${ev.operator}",
                                    color = SlateGrey,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Category: ${ev.category}",
                                    color = WarmSand,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Text(
                            text = SimpleDateFormat("HH:mm:ss dd/MM", Locale.ENGLISH).format(Date(ev.timestamp)),
                            color = SlateGrey,
                            fontSize = 10.sp,
                            modifier = Modifier.weight(0.3f),
                            textAlign = TextAlign.End
                        )
                    }
                }
            }
        }
    }
}


// ----------------- REUSABLE UI ELEMENTS -----------------

@Composable
fun SyntheticBanner(isArabic: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(QatarMaroon.copy(alpha = 0.12f))
            .border(1.dp, QatarMaroon, RoundedCornerShape(6.dp))
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = QatarMaroon, modifier = Modifier.size(16.dp))
            Text(
                text = MetroLocalisation.translate("synthetic_data", isArabic),
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
fun KpiCard(
    title: String,
    subtitle: String,
    value: String,
    color: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Graphite),
        modifier = modifier.height(105.dp),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, color = SlateGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            }
            Text(
                text = value,
                color = color,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
            Text(text = subtitle, color = SlateGrey, fontSize = 9.sp)
        }
    }
}

@Composable
fun InfoStatBlock(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DeepCharcoal)
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = label, color = SlateGrey, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text(text = value, color = color, fontSize = 14.sp, fontWeight = FontWeight.Black)
        }
    }
}
