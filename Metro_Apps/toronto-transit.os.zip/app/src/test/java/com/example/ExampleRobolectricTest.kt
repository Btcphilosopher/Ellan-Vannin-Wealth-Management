package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import com.example.domain.*
import com.example.ui.TransitViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34]) // Set to 34 for maximum compatibility in test environments
class ExampleRobolectricTest {

    @Test
    fun verifyAppNameInResources() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Transit.OS", appName)
    }

    @Test
    fun testOneFareCoFareRebateCalculation() {
        val provider = SyntheticPRESTOProvider()
        
        // Single local transit leg
        val singleTtcLeg = listOf(
            JourneyLeg(
                TransitMode.SUBWAY, Operator.TTC, "l1", "Yonge Line", "1", "#FFFFC72C",
                "Union", "Bloor-Yonge", 12, 5, emptyList(), "Ride Subway"
            )
        )
        assertEquals(3.30, provider.calculateJourneyFare(singleTtcLeg), 0.01)

        // TTC + MiWay multi-operator GTHA journey -> total $3.30 under One-Fare
        val multiLocalLegs = listOf(
            JourneyLeg(
                TransitMode.SUBWAY, Operator.TTC, "l2", "Bloor Line", "2", "#00A550",
                "Bloor-Yonge", "Kipling", 24, 14, emptyList(), "Ride Subway"
            ),
            JourneyLeg(
                TransitMode.BUS, Operator.MIWAY, "miway_110", "Express Bus", "110", "#F2A900",
                "Kipling", "Mississauga CC", 20, 5, emptyList(), "Transfer to MiWay"
            )
        )
        assertEquals(3.30, provider.calculateJourneyFare(multiLocalLegs), 0.01)

        // GO Transit + TTC co-fare -> TTC fare rebated to $0, pays only GO
        val goTtcLegs = listOf(
            JourneyLeg(
                TransitMode.REGIONAL_TRAIN, Operator.GO_TRANSIT, "go_lakeshore", "Lakeshore Line", "GO", "#00853E",
                "Union", "Kennedy", 15, 2, emptyList(), "Ride GO"
            ),
            JourneyLeg(
                TransitMode.SUBWAY, Operator.TTC, "l2", "Bloor Line", "2", "#00A550",
                "Kennedy", "Bloor-Yonge", 22, 12, emptyList(), "Transfer to TTC Subway"
            )
        )
        assertEquals(6.85, provider.calculateJourneyFare(goTtcLegs), 0.01)
    }

    @Test
    fun testFuzzyStationSpellingMatching() {
        val viewModel = TransitViewModel()
        
        // Spelling mistake tolerance test
        viewModel.onSearchQueryChanged("yonge bloore")
        assertTrue(viewModel.filteredStations.any { it.id == "bloor_yonge" })

        // Abbreviation matching test
        viewModel.onSearchQueryChanged("stc")
        assertTrue(viewModel.filteredStations.any { it.id == "scarborough" })

        // Landmark name tolerance test
        viewModel.onSearchQueryChanged("pearson")
        assertTrue(viewModel.filteredStations.any { it.id == "pearson" })
    }

    @Test
    fun testMonthlyFareCapEligibility() {
        val viewModel = TransitViewModel()
        
        // Starts below cap
        viewModel.setPrestoPaidTrips(32)
        assertFalse(viewModel.prestoAccount.isFareCapReached)
        
        // Set to exactly 47 paid trips
        viewModel.setPrestoPaidTrips(47)
        assertTrue(viewModel.prestoAccount.isFareCapReached)
    }
}
