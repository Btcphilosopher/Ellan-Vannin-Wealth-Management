package com.example.data

import com.example.domain.*

object TransitData {

    // Unique Stations with precise relative canvas coordinates (0..1000) for drawing the schematic
    val stations = listOf(
        Station(
            id = "union",
            name = "Union Station",
            shortName = "Union",
            code = "UNS",
            operators = listOf(Operator.TTC, Operator.GO_TRANSIT, Operator.UP_EXPRESS),
            modes = listOf(TransitMode.SUBWAY, TransitMode.REGIONAL_TRAIN, TransitMode.STREETCAR),
            lineIds = listOf("l1", "509", "up_exp", "go_lakeshore"),
            x = 420f,
            y = 780f,
            isAccessible = true,
            entrances = listOf("Front Street (North)", "Bay Street (East)", "York Street (West)", "Scotiabank Arena (South)"),
            exits = listOf("Front St Main Gates", "Royal York PATH Tunnel", "Union Station Bus Terminal"),
            amenities = listOf("PRESTO Vending Machines", "Elevators to Platforms", "Food Court / PATH Shops", "Accessible Restrooms"),
            description = "The historic primary gateway to Toronto. Flagship passenger node integrating TTC, GO, UP, and VIA networks."
        ),
        Station(
            id = "bloor_yonge",
            name = "Bloor–Yonge",
            shortName = "Yonge–Bloor",
            code = "BYO",
            operators = listOf(Operator.TTC),
            modes = listOf(TransitMode.SUBWAY),
            lineIds = listOf("l1", "l2"),
            x = 420f,
            y = 480f,
            isAccessible = true,
            entrances = listOf("Yonge St (North/South East)", "Bloor St (North West)"),
            exits = listOf("Yonge Street Walkway", "Hudson's Bay Centre Tunnel"),
            amenities = listOf("PRESTO Gatehouse", "Escalators to Upper/Lower levels", "Gateway Newsstand"),
            description = "The busiest interchange in the country. Connects Line 1 (Yonge–University) and Line 2 (Bloor–Danforth)."
        ),
        Station(
            id = "dundas",
            name = "Dundas",
            shortName = "Dundas Square",
            code = "DUN",
            operators = listOf(Operator.TTC),
            modes = listOf(TransitMode.SUBWAY),
            lineIds = listOf("l1"),
            x = 420f,
            y = 580f,
            isAccessible = true,
            entrances = listOf("Yonge & Dundas Square Entrance", "Eaton Centre Level 1"),
            exits = listOf("Yonge Street East Side", "Ryerson University PATH"),
            amenities = listOf("PRESTO Gates", "Retail Outlets"),
            description = "At the heart of downtown Toronto's retail and cultural activity."
        ),
        Station(
            id = "yorkdale",
            name = "Yorkdale Station",
            shortName = "Yorkdale",
            code = "YKD",
            operators = listOf(Operator.TTC, Operator.GO_TRANSIT),
            modes = listOf(TransitMode.SUBWAY, TransitMode.BUS),
            lineIds = listOf("l1", "go_bus"),
            x = 240f,
            y = 280f,
            isAccessible = true,
            entrances = listOf("Yorkdale Mall Access Bridge", "Ranee Avenue South Entrance"),
            exits = listOf("Yorkdale Road Highway Terminal"),
            amenities = listOf("Accessible Parking Lot", "Mall Interior Gate"),
            description = "Sleek architecturally significant station featuring high arched glass vaults, feeding directly to Yorkdale Mall."
        ),
        Station(
            id = "pearson",
            name = "Pearson Airport T3/T1",
            shortName = "Pearson",
            code = "YYZ",
            operators = listOf(Operator.UP_EXPRESS, Operator.TTC, Operator.GO_TRANSIT),
            modes = listOf(TransitMode.REGIONAL_TRAIN, TransitMode.BUS),
            lineIds = listOf("up_exp", "52_bus", "go_bus"),
            x = 80f,
            y = 480f,
            isAccessible = true,
            entrances = listOf("Terminal 1 Level 3 Bridge", "Terminal 3 Link Train Gate"),
            exits = listOf("Terminal 1 Departures Road", "Terminal 3 Arrival Gates"),
            amenities = listOf("UP Express Ticket Desk", "NFC Payment Terminal", "Tourist Guide Centre"),
            description = "International gate. Connects GTHA rapid regional transit to terminal check-ins directly."
        ),
        Station(
            id = "billy_bishop",
            name = "Billy Bishop Airport",
            shortName = "Billy Bishop",
            code = "YTZ",
            operators = listOf(Operator.TTC),
            modes = listOf(TransitMode.STREETCAR, TransitMode.BUS),
            lineIds = listOf("509", "121_bus"),
            x = 240f,
            y = 860f,
            isAccessible = true,
            entrances = listOf("Eireann Quay Ferry Terminal", "Underwater Pedestrian Tunnel Entrance"),
            exits = listOf("Airport Terminal Front Gate"),
            amenities = listOf("Ferry Docking", "Shuttle Bus Connection"),
            description = "Downtown island airport hub. Accessible via scenic streetcar connection and pedestrian tunnel."
        ),
        Station(
            id = "scarborough",
            name = "Scarborough Centre",
            shortName = "Scarborough",
            code = "STC",
            operators = listOf(Operator.TTC, Operator.DURHAM_REGION_TRANSIT, Operator.GO_TRANSIT),
            modes = listOf(TransitMode.BUS),
            lineIds = listOf("go_bus", "dr_bus", "38_bus"),
            x = 840f,
            y = 480f,
            isAccessible = true,
            entrances = listOf("Scarborough Town Centre Level 2", "Brimley Road Terminal Gate"),
            exits = listOf("Town Centre Walkway", "Albert Campbell Square"),
            amenities = listOf("Bus Platform Hub", "Indoor Waiting Area"),
            description = "East end terminal hub connecting GTHA regional buses and regional ridership."
        ),
        Station(
            id = "wellesley",
            name = "Wellesley Station",
            shortName = "Wellesley",
            code = "WEL",
            operators = listOf(Operator.TTC),
            modes = listOf(TransitMode.SUBWAY, TransitMode.BUS),
            lineIds = listOf("l1", "94_bus"),
            x = 420f,
            y = 520f,
            isAccessible = true,
            entrances = listOf("Wellesley Street East entrance"),
            exits = listOf("Wellesley Street Lane"),
            amenities = listOf("NFC Gates"),
            description = "Neighbourhood station in Toronto's historic Village."
        ),
        Station(
            id = "kipling",
            name = "Kipling Station",
            shortName = "Kipling",
            code = "KIP",
            operators = listOf(Operator.TTC, Operator.MIWAY),
            modes = listOf(TransitMode.SUBWAY, TransitMode.BUS),
            lineIds = listOf("l2", "miway_110"),
            x = 100f,
            y = 660f,
            isAccessible = true,
            entrances = listOf("Subway Crescent Drop-off", "MiWay Transit Bus Terminal"),
            exits = listOf("Dundas St West Access"),
            amenities = listOf("MiWay Ticket Booth", "Passenger Pick Up Area"),
            description = "West-end interoperator terminal uniting Mississauga MiWay express lines and TTC Line 2 subway."
        ),
        Station(
            id = "kennedy",
            name = "Kennedy Station",
            shortName = "Kennedy",
            code = "KEN",
            operators = listOf(Operator.TTC, Operator.GO_TRANSIT),
            modes = listOf(TransitMode.SUBWAY, TransitMode.REGIONAL_TRAIN, TransitMode.BUS),
            lineIds = listOf("l2", "go_lakeshore", "34_bus"),
            x = 740f,
            y = 660f,
            isAccessible = true,
            entrances = listOf("Transway Crescent East Entrance", "Kennedy GO Platform Steps"),
            exits = listOf("Eglinton Ave East Sidewalk"),
            amenities = listOf("Multi-modal Intersect", "Elevator system"),
            description = "East-end hub serving the subway, GTHA regional train lines, and major bus operations."
        ),
        Station(
            id = "kensington_market",
            name = "Kensington Market (Dundas & Spadina)",
            shortName = "Kensington",
            code = "KSM",
            operators = listOf(Operator.TTC),
            modes = listOf(TransitMode.STREETCAR),
            lineIds = listOf("510_spadina", "505_dundas"),
            x = 300f,
            y = 620f,
            isAccessible = true,
            entrances = listOf("Spadina Avenue at Dundas Street Stop"),
            exits = listOf("Augusta Avenue Walkways"),
            amenities = listOf("Streetcar Shelter", "Bixi Bike Stations"),
            description = "A colorful, bohemian district famous for food, art, and vintage shopping."
        ),
        Station(
            id = "distillery",
            name = "Distillery District (Cherry & Mill)",
            shortName = "Distillery",
            code = "DIS",
            operators = listOf(Operator.TTC),
            modes = listOf(TransitMode.STREETCAR, TransitMode.BUS),
            lineIds = listOf("504", "121_bus"),
            x = 580f,
            y = 780f,
            isAccessible = true,
            entrances = listOf("Cherry Street Streetcar Loop"),
            exits = listOf("Mill Street Brick Archway"),
            amenities = listOf("Sheltered Loop", "Tactile Guidance"),
            description = "Historic cobblestone district of beautifully preserved Victorian industrial buildings."
        ),
        Station(
            id = "mississauga_centre",
            name = "Mississauga City Centre",
            shortName = "Mississauga CC",
            code = "MCC",
            operators = listOf(Operator.MIWAY, Operator.GO_TRANSIT),
            modes = listOf(TransitMode.BUS),
            lineIds = listOf("miway_110", "go_bus"),
            x = 40f,
            y = 780f,
            isAccessible = true,
            entrances = listOf("Square One Bus Terminal", "Duke of York Blvd Gate"),
            exits = listOf("Square One Mall Main Entrance"),
            amenities = listOf("Indoor Ticket Hall", "Regional PRESTO vending"),
            description = "Heart of Mississauga Rapid Regional network. Direct transfers from TTC Kipling terminals."
        )
    )

    val lines = listOf(
        TransitLine("l1", "Yonge–University", "1", "#FFFFC72C", TransitMode.SUBWAY, Operator.TTC),
        TransitLine("l2", "Bloor–Danforth", "2", "#00A550", TransitMode.SUBWAY, Operator.TTC),
        TransitLine("l4", "Sheppard", "4", "#7B2294", TransitMode.SUBWAY, Operator.TTC),
        TransitLine("504", "King Streetcar", "504", "#DA291C", TransitMode.STREETCAR, Operator.TTC),
        TransitLine("509", "Harbourfront Streetcar", "509", "#DA291C", TransitMode.STREETCAR, Operator.TTC),
        TransitLine("up_exp", "UP Express", "UP", "#006F62", TransitMode.REGIONAL_TRAIN, Operator.UP_EXPRESS),
        TransitLine("go_lakeshore", "Lakeshore GO Line", "GO", "#00853E", TransitMode.REGIONAL_TRAIN, Operator.GO_TRANSIT),
        TransitLine("miway_110", "University Express", "110", "#F2A900", TransitMode.BUS, Operator.MIWAY)
    )

    val destinations = listOf(
        TorontoDestination("cn_tower", "CN Tower", "Landmark", "Iconic freestanding concrete communications tower with rotating dining.", "union"),
        TorontoDestination("eaton_centre", "Eaton Centre", "Retail", "Massive downtown glass-domed architectural shopping mall with geese sculptures.", "dundas"),
        TorontoDestination("kensington", "Kensington Market", "Culture", "Bohemian open-air market network of victorian houses, cafes, and graffiti.", "kensington_market"),
        TorontoDestination("distillery_dist", "Distillery District", "Tourism", "19th-century brick distillery complex filled with art galleries, boutiques, and winter markets.", "distillery"),
        TorontoDestination("scotiabank_arena", "Scotiabank Arena", "Sports/Music", "Home of Toronto Maple Leafs & Raptors. Connected to PATH directly.", "union"),
        TorontoDestination("pearson_yyz", "Pearson International", "Airport", "Main international flight hub of Ontario.", "pearson"),
        TorontoDestination("yorkdale_mall", "Yorkdale Mall", "Retail", "Premier luxury shopping center with high modernist glass vaulted ceiling.", "yorkdale")
    )

    fun getStationById(id: String): Station? {
        return stations.find { it.id == id }
    }

    fun getLineById(id: String): TransitLine? {
        return lines.find { it.id == id }
    }
}
