package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// TTC official and design system colors
val TtcRed = Color(0xFFDA291C)
val ConcreteGrey = Color(0xFFF4F4F6)
val SteelSilver = Color(0xFFC0C3C6)
val IndustrialCharcoal = Color(0xFF1E1E24)
val DarkBackground = Color(0xFF121214)
val OffWhite = Color(0xFFFAFAFB)

// Line identifiers
val Line1Yellow = Color(0xFFFFC72C)
val Line2Green = Color(0xFF00A550)
val Line4Purple = Color(0xFF7B2294)
val Line5Orange = Color(0xFFE56A21)
val Line6Grey = Color(0xFF6B808A)

// Operator colors
val GoTransitGreen = Color(0xFF00853E)
val UpExpressTeal = Color(0xFF006F62)
val MiWayOrange = Color(0xFFF2A900)
val YrtBlue = Color(0xFF005696)
val BramptonRed = Color(0xFFC8102E)
val DurhamBlue = Color(0xFF002F6C)

// Material 3 mappings
val PrimaryLight = TtcRed
val OnPrimaryLight = Color.White
val BackgroundLight = OffWhite
val SurfaceLight = Color.White
val OnBackgroundLight = Color(0xFF1E1E24)
val OnSurfaceLight = Color(0xFF1E1E24)

val PrimaryDark = TtcRed
val OnPrimaryDark = Color.White
val BackgroundDark = DarkBackground
val SurfaceDark = IndustrialCharcoal
val OnBackgroundDark = Color(0xFFFAFAFB)
val OnSurfaceDark = Color(0xFFFAFAFB)

