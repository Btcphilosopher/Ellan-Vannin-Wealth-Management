package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.domain.*
import com.example.ui.TransitViewModel
import com.example.ui.components.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: TransitViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Switch bottom bar based on active travel state to behave like a true companion
                        if (!viewModel.activeJourneyStarted) {
                            MainBottomNavigation(
                                currentTab = viewModel.currentTab,
                                onTabSelected = { tab ->
                                    viewModel.currentTab = tab
                                    // Reset map selection state if changing tab
                                    if (tab != "MAP") {
                                        viewModel.mapSelectedStationId = null
                                    }
                                }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            AppHeader(viewModel)
                            NetworkStatusStrip(viewModel)
                            
                            // Load screens based on selection
                            Box(modifier = Modifier.weight(1f)) {
                                if (viewModel.activeJourneyStarted) {
                                    ActiveJourneyCompanionScreen(viewModel)
                                } else {
                                    when (viewModel.currentTab) {
                                        "HOME" -> HomeScreenView(viewModel)
                                        "PLAN" -> JourneyPlannerView(viewModel)
                                        "MAP" -> NetworkMapView(viewModel)
                                        "TAP" -> ContactlessPaymentView(viewModel)
                                        "MORE" -> ConfigurationSettingsView(viewModel)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun HomeScreenView(viewModel: TransitViewModel) {
    var destSearchQuery by remember { mutableStateOf("") }
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Hero Section
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E1E24))
                    .padding(horizontal = 20.dp, vertical = 24.dp)
            ) {
                Column {
                    Text(
                        text = "WHERE ARE YOU GOING?",
                        style = MaterialTheme.typography.displayMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (-1).sp,
                            fontSize = 28.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    
                    // Search bar
                    OutlinedTextField(
                        value = viewModel.searchQuery,
                        onValueChange = { 
                            viewModel.onSearchQueryChanged(it)
                            destSearchQuery = it
                        },
                        placeholder = { 
                            Text(
                                "Enter destination or station...", 
                                color = Color.Gray,
                                style = MaterialTheme.typography.bodyMedium
                            ) 
                        },
                        leadingIcon = { 
                            Icon(
                                imageVector = Icons.Default.Search, 
                                contentDescription = "Search icon", 
                                tint = Color.LightGray
                            ) 
                        },
                        trailingIcon = {
                            if (viewModel.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                    Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = Color.White)
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFDA291C),
                            unfocusedBorderColor = Color(0xFF404048),
                            focusedContainerColor = Color.Black,
                            unfocusedContainerColor = Color.Black
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("destination_search_input")
                    )
                }
            }
        }

        // Search Results drop-down overlay replacement
        if (viewModel.searchQuery.isNotEmpty()) {
            items(viewModel.filteredStations) { station ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .border(0.5.dp, Color(0xFFE5E5E8))
                        .clickable {
                            // Select station to plan or view details
                            viewModel.planToStation = station
                            viewModel.triggerJourneyPlanning()
                            viewModel.searchQuery = ""
                            viewModel.currentTab = "PLAN"
                        }
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Place,
                        contentDescription = "Station icon",
                        tint = Color(0xFFDA291C),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = station.name.uppercase(),
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Connects Lines: ${station.lineIds.joinToString(", ")}",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                        )
                    }
                }
            }
        } else {
            // Quick Destinations Grid
            item {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "QUICK DESTINATIONS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    val quickDestIds = listOf(
                        "union" to "Union",
                        "bloor_yonge" to "Yonge–Bloor",
                        "dundas" to "Dundas Square",
                        "yorkdale" to "Yorkdale",
                        "pearson" to "Pearson Airport",
                        "billy_bishop" to "Billy Bishop",
                        "scarborough" to "Scarborough Centre"
                    )

                    // Staggered horizontal list
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        quickDestIds.forEach { (id, label) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color(0xFFE5E5E8))
                                    .clickable {
                                        val station = TransitData.getStationById(id)
                                        if (station != null) {
                                            viewModel.planToStation = station
                                            viewModel.triggerJourneyPlanning()
                                            viewModel.currentTab = "PLAN"
                                        }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                                    .testTag("quick_dest_$id")
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Real-time departures for nearest station (Wellesley)
            item {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    PaddingRowHeader(title = "NEARBY STATIONS")
                    
                    // Wellesley station departure card
                    val wellesley = TransitData.getStationById("wellesley")
                    if (wellesley != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                                .clickable {
                                    viewModel.viewStationDetails(wellesley)
                                    viewModel.mapSelectedStationId = "wellesley"
                                    viewModel.currentTab = "MAP"
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, Color(0xFFE5E5E8)),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "WELLESLEY STATION",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "LINE 1 — YONGE–UNIVERSITY",
                                            style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFDA291C))
                                        )
                                    }
                                    
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(Color(0xFF142416))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color.Green))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("NORMAL", style = MaterialTheme.typography.labelSmall.copy(color = Color.Green, fontSize = 10.sp))
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(14.dp))
                                
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Next Northbound train (Finch):",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray)
                                    )
                                    
                                    val minutesLeft = (viewModel.trainCountdownSec / 60) + 1
                                    Text(
                                        text = "$minutesLeft min",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            color = Color(0xFFFFC72C),
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Flagship Union experience banner
            item {
                UnionStationSignatureModel(viewModel)
            }
        }
    }
}

@Composable
fun PaddingRowHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(
            color = Color.Gray,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        ),
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
    )
}

@Composable
fun JourneyPlannerView(viewModel: TransitViewModel) {
    var expandedFrom by remember { mutableStateOf(false) }
    var expandedTo by remember { mutableStateOf(false) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Planner Inputs Block
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
            shape = RoundedCornerShape(2.dp),
            border = BorderStroke(1.dp, Color(0xFF33333C))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "PLAN YOUR TRIP",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                )
                
                Spacer(modifier = Modifier.height(14.dp))
                
                // From Selector
                Text("FROM", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedFrom = true }
                        .background(Color.Black)
                        .border(1.dp, Color(0xFF404048))
                        .padding(12.dp)
                ) {
                    Text(
                        text = viewModel.planFromStation?.name?.uppercase() ?: "SELECT START STATION",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    DropdownMenu(
                        expanded = expandedFrom,
                        onDismissRequest = { expandedFrom = false },
                        modifier = Modifier.background(Color.Black)
                    ) {
                        TransitData.stations.forEach { station ->
                            DropdownMenuItem(
                                text = { Text(station.name, color = Color.White) },
                                onClick = {
                                    viewModel.planFromStation = station
                                    expandedFrom = false
                                    viewModel.triggerJourneyPlanning()
                                }
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(10.dp))
                
                // Swap Button
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    IconButton(
                        onClick = {
                            val tmp = viewModel.planFromStation
                            viewModel.planFromStation = viewModel.planToStation
                            viewModel.planToStation = tmp
                            viewModel.triggerJourneyPlanning()
                        }
                    ) {
                        Icon(imageVector = Icons.Default.SwapVert, contentDescription = "Swap Stations", tint = Color.White)
                    }
                }
                
                // To Selector
                Text("TO", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedTo = true }
                        .background(Color.Black)
                        .border(1.dp, Color(0xFF404048))
                        .padding(12.dp)
                ) {
                    Text(
                        text = viewModel.planToStation?.name?.uppercase() ?: "SELECT DESTINATION",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    DropdownMenu(
                        expanded = expandedTo,
                        onDismissRequest = { expandedTo = false },
                        modifier = Modifier.background(Color.Black)
                    ) {
                        TransitData.stations.forEach { station ->
                            DropdownMenuItem(
                                text = { Text(station.name, color = Color.White) },
                                onClick = {
                                    viewModel.planToStation = station
                                    expandedTo = false
                                    viewModel.triggerJourneyPlanning()
                                }
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(14.dp))
                
                // Preferences selectors
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("WHEN", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black)
                                .border(1.dp, Color(0xFF404048))
                                .padding(10.dp)
                        ) {
                            Text(viewModel.planWhen, color = Color.White, fontSize = 12.sp)
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("ROUTE PREFERENCE", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black)
                                .border(1.dp, Color(0xFF404048))
                                .padding(10.dp)
                        ) {
                            Text(viewModel.planPreference, color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        
        // Planner Results Drawer
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            items(viewModel.plannedJourneys) { journey ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .testTag("journey_result_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE5E5E8)),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = journey.routeSummary.uppercase(),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${journey.totalDurationMin} min • ${journey.legs.size} rapid leg(s)",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                                )
                            }
                            
                            // Co-fare regional calculated Price
                            Text(
                                text = "$${String.format("%.2f", journey.adultFare)}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF00A550),
                                    fontWeight = FontWeight.Black
                                )
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(14.dp))
                        
                        // Render Journey route schematic dots
                        journey.legs.forEachIndexed { idx, leg ->
                            Row(
                                modifier = Modifier.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Dot colored line
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(Color(android.graphics.Color.parseColor(leg.lineColorHex)))
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "${leg.fromStationName} → ${leg.toStationName}",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "${leg.lineName} (${leg.operator.label}) — ${leg.durationMin} mins",
                                        style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                                    )
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // START CTA
                        Button(
                            onClick = { viewModel.startJourney(journey) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("start_journey_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDA291C)),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text("START JOURNEY", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NetworkMapView(viewModel: TransitViewModel) {
    var expandedStation by remember { mutableStateOf<Station?>(TransitData.getStationById("union")) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121214))
    ) {
        // Drop-down drawer to quickly select active focus station
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E1E24))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("FOCUS:", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
            
            var expanded by remember { mutableStateOf(false) }
            Box {
                Text(
                    text = expandedStation?.name?.uppercase() ?: "SELECT FOCUS",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { expanded = true }
                        .border(1.dp, Color.Gray)
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                )
                
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                    modifier = Modifier.background(Color.Black)
                ) {
                    TransitData.stations.forEach { station ->
                        DropdownMenuItem(
                            text = { Text(station.name, color = Color.White) },
                            onClick = {
                                expandedStation = station
                                viewModel.viewStationDetails(station)
                                viewModel.mapSelectedStationId = station.id
                                expanded = false
                            }
                        )
                    }
                }
            }
            
            // Map selector toggles
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (viewModel.mapSelectedLineId == "l1") Color(0xFFFFC72C) else Color.DarkGray)
                        .clickable { viewModel.mapSelectedLineId = if (viewModel.mapSelectedLineId == "l1") null else "l1" }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("L1", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (viewModel.mapSelectedLineId == "l2") Color(0xFF00A550) else Color.DarkGray)
                        .clickable { viewModel.mapSelectedLineId = if (viewModel.mapSelectedLineId == "l2") null else "l2" }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("L2", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
        
        // Large canvas vector view
        Box(modifier = Modifier.weight(1f)) {
            SubwayVectorMap(viewModel, isZoomedToStation = expandedStation)
        }
        
        // Arrivals board under focused station
        expandedStation?.let { station ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .height(280.dp)
            ) {
                // Info block
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(station.name.uppercase(), style = MaterialTheme.typography.titleMedium.copy(color = Color.White))
                        Text("Exits: ${station.exits.joinToString(", ")}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                    }
                    
                    if (station.isAccessible) {
                        Icon(imageVector = Icons.Default.Accessible, contentDescription = "Accessible", tint = Color.Green)
                    }
                }
                
                // Real departures list
                Box(modifier = Modifier.weight(1f)) {
                    LazyColumn {
                        items(viewModel.stationDepartures) { dep ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(0.5.dp, Color(0xFF1E1E24))
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(Color(android.graphics.Color.parseColor(dep.lineColorHex)))
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(dep.destination, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White), modifier = Modifier.weight(1f))
                                Text(dep.status.label.uppercase(), style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray), modifier = Modifier.width(80.dp))
                                Text("${dep.minRemaining}m", style = MaterialTheme.typography.labelLarge.copy(color = Color(0xFFFFC72C)), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ContactlessPaymentView(viewModel: TransitViewModel) {
    val account = viewModel.prestoAccount
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Interactive Simulated PRESTO Wallet Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                // Simulated metallic/plastic PRESTO green credit-card badge
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .testTag("presto_card"),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF00853E)),
                    border = BorderStroke(1.5.dp, Color(0xFF00AA4E)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "PRESTO",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp,
                                    color = Color.White
                                )
                            )
                            Icon(
                                imageVector = Icons.Default.Nfc,
                                contentDescription = "NFC active logo",
                                tint = Color.White.copy(alpha = 0.8f)
                            )
                        }
                        
                        // Metallic chip graphics
                        Box(
                            modifier = Modifier
                                .size(32.dp, 24.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color(0xFFE5C060))
                        )
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(
                                    "CARD BALANCE",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.6f))
                                )
                                Text(
                                    "$${String.format("%.2f", account.balance)}",
                                    style = MaterialTheme.typography.displayMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        color = Color.White,
                                        fontWeight = FontWeight.Black
                                    )
                                )
                            }
                            
                            Text(
                                "•••• 9164",
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                        }
                    }
                }
            }
        }

        // Tap triggers
        item {
            NFCReadyToTapPanel(viewModel)
        }
        
        // Tap success acceptance status display
        if (viewModel.nfcState == "ACCEPTED") {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF142416)),
                    border = BorderStroke(1.dp, Color(0xFF00A550)),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Success", tint = Color.Green, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(viewModel.lastTapMessage, style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold))
                            Text("2-HOUR TRANSFER VALID AT ALL CONNECTORS", style = MaterialTheme.typography.labelSmall.copy(color = Color.Green))
                        }
                    }
                }
            }
        }

        // Monthly Capping display
        item {
            MonthlyFareCapProgress(viewModel)
        }

        // Tap history / POP (Proof of payment) section
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "YOUR PROOF OF PAYMENT",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
                    shape = RoundedCornerShape(4.dp),
                    border = BorderStroke(1.dp, Color(0xFF33333C))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("POP: SECURE TICKET ACTIVE", style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold))
                                val tapTime = if (account.activeTransferExpiry != null) "TAPPED TODAY" else "NO RECENT ACTIVE TAP"
                                Text(tapTime, style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFDA291C)))
                            }
                            Icon(imageVector = Icons.Default.QrCode, contentDescription = "pop qr", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        val activeTransfer = account.activeTransferExpiry != null
                        Text(
                            text = if (activeTransfer) "VALID TRANSFER (2H GTHA REBATE ENGAGED)" else "TAP PRESTO ABOVE TO VALIDATE RIDE",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (activeTransfer) Color.Green else Color.Gray,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Tap History list
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "RECENT TRIPS (TAP HISTORY)",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(2.dp),
                    border = BorderStroke(1.dp, Color(0xFFE5E5E8))
                ) {
                    Column {
                        viewModel.tapHistory.forEach { trip ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(0.5.dp, Color(0xFFF4F4F6))
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(trip.stationName.uppercase(), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                    Text(trip.timestampStr, style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                }
                                
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = if (trip.isTransfer) "Transfer" else "$${String.format("%.2f", trip.fareCharged)}",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = if (trip.isTransfer) Color(0xFF00853E) else Color.Black,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text("Bal: $${String.format("%.2f", trip.balanceAfter)}", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontSize = 9.sp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ConfigurationSettingsView(viewModel: TransitViewModel) {
    var addAmount by remember { mutableStateOf("10.00") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Network simulator panel
        item {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "NETWORK SIMULATOR PROFILES",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                SimulationMode.values().forEach { mode ->
                    val selected = viewModel.simulationMode == mode
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .border(
                                1.dp,
                                if (selected) Color(0xFFDA291C) else Color(0xFFE5E5E8),
                                RoundedCornerShape(2.dp)
                            )
                            .clickable { viewModel.changeSimulationMode(mode) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selected) Color(0xFF1E1E24) else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selected,
                                onClick = { viewModel.changeSimulationMode(mode) },
                                colors = RadioButtonDefaults.colors(selectedColor = Color(0xFFDA291C))
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = mode.label.uppercase(),
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (selected) Color.White else Color.Black
                                    )
                                )
                                Text(
                                    text = mode.description,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = if (selected) Color.LightGray else Color.Gray
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Active Service Alerts list
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                Text(
                    text = "ACTIVE TTC SERVICE ALERTS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))
                
                if (viewModel.serviceAlerts.isEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Text(
                            "All networks operating normally. No active alerts.",
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyMedium.copy(color = Color.DarkGray)
                        )
                    }
                } else {
                    viewModel.serviceAlerts.forEach { alert ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF3E1412)),
                            border = BorderStroke(1.dp, Color.Red)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = alert.title.uppercase(),
                                    style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = alert.message,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.White)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "ALTERNATIVE ADVICE: ${alert.alternativeAdvice}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Yellow)
                                )
                            }
                        }
                    }
                }
            }
        }

        // PRESTO Account Top up emulations
        item {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "PRESTO EMULATOR TOOLKIT",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color(0xFFE5E5E8)),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Add Balance directly to PRESTO Card", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { viewModel.addPrestoBalance(10.00) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00853E)),
                                shape = RoundedCornerShape(2.dp)
                            ) {
                                Text("+$10.00", color = Color.White)
                            }
                            Button(
                                onClick = { viewModel.addPrestoBalance(20.00) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00853E)),
                                shape = RoundedCornerShape(2.dp)
                            ) {
                                Text("+$20.00", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Full screen overlay that transforms Transit.OS when active travel scenario begins
@Composable
fun ActiveJourneyCompanionScreen(viewModel: TransitViewModel) {
    val journey = viewModel.activeJourney ?: return
    val leg = journey.legs.getOrNull(viewModel.activeJourneyLegIndex) ?: return
    
    val countdownMinutes = (viewModel.trainCountdownSec / 60) + 1
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121214))
    ) {
        // Global Journey Summary block
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E1E24))
                    .padding(horizontal = 20.dp, vertical = 20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "YOUR ACTIVE JOURNEY",
                            style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFDA291C), fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${journey.legs.first().fromStationName.uppercase()} → ${journey.legs.last().toStationName.uppercase()}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                        )
                    }
                    
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${journey.totalDurationMin}m left",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black
                            )
                        )
                        Text(
                            text = "ESTIMATED BY WEATHER",
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontSize = 8.sp)
                        )
                    }
                }
            }
        }
        
        // Progress sequence visual line
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .padding(vertical = 12.dp, horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                journey.legs.forEachIndexed { idx, itemLeg ->
                    val isPast = idx < viewModel.activeJourneyLegIndex
                    val isCurrent = idx == viewModel.activeJourneyLegIndex
                    val col = if (isPast) Color.DarkGray else if (isCurrent) Color(android.graphics.Color.parseColor(itemLeg.lineColorHex)) else Color.Gray.copy(alpha = 0.3f)
                    
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(col)
                    )
                }
            }
        }
        
        // Huge Step display
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "CURRENT INSTRUCTION",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, letterSpacing = 1.sp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
                    border = BorderStroke(1.dp, Color(android.graphics.Color.parseColor(leg.lineColorHex))),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color(android.graphics.Color.parseColor(leg.lineColorHex)))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = leg.lineNumber ?: leg.mode.label.uppercase(),
                                    color = if (leg.lineId == "l1") Color.Black else Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = leg.lineName.uppercase(),
                                style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Text(
                            text = leg.instructions,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                lineHeight = 24.sp
                            )
                        )
                        
                        Spacer(modifier = Modifier.height(14.dp))
                        
                        // Approaching physical animation
                        if (leg.mode == TransitMode.SUBWAY) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color.Black)
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("TRAIN APPROACHING", style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFFFC72C)))
                                    Text("Arriving in platform queue", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                }
                                
                                Text(
                                    text = if (viewModel.trainCountdownSec <= 15) "ARRIVING" else "${countdownMinutes}m",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = if (viewModel.trainCountdownSec <= 15) Color.Green else Color(0xFFFFC72C),
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
        
        // Stops remaining inside this leg
        if (leg.stops.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Text(
                        text = "STOPS LIST IN PROGRESS",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    leg.stops.forEach { stop ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(0.5.dp, Color(0xFF1E1E24))
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.6f))
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(stop.stopName, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White))
                            }
                            
                            Text(
                                text = "${stop.timeRemainingMin}m",
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontFamily = FontFamily.Monospace)
                            )
                        }
                    }
                }
            }
        }
        
        // Navigation companion control buttons
        item {
            Column(modifier = Modifier.padding(20.dp)) {
                Button(
                    onClick = { viewModel.advanceJourneyLeg() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("advance_journey_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDA291C)),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    val label = if (viewModel.activeJourneyLegIndex < journey.legs.size - 1) "TRANSFER / NEXT STEP" else "COMPLETE JOURNEY"
                    Text(label, fontWeight = FontWeight.Bold, color = Color.White)
                }
                
                Spacer(modifier = Modifier.height(10.dp))
                
                OutlinedButton(
                    onClick = { viewModel.cancelJourney() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, Color.DarkGray),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text("CANCEL ACTIVE TRANSIT", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
