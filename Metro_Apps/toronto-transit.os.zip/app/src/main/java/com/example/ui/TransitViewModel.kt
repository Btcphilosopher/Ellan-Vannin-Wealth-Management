package com.example.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.domain.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TransitViewModel : ViewModel() {

    // Providers
    val fareProvider = SyntheticPRESTOProvider()
    val weatherProvider = SyntheticWeatherProvider()
    val ttcProvider = SyntheticTTCProvider()

    // Core States
    var currentTab by mutableStateOf("HOME") // HOME, PLAN, MAP, TAP, MORE, JOURNEY
    
    // Active Journey States
    var activeJourney by mutableStateOf<Journey?>(null)
    var activeJourneyStarted by mutableStateOf(false)
    var activeJourneyLegIndex by mutableStateOf(0)
    var isApproachingDestination by mutableStateOf(false)
    var isArrived by mutableStateOf(false)
    
    // NFC Tap State
    var nfcState by mutableStateOf("IDLE") // IDLE, READY_TO_TAP, TAP_HELD, ACCEPTED, ERROR
    var lastTapMessage by mutableStateOf("")
    var lastTapSuccessAmount by mutableStateOf(0.0)

    // PRESTO Account State
    var prestoAccount by mutableStateOf(
        PrestoAccount(
            cardNumber = "3220 8914 5580 9164",
            balance = 15.40,
            activeTransferExpiry = null,
            transferStartedStation = null,
            currentMonthPaidTrips = 32, // Starts at 32 for the demonstration flows
            autoLoadActive = true,
            autoLoadAmount = 20.0
        )
    )
    
    var tapHistory by mutableStateOf<List<TapTransaction>>(
        listOf(
            TapTransaction("t_0", "Yesterday 18:12", "Wellesley Station", Operator.TTC, 3.30, false, 15.40),
            TapTransaction("t_1", "Yesterday 14:03", "Union Station", Operator.TTC, 3.30, false, 18.70),
            TapTransaction("t_2", "Yesterday 14:27", "Bloor–Yonge", Operator.TTC, 0.00, true, 18.70)
        )
    )

    // Simulation States
    var simulationMode by mutableStateOf(SimulationMode.NORMAL)
    var weather by mutableStateOf(weatherProvider.getCurrentWeather(SimulationMode.NORMAL))
    var serviceAlerts by mutableStateOf<List<ServiceAlert>>(emptyList())
    
    // Search & Selection
    var searchQuery by mutableStateOf("")
    var filteredStations by mutableStateOf<List<Station>>(TransitData.stations)
    var selectedStation by mutableStateOf<Station?>(null)
    
    // Journey Planner Inputs
    var planFromStation by mutableStateOf<Station?>(TransitData.getStationById("union"))
    var planToStation by mutableStateOf<Station?>(TransitData.getStationById("bloor_yonge"))
    var planWhen by mutableStateOf("Leave now")
    var planPreference by mutableStateOf("Fastest")
    var plannedJourneys by mutableStateOf<List<Journey>>(emptyList())

    // Live Departures
    var stationDepartures by mutableStateOf<List<Departure>>(emptyList())

    // Map Interactivity
    var mapSelectedStationId by mutableStateOf<String?>(null)
    var mapSelectedLineId by mutableStateOf<String?>(null)

    // Animated countdown for approaching train
    var trainCountdownSec by mutableStateOf(120) // 2 minutes in seconds
    var animateTrainPosition by mutableStateOf(0f) // 0f to 1f along the platform track
    private var countdownJob: Job? = null

    init {
        updateAlertsForCurrentMode()
        triggerJourneyPlanning()
        startTrainCountdownTimer()
    }

    // Adjust simulation triggers
    fun changeSimulationMode(mode: SimulationMode) {
        simulationMode = mode
        weather = weatherProvider.getCurrentWeather(mode)
        updateAlertsForCurrentMode()
        triggerJourneyPlanning()
        // Refresh selected station details if any
        selectedStation?.let { viewStationDetails(it) }
    }

    fun updateAlertsForCurrentMode() {
        serviceAlerts = ttcProvider.getActiveAlerts(simulationMode)
    }

    // Station Search autocomplete with spell-checking tolerance
    fun onSearchQueryChanged(query: String) {
        searchQuery = query
        if (query.isBlank()) {
            filteredStations = TransitData.stations
        } else {
            val q = query.lowercase().trim()
            filteredStations = TransitData.stations.filter { station ->
                // Exact, prefix, abbreviation or spelling-mistake tolerance
                station.name.lowercase().contains(q) ||
                station.shortName.lowercase().contains(q) ||
                station.code.lowercase().contains(q) ||
                // Spell tolerance: "yonge bloore" maps to "Bloor-Yonge"
                (q.contains("yonge") && q.contains("bloor")) ||
                (q.contains("yonge") && q.contains("bloore")) ||
                (q.contains("union") && station.id == "union") ||
                (q.contains("pearson") && station.id == "pearson") ||
                (q.contains("stc") && station.id == "scarborough") ||
                (q.contains("distil") && station.id == "distillery")
            }
        }
    }

    // View station specific arrivals & structure
    fun viewStationDetails(station: Station) {
        selectedStation = station
        stationDepartures = ttcProvider.getDeparturesForStation(station.id, simulationMode, weather)
    }

    // Multi-modal Planner Trigger
    fun triggerJourneyPlanning() {
        val from = planFromStation
        val to = planToStation
        if (from != null && to != null) {
            plannedJourneys = ttcProvider.planJourney(from.id, to.id, simulationMode, weather, planPreference)
        }
    }

    // Start Journey companion OS flow
    fun startJourney(journey: Journey) {
        activeJourney = journey
        activeJourneyLegIndex = 0
        activeJourneyStarted = true
        isApproachingDestination = false
        isArrived = false
        currentTab = "JOURNEY"
        
        // Reset countdown timer for physical animation
        trainCountdownSec = 120 
    }

    fun cancelJourney() {
        activeJourney = null
        activeJourneyStarted = false
        currentTab = "HOME"
    }

    fun advanceJourneyLeg() {
        val journey = activeJourney ?: return
        if (activeJourneyLegIndex < journey.legs.size - 1) {
            activeJourneyLegIndex++
        } else {
            // Arrived
            isArrived = true
        }
    }

    // Simulated NFC Tap Flow with GTHA 2-Hour transfer + Cap evaluation
    fun triggerNFCTap() {
        if (nfcState != "IDLE") return
        
        viewModelScope.launch {
            nfcState = "READY_TO_TAP"
            delay(1200) // Phone approaching field
            nfcState = "TAP_HELD"
            delay(1000) // Authenticating with reader
            
            val nowMs = System.currentTimeMillis()
            val fareValue = fareProvider.getAdultContactlessFare()
            val stationName = selectedStation?.name ?: "Union Station"
            
            // 1. Check if 2-hour transfer is active
            val transferExpiry = prestoAccount.activeTransferExpiry
            val isTransferActive = transferExpiry != null && nowMs < transferExpiry
            
            val isCapReached = prestoAccount.isFareCapReached
            
            val fareCharged = when {
                isTransferActive -> 0.0
                isCapReached -> 0.0
                else -> fareValue
            }
            
            // Check if card balance is sufficient (auto-loads if active)
            var currentBalance = prestoAccount.balance
            if (currentBalance < fareCharged && prestoAccount.autoLoadActive) {
                currentBalance += prestoAccount.autoLoadAmount
            }
            
            if (currentBalance < fareCharged) {
                nfcState = "ERROR"
                lastTapMessage = "INSUFFICIENT FUNDS"
                return@launch
            }
            
            // Charge and update details
            val newBalance = currentBalance - fareCharged
            val newTrips = if (!isTransferActive && !isCapReached && fareCharged > 0) {
                prestoAccount.currentMonthPaidTrips + 1
            } else {
                prestoAccount.currentMonthPaidTrips
            }
            
            // If new tap (not a transfer), set transfer window of 2 hours (7200 seconds / 7200000 ms)
            val newExpiry = if (isTransferActive) {
                transferExpiry
            } else {
                nowMs + 7200000 // 2 hours
            }
            
            prestoAccount = prestoAccount.copy(
                balance = newBalance,
                activeTransferExpiry = newExpiry,
                transferStartedStation = if (isTransferActive) prestoAccount.transferStartedStation else stationName,
                currentMonthPaidTrips = newTrips
            )
            
            // Update Tap History
            val sdf = SimpleDateFormat("HH:mm", Locale.US)
            val timeStr = "Today " + sdf.format(Date(nowMs))
            
            val transaction = TapTransaction(
                id = "t_new_${System.currentTimeMillis()}",
                timestampStr = timeStr,
                stationName = stationName,
                operator = selectedStation?.operators?.firstOrNull() ?: Operator.TTC,
                fareCharged = fareCharged,
                isTransfer = isTransferActive,
                balanceAfter = newBalance
            )
            
            tapHistory = listOf(transaction) + tapHistory
            lastTapSuccessAmount = fareCharged
            
            if (isTransferActive) {
                lastTapMessage = "TRANSFER ACCEPTED - $0.00"
            } else if (newTrips == 47 && fareCharged > 0) {
                lastTapMessage = "TAP ACCEPTED - CAP REACHED!"
            } else if (isCapReached) {
                lastTapMessage = "FARE CAP ACTIVE - $0.00"
            } else {
                lastTapMessage = "TAP ACCEPTED - $$fareCharged"
            }
            
            nfcState = "ACCEPTED"
            delay(3500)
            nfcState = "IDLE"
        }
    }

    // Direct mock modifier to test the 46 -> 47 monthly cap progression instantly
    fun setPrestoPaidTrips(count: Int) {
        prestoAccount = prestoAccount.copy(currentMonthPaidTrips = count)
    }

    fun addPrestoBalance(amount: Double) {
        prestoAccount = prestoAccount.copy(balance = prestoAccount.balance + amount)
    }

    // Train countdown simulation loop
    private fun startTrainCountdownTimer() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (trainCountdownSec > 0) {
                    trainCountdownSec--
                    
                    // Animate the train approaching visually when < 60 seconds
                    if (trainCountdownSec <= 60) {
                        // Position advances from 0f (entering tunnel) to 1f (arrived at platform edge)
                        animateTrainPosition = (60 - trainCountdownSec) / 60f
                    } else {
                        animateTrainPosition = 0f
                    }
                } else {
                    // Reset or trigger boarding
                    trainCountdownSec = 180 // Refresh to next train (3 minutes)
                    animateTrainPosition = 0f
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        countdownJob?.cancel()
    }
}
