package com.example.data

import com.example.domain.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

// Data Provenance Wrapping
data class OperationalEnvelope<T>(
    val data: T,
    val source: String = "SYNTHETIC",
    val updatedAt: String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZZZZZ", Locale.US).format(Date()),
    val status: String = "SIMULATED",
    val isLive: Boolean = false
)

// Provider Interfaces
interface FareProvider {
    fun getAdultContactlessFare(): Double
    fun calculateJourneyFare(legs: List<JourneyLeg>): Double
}

interface WeatherProvider {
    fun getCurrentWeather(mode: SimulationMode): WeatherCondition
}

interface DisruptionProvider {
    fun getActiveAlerts(mode: SimulationMode): List<ServiceAlert>
}

interface DepartureProvider {
    fun getDeparturesForStation(stationId: String, mode: SimulationMode, weather: WeatherCondition): List<Departure>
}

interface JourneyPlannerProvider {
    fun planJourney(
        fromId: String,
        toId: String,
        mode: SimulationMode,
        weather: WeatherCondition,
        preferences: String = "Fastest"
    ): List<Journey>
}

// Implementations
class SyntheticPRESTOProvider : FareProvider {
    // $3.30 is the official adult PRESTO fare for TTC
    override fun getAdultContactlessFare(): Double = 3.30

    override fun calculateJourneyFare(legs: List<JourneyLeg>): Double {
        if (legs.isEmpty()) return 0.0
        
        // One Fare GTHA co-fare calculations (Free transfers between TTC, MiWay, YRT, Durham, Brampton and rebates on GO)
        var hasTtc = false
        var hasGo = false
        var hasUp = false
        var hasMiway = false
        
        for (leg in legs) {
            when (leg.operator) {
                Operator.TTC -> hasTtc = true
                Operator.GO_TRANSIT -> hasGo = true
                Operator.UP_EXPRESS -> hasUp = true
                Operator.MIWAY -> hasMiway = true
                else -> {}
            }
        }
        
        // UP Express is premium and not in One Fare rebate
        if (hasUp) {
            return 12.35 // Standard Union-Pearson UP Express fare
        }
        
        // GO Transit + TTC
        if (hasGo && hasTtc) {
            // Under Ontario's One Fare, local TTC fare is 100% rebated, rider pays only GO fare
            return 6.85 // Average GO fare
        }
        
        if (hasGo) return 5.50
        
        // Local multi-operator (TTC + MiWay/YRT)
        if (hasTtc || hasMiway) {
            // One Fare covers local rapid regional transit transfers
            return 3.30
        }
        
        return 3.30
    }
}

class SyntheticWeatherProvider : WeatherProvider {
    override fun getCurrentWeather(mode: SimulationMode): WeatherCondition {
        return when (mode) {
            SimulationMode.WINTER_STORM -> WeatherCondition(
                type = WeatherType.HEAVY_SNOW,
                temperatureCelsius = -12,
                description = "Heavy snowfall warning. Surface routes experiencing significant drag. Indoor transfers strongly recommended.",
                walkingSpeedModifier = 0.65f,
                surfaceDelayFactor = 12
            )
            else -> WeatherCondition(
                type = WeatherType.WINTER, // Default Toronto season in our operating system for aesthetics
                temperatureCelsius = -2,
                description = "Flurries. Walk times slightly adjusted.",
                walkingSpeedModifier = 0.9f,
                surfaceDelayFactor = 2
            )
        }
    }
}

class SyntheticTTCProvider : DisruptionProvider, DepartureProvider, JourneyPlannerProvider {

    override fun getActiveAlerts(mode: SimulationMode): List<ServiceAlert> {
        val alerts = mutableListOf<ServiceAlert>()
        
        // Default Alerts always active
        alerts.add(
            ServiceAlert(
                id = "alert_stc",
                lineId = "go_bus",
                affectedOperator = Operator.GO_TRANSIT,
                title = "GO Bus Platform Relocation",
                message = "All Scarborough Town Centre GO bus platforms shifted to South Terminal until Dec 2026.",
                expectedDelayMin = 0,
                alternativeAdvice = "Follow on-site platform signage."
            )
        )
        
        when (mode) {
            SimulationMode.STREETCAR_DIVERSION -> {
                alerts.add(
                    ServiceAlert(
                        id = "alert_504",
                        lineId = "504",
                        affectedOperator = Operator.TTC,
                        title = "504 King Diversion",
                        message = "Delays on 504 King streetcar due to track structural work. Diverted via Queen St between Spadina and Parliament.",
                        expectedDelayMin = 15,
                        alternativeAdvice = "Board 504 streetcars on Queen St or use 501 Queen streetcars."
                    )
                )
            }
            SimulationMode.ELEVATOR_OUTAGE -> {
                alerts.add(
                    ServiceAlert(
                        id = "alert_elev_union",
                        lineId = "l1",
                        affectedOperator = Operator.TTC,
                        title = "Elevator Outage at Union Station",
                        message = "Main platform elevator to Line 1 Northbound is temporarily out of service.",
                        expectedDelayMin = 0,
                        alternativeAdvice = "Passengers requiring step-free access are advised to use Royal York PATH gate or contact station staff."
                    )
                )
            }
            SimulationMode.MAJOR_INCIDENT -> {
                alerts.add(
                    ServiceAlert(
                        id = "alert_l1_fail",
                        lineId = "l1",
                        affectedOperator = Operator.TTC,
                        title = "Line 1 Major Signal Delays",
                        message = "Severe signal delays between Union and Bloor-Yonge. Trains holding at platforms.",
                        expectedDelayMin = 20,
                        alternativeAdvice = "Use 19 Bay bus or walk via PATH tunnel where possible."
                    )
                )
            }
            SimulationMode.WINTER_STORM -> {
                alerts.add(
                    ServiceAlert(
                        id = "alert_winter_general",
                        lineId = null,
                        affectedOperator = Operator.TTC,
                        title = "Severe Weather Operations",
                        message = "Heavy snow. Reduced speeds across all surface streetcar routes (504, 509) and bus networks.",
                        expectedDelayMin = 12,
                        alternativeAdvice = "TTC Subway operating normally. Limit outdoor transfers."
                    )
                )
            }
            else -> {
                // Normal
            }
        }
        return alerts
    }

    override fun getDeparturesForStation(stationId: String, mode: SimulationMode, weather: WeatherCondition): List<Departure> {
        val departures = mutableListOf<Departure>()
        val rand = Random(stationId.hashCode() + mode.ordinal)
        
        // Find lines serving this station
        val station = TransitData.getStationById(stationId) ?: return emptyList()
        
        for (lineId in station.lineIds) {
            val line = TransitData.getLineById(lineId) ?: continue
            val baseHeadway = when (mode) {
                SimulationMode.MORNING_RUSH -> 2
                SimulationMode.EVENING_RUSH -> 3
                SimulationMode.WINTER_STORM -> 8
                else -> 5
            }
            
            // Adjust delays based on weather
            val delayAdd = if (line.mode == TransitMode.STREETCAR || line.mode == TransitMode.BUS) {
                weather.surfaceDelayFactor
            } else {
                0
            }
            
            val dests = when (lineId) {
                "l1" -> listOf("Finch (Northbound)", "Vaughan Metropolitan Centre (Northbound)")
                "l2" -> listOf("Kennedy (Eastbound)", "Kipling (Westbound)")
                "504" -> listOf("Distillery District", "Dundas West Station")
                "509" -> listOf("Union Station", "Exhibition Place")
                "up_exp" -> listOf("Pearson Airport YYZ", "Union Station")
                "go_lakeshore" -> listOf("Oshawa GO (Eastbound)", "Aldershot GO (Westbound)")
                else -> listOf("Downtown")
            }
            
            for (i in 0..2) {
                val dest = dests[i % dests.size]
                val mins = (i * baseHeadway) + rand.nextInt(1, baseHeadway.coerceAtLeast(2)) + delayAdd
                
                var status = when {
                    mins <= 1 -> DepartureStatus.BOARDING
                    mode == SimulationMode.MAJOR_INCIDENT && lineId == "l1" -> DepartureStatus.DELAYED
                    mode == SimulationMode.WINTER_STORM && (line.mode == TransitMode.STREETCAR || line.mode == TransitMode.BUS) -> DepartureStatus.DELAYED
                    else -> DepartureStatus.ESTIMATED
                }
                
                val crowding = when (mode) {
                    SimulationMode.MORNING_RUSH -> CrowdingLevel.VERY_BUSY
                    SimulationMode.EVENING_RUSH -> CrowdingLevel.BUSY
                    else -> if (rand.nextBoolean()) CrowdingLevel.LOW else CrowdingLevel.MODERATE
                }
                
                departures.add(
                    Departure(
                        id = "${stationId}_${lineId}_$i",
                        lineId = lineId,
                        lineName = line.name,
                        lineNumber = line.number,
                        lineColorHex = line.colorHex,
                        destination = dest,
                        minRemaining = if (status == DepartureStatus.BOARDING) 0 else mins,
                        status = status,
                        crowding = crowding,
                        isLive = true,
                        platform = if (line.mode == TransitMode.SUBWAY) "Platform ${i % 2 + 1}" else "Stop Loop"
                    )
                )
            }
        }
        
        return departures.sortedBy { it.minRemaining }
    }

    override fun planJourney(
        fromId: String,
        toId: String,
        mode: SimulationMode,
        weather: WeatherCondition,
        preferences: String
    ): List<Journey> {
        val results = mutableListOf<Journey>()
        
        // We deterministic map-route plans for requested key scenarios:
        // SCENARIO 1: Union -> Bloor-Yonge
        if (fromId == "union" && toId == "bloor_yonge") {
            // Direct Subway route
            val baseTime = 12
            val finalTime = if (mode == SimulationMode.MAJOR_INCIDENT) baseTime + 15 else baseTime
            
            results.add(
                Journey(
                    id = "j_union_by_sub",
                    fromStationId = fromId,
                    toStationId = toId,
                    totalDurationMin = finalTime,
                    legs = listOf(
                        JourneyLeg(
                            mode = TransitMode.SUBWAY,
                            operator = Operator.TTC,
                            lineId = "l1",
                            lineName = "Yonge–University",
                            lineNumber = "1",
                            lineColorHex = "#FFFFC72C",
                            fromStationName = "Union",
                            toStationName = "Bloor–Yonge",
                            durationMin = finalTime,
                            stopsCount = 5,
                            stops = listOf(
                                StopInfo("King", 2),
                                StopInfo("Queen", 4),
                                StopInfo("Dundas", 6),
                                StopInfo("Wellesley", 9),
                                StopInfo("Bloor–Yonge", finalTime)
                            ),
                            instructions = "Board Line 1 Northbound on Platform 1 toward Finch. Travel 5 stops.",
                            crowding = if (mode == SimulationMode.MORNING_RUSH) CrowdingLevel.VERY_BUSY else CrowdingLevel.MODERATE
                        )
                    ),
                    adultFare = 3.30,
                    routeSummary = "Line 1 Yonge–University",
                    operatorBreakdown = listOf(Operator.TTC)
                )
            )
        }
        
        // SCENARIO 2: Union -> Pearson YYZ
        if (fromId == "union" && toId == "pearson") {
            // Option A: UP Express (Fastest, regional premium)
            results.add(
                Journey(
                    id = "j_union_pearson_up",
                    fromStationId = fromId,
                    toStationId = toId,
                    totalDurationMin = 25,
                    legs = listOf(
                        JourneyLeg(
                            mode = TransitMode.REGIONAL_TRAIN,
                            operator = Operator.UP_EXPRESS,
                            lineId = "up_exp",
                            lineName = "UP Express",
                            lineNumber = "UP",
                            lineColorHex = "#006F62",
                            fromStationName = "Union Station",
                            toStationName = "Pearson Airport T3/T1",
                            durationMin = 25,
                            stopsCount = 2,
                            stops = listOf(
                                StopInfo("Bloor GO", 8),
                                StopInfo("Weston GO", 15),
                                StopInfo("Pearson Airport", 25)
                            ),
                            instructions = "Board UP Express train at Union station UP Platform. Direct express service.",
                            crowding = CrowdingLevel.LOW
                        )
                    ),
                    adultFare = 12.35,
                    routeSummary = "UP Express (Direct Rail)",
                    operatorBreakdown = listOf(Operator.UP_EXPRESS)
                )
            )
            
            // Option B: TTC Subway + Express Bus (Lowest Cost)
            val ttcTime = if (mode == SimulationMode.WINTER_STORM) 72 else 55
            results.add(
                Journey(
                    id = "j_union_pearson_ttc",
                    fromStationId = fromId,
                    toStationId = toId,
                    totalDurationMin = ttcTime,
                    legs = listOf(
                        JourneyLeg(
                            mode = TransitMode.SUBWAY,
                            operator = Operator.TTC,
                            lineId = "l1",
                            lineName = "Yonge–University",
                            lineNumber = "1",
                            lineColorHex = "#FFFFC72C",
                            fromStationName = "Union",
                            toStationName = "Bloor–Yonge",
                            durationMin = 12,
                            stopsCount = 5,
                            instructions = "Take Line 1 Northbound to Bloor-Yonge."
                        ),
                        JourneyLeg(
                            mode = TransitMode.SUBWAY,
                            operator = Operator.TTC,
                            lineId = "l2",
                            lineName = "Bloor–Danforth",
                            lineNumber = "2",
                            lineColorHex = "#00A550",
                            fromStationName = "Bloor–Yonge",
                            toStationName = "Kipling",
                            durationMin = 24,
                            stopsCount = 14,
                            instructions = "Transfer to Line 2 Westbound. Ride to Kipling Terminal."
                        ),
                        JourneyLeg(
                            mode = TransitMode.BUS,
                            operator = Operator.TTC,
                            lineId = null,
                            lineName = "900 Airport Rocket",
                            lineNumber = "900",
                            lineColorHex = "#DA291C",
                            fromStationName = "Kipling Station",
                            toStationName = "Pearson Airport",
                            durationMin = ttcTime - 36,
                            stopsCount = 4,
                            instructions = "Board 900 Airport Express Bus at Bay 2. Arrive at Airport T1/T3."
                        )
                    ),
                    adultFare = 3.30,
                    routeSummary = "TTC One-Fare Subway + Airport Express Bus",
                    operatorBreakdown = listOf(Operator.TTC)
                )
            )
        }
        
        // SCENARIO 3: Kensington Market -> Distillery District (Walking + Streetcar)
        if (fromId == "kensington_market" && toId == "distillery") {
            val normalStreetcarTime = 16
            val delayTime = if (mode == SimulationMode.STREETCAR_DIVERSION) 15 else 0
            val totalWalkTime = (4 / weather.walkingSpeedModifier).toInt() // Walking adjusted by winter
            
            results.add(
                Journey(
                    id = "j_ksm_dist_504",
                    fromStationId = fromId,
                    toStationId = toId,
                    totalDurationMin = normalStreetcarTime + delayTime + totalWalkTime,
                    legs = listOf(
                        JourneyLeg(
                            mode = TransitMode.STREETCAR,
                            operator = Operator.TTC,
                            lineId = "504",
                            lineName = "504 King Streetcar",
                            lineNumber = "504",
                            lineColorHex = "#DA291C",
                            fromStationName = "Spadina & King",
                            toStationName = "Distillery Loop",
                            durationMin = normalStreetcarTime + delayTime,
                            stopsCount = 8,
                            instructions = "Walk south to King St. Board 504 King Eastbound to Cherry St." + 
                                           if (mode == SimulationMode.STREETCAR_DIVERSION) " (Diverted via Queen St due to maintenance)" else ""
                        )
                    ),
                    adultFare = 3.30,
                    routeSummary = "504 King Streetcar",
                    operatorBreakdown = listOf(Operator.TTC)
                )
            )
        }
        
        // SCENARIO 4: Scarborough -> Downtown (Union)
        if (fromId == "scarborough" && toId == "union") {
            results.add(
                Journey(
                    id = "j_stc_union_multi",
                    fromStationId = fromId,
                    toStationId = toId,
                    totalDurationMin = 48,
                    legs = listOf(
                        JourneyLeg(
                            mode = TransitMode.BUS,
                            operator = Operator.TTC,
                            lineId = null,
                            lineName = "38 Ellesmere Bus",
                            lineNumber = "38",
                            lineColorHex = "#DA291C",
                            fromStationName = "Scarborough Centre",
                            toStationName = "Kennedy Station",
                            durationMin = 14,
                            stopsCount = 9,
                            instructions = "Board 38 Ellesmere Bus to Kennedy station."
                        ),
                        JourneyLeg(
                            mode = TransitMode.SUBWAY,
                            operator = Operator.TTC,
                            lineId = "l2",
                            lineName = "Bloor–Danforth",
                            lineNumber = "2",
                            lineColorHex = "#00A550",
                            fromStationName = "Kennedy",
                            toStationName = "Bloor–Yonge",
                            durationMin = 22,
                            stopsCount = 12,
                            instructions = "Transfer to Line 2 Westbound to Bloor-Yonge."
                        ),
                        JourneyLeg(
                            mode = TransitMode.SUBWAY,
                            operator = Operator.TTC,
                            lineId = "l1",
                            lineName = "Yonge–University",
                            lineNumber = "1",
                            lineColorHex = "#FFFFC72C",
                            fromStationName = "Bloor–Yonge",
                            toStationName = "Union",
                            durationMin = 12,
                            stopsCount = 5,
                            instructions = "Transfer to Line 1 Southbound to Union."
                        )
                    ),
                    adultFare = 3.30,
                    routeSummary = "TTC Subway Connect",
                    operatorBreakdown = listOf(Operator.TTC)
                )
            )
        }
        
        // DEFAULT FALLBACK IN CASE USER SEARCHES OTHER PLACES
        if (results.isEmpty()) {
            val fromStation = TransitData.getStationById(fromId)
            val toStation = TransitData.getStationById(toId)
            if (fromStation != null && toStation != null) {
                // Dynamic mock journey
                results.add(
                    Journey(
                        id = "j_${fromId}_${toId}_mock",
                        fromStationId = fromId,
                        toStationId = toId,
                        totalDurationMin = 32,
                        legs = listOf(
                            JourneyLeg(
                                mode = if (fromStation.modes.contains(TransitMode.SUBWAY)) TransitMode.SUBWAY else TransitMode.BUS,
                                operator = fromStation.operators.first(),
                                lineId = fromStation.lineIds.firstOrNull(),
                                lineName = "Rapid Connection",
                                lineNumber = "T1",
                                lineColorHex = "#DA291C",
                                fromStationName = fromStation.name,
                                toStationName = toStation.name,
                                durationMin = 32,
                                stopsCount = 6,
                                instructions = "Board first available vehicle from ${fromStation.name} toward ${toStation.name}."
                            )
                        ),
                        adultFare = 3.30,
                        routeSummary = "Regional Transit Link",
                        operatorBreakdown = listOf(fromStation.operators.first())
                    )
                )
            }
        }
        
        return results
    }
}
