package com.example.domain

import androidx.compose.ui.graphics.Color

enum class Operator(val label: String, val brandColorHex: String) {
    TTC("TTC", "#DA291C"),
    GO_TRANSIT("GO Transit", "#00853E"),
    UP_EXPRESS("UP Express", "#006F62"),
    MIWAY("MiWay", "#F2A900"),
    YRT("YRT", "#005696"),
    BRAMPTON_TRANSIT("Brampton Transit", "#C8102E"),
    DURHAM_REGION_TRANSIT("Durham Transit", "#002F6C")
}

enum class TransitMode(val label: String) {
    SUBWAY("Subway"),
    LIGHT_RAIL("LRT"),
    STREETCAR("Streetcar"),
    BUS("Bus"),
    REGIONAL_TRAIN("Regional Train")
}

enum class DepartureStatus(val label: String) {
    SCHEDULED("Scheduled"),
    ESTIMATED("Estimated"),
    BOARDING("Boarding"),
    DEPARTED("Departed"),
    DELAYED("Delayed"),
    CANCELLED("Cancelled"),
    DIVERTED("Diverted"),
    SIMULATED("Simulated")
}

enum class CrowdingLevel(val label: String) {
    LOW("Low"),
    MODERATE("Moderate"),
    BUSY("Busy"),
    VERY_BUSY("Very Busy")
}

enum class WeatherType(val label: String) {
    SUMMER("Summer Mode"),
    WINTER("Winter Mode"),
    HEAVY_SNOW("Heavy Snow"),
    FREEZING_RAIN("Freezing Rain"),
    HEAT("Heat Alert")
}

enum class SimulationMode(val label: String, val description: String) {
    NORMAL("Normal Day", "Standard service, perfect headways."),
    MORNING_RUSH("Morning Rush", "High demand, trains every 2 minutes, crowded platforms."),
    EVENING_RUSH("Evening Rush", "Peak commuter traffic, moderate crowding."),
    WINTER_STORM("Winter Storm", "Sub-zero temperatures, snow delays on surface routes."),
    STREETCAR_DIVERSION("Streetcar Diversion", "504 King diverted via Queen due to track construction."),
    ELEVATOR_OUTAGE("Elevator Outage", "Union Station South entrance elevators out of service."),
    MAJOR_INCIDENT("Major Incident", "Signal failure at St Clair on Line 1. Delays up to 20 minutes."),
    RECOVERY("Service Recovery", "Clearing backlog, service gradually returning to normal.")
}

data class Station(
    val id: String,
    val name: String,
    val shortName: String,
    val code: String,
    val operators: List<Operator>,
    val modes: List<TransitMode>,
    val lineIds: List<String>,
    val x: Float, // Coordinate X on vector map (0 to 1000)
    val y: Float, // Coordinate Y on vector map (0 to 1000)
    val isAccessible: Boolean = true,
    val entrances: List<String> = emptyList(),
    val exits: List<String> = emptyList(),
    val amenities: List<String> = emptyList(),
    val activeOutage: String? = null,
    val description: String = ""
)

data class TransitLine(
    val id: String,
    val name: String,
    val number: String,
    val colorHex: String,
    val mode: TransitMode,
    val operator: Operator
)

data class Departure(
    val id: String,
    val lineId: String,
    val lineName: String,
    val lineNumber: String,
    val lineColorHex: String,
    val destination: String,
    val minRemaining: Int,
    val status: DepartureStatus,
    val crowding: CrowdingLevel,
    val isLive: Boolean = false,
    val platform: String = "Platform 1"
)

data class ServiceAlert(
    val id: String,
    val lineId: String?,
    val affectedOperator: Operator,
    val title: String,
    val message: String,
    val expectedDelayMin: Int,
    val alternativeAdvice: String,
    val isSimulation: Boolean = true
)

data class StopInfo(
    val stopName: String,
    val timeRemainingMin: Int
)

data class JourneyLeg(
    val mode: TransitMode,
    val operator: Operator,
    val lineId: String?,
    val lineName: String,
    val lineNumber: String?,
    val lineColorHex: String,
    val fromStationName: String,
    val toStationName: String,
    val durationMin: Int,
    val stopsCount: Int,
    val stops: List<StopInfo> = emptyList(),
    val instructions: String,
    val crowding: CrowdingLevel = CrowdingLevel.LOW
)

data class Journey(
    val id: String,
    val fromStationId: String,
    val toStationId: String,
    val totalDurationMin: Int,
    val legs: List<JourneyLeg>,
    val adultFare: Double,
    val routeSummary: String,
    val operatorBreakdown: List<Operator>
)

data class PrestoAccount(
    val cardNumber: String,
    val balance: Double,
    val activeTransferExpiry: Long?, // Epoch ms, null if inactive
    val transferStartedStation: String?,
    val currentMonthPaidTrips: Int,
    val autoLoadAmount: Double = 20.0,
    val autoLoadActive: Boolean = false
) {
    val isFareCapReached: Boolean get() = currentMonthPaidTrips >= 47
}

data class TapTransaction(
    val id: String,
    val timestampStr: String,
    val stationName: String,
    val operator: Operator,
    val fareCharged: Double,
    val isTransfer: Boolean,
    val balanceAfter: Double
)

data class WeatherCondition(
    val type: WeatherType,
    val temperatureCelsius: Int,
    val description: String,
    val walkingSpeedModifier: Float, // 1.0 = normal, 0.7 = slower in heavy snow
    val surfaceDelayFactor: Int, // Minutes of delay for streetcars/buses
    val isSimulation: Boolean = true
)

data class TorontoDestination(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val nearestStationId: String,
    val accessibilityNote: String = "Fully accessible connection"
)
