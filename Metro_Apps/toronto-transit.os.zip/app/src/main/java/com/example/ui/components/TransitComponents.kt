package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.domain.*
import com.example.ui.TransitViewModel
import kotlinx.coroutines.delay

@Composable
fun AppHeader(viewModel: TransitViewModel) {
    val isWinter = viewModel.weather.type == WeatherType.HEAVY_SNOW || viewModel.weather.type == WeatherType.WINTER
    val isStorm = viewModel.weather.type == WeatherType.HEAVY_SNOW
    
    val headerBg = if (isWinter) {
        Brush.verticalGradient(listOf(Color(0xFF0F1E29), Color(0xFF1E1E24)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFDA291C), Color(0xFFB01D12)))
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(headerBg)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "TORONTO",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (isWinter) Color(0xFFC0D5E5) else Color.White.copy(alpha = 0.85f),
                        letterSpacing = 4.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "TRANSIT.OS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                )
            }
            
            // Weather Pill
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.35f))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = when (viewModel.weather.type) {
                        WeatherType.HEAVY_SNOW -> Icons.Default.AcUnit
                        WeatherType.WINTER -> Icons.Default.CloudQueue
                        WeatherType.HEAT -> Icons.Default.WbSunny
                        else -> Icons.Default.WbSunny
                    },
                    contentDescription = "Weather Icon",
                    tint = if (isStorm) Color(0xFF81D4FA) else Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${viewModel.weather.temperatureCelsius}°C",
                    style = MaterialTheme.typography.labelLarge.copy(color = Color.White, fontSize = 13.sp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (viewModel.weather.type == WeatherType.HEAVY_SNOW) "STORM" else "WIN",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (isStorm) Color(0xFF81D4FA) else Color.White.copy(alpha = 0.7f),
                        fontSize = 10.sp
                    )
                )
            }
        }
    }
}

@Composable
fun MainBottomNavigation(currentTab: String, onTabSelected: (String) -> Unit) {
    NavigationBar(
        containerColor = Color(0xFF121214),
        contentColor = Color.White,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        val items = listOf(
            Triple("HOME", Icons.Default.Home, Icons.Outlined.Home),
            Triple("PLAN", Icons.Default.Directions, Icons.Outlined.Directions),
            Triple("MAP", Icons.Default.Map, Icons.Outlined.Map),
            Triple("TAP", Icons.Default.Contactless, Icons.Outlined.Contactless),
            Triple("MORE", Icons.Default.Tune, Icons.Outlined.Tune)
        )

        items.forEach { (tab, filledIcon, outlinedIcon) ->
            val selected = currentTab == tab
            NavigationBarItem(
                selected = selected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = if (selected) filledIcon else outlinedIcon,
                        contentDescription = tab,
                        tint = if (selected) Color(0xFFDA291C) else Color(0xFF8A8D8F)
                    )
                },
                label = {
                    Text(
                        text = tab,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (selected) Color.White else Color(0xFF8A8D8F),
                            fontSize = 10.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = Color(0xFF1E1E24)
                ),
                modifier = Modifier.testTag("nav_tab_$tab")
            )
        }
    }
}

@Composable
fun NetworkStatusStrip(viewModel: TransitViewModel) {
    val systemNormal = viewModel.simulationMode == SimulationMode.NORMAL
    val isWinter = viewModel.simulationMode == SimulationMode.WINTER_STORM
    
    val bgColor = when {
        viewModel.simulationMode == SimulationMode.MAJOR_INCIDENT -> Color(0xFF6B1813)
        isWinter -> Color(0xFF263238)
        systemNormal -> Color(0xFF142416)
        else -> Color(0xFF372D12)
    }
    
    val statusText = when (viewModel.simulationMode) {
        SimulationMode.NORMAL -> "TTC Subway operating on full headway. Surface networks normal."
        SimulationMode.MORNING_RUSH -> "Morning Rush Profile active: increased capacity on lines 1 & 2."
        SimulationMode.EVENING_RUSH -> "Evening Commuter peak loads in transit."
        SimulationMode.WINTER_STORM -> "Winter Storm: delays of up to 12 mins on surface routes."
        SimulationMode.STREETCAR_DIVERSION -> "504 King streetcars diverted via Queen St."
        SimulationMode.ELEVATOR_OUTAGE -> "Union Station NB Elevator Outage. Plan accordingly."
        SimulationMode.MAJOR_INCIDENT -> "LINE 1: Severe signal incident holding trains at St Clair."
        SimulationMode.RECOVERY -> "Service recovering. Clearing subway congestion."
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(bgColor)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = when {
                viewModel.simulationMode == SimulationMode.MAJOR_INCIDENT -> Icons.Default.Dangerous
                systemNormal -> Icons.Default.CheckCircle
                else -> Icons.Default.Warning
            },
            contentDescription = "Alert status icon",
            tint = when {
                viewModel.simulationMode == SimulationMode.MAJOR_INCIDENT -> Color.Red
                systemNormal -> Color.Green
                else -> Color.Yellow
            },
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = statusText,
            style = MaterialTheme.typography.bodySmall.copy(
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun SimulationBadge(mode: SimulationMode) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF26262B))
            .border(1.dp, Color(0xFF404048), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(Color(0xFFFFB300))
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "SIMULATOR: ${mode.label.uppercase()}",
            style = MaterialTheme.typography.labelSmall.copy(
                color = Color(0xFFFFB300),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

// Renders the beautifully stylized vector GTHA schematic
@Composable
fun SubwayVectorMap(
    viewModel: TransitViewModel,
    modifier: Modifier = Modifier,
    isZoomedToStation: Station? = null
) {
    val context = LocalContext.current
    val stations = TransitData.stations
    val lines = TransitData.lines

    // Determine highlighting
    val highlightLineId = viewModel.mapSelectedLineId ?: viewModel.activeJourney?.legs?.firstOrNull()?.lineId
    val highlightStationId = isZoomedToStation?.id ?: viewModel.mapSelectedStationId

    val movingTrainProgress by animateFloatAsState(
        targetValue = (viewModel.trainCountdownSec % 60) / 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(60000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "train_map_motion"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF121214))
            .border(1.dp, Color(0xFF232328))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    // Click mapping for selecting stations on Map
                    // Since it's schematic, we can find the closest node within distance
                }
        ) {
            val width = size.width
            val height = size.height

            // Helper to project relative 1000-scale coordinates onto current canvas size
            fun project(x: Float, y: Float): Offset {
                val paddingX = width * 0.12f
                val paddingY = height * 0.12f
                val scaleX = (width - paddingX * 2) / 1000f
                val scaleY = (height - paddingY * 2) / 1000f
                return Offset(
                    paddingX + x * scaleX,
                    paddingY + y * scaleY
                )
            }

            // Draw line connections (Lines)
            // Line 1: Yellow (Bloor-Yonge -> Wellesley -> Dundas -> Union -> Yorkdale)
            val l1Points = listOf(
                TransitData.getStationById("yorkdale"),
                TransitData.getStationById("bloor_yonge"),
                TransitData.getStationById("wellesley"),
                TransitData.getStationById("dundas"),
                TransitData.getStationById("union")
            ).filterNotNull()

            // Line 2: Green (Kipling -> Bloor-Yonge -> Kennedy)
            val l2Points = listOf(
                TransitData.getStationById("kipling"),
                TransitData.getStationById("bloor_yonge"),
                TransitData.getStationById("kennedy")
            ).filterNotNull()

            // UP Express: Teal (Union -> Pearson)
            val upPoints = listOf(
                TransitData.getStationById("pearson"),
                TransitData.getStationById("union")
            ).filterNotNull()

            // Streetcar 509: Red/Silver (Billy Bishop -> Union)
            val sc509Points = listOf(
                TransitData.getStationById("billy_bishop"),
                TransitData.getStationById("union")
            ).filterNotNull()

            // Streetcar 504: Red/Silver (Kensington -> Distillery)
            val sc504Points = listOf(
                TransitData.getStationById("kensington_market"),
                TransitData.getStationById("distillery")
            ).filterNotNull()

            fun drawSchematicLine(points: List<Station>, color: Color, strokeW: Float, isHighlighted: Boolean) {
                val alpha = if (highlightLineId == null || isHighlighted) 1.0f else 0.15f
                for (i in 0 until points.size - 1) {
                    val p1 = project(points[i].x, points[i].y)
                    val p2 = project(points[i + 1].x, points[i + 1].y)
                    drawLine(
                        color = color.copy(alpha = alpha),
                        start = p1,
                        end = p2,
                        strokeWidth = strokeW,
                        cap = StrokeCap.Round
                    )
                }
            }

            // Draw Paths
            drawSchematicLine(l1Points, Color(0xFFFFC72C), 10f, highlightLineId == "l1" || highlightLineId == null)
            drawSchematicLine(l2Points, Color(0xFF00A550), 10f, highlightLineId == "l2" || highlightLineId == null)
            drawSchematicLine(upPoints, Color(0xFF006F62), 6f, highlightLineId == "up_exp" || highlightLineId == null)
            drawSchematicLine(sc509Points, Color(0xFFDA291C), 4f, highlightLineId == "509" || highlightLineId == null)
            drawSchematicLine(sc504Points, Color(0xFFDA291C), 4f, highlightLineId == "504" || highlightLineId == null)

            // Draw Station Nodes
            for (station in stations) {
                val center = project(station.x, station.y)
                val isNodeSelected = station.id == highlightStationId
                val isDimmed = highlightStationId != null && !isNodeSelected
                
                val nodeAlpha = if (isDimmed) 0.25f else 1.0f
                val nodeRadius = if (isNodeSelected) 12.dp.toPx() else 7.dp.toPx()
                
                // Outer Ring for Interchange or Selected
                if (station.lineIds.size > 1 || isNodeSelected) {
                    drawCircle(
                        color = if (isNodeSelected) Color(0xFFDA291C) else Color.White.copy(alpha = nodeAlpha),
                        radius = nodeRadius + 4.dp.toPx(),
                        center = center,
                        style = Stroke(width = 2.dp.toPx())
                    )
                }

                // Inner core
                drawCircle(
                    color = if (isNodeSelected) Color.White else Color(0xFF1E1E24).copy(alpha = nodeAlpha),
                    radius = nodeRadius,
                    center = center
                )
                drawCircle(
                    color = if (isNodeSelected) Color(0xFFDA291C) else Color.White.copy(alpha = nodeAlpha),
                    radius = nodeRadius - 3.dp.toPx(),
                    center = center
                )
            }

            // Draw small moving Train indicators on active highlighted lines
            // Let's animate a train between Yorkdale & Bloor-Yonge on Line 1
            if (l1Points.size >= 2) {
                val tStart = project(l1Points[0].x, l1Points[0].y)
                val tEnd = project(l1Points[1].x, l1Points[1].y)
                val trainPos = Offset(
                    tStart.x + (tEnd.x - tStart.x) * movingTrainProgress,
                    tStart.y + (tEnd.y - tStart.y) * movingTrainProgress
                )
                
                drawCircle(
                    color = Color.Black,
                    radius = 8.dp.toPx(),
                    center = trainPos
                )
                drawCircle(
                    color = Color(0xFFFFC72C),
                    radius = 5.dp.toPx(),
                    center = trainPos
                )
                drawCircle(
                    color = Color.White,
                    radius = 2.dp.toPx(),
                    center = trainPos
                )
            }
        }
        
        // Static Map labels overlays
        stations.forEach { station ->
            val isSelected = station.id == highlightStationId
            if (isSelected || station.lineIds.size > 1 || station.id == "union" || station.id == "pearson") {
                // Approximate overlays
                Box(
                    modifier = Modifier
                        .offset(
                            x = (station.x * 0.72f).dp,
                            y = (station.y * 0.72f - 30).dp
                        )
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color.Black.copy(alpha = 0.85f))
                        .border(
                            1.dp,
                            if (isSelected) Color(0xFFDA291C) else Color.DarkGray,
                            RoundedCornerShape(2.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = station.shortName.uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// Signature view of the flagship UNION ST station
@Composable
fun UnionStationSignatureModel(viewModel: TransitViewModel) {
    var activeSubSection by remember { mutableStateOf("TTC") } // TTC, GO, UP, VIA
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
        border = BorderStroke(1.dp, Color(0xFF33333C)),
        shape = RoundedCornerShape(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "UNION STATION",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "METROPOLITAN INFRASTRUCTURE PROFILE",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFDA291C))
                    )
                }
                Icon(
                    imageVector = Icons.Default.Hub,
                    contentDescription = "Hub",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(14.dp))
            
            Text(
                text = "Integrating Canada's busiest rapid rail networks, subways, and streetcars into a single physical architectural grid on Front Street.",
                style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFFC0C3C6))
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Grid selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.Black)
                    .padding(2.dp)
            ) {
                listOf("TTC", "GO", "UP EXPRESS", "VIA RAIL").forEach { sect ->
                    val selected = activeSubSection == sect
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (selected) Color(0xFFDA291C) else Color.Transparent)
                            .clickable { activeSubSection = sect }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = sect,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (selected) Color.White else Color(0xFF8A8D8F),
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Sub details depending on section
            when (activeSubSection) {
                "TTC" -> {
                    Text(
                        text = "TTC SUBWAY & STREETCARS",
                        style = MaterialTheme.typography.labelLarge.copy(color = Color.White)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Platform 1 (Northbound to Finch via Yonge)\n" +
                               "• Platform 2 (Northbound to VMC via University)\n" +
                               "• 509 Harbourfront streetcar platform loop (South Corridor)",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFC0C3C6), lineHeight = 18.sp)
                    )
                }
                "GO" -> {
                    Text(
                        text = "GO TRANSIT REGIONAL RAIL & BUS",
                        style = MaterialTheme.typography.labelLarge.copy(color = Color(0xFF00853E))
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Platforms 3-12 (Lakeshore East/West rapid tracks)\n" +
                               "• Platforms 13-21 (Kitchener, Barrie, Stouffville commuter lines)\n" +
                               "• Union Station Bus Terminal (East Wing direct PATH link)",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFC0C3C6), lineHeight = 18.sp)
                    )
                }
                "UP EXPRESS" -> {
                    Text(
                        text = "UP EXPRESS PEARSON AIRPORT LINK",
                        style = MaterialTheme.typography.labelLarge.copy(color = Color(0xFF006F62))
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Dedicated West Wing Lounge Platform\n" +
                               "• Automated PRESTO ticket gates with contactless card tap-on\n" +
                               "• 25 minutes non-stop service directly into Terminal 1",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFC0C3C6), lineHeight = 18.sp)
                    )
                }
                "VIA RAIL" -> {
                    Text(
                        text = "VIA RAIL NATIONAL CORRIDOR SERVICES",
                        style = MaterialTheme.typography.labelLarge.copy(color = Color(0xFFE56A21))
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Main Great Hall Ticketing and departure lounge\n" +
                               "• Inter-provincial rapid rail serving Ottawa, Montreal, and Windsor\n" +
                               "• Direct underground PATH link to Royal York Hotel",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFC0C3C6), lineHeight = 18.sp)
                    )
                }
            }
        }
    }
}

// Live departures scoreboard component
@Composable
fun DeparturesBoard(
    stationName: String,
    departures: List<Departure>,
    onRefresh: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF121214)),
        border = BorderStroke(1.dp, Color(0xFF26262B)),
        shape = RoundedCornerShape(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = stationName.uppercase(),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "REAL-TIME ARRIVAL BOARD",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFFDA291C),
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
                
                IconButton(onClick = onRefresh) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh board",
                        tint = Color.White
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(14.dp))
            
            // Header table
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E1E24))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text("LINE", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray), modifier = Modifier.width(55.dp))
                Text("DESTINATION", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray), modifier = Modifier.weight(1f))
                Text("STATUS", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray), modifier = Modifier.width(85.dp))
                Text("ARR", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray), modifier = Modifier.width(45.dp), textAlign = TextAlign.End)
            }
            
            if (departures.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "NO ACTIVE DEPARTURES REGISTERED",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.DarkGray)
                    )
                }
            } else {
                departures.forEach { dep ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(0.5.dp, Color(0xFF1E1E24))
                            .padding(horizontal = 8.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Line tag colored badge
                        Box(
                            modifier = Modifier
                                .width(45.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color(android.graphics.Color.parseColor(dep.lineColorHex)))
                                .padding(vertical = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = dep.lineNumber,
                                color = if (dep.lineId == "l1") Color.Black else Color.White,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(10.dp))
                        
                        // Destination
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = dep.destination,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.People,
                                    contentDescription = "crowding",
                                    tint = Color.Gray,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${dep.crowding.label} Crowding",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color.Gray,
                                        fontSize = 9.sp
                                    )
                                )
                            }
                        }
                        
                        // Status
                        val isBoarding = dep.status == DepartureStatus.BOARDING
                        val isDelayed = dep.status == DepartureStatus.DELAYED
                        
                        Text(
                            text = dep.status.label.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = when {
                                    isBoarding -> Color(0xFF00A550)
                                    isDelayed -> Color(0xFFDA291C)
                                    else -> Color.White.copy(alpha = 0.65f)
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.width(85.dp)
                        )
                        
                        // Arrival Countdown
                        Text(
                            text = if (isBoarding) "NOW" else "${dep.minRemaining}m",
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = if (isBoarding) Color(0xFF00A550) else Color(0xFFFFC72C),
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            ),
                            modifier = Modifier.width(45.dp),
                            textAlign = TextAlign.End
                        )
                    }
                }
            }
        }
    }
}

// Gorgeous NFC Tap Ready to Tap Animation Screen
@Composable
fun NFCReadyToTapPanel(viewModel: TransitViewModel) {
    val infiniteTransition = rememberInfiniteTransition(label = "nfc_ripple")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "nfc_scale"
    )
    val alpha by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "nfc_alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1E1E24))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "READY TO TAP",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 1.sp
            )
        )
        Text(
            text = "Hold your device near the reader at ${viewModel.selectedStation?.name ?: "Union Station"}",
            style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray, textAlign = TextAlign.Center)
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Circular animated NFC concentric rings
        Box(
            modifier = Modifier.size(160.dp),
            contentAlignment = Alignment.Center
        ) {
            // Ripple 1
            if (viewModel.nfcState == "READY_TO_TAP") {
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .border(
                            2.dp,
                            Color(0xFFDA291C).copy(alpha = alpha),
                            CircleShape
                        )
                        .padding(10.dp)
                )
            }
            
            // Core
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(Color.Black)
                    .border(2.dp, Color(0xFFDA291C), CircleShape)
                    .clickable { viewModel.triggerNFCTap() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Contactless,
                    contentDescription = "Contactless reader icon",
                    tint = Color(0xFFDA291C),
                    modifier = Modifier.size(42.dp)
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "TAP CORE SENSOR TO EMULATE",
            style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontSize = 9.sp)
        )
    }
}

// Monthly fare capping display
@Composable
fun MonthlyFareCapProgress(viewModel: TransitViewModel) {
    val account = viewModel.prestoAccount
    val targetTrips = 47
    val progress = (account.currentMonthPaidTrips.toFloat() / targetTrips).coerceIn(0f, 1f)
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24)),
        border = BorderStroke(1.dp, Color(0xFF33333C)),
        shape = RoundedCornerShape(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MONTHLY FARE CAP",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "SEPTEMBER CALENDAR CAP",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                    )
                }
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (account.isFareCapReached) Color(0xFF00A550) else Color(0xFFDA291C))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (account.isFareCapReached) "CAP MET" else "ACTIVE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Progress Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${account.currentMonthPaidTrips}",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                Text(
                    text = " / $targetTrips paid trips",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray),
                    modifier = Modifier.weight(1f)
                )
                
                val remaining = (targetTrips - account.currentMonthPaidTrips).coerceAtLeast(0)
                Text(
                    text = if (account.isFareCapReached) "Free Rides Active" else "$remaining remaining",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (account.isFareCapReached) Color(0xFF00A550) else Color.White,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (account.isFareCapReached) Color(0xFF00A550) else Color(0xFFDA291C),
                trackColor = Color.Black
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "Under the Sept 1 2026 TTC Cap, after 47 single-fare paid journeys in a calendar month, all subsequent eligible TTC journeys are completely free of charge ($0.00).",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.Gray,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Demo adjust triggers
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.setPrestoPaidTrips(46) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, Color.Gray),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text("SET TO 46 TRIPS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                
                OutlinedButton(
                    onClick = { viewModel.setPrestoPaidTrips(47) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, Color.Gray),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text("SET TO 47 TRIPS (MET)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
