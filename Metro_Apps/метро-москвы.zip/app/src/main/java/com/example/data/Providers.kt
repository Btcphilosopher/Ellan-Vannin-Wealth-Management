package com.example.data

import com.example.storage.TicketEntity
import com.example.storage.TroikaCardEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

interface PaymentResult {
    val success: Boolean
    val transactionId: String
    val errorMessage: String?
}

data class DemoPaymentResult(
    override val success: Boolean,
    override val transactionId: String,
    override val errorMessage: String? = null
) : PaymentResult

interface PaymentProvider {
    suspend fun processPayment(amountRubles: Int, details: String): PaymentResult
}

class DemoPaymentProvider : PaymentProvider {
    override suspend fun processPayment(amountRubles: Int, details: String): PaymentResult {
        // Simulate immediate success for demo
        val txId = "TX-${UUID.randomUUID().toString().take(8).uppercase()}"
        return DemoPaymentResult(success = true, transactionId = txId)
    }
}

interface TroikaProvider {
    suspend fun getBalance(cardId: String): Int
    suspend fun topUp(cardId: String, amountRubles: Int, paymentProvider: PaymentProvider): PaymentResult
    suspend fun createNewCard(name: String): TroikaCardEntity
}

class DemoTroikaProvider(private val dao: com.example.storage.MetroDao) : TroikaProvider {
    override suspend fun getBalance(cardId: String): Int {
        val card = dao.getTroikaCard(cardId)
        return card?.balance ?: 0
    }

    override suspend fun topUp(cardId: String, amountRubles: Int, paymentProvider: PaymentProvider): PaymentResult {
        val result = paymentProvider.processPayment(amountRubles, "Пополнение Тройки $cardId")
        if (result.success) {
            val currentCard = dao.getTroikaCard(cardId)
            val currentBalance = currentCard?.balance ?: 0
            val updatedCard = TroikaCardEntity(
                cardId = cardId,
                balance = currentBalance + amountRubles,
                cardName = currentCard?.cardName ?: "Моя Тройка"
            )
            dao.insertOrUpdateTroikaCard(updatedCard)
        }
        return result
    }

    override suspend fun createNewCard(name: String): TroikaCardEntity {
        val newId = "000${(10000000..99999999).random()}"
        val newCard = TroikaCardEntity(
            cardId = newId,
            balance = 1245, // default requested in Prompt Section 20
            cardName = name
        )
        dao.insertOrUpdateTroikaCard(newCard)
        return newCard
    }
}
