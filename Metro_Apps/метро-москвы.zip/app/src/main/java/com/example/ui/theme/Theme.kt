package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MetroRedBrand,
    secondary = MetroRedDarkAccent,
    background = MetroCharcoalBg,
    surface = MetroCardDark,
    outline = MetroBorderDark,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = MetroTextDarkPrimary,
    onSurface = MetroTextDarkPrimary,
    onSurfaceVariant = MetroTextDarkSecondary
)

private val LightColorScheme = lightColorScheme(
    primary = MetroRedBrand,
    secondary = MetroRedDarkAccent,
    background = MetroCreamBg,
    surface = MetroCardLight,
    outline = MetroBorderLight,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = MetroTextLightPrimary,
    onSurface = MetroTextLightPrimary,
    onSurfaceVariant = MetroTextLightSecondary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
