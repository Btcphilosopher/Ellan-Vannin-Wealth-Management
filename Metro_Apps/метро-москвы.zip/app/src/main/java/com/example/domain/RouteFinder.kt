package com.example.domain

import com.example.data.Interchange
import com.example.data.MetroLine
import com.example.data.MetroStation
import com.example.data.MetroRepository
import java.util.PriorityQueue

sealed class RouteSegment {
    data class Ride(val station: MetroStation, val line: MetroLine) : RouteSegment()
    data class Transfer(
        val fromStation: MetroStation,
        val toStation: MetroStation,
        val fromLine: MetroLine,
        val toLine: MetroLine,
        val timeMinutes: Int
    ) : RouteSegment()
}

data class Route(
    val segments: List<RouteSegment>,
    val totalTimeMinutes: Int,
    val totalStationsCount: Int,
    val transferCount: Int,
    val typeName: String // "Самый быстрый", "Меньше пересадок", "Меньше пешком"
)

class RouteFinder(private val repository: MetroRepository) {

    // Graph node: holds station ID and line ID
    data class Node(val stationId: String, val lineId: String)

    data class Edge(val target: Node, val weightMinutes: Int, val isTransfer: Boolean)

    // Build the graph dynamically from repository data
    private fun buildGraph(transferPenalty: Int = 0): Map<Node, List<Edge>> {
        val adj = mutableMapOf<Node, MutableList<Edge>>()

        // Initialize adjacency lists for all (station, line) pairs
        for (station in repository.stations) {
            for (lineId in station.lines) {
                adj[Node(station.id, lineId)] = mutableListOf()
            }
        }

        // 1. Edges between consecutive stations on the same line
        for (line in repository.lines) {
            for (i in 0 until line.stations.size - 1) {
                val s1Id = line.stations[i]
                val s2Id = line.stations[i + 1]

                val n1 = Node(s1Id, line.id)
                val n2 = Node(s2Id, line.id)

                // Only add edges if nodes exist in our station map
                if (adj.containsKey(n1) && adj.containsKey(n2)) {
                    // Say typical travel is 3 minutes
                    adj[n1]?.add(Edge(n2, 3, false))
                    adj[n2]?.add(Edge(n1, 3, false))
                }
            }
        }

        // 2. Add interchanges (transfers) from repository
        for (interchange in repository.interchanges) {
            val fromStation = repository.getStationById(interchange.fromStation) ?: continue
            val toStation = repository.getStationById(interchange.toStation) ?: continue

            // For each line of fromStation, connect to each line of toStation
            for (fromLineId in fromStation.lines) {
                for (toLineId in toStation.lines) {
                    // It's a transfer if they are different lines, or different stations on the same line
                    if (fromLineId != toLineId || fromStation.id != toStation.id) {
                        val nFrom = Node(fromStation.id, fromLineId)
                        val nTo = Node(toStation.id, toLineId)
                        if (adj.containsKey(nFrom) && adj.containsKey(nTo)) {
                            // Weight consists of actual walking time + transfer penalty (useful for "fewer transfers" preference)
                            val finalWeight = interchange.timeMinutes + transferPenalty
                            adj[nFrom]?.add(Edge(nTo, finalWeight, true))
                        }
                    }
                }
            }
        }

        // 3. Add same-station transfers (if a station is on multiple lines but not in interchanges explicitly, create default 3min transfer)
        for (station in repository.stations) {
            if (station.lines.size > 1) {
                for (i in station.lines.indices) {
                    for (j in i + 1 until station.lines.size) {
                        val lineA = station.lines[i]
                        val lineB = station.lines[j]
                        val nA = Node(station.id, lineA)
                        val nB = Node(station.id, lineB)

                        // Check if an interchange isn't already added
                        val existsAToB = adj[nA]?.any { it.target == nB } ?: false
                        if (!existsAToB) {
                            val weight = 3 + transferPenalty
                            adj[nA]?.add(Edge(nB, weight, true))
                            adj[nB]?.add(Edge(nA, weight, true))
                        }
                    }
                }
            }
        }

        return adj
    }

    /**
     * Finds the optimal route between origin and destination stations.
     * Supports preferences:
     * - "Самый быстрый" (transferPenalty = 0)
     * - "Меньше пересадок" (transferPenalty = 15 minutes)
     * - "Меньше пешком" (transferPenalty = 30 minutes, prioritizing long rides over walking transfers)
     */
    fun findRoute(
        originId: String,
        destinationId: String,
        preference: String = "Самый быстрый"
    ): Route? {
        if (originId == destinationId) {
            val station = repository.getStationById(originId) ?: return null
            val line = repository.getLineForStation(station) ?: return null
            return Route(
                segments = listOf(RouteSegment.Ride(station, line)),
                totalTimeMinutes = 0,
                totalStationsCount = 1,
                transferCount = 0,
                typeName = preference
            )
        }

        val penalty = when (preference) {
            "Меньше пересадок" -> 15
            "Меньше пешком" -> 25
            else -> 0
        }

        val graph = buildGraph(penalty)

        val originStation = repository.getStationById(originId) ?: return null
        val destStation = repository.getStationById(destinationId) ?: return null

        // Dijkstra's algorithm state
        val dist = mutableMapOf<Node, Int>()
        val parent = mutableMapOf<Node, Node>()
        val parentEdge = mutableMapOf<Node, Edge>()

        // Min-priority queue based on distance (time)
        val pq = PriorityQueue<Pair<Node, Int>>(compareBy { it.second })

        // Initialize start nodes (origin station might have multiple lines)
        for (lineId in originStation.lines) {
            val startNode = Node(originId, lineId)
            dist[startNode] = 0
            pq.add(Pair(startNode, 0))
        }

        var foundEndNode: Node? = null
        val destNodes = destStation.lines.map { Node(destinationId, it) }.toSet()

        while (pq.isNotEmpty()) {
            val (u, d) = pq.poll()

            // If we already found a shorter path to u, skip
            if (d > (dist[u] ?: Int.MAX_VALUE)) continue

            if (destNodes.contains(u)) {
                foundEndNode = u
                break
            }

            val edges = graph[u] ?: continue
            for (edge in edges) {
                val v = edge.target
                val newDist = d + edge.weightMinutes

                if (newDist < (dist[v] ?: Int.MAX_VALUE)) {
                    dist[v] = newDist
                    parent[v] = u
                    parentEdge[v] = edge
                    pq.add(Pair(v, newDist))
                }
            }
        }

        if (foundEndNode == null) return null

        // Reconstruct path
        val pathNodes = mutableListOf<Node>()
        var curr: Node? = foundEndNode
        while (curr != null) {
            pathNodes.add(curr)
            curr = parent[curr]
        }
        pathNodes.reverse()

        // Build segment list
        val segments = mutableListOf<RouteSegment>()
        var stationCount = 0
        var transferCount = 0
        var actualTimeMinutes = 0

        for (i in pathNodes.indices) {
            val currNode = pathNodes[i]
            val station = repository.getStationById(currNode.stationId) ?: continue
            val line = repository.getLineById(currNode.lineId) ?: continue

            if (i > 0) {
                val prevNode = pathNodes[i - 1]
                val edge = parentEdge[currNode]!!
                
                if (edge.isTransfer) {
                    val prevStation = repository.getStationById(prevNode.stationId)!!
                    val prevLine = repository.getLineById(prevNode.lineId)!!
                    
                    // Deduct penalty from weight for displaying actual walking time
                    val actualTransferTime = edge.weightMinutes - penalty
                    segments.add(
                        RouteSegment.Transfer(
                            fromStation = prevStation,
                            toStation = station,
                            fromLine = prevLine,
                            toLine = line,
                            timeMinutes = actualTransferTime.coerceAtLeast(1)
                        )
                    )
                    transferCount++
                    actualTimeMinutes += actualTransferTime.coerceAtLeast(1)
                } else {
                    segments.add(RouteSegment.Ride(station, line))
                    stationCount++
                    actualTimeMinutes += 3 // travel time
                }
            } else {
                segments.add(RouteSegment.Ride(station, line))
                stationCount++
            }
        }

        return Route(
            segments = segments,
            totalTimeMinutes = actualTimeMinutes,
            totalStationsCount = stationCount,
            transferCount = transferCount,
            typeName = preference
        )
    }

    /**
     * Suggests all 3 travel choices for origin -> destination
     */
    fun findRouteOptions(originId: String, destinationId: String): List<Route> {
        val options = mutableListOf<Route>()
        
        findRoute(originId, destinationId, "Самый быстрый")?.let { options.add(it) }
        findRoute(originId, destinationId, "Меньше пересадок")?.let {
            // Avoid duplicate if identical
            if (options.none { opt -> opt.totalTimeMinutes == it.totalTimeMinutes && opt.transferCount == it.transferCount }) {
                options.add(it)
            }
        }
        findRoute(originId, destinationId, "Меньше пешком")?.let {
            if (options.none { opt -> opt.totalTimeMinutes == it.totalTimeMinutes && opt.transferCount == it.transferCount }) {
                options.add(it)
            }
        }

        return options
    }
}
