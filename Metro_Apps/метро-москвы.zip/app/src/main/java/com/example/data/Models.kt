package com.example.data

data class StationExit(
    val id: Int,
    val description: String
)

data class MetroLine(
    val id: String,
    val name: String,
    val shortName: String,
    val color: String,
    val stations: List<String>
)

data class MetroStation(
    val id: String,
    val name: String,
    val lines: List<String>,
    val interchange: Boolean,
    val exits: List<StationExit>,
    val facilities: List<String>,
    val architectureStyle: String = "",
    val architect: String = "",
    val yearOpened: Int = 1935,
    val description: String = ""
)

data class Interchange(
    val fromStation: String,
    val toStation: String,
    val timeMinutes: Int
)

data class MccStation(
    val id: String,
    val name: String,
    val line: String,
    val interchangeTo: String
)

data class McdRoute(
    val id: String,
    val name: String,
    val line: String,
    val stations: List<String>
)

data class Airport(
    val id: String,
    val name: String,
    val aeroexpressFrom: String,
    val aeroexpressTime: String
)

data class RailwayStation(
    val id: String,
    val name: String,
    val connectedStationId: String,
    val directions: List<String>
)
