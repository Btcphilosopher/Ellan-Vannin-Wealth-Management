package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MetroLine
import com.example.data.MetroStation
import com.example.domain.RouteSegment
import com.example.ui.MetroViewModel
import com.example.ui.SimulationStatus
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun MapScreen(viewModel: MetroViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val stations = viewModel.repository.stations
    val lines = viewModel.repository.lines
    val activeRoute by viewModel.selectedRoute.collectAsState()
    val simState by viewModel.simulationState.collectAsState()

    // Interactive panning/zooming states
    var scale by remember { mutableStateOf(1.0f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    // Selected items on map
    var tappedStation by remember { mutableStateOf<MetroStation?>(null) }
    val textMeasurer = rememberTextMeasurer()

    // Let's define the schematic coordinates of the stations (600x600 grid)
    val coords = remember {
        mapOf(
            // Line 1 (Red)
            "s1_1" to Offset(470f, 60f),
            "s1_2" to Offset(430f, 120f),
            "s1_3" to Offset(390f, 185f),
            "s1_4" to Offset(340f, 235f),
            "s1_5" to Offset(290f, 275f),
            "s1_6" to Offset(250f, 310f),
            "s1_7" to Offset(210f, 345f),
            "s1_8" to Offset(170f, 385f),

            // Line 2 (Green)
            "s2_1" to Offset(170f, 60f),
            "s2_2" to Offset(210f, 120f),
            "s2_3" to Offset(250f, 185f),
            "s2_4" to Offset(270f, 235f),
            "s2_5" to Offset(290f, 275f), // Tverская sits right near Lubyanka/Okhotny
            "s2_6" to Offset(310f, 310f),
            "s2_7" to Offset(350f, 385f),

            // Line 3 (Dark Blue)
            "s3_1" to Offset(60f, 350f),
            "s3_2" to Offset(120f, 350f),
            "s3_3" to Offset(180f, 350f),
            "s3_4" to Offset(240f, 350f),
            "s3_5" to Offset(300f, 350f),
            "s3_6" to Offset(360f, 350f),

            // Line 5 (Ring - arranged circularly centered at 300, 300 with radius 130)
            // s5_4 (Komsomolskaya) -> 300 + 130 * cos(-45) = 392, 300 + 130 * sin(-45) = 208
            "s5_4" to Offset(392f, 208f),
            // s5_5 (Kurskaya) -> 300 + 130 * cos(15) = 425, 300 + 130 * sin(15) = 333
            "s5_5" to Offset(425f, 333f),
            // s5_6 (Park Kultury) -> 300 + 130 * cos(75) = 333, 300 + 130 * sin(75) = 425
            "s5_6" to Offset(333f, 425f),
            // s5_1 (Kievskaya) -> 300 + 130 * cos(165) = 174, 300 + 130 * sin(165) = 333
            "s5_1" to Offset(174f, 333f),
            // s5_2 (Belorusskaya) -> 300 + 130 * cos(225) = 208, 300 + 130 * sin(225) = 208
            "s5_2" to Offset(208f, 208f),
            // s5_3 (Novoslobodskaya) -> 300 + 130 * cos(285) = 333, 300 + 130 * sin(285) = 174
            "s5_3" to Offset(333f, 174f),

            // Line 6 (Orange)
            "s6_1" to Offset(300f, 50f),
            "s6_2" to Offset(300f, 110f),
            "s6_3" to Offset(300f, 170f),
            "s6_4" to Offset(300f, 220f),
            "s6_5" to Offset(330f, 330f),
            "s6_6" to Offset(210f, 430f),

            // Line 7 (Purple)
            "s7_1" to Offset(220f, 250f),
            "s7_2" to Offset(260f, 280f),
            "s7_3" to Offset(330f, 330f), // cross platform s6_5
            "s7_4" to Offset(390f, 390f),
            "s7_5" to Offset(460f, 460f),

            // Line 17 (Graphite)
            "s17_1" to Offset(80f, 250f),
            "s17_2" to Offset(120f, 275f),
            "s17_3" to Offset(160f, 300f)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("map_screen_root")
    ) {
        // Schematic rendering Canvas
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.5f, 3.5f)
                        offsetX += pan.x
                        offsetY += pan.y
                    }
                }
                .pointerInput(Unit) {
                    // Tap selection algorithm
                    detectTransformGestures { centroid, _, _, _ ->
                        // Convert touch screen centroid to raw map coordinate
                        val mapX = (centroid.x - offsetX) / scale
                        val mapY = (centroid.y - offsetY) / scale
                        val tapPos = Offset(mapX, mapY)

                        var closestStation: MetroStation? = null
                        var minDist = Float.MAX_VALUE

                        for ((id, pos) in coords) {
                            val dist = sqrt((pos.x - tapPos.x) * (pos.x - tapPos.x) + (pos.y - tapPos.y) * (pos.y - tapPos.y))
                            if (dist < minDist) {
                                minDist = dist
                                closestStation = stations.find { it.id == id }
                            }
                        }

                        if (minDist < 30f / scale) {
                            tappedStation = closestStation
                        }
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Apply zoom and panning translations
                drawContext.canvas.save()
                drawContext.canvas.translate(offsetX, offsetY)
                drawContext.canvas.scale(scale, scale)

                // 1. Draw connections / lines
                for (line in lines) {
                    val lineColor = Color(android.graphics.Color.parseColor(line.color))
                    
                    // Specific ring path rendering
                    if (line.id == "5") {
                        // Drawing ring line as closed circle around center (300, 300)
                        drawCircle(
                            color = lineColor,
                            radius = 130f,
                            center = Offset(300f, 300f),
                            style = Stroke(width = 6f)
                        )
                    } else {
                        // Draw radial straight segment sections
                        for (i in 0 until line.stations.size - 1) {
                            val p1 = coords[line.stations[i]]
                            val p2 = coords[line.stations[i + 1]]
                            if (p1 != null && p2 != null) {
                                drawLine(
                                    color = lineColor,
                                    start = p1,
                                    end = p2,
                                    strokeWidth = 6f,
                                    cap = StrokeCap.Round
                                )
                            }
                        }
                    }
                }

                // 2. Draw interchange bridges
                for (inter in viewModel.repository.interchanges) {
                    val p1 = coords[inter.fromStation]
                    val p2 = coords[inter.toStation]
                    if (p1 != null && p2 != null && p1 != p2) {
                        // Small white dash-line between transfer stations
                        drawLine(
                            color = Color(0xFF6A7074),
                            start = p1,
                            end = p2,
                            strokeWidth = 3f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f))
                        )
                    }
                }

                // 3. Highlight calculated active route
                activeRoute?.let { route ->
                    for (i in 0 until route.segments.size - 1) {
                        val s1 = route.segments[i]
                        val s2 = route.segments[i + 1]
                        
                        val p1 = when(s1) {
                            is RouteSegment.Ride -> coords[s1.station.id]
                            is RouteSegment.Transfer -> coords[s1.fromStation.id]
                        }
                        val p2 = when(s2) {
                            is RouteSegment.Ride -> coords[s2.station.id]
                            is RouteSegment.Transfer -> coords[s2.toStation.id]
                        }

                        if (p1 != null && p2 != null) {
                            // Bright glowing red line for active route
                            drawLine(
                                color = Color(0xFFEF1E25),
                                start = p1,
                                end = p2,
                                strokeWidth = 10f,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }

                // 4. Draw Stations and text plates
                for (station in stations) {
                    val pos = coords[station.id] ?: continue
                    val mainLineId = station.lines.firstOrNull() ?: "1"
                    val line = lines.find { it.id == mainLineId }
                    val stationColor = if (line != null) Color(android.graphics.Color.parseColor(line.color)) else Color.Red

                    // Highlight selected station
                    val isSelected = tappedStation?.id == station.id
                    if (isSelected) {
                        drawCircle(
                            color = Color(0xFFEF1E25),
                            radius = 12f,
                            center = pos
                        )
                    }

                    // Circle backdrop
                    drawCircle(
                        color = if (station.interchange) Color.White else Color.Black,
                        radius = 8f,
                        center = pos
                    )
                    drawCircle(
                        color = if (station.interchange) Color.Black else stationColor,
                        radius = 6f,
                        center = pos
                    )

                    // Draw station name plate (Russian only)
                    if (scale > 0.8f) {
                        val textStyle = TextStyle(
                            color = if (isSelected) Color(0xFFE31E24) else Color(0xFF1D2022),
                            fontSize = 8.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        
                        // Slightly shift text plate around node
                        val textOffset = when {
                            pos.x < 250f -> Offset(pos.x - 45f, pos.y - 12f)
                            pos.x > 350f -> Offset(pos.x + 10f, pos.y - 12f)
                            else -> Offset(pos.x - 20f, pos.y + 10f)
                        }

                        drawText(
                            textMeasurer = textMeasurer,
                            text = station.name,
                            topLeft = textOffset,
                            style = textStyle
                        )
                    }
                }

                // 5. Draw simulation dot if active
                if (simState.status != SimulationStatus.INACTIVE && simState.currentStation != null) {
                    val currPos = coords[simState.currentStation!!.id]
                    if (currPos != null) {
                        val nextPos = simState.nextStation?.id?.let { coords[it] }
                        val activePos = if (nextPos != null && simState.status == SimulationStatus.TRAVELING) {
                            // Interpolate position based on progress
                            Offset(
                                x = currPos.x + (nextPos.x - currPos.x) * simState.progress,
                                y = currPos.y + (nextPos.y - currPos.y) * simState.progress
                            )
                        } else {
                            currPos
                        }

                        // Drawing animated pulse ring
                        drawCircle(
                            color = Color(0xFFE31E24).copy(alpha = 0.4f),
                            radius = 18f,
                            center = activePos
                        )
                        drawCircle(
                            color = Color(0xFFE31E24),
                            radius = 7f,
                            center = activePos
                        )
                    }
                }

                drawContext.canvas.restore()
            }
        }

        // Zoom Overlay Buttons
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = { scale = (scale + 0.25f).coerceAtMost(3.5f) },
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Приблизить",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
            IconButton(
                onClick = { scale = (scale - 0.25f).coerceAtLeast(0.5f) },
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Remove,
                    contentDescription = "Отдалить",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Overlay instructions
        Text(
            text = "СХЕМА МОСКОВСКОГО ТРАНСПОРТА\nМасштабируйте и перемещайте пальцами",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp)
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )

        // Tapped Station Bottom Card
        tappedStation?.let { station ->
            val mainLineId = station.lines.firstOrNull() ?: "1"
            val line = lines.find { it.id == mainLineId }
            val lineColor = if (line != null) Color(android.graphics.Color.parseColor(line.color)) else Color.Red

            Card(
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 16.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(lineColor, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = line?.name?.uppercase() ?: "",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = lineColor
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = station.name.uppercase(),
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Close button
                        IconButton(onClick = { tappedStation = null }) {
                            Text(
                                text = "✕",
                                style = TextStyle(
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = station.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                viewModel.originStation.value = station
                                viewModel.currentTab.value = "ГЛАВНАЯ"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onBackground),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("ОТКУДА", style = MaterialTheme.typography.labelLarge)
                        }

                        Button(
                            onClick = {
                                viewModel.destinationStation.value = station
                                viewModel.currentTab.value = "ГЛАВНАЯ"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("КУДА", style = MaterialTheme.typography.labelLarge)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(
                        onClick = {
                            viewModel.selectedStationForDetail.value = station
                            viewModel.currentTab.value = "ГЛАВНАЯ" // triggers selection in master ui
                        },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text("ПОДРОБНЕЕ О СТАНЦИИ ➔", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}
