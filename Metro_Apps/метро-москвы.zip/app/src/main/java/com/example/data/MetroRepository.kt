package com.example.data

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

class MetroRepository(private val context: Context) {

    private val TAG = "MetroRepository"

    var lines: List<MetroLine> = emptyList()
        private set

    var stations: List<MetroStation> = emptyList()
        private set

    var interchanges: List<Interchange> = emptyList()
        private set

    var mccStations: List<MccStation> = emptyList()
        private set

    var mcdRoutes: List<McdRoute> = emptyList()
        private set

    var airports: List<Airport> = emptyList()
        private set

    var railwayStations: List<RailwayStation> = emptyList()
        private set

    init {
        loadAllData()
    }

    private fun loadAllData() {
        try {
            lines = loadLines()
            stations = loadStations()
            interchanges = loadInterchanges()
            mccStations = loadMcc()
            mcdRoutes = loadMcd()
            airports = loadAirports()
            railwayStations = loadRailwayStations()
            Log.d(TAG, "Data loaded successfully. Lines: ${lines.size}, Stations: ${stations.size}")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading network configuration data", e)
        }
    }

    private fun readAssetFile(fileName: String): String {
        val inputStream = context.assets.open(fileName)
        val reader = BufferedReader(InputStreamReader(inputStream))
        val sb = StringBuilder()
        var line: String? = reader.readLine()
        while (line != null) {
            sb.append(line).append("\n")
            line = reader.readLine()
        }
        reader.close()
        inputStream.close()
        return sb.toString()
    }

    private fun loadLines(): List<MetroLine> {
        val jsonStr = readAssetFile("data/metro_lines.json")
        val array = JSONArray(jsonStr)
        val list = mutableListOf<MetroLine>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val stationIdsArray = obj.getJSONArray("stations")
            val stationIds = mutableListOf<String>()
            for (j in 0 until stationIdsArray.length()) {
                stationIds.add(stationIdsArray.getString(j))
            }
            list.add(
                MetroLine(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    shortName = obj.getString("shortName"),
                    color = obj.getString("color"),
                    stations = stationIds
                )
            )
        }
        return list
    }

    private fun loadStations(): List<MetroStation> {
        val jsonStr = readAssetFile("data/metro_stations.json")
        val array = JSONArray(jsonStr)
        val list = mutableListOf<MetroStation>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            
            val linesArray = obj.getJSONArray("lines")
            val lineList = mutableListOf<String>()
            for (j in 0 until linesArray.length()) {
                lineList.add(linesArray.getString(j))
            }

            val exitsArray = obj.getJSONArray("exits")
            val exitList = mutableListOf<StationExit>()
            for (j in 0 until exitsArray.length()) {
                val exitObj = exitsArray.getJSONObject(j)
                exitList.add(
                    StationExit(
                        id = exitObj.getInt("id"),
                        description = exitObj.getString("description")
                    )
                )
            }

            val facilitiesArray = obj.getJSONArray("facilities")
            val facilityList = mutableListOf<String>()
            for (j in 0 until facilitiesArray.length()) {
                facilityList.add(facilitiesArray.getString(j))
            }

            list.add(
                MetroStation(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    lines = lineList,
                    interchange = obj.getBoolean("interchange"),
                    exits = exitList,
                    facilities = facilityList,
                    architectureStyle = obj.optString("architectureStyle", ""),
                    architect = obj.optString("architect", ""),
                    yearOpened = obj.optInt("yearOpened", 1935),
                    description = obj.optString("description", "")
                )
            )
        }
        return list
    }

    private fun loadInterchanges(): List<Interchange> {
        val jsonStr = readAssetFile("data/interchanges.json")
        val array = JSONArray(jsonStr)
        val list = mutableListOf<Interchange>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                Interchange(
                    fromStation = obj.getString("from"),
                    toStation = obj.getString("to"),
                    timeMinutes = obj.getInt("timeMinutes")
                )
            )
        }
        return list
    }

    private fun loadMcc(): List<MccStation> {
        val jsonStr = readAssetFile("data/mcc.json")
        val array = JSONArray(jsonStr)
        val list = mutableListOf<MccStation>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                MccStation(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    line = obj.getString("line"),
                    interchangeTo = obj.getString("interchangeTo")
                )
            )
        }
        return list
    }

    private fun loadMcd(): List<McdRoute> {
        val jsonStr = readAssetFile("data/mcd.json")
        val array = JSONArray(jsonStr)
        val list = mutableListOf<McdRoute>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val stationsArray = obj.getJSONArray("stations")
            val stationNames = mutableListOf<String>()
            for (j in 0 until stationsArray.length()) {
                stationNames.add(stationsArray.getString(j))
            }
            list.add(
                McdRoute(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    line = obj.getString("line"),
                    stations = stationNames
                )
            )
        }
        return list
    }

    private fun loadAirports(): List<Airport> {
        val jsonStr = readAssetFile("data/airports.json")
        val array = JSONArray(jsonStr)
        val list = mutableListOf<Airport>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                Airport(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    aeroexpressFrom = obj.getString("aeroexpressFrom"),
                    aeroexpressTime = obj.getString("aeroexpressTime")
                )
            )
        }
        return list
    }

    private fun loadRailwayStations(): List<RailwayStation> {
        val jsonStr = readAssetFile("data/railway_stations.json")
        val array = JSONArray(jsonStr)
        val list = mutableListOf<RailwayStation>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val dirArray = obj.getJSONArray("directions")
            val dirs = mutableListOf<String>()
            for (j in 0 until dirArray.length()) {
                dirs.add(dirArray.getString(j))
            }
            list.add(
                RailwayStation(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    connectedStationId = obj.getString("connectedStationId"),
                    directions = dirs
                )
            )
        }
        return list
    }

    fun getStationById(id: String): MetroStation? {
        return stations.find { it.id == id }
    }

    fun getLineById(id: String): MetroLine? {
        return lines.find { it.id == id }
    }

    fun getLineForStation(station: MetroStation): MetroLine? {
        if (station.lines.isEmpty()) return null
        return getLineById(station.lines.first())
    }

    fun searchStations(query: String): List<MetroStation> {
        if (query.isBlank()) return emptyList()
        val normalizedQuery = query.lowercase().trim()
        return stations.filter { it.name.lowercase().contains(normalizedQuery) }
    }
}
