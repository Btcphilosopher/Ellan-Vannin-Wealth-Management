package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.MetroViewModel

@Composable
fun DeveloperScreen(viewModel: MetroViewModel, onBack: () -> Unit) {
    val totalStations = viewModel.repository.stations.size
    val totalLines = viewModel.repository.lines.size
    val totalInterchanges = viewModel.repository.interchanges.size
    
    val origin by viewModel.originStation.collectAsState()
    val dest by viewModel.destinationStation.collectAsState()
    val calculationTime by viewModel.routeCalculationTimeMs.collectAsState()
    val lastEvent by viewModel.lastDevEvent.collectAsState()
    val simState by viewModel.simulationState.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp)
            .testTag("developer_screen_root"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(48.dp)) }

        // Back button row
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surface, CircleShape)
                        .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                        .size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Назад",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "ОТЛАДКА СИСТЕМЫ",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Title (Section 39)
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.BugReport,
                    contentDescription = "Dev Mode",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "РЕЖИМ РАЗРАБОТЧИКА",
                    style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }

        // Telemetry values grid
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TelemetryRow(label = "СОСТОЯНИЕ СЕТИ", value = "ОФЛАЙН (АВТОНОМНО)")
                    TelemetryRow(label = "ИСТОЧНИК ДАННЫХ", value = "JSON ASSETS (ВСТРОЕННЫЙ)")
                    TelemetryRow(label = "ВСЕГО СТАНЦИЙ", value = "$totalStations")
                    TelemetryRow(label = "ВСЕГО ЛИНИЙ", value = "$totalLines")
                    TelemetryRow(label = "СМЕЖНЫХ ПЕРЕХОДОВ", value = "$totalInterchanges")
                }
            }
        }

        // Path finder benchmarks (Section 39)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "ПОСТРОЕНИЕ МАРШРУТА (DIJKSTRA)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.ExtraBold
                    )
                    TelemetryRow(label = "ОТПРАВЛЕНИЕ", value = origin?.name ?: "Не выбрано")
                    TelemetryRow(label = "НАЗНАЧЕНИЕ", value = dest?.name ?: "Не выбрано")
                    TelemetryRow(label = "ВРЕМЯ РАСЧЕТА", value = "$calculationTime мс")
                }
            }
        }

        // Simulator state engine metrics
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "АКТИВНЫЙ СИМУЛЯТОР ПОЕЗДКИ",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.ExtraBold
                    )
                    TelemetryRow(label = "СТАТУС ПОЕЗДКИ", value = simState.status.name)
                    TelemetryRow(label = "ТЕКУЩИЙ УЗЕЛ", value = simState.currentStation?.name ?: "—")
                    TelemetryRow(label = "СЛЕДУЮЩИЙ УЗЕЛ", value = simState.nextStation?.name ?: "—")
                    TelemetryRow(label = "ИНДЕКС СЕГМЕНТА", value = "${simState.activeSegmentIndex}")
                    TelemetryRow(label = "СИМУЛИРОВАННЫЙ ПРОГРЕСС", value = "${(simState.progress * 100).toInt()}%")
                }
            }
        }

        // Logging feed
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "ПОСЛЕДНЕЕ СОБЫТИЕ СИСТЕМЫ",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = lastEvent,
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(100.dp)) }
    }
}

@Composable
fun TelemetryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
    }
}
