package com.example.storage

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorite_stations")
data class FavoriteStationEntity(
    @PrimaryKey val id: String,
    val name: String
)

@Entity(tableName = "recent_routes")
data class RecentRouteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originId: String,
    val originName: String,
    val destId: String,
    val destName: String,
    val timeMinutes: Int,
    val transferCount: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val title: String, // e.g. "ЕДИНЫЙ"
    val dateCreated: String,
    val qrCodeData: String,
    val isValid: Boolean
)

@Entity(tableName = "troika_cards")
data class TroikaCardEntity(
    @PrimaryKey val cardId: String,
    val balance: Int,
    val cardName: String
)
