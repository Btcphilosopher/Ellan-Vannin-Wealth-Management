package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors (Cream & Graphite)
val MetroCreamBg = Color(0xFFFAF6EE) // Cream/marble tone
val MetroCardLight = Color(0xFFFFFFFF) // Crisp white paper
val MetroTextLightPrimary = Color(0xFF1C1E1F) // Deep graphite
val MetroTextLightSecondary = Color(0xFF6A7074) // Medium slate gray
val MetroBorderLight = Color(0xFFE5DEC9) // Soft warm clay

// Dark Theme Colors (Charcoal & Graphite)
val MetroCharcoalBg = Color(0xFF121415) // Slate/charcoal block
val MetroCardDark = Color(0xFF1B1E20) // Deep graphite container
val MetroTextDarkPrimary = Color(0xFFFAF6EE) // Off-white/cream text
val MetroTextDarkSecondary = Color(0xFF8F969B) // Warm silver
val MetroBorderDark = Color(0xFF2D3134) // Muted steel divider

// Core Branding Red
val MetroRedBrand = Color(0xFFE31E24) // Official deep red brand accent
val MetroRedDarkAccent = Color(0xFF9E151A) // Muted deep crimson

// Specific Line Colors (Reference)
val LineRed = Color(0xFFEF1E25)
val LineGreen = Color(0xFF029A55)
val LineBlue = Color(0xFF0B51A0)
val LineBrown = Color(0xFF7F4224)
val LineOrange = Color(0xFFED7E13)
val LinePurple = Color(0xFFAC1B78)
val LineGraphite = Color(0xFF7A7A7A)
val LineMccPink = Color(0xFFFF8BBE)
val LineMcdOrange = Color(0xFFFF9E1B)
