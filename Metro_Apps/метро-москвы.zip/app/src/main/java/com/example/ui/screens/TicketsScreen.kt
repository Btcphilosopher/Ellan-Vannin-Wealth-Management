package com.example.ui.screens

import kotlinx.coroutines.launch

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.storage.TicketEntity
import com.example.ui.MetroViewModel

@Composable
fun TicketsScreen(viewModel: MetroViewModel) {
    val activeTroika by viewModel.activeTroika.collectAsState()
    val ticketList by viewModel.tickets.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var selectedTab by remember { mutableStateOf(0) } // 0: Действующие, 1: Будущие, 2: История
    val tabTitles = listOf("Действующие", "Будущие", "История")

    var showHistoryDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp)
            .testTag("tickets_screen_root"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(48.dp)) }

        // Screen title
        item {
            Text(
                text = "БИЛЕТЫ",
                style = MaterialTheme.typography.displayLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.ExtraBold
            )
        }

        // Section: ТРОЙКА Card (Section 20)
        item {
            activeTroika?.let { card ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2537)), // Deep oceanic space blue
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "КАРТА ТРОЙКА",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF63B3ED), // Light sky blue
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = card.cardName.uppercase(),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Dynamic double circular logo
                            Row {
                                Box(modifier = Modifier.size(20.dp).background(Color(0xFFE31E24).copy(alpha = 0.8f), CircleShape))
                                Spacer(modifier = Modifier.width(-8.dp))
                                Box(modifier = Modifier.size(20.dp).background(Color(0xFF029A55).copy(alpha = 0.8f), CircleShape))
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Text(
                            text = "БАЛАНС",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFE2E8F0)
                        )
                        Text(
                            text = "${card.balance} ₽",
                            style = MaterialTheme.typography.displayMedium,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "№ ${card.cardId.chunked(4).joinToString(" ")}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFA0AEC0)
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Fast top-up actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TroikaActionButton(
                                title = "+100 ₽",
                                onClick = { viewModel.topUpTroika(100) }
                            )
                            TroikaActionButton(
                                title = "+500 ₽",
                                onClick = { viewModel.topUpTroika(500) }
                            )
                            TroikaActionButton(
                                title = "+1000 ₽",
                                onClick = { viewModel.topUpTroika(1000) }
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TextButton(onClick = { showHistoryDialog = true }) {
                                Text(
                                    text = "ИСТОРИЯ ОПЕРАЦИЙ",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Color(0xFF63B3ED)
                                )
                            }
                            TextButton(
                                onClick = {
                                    coroutineScope.launch {
                                        viewModel.topUpTroika(100) // add default topup on card click
                                    }
                                }
                            ) {
                                Text(
                                    text = "УПРАВЛЕНИЕ КАРТОЙ",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Color(0xFFE2E8F0)
                                )
                            }
                        }
                    }
                }
            } ?: run {
                // No card placeholder
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Карта не найдена. Создание по умолчанию...")
                }
            }
        }

        // Section: Tab Selection
        item {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.primary,
                divider = {}
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                            )
                        }
                    )
                }
            }
        }

        // Action: Purchase Single Ticket Button
        item {
            Button(
                onClick = { viewModel.purchaseSingleTicket() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Купить")
                Spacer(modifier = Modifier.width(8.dp))
                Text("КУПИТЬ РАЗОВЫЙ БИЛЕТ (ЕДИНЫЙ)", style = MaterialTheme.typography.labelLarge)
            }
        }

        // Active Ticket Items
        if (selectedTab == 0) {
            val activeTickets = ticketList.filter { it.isValid }
            if (activeTickets.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Действующих билетов нет",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    }
                }
            } else {
                items(activeTickets) { ticket ->
                    TicketCard(ticket = ticket)
                }
            }
        } else {
            // Future / History empty placeholder
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "В этой вкладке ничего нет",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(100.dp)) }
    }

    // History log popup
    if (showHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showHistoryDialog = false },
            title = { Text("ИСТОРИЯ ОПЕРАЦИЙ", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OperationRow(title = "Пополнение баланса", value = "+500 ₽", date = "Сегодня")
                    OperationRow(title = "Поездка: Охотный Ряд", value = "-54 ₽", date = "Вчера")
                    OperationRow(title = "Поездка: Динамо", value = "-54 ₽", date = "18 сентября")
                    OperationRow(title = "Пополнение Тройки", value = "+100 ₽", date = "15 сентября")
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistoryDialog = false }) {
                    Text("ЗАКРЫТЬ")
                }
            }
        )
    }
}

@Composable
fun OperationRow(title: String, value: String, date: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
            Text(text = date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            color = if (value.startsWith("+")) Color(0xFF029A55) else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun TroikaActionButton(
    title: String,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A5F)),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        modifier = Modifier.height(36.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun TicketCard(ticket: TicketEntity) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Top branding (Section 22)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "МЕТРО МОСКВЫ",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "ЕДИНЫЙ",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Divider(color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(vertical = 12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ДАТА ВЫДАЧИ",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = ticket.dateCreated,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "ДЕЙСТВУЕТ",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "на всех станциях",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Schematic vector QR code (Section 22 & 23)
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .background(Color.White)
                        .border(1.dp, Color.Black)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val gridSize = 7
                        val cellW = size.width / gridSize
                        val cellH = size.height / gridSize
                        
                        // Seed logic to draw nice custom matrix squares
                        val pattern = listOf(
                            listOf(1, 1, 1, 0, 1, 1, 1),
                            listOf(1, 0, 1, 0, 1, 0, 1),
                            listOf(1, 1, 1, 1, 0, 0, 1),
                            listOf(0, 0, 0, 1, 1, 1, 0),
                            listOf(1, 1, 0, 1, 0, 1, 1),
                            listOf(1, 0, 1, 0, 1, 0, 1),
                            listOf(1, 1, 1, 0, 1, 1, 1)
                        )

                        for (r in 0 until gridSize) {
                            for (c in 0 until gridSize) {
                                if (pattern[r][c] == 1) {
                                    drawRect(
                                        color = Color.Black,
                                        topLeft = Offset(c * cellW, r * cellH),
                                        size = Size(cellW, cellH)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Divider(color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(vertical = 12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "№ ${ticket.id}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "ДЕМОНСТРАЦИОННЫЙ БИЛЕТ",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}
