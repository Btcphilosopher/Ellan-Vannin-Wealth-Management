package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.domain.Route
import com.example.domain.RouteFinder
import com.example.domain.RouteSegment
import com.example.storage.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class SimulationStatus(val displayTitle: String) {
    INACTIVE("Ожидание поездки"),
    ENTERING_STATION("Вход на станцию"),
    WAITING_FOR_TRAIN("Ожидание поезда"),
    BOARDING("В поезде"),
    TRAVELING("В пути"),
    TRANSFERRING("Пересадка на другую линию"),
    ARRIVED("Вы приехали")
}

data class SimulationState(
    val status: SimulationStatus = SimulationStatus.INACTIVE,
    val currentStation: MetroStation? = null,
    val nextStation: MetroStation? = null,
    val activeSegmentIndex: Int = 0,
    val progress: Float = 0.0f, // 0.0 to 1.0
    val timeRemainingMinutes: Int = 0,
    val logMessage: String = "Маршрут готов к симуляции"
)

data class ServiceAlert(
    val id: String,
    val type: String, // "Задержка", "Изменение", "Закрытие", "Ремонт", "Инфо"
    val title: String,
    val description: String,
    val date: String
)

class MetroViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val dao = db.metroDao()
    
    val repository = MetroRepository(application)
    val routeFinder = RouteFinder(repository)
    private val paymentProvider = DemoPaymentProvider()
    private val troikaProvider = DemoTroikaProvider(dao)

    // UI state
    val currentTab = MutableStateFlow("ГЛАВНАЯ") // ГЛАВНАЯ, КАРТА, МАРШРУТ, БИЛЕТЫ, НАСТРОЙКИ
    val searchQuery = MutableStateFlow("")
    
    val searchResults = searchQuery
        .debounce(100)
        .map { query ->
            repository.searchStations(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selection State
    val originStation = MutableStateFlow<MetroStation?>(null)
    val destinationStation = MutableStateFlow<MetroStation?>(null)
    
    val routeOptions = MutableStateFlow<List<Route>>(emptyList())
    val selectedRoute = MutableStateFlow<Route?>(null)
    
    // Detailed Station View State
    val selectedStationForDetail = MutableStateFlow<MetroStation?>(null)

    // Persistent States from Database
    val favoriteStations = dao.getFavoriteStations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val recentRoutes = dao.getRecentRoutes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val tickets = dao.getTickets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val activeTroika = dao.getActiveTroikaCard()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Developer Screen telemetry
    val routeCalculationTimeMs = MutableStateFlow(0L)
    val lastDevEvent = MutableStateFlow("Приложение запущено")

    // Service Alerts list (offline mock, Section 29)
    val serviceAlerts = listOf(
        ServiceAlert(
            id = "a1",
            type = "Закрытие",
            title = "Временное закрытие вестибюлей",
            description = "На станции Маяковская временно закрыт выход №2 в связи с ремонтом эскалаторов.",
            date = "Сегодня"
        ),
        ServiceAlert(
            id = "a2",
            type = "Ремонт",
            title = "Плановые работы на путях",
            description = "Интервалы движения поездов на Кольцевой линии увеличены на 1-2 минуты в ночное время.",
            date = "Вчера"
        ),
        ServiceAlert(
            id = "a3",
            type = "Инфо",
            title = "Открытие новых станций",
            description = "Введена в эксплуатацию Рублёво-Архангельская линия в сентябре 2026 года.",
            date = "15 сентября 2026"
        )
    )

    // Simulation Engine State
    val simulationState = MutableStateFlow(SimulationState())
    private var simulationJob: Job? = null

    init {
        // Initialize default tickets & Troika card if empty
        viewModelScope.launch {
            dao.getActiveTroikaCard().first()?.let {
                // already has card
            } ?: run {
                // create default Troika Card
                troikaProvider.createNewCard("Карта Тройка")
            }

            dao.getTickets().first().let { list ->
                if (list.isEmpty()) {
                    // Create a default demo ticket
                    val format = SimpleDateFormat("dd MMMM yyyy", Locale("ru"))
                    dao.insertTicket(
                        TicketEntity(
                            id = "004827193",
                            title = "ЕДИНЫЙ",
                            dateCreated = format.format(Date()),
                            qrCodeData = "DEMO-TICKET-004827193",
                            isValid = true
                        )
                    )
                }
            }
        }
    }

    // Toggle Station Favorite
    fun toggleFavorite(station: MetroStation) {
        viewModelScope.launch {
            val isFav = dao.isFavoriteStation(station.id)
            if (isFav) {
                dao.deleteFavoriteStationById(station.id)
                lastDevEvent.value = "Станция ${station.name} удалена из избранного"
            } else {
                dao.insertFavoriteStation(FavoriteStationEntity(station.id, station.name))
                lastDevEvent.value = "Станция ${station.name} добавлена в избранное"
            }
        }
    }

    // Check if station is favorite
    suspend fun isStationFavorite(stationId: String): Boolean {
        return dao.isFavoriteStation(stationId)
    }

    // Calculate Route
    fun calculateRoutes() {
        val o = originStation.value ?: return
        val d = destinationStation.value ?: return
        
        viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            val options = routeFinder.findRouteOptions(o.id, d.id)
            val endTime = System.currentTimeMillis()
            
            routeCalculationTimeMs.value = (endTime - startTime)
            routeOptions.value = options
            
            if (options.isNotEmpty()) {
                selectedRoute.value = options.first()
                
                // Save to recent routes in DB
                dao.insertRecentRoute(
                    RecentRouteEntity(
                        originId = o.id,
                        originName = o.name,
                        destId = d.id,
                        destName = d.name,
                        timeMinutes = options.first().totalTimeMinutes,
                        transferCount = options.first().transferCount
                    )
                )
                lastDevEvent.value = "Маршрут ${o.name} -> ${d.name} построен за ${endTime - startTime} мс"
            } else {
                selectedRoute.value = null
                lastDevEvent.value = "Не удалось проложить маршрут ${o.name} -> ${d.name}"
            }
        }
    }

    // Select alternative route
    fun selectRouteOption(route: Route) {
        selectedRoute.value = route
        lastDevEvent.value = "Выбран альтернативный вариант: ${route.typeName}"
    }

    // Purchase mock single ticket
    fun purchaseSingleTicket() {
        viewModelScope.launch {
            val format = SimpleDateFormat("dd MMMM yyyy", Locale("ru"))
            val ticketId = "00${(10000000..99999999).random()}"
            val newTicket = TicketEntity(
                id = ticketId,
                title = "ЕДИНЫЙ",
                dateCreated = format.format(Date()),
                qrCodeData = "DEMO-TICKET-$ticketId",
                isValid = true
            )
            dao.insertTicket(newTicket)
            lastDevEvent.value = "Куплен разовый билет №$ticketId"
        }
    }

    // Replenish Troika balance
    fun topUpTroika(amount: Int) {
        viewModelScope.launch {
            val currentCard = activeTroika.value ?: return@launch
            val result = troikaProvider.topUp(currentCard.cardId, amount, paymentProvider)
            if (result.success) {
                lastDevEvent.value = "Тройка ${currentCard.cardId} пополнена на $amount ₽. Номер транзакции: ${result.transactionId}"
            }
        }
    }

    // Swapping origin and destination
    fun swapStations() {
        val temp = originStation.value
        originStation.value = destinationStation.value
        destinationStation.value = temp
        if (originStation.value != null && destinationStation.value != null) {
            calculateRoutes()
        }
    }

    // Start Trip Simulator
    fun startSimulation(route: Route) {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            lastDevEvent.value = "Симуляция поездки запущена"
            val segments = route.segments
            if (segments.isEmpty()) return@launch

            // Step 1: Entering origin station
            val firstRide = segments.first() as? RouteSegment.Ride
            val firstStation = firstRide?.station ?: repository.getStationById(route.segments.first().let { 
                when(it) {
                    is RouteSegment.Ride -> it.station.id
                    is RouteSegment.Transfer -> it.fromStation.id
                }
            })!!

            simulationState.value = SimulationState(
                status = SimulationStatus.ENTERING_STATION,
                currentStation = firstStation,
                nextStation = null,
                activeSegmentIndex = 0,
                progress = 0.0f,
                timeRemainingMinutes = route.totalTimeMinutes,
                logMessage = "Вход на станцию ${firstStation.name}"
            )
            delay(2000)

            // Step 2: Waiting for train at origin
            simulationState.value = simulationState.value.copy(
                status = SimulationStatus.WAITING_FOR_TRAIN,
                logMessage = "Ожидание поезда на платформе"
            )
            delay(2000)

            // Step 3: Travelling through segments
            for (idx in segments.indices) {
                val segment = segments[idx]
                
                when (segment) {
                    is RouteSegment.Ride -> {
                        val currentStation = segment.station
                        val nextStation = if (idx + 1 < segments.size) {
                            val nextSeg = segments[idx + 1]
                            when (nextSeg) {
                                is RouteSegment.Ride -> nextSeg.station
                                is RouteSegment.Transfer -> nextSeg.toStation
                            }
                        } else null

                        // Transition to boarding
                        simulationState.value = simulationState.value.copy(
                            status = SimulationStatus.BOARDING,
                            currentStation = currentStation,
                            nextStation = nextStation,
                            activeSegmentIndex = idx,
                            progress = 0.0f,
                            logMessage = "Посадка в поезд на станции ${currentStation.name}"
                        )
                        delay(1500)

                        // Transition to active travel animation
                        val steps = 10
                        for (step in 1..steps) {
                            simulationState.value = simulationState.value.copy(
                                status = SimulationStatus.TRAVELING,
                                progress = step / steps.toFloat(),
                                timeRemainingMinutes = (route.totalTimeMinutes * (1.0 - (idx.toFloat() / segments.size))).toInt(),
                                logMessage = "Движение между станциями: ${(step * 10)}% пути пройдено"
                            )
                            delay(400)
                        }
                    }
                    is RouteSegment.Transfer -> {
                        // Transfer state
                        simulationState.value = simulationState.value.copy(
                            status = SimulationStatus.TRANSFERRING,
                            currentStation = segment.fromStation,
                            nextStation = segment.toStation,
                            activeSegmentIndex = idx,
                            progress = 0.5f,
                            logMessage = "Пешеходный переход: ${segment.fromStation.name} ➔ ${segment.toStation.name} (${segment.timeMinutes} мин)"
                        )
                        delay(3000)
                    }
                }
            }

            // Arrived
            val lastStation = repository.getStationById(destinationStation.value?.id ?: "")
            simulationState.value = SimulationState(
                status = SimulationStatus.ARRIVED,
                currentStation = lastStation,
                nextStation = null,
                activeSegmentIndex = segments.size,
                progress = 1.0f,
                timeRemainingMinutes = 0,
                logMessage = "Поездка успешно завершена. Станция назначения: ${lastStation?.name}"
            )
            lastDevEvent.value = "Симуляция завершена — Вы прибыли!"
        }
    }

    // Stop Simulation
    fun stopSimulation() {
        simulationJob?.cancel()
        simulationState.value = SimulationState()
        lastDevEvent.value = "Симуляция поездки остановлена"
    }

    fun clearSelections() {
        originStation.value = null
        destinationStation.value = null
        routeOptions.value = emptyList()
        selectedRoute.value = null
        stopSimulation()
    }
}
