package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.MetroViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val systemDark = isSystemInDarkTheme()
            var darkTheme by remember { mutableStateOf(systemDark) }

            MyApplicationTheme(darkTheme = darkTheme) {
                // Initialize MetroViewModel manually for maximum reliability in compiler environment
                val context = LocalContext.current.applicationContext as android.app.Application
                val viewModel = remember { MetroViewModel(context) }
                
                val currentTab by viewModel.currentTab.collectAsState()
                val selectedStationDetail by viewModel.selectedStationForDetail.collectAsState()
                
                // Active sub-screen state (e.g. Developer options)
                var activeSubScreen by remember { mutableStateOf("") } // "" or "DEVELOPER"

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Display bottom bar only if we are not in a full screen subview
                        if (selectedStationDetail == null && activeSubScreen.isEmpty()) {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface,
                                tonalElevation = 8.dp,
                                modifier = Modifier
                                    .testTag("main_navigation_bar")
                                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                            ) {
                                NavigationBarItem(
                                    selected = currentTab == "ГЛАВНАЯ",
                                    onClick = { viewModel.currentTab.value = "ГЛАВНАЯ" },
                                    label = { Text("ГЛАВНАЯ") },
                                    icon = { Icon(Icons.Default.Home, contentDescription = "Главная") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.White,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary
                                    ),
                                    modifier = Modifier.testTag("nav_tab_home")
                                )
                                NavigationBarItem(
                                    selected = currentTab == "КАРТА",
                                    onClick = { viewModel.currentTab.value = "КАРТА" },
                                    label = { Text("КАРТА") },
                                    icon = { Icon(Icons.Default.Map, contentDescription = "Карта") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.White,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary
                                    ),
                                    modifier = Modifier.testTag("nav_tab_map")
                                )
                                NavigationBarItem(
                                    selected = currentTab == "МАРШРУТ",
                                    onClick = { viewModel.currentTab.value = "МАРШРУТ" },
                                    label = { Text("МАРШРУТ") },
                                    icon = { Icon(Icons.Default.AltRoute, contentDescription = "Маршрут") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.White,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary
                                    ),
                                    modifier = Modifier.testTag("nav_tab_route")
                                )
                                NavigationBarItem(
                                    selected = currentTab == "БИЛЕТЫ",
                                    onClick = { viewModel.currentTab.value = "БИЛЕТЫ" },
                                    label = { Text("БИЛЕТЫ") },
                                    icon = { Icon(Icons.Default.QrCode, contentDescription = "Билеты") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.White,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary
                                    ),
                                    modifier = Modifier.testTag("nav_tab_tickets")
                                )
                                NavigationBarItem(
                                    selected = currentTab == "НАСТРОЙКИ",
                                    onClick = { viewModel.currentTab.value = "НАСТРОЙКИ" },
                                    label = { Text("НАСТРОЙКИ") },
                                    icon = { Icon(Icons.Default.Settings, contentDescription = "Настройки") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.White,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary
                                    ),
                                    modifier = Modifier.testTag("nav_tab_settings")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = if (selectedStationDetail == null && activeSubScreen.isEmpty()) innerPadding.calculateBottomPadding() else 0.dp)
                    ) {
                        // Navigation router logic
                        when {
                            activeSubScreen == "DEVELOPER" -> {
                                DeveloperScreen(
                                    viewModel = viewModel,
                                    onBack = { activeSubScreen = "" }
                                )
                            }
                            selectedStationDetail != null -> {
                                StationDetailScreen(
                                    viewModel = viewModel,
                                    onBack = { viewModel.selectedStationForDetail.value = null }
                                )
                            }
                            else -> {
                                when (currentTab) {
                                    "ГЛАВНАЯ" -> {
                                        HomeScreen(
                                            viewModel = viewModel,
                                            onNavigateToRoute = { viewModel.currentTab.value = "МАРШРУТ" },
                                            onNavigateToMap = { viewModel.currentTab.value = "КАРТА" },
                                            onNavigateToTickets = { viewModel.currentTab.value = "БИЛЕТЫ" }
                                        )
                                    }
                                    "КАРТА" -> {
                                        MapScreen(viewModel = viewModel)
                                    }
                                    "МАРШРУТ" -> {
                                        RouteScreen(viewModel = viewModel)
                                    }
                                    "БИЛЕТЫ" -> {
                                        TicketsScreen(viewModel = viewModel)
                                    }
                                    "НАСТРОЙКИ" -> {
                                        Column(modifier = Modifier.fillMaxSize()) {
                                            Box(modifier = Modifier.weight(1f)) {
                                                SettingsScreen(
                                                    viewModel = viewModel,
                                                    isDarkTheme = darkTheme,
                                                    onToggleDarkTheme = { darkTheme = it }
                                                )
                                            }
                                            
                                            // Discreet Development entry button inside settings view to respect original UI design
                                            Button(
                                                onClick = { activeSubScreen = "DEVELOPER" },
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 20.dp, vertical = 8.dp)
                                            ) {
                                                Icon(Icons.Default.BugReport, contentDescription = "Отладка", tint = MaterialTheme.colorScheme.primary)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("ВХОД В РЕЖИМ РАЗРАБОТЧИКА", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
