package com.example.storage

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {

    // Favorite Stations
    @Query("SELECT * FROM favorite_stations ORDER BY name ASC")
    fun getFavoriteStations(): Flow<List<FavoriteStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavoriteStation(station: FavoriteStationEntity)

    @Query("DELETE FROM favorite_stations WHERE id = :id")
    suspend fun deleteFavoriteStationById(id: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_stations WHERE id = :id)")
    suspend fun isFavoriteStation(id: String): Boolean


    // Recent Routes
    @Query("SELECT * FROM recent_routes ORDER BY timestamp DESC LIMIT 5")
    fun getRecentRoutes(): Flow<List<RecentRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentRoute(route: RecentRouteEntity)

    @Query("DELETE FROM recent_routes")
    suspend fun clearRecentRoutes()


    // Tickets
    @Query("SELECT * FROM tickets ORDER BY dateCreated DESC")
    fun getTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)


    // Troika Card
    @Query("SELECT * FROM troika_cards WHERE cardId = :cardId")
    suspend fun getTroikaCard(cardId: String): TroikaCardEntity?

    @Query("SELECT * FROM troika_cards LIMIT 1")
    fun getActiveTroikaCard(): Flow<TroikaCardEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateTroikaCard(card: TroikaCardEntity)
}
