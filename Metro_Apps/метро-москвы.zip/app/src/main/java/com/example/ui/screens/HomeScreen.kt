package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MetroStation
import com.example.ui.MetroViewModel

@Composable
fun HomeScreen(
    viewModel: MetroViewModel,
    onNavigateToRoute: () -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToTickets: () -> Unit
) {
    val origin by viewModel.originStation.collectAsState()
    val dest by viewModel.destinationStation.collectAsState()
    val recentList by viewModel.recentRoutes.collectAsState()

    var showOriginSearch by remember { mutableStateOf(false) }
    var showDestSearch by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp)
            .testTag("home_screen_root"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Safe drawing top padding
        item { Spacer(modifier = Modifier.height(48.dp)) }

        // Header Title (Section 4)
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "МЕТРО МОСКВЫ",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Ваш маршрут по городу",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
            }
        }

        // Offline Banner (Section 30)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(Color(0xFF029A55), CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "ОФЛАЙН-РЕЖИМ АКТИВЕН",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Схема и поиск станций работают без интернета",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Travel planner Card (Section 4)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "КУДА ЕДЕМ?",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Origin Station Input Field
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.background.copy(alpha = 0.5f),
                                RoundedCornerShape(12.dp)
                            )
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                            .clickable { showOriginSearch = true }
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RadioButtonUnchecked,
                                contentDescription = "Откуда",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "ОТКУДА",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = origin?.name ?: "Выберите станцию отправления",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (origin != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Swap Stations Button Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = { viewModel.swapStations() },
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.background, CircleShape)
                                .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "Поменять местами",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Destination Station Input Field
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.background.copy(alpha = 0.5f),
                                RoundedCornerShape(12.dp)
                            )
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                            .clickable { showDestSearch = true }
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Куда",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "КУДА",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = dest?.name ?: "Выберите станцию прибытия",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (dest != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Calculate Route Button
                    Button(
                        onClick = {
                            if (origin != null && dest != null) {
                                viewModel.calculateRoutes()
                                onNavigateToRoute()
                            }
                        },
                        enabled = origin != null && dest != null,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            disabledContainerColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("build_route_button")
                    ) {
                        Text(
                            text = "ПОСТРОИТЬ МАРШРУТ",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Fast Access actions grid (Section 5)
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "БЫСТРЫЙ ДОСТУП",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FastActionButton(
                        title = "Рядом\nсо мной",
                        icon = Icons.Default.MyLocation,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            // Select dynamic default close station (e.g. Mayakovskaya)
                            viewModel.originStation.value = viewModel.repository.getStationById("s2_4")
                        }
                    )
                    FastActionButton(
                        title = "Схема\nметро",
                        icon = Icons.Default.Map,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToMap
                    )
                    FastActionButton(
                        title = "Мои\nбилеты",
                        icon = Icons.Default.QrCode,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToTickets
                    )
                }
            }
        }

        // Recent Routes list (Section 6)
        if (recentList.isNotEmpty()) {
            item {
                Text(
                    text = "ПОСЛЕДНИЕ МАРШРУТЫ",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            items(recentList) { routeEntity ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                            RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            val orig = viewModel.repository.getStationById(routeEntity.originId)
                            val dst = viewModel.repository.getStationById(routeEntity.destId)
                            if (orig != null && dst != null) {
                                viewModel.originStation.value = orig
                                viewModel.destinationStation.value = dst
                                viewModel.calculateRoutes()
                                onNavigateToRoute()
                            }
                        }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = routeEntity.originName,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "к",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .padding(horizontal = 8.dp)
                                    .size(16.dp)
                            )
                            Text(
                                text = routeEntity.destName,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${routeEntity.timeMinutes} мин · пересадок: ${routeEntity.transferCount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Повторить",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                }
            }
        }

        // Base safe spacer
        item { Spacer(modifier = Modifier.height(100.dp)) }
    }

    // Modal Search overlays
    if (showOriginSearch) {
        StationSearchModal(
            title = "ВЫБОР СТАНЦИИ ОТПРАВЛЕНИЯ",
            viewModel = viewModel,
            onClose = { showOriginSearch = false },
            onSelect = { station ->
                viewModel.originStation.value = station
                showOriginSearch = false
                if (dest != null) {
                    viewModel.calculateRoutes()
                }
            }
        )
    }

    if (showDestSearch) {
        StationSearchModal(
            title = "ВЫБОР СТАНЦИИ НАЗНАЧЕНИЯ",
            viewModel = viewModel,
            onClose = { showDestSearch = false },
            onSelect = { station ->
                viewModel.destinationStation.value = station
                showDestSearch = false
                if (origin != null) {
                    viewModel.calculateRoutes()
                }
            }
        )
    }
}

@Composable
fun FastActionButton(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                lineHeight = 14.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationSearchModal(
    title: String,
    viewModel: MetroViewModel,
    onClose: () -> Unit,
    onSelect: (MetroStation) -> Unit
) {
    val query by viewModel.searchQuery.collectAsState()
    val results by viewModel.searchResults.collectAsState()
    val favorites by viewModel.favoriteStations.collectAsState()
    val allStations = viewModel.repository.stations

    ModalBottomSheet(
        onDismissRequest = onClose,
        containerColor = MaterialTheme.colorScheme.background,
        dragHandle = { BottomSheetDefaults.DragHandle(color = MaterialTheme.colorScheme.outline) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Search Text Field
            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.searchQuery.value = it },
                placeholder = { Text("Поиск станции...", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Поиск") },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Очистить")
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                // If query is empty, show Favorites and All Stations list
                if (query.isBlank()) {
                    if (favorites.isNotEmpty()) {
                        item {
                            Text(
                                text = "ИЗБРАННЫЕ СТАНЦИИ",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                            )
                        }
                        items(favorites) { fav ->
                            val fullStation = allStations.find { it.id == fav.id }
                            if (fullStation != null) {
                                StationSearchRow(fullStation, onSelect)
                            }
                        }
                        item { Spacer(modifier = Modifier.height(8.dp)) }
                    }

                    item {
                        Text(
                            text = "ВСЕ СТАНЦИИ СЕТИ",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    }

                    items(allStations) { station ->
                        StationSearchRow(station, onSelect)
                    }
                } else {
                    // Show search results
                    if (results.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Ничего не найдено",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                )
                            }
                        }
                    } else {
                        items(results) { station ->
                            StationSearchRow(station, onSelect)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun StationSearchRow(station: MetroStation, onSelect: (MetroStation) -> Unit) {
    val mainLineId = station.lines.firstOrNull() ?: "1"
    val lineColor = when (mainLineId) {
        "1" -> Color(0xFFEF1E25)
        "2" -> Color(0xFF029A55)
        "3" -> Color(0xFF0B51A0)
        "5" -> Color(0xFF7F4224)
        "6" -> Color(0xFFED7E13)
        "7" -> Color(0xFFAC1B78)
        "17" -> Color(0xFF7A7A7A)
        else -> Color.DarkGray
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .clickable { onSelect(station) }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(lineColor, CircleShape)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = station.name,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
            if (station.interchange) {
                Text(
                    text = "Есть пересадка",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
