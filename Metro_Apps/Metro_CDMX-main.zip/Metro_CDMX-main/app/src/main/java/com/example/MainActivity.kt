package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.ui.components.Localization
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.TransitViewModel

// Route definitions matching Jetpack Navigation Compose conventions
const val ROUTE_HOME = "HomeScreen"
const val ROUTE_JOURNEY_PLANNER = "JourneyPlannerScreen"
const val ROUTE_NETWORK_MAP = "NetworkMapScreen"
const val ROUTE_TOURIST_GUIDE = "TouristScreen"
const val ROUTE_ADMIN_CONSOLE = "AdminConsoleScreen"
const val ROUTE_SETTINGS = "SettingsScreen"
const val ROUTE_STATION_DETAIL = "StationDetailScreen"

class MainActivity : ComponentActivity() {
    
    private val viewModel: TransitViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val lang by viewModel.currentLanguage.collectAsState()
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                // Determine screen layout size class (responsive adaptive layout)
                val configuration = LocalConfiguration.current
                val isTablet = configuration.screenWidthDp >= 600

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        if (currentRoute != null && (
                            currentRoute == ROUTE_HOME ||
                            currentRoute == ROUTE_JOURNEY_PLANNER ||
                            currentRoute == ROUTE_NETWORK_MAP ||
                            currentRoute == ROUTE_TOURIST_GUIDE ||
                            currentRoute == ROUTE_SETTINGS
                        )) {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = MaterialTheme.colorScheme.surface,
                                shadowElevation = 1.dp
                            ) {
                                Row(
                                    modifier = Modifier
                                        .statusBarsPadding()
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(MaterialTheme.colorScheme.primary),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "M",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 20.sp
                                            )
                                        }
                                        Text(
                                            text = "Metro CDMX",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            letterSpacing = (-0.5).sp
                                        )
                                    }
                                    
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFE8F5E9))
                                                .clickable {
                                                    navController.navigate(ROUTE_JOURNEY_PLANNER)
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Search,
                                                contentDescription = "Buscar",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                        
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFE0E2E0))
                                        )
                                    }
                                }
                            }
                        }
                    },
                    bottomBar = {
                        // Display bottom bar on compact/phone screens and if not a child detail screen
                        if (!isTablet && currentRoute != null && !currentRoute.startsWith(ROUTE_STATION_DETAIL)) {
                            NavigationBar(
                                modifier = Modifier.testTag("bottom_nav_bar")
                            ) {
                                NavigationBarItem(
                                    selected = currentRoute == ROUTE_HOME,
                                    onClick = { navController.navigate(ROUTE_HOME) { popUpTo(ROUTE_HOME) { inclusive = false } } },
                                    icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Home") },
                                    label = { Text(text = "Inicio", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                    modifier = Modifier.testTag("nav_home")
                                )
                                NavigationBarItem(
                                    selected = currentRoute == ROUTE_JOURNEY_PLANNER,
                                    onClick = { navController.navigate(ROUTE_JOURNEY_PLANNER) { launchSingleTop = true } },
                                    icon = { Icon(imageVector = Icons.Default.Route, contentDescription = "Planner") },
                                    label = { Text(text = "Ruta", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                    modifier = Modifier.testTag("nav_planner")
                                )
                                NavigationBarItem(
                                    selected = currentRoute == ROUTE_NETWORK_MAP,
                                    onClick = { navController.navigate(ROUTE_NETWORK_MAP) { launchSingleTop = true } },
                                    icon = { Icon(imageVector = Icons.Default.Map, contentDescription = "Map") },
                                    label = { Text(text = "Mapa", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                    modifier = Modifier.testTag("nav_map")
                                )
                                NavigationBarItem(
                                    selected = currentRoute == ROUTE_TOURIST_GUIDE,
                                    onClick = { navController.navigate(ROUTE_TOURIST_GUIDE) { launchSingleTop = true } },
                                    icon = { Icon(imageVector = Icons.Default.TravelExplore, contentDescription = "Tourist") },
                                    label = { Text(text = "Turista", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                    modifier = Modifier.testTag("nav_tourist")
                                )
                                NavigationBarItem(
                                    selected = currentRoute == ROUTE_SETTINGS,
                                    onClick = { navController.navigate(ROUTE_SETTINGS) { launchSingleTop = true } },
                                    icon = { Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings") },
                                    label = { Text(text = "Ajustes", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                    modifier = Modifier.testTag("nav_settings")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // Display NavigationRail on wide tablet screens
                        if (isTablet && currentRoute != null && !currentRoute.startsWith(ROUTE_STATION_DETAIL)) {
                            NavigationRail(
                                header = {
                                    Icon(
                                        imageVector = Icons.Default.DirectionsSubway,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(36.dp).padding(bottom = 12.dp),
                                        contentDescription = "CDMX"
                                    )
                                },
                                modifier = Modifier.testTag("side_nav_rail")
                            ) {
                                NavigationRailItem(
                                    selected = currentRoute == ROUTE_HOME,
                                    onClick = { navController.navigate(ROUTE_HOME) { popUpTo(ROUTE_HOME) { inclusive = false } } },
                                    icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Home") },
                                    label = { Text(text = "Inicio", fontWeight = FontWeight.Bold) }
                                )
                                NavigationRailItem(
                                    selected = currentRoute == ROUTE_JOURNEY_PLANNER,
                                    onClick = { navController.navigate(ROUTE_JOURNEY_PLANNER) { launchSingleTop = true } },
                                    icon = { Icon(imageVector = Icons.Default.Route, contentDescription = "Planner") },
                                    label = { Text(text = "Ruta", fontWeight = FontWeight.Bold) }
                                )
                                NavigationRailItem(
                                    selected = currentRoute == ROUTE_NETWORK_MAP,
                                    onClick = { navController.navigate(ROUTE_NETWORK_MAP) { launchSingleTop = true } },
                                    icon = { Icon(imageVector = Icons.Default.Map, contentDescription = "Map") },
                                    label = { Text(text = "Mapa", fontWeight = FontWeight.Bold) }
                                )
                                NavigationRailItem(
                                    selected = currentRoute == ROUTE_TOURIST_GUIDE,
                                    onClick = { navController.navigate(ROUTE_TOURIST_GUIDE) { launchSingleTop = true } },
                                    icon = { Icon(imageVector = Icons.Default.TravelExplore, contentDescription = "Tourist") },
                                    label = { Text(text = "Turista", fontWeight = FontWeight.Bold) }
                                )
                                NavigationRailItem(
                                    selected = currentRoute == ROUTE_SETTINGS,
                                    onClick = { navController.navigate(ROUTE_SETTINGS) { launchSingleTop = true } },
                                    icon = { Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings") },
                                    label = { Text(text = "Ajustes", fontWeight = FontWeight.Bold) }
                                )
                            }
                        }

                        // NavHost Main Window View
                        NavHost(
                            navController = navController,
                            startDestination = ROUTE_HOME,
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxHeight()
                        ) {
                            composable(ROUTE_HOME) {
                                HomeScreen(
                                    viewModel = viewModel,
                                    onNavigateToJourneyPlanner = {
                                        navController.navigate(ROUTE_JOURNEY_PLANNER)
                                    },
                                    onNavigateToStationDetail = { stationId ->
                                        navController.navigate("$ROUTE_STATION_DETAIL/$stationId")
                                    },
                                    onNavigateToNetworkMap = {
                                        navController.navigate(ROUTE_NETWORK_MAP)
                                    }
                                )
                            }

                            composable(ROUTE_JOURNEY_PLANNER) {
                                JourneyPlannerScreen(viewModel = viewModel)
                            }

                            composable(ROUTE_NETWORK_MAP) {
                                NetworkMapScreen(
                                    viewModel = viewModel,
                                    onNavigateToStationDetail = { stationId ->
                                        navController.navigate("$ROUTE_STATION_DETAIL/$stationId")
                                    }
                                )
                            }

                            composable(ROUTE_TOURIST_GUIDE) {
                                TouristScreen(
                                    viewModel = viewModel,
                                    onNavigateToJourneyPlanner = {
                                        navController.navigate(ROUTE_JOURNEY_PLANNER)
                                    }
                                )
                            }

                            composable(ROUTE_SETTINGS) {
                                Column(modifier = Modifier.fillMaxSize()) {
                                    // Hidden shortcut at top to reach Admin Console Screen in Settings
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                navController.navigate(ROUTE_ADMIN_CONSOLE)
                                            }
                                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                                            .padding(horizontal = 16.dp, vertical = 12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.AdminPanelSettings,
                                                tint = MaterialTheme.colorScheme.primary,
                                                contentDescription = null,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = Localization.get("admin_console", lang),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Icon(
                                            imageVector = Icons.Default.ChevronRight,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp),
                                            contentDescription = null
                                        )
                                    }
                                    
                                    SettingsScreen(
                                        viewModel = viewModel,
                                        modifier = Modifier.weight(1.0f)
                                    )
                                }
                            }

                            composable(ROUTE_ADMIN_CONSOLE) {
                                Column(modifier = Modifier.fillMaxSize()) {
                                    // Custom header toolbar back option
                                    IconButton(
                                        onClick = { navController.popBackStack() },
                                        modifier = Modifier.padding(8.dp).testTag("admin_back_btn")
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = "Volver", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    AdminConsoleScreen(viewModel = viewModel)
                                }
                            }

                            composable(
                                route = "$ROUTE_STATION_DETAIL/{stationId}",
                                arguments = listOf(navArgument("stationId") { type = NavType.StringType })
                            ) { backStackEntry ->
                                val stationId = backStackEntry.arguments?.getString("stationId") ?: ""
                                Column(modifier = Modifier.fillMaxSize()) {
                                    // Custom header toolbar back option
                                    IconButton(
                                        onClick = { navController.popBackStack() },
                                        modifier = Modifier.padding(8.dp).testTag("station_back_btn")
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = Localization.get("back", lang), fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    StationDetailScreen(
                                        viewModel = viewModel,
                                        stationId = stationId
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
