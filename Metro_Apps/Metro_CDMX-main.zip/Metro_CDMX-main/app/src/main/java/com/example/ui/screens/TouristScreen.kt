package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.Localization
import com.example.viewmodel.TransitViewModel

@Composable
fun TouristScreen(
    viewModel: TransitViewModel,
    onNavigateToJourneyPlanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("tourist_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Title Hero Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFFE51C7C), Color(0xFFEB6105))
                        )
                    )
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.align(Alignment.CenterStart)) {
                    Text(
                        text = Localization.get("tourist_title", lang),
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Guía del Viajero • Visitor Information",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Icon(
                    imageVector = Icons.Default.TravelExplore,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.15f),
                    modifier = Modifier
                        .size(110.dp)
                        .align(Alignment.CenterEnd)
                        .offset(x = 10.dp, y = 5.dp)
                )
            }
        }

        // 2. Tarjeta de Movilidad (Integrated Card Details)
        item {
            TouristInfoCard(
                icon = Icons.Default.CreditCard,
                iconTint = Color(0xFFEB6105),
                title = Localization.get("card_info", lang),
                description = Localization.get("card_desc", lang)
            )
        }

        // 3. Airport Connections
        item {
            TouristInfoCard(
                icon = Icons.Default.FlightTakeoff,
                iconTint = Color(0xFF00579C),
                title = Localization.get("airport_conn", lang),
                description = Localization.get("airport_desc", lang)
            )
        }

        // 4. Metro Etiquette
        item {
            TouristInfoCard(
                icon = Icons.Default.Rule,
                iconTint = Color(0xFF009B77),
                title = Localization.get("etiquette", lang),
                description = Localization.get("etiquette_desc", lang)
            )
        }

        // 5. Popular Tours (Preprogrammed Routes)
        item {
            Text(
                text = Localization.get("popular_routes", lang),
                fontWeight = FontWeight.ExtraBold,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
            )
        }

        // Tour 1: Centro Histórico (Zócalo / Bellas Artes)
        item {
            PopularTourItem(
                title = Localization.get("route_1_title", lang),
                description = Localization.get("route_1_desc", lang),
                startStationName = "Bellas Artes",
                startStationId = "bellas_artes_m2",
                destStationName = "Pino Suárez",
                destStationId = "pino_suarez_m2",
                viewModel = viewModel,
                onNavigate = onNavigateToJourneyPlanner
            )
        }

        // Tour 2: Chapultepec Forest & Castle (Auditorio / Chapultepec)
        item {
            PopularTourItem(
                title = Localization.get("route_2_title", lang),
                description = Localization.get("route_2_desc", lang),
                startStationName = "Auditorio",
                startStationId = "auditorio_m7",
                destStationName = "Tacubaya",
                destStationId = "tacubaya_m7",
                viewModel = viewModel,
                onNavigate = onNavigateToJourneyPlanner
            )
        }

        // Tour 3: Coyoacán Historical Center
        item {
            PopularTourItem(
                title = Localization.get("route_3_title", lang),
                description = Localization.get("route_3_desc", lang),
                startStationName = "Zapata",
                startStationId = "zapata_m3",
                destStationName = "Universidad",
                destStationId = "universidad_m3",
                viewModel = viewModel,
                onNavigate = onNavigateToJourneyPlanner
            )
        }
    }
}

@Composable
fun TouristInfoCard(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    description: String
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(iconTint.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        tint = iconTint,
                        contentDescription = null,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 20.sp
            )
        }
    }
}

@Composable
fun PopularTourItem(
    title: String,
    description: String,
    startStationName: String,
    startStationId: String,
    destStationName: String,
    destStationId: String,
    viewModel: TransitViewModel,
    onNavigate: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                fontWeight = FontWeight.ExtraBold,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF49454F)
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Ruta sugerida:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF49454F)
                    )
                    Text(
                        text = "$startStationName ➔ $destStationName",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Button(
                    onClick = {
                        viewModel.setStartStation(startStationId)
                        viewModel.setDestStation(destStationId)
                        onNavigate()
                    },
                    shape = RoundedCornerShape(100.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Ver Ruta", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
