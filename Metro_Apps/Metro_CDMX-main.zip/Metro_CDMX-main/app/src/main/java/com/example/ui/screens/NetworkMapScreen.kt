package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.Localization
import com.example.ui.components.TransitMapCanvas
import com.example.viewmodel.TransitViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkMapScreen(
    viewModel: TransitViewModel,
    onNavigateToStationDetail: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val lines by viewModel.allLines.collectAsState()
    val stations by viewModel.allStations.collectAsState()

    // Filters and search states from ViewModel
    val filteredStations by viewModel.filteredStations.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val activeLineFilter by viewModel.lineFilter.collectAsState()

    val linesMap = remember(lines) { lines.associateBy { it.id } }

    // Map specific states
    var selectedMapStationId by remember { mutableStateOf<String?>(null) }
    var activeTab by remember { mutableStateOf(0) } // 0: Interactive Map, 1: Station Directory

    // Categorized lines filters
    val categories = listOf(
        Pair(null, Localization.get("all_systems", lang)),
        Pair("Metro", "Metro"),
        Pair("Metrobús", "Metrobús"),
        Pair("Cablebús", "Cablebús")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("network_map_screen")
    ) {
        // Tab Selector
        TabRow(selectedTabIndex = activeTab) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text(Localization.get("network_map", lang)) },
                icon = { Icon(imageVector = Icons.Default.Map, contentDescription = null) }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("Directorio") },
                icon = { Icon(imageVector = Icons.Default.List, contentDescription = null) }
            )
        }

        if (activeTab == 0) {
            // Interactive Map View
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.0f)
            ) {
                // The interactive canvas map
                TransitMapCanvas(
                    stations = stations,
                    lines = lines,
                    selectedStationId = selectedMapStationId,
                    onStationSelect = { stationId ->
                        selectedMapStationId = stationId
                    }
                )

                // Floating quick summary overlay
                if (selectedMapStationId != null) {
                    val focusedStation = stations.find { it.id == selectedMapStationId }
                    if (focusedStation != null) {
                        val focusedLine = linesMap[focusedStation.lineId]
                        val focusColor = Color(android.graphics.Color.parseColor(focusedLine?.colorHex ?: "#7F8C8D"))

                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(16.dp)
                        ) {
                            Card(
                                shape = RoundedCornerShape(24.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onNavigateToStationDetail(focusedStation.id)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(14.dp)
                                            .clip(CircleShape)
                                            .background(focusColor)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1.0f)) {
                                        Text(
                                            text = focusedStation.name,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Text(
                                            text = focusedLine?.name ?: "",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Ver detalles",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Default.ChevronRight,
                                            tint = MaterialTheme.colorScheme.primary,
                                            contentDescription = "Details"
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Top floating instructions
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Gestos: Pellizcar para Zoom • Arrastrar para Mover",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        } else {
            // Station Directory View
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.0f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Search field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text(Localization.get("station_search_placeholder", lang)) },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search") },
                    trailingIcon = if (searchQuery.isNotEmpty()) {
                        {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    } else null,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                )

                // Category filter row (chips)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { (typeVal, label) ->
                        val isSelected = (typeVal == null && activeLineFilter == null) || 
                                         (typeVal != null && activeLineFilter != null && linesMap[activeLineFilter!!]?.type == typeVal)

                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                if (typeVal == null) {
                                    viewModel.setLineFilter(null)
                                } else {
                                    // Set first line of this type as filter
                                    val matchLine = lines.find { it.type == typeVal }
                                    viewModel.setLineFilter(matchLine?.id)
                                }
                            },
                            label = { Text(text = label, fontSize = 11.sp) }
                        )
                    }
                }

                // Station list results
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(filteredStations) { station ->
                        val lineObj = linesMap[station.lineId]
                        val lineColor = Color(android.graphics.Color.parseColor(lineObj?.colorHex ?: "#7F8C8D"))

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onNavigateToStationDetail(station.id)
                                },
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(lineColor)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1.0f)) {
                                    Text(
                                        text = station.name,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = lineObj?.name ?: "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (station.isLiftAvailable) {
                                        Icon(
                                            imageVector = Icons.Default.Accessible,
                                            tint = Color(0xFF059669),
                                            contentDescription = "Accessible",
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                    }
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                        contentDescription = "Go"
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
