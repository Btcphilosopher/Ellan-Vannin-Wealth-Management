package com.example.data.repository

import com.example.data.local.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.PriorityQueue

enum class RouteCriteria {
    FASTEST,
    CHEAPEST,
    FEWEST_TRANSFERS
}

data class RouteStep(
    val stationId: String,
    val stationName: String,
    val lineId: String,
    val lineName: String,
    val lineColorHex: String,
    val isTransfer: Boolean,
    val estimatedTimeMinutes: Int
)

data class JourneyResult(
    val criteria: RouteCriteria,
    val steps: List<RouteStep>,
    val totalTimeMinutes: Int,
    val totalFareMxn: Double,
    val transferCount: Int,
    val lineChanges: List<String>,
    val walkingTransferDistanceMeters: Int
)

class TransitRepository(private val transitDao: TransitDao) {

    val allLines: Flow<List<LineEntity>> = transitDao.getAllLinesFlow()
    val allStations: Flow<List<StationEntity>> = transitDao.getAllStationsFlow()
    val allAlerts: Flow<List<AlertEntity>> = transitDao.getAllAlertsFlow()
    val allFavorites: Flow<List<FavoriteEntity>> = transitDao.getAllFavoritesFlow()
    val allSavedStations: Flow<List<SavedStationEntity>> = transitDao.getAllSavedStationsFlow()

    fun isStationSaved(stationId: String): Flow<Boolean> = transitDao.isStationSavedFlow(stationId)

    suspend fun saveStation(entity: SavedStationEntity) = transitDao.insertSavedStation(entity)
    suspend fun unsaveStation(stationId: String) = transitDao.deleteSavedStation(stationId)

    suspend fun addFavorite(label: String, from: StationEntity, to: StationEntity) {
        transitDao.insertFavorite(
            FavoriteEntity(
                label = label,
                fromStationId = from.id,
                fromStationName = from.name,
                toStationId = to.id,
                toStationName = to.name
            )
        )
    }

    suspend fun removeFavorite(id: Int) = transitDao.deleteFavorite(id)

    suspend fun addAlert(title: String, description: String, level: String, lineId: String?) {
        transitDao.insertAlert(
            AlertEntity(
                title = title,
                description = description,
                level = level,
                lineId = lineId
            )
        )
    }

    suspend fun removeAlert(id: Int) = transitDao.deleteAlert(id)

    suspend fun getStationById(stationId: String): StationEntity? = transitDao.getStationById(stationId)
    fun getStationByIdFlow(stationId: String): Flow<StationEntity?> = transitDao.getStationByIdFlow(stationId)

    suspend fun seedDatabaseIfNeeded() {
        val existingLines = transitDao.getAllLines()
        if (existingLines.isEmpty()) {
            transitDao.insertLines(TransitDataSeeder.getLines())
            transitDao.insertStations(TransitDataSeeder.getStations())
            transitDao.insertConnections(TransitDataSeeder.getConnections())
            for (alert in TransitDataSeeder.getInitialAlerts()) {
                transitDao.insertAlert(alert)
            }
        }
    }

    // Graph Journey Planner Routing Engine
    suspend fun planJourney(
        fromStationId: String,
        toStationId: String,
        criteria: RouteCriteria
    ): JourneyResult? {
        val stationsList = transitDao.getAllStations()
        val stationsMap = stationsList.associateBy { it.id }
        val connections = transitDao.getAllConnections()
        val linesList = transitDao.getAllLines()
        val linesMap = linesList.associateBy { it.id }

        if (!stationsMap.containsKey(fromStationId) || !stationsMap.containsKey(toStationId)) {
            return null
        }

        // Build Adjacency List
        val graph = mutableMapOf<String, MutableList<ConnectionEntity>>()
        for (connection in connections) {
            graph.getOrPut(connection.fromStationId) { mutableListOf() }.add(connection)
        }

        // Dijkstra implementation
        // PriorityQueue elements: DijkstraState(stationId, accumulatedCost, parentConnection, previousLineId)
        data class DijkstraState(
            val stationId: String,
            val priorityCost: Double, // Cost parameter used for sorting
            val accumulatedTimeSeconds: Int,
            val accumulatedCashMxn: Double,
            val accumulatedTransfers: Int,
            val lastLineId: String?,
            val path: List<ConnectionEntity>
        ) : Comparable<DijkstraState> {
            override fun compareTo(other: DijkstraState): Int =
                this.priorityCost.compareTo(other.priorityCost)
        }

        val queue = PriorityQueue<DijkstraState>()
        val minCostToNode = mutableMapOf<Pair<String, String?>, Double>() // (StationId, LastLineId) -> min cost

        // Initialize starting nodes
        queue.add(
            DijkstraState(
                stationId = fromStationId,
                priorityCost = 0.0,
                accumulatedTimeSeconds = 0,
                accumulatedCashMxn = if (stationsMap[fromStationId]?.lineId?.startsWith("metrobus") == true) 6.0 else 5.0,
                accumulatedTransfers = 0,
                lastLineId = stationsMap[fromStationId]?.lineId,
                path = emptyList()
            )
        )

        var finalState: DijkstraState? = null

        while (queue.isNotEmpty()) {
            val current = queue.poll()

            // If we reached the target, since we use priority queue, we found an optimal path according to criteria
            if (current.stationId == toStationId) {
                if (finalState == null || current.priorityCost < finalState.priorityCost) {
                    finalState = current
                }
                break
            }

            val key = Pair(current.stationId, current.lastLineId)
            if (minCostToNode.containsKey(key) && minCostToNode[key]!! <= current.priorityCost) {
                continue
            }
            minCostToNode[key] = current.priorityCost

            val edges = graph[current.stationId] ?: emptyList()
            for (edge in edges) {
                val nextStationId = edge.toStationId
                val edgeLineId = edge.lineId
                val isTransferEdge = edgeLineId == "transfer"

                val nextLineId = if (isTransferEdge) {
                    stationsMap[nextStationId]?.lineId
                } else {
                    edgeLineId
                }

                // Travel costs
                val edgeTime = edge.travelTimeSeconds
                val edgeCash = edge.cost

                // Calculate Penalties based on search criteria
                var penalty = 0.0
                var extraTime = edgeTime
                var extraCash = edgeCash
                var transferIncrement = 0

                // Transfer handling
                val isLineChange = current.lastLineId != null && nextLineId != null && current.lastLineId != nextLineId
                if (isLineChange || isTransferEdge) {
                    transferIncrement = 1
                    // Add standard time penalty for transferring in calculations
                    extraTime += 180 // 3 minutes walking & waiting
                }

                when (criteria) {
                    RouteCriteria.FASTEST -> {
                        // Priority is time in seconds
                        var costValue = current.accumulatedTimeSeconds + extraTime
                        if (isLineChange) {
                            costValue += 300 // Extra 5 min virtual penalty to avoid excessive transfers
                        }
                        penalty = costValue.toDouble()
                    }
                    RouteCriteria.CHEAPEST -> {
                        // Priority is fare cost
                        // Metro inside transfers are free. MB transfers cost money.
                        penalty = (current.accumulatedCashMxn + extraCash) * 10000.0 + (current.accumulatedTimeSeconds + extraTime)
                    }
                    RouteCriteria.FEWEST_TRANSFERS -> {
                        // Priority is transfers. 1 transfer = massive cost penalty
                        penalty = (current.accumulatedTransfers + transferIncrement) * 1000000.0 + (current.accumulatedTimeSeconds + extraTime)
                    }
                }

                val nextState = DijkstraState(
                    stationId = nextStationId,
                    priorityCost = penalty,
                    accumulatedTimeSeconds = current.accumulatedTimeSeconds + extraTime,
                    accumulatedCashMxn = current.accumulatedCashMxn + extraCash,
                    accumulatedTransfers = current.accumulatedTransfers + transferIncrement,
                    lastLineId = nextLineId,
                    path = current.path + edge
                )

                queue.add(nextState)
            }
        }

        val optimalState = finalState ?: return null

        // Convert optimal state path into a readable RouteStep sequence
        val stepsList = mutableListOf<RouteStep>()
        
        // Add start station step
        val startStation = stationsMap[fromStationId] ?: return null
        val startLine = linesMap[startStation.lineId]
        stepsList.add(
            RouteStep(
                stationId = startStation.id,
                stationName = startStation.name,
                lineId = startStation.lineId,
                lineName = startLine?.name ?: "Unknown Line",
                lineColorHex = startLine?.colorHex ?: "#7F8C8D",
                isTransfer = false,
                estimatedTimeMinutes = 0
            )
        )

        var accumulatedSeconds = 0
        for (i in optimalState.path.indices) {
            val edge = optimalState.path[i]
            accumulatedSeconds += edge.travelTimeSeconds
            val currentStation = stationsMap[edge.toStationId] ?: continue
            val isTransferEdge = edge.lineId == "transfer"
            val lineObj = linesMap[if (isTransferEdge) "transfer" else edge.lineId]

            stepsList.add(
                RouteStep(
                    stationId = currentStation.id,
                    stationName = currentStation.name,
                    lineId = if (isTransferEdge) "transfer" else edge.lineId,
                    lineName = if (isTransferEdge) "Transbordo" else (lineObj?.name ?: "Conexión"),
                    lineColorHex = if (isTransferEdge) "#7F8C8D" else (lineObj?.colorHex ?: "#7F8C8D"),
                    isTransfer = isTransferEdge,
                    estimatedTimeMinutes = Math.round(accumulatedSeconds / 60.0).toInt()
                )
            )
        }

        // Deduce lineChanges
        val lineChanges = optimalState.path.map { it.lineId }.filter { it != "transfer" }.distinct()

        return JourneyResult(
            criteria = criteria,
            steps = stepsList,
            totalTimeMinutes = Math.round(optimalState.accumulatedTimeSeconds / 60.0).toInt(),
            totalFareMxn = optimalState.accumulatedCashMxn,
            transferCount = optimalState.accumulatedTransfers,
            lineChanges = lineChanges,
            walkingTransferDistanceMeters = optimalState.accumulatedTransfers * 150 // estimate 150m per transfer
        )
    }
}
