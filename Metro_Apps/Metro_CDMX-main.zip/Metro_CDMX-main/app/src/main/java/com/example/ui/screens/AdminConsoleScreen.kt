package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.Localization
import com.example.viewmodel.TransitViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminConsoleScreen(
    viewModel: TransitViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val lines by viewModel.allLines.collectAsState()
    val alerts by viewModel.allAlerts.collectAsState()
    val isOperatorLoggedIn by viewModel.isOperatorLoggedIn.collectAsState()

    val linesMap = remember(lines) { lines.associateBy { it.id } }

    // Forms states
    var alertTitle by remember { mutableStateOf("") }
    var alertDescription by remember { mutableStateOf("") }
    var alertSeverity by remember { mutableStateOf("WARNING") } // INFO, WARNING, CRITICAL
    var selectedLineIdForAlert by remember { mutableStateOf<String?>(null) } // null is network-wide

    var lineSelectorExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("admin_console_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFF334155), Color(0xFF1E293B))
                        )
                    )
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.align(Alignment.CenterStart)) {
                    Text(
                        text = Localization.get("admin_title", lang),
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Portal de Control de Tránsito • Admin Portal",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.12f),
                    modifier = Modifier
                        .size(110.dp)
                        .align(Alignment.CenterEnd)
                        .offset(x = 10.dp, y = 5.dp)
                )
            }
        }

        // 2. Authentication Block
        if (!isOperatorLoggedIn) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Acceso Restringido",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = Localization.get("login_prompt", lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Button(
                            onClick = { viewModel.setOperatorLogin(true) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("login_operator_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.LockOpen, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = Localization.get("login_btn", lang))
                            }
                        }
                    }
                }
            }
        } else {
            // Operator dashboard when authenticated
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Consola de Operador Activa",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.titleMedium
                    )
                    
                    TextButton(
                        onClick = { viewModel.setOperatorLogin(false) },
                        modifier = Modifier.testTag("logout_operator_btn")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = Localization.get("logout_btn", lang))
                        }
                    }
                }
            }

            // Real-time alerting creation form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = Localization.get("publish_alert", lang),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // Alert Title
                        OutlinedTextField(
                            value = alertTitle,
                            onValueChange = { alertTitle = it },
                            label = { Text(text = Localization.get("alert_title_label", lang)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Alert Description
                        OutlinedTextField(
                            value = alertDescription,
                            onValueChange = { alertDescription = it },
                            label = { Text(text = Localization.get("alert_desc_label", lang)) },
                            minLines = 2,
                            maxLines = 4,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Severity selection chip
                        Column {
                            Text(
                                text = Localization.get("severity", lang),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("INFO", "WARNING", "CRITICAL").forEach { severity ->
                                    val isSelected = alertSeverity == severity
                                    val chipColor = when (severity) {
                                        "INFO" -> Color(0xFF0284C7)
                                        "WARNING" -> Color(0xFFD97706)
                                        "CRITICAL" -> Color(0xFFDC2626)
                                        else -> Color.Gray
                                    }

                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { alertSeverity = severity },
                                        label = { Text(text = severity, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSelected) Color.White else chipColor) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = chipColor
                                        )
                                    )
                                }
                            }
                        }

                        // Affected line drop-down selector
                        Column {
                            Text(
                                text = Localization.get("select_line", lang),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                            Box {
                                OutlinedTextField(
                                    value = selectedLineIdForAlert?.let { linesMap[it]?.name } ?: Localization.get("all_lines", lang),
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = {
                                        IconButton(onClick = { lineSelectorExpanded = true }) {
                                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Expand")
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                DropdownMenu(
                                    expanded = lineSelectorExpanded,
                                    onDismissRequest = { lineSelectorExpanded = false },
                                    modifier = Modifier.fillMaxWidth(0.9f)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text(Localization.get("all_lines", lang)) },
                                        onClick = {
                                            selectedLineIdForAlert = null
                                            lineSelectorExpanded = false
                                        }
                                    )
                                    lines.forEach { line ->
                                        DropdownMenuItem(
                                            text = { Text(line.name) },
                                            onClick = {
                                                selectedLineIdForAlert = line.id
                                                lineSelectorExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Submit Button
                        Button(
                            onClick = {
                                if (alertTitle.isNotEmpty() && alertDescription.isNotEmpty()) {
                                    viewModel.addAlert(
                                        title = alertTitle,
                                        description = alertDescription,
                                        level = alertSeverity,
                                        lineId = selectedLineIdForAlert
                                    )
                                    // Reset form
                                    alertTitle = ""
                                    alertDescription = ""
                                    alertSeverity = "WARNING"
                                    selectedLineIdForAlert = null
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("submit_alert_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Publish, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = Localization.get("publish_btn", lang))
                        }
                    }
                }
            }

            // List of currently active alerts with delete operations
            item {
                Text(
                    text = Localization.get("active_alerts_admin", lang),
                    fontWeight = FontWeight.ExtraBold,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            if (alerts.isEmpty()) {
                item {
                    Text(
                        text = "No hay alertas activas.",
                        modifier = Modifier.padding(horizontal = 4.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }
            }

            items(alerts) { alert ->
                val lineObj = alert.lineId?.let { linesMap[it] }
                val alertColor = when (alert.level) {
                    "INFO" -> Color(0xFF0284C7)
                    "WARNING" -> Color(0xFFD97706)
                    "CRITICAL" -> Color(0xFFDC2626)
                    else -> Color.Gray
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(alertColor)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1.0f)) {
                            Text(
                                text = alert.title,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = (lineObj?.let { "[${it.name}] " } ?: "") + alert.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = { viewModel.removeAlert(alert.id) }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                tint = MaterialTheme.colorScheme.error,
                                contentDescription = "Delete Alert"
                            )
                        }
                    }
                }
            }
        }
    }
}
