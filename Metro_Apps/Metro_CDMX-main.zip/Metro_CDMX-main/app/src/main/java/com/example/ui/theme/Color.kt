package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val MetroEmerald = Color(0xFF008542) // CDMX Emerald green accent (Professional Polish)
val MetroEmeraldDark = Color(0xFF005C2E)
val MetroCharcoal = Color(0xFF1D1B20) // Dark charcoal typography
val LightBackground = Color(0xFFF7F9F8)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF1D1B20)
val LightBorder = Color(0xFFE0E2E0)

// Dark Theme Colors
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkOnSurface = Color(0xFFF3F4F6)
val MetroEmeraldLight = Color(0xFF00E676)
val DarkBorder = Color(0xFF2D3748)

// CDMX System Line Colors (Official)
val Line1Color = Color(0xFFE51C7C)   // Pink
val Line2Color = Color(0xFF00579C)   // Blue
val Line3Color = Color(0xFF817F26)   // Olive Green
val Line4Color = Color(0xFF59B5DC)   // Light Blue
val Line5Color = Color(0xFFFEED01)   // Yellow
val Line6Color = Color(0xFFDD021E)   // Red
val Line7Color = Color(0xFFEB6105)   // Orange
val Line8Color = Color(0xFF009639)   // Green
val Line9Color = Color(0xFF754A23)   // Brown
val LineAColor = Color(0xFF992473)   // Purple
val LineBColor = Color(0xFF00A78F)   // Green/Gray
val Line12Color = Color(0xFFC29B38)  // Gold

// Other Transit Colors
val MetrobusColor = Color(0xFFE30613)  // Red
val CablebusColor = Color(0xFF009BD8)  // Sky Blue
val TrenLigeroColor = Color(0xFF0065AF) // Blue
val TrolebusColor = Color(0xFF003366)   // Dark Blue
val EcobiciColor = Color(0xFF8CC63F)    // Bright light green
val RtpColor = Color(0xFF2E7D32)        // Dark green
val SuburbanColor = Color(0xFF424242)    // Dark gray
