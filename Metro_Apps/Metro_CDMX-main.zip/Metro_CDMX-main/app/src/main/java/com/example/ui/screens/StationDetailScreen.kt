package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.StationEntity
import com.example.ui.components.Localization
import com.example.viewmodel.TransitViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationDetailScreen(
    viewModel: TransitViewModel,
    stationId: String,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val lines by viewModel.allLines.collectAsState()
    val linesMap = remember(lines) { lines.associateBy { it.id } }

    // Re-trigger select station on enter
    LaunchedEffect(stationId) {
        viewModel.selectStation(stationId)
    }

    val station by viewModel.selectedStation.collectAsState()
    val isSaved by viewModel.isStationSavedFlow(stationId).collectAsState(initial = false)

    if (station == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val currentStation = station!!
    val lineObj = linesMap[currentStation.lineId]
    val lineColor = Color(android.graphics.Color.parseColor(lineObj?.colorHex ?: "#7F8C8D"))

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("station_detail_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header with Line Color Code
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Color line indicator pill
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(lineColor)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = lineObj?.name ?: "",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = lineColor
                            )
                        }

                        // Save Station Heart Button
                        IconButton(
                            onClick = {
                                viewModel.toggleSaveStation(
                                    currentStation,
                                    isSaved,
                                    lineObj?.name ?: "Unknown",
                                    lineObj?.colorHex ?: "#7F8C8D"
                                )
                            },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                                .testTag("save_station_heart_btn")
                        ) {
                            Icon(
                                imageVector = if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                tint = if (isSaved) Color.Red else MaterialTheme.colorScheme.primary,
                                contentDescription = "Save Station"
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = currentStation.name,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.ExtraBold,
                        lineHeight = 36.sp
                    )

                    if (currentStation.isInterchange) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFE0F2FE))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.AltRoute, tint = Color(0xFF0369A1), modifier = Modifier.size(16.dp), contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = Localization.get("interchange", lang),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0369A1)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Accessibility & Facility Summary Quick Grid
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = Localization.get("facilities_avail", lang),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FacilityIndicator(
                            icon = Icons.Default.Elevator,
                            label = Localization.get("lifts", lang),
                            active = currentStation.isLiftAvailable
                        )
                        FacilityIndicator(
                            icon = Icons.Default.Escalator,
                            label = Localization.get("escalators", lang),
                            active = currentStation.isEscalatorAvailable
                        )
                        FacilityIndicator(
                            icon = Icons.Default.PedalBike,
                            label = "Bici",
                            active = currentStation.hasBikeParking
                        )
                        FacilityIndicator(
                            icon = Icons.Default.Accessible,
                            label = "Silla de Ruedas",
                            active = currentStation.isLiftAvailable
                        )
                    }
                }
            }
        }

        // 3. Technical Facilities Breakdown
        item {
            CardItemDetailSection(
                icon = Icons.Default.Settings,
                title = Localization.get("facilities", lang),
                description = currentStation.facilities.ifEmpty { "Información básica de andenes y taquillas disponible." }
            )
        }

        // 4. Accessibility Details
        item {
            CardItemDetailSection(
                icon = Icons.Default.Accessible,
                title = Localization.get("accessibility", lang),
                description = currentStation.accessibilityInfo.ifEmpty { "Paso accesible estándar. Rampa de acceso disponible en entradas principales." }
            )
        }

        // 5. Exits Locations
        item {
            CardItemDetailSection(
                icon = Icons.Default.Login,
                title = Localization.get("exits", lang),
                description = currentStation.exitLocations.ifEmpty { "Accesos distribuidos en esquinas de cruce principal." }
            )
        }

        // 6. Bus Connections
        item {
            CardItemDetailSection(
                icon = Icons.Default.DirectionsBus,
                title = Localization.get("nearby_bus", lang),
                description = currentStation.nearbyBusConnections.ifEmpty { "Servicios de RTP y microbuses locales disponibles en el paradero exterior." }
            )
        }

        // 7. Attractions
        item {
            CardItemDetailSection(
                icon = Icons.Default.Map,
                title = Localization.get("attractions", lang),
                description = currentStation.nearbyAttractions.ifEmpty { "Zonas residenciales y comerciales circundantes." }
            )
        }
    }
}

@Composable
fun FacilityIndicator(
    icon: ImageVector,
    label: String,
    active: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(72.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(
                    if (active) Color(0xFFD1FAE5) else Color(0xFFF1F5F9)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                tint = if (active) Color(0xFF059669) else Color(0xFF94A3B8),
                contentDescription = label,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = if (active) Color(0xFF065F46) else Color(0xFF64748B),
            lineHeight = 13.sp
        )
    }
}

@Composable
fun CardItemDetailSection(
    icon: ImageVector,
    title: String,
    description: String
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    tint = MaterialTheme.colorScheme.primary,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
