package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.AlertEntity
import com.example.data.local.LineEntity
import com.example.data.local.SavedStationEntity
import com.example.data.local.StationEntity
import com.example.data.repository.JourneyResult
import com.example.data.repository.RouteCriteria
import com.example.data.repository.TransitRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TransitViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TransitRepository(AppDatabase.getDatabase(application).transitDao())

    // Base flows from Database
    val allLines: StateFlow<List<LineEntity>> = repository.allLines
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val allStations: StateFlow<List<StationEntity>> = repository.allStations
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val allAlerts: StateFlow<List<AlertEntity>> = repository.allAlerts
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val allFavorites: StateFlow<List<com.example.data.local.FavoriteEntity>> = repository.allFavorites
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val allSavedStations: StateFlow<List<SavedStationEntity>> = repository.allSavedStations
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // User State Flows
    private val _currentLanguage = MutableStateFlow("ES") // "ES" or "EN"
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    private val _startStationId = MutableStateFlow<String?>(null)
    val startStationId: StateFlow<String?> = _startStationId.asStateFlow()

    private val _destStationId = MutableStateFlow<String?>(null)
    val destStationId: StateFlow<String?> = _destStationId.asStateFlow()

    private val _selectedRouteCriteria = MutableStateFlow(RouteCriteria.FASTEST)
    val selectedRouteCriteria: StateFlow<RouteCriteria> = _selectedRouteCriteria.asStateFlow()

    private val _journeyResult = MutableStateFlow<JourneyResult?>(null)
    val journeyResult: StateFlow<JourneyResult?> = _journeyResult.asStateFlow()

    private val _isCalculatingJourney = MutableStateFlow(false)
    val isCalculatingJourney: StateFlow<Boolean> = _isCalculatingJourney.asStateFlow()

    private val _selectedStationId = MutableStateFlow<String?>(null)
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    val selectedStation: StateFlow<StationEntity?> = _selectedStationId
        .flatMapLatest { id ->
            if (id != null) repository.getStationByIdFlow(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Admin / Operator simulation state
    private val _isOperatorLoggedIn = MutableStateFlow(false)
    val isOperatorLoggedIn: StateFlow<Boolean> = _isOperatorLoggedIn.asStateFlow()

    // Station search state for Station Directory
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _lineFilter = MutableStateFlow<String?>(null)
    val lineFilter: StateFlow<String?> = _lineFilter.asStateFlow()

    // Filtered Stations for search directory
    val filteredStations: StateFlow<List<StationEntity>> = combine(
        allStations,
        _searchQuery,
        _lineFilter
    ) { stations, query, filter ->
        stations.filter { station ->
            val matchesQuery = query.isEmpty() || station.name.contains(query, ignoreCase = true)
            val matchesFilter = filter == null || station.lineId == filter
            matchesQuery && matchesFilter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Initial Seed
        viewModelScope.launch {
            repository.seedDatabaseIfNeeded()
        }
    }

    fun setLanguage(lang: String) {
        _currentLanguage.value = lang
    }

    fun setStartStation(id: String?) {
        _startStationId.value = id
        triggerJourneyPlan()
    }

    fun setDestStation(id: String?) {
        _destStationId.value = id
        triggerJourneyPlan()
    }

    fun setRouteCriteria(criteria: RouteCriteria) {
        _selectedRouteCriteria.value = criteria
        triggerJourneyPlan()
    }

    fun swapStations() {
        val temp = _startStationId.value
        _startStationId.value = _destStationId.value
        _destStationId.value = temp
        triggerJourneyPlan()
    }

    private fun triggerJourneyPlan() {
        val start = _startStationId.value
        val dest = _destStationId.value
        if (start != null && dest != null) {
            if (start == dest) {
                _journeyResult.value = null
                return
            }
            _isCalculatingJourney.value = true
            viewModelScope.launch {
                val plan = repository.planJourney(start, dest, _selectedRouteCriteria.value)
                _journeyResult.value = plan
                _isCalculatingJourney.value = false
            }
        } else {
            _journeyResult.value = null
        }
    }

    fun saveFavoriteRoute(label: String) {
        val startId = _startStationId.value ?: return
        val destId = _destStationId.value ?: return
        viewModelScope.launch {
            val startEntity = repository.getStationById(startId) ?: return@launch
            val destEntity = repository.getStationById(destId) ?: return@launch
            repository.addFavorite(label, startEntity, destEntity)
        }
    }

    fun deleteFavoriteRoute(id: Int) {
        viewModelScope.launch {
            repository.removeFavorite(id)
        }
    }

    fun selectStation(stationId: String?) {
        _selectedStationId.value = stationId
    }

    fun toggleSaveStation(station: StationEntity, isSaved: Boolean, lineName: String, lineColorHex: String) {
        viewModelScope.launch {
            if (isSaved) {
                repository.unsaveStation(station.id)
            } else {
                repository.saveStation(
                    SavedStationEntity(
                        stationId = station.id,
                        stationName = station.name,
                        lineName = lineName,
                        lineColorHex = lineColorHex
                    )
                )
            }
        }
    }

    fun isStationSavedFlow(stationId: String): Flow<Boolean> {
        return repository.isStationSaved(stationId)
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setLineFilter(lineId: String?) {
        _lineFilter.value = lineId
    }

    // Admin operations
    fun setOperatorLogin(loggedIn: Boolean) {
        _isOperatorLoggedIn.value = loggedIn
    }

    fun addAlert(title: String, description: String, level: String, lineId: String?) {
        viewModelScope.launch {
            repository.addAlert(title, description, level, lineId)
        }
    }

    fun removeAlert(id: Int) {
        viewModelScope.launch {
            repository.removeAlert(id)
        }
    }
}
