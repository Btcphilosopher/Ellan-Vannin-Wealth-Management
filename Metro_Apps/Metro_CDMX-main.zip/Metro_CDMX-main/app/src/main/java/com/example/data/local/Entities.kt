package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lines")
data class LineEntity(
    @PrimaryKey val id: String,
    val name: String,
    val colorHex: String,
    val type: String // "Metro", "Metrobús", "Cablebús", "Tren Ligero", "Trolebús", "RTP", "Suburban Rail", "Ecobici"
)

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String, // Unique combination, e.g. "observatorio_metro_1" or just "observatorio"
    val name: String,
    val lineId: String,
    val latitude: Double,
    val longitude: Double,
    val facilities: String = "",
    val accessibilityInfo: String = "",
    val isLiftAvailable: Boolean = false,
    val isEscalatorAvailable: Boolean = false,
    val nearbyAttractions: String = "",
    val nearbyBusConnections: String = "",
    val exitLocations: String = "",
    val hasBikeParking: Boolean = false,
    val isInterchange: Boolean = false
)

@Entity(tableName = "connections")
data class ConnectionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fromStationId: String,
    val toStationId: String,
    val lineId: String, // e.g., "metro_1" or "transfer"
    val travelTimeSeconds: Int,
    val cost: Double
)

@Entity(tableName = "alerts")
data class AlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val level: String, // "INFO", "WARNING", "CRITICAL"
    val timestamp: Long = System.currentTimeMillis(),
    val lineId: String? = null // Specific line or null for system-wide
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val label: String,
    val fromStationId: String,
    val fromStationName: String,
    val toStationId: String,
    val toStationName: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_stations")
data class SavedStationEntity(
    @PrimaryKey val stationId: String,
    val stationName: String,
    val lineName: String,
    val lineColorHex: String
)
