package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.RouteCriteria
import com.example.ui.components.Localization
import com.example.viewmodel.TransitViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyPlannerScreen(
    viewModel: TransitViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val stations by viewModel.allStations.collectAsState()
    val lines by viewModel.allLines.collectAsState()

    val startStationId by viewModel.startStationId.collectAsState()
    val destStationId by viewModel.destStationId.collectAsState()
    val selectedCriteria by viewModel.selectedRouteCriteria.collectAsState()
    val journeyResult by viewModel.journeyResult.collectAsState()
    val isCalculating by viewModel.isCalculatingJourney.collectAsState()

    val linesMap = remember(lines) { lines.associateBy { it.id } }

    // Dropdown expanded states
    var startExpanded by remember { mutableStateOf(false) }
    var destExpanded by remember { mutableStateOf(false) }

    // Favorite Label dialogue
    var showFavoriteDialog by remember { mutableStateOf(false) }
    var favoriteLabel by remember { mutableStateOf("") }

    val selectedStartStation = stations.find { it.id == startStationId }
    val selectedDestStation = stations.find { it.id == destStationId }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("journey_planner_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Selector Cards
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = Localization.get("journey_planner", lang),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // Origin Selection Box
                    Box {
                        OutlinedTextField(
                            value = selectedStartStation?.name ?: "",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(text = Localization.get("origin", lang)) },
                            placeholder = { Text(text = Localization.get("select_origin", lang)) },
                            leadingIcon = { Icon(imageVector = Icons.Default.TripOrigin, contentDescription = "Origin") },
                            trailingIcon = {
                                IconButton(onClick = { startExpanded = true }) {
                                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Expand")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { startExpanded = true }
                                .testTag("origin_select_input")
                        )
                        DropdownMenu(
                            expanded = startExpanded,
                            onDismissRequest = { startExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            DropdownMenuItem(
                                text = { Text("-- Ninguno --") },
                                onClick = {
                                    viewModel.setStartStation(null)
                                    startExpanded = false
                                }
                            )
                            stations.forEach { station ->
                                val line = linesMap[station.lineId]
                                DropdownMenuItem(
                                    text = { Text("${station.name} (${line?.name ?: ""})") },
                                    onClick = {
                                        viewModel.setStartStation(station.id)
                                        startExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Swap Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = { viewModel.swapStations() },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                                .testTag("swap_stations_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                tint = MaterialTheme.colorScheme.primary,
                                contentDescription = Localization.get("swap", lang)
                            )
                        }
                    }

                    // Destination Selection Box
                    Box {
                        OutlinedTextField(
                            value = selectedDestStation?.name ?: "",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(text = Localization.get("destination", lang)) },
                            placeholder = { Text(text = Localization.get("select_dest", lang)) },
                            leadingIcon = { Icon(imageVector = Icons.Default.Place, contentDescription = "Destination") },
                            trailingIcon = {
                                IconButton(onClick = { destExpanded = true }) {
                                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Expand")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { destExpanded = true }
                                .testTag("dest_select_input")
                        )
                        DropdownMenu(
                            expanded = destExpanded,
                            onDismissRequest = { destExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            DropdownMenuItem(
                                text = { Text("-- Ninguno --") },
                                onClick = {
                                    viewModel.setDestStation(null)
                                    destExpanded = false
                                }
                            )
                            stations.forEach { station ->
                                val line = linesMap[station.lineId]
                                DropdownMenuItem(
                                    text = { Text("${station.name} (${line?.name ?: ""})") },
                                    onClick = {
                                        viewModel.setDestStation(station.id)
                                        destExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Criteria Filters
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RouteCriteria.values().forEach { criteria ->
                    val isSelected = selectedCriteria == criteria
                    val label = when (criteria) {
                        RouteCriteria.FASTEST -> Localization.get("fastest", lang)
                        RouteCriteria.CHEAPEST -> Localization.get("cheapest", lang)
                        RouteCriteria.FEWEST_TRANSFERS -> Localization.get("fewest_transfers", lang)
                    }

                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setRouteCriteria(criteria) },
                        label = { Text(text = label, fontSize = 12.sp) },
                        leadingIcon = if (isSelected) {
                            { Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else null,
                        modifier = Modifier.weight(1.0f)
                    )
                }
            }
        }

        // 3. Calculating Indicator
        if (isCalculating) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        // 4. Journey Result Section
        if (journeyResult != null) {
            val result = journeyResult!!
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Resumen de Ruta",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )

                            Button(
                                onClick = { showFavoriteDialog = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = Localization.get("save", lang), fontSize = 12.sp)
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(12.dp))

                        // Stats Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = Localization.get("estimated_time", lang), style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "${result.totalTimeMinutes} ${Localization.get("mins", lang)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Column {
                                Text(text = Localization.get("total_fare", lang), style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "\$${String.format("%.2f", result.totalFareMxn)} ${Localization.get("mxn", lang)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Column {
                                Text(text = Localization.get("transfers", lang), style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "${result.transferCount}",
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // Route step by step items
            item {
                Text(
                    text = Localization.get("route_instructions", lang).uppercase(),
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF49454F),
                    fontSize = 12.sp,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            itemsIndexed(result.steps) { index, step ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Line indicator bullet with customized side rail
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(36.dp)
                    ) {
                        val bulletColor = Color(android.graphics.Color.parseColor(step.lineColorHex))
                        Box(
                            modifier = Modifier
                                .size(if (step.isTransfer) 18.dp else 14.dp)
                                .clip(CircleShape)
                                .background(bulletColor)
                                .border(
                                    width = if (step.isTransfer) 3.dp else 0.dp,
                                    color = if (step.isTransfer) Color.White else Color.Transparent,
                                    shape = CircleShape
                                )
                        )
                        
                        if (index < result.steps.lastIndex) {
                            Spacer(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(40.dp)
                                    .background(bulletColor)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(
                        modifier = Modifier.weight(1.0f)
                    ) {
                        Text(
                            text = step.stationName,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = step.lineName,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                            if (step.estimatedTimeMinutes > 0) {
                                Text(
                                    text = " • ${step.estimatedTimeMinutes} min",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    if (step.isTransfer) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFE2E8F0))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "TRANSBORDO",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF475569)
                            )
                        }
                    }
                }
            }
        } else if (selectedStartStation != null && selectedDestStation != null && selectedStartStation.id == selectedDestStation.id) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Text(
                        text = Localization.get("no_route", lang),
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // Save Favorite Journey dialog
    if (showFavoriteDialog) {
        AlertDialog(
            onDismissRequest = { showFavoriteDialog = false },
            title = { Text(text = Localization.get("save_this_route", lang)) },
            text = {
                Column {
                    Text(text = "Elige una etiqueta identificadora para guardar esta ruta:")
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = favoriteLabel,
                        onValueChange = { favoriteLabel = it },
                        singleLine = true,
                        placeholder = { Text(text = Localization.get("route_label_placeholder", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (favoriteLabel.isNotEmpty()) {
                            viewModel.saveFavoriteRoute(favoriteLabel)
                            showFavoriteDialog = false
                            favoriteLabel = ""
                        }
                    }
                ) {
                    Text(text = Localization.get("save", lang))
                }
            },
            dismissButton = {
                TextButton(onClick = { showFavoriteDialog = false }) {
                    Text(text = Localization.get("cancel", lang))
                }
            }
        )
    }
}
