package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import com.example.data.local.LineEntity
import com.example.data.local.StationEntity
import com.example.data.repository.TransitDataSeeder

@Composable
fun TransitMapCanvas(
    stations: List<StationEntity>,
    lines: List<LineEntity>,
    selectedStationId: String? = null,
    highlightedStationIds: List<String> = emptyList(),
    onStationSelect: (String) -> Unit
) {
    val linesMap = remember(lines) { lines.associateBy { it.id } }

    // Coordinates normalization bounds based on real station coordinates in TransitDataSeeder
    val minLat = 19.30
    val maxLat = 19.54
    val minLng = -99.22
    val maxLng = -99.07

    // Gesture States for zoom & pan
    var scale by remember { mutableStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.6f, 5.0f)
                    offset = if (scale <= 1.0f) Offset.Zero else offset + pan
                }
            }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        ) {
            val width = size.width
            val height = size.height

            // Helper to project Lat/Lng to Canvas pixels (Mercator-ish simplified projection)
            // Note: Latitude needs to be inverted because Y is 0 at the top
            fun project(lat: Double, lng: Double): Offset {
                val xNorm = (lng - minLng) / (maxLng - minLng)
                val yNorm = 1.0 - (lat - minLat) / (maxLat - minLat)

                // Add 10% padding to avoid drawing on edges
                val pxX = (0.1 + xNorm * 0.8) * width
                val pxY = (0.1 + yNorm * 0.8) * height
                return Offset(pxX.toFloat(), pxY.toFloat())
            }

            // 1. Draw Connection Lines
            val connectionsList = TransitDataSeeder.getConnections()
            for (conn in connectionsList) {
                val fromStation = stations.find { it.id == conn.fromStationId }
                val toStation = stations.find { it.id == conn.toStationId }

                if (fromStation != null && toStation != null) {
                    val p1 = project(fromStation.latitude, fromStation.longitude)
                    val p2 = project(toStation.latitude, toStation.longitude)

                    val isTransfer = conn.lineId == "transfer"
                    val line = linesMap[conn.lineId]
                    val lineColor = if (isTransfer) {
                        Color(0xFF7F8C8D) // Gray for transfer walking
                    } else {
                        Color(android.graphics.Color.parseColor(line?.colorHex ?: "#BDC3C7"))
                    }

                    if (isTransfer) {
                        // Dashed transfer line
                        val dashPathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(
                            floatArrayOf(10f, 10f), 0f
                        )
                        drawLine(
                            color = lineColor,
                            start = p1,
                            end = p2,
                            strokeWidth = 4f,
                            pathEffect = dashPathEffect
                        )
                    } else {
                        drawLine(
                            color = lineColor,
                            start = p1,
                            end = p2,
                            strokeWidth = 8f
                        )
                    }
                }
            }

            // 2. Draw Stations
            for (station in stations) {
                val pos = project(station.latitude, station.longitude)
                val line = linesMap[station.lineId]
                val lineColor = Color(android.graphics.Color.parseColor(line?.colorHex ?: "#BDC3C7"))

                val isHighlighted = highlightedStationIds.contains(station.id)
                val isSelected = station.id == selectedStationId

                // Base outer size
                val baseRadius = if (station.isInterchange) 12f else 8f
                val radius = when {
                    isSelected -> baseRadius * 2f
                    isHighlighted -> baseRadius * 1.6f
                    else -> baseRadius
                }

                // Draw background circle (white backing)
                drawCircle(
                    color = Color.White,
                    radius = radius + 3f,
                    center = pos
                )

                // Draw outer ring if interchange, else solid circle
                if (station.isInterchange) {
                    drawCircle(
                        color = if (isSelected) Color(0xFF009B77) else lineColor,
                        radius = radius,
                        center = pos,
                        style = Stroke(width = 4f)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = radius - 4f,
                        center = pos
                    )
                } else {
                    drawCircle(
                        color = if (isSelected) Color(0xFF009B77) else lineColor,
                        radius = radius,
                        center = pos
                    )
                }

                // If zoom level is high enough, draw station labels
                if (scale >= 1.5f || isSelected || isHighlighted) {
                    // Compose Canvas doesn't draw Text easily without Native Canvas, let's use drawContext.canvas.nativeCanvas
                    drawContext.canvas.nativeCanvas.apply {
                        val paint = android.graphics.Paint().apply {
                            color = if (isSelected) {
                                android.graphics.Color.parseColor("#009B77")
                            } else {
                                android.graphics.Color.parseColor("#1C1D1E")
                            }
                            textSize = if (isSelected) 28f else 22f
                            isFakeBoldText = isSelected || isHighlighted
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                        
                        // Draw shadow backing for text readability
                        val shadowPaint = android.graphics.Paint(paint).apply {
                            color = android.graphics.Color.WHITE
                            strokeWidth = 6f
                            style = android.graphics.Paint.Style.STROKE
                        }
                        
                        val yOffset = if (station.isInterchange) 25f else 20f
                        drawText(station.name, pos.x, pos.y - yOffset, shadowPaint)
                        drawText(station.name, pos.x, pos.y - yOffset, paint)
                    }
                }
            }
        }
    }
}
