package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TransitDao {
    // Lines
    @Query("SELECT * FROM lines")
    fun getAllLinesFlow(): Flow<List<LineEntity>>

    @Query("SELECT * FROM lines")
    suspend fun getAllLines(): List<LineEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLines(lines: List<LineEntity>)

    // Stations
    @Query("SELECT * FROM stations ORDER BY name ASC")
    fun getAllStationsFlow(): Flow<List<StationEntity>>

    @Query("SELECT * FROM stations ORDER BY name ASC")
    suspend fun getAllStations(): List<StationEntity>

    @Query("SELECT * FROM stations WHERE lineId = :lineId ORDER BY name ASC")
    fun getStationsByLineFlow(lineId: String): Flow<List<StationEntity>>

    @Query("SELECT * FROM stations WHERE id = :stationId LIMIT 1")
    suspend fun getStationById(stationId: String): StationEntity?

    @Query("SELECT * FROM stations WHERE id = :stationId LIMIT 1")
    fun getStationByIdFlow(stationId: String): Flow<StationEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)

    // Connections
    @Query("SELECT * FROM connections")
    suspend fun getAllConnections(): List<ConnectionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConnections(connections: List<ConnectionEntity>)

    // Alerts
    @Query("SELECT * FROM alerts ORDER BY timestamp DESC")
    fun getAllAlertsFlow(): Flow<List<AlertEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: AlertEntity)

    @Query("DELETE FROM alerts WHERE id = :alertId")
    suspend fun deleteAlert(alertId: Int)

    // Favorites
    @Query("SELECT * FROM favorites ORDER BY timestamp DESC")
    fun getAllFavoritesFlow(): Flow<List<FavoriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE id = :favoriteId")
    suspend fun deleteFavorite(favoriteId: Int)

    // Saved Stations
    @Query("SELECT * FROM saved_stations")
    fun getAllSavedStationsFlow(): Flow<List<SavedStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedStation(savedStation: SavedStationEntity)

    @Query("DELETE FROM saved_stations WHERE stationId = :stationId")
    suspend fun deleteSavedStation(stationId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM saved_stations WHERE stationId = :stationId)")
    fun isStationSavedFlow(stationId: String): Flow<Boolean>
}
