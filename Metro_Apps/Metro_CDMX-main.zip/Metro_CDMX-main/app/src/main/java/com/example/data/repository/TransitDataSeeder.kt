package com.example.data.repository

import com.example.data.local.LineEntity
import com.example.data.local.StationEntity
import com.example.data.local.ConnectionEntity
import com.example.data.local.AlertEntity

object TransitDataSeeder {
    fun getLines(): List<LineEntity> {
        return listOf(
            LineEntity("metro_1", "Línea 1 (Metro)", "#E51C7C", "Metro"),
            LineEntity("metro_2", "Línea 2 (Metro)", "#00579C", "Metro"),
            LineEntity("metro_3", "Línea 3 (Metro)", "#817F26", "Metro"),
            LineEntity("metro_4", "Línea 4 (Metro)", "#59B5DC", "Metro"),
            LineEntity("metro_5", "Línea 5 (Metro)", "#FEED01", "Metro"),
            LineEntity("metro_6", "Línea 6 (Metro)", "#DD021E", "Metro"),
            LineEntity("metro_7", "Línea 7 (Metro)", "#EB6105", "Metro"),
            LineEntity("metro_8", "Línea 8 (Metro)", "#009639", "Metro"),
            LineEntity("metro_9", "Línea 9 (Metro)", "#754A23", "Metro"),
            LineEntity("metro_A", "Línea A (Metro)", "#992473", "Metro"),
            LineEntity("metro_B", "Línea B (Metro)", "#00A78F", "Metro"),
            LineEntity("metro_12", "Línea 12 (Metro)", "#C29B38", "Metro"),
            
            LineEntity("metrobus_1", "Línea 1 (Metrobús)", "#E30613", "Metrobús"),
            LineEntity("cablebus_1", "Línea 1 (Cablebús)", "#009BD8", "Cablebús"),
            LineEntity("cablebus_2", "Línea 2 (Cablebús)", "#009BD8", "Cablebús"),
            LineEntity("tren_ligero", "Tren Ligero", "#0065AF", "Tren Ligero"),
            LineEntity("trolebus_1", "Trolebús Cero Emisiones", "#003366", "Trolebús"),
            LineEntity("rtp_1", "Ruta 200 (RTP)", "#2E7D32", "RTP"),
            LineEntity("suburban", "Ferrocarril Suburbano", "#424242", "Suburban Rail")
        )
    }

    fun getStations(): List<StationEntity> {
        return listOf(
            // Line 1 (Metro)
            StationEntity("observatorio_m1", "Observatorio", "metro_1", 19.3982, -99.2004, "Elevators, Escalators, Bike parking", "Accessible steps", true, true, "Terminal Central de Poniente", "RTP, Taxis", "Av. Río de Tacubaya", true, false),
            StationEntity("tacubaya_m1", "Tacubaya", "metro_1", 19.4032, -99.1872, "Escalators, Restrooms", "Tactile flooring", false, true, "Parque Lira", "Metrobus L2, Trolebús L5", "Av. Jalisco", false, true),
            StationEntity("balderas_m1", "Balderas", "metro_1", 19.4273, -99.1491, "Escalators, Cyber center", "Partial access", false, true, "La Ciudadela, Library of Mexico", "Metrobus L3", "Av. Balderas", true, true),
            StationEntity("salto_agua_m1", "Salto del Agua", "metro_1", 19.4270, -99.1420, "Escalators", "Tactile flooring", false, true, "Historic Fountain of Salto del Agua", "Trolebús L1", "Eje Central Lázaro Cárdenas", false, true),
            StationEntity("pino_suarez_m1", "Pino Suárez", "metro_1", 19.4262, -99.1330, "Escalators, Aztec Pyramid (Ehécatl)", "Full access", true, true, "Historic Center, Zócalo access", "RTP", "José María Izazaga", false, true),
            StationEntity("san_lazaro_m1", "San Lázaro", "metro_1", 19.4303, -99.1148, "Elevators, Escalators, Restrooms", "Full access", true, true, "TAPO Bus Terminal, Legislative Palace", "Metrobus L4, MB L5", "Calz. Ignacio Zaragoza", true, true),
            StationEntity("pantitlan_m1", "Pantitlán", "metro_1", 19.4162, -99.0742, "Escalators, Bike Parking", "Step-free ramp", true, true, "Pantitlán Multimodal Center", "MB L4, RTP, State of Mexico Buses", "Av. Río Churubusco", true, true),

            // Line 2 (Metro)
            StationEntity("cuatro_caminos_m2", "Cuatro Caminos", "metro_2", 19.4597, -99.2158, "Escalators, Large terminal shops", "Partial access", false, true, "Toreo Parque Central", "State of Mexico buses", "Calz. San Bartolo Naucalpan", false, false),
            StationEntity("tacuba_m2", "Tacuba", "metro_2", 19.4589, -99.1812, "Escalators, Restrooms", "Full access", true, true, "Parroquia de San Gabriel Arcángel", "RTP", "Calz. México-Tacuba", true, true),
            StationEntity("hidalgo_m2", "Hidalgo", "metro_2", 19.4373, -99.1473, "Elevators, Escalators", "Full access", true, true, "Alameda Central, San Hipólito Church", "Metrobus L1, MB L3, MB L4", "Av. Hidalgo", false, true),
            StationEntity("bellas_artes_m2", "Bellas Artes", "metro_2", 19.4362, -99.1412, "Elevators, Escalators", "Full access", true, true, "Palacio de Bellas Artes, Torre Latinoamericana", "Trolebús L1", "Av. Juárez", false, true),
            StationEntity("pino_suarez_m2", "Pino Suárez", "metro_2", 19.4262, -99.1330, "Escalators, Aztec Pyramid (Ehécatl)", "Full access", true, true, "Historic Center, Zócalo access", "RTP", "José María Izazaga", false, true),
            StationEntity("chabacano_m2", "Chabacano", "metro_2", 19.4085, -99.1359, "Elevators, Escalators", "Full access", true, true, "Chabacano shopping district", "RTP", "Calz. de Tlalpan", true, true),
            StationEntity("tasquena_m2", "Tasqueña", "metro_2", 19.3442, -99.1428, "Elevators, Escalators, Bike parking", "Accessible steps", true, true, "Terminal de Autobuses del Sur (South Terminal)", "Tren Ligero, Trolebús L1", "Calz. de Tlalpan", true, true),

            // Line 3 (Metro)
            StationEntity("indios_verdes_m3", "Indios Verdes", "metro_3", 19.4975, -99.1197, "Elevators, Escalators, Bike parking", "Full access", true, true, "Indios Verdes Monuments", "Metrobus L1, MB L7, Cablebus L1", "Av. Insurgentes Norte", true, true),
            StationEntity("la_raza_m3", "La Raza", "metro_3", 19.4697, -99.1362, "Escalators, Science and Culture Tunnel", "Partial access", false, true, "La Raza Monument, Science Tunnel", "Metrobus L1, MB L3", "Av. Insurgentes Norte", false, true),
            StationEntity("guerrero_m3", "Guerrero", "metro_3", 19.4448, -99.1448, "Escalators, Restrooms", "Step-free ramp", false, true, "Los Ángeles Church", "Metrobus L3", "Eje 1 Norte", false, true),
            StationEntity("hidalgo_m3", "Hidalgo", "metro_3", 19.4373, -99.1473, "Elevators, Escalators", "Full access", true, true, "Alameda Central, San Hipólito Church", "Metrobus L1, MB L3, MB L4", "Av. Hidalgo", false, true),
            StationEntity("balderas_m3", "Balderas", "metro_3", 19.4273, -99.1491, "Escalators, Cyber center", "Partial access", false, true, "La Ciudadela, Library of Mexico", "Metrobus L3", "Av. Balderas", true, true),
            StationEntity("centro_medico_m3", "Centro Médico", "metro_3", 19.4069, -99.1554, "Escalators", "Partial access", false, true, "Siglo XXI Medical Center, Delta Park", "Metrobus L3", "Av. Cuauhtémoc", false, true),
            StationEntity("zapata_m3", "Zapata", "metro_3", 19.3708, -99.1648, "Elevators, Escalators, Museum of Caricature", "Full access", true, true, "Zapata Market, Coyoacán Gateway", "Metrobus L3, Trolebús D", "Av. Universidad", true, true),
            StationEntity("universidad_m3", "Universidad", "metro_3", 19.3242, -99.1739, "Elevators, Bike parking", "Full access", true, false, "UNAM Main Campus, Universum Museum", "Pumabús (UNAM Shuttle)", "Av. Antonio Delfín Madrigal", true, false),

            // Line 7 (Metro)
            StationEntity("el_rosario_m7", "El Rosario", "metro_7", 19.5042, -99.2003, "Elevators, Escalators, Bike parking", "Full access", true, true, "El Rosario Town Hall", "RTP", "Av. Tierra de Fuego", true, true),
            StationEntity("tacuba_m7", "Tacuba", "metro_7", 19.4589, -99.1812, "Escalators, Restrooms", "Full access", true, true, "Parroquia de San Gabriel Arcángel", "RTP", "Calz. México-Tacuba", true, true),
            StationEntity("auditorio_m7", "Auditorio", "metro_7", 19.4258, -99.1862, "Elevators, Escalators, Audio Library", "Full access", true, true, "Auditorio Nacional, Chapultepec Castle, Campo Marte", "Metrobus L7", "Paseo de la Reforma", false, false),
            StationEntity("tacubaya_m7", "Tacubaya", "metro_7", 19.4032, -99.1872, "Escalators, Restrooms", "Tactile flooring", false, true, "Parque Lira", "Metrobus L2, Trolebús L5", "Av. Jalisco", false, true),
            StationEntity("mixcoac_m7", "Mixcoac", "metro_7", 19.3761, -99.1878, "Elevators, Escalators, Metro Museum", "Full access", true, true, "Metro Museum, Mixcoac Plaza", "RTP", "Av. Revolución", true, true),
            StationEntity("barranca_muerto_m7", "Barranca del Muerto", "metro_7", 19.3601, -99.1895, "Escalators", "Partial access", false, true, "Portal San Ángel, San Jacinto Square", "RTP", "Av. Revolución", false, false),

            // Line 9 (Metro)
            StationEntity("tacubaya_m9", "Tacubaya", "metro_9", 19.4032, -99.1872, "Escalators, Restrooms", "Tactile flooring", false, true, "Parque Lira", "Metrobus L2, Trolebús L5", "Av. Jalisco", false, true),
            StationEntity("centro_medico_m9", "Centro Médico", "metro_9", 19.4069, -99.1554, "Escalators", "Partial access", false, true, "Siglo XXI Medical Center, Delta Park", "Metrobus L3", "Av. Cuauhtémoc", false, true),
            StationEntity("chabacano_m9", "Chabacano", "metro_9", 19.4085, -99.1359, "Elevators, Escalators", "Full access", true, true, "Chabacano shopping district", "RTP", "Calz. de Tlalpan", true, true),
            StationEntity("pantitlan_m9", "Pantitlán", "metro_9", 19.4162, -99.0742, "Escalators, Bike Parking", "Step-free ramp", true, true, "Pantitlán Multimodal Center", "MB L4, RTP, State of Mexico Buses", "Av. Río Churubusco", true, true),

            // Line 12 (Metro)
            StationEntity("mixcoac_m12", "Mixcoac", "metro_12", 19.3761, -99.1878, "Elevators, Escalators, Metro Museum", "Full access", true, true, "Metro Museum, Mixcoac Plaza", "RTP", "Av. Revolución", true, true),
            StationEntity("zapata_m12", "Zapata", "metro_12", 19.3708, -99.1648, "Elevators, Escalators, Museum of Caricature", "Full access", true, true, "Zapata Market, Coyoacán Gateway", "Metrobus L3, Trolebús D", "Av. Universidad", true, true),
            StationEntity("ermita_m12", "Ermita", "metro_12", 19.3619, -99.1428, "Elevators, Escalators", "Full access", true, true, "Ermita historic neighborhood", "Trolebús L1", "Calz. de Tlalpan", false, true),
            StationEntity("atlalilco_m12", "Atlalilco", "metro_12", 19.3562, -99.1017, "Elevators, Escalators", "Full access", true, true, "Iztapalapa Town Hall access", "RTP", "Calz. Ermita Iztapalapa", false, true),

            // Metrobús Line 1
            StationEntity("indios_verdes_mb1", "Indios Verdes (Metrobús)", "metrobus_1", 19.4975, -99.1197, "Level-boarding platform, Elevators", "Full wheelchair access", true, false, "Indios Verdes Monuments", "Metro L3, Cablebus L1", "Av. Insurgentes Norte", true, true),
            StationEntity("revolucion_mb1", "Revolución (Metrobús)", "metrobus_1", 19.4392, -99.1528, "Level boarding", "Full wheelchair access", true, false, "Revolution Monument", "Metro L2", "Av. Insurgentes", false, false),
            StationEntity("glorieta_insurgentes_mb1", "Insurgentes (Metrobús)", "metrobus_1", 19.4239, -99.1633, "Level boarding, escalators nearby", "Full wheelchair access", true, true, "Zona Rosa, Glorieta de Insurgentes", "Metro L1", "Av. Insurgentes", false, true),
            StationEntity("chilpancingo_mb1", "Chilpancingo (Metrobús)", "metrobus_1", 19.4061, -99.1683, "Level boarding", "Full wheelchair access", true, false, "Parque México, Condesa District", "Metro L9", "Av. Insurgentes", true, true),

            // Cablebús Line 1
            StationEntity("indios_verdes_cb1", "Indios Verdes (Cablebús)", "cablebus_1", 19.4975, -99.1197, "Elevators, Cabin step-free boarding", "Full accessibility", true, false, "Indios Verdes Multimodal", "Metro L3, MB L1", "Av. Insurgentes Norte", true, true),
            StationEntity("cuautepec_cb1", "Cuautepec", "cablebus_1", 19.5312, -99.1232, "Elevators", "Full accessibility", true, false, "Cuautepec Valley Lookout", "Local Microbuses", "Av. Venustiano Carranza", false, false),

            // Tren Ligero
            StationEntity("tasquena_tl", "Tasqueña (Tren Ligero)", "tren_ligero", 19.3442, -99.1428, "Elevators, Level boarding", "Full access", true, false, "Sur Bus Terminal", "Metro L2, Trolebús L1", "Calz. de Tlalpan", true, true),
            StationEntity("estadio_azteca_tl", "Estadio Azteca", "tren_ligero", 19.3031, -99.1508, "Ramps, Level boarding", "Full access", true, false, "Estadio Azteca (World Cup Stadium)", "RTP, Colectivos", "Calz. de Tlalpan", false, false),

            // Suburban Rail
            StationEntity("buenavista_sub", "Buenavista (Suburbano)", "suburban", 19.4462, -99.1528, "Elevators, Escalators, Mall integrated", "Full access", true, true, "Forum Buenavista Mall, Vasconcelos Library", "Metro L8, MB L1, MB L3", "Av. Insurgentes Norte", true, true)
        )
    }

    fun getConnections(): List<ConnectionEntity> {
        return listOf(
            // Line 1 (Metro) consecutive paths
            ConnectionEntity(0, "observatorio_m1", "tacubaya_m1", "metro_1", 120, 5.0),
            ConnectionEntity(0, "tacubaya_m1", "observatorio_m1", "metro_1", 120, 5.0),
            ConnectionEntity(0, "tacubaya_m1", "balderas_m1", "metro_1", 240, 5.0),
            ConnectionEntity(0, "balderas_m1", "tacubaya_m1", "metro_1", 240, 5.0),
            ConnectionEntity(0, "balderas_m1", "salto_agua_m1", "metro_1", 80, 5.0),
            ConnectionEntity(0, "salto_agua_m1", "balderas_m1", "metro_1", 80, 5.0),
            ConnectionEntity(0, "salto_agua_m1", "pino_suarez_m1", "metro_1", 100, 5.0),
            ConnectionEntity(0, "pino_suarez_m1", "salto_agua_m1", "metro_1", 100, 5.0),
            ConnectionEntity(0, "pino_suarez_m1", "san_lazaro_m1", "metro_1", 300, 5.0),
            ConnectionEntity(0, "san_lazaro_m1", "pino_suarez_m1", "metro_1", 300, 5.0),
            ConnectionEntity(0, "san_lazaro_m1", "pantitlan_m1", "metro_1", 360, 5.0),
            ConnectionEntity(0, "pantitlan_m1", "san_lazaro_m1", "metro_1", 360, 5.0),

            // Line 2 (Metro)
            ConnectionEntity(0, "cuatro_caminos_m2", "tacuba_m2", "metro_2", 180, 5.0),
            ConnectionEntity(0, "tacuba_m2", "cuatro_caminos_m2", "metro_2", 180, 5.0),
            ConnectionEntity(0, "tacuba_m2", "hidalgo_m2", "metro_2", 240, 5.0),
            ConnectionEntity(0, "hidalgo_m2", "tacuba_m2", "metro_2", 240, 5.0),
            ConnectionEntity(0, "hidalgo_m2", "bellas_artes_m2", "metro_2", 90, 5.0),
            ConnectionEntity(0, "bellas_artes_m2", "hidalgo_m2", "metro_2", 90, 5.0),
            ConnectionEntity(0, "bellas_artes_m2", "pino_suarez_m2", "metro_2", 150, 5.0),
            ConnectionEntity(0, "pino_suarez_m2", "bellas_artes_m2", "metro_2", 150, 5.0),
            ConnectionEntity(0, "pino_suarez_m2", "chabacano_m2", "metro_2", 130, 5.0),
            ConnectionEntity(0, "chabacano_m2", "pino_suarez_m2", "metro_2", 130, 5.0),
            ConnectionEntity(0, "chabacano_m2", "tasquena_m2", "metro_2", 360, 5.0),
            ConnectionEntity(0, "tasquena_m2", "chabacano_m2", "metro_2", 360, 5.0),

            // Line 3 (Metro)
            ConnectionEntity(0, "indios_verdes_m3", "la_raza_m3", "metro_3", 200, 5.0),
            ConnectionEntity(0, "la_raza_m3", "indios_verdes_m3", "metro_3", 200, 5.0),
            ConnectionEntity(0, "la_raza_m3", "guerrero_m3", "metro_3", 120, 5.0),
            ConnectionEntity(0, "guerrero_m3", "la_raza_m3", "metro_3", 120, 5.0),
            ConnectionEntity(0, "guerrero_m3", "hidalgo_m3", "metro_3", 90, 5.0),
            ConnectionEntity(0, "hidalgo_m3", "guerrero_m3", "metro_3", 90, 5.0),
            ConnectionEntity(0, "hidalgo_m3", "balderas_m3", "metro_3", 90, 5.0),
            ConnectionEntity(0, "balderas_m3", "hidalgo_m3", "metro_3", 90, 5.0),
            ConnectionEntity(0, "balderas_m3", "centro_medico_m3", "metro_3", 160, 5.0),
            ConnectionEntity(0, "centro_medico_m3", "balderas_m3", "metro_3", 160, 5.0),
            ConnectionEntity(0, "centro_medico_m3", "zapata_m3", "metro_3", 240, 5.0),
            ConnectionEntity(0, "zapata_m3", "centro_medico_m3", "metro_3", 240, 5.0),
            ConnectionEntity(0, "zapata_m3", "universidad_m3", "metro_3", 280, 5.0),
            ConnectionEntity(0, "universidad_m3", "zapata_m3", "metro_3", 280, 5.0),

            // Line 7 (Metro)
            ConnectionEntity(0, "el_rosario_m7", "tacuba_m7", "metro_7", 200, 5.0),
            ConnectionEntity(0, "tacuba_m7", "el_rosario_m7", "metro_7", 200, 5.0),
            ConnectionEntity(0, "tacuba_m7", "auditorio_m7", "metro_7", 240, 5.0),
            ConnectionEntity(0, "auditorio_m7", "tacuba_m7", "metro_7", 240, 5.0),
            ConnectionEntity(0, "auditorio_m7", "tacubaya_m7", "metro_7", 120, 5.0),
            ConnectionEntity(0, "tacubaya_m7", "auditorio_m7", "metro_7", 120, 5.0),
            ConnectionEntity(0, "tacubaya_m7", "mixcoac_m7", "metro_7", 180, 5.0),
            ConnectionEntity(0, "mixcoac_m7", "tacubaya_m7", "metro_7", 180, 5.0),
            ConnectionEntity(0, "mixcoac_m7", "barranca_muerto_m7", "metro_7", 100, 5.0),
            ConnectionEntity(0, "barranca_muerto_m7", "mixcoac_m7", "metro_7", 100, 5.0),

            // Line 9 (Metro)
            ConnectionEntity(0, "tacubaya_m9", "centro_medico_m9", "metro_9", 200, 5.0),
            ConnectionEntity(0, "centro_medico_m9", "tacubaya_m9", "metro_9", 200, 5.0),
            ConnectionEntity(0, "centro_medico_m9", "chabacano_m9", "metro_9", 220, 5.0),
            ConnectionEntity(0, "chabacano_m9", "centro_medico_m9", "metro_9", 220, 5.0),
            ConnectionEntity(0, "chabacano_m9", "pantitlan_m9", "metro_9", 420, 5.0),
            ConnectionEntity(0, "pantitlan_m9", "chabacano_m9", "metro_9", 420, 5.0),

            // Line 12 (Metro)
            ConnectionEntity(0, "mixcoac_m12", "zapata_m12", "metro_12", 240, 5.0),
            ConnectionEntity(0, "zapata_m12", "mixcoac_m12", "metro_12", 240, 5.0),
            ConnectionEntity(0, "zapata_m12", "ermita_m12", "metro_12", 200, 5.0),
            ConnectionEntity(0, "ermita_m12", "zapata_m12", "metro_12", 200, 5.0),
            ConnectionEntity(0, "ermita_m12", "atlalilco_m12", "metro_12", 300, 5.0),
            ConnectionEntity(0, "atlalilco_m12", "ermita_m12", "metro_12", 300, 5.0),

            // Metrobús Line 1
            ConnectionEntity(0, "indios_verdes_mb1", "revolucion_mb1", "metrobus_1", 360, 6.0),
            ConnectionEntity(0, "revolucion_mb1", "indios_verdes_mb1", "metrobus_1", 360, 6.0),
            ConnectionEntity(0, "revolucion_mb1", "glorieta_insurgentes_mb1", "metrobus_1", 180, 6.0),
            ConnectionEntity(0, "glorieta_insurgentes_mb1", "revolucion_mb1", "metrobus_1", 180, 6.0),
            ConnectionEntity(0, "glorieta_insurgentes_mb1", "chilpancingo_mb1", "metrobus_1", 200, 6.0),
            ConnectionEntity(0, "chilpancingo_mb1", "glorieta_insurgentes_mb1", "metrobus_1", 200, 6.0),

            // Cablebús Line 1
            ConnectionEntity(0, "indios_verdes_cb1", "cuautepec_cb1", "cablebus_1", 600, 7.0),
            ConnectionEntity(0, "cuautepec_cb1", "indios_verdes_cb1", "cablebus_1", 600, 7.0),

            // Tren Ligero
            ConnectionEntity(0, "tasquena_tl", "estadio_azteca_tl", "tren_ligero", 480, 3.0),
            ConnectionEntity(0, "estadio_azteca_tl", "tasquena_tl", "tren_ligero", 480, 3.0),

            // INTERCHANGE TRANSFERS (Walking physical connections, usually free except for multi-modal crossings)
            // Tacubaya (L1 <-> L7 <-> L9)
            ConnectionEntity(0, "tacubaya_m1", "tacubaya_m7", "transfer", 180, 0.0),
            ConnectionEntity(0, "tacubaya_m7", "tacubaya_m1", "transfer", 180, 0.0),
            ConnectionEntity(0, "tacubaya_m1", "tacubaya_m9", "transfer", 150, 0.0),
            ConnectionEntity(0, "tacubaya_m9", "tacubaya_m1", "transfer", 150, 0.0),
            ConnectionEntity(0, "tacubaya_m7", "tacubaya_m9", "transfer", 240, 0.0),
            ConnectionEntity(0, "tacubaya_m9", "tacubaya_m7", "transfer", 240, 0.0),

            // Balderas (L1 <-> L3)
            ConnectionEntity(0, "balderas_m1", "balderas_m3", "transfer", 120, 0.0),
            ConnectionEntity(0, "balderas_m3", "balderas_m1", "transfer", 120, 0.0),

            // Pino Suárez (L1 <-> L2)
            ConnectionEntity(0, "pino_suarez_m1", "pino_suarez_m2", "transfer", 140, 0.0),
            ConnectionEntity(0, "pino_suarez_m2", "pino_suarez_m1", "transfer", 140, 0.0),

            // Pantitlán (L1 <-> L9)
            ConnectionEntity(0, "pantitlan_m1", "pantitlan_m9", "transfer", 300, 0.0),
            ConnectionEntity(0, "pantitlan_m9", "pantitlan_m1", "transfer", 300, 0.0),

            // Tacuba (L2 <-> L7)
            ConnectionEntity(0, "tacuba_m2", "tacuba_m7", "transfer", 160, 0.0),
            ConnectionEntity(0, "tacuba_m7", "tacuba_m2", "transfer", 160, 0.0),

            // Hidalgo (L2 <-> L3)
            ConnectionEntity(0, "hidalgo_m2", "hidalgo_m3", "transfer", 110, 0.0),
            ConnectionEntity(0, "hidalgo_m3", "hidalgo_m2", "transfer", 110, 0.0),

            // Chabacano (L2 <-> L9)
            ConnectionEntity(0, "chabacano_m2", "chabacano_m9", "transfer", 130, 0.0),
            ConnectionEntity(0, "chabacano_m9", "chabacano_m2", "transfer", 130, 0.0),

            // Centro Médico (L3 <-> L9)
            ConnectionEntity(0, "centro_medico_m3", "centro_medico_m9", "transfer", 100, 0.0),
            ConnectionEntity(0, "centro_medico_m9", "centro_medico_m3", "transfer", 100, 0.0),

            // Zapata (L3 <-> L12)
            ConnectionEntity(0, "zapata_m3", "zapata_m12", "transfer", 150, 0.0),
            ConnectionEntity(0, "zapata_m12", "zapata_m3", "transfer", 150, 0.0),

            // Mixcoac (L7 <-> L12)
            ConnectionEntity(0, "mixcoac_m7", "mixcoac_m12", "transfer", 200, 0.0),
            ConnectionEntity(0, "mixcoac_m12", "mixcoac_m7", "transfer", 200, 0.0),

            // MULTI-MODAL INTERCHANGES (Cross-system transfers with cost, e.g. Metro <-> Metrobús)
            // Indios Verdes (Metro L3 <-> MB L1 <-> CB L1)
            ConnectionEntity(0, "indios_verdes_m3", "indios_verdes_mb1", "transfer", 180, 6.0),
            ConnectionEntity(0, "indios_verdes_mb1", "indios_verdes_m3", "transfer", 180, 5.0),
            ConnectionEntity(0, "indios_verdes_m3", "indios_verdes_cb1", "transfer", 240, 7.0),
            ConnectionEntity(0, "indios_verdes_cb1", "indios_verdes_m3", "transfer", 240, 5.0),
            ConnectionEntity(0, "indios_verdes_mb1", "indios_verdes_cb1", "transfer", 240, 7.0),
            ConnectionEntity(0, "indios_verdes_cb1", "indios_verdes_mb1", "transfer", 240, 6.0),

            // Tasqueña (Metro L2 <-> TL)
            ConnectionEntity(0, "tasquena_m2", "tasquena_tl", "transfer", 180, 3.0),
            ConnectionEntity(0, "tasquena_tl", "tasquena_m2", "transfer", 180, 5.0)
        )
    }

    fun getInitialAlerts(): List<AlertEntity> {
        return listOf(
            AlertEntity(0, "Línea 1: Renovación en Curso", "Servicio parcial entre Observatorio y Balderas. Use alternativas de Metrobús y RTP proporcionadas.", "WARNING", System.currentTimeMillis() - 3600000, "metro_1"),
            AlertEntity(0, "Alta Afluencia en Indios Verdes", "Tiempo de espera aproximado de 6 minutos debido a alta afluencia de pasajeros. Tome precauciones.", "INFO", System.currentTimeMillis() - 1800000, "metro_3"),
            AlertEntity(0, "Mantenimiento Preventivo Cablebús L1", "Línea 1 operando con velocidad reducida por ráfagas de viento fuertes en la zona alta de Cuautepec.", "INFO", System.currentTimeMillis(), "cablebus_1"),
            AlertEntity(0, "Suspensión de Elevador en Tacubaya L7", "Elevador con acceso a andén dirección Barranca del Muerto fuera de servicio temporalmente por reparación.", "CRITICAL", System.currentTimeMillis() - 12000000, "metro_7")
        )
    }
}
