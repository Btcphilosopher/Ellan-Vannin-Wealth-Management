# Metro CDMX - Passenger Information & Journey Planning Backend System

This is the official production-grade backend service documentation, database designs, and deployment configurations for the integrated **Metro CDMX** transit application.

---

## 🚀 Features

* **High-Scale Dijkstra Journey Planner**: Calculates FASTEST, CHEAPEST, and FEWEST TRANSFERS routes.
* **PostGIS Spatial Geo-searches**: Real-time nearby station calculation based on radial proximity using specialized spatial indexes.
* **Redis Cache Layer**: Caches precalculated travel directions and active alerts.
* **JWT-Authenticated Operator Console**: Secures operational admin activities.

---

## 📦 Tech Stack

* **Framework**: Spring Boot (Java 17)
* **Database**: PostgreSQL 15 + PostGIS Spatial Extensions
* **Caching**: Redis Cache
* **Deployment**: Docker & Kubernetes Ready

---

## 🗺️ REST API Documentation

### 1. Journey Calculations
* **Endpoint**: `GET /api/v1/journey/plan`
* **Parameters**:
  * `fromStationId` (string, required) - Starting station ID (e.g. `observatorio_m1`)
  * `toStationId` (string, required) - Ending destination ID (e.g. `tasquena_m2`)
  * `criteria` (string, optional) - `FASTEST`, `CHEAPEST`, `FEWEST_TRANSFERS`
* **Response (200 OK)**:
```json
{
  "criteria": "FASTEST",
  "totalTimeMinutes": 18,
  "totalFareMxn": 5.0,
  "transferCount": 1,
  "steps": [
    {
      "stationId": "observatorio_m1",
      "stationName": "Observatorio",
      "lineId": "metro_1",
      "isTransfer": false,
      "estimatedTimeMinutes": 0
    },
    {
      "stationId": "tacubaya_m1",
      "stationName": "Tacubaya",
      "lineId": "metro_1",
      "isTransfer": true,
      "estimatedTimeMinutes": 2
    }
  ]
}
```

### 2. Service Alerts
* **Endpoint**: `GET /api/v1/alerts`
* **Response (200 OK)**:
```json
[
  {
    "id": 104,
    "title": "Línea 1: Renovación en Curso",
    "description": "Servicio parcial entre Observatorio y Balderas.",
    "severity": "WARNING",
    "lineId": "metro_1",
    "publishedAt": "2026-07-06T02:00:00Z"
  }
]
```

---

## 🗄️ Database Spatial Schema

We use PostGIS Point representations to store and query physical coordinates. For example, to find all stations within **500 meters** of the user's current coordinates (`-99.1473, 19.4373`), we query:

```sql
SELECT id, name, line_id, ST_Distance(geom, ST_SetSRID(ST_MakePoint(-99.1473, 19.4373), 4326)::geography) AS distance_meters
FROM stations
WHERE ST_DWithin(geom, ST_SetSRID(ST_MakePoint(-99.1473, 19.4373), 4326)::geography, 500)
ORDER BY distance_meters ASC;
```

---

## 🛠️ Docker Installation Guide

### Prerequisites
* Docker installed on your host system.
* Docker Compose installed.

### Run the Stack Locally
1. Navigate to the backend directory:
   ```bash
   cd backend
   ```
2. Start the integrated Spring Boot rest service, PostGIS container, and Redis cache:
   ```bash
   docker-compose up --build
   ```
3. The server will launch and bind to `http://localhost:8080`.
