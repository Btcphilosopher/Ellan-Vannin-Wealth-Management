package com.metrocdmx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class MetroCdmxApplication {
    public static void main(String[] args) {
        SpringApplication.run(MetroCdmxApplication.class, args);
    }
}
