-- PostgreSQL & PostGIS Database Schema for Metro CDMX Transit Network

-- Enable PostGIS spatial extension for geographic calculations
CREATE EXTENSION IF NOT EXISTS postgis;

-- 1. Users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    preferred_language VARCHAR(5) DEFAULT 'ES',
    wheelchair_accessible_preferred BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Lines / Transport networks table
CREATE TABLE IF NOT EXISTS lines (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    color_hex VARCHAR(7) NOT NULL,
    type VARCHAR(50) NOT NULL -- 'Metro', 'Metrobús', 'Cablebús', 'Tren Ligero', etc.
);

-- 3. Stations Table with Spatial coordinates support (PostGIS)
CREATE TABLE IF NOT EXISTS stations (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    line_id VARCHAR(50) REFERENCES lines(id) ON DELETE CASCADE,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    geom GEOMETRY(Point, 4326), -- PostGIS Point geometry (SRID 4326 for WGS84 coordinates)
    facilities TEXT,
    accessibility_info TEXT,
    is_lift_available BOOLEAN DEFAULT FALSE,
    is_escalator_available BOOLEAN DEFAULT FALSE,
    nearby_attractions TEXT,
    nearby_bus_connections TEXT,
    exit_locations TEXT,
    has_bike_parking BOOLEAN DEFAULT FALSE,
    is_interchange BOOLEAN DEFAULT FALSE
);

-- Spatial index on station coordinates for fast radial searches (Nearby Stations queries)
CREATE INDEX IF NOT EXISTS idx_stations_geom ON stations USING gist(geom);

-- 4. Routes (General directional collections)
CREATE TABLE IF NOT EXISTS routes (
    id VARCHAR(50) PRIMARY KEY,
    line_id VARCHAR(50) REFERENCES lines(id) ON DELETE CASCADE,
    direction_destination VARCHAR(100) NOT NULL
);

-- 5. Physical station connections / Graph Edges
CREATE TABLE IF NOT EXISTS connections (
    id SERIAL PRIMARY KEY,
    from_station_id VARCHAR(50) REFERENCES stations(id) ON DELETE CASCADE,
    to_station_id VARCHAR(50) REFERENCES stations(id) ON DELETE CASCADE,
    line_id VARCHAR(50) REFERENCES lines(id) ON DELETE CASCADE,
    travel_time_seconds INTEGER NOT NULL,
    cost NUMERIC(5,2) DEFAULT 5.00
);

-- 6. Scheduled Station departures / Timetables
CREATE TABLE IF NOT EXISTS timetables (
    id SERIAL PRIMARY KEY,
    station_id VARCHAR(50) REFERENCES stations(id) ON DELETE CASCADE,
    route_id VARCHAR(50) REFERENCES routes(id) ON DELETE CASCADE,
    scheduled_departure_time TIME NOT NULL,
    day_of_week VARCHAR(10) NOT NULL -- 'WEEKDAY', 'SATURDAY', 'SUNDAY'
);

-- 7. Real-time Service Alerts
CREATE TABLE IF NOT EXISTS service_alerts (
    id SERIAL PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    severity VARCHAR(20) NOT NULL, -- 'INFO', 'WARNING', 'CRITICAL'
    line_id VARCHAR(50) REFERENCES lines(id) ON DELETE SET NULL,
    published_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP WITH TIME ZONE
);

-- 8. Saved Favourite Routes for users
CREATE TABLE IF NOT EXISTS favorite_routes (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    label VARCHAR(100) NOT NULL,
    from_station_id VARCHAR(50) REFERENCES stations(id) ON DELETE CASCADE,
    to_station_id VARCHAR(50) REFERENCES stations(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. Historical User Journey Statistics
CREATE TABLE IF NOT EXISTS journey_history (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    from_station_id VARCHAR(50) REFERENCES stations(id) ON DELETE CASCADE,
    to_station_id VARCHAR(50) REFERENCES stations(id) ON DELETE CASCADE,
    travel_time_seconds INTEGER NOT NULL,
    fare_paid NUMERIC(5,2) NOT NULL,
    traveled_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 10. Push Notifications queue
CREATE TABLE IF NOT EXISTS notifications_queue (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    body TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'PENDING', -- 'PENDING', 'SENT', 'FAILED'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    sent_at TIMESTAMP WITH TIME ZONE
);
