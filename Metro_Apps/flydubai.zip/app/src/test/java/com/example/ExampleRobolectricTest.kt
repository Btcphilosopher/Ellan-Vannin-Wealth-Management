package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.model.AirlineEvent
import com.example.core.model.FareType
import com.example.core.viewmodel.DemoStage
import com.example.core.viewmodel.FlyDubaiViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppName() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("flydubai", appName)
    }

    @Test
    fun testCurrencyMultipliers() {
        val viewModel = FlyDubaiViewModel()
        
        // Default currency is AED (rate 1.0)
        assertEquals("AED", viewModel.uiState.value.selectedCurrency)
        assertEquals(1.0, viewModel.uiState.value.currencyRate, 0.001)

        // Switch to USD (rate 0.27)
        viewModel.setCurrency("USD")
        assertEquals("USD", viewModel.uiState.value.selectedCurrency)
        assertEquals(0.27, viewModel.uiState.value.currencyRate, 0.001)
    }

    @Test
    fun testFlightBookingIntegrationFlow() {
        val viewModel = FlyDubaiViewModel()
        
        // Start Booking
        viewModel.startBooking()
        val currentBooking = viewModel.uiState.value.currentBookingInProgress
        assertTrue(currentBooking != null)
        
        // Fare price verification
        val basePrice = viewModel.uiState.value.selectedFlight?.basePriceAED ?: 1240
        val multiplier = viewModel.uiState.value.selectedFareType.priceMultiplier
        assertEquals((basePrice * multiplier).toInt(), currentBooking?.runningTotalAED)

        // Assign Seat (Extra Legroom in row 1 or 12 increases price by AED 180)
        viewModel.selectBookingSeat("12A")
        val updatedBooking = viewModel.uiState.value.currentBookingInProgress
        assertEquals("12A", updatedBooking?.seatNumber)
        assertEquals((basePrice * multiplier).toInt() + 180, updatedBooking?.runningTotalAED)
    }

    @Test
    fun testCheckInWorkflowWizard() {
        val viewModel = FlyDubaiViewModel()
        val activeBooking = viewModel.uiState.value.bookings.first()

        // Init Check-In
        viewModel.startCheckIn(activeBooking)
        assertEquals(1, viewModel.uiState.value.checkInStep)

        // Walk through check-in steps
        viewModel.advanceCheckIn() // step 2
        viewModel.advanceCheckIn() // step 3
        viewModel.advanceCheckIn() // step 4
        viewModel.advanceCheckIn() // step 5
        assertEquals(5, viewModel.uiState.value.checkInStep)

        // Issue Boarding Pass
        viewModel.advanceCheckIn() // step 6
        
        // Verify user is checked in and has boarding pass
        val updatedBooking = viewModel.uiState.value.bookings.first()
        assertTrue(updatedBooking.isCheckedIn)
        assertTrue(updatedBooking.hasBoardingPass)
    }

    @Test
    fun testNotificationEvents() {
        val viewModel = FlyDubaiViewModel()
        assertTrue(viewModel.uiState.value.notifications.isEmpty())

        // Trigger Delay event
        viewModel.triggerEvent(AirlineEvent.FLIGHT_DELAYED)
        assertEquals(1, viewModel.uiState.value.notifications.size)
        assertEquals("Flight Delayed", viewModel.uiState.value.notifications.first().first)
    }
}
