package com.example.feature.trips

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.core.viewmodel.DemoStage
import com.example.core.viewmodel.FlyDubaiUiState
import com.example.core.viewmodel.FlyDubaiViewModel
import com.example.design.*
import com.example.ui.theme.*

@Composable
fun TripsScreen(
    viewModel: FlyDubaiViewModel,
    uiState: FlyDubaiUiState,
    onNavigateToCheckIn: (Booking) -> Unit
) {
    var selectedTab by remember { mutableStateOf("UPCOMING") } // UPCOMING, PAST, CANCELLED
    var selectedBookingForDetail by remember { mutableStateOf<Booking?>(null) }

    if (selectedBookingForDetail != null) {
        TripDetailTimelineScreen(
            booking = selectedBookingForDetail!!,
            uiState = uiState,
            viewModel = viewModel,
            onBack = { selectedBookingForDetail = null },
            onNavigateToCheckIn = { onNavigateToCheckIn(selectedBookingForDetail!!) }
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "MY TRIPS",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("UPCOMING", "PAST", "CANCELLED").forEach { tab ->
                val isSel = selectedTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isSel) FlyDubaiBlue else FlyDubaiSand,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { selectedTab = tab }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) Color.White else FlyDubaiCharcoal,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Filter bookings list
        val filteredBookings = when (selectedTab) {
            "UPCOMING" -> uiState.bookings.filter { !it.isCancelled }
            "PAST" -> emptyList() // Demo PAST trips
            "CANCELLED" -> uiState.bookings.filter { it.isCancelled }
            else -> emptyList()
        }

        if (filteredBookings.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Flight, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No trips found in this category.",
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredBookings) { booking ->
                    FZFlightCard(
                        flight = booking.flight,
                        onClick = { selectedBookingForDetail = booking }
                    )
                }
            }
        }
    }
}

@Composable
fun TripDetailTimelineScreen(
    booking: Booking,
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel,
    onBack: () -> Unit,
    onNavigateToCheckIn: () -> Unit
) {
    var activeSubTab by remember { mutableStateOf("TIMELINE") } // TIMELINE, AIRPORT, BAGGAGE, DISRUPTION, LIVE MAP

    val flight = booking.flight
    val stage = uiState.currentStage

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "${flight.origin.code} → ${flight.destination.code}",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
            )
            Spacer(modifier = Modifier.weight(1f))
            FZStatus(status = flight.status)
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Horizontal Category Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(FlyDubaiSand, RoundedCornerShape(8.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf("TIMELINE", "AIRPORT", "BAGGAGE", "LIVE MAP").forEach { tab ->
                val isSel = activeSubTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isSel) FlyDubaiBlue else Color.Transparent,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { activeSubTab = tab }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) Color.White else Color.Gray,
                        fontSize = 10.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Delay Disruption banner overlay if PREPARE stage is delayed or operational changes happen (#20)
        if (stage == DemoStage.PREPARE && flight.delayedDepartureTime != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(1.dp, Color.Red.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("YOUR FLIGHT HAS BEEN DELAYED", fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                    Text("Original: ${flight.originalDepartureTime} • New Departure: ${flight.delayedDepartureTime}", fontSize = 12.sp, color = Color.DarkGray)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("WHAT THIS MEANS: Boarding time is changed, connect with assistance.", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Red)) {
                            Text("Accept", fontSize = 11.sp)
                        }
                        Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = FlyDubaiBlue, contentColor = Color.White)) {
                            Text("Alternative Flights", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeSubTab) {
                "TIMELINE" -> TripTimelineView(booking, uiState, onNavigateToCheckIn)
                "AIRPORT" -> AirportModeView(booking, uiState)
                "BAGGAGE" -> BaggageTrackingView(booking, uiState)
                "LIVE MAP" -> LiveFlightMapTelemetryView(booking, uiState)
            }
        }
    }
}

@Composable
fun TripTimelineView(
    booking: Booking,
    uiState: FlyDubaiUiState,
    onNavigateToCheckIn: () -> Unit
) {
    val timelineStages = listOf(
        Pair("05:40", "Arrive at Dubai Terminal 2"),
        Pair("06:10", "Check-in at flydubai Counter"),
        Pair("07:00", "Clear Security Checkpoint"),
        Pair("07:40", "Boarding commenced at Gate ${booking.flight.gate}"),
        Pair("08:20", "Boarding gates closed"),
        Pair("08:40", "Departure from Dubai (DXB)"),
        Pair("12:40", "Arrival at Istanbul (IST)")
    )

    // Highlight timeline stage based on demo state
    val currentHighlightIndex = when (uiState.currentStage) {
        DemoStage.NO_FLIGHT -> 0
        DemoStage.PREPARE -> 1
        DemoStage.AIRPORT_MODE -> 2
        DemoStage.BOARD_NOW -> 3
        DemoStage.FLIGHT_MODE -> 5
        DemoStage.ARRIVED -> 6
    }

    Column {
        FZTimeline(stages = timelineStages, currentStageIndex = currentHighlightIndex)

        Spacer(modifier = Modifier.height(24.dp))

        // Connection Management Widget (#21)
        FZCard {
            Text("CONNECTING JOURNEY INFO", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Dubai (DXB) ", fontSize = 13.sp)
                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                Text(" Doha (DOH) ", fontSize = 13.sp)
                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                Text(" Istanbul (IST)", fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("Connection Interval: 1h 25m", fontWeight = FontWeight.ExtraBold, color = FlyDubaiOrange, fontSize = 14.sp)
            Text("Transit Gate Transfer distance: 240m • Low Connection Risk", color = Color.Gray, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (!booking.isCheckedIn) {
            FZButton(
                text = "PROCEED TO CHECK-IN",
                onClick = onNavigateToCheckIn,
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("CHECKED IN SUCCESSFULLY", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        Text("Seat ${booking.seatNumber ?: "12A"} • Digital Boarding Pass Ready", fontSize = 12.sp, color = Color.DarkGray)
                    }
                }
            }
        }
    }
}

@Composable
fun AirportModeView(
    booking: Booking,
    uiState: FlyDubaiUiState
) {
    Column {
        Text("DXB TERMINAL 2 EXPERIENCE", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Text("Your active guide inside Dubai International Airport", fontSize = 13.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FZMetric(label = "Check-In Area", value = "Counter 4", modifier = Modifier.weight(1f))
            FZMetric(label = "Security Gate", value = "Gate B", modifier = Modifier.weight(1f))
            FZMetric(label = "Boarding Gate", value = "B32", modifier = Modifier.weight(1f), highlight = true)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("FACILITIES & SERVICES NEAR B32", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocalCafe, contentDescription = null, tint = FlyDubaiOrange, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("flydubai Business Lounge", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Premium quiet zones & dining • Terminal 2, Level 2", fontSize = 12.sp, color = Color.Gray)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Restaurant, contentDescription = null, tint = FlyDubaiBlue, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Dubai Airport Duty Free & Shops", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Perfumes, souvenirs, snacks • 3 min walk", fontSize = 12.sp, color = Color.Gray)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DirectionsBus, contentDescription = null, tint = FlyDubaiBlue, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Inter-Terminal Shuttle Bus", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("To Terminals 1 & 3 • Every 10 mins", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun BaggageTrackingView(
    booking: Booking,
    uiState: FlyDubaiUiState
) {
    val tag = booking.baggage.firstOrNull()?.tagNumber ?: "FZ48291A"
    val baggageStatus = booking.baggage.firstOrNull()?.status ?: BaggageStatus.CHECKED_IN

    Column {
        Text("BAGGAGE TRACKER", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Text("Tag ID: $tag • SECURE LUGGAGE IDENTIFICATION SYSTEM", fontSize = 12.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(24.dp))

        // Baggage status milestones
        listOf(
            Triple(BaggageStatus.CHECKED_IN, "Checked-In at Dubai Counter", baggageStatus.ordinal >= 0),
            Triple(BaggageStatus.LOADED, "Loaded onto Flight ${booking.flight.flightNumber}", baggageStatus.ordinal >= 1),
            Triple(BaggageStatus.ARRIVED, "Arrived at Istanbul Airport (IST)", baggageStatus.ordinal >= 3),
            Triple(BaggageStatus.DELIVERED, "Ready for collection on BELT 7", baggageStatus.ordinal >= 4)
        ).forEachIndexed { index, step ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (step.third) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (step.third) FlyDubaiOrange else Color.LightGray,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(text = step.first.label, fontWeight = FontWeight.Bold, color = if (step.third) FlyDubaiBlue else Color.LightGray)
                    Text(text = step.second, fontSize = 12.sp, color = if (step.third) Color.DarkGray else Color.LightGray)
                }
            }
        }
    }
}

@Composable
fun LiveFlightMapTelemetryView(
    booking: Booking,
    uiState: FlyDubaiUiState
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("FLIGHT TELEMETRY MODE", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("SIMULATED DATA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = FlyDubaiOrange)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text("Flight status: AIRBORNE • FZ 123", color = Color.Gray, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(16.dp))

        FZMap(booking.flight.origin.code, booking.flight.destination.code)

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text("ALTITUDE", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                Text("${uiState.altitudeFeet} FT", style = MaterialTheme.typography.titleLarge.copy(color = FlyDubaiBlue, fontWeight = FontWeight.ExtraBold))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("SPEED", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                Text("${uiState.speedKnots} KTS", style = MaterialTheme.typography.titleLarge.copy(color = FlyDubaiBlue, fontWeight = FontWeight.ExtraBold))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("REMAINING", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                Text("${uiState.distanceRemainingKm} KM", style = MaterialTheme.typography.titleLarge.copy(color = FlyDubaiOrange, fontWeight = FontWeight.ExtraBold))
            }
        }
    }
}
