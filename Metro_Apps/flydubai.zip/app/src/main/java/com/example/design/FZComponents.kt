package com.example.design

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.theme.*

// --- SECTION 44: CUSTOM COMPONENT LIBRARY (FZ COMPONENTS) ---

@Composable
fun FZButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isSecondary: Boolean = false,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    testTag: String = ""
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(52.dp)
            .testTag(testTag)
            .minimumInteractiveComponentSize(),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSecondary) FlyDubaiBlue else FlyDubaiOrange,
            contentColor = Color.White,
            disabledContainerColor = Color.LightGray,
            disabledContentColor = Color.DarkGray
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    letterSpacing = 0.5.sp
                )
            )
        }
    }
}

@Composable
fun FZCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = Color.White,
    borderColor: Color = FlyDubaiSandDark.copy(alpha = 0.5f),
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            content()
        }
    }
}

@Composable
fun FZFlightCard(
    flight: Flight,
    selectedFareType: FareType = FareType.BASIC,
    currencySymbol: String = "AED",
    currencyRate: Double = 1.0,
    onClick: () -> Unit = {},
    showPrice: Boolean = true
) {
    val totalPrice = (flight.basePriceAED * selectedFareType.priceMultiplier * currencyRate).toInt()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, FlyDubaiSandDark.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.FlightTakeoff,
                        contentDescription = null,
                        tint = FlyDubaiBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = flight.flightNumber,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = FlyDubaiBlue,
                            letterSpacing = 1.sp
                        )
                    )
                }
                FZStatus(status = flight.status)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Origin
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = flight.origin.code,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = FlyDubaiCharcoal
                        )
                    )
                    Text(
                        text = flight.departureTime,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = FlyDubaiBlue
                        )
                    )
                    Text(
                        text = flight.origin.city,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }

                // Flight path line
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = flight.duration,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                        color = Color.Gray
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                            .background(Color.LightGray)
                    )
                    Text(
                        text = if (flight.isNonStop) "Non-stop" else "${flight.stopsCount} stop",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (flight.isNonStop) Color.Gray else FlyDubaiOrange
                    )
                }

                // Destination
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = flight.destination.code,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = FlyDubaiCharcoal
                        )
                    )
                    Text(
                        text = flight.arrivalTime,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = FlyDubaiBlue
                        )
                    )
                    Text(
                        text = flight.destination.city,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Divider(color = FlyDubaiSand)

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = flight.aircraft.model,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
                if (showPrice) {
                    FZPrice(
                        amount = totalPrice,
                        currencySymbol = currencySymbol,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = FlyDubaiOrange
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun FZAirportCard(
    airport: Airport,
    onClick: () -> Unit = {}
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, FlyDubaiSand, RoundedCornerShape(10.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = FlyDubaiWarmWhite)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(FlyDubaiBlue, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = airport.code,
                    color = Color.White,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "${airport.city} (${airport.code})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${airport.name}, ${airport.country}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun FZBoardingPass(
    flight: Flight,
    passengerName: String,
    seat: String,
    pnr: String,
    onSaveToWallet: () -> Unit = {}
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(2.dp, FlyDubaiOrange.copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = FlyDubaiBlue),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FLYDUBAI",
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp
                    )
                )
                Text(
                    text = "BOARDING PASS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = FlyDubaiOrange,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Flight Route
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = flight.origin.code,
                        style = MaterialTheme.typography.headlineLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                    Text(text = flight.origin.city, color = FlyDubaiSand, style = MaterialTheme.typography.bodySmall)
                }

                Icon(
                    Icons.Default.FlightTakeoff,
                    contentDescription = null,
                    tint = FlyDubaiOrange,
                    modifier = Modifier.size(32.dp)
                )

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = flight.destination.code,
                        style = MaterialTheme.typography.headlineLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                    Text(text = flight.destination.city, color = FlyDubaiSand, style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Dashed separator
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
            ) {
                val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                drawLine(
                    color = FlyDubaiSand.copy(alpha = 0.5f),
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    pathEffect = pathEffect,
                    strokeWidth = 2f
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Flight stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "PASSENGER", color = FlyDubaiSand, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = passengerName,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "FLIGHT", color = FlyDubaiSand, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = flight.flightNumber,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "BOARDING", color = FlyDubaiSand, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = "07:40",
                        color = FlyDubaiOrange,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "GATE", color = FlyDubaiSand, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = flight.gate,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "SEAT", color = FlyDubaiSand, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = seat,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Fake Barcode Representation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(Color.White, RoundedCornerShape(4.dp))
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                // Draw barcode patterns using a custom canvas lines
                Canvas(modifier = Modifier.fillMaxSize()) {
                    var currentX = 0f
                    val widths = listOf(4f, 8f, 2f, 10f, 6f, 2f, 12f, 4f, 6f, 8f, 2f, 4f, 12f, 6f, 4f, 8f, 10f, 4f, 2f, 8f, 4f, 12f, 4f, 6f, 8f)
                    var index = 0
                    while (currentX < size.width && index < widths.size) {
                        val barWidth = widths[index % widths.size]
                        drawRect(
                            color = Color.Black,
                            topLeft = Offset(currentX, 0f),
                            size = androidx.compose.ui.geometry.Size(barWidth, size.height)
                        )
                        currentX += barWidth + (if (index % 3 == 0) 6f else 3f)
                        index++
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "PNR: $pnr • SECURE FLIGHT DATA SYSTEM",
                color = FlyDubaiSand.copy(alpha = 0.8f),
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelSmall
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onSaveToWallet,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = FlyDubaiBlue),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add to Wallet", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun FZMetric(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    Column(
        modifier = modifier
            .background(
                if (highlight) FlyDubaiOrange.copy(alpha = 0.1f) else FlyDubaiSand.copy(alpha = 0.4f),
                RoundedCornerShape(8.dp)
            )
            .padding(12.dp)
    ) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (highlight) FlyDubaiOrange else Color.Gray,
                letterSpacing = 1.sp
            )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.ExtraBold,
                color = FlyDubaiBlue,
                fontSize = 20.sp
            )
        )
    }
}

@Composable
fun FZTimeline(
    stages: List<Pair<String, String>>,
    currentStageIndex: Int
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        stages.forEachIndexed { index, stage ->
            val isActive = index == currentStageIndex
            val isPassed = index < currentStageIndex

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Time
                Text(
                    text = stage.first,
                    modifier = Modifier.width(60.dp),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Normal,
                        color = if (isActive) FlyDubaiOrange else if (isPassed) Color.Gray else FlyDubaiCharcoal
                    )
                )

                // Circle & Line Indicators
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .border(
                                2.dp,
                                if (isActive) FlyDubaiOrange else if (isPassed) FlyDubaiBlue else Color.LightGray,
                                CircleShape
                            )
                            .background(
                                if (isActive) FlyDubaiOrange else if (isPassed) FlyDubaiBlue else Color.Transparent,
                                CircleShape
                            )
                    )
                    if (index < stages.size - 1) {
                        Box(
                            modifier = Modifier
                                .width(2.dp)
                                .height(24.dp)
                                .background(if (isPassed) FlyDubaiBlue else Color.LightGray)
                        )
                    }
                }

                // Stage Label
                Text(
                    text = stage.second,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                        color = if (isActive) FlyDubaiOrange else if (isPassed) Color.Gray else FlyDubaiCharcoal
                    )
                )
            }
        }
    }
}

@Composable
fun FZStatus(status: FlightStatus) {
    val color = when (status) {
        FlightStatus.SCHEDULED -> Color.Gray
        FlightStatus.CHECK_IN_OPEN -> FlyDubaiBlue
        FlightStatus.BOARDING -> FlyDubaiOrange
        FlightStatus.FINAL_CALL -> Color(0xFFC62828)
        FlightStatus.DEPARTED -> FlyDubaiBlue
        FlightStatus.AIRBORNE -> Color(0xFF2E7D32)
        FlightStatus.LANDED -> Color(0xFF2E7D32)
        FlightStatus.DELAYED -> Color(0xFFE65100)
        FlightStatus.CANCELLED -> Color.Red
        FlightStatus.DIVERTED -> Color(0xFF7B1FA2)
    }

    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = status.label.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = color,
                letterSpacing = 0.5.sp
            )
        )
    }
}

@Composable
fun FZSeatMap(
    selectedSeat: String?,
    onSeatSelected: (String) -> Unit
) {
    // 737 Configuration: Rows 1 to 30. A, B, C, Aisle, D, E, F
    val rows = (1..20).toList()
    val cols = listOf("A", "B", "C", "D", "E", "F")

    // Hardcode some occupied seats
    val occupiedSeats = remember { setOf("1A", "1F", "3B", "4C", "5D", "6E", "10A", "10B", "11C", "12F") }
    val extraLegroomRows = remember { setOf(1, 12, 14) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
            .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Text(
            text = "BOEING 737 CABIN (TAP SEAT)",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Color.Gray,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Legend
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(12.dp).background(Color.White).border(1.dp, Color.Gray))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Avail", fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(12.dp).background(FlyDubaiOrange))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Selected", fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(12.dp).background(Color.LightGray))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Occ", fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(12.dp).background(Color(0xFFE8F5E9)).border(1.dp, Color(0xFF2E7D32)))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Legroom", fontSize = 10.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(rows.size) { rowIndex ->
                val rowNum = rows[rowIndex]
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$rowNum",
                        modifier = Modifier.width(20.dp),
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )

                    // Seats A B C
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        for (i in 0..2) {
                            val seatId = "$rowNum${cols[i]}"
                            SeatCell(
                                seatId = seatId,
                                isOccupied = occupiedSeats.contains(seatId),
                                isExtraLegroom = extraLegroomRows.contains(rowNum),
                                isSelected = selectedSeat == seatId,
                                onSeatSelected = onSeatSelected
                            )
                        }
                    }

                    // Aisle
                    Text(
                        text = "AISLE",
                        fontSize = 9.sp,
                        color = Color.LightGray,
                        modifier = Modifier.width(36.dp),
                        textAlign = TextAlign.Center
                    )

                    // Seats D E F
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        for (i in 3..5) {
                            val seatId = "$rowNum${cols[i]}"
                            SeatCell(
                                seatId = seatId,
                                isOccupied = occupiedSeats.contains(seatId),
                                isExtraLegroom = extraLegroomRows.contains(rowNum),
                                isSelected = selectedSeat == seatId,
                                onSeatSelected = onSeatSelected
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SeatCell(
    seatId: String,
    isOccupied: Boolean,
    isExtraLegroom: Boolean,
    isSelected: Boolean,
    onSeatSelected: (String) -> Unit
) {
    val bgColor = when {
        isOccupied -> Color.LightGray
        isSelected -> FlyDubaiOrange
        isExtraLegroom -> Color(0xFFC8E6C9)
        else -> Color.White
    }

    val borderColor = when {
        isSelected -> FlyDubaiOrange
        isExtraLegroom -> Color(0xFF2E7D32)
        else -> Color.Gray
    }

    Box(
        modifier = Modifier
            .size(24.dp)
            .background(bgColor, RoundedCornerShape(4.dp))
            .border(1.dp, borderColor, RoundedCornerShape(4.dp))
            .clickable(enabled = !isOccupied) { onSeatSelected(seatId) },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = seatId.takeLast(1),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) Color.White else Color.Black
        )
    }
}

@Composable
fun FZMap(
    originCode: String = "DXB",
    destCode: String = "IST"
) {
    // Elegant DrawScope Canvas representing flight trajectory
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .background(FlyDubaiBlue.copy(alpha = 0.95f), RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Coordinates for Dubai (left) & Istanbul (right)
            val dxbX = width * 0.2f
            val dxbY = height * 0.7f

            val istX = width * 0.8f
            val istY = height * 0.3f

            // Draw grid points for tactical map feel
            for (i in 1..8) {
                for (j in 1..4) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.08f),
                        radius = 2f,
                        center = Offset(width * (i / 9f), height * (j / 5f))
                    )
                }
            }

            // Draw route curved arc
            val controlX = (dxbX + istX) / 2
            val controlY = (dxbY + istY) / 2 - 60f

            val routePath = androidx.compose.ui.graphics.Path().apply {
                moveTo(dxbX, dxbY)
                quadraticTo(controlX, controlY, istX, istY)
            }

            // Flight path line (dashed)
            drawPath(
                path = routePath,
                color = FlyDubaiOrange.copy(alpha = 0.8f),
                style = Stroke(
                    width = 4f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                )
            )

            // Origin Radar Circle
            drawCircle(color = Color.White, radius = 6f, center = Offset(dxbX, dxbY))
            drawCircle(color = Color.White.copy(alpha = 0.3f), radius = 12f, center = Offset(dxbX, dxbY), style = Stroke(2f))

            // Destination Radar Circle
            drawCircle(color = FlyDubaiOrange, radius = 6f, center = Offset(istX, istY))
            drawCircle(color = FlyDubaiOrange.copy(alpha = 0.3f), radius = 12f, center = Offset(istX, istY), style = Stroke(2f))

            // Simulated current airplane location along the path
            val planeX = dxbX + (istX - dxbX) * 0.45f
            val planeY = dxbY + (istY - dxbY) * 0.45f - 25f // Elevated on the arc

            drawCircle(color = Color.White, radius = 8f, center = Offset(planeX, planeY))
            drawCircle(color = FlyDubaiOrange, radius = 3f, center = Offset(planeX, planeY))
        }

        // Overlay text labels
        Box(modifier = Modifier.fillMaxSize()) {
            Text(
                text = originCode,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, bottom = 12.dp)
            )
            Text(
                text = destCode,
                color = FlyDubaiOrange,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier.align(Alignment.TopEnd).padding(end = 16.dp, top = 12.dp)
            )
            Text(
                text = "FLIGHT RADAR • ACTIVE TRAJECTORY",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart)
            )
        }
    }
}

@Composable
fun FZPrice(
    amount: Int,
    currencySymbol: String = "AED",
    style: androidx.compose.ui.text.TextStyle = LocalTextStyle.current
) {
    Text(
        text = "$currencySymbol %,d".format(amount),
        style = style
    )
}

@Composable
fun FZBottomSheet(
    title: String,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(Color.White)
            .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            content()
        }
    }
}

@Composable
fun FZNavigation(
    selectedItemIndex: Int,
    onItemSelected: (Int) -> Unit
) {
    NavigationBar(
        containerColor = FlyDubaiBlue,
        contentColor = Color.White
    ) {
        NavigationBarItem(
            selected = selectedItemIndex == 0,
            onClick = { onItemSelected(0) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = FlyDubaiOrange,
                unselectedIconColor = FlyDubaiSand,
                unselectedTextColor = FlyDubaiSand
            )
        )
        NavigationBarItem(
            selected = selectedItemIndex == 1,
            onClick = { onItemSelected(1) },
            icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            label = { Text("Book", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = FlyDubaiOrange,
                unselectedIconColor = FlyDubaiSand,
                unselectedTextColor = FlyDubaiSand
            )
        )
        NavigationBarItem(
            selected = selectedItemIndex == 2,
            onClick = { onItemSelected(2) },
            icon = { Icon(Icons.Default.FlightTakeoff, contentDescription = "Trips") },
            label = { Text("Trips", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = FlyDubaiOrange,
                unselectedIconColor = FlyDubaiSand,
                unselectedTextColor = FlyDubaiSand
            )
        )
        NavigationBarItem(
            selected = selectedItemIndex == 3,
            onClick = { onItemSelected(3) },
            icon = { Icon(Icons.Default.SupportAgent, contentDescription = "Support") },
            label = { Text("Assist", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = FlyDubaiOrange,
                unselectedIconColor = FlyDubaiSand,
                unselectedTextColor = FlyDubaiSand
            )
        )
        NavigationBarItem(
            selected = selectedItemIndex == 4,
            onClick = { onItemSelected(4) },
            icon = { Icon(Icons.Default.Settings, contentDescription = "Ops") },
            label = { Text("Ops", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = Color.White,
                indicatorColor = FlyDubaiOrange,
                unselectedIconColor = FlyDubaiSand,
                unselectedTextColor = FlyDubaiSand
            )
        )
    }
}

@Composable
fun FZNotification(
    title: String,
    message: String,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .border(1.dp, FlyDubaiOrange, RoundedCornerShape(8.dp)),
        colors = CardDefaults.cardColors(containerColor = FlyDubaiSand)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = FlyDubaiOrange)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, color = FlyDubaiBlue, fontSize = 14.sp)
                Text(text = message, color = Color.DarkGray, fontSize = 12.sp)
            }
            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray, modifier = Modifier.size(16.dp))
            }
        }
    }
}
