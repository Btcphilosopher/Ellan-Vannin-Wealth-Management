package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// flydubai Brand Palette
val FlyDubaiBlue = Color(0xFF002D62)       // Deep Blue
val FlyDubaiOrange = Color(0xFFFF6600)     // Bright Orange Accent
val FlyDubaiSand = Color(0xFFF2ECE4)       // Warm Sand Tone
val FlyDubaiSandDark = Color(0xFFDCD3C7)   // Darker Sand Accent
val FlyDubaiCharcoal = Color(0xFF1E1E24)   // Clean modern charcoal
val FlyDubaiWarmWhite = Color(0xFFFAF9F6)  // Warm soft white background

val FlyDubaiBlueDark = Color(0xFF4A80D4)
val FlyDubaiOrangeDark = Color(0xFFFF8C3D)
val FlyDubaiSurfaceDark = Color(0xFF121214)
val FlyDubaiBackgroundDark = Color(0xFF0C0C0E)
