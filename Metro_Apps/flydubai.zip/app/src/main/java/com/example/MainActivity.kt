package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.data.DemoData
import com.example.core.model.Booking
import com.example.core.viewmodel.DemoStage
import com.example.core.viewmodel.FlyDubaiUiState
import com.example.core.viewmodel.FlyDubaiViewModel
import com.example.design.*
import com.example.feature.booking.BookingFlowScreen
import com.example.feature.checkin.CheckInFlowScreen
import com.example.feature.operations.OperationsViewScreen
import com.example.feature.support.SupportScreen
import com.example.feature.trips.TripsScreen
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen()
            }
        }
    }
}

@Composable
fun MainAppScreen() {
    val viewModel: FlyDubaiViewModel = viewModel()
    val uiState by viewModel.uiState.collectAsState()

    var navigationIndex by remember { mutableStateOf(0) } // 0: Home, 1: Book, 2: Trips, 3: Assist, 4: Ops
    var isCheckingInDirectly by remember { mutableStateOf<Booking?>(null) }

    // Multi-Language RTL Layout direction wrapper (#47)
    val layoutDirection = if (uiState.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides layoutDirection) {
        Scaffold(
            topBar = {
                FlyDubaiHeader(
                    uiState = uiState,
                    viewModel = viewModel
                )
            },
            bottomBar = {
                FZNavigation(
                    selectedItemIndex = navigationIndex,
                    onItemSelected = { index ->
                        isCheckingInDirectly = null
                        navigationIndex = index
                    }
                )
            },
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Persistent dynamic notification banner (#31)
                if (uiState.notifications.isNotEmpty()) {
                    val notif = uiState.notifications.first()
                    FZNotification(
                        title = notif.first,
                        message = notif.second,
                        onDismiss = { viewModel.dismissNotification(0) }
                    )
                }

                Box(modifier = Modifier.weight(1f)) {
                    if (isCheckingInDirectly != null) {
                        CheckInFlowScreen(
                            viewModel = viewModel,
                            uiState = uiState,
                            onNavigateHome = {
                                isCheckingInDirectly = null
                                navigationIndex = 0 // Go back to Home
                            }
                        )
                    } else {
                        when (navigationIndex) {
                            0 -> HomeScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onNavigateToSearch = { navigationIndex = 1 },
                                onNavigateToCheckIn = { booking ->
                                    viewModel.startCheckIn(booking)
                                    isCheckingInDirectly = booking
                                }
                            )
                            1 -> BookingFlowScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onNavigateToTrips = { navigationIndex = 2 }
                            )
                            2 -> TripsScreen(
                                viewModel = viewModel,
                                uiState = uiState,
                                onNavigateToCheckIn = { booking ->
                                    viewModel.startCheckIn(booking)
                                    isCheckingInDirectly = booking
                                }
                            )
                            3 -> SupportScreen(
                                viewModel = viewModel,
                                uiState = uiState
                            )
                            4 -> OperationsViewScreen(
                                viewModel = viewModel,
                                uiState = uiState
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FlyDubaiHeader(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel
) {
    var showConfigMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .background(FlyDubaiBlue)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "FLYDUBAI",
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp
                    )
                )
                Text(
                    text = "THE SMARTER WAY TO FLY",
                    color = FlyDubaiOrange,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
            }

            // Configurations selector
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { showConfigMenu = !showConfigMenu }) {
                    Icon(Icons.Default.Language, contentDescription = "Config", tint = Color.White)
                }
            }
        }

        // Expanded Configurations drawer for Language and Currency (#47, #48)
        if (showConfigMenu) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .border(1.dp, FlyDubaiOrange.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("REGIONAL SETTINGS", fontWeight = FontWeight.Bold, color = FlyDubaiBlue, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Language chips list
                    Text("Language:", fontSize = 11.sp, color = Color.Gray)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(listOf("English", "Arabic", "Russian", "German", "Spanish")) { lang ->
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (uiState.selectedLanguage == lang) FlyDubaiOrange else FlyDubaiSand,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .clickable { viewModel.setLanguage(lang) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (lang == "Arabic") "العربية (RTL)" else lang,
                                    color = if (uiState.selectedLanguage == lang) Color.White else FlyDubaiCharcoal,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Currency chips list
                    Text("Currency:", fontSize = 11.sp, color = Color.Gray)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(listOf("AED", "USD", "EUR", "GBP")) { curr ->
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (uiState.selectedCurrency == curr) FlyDubaiBlue else FlyDubaiSand,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .clickable { viewModel.setCurrency(curr) }
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = curr,
                                    color = if (uiState.selectedCurrency == curr) Color.White else FlyDubaiCharcoal,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // DISCLAIMER LABEL (#49)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = DemoData.ENVIRONMENT_DISCLAIMER,
                fontSize = 9.sp,
                color = FlyDubaiSand.copy(alpha = 0.8f),
                fontWeight = FontWeight.ExtraBold
            )
            // Interactive Demo Stage Selector directly accessible!
            Text(
                text = "STAGE: ${uiState.currentStage.label}",
                fontSize = 10.sp,
                color = FlyDubaiOrange,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier
                    .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                    .clickable {
                        // Cycle through stages
                        val values = DemoStage.values()
                        val nextIndex = (uiState.currentStage.ordinal + 1) % values.size
                        viewModel.setDemoStage(values[nextIndex])
                    }
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
fun HomeScreen(
    viewModel: FlyDubaiViewModel,
    uiState: FlyDubaiUiState,
    onNavigateToSearch: () -> Unit,
    onNavigateToCheckIn: (Booking) -> Unit
) {
    val stage = uiState.currentStage
    val primaryBooking = uiState.bookings.firstOrNull { !it.isCancelled }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Evening / Morning Greeting Banner
        item {
            Column {
                Text(
                    text = if (uiState.isRtl) "مساء الخير" else "Good evening",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = FlyDubaiBlue
                    )
                )
                Text(
                    text = if (uiState.isRtl) "الوجهة التالية المتاحة" else "Welcome to your digital travel cockpit",
                    color = Color.Gray,
                    fontSize = 13.sp
                )
            }
        }

        // Stage Switcher Guidance Bar
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = FlyDubaiSand),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.TouchApp, contentDescription = null, tint = FlyDubaiOrange)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "DEMO SIMULATOR CONTROL",
                            fontWeight = FontWeight.ExtraBold,
                            color = FlyDubaiBlue,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "Tap 'STAGE' top-right to simulate different flight day phases!",
                            fontSize = 10.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }
        }

        // Render appropriate Personalized widget based on Stage selection (#46)
        item {
            when (stage) {
                DemoStage.NO_FLIGHT -> {
                    // Discovery carousel call to action
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("DISCOVER YOUR NEXT ADVENTURE", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                            Text("Direct flydubai routes to Baku, Muscat, Belgrade & Colombo open.", fontSize = 12.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(12.dp))
                            FZButton(
                                text = "EXPLORE DESTINATIONS",
                                onClick = onNavigateToSearch,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
                DemoStage.PREPARE -> {
                    if (primaryBooking != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(2.dp, FlyDubaiOrange.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                            colors = CardDefaults.cardColors(containerColor = FlyDubaiBlue)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("YOUR NEXT FLIGHT", color = FlyDubaiOrange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Box(
                                        modifier = Modifier
                                            .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("CHECK-IN OPEN", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = primaryBooking.flight.flightNumber,
                                            style = MaterialTheme.typography.headlineSmall.copy(color = Color.White, fontWeight = FontWeight.ExtraBold)
                                        )
                                        Text(
                                            text = "${primaryBooking.flight.origin.city} → ${primaryBooking.flight.destination.city}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("08:40", style = MaterialTheme.typography.headlineSmall.copy(color = Color.White, fontWeight = FontWeight.Bold))
                                        Text("Tomorrow", color = FlyDubaiSand, fontSize = 12.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FZMetric(label = "Terminal", value = "2", modifier = Modifier.weight(1f))
                                    FZMetric(label = "Gate", value = "B32", modifier = Modifier.weight(1f))
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                FZButton(
                                    text = "START ONLINE CHECK-IN",
                                    onClick = { onNavigateToCheckIn(primaryBooking) },
                                    modifier = Modifier.fillMaxWidth(),
                                    testTag = "home_checkin_btn"
                                )
                            }
                        }
                    }
                }
                DemoStage.AIRPORT_MODE -> {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("DXB PILOT: AIRPORT MODE", color = FlyDubaiOrange, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text("YOU ARE AT TERMINAL 2", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Proceed to security gate. Estimated walking time to Gate B32: 8 mins.", fontSize = 12.sp, color = Color.Gray)

                            Spacer(modifier = Modifier.height(12.dp))

                            // Simplified Airport Mode checklist
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Check-In Complete", fontSize = 13.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.RadioButtonUnchecked, contentDescription = null, tint = FlyDubaiOrange, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Security Checkpoint (Next step)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FlyDubaiOrange)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.RadioButtonUnchecked, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Gate B32 Boarding", fontSize = 13.sp, color = Color.LightGray)
                                }
                            }
                        }
                    }
                }
                DemoStage.BOARD_NOW -> {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(2.dp, Color.Red, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F1))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("BOARDING STARTED • FINAL CALL", fontWeight = FontWeight.ExtraBold, color = Color.Red, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Flight FZ 123 to Istanbul is boarding now from Gate B32.", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                            Text("Gate closes strictly in 12 minutes!", color = Color.Red, fontWeight = FontWeight.Bold)

                            Spacer(modifier = Modifier.height(16.dp))

                            Text("SHOW BOARDING PASS TO GATEMAN:", fontSize = 12.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(8.dp))

                            if (primaryBooking != null) {
                                FZBoardingPass(
                                    flight = primaryBooking.flight,
                                    passengerName = "TOM LOVEITT",
                                    seat = primaryBooking.seatNumber ?: "12A",
                                    pnr = primaryBooking.pnr
                                )
                            }
                        }
                    }
                }
                DemoStage.FLIGHT_MODE -> {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = FlyDubaiBlue)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("FZ 123 • IN FLIGHT", color = FlyDubaiOrange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("FLIGHT TELEMETRY ACTIVE", color = Color.White, fontSize = 10.sp)
                            }
                            Text("DUBAI → ISTANBUL", style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.ExtraBold))

                            Spacer(modifier = Modifier.height(12.dp))

                            // Canvas Route Trajectory Map
                            FZMap()

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("ALTITUDE", color = FlyDubaiSand, fontSize = 10.sp)
                                    Text("36,000 FT", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("SPEED", color = FlyDubaiSand, fontSize = 10.sp)
                                    Text("480 KTS", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("REMAINING", color = FlyDubaiSand, fontSize = 10.sp)
                                    Text("02:18", color = FlyDubaiOrange, fontWeight = FontWeight.ExtraBold)
                                }
                            }
                        }
                    }
                }
                DemoStage.ARRIVED -> {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("WELCOME TO ISTANBUL!", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("We hope you enjoyed your flydubai flight.", fontSize = 13.sp)

                            Spacer(modifier = Modifier.height(16.dp))

                            Card(
                                colors = CardDefaults.cardColors(containerColor = FlyDubaiSand)
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LocalMall, contentDescription = null, tint = FlyDubaiOrange)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text("BAGGAGE CLAIM READY", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                                        Text("Please collect checked bag GBR948271A at BELT 7.", fontSize = 12.sp, color = Color.DarkGray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // BOOK A FLIGHT Search Widget
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("BOOK A NEW JOURNEY", fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
                    Text("Find special deals across the flydubai network.", fontSize = 12.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(12.dp))
                    FZButton(
                        text = "BOOK FLIGHT NOW",
                        onClick = onNavigateToSearch,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // LOYALTY CARD WIDGET (#26)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("YOUR FLYDUBAI ACCOUNT", fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 11.sp)
                        Box(
                            modifier = Modifier
                                .background(FlyDubaiOrange.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("GOLD TIER", color = FlyDubaiOrange, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Points Available:", fontSize = 12.sp, color = Color.Gray)
                    Text("42,850", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue))

                    Spacer(modifier = Modifier.height(8.dp))

                    // Tier Progress bar
                    LinearProgressIndicator(
                        progress = { 42850f / 50000f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = FlyDubaiBlue,
                        trackColor = FlyDubaiSand
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("7,150 points to PLATINUM tier", fontSize = 10.sp, color = Color.Gray)
                }
            }
        }
    }
}
