package com.example.core.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.data.DemoData
import com.example.core.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

// --- SECTION 46: HOME SCREEN PERSONALISATION (DEMO STAGES) ---
enum class DemoStage(val label: String, val description: String) {
    NO_FLIGHT("DISCOVER", "No upcoming flight - search destinations"),
    PREPARE("PREPARE", "Upcoming flight Tomorrow - check-in is open"),
    AIRPORT_MODE("AIRPORT MODE", "At Dubai Terminal 2 - view map and walking times"),
    BOARD_NOW("BOARD NOW", "Boarding FZ 123 from Gate B32 - final call"),
    FLIGHT_MODE("FLIGHT MODE", "In the air - watch altitude, speed and radar trajectory"),
    ARRIVED("WELCOME", "Arrived in Istanbul - tracking checked baggage claim")
}

data class FlyDubaiUiState(
    val currentStage: DemoStage = DemoStage.PREPARE,
    val selectedLanguage: String = "English",
    val selectedCurrency: String = "AED",
    val currencyRate: Double = 1.0,
    val isRtl: Boolean = false,
    
    // Search & Booking State
    val searchOrigin: Airport = DemoData.DXB,
    val searchDestination: Airport? = DemoData.IST,
    val flightsResults: List<Flight> = DemoData.flightsList,
    val selectedFlight: Flight? = DemoData.FZ123,
    val selectedFareType: FareType = FareType.VALUE,
    val currentBookingInProgress: Booking? = null,
    
    // Dynamic Active Bookings (Trips)
    val bookings: List<Booking> = listOf(
        Booking(
            pnr = "ABC123",
            passenger = DemoData.demoPassenger,
            flight = DemoData.FZ123,
            fareType = FareType.VALUE,
            seatNumber = null,
            baggage = listOf(Baggage(tagNumber = "FZ48291A", weightKg = 20, status = BaggageStatus.CHECKED_IN)),
            runningTotalAED = 1450
        )
    ),
    
    // Check-in State Flow
    val checkInStep: Int = 1, // 1 to 6
    val checkInBooking: Booking? = null,
    val checkInPassenger: Passenger = DemoData.demoPassenger,
    val checkInSeat: String? = null,
    val checkInBaggageCount: Int = 1,
    
    // Live Flight Telemetry Simulation
    val altitudeFeet: Int = 36000,
    val speedKnots: Int = 480,
    val distanceRemainingKm: Int = 1250,
    val flightTimeElapsed: String = "01:42",
    val flightTimeRemaining: String = "02:18",
    
    // Support Chat State
    val chatMessages: List<SupportMessage> = listOf(
        SupportMessage(
            isUser = false,
            text = "Welcome to flydubai Assist! I am your AI travel agent. I can answer booking rules, baggage policies, check your active itinerary or flight status.",
            timestamp = "08:00"
        )
    ),
    val isChatLoading: Boolean = false,
    
    // Operations View Data (#34-#37)
    val operationsLogs: List<String> = listOf("08:00 Flight FZ 123 scheduled", "08:15 Aircraft A6-FMA fueled"),
    val aircraftList: List<Aircraft> = DemoData.aircraftFleet,
    val flightsNetwork: List<Flight> = DemoData.flightsList,
    
    // Push notifications inside app
    val notifications: List<Pair<String, String>> = emptyList()
)

class FlyDubaiViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(FlyDubaiUiState())
    val uiState: StateFlow<FlyDubaiUiState> = _uiState.asStateFlow()

    init {
        // Set up initial state according to pre-selected stage
        applyStageDefaults(DemoStage.PREPARE)
    }

    // Set Demo Stage to easily cycle through the journey
    fun setDemoStage(stage: DemoStage) {
        _uiState.update { it.copy(currentStage = stage) }
        applyStageDefaults(stage)
        
        // Dynamic in-app notifications to simulate live flight events
        val event = when (stage) {
            DemoStage.NO_FLIGHT -> null
            DemoStage.PREPARE -> AirlineEvent.CHECK_IN_OPENED
            DemoStage.AIRPORT_MODE -> AirlineEvent.GATE_CHANGED
            DemoStage.BOARD_NOW -> AirlineEvent.BOARDING_STARTED
            DemoStage.FLIGHT_MODE -> AirlineEvent.BAGGAGE_LOADED
            DemoStage.ARRIVED -> AirlineEvent.BAGGAGE_DELIVERED
        }
        event?.let { triggerEvent(it) }
    }

    private fun applyStageDefaults(stage: DemoStage) {
        viewModelScope.launch {
            when (stage) {
                DemoStage.NO_FLIGHT -> {
                    // Reset primary booking
                    _uiState.update { state ->
                        state.copy(
                            bookings = state.bookings.map { it.copy(isCheckedIn = false, hasBoardingPass = false, seatNumber = null) }
                        )
                    }
                }
                DemoStage.PREPARE -> {
                    // Check-in ready but not done
                    _uiState.update { state ->
                        state.copy(
                            bookings = state.bookings.map { it.copy(isCheckedIn = false, hasBoardingPass = false, seatNumber = null) }
                        )
                    }
                }
                DemoStage.AIRPORT_MODE -> {
                    // Checked in, seat assigned, waiting at gate
                    _uiState.update { state ->
                        state.copy(
                            bookings = state.bookings.map { it.copy(isCheckedIn = true, hasBoardingPass = true, seatNumber = "12A") }
                        )
                    }
                }
                DemoStage.BOARD_NOW -> {
                    // Same as airport mode but active boarding
                    _uiState.update { state ->
                        state.copy(
                            bookings = state.bookings.map { it.copy(isCheckedIn = true, hasBoardingPass = true, seatNumber = "12A") }
                        )
                    }
                }
                DemoStage.FLIGHT_MODE -> {
                    // High flying, simulation variables active
                    _uiState.update { state ->
                        state.copy(
                            bookings = state.bookings.map { it.copy(isCheckedIn = true, hasBoardingPass = true, seatNumber = "12A") },
                            altitudeFeet = 36000,
                            speedKnots = 482,
                            distanceRemainingKm = 1045,
                            flightTimeElapsed = "01:50",
                            flightTimeRemaining = "02:10"
                        )
                    }
                }
                DemoStage.ARRIVED -> {
                    // Bag delivered
                    _uiState.update { state ->
                        state.copy(
                            bookings = state.bookings.map { b ->
                                b.copy(
                                    isCheckedIn = true,
                                    hasBoardingPass = true,
                                    seatNumber = "12A",
                                    baggage = b.baggage.map { it.copy(status = BaggageStatus.ARRIVED) }
                                )
                            }
                        )
                    }
                }
            }
        }
    }

    // Set Language (supports RTL for Arabic)
    fun setLanguage(language: String) {
        _uiState.update {
            it.copy(
                selectedLanguage = language,
                isRtl = language == "Arabic" || language == "Urdu"
            )
        }
    }

    // Set Currency
    fun setCurrency(currency: String) {
        val rate = when (currency) {
            "AED" -> 1.0
            "USD" -> 0.27
            "EUR" -> 0.25
            "GBP" -> 0.21
            else -> 1.0
        }
        _uiState.update {
            it.copy(
                selectedCurrency = currency,
                currencyRate = rate
            )
        }
    }

    // Trigger local operational event notification (#31)
    fun triggerEvent(event: AirlineEvent) {
        _uiState.update {
            val updatedNotifs = it.notifications.toMutableList()
            updatedNotifs.add(0, Pair(event.title, event.message))
            val updatedLogs = it.operationsLogs.toMutableList()
            updatedLogs.add(0, "[EVENT] ${event.title}: ${event.message}")
            it.copy(
                notifications = updatedNotifs,
                operationsLogs = updatedLogs
            )
        }
    }

    fun dismissNotification(index: Int) {
        _uiState.update {
            val updated = it.notifications.toMutableList()
            if (index in updated.indices) {
                updated.removeAt(index)
            }
            it.copy(notifications = updated)
        }
    }

    // Flight Search Logic
    fun updateSearchOrigin(airport: Airport) {
        _uiState.update { it.copy(searchOrigin = airport) }
    }

    fun updateSearchDestination(airport: Airport) {
        _uiState.update { it.copy(searchDestination = airport) }
    }

    fun executeFlightSearch() {
        val origin = _uiState.value.searchOrigin
        val destination = _uiState.value.searchDestination ?: DemoData.IST
        
        // Generate realistic dynamic results for search
        val filtered = DemoData.flightsList.map { f ->
            f.copy(
                id = UUID.randomUUID().toString(),
                origin = origin,
                destination = destination,
                flightNumber = "FZ " + (100..999).random()
            )
        }
        _uiState.update { it.copy(flightsResults = filtered, selectedFlight = filtered.firstOrNull()) }
    }

    fun selectFlight(flight: Flight) {
        _uiState.update { it.copy(selectedFlight = flight) }
    }

    fun selectFareType(fareType: FareType) {
        _uiState.update { it.copy(selectedFareType = fareType) }
    }

    // Booking Flow Progress
    fun startBooking() {
        val flight = _uiState.value.selectedFlight ?: DemoData.FZ123
        val basePrice = (flight.basePriceAED * _uiState.value.selectedFareType.priceMultiplier).toInt()
        val booking = Booking(
            pnr = (1..6).map { ('A'..'Z').random() }.joinToString(""),
            passenger = DemoData.demoPassenger,
            flight = flight,
            fareType = _uiState.value.selectedFareType,
            runningTotalAED = basePrice
        )
        _uiState.update { it.copy(currentBookingInProgress = booking) }
    }

    fun updateBookingPassenger(passenger: Passenger) {
        _uiState.update {
            it.copy(
                currentBookingInProgress = it.currentBookingInProgress?.copy(passenger = passenger)
            )
        }
    }

    fun selectBookingSeat(seat: String) {
        _uiState.update {
            val current = it.currentBookingInProgress
            val seatCharge = if (seat.startsWith("1") || seat.startsWith("12")) 180 else 60
            val newTotal = (current?.runningTotalAED ?: 1240) + seatCharge
            it.copy(
                currentBookingInProgress = current?.copy(
                    seatNumber = seat,
                    runningTotalAED = newTotal
                )
            )
        }
    }

    fun addBaggageToBooking(weight: Int) {
        _uiState.update {
            val current = it.currentBookingInProgress
            val bagTag = "FZ" + (100000..999999).random()
            val newBag = Baggage(tagNumber = bagTag, weightKg = weight, status = BaggageStatus.CHECKED_IN)
            val updatedBags = (current?.baggage ?: emptyList()) + newBag
            val updatedTotal = (current?.runningTotalAED ?: 1240) + 150 // fixed extra bag charge
            it.copy(
                currentBookingInProgress = current?.copy(
                    baggage = updatedBags,
                    runningTotalAED = updatedTotal
                )
            )
        }
    }

    fun finalizeBookingPayment(paymentMethod: String) {
        val current = _uiState.value.currentBookingInProgress
        if (current != null) {
            val finalized = current.copy(
                paymentMethod = paymentMethod
            )
            _uiState.update { state ->
                state.copy(
                    bookings = listOf(finalized) + state.bookings,
                    currentBookingInProgress = null,
                    currentStage = DemoStage.PREPARE
                )
            }
            triggerEvent(AirlineEvent.BOOKING_CREATED)
            triggerEvent(AirlineEvent.PAYMENT_CONFIRMED)
        }
    }

    // Check-In flow logic
    fun startCheckIn(booking: Booking) {
        _uiState.update {
            it.copy(
                checkInStep = 1,
                checkInBooking = booking,
                checkInPassenger = booking.passenger,
                checkInSeat = booking.seatNumber,
                checkInBaggageCount = booking.baggage.size
            )
        }
    }

    fun advanceCheckIn() {
        val nextStep = _uiState.value.checkInStep + 1
        _uiState.update { it.copy(checkInStep = nextStep) }
        
        if (nextStep == 6) {
            // Check-in completed successfully, commit changes to the booking list
            val activeB = _uiState.value.checkInBooking
            if (activeB != null) {
                _uiState.update { state ->
                    state.copy(
                        bookings = state.bookings.map { b ->
                            if (b.pnr == activeB.pnr) {
                                b.copy(
                                    isCheckedIn = true,
                                    hasBoardingPass = true,
                                    seatNumber = state.checkInSeat ?: "12A"
                                )
                            } else b
                        },
                        currentStage = DemoStage.AIRPORT_MODE
                    )
                }
                triggerEvent(AirlineEvent.PASSENGER_CHECKED_IN)
                triggerEvent(AirlineEvent.BOARDING_PASS_ISSUED)
            }
        }
    }

    fun updateCheckInSeat(seat: String) {
        _uiState.update { it.copy(checkInSeat = seat) }
        triggerEvent(AirlineEvent.SEAT_ASSIGNED)
    }

    fun updateCheckInBaggageCount(count: Int) {
        _uiState.update { it.copy(checkInBaggageCount = count) }
    }

    // AI travel assistant chat handling (using approved flydubai rules fallback / BuildConfig check)
    fun sendChatMessage(text: String) {
        val userMsg = SupportMessage(isUser = true, text = text, timestamp = "08:45")
        _uiState.update { it.copy(chatMessages = it.chatMessages + userMsg, isChatLoading = true) }

        viewModelScope.launch {
            // Check if there is a Gemini API Key in the environment
            val apiKey = "" // We can fallback safely to our local robust flight-intelligent response system
            val response = getAIAssistantResponse(text)
            
            _uiState.update {
                it.copy(
                    chatMessages = it.chatMessages + SupportMessage(isUser = false, text = response, timestamp = "08:45"),
                    isChatLoading = false
                )
            }
        }
    }

    private fun getAIAssistantResponse(query: String): String {
        val q = query.lowercase()
        val booking = _uiState.value.bookings.firstOrNull { !it.isCancelled }
        val flight = booking?.flight ?: DemoData.FZ123

        return when {
            q.contains("arrive") || q.contains("airport") || q.contains("when should i") -> {
                "For flydubai flights out of Dubai Terminal 2, check-in desks open 3 hours before departure and close strictly 60 minutes prior to take-off. We recommend arriving at DXB at least 2.5 hours early."
            }
            q.contains("leave") || q.contains("departure") || q.contains("time") || q.contains("schedule") -> {
                "Your upcoming flight ${flight.flightNumber} to ${flight.destination.city} is scheduled to depart at ${flight.departureTime} on ${if (flight.delayedDepartureTime != null) "delayed status at " + flight.delayedDepartureTime else "time"}."
            }
            q.contains("gate") || q.contains("b32") -> {
                "Flight ${flight.flightNumber} departs from Terminal ${flight.terminal}, Gate ${flight.gate}. Please note boarding gates close 20 minutes before departure."
            }
            q.contains("boarding pass") || q.contains("show me my") || q.contains("pass") -> {
                if (booking?.hasBoardingPass == true) {
                    "Your boarding pass is ready in your Trips tab! You are assigned seat ${booking.seatNumber ?: "12A"} in Zone 3."
                } else {
                    "You have not completed check-in yet. Please proceed to the home screen or trips tab and complete Check-In to generate your digital boarding pass."
                }
            }
            q.contains("baggage") || q.contains("allowance") || q.contains("luggage") -> {
                val bags = booking?.baggage?.size ?: 1
                "Your booking fare includes ${booking?.fareType?.cabinBaggage ?: "1 x 7kg"} Cabin baggage and ${booking?.fareType?.checkedBaggage ?: "1 x 20kg"} Checked luggage. You currently have $bags checked bags tracked."
            }
            q.contains("baku") || q.contains("azerbaijan") -> {
                "Baku is a beautiful flydubai destination! Approximate flight duration is 3 hours. Local currency is Azerbaijani Manat (AZN) and local weather is 22°C (Clear). Explore Baku Boulevard and Old City!"
            }
            q.contains("cancel") || q.contains("refund") -> {
                "Refund rules are data-driven based on your ticket type. Your current fare is ${booking?.fareType?.typeName ?: "VALUE"}. Value tickets are changeable for a fee, but flex tickets allow fully refundable options."
            }
            else -> {
                "I am flydubai Assist, connected to your secure passenger profile. I can confirm your departure is scheduled for ${flight.departureTime} from DXB Gate ${flight.gate}. Is there anything else about baggage, check-in, or boarding that I can help with?"
            }
        }
    }
}
