package com.example.feature.operations

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Aircraft
import com.example.core.model.TurnaroundStep
import com.example.core.viewmodel.FlyDubaiUiState
import com.example.core.viewmodel.FlyDubaiViewModel
import com.example.design.*
import com.example.ui.theme.*

@Composable
fun OperationsViewScreen(
    viewModel: FlyDubaiViewModel,
    uiState: FlyDubaiUiState
) {
    var opsSection by remember { mutableStateOf("FLEET") } // FLEET, TURNAROUNDS, EVENT_LOGS

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "AIRLINE OPERATIONS",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
            )
            Text(
                text = "INTERNAL COCKPIT",
                style = MaterialTheme.typography.labelSmall.copy(color = FlyDubaiOrange, fontWeight = FontWeight.Bold)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Navigation Header Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("FLEET", "TURNAROUNDS", "EVENT_LOGS").forEach { sec ->
                val isSel = opsSection == sec
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isSel) FlyDubaiOrange else FlyDubaiSand,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { opsSection = sec }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = sec,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) Color.White else FlyDubaiCharcoal,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (opsSection) {
                "FLEET" -> OperationsFleetView(uiState)
                "TURNAROUNDS" -> OperationsTurnaroundsView(uiState)
                "EVENT_LOGS" -> OperationsEventLogsView(uiState)
            }
        }
    }
}

@Composable
fun OperationsFleetView(uiState: FlyDubaiUiState) {
    Column {
        Text("ACTIVE BOEING 737 MAX FLEET", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(uiState.aircraftList) { aircraft ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(10.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null, tint = FlyDubaiOrange, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = aircraft.registration,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
                            )
                            Text(text = aircraft.model, fontSize = 12.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (aircraft.status == "IN SERVICE") Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                                        RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = aircraft.status,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = if (aircraft.status == "IN SERVICE") Color(0xFF2E7D32) else Color(0xFFC62828)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Hours: ${aircraft.hours} • Cycles: ${aircraft.cycles}", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OperationsTurnaroundsView(uiState: FlyDubaiUiState) {
    Column {
        Text("AIRCRAFT TURNAROUND PIPELINES", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Text("Real-time ground ops checklist sequence", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))

        FZCard {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("AIRCRAFT REG", fontWeight = FontWeight.Bold)
                Text("A6-FMA", fontWeight = FontWeight.ExtraBold, color = FlyDubaiOrange)
            }
            Text("FLIGHT ASSIGNMENT: FZ 123 (DXB → IST)", fontSize = 12.sp, color = Color.Gray)

            Spacer(modifier = Modifier.height(16.dp))

            // Sequence representation Arrival -> Deboard -> Clean -> Cater -> Baggage -> Board -> Pushback
            val steps = TurnaroundStep.values().toList()
            steps.forEachIndexed { index, step ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .background(if (index <= 5) FlyDubaiBlue else Color.LightGray, RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (index <= 5) {
                            Text("✓", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = step.label,
                        fontWeight = if (index == 5) FontWeight.Bold else FontWeight.Normal,
                        color = if (index == 5) FlyDubaiOrange else if (index < 5) Color.Gray else FlyDubaiCharcoal,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
fun OperationsEventLogsView(uiState: FlyDubaiUiState) {
    Column {
        Text("OPERATIONAL EVENT DISPATCH LOGS", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Text("Live secure audit metadata stream", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(8.dp)),
            colors = CardDefaults.cardColors(containerColor = FlyDubaiCharcoal)
        ) {
            LazyColumn(
                modifier = Modifier
                    .padding(12.dp)
                    .fillMaxSize()
            ) {
                items(uiState.operationsLogs) { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.ListAlt, contentDescription = null, tint = FlyDubaiOrange, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = log,
                            color = Color.LightGray,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
