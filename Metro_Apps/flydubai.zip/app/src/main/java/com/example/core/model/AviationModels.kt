package com.example.core.model

import java.util.UUID

// --- SECTION 38: CANONICAL AVIATION DATA MODEL ---

data class Passenger(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val firstName: String,
    val middleName: String = "",
    val surname: String,
    val dateOfBirth: String,
    val nationality: String,
    val passportNumber: String,
    val passportExpiry: String,
    val contactEmail: String,
    val contactPhone: String
)

data class Aircraft(
    val id: String = UUID.randomUUID().toString(),
    val model: String = "Boeing 737 MAX 8",
    val registration: String,
    val status: String = "IN SERVICE", // IN SERVICE, MAINTENANCE, TURNAROUND
    val hours: Int = 4250,
    val cycles: Int = 1840,
    val currentTurnaroundStep: TurnaroundStep = TurnaroundStep.DEBOARD
)

enum class TurnaroundStep(val label: String, val progress: Float) {
    ARRIVAL("ARRIVAL", 0.0f),
    DEBOARD("DEBOARD", 0.15f),
    CLEAN("CLEAN", 0.35f),
    CATER("CATER", 0.50f),
    BAGGAGE("BAGGAGE LOAD", 0.70f),
    BOARD("BOARDING", 0.85f),
    PUSHBACK("PUSHBACK", 1.0f)
}

data class Airport(
    val code: String, // DXB
    val name: String, // Dubai International Airport
    val city: String, // Dubai
    val country: String, // United Arab Emirates
    val terminal: String = "2"
)

enum class FlightStatus(val label: String, val isDelayed: Boolean = false) {
    SCHEDULED("Scheduled"),
    CHECK_IN_OPEN("Check-in Open"),
    BOARDING("Boarding"),
    FINAL_CALL("Final Call"),
    DEPARTED("Departed"),
    AIRBORNE("Airborne"),
    LANDED("Landed"),
    DELAYED("Delayed", true),
    CANCELLED("Cancelled"),
    DIVERTED("Diverted")
}

data class Flight(
    val id: String = UUID.randomUUID().toString(),
    val flightNumber: String, // FZ 123
    val origin: Airport,
    val destination: Airport,
    val departureTime: String, // "08:40"
    val arrivalTime: String, // "12:40"
    val duration: String = "4h 00m",
    val aircraft: Aircraft,
    val status: FlightStatus = FlightStatus.SCHEDULED,
    val gate: String = "B32",
    val terminal: String = "2",
    val basePriceAED: Int = 1240,
    val isNonStop: Boolean = true,
    val stopsCount: Int = 0,
    val delayedDepartureTime: String? = null, // "10:15"
    val originalDepartureTime: String = "08:40"
)

enum class FareType(
    val typeName: String,
    val cabinBaggage: String,
    val checkedBaggage: String,
    val seatSelection: String,
    val mealIncluded: Boolean,
    val refundAllowed: Boolean,
    val priceMultiplier: Double
) {
    BASIC("BASIC", "1 x 7kg", "None", "Paid Only", false, false, 1.0),
    VALUE("VALUE", "1 x 7kg", "1 x 20kg", "Standard Free", true, false, 1.25),
    FLEX("FLEX", "1 x 7kg", "1 x 30kg", "Any Free", true, true, 1.5)
}

data class Baggage(
    val tagNumber: String, // e.g. "FZ123456"
    val weightKg: Int = 20,
    val status: BaggageStatus = BaggageStatus.CHECKED_IN,
    val claimBelt: String = "BELT 7"
)

enum class BaggageStatus(val label: String) {
    CHECKED_IN("CHECKED IN"),
    LOADED("LOADED"),
    TRANSFERRED("TRANSFERRED"),
    ARRIVED("ARRIVED"),
    DELIVERED("DELIVERED")
}

data class Booking(
    val id: String = UUID.randomUUID().toString(),
    val pnr: String, // 6 characters
    val passenger: Passenger,
    val flight: Flight,
    val fareType: FareType,
    val seatNumber: String? = null,
    val baggage: List<Baggage> = emptyList(),
    val isCheckedIn: Boolean = false,
    val hasBoardingPass: Boolean = false,
    val runningTotalAED: Int = 0,
    val paymentMethod: String? = null,
    val isCancelled: Boolean = false
)

data class LoyaltyAccount(
    val tier: String = "GOLD",
    val points: Int = 42850,
    val nextTierPoints: Int = 50000,
    val nextTierName: String = "PLATINUM"
)

data class SupportMessage(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean,
    val text: String,
    val timestamp: String
)

// --- SECTION 39: EVENT-DRIVEN NOTIFICATION MODELS ---

enum class AirlineEvent(val title: String, val message: String) {
    BOOKING_CREATED("Booking Confirmed", "Your flydubai booking has been successfully confirmed."),
    PAYMENT_CONFIRMED("Payment Processed", "Your payment was tokenized and secure payment was processed successfully."),
    CHECK_IN_OPENED("Check-In Open", "Check-in for your flight FZ 123 is now open. Prepare your boarding pass."),
    PASSENGER_CHECKED_IN("Checked In Successfully", "You have checked in for flight FZ 123. Safe travels!"),
    SEAT_ASSIGNED("Seat Selection Confirmed", "Your seat assignment has been successfully updated."),
    BOARDING_PASS_ISSUED("Boarding Pass Available", "Your digital boarding pass for FZ 123 is ready in your wallet."),
    GATE_CHANGED("Gate Changed", "Your boarding gate has been updated to Gate B32."),
    BOARDING_STARTED("Boarding Started", "Boarding has commenced for FZ 123. Please proceed to Gate B32 immediately."),
    FINAL_CALL("Final Call", "Final call for flight FZ 123. Proceed to Gate B32 for immediate boarding."),
    FLIGHT_DELAYED("Flight Delayed", "Your flight FZ 123 is delayed due to operations. New departure: 10:15."),
    BAGGAGE_LOADED("Baggage Loaded", "Your checked bag (Tag: FZ48291A) has been loaded onto FZ 123."),
    BAGGAGE_DELIVERED("Baggage Arrived", "Your baggage is ready at Istanbul Airport. Claim belt: BELT 7.")
}
