package com.example.feature.checkin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.LocalMall
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Booking
import com.example.core.viewmodel.FlyDubaiUiState
import com.example.core.viewmodel.FlyDubaiViewModel
import com.example.design.*
import com.example.ui.theme.*

@Composable
fun CheckInFlowScreen(
    viewModel: FlyDubaiViewModel,
    uiState: FlyDubaiUiState,
    onNavigateHome: () -> Unit
) {
    val step = uiState.checkInStep
    val activeBooking = uiState.checkInBooking ?: uiState.bookings.firstOrNull()

    if (activeBooking == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No active bookings found to check in. Please book a flight first.", textAlign = TextAlign.Center)
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Step Progress Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "FLIGHT CHECK-IN",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
            )
            Text(
                text = "STEP $step OF 6",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = FlyDubaiOrange)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Linear Progress Indicator
        LinearProgressIndicator(
            progress = { (step / 6.0f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp),
            color = FlyDubaiOrange,
            trackColor = FlyDubaiSand
        )

        Spacer(modifier = Modifier.height(20.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (step) {
                1 -> CheckInStep1Passenger(uiState, viewModel)
                2 -> CheckInStep2Documents(uiState, viewModel)
                3 -> CheckInStep3Seat(uiState, viewModel)
                4 -> CheckInStep4Baggage(uiState, viewModel)
                5 -> CheckInStep5Confirmation(uiState, viewModel)
                6 -> CheckInStep6BoardingPass(uiState, activeBooking, onNavigateHome)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (step < 6) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (step > 1) {
                    OutlinedButton(
                        onClick = {
                            // Go back
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("BACK", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                    }
                }
                FZButton(
                    text = if (step == 5) "ISSUE BOARDING PASS" else "CONFIRM & CONTINUE",
                    onClick = {
                        viewModel.advanceCheckIn()
                    },
                    modifier = Modifier.weight(2f),
                    testTag = "checkin_next_btn"
                )
            }
        }
    }
}

@Composable
fun CheckInStep1Passenger(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel
) {
    Column {
        Text("CONFIRM PASSENGER", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Spacer(modifier = Modifier.height(8.dp))
        Text("Please confirm the primary passenger details match your travel tickets.", color = Color.Gray, fontSize = 13.sp)

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, FlyDubaiSandDark)
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, tint = FlyDubaiBlue, modifier = Modifier.size(40.dp))
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "${uiState.checkInPassenger.firstName} ${uiState.checkInPassenger.surname}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
                    )
                    Text("Nationality: ${uiState.checkInPassenger.nationality}", fontSize = 13.sp, color = Color.Gray)
                    Text("DOB: ${uiState.checkInPassenger.dateOfBirth}", fontSize = 13.sp, color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun CheckInStep2Documents(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel
) {
    var consentChecked by remember { mutableStateOf(false) }

    Column {
        Text("TRAVEL DOCUMENTS WALLET", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Spacer(modifier = Modifier.height(8.dp))
        Text("Verify passport validity and visa requirements for Turkey.", color = Color.Gray, fontSize = 13.sp)

        Spacer(modifier = Modifier.height(20.dp))

        FZCard {
            Text("SECURE STORED PASSPORT", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Passport No", color = Color.Gray)
                Text(uiState.checkInPassenger.passportNumber, fontWeight = FontWeight.Bold)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Expiry Date", color = Color.Gray)
                Text(uiState.checkInPassenger.passportExpiry, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("VERIFIED BY SECURITY DATA SERVICE", fontSize = 12.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { consentChecked = !consentChecked },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = consentChecked, onCheckedChange = { consentChecked = it })
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "I certify that these passport documents are valid and belong to the ticketed passenger.",
                fontSize = 12.sp,
                color = FlyDubaiCharcoal
            )
        }
    }
}

@Composable
fun CheckInStep3Seat(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel
) {
    Column {
        Text("CHOOSE SEAT FOR CHECK-IN", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Spacer(modifier = Modifier.height(4.dp))
        Text("Confirm your flight seat assignment.", color = Color.Gray, fontSize = 13.sp)

        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Selected Seat:", fontWeight = FontWeight.Bold)
            Text(
                text = uiState.checkInSeat ?: "12A (Assigned)",
                fontWeight = FontWeight.ExtraBold,
                color = FlyDubaiOrange
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Box(modifier = Modifier.fillMaxSize()) {
            FZSeatMap(
                selectedSeat = uiState.checkInSeat,
                onSeatSelected = { seat ->
                    viewModel.updateCheckInSeat(seat)
                }
            )
        }
    }
}

@Composable
fun CheckInStep4Baggage(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel
) {
    Column {
        Text("CHECKED BAGGAGE STATUS", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Spacer(modifier = Modifier.height(8.dp))
        Text("Confirm how many checked bags you will bring to DXB Terminal 2.", color = Color.Gray, fontSize = 13.sp)

        Spacer(modifier = Modifier.height(24.dp))

        FZCard {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocalMall, contentDescription = null, tint = FlyDubaiBlue, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Checked Bag Allowance", fontWeight = FontWeight.Bold)
                        Text("1 Bag up to 20kg included", color = Color.Gray, fontSize = 12.sp)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        if (uiState.checkInBaggageCount > 0) {
                            viewModel.updateCheckInBaggageCount(uiState.checkInBaggageCount - 1)
                        }
                    }) {
                        Text("-", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("${uiState.checkInBaggageCount}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                    IconButton(onClick = {
                        viewModel.updateCheckInBaggageCount(uiState.checkInBaggageCount + 1)
                    }) {
                        Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CheckInStep5Confirmation(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel
) {
    Column {
        Text("CONFIRM DEPARTURE INFO", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Spacer(modifier = Modifier.height(16.dp))

        FZCard {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Passenger")
                Text("${uiState.checkInPassenger.firstName} ${uiState.checkInPassenger.surname}", fontWeight = FontWeight.Bold)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Flight")
                Text(uiState.checkInBooking?.flight?.flightNumber ?: "FZ 123", fontWeight = FontWeight.Bold)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Seat Assignment")
                Text(uiState.checkInSeat ?: "12A", fontWeight = FontWeight.Bold, color = FlyDubaiOrange)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Checked Bags")
                Text("${uiState.checkInBaggageCount} Checked Bag(s)", fontWeight = FontWeight.Bold)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Origin")
                Text(uiState.checkInBooking?.flight?.origin?.city ?: "Dubai", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun CheckInStep6BoardingPass(
    uiState: FlyDubaiUiState,
    booking: Booking,
    onNavigateHome: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        FZBoardingPass(
            flight = booking.flight,
            passengerName = "${uiState.checkInPassenger.firstName} ${uiState.checkInPassenger.surname}",
            seat = uiState.checkInSeat ?: "12A",
            pnr = booking.pnr,
            onSaveToWallet = {
                // Done
            }
        )

        Spacer(modifier = Modifier.height(20.dp))

        FZButton(
            text = "RETURN TO DASHBOARD",
            onClick = onNavigateHome,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
