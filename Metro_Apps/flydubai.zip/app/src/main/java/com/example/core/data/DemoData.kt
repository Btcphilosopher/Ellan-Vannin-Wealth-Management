package com.example.core.data

import com.example.core.model.Aircraft
import com.example.core.model.Airport
import com.example.core.model.Flight
import com.example.core.model.FlightStatus
import com.example.core.model.Passenger

object DemoData {

    // Disclaimer
    const val ENVIRONMENT_DISCLAIMER = "DEMO ENVIRONMENT — SYNTHETIC DATA"

    val DXB = Airport("DXB", "Dubai International Airport", "Dubai", "United Arab Emirates", "2")
    val IST = Airport("IST", "Istanbul Airport", "Istanbul", "Turkey", "I")
    val MCT = Airport("MCT", "Muscat International Airport", "Muscat", "Oman", "1")
    val DOH = Airport("DOH", "Hamad International Airport", "Doha", "Qatar", "A")
    val GYD = Airport("GYD", "Heydar Aliyev International Airport", "Baku", "Azerbaijan", "1")
    val BEG = Airport("BEG", "Belgrade Nikola Tesla Airport", "Belgrade", "Serbia", "2")
    val CMB = Airport("CMB", "Bandaranaike International Airport", "Colombo", "Sri Lanka", "B")
    val KIX = Airport("KIX", "Kansai International Airport", "Osaka", "Japan", "1")
    val LED = Airport("LED", "Pulkovo Airport", "St. Petersburg", "Russia", "1")
    val KWI = Airport("KWI", "Kuwait International Airport", "Kuwait City", "Kuwait", "M")

    val airports = listOf(DXB, IST, MCT, DOH, GYD, BEG, CMB, KIX, LED, KWI)

    // Aircraft fleet
    val aircraftFleet = listOf(
        Aircraft(registration = "A6-FMA", model = "Boeing 737 MAX 8", status = "IN SERVICE"),
        Aircraft(registration = "A6-FMB", model = "Boeing 737 MAX 8", status = "IN SERVICE"),
        Aircraft(registration = "A6-FMC", model = "Boeing 737 MAX 8", status = "TURNAROUND"),
        Aircraft(registration = "A6-FMD", model = "Boeing 737 MAX 8", status = "IN SERVICE"),
        Aircraft(registration = "A6-FME", model = "Boeing 737 MAX 8", status = "MAINTENANCE")
    )

    // Primary demo flight
    val FZ123 = Flight(
        flightNumber = "FZ 123",
        origin = DXB,
        destination = IST,
        departureTime = "08:40",
        arrivalTime = "12:40",
        duration = "4h 00m",
        aircraft = aircraftFleet[0],
        status = FlightStatus.SCHEDULED,
        gate = "B32",
        terminal = "2",
        basePriceAED = 1240,
        originalDepartureTime = "08:40"
    )

    // Other flight schedules to populate results
    val flightsList = listOf(
        FZ123,
        Flight(
            flightNumber = "FZ 125",
            origin = DXB,
            destination = IST,
            departureTime = "14:20",
            arrivalTime = "18:20",
            duration = "4h 00m",
            aircraft = aircraftFleet[1],
            status = FlightStatus.SCHEDULED,
            gate = "C15",
            terminal = "2",
            basePriceAED = 1450,
            originalDepartureTime = "14:20"
        ),
        Flight(
            flightNumber = "FZ 045",
            origin = DXB,
            destination = MCT,
            departureTime = "07:15",
            arrivalTime = "08:25",
            duration = "1h 10m",
            aircraft = aircraftFleet[2],
            status = FlightStatus.CHECK_IN_OPEN,
            gate = "B12",
            terminal = "2",
            basePriceAED = 450,
            originalDepartureTime = "07:15"
        ),
        Flight(
            flightNumber = "FZ 701",
            origin = DXB,
            destination = GYD,
            departureTime = "11:55",
            arrivalTime = "14:55",
            duration = "3h 00m",
            aircraft = aircraftFleet[3],
            status = FlightStatus.SCHEDULED,
            gate = "B24",
            terminal = "2",
            basePriceAED = 1100,
            originalDepartureTime = "11:55"
        ),
        Flight(
            flightNumber = "FZ 456",
            origin = DOH,
            destination = IST,
            departureTime = "15:30",
            arrivalTime = "19:50",
            duration = "4h 20m",
            aircraft = aircraftFleet[1],
            status = FlightStatus.SCHEDULED,
            gate = "A02",
            terminal = "1",
            basePriceAED = 1380,
            originalDepartureTime = "15:30"
        )
    )

    // Demo user
    val demoPassenger = Passenger(
        title = "Mr.",
        firstName = "TOM",
        middleName = "",
        surname = "LOVEITT",
        dateOfBirth = "1992-05-15",
        nationality = "United Kingdom",
        passportNumber = "GBR948271A",
        passportExpiry = "2032-10-12",
        contactEmail = "tom@ahyx.org",
        contactPhone = "+971 50 123 4567"
    )

    // Destination discovery data with categories (Beach, Business, Culture, Food, Mountains, Desert, City, Family)
    data class DiscoveryDestination(
        val name: String,
        val country: String,
        val category: String,
        val imageDescription: String,
        val duration: String,
        val weather: String,
        val timeZone: String,
        val currency: String,
        val description: String,
        val neighborhoods: List<String>,
        val foodSpecialties: List<String>
    )

    val destinations = listOf(
        DiscoveryDestination(
            name = "BAKU",
            country = "Azerbaijan",
            category = "Culture",
            imageDescription = "Flame Towers overlooking the Caspian Sea, combining historical stone and hyper-modern architecture.",
            duration = "Approx. 3h",
            weather = "22°C (Clear)",
            timeZone = "GMT+4",
            currency = "AZN (Azerbaijani Manat)",
            description = "Where East meets West on the Caspian Sea coast, combining UNESCO-listed Old Town walls with dazzling modern architecture.",
            neighborhoods = listOf("Icherisheher (Old City)", "Baku Boulevard", "Fountain Square"),
            foodSpecialties = listOf("Plov (Saffron rice)", "Dushbara (Dumpling soup)", "Kutab (Herb flatbread)")
        ),
        DiscoveryDestination(
            name = "MUSCAT",
            country = "Oman",
            category = "Desert",
            imageDescription = "Stunning white domed mosques nestled against ancient volcanic mountains and turquoise waters.",
            duration = "Approx. 1h 10m",
            weather = "31°C (Sunny)",
            timeZone = "GMT+4",
            currency = "OMR (Omani Rial)",
            description = "A peaceful haven where traditional white low-rise architecture blends seamlessly with natural mountain backdrops.",
            neighborhoods = listOf("Mutrah Mutrah Corniche", "Ruwi Commercial Area", "Al Qurum Beach"),
            foodSpecialties = listOf("Shuwa (Slow-cooked meat)", "Omani Halwa", "Meshkak (Spiced skewers)")
        ),
        DiscoveryDestination(
            name = "BELGRADE",
            country = "Serbia",
            category = "City",
            imageDescription = "Fortress overlooking the confluence of the Danube and Sava rivers, bursting with street cafes and lively squares.",
            duration = "Approx. 5h 30m",
            weather = "17°C (Partly Cloudy)",
            timeZone = "GMT+2",
            currency = "RSD (Serbian Dinar)",
            description = "One of Europe's oldest cities, famous for its energetic dining scene, fortress parks, and warm Balkan hospitality.",
            neighborhoods = listOf("Stari Grad (Old Town)", "Skadarlija (Bohemian)", "Dorcol"),
            foodSpecialties = listOf("Cevapi (Grilled meat)", "Sarma (Stuffed cabbage)", "Kajmak (Clotted cream)")
        ),
        DiscoveryDestination(
            name = "COLOMBO",
            country = "Beach",
            category = "Beach",
            imageDescription = "Vibrant tropical capital with colonial architecture, bustling markets, and sweeping coastline sand dunes.",
            duration = "Approx. 4h 30m",
            weather = "29°C (Tropical Rain)",
            timeZone = "GMT+5.5",
            currency = "LKR (Sri Lankan Rupee)",
            description = "A sprawling tropical seaside gateway with beautiful temples, colonial charm, and rich coconut-infused culinary heritage.",
            neighborhoods = listOf("Fort District", "Pettah Market", "Cinnamon Gardens"),
            foodSpecialties = listOf("Egg Hoppers", "Kottu Roti", "Pol Sambol")
        )
    )
}
