package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = FlyDubaiBlueDark,
    secondary = FlyDubaiOrangeDark,
    tertiary = FlyDubaiSandDark,
    background = FlyDubaiBackgroundDark,
    surface = FlyDubaiSurfaceDark,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF24242B),
    onSurfaceVariant = Color(0xFFDCD3C7)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = FlyDubaiBlue,
    secondary = FlyDubaiOrange,
    tertiary = FlyDubaiSand,
    background = FlyDubaiWarmWhite,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = FlyDubaiCharcoal,
    onSurface = FlyDubaiCharcoal,
    surfaceVariant = FlyDubaiSand,
    onSurfaceVariant = Color(0xFF4A453F)
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = true,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
