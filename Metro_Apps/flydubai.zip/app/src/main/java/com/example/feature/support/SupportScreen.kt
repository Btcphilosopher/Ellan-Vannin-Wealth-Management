package com.example.feature.support

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.DemoData
import com.example.core.viewmodel.FlyDubaiUiState
import com.example.core.viewmodel.FlyDubaiViewModel
import com.example.design.*
import com.example.ui.theme.*

@Composable
fun SupportScreen(
    viewModel: FlyDubaiViewModel,
    uiState: FlyDubaiUiState
) {
    var chatQuery by remember { mutableStateOf("") }
    var selectedGuideDestination by remember { mutableStateOf<DemoData.DiscoveryDestination?>(null) }

    if (selectedGuideDestination != null) {
        DestinationGuideScreen(
            destination = selectedGuideDestination!!,
            onBack = { selectedGuideDestination = null }
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Main split: AI ASSISTANT & DISCOVER PORTAL
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "FLYDUBAI ASSIST",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
            )
            IconButton(onClick = { viewModel.sendChatMessage("Help") }) {
                Icon(Icons.Default.Refresh, contentDescription = "Reset Chat")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Suggestion Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val suggestions = listOf(
                "When should I arrive?",
                "What's my flight status?",
                "Show my boarding pass",
                "Has my gate changed?",
                "How much baggage is allowed?"
            )
            items(suggestions) { suggestion ->
                Box(
                    modifier = Modifier
                        .background(FlyDubaiSand, RoundedCornerShape(16.dp))
                        .clickable { viewModel.sendChatMessage(suggestion) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = suggestion, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Chat Conversation Window
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.3f)
                .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(uiState.chatMessages) { message ->
                        val isUser = message.isUser
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isUser) FlyDubaiOrange else FlyDubaiBlue)
                                    .padding(10.dp)
                                    .widthIn(max = 240.dp)
                            ) {
                                Text(
                                    text = message.text,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }

                if (uiState.isChatLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier
                            .size(20.dp)
                            .align(Alignment.CenterHorizontally),
                        color = FlyDubaiOrange
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Query Text Input Field
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = chatQuery,
                        onValueChange = { chatQuery = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ask flydubai AI Assistant...", fontSize = 12.sp) },
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FlyDubaiOrange,
                            unfocusedBorderColor = Color.Gray
                        ),
                        trailingIcon = {
                            IconButton(onClick = {
                                if (chatQuery.isNotEmpty()) {
                                    viewModel.sendChatMessage(chatQuery)
                                    chatQuery = ""
                                }
                            }) {
                                Icon(Icons.Default.Send, contentDescription = "Send", tint = FlyDubaiBlue)
                            }
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Destination Discovery Section (#24, #25)
        Text(
            text = "WHERE NEXT? DISCOVER",
            fontWeight = FontWeight.ExtraBold,
            color = FlyDubaiBlue,
            fontSize = 14.sp
        )
        Text("Get practical information and custom guides", color = Color.Gray, fontSize = 11.sp)

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(DemoData.destinations) { dest ->
                Card(
                    modifier = Modifier
                        .width(200.dp)
                        .fillMaxHeight()
                        .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(12.dp))
                        .clickable { selectedGuideDestination = dest },
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column {
                        // Simulated Image Asset representation with high fidelity M3 Canvas
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .background(FlyDubaiBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.LocationCity, contentDescription = null, modifier = Modifier.size(32.dp), tint = FlyDubaiOrange)
                        }

                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = dest.name,
                                fontWeight = FontWeight.Bold,
                                color = FlyDubaiBlue,
                                fontSize = 14.sp
                            )
                            Text(
                                text = dest.country,
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = dest.category.uppercase(),
                                fontWeight = FontWeight.ExtraBold,
                                color = FlyDubaiOrange,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DestinationGuideScreen(
    destination: DemoData.DiscoveryDestination,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "${destination.name} TRAVEL GUIDE",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = FlyDubaiBlue)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(destination.name, style = MaterialTheme.typography.headlineMedium.copy(color = Color.White, fontWeight = FontWeight.ExtraBold))
                        Text(destination.country, style = MaterialTheme.typography.bodyMedium.copy(color = FlyDubaiSand))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(destination.description, color = Color.White, fontSize = 13.sp)
                    }
                }
            }

            // Practical quick metrics
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FZMetric(label = "Duration", value = destination.duration, modifier = Modifier.weight(1f))
                    FZMetric(label = "Weather", value = destination.weather, modifier = Modifier.weight(1f))
                }
            }

            // Arriving Practical Info
            item {
                FZCard {
                    Text("ARRIVING PRACTICALITIES", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Currency")
                        Text(destination.currency, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Time Zone")
                        Text(destination.timeZone, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Food & Neighborhoods list guide
            item {
                FZCard {
                    Text("POPULAR NEIGHBORHOODS", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                    Spacer(modifier = Modifier.height(8.dp))
                    destination.neighborhoods.forEach { place ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp), tint = FlyDubaiOrange)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(place, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Food specialties
            item {
                FZCard {
                    Text("LOCAL FOOD SPECIALTIES", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                    Spacer(modifier = Modifier.height(8.dp))
                    destination.foodSpecialties.forEach { food ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                            Icon(Icons.Default.RestaurantMenu, contentDescription = null, modifier = Modifier.size(12.dp), tint = FlyDubaiOrange)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(food, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
