package com.example.feature.booking

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.DemoData
import androidx.compose.foundation.BorderStroke
import com.example.core.model.*
import com.example.core.viewmodel.FlyDubaiUiState
import com.example.core.viewmodel.FlyDubaiViewModel
import com.example.design.*
import com.example.ui.theme.*

@Composable
fun BookingFlowScreen(
    viewModel: FlyDubaiViewModel,
    uiState: FlyDubaiUiState,
    onNavigateToTrips: () -> Unit
) {
    var flowStep by remember { mutableStateOf("SEARCH") } // SEARCH, RESULTS, FARE, PASSENGER, SEAT, ADDONS, PAYMENT, CONFIRM

    when (flowStep) {
        "SEARCH" -> FlightSearchScreen(
            uiState = uiState,
            viewModel = viewModel,
            onSearchCompleted = {
                viewModel.executeFlightSearch()
                flowStep = "RESULTS"
            }
        )
        "RESULTS" -> SearchResultsScreen(
            uiState = uiState,
            viewModel = viewModel,
            onFlightSelected = { flight ->
                viewModel.selectFlight(flight)
                flowStep = "FARE"
            },
            onBack = { flowStep = "SEARCH" }
        )
        "FARE" -> FareSelectorScreen(
            uiState = uiState,
            viewModel = viewModel,
            onFareSelected = { fare ->
                viewModel.selectFareType(fare)
                viewModel.startBooking()
                flowStep = "PASSENGER"
            },
            onBack = { flowStep = "RESULTS" }
        )
        "PASSENGER" -> PassengerDetailsScreen(
            uiState = uiState,
            viewModel = viewModel,
            onNext = { flowStep = "SEAT" },
            onBack = { flowStep = "FARE" }
        )
        "SEAT" -> SeatSelectionScreen(
            uiState = uiState,
            viewModel = viewModel,
            onNext = { flowStep = "ADDONS" },
            onBack = { flowStep = "PASSENGER" }
        )
        "ADDONS" -> AddonsScreen(
            uiState = uiState,
            viewModel = viewModel,
            onNext = { flowStep = "PAYMENT" },
            onBack = { flowStep = "SEAT" }
        )
        "PAYMENT" -> PaymentScreen(
            uiState = uiState,
            viewModel = viewModel,
            onPaymentSuccess = {
                flowStep = "CONFIRM"
            },
            onBack = { flowStep = "ADDONS" }
        )
        "CONFIRM" -> BookingConfirmationScreen(
            uiState = uiState,
            onViewTrips = {
                onNavigateToTrips()
            }
        )
    }
}

@Composable
fun FlightSearchScreen(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel,
    onSearchCompleted: () -> Unit
) {
    var selectedTab by remember { mutableStateOf("Return") } // Return, One Way, Multi-city
    var originSearchQuery by remember { mutableStateOf("") }
    var destSearchQuery by remember { mutableStateOf("") }
    var showOriginList by remember { mutableStateOf(false) }
    var showDestList by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "BOOK A FLIGHT",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Trip Type Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Return", "One Way", "Multi-City").forEach { tab ->
                val isSel = selectedTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isSel) FlyDubaiOrange else FlyDubaiSand,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { selectedTab = tab }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) Color.White else FlyDubaiCharcoal,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // FROM Airport Selection
        Text("FROM", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color.Gray)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = if (originSearchQuery.isEmpty()) uiState.searchOrigin.name else originSearchQuery,
            onValueChange = {
                originSearchQuery = it
                showOriginList = true
            },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = FlyDubaiBlue) },
            trailingIcon = {
                if (showOriginList) {
                    IconButton(onClick = { showOriginList = false }) {
                        Icon(Icons.Default.Close, contentDescription = null)
                    }
                }
            },
            placeholder = { Text("Dubai (DXB)") }
        )

        if (showOriginList) {
            val filteredOrigins = DemoData.airports.filter {
                it.city.contains(originSearchQuery, ignoreCase = true) ||
                        it.code.contains(originSearchQuery, ignoreCase = true) ||
                        it.name.contains(originSearchQuery, ignoreCase = true)
            }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 150.dp)
                    .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                LazyColumn {
                    items(filteredOrigins) { airport ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateSearchOrigin(airport)
                                    originSearchQuery = "${airport.city} (${airport.code})"
                                    showOriginList = false
                                }
                                .padding(12.dp)
                        ) {
                            Text("${airport.city} • ${airport.code} • ${airport.name}", fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // TO Airport Selection
        Text("TO", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color.Gray)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = if (destSearchQuery.isEmpty()) uiState.searchDestination?.name ?: "" else destSearchQuery,
            onValueChange = {
                destSearchQuery = it
                showDestList = true
            },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.FlightLand, contentDescription = null, tint = FlyDubaiBlue) },
            trailingIcon = {
                if (showDestList) {
                    IconButton(onClick = { showDestList = false }) {
                        Icon(Icons.Default.Close, contentDescription = null)
                    }
                }
            },
            placeholder = { Text("Where would you like to go?") }
        )

        if (showDestList) {
            val filteredDests = DemoData.airports.filter {
                it.city.contains(destSearchQuery, ignoreCase = true) ||
                        it.code.contains(destSearchQuery, ignoreCase = true) ||
                        it.name.contains(destSearchQuery, ignoreCase = true)
            }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 150.dp)
                    .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(8.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                LazyColumn {
                    items(filteredDests) { airport ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateSearchDestination(airport)
                                    destSearchQuery = "${airport.city} (${airport.code})"
                                    showDestList = false
                                }
                                .padding(12.dp)
                        ) {
                            Text("${airport.city} • ${airport.code} • ${airport.name}", fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Dates & Passengers Block
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text("DEPARTURE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.Gray, RoundedCornerShape(4.dp))
                        .padding(14.dp)
                ) {
                    Text("Tomorrow", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("PASSENGERS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.Gray, RoundedCornerShape(4.dp))
                        .padding(14.dp)
                ) {
                    Text("1 Adult, Economy", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        FZButton(
            text = "SEARCH FLIGHTS",
            onClick = onSearchCompleted,
            modifier = Modifier.fillMaxWidth(),
            testTag = "search_flights_btn"
        )
    }
}

@Composable
fun SearchResultsScreen(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel,
    onFlightSelected: (Flight) -> Unit,
    onBack: () -> Unit
) {
    var sortBy by remember { mutableStateOf("cheapest") } // cheapest, fastest, departure

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "${uiState.searchOrigin.code} → ${uiState.searchDestination?.code ?: "IST"}",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
            )
            Spacer(modifier = Modifier.width(48.dp))
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Sort Selector Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(FlyDubaiSand, RoundedCornerShape(8.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf("cheapest", "fastest", "departure").forEach { sort ->
                val isSel = sortBy == sort
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isSel) FlyDubaiBlue else Color.Transparent,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { sortBy = sort }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = sort.uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) Color.White else Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Results List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(uiState.flightsResults) { flight ->
                FZFlightCard(
                    flight = flight,
                    currencySymbol = uiState.selectedCurrency,
                    currencyRate = uiState.currencyRate,
                    onClick = { onFlightSelected(flight) }
                )
            }
        }
    }
}

@Composable
fun FareSelectorScreen(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel,
    onFareSelected: (FareType) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "FLYDUBAI FARES",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Display Data-driven Fare Matrix (#6)
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(FareType.values().toList()) { fare ->
                val flightPrice = uiState.selectedFlight?.basePriceAED ?: 1240
                val price = (flightPrice * fare.priceMultiplier * uiState.currencyRate).toInt()

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, FlyDubaiSandDark, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = fare.typeName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FlyDubaiBlue,
                                    letterSpacing = 1.sp
                                )
                            )
                            FZPrice(
                                amount = price,
                                currencySymbol = uiState.selectedCurrency,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FlyDubaiOrange
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Fare conditions
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Cabin Bag: ${fare.cabinBaggage}", fontSize = 13.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (fare.checkedBaggage == "None") Icons.Default.Cancel else Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (fare.checkedBaggage == "None") Color.Gray else Color(0xFF2E7D32),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Checked Bag: ${fare.checkedBaggage}", fontSize = 13.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Seat Selection: ${fare.seatSelection}", fontSize = 13.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (fare.mealIncluded) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                    contentDescription = null,
                                    tint = if (fare.mealIncluded) Color(0xFF2E7D32) else Color.Gray,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Onboard Meal: ${if (fare.mealIncluded) "Included" else "Paid Only"}", fontSize = 13.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        FZButton(
                            text = "SELECT ${fare.typeName}",
                            onClick = { onFareSelected(fare) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PassengerDetailsScreen(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel,
    onNext: () -> Unit,
    onBack: () -> Unit
) {
    var title by remember { mutableStateOf("Mr.") }
    var firstName by remember { mutableStateOf("") }
    var surname by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var nationality by remember { mutableStateOf("") }
    var passport by remember { mutableStateOf("") }
    var passportExpiry by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "PASSENGER DETAILS",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("PERSONAL INFORMATION", fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 12.sp)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Title") },
                        modifier = Modifier.width(80.dp)
                    )
                    OutlinedTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        label = { Text("First Name") },
                        modifier = Modifier.weight(1f).testTag("first_name_input")
                    )
                }
            }
            item {
                OutlinedTextField(
                    value = surname,
                    onValueChange = { surname = it },
                    label = { Text("Surname") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = dob,
                    onValueChange = { dob = it },
                    label = { Text("Date of Birth (YYYY-MM-DD)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = nationality,
                    onValueChange = { nationality = it },
                    label = { Text("Nationality") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Text("PASSPORT DATA (SECURE)", fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 12.sp)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = passport,
                        onValueChange = { passport = it },
                        label = { Text("Passport Number") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = passportExpiry,
                        onValueChange = { passportExpiry = it },
                        label = { Text("Expiry (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            item {
                Text("CONTACT INFO", fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 12.sp)
            }
            item {
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Mobile Number") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        FZButton(
            text = "CONTINUE TO SEATS",
            onClick = {
                val p = Passenger(
                    title = title,
                    firstName = firstName.ifEmpty { "TOM" },
                    surname = surname.ifEmpty { "LOVEITT" },
                    dateOfBirth = dob.ifEmpty { "1992-05-15" },
                    nationality = nationality.ifEmpty { "United Kingdom" },
                    passportNumber = passport.ifEmpty { "GBR948271A" },
                    passportExpiry = passportExpiry.ifEmpty { "2032-10-12" },
                    contactEmail = email.ifEmpty { "tom@ahyx.org" },
                    contactPhone = phone.ifEmpty { "+971 50 123 4567" }
                )
                viewModel.updateBookingPassenger(p)
                onNext()
            },
            modifier = Modifier.fillMaxWidth(),
            testTag = "passenger_continue_btn"
        )
    }
}

@Composable
fun SeatSelectionScreen(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel,
    onNext: () -> Unit,
    onBack: () -> Unit
) {
    var selectedSeatLocal by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "CHOOSE SEAT",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        FZCard {
            Text(
                text = "Flight ${uiState.selectedFlight?.flightNumber ?: "FZ 123"}",
                fontWeight = FontWeight.Bold,
                color = FlyDubaiBlue
            )
            Text(
                text = "Passenger: ${uiState.currentBookingInProgress?.passenger?.firstName ?: "Tom"} ${uiState.currentBookingInProgress?.passenger?.surname ?: "Loveitt"}",
                fontSize = 13.sp,
                color = Color.Gray
            )
            if (selectedSeatLocal != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .background(FlyDubaiOrange.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                        .padding(6.dp)
                ) {
                    Text("Selected: ", fontWeight = FontWeight.Bold, color = FlyDubaiOrange, fontSize = 13.sp)
                    Text("$selectedSeatLocal (Extra Legroom +AED 180)", fontWeight = FontWeight.Bold, color = FlyDubaiBlue, fontSize = 13.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Box(modifier = Modifier.weight(1f)) {
            FZSeatMap(
                selectedSeat = selectedSeatLocal,
                onSeatSelected = { seat ->
                    selectedSeatLocal = seat
                    viewModel.selectBookingSeat(seat)
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        FZButton(
            text = "CONFIRM SEAT Selection",
            onClick = onNext,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun AddonsScreen(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel,
    onNext: () -> Unit,
    onBack: () -> Unit
) {
    var extraBagCount by remember { mutableStateOf(0) }
    var loungeAccess by remember { mutableStateOf(false) }
    var hotMeal by remember { mutableStateOf(false) }

    val currency = uiState.selectedCurrency
    val rate = uiState.currencyRate

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "CUSTOMISE YOUR JOURNEY",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Checked baggage addon
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, FlyDubaiSandDark)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Backpack, contentDescription = null, tint = FlyDubaiBlue, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Extra Checked Baggage (+20kg)", fontWeight = FontWeight.Bold)
                            Text("AED 150 per bag", color = Color.Gray, fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = {
                                if (extraBagCount > 0) {
                                    extraBagCount--
                                }
                            }) {
                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = null)
                            }
                            Text("$extraBagCount", fontWeight = FontWeight.Bold)
                            IconButton(onClick = {
                                extraBagCount++
                                viewModel.addBaggageToBooking(20)
                            }) {
                                Icon(Icons.Default.AddCircleOutline, contentDescription = null)
                            }
                        }
                    }
                }
            }

            // Lounge Access addon
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (loungeAccess) FlyDubaiSand else Color.White),
                    border = BorderStroke(1.dp, FlyDubaiSandDark)
                ) {
                    Row(
                        modifier = Modifier
                            .clickable { loungeAccess = !loungeAccess }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.LocalCafe, contentDescription = null, tint = FlyDubaiBlue, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("flydubai Business Lounge Access", fontWeight = FontWeight.Bold)
                            Text("DXB Terminal 2 • AED 200", color = Color.Gray, fontSize = 12.sp)
                        }
                        Checkbox(checked = loungeAccess, onCheckedChange = { loungeAccess = it })
                    }
                }
            }

            // Onboard Hot Meal Addon
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (hotMeal) FlyDubaiSand else Color.White),
                    border = BorderStroke(1.dp, FlyDubaiSandDark)
                ) {
                    Row(
                        modifier = Modifier
                            .clickable { hotMeal = !hotMeal }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Restaurant, contentDescription = null, tint = FlyDubaiBlue, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Warm Arabian Rice & Chicken Meal", fontWeight = FontWeight.Bold)
                            Text("Freshly prepared on board • AED 45", color = Color.Gray, fontSize = 12.sp)
                        }
                        Checkbox(checked = hotMeal, onCheckedChange = { hotMeal = it })
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Running Total Card
        Card(
            colors = CardDefaults.cardColors(containerColor = FlyDubaiBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("RUNNING TOTAL", color = Color.White, fontWeight = FontWeight.Bold)
                FZPrice(
                    amount = ((uiState.currentBookingInProgress?.runningTotalAED ?: 1240) * rate).toInt(),
                    currencySymbol = currency,
                    style = MaterialTheme.typography.titleLarge.copy(color = FlyDubaiOrange, fontWeight = FontWeight.ExtraBold)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        FZButton(
            text = "PROCEED TO PAYMENT",
            onClick = onNext,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun PaymentScreen(
    uiState: FlyDubaiUiState,
    viewModel: FlyDubaiViewModel,
    onPaymentSuccess: () -> Unit,
    onBack: () -> Unit
) {
    var cardNumber by remember { mutableStateOf("") }
    var cardName by remember { mutableStateOf("") }
    var cardExpiry by remember { mutableStateOf("") }
    var cardCvv by remember { mutableStateOf("") }
    var promoCode by remember { mutableStateOf("") }

    val rate = uiState.currencyRate
    val currency = uiState.selectedCurrency
    val base = uiState.currentBookingInProgress?.runningTotalAED ?: 1240
    val total = (base * rate).toInt()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "SECURE CHECKOUT",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Price Breakdown List
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = FlyDubaiSand)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("PRICE BREAKDOWN", fontWeight = FontWeight.Bold, color = FlyDubaiBlue)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("FLIGHT FARE (${uiState.currentBookingInProgress?.fareType?.typeName})")
                            FZPrice(amount = (base * rate).toInt(), currencySymbol = currency)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("SEAT SELECTION")
                            Text("Included")
                        }
                        Divider(color = Color.LightGray, modifier = Modifier.padding(vertical = 8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("TOTAL AMOUNT", fontWeight = FontWeight.Bold)
                            FZPrice(amount = total, currencySymbol = currency, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = FlyDubaiOrange))
                        }
                    }
                }
            }

            item {
                Text("CREDIT / DEBIT CARD", fontWeight = FontWeight.Bold, color = Color.Gray, fontSize = 12.sp)
            }

            item {
                OutlinedTextField(
                    value = cardNumber,
                    onValueChange = { cardNumber = it },
                    label = { Text("Card Number") },
                    leadingIcon = { Icon(Icons.Default.CreditCard, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("card_number_input")
                )
            }

            item {
                OutlinedTextField(
                    value = cardName,
                    onValueChange = { cardName = it },
                    label = { Text("Cardholder Name") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = cardExpiry,
                        onValueChange = { cardExpiry = it },
                        label = { Text("Expiry (MM/YY)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = cardCvv,
                        onValueChange = { cardCvv = it },
                        label = { Text("CVV") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = promoCode,
                        onValueChange = { promoCode = it },
                        label = { Text("Promo Code") },
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { },
                        modifier = Modifier.height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FlyDubaiBlue)
                    ) {
                        Text("Apply")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        FZButton(
            text = "PAY $currency %,d".format(total),
            onClick = {
                viewModel.finalizeBookingPayment("Card Ending *${cardNumber.takeLast(4).ifEmpty { "4242" }}")
                onPaymentSuccess()
            },
            modifier = Modifier.fillMaxWidth(),
            testTag = "pay_button"
        )
    }
}

@Composable
fun BookingConfirmationScreen(
    uiState: FlyDubaiUiState,
    onViewTrips: () -> Unit
) {
    val booked = uiState.bookings.firstOrNull() ?: Booking(
        pnr = "ABC123",
        passenger = DemoData.demoPassenger,
        flight = DemoData.FZ123,
        fareType = FareType.VALUE
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF2E7D32),
            modifier = Modifier.size(72.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "BOOKING CONFIRMED",
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold, color = FlyDubaiBlue)
        )
        Text(
            text = "The Smarter Way to Fly",
            style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray)
        )

        Spacer(modifier = Modifier.height(32.dp))

        FZCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("PNR REFERENCE", fontWeight = FontWeight.Bold, color = Color.Gray)
                Text(booked.pnr, fontWeight = FontWeight.ExtraBold, color = FlyDubaiOrange, fontSize = 18.sp)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text("FLIGHT: ${booked.flight.flightNumber}", fontWeight = FontWeight.Bold)
            Text("${booked.flight.origin.city} (${booked.flight.origin.code}) → ${booked.flight.destination.city} (${booked.flight.destination.code})", fontSize = 14.sp)
            Text("DEPARTURE: Tomorrow at ${booked.flight.departureTime}", fontSize = 14.sp, color = FlyDubaiBlue)
        }

        Spacer(modifier = Modifier.height(40.dp))

        FZButton(
            text = "VIEW MY TRIP TIMELINE",
            onClick = onViewTrips,
            modifier = Modifier.fillMaxWidth(),
            testTag = "view_trip_btn"
        )
    }
}
