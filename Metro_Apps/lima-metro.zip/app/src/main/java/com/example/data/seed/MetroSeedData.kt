package com.example.data.seed

import com.example.core.model.*

object MetroSeedData {
    val lines = listOf(
        MetroLine(
            id = "L1",
            name = "Línea 1",
            color = "#00A859", // Green
            description = "Conecta el sur con el noreste de Lima, de Villa El Salvador a Bayóvar.",
            status = OperationalStatus.OPERATIVA
        ),
        MetroLine(
            id = "L2",
            name = "Línea 2",
            color = "#E31A1C", // Red
            description = "Primer metro subterráneo del Perú, conecta Ate con el Callao. Etapa 1A operativa.",
            status = OperationalStatus.OPERATIVA
        ),
        MetroLine(
            id = "L3",
            name = "Línea 3 (Planificada)",
            color = "#F7931E", // Orange
            description = "Futura línea de norte a sur, en fase de planificación por el MTC.",
            status = OperationalStatus.PLANIFICADA
        ),
        MetroLine(
            id = "L4",
            name = "Línea 4 (En Construcción)",
            color = "#00AEEF", // Muted Pacific Blue
            description = "Futura línea este-oeste. Ramal Av. Faucett - Av. Gambetta en construcción.",
            status = OperationalStatus.EN_CONSTRUCCION
        )
    )

    val stations = listOf(
        // Line 1
        MetroStation(
            id = "L1-VES",
            name = "Villa El Salvador",
            lineId = "L1",
            latitude = -12.2101,
            longitude = -76.9361,
            district = "Villa El Salvador",
            description = "Estación terminal sur. Acceso cercano al Parque Zonal Huáscar y la Municipalidad.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Parque Zonal Huáscar", "Municipalidad de VES")
        ),
        MetroStation(
            id = "L1-PUM",
            name = "Pumacahua",
            lineId = "L1",
            latitude = -12.1953,
            longitude = -76.9402,
            district = "Villa El Salvador",
            description = "Estación ubicada cerca a la Av. Unión. Conexión rápida con el Parque Industrial.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Parque Industrial de VES")
        ),
        MetroStation(
            id = "L1-MAR",
            name = "María Auxiliadora",
            lineId = "L1",
            latitude = -12.1643,
            longitude = -76.9535,
            district = "San Juan de Miraflores",
            description = "Ubicada en la Av. Pachacútec. Estación crítica con acceso al Hospital María Auxiliadora.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Hospital María Auxiliadora")
        ),
        MetroStation(
            id = "L1-ATO",
            name = "Atocongo",
            lineId = "L1",
            latitude = -12.1481,
            longitude = -76.9632,
            district = "San Juan de Miraflores",
            description = "Ubicada junto a la Panamericana Sur. Conecta con paraderos metropolitanos y Mall del Sur.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Mall del Sur", "Puente Atocongo")
        ),
        MetroStation(
            id = "L1-CAB",
            name = "Cabitos",
            lineId = "L1",
            latitude = -12.1245,
            longitude = -76.9972,
            district = "Santiago de Surco",
            description = "Estación de alta afluencia en el Óvalo Higuereta. Conexión comercial intensa.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Óvalo Higuereta", "C.C. Polvos Rosados", "Av. Benavides")
        ),
        MetroStation(
            id = "L1-ANG",
            name = "Angamos",
            lineId = "L1",
            latitude = -12.1118,
            longitude = -77.0031,
            district = "San Borja",
            description = "Ubicada en el cruce de Av. Aviación y Av. Angamos. Centro de tránsito y comercio.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("C.C. Real Plaza Primavera", "Instituto de Enfermedades Neoplásicas")
        ),
        MetroStation(
            id = "L1-SBN",
            name = "San Borja Sur",
            lineId = "L1",
            latitude = -12.0991,
            longitude = -77.0055,
            district = "San Borja",
            description = "Estación de carácter residencial y comercial medio, ubicada en el cruce de Av. Aviación y Av. San Borja Sur.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Av. San Borja Sur", "Ciclovía de San Borja")
        ),
        MetroStation(
            id = "L1-CUL",
            name = "La Cultura",
            lineId = "L1",
            latitude = -12.0864,
            longitude = -77.0084,
            district = "San Borja",
            description = "Estación neurálgica de Lima. Centro de convenciones, museos y finanzas nacionales.",
            isInterchange = true,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Gran Teatro Nacional", "Biblioteca Nacional del Perú", "Museo de la Nación", "Banco de la Nación")
        ),
        MetroStation(
            id = "L1-GAM",
            name = "Gamarra",
            lineId = "L1",
            latitude = -12.0672,
            longitude = -77.0132,
            district = "La Victoria",
            description = "Estación con el mayor volumen de pasajeros diarios. Corazón textil del Perú.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Emporio Comercial Gamarra", "Parque Cánepa", "Av. Aviación")
        ),
        MetroStation(
            id = "L1-GRA",
            name = "Grau",
            lineId = "L1",
            latitude = -12.0573,
            longitude = -77.0163,
            district = "Cercado de Lima",
            description = "Conexión histórica con el centro cívico de Lima. Ofrece enlace de integración hacia la Línea 2.",
            isInterchange = true,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Hospital Almenara", "Av. Grau", "Parque de la Exposición")
        ),
        MetroStation(
            id = "L1-CDA",
            name = "Caja de Agua",
            lineId = "L1",
            latitude = -12.0298,
            longitude = -77.0153,
            district = "San Juan de Lurigancho",
            description = "Ingreso a San Juan de Lurigancho. Cercana al Túnel Santa Rosa que conecta con el Rímac.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Túnel Santa Rosa", "Av. Próceres de la Independencia")
        ),
        MetroStation(
            id = "L1-JAD",
            name = "Los Jardines",
            lineId = "L1",
            latitude = -12.0101,
            longitude = -76.9991,
            district = "San Juan de Lurigancho",
            description = "Zona comercial estratégica en San Juan de Lurigancho, rodeada de centros de estudio.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Metro de Próceres", "Instituto Superior Tecnológico")
        ),
        MetroStation(
            id = "L1-BAY",
            name = "Bayóvar",
            lineId = "L1",
            latitude = -11.9764,
            longitude = -76.9745,
            district = "San Juan de Lurigancho",
            description = "Estación terminal norte. Alta demanda de transporte de conexión hacia las zonas altas del distrito.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Parque Huiracocha", "Universidad César Vallejo - SJL")
        ),

        // Line 2
        MetroStation(
            id = "L2-PCL",
            name = "Puerto del Callao",
            lineId = "L2",
            latitude = -12.0620,
            longitude = -77.1471,
            district = "Callao",
            description = "Terminal Oeste proyectado en el Puerto de Callao. Clave para la integración marítima.",
            isInterchange = false,
            status = OperationalStatus.EN_CONSTRUCCION,
            landmarks = listOf("Terminal Portuario APM Terminals", "Fortaleza del Real Felipe")
        ),
        MetroStation(
            id = "L2-GCH",
            name = "Guardia Chalaca",
            lineId = "L2",
            latitude = -12.0632,
            longitude = -77.1278,
            district = "Callao",
            description = "Estación subterránea en planificación en el Callao. Cruce de Av. Guardia Chalaca.",
            isInterchange = false,
            status = OperationalStatus.EN_CONSTRUCCION,
            landmarks = listOf("Hospital Daniel Alcides Carrión")
        ),
        MetroStation(
            id = "L2-EVI",
            name = "Evitamiento",
            lineId = "L2",
            latitude = -12.0528,
            longitude = -76.9792,
            district = "Santa Anita",
            description = "Estación de empalme crucial con la Vía de Evitamiento. Inicio de la Etapa 1A operativa.",
            isInterchange = true,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Vía de Evitamiento", "Gran Mercado de Flores")
        ),
        MetroStation(
            id = "L2-OSA",
            name = "Óvalo Santa Anita",
            lineId = "L2",
            latitude = -12.0541,
            longitude = -76.9685,
            district = "Santa Anita",
            description = "Ubicada bajo el Óvalo de Santa Anita. Conexión con un gran centro comercial y residencial.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Mall Aventura Santa Anita", "Av. Nicolás Ayllón")
        ),
        MetroStation(
            id = "L2-COI",
            name = "Colectora Industrial",
            lineId = "L2",
            latitude = -12.0549,
            longitude = -76.9585,
            district = "Santa Anita",
            description = "Ubicada en la Av. Nicolás Ayllón con Av. Colectora Industrial. Zona de alto tránsito peatonal.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Av. Colectora Industrial", "Zonas Industriales de Santa Anita")
        ),
        MetroStation(
            id = "L2-HVA",
            name = "Hermilio Valdizán",
            lineId = "L2",
            latitude = -12.0558,
            longitude = -76.9472,
            district = "Ate",
            description = "Estación subterránea de la Etapa 1A. Nombrada en honor al ilustre médico psiquiatra peruano.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Universidad Nacional de Educación La Cantuta - Sede Ate")
        ),
        MetroStation(
            id = "L2-MSA",
            name = "Mercado Santa Anita",
            lineId = "L2",
            latitude = -12.0569,
            longitude = -76.9371,
            district = "Ate",
            description = "Terminal este actual de la Etapa 1A de la Línea 2, adyacente al Mercado Mayorista de Lima.",
            isInterchange = false,
            status = OperationalStatus.OPERATIVA,
            landmarks = listOf("Mercado Mayorista de Santa Anita", "C.C. Real Plaza Puruchuco (Cercano)")
        ),
        MetroStation(
            id = "L2-ATE",
            name = "Municipalidad de Ate",
            lineId = "L2",
            latitude = -12.0594,
            longitude = -76.9185,
            district = "Ate",
            description = "Futura estación terminal de la etapa 1B. En fase avanzada de obras civiles subterráneas.",
            isInterchange = false,
            status = OperationalStatus.EN_CONSTRUCCION,
            landmarks = listOf("Plaza de Armas de Ate", "Municipalidad Distrital de Ate")
        ),

        // Line 3 (Planned - Configurable)
        MetroStation(
            id = "L3-CCS",
            name = "Estación Central (Planificada)",
            lineId = "L3",
            latitude = -12.0551,
            longitude = -77.0371,
            district = "Cercado de Lima",
            description = "Gran nodo subterráneo planificado para integrar las líneas 2, 3 y el Metropolitano.",
            isInterchange = true,
            status = OperationalStatus.PLANIFICADA,
            landmarks = listOf("Palacio de Justicia", "C.C. Real Plaza Centro Cívico", "Paseo de los Héroes Navales")
        )
    )

    // Connections between adjacent stations for routing
    val connections = listOf(
        // Line 1 connections (both directions represented by simple graph builder)
        MetroConnection("L1-VES", "L1-PUM", 1500, 120),
        MetroConnection("L1-PUM", "L1-MAR", 2200, 180),
        MetroConnection("L1-MAR", "L1-ATO", 1800, 150),
        MetroConnection("L1-ATO", "L1-CAB", 2800, 210),
        MetroConnection("L1-CAB", "L1-ANG", 1600, 120),
        MetroConnection("L1-ANG", "L1-SBN", 1400, 110),
        MetroConnection("L1-SBN", "L1-CUL", 1500, 115),
        MetroConnection("L1-CUL", "L1-GAM", 2100, 160),
        MetroConnection("L1-GAM", "L1-GRA", 1800, 130),
        MetroConnection("L1-GRA", "L1-CDA", 2900, 220),
        MetroConnection("L1-CDA", "L1-JAD", 2400, 180),
        MetroConnection("L1-JAD", "L1-BAY", 3200, 260),

        // Line 2 connections
        MetroConnection("L2-PCL", "L2-GCH", 1400, 100),
        MetroConnection("L2-GCH", "L2-EVI", 3500, 280),
        MetroConnection("L2-EVI", "L2-OSA", 1200, 90),
        MetroConnection("L2-OSA", "L2-COI", 1100, 80),
        MetroConnection("L2-COI", "L2-HVA", 1150, 85),
        MetroConnection("L2-HVA", "L2-MSA", 1100, 80),
        MetroConnection("L2-MSA", "L2-ATE", 1900, 140),

        // Inter-line simulated Integration Connection (demonstration transfer walk/shuttle)
        // From Line 1 Grau to Line 2 Evitamiento (representing real connected transit experience)
        MetroConnection("L1-GRA", "L2-EVI", 3800, 480)
    )

    val fareProducts = listOf(
        FareProduct("FP-ADULT", "Pasaje Adulto — Demostración", 1.50, "Boleto estándar para el sistema Lima Metro."),
        FareProduct("FP-UNI", "Pasaje Universitario — Demostración", 0.75, "Boleto con tarifa preferencial para estudiantes universitarios y de institutos."),
        FareProduct("FP-ESCOLAR", "Pasaje Escolar — Demostración", 0.37, "Boleto con tarifa preferencial para escolares de educación básica."),
        FareProduct("FP-INTEGRADO", "Producto Integrado — Demostración", 2.50, "Acceso combinado para transbordos integrados Metro-Metropolitano (Piloto).")
    )

    val initialAlerts = listOf(
        ServiceAlert(
            id = "ALERT-01",
            lineId = "L1",
            stationId = "L1-GAM",
            title = "Alta Afluencia en Horas Punta",
            description = "Estación Gamarra presenta alta afluencia de pasajeros entre las 18:00 y 20:00. Se recomienda tomar previsiones.",
            severity = AlertSeverity.INFO
        ),
        ServiceAlert(
            id = "ALERT-02",
            lineId = "L2",
            stationId = "L2-EVI",
            title = "Frecuencia Mejorada en Línea 2",
            description = "La Etapa 1A de Línea 2 opera con trenes cada 6 minutos de manera continua y exitosa.",
            severity = AlertSeverity.NORMAL
        ),
        ServiceAlert(
            id = "ALERT-03",
            lineId = "L4",
            stationId = null,
            title = "Obras de Ramal Av. Faucett",
            description = "Obras de construcción del Ramal Línea 4 continúan en Av. Faucett. Tránsito desviado en superficie.",
            severity = AlertSeverity.INFO,
            isSimulated = false
        )
    )
}
