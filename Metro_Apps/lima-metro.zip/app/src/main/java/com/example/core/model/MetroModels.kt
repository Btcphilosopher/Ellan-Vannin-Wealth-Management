package com.example.core.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class OperationalStatus {
    OPERATIVA,
    EN_CONSTRUCCION,
    PLANIFICADA,
    NO_DISPONIBLE_DEMO
}

data class MetroLine(
    val id: String,
    val name: String,
    val color: String, // Hex string
    val description: String,
    val status: OperationalStatus
)

data class MetroStation(
    val id: String,
    val name: String,
    val lineId: String,
    val latitude: Double,
    val longitude: Double,
    val district: String,
    val description: String,
    val isInterchange: Boolean,
    val status: OperationalStatus,
    val landmarks: List<String> = emptyList(),
    val accessibilityNotes: String = "Acceso con ascensor, baldosas podotáctiles y escaleras mecánicas."
)

data class MetroConnection(
    val fromStationId: String,
    val toStationId: String,
    val distanceMeters: Int,
    val travelTimeSeconds: Int
)

data class ServiceAlert(
    val id: String,
    val lineId: String?,
    val stationId: String?,
    val title: String,
    val description: String,
    val severity: AlertSeverity,
    val isSimulated: Boolean = true
)

enum class AlertSeverity {
    NORMAL,
    INFO,
    WARNING,
    CRITICAL
}

data class FareProduct(
    val id: String,
    val name: String,
    val price: Double,
    val description: String
)

data class JourneyLeg(
    val lineId: String?, // Null if walking/transfer
    val fromStationId: String,
    val toStationId: String,
    val estimatedMinutes: Int,
    val intermediateStations: List<String> = emptyList(),
    val transferInstructions: String? = null
)

data class RouteOption(
    val type: RouteType,
    val totalMinutes: Int,
    val transfers: Int,
    val legs: List<JourneyLeg>
)

enum class RouteType {
    RAPIDA,
    MENOS_TRANSBORDOS,
    SENCILLA
}

@Entity(tableName = "saved_stations")
data class SavedStationEntity(
    @PrimaryKey val stationId: String,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "purchased_tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val productName: String,
    val price: Double,
    val purchaseTime: Long,
    val validityPeriod: String,
    val qrCodeContent: String
)

@Entity(tableName = "recent_searches")
data class RecentSearchEntity(
    @PrimaryKey val id: String, // Usually "fromStationId-toStationId"
    val fromStationId: String,
    val toStationId: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "wallet_balance")
data class WalletEntity(
    @PrimaryKey val id: Int = 1,
    val balance: Double = 15.00
)
