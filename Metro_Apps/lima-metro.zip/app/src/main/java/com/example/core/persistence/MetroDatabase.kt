package com.example.core.persistence

import android.content.Context
import androidx.room.*
import com.example.core.model.RecentSearchEntity
import com.example.core.model.SavedStationEntity
import com.example.core.model.TicketEntity
import com.example.core.model.WalletEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {
    @Query("SELECT * FROM saved_stations ORDER BY savedAt DESC")
    fun getSavedStations(): Flow<List<SavedStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedStation(station: SavedStationEntity)

    @Delete
    suspend fun deleteSavedStation(station: SavedStationEntity)

    @Query("SELECT EXISTS(SELECT 1 FROM saved_stations WHERE stationId = :stationId)")
    fun isStationSaved(stationId: String): Flow<Boolean>

    @Query("SELECT * FROM purchased_tickets ORDER BY purchaseTime DESC")
    fun getPurchasedTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Query("SELECT * FROM recent_searches ORDER BY timestamp DESC LIMIT 5")
    fun getRecentSearches(): Flow<List<RecentSearchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentSearch(search: RecentSearchEntity)

    @Query("SELECT * FROM wallet_balance WHERE id = 1")
    fun getWalletFlow(): Flow<WalletEntity?>

    @Query("SELECT * FROM wallet_balance WHERE id = 1")
    suspend fun getWallet(): WalletEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWallet(wallet: WalletEntity)

    @Update
    suspend fun updateWallet(wallet: WalletEntity)
}

@Database(
    entities = [
        SavedStationEntity::class,
        TicketEntity::class,
        RecentSearchEntity::class,
        WalletEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MetroDatabase : RoomDatabase() {
    abstract fun metroDao(): MetroDao

    companion object {
        @Volatile
        private var INSTANCE: MetroDatabase? = null

        fun getDatabase(context: Context): MetroDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MetroDatabase::class.java,
                    "metro_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
