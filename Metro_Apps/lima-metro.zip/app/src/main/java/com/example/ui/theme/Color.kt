package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// M3 Palette for Lima Metro
val LimaGreen = Color(0xFF00A859)
val MetroRed = Color(0xFFE31A1C)
val DeepRed = Color(0xFF9E0B0E)
val Terracotta = Color(0xFFC85A32)
val SandLight = Color(0xFFFAF6EE)
val SandDark = Color(0xFF1F1B16)
val GraphiteLight = Color(0xFF1E1E1E)
val GraphiteDark = Color(0xFFE5E2DA)
val ConcreteGrey = Color(0xFF8E8D8A)
val ConcreteLight = Color(0xFFF2F1ED)
val ConcreteDark = Color(0xFF2C2C2B)
val PacificBlue = Color(0xFF0077C0)
val GoldMuted = Color(0xFFC5A059)

// Theme Colors
val PrimaryLight = MetroRed
val SecondaryLight = GraphiteLight
val TertiaryLight = PacificBlue
val BackgroundLight = SandLight
val SurfaceLight = Color(0xFFFFFFFF)

val PrimaryDark = MetroRed
val SecondaryDark = GraphiteDark
val TertiaryDark = PacificBlue
val BackgroundDark = SandDark
val SurfaceDark = ConcreteDark
