package com.example.core.settings

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SettingsState(
    val darkTheme: Boolean? = null, // null means use system
    val largeText: Boolean = false,
    val highContrast: Boolean = false,
    val reducedMotion: Boolean = false,
    val hapticFeedback: Boolean = true,
    val showFutureLines: Boolean = true,
    val showSimulatedAlerts: Boolean = true,
    val useDiacriticFreeSearch: Boolean = true
)

object MetroSettings {
    private val _state = MutableStateFlow(SettingsState())
    val state: StateFlow<SettingsState> = _state.asStateFlow()

    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        val prefs = context.getSharedPreferences("metro_settings", Context.MODE_PRIVATE)
        _state.value = SettingsState(
            darkTheme = if (prefs.contains("darkTheme")) prefs.getBoolean("darkTheme", false) else null,
            largeText = prefs.getBoolean("largeText", false),
            highContrast = prefs.getBoolean("highContrast", false),
            reducedMotion = prefs.getBoolean("reducedMotion", false),
            hapticFeedback = prefs.getBoolean("hapticFeedback", true),
            showFutureLines = prefs.getBoolean("showFutureLines", true),
            showSimulatedAlerts = prefs.getBoolean("showSimulatedAlerts", true),
            useDiacriticFreeSearch = prefs.getBoolean("useDiacriticFreeSearch", true)
        )
        initialized = true
    }

    fun updateDarkTheme(context: Context, value: Boolean?) {
        val prefs = context.getSharedPreferences("metro_settings", Context.MODE_PRIVATE)
        prefs.edit().apply {
            if (value == null) remove("darkTheme") else putBoolean("darkTheme", value)
            apply()
        }
        _state.value = _state.value.copy(darkTheme = value)
    }

    fun updateLargeText(context: Context, value: Boolean) {
        savePref(context, "largeText", value)
        _state.value = _state.value.copy(largeText = value)
    }

    fun updateHighContrast(context: Context, value: Boolean) {
        savePref(context, "highContrast", value)
        _state.value = _state.value.copy(highContrast = value)
    }

    fun updateReducedMotion(context: Context, value: Boolean) {
        savePref(context, "reducedMotion", value)
        _state.value = _state.value.copy(reducedMotion = value)
    }

    fun updateHapticFeedback(context: Context, value: Boolean) {
        savePref(context, "hapticFeedback", value)
        _state.value = _state.value.copy(hapticFeedback = value)
    }

    fun updateShowFutureLines(context: Context, value: Boolean) {
        savePref(context, "showFutureLines", value)
        _state.value = _state.value.copy(showFutureLines = value)
    }

    fun updateShowSimulatedAlerts(context: Context, value: Boolean) {
        savePref(context, "showSimulatedAlerts", value)
        _state.value = _state.value.copy(showSimulatedAlerts = value)
    }

    fun updateUseDiacriticFreeSearch(context: Context, value: Boolean) {
        savePref(context, "useDiacriticFreeSearch", value)
        _state.value = _state.value.copy(useDiacriticFreeSearch = value)
    }

    fun resetAll(context: Context) {
        context.getSharedPreferences("metro_settings", Context.MODE_PRIVATE).edit().clear().apply()
        _state.value = SettingsState()
    }

    private fun savePref(context: Context, key: String, value: Boolean) {
        context.getSharedPreferences("metro_settings", Context.MODE_PRIVATE).edit().putBoolean(key, value).apply()
    }
}
