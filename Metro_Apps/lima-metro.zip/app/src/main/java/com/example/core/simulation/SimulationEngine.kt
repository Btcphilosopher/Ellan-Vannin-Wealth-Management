package com.example.core.simulation

import com.example.core.model.AlertSeverity
import com.example.core.model.ServiceAlert
import com.example.core.model.*
import com.example.data.seed.MetroSeedData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class SimulatedTimeOfDay(val label: String, val startHour: Int) {
    MAÑANA_PUNTA("Hora Punta Mañana (07:30)", 7),
    MEDIODIA("Mediodía (12:00)", 12),
    TARDE_PUNTA("Hora Punta Tarde (18:30)", 18),
    NOCHE("Noche (22:00)", 22)
}

enum class CrowdingLevel(val label: String) {
    BAJO("Baja afluencia"),
    MEDIO("Moderado"),
    ALTO("Alta afluencia"),
    MUY_ALTO("Saturado (Estación Gamarra)")
}

data class SimulationState(
    val selectedTimeOfDay: SimulatedTimeOfDay = SimulatedTimeOfDay.MAÑANA_PUNTA,
    val currentSimulatedTime: String = "07:30",
    val simulatedMinutesSinceMidnight: Int = 450, // 7 * 60 + 30
    val trainFrequencyMinutesL1: Int = 3,
    val trainFrequencyMinutesL2: Int = 6,
    val activeDisruptions: Set<String> = emptySet(), // Set of stationIds that are "disrupted/closed"
    val globalCrowding: CrowdingLevel = CrowdingLevel.ALTO,
    val logs: List<String> = listOf("Simulador iniciado con éxito en Lima Metropolitana.")
)

object SimulationEngine {
    private val _state = MutableStateFlow(SimulationState())
    val state: StateFlow<SimulationState> = _state.asStateFlow()

    fun logEvent(message: String) {
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        _state.value = _state.value.copy(
            logs = listOf("[$timeStr] $message") + _state.value.logs.take(49)
        )
    }

    fun setTimeOfDay(time: SimulatedTimeOfDay) {
        val minutes = when (time) {
            SimulatedTimeOfDay.MAÑANA_PUNTA -> 7 * 60 + 30
            SimulatedTimeOfDay.MEDIODIA -> 12 * 60 + 0
            SimulatedTimeOfDay.TARDE_PUNTA -> 18 * 60 + 30
            SimulatedTimeOfDay.NOCHE -> 22 * 60 + 0
        }
        val freqL1 = when (time) {
            SimulatedTimeOfDay.MAÑANA_PUNTA, SimulatedTimeOfDay.TARDE_PUNTA -> 3
            else -> 6
        }
        val freqL2 = when (time) {
            SimulatedTimeOfDay.MAÑANA_PUNTA, SimulatedTimeOfDay.TARDE_PUNTA -> 5
            else -> 8
        }
        val crowding = when (time) {
            SimulatedTimeOfDay.MAÑANA_PUNTA, SimulatedTimeOfDay.TARDE_PUNTA -> CrowdingLevel.MUY_ALTO
            SimulatedTimeOfDay.MEDIODIA -> CrowdingLevel.MEDIO
            SimulatedTimeOfDay.NOCHE -> CrowdingLevel.BAJO
        }

        _state.value = _state.value.copy(
            selectedTimeOfDay = time,
            simulatedMinutesSinceMidnight = minutes,
            currentSimulatedTime = formatMinutes(minutes),
            trainFrequencyMinutesL1 = freqL1,
            trainFrequencyMinutesL2 = freqL2,
            globalCrowding = crowding
        )
        logEvent("Hora simulada cambiada a ${time.label}. Frecuencia L1: $freqL1 min, L2: $freqL2 min.")
    }

    fun toggleStationDisruption(stationId: String) {
        val currentDisrupted = _state.value.activeDisruptions.toMutableSet()
        val station = MetroSeedData.stations.find { it.id == stationId } ?: return
        if (currentDisrupted.contains(stationId)) {
            currentDisrupted.remove(stationId)
            logEvent("Estación ${station.name} reabierta y operativa.")
        } else {
            currentDisrupted.add(stationId)
            logEvent("Estación ${station.name} clausurada temporalmente por mantenimiento simulado.")
        }
        _state.value = _state.value.copy(activeDisruptions = currentDisrupted)
    }

    fun clearAllDisruptions() {
        _state.value = _state.value.copy(activeDisruptions = emptySet())
        logEvent("Todas las incidencias han sido resueltas. Operación normal.")
    }

    fun changeFrequencies(l1: Int, l2: Int) {
        _state.value = _state.value.copy(
            trainFrequencyMinutesL1 = l1,
            trainFrequencyMinutesL2 = l2
        )
        logEvent("Frecuencia personalizada: L1=$l1 min, L2=$l2 min.")
    }

    fun setCrowding(crowding: CrowdingLevel) {
        _state.value = _state.value.copy(globalCrowding = crowding)
        logEvent("Afluencia global establecida en: ${crowding.label}")
    }

    fun advanceTimeByMinutes(mins: Int) {
        val newMinutes = (_state.value.simulatedMinutesSinceMidnight + mins) % 1440
        _state.value = _state.value.copy(
            simulatedMinutesSinceMidnight = newMinutes,
            currentSimulatedTime = formatMinutes(newMinutes)
        )
        logEvent("Reloj de simulación avanzado $mins minutos. Nueva hora: ${formatMinutes(newMinutes)}")
    }

    private fun formatMinutes(minutes: Int): String {
        val hours = minutes / 60
        val mins = minutes % 60
        return String.format(Locale.US, "%02d:%02d", hours, mins)
    }

    /**
     * Generates a list of simulated departures for a station
     */
    fun getSimulatedDepartures(stationId: String): List<SimulatedDeparture> {
        val station = MetroSeedData.stations.find { it.id == stationId } ?: return emptyList()
        val frequency = if (station.lineId == "L1") _state.value.trainFrequencyMinutesL1 else _state.value.trainFrequencyMinutesL2
        val activeDisrupted = _state.value.activeDisruptions.contains(stationId)

        if (activeDisrupted || station.status == OperationalStatus.PLANIFICADA) {
            return emptyList()
        }

        // Determinisitc departures based on the current simulated minute clock
        val clockMin = _state.value.simulatedMinutesSinceMidnight
        
        // Let's create departures for two main directions based on Line
        val directions = when (station.lineId) {
            "L1" -> listOf("Villa El Salvador", "Bayóvar")
            "L2" -> listOf("Puerto del Callao", "Mercado Santa Anita")
            else -> listOf("Terminal Proyectado")
        }

        val departures = mutableListOf<SimulatedDeparture>()
        directions.forEachIndexed { index, dir ->
            // Shift departure timings slightly per direction and station to feel organic
            val offset = (stationId.hashCode() + index * 7) % frequency
            val firstDepartureMin = (frequency - (clockMin % frequency) + offset) % frequency
            
            val dep1 = if (firstDepartureMin == 0) frequency else firstDepartureMin
            val dep2 = dep1 + frequency
            val dep3 = dep2 + frequency

            departures.add(SimulatedDeparture(dir, dep1, "Andén ${index + 1}", getCrowdingForStation(stationId)))
            departures.add(SimulatedDeparture(dir, dep2, "Andén ${index + 1}", getCrowdingForStation(stationId)))
            departures.add(SimulatedDeparture(dir, dep3, "Andén ${index + 1}", getCrowdingForStation(stationId)))
        }

        return departures.sortedBy { it.minutesLeft }
    }

    fun getCrowdingForStation(stationId: String): CrowdingLevel {
        if (stationId == "L1-GAM") return CrowdingLevel.MUY_ALTO // Gamarra is always dense!
        return _state.value.globalCrowding
    }

    fun getSimulatedAlerts(): List<ServiceAlert> {
        val currentDisrupted = _state.value.activeDisruptions
        val simulatedAlerts = mutableListOf<ServiceAlert>()

        // Map disruptions to ServiceAlert objects
        currentDisrupted.forEach { stationId ->
            val station = MetroSeedData.stations.find { it.id == stationId }
            if (station != null) {
                simulatedAlerts.add(
                    ServiceAlert(
                        id = "DISRUPT-$stationId",
                        lineId = station.lineId,
                        stationId = stationId,
                        title = "Estación ${station.name} Cerrada",
                        description = "Simulación de interrupción parcial por mantenimiento preventivo de escaleras eléctricas.",
                        severity = AlertSeverity.CRITICAL
                    )
                )
            }
        }

        return MetroSeedData.initialAlerts + simulatedAlerts
    }
}

data class SimulatedDeparture(
    val destination: String,
    val minutesLeft: Int,
    val platform: String,
    val crowding: CrowdingLevel
)
