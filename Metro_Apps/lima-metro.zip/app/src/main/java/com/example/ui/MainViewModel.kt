package com.example.ui

import android.app.Application
import android.content.Context
import android.os.Vibrator
import android.os.VibrationEffect
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.*
import com.example.core.persistence.MetroDatabase
import com.example.core.settings.MetroSettings
import com.example.core.simulation.SimulationEngine
import com.example.data.seed.MetroSeedData
import com.example.domain.routing.RoutingEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

data class ActiveJourneyState(
    val isActive: Boolean = false,
    val selectedRoute: RouteOption? = null,
    val currentLegIndex: Int = 0,
    val currentStationId: String = "",
    val nextStationId: String? = null,
    val progressPercent: Float = 0f, // 0.0 to 1.0 between current and next
    val isPaused: Boolean = false,
    val remainingMinutes: Int = 0,
    val completedStationIds: Set<String> = emptySet()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = MetroDatabase.getDatabase(application)
    private val dao = database.metroDao()

    // Preferences & Settings state
    val settingsState = MetroSettings.state

    // Database backed states
    val savedStations = dao.getSavedStations().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val purchasedTickets = dao.getPurchasedTickets().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentSearches = dao.getRecentSearches().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val walletState = dao.getWalletFlow().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = WalletEntity(1, 15.0)
    )

    // Simulation Engine States
    val simulationState = SimulationEngine.state

    // UI Interactive States
    private val _originStationId = MutableStateFlow<String>("")
    val originStationId: StateFlow<String> = _originStationId.asStateFlow()

    private val _destinationStationId = MutableStateFlow<String>("")
    val destinationStationId: StateFlow<String> = _destinationStationId.asStateFlow()

    private val _selectedStationId = MutableStateFlow<String?>(null)
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    // Route calculation results
    private val _calculatedRoutes = MutableStateFlow<List<RouteOption>>(emptyList())
    val calculatedRoutes: StateFlow<List<RouteOption>> = _calculatedRoutes.asStateFlow()

    // Current active journey simulation
    private val _activeJourney = MutableStateFlow(ActiveJourneyState())
    val activeJourney: StateFlow<ActiveJourneyState> = _activeJourney.asStateFlow()

    private var journeyJob: Job? = null

    init {
        MetroSettings.init(application)
        viewModelScope.launch {
            // Seed wallet balance if empty
            if (dao.getWallet() == null) {
                dao.insertWallet(WalletEntity(1, 15.00))
            }
        }
    }

    fun setOrigin(stationId: String) {
        _originStationId.value = stationId
        triggerRouteCalculation()
    }

    fun setDestination(stationId: String) {
        _destinationStationId.value = stationId
        triggerRouteCalculation()
    }

    fun swapOriginAndDestination() {
        val temp = _originStationId.value
        _originStationId.value = _destinationStationId.value
        _destinationStationId.value = temp
        triggerRouteCalculation()
    }

    fun selectStation(stationId: String?) {
        _selectedStationId.value = stationId
    }

    private fun triggerRouteCalculation() {
        val origin = _originStationId.value
        val dest = _destinationStationId.value
        if (origin.isNotEmpty() && dest.isNotEmpty()) {
            viewModelScope.launch {
                val disruptions = simulationState.value.activeDisruptions
                val routes = RoutingEngine.findRoutes(origin, dest, disruptions)
                _calculatedRoutes.value = routes

                // Log to recent searches
                dao.insertRecentSearch(
                    RecentSearchEntity(
                        id = "$origin-$dest",
                        fromStationId = origin,
                        toStationId = dest
                    )
                )
                SimulationEngine.logEvent("Ruta consultada de ${getStationName(origin)} a ${getStationName(dest)}.")
            }
        } else {
            _calculatedRoutes.value = emptyList()
        }
    }

    fun getStationName(id: String): String {
        return MetroSeedData.stations.find { it.id == id }?.name ?: id
    }

    fun getStation(id: String): MetroStation? {
        return MetroSeedData.stations.find { it.id == id }
    }

    fun isStationFavorite(stationId: String): Flow<Boolean> {
        return dao.isStationSaved(stationId)
    }

    fun toggleFavorite(stationId: String) {
        viewModelScope.launch {
            val isFav = savedStations.value.any { it.stationId == stationId }
            if (isFav) {
                dao.deleteSavedStation(SavedStationEntity(stationId))
                SimulationEngine.logEvent("Estación ${getStationName(stationId)} removida de favoritos.")
            } else {
                dao.insertSavedStation(SavedStationEntity(stationId))
                SimulationEngine.logEvent("Estación ${getStationName(stationId)} guardada en favoritos.")
            }
        }
    }

    // Ticketing Actions
    fun buyTicket(product: FareProduct, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val currentWallet = dao.getWallet() ?: WalletEntity(1, 15.0)
            if (currentWallet.balance >= product.price) {
                // Deduct balance
                val newWallet = currentWallet.copy(balance = currentWallet.balance - product.price)
                dao.updateWallet(newWallet)

                // Insert digital ticket
                val qrCode = "LIMAMETRO-${UUID.randomUUID().toString().take(8).uppercase()}"
                val ticket = TicketEntity(
                    id = "TKT-${System.currentTimeMillis()}",
                    productName = product.name,
                    price = product.price,
                    purchaseTime = System.currentTimeMillis(),
                    validityPeriod = "Válido por 120 minutos desde la compra",
                    qrCodeContent = qrCode
                )
                dao.insertTicket(ticket)

                SimulationEngine.logEvent("Billete comprado con éxito: ${product.name} (S/ ${String.format("%.2f", product.price)}).")
                onSuccess()
            } else {
                onError("Saldo insuficiente. Por favor, recargue su saldo en la sección BILLETES.")
            }
        }
    }

    fun rechargeWallet(amount: Double) {
        viewModelScope.launch {
            val currentWallet = dao.getWallet() ?: WalletEntity(1, 0.0)
            val newWallet = currentWallet.copy(balance = currentWallet.balance + amount)
            dao.updateWallet(newWallet)
            SimulationEngine.logEvent("Saldo recargado con éxito: +S/ ${String.format("%.2f", amount)}. Nuevo saldo: S/ ${String.format("%.2f", newWallet.balance)}")
        }
    }

    // Journey Simulation Manager
    fun startJourney(route: RouteOption) {
        journeyJob?.cancel()
        _activeJourney.value = ActiveJourneyState(
            isActive = true,
            selectedRoute = route,
            currentLegIndex = 0,
            currentStationId = route.legs.first().fromStationId,
            nextStationId = getNextStationIdInLeg(route.legs.first(), route.legs.first().fromStationId),
            progressPercent = 0f,
            isPaused = false,
            remainingMinutes = route.totalMinutes,
            completedStationIds = setOf(route.legs.first().fromStationId)
        )

        SimulationEngine.logEvent("Viaje simulado iniciado hacia ${getStationName(route.legs.last().toStationId)}.")
        triggerVibration()

        // Launch simulation timer
        journeyJob = viewModelScope.launch {
            while (true) {
                delay(200) // update tick every 200ms for visual fluid progress
                val journey = _activeJourney.value
                if (journey.isActive && !journey.isPaused) {
                    val currentLeg = journey.selectedRoute?.legs?.getOrNull(journey.currentLegIndex)
                    if (currentLeg != null) {
                        // Increment progress
                        val newProgress = journey.progressPercent + 0.05f
                        if (newProgress >= 1f) {
                            // Arrived at next station!
                            val reachedStationId = journey.nextStationId ?: currentLeg.toStationId
                            
                            val completed = journey.completedStationIds + reachedStationId
                            triggerVibration()

                            // Check if leg is completed
                            if (reachedStationId == currentLeg.toStationId) {
                                // Move to next leg if any
                                val nextLegIdx = journey.currentLegIndex + 1
                                val nextLeg = journey.selectedRoute.legs.getOrNull(nextLegIdx)
                                if (nextLeg != null) {
                                    SimulationEngine.logEvent("Transbordo completado en ${getStationName(reachedStationId)}. Iniciando tramo de ${nextLeg.lineId ?: "Caminata"}.")
                                    _activeJourney.value = journey.copy(
                                        currentLegIndex = nextLegIdx,
                                        currentStationId = nextLeg.fromStationId,
                                        nextStationId = getNextStationIdInLeg(nextLeg, nextLeg.fromStationId),
                                        progressPercent = 0f,
                                        completedStationIds = completed,
                                        remainingMinutes = Math.max(0, journey.remainingMinutes - currentLeg.estimatedMinutes)
                                    )
                                } else {
                                    // Journey Completed!
                                    SimulationEngine.logEvent("¡Ha llegado a su destino: ${getStationName(reachedStationId)}! Gracias por viajar con Lima Metro.")
                                    _activeJourney.value = journey.copy(
                                        isActive = false,
                                        progressPercent = 1.0f,
                                        currentStationId = reachedStationId,
                                        nextStationId = null,
                                        remainingMinutes = 0,
                                        completedStationIds = completed
                                    )
                                    break
                                }
                            } else {
                                // Move to next station inside same leg
                                val nextNextStationId = getNextStationIdInLeg(currentLeg, reachedStationId)
                                SimulationEngine.logEvent("Pasando por estación ${getStationName(reachedStationId)}.")
                                _activeJourney.value = journey.copy(
                                    currentStationId = reachedStationId,
                                    nextStationId = nextNextStationId,
                                    progressPercent = 0f,
                                    completedStationIds = completed,
                                    remainingMinutes = Math.max(0, journey.remainingMinutes - 1)
                                )
                            }
                        } else {
                            _activeJourney.value = journey.copy(progressPercent = newProgress)
                        }
                    } else {
                        break
                    }
                }
            }
        }
    }

    fun pauseJourney() {
        val current = _activeJourney.value
        _activeJourney.value = current.copy(isPaused = !current.isPaused)
        SimulationEngine.logEvent(if (_activeJourney.value.isPaused) "Viaje pausado." else "Viaje reanudado.")
    }

    fun endJourney() {
        journeyJob?.cancel()
        _activeJourney.value = ActiveJourneyState(isActive = false)
        SimulationEngine.logEvent("Viaje simulado cancelado por el usuario.")
    }

    private fun getNextStationIdInLeg(leg: JourneyLeg, currentStationId: String): String {
        if (leg.lineId == null) {
            // Walking/transfer leg has only start and end
            return leg.toStationId
        }
        
        // Find line stations in order
        val lineStations = MetroSeedData.stations.filter { it.lineId == leg.lineId }
        val startIndex = lineStations.indexOfFirst { it.id == leg.fromStationId }
        val endIndex = lineStations.indexOfFirst { it.id == leg.toStationId }
        val currentIndex = lineStations.indexOfFirst { it.id == currentStationId }

        if (startIndex == -1 || endIndex == -1 || currentIndex == -1) {
            return leg.toStationId
        }

        return if (startIndex <= endIndex) {
            // Forward direction
            if (currentIndex < endIndex) {
                lineStations[currentIndex + 1].id
            } else {
                leg.toStationId
            }
        } else {
            // Reverse direction
            if (currentIndex > endIndex) {
                lineStations[currentIndex - 1].id
            } else {
                leg.toStationId
            }
        }
    }

    private fun triggerVibration() {
        if (!settingsState.value.hapticFeedback) return
        try {
            val vibrator = getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(150)
            }
        } catch (e: Exception) {
            // No permission or no vibrator
        }
    }

    override fun onCleared() {
        super.onCleared()
        journeyJob?.cancel()
    }
}
