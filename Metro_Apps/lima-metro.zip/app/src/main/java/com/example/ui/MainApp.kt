package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.DirectionsWalk
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.model.*
import com.example.core.simulation.CrowdingLevel
import com.example.core.simulation.SimulatedTimeOfDay
import com.example.core.simulation.SimulationEngine
import com.example.data.seed.MetroSeedData
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.core.settings.MetroSettings
import com.example.features.map.InteractiveMetroMap
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class MetroTab(val label: String, val icon: ImageVector) {
    INICIO("Inicio", Icons.Filled.Home),
    MAPA("Mapa", Icons.Filled.Map),
    RUTAS("Rutas", Icons.Filled.Navigation),
    BILLETES("Billetes", Icons.Filled.QrCode),
    MAS("Más", Icons.Filled.Menu)
}

@Composable
fun MainApp(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(MetroTab.INICIO) }
    val activeJourney by viewModel.activeJourney.collectAsState()
    val context = LocalContext.current

    // Observe active journey and redirect tab to RUTAS to show tracking
    LaunchedEffect(activeJourney.isActive) {
        if (activeJourney.isActive) {
            selectedTab = MetroTab.RUTAS
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                MetroTab.values().forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label
                            )
                        },
                        label = { Text(tab.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            when (selectedTab) {
                MetroTab.INICIO -> InicioScreen(viewModel, onNavigateToTab = { selectedTab = it })
                MetroTab.MAPA -> MapaScreen(viewModel)
                MetroTab.RUTAS -> RutasScreen(viewModel)
                MetroTab.BILLETES -> BilletesScreen(viewModel)
                MetroTab.MAS -> MasScreen(viewModel)
            }
        }
    }
}

// ==========================================
// 1. INICIO SCREEN
// ==========================================
@Composable
fun InicioScreen(viewModel: MainViewModel, onNavigateToTab: (MetroTab) -> Unit) {
    val simState by viewModel.simulationState.collectAsState()
    val savedList by viewModel.savedStations.collectAsState()
    val recentSearches by viewModel.recentSearches.collectAsState()
    val wallet by viewModel.walletState.collectAsState()

    var showOriginSelector by remember { mutableStateOf(false) }
    var showDestinationSelector by remember { mutableStateOf(false) }

    val originId by viewModel.originStationId.collectAsState()
    val destId by viewModel.destinationStationId.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome and Status Header
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        val greeting = when (simState.selectedTimeOfDay) {
                            SimulatedTimeOfDay.MAÑANA_PUNTA -> "Buenos días"
                            SimulatedTimeOfDay.MEDIODIA -> "Buenas tardes"
                            SimulatedTimeOfDay.TARDE_PUNTA -> "Buenas tardes"
                            SimulatedTimeOfDay.NOCHE -> "Buenas noches"
                        }
                        Text(
                            text = "$greeting, viajero",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Muévete por Lima. Conecta tu ciudad.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                    Card(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Text(
                            text = simState.currentSimulatedTime,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Mode Indicator Badge
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(0xFFC85A32).copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, Color(0xFFC85A32).copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Filled.Info, contentDescription = "Modo Demostración", tint = Color(0xFFC85A32), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "PROTOCOLO DE DEMOSTRACIÓN — DATOS SIMULADOS",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFC85A32),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Hero Card: ¿A Dónde quieres ir?
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "¿A DÓNDE QUIERES IR?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Origin selector button
                    Button(
                        onClick = { showOriginSelector = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(12.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.RadioButtonUnchecked, contentDescription = "Origen", tint = Color(0xFF00A859), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (originId.isNotEmpty()) viewModel.getStationName(originId) else "Seleccionar estación de origen",
                                color = if (originId.isNotEmpty()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Swap icon row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = { viewModel.swapOriginAndDestination() },
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(Icons.Filled.SwapVert, contentDescription = "Intercambiar", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        }
                    }

                    // Destination selector button
                    Button(
                        onClick = { showDestinationSelector = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(12.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Place, contentDescription = "Destino", tint = Color(0xFFE31A1C), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (destId.isNotEmpty()) viewModel.getStationName(destId) else "Seleccionar estación de destino",
                                color = if (destId.isNotEmpty()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = { onNavigateToTab(MetroTab.RUTAS) },
                        enabled = originId.isNotEmpty() && destId.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.Search, contentDescription = "Buscar")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("BUSCAR RUTA", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Quick Actions (ACCESOS RÁPIDOS)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "ACCESOS RÁPIDOS",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val actionModifier = Modifier.weight(1f).height(65.dp)
                    
                    QuickActionCard(
                        title = "Ver Mapa",
                        icon = Icons.Filled.Map,
                        onClick = { onNavigateToTab(MetroTab.MAPA) },
                        modifier = actionModifier
                    )
                    QuickActionCard(
                        title = "Comprar",
                        icon = Icons.Filled.QrCode,
                        onClick = { onNavigateToTab(MetroTab.BILLETES) },
                        modifier = actionModifier
                    )
                    QuickActionCard(
                        title = "Panel Sim",
                        icon = Icons.Filled.SettingsInputHdmi,
                        onClick = { onNavigateToTab(MetroTab.MAS) },
                        modifier = actionModifier
                    )
                }
            }
        }

        // Favorites and Recent Search Split
        if (savedList.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "MIS ESTACIONES FAVORITAS",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(savedList) { fav ->
                            val station = viewModel.getStation(fav.stationId)
                            if (station != null) {
                                Card(
                                    modifier = Modifier
                                        .width(140.dp)
                                        .clickable {
                                            viewModel.setDestination(station.id)
                                            onNavigateToTab(MetroTab.RUTAS)
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            StationLineBadge(lineId = station.lineId)
                                            Icon(Icons.Filled.Favorite, contentDescription = "Fav", tint = Color.Red, modifier = Modifier.size(16.dp))
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = station.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = station.district,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Network Status Details
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "ESTADO DEL METRO",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(Color.Green, CircleShape))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Servicio Normal", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Green)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    val alerts = simState.activeDisruptions
                    if (alerts.isEmpty()) {
                        Text(
                            "Línea 1 y Línea 2 operando con regularidad. No se registran cierres de estaciones de forma simulada.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            alerts.forEach { disId ->
                                val st = viewModel.getStation(disId)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color.Red.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                                        .padding(8.dp)
                                ) {
                                    Icon(Icons.Filled.Warning, contentDescription = "Cierre", tint = Color.Red, modifier = Modifier.size(16.dp))
                                    Text(
                                        "Estación ${st?.name} cerrada temporalmente.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.Red,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Origin Selector Dialog
    if (showOriginSelector) {
        StationPickerDialog(
            title = "Seleccionar Origen",
            onDismiss = { showOriginSelector = false },
            onSelect = {
                viewModel.setOrigin(it)
                showOriginSelector = false
            }
        )
    }

    // Destination Selector Dialog
    if (showDestinationSelector) {
        StationPickerDialog(
            title = "Seleccionar Destino",
            onDismiss = { showDestinationSelector = false },
            onSelect = {
                viewModel.setDestination(it)
                showDestinationSelector = false
            }
        )
    }
}

@Composable
fun QuickActionCard(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ==========================================
// 2. MAP SCREEN
// ==========================================
@Composable
fun MapaScreen(viewModel: MainViewModel) {
    val selectedId by viewModel.selectedStationId.collectAsState()
    val simState by viewModel.simulationState.collectAsState()
    val isFav = selectedId?.let { viewModel.isStationFavorite(it).collectAsState(false).value } ?: false

    var searchQuery by remember { mutableStateOf("") }
    val filteredStations = remember(searchQuery) {
        if (searchQuery.isEmpty()) {
            emptyList()
        } else {
            MetroSeedData.stations.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.district.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Main Map Canvas
        InteractiveMetroMap(
            selectedStationId = selectedId,
            onStationSelected = { viewModel.selectStation(it) },
            activeDisruptions = simState.activeDisruptions
        )

        // Floating Search Bar at Top
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Buscar estación o distrito...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Buscar") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Filled.Clear, contentDescription = "Limpiar")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.95f), RoundedCornerShape(12.dp)),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Color.Transparent
                )
            )

            // Auto-complete dropdown list
            if (filteredStations.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    LazyColumn {
                        items(filteredStations) { station ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(station.name, fontWeight = FontWeight.Bold)
                                        Text(station.district, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    }
                                },
                                leadingIcon = { StationLineBadge(lineId = station.lineId) },
                                onClick = {
                                    viewModel.selectStation(station.id)
                                    searchQuery = "" // Clear search after selection
                                }
                            )
                        }
                    }
                }
            }
        }

        // Details Panel (Card/BottomSheet style)
        if (selectedId != null) {
            val station = viewModel.getStation(selectedId!!)
            if (station != null) {
                Card(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(16.dp)
                        .clickable(enabled = false) {},
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    StationLineBadge(lineId = station.lineId)
                                    Text(
                                        text = station.name,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = station.district,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                            
                            // Close button
                            IconButton(onClick = { viewModel.selectStation(null) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Cerrar")
                            }
                        }

                        // Operational Status and Favorites
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val isDisrupted = simState.activeDisruptions.contains(station.id)
                            StatusIndicatorBadge(
                                status = if (isDisrupted) OperationalStatus.NO_DISPONIBLE_DEMO else station.status
                            )

                            // Favorite Button
                            Button(
                                onClick = { viewModel.toggleFavorite(station.id) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isFav) Color.Red.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (isFav) Color.Red else MaterialTheme.colorScheme.onSurface
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    contentDescription = "Favorito",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isFav) "Guardada" else "Guardar", fontSize = 12.sp)
                            }
                        }

                        // Description & Landmarks
                        Text(
                            text = station.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )

                        if (station.landmarks.isNotEmpty()) {
                            Text(
                                text = "Lugares cercanos: " + station.landmarks.joinToString(", "),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Facilities badges
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FacilityChip(icon = Icons.Filled.Accessible, label = "Accesible")
                            FacilityChip(icon = Icons.Filled.Elevator, label = "Ascensor")
                            FacilityChip(icon = Icons.Filled.Escalator, label = "Escalera Mecánica")
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Destination selection actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.setOrigin(station.id)
                                    viewModel.selectStation(null)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
                            ) {
                                Text("Desde aquí", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            Button(
                                onClick = {
                                    viewModel.setDestination(station.id)
                                    viewModel.selectStation(null)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Ir hasta aquí", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FacilityChip(icon: ImageVector, label: String) {
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.padding(vertical = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = label, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
        }
    }
}

// ==========================================
// 3. RUTAS SCREEN & VIAJE SIMULADO
// ==========================================
@Composable
fun RutasScreen(viewModel: MainViewModel) {
    val originId by viewModel.originStationId.collectAsState()
    val destId by viewModel.destinationStationId.collectAsState()
    val routes by viewModel.calculatedRoutes.collectAsState()
    val activeJourney by viewModel.activeJourney.collectAsState()

    var showOriginDialog by remember { mutableStateOf(false) }
    var showDestDialog by remember { mutableStateOf(false) }

    if (activeJourney.isActive) {
        // SHOW LIVE VIAJE SIMULADO PANEL
        ViajeSimuladoScreen(activeJourney = activeJourney, viewModel = viewModel)
    } else {
        // NORMAL ROUTE PLANNER SEARCH FORM
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "PLANIFICADOR DE RUTAS",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            // Selector cards
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Origin Select Box
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showOriginDialog = true }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.RadioButtonUnchecked, contentDescription = "Origen", tint = Color(0xFF00A859))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Origen", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(
                                text = if (originId.isNotEmpty()) viewModel.getStationName(originId) else "Seleccionar origen",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (originId.isNotEmpty()) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }

                    HorizontalDivider()

                    // Destination Select Box
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showDestDialog = true }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Place, contentDescription = "Destino", tint = Color(0xFFE31A1C))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Destino", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(
                                text = if (destId.isNotEmpty()) viewModel.getStationName(destId) else "Seleccionar destino",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (destId.isNotEmpty()) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            // Route search result list
            if (originId.isEmpty() || destId.isEmpty()) {
                // Empty state
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.DirectionsTransit, contentDescription = "Rutas", modifier = Modifier.size(48.dp), tint = Color.LightGray)
                        Text(
                            "Seleccione origen y destino para planificar su viaje de demostración.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray,
                            modifier = Modifier.padding(horizontal = 32.dp)
                        )
                    }
                }
            } else if (routes.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No se encontraron rutas disponibles entre estas estaciones debido a cierres temporales.", textAlign = TextAlign.Center, color = Color.Red)
                }
            } else {
                // List routes
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(routes) { option ->
                        RouteOptionCard(
                            option = option,
                            viewModel = viewModel,
                            onStartJourney = { viewModel.startJourney(option) }
                        )
                    }
                }
            }
        }
    }

    if (showOriginDialog) {
        StationPickerDialog("Seleccionar Origen", onDismiss = { showOriginDialog = false }) {
            viewModel.setOrigin(it)
            showOriginDialog = false
        }
    }

    if (showDestDialog) {
        StationPickerDialog("Seleccionar Destino", onDismiss = { showDestDialog = false }) {
            viewModel.setDestination(it)
            showDestDialog = false
        }
    }
}

@Composable
fun RouteOptionCard(
    option: RouteOption,
    viewModel: MainViewModel,
    onStartJourney: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Header stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Route Type Badge
                val badgeColor = when (option.type) {
                    RouteType.RAPIDA -> Color(0xFF00A859)
                    RouteType.MENOS_TRANSBORDOS -> Color(0xFF0077C0)
                    RouteType.SENCILLA -> Color(0xFF8E8D8A)
                }
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = badgeColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = option.type.name,
                        style = MaterialTheme.typography.labelSmall,
                        color = badgeColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "${option.totalMinutes} min",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        if (option.transfers == 0) "Directo" else "${option.transfers} transb.",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.Gray
                    )
                }
            }

            // Connection leg overview representation
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                option.legs.forEachIndexed { idx, leg ->
                    if (idx > 0) {
                        Icon(Icons.Filled.ArrowRight, contentDescription = "Transbordo", tint = Color.Gray)
                    }
                    if (leg.lineId != null) {
                        StationLineBadge(lineId = leg.lineId)
                    } else {
                        Icon(Icons.AutoMirrored.Filled.DirectionsWalk, contentDescription = "Caminar", tint = Color.Gray, modifier = Modifier.size(16.dp))
                    }
                }
            }

            HorizontalDivider()

            // Main station summary label
            Text(
                text = "${viewModel.getStationName(option.legs.first().fromStationId)} → ${viewModel.getStationName(option.legs.last().toStationId)}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )

            if (expanded) {
                // Expanded detailed step-by-step
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    option.legs.forEachIndexed { idx, leg ->
                        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                if (leg.lineId != null) {
                                    StationLineBadge(lineId = leg.lineId)
                                } else {
                                    Icon(Icons.AutoMirrored.Filled.DirectionsWalk, contentDescription = "Caminar", tint = Color.Gray, modifier = Modifier.size(18.dp))
                                }
                                Box(modifier = Modifier.width(2.dp).height(24.dp).background(Color.Gray))
                            }
                            Column {
                                Text(
                                    "${viewModel.getStationName(leg.fromStationId)} a ${viewModel.getStationName(leg.toStationId)}",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    "${leg.estimatedMinutes} min | ${if (leg.intermediateStations.isEmpty()) "Sin paradas" else "${leg.intermediateStations.size} paradas interm."}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.Gray
                                )
                                if (leg.transferInstructions != null) {
                                    Text(
                                        leg.transferInstructions,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFFC85A32),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    // Terminal arrival display
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Filled.Place, contentDescription = "Llegada", tint = Color.Red, modifier = Modifier.size(18.dp))
                        Text(
                            "Destino: ${viewModel.getStationName(option.legs.last().toStationId)}",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { expanded = !expanded }) {
                    Text(if (expanded) "Ocultar recorrido" else "Ver recorrido")
                    Icon(
                        imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = "Detalles"
                    )
                }

                Button(
                    onClick = { onStartJourney() },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = "Iniciar")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Iniciar viaje", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ViajeSimuladoScreen(
    activeJourney: ActiveJourneyState,
    viewModel: MainViewModel
) {
    val route = activeJourney.selectedRoute ?: return
    val currentStationName = viewModel.getStationName(activeJourney.currentStationId)
    val nextStationName = activeJourney.nextStationId?.let { viewModel.getStationName(it) } ?: "Destino"
    val destName = viewModel.getStationName(route.legs.last().toStationId)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header Status Info
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = Color.Red.copy(alpha = 0.1f),
                border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.4f))
            ) {
                Text(
                    "VIAJE SIMULADO EN EJECUCIÓN",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Red,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                "Tránsito hacia $destName",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }

        // Animated Transit Graphics (Train between stations)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Estación Actual", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Text(currentStationName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Tránsito",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                        Text("Siguiente Estación", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Text(nextStationName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    }
                }

                // Dynamic progress track bar representing train travel movement
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(activeJourney.progressPercent)
                            .background(Color(0xFF00A859)) // Animated Green Line
                    )
                }

                // Estimated remaining minutes countdown
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Tiempo Estimado Restante:", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                    Text(
                        "${activeJourney.remainingMinutes} min",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Interactive pause and control buttons
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { viewModel.pauseJourney() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeJourney.isPaused) Color(0xFF00A859) else Color(0xFFC85A32)
                )
            ) {
                Icon(
                    imageVector = if (activeJourney.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                    contentDescription = "Pausar"
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (activeJourney.isPaused) "REANUDAR VIAJE" else "PAUSAR VIAJE",
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = { viewModel.endJourney() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.5.dp, Color.Red),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red)
            ) {
                Icon(Icons.Filled.Stop, contentDescription = "Detener")
                Spacer(modifier = Modifier.width(8.dp))
                Text("FINALIZAR VIAJE", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ==========================================
// 4. BILLETES & WALLET SCREEN
// ==========================================
@Composable
fun BilletesScreen(viewModel: MainViewModel) {
    val wallet by viewModel.walletState.collectAsState()
    val tickets by viewModel.purchasedTickets.collectAsState()
    val context = LocalContext.current

    var selectedProductForBuy by remember { mutableStateOf<FareProduct?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "MIS BILLETES Y TARJETA",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        // Premium Virtual Ticket Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)), // Dark Slate Graphite
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Deco overlay representing Lime City abstract grid
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.White.copy(alpha = 0.03f))
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "TARJETA METROPOLITANA INTEGRADA",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "LIMA METRO",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            // Gold microchip simulator icon
                            Box(
                                modifier = Modifier
                                    .size(32.dp, 24.dp)
                                    .background(Color(0xFFC5A059), RoundedCornerShape(4.dp))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(
                                    "SALDO DISPONIBLE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.5f)
                                )
                                Text(
                                    "S/ " + String.format(Locale.US, "%.2f", wallet?.balance ?: 0.0),
                                    style = MaterialTheme.typography.headlineLarge,
                                    color = Color(0xFF00A859), // Light Green balance text
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            
                            // Recharge options row
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { viewModel.rechargeWallet(10.0) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC5A059)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("+ S/ 10", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                                Button(
                                    onClick = { viewModel.rechargeWallet(20.0) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC5A059)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("+ S/ 20", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Purchase New Tickets Section
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "COMPRAR BILLETES DIGITALES",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
                
                // Horizontal list of products
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(MetroSeedData.fareProducts) { product ->
                        Card(
                            modifier = Modifier
                                .width(160.dp)
                                .clickable { selectedProductForBuy = product },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(product.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("S/ " + String.format(Locale.US, "%.2f", product.price), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text(product.description, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color.Gray)
                                Spacer(modifier = Modifier.height(4.dp))
                                Button(
                                    onClick = { selectedProductForBuy = product },
                                    modifier = Modifier.fillMaxWidth(),
                                    contentPadding = PaddingValues(vertical = 4.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Adquirir", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Wallet Purchased Digital Tickets history / active tickets list
        item {
            Text(
                "MIS BILLETES ADQUIRIDOS",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
        }

        if (tickets.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().height(120.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No tiene billetes digitales activos. Adquiera uno arriba.", color = Color.Gray, style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            items(tickets) { ticket ->
                TicketItemRow(ticket = ticket)
            }
        }
    }

    // Purchase Dialog Confirmation
    if (selectedProductForBuy != null) {
        val product = selectedProductForBuy!!
        AlertDialog(
            onDismissRequest = { selectedProductForBuy = null },
            title = { Text("Confirmar Compra") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("¿Desea adquirir el siguiente producto de demostración?")
                    Text(product.name, fontWeight = FontWeight.Bold)
                    Text("Costo total: S/ " + String.format(Locale.US, "%.2f", product.price), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("Este billete se debitará de su tarjeta digital simulada.", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.buyTicket(
                            product = product,
                            onSuccess = {
                                selectedProductForBuy = null
                                Toast.makeText(context, "¡Compra simulada exitosa!", Toast.LENGTH_SHORT).show()
                            },
                            onError = { error ->
                                Toast.makeText(context, error, Toast.LENGTH_LONG).show()
                            }
                        )
                    }
                ) {
                    Text("Confirmar Compra")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedProductForBuy = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun TicketItemRow(ticket: TicketEntity) {
    var showQRDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showQRDialog = true },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Icon(
                    Icons.Filled.QrCode,
                    contentDescription = "Boleto",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
                Column {
                    Text(ticket.productName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text("S/ " + String.format(Locale.US, "%.2f", ticket.price), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text(ticket.validityPeriod, style = MaterialTheme.typography.labelSmall, color = Color(0xFFC85A32), fontWeight = FontWeight.Bold)
                }
            }

            Icon(Icons.Filled.QrCodeScanner, contentDescription = "Ver Código QR", tint = Color.Gray)
        }
    }

    // Modal dialogue to display ticket QR Code
    if (showQRDialog) {
        Dialog(onDismissRequest = { showQRDialog = false }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("BILLETE DE DEMOSTRACIÓN", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Text(ticket.productName, fontWeight = FontWeight.SemiBold)
                    
                    // Simple schematic QR Code simulation box
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .background(Color.Black, RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Drawing grid dots inside QR Box
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val dotSpacing = 16f
                            for (x in 0..10) {
                                for (y in 0..10) {
                                    if ((x + y) % 3 == 0 || (x * y) % 5 == 2) {
                                        drawRect(
                                            color = Color.White,
                                            topLeft = Offset(x * dotSpacing, y * dotSpacing),
                                            size = androidx.compose.ui.geometry.Size(10f, 10f)
                                        )
                                    }
                                }
                            }
                            // Corner locator anchors
                            drawRect(Color.White, topLeft = Offset(0f, 0f), size = androidx.compose.ui.geometry.Size(32f, 32f), style = Stroke(width = 4f))
                            drawRect(Color.White, topLeft = Offset(size.width - 32f, 0f), size = androidx.compose.ui.geometry.Size(32f, 32f), style = Stroke(width = 4f))
                            drawRect(Color.White, topLeft = Offset(0f, size.height - 32f), size = androidx.compose.ui.geometry.Size(32f, 32f), style = Stroke(width = 4f))
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color.Red.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, Color.Red)
                    ) {
                        Text(
                            "NO VÁLIDO PARA VIAJAR — DEMOSTRACIÓN",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Red,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            textAlign = TextAlign.Center
                        )
                    }

                    Text("Código único: ${ticket.qrCodeContent}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)

                    Button(
                        onClick = { showQRDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cerrar")
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. MAS & AJUSTES & DEV SCREEN
// ==========================================
@Composable
fun MasScreen(viewModel: MainViewModel) {
    val settings by viewModel.settingsState.collectAsState()
    val simState by viewModel.simulationState.collectAsState()
    val context = LocalContext.current

    var selectedSection by remember { mutableStateOf(0) } // 0: Settings, 1: Dev Console, 2: District Guides

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Horizontal selector tabs
        TabRow(selectedTabIndex = selectedSection) {
            Tab(selected = selectedSection == 0, onClick = { selectedSection = 0 }) {
                Text("Ajustes", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedSection == 1, onClick = { selectedSection = 1 }) {
                Text("Desarrollador", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = selectedSection == 2, onClick = { selectedSection = 2 }) {
                Text("Guía Lima", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (selectedSection) {
                0 -> SettingsSubSection(settings, viewModel, context)
                1 -> DeveloperSubSection(simState, viewModel)
                2 -> DistrictGuideSubSection()
            }
        }
    }
}

@Composable
fun SettingsSubSection(
    settings: com.example.core.settings.SettingsState,
    viewModel: MainViewModel,
    context: android.content.Context
) {
    val coroutineScope = rememberCoroutineScope()
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("PREFERENCIAS DE ACCESIBILIDAD Y TEMA", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color.Gray)
        }

        // Dark Mode
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Modo Oscuro", fontWeight = FontWeight.Bold)
                    Text("Forzar interfaz con paleta oscura", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
                Switch(
                    checked = settings.darkTheme == true,
                    onCheckedChange = { coroutineScope.launch { MetroSettings.updateDarkTheme(context, if (it) true else null) } }
                )
            }
        }

        // Large Text Scale
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Texto Grande", fontWeight = FontWeight.Bold)
                    Text("Incrementa el tamaño de fuente", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
                Switch(
                    checked = settings.largeText,
                    onCheckedChange = { coroutineScope.launch { MetroSettings.updateLargeText(context, it) } }
                )
            }
        }

        // High Contrast Theme
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Alto Contraste", fontWeight = FontWeight.Bold)
                    Text("Optimiza contraste de colores", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
                Switch(
                    checked = settings.highContrast,
                    onCheckedChange = { coroutineScope.launch { MetroSettings.updateHighContrast(context, it) } }
                )
            }
        }

        // Reduced Motion
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Movimiento Reducido", fontWeight = FontWeight.Bold)
                    Text("Desactiva animaciones secundarias", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
                Switch(
                    checked = settings.reducedMotion,
                    onCheckedChange = { coroutineScope.launch { MetroSettings.updateReducedMotion(context, it) } }
                )
            }
        }

        // Haptic Feedback
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Retroalimentación Háptica", fontWeight = FontWeight.Bold)
                    Text("Vibración táctil al pasar estaciones", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
                Switch(
                    checked = settings.hapticFeedback,
                    onCheckedChange = { coroutineScope.launch { MetroSettings.updateHapticFeedback(context, it) } }
                )
            }
        }

        // Show Future Lines
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Mostrar Líneas Futuras", fontWeight = FontWeight.Bold)
                    Text("Visualiza Línea 3 y Línea 4 planificadas", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
                Switch(
                    checked = settings.showFutureLines,
                    onCheckedChange = { coroutineScope.launch { MetroSettings.updateShowFutureLines(context, it) } }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = {
                    coroutineScope.launch {
                        MetroSettings.resetAll(context)
                        Toast.makeText(context, "Ajustes restablecidos.", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Restablecer Ajustes", fontWeight = FontWeight.Bold)
            }
        }

        // Disclaimer
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            ) {
                Text(
                    text = "DESCARGO DE RESPONSABILIDAD: Esta aplicación es un prototipo conceptual de Lima Metro, de carácter puramente demostrativo y educativo. No posee afiliación alguna con la Línea 1, la Línea 2, el MTC, ATU, ni entidades gubernamentales del Perú. Todos los pasajes, saldos y tiempos de traslado son simulados.",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }
}

@Composable
fun DeveloperSubSection(
    simState: com.example.core.simulation.SimulationState,
    viewModel: MainViewModel
) {
    var customL1Freq by remember { mutableStateOf(simState.trainFrequencyMinutesL1.toString()) }
    var customL2Freq by remember { mutableStateOf(simState.trainFrequencyMinutesL2.toString()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("PANEL DE CONTROL DE SIMULACIÓN", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color.Gray)
        }

        // Set Simulated Hour Selectors
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Reloj de Simulación (Hora del Día)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SimulatedTimeOfDay.values().forEach { time ->
                            val isSelected = simState.selectedTimeOfDay == time
                            Button(
                                onClick = { SimulationEngine.setTimeOfDay(time) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(time.name.replace("_", " "), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Advance simulation time
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Avanzar Reloj", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { SimulationEngine.advanceTimeByMinutes(5) }) {
                            Text("+5 min")
                        }
                        Button(onClick = { SimulationEngine.advanceTimeByMinutes(15) }) {
                            Text("+15 min")
                        }
                    }
                }
            }
        }

        // Station Disruptions Closure control
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Simular Cierres de Estaciones", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    
                    val operationalStations = MetroSeedData.stations.filter { it.status == OperationalStatus.OPERATIVA }
                    
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.height(180.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(operationalStations) { st ->
                            val isClosed = simState.activeDisruptions.contains(st.id)
                            Button(
                                onClick = { SimulationEngine.toggleStationDisruption(st.id) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isClosed) Color.Red else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (isClosed) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                contentPadding = PaddingValues(6.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(st.name, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }

                    if (simState.activeDisruptions.isNotEmpty()) {
                        Button(
                            onClick = { SimulationEngine.clearAllDisruptions() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Green, contentColor = Color.Black),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Resolver Todas las Incidencias", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Real-time Event Log screen Console
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("REGISTRO DE OPERACIÓN EN VIVO (LOG)", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Gray)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Black)
                ) {
                    LazyColumn(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(simState.logs) { log ->
                            Text(log, style = MaterialTheme.typography.labelSmall, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, color = Color.Green)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DistrictGuideSubSection() {
    val districts = listOf(
        Pair("Centro Histórico", "Conectado por la estación Grau. Alberga la Catedral de Lima, Plaza Mayor, iglesias barrocas y el centro político del país."),
        Pair("Gamarra", "El emporio textil más grande de Sudamérica, ubicado en La Victoria. La estación Gamarra registra el mayor flujo comercial del sistema."),
        Pair("San Borja", "Zona residencial y cultural, con estación La Cultura enlazando el Gran Teatro Nacional y la Biblioteca de la Nación."),
        Pair("Ate Vitarte", "Conectado por el nuevo tramo subterráneo de Línea 2, adyacente al Mercado Mayorista e industrias clave de la zona este."),
        Pair("Callao", "Primer puerto peruano, clave industrial y pesquera. Cruce vital de obras del tramo subterráneo de la Línea 2.")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("GUÍA CIVICA DE LIMA METROPOLITANA", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Color.Gray)
        }

        items(districts) { district ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(district.first, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(district.second, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                }
            }
        }
    }
}

// ==========================================
// REUSABLE SUPPORTING COMPOSABLES
// ==========================================
@Composable
fun StationLineBadge(lineId: String) {
    val color = when (lineId) {
        "L1" -> Color(0xFF00A859) // Green
        "L2" -> Color(0xFFE31A1C) // Red
        "L3" -> Color(0xFFF7931E) // Orange
        "L4" -> Color(0xFF00AEEF) // Blue
        else -> Color.Gray
    }
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = color
    ) {
        Text(
            text = lineId,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun StatusIndicatorBadge(status: OperationalStatus) {
    val (label, bg, fg) = when (status) {
        OperationalStatus.OPERATIVA -> Triple("OPERATIVA", Color(0xFF00A859).copy(alpha = 0.15f), Color(0xFF00A859))
        OperationalStatus.EN_CONSTRUCCION -> Triple("EN CONSTRUCCIÓN", Color(0xFF0077C0).copy(alpha = 0.15f), Color(0xFF0077C0))
        OperationalStatus.PLANIFICADA -> Triple("PLANIFICADA", Color.Gray.copy(alpha = 0.15f), Color.DarkGray)
        OperationalStatus.NO_DISPONIBLE_DEMO -> Triple("CERRADA POR MANTENIMIENTO", Color.Red.copy(alpha = 0.15f), Color.Red)
    }

    Surface(
        shape = RoundedCornerShape(4.dp),
        color = bg,
        border = BorderStroke(1.dp, fg.copy(alpha = 0.4f))
    ) {
        Text(
            text = label,
            color = fg,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun StationPickerDialog(
    title: String,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    var filterText by remember { mutableStateOf("") }
    val filtered = remember(filterText) {
        MetroSeedData.stations.filter {
            it.status != OperationalStatus.PLANIFICADA &&
            (it.name.contains(filterText, ignoreCase = true) || it.district.contains(filterText, ignoreCase = true))
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(450.dp)
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                
                OutlinedTextField(
                    value = filterText,
                    onValueChange = { filterText = it },
                    placeholder = { Text("Buscar por nombre o distrito...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Buscar") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filtered) { station ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(station.id) }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StationLineBadge(lineId = station.lineId)
                            Column {
                                Text(station.name, fontWeight = FontWeight.Bold)
                                Text(station.district, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }
                        }
                        HorizontalDivider()
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Cancelar")
                }
            }
        }
    }
}
