package com.example.features.map

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.OperationalStatus
import com.example.core.settings.MetroSettings
import com.example.data.seed.MetroSeedData
import kotlinx.coroutines.launch
import kotlin.math.sqrt

// Relative schematic coordinates defined in (0 to 1000) space
private data class SchematicCoord(val x: Float, val y: Float)

private val schematicCoords = mapOf(
    // Line 1
    "L1-VES" to SchematicCoord(150f, 820f),
    "L1-PUM" to SchematicCoord(200f, 760f),
    "L1-MAR" to SchematicCoord(250f, 700f),
    "L1-ATO" to SchematicCoord(300f, 640f),
    "L1-CAB" to SchematicCoord(350f, 580f),
    "L1-ANG" to SchematicCoord(400f, 520f),
    "L1-SBN" to SchematicCoord(450f, 460f),
    "L1-CUL" to SchematicCoord(500f, 400f), // Center interchange
    "L1-GAM" to SchematicCoord(550f, 330f),
    "L1-GRA" to SchematicCoord(600f, 260f),
    "L1-CDA" to SchematicCoord(650f, 200f),
    "L1-JAD" to SchematicCoord(700f, 140f),
    "L1-BAY" to SchematicCoord(750f, 80f),

    // Line 2
    "L2-PCL" to SchematicCoord(100f, 400f),
    "L2-GCH" to SchematicCoord(220f, 400f),
    "L2-EVI" to SchematicCoord(420f, 400f),
    "L2-OSA" to SchematicCoord(500f, 400f), // Near Center
    "L2-COI" to SchematicCoord(620f, 400f),
    "L2-HVA" to SchematicCoord(740f, 400f),
    "L2-MSA" to SchematicCoord(850f, 400f),
    "L2-ATE" to SchematicCoord(940f, 400f),

    // Line 3 (Planned)
    "L3-CCS" to SchematicCoord(500f, 260f)
)

@OptIn(ExperimentalTextApi::class)
@Composable
fun InteractiveMetroMap(
    selectedStationId: String?,
    onStationSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    activeDisruptions: Set<String> = emptySet(),
    activeJourneyStationIds: Set<String> = emptySet(),
    currentJourneyStationId: String? = null
) {
    val settings by MetroSettings.state.collectAsState()

    var scale by remember { mutableStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset(0f, 0f)) }

    val textMeasurer = rememberTextMeasurer()
    val onBackground = MaterialTheme.colorScheme.onBackground

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Main map gesture canvas container
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.6f, 4.0f)
                        offset += pan
                    }
                }
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(scale, offset) {
                        detectMetroTapGestures(scale, offset, onStationSelected)
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // 1. Draw Lines (Connections)
                MetroSeedData.connections.forEach { conn ->
                    val fromStation = MetroSeedData.stations.find { it.id == conn.fromStationId } ?: return@forEach
                    val toStation = MetroSeedData.stations.find { it.id == conn.toStationId } ?: return@forEach

                    // Filter out future lines if hidden
                    if (!settings.showFutureLines && (fromStation.status == OperationalStatus.PLANIFICADA || toStation.status == OperationalStatus.PLANIFICADA)) {
                        return@forEach
                    }

                    val coordFrom = schematicCoords[conn.fromStationId] ?: return@forEach
                    val coordTo = schematicCoords[conn.toStationId] ?: return@forEach

                    val p1 = Offset((coordFrom.x / 1000f) * canvasWidth, (coordFrom.y / 1000f) * canvasHeight)
                    val p2 = Offset((coordTo.x / 1000f) * canvasWidth, (coordTo.y / 1000f) * canvasHeight)

                    // Line Color
                    val line = MetroSeedData.lines.find { it.id == fromStation.lineId }
                    val baseColor = line?.color?.let { Color(android.graphics.Color.parseColor(it)) } ?: Color.Gray
                    
                    // Style adjustments based on status
                    val isFuture = fromStation.status == OperationalStatus.PLANIFICADA || 
                                     toStation.status == OperationalStatus.PLANIFICADA ||
                                     fromStation.status == OperationalStatus.EN_CONSTRUCCION ||
                                     toStation.status == OperationalStatus.EN_CONSTRUCCION

                    val color = if (isFuture) baseColor.copy(alpha = 0.4f) else baseColor
                    val strokeWidth = if (isFuture) 6f else 12f
                    
                    drawLine(
                        color = color,
                        start = p1,
                        end = p2,
                        strokeWidth = strokeWidth,
                        cap = StrokeCap.Round
                    )
                }

                // 2. Draw Stations (Circles) and Labels
                MetroSeedData.stations.forEach { station ->
                    if (!settings.showFutureLines && station.status == OperationalStatus.PLANIFICADA) {
                        return@forEach
                    }

                    val coord = schematicCoords[station.id] ?: return@forEach
                    val center = Offset((coord.x / 1000f) * canvasWidth, (coord.y / 1000f) * canvasHeight)

                    val line = MetroSeedData.lines.find { it.id == station.lineId }
                    val lineColor = line?.color?.let { Color(android.graphics.Color.parseColor(it)) } ?: Color.Gray

                    val isSelected = station.id == selectedStationId
                    val isDisrupted = activeDisruptions.contains(station.id)
                    val isActiveInJourney = activeJourneyStationIds.contains(station.id)
                    val isCurrentInJourney = station.id == currentJourneyStationId

                    // Outer halo
                    if (isSelected) {
                        drawCircle(
                            color = lineColor.copy(alpha = 0.3f),
                            radius = 28f,
                            center = center
                        )
                        drawCircle(
                            color = lineColor,
                            radius = 18f,
                            center = center,
                            style = Stroke(width = 4f)
                        )
                    }

                    if (isCurrentInJourney) {
                        drawCircle(
                            color = Color.Yellow.copy(alpha = 0.5f),
                            radius = 32f,
                            center = center
                        )
                    }

                    // Base Station Circle
                    val circleColor = when {
                        isDisrupted -> Color.Red
                        isCurrentInJourney -> Color.Yellow
                        isActiveInJourney -> Color.Green
                        station.status == OperationalStatus.PLANIFICADA -> Color.Gray.copy(alpha = 0.5f)
                        station.status == OperationalStatus.EN_CONSTRUCCION -> lineColor.copy(alpha = 0.6f)
                        station.isInterchange -> Color.White
                        else -> lineColor
                    }

                    drawCircle(
                        color = circleColor,
                        radius = if (station.isInterchange) 11f else 8f,
                        center = center
                    )

                    if (station.isInterchange) {
                        drawCircle(
                            color = lineColor,
                            radius = 11f,
                            center = center,
                            style = Stroke(width = 3f)
                        )
                    }

                    // Station labels (Only if scale is decent to prevent clutter, or smaller labels)
                    val labelSize = (11 / scale).coerceIn(6f, 13f)
                    val textLayoutResult = textMeasurer.measure(
                        text = AnnotatedString(station.name),
                        style = TextStyle(
                            fontSize = labelSize.sp,
                            fontWeight = if (station.isInterchange || isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) lineColor else onBackground
                        )
                    )

                    // Draw labels slightly offset from circle
                    val textOffset = Offset(
                        x = center.x + 14f,
                        y = center.y - (textLayoutResult.size.height / 2f)
                    )
                    drawText(textLayoutResult = textLayoutResult, topLeft = textOffset)
                }
            }
        }

        // Float Control Buttons (+ / - / Reset)
        Card(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(
                modifier = Modifier.padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { scale = (scale * 1.3f).coerceAtMost(4.0f) }) {
                    Icon(Icons.Filled.Add, contentDescription = "Acercar", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { scale = (scale / 1.3f).coerceAtLeast(0.6f) }) {
                    Icon(Icons.Filled.Remove, contentDescription = "Alejar", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { 
                    scale = 1.0f
                    offset = Offset(0f, 0f)
                }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Centrar", tint = MaterialTheme.colorScheme.secondary)
                }
            }
        }

        // Fast Legend
        Card(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("LEYENDA", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(8.dp).background(Color(0xFF00A859), CircleShape))
                    Text("Línea 1", style = MaterialTheme.typography.labelSmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(8.dp).background(Color(0xFFE31A1C), CircleShape))
                    Text("Línea 2", style = MaterialTheme.typography.labelSmall)
                }
                if (settings.showFutureLines) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(modifier = Modifier.size(8.dp).background(Color.Gray, CircleShape))
                        Text("Futura/En obras", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

// Custom Gesture detector helper for Tap gestures on Canvas
private suspend fun androidx.compose.ui.input.pointer.PointerInputScope.detectMetroTapGestures(
    scale: Float,
    offset: Offset,
    onStationSelected: (String) -> Unit
) {
    detectTapGestures { tapOffset ->
        val canvasWidth = size.width.toFloat()
        val canvasHeight = size.height.toFloat()

        // Reverse-engineer tap coordinate to relative (0 to 1000) space
        val untransformedTapX = (tapOffset.x - offset.x) / scale
        val untransformedTapY = (tapOffset.y - offset.y) / scale

        var closestStationId: String? = null
        var minDistance = 100f // Click tolerance in pixels

        schematicCoords.forEach { (stationId, coord) ->
            val actualX = (coord.x / 1000f) * canvasWidth
            val actualY = (coord.y / 1000f) * canvasHeight

            val distance = sqrt(((actualX - untransformedTapX) * (actualX - untransformedTapX) + (actualY - untransformedTapY) * (actualY - untransformedTapY)).toDouble()).toFloat()
            if (distance < minDistance) {
                minDistance = distance
                closestStationId = stationId
            }
        }

        closestStationId?.let {
            onStationSelected(it)
        }
    }
}
