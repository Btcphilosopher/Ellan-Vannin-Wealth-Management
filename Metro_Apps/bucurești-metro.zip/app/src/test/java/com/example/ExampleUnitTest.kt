package com.example

import com.example.core.model.*
import com.example.core.routing.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    // Helper normalizer
    private fun String.normalizeRomanian(): String {
        return this.lowercase()
            .replace("ă", "a")
            .replace("â", "a")
            .replace("î", "i")
            .replace("ș", "s")
            .replace("ț", "t")
    }

    @Test
    fun testRomanianSearchNormalization() {
        val test1 = "Piața Unirii".normalizeRomanian()
        val test2 = "piata unirii".normalizeRomanian()
        assertEquals(test1, test2)

        val test3 = "Tineretului".normalizeRomanian()
        val test4 = "tineretului".normalizeRomanian()
        assertEquals(test3, test4)

        val test5 = "Eroilor".normalizeRomanian()
        val test6 = "eroilor".normalizeRomanian()
        assertEquals(test5, test6)
    }

    @Test
    fun testMetroRouterBasicAndAccessibilityPathfinding() {
        // Create a mock network
        val stations = listOf(
            MetroStation("S1", "Stația 1", 44.40, 26.00, listOf("M1"), false, null, true, null, null),
            MetroStation("S2", "Stația 2", 44.41, 26.01, listOf("M1", "M2"), true, null, true, null, null),
            MetroStation("S3", "Stația 3", 44.42, 26.02, listOf("M2"), false, null, false, null, null), // NOT accessible
            MetroStation("S4", "Stația 4", 44.43, 26.03, listOf("M1"), false, null, true, null, null)
        )

        val lines = listOf(
            MetroLine("M1", "M1", "Linia M1", "#FF0000", listOf("S1", "S2", "S4"), "S1", "S4", ""),
            MetroLine("M2", "M2", "Linia M2", "#0000FF", listOf("S2", "S3"), "S2", "S3", "")
        )

        val connections = listOf(
            MetroConnection("S1", "S2", "M1", 100, 1000),
            MetroConnection("S2", "S4", "M1", 120, 1200),
            MetroConnection("S2", "S3", "M2", 150, 1500)
        )

        val interchanges = listOf(
            InterchangeStation("S2", "Stația 2", listOf("M1", "M2"), 180, "Transfer rapid")
        )

        val router = MetroRouter(stations, lines, connections, interchanges)

        // 1. Direct path S1 -> S4 on M1
        val resultDirect = router.calculateRoute("S1", "S4", RoutePreference.CEL_MAI_RAPID)
        assertNotNull(resultDirect)
        assertEquals(220, resultDirect!!.durationSeconds)
        assertEquals(listOf("S1", "S2", "S4"), resultDirect.stations)
        assertEquals(0, resultDirect.transfersCount)

        // 2. Multi-line path S1 -> S3 (requires transfer at S2 to M2)
        val resultTransfer = router.calculateRoute("S1", "S3", RoutePreference.CEL_MAI_RAPID)
        assertNotNull(resultTransfer)
        // S1 -> S2 (100) + transfer at S2 (180) + S2 -> S3 (150) = 430
        assertEquals(430, resultTransfer!!.durationSeconds)
        assertEquals(1, resultTransfer.transfersCount)

        // 3. Accessibility filter: S3 is NOT accessible.
        // If we request ACCESIBIL route preference, the route through S3 should be heavily penalized or marked as inaccessible
        val resultAccessible = router.calculateRoute("S1", "S3", RoutePreference.ACCESIBIL)
        assertNotNull(resultAccessible)
        assertFalse(resultAccessible!!.isAccessible)
    }

    @Test
    fun testTicketPricingAndValidityDetails() {
        val product = FareProduct(
            id = "one_trip",
            name = "Bilet 1 călătorie",
            price = 3.0,
            currency = "lei",
            validityMinutes = 90,
            validityHours = 0,
            transportModes = listOf("Metro"),
            eligibility = "Toți pasagerii",
            lastUpdated = "2026-09-01",
            isDemonstration = true
        )

        assertEquals("lei", product.currency)
        assertEquals(3.0, product.price, 0.0)
        assertTrue(product.isDemonstration)
        assertEquals(90, product.validityMinutes)
    }
}
