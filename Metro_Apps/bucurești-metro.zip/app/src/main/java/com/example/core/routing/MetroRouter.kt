package com.example.core.routing

import com.example.core.model.InterchangeStation
import com.example.core.model.MetroConnection
import com.example.core.model.MetroLine
import com.example.core.model.MetroStation
import java.util.PriorityQueue

data class RouteStep(
    val type: StepType,
    val stationId: String,
    val stationName: String,
    val lineId: String? = null,
    val direction: String? = null,
    val durationSeconds: Int = 0,
    val description: String = ""
)

enum class StepType {
    PLECARE,      // Departure station / board train
    CALATORIE,    // Riding the train (intermediate stops)
    SCHIMB,       // Transfer to another line
    SOSIRE        // Arrival / exit
}

data class RouteResult(
    val type: RoutePreference,
    val durationSeconds: Int,
    val stations: List<String>,
    val transfersCount: Int,
    val steps: List<RouteStep>,
    val isAccessible: Boolean
)

enum class RoutePreference {
    CEL_MAI_RAPID,
    CELE_MAI_PUTINE_SCHIMBARI,
    CEL_MAI_SIMPLU,
    ACCESIBIL
}

class MetroRouter(
    private val stations: List<MetroStation>,
    private val lines: List<MetroLine>,
    private val connections: List<MetroConnection>,
    private val interchanges: List<InterchangeStation>
) {

    private val stationMap = stations.associateBy { it.id }
    private val lineMap = lines.associateBy { it.id }

    fun calculateRoute(
        fromId: String,
        toId: String,
        preference: RoutePreference
    ): RouteResult? {
        if (fromId == toId) return null
        if (!stationMap.containsKey(fromId) || !stationMap.containsKey(toId)) return null

        // Node in our search space represents (StationID, LineID)
        // This is crucial because a station can have multiple lines passing through it.
        // Transferring between lines at the same station is an edge.
        data class GraphNode(val stationId: String, val lineId: String)

        // For Dijkstra:
        data class PathState(
            val node: GraphNode,
            val totalCost: Double, // time or generalized weight
            val realTimeSeconds: Int,
            val transfers: Int,
            val path: List<GraphNode>
        ) : Comparable<PathState> {
            override fun compareTo(other: PathState): Int = this.totalCost.compareTo(other.totalCost)
        }

        val pq = PriorityQueue<PathState>()
        val visited = mutableSetOf<GraphNode>()

        // Find initial lines for the source station
        val sourceStation = stationMap[fromId] ?: return null
        for (lineId in sourceStation.lines) {
            val startNode = GraphNode(fromId, lineId)
            pq.add(
                PathState(
                    node = startNode,
                    totalCost = 0.0,
                    realTimeSeconds = 0,
                    transfers = 0,
                    path = listOf(startNode)
                )
            )
        }

        var bestState: PathState? = null

        while (pq.isNotEmpty()) {
            val state = pq.poll()!!
            val currNode = state.node

            if (currNode.stationId == toId) {
                bestState = state
                break
            }

            if (currNode in visited) continue
            visited.add(currNode)

            // 1. Move to adjacent stations on the SAME line (Ride the train)
            // We find connections on currNode.lineId
            val currentLine = lineMap[currNode.lineId]
            if (currentLine != null) {
                val stationIndex = currentLine.stations.indexOf(currNode.stationId)
                val adjacentIds = mutableListOf<String>()
                if (stationIndex > 0) adjacentIds.add(currentLine.stations[stationIndex - 1])
                if (stationIndex < currentLine.stations.size - 1) adjacentIds.add(currentLine.stations[stationIndex + 1])

                for (adjId in adjacentIds) {
                    val conn = findConnection(currNode.stationId, adjId, currNode.lineId)
                    val edgeTime = conn?.travelTimeSeconds ?: 120 // Fallback

                    // Evaluate accessibility penalty
                    val adjStation = stationMap[adjId]
                    var accessibilityPenalty = 0.0
                    if (preference == RoutePreference.ACCESIBIL && adjStation?.accessibility == false) {
                        accessibilityPenalty = 10000.0 // heavily penalize non-accessible stations
                    }

                    val nextCost = state.totalCost + edgeTime + accessibilityPenalty
                    val nextRealTime = state.realTimeSeconds + edgeTime
                    val nextNode = GraphNode(adjId, currNode.lineId)

                    pq.add(
                        PathState(
                            node = nextNode,
                            totalCost = nextCost,
                            realTimeSeconds = nextRealTime,
                            transfers = state.transfers,
                            path = state.path + nextNode
                        )
                    )
                }
            }

            // 2. Transfer to ANOTHER line at the SAME station
            val currStation = stationMap[currNode.stationId]
            if (currStation != null && currStation.lines.size > 1) {
                for (otherLineId in currStation.lines) {
                    if (otherLineId != currNode.lineId) {
                        val transferTime = interchanges.find { it.stationId == currNode.stationId }?.transferTimeSeconds ?: 180

                        // Calculate weight of transferring
                        var weightPenalty = transferTime.toDouble()
                        when (preference) {
                            RoutePreference.CELE_MAI_PUTINE_SCHIMBARI -> {
                                weightPenalty += 5000.0 // Giant penalty for changes
                            }
                            RoutePreference.CEL_MAI_SIMPLU -> {
                                weightPenalty += 1000.0 // Medium penalty to keep it simpler
                            }
                            RoutePreference.ACCESIBIL -> {
                                // If the transfer station is not accessible, penalize it
                                if (!currStation.accessibility) {
                                    weightPenalty += 20000.0
                                }
                            }
                            else -> {}
                        }

                        val nextCost = state.totalCost + weightPenalty
                        val nextRealTime = state.realTimeSeconds + transferTime
                        val nextNode = GraphNode(currNode.stationId, otherLineId)

                        pq.add(
                            PathState(
                                node = nextNode,
                                totalCost = nextCost,
                                realTimeSeconds = nextRealTime,
                                transfers = state.transfers + 1,
                                path = state.path + nextNode
                            )
                        )
                    }
                }
            }
        }

        val finalState = bestState ?: return null

        // Reconstruct steps
        val steps = mutableListOf<RouteStep>()
        val pathNodes = finalState.path

        if (pathNodes.isEmpty()) return null

        var currentRideStart = pathNodes.first()
        var intermediateRideStops = mutableListOf<String>()

        for (i in 1 until pathNodes.size) {
            val prevNode = pathNodes[i - 1]
            val currNode = pathNodes[i]

            if (prevNode.lineId != currNode.lineId) {
                // We changed lines at prevNode.stationId
                // Before changing lines, we complete the ride step
                if (prevNode.stationId != currentRideStart.stationId) {
                    val line = lineMap[currentRideStart.lineId]!!
                    val direction = determineDirection(currentRideStart.stationId, prevNode.stationId, line)
                    val rideTime = calculateRideTime(currentRideStart.stationId, prevNode.stationId, currentRideStart.lineId)
                    steps.add(
                        RouteStep(
                            type = StepType.CALATORIE,
                            stationId = prevNode.stationId,
                            stationName = stationMap[prevNode.stationId]?.name ?: prevNode.stationId,
                            lineId = currentRideStart.lineId,
                            direction = direction,
                            durationSeconds = rideTime,
                            description = "Călătorește pe linia ${currentRideStart.lineId} direcția $direction (${intermediateRideStops.size} stații)"
                        )
                    )
                }

                // Add transfer step
                val transferTime = interchanges.find { it.stationId == prevNode.stationId }?.transferTimeSeconds ?: 180
                steps.add(
                    RouteStep(
                        type = StepType.SCHIMB,
                        stationId = prevNode.stationId,
                        stationName = stationMap[prevNode.stationId]?.name ?: prevNode.stationId,
                        lineId = currNode.lineId,
                        durationSeconds = transferTime,
                        description = "Schimbă linia la ${stationMap[prevNode.stationId]?.name ?: prevNode.stationId} către linia ${currNode.lineId}"
                    )
                )

                currentRideStart = currNode
                intermediateRideStops = mutableListOf()
            } else {
                // Same line, riding
                intermediateRideStops.add(currNode.stationId)
            }
        }

        // Add final ride step if any
        val lastNode = pathNodes.last()
        if (lastNode.stationId != currentRideStart.stationId) {
            val line = lineMap[currentRideStart.lineId]!!
            val direction = determineDirection(currentRideStart.stationId, lastNode.stationId, line)
            val rideTime = calculateRideTime(currentRideStart.stationId, lastNode.stationId, currentRideStart.lineId)
            steps.add(
                RouteStep(
                    type = StepType.CALATORIE,
                    stationId = lastNode.stationId,
                    stationName = stationMap[lastNode.stationId]?.name ?: lastNode.stationId,
                    lineId = currentRideStart.lineId,
                    direction = direction,
                    durationSeconds = rideTime,
                    description = "Călătorește pe linia ${currentRideStart.lineId} direcția $direction (${intermediateRideStops.size} stații)"
                )
            )
        }

        // Prepend departure step and append arrival step
        val startStationName = stationMap[fromId]?.name ?: fromId
        val endStationName = stationMap[toId]?.name ?: toId

        val firstLineId = pathNodes.first().lineId
        val firstLine = lineMap[firstLineId]!!
        val firstRideEndId = pathNodes.find { it.lineId != firstLineId }?.stationId ?: toId
        val firstDirection = determineDirection(fromId, firstRideEndId, firstLine)

        val departureStep = RouteStep(
            type = StepType.PLECARE,
            stationId = fromId,
            stationName = startStationName,
            lineId = firstLineId,
            direction = firstDirection,
            description = "Intră în stația $startStationName și urcă în trenul liniei $firstLineId direcția $firstDirection"
        )

        val arrivalStep = RouteStep(
            type = StepType.SOSIRE,
            stationId = toId,
            stationName = endStationName,
            description = "Coboară la stația $endStationName și îndreaptă-te spre ieșire."
        )

        val finalSteps = listOf(departureStep) + steps.filter { it.type == StepType.SCHIMB || it.type == StepType.CALATORIE } + listOf(arrivalStep)

        // Check if the entire route is accessible
        val routeStations = pathNodes.map { it.stationId }.distinct()
        val isAccessible = routeStations.all { stationMap[it]?.accessibility ?: false }

        return RouteResult(
            type = preference,
            durationSeconds = finalState.realTimeSeconds,
            stations = routeStations,
            transfersCount = finalState.transfers,
            steps = finalSteps,
            isAccessible = isAccessible
        )
    }

    private fun findConnection(fromId: String, toId: String, lineId: String): MetroConnection? {
        return connections.find {
            it.lineId == lineId &&
                    ((it.fromStationId == fromId && it.toStationId == toId) ||
                     (it.fromStationId == toId && it.toStationId == fromId))
        }
    }

    private fun determineDirection(fromId: String, toId: String, line: MetroLine): String {
        val fromIndex = line.stations.indexOf(fromId)
        val toIndex = line.stations.indexOf(toId)
        return if (fromIndex < toIndex) {
            line.directionB
        } else {
            line.directionA
        }
    }

    private fun calculateRideTime(fromId: String, toId: String, lineId: String): Int {
        val line = lineMap[lineId] ?: return 120
        val fromIndex = line.stations.indexOf(fromId)
        val toIndex = line.stations.indexOf(toId)
        if (fromIndex == -1 || toIndex == -1) return 120

        val startIndex = minOf(fromIndex, toIndex)
        val endIndex = maxOf(fromIndex, toIndex)

        var totalTime = 0
        for (i in startIndex until endIndex) {
            val sA = line.stations[i]
            val sB = line.stations[i + 1]
            totalTime += findConnection(sA, sB, lineId)?.travelTimeSeconds ?: 120
        }
        return totalTime
    }
}
