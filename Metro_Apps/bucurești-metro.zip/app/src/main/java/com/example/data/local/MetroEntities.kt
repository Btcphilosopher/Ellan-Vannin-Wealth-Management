package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorite_stations")
data class FavoriteStation(
    @PrimaryKey val stationId: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recent_searches")
data class RecentSearch(
    @PrimaryKey val query: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "purchased_tickets")
data class PurchasedTicket(
    @PrimaryKey val id: String,
    val name: String,
    val price: Double,
    val currency: String,
    val validityMinutes: Int,
    val validityHours: Int,
    val status: String, // DRAFT, PROCESSING, PAID_DEMO, ACTIVE, EXPIRED, CANCELLED
    val activatedAt: Long = 0L,
    val expiredAt: Long = 0L,
    val qrCode: String,
    val referenceNumber: String,
    val isDemo: Boolean = true
)

@Entity(tableName = "completed_journeys")
data class CompletedJourney(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val fromStationId: String,
    val fromStationName: String,
    val toStationId: String,
    val toStationName: String,
    val durationSeconds: Int,
    val timestamp: Long = System.currentTimeMillis()
)
