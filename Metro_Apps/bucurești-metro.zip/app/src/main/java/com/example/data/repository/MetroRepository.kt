package com.example.data.repository

import android.content.Context
import com.example.core.model.*
import com.example.data.local.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.IOException

class MetroRepository(
    private val context: Context,
    private val metroDao: MetroDao
) {
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    // Loaded caches
    private var cachedStations: List<MetroStation> = emptyList()
    private var cachedLines: List<MetroLine> = emptyList()
    private var cachedConnections: List<MetroConnection> = emptyList()
    private var cachedInterchanges: List<InterchangeStation> = emptyList()
    private var cachedExits: List<StationExit> = emptyList()
    private var cachedFacilities: List<StationFacility> = emptyList()
    private var cachedAlerts: List<ServiceIncident> = emptyList()
    private var cachedFareProducts: List<FareProduct> = emptyList()

    suspend fun initialize() = withContext(Dispatchers.IO) {
        try {
            cachedStations = loadListFromAsset("data/metro_stations.json", MetroStation::class.java)
            cachedLines = loadListFromAsset("data/metro_lines.json", MetroLine::class.java)
            cachedConnections = loadListFromAsset("data/metro_connections.json", MetroConnection::class.java)
            cachedInterchanges = loadListFromAsset("data/interchange_stations.json", InterchangeStation::class.java)
            cachedExits = loadListFromAsset("data/station_exits.json", StationExit::class.java)
            cachedFacilities = loadListFromAsset("data/station_facilities.json", StationFacility::class.java)
            cachedAlerts = loadListFromAsset("data/service_alerts.json", ServiceIncident::class.java)
            cachedFareProducts = loadListFromAsset("data/fare_products.json", FareProduct::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun <T> loadListFromAsset(fileName: String, clazz: Class<T>): List<T> {
        return try {
            val jsonString = context.assets.open(fileName).bufferedReader().use { it.readText() }
            val listType = Types.newParameterizedType(List::class.java, clazz)
            val adapter = moshi.adapter<List<T>>(listType)
            adapter.fromJson(jsonString) ?: emptyList()
        } catch (e: IOException) {
            e.printStackTrace()
            emptyList()
        }
    }

    // Static Data Getters
    fun getStations(): List<MetroStation> = cachedStations
    fun getLines(): List<MetroLine> = cachedLines
    fun getConnections(): List<MetroConnection> = cachedConnections
    fun getInterchanges(): List<InterchangeStation> = cachedInterchanges
    fun getExits(): List<StationExit> = cachedExits
    fun getFacilities(): List<StationFacility> = cachedFacilities
    fun getAlerts(): List<ServiceIncident> = cachedAlerts
    fun getFareProducts(): List<FareProduct> = cachedFareProducts

    fun getStationById(id: String): MetroStation? = cachedStations.find { it.id == id }
    fun getLineById(id: String): MetroLine? = cachedLines.find { it.id == id }

    // Room Database Operations (delegated to DAO)
    val favoriteStations: Flow<List<FavoriteStation>> = metroDao.getFavoriteStations()
    val recentSearches: Flow<List<RecentSearch>> = metroDao.getRecentSearches()
    val purchasedTickets: Flow<List<PurchasedTicket>> = metroDao.getPurchasedTickets()
    val completedJourneys: Flow<List<CompletedJourney>> = metroDao.getCompletedJourneys()

    suspend fun toggleFavorite(stationId: String) {
        val isFav = metroDao.isFavorite(stationId)
        if (isFav) {
            metroDao.deleteFavorite(FavoriteStation(stationId))
        } else {
            metroDao.insertFavorite(FavoriteStation(stationId))
        }
    }

    suspend fun isFavorite(stationId: String): Boolean {
        return metroDao.isFavorite(stationId)
    }

    suspend fun addRecentSearch(query: String) {
        if (query.isNotBlank()) {
            metroDao.insertRecentSearch(RecentSearch(query = query, timestamp = System.currentTimeMillis()))
        }
    }

    suspend fun deleteRecentSearch(query: String) {
        metroDao.deleteRecentSearch(query)
    }

    suspend fun clearRecentSearches() {
        metroDao.clearRecentSearches()
    }

    suspend fun purchaseTicket(ticket: PurchasedTicket) {
        metroDao.insertTicket(ticket)
    }

    suspend fun getTicketById(ticketId: String): PurchasedTicket? {
        return metroDao.getTicketById(ticketId)
    }

    suspend fun updateTicketStatus(ticketId: String, status: String, activatedAt: Long, expiredAt: Long) {
        metroDao.updateTicketStatus(ticketId, status, activatedAt, expiredAt)
    }

    suspend fun addCompletedJourney(journey: CompletedJourney) {
        metroDao.insertCompletedJourney(journey)
    }
}
