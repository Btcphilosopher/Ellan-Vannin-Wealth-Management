package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = DarkConcretePrimary,
    onPrimary = DarkConcreteOnPrimary,
    secondary = ConcreteSecondary,
    background = DarkConcreteBackground,
    surface = DarkConcreteSurface,
    onBackground = DarkConcreteOnSurface,
    onSurface = DarkConcreteOnSurface,
    surfaceVariant = GraphiteDark
)

private val LightColorScheme = lightColorScheme(
    primary = ConcretePrimary,
    onPrimary = ConcreteOnPrimary,
    secondary = ConcreteSecondary,
    background = ConcreteBackground,
    surface = ConcreteSurface,
    onBackground = ConcreteOnSurface,
    onSurface = ConcreteOnSurface,
    surfaceVariant = ConcreteGray
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Disable dynamic colors to enforce the beautiful București Brutalist infrastructure branding
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
