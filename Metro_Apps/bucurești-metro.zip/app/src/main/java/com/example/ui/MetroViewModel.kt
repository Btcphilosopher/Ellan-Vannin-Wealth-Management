package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.*
import com.example.core.routing.*
import com.example.core.simulation.MetroSimulator
import com.example.data.local.*
import com.example.data.repository.MetroRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MetroViewModel(application: Application) : AndroidViewModel(application) {

    private val database = MetroDatabase.getDatabase(application)
    private val repository = MetroRepository(application, database.metroDao())

    // UI state for initialization
    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized.asStateFlow()

    // Current navigation screen state
    // "ACASA", "HARTA", "TRASEE", "BILETE", "MAI_MULT", "DETALII_STATIE", "DETALII_TRASEU", "MOD_CALATORIE", "STARE_RETEA", "MOD_DEZVOLTATOR"
    private val _currentScreen = MutableStateFlow("ACASA")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    // Screen back stack
    private val screenHistory = mutableListOf<String>()

    // Current selected item details
    private val _selectedStationId = MutableStateFlow<String?>(null)
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    private val _selectedLineId = MutableStateFlow<String?>(null)
    val selectedLineId: StateFlow<String?> = _selectedLineId.asStateFlow()

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Route fields
    private val _routeFromId = MutableStateFlow<String?>("piata_unirii")
    val routeFromId: StateFlow<String?> = _routeFromId.asStateFlow()

    private val _routeToId = MutableStateFlow<String?>("pipera")
    val routeToId: StateFlow<String?> = _routeToId.asStateFlow()

    private val _routePreference = MutableStateFlow(RoutePreference.CEL_MAI_RAPID)
    val routePreference: StateFlow<RoutePreference> = _routePreference.asStateFlow()

    private val _calculatedRoute = MutableStateFlow<RouteResult?>(null)
    val calculatedRoute: StateFlow<RouteResult?> = _calculatedRoute.asStateFlow()

    // Active journey state (Modul de Călătorie)
    private val _activeJourney = MutableStateFlow<ActiveJourneyState?>(null)
    val activeJourney: StateFlow<ActiveJourneyState?> = _activeJourney.asStateFlow()

    // Ticket Purchase Flow
    private val _selectedFareProductId = MutableStateFlow<String?>(null)
    val selectedFareProductId: StateFlow<String?> = _selectedFareProductId.asStateFlow()

    private val _purchaseStatus = MutableStateFlow("DRAFT") // DRAFT, PROCESSING, PAID_DEMO, ACTIVE
    val purchaseStatus: StateFlow<String> = _purchaseStatus.asStateFlow()

    private val _activeTicketId = MutableStateFlow<String?>(null)
    val activeTicketId: StateFlow<String?> = _activeTicketId.asStateFlow()

    // Developer mode / Night mode simulator state
    private val _isNightMode = MutableStateFlow(false)
    val isNightMode: StateFlow<Boolean> = _isNightMode.asStateFlow()

    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    // Simulator reference
    private lateinit var simulator: MetroSimulator
    private lateinit var router: MetroRouter

    // Flow integration for UI
    val favoriteStations: StateFlow<List<FavoriteStation>> = repository.favoriteStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentSearches: StateFlow<List<RecentSearch>> = repository.recentSearches
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchasedTickets: StateFlow<List<PurchasedTicket>> = repository.purchasedTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val completedJourneys: StateFlow<List<CompletedJourney>> = repository.completedJourneys
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Simulation flows
    private val _trains = MutableStateFlow<List<MetroTrain>>(emptyList())
    val trains: StateFlow<List<MetroTrain>> = _trains.asStateFlow()

    private val _simMultiplier = MutableStateFlow(1)
    val simMultiplier: StateFlow<Int> = _simMultiplier.asStateFlow()

    private val _simIsPaused = MutableStateFlow(false)
    val simIsPaused: StateFlow<Boolean> = _simIsPaused.asStateFlow()

    val simEvents = MutableStateFlow<List<String>>(emptyList())

    // Filtered Stations (Search Logic)
    val filteredStations: StateFlow<List<MetroStation>> = combine(_searchQuery, favoriteStations) { query, favorites ->
        val stationsList = repository.getStations()
        if (query.isBlank()) {
            stationsList
        } else {
            val normalizedQuery = query.normalizeRomanian()
            stationsList.filter { station ->
                station.name.normalizeRomanian().contains(normalizedQuery) ||
                        station.lines.any { it.normalizeRomanian().contains(normalizedQuery) } ||
                        (station.nearbyLandmarks?.any { it.normalizeRomanian().contains(normalizedQuery) } == true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.initialize()
            router = MetroRouter(
                stations = repository.getStations(),
                lines = repository.getLines(),
                connections = repository.getConnections(),
                interchanges = repository.getInterchanges()
            )
            simulator = MetroSimulator(repository.getLines()) { fromId, toId, lineId ->
                repository.getConnections().find {
                    it.lineId == lineId &&
                            ((it.fromStationId == fromId && it.toStationId == toId) ||
                             (it.fromStationId == toId && it.toStationId == fromId))
                }?.travelTimeSeconds ?: 120
            }
            simulator.start()

            // Observe simulator updates
            launch {
                simulator.trains.collect { _trains.value = it }
            }
            launch {
                simulator.simTimeMultiplier.collect { _simMultiplier.value = it }
            }
            launch {
                simulator.isPaused.collect { _simIsPaused.value = it }
            }
            launch {
                simulator.events.collect { simEvents.value = it }
            }

            // Route default calculated
            recalculateRoute()

            // Active journey tick link to simulator tick
            launch {
                trains.collect {
                    val journey = _activeJourney.value
                    if (journey != null && !simIsPaused.value) {
                        advanceActiveJourney(simMultiplier.value)
                    }
                }
            }

            _isInitialized.value = true
        }
    }

    // Navigation Backstack
    fun navigateTo(screen: String) {
        if (_currentScreen.value != screen) {
            screenHistory.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun goBack() {
        if (screenHistory.isNotEmpty()) {
            _currentScreen.value = screenHistory.removeAt(screenHistory.size - 1)
        } else {
            _currentScreen.value = "ACASA"
        }
    }

    // Station and Line Selecting
    fun selectStation(id: String) {
        _selectedStationId.value = id
        navigateTo("DETALII_STATIE")
    }

    fun selectLine(id: String) {
        _selectedLineId.value = id
    }

    // Favorites & Recent Searches
    fun toggleFavorite(stationId: String) {
        viewModelScope.launch {
            repository.toggleFavorite(stationId)
        }
    }

    fun searchFor(query: String) {
        _searchQuery.value = query
        if (query.isNotBlank()) {
            viewModelScope.launch {
                repository.addRecentSearch(query)
            }
        }
    }

    fun clearSearchQuery() {
        _searchQuery.value = ""
    }

    fun deleteRecentSearch(query: String) {
        viewModelScope.launch {
            repository.deleteRecentSearch(query)
        }
    }

    fun clearRecentSearches() {
        viewModelScope.launch {
            repository.clearRecentSearches()
        }
    }

    // Routing Logic
    fun setRouteFrom(id: String?) {
        _routeFromId.value = id
        recalculateRoute()
    }

    fun setRouteTo(id: String?) {
        _routeToId.value = id
        recalculateRoute()
    }

    fun swapRouteEndpoints() {
        val temp = _routeFromId.value
        _routeFromId.value = _routeToId.value
        _routeToId.value = temp
        recalculateRoute()
    }

    fun setRoutePreference(pref: RoutePreference) {
        _routePreference.value = pref
        recalculateRoute()
    }

    fun recalculateRoute() {
        val from = _routeFromId.value
        val to = _routeToId.value
        if (from != null && to != null) {
            _calculatedRoute.value = router.calculateRoute(from, to, _routePreference.value)
        } else {
            _calculatedRoute.value = null
        }
    }

    // Active Journey (Simulating traveler)
    fun startActiveJourney(route: RouteResult) {
        val firstStationId = route.stations.first()
        _activeJourney.value = ActiveJourneyState(
            route = route,
            currentStationIndex = 0,
            secondsToNextStation = 0,
            status = "IMBARCARE", // IMBARCARE, DEPLASARE, SOSIT
            completed = false
        )
        navigateTo("MOD_CALATORIE")
        simEvents.value = listOf("[Călătorie] Călătoria a început de la ${repository.getStationById(firstStationId)?.name}") + simEvents.value
    }

    fun cancelActiveJourney() {
        _activeJourney.value = null
        navigateTo("ACASA")
    }

    private fun advanceActiveJourney(multiplier: Int) {
        val journey = _activeJourney.value ?: return
        if (journey.completed) return

        val route = journey.route
        val currentIndex = journey.currentStationIndex
        val currentStationId = route.stations[currentIndex]

        if (currentIndex >= route.stations.size - 1) {
            // Arrived at final destination!
            _activeJourney.value = journey.copy(
                status = "SOSIT",
                completed = true
            )
            viewModelScope.launch {
                repository.addCompletedJourney(
                    CompletedJourney(
                        fromStationId = route.stations.first(),
                        fromStationName = repository.getStationById(route.stations.first())?.name ?: "",
                        toStationId = route.stations.last(),
                        toStationName = repository.getStationById(route.stations.last())?.name ?: "",
                        durationSeconds = route.durationSeconds
                    )
                )
            }
            return
        }

        val nextStationId = route.stations[currentIndex + 1]

        // Find standard connection time
        // Since Dijkstra gives a list of stations, we find connection on active lines
        val connTime = repository.getConnections().find {
            ((it.fromStationId == currentStationId && it.toStationId == nextStationId) ||
             (it.fromStationId == nextStationId && it.toStationId == currentStationId))
        }?.travelTimeSeconds ?: 120

        var remainingSeconds = journey.secondsToNextStation - multiplier
        if (remainingSeconds <= 0) {
            // Arrived at next station!
            val nextIndex = currentIndex + 1
            val nextStation = repository.getStationById(route.stations[nextIndex])?.name ?: ""
            _activeJourney.value = journey.copy(
                currentStationIndex = nextIndex,
                secondsToNextStation = connTime,
                status = if (nextIndex == route.stations.size - 1) "SOSIT" else "IMBARCARE"
            )
            simEvents.value = listOf("[Călătorie] Ai sosit în stația $nextStation") + simEvents.value
        } else {
            _activeJourney.value = journey.copy(
                secondsToNextStation = remainingSeconds,
                status = "DEPLASARE"
            )
        }
    }

    // Fare products & Tickets
    fun selectFareProduct(productId: String) {
        _selectedFareProductId.value = productId
        _purchaseStatus.value = "DRAFT"
        navigateTo("BILETE")
    }

    fun startDemoPurchase(productId: String) {
        _selectedFareProductId.value = productId
        _purchaseStatus.value = "PROCESSING"
        viewModelScope.launch {
            // Simulate processing payment for 1.5 seconds
            kotlinx.coroutines.delay(1500)
            val product = repository.getFareProducts().find { it.id == productId }
            if (product != null) {
                val ref = "RO-METRO-${(100000..999999).random()}"
                val ticket = PurchasedTicket(
                    id = UUID.randomUUID().toString(),
                    name = product.name,
                    price = product.price,
                    currency = product.currency,
                    validityMinutes = product.validityMinutes,
                    validityHours = product.validityHours,
                    status = "PAID_DEMO",
                    qrCode = "DEMO-TICKET-CODE-${UUID.randomUUID().toString().take(8).uppercase()}",
                    referenceNumber = ref
                )
                repository.purchaseTicket(ticket)
                _activeTicketId.value = ticket.id
                _purchaseStatus.value = "ACTIVE"
                simEvents.value = listOf("[Bilete] Bilet achiziționat demonstrativ cu succes! Cod ref: $ref") + simEvents.value
            }
        }
    }

    fun activateTicket(ticketId: String) {
        viewModelScope.launch {
            val ticket = repository.getTicketById(ticketId)
            if (ticket != null) {
                val now = System.currentTimeMillis()
                val validityMs = if (ticket.validityMinutes > 0) {
                    ticket.validityMinutes * 60 * 1000L
                } else {
                    ticket.validityHours * 60 * 60 * 1000L
                }
                repository.updateTicketStatus(ticketId, "ACTIVE", now, now + validityMs)
                _activeTicketId.value = ticketId
                simEvents.value = listOf("[Bilete] Biletul ${ticket.referenceNumber} a fost activat!") + simEvents.value
            }
        }
    }

    // Night Mode & Offline Mode toggles
    fun toggleNightMode() {
        _isNightMode.value = !_isNightMode.value
    }

    fun toggleOfflineMode() {
        _isOfflineMode.value = !_isOfflineMode.value
    }

    // Simulator Multipliers & incidents
    fun setSimulatorSpeed(multiplier: Int) {
        simulator.setMultiplier(multiplier)
    }

    fun toggleSimulatorPause() {
        simulator.togglePause()
    }

    fun triggerTrainIncident(lineId: String, stationId: String) {
        simulator.generateIncident(lineId, stationId)
    }

    fun resolveTrainIncidents() {
        simulator.resolveIncidents()
    }

    // Static access helper for repository
    fun getStaticStations(): List<MetroStation> = repository.getStations()
    fun getStaticLines(): List<MetroLine> = repository.getLines()
    fun getStaticAlerts(): List<ServiceIncident> = repository.getAlerts()
    fun getStaticFareProducts(): List<FareProduct> = repository.getFareProducts()
    fun getStaticExitsForStation(stationId: String): List<StationExit> = repository.getExits().filter { it.stationId == stationId }
    fun getStaticFacilityForStation(stationId: String): StationFacility? = repository.getFacilities().find { it.stationId == stationId }

    // Text normalization helper
    private fun String.normalizeRomanian(): String {
        return this.lowercase()
            .replace("ă", "a")
            .replace("â", "a")
            .replace("î", "i")
            .replace("ș", "s")
            .replace("ț", "t")
    }
}

// Custom data holder for active simulated journey progress
data class ActiveJourneyState(
    val route: RouteResult,
    val currentStationIndex: Int,
    val secondsToNextStation: Int,
    val status: String, // IMBARCARE, DEPLASARE, SOSIT
    val completed: Boolean
)
