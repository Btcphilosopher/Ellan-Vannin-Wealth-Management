package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Brutalist Concrete & Graphite theme colors
val LightWarmWhite = Color(0xFFFAF9F6)
val ConcreteGray = Color(0xFFE2DFDA)
val GraphiteDark = Color(0xFF1E1E1E)
val SoftBlack = Color(0xFF121212)
val SoftWhite = Color(0xFFFFFFFF)

// Metro Lines Colors
val MetroRed = Color(0xFFD32F2F)      // M3
val MetroYellow = Color(0xFFFBC02D)   // M1
val MetroBlue = Color(0xFF1976D2)     // M2
val MetroGreen = Color(0xFF388E3C)    // M4
val MetroOrange = Color(0xFFF57C00)   // M5
val MetroAmber = Color(0xFFFFA000)    // Alert WARNING
val MetroGray = Color(0xFF757575)

// Material 3 semantic palette
val ConcretePrimary = Color(0xFF1E1E1E)     // Graphite
val ConcreteOnPrimary = Color(0xFFFAF9F6)   // Warm white
val ConcreteSecondary = Color(0xFF757575)   // Slate gray
val ConcreteBackground = Color(0xFFFAF9F6) // Warm Concrete Base
val ConcreteSurface = Color(0xFFEFECE6)    // Tonal surface
val ConcreteOnSurface = Color(0xFF121212)  // Soft Black text

val DarkConcretePrimary = Color(0xFFFAF9F6)
val DarkConcreteOnPrimary = Color(0xFF121212)
val DarkConcreteBackground = Color(0xFF121212)
val DarkConcreteSurface = Color(0xFF1E1E1E)
val DarkConcreteOnSurface = Color(0xFFFAF9F6)
