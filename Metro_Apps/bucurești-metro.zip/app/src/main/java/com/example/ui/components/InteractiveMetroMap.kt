package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.core.model.MetroLine
import com.example.core.model.MetroStation
import kotlin.math.sqrt

@Composable
fun InteractiveMetroMap(
    stations: List<MetroStation>,
    lines: List<MetroLine>,
    selectedStationId: String?,
    highlightedStations: List<String> = emptyList(),
    onStationSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (stations.isEmpty() || lines.isEmpty()) {
        Box(modifier = modifier)
        return
    }

    // Min and max coordinates for projection
    val minLat = 44.360
    val maxLat = 44.484
    val minLon = 26.009
    val maxLon = 26.176

    val latRange = maxLat - minLat
    val lonRange = maxLon - minLon

    // Interactive panning / zoom states
    var scale by remember { mutableStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    // Convert hex string color to Compose Color
    fun getLineColor(lineId: String): Color {
        val line = lines.find { it.id == lineId } ?: return Color.Gray
        return try {
            Color(android.graphics.Color.parseColor(line.color))
        } catch (e: Exception) {
            Color.Gray
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFEFECE6)) // Concrete Warm base
            .pointerInput(Unit) {
                detectTapGestures { tapOffset ->
                    // Reverse the transform to find the actual clicked coordinates on the map
                    val projectedTapX = (tapOffset.x - offset.x) / scale
                    val projectedTapY = (tapOffset.y - offset.y) / scale

                    // Find nearest station
                    var nearestStation: MetroStation? = null
                    var minDistance = Double.MAX_VALUE

                    val width = size.width
                    val height = size.height

                    for (station in stations) {
                        // Project station coordinates
                        val normX = (station.longitude - minLon) / lonRange
                        val normY = 1.0 - (station.latitude - minLat) / latRange

                        val paddingX = width * 0.1f
                        val paddingY = height * 0.1f
                        val plotX = paddingX + normX * (width * 0.8f)
                        val plotY = paddingY + normY * (height * 0.8f)

                        val dx = projectedTapX - plotX
                        val dy = projectedTapY - plotY
                        val distance = sqrt(dx * dx + dy * dy)

                        if (distance < minDistance) {
                            minDistance = distance
                            nearestStation = station
                        }
                    }

                    // If click is within 35dp radius, select it
                    if (minDistance < 35.0f && nearestStation != null) {
                        onStationSelect(nearestStation.id)
                    }
                }
            }
    ) {
        val width = size.width
        val height = size.height

        withTransform({
            translate(offset.x, offset.y)
            scale(scale, scale)
        }) {
            // 1. Draw connections (lines)
            for (line in lines) {
                val lineColor = getLineColor(line.id)
                val lineStations = line.stations

                for (i in 0 until lineStations.size - 1) {
                    val sIdA = lineStations[i]
                    val sIdB = lineStations[i + 1]

                    val sA = stations.find { it.id == sIdA }
                    val sB = stations.find { it.id == sIdB }

                    if (sA != null && sB != null) {
                        // Project coordinates
                        val normXA = (sA.longitude - minLon) / lonRange
                        val normYA = 1.0 - (sA.latitude - minLat) / latRange
                        val normXB = (sB.longitude - minLon) / lonRange
                        val normYB = 1.0 - (sB.latitude - minLat) / latRange

                        val paddingX = width * 0.1f
                        val paddingY = height * 0.1f
                        val plotXA = paddingX + normXA * (width * 0.8f)
                        val plotYA = paddingY + normYA * (height * 0.8f)
                        val plotXB = paddingX + normXB * (width * 0.8f)
                        val plotYB = paddingY + normYB * (height * 0.8f)

                        // Highlight route path if necessary
                        val isSegmentHighlighted = highlightedStations.contains(sIdA) && highlightedStations.contains(sIdB)
                        val strokeWidth = if (isSegmentHighlighted) 8.dp.toPx() else 4.dp.toPx()
                        val color = if (highlightedStations.isNotEmpty() && !isSegmentHighlighted) {
                            lineColor.copy(alpha = 0.15f)
                        } else {
                            lineColor
                        }

                        drawLine(
                            color = color,
                            start = Offset(plotXA.toFloat(), plotYA.toFloat()),
                            end = Offset(plotXB.toFloat(), plotYB.toFloat()),
                            strokeWidth = strokeWidth
                        )
                    }
                }
            }

            // 2. Draw stations (nodes)
            for (station in stations) {
                val normX = (station.longitude - minLon) / lonRange
                val normY = 1.0 - (station.latitude - minLat) / latRange

                val paddingX = width * 0.1f
                val paddingY = height * 0.1f
                val plotX = paddingX + normX * (width * 0.8f)
                val plotY = paddingY + normY * (height * 0.8f)

                val isSelected = station.id == selectedStationId
                val isHighlighted = highlightedStations.isEmpty() || highlightedStations.contains(station.id)

                val primaryLineColor = if (station.lines.isNotEmpty()) getLineColor(station.lines.first()) else Color.Gray
                val nodeColor = if (isHighlighted) primaryLineColor else primaryLineColor.copy(alpha = 0.2f)

                // Outer node ring / background
                drawCircle(
                    color = if (isSelected) Color(0xFFCC3333) else nodeColor,
                    radius = if (isSelected) 14.dp.toPx() else (if (station.interchange) 11.dp.toPx() else 8.dp.toPx()),
                    center = Offset(plotX.toFloat(), plotY.toFloat())
                )

                // Inner core
                drawCircle(
                    color = if (isHighlighted) Color.White else Color.White.copy(alpha = 0.3f),
                    radius = if (isSelected) 7.dp.toPx() else (if (station.interchange) 6.dp.toPx() else 4.dp.toPx()),
                    center = Offset(plotX.toFloat(), plotY.toFloat())
                )

                // If interchange, draw additional indicator ring
                if (station.interchange) {
                    drawCircle(
                        color = if (isHighlighted) Color.Black else Color.Black.copy(alpha = 0.2f),
                        radius = 11.dp.toPx(),
                        center = Offset(plotX.toFloat(), plotY.toFloat()),
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                }
            }
        }
    }
}
