package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {

    // Favorites
    @Query("SELECT * FROM favorite_stations ORDER BY addedAt DESC")
    fun getFavoriteStations(): Flow<List<FavoriteStation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteStation)

    @Delete
    suspend fun deleteFavorite(favorite: FavoriteStation)

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_stations WHERE stationId = :stationId)")
    suspend fun isFavorite(stationId: String): Boolean

    // Recent Searches
    @Query("SELECT * FROM recent_searches ORDER BY timestamp DESC LIMIT 5")
    fun getRecentSearches(): Flow<List<RecentSearch>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentSearch(search: RecentSearch)

    @Query("DELETE FROM recent_searches WHERE `query` = :query")
    suspend fun deleteRecentSearch(query: String)

    @Query("DELETE FROM recent_searches")
    suspend fun clearRecentSearches()

    // Tickets
    @Query("SELECT * FROM purchased_tickets ORDER BY activatedAt DESC")
    fun getPurchasedTickets(): Flow<List<PurchasedTicket>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: PurchasedTicket)

    @Query("SELECT * FROM purchased_tickets WHERE id = :ticketId")
    suspend fun getTicketById(ticketId: String): PurchasedTicket?

    @Query("UPDATE purchased_tickets SET status = :status, activatedAt = :activatedAt, expiredAt = :expiredAt WHERE id = :ticketId")
    suspend fun updateTicketStatus(ticketId: String, status: String, activatedAt: Long, expiredAt: Long)

    // Completed Journeys
    @Query("SELECT * FROM completed_journeys ORDER BY timestamp DESC")
    fun getCompletedJourneys(): Flow<List<CompletedJourney>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompletedJourney(journey: CompletedJourney)
}
