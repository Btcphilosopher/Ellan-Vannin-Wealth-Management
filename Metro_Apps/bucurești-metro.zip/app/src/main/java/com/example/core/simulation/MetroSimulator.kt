package com.example.core.simulation

import com.example.core.model.MetroLine
import com.example.core.model.MetroTrain
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MetroSimulator(
    private val lines: List<MetroLine>,
    private val travelTimeCalculator: (String, String, String) -> Int // (fromId, toId, lineId) -> seconds
) {
    private val _trains = MutableStateFlow<List<MetroTrain>>(emptyList())
    val trains: StateFlow<List<MetroTrain>> = _trains.asStateFlow()

    private val _simTimeMultiplier = MutableStateFlow(1) // 1x, 10x, 60x
    val simTimeMultiplier: StateFlow<Int> = _simTimeMultiplier.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private var simulationJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    // Log of simulation events
    private val _events = MutableStateFlow<List<String>>(emptyList())
    val events: StateFlow<List<String>> = _events.asStateFlow()

    init {
        initializeTrains()
    }

    private fun logEvent(event: String) {
        val currentList = _events.value
        _events.value = (listOf("[Sim] $event") + currentList).take(30)
    }

    fun start() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            while (true) {
                delay(1000L) // Real-world second tick
                if (!_isPaused.value) {
                    val ticks = _simTimeMultiplier.value
                    updateSimulation(ticks)
                }
            }
        }
        logEvent("Simularea a pornit la viteza ${simTimeMultiplier.value}x")
    }

    fun stop() {
        simulationJob?.cancel()
        simulationJob = null
        logEvent("Simularea a fost oprită")
    }

    fun togglePause() {
        _isPaused.value = !_isPaused.value
        logEvent(if (_isPaused.value) "Simulare pusă pe PAUZĂ" else "Simulare RELUATĂ")
    }

    fun setMultiplier(mult: Int) {
        _simTimeMultiplier.value = mult
        logEvent("Viteza simulării setată la ${mult}x")
    }

    fun generateIncident(lineId: String, stationId: String) {
        val currentList = _trains.value.toMutableList()
        val index = currentList.indexOfFirst { it.lineId == lineId && (it.currentStationId == stationId || it.nextStationId == stationId) }
        if (index != -1) {
            val train = currentList[index]
            currentList[index] = train.copy(
                status = "BLOCAT",
                speed = 0f,
                delaySeconds = train.delaySeconds + 300
            )
            _trains.value = currentList
            logEvent("ALERTĂ: Trenul ${train.id} pe linia $lineId este BLOCAT la stația $stationId!")
        }
    }

    fun resolveIncidents() {
        val currentList = _trains.value.map {
            if (it.status == "BLOCAT") {
                it.copy(status = "IN_DEPLASARE", speed = 50f, delaySeconds = 0)
            } else it
        }
        _trains.value = currentList
        logEvent("Toate incidentele de circulație au fost REZOLVATE")
    }

    private fun initializeTrains() {
        val initialTrains = mutableListOf<MetroTrain>()
        for (line in lines) {
            if (line.stations.size < 2) continue

            // Train A: Heading from terminal A to terminal B
            val startStationIdA = line.stations.first()
            val nextStationIdA = line.stations[1]
            initialTrains.add(
                MetroTrain(
                    id = "Tren-${line.id}-A",
                    lineId = line.id,
                    currentStationId = startStationIdA,
                    nextStationId = nextStationIdA,
                    direction = line.directionB,
                    progress = 0f,
                    speed = 45f,
                    delaySeconds = 0,
                    status = "STATIONAT"
                )
            )

            // Train B: Heading from terminal B to terminal A
            val startStationIdB = line.stations.last()
            val nextStationIdB = line.stations[line.stations.size - 2]
            initialTrains.add(
                MetroTrain(
                    id = "Tren-${line.id}-B",
                    lineId = line.id,
                    currentStationId = startStationIdB,
                    nextStationId = nextStationIdB,
                    direction = line.directionA,
                    progress = 0f,
                    speed = 45f,
                    delaySeconds = 0,
                    status = "STATIONAT"
                )
            )
        }
        _trains.value = initialTrains
    }

    private fun updateSimulation(ticks: Int) {
        val currentList = _trains.value.map { train ->
            if (train.status == "BLOCAT" || train.status == "SCOS_DIN_CIRCULATIE") {
                return@map train
            }

            var status = train.status
            var currentStationId = train.currentStationId
            var nextStationId = train.nextStationId
            var progress = train.progress
            var speed = train.speed
            var direction = train.direction

            val line = lines.find { it.id == train.lineId }
            if (line == null) return@map train

            val totalTravelTime = travelTimeCalculator(currentStationId, nextStationId, train.lineId)

            if (status == "STATIONAT") {
                // Stationed waiting. We model progress as "waiting progress"
                // Let's say a train stations for 20 seconds.
                val waitProgressPerTick = 1.0f / 20.0f
                progress += waitProgressPerTick * ticks

                if (progress >= 1.0f) {
                    // Depart!
                    status = "IN_DEPLASARE"
                    progress = 0.0f
                    speed = 50f
                    logEvent("Trenul ${train.id} a PLECAT din stația ${currentStationId} spre ${nextStationId}")
                }
            } else if (status == "IN_DEPLASARE" || status == "IN_INTARZIERE") {
                // Moving towards next station.
                val travelProgressPerTick = 1.0f / totalTravelTime.toFloat()
                progress += travelProgressPerTick * ticks

                if (progress >= 1.0f) {
                    // Arrived!
                    status = "STATIONAT"
                    progress = 0.0f
                    speed = 0f
                    currentStationId = nextStationId

                    // Find the next destination station on the line
                    val currentIdx = line.stations.indexOf(currentStationId)
                    val stationsList = line.stations

                    if (direction == line.directionB) {
                        if (currentIdx < stationsList.size - 1) {
                            nextStationId = stationsList[currentIdx + 1]
                        } else {
                            // Terminus reached, reverse direction!
                            direction = line.directionA
                            nextStationId = stationsList[stationsList.size - 2]
                            logEvent("Trenul ${train.id} a ajuns la TERMINUS ${currentStationId} și a întors")
                        }
                    } else {
                        if (currentIdx > 0) {
                            nextStationId = stationsList[currentIdx - 1]
                        } else {
                            // Terminus reached, reverse direction!
                            direction = line.directionB
                            nextStationId = stationsList[1]
                            logEvent("Trenul ${train.id} a ajuns la TERMINUS ${currentStationId} și a întors")
                        }
                    }

                    logEvent("Trenul ${train.id} a SOSIT în stația ${currentStationId}")
                }
            }

            train.copy(
                status = status,
                currentStationId = currentStationId,
                nextStationId = nextStationId,
                progress = progress.coerceIn(0f, 1f),
                speed = speed,
                direction = direction
            )
        }
        _trains.value = currentList
    }
}
