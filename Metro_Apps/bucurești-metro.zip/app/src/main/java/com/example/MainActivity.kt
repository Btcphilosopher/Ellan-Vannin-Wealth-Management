package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.DirectionsRun
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.model.*
import com.example.core.routing.*
import com.example.ui.ActiveJourneyState
import com.example.ui.MetroViewModel
import com.example.ui.components.InteractiveMetroMap
import com.example.ui.theme.MyApplicationTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: MetroViewModel = viewModel()
                val isInitialized by viewModel.isInitialized.collectAsState()

                if (!isInitialized) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "BUCUREȘTI",
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "METRO",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.secondary,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 4.sp
                            )
                            Spacer(modifier = Modifier.height(32.dp))
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.primary,
                                strokeWidth = 4.dp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Se încarcă rețeaua subterană...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                } else {
                    MetroAppContainer(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun MetroAppContainer(viewModel: MetroViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isNightMode by viewModel.isNightMode.collectAsState()
    val isOfflineMode by viewModel.isOfflineMode.collectAsState()

    Scaffold(
        topBar = {
            Column {
                // Header panel
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isNightMode) Color(0xFF1C1B1A) else Color(0xFFFAF9F6))
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "BUCUREȘTI",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace,
                                color = if (isNightMode) Color(0xFFFAF9F6) else Color(0xFF1E1E1E)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFCC3333))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "METRO",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                        Text(
                            text = "PROTOTIP NE-OFICIAL",
                            fontSize = 9.sp,
                            color = Color(0xFF757575),
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Offline Mode Indicator
                        if (isOfflineMode) {
                            Box(
                                modifier = Modifier
                                    .padding(end = 8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFCC3333).copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "MOD OFFLINE",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFCC3333)
                                )
                            }
                        }

                        IconButton(onClick = { viewModel.toggleNightMode() }) {
                            Icon(
                                imageVector = if (isNightMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Schimbă modul zi/noapte",
                                tint = if (isNightMode) Color(0xFFFBC02D) else Color(0xFF1E1E1E)
                            )
                        }

                        IconButton(onClick = { viewModel.navigateTo("MOD_DEZVOLTATOR") }) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = "Mod Dezvoltator",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), thickness = 1.dp)
            }
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.navigationBarsPadding(),
                containerColor = if (isNightMode) Color(0xFF121212) else Color(0xFFEFECE6),
                tonalElevation = 8.dp
            ) {
                val screens = listOf(
                    NavigationItem("ACASA", "Acasă", Icons.Default.Home, "nav_home"),
                    NavigationItem("HARTA", "Hartă", Icons.Default.Map, "nav_map"),
                    NavigationItem("TRASEE", "Trasee", Icons.Default.Directions, "nav_routes"),
                    NavigationItem("BILETE", "Bilete", Icons.Default.ConfirmationNumber, "nav_tickets"),
                    NavigationItem("MAI_MULT", "Mai mult", Icons.Default.MoreHoriz, "nav_more")
                )

                screens.forEach { screen ->
                    val isActive = currentScreen == screen.id ||
                            (screen.id == "TRASEE" && currentScreen == "DETALII_TRASEU") ||
                            (screen.id == "TRASEE" && currentScreen == "MOD_CALATORIE") ||
                            (screen.id == "HARTA" && currentScreen == "DETALII_STATIE")

                    NavigationBarItem(
                        selected = isActive,
                        onClick = { viewModel.navigateTo(screen.id) },
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = Color(0xFF1E1E1E),
                            unselectedIconColor = MaterialTheme.colorScheme.secondary,
                            unselectedTextColor = MaterialTheme.colorScheme.secondary
                        ),
                        modifier = Modifier.testTag(screen.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(if (isNightMode) Color(0xFF121212) else Color(0xFFFAF9F6))
        ) {
            when (currentScreen) {
                "ACASA" -> HomeScreen(viewModel)
                "HARTA" -> MapScreen(viewModel)
                "DETALII_STATIE" -> StationDetailScreen(viewModel)
                "TRASEE" -> RoutePlannerScreen(viewModel)
                "DETALII_TRASEU" -> RouteDetailScreen(viewModel)
                "MOD_CALATORIE" -> ActiveJourneyScreen(viewModel)
                "BILETE" -> TicketScreen(viewModel)
                "MAI_MULT" -> MoreScreen(viewModel)
                "MOD_DEZVOLTATOR" -> DeveloperModeScreen(viewModel)
            }
        }
    }
}

data class NavigationItem(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: MetroViewModel) {
    val stations = viewModel.getStaticStations()
    val routeFromId by viewModel.routeFromId.collectAsState()
    val routeToId by viewModel.routeToId.collectAsState()
    val favorites by viewModel.favoriteStations.collectAsState()
    val isNightMode by viewModel.isNightMode.collectAsState()

    var showFromDropdown by remember { mutableStateOf(false) }
    var showToDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Main Banner / Greeting
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                Text(
                    text = "UNDE MERGI?",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Planifică-ți călătoria cu metroul din București",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        item {
            // Routing Search Card (DE LA -> PÂNĂ LA)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFEFECE6)
                ),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // DE LA Selector
                    val currentFromStation = stations.find { it.id == routeFromId }
                    Box {
                        OutlinedTextField(
                            value = currentFromStation?.name ?: "Selectează stația",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("DE LA") },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, "dropdown") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showFromDropdown = true }
                                .testTag("route_from_input"),
                            enabled = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledBorderColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        DropdownMenu(
                            expanded = showFromDropdown,
                            onDismissRequest = { showFromDropdown = false }
                        ) {
                            stations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(station.name) },
                                    onClick = {
                                        viewModel.setRouteFrom(station.id)
                                        showFromDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Swap Button
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(
                            onClick = { viewModel.swapRouteEndpoints() },
                            modifier = Modifier
                                .size(36.dp)
                                .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(18.dp))
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "Inversează destinațiile",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // PÂNĂ LA Selector
                    val currentToStation = stations.find { it.id == routeToId }
                    Box {
                        OutlinedTextField(
                            value = currentToStation?.name ?: "Selectează stația",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("PÂNĂ LA") },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, "dropdown") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showToDropdown = true }
                                .testTag("route_to_input"),
                            enabled = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledBorderColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        DropdownMenu(
                            expanded = showToDropdown,
                            onDismissRequest = { showToDropdown = false }
                        ) {
                            stations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(station.name) },
                                    onClick = {
                                        viewModel.setRouteTo(station.id)
                                        showToDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // CAUTĂ TRASEU Button
                    Button(
                        onClick = { viewModel.navigateTo("TRASEE") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("search_route_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFCC3333)
                        )
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Caută")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CAUTĂ TRASEU",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Favorites Shortcuts
        if (favorites.isNotEmpty()) {
            item {
                Column {
                    Text(
                        text = "STAȚII FAVORITE",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        favorites.forEach { fav ->
                            val station = stations.find { it.id == fav.stationId }
                            if (station != null) {
                                Card(
                                    modifier = Modifier
                                        .clickable { viewModel.selectStation(station.id) }
                                        .widthIn(min = 120.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isNightMode) Color(0xFF262524) else Color(0xFFFFFAFA)
                                    ),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = station.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            station.lines.forEach { lineId ->
                                                val line = viewModel.getStaticLines().find { it.id == lineId }
                                                val lCol = try {
                                                    Color(android.graphics.Color.parseColor(line?.color ?: "#757575"))
                                                } catch (e: Exception) {
                                                    Color.Gray
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .size(20.dp)
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(lCol),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = lineId,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.White
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Starea Rețelei Summary Section
        item {
            Column {
                Text(
                    text = "STAREA REȚELEI",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFFFFCF8)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Display line status summary
                        val lines = viewModel.getStaticLines()
                        val alerts = viewModel.getStaticAlerts()

                        lines.forEach { line ->
                            val lineAlerts = alerts.filter { it.affectedLines.contains(line.id) }
                            val statusText = when {
                                lineAlerts.any { it.severity == "CRITICAL" } -> "ÎNTÂRZIERI MARI"
                                lineAlerts.any { it.severity == "WARNING" } -> "RESTRICȚII"
                                lineAlerts.isNotEmpty() -> "INFORMAȚII"
                                else -> "NORMAL"
                            }
                            val statusColor = when (statusText) {
                                "ÎNTÂRZIERI MARI" -> Color(0xFFCC3333)
                                "RESTRICȚII" -> Color(0xFFFF9900)
                                "INFORMAȚII" -> Color(0xFF0066CC)
                                else -> Color(0xFF009933)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val lineColor = try {
                                        Color(android.graphics.Color.parseColor(line.color))
                                    } catch (e: Exception) {
                                        Color.Gray
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(lineColor),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = line.id,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = line.name,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 14.sp
                                    )
                                }

                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = statusColor.copy(alpha = 0.12f)
                                    )
                                ) {
                                    Text(
                                        text = statusText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = statusColor,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                        Text(
                            text = "DATE DEMONSTRATIVE — Actualizat local",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF757575),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MapScreen(viewModel: MetroViewModel) {
    val stations = viewModel.getStaticStations()
    val lines = viewModel.getStaticLines()
    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val isNightMode by viewModel.isNightMode.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        InteractiveMetroMap(
            stations = stations,
            lines = lines,
            selectedStationId = selectedStationId,
            onStationSelect = { viewModel.selectStation(it) },
            modifier = Modifier.fillMaxSize()
        )

        // Floating Instructions overlay
        Card(
            modifier = Modifier
                .padding(16.dp)
                .align(Alignment.TopCenter),
            colors = CardDefaults.cardColors(
                containerColor = if (isNightMode) Color(0xFF1E1E1E).copy(alpha = 0.9f) else Color.White.copy(alpha = 0.9f)
            )
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = "Tap",
                    tint = Color(0xFFCC3333),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Apasă pe stație pentru detalii subterane",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun StationDetailScreen(viewModel: MetroViewModel) {
    val stations = viewModel.getStaticStations()
    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val favorites by viewModel.favoriteStations.collectAsState()
    val isNightMode by viewModel.isNightMode.collectAsState()

    val station = stations.find { it.id == selectedStationId } ?: return
    val exits = viewModel.getStaticExitsForStation(station.id)
    val facility = viewModel.getStaticFacilityForStation(station.id)
    val isFav = favorites.any { it.stationId == station.id }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Back Navigation and Favorite toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.goBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Înapoi")
            }

            IconButton(onClick = { viewModel.toggleFavorite(station.id) }) {
                Icon(
                    imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "Salvează la favorite",
                    tint = if (isFav) Color(0xFFFBC02D) else MaterialTheme.colorScheme.primary
                )
            }
        }

        // Station Header
        Column {
            Text(
                text = station.name.uppercase(),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LINII:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                station.lines.forEach { lineId ->
                    val line = viewModel.getStaticLines().find { it.id == lineId }
                    val lineColor = try {
                        Color(android.graphics.Color.parseColor(line?.color ?: "#757575"))
                    } catch (e: Exception) {
                        Color.Gray
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(lineColor)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = lineId,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        Divider()

        // Original schematic illustration placeholder
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isNightMode) Color(0xFF262524) else Color(0xFFE2DFDA)
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Domain,
                        contentDescription = "Subground Structure",
                        modifier = Modifier.size(36.dp),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Vedere schematică a stației ${station.name}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "Adâncime estimată: ~14m — Modernist",
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        // PLECĂRI SIMULATE
        Column {
            Text(
                text = "URMĂTOARELE PLECĂRI (SIMULAT)",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFFFFCF8)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    station.lines.forEach { lineId ->
                        val line = viewModel.getStaticLines().find { it.id == lineId }
                        if (line != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val lCol = try {
                                        Color(android.graphics.Color.parseColor(line.color))
                                    } catch (e: Exception) {
                                        Color.Gray
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(lCol),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = line.id,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = "Direcția: ${line.directionB}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF009933).copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "3 min", fontSize = 11.sp, color = Color(0xFF009933), fontWeight = FontWeight.Bold)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF757575).copy(alpha = 0.1f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "8 min", fontSize = 11.sp, color = Color(0xFF757575))
                                    }
                                }
                            }
                        }
                    }
                    Text(
                        text = "PLECĂRI ESTIMATIVE CONFORM ORARULUI DE WEEKEND / ZI",
                        fontSize = 9.sp,
                        color = Color(0xFF757575),
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // ACCESSIBILITY & FACILITIES
        Column {
            Text(
                text = "FACILITĂȚI ȘI ACCESIBILITATE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFFFFCF8)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Accessibility
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (station.accessibility) Icons.Default.Accessible else Icons.Default.NotAccessible,
                            contentDescription = "Accesibil",
                            tint = if (station.accessibility) Color(0xFF009933) else Color(0xFFCC3333)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (station.accessibility) "Stație complet accesibilă persoanelor cu dizabilități" else "Stație cu accesibilitate limitată",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    if (facility != null) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            FacilityPill(label = "Lifte: ${facility.lifts}", icon = Icons.Default.Elevator)
                            FacilityPill(label = "Scări rulante: ${facility.escalators}", icon = Icons.Default.CompareArrows)
                            FacilityPill(label = "Automate: ${facility.ticketMachines}", icon = Icons.Default.LocalActivity)
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            if (facility.publicToilets) FacilityBoolPill(label = "Toaletă Publică")
                            if (facility.wifiAvailable) FacilityBoolPill(label = "Wi-Fi Gratuit")
                        }
                    }
                }
            }
        }

        // EXITS
        if (exits.isNotEmpty()) {
            Column {
                Text(
                    text = "IEȘIRI ȘI PUNCTE DE ORIENTARE",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                exits.forEach { exit ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isNightMode) Color(0xFF262524) else Color(0xFFFFFCF8)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = exit.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = exit.description,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            if (!exit.nearbyLandmarks.isNullOrEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    exit.nearbyLandmarks.forEach { landmark ->
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(text = landmark, fontSize = 9.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FacilityPill(label: String, icon: ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.04f))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, fontSize = 11.sp)
    }
}

@Composable
fun FacilityBoolPill(label: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF009933).copy(alpha = 0.08f))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(text = label, fontSize = 11.sp, color = Color(0xFF009933), fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutePlannerScreen(viewModel: MetroViewModel) {
    val stations = viewModel.getStaticStations()
    val routeFromId by viewModel.routeFromId.collectAsState()
    val routeToId by viewModel.routeToId.collectAsState()
    val pref by viewModel.routePreference.collectAsState()
    val routeResult by viewModel.calculatedRoute.collectAsState()
    val isNightMode by viewModel.isNightMode.collectAsState()

    var showFromDropdown by remember { mutableStateOf(false) }
    var showToDropdown by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "PLANIFICATOR RUTE",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.primary
        )

        // Selectors Panel
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFEFECE6)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // FROM Selector
                val currentFromStation = stations.find { it.id == routeFromId }
                Box {
                    OutlinedTextField(
                        value = currentFromStation?.name ?: "Selectează stația",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("PLECARE") },
                        trailingIcon = { Icon(Icons.Default.ArrowDropDown, "dropdown") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showFromDropdown = true },
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledBorderColor = MaterialTheme.colorScheme.primary
                        )
                    )
                    DropdownMenu(
                        expanded = showFromDropdown,
                        onDismissRequest = { showFromDropdown = false }
                    ) {
                        stations.forEach { station ->
                            DropdownMenuItem(
                                text = { Text(station.name) },
                                onClick = {
                                    viewModel.setRouteFrom(station.id)
                                    showFromDropdown = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // TO Selector
                val currentToStation = stations.find { it.id == routeToId }
                Box {
                    OutlinedTextField(
                        value = currentToStation?.name ?: "Selectează stația",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("SOSIRE") },
                        trailingIcon = { Icon(Icons.Default.ArrowDropDown, "dropdown") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showToDropdown = true },
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledBorderColor = MaterialTheme.colorScheme.primary
                        )
                    )
                    DropdownMenu(
                        expanded = showToDropdown,
                        onDismissRequest = { showToDropdown = false }
                    ) {
                        stations.forEach { station ->
                            DropdownMenuItem(
                                text = { Text(station.name) },
                                onClick = {
                                    viewModel.setRouteTo(station.id)
                                    showToDropdown = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Routing Preferences Pill selector
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            RoutePreferencePill(
                label = "Cel mai rapid",
                isActive = pref == RoutePreference.CEL_MAI_RAPID,
                onClick = { viewModel.setRoutePreference(RoutePreference.CEL_MAI_RAPID) }
            )
            RoutePreferencePill(
                label = "Puține schimbări",
                isActive = pref == RoutePreference.CELE_MAI_PUTINE_SCHIMBARI,
                onClick = { viewModel.setRoutePreference(RoutePreference.CELE_MAI_PUTINE_SCHIMBARI) }
            )
            RoutePreferencePill(
                label = "Cel mai simplu",
                isActive = pref == RoutePreference.CEL_MAI_SIMPLU,
                onClick = { viewModel.setRoutePreference(RoutePreference.CEL_MAI_SIMPLU) }
            )
            RoutePreferencePill(
                label = "Accesibil",
                isActive = pref == RoutePreference.ACCESIBIL,
                onClick = { viewModel.setRoutePreference(RoutePreference.ACCESIBIL) }
            )
        }

        Divider()

        // Results Section
        if (routeResult != null) {
            val result = routeResult!!
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isNightMode) Color(0xFF262524) else Color(0xFFFFFCF8)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo("DETALII_TRASEU") }
                    .testTag("route_result_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            val minutes = result.durationSeconds / 60
                            Text(
                                text = "$minutes MIN",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFCC3333)
                            )
                            Text(
                                text = "Timp total estimat",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (result.transfersCount == 0) Color(0xFF009933).copy(alpha = 0.1f) else Color(0xFF0066CC).copy(alpha = 0.1f)
                            )
                        ) {
                            Text(
                                text = if (result.transfersCount == 0) "Direct" else "${result.transfersCount} Schimbări",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (result.transfersCount == 0) Color(0xFF009933) else Color(0xFF0066CC),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Draw line flow indicators
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // First Station name
                        Text(
                            text = stations.find { it.id == routeFromId }?.name ?: "",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Icon(Icons.Default.ChevronRight, contentDescription = "Spre", modifier = Modifier.size(16.dp))

                        // Draw intermediate transfers
                        result.steps.filter { it.type == StepType.CALATORIE }.forEach { step ->
                            val line = viewModel.getStaticLines().find { it.id == step.lineId }
                            val lCol = try {
                                Color(android.graphics.Color.parseColor(line?.color ?: "#757575"))
                            } catch (e: Exception) {
                                Color.Gray
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(lCol)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = step.lineId ?: "",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = "Spre", modifier = Modifier.size(16.dp))
                        }

                        // Last Station name
                        Text(
                            text = stations.find { it.id == routeToId }?.name ?: "",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (result.isAccessible) Icons.Default.Accessible else Icons.Default.NotAccessible,
                                contentDescription = "Accesibilitate",
                                tint = if (result.isAccessible) Color(0xFF009933) else Color(0xFF757575),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (result.isAccessible) "Traseu complet accesibil" else "Limitat",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }

                        Text(
                            text = "Apasă pentru detalii traseu →",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFCC3333)
                        )
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.DirectionsSubway,
                        contentDescription = "Subway",
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Introduceți destinațiile de plecare și sosire",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
    }
}

@Composable
fun RoutePreferencePill(label: String, isActive: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isActive) Color(0xFF1E1E1E) else Color(0xFFEFECE6))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (isActive) Color.White else Color(0xFF1E1E1E)
        )
    }
}

@Composable
fun RouteDetailScreen(viewModel: MetroViewModel) {
    val routeResult by viewModel.calculatedRoute.collectAsState()
    val isNightMode by viewModel.isNightMode.collectAsState()

    val result = routeResult ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Bar back
        IconButton(onClick = { viewModel.goBack() }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Înapoi")
        }

        Text(
            text = "CĂLĂTORIA TA DETALIATĂ",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.primary
        )

        // General Info Header card
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFEFECE6)
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DURATA ESTIMATĂ:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "${result.durationSeconds / 60} minute",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SCHIMBĂRI LINIE:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = if (result.transfersCount == 0) "Direct (fără schimb)" else "${result.transfersCount} Schimbări",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Horizontal visual step-by-step connection nodes
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            result.steps.forEachIndexed { idx, step ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    // Vertical Line indicator
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(32.dp)
                    ) {
                        val indicatorColor = when (step.type) {
                            StepType.PLECARE -> Color(0xFFCC3333)
                            StepType.SOSIRE -> Color(0xFF009933)
                            StepType.SCHIMB -> Color(0xFFFFA000)
                            StepType.CALATORIE -> {
                                val line = viewModel.getStaticLines().find { it.id == step.lineId }
                                try {
                                    Color(android.graphics.Color.parseColor(line?.color ?: "#757575"))
                                } catch (e: Exception) {
                                    Color.Gray
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(indicatorColor)
                        )

                        if (idx < result.steps.size - 1) {
                            Box(
                                modifier = Modifier
                                    .width(2.dp)
                                    .height(60.dp)
                                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f))
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Step Text Description
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = step.stationName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = step.description,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        if (step.durationSeconds > 0) {
                            Text(
                                text = "Timp estimat: ${step.durationSeconds / 60} min",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFCC3333),
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Start active traveler journey simulation
        Button(
            onClick = { viewModel.startActiveJourney(result) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF009933)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("start_journey_button")
        ) {
            Icon(Icons.AutoMirrored.Filled.DirectionsRun, contentDescription = "Start")
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "PORNEȘTE SIMULAREA CĂLĂTORIEI",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun ActiveJourneyScreen(viewModel: MetroViewModel) {
    val activeJourney by viewModel.activeJourney.collectAsState()
    val isNightMode by viewModel.isNightMode.collectAsState()
    val simMultiplier by viewModel.simMultiplier.collectAsState()
    val simIsPaused by viewModel.simIsPaused.collectAsState()

    val journey = activeJourney ?: return
    val route = journey.route
    val currentIndex = journey.currentStationIndex
    val currentStationId = route.stations[currentIndex]
    val currentStation = viewModel.getStaticStations().find { it.id == currentStationId }

    val progressValue = (currentIndex.toFloat() / (route.stations.size - 1).toFloat()).coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CĂLĂTORIE ÎN DESFĂȘURARE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFCC3333)
            )

            IconButton(onClick = { viewModel.cancelActiveJourney() }) {
                Icon(Icons.Default.Close, contentDescription = "Oprește călătoria")
            }
        }

        // Active State Display Card
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFEFECE6)
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // EȘTI LA
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "EȘTI LA:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = currentStation?.name?.uppercase() ?: "",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                }

                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                // URMĂTOAREA STAȚIE & COUNTDOWN
                if (!journey.completed && currentIndex < route.stations.size - 1) {
                    val nextStationId = route.stations[currentIndex + 1]
                    val nextStation = viewModel.getStaticStations().find { it.id == nextStationId }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "URMĂTOAREA STAȚIE:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            letterSpacing = 2.sp
                        )
                        Text(
                            text = nextStation?.name?.uppercase() ?: "",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "SOSIRE ÎN APROXIMATIV:",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF757575)
                        )
                        Text(
                            text = "${journey.secondsToNextStation} SECUNDE",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFCC3333)
                        )
                    }
                } else {
                    // Journey complete
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Sosit",
                            tint = Color(0xFF009933),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "AI AJUNS LA DESTINAȚIE!",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF009933),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Călătoria de la ${viewModel.getStaticStations().find { it.id == route.stations.first() }?.name} la ${viewModel.getStaticStations().find { it.id == route.stations.last() }?.name} s-a încheiat cu succes.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.secondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Progress Bar
                LinearProgressIndicator(
                    progress = progressValue,
                    color = Color(0xFFCC3333),
                    trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Plecare: ${viewModel.getStaticStations().find { it.id == route.stations.first() }?.name}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "Destinație: ${viewModel.getStaticStations().find { it.id == route.stations.last() }?.name}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        // Active Controls Panel
        Column {
            Text(
                text = "CONTROL SIMULARE CĂLĂTORIE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFFFFCF8)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "STARE:", fontWeight = FontWeight.Bold, fontSize = 12.sp)

                        Button(
                            onClick = { viewModel.toggleSimulatorPause() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (simIsPaused) Color(0xFF009933) else Color(0xFFCC3333)
                            )
                        ) {
                            Icon(
                                imageVector = if (simIsPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                contentDescription = if (simIsPaused) "Play" else "Pause"
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = if (simIsPaused) "PORNEȘTE" else "PAUZĂ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "VITEZĂ CEAS SIMULATOR:", fontWeight = FontWeight.Bold, fontSize = 12.sp)

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(1, 10, 60).forEach { mult ->
                                val active = simMultiplier == mult
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (active) Color(0xFF1E1E1E) else Color(0xFFEFECE6))
                                        .clickable { viewModel.setSimulatorSpeed(mult) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "${mult}x",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (active) Color.White else Color(0xFF1E1E1E)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Close/finish button
        Button(
            onClick = { viewModel.cancelActiveJourney() },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text(
                text = "ÎNCHIDE ȘI REVI-O LA ACASĂ",
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun TicketScreen(viewModel: MetroViewModel) {
    val fareProducts = viewModel.getStaticFareProducts()
    val activeTicketId by viewModel.activeTicketId.collectAsState()
    val purchaseStatus by viewModel.purchaseStatus.collectAsState()
    val purchasedTickets by viewModel.purchasedTickets.collectAsState()
    val selectedFareProductId by viewModel.selectedFareProductId.collectAsState()
    val isNightMode by viewModel.isNightMode.collectAsState()

    val selectedProduct = fareProducts.find { it.id == selectedFareProductId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "BILETE ȘI ABONAMENTE",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.primary
        )

        // Ticket simulated purchase state flow
        when (purchaseStatus) {
            "PROCESSING" -> {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFEFECE6)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = Color(0xFFCC3333))
                        Text(
                            text = "Se procesează plata simulată...",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Furnizor de plată demonstrativ activat",
                            fontSize = 10.sp,
                            color = Color(0xFF757575)
                        )
                    }
                }
            }
            "ACTIVE" -> {
                val activeTicket = purchasedTickets.find { it.id == activeTicketId }
                if (activeTicket != null) {
                    // DIGITAL TICKET CARD
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isNightMode) Color(0xFF262524) else Color(0xFFFFFAFA)
                        ),
                        border = BorderStroke(2.dp, Color(0xFFCC3333)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "BUCUREȘTI",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(Color(0xFFCC3333))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "METRO", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }

                                Text(
                                    text = "BILET ACTIV",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF009933)
                                )
                            }

                            Divider()

                            // Product details
                            Text(
                                text = activeTicket.name.uppercase(),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Text(
                                text = "PREȚ: ${activeTicket.price} ${activeTicket.currency} — DEMO",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFCC3333)
                            )

                            // QR Code Graphic
                            Box(
                                modifier = Modifier
                                    .size(140.dp)
                                    .background(Color.White)
                                    .border(1.dp, Color.LightGray)
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                // Draw a decorative retro look QR representation
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    repeat(10) { row ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            repeat(10) { col ->
                                                val fill = (row + col) % 3 == 0 || (row * col) % 5 == 1
                                                Box(
                                                    modifier = Modifier
                                                        .size(10.dp)
                                                        .background(if (fill) Color.Black else Color.White)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Cod Referință Fictiv: ${activeTicket.referenceNumber}",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "ACTIVAT LA: ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}",
                                    fontSize = 10.sp,
                                    color = Color(0xFF757575)
                                )
                            }

                            Divider()

                            Text(
                                text = "BILET DE DEMONSTRAȚIE — FĂRĂ VALABILITATE REALĂ",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFCC3333),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
            "DRAFT" -> {
                if (selectedProduct != null) {
                    // Confirmation layout for draft selection
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFEFECE6)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "CONFIRMĂ PRODUSUL",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.secondary
                            )

                            Text(
                                text = selectedProduct.name,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text = "PREȚ TOTAL: ${selectedProduct.price} lei",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFCC3333)
                            )

                            Text(
                                text = "Valabilitate: ${if (selectedProduct.validityMinutes > 0) "${selectedProduct.validityMinutes} minute" else "${selectedProduct.validityHours} ore"}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(
                                onClick = { viewModel.startDemoPurchase(selectedProduct.id) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFCC3333)
                                ),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Text(text = "CONFIRMĂ ACHIZIȚIE DEMO", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // List of products to purchase
        Column {
            Text(
                text = "PRODUSE DISPONIBILE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            fareProducts.forEach { product ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFFFFCF8)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clickable { viewModel.selectFareProduct(product.id) },
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = product.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = product.eligibility,
                                fontSize = 11.sp,
                                color = Color(0xFF757575)
                            )
                        }

                        Text(
                            text = "${product.price} lei",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFCC3333)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MoreScreen(viewModel: MetroViewModel) {
    val completedJourneys by viewModel.completedJourneys.collectAsState()
    val isNightMode by viewModel.isNightMode.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "OPȚIUNI ȘI ISTORIC",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.primary
        )

        // Honest Information Note
        Card(
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFCC3333).copy(alpha = 0.08f)
            ),
            border = BorderStroke(1.dp, Color(0xFFCC3333))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "INFORMAȚIE OFICIALĂ",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFFCC3333)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Această aplicație reprezintă un prototip conceptual neoficial destinat pasagerilor rețelei de metrou din București (Metrorex). Toate datele, plecările, orarele și biletele sunt STRICT DEMONSTRATIVE și nu au valabilitate juridică sau operațională reală.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Completed Journeys History List
        Column {
            Text(
                text = "ISTORIC CĂLĂTORII SIMULATE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            if (completedJourneys.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFFFFCF8)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier.padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Nu ai nicio călătorie simulată finalizată încă.",
                            fontSize = 12.sp,
                            color = Color(0xFF757575)
                        )
                    }
                }
            } else {
                completedJourneys.forEach { journey ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFFFFCF8)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${journey.fromStationName} → ${journey.toStationName}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )

                                Text(
                                    text = "SUCCES",
                                    color = Color(0xFF009933),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Durată: ${journey.durationSeconds / 60} minute",
                                fontSize = 11.sp,
                                color = Color(0xFF757575)
                            )
                        }
                    }
                }
            }
        }

        // Settings toggle or developers triggers
        Column {
            Text(
                text = "SETĂRI APLICAȚIE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFFFFCF8)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val offlineState by viewModel.isOfflineMode.collectAsState()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Forțează mod offline (local)", fontSize = 13.sp)
                        Switch(
                            checked = offlineState,
                            onCheckedChange = { viewModel.toggleOfflineMode() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DeveloperModeScreen(viewModel: MetroViewModel) {
    val simEvents by viewModel.simEvents.collectAsState()
    val trains by viewModel.trains.collectAsState()
    val isNightMode by viewModel.isNightMode.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Back navigation
        IconButton(onClick = { viewModel.goBack() }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Înapoi")
        }

        Text(
            text = "MOD DEZVOLTATOR",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.primary
        )

        // General tools actions
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFEFECE6)
            )
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = "SIMULATOR RAPID & INCIDENTE", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.triggerTrainIncident("M2", "romana") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFCC3333)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "Blochează M2", fontSize = 11.sp)
                    }

                    Button(
                        onClick = { viewModel.resolveTrainIncidents() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF009933)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "Rezolvă tot", fontSize = 11.sp)
                    }
                }
            }
        }

        // Live trains list from the simulator
        Column {
            Text(
                text = "INSPECTOR TRENURI ÎN MIȘCARE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            trains.forEach { train ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isNightMode) Color(0xFF262524) else Color(0xFFFFFCF8)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = train.id,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )

                            Text(
                                text = train.status,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = if (train.status == "BLOCAT") Color(0xFFCC3333) else Color(0xFF009933)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "De la: ${viewModel.getStaticStations().find { it.id == train.currentStationId }?.name} → Spre: ${viewModel.getStaticStations().find { it.id == train.nextStationId }?.name}",
                            fontSize = 11.sp,
                            color = Color(0xFF757575)
                        )
                        Text(
                            text = "Progres: ${(train.progress * 100).toInt()}% | Direcția: ${train.direction}",
                            fontSize = 11.sp,
                            color = Color(0xFF757575)
                        )
                    }
                }
            }
        }

        // Event Log list
        Column {
            Text(
                text = "JURNAL DE EVENIMENTE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isNightMode) Color(0xFF1E1E1E) else Color(0xFFFFFCF8)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (simEvents.isEmpty()) {
                        Text(
                            text = "Niciun eveniment înregistrat.",
                            fontSize = 11.sp,
                            color = Color(0xFF757575)
                        )
                    } else {
                        simEvents.forEach { ev ->
                            Text(
                                text = ev,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}
