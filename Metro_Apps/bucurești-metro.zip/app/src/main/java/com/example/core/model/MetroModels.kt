package com.example.core.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class MetroStation(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val lines: List<String>,
    val interchange: Boolean,
    val exits: List<String>?,
    val accessibility: Boolean,
    val facilities: List<String>?,
    val nearbyLandmarks: List<String>?
)

@JsonClass(generateAdapter = true)
data class MetroLine(
    val id: String,
    val code: String,
    val name: String,
    val color: String, // Hex string
    val stations: List<String>,
    val directionA: String,
    val directionB: String,
    val operatingNotes: String
)

@JsonClass(generateAdapter = true)
data class MetroConnection(
    val fromStationId: String,
    val toStationId: String,
    val lineId: String,
    val travelTimeSeconds: Int,
    val distanceMeters: Int
)

@JsonClass(generateAdapter = true)
data class InterchangeStation(
    val stationId: String,
    val name: String,
    val lines: List<String>,
    val transferTimeSeconds: Int,
    val description: String
)

@JsonClass(generateAdapter = true)
data class StationExit(
    val id: String,
    val stationId: String,
    val name: String,
    val description: String,
    val nearbyLandmarks: List<String>?,
    val accessibility: Boolean,
    val coordinates: String
)

@JsonClass(generateAdapter = true)
data class StationFacility(
    val stationId: String,
    val lifts: Int,
    val escalators: Int,
    val ticketMachines: Int,
    val ticketCounters: Int,
    val publicToilets: Boolean,
    val wheelchairAccessible: Boolean,
    val bicycleParking: Boolean,
    val wifiAvailable: Boolean,
    val securityOffice: Boolean
)

@JsonClass(generateAdapter = true)
data class ServiceIncident(
    val id: String,
    val title: String,
    val description: String,
    val severity: String, // INFO, WARNING, CRITICAL
    val affectedLines: List<String>,
    val affectedStations: List<String>,
    val startTime: String,
    val expectedEnd: String,
    val alternativeRoutes: String
)

@JsonClass(generateAdapter = true)
data class FareProduct(
    val id: String,
    val name: String,
    val price: Double,
    val currency: String,
    val validityMinutes: Int,
    val validityHours: Int,
    val transportModes: List<String>,
    val eligibility: String,
    val lastUpdated: String,
    val isDemonstration: Boolean
)

data class MetroTrain(
    val id: String,
    val lineId: String,
    val currentStationId: String,
    val nextStationId: String,
    val direction: String,
    val progress: Float, // 0.0 to 1.0
    val speed: Float, // km/h
    val delaySeconds: Int,
    val status: String // STATIONAT, IN_DEPLASARE, IN_INTARZIERE, BLOCAT, SCOS_DIN_CIRCULATIE
)
