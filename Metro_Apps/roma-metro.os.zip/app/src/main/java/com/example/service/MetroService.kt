package com.example.service

import android.content.Context
import android.util.Log
import com.example.data.fixtures.MetroFixtures
import com.example.data.model.*
import com.example.data.repository.MetroRepository
import com.example.service.simulation.SimScenario
import com.example.service.simulation.TrainSimulator
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

data class WeatherObservation(
    val tempCelsius: Int,
    val description: String, // Soleggiato, Pioggia, Caldo Intenso, Nuvoloso, Vento
    val rainMm: Float,
    val recommendation: String
)

class MetroService private constructor(
    private val context: Context,
    val repository: MetroRepository
) {

    companion object {
        private const val TAG = "MetroService"

        @Volatile
        private var INSTANCE: MetroService? = null

        fun getInstance(context: Context): MetroService {
            return INSTANCE ?: synchronized(this) {
                val repo = MetroRepository.getInstance(context)
                val service = MetroService(context.applicationContext, repo)
                INSTANCE = service
                service
            }
        }
    }

    val trainSimulator = TrainSimulator(repository)

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var simulationJob: Job? = null

    private val _isSimRunning = MutableStateFlow(false)
    val isSimRunning: StateFlow<Boolean> = _isSimRunning

    private val _weather = MutableStateFlow(WeatherObservation(24, "Soleggiato", 0.0f, "Rotta standard consigliata."))
    val weather: StateFlow<WeatherObservation> = _weather

    init {
        // Run database seeding on startup
        serviceScope.launch {
            repository.seedIfNeeded()
            trainSimulator.setScenario(SimScenario.NORMALE)
            updateDbWithSimulatorData()
        }
    }

    fun startSimulation(tickRateMs: Long = 4000L) {
        if (_isSimRunning.value) return
        _isSimRunning.value = true

        simulationJob = serviceScope.launch {
            Log.d(TAG, "Background simulation ticker started.")
            while (isActive) {
                delay(tickRateMs)
                // Increment simulated clock by 1 minute
                trainSimulator.incrementTime(1)
                updateDbWithSimulatorData()
                Log.d(TAG, "Simulation tick completed. Time: ${formatSimTime(trainSimulator.simTimeMinutes.value)}")
            }
        }
    }

    fun stopSimulation() {
        simulationJob?.cancel()
        _isSimRunning.value = false
        Log.d(TAG, "Background simulation ticker stopped.")
    }

    private suspend fun updateDbWithSimulatorData() {
        val trains = trainSimulator.getActiveTrains()
        if (trains.isEmpty()) return

        // Compute simulated arrivals down each line and save
        val stations = repository.getAllStations()
        val arrivals = mutableListOf<OrarioArrivoEntity>()

        for (train in trains) {
            val lineStations = stations.filter { it.lineId == train.lineId }.sortedBy { it.orderIndex }
            val currentIdx = lineStations.indexOfFirst { it.id == train.currentStationId }
            val targetIdx = lineStations.indexOfFirst { it.id == train.targetStationId }
            if (currentIdx == -1 || targetIdx == -1) continue

            val isForward = train.direction == lineStations.last().name
            val progress = train.progress

            // Progress represents completion between current and target
            // Calculate minutes to subsequent stations
            var cumulativeTime = if (train.status == "IN_MOVIMENTO") {
                ((1.0f - progress) * 2.0).coerceAtLeast(0.5)
            } else {
                1.5 // dwell remaining
            }

            if (isForward) {
                // Stations remaining forward
                for (idx in targetIdx until lineStations.size) {
                    val targetStation = lineStations[idx]
                    arrivals.add(
                        OrarioArrivoEntity(
                            stationId = targetStation.id,
                            lineId = train.lineId,
                            direction = train.direction,
                            estimatedMinutes = cumulativeTime.toInt().coerceAtLeast(1),
                            platform = "Binario 1",
                            source = "METRO.OS Digital Twin",
                            sourceType = DataSourceType.SIMULATED
                        )
                    )
                    cumulativeTime += 2.0
                }
            } else {
                // Stations remaining backward
                for (idx in targetIdx downTo 0) {
                    val targetStation = lineStations[idx]
                    arrivals.add(
                        OrarioArrivoEntity(
                            stationId = targetStation.id,
                            lineId = train.lineId,
                            direction = train.direction,
                            estimatedMinutes = cumulativeTime.toInt().coerceAtLeast(1),
                            platform = "Binario 2",
                            source = "METRO.OS Digital Twin",
                            sourceType = DataSourceType.SIMULATED
                        )
                    )
                    cumulativeTime += 2.0
                }
            }
        }

        // Save to Database
        try {
            repository.clearTrains()
            repository.insertTrains(trains)

            repository.clearAllArrivals()
            repository.insertArrivals(arrivals)

            // Dynamically simulate passenger flow densities in the stations
            simulatePassengerFlows(stations)
        } catch (e: Exception) {
            Log.e(TAG, "Error writing simulation tick data to DB", e)
        }
    }

    private suspend fun simulatePassengerFlows(stations: List<StationEntity>) {
        val minutes = trainSimulator.simTimeMinutes.value
        // Determine demand based on peak hour formulas
        // Peaks at 8:00 (480 min) and 18:00 (1080 min)
        val peakFactor1 = Math.exp(-Math.pow((minutes - 480.0) / 60.0, 2.0))
        val peakFactor2 = Math.exp(-Math.pow((minutes - 1080.0) / 60.0, 2.0))
        val baseTraffic = 0.25
        val systemTraffic = (baseTraffic + peakFactor1 * 0.65 + peakFactor2 * 0.55).coerceIn(0.1, 1.0)

        for (station in stations) {
            // stations have local demand factors (Termini, Spagna, Colosseo are busier)
            val busyMultiplier = when (station.id) {
                "TERMINI_A", "TERMINI_B" -> 1.3
                "COLOSSEO", "SPAGNA", "BARBERINI" -> 1.15
                "QUINTILIANI" -> 0.4
                else -> 0.8
            }
            val calculatedDemand = (systemTraffic * busyMultiplier).coerceIn(0.05, 1.0)
            repository.updateStationDemand(station.id, calculatedDemand)
        }
    }

    // DISRUPTIONS
    suspend fun createSimulatedDisruption(
        lineId: String,
        title: String,
        desc: String,
        affectedStationsCsv: String,
        severity: IncidentSeverity = IncidentSeverity.WARNING
    ): String {
        val incidentId = UUID.randomUUID().toString()
        val incident = IncidentEntity(
            id = incidentId,
            lineId = lineId,
            title = title,
            description = desc,
            severity = severity,
            status = "ATTIVO",
            stationsAffected = affectedStationsCsv,
            alternativeRouteDesc = "Utilizzare Linea A con cambio a Termini o bus navetta sostitutivo se disponibile."
        )

        repository.insertIncidents(listOf(incident))

        // Update line status
        val status = if (severity == IncidentSeverity.CRITICAL) LineStatus.INTERRUZIONE else LineStatus.RALLENTAMENTI
        repository.updateLineStatus(lineId, status, "SOGGETTO A PERTURBAZIONE: $title")

        // Trigger simulation refresh
        updateDbWithSimulatorData()

        return incidentId
    }

    suspend fun resolveDisruption(incidentId: String) {
        val incidents = repository.getAllIncidents()
        val incident = incidents.find { it.id == incidentId } ?: return

        repository.deleteIncident(incidentId)

        // Check if any other incidents active on this line
        val remaining = repository.getAllIncidents().any { it.lineId == incident.lineId }
        if (!remaining) {
            repository.updateLineStatus(incident.lineId, LineStatus.REGOLARE, "Servizio regolare.")
        }

        updateDbWithSimulatorData()
    }

    // WEATHER AND ENVIRONMENTAL ROUTING
    fun setWeather(temp: Int, desc: String, rain: Float) {
        val rec = when (desc) {
            "Pioggia" -> "Si consiglia di evitare lunghi percorsi a piedi all'aperto. Preferire cambi interni di metropolitana."
            "Caldo Intenso" -> "Temperature esterne elevate (37°C+). Preferire stazioni dotate di ascensori climatizzati ed evitare lunghi tratti a piedi."
            else -> "Rotta standard consigliata."
        }
        _weather.value = WeatherObservation(temp, desc, rain, rec)
    }

    fun formatSimTime(minutes: Int): String {
        val hrs = (minutes / 60) % 24
        val mins = minutes % 60
        return String.format("%02d:%02d", hrs, mins)
    }
}
