package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.fixtures.MetroFixtures
import com.example.data.model.*
import com.example.data.repository.MetroRepository
import com.example.domain.routing.MetroRoutingEngine
import com.example.domain.routing.RoutingPreference
import com.example.domain.routing.RouteResult
import com.example.service.MetroService
import com.example.service.WeatherObservation
import com.example.service.simulation.SimScenario
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MetroViewModel(application: Application) : AndroidViewModel(application) {

    private val TAG = "MetroViewModel"
    private val metroService = MetroService.getInstance(application)
    private val repository = metroService.repository

    // Local lists caching for fast access
    private val _allStations = MutableStateFlow<List<StationEntity>>(emptyList())
    val allStations: StateFlow<List<StationEntity>> = _allStations

    // Expose DB flows reactively
    val lines: StateFlow<List<LineEntity>> = repository.linesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stations: StateFlow<List<StationEntity>> = repository.stationsFlow
        .onEach { if (it.isNotEmpty()) _allStations.value = it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trains: StateFlow<List<TrenoEntity>> = repository.trainsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val incidents: StateFlow<List<IncidentEntity>> = repository.incidentsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val places: StateFlow<List<LuogoEntity>> = repository.placesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedRoutes: StateFlow<List<SavedRouteEntity>> = repository.savedRoutesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val fares: StateFlow<List<FareProductEntity>> = repository.faresFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Simulation states
    val isSimRunning: StateFlow<Boolean> = metroService.isSimRunning
    val simScenario: StateFlow<SimScenario> = metroService.trainSimulator.currentScenario
    val simTimeMinutes: StateFlow<Int> = metroService.trainSimulator.simTimeMinutes
    val weather: StateFlow<WeatherObservation> = metroService.weather

    // Navigation and UI state
    private val _currentTab = MutableStateFlow("home") // "home", "mappa", "percorso", "stazioni", "salvati", "ticket", "digital_twin"
    val currentTab: StateFlow<String> = _currentTab

    private val _selectedStationId = MutableStateFlow<String?>(null)
    val selectedStationId: StateFlow<String?> = _selectedStationId

    // Selected station details (exposes flow for dynamic arrivals)
    val selectedStationFlow: StateFlow<StationEntity?> = _selectedStationId
        .map { id -> if (id == null) null else _allStations.value.find { s -> s.id == id } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedStationArrivals: StateFlow<List<OrarioArrivoEntity>> = _selectedStationId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else repository.getArrivalsForStationFlow(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Routing Search inputs
    private val _fromSearchQuery = MutableStateFlow("")
    val fromSearchQuery: StateFlow<String> = _fromSearchQuery

    private val _toSearchQuery = MutableStateFlow("")
    val toSearchQuery: StateFlow<String> = _toSearchQuery

    private val _selectedFromStation = MutableStateFlow<StationEntity?>(null)
    val selectedFromStation: StateFlow<StationEntity?> = _selectedFromStation

    private val _selectedToStation = MutableStateFlow<StationEntity?>(null)
    val selectedToStation: StateFlow<StationEntity?> = _selectedToStation

    // Routing preference state
    private val _routingPref = MutableStateFlow(RoutingPreference())
    val routingPref: StateFlow<RoutingPreference> = _routingPref

    // Routing calculation outputs
    private val _plannedRoutesList = MutableStateFlow<List<RouteResult>>(emptyList())
    val plannedRoutesList: StateFlow<List<RouteResult>> = _plannedRoutesList

    private val _activeRouteResult = MutableStateFlow<RouteResult?>(null)
    val activeRouteResult: StateFlow<RouteResult?> = _activeRouteResult

    private val _activeLegProgressIndex = MutableStateFlow(0)
    val activeLegProgressIndex: StateFlow<Int> = _activeLegProgressIndex

    // Structured Search Results
    sealed class SearchResultItem {
        data class StazioneItem(val station: StationEntity) : SearchResultItem()
        data class LuogoItem(val place: LuogoEntity) : SearchResultItem()
    }

    private val _searchResults = MutableStateFlow<List<SearchResultItem>>(emptyList())
    val searchResults: StateFlow<List<SearchResultItem>> = _searchResults

    // Tickets
    private val _activeTicket = MutableStateFlow<FareProductEntity?>(null)
    val activeTicket: StateFlow<FareProductEntity?> = _activeTicket

    private val _ticketStatus = MutableStateFlow("ATTIVO") // "ATTIVO", "NON_ATTIVO", "SCADUTO"
    val ticketStatus: StateFlow<String> = _ticketStatus

    private val _ticketExpirationTime = MutableStateFlow<String?>(null)
    val ticketExpirationTime: StateFlow<String?> = _ticketExpirationTime

    private val _ticketsHistory = MutableStateFlow<List<Pair<FareProductEntity, String>>>(emptyList())
    val ticketsHistory: StateFlow<List<Pair<FareProductEntity, String>>> = _ticketsHistory

    init {
        // Run seed check immediately in ViewModel init block
        viewModelScope.launch {
            repository.seedIfNeeded()
            // Pull initial stations list for pathfinder init
            _allStations.value = repository.getAllStations()
            // Select default stations for convenience
            val termini = _allStations.value.find { it.id == "TERMINI_B" }
            val colosseo = _allStations.value.find { it.id == "COLOSSEO" }
            _selectedFromStation.value = termini
            _selectedToStation.value = colosseo
            calculateRoute()
        }
    }

    fun selectTab(tab: String) {
        _currentTab.value = tab
        _selectedStationId.value = null // reset selection when swapping main views
    }

    fun setFromQuery(query: String) {
        _fromSearchQuery.value = query
        performSearch(query)
    }

    fun setToQuery(query: String) {
        _toSearchQuery.value = query
        performSearch(query)
    }

    private fun performSearch(query: String) {
        if (query.length < 2) {
            _searchResults.value = emptyList()
            return
        }

        val lowercase = query.lowercase()
        val stationResults = _allStations.value.filter {
            it.name.lowercase().contains(lowercase) || it.code.lowercase().contains(lowercase)
        }.map { SearchResultItem.StazioneItem(it) }

        val placeResults = places.value.filter {
            it.name.lowercase().contains(lowercase) || it.category.lowercase().contains(lowercase)
        }.map { SearchResultItem.LuogoItem(it) }

        _searchResults.value = (stationResults + placeResults).take(8)
    }

    fun selectFromStation(station: StationEntity) {
        _selectedFromStation.value = station
        _fromSearchQuery.value = station.name
        _searchResults.value = emptyList()
        calculateRoute()
    }

    fun selectToStation(station: StationEntity) {
        _selectedToStation.value = station
        _toSearchQuery.value = station.name
        _searchResults.value = emptyList()
        calculateRoute()
    }

    fun selectToPlace(place: LuogoEntity) {
        val st = _allStations.value.find { it.id == place.nearestStationId }
        if (st != null) {
            _selectedToStation.value = st
            _toSearchQuery.value = "${place.name} (Stazione ${st.name})"
            _searchResults.value = emptyList()
            calculateRoute()
        }
    }

    fun toggleRoutingPref(type: String) {
        val current = _routingPref.value
        val updated = when (type) {
            "fastest" -> current.copy(fastest = true, fewestTransfers = false)
            "fewestTransfers" -> current.copy(fastest = false, fewestTransfers = true)
            "stepFree" -> current.copy(stepFree = !current.stepFree)
            "wheelchair" -> current.copy(wheelchairAccessible = !current.wheelchairAccessible)
            "avoidEscalators" -> current.copy(avoidEscalators = !current.avoidEscalators)
            else -> current
        }
        _routingPref.value = updated
        calculateRoute()
    }

    fun calculateRoute() {
        val from = _selectedFromStation.value ?: return
        val to = _selectedToStation.value ?: return

        if (from.id == to.id) {
            _plannedRoutesList.value = emptyList()
            return
        }

        viewModelScope.launch {
            val engine = MetroRoutingEngine(_allStations.value)
            val closedIds = stations.value.filter { it.isClosed }.map { it.id }.toSet()
            val slowedLines = lines.value.filter { it.status == LineStatus.RALLENTAMENTI || it.status == LineStatus.INTERRUZIONE }.map { it.id }.toSet()

            val routes = engine.planRoute(
                fromId = from.id,
                toId = to.id,
                pref = _routingPref.value,
                closedStations = closedIds,
                lineDisruptions = slowedLines
            )
            _plannedRoutesList.value = routes
            if (routes.isNotEmpty()) {
                _activeRouteResult.value = routes.first()
                _activeLegProgressIndex.value = 0
            } else {
                _activeRouteResult.value = null
            }
        }
    }

    fun selectActiveRoute(route: RouteResult) {
        _activeRouteResult.value = route
        _activeLegProgressIndex.value = 0
    }

    fun advanceRouteLegProgress() {
        val route = _activeRouteResult.value ?: return
        val currentIdx = _activeLegProgressIndex.value
        if (currentIdx < route.legs.size - 1) {
            _activeLegProgressIndex.value = currentIdx + 1
        }
    }

    fun resetRouteLegProgress() {
        _activeLegProgressIndex.value = 0
    }

    fun selectStation(stationId: String) {
        _selectedStationId.value = stationId
        selectTab("stazioni")
    }

    // SAVED ROUTES
    fun saveActiveRoute() {
        val from = _selectedFromStation.value ?: return
        val to = _selectedToStation.value ?: return
        viewModelScope.launch {
            repository.insertSavedRoute(
                fromId = from.id,
                toId = to.id,
                fromName = from.name,
                toName = to.name,
                prefJson = "{}"
            )
        }
    }

    fun deleteSavedRoute(id: String) {
        viewModelScope.launch {
            repository.deleteSavedRoute(id)
        }
    }

    fun loadSavedRoute(saved: SavedRouteEntity) {
        val from = _allStations.value.find { it.id == saved.fromStationId }
        val to = _allStations.value.find { it.id == saved.toStationId }
        if (from != null && to != null) {
            _selectedFromStation.value = from
            _selectedToStation.value = to
            _fromSearchQuery.value = from.name
            _toSearchQuery.value = to.name
            selectTab("percorso")
            calculateRoute()
        }
    }

    // TICKETS
    fun purchaseTicket(fare: FareProductEntity) {
        _activeTicket.value = fare
        _ticketStatus.value = "ATTIVO"
        val expTime = System.currentTimeMillis() + (fare.durationMinutes * 60 * 1000L)
        val expDateStr = java.text.SimpleDateFormat("HH:mm:ss dd/MM", java.util.Locale.ITALIAN).format(java.util.Date(expTime))
        _ticketExpirationTime.value = expDateStr
        _ticketsHistory.value = listOf(Pair(fare, "Acquistato alle " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.ITALIAN).format(java.util.Date()))) + _ticketsHistory.value
    }

    fun invalidateTicket() {
        _activeTicket.value = null
        _ticketStatus.value = "NON_ATTIVO"
        _ticketExpirationTime.value = null
    }

    // SIMULATOR TRIGGER PANEL
    fun toggleSimulation() {
        if (isSimRunning.value) {
            metroService.stopSimulation()
        } else {
            metroService.startSimulation()
        }
    }

    fun updateScenario(scenario: SimScenario) {
        viewModelScope.launch {
            metroService.trainSimulator.setScenario(scenario)
            calculateRoute() // recalculate route in case disruption scenario updates weights
        }
    }

    fun triggerLineBIncident() {
        viewModelScope.launch {
            metroService.createSimulatedDisruption(
                lineId = "B",
                title = "Rallentamento Linea B",
                desc = "Problemi tecnici alla linea aerea tra Termini e Colosseo. I treni viaggiano a velocità ridotta.",
                affectedStationsCsv = "TERMINI_B;CAVOUR;COLOSSEO",
                severity = IncidentSeverity.WARNING
            )
            calculateRoute()
        }
    }

    fun clearIncidents() {
        viewModelScope.launch {
            metroService.repository.clearAllIncidents()
            metroService.repository.updateLineStatus("B", LineStatus.REGOLARE, "Servizio regolare.")
            calculateRoute()
        }
    }

    fun updateWeatherCondition(desc: String) {
        when (desc) {
            "Pioggia" -> metroService.setWeather(18, "Pioggia", 4.5f)
            "Caldo Intenso" -> metroService.setWeather(37, "Caldo Intenso", 0.0f)
            "Nuvoloso" -> metroService.setWeather(21, "Nuvoloso", 0.0f)
            else -> metroService.setWeather(24, "Soleggiato", 0.0f)
        }
        calculateRoute()
    }

    fun formatMinutesToTime(minutes: Int): String {
        return metroService.formatSimTime(minutes)
    }

    override fun onCleared() {
        super.onCleared()
        metroService.stopSimulation()
    }
}
