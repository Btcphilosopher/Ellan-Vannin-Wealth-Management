package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.simulation.SimScenario
import com.example.ui.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalTwinTab(viewModel: MetroViewModel) {
    val isSimRunning by viewModel.isSimRunning.collectAsState()
    val currentScenario by viewModel.simScenario.collectAsState()
    val simTimeMin by viewModel.simTimeMinutes.collectAsState()
    val trains by viewModel.trains.collectAsState()
    val incidents by viewModel.incidents.collectAsState()

    val formattedTime = viewModel.formatMinutesToTime(simTimeMin)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title Header
        item {
            Column {
                Text(
                    text = "DIGITAL TWIN E SIMULATORE",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "CRUSCOTTO DI CONTROLLO MATEMATICO DELLA RETE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        // Ticker Control Block
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Orologio di Rete",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // Ticker active indicator
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(if (isSimRunning) SuccessEmerald else AlertRed, shape = MaterialTheme.shapes.extraSmall)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                if (isSimRunning) "MOTORE ATTIVO" else "MOTORE FERMO",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isSimRunning) SuccessEmerald else AlertRed
                            )
                        }
                    }

                    // Display virtual time
                    Text(
                        text = formattedTime,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        letterSpacing = 2.sp
                    )

                    // Control Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Play / Pause Simulation
                        Button(
                            onClick = { viewModel.toggleSimulation() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("toggle_sim_button")
                        ) {
                            Icon(
                                imageVector = if (isSimRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Toggle"
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isSimRunning) "Pausa" else "Avvia")
                        }

                        // Fast forward simulated minutes
                        Button(
                            onClick = { viewModel.toggleSimulation(); viewModel.toggleSimulation() }, // Trigger tick
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.SkipNext, contentDescription = "Tick")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("+1 Minuto")
                        }
                    }
                }
            }
        }

        // Scenario Selector Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Scenario di Carico e Flussi",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(
                            selected = currentScenario == SimScenario.NORMALE,
                            onClick = { viewModel.updateScenario(SimScenario.NORMALE) },
                            label = { Text("Normale") }
                        )
                        FilterChip(
                            selected = currentScenario == SimScenario.ORA_DI_PUNTA,
                            onClick = { viewModel.updateScenario(SimScenario.ORA_DI_PUNTA) },
                            label = { Text("Ora di Punta") }
                        )
                        FilterChip(
                            selected = currentScenario == SimScenario.BASSA_DOMANDA,
                            onClick = { viewModel.updateScenario(SimScenario.BASSA_DOMANDA) },
                            label = { Text("Bassa Dom.") }
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(
                            selected = currentScenario == SimScenario.RITARDO,
                            onClick = { viewModel.updateScenario(SimScenario.RITARDO) },
                            label = { Text("Accul. Ritardi") }
                        )
                        FilterChip(
                            selected = currentScenario == SimScenario.DISSERVIZIO,
                            onClick = { viewModel.updateScenario(SimScenario.DISSERVIZIO) },
                            label = { Text("Guasti Rete") }
                        )
                    }
                }
            }
        }

        // Active Disruption Injector
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Generatore Perturbazioni sulla Rete",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (incidents.isEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "OK", tint = SuccessEmerald)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                "Nessun guasto simulato attivo. Rete regolare.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = { viewModel.triggerLineBIncident() },
                            colors = ButtonDefaults.buttonColors(containerColor = AlertOrange),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.FlashOn, contentDescription = "Fault")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Simula Guasto Linea B (Rallentamenti)")
                        }
                    } else {
                        incidents.forEach { inc ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, AlertRed, MaterialTheme.shapes.small)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        inc.title.uppercase(),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = AlertRed
                                    )
                                    Text(
                                        inc.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = { viewModel.clearIncidents() },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Build, contentDescription = "Repair")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Risolvi Incidenti e Ripristina Rete")
                        }
                    }
                }
            }
        }

        // Custom Vector Passenger Density Chart
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Affluenza Giornaliera (Trend Storico e Reale)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    PassengerTrendChart()
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalTextApi::class)
@Composable
fun PassengerTrendChart() {
    val outlineColor = MaterialTheme.colorScheme.outline
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .background(Color.White, shape = MaterialTheme.shapes.small)
            .padding(10.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Y Grid lines (0%, 50%, 100% capacity)
            drawLine(color = gridColor, start = Offset(0f, 0f), end = Offset(width, 0f), strokeWidth = 1f)
            drawLine(color = gridColor, start = Offset(0f, height / 2f), end = Offset(width, height / 2f), strokeWidth = 1f)
            drawLine(color = gridColor, start = Offset(0f, height), end = Offset(width, height), strokeWidth = 1.5f)

            // Hours slots: Peak at 8am, Peak at 6pm
            val hoursX = listOf(6, 8, 10, 12, 14, 16, 18, 20, 22)
            val loadY = listOf(0.15f, 0.85f, 0.45f, 0.40f, 0.55f, 0.50f, 0.90f, 0.60f, 0.20f)

            // Draw line graph path
            val path = Path()
            val stepX = width / (hoursX.size - 1)

            path.moveTo(0f, height - (loadY[0] * height))
            for (i in 1 until hoursX.size) {
                val cx = i * stepX
                val cy = height - (loadY[i] * height)
                path.lineTo(cx, cy)
            }

            drawPath(
                path = path,
                color = Color(0xFFA14923), // Rust Red
                style = Stroke(width = 3f, cap = StrokeCap.Round)
            )

            // Draw data points
            for (i in hoursX.indices) {
                val cx = i * stepX
                val cy = height - (loadY[i] * height)
                drawCircle(color = Color.White, radius = 5f, center = Offset(cx, cy))
                drawCircle(color = Color(0xFFA14923), radius = 3f, center = Offset(cx, cy))

                // Label hours
                if (i % 2 == 0) {
                    val measuredText = textMeasurer.measure(
                        text = "${hoursX[i]}:00",
                        style = TextStyle(color = Color.Gray, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    )
                    drawText(
                        measuredText,
                        topLeft = Offset(cx - measuredText.size.width / 2f, height - 12f)
                    )
                }
            }
        }
    }
}
