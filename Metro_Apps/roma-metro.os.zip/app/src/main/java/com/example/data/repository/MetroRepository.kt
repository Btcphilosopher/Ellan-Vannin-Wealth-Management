package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.dao.MetroDao
import com.example.data.database.MetroDatabase
import com.example.data.fixtures.MetroFixtures
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class MetroRepository(private val metroDao: MetroDao) {

    companion object {
        private const val TAG = "MetroRepository"

        @Volatile
        private var INSTANCE: MetroRepository? = null

        fun getInstance(context: Context): MetroRepository {
            return INSTANCE ?: synchronized(this) {
                val db = MetroDatabase.getDatabase(context)
                val repo = MetroRepository(db.metroDao())
                INSTANCE = repo
                repo
            }
        }
    }

    val linesFlow: Flow<List<LineEntity>> = metroDao.getAllLinesFlow()
    val stationsFlow: Flow<List<StationEntity>> = metroDao.getAllStationsFlow()
    val trainsFlow: Flow<List<TrenoEntity>> = metroDao.getAllTrainsFlow()
    val incidentsFlow: Flow<List<IncidentEntity>> = metroDao.getAllIncidentsFlow()
    val placesFlow: Flow<List<LuogoEntity>> = metroDao.getAllPlacesFlow()
    val savedRoutesFlow: Flow<List<SavedRouteEntity>> = metroDao.getAllSavedRoutesFlow()
    val faresFlow: Flow<List<FareProductEntity>> = metroDao.getAllFaresFlow()

    suspend fun seedIfNeeded() = withContext(Dispatchers.IO) {
        try {
            val existingLines = metroDao.getAllLines()
            if (existingLines.isEmpty()) {
                Log.d(TAG, "Database is empty. Seeding fixtures...")
                metroDao.insertLines(MetroFixtures.lines)
                metroDao.insertStations(MetroFixtures.stations)
                metroDao.insertPlaces(MetroFixtures.places)
                metroDao.insertFares(MetroFixtures.fares)
                Log.d(TAG, "Seeding completed successfully.")
            } else {
                Log.d(TAG, "Database already seeded. ${existingLines.size} lines found.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error seeding database", e)
        }
    }

    suspend fun getAllLines(): List<LineEntity> = withContext(Dispatchers.IO) {
        metroDao.getAllLines()
    }

    suspend fun getLineById(id: String): LineEntity? = withContext(Dispatchers.IO) {
        metroDao.getLineById(id)
    }

    suspend fun updateLineStatus(lineId: String, status: LineStatus, message: String) = withContext(Dispatchers.IO) {
        metroDao.updateLineStatus(lineId, status, message)
    }

    suspend fun getAllStations(): List<StationEntity> = withContext(Dispatchers.IO) {
        metroDao.getAllStations()
    }

    suspend fun getStationById(id: String): StationEntity? = withContext(Dispatchers.IO) {
        metroDao.getStationById(id)
    }

    suspend fun getStationsByLine(lineId: String): List<StationEntity> = withContext(Dispatchers.IO) {
        metroDao.getStationsByLine(lineId)
    }

    suspend fun updateStationDemand(stationId: String, demand: Double) = withContext(Dispatchers.IO) {
        metroDao.updateStationDemand(stationId, demand)
    }

    suspend fun getAllTrains(): List<TrenoEntity> = withContext(Dispatchers.IO) {
        metroDao.getAllTrains()
    }

    suspend fun insertTrains(trains: List<TrenoEntity>) = withContext(Dispatchers.IO) {
        metroDao.insertTrains(trains)
    }

    suspend fun clearTrains() = withContext(Dispatchers.IO) {
        metroDao.clearTrains()
    }

    fun getArrivalsForStationFlow(stationId: String): Flow<List<OrarioArrivoEntity>> {
        return metroDao.getArrivalsForStationFlow(stationId)
    }

    suspend fun getArrivalsForStation(stationId: String): List<OrarioArrivoEntity> = withContext(Dispatchers.IO) {
        metroDao.getArrivalsForStation(stationId)
    }

    suspend fun insertArrivals(arrivals: List<OrarioArrivoEntity>) = withContext(Dispatchers.IO) {
        metroDao.insertArrivals(arrivals)
    }

    suspend fun clearArrivalsForStation(stationId: String) = withContext(Dispatchers.IO) {
        metroDao.clearArrivalsForStation(stationId)
    }

    suspend fun clearAllArrivals() = withContext(Dispatchers.IO) {
        metroDao.clearAllArrivals()
    }

    suspend fun getAllIncidents(): List<IncidentEntity> = withContext(Dispatchers.IO) {
        metroDao.getAllIncidents()
    }

    suspend fun insertIncidents(incidents: List<IncidentEntity>) = withContext(Dispatchers.IO) {
        metroDao.insertIncidents(incidents)
    }

    suspend fun deleteIncident(id: String) = withContext(Dispatchers.IO) {
        metroDao.deleteIncident(id)
    }

    suspend fun clearAllIncidents() = withContext(Dispatchers.IO) {
        metroDao.clearAllIncidents()
    }

    suspend fun getAllPlaces(): List<LuogoEntity> = withContext(Dispatchers.IO) {
        metroDao.getAllPlaces()
    }

    suspend fun getPlacesByCategory(category: String): List<LuogoEntity> = withContext(Dispatchers.IO) {
        metroDao.getPlacesByCategory(category)
    }

    suspend fun insertSavedRoute(fromId: String, toId: String, fromName: String, toName: String, prefJson: String) = withContext(Dispatchers.IO) {
        metroDao.insertSavedRoute(
            SavedRouteEntity(
                fromStationId = fromId,
                toStationId = toId,
                fromStationName = fromName,
                toStationName = toName,
                preferencesJson = prefJson
            )
        )
    }

    suspend fun deleteSavedRoute(id: String) = withContext(Dispatchers.IO) {
        metroDao.deleteSavedRoute(id)
    }

    suspend fun isRouteSaved(fromId: String, toId: String): Boolean = withContext(Dispatchers.IO) {
        metroDao.isRouteSaved(fromId, toId)
    }

    suspend fun getAllFares(): List<FareProductEntity> = withContext(Dispatchers.IO) {
        metroDao.getAllFares()
    }
}
