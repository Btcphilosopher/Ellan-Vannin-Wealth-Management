package com.example.ui.map

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fixtures.MetroFixtures
import com.example.data.model.StationEntity
import com.example.data.model.TrenoEntity
import com.example.domain.routing.RouteResult
import com.example.ui.theme.*
import kotlin.math.sqrt

@OptIn(ExperimentalTextApi::class)
@Composable
fun MetroMap(
    stations: List<StationEntity>,
    trains: List<TrenoEntity>,
    activeRoute: RouteResult?,
    selectedStation: StationEntity?,
    onStationSelect: (StationEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val textMeasurer = rememberTextMeasurer()
    val labelColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f)

    // Geographic bounds to crop Rome area perfectly
    val minLat = 41.8200
    val maxLat = 41.9350
    val minLon = 12.4100
    val maxLon = 12.6800

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.5f, 5.0f)
                    offset += pan
                }
            }
            .pointerInput(stations) {
                detectTapGestures { tapOffset ->
                    // Reverse the transform to find the geographical match
                    val adjustedOffset = (tapOffset - offset) / scale

                    // Find nearest station on screen
                    var nearest: StationEntity? = null
                    var minDist = Float.MAX_VALUE

                    // We need matching projection. We will simulate projection here
                    // directly using the same scale calculations
                    val size = this.size
                    val width = size.width
                    val height = size.height

                    for (station in stations) {
                        // Project longitude to x [0, width]
                        val x = ((station.longitude - minLon) / (maxLon - minLon) * width).toFloat()
                        // Project latitude to y [height, 0] (Inverted)
                        val y = (height - (station.latitude - minLat) / (maxLat - minLat) * height).toFloat()

                        val dist = sqrt((adjustedOffset.x - x) * (adjustedOffset.x - x) + (adjustedOffset.y - y) * (adjustedOffset.y - y))
                        if (dist < 24f * scale && dist < minDist) {
                            minDist = dist
                            nearest = station
                        }
                    }

                    if (nearest != null) {
                        onStationSelect(nearest)
                    }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Coordinate to offset converter
            fun getOffset(station: StationEntity): Offset {
                val x = ((station.longitude - minLon) / (maxLon - minLon) * width).toFloat()
                val y = (height - (station.latitude - minLat) / (maxLat - minLat) * height).toFloat()
                return Offset(x, y)
            }

            // Draw with viewport transformation
            withTransform({
                translate(offset.x, offset.y)
                scale(scale, scale)
            }) {
                // Group stations by line
                val linesGrouped = stations.groupBy { it.lineId }

                // 1. Draw Physical Tracks/Lines
                for ((lineId, lineStations) in linesGrouped) {
                    val sorted = lineStations.sortedBy { it.orderIndex }
                    if (sorted.isEmpty()) continue

                    val pathColor = when (lineId) {
                        "A" -> Color(0xFFF2780C)
                        "B" -> Color(0xFF007CC0)
                        "C" -> Color(0xFF32A041)
                        else -> Color.Gray
                    }

                    val path = Path()
                    path.moveTo(getOffset(sorted.first()).x, getOffset(sorted.first()).y)
                    for (i in 1 until sorted.size) {
                        val o = getOffset(sorted[i])
                        path.lineTo(o.x, o.y)
                    }

                    drawPath(
                        path = path,
                        color = pathColor.copy(alpha = 0.6f),
                        style = Stroke(width = 6f / scale, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }

                // 2. Draw Highlight Active Navigation Path if present
                if (activeRoute != null) {
                    val highlightColor = Color(0xFFCE9B4E) // Imperial Roman Gold
                    activeRoute.legs.filter { it.type == "METRO" }.forEach { leg ->
                        val legSts = mutableListOf<StationEntity>()
                        val fromSt = stations.find { it.id == leg.fromStationId }
                        val toSt = stations.find { it.id == leg.toStationId }

                        if (fromSt != null && toSt != null) {
                            val sameLine = stations.filter { it.lineId == leg.lineId }.sortedBy { it.orderIndex }
                            val startIdx = sameLine.indexOf(fromSt)
                            val endIdx = sameLine.indexOf(toSt)

                            val step = if (startIdx <= endIdx) 1 else -1
                            var idx = startIdx
                            while (idx != endIdx + step) {
                                legSts.add(sameLine[idx])
                                idx += step
                            }

                            if (legSts.size >= 2) {
                                val legPath = Path()
                                legPath.moveTo(getOffset(legSts.first()).x, getOffset(legSts.first()).y)
                                for (i in 1 until legSts.size) {
                                    legPath.lineTo(getOffset(legSts[i]).x, getOffset(legSts[i]).y)
                                }
                                drawPath(
                                    path = legPath,
                                    color = highlightColor,
                                    style = Stroke(width = 10f / scale, cap = StrokeCap.Round, join = StrokeJoin.Round)
                                )
                            }
                        }
                    }
                }

                // 3. Draw Station Nodes
                for (station in stations) {
                    val pos = getOffset(station)
                    val color = when (station.lineId) {
                        "A" -> Color(0xFFF2780C)
                        "B" -> Color(0xFF007CC0)
                        "C" -> Color(0xFF32A041)
                        else -> Color.Gray
                    }

                    val isInterchange = station.id.startsWith("TERMINI") || station.id.startsWith("SAN_GIOVANNI")
                    val isSelected = selectedStation?.id == station.id

                    if (isInterchange) {
                        // Double rings for intermodal interchange
                        drawCircle(color = Color.White, radius = 9f, center = pos)
                        drawCircle(color = Color.DarkGray, radius = 9f, center = pos, style = Stroke(width = 2.5f))
                        drawCircle(color = Color.White, radius = 4f, center = pos)
                    } else {
                        // Standard station circle
                        drawCircle(color = Color.White, radius = 6f, center = pos)
                        drawCircle(color = color, radius = 6f, center = pos, style = Stroke(width = 2f))
                    }

                    if (isSelected) {
                        // Highlight selected station with gold ring
                        drawCircle(color = Color(0xFFCE9B4E), radius = 13f, center = pos, style = Stroke(width = 3f))
                    }

                    // Labels if zoomed in sufficiently
                    if (scale > 1.2f) {
                        val textLayoutResult = textMeasurer.measure(
                            text = AnnotatedString(station.name),
                            style = TextStyle(
                                color = labelColor,
                                fontSize = (7f / scale).coerceAtLeast(6f).sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        // Offset label to avoid overlap
                        val labelPos = pos + Offset(8f, -4f)
                        drawText(textLayoutResult, topLeft = labelPos)
                    }
                }

                // 4. Draw Simulated Train Indicators
                for (train in trains) {
                    val currentSt = stations.find { it.id == train.currentStationId }
                    val targetSt = stations.find { it.id == train.targetStationId }

                    if (currentSt != null && targetSt != null) {
                        val p1 = getOffset(currentSt)
                        val p2 = getOffset(targetSt)

                        // Interpolated position
                        val trainPos = Offset(
                            p1.x + (p2.x - p1.x) * train.progress,
                            p1.y + (p2.y - p1.y) * train.progress
                        )

                        val trainColor = when (train.lineId) {
                            "A" -> Color(0xFFEF6C00)
                            "B" -> Color(0xFF0D47A1)
                            "C" -> Color(0xFF1B5E20)
                            else -> Color.Black
                        }

                        // Drawing train arrow pulsing marker
                        drawCircle(color = Color.White, radius = 8f, center = trainPos)
                        drawCircle(color = trainColor, radius = 7f, center = trainPos)

                        // If zoomed in, display abbreviated line identifier inside train circle
                        if (scale > 1.4f) {
                            val textLayoutResult = textMeasurer.measure(
                                text = AnnotatedString(train.lineId),
                                style = TextStyle(
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            drawText(
                                textLayoutResult,
                                topLeft = trainPos - Offset(textLayoutResult.size.width / 2f, textLayoutResult.size.height / 2f)
                            )
                        }
                    }
                }
            }
        }

        // Legend overlay (Bottom Left)
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
                .background(
                    MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    shape = MaterialTheme.shapes.medium
                )
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "ROMA METRO.OS",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(12.dp, 4.dp).background(LineaAOrange))
                Text("Linea A (Anagnina - Battistini)", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(12.dp, 4.dp).background(LineaBBlue))
                Text("Linea B (Laurentina - Rebibbia)", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(12.dp, 4.dp).background(LineaCGreen))
                Text("Linea C (San Giovanni - Pantano)", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.size(12.dp, 4.dp).background(Color(0xFFCE9B4E)))
                Text("Percorso Calcolato", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Canvas(modifier = Modifier.size(10.dp)) {
                    drawCircle(color = Color.DarkGray, radius = 5f)
                    drawCircle(color = Color.White, radius = 2f)
                }
                Text("Treno in Simulazione", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
            }
            Text(
                text = "Pizzica per zoomare / Trascina per spostarti",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                fontSize = 9.sp
            )
        }
    }
}
