package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {

    // Lines
    @Query("SELECT * FROM lines")
    fun getAllLinesFlow(): Flow<List<LineEntity>>

    @Query("SELECT * FROM lines")
    suspend fun getAllLines(): List<LineEntity>

    @Query("SELECT * FROM lines WHERE id = :lineId LIMIT 1")
    suspend fun getLineById(lineId: String): LineEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLines(lines: List<LineEntity>)

    @Query("UPDATE lines SET status = :status, statusMessage = :message WHERE id = :lineId")
    suspend fun updateLineStatus(lineId: String, status: LineStatus, message: String)

    // Stations
    @Query("SELECT * FROM stations ORDER BY lineId, orderIndex")
    fun getAllStationsFlow(): Flow<List<StationEntity>>

    @Query("SELECT * FROM stations ORDER BY lineId, orderIndex")
    suspend fun getAllStations(): List<StationEntity>

    @Query("SELECT * FROM stations WHERE lineId = :lineId ORDER BY orderIndex")
    suspend fun getStationsByLine(lineId: String): List<StationEntity>

    @Query("SELECT * FROM stations WHERE id = :stationId LIMIT 1")
    suspend fun getStationById(stationId: String): StationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)

    @Query("UPDATE stations SET currentDemand = :demand WHERE id = :stationId")
    suspend fun updateStationDemand(stationId: String, demand: Double)

    // Trains (Simulated)
    @Query("SELECT * FROM trains")
    fun getAllTrainsFlow(): Flow<List<TrenoEntity>>

    @Query("SELECT * FROM trains")
    suspend fun getAllTrains(): List<TrenoEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrains(trains: List<TrenoEntity>)

    @Query("DELETE FROM trains")
    suspend fun clearTrains()

    // Arrivals
    @Query("SELECT * FROM arrivals WHERE stationId = :stationId ORDER BY estimatedMinutes ASC")
    fun getArrivalsForStationFlow(stationId: String): Flow<List<OrarioArrivoEntity>>

    @Query("SELECT * FROM arrivals WHERE stationId = :stationId ORDER BY estimatedMinutes ASC")
    suspend fun getArrivalsForStation(stationId: String): List<OrarioArrivoEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArrivals(arrivals: List<OrarioArrivoEntity>)

    @Query("DELETE FROM arrivals WHERE stationId = :stationId")
    suspend fun clearArrivalsForStation(stationId: String)

    @Query("DELETE FROM arrivals")
    suspend fun clearAllArrivals()

    // Incidents
    @Query("SELECT * FROM incidents ORDER BY createdAt DESC")
    fun getAllIncidentsFlow(): Flow<List<IncidentEntity>>

    @Query("SELECT * FROM incidents ORDER BY createdAt DESC")
    suspend fun getAllIncidents(): List<IncidentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncidents(incidents: List<IncidentEntity>)

    @Query("DELETE FROM incidents WHERE id = :id")
    suspend fun deleteIncident(id: String)

    @Query("DELETE FROM incidents")
    suspend fun clearAllIncidents()

    // Places / Places of Interest
    @Query("SELECT * FROM places")
    fun getAllPlacesFlow(): Flow<List<LuogoEntity>>

    @Query("SELECT * FROM places")
    suspend fun getAllPlaces(): List<LuogoEntity>

    @Query("SELECT * FROM places WHERE category = :category")
    suspend fun getPlacesByCategory(category: String): List<LuogoEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaces(places: List<LuogoEntity>)

    // Saved Routes
    @Query("SELECT * FROM saved_routes ORDER BY savedAt DESC")
    fun getAllSavedRoutesFlow(): Flow<List<SavedRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedRoute(route: SavedRouteEntity)

    @Query("DELETE FROM saved_routes WHERE id = :id")
    suspend fun deleteSavedRoute(id: String)

    @Query("SELECT EXISTS(SELECT 1 FROM saved_routes WHERE fromStationId = :fromId AND toStationId = :toId LIMIT 1)")
    suspend fun isRouteSaved(fromId: String, toId: String): Boolean

    // Fares / Tariffe
    @Query("SELECT * FROM fares ORDER BY price ASC")
    fun getAllFaresFlow(): Flow<List<FareProductEntity>>

    @Query("SELECT * FROM fares ORDER BY price ASC")
    suspend fun getAllFares(): List<FareProductEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFares(fares: List<FareProductEntity>)
}
