package com.example.data.fixtures

import com.example.data.model.*

object MetroFixtures {

    val lines = listOf(
        LineEntity(
            id = "A",
            name = "Linea A",
            code = "A",
            color = "#FF9A00", // Orange
            status = LineStatus.REGOLARE,
            statusMessage = "Servizio regolare sull'intera linea."
        ),
        LineEntity(
            id = "B",
            name = "Linea B",
            code = "B",
            color = "#007FFF", // Cobalt Blue
            status = LineStatus.REGOLARE,
            statusMessage = "Servizio regolare."
        ),
        LineEntity(
            id = "C",
            name = "Linea C",
            code = "C",
            color = "#4C9F38", // Green
            status = LineStatus.REGOLARE,
            statusMessage = "Servizio regolare."
        )
    )

    val stations = listOf(
        // LINE A Stations (from West to East)
        StationEntity("BATTISTINI", "Battistini", "A", 41.9063, 12.4148, "BAT", 1, true, true, true, 0.35, exitsJson = "Via di Boccea;Via Ennio Bonifazi"),
        StationEntity("CORNELIA", "Cornelia", "A", 41.9009, 12.4263, "COR", 2, true, true, true, 0.45, exitsJson = "Piazza dei Giureconsulti;Circonvallazione Cornelia"),
        StationEntity("BALDO_DEGLI_UBALDI", "Baldo degli Ubaldi", "A", 41.8996, 12.4354, "BAL", 3, true, true, true, 0.30, exitsJson = "Via Baldo degli Ubaldi;Via della Meloria"),
        StationEntity("VALLE_AURELIA", "Valle Aurelia", "A", 41.9026, 12.4418, "VAL", 4, true, true, true, 0.40, exitsJson = "Via Angelo Emo;Centro Commerciale Aura"),
        StationEntity("CIPRO", "Cipro", "A", 41.9075, 12.4476, "CIP", 5, true, true, true, 0.50, exitsJson = "Via Cipro;Piazzale degli Eroi"),
        StationEntity("OTTAVIANO", "Ottaviano (San Pietro)", "A", 41.9091, 12.4580, "OTT", 6, false, true, false, 0.85, exitsJson = "Via Giulio Cesare;Via Ottaviano"),
        StationEntity("LEPANTO", "Lepanto", "A", 41.9114, 12.4667, "LEP", 7, false, true, false, 0.55, exitsJson = "Viale delle Milizie;Via Marcantonio Colonna"),
        StationEntity("FLAMINIO", "Flaminio (Piazza del Popolo)", "A", 41.9126, 12.4764, "FLA", 8, false, true, false, 0.80, exitsJson = "Piazza del Popolo;Villa Borghese"),
        StationEntity("SPAGNA", "Spagna", "A", 41.9060, 12.4828, "SPA", 9, true, true, true, 0.90, exitsJson = "Piazza di Spagna;Vicolo del Bottino;Pincio"),
        StationEntity("BARBERINI", "Barberini (Fontana di Trevi)", "A", 41.9038, 12.4883, "BAR", 10, false, true, false, 0.88, exitsJson = "Piazza Barberini;Via Veneto"),
        StationEntity("REPUBBLICA", "Repubblica (Teatro dell'Opera)", "A", 41.9030, 12.4960, "REP", 11, false, true, false, 0.65, exitsJson = "Piazza della Repubblica;Via Nazionale"),
        StationEntity("TERMINI_A", "Termini (A)", "A", 41.9014, 12.5018, "TER", 12, true, true, true, 0.98, exitsJson = "Piazza dei Cinquecento;Via Giolitti;Via Marsala"),
        StationEntity("VITTORIO_EMANUELE", "Vittorio Emanuele", "A", 41.8953, 12.5042, "VIT", 13, false, true, false, 0.50, exitsJson = "Piazza Vittorio Emanuele II;Via Principe Amedeo"),
        StationEntity("MANZONI", "Manzoni", "A", 41.8911, 12.5061, "MAN", 14, true, true, true, 0.40, exitsJson = "Viale Manzoni;Via Emanuele Filiberto"),
        StationEntity("SAN_GIOVANNI_A", "San Giovanni (A)", "A", 41.8848, 12.5097, "SGI", 15, true, true, true, 0.75, exitsJson = "Piazzale Appio;Via Taranto;Via Sannio"),
        StationEntity("RE_DI_ROMA", "Re di Roma", "A", 41.8819, 12.5134, "RDR", 16, true, true, true, 0.42, exitsJson = "Piazza Re di Roma;Via Albalonga"),
        StationEntity("PONTE_LUNGO", "Ponte Lungo", "A", 41.8785, 12.5186, "PTL", 17, true, true, true, 0.48, exitsJson = "Via Appia Nuova;Stazione Tuscolana"),
        StationEntity("FURIO_CAMILLO", "Furio Camillo", "A", 41.8753, 12.5228, "FUR", 18, true, true, true, 0.38, exitsJson = "Via Cesare Baronio;Viale Furio Camillo"),
        StationEntity("COLLI_ALBANI", "Colli Albani", "A", 41.8694, 12.5303, "COL", 19, true, true, true, 0.40, exitsJson = "Largo dei Colli Albani;Via Appia Nuova"),
        StationEntity("PORTA_FURBA", "Porta Furba Quadraro", "A", 41.8647, 12.5372, "PFU", 20, false, false, false, 0.30, exitsJson = "Via Tuscolana;Vicolo di Porta Furba"),
        StationEntity("NUMIDIO_QUADRATO", "Numidio Quadrato", "A", 41.8619, 12.5434, "NQU", 21, false, false, false, 0.32, exitsJson = "Via Tuscolana;Via dei Consoli"),
        StationEntity("LUCIO_SESTIO", "Lucio Sestio", "A", 41.8592, 12.5492, "LSE", 22, false, false, false, 0.34, exitsJson = "Via Tuscolana;Via Lucio Sestio"),
        StationEntity("GIULIO_AGRICOLA", "Giulio Agricola", "A", 41.8564, 12.5550, "GAG", 23, false, false, false, 0.36, exitsJson = "Via Tuscolana;Viale Giulio Agricola"),
        StationEntity("SUBAUGUSTA", "Subaugusta", "A", 41.8540, 12.5601, "SUB", 24, true, true, true, 0.40, exitsJson = "Piazza di Cinecittà;Circonvallazione Tuscolana"),
        StationEntity("CINECITTA", "Cinecittà", "A", 41.8491, 12.5701, "CIN", 25, true, true, true, 0.45, exitsJson = "Via Tuscolana (Cinecittà);Studi di Cinecittà"),
        StationEntity("ANAGNINA", "Anagnina", "A", 41.8419, 12.5855, "ANA", 26, true, true, true, 0.70, exitsJson = "Terminal Bus;Via Tuscolana;Via Anagnina"),

        // LINE B Stations (from South to North)
        StationEntity("LAURENTINA", "Laurentina", "B", 41.8273, 12.4807, "LAU", 1, true, true, true, 0.65, exitsJson = "Viale Laurentina;Via di Vigna Murata;Terminal Bus"),
        StationEntity("EUR_FERMI", "EUR Fermi", "B", 41.8288, 12.4709, "FER", 2, true, true, true, 0.55, exitsJson = "Viale America;Viale Shakespeare"),
        StationEntity("EUR_PALASPORT", "EUR Palasport", "B", 41.8289, 12.4616, "PAL", 3, true, true, true, 0.50, exitsJson = "Viale America;Lago dell'EUR"),
        StationEntity("EUR_MAGLIANA", "EUR Magliana", "B", 41.8385, 12.4636, "MAG", 4, true, true, true, 0.60, exitsJson = "Via di Val Fiorita;Ostia Lido Line"),
        StationEntity("MARCONI", "Marconi", "B", 41.8475, 12.4716, "MAR", 5, true, true, true, 0.48, exitsJson = "Viale Marconi;Via Ostiense"),
        StationEntity("BASILICA_SAN_PAOLO", "Basilica San Paolo", "B", 41.8560, 12.4787, "SPA", 6, true, true, true, 0.58, exitsJson = "Via Ostiense;Viale di San Paolo"),
        StationEntity("GARBATELLA", "Garbatella", "B", 41.8672, 12.4822, "GAR", 7, true, true, true, 0.52, exitsJson = "Via Giacinto Pullino;Piazza Giancarlo Vallauri"),
        StationEntity("PIRAMIDE", "Piramide", "B", 41.8758, 12.4824, "PIR", 8, true, true, true, 0.78, exitsJson = "Piazzale Ostiense;Stazione Porta San Paolo"),
        StationEntity("CIRCO_MASSIMO", "Circo Massimo", "B", 41.8837, 12.4874, "CMA", 9, true, true, true, 0.65, exitsJson = "Viale Aventino;Via dei Cerchi"),
        StationEntity("COLOSSEO", "Colosseo", "B", 41.8906, 12.4928, "COL", 10, false, true, false, 0.95, exitsJson = "Piazza del Colosseo;Via dei Fori Imperiali"),
        StationEntity("CAVOUR", "Cavour", "B", 41.8949, 12.4934, "CAV", 11, false, false, false, 0.58, exitsJson = "Via Cavour;Via in Selci"),
        StationEntity("TERMINI_B", "Termini (B)", "B", 41.9014, 12.5018, "TER", 12, true, true, true, 0.98, exitsJson = "Piazza dei Cinquecento;Via Giolitti;Via Marsala"),
        StationEntity("CASTRO_PRETORIO", "Castro Pretorio", "B", 41.9061, 12.5056, "CAS", 13, true, true, true, 0.48, exitsJson = "Viale Castro Pretorio;Biblioteca Nazionale"),
        StationEntity("POLICLINICO", "Policlinico", "B", 41.9080, 12.5113, "POL", 14, false, true, false, 0.62, exitsJson = "Viale Regina Margherita;Piazza Sassari"),
        StationEntity("BOLOGNA", "Bologna", "B", 41.9129, 12.5208, "BOL", 15, true, true, true, 0.70, exitsJson = "Piazza Bologna;Viale XXI Aprile"),
        StationEntity("TIBURTINA", "Tiburtina", "B", 41.9099, 12.5312, "TIB", 16, true, true, true, 0.82, exitsJson = "Piazzale della Stazione Tiburtina;Largo Guido Mazzoni"),
        StationEntity("QUINTILIANI", "Quintiliani", "B", 41.9142, 12.5385, "QUI", 17, true, true, true, 0.15, exitsJson = "Via della Pietra Sanguigna"),
        StationEntity("MONTI_TIBURTINI", "Monti Tiburtini", "B", 41.9168, 12.5487, "MTI", 18, true, true, true, 0.40, exitsJson = "Via dei Monti Tiburtini;Via Durantini"),
        StationEntity("PIETRALATA", "Pietralata", "B", 41.9150, 12.5568, "PIE", 19, true, true, true, 0.38, exitsJson = "Via di Pietralata;Via Silvano"),
        StationEntity("S_MARIA_SOCCORSO", "S. Maria del Soccorso", "B", 41.9118, 12.5668, "SMS", 20, false, true, false, 0.45, exitsJson = "Piazza di Santa Maria del Soccorso;Via Tiburtina"),
        StationEntity("PONTE_MAMMOLO", "Ponte Mammolo", "B", 41.9211, 12.5714, "PMA", 21, true, true, true, 0.62, exitsJson = "Terminal Bus;Viale Palmiro Togliatti"),
        StationEntity("REBIBBIA", "Rebibbia", "B", 41.9270, 12.5721, "REB", 22, true, true, true, 0.68, exitsJson = "Via Tiburtina;Piazza de Cupis"),

        // LINE C Stations (from West to East)
        StationEntity("SAN_GIOVANNI_C", "San Giovanni (C)", "C", 41.8848, 12.5097, "SGI", 1, true, true, true, 0.70, exitsJson = "Largo Brindisi;Piazzale Appio"),
        StationEntity("LODI", "Lodi", "C", 41.8872, 12.5186, "LOD", 2, true, true, true, 0.45, exitsJson = "Via La Spezia;Via Orvieto"),
        StationEntity("PIGNETO", "Pigneto", "C", 41.8889, 12.5273, "PIG", 3, true, true, true, 0.65, exitsJson = "Via del Pigneto;Via Aquila"),
        StationEntity("MALATESTA", "Malatesta", "C", 41.8885, 12.5372, "MAL", 4, true, true, true, 0.42, exitsJson = "Piazza Roberto Malatesta;Via Roberto Malatesta"),
        StationEntity("TEANO", "Teano", "C", 41.8894, 12.5485, "TEA", 5, true, true, true, 0.35, exitsJson = "Via dei Gordiani;Via Teano"),
        StationEntity("GARDENIE", "Gardenie", "C", 41.8879, 12.5570, "GAR", 6, true, true, true, 0.38, exitsJson = "Piazza delle Gardenie;Viale della Primavera"),
        StationEntity("MIRTI", "Mirti", "C", 41.8845, 12.5629, "MIR", 7, true, true, true, 0.40, exitsJson = "Piazza dei Mirti;Via dei Castani"),
        StationEntity("PARCO_CENTOCELLE", "Parco di Centocelle", "C", 41.8753, 12.5670, "PCE", 8, true, true, true, 0.45, exitsJson = "Viale Palmiro Togliatti;Via Casilina"),
        StationEntity("ALESSANDRINO", "Alessandrino", "C", 41.8711, 12.5801, "ALE", 9, true, true, true, 0.48, exitsJson = "Via Casilina;Viale Alessandrino"),
        StationEntity("TORRE_SPACCATA", "Torre Spaccata", "C", 41.8679, 12.5898, "TSP", 10, true, true, true, 0.35, exitsJson = "Via Casilina;Viale dei Romanisti"),
        StationEntity("TORRE_MAURA", "Torre Maura", "C", 41.8629, 12.5975, "TMA", 11, true, true, true, 0.38, exitsJson = "Via Casilina;Via di Torre Maura"),
        StationEntity("GIARDINETTI", "Giardinetti", "C", 41.8548, 12.6092, "GIA", 12, true, true, true, 0.35, exitsJson = "Via Casilina;Via dei Giardinetti"),
        StationEntity("TORRE_ANGELA", "Torre Angela", "C", 41.8521, 12.6179, "TAN", 13, true, true, true, 0.42, exitsJson = "Via Casilina;Viale di Torre Angela"),
        StationEntity("TORRE_GAIA", "Torre Gaia", "C", 41.8491, 12.6270, "TGA", 14, true, true, true, 0.38, exitsJson = "Via Casilina;Via di Tor Vergata"),
        StationEntity("GROTTE_CELONI", "Grotte Celoni", "C", 41.8475, 12.6356, "GCE", 15, true, true, true, 0.50, exitsJson = "Terminal Bus;Via Casilina"),
        StationEntity("PANTANO", "Pantano (Monte Compatri)", "C", 41.8441, 12.6680, "PAN", 16, true, true, true, 0.55, exitsJson = "Via Casilina Km 20;Parcheggio di Scambio")
    )

    val places = listOf(
        // Archaeological sites
        LuogoEntity("COLOSSEO_MON", "Colosseo", "Archeologia", "COLOSSEO", 1, "B", "Prendere l'uscita Piazza del Colosseo. Il monumento si trova direttamente di fronte.", "Il più celebre anfiteatro romano, icona nel mondo."),
        LuogoEntity("FORO_ROMANO", "Foro Romano", "Archeologia", "COLOSSEO", 3, "B", "Prendere l'uscita Via dei Fori Imperiali e percorrere 150m in direzione Piazza Venezia.", "Il centro politico, giuridico e commerciale dell'antica Roma."),
        LuogoEntity("PALATINO", "Palatino", "Archeologia", "COLOSSEO", 5, "B", "Dall'uscita, girare attorno al Colosseo verso Via di San Gregorio. Ingresso a 300 metri.", "Il colle dove fu fondata Roma, sede dei palazzi imperiali."),
        LuogoEntity("CIRCO_MASSIMO_MON", "Circo Massimo", "Archeologia", "CIRCO_MASSIMO", 1, "B", "Prendere l'uscita Viale Aventino. Il parco archeologico si estende subito a destra.", "L'antico circo romano, il più grande edificio per spettacoli della storia."),
        LuogoEntity("TERME_CARACALLA", "Terme di Caracalla", "Archeologia", "CIRCO_MASSIMO", 10, "B", "Uscire su Viale Aventino, percorrere Viale delle Terme di Caracalla a piedi per 800 metri.", "Uno dei più grandi ed intatti complessi termali dell'antichità."),

        // Museums and Vatican
        LuogoEntity("MUSEI_VATICANI", "Musei Vaticani", "Musei", "OTTAVIANO", 8, "A", "Uscire su Via Ottaviano, percorrere Via di Porta Angelica, svoltare a destra su Viale Vaticano.", "Straordinaria raccolta di opere d'arte papali, tra cui la Cappella Sistina."),
        LuogoEntity("SAN_PIETRO", "Basilica di San Pietro", "Monumenti", "OTTAVIANO", 10, "A", "Uscire su Via Ottaviano e percorrere la via dritta per 900 metri fino a Piazza San Pietro.", "Il centro del cattolicesimo, capolavoro di Michelangelo e Bernini."),

        // Landmarks & Piazzas
        LuogoEntity("PIAZZA_SPAGNA", "Piazza di Spagna", "Piazze", "SPAGNA", 1, "A", "Prendere l'uscita diretta Piazza di Spagna. Siete sulla piazza, di fronte alla Scalinata.", "Una delle piazze più famose di Roma con la Fontana della Barcaccia."),
        LuogoEntity("PANTHEON", "Pantheon", "Monumenti", "BARBERINI", 12, "A", "Uscire su Via del Tritone, camminare verso Via del Corso e svoltare su Via dei Pastini.", "Antico tempio romano dedicato a tutte le divinità, celebre per la sua cupola aperta."),
        LuogoEntity("FONTANA_TREVI", "Fontana di Trevi", "Monumenti", "BARBERINI", 8, "A", "Uscire verso Via del Tritone, percorrere Via della Stamperia fino alla fontana.", "La fontana barocca più celebre al mondo, scolpita contro Palazzo Poli."),
        LuogoEntity("PIAZZA_POPOLO", "Piazza del Popolo", "Piazze", "FLAMINIO", 1, "A", "Prendere l'uscita Piazza del Popolo. Siete direttamente all'ingresso nord della piazza.", "Grande piazza monumentale che ospita l'obelisco Flaminio e le chiese gemelle."),
        LuogoEntity("LAGO_EUR", "Parco del Lago dell'EUR", "Parchi", "EUR_PALASPORT", 2, "B", "Svoltare a destra su Viale America, il laghetto artificiale è a soli 100 metri.", "Un oasi di verde artificiale progettata per l'Esposizione Universale del 1942."),

        // Universities
        LuogoEntity("SAPIENZA", "Università Sapienza", "Università", "POLICLINICO", 6, "B", "Prendere l'uscita Viale Regina Margherita e camminare lungo Viale dell'Università per 400 metri.", "La più grande università d'Europa, fondata nel 1303."),
        LuogoEntity("ROMA_TRE", "Università Roma Tre (Lettere)", "Università", "BASILICA_SAN_PAOLO", 5, "B", "Prendere l'uscita Via Ostiense e camminare in direzione di Via Vito Volterra.", "Il polo umanistico della terza università di Roma."),

        // Intermodal and Airport connections
        LuogoEntity("STAZ_TERMINI", "Stazione Roma Termini", "Stazioni", "TERMINI_A", 1, "A", "I binari ferroviari sono accessibili direttamente tramite le scale mobili dall'atrio.", "Il principale scalo ferroviario d'Italia, interscambio Metro A e B."),
        LuogoEntity("STAZ_TIBURTINA", "Stazione Roma Tiburtina", "Stazioni", "TIBURTINA", 2, "B", "Scale mobili collegano direttamente la stazione metro con la galleria vetrata.", "Secondo scalo romano per treni AV e regionali."),
        LuogoEntity("STAZ_OSTIENSE", "Stazione Roma Ostiense", "Stazioni", "PIRAMIDE", 4, "B", "Utilizzare il sottopasso pedonale di collegamento diretto tra Metro Piramide e Binari FS.", "Nodo di interscambio per ferrovie regionali e treni Italo."),
        LuogoEntity("AER_FIUMICINO", "Aeroporto Fiumicino FCO", "Aeroporti", "TERMINI_B", 32, "B", "Prendere il treno non-stop Leonardo Express dal binario 24 della Stazione Termini (32 min).", "Il principale hub aeroportile italiano ed internazionale (intermodale)."),
        LuogoEntity("AER_CIAMPINO", "Aeroporto Ciampino CIA", "Aeroporti", "ANAGNINA", 20, "A", "Prendere il bus navetta ATRAL/COTRAL dal piazzale bus della stazione Anagnina (20 min).", "Scalo romano low-cost per voli nazionali ed europei (intermodale).")
    )

    val fares = listOf(
        FareProductEntity(
            id = "BIT",
            name = "BIT (Biglietto Integrato Tempo)",
            durationMinutes = 100,
            price = 1.50,
            description = "Valido per 100 minuti dalla prima timbratura. Consente un solo viaggio in metropolitana (anche su più linee senza superare i tornelli) ed illimitati viaggi in bus.",
            conditions = "Deve essere convalidato all'accesso."
        ),
        FareProductEntity(
            id = "ROMA24H",
            name = "Roma 24H",
            durationMinutes = 1440,
            price = 7.00,
            description = "Valido per 24 ore dalla prima timbratura per illimitati viaggi nel territorio di Roma Capitale su metro, bus, tram e ferrovie regionali.",
            conditions = "Uso personale e non trasferibile."
        ),
        FareProductEntity(
            id = "ROMA48H",
            name = "Roma 48H",
            durationMinutes = 2880,
            price = 12.50,
            description = "Valido per 48 ore dalla prima timbratura per illimitati viaggi su tutta la rete urbana di Roma.",
            conditions = "Uso personale."
        ),
        FareProductEntity(
            id = "ROMA72H",
            name = "Roma 72H",
            durationMinutes = 4320,
            price = 18.00,
            description = "Valido per 72 ore dalla prima timbratura per viaggiare senza limiti a Roma.",
            conditions = "Uso personale."
        ),
        FareProductEntity(
            id = "CIS",
            name = "CIS (Carta Integrata Settimanale)",
            durationMinutes = 10080,
            price = 24.00,
            description = "Valido per 7 giorni consecutivi fino alle ore 24:00 del settimo giorno compresa la data di convalida.",
            conditions = "Uso personale, scrivere nome e cognome sul supporto cartaceo se non dematerializzato."
        )
    )

    // Helper to get matching physical links
    fun getAdjacentStations(stationId: String, allStations: List<StationEntity>): List<Pair<StationEntity, Double>> {
        val current = allStations.find { it.id == stationId } ?: return emptyList()
        val sameLine = allStations.filter { it.lineId == current.lineId }.sortedBy { it.orderIndex }
        val idx = sameLine.indexOf(current)
        val result = mutableListOf<Pair<StationEntity, Double>>()

        if (idx > 0) {
            val prev = sameLine[idx - 1]
            result.add(prev to 2.0) // Assume 2 minutes between consecutive stations
        }
        if (idx < sameLine.size - 1) {
            val next = sameLine[idx + 1]
            result.add(next to 2.0)
        }

        // Add Interchanges manually
        // Termini_A <-> Termini_B (transfer takes about 3 minutes)
        if (stationId == "TERMINI_A") {
            allStations.find { it.id == "TERMINI_B" }?.let { result.add(it to 3.0) }
        }
        if (stationId == "TERMINI_B") {
            allStations.find { it.id == "TERMINI_A" }?.let { result.add(it to 3.0) }
        }

        // San Giovanni_A <-> San Giovanni_C (transfer takes about 4 minutes)
        if (stationId == "SAN_GIOVANNI_A") {
            allStations.find { it.id == "SAN_GIOVANNI_C" }?.let { result.add(it to 4.0) }
        }
        if (stationId == "SAN_GIOVANNI_C") {
            allStations.find { it.id == "SAN_GIOVANNI_A" }?.let { result.add(it to 4.0) }
        }

        return result
    }
}
