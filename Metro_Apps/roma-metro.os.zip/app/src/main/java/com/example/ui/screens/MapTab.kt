package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MetroViewModel
import com.example.ui.map.MetroMap

@Composable
fun MapTab(viewModel: MetroViewModel) {
    val stations by viewModel.stations.collectAsState()
    val trains by viewModel.trains.collectAsState()
    val activeRouteResult by viewModel.activeRouteResult.collectAsState()
    val selectedStation by viewModel.selectedStationFlow.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "MAPPA INTERATTIVA DELLA RETE",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "TRACCIAMENTO REALE DEI TRENI • DATI SIMULATI",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            MetroMap(
                stations = stations,
                trains = trains,
                activeRoute = activeRouteResult,
                selectedStation = selectedStation,
                onStationSelect = { station ->
                    viewModel.selectStation(station.id)
                }
            )
        }
    }
}
