package com.example.domain.routing

import com.example.data.fixtures.MetroFixtures
import com.example.data.model.StationEntity
import java.util.PriorityQueue

data class RoutingPreference(
    val fastest: Boolean = true,
    val fewestTransfers: Boolean = false,
    val stepFree: Boolean = false, // Solo percorsi senza scale
    val avoidEscalators: Boolean = false,
    val wheelchairAccessible: Boolean = false,
    val avoidCrowded: Boolean = false
)

data class RouteLeg(
    val type: String, // "METRO", "TRANSFER", "WALK"
    val lineId: String?, // Line code (e.g., "A", "B")
    val lineName: String?,
    val lineColor: String?,
    val fromStationId: String,
    val fromStationName: String,
    val toStationId: String,
    val toStationName: String,
    val stopsList: List<String>, // Intermediate stations names
    val durationMinutes: Int
)

data class RouteResult(
    val totalTime: Int,
    val stopsCount: Int,
    val transfersCount: Int,
    val legs: List<RouteLeg>,
    val criterionLabel: String, // "Più veloce", "Meno cambi", "Accessibile"
    val extraDescription: String = ""
)

class MetroRoutingEngine(private val allStations: List<StationEntity>) {

    // Dijkstra state holder
    private class NodeState(
        val stationId: String,
        val lineId: String?,
        val time: Double,
        val stops: Int,
        val transfers: Int,
        val path: List<String>,
        val pathLines: List<String>
    ) : Comparable<NodeState> {
        override fun compareTo(other: NodeState): Int {
            return this.time.compareTo(other.time)
        }
    }

    fun planRoute(
        fromId: String,
        toId: String,
        pref: RoutingPreference,
        closedStations: Set<String> = emptySet(),
        lineDisruptions: Set<String> = emptySet() // e.g. "B" if slowed down
    ): List<RouteResult> {
        val startStation = allStations.find { it.id == fromId } ?: return emptyList()
        val destStation = allStations.find { it.id == toId } ?: return emptyList()

        // We run pathfinding with different weight biases to return multiple alternatives
        val alternatives = mutableListOf<RouteResult>()

        // 1. Primary path matching preferences
        val path1 = runDijkstra(startStation, destStation, pref, closedStations, lineDisruptions)
        if (path1 != null) {
            val label = when {
                pref.wheelchairAccessible -> "Accessibile sedia a rotelle"
                pref.stepFree -> "Senza scale (Ascensori)"
                pref.fewestTransfers -> "Meno cambi"
                else -> "Consigliato (Più veloce)"
            }
            alternatives.add(buildRouteResult(path1, label))
        }

        // 2. Fast alternative if they wanted something else, or "Meno Cambi" alternative
        if (pref.fewestTransfers || pref.stepFree) {
            // Also provide the absolute fastest route as comparison
            val fastPath = runDijkstra(startStation, destStation, RoutingPreference(fastest = true), closedStations, lineDisruptions)
            if (fastPath != null && fastPath.stationIdPath != path1?.stationIdPath) {
                alternatives.add(buildRouteResult(fastPath, "Più veloce"))
            }
        } else {
            // Provide a step-free path or fewest transfers path
            val transferPath = runDijkstra(startStation, destStation, RoutingPreference(fewestTransfers = true), closedStations, lineDisruptions)
            if (transferPath != null && transferPath.stationIdPath != path1?.stationIdPath) {
                alternatives.add(buildRouteResult(transferPath, "Meno cambi"))
            }

            val stepFreePath = runDijkstra(startStation, destStation, RoutingPreference(stepFree = true), closedStations, lineDisruptions)
            if (stepFreePath != null && stepFreePath.stationIdPath != path1?.stationIdPath && stepFreePath.stationIdPath != transferPath?.stationIdPath) {
                alternatives.add(buildRouteResult(stepFreePath, "Accessibile (Senza scale)"))
            }
        }

        return alternatives.distinctBy { it.legs.map { leg -> leg.fromStationId + "_" + leg.toStationId } }
    }

    private class DijkstraOutput(
        val stationIdPath: List<String>,
        val linePath: List<String>,
        val totalTime: Double,
        val totalStops: Int,
        val totalTransfers: Int
    )

    private fun runDijkstra(
        start: StationEntity,
        dest: StationEntity,
        pref: RoutingPreference,
        closedStations: Set<String>,
        lineDisruptions: Set<String>
    ): DijkstraOutput? {
        val pq = PriorityQueue<NodeState>()
        val visited = mutableMapOf<Pair<String, String?>, Double>() // Map representing (StationID, LineID) -> minTime

        // Start states (if it's an interchange, start with its line)
        pq.add(NodeState(start.id, start.lineId, 0.0, 0, 0, listOf(start.id), listOf(start.lineId)))

        while (pq.isNotEmpty()) {
            val curr = pq.poll()
            val visitKey = Pair(curr.stationId, curr.lineId)

            if (visited.containsKey(visitKey) && visited[visitKey]!! <= curr.time) continue
            visited[visitKey] = curr.time

            if (curr.stationId == dest.id) {
                return DijkstraOutput(
                    stationIdPath = curr.path,
                    linePath = curr.pathLines,
                    totalTime = curr.time,
                    totalStops = curr.stops,
                    totalTransfers = curr.transfers
                )
            }

            val stationObj = allStations.find { it.id == curr.stationId } ?: continue

            // Get neighbours
            val adjacent = MetroFixtures.getAdjacentStations(curr.stationId, allStations)
            for ((nextStation, travelTime) in adjacent) {
                if (nextStation.isClosed || closedStations.contains(nextStation.id)) continue

                // Apply accessibility filters
                if (pref.stepFree && !nextStation.hasElevator && !nextStation.isAccessible) continue
                if (pref.wheelchairAccessible && !nextStation.isAccessible) continue
                if (pref.avoidEscalators && nextStation.hasEscalator && !nextStation.hasElevator) continue

                // Calculate edge cost
                var edgeWeight = travelTime

                // Disruptions penalty
                if (lineDisruptions.contains(nextStation.lineId)) {
                    edgeWeight += 4.0 // Add 4 minutes penalty for slowdowns
                }

                // Transfer cost
                val isTransfer = curr.lineId != null && nextStation.lineId != curr.lineId
                var transferPenalty = 0.0
                if (isTransfer) {
                    transferPenalty = if (pref.fewestTransfers) 15.0 else 4.0 // High penalty if fewestTransfers preferred
                }

                val nextTime = curr.time + edgeWeight + transferPenalty
                val nextStops = curr.stops + (if (isTransfer) 0 else 1)
                val nextTransfers = curr.transfers + (if (isTransfer) 1 else 0)

                pq.add(
                    NodeState(
                        stationId = nextStation.id,
                        lineId = nextStation.lineId,
                        time = nextTime,
                        stops = nextStops,
                        transfers = nextTransfers,
                        path = curr.path + nextStation.id,
                        pathLines = curr.pathLines + nextStation.lineId
                    )
                )
            }
        }
        return null
    }

    private fun buildRouteResult(out: DijkstraOutput, criteria: String): RouteResult {
        val legs = mutableListOf<RouteLeg>()
        if (out.stationIdPath.isEmpty()) {
            return RouteResult(0, 0, 0, emptyList(), criteria)
        }

        var currentLegType = "METRO"
        var currentLineId = out.linePath.first()
        var legStartIdx = 0

        val size = out.stationIdPath.size
        for (i in 1 until size) {
            val prevId = out.stationIdPath[i - 1]
            val currId = out.stationIdPath[i]
            val prevLine = out.linePath[i - 1]
            val currLine = out.linePath[i]

            val isTransfer = prevLine != currLine && (prevId.startsWith("TERMINI") && currId.startsWith("TERMINI") || prevId.startsWith("SAN_GIOVANNI") && currId.startsWith("SAN_GIOVANNI"))

            if (isTransfer) {
                // Add the preceding metro leg
                if (i - 1 > legStartIdx) {
                    legs.add(createMetroLeg(out.stationIdPath.subList(legStartIdx, i), prevLine))
                }
                // Add transfer leg
                val fromStObj = allStations.find { it.id == prevId }!!
                val toStObj = allStations.find { it.id == currId }!!
                legs.add(
                    RouteLeg(
                        type = "TRANSFER",
                        lineId = null,
                        lineName = null,
                        lineColor = null,
                        fromStationId = prevId,
                        fromStationName = fromStObj.name,
                        toStationId = currId,
                        toStationName = toStObj.name,
                        stopsList = emptyList(),
                        durationMinutes = if (prevId.startsWith("TERMINI")) 3 else 4
                    )
                )
                legStartIdx = i
                currentLineId = currLine
            } else if (prevLine != currLine) {
                // Inline physical swap (e.g. at the same platform, should be modeled as leg split)
                if (i - 1 > legStartIdx) {
                    legs.add(createMetroLeg(out.stationIdPath.subList(legStartIdx, i), prevLine))
                }
                legStartIdx = i - 1
                currentLineId = currLine
            }
        }

        // Add the final metro leg
        if (size > legStartIdx) {
            legs.add(createMetroLeg(out.stationIdPath.subList(legStartIdx, size), currentLineId))
        }

        val totalTimeMinutes = out.totalTime.toInt()
        val totalStops = legs.filter { it.type == "METRO" }.sumOf { it.stopsList.size + 1 }

        return RouteResult(
            totalTime = totalTimeMinutes,
            stopsCount = totalStops,
            transfersCount = out.totalTransfers,
            legs = legs,
            criterionLabel = criteria,
            extraDescription = when (out.totalTransfers) {
                0 -> "Nessun cambio"
                1 -> "1 cambio"
                else -> "${out.totalTransfers} cambi"
            }
        )
    }

    private fun createMetroLeg(stationIds: List<String>, lineId: String): RouteLeg {
        val fromId = stationIds.first()
        val toId = stationIds.last()
        val fromSt = allStations.find { it.id == fromId }!!
        val toSt = allStations.find { it.id == toId }!!

        val lineDetails = MetroFixtures.lines.find { it.id == lineId }
        val lineColor = lineDetails?.color ?: "#7F7F7F"
        val lineName = lineDetails?.name ?: "Linea $lineId"

        val intermediateNames = if (stationIds.size > 2) {
            stationIds.subList(1, stationIds.size - 1).map { id -> allStations.find { it.id == id }?.name ?: id }
        } else {
            emptyList()
        }

        // Estimated travel duration (2 minutes per hop)
        val duration = (stationIds.size - 1) * 2

        return RouteLeg(
            type = "METRO",
            lineId = lineId,
            lineName = lineName,
            lineColor = lineColor,
            fromStationId = fromId,
            fromStationName = fromSt.name,
            toStationId = toId,
            toStationName = toSt.name,
            stopsList = intermediateNames,
            durationMinutes = duration
        )
    }
}
