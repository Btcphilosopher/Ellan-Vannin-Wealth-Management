package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fixtures.MetroFixtures
import com.example.domain.routing.RouteLeg
import com.example.domain.routing.RouteResult
import com.example.ui.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RouteTab(viewModel: MetroViewModel) {
    val stations by viewModel.stations.collectAsState()
    val selectedFrom by viewModel.selectedFromStation.collectAsState()
    val selectedTo by viewModel.selectedToStation.collectAsState()
    val plannedRoutes by viewModel.plannedRoutesList.collectAsState()
    val activeRoute by viewModel.activeRouteResult.collectAsState()
    val activeLegIndex by viewModel.activeLegProgressIndex.collectAsState()
    val routingPref by viewModel.routingPref.collectAsState()
    val weather by viewModel.weather.collectAsState()

    var isNavigating by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NAVIGAZIONE E PERCORSI",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "MOTORE DI ROUTING DETERMINISTICO",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                // Weather Widget
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.clickable {
                        // Cycles weather options
                        val next = when (weather.description) {
                            "Soleggiato" -> "Pioggia"
                            "Pioggia" -> "Caldo Intenso"
                            else -> "Soleggiato"
                        }
                        viewModel.updateWeatherCondition(next)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when (weather.description) {
                                "Pioggia" -> Icons.Default.Cloud
                                "Caldo Intenso" -> Icons.Default.WbSunny
                                else -> Icons.Default.WbSunny
                            },
                            contentDescription = "Meteo",
                            tint = if (weather.description == "Caldo Intenso") AlertOrange else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("${weather.tempCelsius}°C", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Selected endpoints summary
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MyLocation, contentDescription = "From", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = selectedFrom?.name ?: "Seleziona punto di partenza...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Divider(modifier = Modifier.padding(start = 28.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Place, contentDescription = "To", modifier = Modifier.size(16.dp), tint = AlertRed)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = selectedTo?.name ?: "Seleziona destinazione...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Routing Preferences Filters
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Fastest filter
                FilterChip(
                    selected = routingPref.fastest,
                    onClick = { viewModel.toggleRoutingPref("fastest") },
                    label = { Text("Più veloce") }
                )
                // Fewest transfers
                FilterChip(
                    selected = routingPref.fewestTransfers,
                    onClick = { viewModel.toggleRoutingPref("fewestTransfers") },
                    label = { Text("Meno cambi") }
                )
                // Step Free
                FilterChip(
                    selected = routingPref.stepFree,
                    onClick = { viewModel.toggleRoutingPref("stepFree") },
                    label = { Text("Senza scale") }
                )
            }
        }

        // Weather Warning alert recommendation
        if (weather.description != "Soleggiato") {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AlertRed.copy(alpha = 0.3f), MaterialTheme.shapes.medium)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Warning", tint = AlertRed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                "IMPATTO AMBIENTALE SULLA ROTTA (${weather.description.uppercase()})",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = AlertRed
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                weather.recommendation,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (weather.description == "Caldo Intenso") {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "Rotta alternativa consigliata: +3 min. Tratta sotterranea climatizzata, risparmiati 6 min all'aperto.",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }

        if (plannedRoutes.isEmpty()) {
            item {
                Text(
                    "Nessun percorso calcolato. Seleziona partenza e destinazione diverse per iniziare.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp)
                )
            }
        } else {
            // Alternative Results Selector
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "PERCORSI DISPONIBILI",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )

                    plannedRoutes.forEach { route ->
                        val isSelected = activeRoute == route
                        val borderColor = if (isSelected) Color(0xFFCE9B4E) else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        val elevation = if (isSelected) 4.dp else 1.dp

                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(elevation),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectActiveRoute(route) }
                                .border(1.5.dp, borderColor, MaterialTheme.shapes.medium)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            "${route.totalTime} MIN",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Box(
                                            modifier = Modifier
                                                .background(MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.extraSmall)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                route.criterionLabel.uppercase(),
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    // Legs summary graphic
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        route.legs.forEachIndexed { idx, leg ->
                                            if (idx > 0) {
                                                Icon(Icons.Default.ChevronRight, contentDescription = "then", modifier = Modifier.size(12.dp))
                                            }
                                            if (leg.type == "METRO") {
                                                Box(
                                                    modifier = Modifier
                                                        .background(Color(android.graphics.Color.parseColor(leg.lineColor ?: "#808080")), shape = MaterialTheme.shapes.extraSmall)
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        leg.lineId ?: "",
                                                        color = Color.White,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 10.sp
                                                    )
                                                }
                                            } else if (leg.type == "TRANSFER") {
                                                Icon(Icons.Default.CompareArrows, contentDescription = "Transfer", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.secondary)
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "${route.stopsCount} fermate • ${route.extraDescription}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Selected",
                                        tint = Color(0xFFCE9B4E)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Expanded detail for selected active route
            activeRoute?.let { route ->
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Dettaglio Percorso Selezionato",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                IconButton(onClick = { viewModel.saveActiveRoute() }) {
                                    Icon(Icons.Default.BookmarkBorder, contentDescription = "Salva rotta", tint = MaterialTheme.colorScheme.secondary)
                                }
                            }

                            // Dynamic Journey Status if traveling
                            if (isNavigating) {
                                val currentLeg = route.legs[activeLegIndex]
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            "NAVIGAZIONE ATTIVA • PASSO ${activeLegIndex + 1} DI ${route.legs.size}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            if (currentLeg.type == "METRO") "Sali sul treno Linea ${currentLeg.lineId} in direzione ${currentLeg.toStationName}"
                                            else "Effettua l'interscambio a piedi per raggiungere le banchine",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                "Arrivo stimato: ${currentLeg.durationMinutes} min",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSecondaryContainer
                                            )
                                            Button(
                                                onClick = {
                                                    if (activeLegIndex < route.legs.size - 1) {
                                                        viewModel.advanceRouteLegProgress()
                                                    } else {
                                                        isNavigating = false
                                                        viewModel.resetRouteLegProgress()
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                            ) {
                                                Text(if (activeLegIndex < route.legs.size - 1) "Prossima Tratta" else "Arrivato!")
                                            }
                                        }
                                    }
                                }
                            }

                            // Iterating path legs
                            route.legs.forEachIndexed { index, leg ->
                                val isLegActive = isNavigating && index == activeLegIndex
                                val legColor = if (isLegActive) Color(0xFFCE9B4E) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(if (isLegActive) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else Color.Transparent)
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    // Visual node indicator
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .background(
                                                    if (leg.type == "METRO") Color(android.graphics.Color.parseColor(leg.lineColor ?: "#808080")) else Color.Gray,
                                                    shape = MaterialTheme.shapes.extraSmall
                                                )
                                        )
                                        Box(
                                            modifier = Modifier
                                                .width(2.dp)
                                                .height(48.dp)
                                                .background(legColor)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(16.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            leg.fromStationName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = if (leg.type == "METRO") "Prendere Metropolitana Linea ${leg.lineId} (${leg.durationMinutes} min, ${leg.stopsList.size + 1} fermate)"
                                            else "Interscambio a piedi (${leg.durationMinutes} min)",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        if (leg.stopsList.isNotEmpty()) {
                                            Text(
                                                "Fermate intermedie: " + leg.stopsList.joinToString(", "),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(top = 4.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            leg.toStationName,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Start Journey Button
                            if (!isNavigating) {
                                Button(
                                    onClick = {
                                        isNavigating = true
                                        viewModel.resetRouteLegProgress()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("start_journey_button")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Start")
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("AVVIA PERCORSO")
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
