package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class DataSourceType {
    LIVE, REFERENCE, SYNTHETIC, SIMULATED, UNKNOWN
}

enum class LineStatus {
    REGOLARE, RALLENTAMENTI, INTERRUZIONE, SERVIZIO_MODIFICATO
}

enum class IncidentSeverity {
    INFO, WARNING, CRITICAL
}

@Entity(tableName = "lines")
data class LineEntity(
    @PrimaryKey val id: String, // e.g., "A", "B", "C"
    val name: String, // e.g., "Linea A"
    val code: String, // "A"
    val color: String, // Hex color
    val status: LineStatus,
    val statusMessage: String,
    val source: String = "METRO.OS Core Engine",
    val sourceType: DataSourceType = DataSourceType.SIMULATED,
    val retrievedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String, // e.g., "TERMINI_A", "COLOSSEO"
    val name: String,
    val lineId: String, // Which line it belongs to
    val latitude: Double,
    val longitude: Double,
    val code: String, // e.g., "TRM", "COL"
    val orderIndex: Int, // Position along the line
    val hasElevator: Boolean,
    val hasEscalator: Boolean,
    val isAccessible: Boolean,
    val currentDemand: Double, // Passenger density 0.0 - 1.0
    val isClosed: Boolean = false,
    val exitsJson: String = "", // Semicolon separated exit names
    val platformCount: Int = 2
)

@Entity(tableName = "trains")
data class TrenoEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val lineId: String,
    val direction: String, // e.g., "Laurentina", "Battistini"
    val currentStationId: String,
    val targetStationId: String,
    val progress: Float, // 0.0f to 1.0f between current and target
    val speedKmh: Float,
    val status: String, // "IN_MOVIMENTO", "FERMO_IN_STAZIONE", "RITARDATO"
    val demandLevel: String, // "BASSA", "MEDIA", "ALTA", "MASSIMA"
    val passengerCount: Int,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "arrivals")
data class OrarioArrivoEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val stationId: String,
    val lineId: String,
    val direction: String,
    val estimatedMinutes: Int,
    val platform: String,
    val timestamp: Long = System.currentTimeMillis(),
    val source: String = "SIMULATOR_ENGINE",
    val sourceType: DataSourceType = DataSourceType.SIMULATED,
    val simulationRunId: String = "SIM-2026"
)

@Entity(tableName = "incidents")
data class IncidentEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val lineId: String,
    val title: String,
    val description: String,
    val severity: IncidentSeverity,
    val status: String, // "ATTIVO", "RISOLTO", "IN_GESTIONE"
    val stationsAffected: String, // Semicolon separated list of station IDs
    val alternativeRouteDesc: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "places")
data class LuogoEntity(
    @PrimaryKey val id: String, // e.g., "COLOSSEO_MON"
    val name: String,
    val category: String, // Archeologia, Monumenti, Musei, Università, Parchi, Shopping, Stazioni, Aeroporti
    val nearestStationId: String,
    val walkTimeMinutes: Int,
    val lineCode: String,
    val recommendedPath: String,
    val description: String = ""
)

@Entity(tableName = "saved_routes")
data class SavedRouteEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val fromStationId: String,
    val toStationId: String,
    val fromStationName: String,
    val toStationName: String,
    val preferencesJson: String, // serialized routing preferences
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "fares")
data class FareProductEntity(
    @PrimaryKey val id: String, // e.g., "BIT", "ROMA24"
    val name: String,
    val durationMinutes: Int,
    val price: Double,
    val description: String,
    val conditions: String,
    val validityZone: String = "Zona Metrebus Roma",
    val dataSource: String = "ATAC Tariffe Ufficiali Dati Esempio",
    val lastUpdated: Long = System.currentTimeMillis()
)
