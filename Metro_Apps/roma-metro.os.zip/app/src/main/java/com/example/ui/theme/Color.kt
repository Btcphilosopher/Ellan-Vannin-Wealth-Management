package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Travertino & Stone Warm Theme (Light Mode)
val TravertinoWhite = Color(0xFFFAF8F5) // Extremely soft warm ivory
val TravertinoCream = Color(0xFFF3ECE0) // Soft sand/marble
val PietraGray = Color(0xFFE2DDD5)      // Travertine stone gray
val BasaltBlack = Color(0xFF232221)     // Soft basalt charcoal
val AnthraciteDark = Color(0xFF1E1E1C)  // Dark slate stone
val SoftWhite = Color(0xFFFCFAF7)

// Line Colors (Rome Transit System)
val LineaAOrange = Color(0xFFF2780C)    // Linea A Orange
val LineaBBlue = Color(0xFF007CC0)      // Linea B Cobalt Blue
val LineaCGreen = Color(0xFF32A041)     // Linea C Green

// Functional Accent Colors
val AccentRust = Color(0xFFA14923)      // Classic Roman Terracotta
val AccentGold = Color(0xFFCE9B4E)      // Roman Imperial Gold
val AlertRed = Color(0xFFC62828)        // Pompeii Red for alerts
val SuccessEmerald = Color(0xFF2E7D32)  // Clean green for normal state
val AlertOrange = Color(0xFFEF6C00)     // Slowdown alert orange

// Dark Mode Colors
val DarkBasalt = Color(0xFF121211)      // Ultra-dark basalt
val DarkSurface = Color(0xFF1C1C1A)     // Dark stone card background
val DarkBorder = Color(0xFF2A2A28)      // Dark slate border
val DarkTextPrimary = Color(0xFFEBE6DD) // Warm bone text
val DarkTextSecondary = Color(0xFF9E988E) // Stone ash text
