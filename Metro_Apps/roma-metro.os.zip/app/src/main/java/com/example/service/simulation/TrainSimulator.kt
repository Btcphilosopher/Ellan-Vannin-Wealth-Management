package com.example.service.simulation

import android.util.Log
import com.example.data.fixtures.MetroFixtures
import com.example.data.model.*
import com.example.data.repository.MetroRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Random

enum class SimScenario {
    NORMALE, ORA_DI_PUNTA, BASSA_DOMANDA, RITARDO, DISSERVIZIO, RECUPERO
}

class TrainSimulator(private val repository: MetroRepository) {

    companion object {
        private const val TAG = "TrainSimulator"
    }

    private val _currentScenario = MutableStateFlow(SimScenario.NORMALE)
    val currentScenario: StateFlow<SimScenario> = _currentScenario

    private val _simTimeMinutes = MutableStateFlow(420) // Start at 07:00 AM (420 minutes from midnight)
    val simTimeMinutes: StateFlow<Int> = _simTimeMinutes

    private var random = Random(42) // Fixed seed 42 as default for deterministic behavior
    private var isRunning = false
    private val activeTrains = mutableListOf<TrenoEntity>()

    fun setScenario(scenario: SimScenario, seed: Long = 42) {
        _currentScenario.value = scenario
        random = Random(seed)
        Log.d(TAG, "Scenario set to $scenario with seed $seed")
        // Re-initialize trains according to the scenario
        initializeSimulation()
    }

    fun incrementTime(minutesDelta: Int) {
        _simTimeMinutes.value = (_simTimeMinutes.value + minutesDelta) % 1440
        tickSimulation()
    }

    fun initializeSimulation() {
        activeTrains.clear()
        val stations = MetroFixtures.stations
        val lines = MetroFixtures.lines

        // For each line, we place multiple trains in both directions
        val densityFactor = when (_currentScenario.value) {
            SimScenario.ORA_DI_PUNTA -> 4
            SimScenario.BASSA_DOMANDA -> 1
            SimScenario.RITARDO -> 2
            SimScenario.DISSERVIZIO -> 2
            SimScenario.RECUPERO -> 3
            else -> 2 // Normale
        }

        for (line in lines) {
            val lineStations = stations.filter { it.lineId == line.id }.sortedBy { it.orderIndex }
            if (lineStations.isEmpty()) continue

            val forwardTerminalName = lineStations.last().name
            val backwardTerminalName = lineStations.first().name

            // Forward trains
            for (i in 0 until densityFactor) {
                val index = (i * (lineStations.size / densityFactor)) % lineStations.size
                val currentSt = lineStations[index]
                val targetSt = lineStations[(index + 1) % lineStations.size]

                val demand = getScenarioDemand()
                val passengerCount = (demand * 300 * (0.8 + random.nextDouble() * 0.4)).toInt().coerceIn(10, 500)

                activeTrains.add(
                    TrenoEntity(
                        id = "${line.id}-F-$i",
                        lineId = line.id,
                        direction = forwardTerminalName,
                        currentStationId = currentSt.id,
                        targetStationId = targetSt.id,
                        progress = random.nextFloat().coerceIn(0.0f, 0.9f),
                        speedKmh = getScenarioSpeed(),
                        status = "IN_MOVIMENTO",
                        demandLevel = getDemandLevelLabel(demand),
                        passengerCount = passengerCount
                    )
                )
            }

            // Backward trains
            for (i in 0 until densityFactor) {
                val index = (i * (lineStations.size / densityFactor)) % lineStations.size
                val currentSt = lineStations[index]
                val targetSt = lineStations[if (index - 1 < 0) lineStations.size - 1 else index - 1]

                val demand = getScenarioDemand()
                val passengerCount = (demand * 300 * (0.8 + random.nextDouble() * 0.4)).toInt().coerceIn(10, 500)

                activeTrains.add(
                    TrenoEntity(
                        id = "${line.id}-B-$i",
                        lineId = line.id,
                        direction = backwardTerminalName,
                        currentStationId = currentSt.id,
                        targetStationId = targetSt.id,
                        progress = random.nextFloat().coerceIn(0.0f, 0.9f),
                        speedKmh = getScenarioSpeed(),
                        status = "IN_MOVIMENTO",
                        demandLevel = getDemandLevelLabel(demand),
                        passengerCount = passengerCount
                    )
                )
            }
        }
    }

    private fun getScenarioSpeed(): Float {
        return when (_currentScenario.value) {
            SimScenario.RITARDO -> 32.0f
            SimScenario.DISSERVIZIO -> 28.0f
            SimScenario.RECUPERO -> 52.0f
            SimScenario.BASSA_DOMANDA -> 48.0f
            else -> 42.0f // Normale
        }
    }

    private fun getScenarioDemand(): Double {
        return when (_currentScenario.value) {
            SimScenario.ORA_DI_PUNTA -> 0.85
            SimScenario.BASSA_DOMANDA -> 0.20
            SimScenario.RITARDO -> 0.75
            SimScenario.DISSERVIZIO -> 0.90
            else -> 0.50 // Normale
        }
    }

    private fun getDemandLevelLabel(demand: Double): String {
        return when {
            demand < 0.3 -> "BASSA"
            demand < 0.6 -> "MEDIA"
            demand < 0.85 -> "ALTA"
            else -> "MASSIMA"
        }
    }

    // Advance the train states deterministically
    fun tickSimulation() {
        val stations = MetroFixtures.stations
        val updatedTrains = mutableListOf<TrenoEntity>()
        val generatedArrivals = mutableListOf<OrarioArrivoEntity>()

        val isDelayedDisruption = _currentScenario.value == SimScenario.DISSERVIZIO || _currentScenario.value == SimScenario.RITARDO

        for (train in activeTrains) {
            val lineStations = stations.filter { it.lineId == train.lineId }.sortedBy { it.orderIndex }
            if (lineStations.isEmpty()) continue

            var status = train.status
            var progress = train.progress
            var currentStId = train.currentStationId
            var targetStId = train.targetStationId
            var currentSpeed = train.speedKmh

            // Check if there is an active disruption affecting this segment (Line B Cavour/Colosseo)
            val inDisruptedArea = isDelayedDisruption && train.lineId == "B" && 
                    (currentStId == "CAVOUR" || currentStId == "COLOSSEO" || currentStId == "TERMINI_B" ||
                     targetStId == "CAVOUR" || targetStId == "COLOSSEO" || targetStId == "TERMINI_B")

            if (status == "FERMO_IN_STAZIONE") {
                // Change status to moving, set target to next station
                status = "IN_MOVIMENTO"
                progress = 0.0f
                currentSpeed = getScenarioSpeed()
                if (inDisruptedArea) {
                    currentSpeed *= 0.5f // Half speed in disrupted zone
                }
            } else {
                // In motion, advance progress
                // Simulating 1 minute step: progress advances by speed and distance. 
                // Distance between consecutive stations is roughly 1.5km. At 45km/h, it takes 2 minutes.
                // So progress advances by ~0.5 per simulated minute.
                val progressStep = if (inDisruptedArea) 0.15f else 0.45f
                progress += progressStep

                if (progress >= 1.0f) {
                    // Train reached target. Stop at station.
                    progress = 1.0f
                    status = "FERMO_IN_STAZIONE"
                    currentSpeed = 0.0f

                    // Target station becomes current station
                    currentStId = targetStId

                    // Determine new target station along the line
                    val currentStObj = lineStations.find { it.id == currentStId }
                    if (currentStObj != null) {
                        val currentIdx = lineStations.indexOf(currentStObj)
                        val isForward = train.direction == lineStations.last().name

                        if (isForward) {
                            if (currentIdx == lineStations.size - 1) {
                                // Reached forward end, turn back
                                targetStId = lineStations[lineStations.size - 2].id
                            } else {
                                targetStId = lineStations[currentIdx + 1].id
                            }
                        } else {
                            if (currentIdx == 0) {
                                // Reached backward end, turn forward
                                targetStId = lineStations[1].id
                            } else {
                                targetStId = lineStations[currentIdx - 1].id
                            }
                        }
                    }
                }
            }

            // Passenger fluctuation
            val demand = getScenarioDemand()
            val passDelta = (random.nextInt(41) - 20) // fluctuation
            val passengerCount = (train.passengerCount + passDelta).coerceIn(10, 600)

            val updatedTrain = train.copy(
                currentStationId = currentStId,
                targetStationId = targetStId,
                progress = progress,
                speedKmh = currentSpeed,
                status = status,
                passengerCount = passengerCount,
                demandLevel = getDemandLevelLabel(passengerCount / 600.0),
                lastUpdated = System.currentTimeMillis()
            )
            updatedTrains.add(updatedTrain)

            // Generate future arrival estimates for stations down the line
            generateArrivalsForTrain(updatedTrain, lineStations, generatedArrivals)
        }

        // Replace active trains in memory
        activeTrains.clear()
        activeTrains.addAll(updatedTrains)
    }

    private fun generateArrivalsForTrain(
        train: TrenoEntity,
        lineStations: List<StationEntity>,
        arrivalsList: MutableList<OrarioArrivoEntity>
    ) {
        val currentStObj = lineStations.find { it.id == train.currentStationId } ?: return
        val targetStObj = lineStations.find { it.id == train.targetStationId } ?: return

        val currentIdx = lineStations.indexOf(currentStObj)
        val targetIdx = lineStations.indexOf(targetStObj)

        val isForward = train.direction == lineStations.last().name
        val isMoving = train.status == "IN_MOVIMENTO"

        // Estimated minutes to target
        var accumulatedTime = if (isMoving) {
            ((1.0f - train.progress) * 2.0).coerceAtLeast(0.5)
        } else {
            1.5 // Dwell remaining
        }

        if (isForward) {
            // Stations ahead in forward direction (indices from targetIdx to last)
            for (idx in targetIdx until lineStations.size) {
                val station = lineStations[idx]
                arrivalsList.add(
                    OrarioArrivoEntity(
                        id = "ARR-${train.id}-${station.id}",
                        stationId = station.id,
                        lineId = train.lineId,
                        direction = train.direction,
                        estimatedMinutes = accumulatedTime.toInt().coerceAtLeast(1),
                        platform = "Binario 1",
                        sourceType = DataSourceType.SIMULATED
                    )
                )
                accumulatedTime += 2.0 // Add 2 min for each subsequent hop
            }
        } else {
            // Stations ahead in backward direction (indices from targetIdx down to 0)
            for (idx in targetIdx downTo 0) {
                val station = lineStations[idx]
                arrivalsList.add(
                    OrarioArrivoEntity(
                        id = "ARR-${train.id}-${station.id}",
                        stationId = station.id,
                        lineId = train.lineId,
                        direction = train.direction,
                        estimatedMinutes = accumulatedTime.toInt().coerceAtLeast(1),
                        platform = "Binario 2",
                        sourceType = DataSourceType.SIMULATED
                    )
                )
                accumulatedTime += 2.0
            }
        }
    }

    fun getActiveTrains(): List<TrenoEntity> = activeTrains
}
