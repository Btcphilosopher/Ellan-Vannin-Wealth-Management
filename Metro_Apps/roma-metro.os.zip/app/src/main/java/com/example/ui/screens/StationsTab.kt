package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fixtures.MetroFixtures
import com.example.data.model.StationEntity
import com.example.ui.MetroViewModel
import com.example.ui.stations.StationDiagram
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationsTab(viewModel: MetroViewModel) {
    val stations by viewModel.stations.collectAsState()
    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val selectedStation by viewModel.selectedStationFlow.collectAsState()
    val arrivals by viewModel.selectedStationArrivals.collectAsState()
    val places by viewModel.places.collectAsState()

    var showDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Selector Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "INFORMAZIONI STAZIONI",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "SELEZIONA UNA STAZIONE DELLA RETE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                // Select Box
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    onClick = { showDropdown = !showDropdown },
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DirectionsSubway, contentDescription = "Subway", modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = selectedStation?.name ?: "Scegli una stazione...",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Icon(
                            imageVector = if (showDropdown) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                            contentDescription = "Dropdown"
                        )
                    }
                }
            }
        }

        // Dropdown options
        if (showDropdown) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 240.dp)
                        .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val alphabetGroup = stations.sortedBy { it.name }
                        items(alphabetGroup) { st ->
                            val col = if (st.lineId == "A") LineaAOrange else if (st.lineId == "B") LineaBBlue else LineaCGreen
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectStation(st.id)
                                        showDropdown = false
                                    }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .background(col, shape = MaterialTheme.shapes.extraSmall)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(st.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.weight(1f))
                                Text("Linea ${st.lineId}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Divider()
                        }
                    }
                }
            }
        }

        selectedStation?.let { station ->
            val col = if (station.lineId == "A") LineaAOrange else if (station.lineId == "B") LineaBBlue else LineaCGreen

            // Station general header
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = col),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "STAZIONE METROPOLITANA",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Box(
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.25f), shape = MaterialTheme.shapes.extraSmall)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    "LINEA ${station.lineId}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                        Text(
                            station.name.uppercase(),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (station.isClosed) Icons.Default.Cancel else Icons.Default.CheckCircle,
                                contentDescription = "Stato",
                                tint = if (station.isClosed) Color.White else Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                if (station.isClosed) "STATO: TEMPORANEAMENTE CHIUSA" else "STATO: REGOLARE",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // Real-time Arrivals Board
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "PROSSIMI TRENI (ARRIVI)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFFE2DDD5), shape = MaterialTheme.shapes.extraSmall)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    "SIMULATORE",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        if (arrivals.isEmpty()) {
                            Text(
                                "Nessun treno in arrivo programmato al momento. Avvia la simulazione nella scheda Digital Twin.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.padding(vertical = 12.dp),
                                textAlign = TextAlign.Center
                            )
                        } else {
                            arrivals.forEach { arr ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Tram,
                                            contentDescription = "Train",
                                            tint = col,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                "Direzione ${arr.direction}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                arr.platform,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    // Minutes indicator
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (arr.estimatedMinutes <= 2) AlertOrange.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                                                shape = MaterialTheme.shapes.small
                                            )
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            "${arr.estimatedMinutes} min",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (arr.estimatedMinutes <= 2) AlertOrange else MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                Divider()
                            }
                        }
                    }
                }
            }

            // Interactive Vector Diagram Slot
            item {
                StationDiagram(
                    stationId = station.id,
                    stationName = station.name
                )
            }

            // Accessibility Features List
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "ACCESSIBILITÀ E SERVIZI",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Elevators (Ascensori)
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    imageVector = if (station.hasElevator) Icons.Default.UnfoldMore else Icons.Default.Cancel,
                                    contentDescription = "Lift",
                                    tint = if (station.hasElevator) SuccessEmerald else AlertRed,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Ascensori", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(if (station.hasElevator) "Disponibile" else "Non presente", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            // Escalators (Scale mobili)
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    imageVector = if (station.hasEscalator) Icons.Default.TrendingUp else Icons.Default.Cancel,
                                    contentDescription = "Escalator",
                                    tint = if (station.hasEscalator) SuccessEmerald else AlertRed,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Scale Mobili", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Text(if (station.hasEscalator) "Disponibile" else "Non presente", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        Divider()

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (station.isAccessible) Icons.Default.Accessible else Icons.Default.Warning,
                                contentDescription = "Accessibility",
                                tint = if (station.isAccessible) SuccessEmerald else AlertRed,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (station.isAccessible) "Percorso interamente accessibile per disabilità motorie (Sedia a rotelle)."
                                else "Attenzione: questo snodo presenta barriere architettoniche parziali.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Nearby Places & Exits
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "USCITE DI STRADA ED ATTRAZIONI",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // Exits List
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("USCITE STRADALI:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                            val exits = station.exitsJson.split(";")
                            exits.forEach { exit ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ExitToApp, contentDescription = "Exit", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(exit, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }

                        // Nearby Landmarks
                        val localPOI = places.filter { it.nearestStationId == station.id }
                        if (localPOI.isNotEmpty()) {
                            Divider()
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("LUOGHI DI INTERESSE NELLE VICINANZE:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                localPOI.forEach { poi ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(poi.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                                Text("${poi.walkTimeMinutes} min a piedi", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = col)
                                            }
                                            Text(poi.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
