package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LineStatus
import com.example.data.model.StationEntity
import com.example.ui.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTab(
    viewModel: MetroViewModel,
    onNavigateToTab: (String) -> Unit
) {
    val lines by viewModel.lines.collectAsState()
    val stations by viewModel.stations.collectAsState()
    val fromQuery by viewModel.fromSearchQuery.collectAsState()
    val toQuery by viewModel.toSearchQuery.collectAsState()
    val selectedFrom by viewModel.selectedFromStation.collectAsState()
    val selectedTo by viewModel.selectedToStation.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val activeTicket by viewModel.activeTicket.collectAsState()

    var isFromFocused by remember { mutableStateOf(false) }
    var isToFocused by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App header
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "ROMA METRO.OS",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "SISTEMA INTEGRATO DI MOBILITÀ URBANA",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }
        }

        // Active Ticket Banner
        if (activeTicket != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                    onClick = { onNavigateToTab("ticket") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Ticket",
                            tint = MaterialTheme.colorScheme.onTertiaryContainer,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "TICKET ATTIVO DIMOSTRATIVO",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                            Text(
                                activeTicket?.name ?: "",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Open",
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Path Planner input panel
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "DOVE DEVI ANDARE?",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // FROM STATION
                    OutlinedTextField(
                        value = fromQuery,
                        onValueChange = {
                            viewModel.setFromQuery(it)
                            isFromFocused = true
                            isToFocused = false
                        },
                        label = { Text("Partenza (Da)") },
                        placeholder = { Text("Cerca una stazione o indirizzo...") },
                        leadingIcon = { Icon(Icons.Default.MyLocation, contentDescription = "From") },
                        trailingIcon = {
                            if (fromQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setFromQuery("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_from_input")
                    )

                    // TO STATION
                    OutlinedTextField(
                        value = toQuery,
                        onValueChange = {
                            viewModel.setToQuery(it)
                            isToFocused = true
                            isFromFocused = false
                        },
                        label = { Text("Destinazione (A)") },
                        placeholder = { Text("Cerca un monumento, stazione...") },
                        leadingIcon = { Icon(Icons.Default.Place, contentDescription = "To") },
                        trailingIcon = {
                            if (toQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setToQuery("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_to_input")
                    )

                    // Autocomplete suggestion overlay
                    AnimatedVisibility(visible = searchResults.isNotEmpty()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    "RISULTATI STRUTTURATI",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                                    fontWeight = FontWeight.Bold
                                )
                                searchResults.forEach { item ->
                                    when (item) {
                                        is MetroViewModel.SearchResultItem.StazioneItem -> {
                                            val s = item.station
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        if (isFromFocused) viewModel.selectFromStation(s)
                                                        else viewModel.selectToStation(s)
                                                    }
                                                    .padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.DirectionsSubway, contentDescription = "Subway", modifier = Modifier.size(20.dp))
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(s.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                                    Text("Stazione Metropolitana • Linea ${s.lineId}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                                // Line Color Badge
                                                val col = if (s.lineId == "A") LineaAOrange else if (s.lineId == "B") LineaBBlue else LineaCGreen
                                                Box(
                                                    modifier = Modifier
                                                        .size(24.dp, 16.dp)
                                                        .background(col, shape = MaterialTheme.shapes.small)
                                                )
                                            }
                                        }
                                        is MetroViewModel.SearchResultItem.LuogoItem -> {
                                            val p = item.place
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        if (isFromFocused) {
                                                            // Can select nearest station
                                                            val st = stations.find { it.id == p.nearestStationId }
                                                            if (st != null) viewModel.selectFromStation(st)
                                                        } else {
                                                            viewModel.selectToPlace(p)
                                                        }
                                                    }
                                                    .padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.AccountBalance, contentDescription = "Monument", modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.secondary)
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(p.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                                    Text("${p.category} • ${p.walkTimeMinutes} min a piedi da stazione ${p.nearestStationId}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                            }
                                        }
                                    }
                                    Divider()
                                }
                            }
                        }
                    }

                    // Quick Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = {
                                // Default Termini
                                stations.find { it.id == "TERMINI_B" }?.let { viewModel.selectFromStation(it) }
                            },
                            colors = ButtonDefaults.textButtonColors(),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.Home, contentDescription = "Casa", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Da Termini", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                // Default Colosseo
                                stations.find { it.id == "COLOSSEO" }?.let { viewModel.selectToStation(it) }
                            },
                            colors = ButtonDefaults.textButtonColors(),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.Work, contentDescription = "Lavoro", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Al Colosseo", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                // Go to route plan tab
                                onNavigateToTab("percorso")
                            },
                            modifier = Modifier.testTag("plan_route_button")
                        ) {
                            Icon(Icons.Default.Directions, contentDescription = "Plan")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Pianifica", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Quick Favorites List if populated
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "STAZIONI RECENTI ED INTERSCAMBI",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val quickSts = stations.filter { it.id == "TERMINI_B" || it.id == "COLOSSEO" || it.id == "SPAGNA" || it.id == "SAN_GIOVANNI_A" }
                    quickSts.forEach { st ->
                        val col = if (st.lineId == "A") LineaAOrange else if (st.lineId == "B") LineaBBlue else LineaCGreen
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            onClick = { viewModel.selectStation(st.id) },
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), MaterialTheme.shapes.small)
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .background(col, shape = MaterialTheme.shapes.extraSmall)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(st.name, style = MaterialTheme.typography.bodySmall, maxLines = 1, fontWeight = FontWeight.Bold)
                                Text("Vedi info", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }
        }

        // Real-Time Network Service Status
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STATO DELLA RETE METRO",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        // Simulation vs Live Origin Badge
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFE2DDD5), shape = MaterialTheme.shapes.extraSmall)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                "DATI SIMULATI",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    lines.forEach { line ->
                        val lineCol = when (line.code) {
                            "A" -> LineaAOrange
                            "B" -> LineaBBlue
                            else -> LineaCGreen
                        }

                        val statusColor = when (line.status) {
                            LineStatus.REGOLARE -> SuccessEmerald
                            LineStatus.RALLENTAMENTI -> AlertOrange
                            else -> AlertRed
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Line Identifier Box
                            Box(
                                modifier = Modifier
                                    .size(36.dp, 24.dp)
                                    .background(lineCol, shape = MaterialTheme.shapes.small),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    line.code,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    line.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    line.statusMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // Status Indicator Circle
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(statusColor, shape = MaterialTheme.shapes.extraSmall)
                                )
                                Text(
                                    text = line.status.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = statusColor,
                                    fontSize = 9.sp
                                )
                            }
                        }
                        Divider(modifier = Modifier.padding(vertical = 4.dp))
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
