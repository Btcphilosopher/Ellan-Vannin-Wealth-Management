package com.example.ui.stations

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalTextApi::class)
@Composable
fun StationDiagram(
    stationId: String,
    stationName: String,
    modifier: Modifier = Modifier
) {
    var selectedElement by remember { mutableStateOf<String?>(null) }
    var selectedDetails by remember { mutableStateOf<String?>(null) }

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), shape = MaterialTheme.shapes.medium)
            .padding(8.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Text(
                text = "SCHEMA SCHEMATICO DI STAZIONE: ${stationName.uppercase()}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(4.dp)
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(stationId) {
                        detectTapGestures { tapOffset ->
                            val x = tapOffset.x
                            val y = tapOffset.y

                            if (stationId.startsWith("TERMINI")) {
                                // Click zones for Termini
                                when {
                                    y in 10f..65f && x in 100f..350f -> {
                                        selectedElement = "Atrio Centrale"
                                        selectedDetails = "Livello stradale. Biglietterie automatiche, tornelli di accesso principali. Accessibile."
                                    }
                                    y in 85f..140f && x in 50f..200f -> {
                                        selectedElement = "Ascensore Linea A"
                                        selectedDetails = "Collegamento diretto tra Atrio Principale e Banchine Linea A. Stato: ATTIVO."
                                    }
                                    y in 85f..140f && x in 220f..380f -> {
                                        selectedElement = "Scale mobili Linea B"
                                        selectedDetails = "Scale mobili di transito per banchine Linea B. Stato: ATTIVO."
                                    }
                                    y in 160f..215f && x in 30f..180f -> {
                                        selectedElement = "Binario 1 - Linea A (Direz. Anagnina)"
                                        selectedDetails = "Banchina interrata a -15m. Dotata di percorso tattile Loges. Accesso con ascensore."
                                    }
                                    y in 160f..215f && x in 210f..360f -> {
                                        selectedElement = "Binario 2 - Linea B (Direz. Laurentina)"
                                        selectedDetails = "Banchina interrata a -22m. Interscambio sotterraneo con Linea A."
                                    }
                                }
                            } else {
                                // Click zones for Colosseo
                                when {
                                    y in 10f..65f && x in 80f..220f -> {
                                        selectedElement = "Uscita Piazza Colosseo"
                                        selectedDetails = "Livello stradale, di fronte al monumento. Presenza di gradini. Non accessibile in sedia a rotelle."
                                    }
                                    y in 10f..65f && x in 240f..380f -> {
                                        selectedElement = "Ascensore Disabili"
                                        selectedDetails = "Ascensore esterno di collegamento tra Piazza del Colosseo e Atrio Biglietteria. Stato: ATTIVO."
                                    }
                                    y in 85f..140f && x in 100f..300f -> {
                                        selectedElement = "Atrio Biglietteria"
                                        selectedDetails = "Livello sotterraneo -1. Tornelli di accesso rapido, assistenza clienti. Accessibile."
                                    }
                                    y in 160f..215f && x in 40f..190f -> {
                                        selectedElement = "Binario 1 (Direz. Rebibbia)"
                                        selectedDetails = "Banchina sotterranea. Accesso con scale mobili e scale fisse."
                                    }
                                    y in 160f..215f && x in 210f..360f -> {
                                        selectedElement = "Binario 2 (Direz. Laurentina)"
                                        selectedDetails = "Banchina sotterranea. Dotata di servoscala mobile."
                                    }
                                }
                            }
                        }
                    }
            ) {
                val primaryColor = MaterialTheme.colorScheme.primary
                val outlineColor = MaterialTheme.colorScheme.outline
                val textSecondaryColor = MaterialTheme.colorScheme.onSurfaceVariant

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val scaleWidth = size.width / 400f
                    val scaleHeight = size.height / 240f

                    // Function to map standard coordinate boxes nicely
                    fun drawBoxWithText(
                        label: String,
                        x: Float,
                        y: Float,
                        w: Float,
                        h: Float,
                        bgColor: Color,
                        textColor: Color,
                        borderWidth: Float = 1.5f,
                        hasIcon: Boolean = false
                    ) {
                        val rectX = x * scaleWidth
                        val rectY = y * scaleHeight
                        val rectW = w * scaleWidth
                        val rectH = h * scaleHeight

                        drawRoundRect(
                            color = bgColor,
                            topLeft = Offset(rectX, rectY),
                            size = Size(rectW, rectH),
                            cornerRadius = CornerRadius(6f, 6f)
                        )

                        drawRoundRect(
                            color = outlineColor,
                            topLeft = Offset(rectX, rectY),
                            size = Size(rectW, rectH),
                            cornerRadius = CornerRadius(6f, 6f),
                            style = Stroke(width = borderWidth)
                        )

                        val measuredText = textMeasurer.measure(
                            text = AnnotatedString(label),
                            style = TextStyle(
                                color = textColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        )

                        drawText(
                            measuredText,
                            topLeft = Offset(
                                rectX + (rectW - measuredText.size.width) / 2f,
                                rectY + (rectH - measuredText.size.height) / 2f
                            )
                        )

                        if (hasIcon) {
                            // Small accessibility indicator
                            drawCircle(
                                color = Color(0xFF007CC0),
                                radius = 4f,
                                center = Offset(rectX + 10f, rectY + 10f)
                            )
                        }
                    }

                    if (stationId.startsWith("TERMINI")) {
                        // TERMINI INTERCHANGE DIAGRAM
                        // Connection lines
                        drawLine(
                            color = Color(0xFFF2780C),
                            start = Offset(125f * scaleWidth, 65f * scaleHeight),
                            end = Offset(125f * scaleWidth, 160f * scaleHeight),
                            strokeWidth = 3f,
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = Color(0xFF007CC0),
                            start = Offset(285f * scaleWidth, 65f * scaleHeight),
                            end = Offset(285f * scaleWidth, 160f * scaleHeight),
                            strokeWidth = 3f,
                            cap = StrokeCap.Round
                        )

                        // 1. Atrio Centrale
                        drawBoxWithText(
                            "ATRIO CENTRALE (Tornelli & Biglietteria)",
                            100f, 10f, 250f, 55f,
                            bgColor = Color.White,
                            textColor = primaryColor
                        )

                        // 2. Ascensori / Transits
                        drawBoxWithText(
                            "ASCENSORE [A]",
                            50f, 85f, 150f, 55f,
                            bgColor = Color(0xFFE3DFD5),
                            textColor = primaryColor,
                            hasIcon = true
                        )
                        drawBoxWithText(
                            "SCALEMOBILI [B]",
                            220f, 85f, 150f, 55f,
                            bgColor = Color(0xFFE3DFD5),
                            textColor = primaryColor
                        )

                        // 3. Platforms
                        drawBoxWithText(
                            "B1 - LINEA A (Anagnina)",
                            30f, 160f, 150f, 55f,
                            bgColor = Color(0xFFF2780C).copy(alpha = 0.15f),
                            textColor = Color(0xFFF2780C),
                            borderWidth = 2.5f
                        )
                        drawBoxWithText(
                            "B2 - LINEA B (Laurentina)",
                            210f, 160f, 150f, 55f,
                            bgColor = Color(0xFF007CC0).copy(alpha = 0.15f),
                            textColor = Color(0xFF007CC0),
                            borderWidth = 2.5f
                        )

                    } else {
                        // COLOSSEO STATION DIAGRAM
                        // Connection lines
                        drawLine(
                            color = Color.LightGray,
                            start = Offset(150f * scaleWidth, 65f * scaleHeight),
                            end = Offset(200f * scaleWidth, 85f * scaleHeight),
                            strokeWidth = 2f
                        )
                        drawLine(
                            color = Color(0xFF007CC0),
                            start = Offset(310f * scaleWidth, 65f * scaleHeight),
                            end = Offset(200f * scaleWidth, 85f * scaleHeight),
                            strokeWidth = 2f
                        )
                        drawLine(
                            color = Color(0xFF007CC0),
                            start = Offset(200f * scaleWidth, 140f * scaleHeight),
                            end = Offset(115f * scaleWidth, 160f * scaleHeight),
                            strokeWidth = 3f
                        )
                        drawLine(
                            color = Color(0xFF007CC0),
                            start = Offset(200f * scaleWidth, 140f * scaleHeight),
                            end = Offset(285f * scaleWidth, 160f * scaleHeight),
                            strokeWidth = 3f
                        )

                        // 1. Uscita e Ascensore
                        drawBoxWithText(
                            "USCITA PIAZZA COLOSSEO",
                            80f, 10f, 140f, 55f,
                            bgColor = Color.White,
                            textColor = primaryColor
                        )
                        drawBoxWithText(
                            "ASCENSORE [ATTIVO]",
                            240f, 10f, 140f, 55f,
                            bgColor = Color(0xFFE2DDD5),
                            textColor = Color(0xFF007CC0),
                            hasIcon = true
                        )

                        // 2. Atrio Biglietteria
                        drawBoxWithText(
                            "ATRIO BIGLIETTERIA (Tornelli)",
                            100f, 85f, 200f, 55f,
                            bgColor = Color.White,
                            textColor = primaryColor
                        )

                        // 3. Platforms
                        drawBoxWithText(
                            "B1 (Laurentina)",
                            40f, 160f, 150f, 55f,
                            bgColor = Color(0xFF007CC0).copy(alpha = 0.12f),
                            textColor = Color(0xFF007CC0),
                            borderWidth = 2f
                        )
                        drawBoxWithText(
                            "B2 (Rebibbia)",
                            210f, 160f, 150f, 55f,
                            bgColor = Color(0xFF007CC0).copy(alpha = 0.12f),
                            textColor = Color(0xFF007CC0),
                            borderWidth = 2f
                        )
                    }
                }
            }

            // Info text and details
            AnimatedVisibility(visible = selectedElement != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Info",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = selectedElement ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = selectedDetails ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            if (selectedElement == null) {
                Text(
                    text = "Tocca un elemento del diagramma per visualizzare la connettività sotterranea e i dettagli di accessibilità.",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    fontSize = 11.sp
                )
            }
        }
    }
}
