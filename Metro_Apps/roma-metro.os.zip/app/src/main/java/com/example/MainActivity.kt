package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MetroViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MetroViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScaffold(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppScaffold(viewModel: MetroViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val simTimeMin by viewModel.simTimeMinutes.collectAsState()
    val isSimRunning by viewModel.isSimRunning.collectAsState()
    val weather by viewModel.weather.collectAsState()

    val formattedTime = viewModel.formatMinutesToTime(simTimeMin)

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            // Elegant top status bar showing simulation clock and weather across the platform
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Brand
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(Color(0xFFCE9B4E), shape = MaterialTheme.shapes.extraSmall)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "METRO.OS",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 1.sp
                        )
                    }

                    // Right Indicators (Sim time & weather)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Weather Status icon
                        Icon(
                            imageVector = when (weather.description) {
                                "Pioggia" -> Icons.Default.Cloud
                                "Caldo Intenso" -> Icons.Default.WbSunny
                                else -> Icons.Default.WbSunny
                            },
                            contentDescription = "Meteo",
                            tint = if (weather.description == "Caldo Intenso") Color(0xFFEF6C00) else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )

                        // Simulation Clock Indicator
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(if (isSimRunning) Color(0xFF2E7D32) else Color(0xFFC62828), shape = MaterialTheme.shapes.extraSmall)
                            )
                            Text(
                                text = formattedTime,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                // Home Tab Button
                NavigationBarItem(
                    selected = currentTab == "home",
                    onClick = { viewModel.selectTab("home") },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 10.sp) },
                    modifier = Modifier.testTag("nav_home")
                )

                // Route Tab Button
                NavigationBarItem(
                    selected = currentTab == "percorso",
                    onClick = { viewModel.selectTab("percorso") },
                    icon = { Icon(Icons.Default.Directions, contentDescription = "Percorsi") },
                    label = { Text("Percorsi", fontSize = 10.sp) },
                    modifier = Modifier.testTag("nav_percorsi")
                )

                // Map Tab Button
                NavigationBarItem(
                    selected = currentTab == "mappa",
                    onClick = { viewModel.selectTab("mappa") },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Mappa") },
                    label = { Text("Mappa", fontSize = 10.sp) },
                    modifier = Modifier.testTag("nav_mappa")
                )

                // Stations Tab Button
                NavigationBarItem(
                    selected = currentTab == "stazioni",
                    onClick = { viewModel.selectTab("stazioni") },
                    icon = { Icon(Icons.Default.DirectionsSubway, contentDescription = "Stazioni") },
                    label = { Text("Stazioni", fontSize = 10.sp) },
                    modifier = Modifier.testTag("nav_stazioni")
                )

                // Wallet / Saved Routes Tab Button
                NavigationBarItem(
                    selected = currentTab == "salvati",
                    onClick = { viewModel.selectTab("salvati") },
                    icon = { Icon(Icons.Default.Bookmark, contentDescription = "Preferiti") },
                    label = { Text("Preferiti", fontSize = 10.sp) },
                    modifier = Modifier.testTag("nav_salvati")
                )

                // Digital Twin Admin Toggles Button
                NavigationBarItem(
                    selected = currentTab == "digital_twin",
                    onClick = { viewModel.selectTab("digital_twin") },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Digital Twin") },
                    label = { Text("Twin", fontSize = 10.sp) },
                    modifier = Modifier.testTag("nav_twin")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                "home" -> HomeTab(viewModel = viewModel, onNavigateToTab = { viewModel.selectTab(it) })
                "percorso" -> RouteTab(viewModel = viewModel)
                "mappa" -> MapTab(viewModel = viewModel)
                "stazioni" -> StationsTab(viewModel = viewModel)
                "salvati" -> SavedTicketsTab(viewModel = viewModel)
                "digital_twin" -> DigitalTwinTab(viewModel = viewModel)
                else -> HomeTab(viewModel = viewModel, onNavigateToTab = { viewModel.selectTab(it) })
            }
        }
    }
}
