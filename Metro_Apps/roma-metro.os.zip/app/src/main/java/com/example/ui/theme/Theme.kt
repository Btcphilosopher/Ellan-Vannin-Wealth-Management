package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = BasaltBlack,
    onPrimary = TravertinoWhite,
    secondary = AccentRust,
    onSecondary = Color.White,
    tertiary = AccentGold,
    onTertiary = BasaltBlack,
    background = TravertinoWhite,
    onBackground = BasaltBlack,
    surface = SoftWhite,
    onSurface = BasaltBlack,
    surfaceVariant = TravertinoCream,
    onSurfaceVariant = AnthraciteDark,
    outline = PietraGray,
    error = AlertRed,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkTextPrimary,
    onPrimary = DarkBasalt,
    secondary = AccentRust,
    onSecondary = Color.White,
    tertiary = AccentGold,
    onTertiary = DarkBasalt,
    background = DarkBasalt,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkBorder,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkBorder,
    error = AlertRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
