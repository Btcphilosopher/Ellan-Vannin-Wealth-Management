package com.example.data.simulation

import com.example.data.mock.SydneyMetroData
import com.example.data.model.AlertSeverity
import com.example.data.model.Facility
import com.example.data.model.FacilityStatus
import com.example.data.model.OccupancyLevel
import com.example.data.model.Platform
import com.example.data.model.ServiceAlert
import com.example.data.model.Station
import com.example.data.model.Train
import com.example.data.model.TrainDirection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MetroSimulationState(
    val isRunning: Boolean = true,
    val speedFactor: Int = 1, // 1x, 2x, 5x, 10x
    val activeTrains: List<Train> = SydneyMetroData.INITIAL_TRAINS,
    val stations: List<Station> = SydneyMetroData.STATIONS,
    val serviceAlerts: List<ServiceAlert> = SydneyMetroData.INITIAL_ALERTS,
    val systemStatusText: String = "OPERATIONAL — 100% AUTOMATED DRIVERLESS METRO"
)

sealed class RealTimeEvent {
    data class TrainArriving(val trainId: String, val stationName: String, val platform: String) : RealTimeEvent()
    data class DelayInjected(val lineCode: String, val delayMinutes: Int, val reason: String) : RealTimeEvent()
    data class LiftStatusChanged(val stationName: String, val facilityName: String, val status: FacilityStatus) : RealTimeEvent()
    data class StationClosureToggled(val stationName: String, val isClosed: Boolean) : RealTimeEvent()
}

class SimulationEngine {
    private val scope = CoroutineScope(Dispatchers.Default)
    private var simulationJob: Job? = null

    private val _state = MutableStateFlow(MetroSimulationState())
    val state: StateFlow<MetroSimulationState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<RealTimeEvent>()
    val events: SharedFlow<RealTimeEvent> = _events.asSharedFlow()

    init {
        startSimulation()
    }

    fun startSimulation() {
        if (simulationJob?.isActive == true) return
        _state.value = _state.value.copy(isRunning = true)
        simulationJob = scope.launch {
            while (true) {
                val delayTime = (1000 / _state.value.speedFactor.coerceAtLeast(1)).toLong()
                delay(delayTime)
                if (_state.value.isRunning) {
                    tickSimulation()
                }
            }
        }
    }

    fun pauseSimulation() {
        _state.value = _state.value.copy(isRunning = false)
    }

    fun togglePlayPause() {
        if (_state.value.isRunning) {
            pauseSimulation()
        } else {
            startSimulation()
        }
    }

    fun setSpeedFactor(factor: Int) {
        _state.value = _state.value.copy(speedFactor = factor)
    }

    private suspend fun tickSimulation() {
        val currentStations = _state.value.stations
        val updatedTrains = _state.value.activeTrains.map { train ->
            val step = 0.05f
            var newProgress = train.progressToNext + step
            var currStationId = train.currentStationId
            var nextStationId = train.nextStationId
            var mins = train.minutesToNextStation

            if (newProgress >= 1.0f) {
                newProgress = 0.0f
                // Move to next station along M1 station list
                val stationIndex = currentStations.indexOfFirst { it.id == nextStationId }
                if (stationIndex != -1) {
                    currStationId = nextStationId
                    val isSouth = train.direction == TrainDirection.TOWARDS_SYDENHAM
                    val nextIdx = if (isSouth) {
                        if (stationIndex + 1 < currentStations.size) stationIndex + 1 else 0
                    } else {
                        if (stationIndex - 1 >= 0) stationIndex - 1 else currentStations.size - 1
                    }
                    nextStationId = currentStations[nextIdx].id
                    mins = (2..4).random()

                    val targetStation = currentStations[stationIndex]
                    val plat = if (isSouth) "Platform 2" else "Platform 1"
                    _events.emit(RealTimeEvent.TrainArriving(train.id, targetStation.name, plat))
                }
            } else {
                mins = ((1.0f - newProgress) * 3).toInt().coerceAtLeast(1)
            }

            train.copy(
                progressToNext = newProgress,
                currentStationId = currStationId,
                nextStationId = nextStationId,
                minutesToNextStation = mins
            )
        }

        // Also update station platforms arrival counts dynamically
        val updatedStations = currentStations.map { station ->
            val nextS = updatedTrains.filter { it.nextStationId == station.id || it.currentStationId == station.id }
                .minOfOrNull { it.minutesToNextStation } ?: (2..6).random()

            val updatedPlatforms = station.platforms.map { p ->
                val calcArrival = (p.nextTrainArrivalMinutes - 1).let { if (it <= 0) (2..5).random() else it }
                p.copy(nextTrainArrivalMinutes = calcArrival)
            }
            station.copy(platforms = updatedPlatforms)
        }

        _state.value = _state.value.copy(
            activeTrains = updatedTrains,
            stations = updatedStations
        )
    }

    // Controls for Simulation Control Panel
    suspend fun injectDelay(lineCode: String, delayMinutes: Int) {
        val updatedAlerts = _state.value.serviceAlerts.map { alert ->
            if (alert.lineCode == lineCode) {
                alert.copy(
                    severity = AlertSeverity.MAJOR_DELAYS,
                    message = "Simulated track interference. Expect +$delayMinutes min delays.",
                    affectedSection = "Central ↔ Sydenham",
                    recommendedAlternative = "Consider Sydney Trains T4 connection at Sydenham or Central."
                )
            } else alert
        }
        val updatedTrains = _state.value.activeTrains.map {
            if (it.lineCode == lineCode) it.copy(delayMinutes = delayMinutes) else it
        }
        _state.value = _state.value.copy(
            serviceAlerts = updatedAlerts,
            activeTrains = updatedTrains,
            systemStatusText = "ALERT: +$delayMinutes MIN DELAY INJECTED ON $lineCode"
        )
        _events.emit(RealTimeEvent.DelayInjected(lineCode, delayMinutes, "Simulated Control Intervention"))
    }

    suspend fun toggleStationClosure(stationId: String) {
        val updatedStations = _state.value.stations.map { station ->
            if (station.id == stationId) {
                val newClosed = !station.isClosed
                _events.emit(RealTimeEvent.StationClosureToggled(station.name, newClosed))
                station.copy(isClosed = newClosed)
            } else station
        }
        _state.value = _state.value.copy(stations = updatedStations)
    }

    suspend fun toggleLiftStatus(stationId: String, facilityId: String) {
        val updatedStations = _state.value.stations.map { station ->
            if (station.id == stationId) {
                val updatedFacs = station.facilities.map { f ->
                    if (f.id == facilityId) {
                        val newStatus = if (f.status == FacilityStatus.OPERATIONAL) FacilityStatus.CLOSED else FacilityStatus.OPERATIONAL
                        _events.emit(RealTimeEvent.LiftStatusChanged(station.name, f.name, newStatus))
                        f.copy(status = newStatus)
                    } else f
                }
                station.copy(facilities = updatedFacs)
            } else station
        }
        _state.value = _state.value.copy(stations = updatedStations)
    }

    fun updateTrainOccupancy(trainId: String, level: OccupancyLevel) {
        val updatedTrains = _state.value.activeTrains.map {
            if (it.id == trainId) it.copy(occupancy = level) else it
        }
        _state.value = _state.value.copy(activeTrains = updatedTrains)
    }
}
