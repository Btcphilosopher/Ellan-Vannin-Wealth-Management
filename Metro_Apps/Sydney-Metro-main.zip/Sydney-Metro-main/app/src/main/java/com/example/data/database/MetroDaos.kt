package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.OpalTransaction
import com.example.data.model.Station
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteStationDao {
    @Query("SELECT * FROM favorite_stations ORDER BY name ASC")
    fun getAllFavorites(): Flow<List<Station>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(station: Station)

    @Query("DELETE FROM favorite_stations WHERE id = :stationId")
    suspend fun deleteFavorite(stationId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_stations WHERE id = :stationId)")
    fun isFavorite(stationId: String): Flow<Boolean>
}

@Dao
interface OpalTransactionDao {
    @Query("SELECT * FROM opal_transactions ORDER BY id DESC")
    fun getAllTransactions(): Flow<List<OpalTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: OpalTransaction)

    @Query("DELETE FROM opal_transactions")
    suspend fun clearTransactions()
}
