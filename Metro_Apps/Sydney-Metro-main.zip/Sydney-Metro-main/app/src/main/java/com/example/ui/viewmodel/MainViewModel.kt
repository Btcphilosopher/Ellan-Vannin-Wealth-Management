package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.FacilityStatus
import com.example.data.model.JourneyPlan
import com.example.data.model.OccupancyLevel
import com.example.data.model.OpalTransaction
import com.example.data.model.ServiceAlert
import com.example.data.model.Station
import com.example.data.model.Train
import com.example.data.repository.MetroRepository
import com.example.data.simulation.MetroSimulationState
import com.example.data.simulation.RealTimeEvent
import com.example.data.simulation.SimulationEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MetroNavTab {
    HOME, NETWORK_MAP, JOURNEY, STATIONS, WALLET, PROFILE
}

data class MainUiState(
    val currentTab: MetroNavTab = MetroNavTab.HOME,
    val selectedStation: Station? = null,
    val selectedTrain: Train? = null,
    val selectedPlatformNumber: Int? = null,
    val showSimulationPanel: Boolean = false,
    val originStationId: String = "S16", // Martin Place
    val destinationStationId: String = "S12", // Chatswood
    val requireWheelchairAccess: Boolean = false,
    val avoidStairs: Boolean = false,
    val journeyPlans: List<JourneyPlan> = emptyList(),
    val activeJourney: JourneyPlan? = null,
    val isLiveJourneyActive: Boolean = false,
    val opalBalanceAud: Double = 42.80,
    val recentEvents: List<RealTimeEvent> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val simulationEngine = SimulationEngine()
    val repository = MetroRepository(
        simulationEngine = simulationEngine,
        favoriteStationDao = database.favoriteStationDao(),
        opalTransactionDao = database.opalTransactionDao()
    )

    val simulationState: StateFlow<MetroSimulationState> = repository.simulationState

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    val favoriteStations = repository.favoriteStations.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val opalTransactions = repository.opalTransactions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        // Observe simulation events
        viewModelScope.launch {
            repository.realTimeEvents.collect { event ->
                val current = _uiState.value.recentEvents.take(5)
                _uiState.value = _uiState.value.copy(
                    recentEvents = listOf(event) + current
                )
            }
        }

        // Initial Journey Plan Calculation
        calculateJourney()
    }

    fun selectTab(tab: MetroNavTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
    }

    fun selectStation(station: Station?) {
        _uiState.value = _uiState.value.copy(selectedStation = station)
    }

    fun selectTrain(train: Train?) {
        _uiState.value = _uiState.value.copy(selectedTrain = train)
    }

    fun toggleSimulationPanel() {
        _uiState.value = _uiState.value.copy(showSimulationPanel = !_uiState.value.showSimulationPanel)
    }

    fun setJourneyOrigin(stationId: String) {
        _uiState.value = _uiState.value.copy(originStationId = stationId)
        calculateJourney()
    }

    fun setJourneyDestination(stationId: String) {
        _uiState.value = _uiState.value.copy(destinationStationId = stationId)
        calculateJourney()
    }

    fun toggleWheelchairAccess() {
        _uiState.value = _uiState.value.copy(requireWheelchairAccess = !_uiState.value.requireWheelchairAccess)
        calculateJourney()
    }

    fun toggleAvoidStairs() {
        _uiState.value = _uiState.value.copy(avoidStairs = !_uiState.value.avoidStairs)
        calculateJourney()
    }

    fun calculateJourney() {
        val plans = repository.calculateJourneyPlans(
            fromStationId = _uiState.value.originStationId,
            toStationId = _uiState.value.destinationStationId,
            requireWheelchairAccess = _uiState.value.requireWheelchairAccess,
            avoidStairs = _uiState.value.avoidStairs
        )
        _uiState.value = _uiState.value.copy(
            journeyPlans = plans,
            activeJourney = plans.firstOrNull()
        )
    }

    fun startLiveJourney(plan: JourneyPlan) {
        _uiState.value = _uiState.value.copy(
            activeJourney = plan,
            isLiveJourneyActive = true,
            currentTab = MetroNavTab.JOURNEY
        )
    }

    fun stopLiveJourney() {
        _uiState.value = _uiState.value.copy(isLiveJourneyActive = false)
    }

    fun toggleFavoriteStation(station: Station) {
        viewModelScope.launch {
            repository.toggleFavorite(station)
        }
    }

    fun simulateOpalTap(fromStation: String, toStation: String) {
        viewModelScope.launch {
            val fare = 3.79
            val currentBal = _uiState.value.opalBalanceAud
            if (currentBal >= fare) {
                val newBal = currentBal - fare
                _uiState.value = _uiState.value.copy(opalBalanceAud = newBal)
                repository.recordOpalTap(fromStation, toStation, fare)
            }
        }
    }

    fun topUpOpal(amount: Double) {
        val newBal = _uiState.value.opalBalanceAud + amount
        _uiState.value = _uiState.value.copy(opalBalanceAud = newBal)
    }

    // Simulation Engine Delegations
    fun togglePlayPauseSimulation() {
        simulationEngine.togglePlayPause()
    }

    fun setSimulationSpeed(factor: Int) {
        simulationEngine.setSpeedFactor(factor)
    }

    fun injectDelay(lineCode: String, delayMinutes: Int) {
        viewModelScope.launch {
            simulationEngine.injectDelay(lineCode, delayMinutes)
            calculateJourney()
        }
    }

    fun toggleStationClosure(stationId: String) {
        viewModelScope.launch {
            simulationEngine.toggleStationClosure(stationId)
        }
    }

    fun toggleLiftStatus(stationId: String, facilityId: String) {
        viewModelScope.launch {
            simulationEngine.toggleLiftStatus(stationId, facilityId)
            calculateJourney()
        }
    }

    fun setTrainOccupancy(trainId: String, level: OccupancyLevel) {
        simulationEngine.updateTrainOccupancy(trainId, level)
    }
}
