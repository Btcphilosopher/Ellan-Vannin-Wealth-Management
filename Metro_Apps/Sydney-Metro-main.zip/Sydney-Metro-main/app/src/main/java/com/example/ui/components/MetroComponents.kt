package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AlertSeverity
import com.example.data.model.OccupancyLevel
import com.example.data.model.Train
import com.example.ui.theme.MetroCardBorder
import com.example.ui.theme.MetroCardSurface
import com.example.ui.theme.MetroM1Teal
import com.example.ui.theme.MetroM1TealGlow
import com.example.ui.theme.MetroTextSecondary
import com.example.ui.theme.MetroWhite
import com.example.ui.theme.StatusErrorRed
import com.example.ui.theme.StatusGoodGreen
import com.example.ui.theme.StatusWarningAmber

@Composable
fun OccupancyMeter(
    level: OccupancyLevel,
    modifier: Modifier = Modifier
) {
    val activeColor = when (level) {
        OccupancyLevel.LOW -> StatusGoodGreen
        OccupancyLevel.MEDIUM -> StatusWarningAmber
        OccupancyLevel.HIGH -> StatusErrorRed
    }

    val blockCount = when (level) {
        OccupancyLevel.LOW -> 3
        OccupancyLevel.MEDIUM -> 6
        OccupancyLevel.HIGH -> 9
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        modifier = modifier
    ) {
        repeat(9) { index ->
            val isFilled = index < blockCount
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .height(14.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (isFilled) activeColor else Color.White.copy(alpha = 0.15f))
            )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = level.name,
            style = MaterialTheme.typography.labelSmall,
            color = activeColor,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun NetworkStatusChip(
    severity: AlertSeverity,
    text: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = when (severity) {
        AlertSeverity.GOOD -> StatusGoodGreen.copy(alpha = 0.15f) to StatusGoodGreen
        AlertSeverity.MINOR_DELAYS -> StatusWarningAmber.copy(alpha = 0.15f) to StatusWarningAmber
        AlertSeverity.MAJOR_DELAYS -> StatusErrorRed.copy(alpha = 0.15f) to StatusErrorRed
        AlertSeverity.SUSPENDED -> StatusErrorRed.copy(alpha = 0.25f) to StatusErrorRed
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
            .testTag("status_chip_${severity.name}")
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(textColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = textColor,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun LiveTrainBadge(
    train: Train,
    nextStationName: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MetroCardSurface)
            .border(1.dp, MetroCardBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
            .testTag("train_badge_${train.id}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MetroM1Teal)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = train.lineCode,
                            color = MetroWhite,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TRAIN ${train.id}",
                        color = MetroWhite,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Speed",
                        tint = MetroM1TealGlow,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${train.currentSpeedKmH} km/h",
                        style = MaterialTheme.typography.labelMedium,
                        color = MetroM1TealGlow,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "NEXT STATION",
                        style = MaterialTheme.typography.labelSmall,
                        color = MetroTextSecondary
                    )
                    Text(
                        text = nextStationName,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MetroWhite,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "ARRIVING IN",
                        style = MaterialTheme.typography.labelSmall,
                        color = MetroTextSecondary
                    )
                    Text(
                        text = "${train.minutesToNextStation} MIN",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MetroM1TealGlow,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OccupancyMeter(level = train.occupancy)

                if (train.delayMinutes > 0) {
                    Text(
                        text = "+${train.delayMinutes} MIN DELAY",
                        color = StatusErrorRed,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        text = "ON TIME",
                        color = StatusGoodGreen,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
