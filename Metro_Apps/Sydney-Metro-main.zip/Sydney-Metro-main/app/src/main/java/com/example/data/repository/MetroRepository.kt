package com.example.data.repository

import com.example.data.database.FavoriteStationDao
import com.example.data.database.OpalTransactionDao
import com.example.data.model.FacilityStatus
import com.example.data.model.JourneyPlan
import com.example.data.model.JourneySegment
import com.example.data.model.OccupancyLevel
import com.example.data.model.OpalTransaction
import com.example.data.model.ServiceAlert
import com.example.data.model.Station
import com.example.data.model.TravelAnalytics
import com.example.data.simulation.MetroSimulationState
import com.example.data.simulation.RealTimeEvent
import com.example.data.simulation.SimulationEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

class MetroRepository(
    val simulationEngine: SimulationEngine,
    private val favoriteStationDao: FavoriteStationDao,
    private val opalTransactionDao: OpalTransactionDao
) {
    val simulationState: StateFlow<MetroSimulationState> = simulationEngine.state
    val realTimeEvents: SharedFlow<RealTimeEvent> = simulationEngine.events

    val favoriteStations: Flow<List<Station>> = favoriteStationDao.getAllFavorites()
    val opalTransactions: Flow<List<OpalTransaction>> = opalTransactionDao.getAllTransactions()

    suspend fun toggleFavorite(station: Station) {
        if (station.isFavorite) {
            favoriteStationDao.deleteFavorite(station.id)
        } else {
            favoriteStationDao.insertFavorite(station.copy(isFavorite = true))
        }
    }

    suspend fun recordOpalTap(fromStation: String, toStation: String, fare: Double) {
        val tx = OpalTransaction(
            date = "Today",
            fromStation = fromStation,
            toStation = toStation,
            lineCode = "M1",
            amountAud = fare,
            timeFormatted = "08:42 AM"
        )
        opalTransactionDao.insertTransaction(tx)
    }

    fun calculateJourneyPlans(
        fromStationId: String,
        toStationId: String,
        requireWheelchairAccess: Boolean = false,
        avoidStairs: Boolean = false
    ): List<JourneyPlan> {
        val stations = simulationEngine.state.value.stations
        val origin = stations.find { it.id == fromStationId } ?: stations.first()
        val dest = stations.find { it.id == toStationId } ?: stations.last()

        val originIdx = stations.indexOf(origin)
        val destIdx = stations.indexOf(dest)

        if (originIdx == -1 || destIdx == -1 || originIdx == destIdx) {
            return emptyList()
        }

        val stopCount = kotlin.math.abs(destIdx - originIdx)
        val trainTravelMins = stopCount * 2
        val initialWaitMins = 3
        val totalMins = trainTravelMins + initialWaitMins

        val isSouth = destIdx > originIdx
        val platform = if (isSouth) "Platform 2" else "Platform 1"
        val lineCode = "M1"

        val intermediateNames = if (isSouth) {
            stations.subList(originIdx + 1, destIdx).map { it.name }
        } else {
            stations.subList(destIdx + 1, originIdx).reversed().map { it.name }
        }

        val liftAvailable = origin.facilities.none { it.type == com.example.data.model.StationFacilityType.LIFT && it.status != FacilityStatus.OPERATIONAL }
        val accessNote = if (requireWheelchairAccess || avoidStairs) {
            if (liftAvailable) "✓ 100% Step-free route via concourse lifts" else "⚠️ Lift B at ${origin.name} under maintenance — alternative ramp path assigned"
        } else null

        val primarySegment = JourneySegment(
            mode = "METRO",
            instruction = "Board M1 Metro towards ${if (isSouth) "Sydenham" else "Tallawong"}",
            fromStationName = origin.name,
            toStationName = dest.name,
            platform = platform,
            durationMinutes = trainTravelMins,
            lineCode = lineCode,
            intermediateStops = intermediateNames
        )

        val directPlan = JourneyPlan(
            id = "JP_DIRECT",
            originStationId = origin.id,
            originName = origin.name,
            destinationStationId = dest.id,
            destinationName = dest.name,
            totalDurationMinutes = totalMins,
            departureTime = "08:42",
            arrivalTime = "08:${42 + totalMins}",
            fareAud = 3.79 + (stopCount * 0.15),
            isAccessible = true,
            segments = listOf(
                JourneySegment("WALK", "Walk 2 min to $platform", origin.name, origin.name, durationMinutes = 2),
                primarySegment,
                JourneySegment("WALK", "Exit at ${dest.name} via Central Concourse Lifts", dest.name, dest.name, durationMinutes = 2)
            ),
            alternativeNote = accessNote
        )

        val alternativePlan = JourneyPlan(
            id = "JP_ALT",
            originStationId = origin.id,
            originName = origin.name,
            destinationStationId = dest.id,
            destinationName = dest.name,
            totalDurationMinutes = totalMins + 4,
            departureTime = "08:47",
            arrivalTime = "08:${51 + totalMins}",
            fareAud = 3.79 + (stopCount * 0.15),
            isAccessible = true,
            segments = listOf(
                primarySegment.copy(platform = if (isSouth) "Platform 2" else "Platform 1")
            ),
            alternativeNote = "Following train in 8 min — expected LOW occupancy"
        )

        return listOf(directPlan, alternativePlan)
    }

    fun getTravelAnalytics(): TravelAnalytics {
        return TravelAnalytics()
    }
}
