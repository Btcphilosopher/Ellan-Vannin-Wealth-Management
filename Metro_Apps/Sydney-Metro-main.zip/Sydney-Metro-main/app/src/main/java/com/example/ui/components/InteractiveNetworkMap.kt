package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Station
import com.example.data.model.Train
import com.example.ui.theme.MetroCardBorder
import com.example.ui.theme.MetroCardSurface
import com.example.ui.theme.MetroDarkNavy
import com.example.ui.theme.MetroM1Teal
import com.example.ui.theme.MetroM1TealGlow
import com.example.ui.theme.MetroTextSecondary
import com.example.ui.theme.MetroWhite
import com.example.ui.theme.StatusGoodGreen

@Composable
fun InteractiveNetworkMap(
    stations: List<Station>,
    trains: List<Train>,
    onStationSelect: (Station) -> Unit,
    onTrainSelect: (Train) -> Unit,
    modifier: Modifier = Modifier
) {
    var isSchematicView by remember { mutableStateOf(true) }
    var selectedStation by remember { mutableStateOf<Station?>(null) }
    var selectedTrain by remember { mutableStateOf<Train?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MetroDarkNavy)
            .testTag("interactive_network_map")
    ) {
        // Render Canvas Map
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(stations, trains, isSchematicView) {
                    detectTapGestures { tapOffset ->
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()

                        // Check station click
                        val clickedStation = stations.find { station ->
                            val sx = if (isSchematicView) station.mapXRatio * w else (0.15f + station.mapXRatio * 0.7f) * w
                            val sy = if (isSchematicView) station.mapYRatio * h else (0.10f + station.mapYRatio * 0.8f) * h
                            val dist = (Offset(sx, sy) - tapOffset).getDistance()
                            dist < 40f
                        }

                        if (clickedStation != null) {
                            selectedStation = clickedStation
                            selectedTrain = null
                            onStationSelect(clickedStation)
                        } else {
                            // Check train click
                            val clickedTrain = trains.find { train ->
                                val s1 = stations.find { it.id == train.currentStationId }
                                val s2 = stations.find { it.id == train.nextStationId }
                                if (s1 != null && s2 != null) {
                                    val x1 = if (isSchematicView) s1.mapXRatio * w else (0.15f + s1.mapXRatio * 0.7f) * w
                                    val y1 = if (isSchematicView) s1.mapYRatio * h else (0.10f + s1.mapYRatio * 0.8f) * h
                                    val x2 = if (isSchematicView) s2.mapXRatio * w else (0.15f + s2.mapXRatio * 0.7f) * w
                                    val y2 = if (isSchematicView) s2.mapYRatio * h else (0.10f + s2.mapYRatio * 0.8f) * h
                                    val tx = x1 + (x2 - x1) * train.progressToNext
                                    val ty = y1 + (y2 - y1) * train.progressToNext
                                    val dist = (Offset(tx, ty) - tapOffset).getDistance()
                                    dist < 45f
                                } else false
                            }

                            if (clickedTrain != null) {
                                selectedTrain = clickedTrain
                                selectedStation = null
                                onTrainSelect(clickedTrain)
                            } else {
                                selectedStation = null
                                selectedTrain = null
                            }
                        }
                    }
                }
        ) {
            val canvasW = size.width
            val canvasH = size.height

            // 1. Draw grid background lines
            val gridStep = 80f
            var x = 0f
            while (x < canvasW) {
                drawLine(
                    color = Color.White.copy(alpha = 0.04f),
                    start = Offset(x, 0f),
                    end = Offset(x, canvasH),
                    strokeWidth = 1f
                )
                x += gridStep
            }
            var y = 0f
            while (y < canvasH) {
                drawLine(
                    color = Color.White.copy(alpha = 0.04f),
                    start = Offset(0f, y),
                    end = Offset(canvasW, y),
                    strokeWidth = 1f
                )
                y += gridStep
            }

            // 2. Build track path
            val trackPath = Path()
            stations.forEachIndexed { index, station ->
                val sx = if (isSchematicView) station.mapXRatio * canvasW else (0.15f + station.mapXRatio * 0.7f) * canvasW
                val sy = if (isSchematicView) station.mapYRatio * canvasH else (0.10f + station.mapYRatio * 0.8f) * canvasH
                if (index == 0) {
                    trackPath.moveTo(sx, sy)
                } else {
                    trackPath.lineTo(sx, sy)
                }
            }

            // Outer glow line
            drawPath(
                path = trackPath,
                color = MetroM1TealGlow.copy(alpha = 0.35f),
                style = Stroke(width = 18f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // Main line
            drawPath(
                path = trackPath,
                color = MetroM1Teal,
                style = Stroke(width = 8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // 3. Draw Stations
            stations.forEach { station ->
                val sx = if (isSchematicView) station.mapXRatio * canvasW else (0.15f + station.mapXRatio * 0.7f) * canvasW
                val sy = if (isSchematicView) station.mapYRatio * canvasH else (0.10f + station.mapYRatio * 0.8f) * canvasH

                val isSelected = selectedStation?.id == station.id
                val radius = if (station.isInterchange) 12f else 8f

                // Outer border
                drawCircle(
                    color = if (isSelected) MetroM1TealGlow else Color.White,
                    radius = radius + 4f,
                    center = Offset(sx, sy)
                )

                // Fill
                drawCircle(
                    color = if (station.isClosed) Color.Red else MetroDarkNavy,
                    radius = radius,
                    center = Offset(sx, sy)
                )

                if (station.isInterchange) {
                    drawCircle(
                        color = MetroM1Teal,
                        radius = 4f,
                        center = Offset(sx, sy)
                    )
                }
            }

            // 4. Draw Animated Moving Trains
            trains.forEach { train ->
                val s1 = stations.find { it.id == train.currentStationId }
                val s2 = stations.find { it.id == train.nextStationId }
                if (s1 != null && s2 != null) {
                    val x1 = if (isSchematicView) s1.mapXRatio * canvasW else (0.15f + s1.mapXRatio * 0.7f) * canvasW
                    val y1 = if (isSchematicView) s1.mapYRatio * canvasH else (0.10f + s1.mapYRatio * 0.8f) * canvasH
                    val x2 = if (isSchematicView) s2.mapXRatio * canvasW else (0.15f + s2.mapXRatio * 0.7f) * canvasW
                    val y2 = if (isSchematicView) s2.mapYRatio * canvasH else (0.10f + s2.mapYRatio * 0.8f) * canvasH

                    val tx = x1 + (x2 - x1) * train.progressToNext
                    val ty = y1 + (y2 - y1) * train.progressToNext

                    // Train outer pulse glow
                    drawCircle(
                        color = MetroM1TealGlow.copy(alpha = 0.5f),
                        radius = 20f,
                        center = Offset(tx, ty)
                    )

                    // Train dot
                    drawCircle(
                        color = MetroWhite,
                        radius = 12f,
                        center = Offset(tx, ty)
                    )

                    drawCircle(
                        color = MetroM1Teal,
                        radius = 8f,
                        center = Offset(tx, ty)
                    )
                }
            }
        }

        // Top Control Overlay (Toggle Schematic / Geographic View)
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(MetroCardSurface.copy(alpha = 0.9f))
                .border(1.dp, MetroCardBorder, RoundedCornerShape(20.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { isSchematicView = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSchematicView) MetroM1Teal else Color.Transparent
                ),
                contentPadding = PaddingValuesHorizontal12Vertical4(),
                modifier = Modifier.testTag("map_toggle_schematic")
            ) {
                Text("SCHEMATIC", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(6.dp))

            Button(
                onClick = { isSchematicView = false },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (!isSchematicView) MetroM1Teal else Color.Transparent
                ),
                contentPadding = PaddingValuesHorizontal12Vertical4(),
                modifier = Modifier.testTag("map_toggle_geographic")
            ) {
                Text("GEOGRAPHIC", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Live Active Trains Legend Overlay
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MetroCardSurface.copy(alpha = 0.9f))
                .border(1.dp, MetroCardBorder, RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(StatusGoodGreen)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${trains.size} TRAINS ACTIVE",
                    color = MetroWhite,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Bottom Selection Panel Sheet
        AnimatedVisibility(
            visible = selectedStation != null || selectedTrain != null,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        ) {
            Surface(
                color = MetroCardSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MetroM1Teal),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (selectedStation != null) {
                        val st = selectedStation!!
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = st.name.uppercase(),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MetroWhite,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = if (st.isInterchange) "INTERCHANGE STATION • M1 METRO" else "SYDNEY METRO M1 STATION",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MetroM1TealGlow
                                )
                            }
                            Button(
                                onClick = { onStationSelect(st) },
                                colors = ButtonDefaults.buttonColors(containerColor = MetroM1Teal),
                                modifier = Modifier.testTag("open_station_detail")
                            ) {
                                Text("VIEW DASHBOARD", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        st.platforms.forEach { platform ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Platform ${platform.platformNumber} → ${platform.destination}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MetroTextSecondary
                                )
                                Text(
                                    text = "${platform.nextTrainArrivalMinutes} min",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MetroWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (selectedTrain != null) {
                        val tr = selectedTrain!!
                        val nextSt = stations.find { it.id == tr.nextStationId }?.name ?: "Next Station"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "LIVE METRO TRAIN ${tr.id}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MetroWhite,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Towards ${if (tr.direction == com.example.data.model.TrainDirection.TOWARDS_SYDENHAM) "Sydenham" else "Tallawong"}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MetroM1TealGlow
                                )
                            }

                            Button(
                                onClick = { onTrainSelect(tr) },
                                colors = ButtonDefaults.buttonColors(containerColor = MetroM1Teal),
                                modifier = Modifier.testTag("open_train_detail")
                            ) {
                                Text("LIVE MONITOR", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Next: $nextSt in ${tr.minutesToNextStation} min",
                                style = MaterialTheme.typography.bodySmall,
                                color = MetroWhite
                            )
                            Text(
                                text = "Speed: ${tr.currentSpeedKmH} km/h",
                                style = MaterialTheme.typography.bodySmall,
                                color = MetroM1TealGlow,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PaddingValuesHorizontal12Vertical4() = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp)
