package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SophisticatedDarkColorScheme = darkColorScheme(
    primary = MetroM1Teal,
    onPrimary = MetroWhite,
    primaryContainer = MetroCardDark,
    onPrimaryContainer = MetroM1TealGlow,
    secondary = MetroAccentCyan,
    onSecondary = MetroDeepBlack,
    secondaryContainer = MetroSurfaceDark,
    onSecondaryContainer = MetroWhite,
    tertiary = MetroM2Orange,
    background = MetroDeepBlack,
    onBackground = MetroWhite,
    surface = MetroSurfaceDark,
    onSurface = MetroWhite,
    surfaceVariant = MetroCardDark,
    onSurfaceVariant = MetroTextSecondary,
    outline = MetroCardBorder
)

@Composable
fun SydneyMetroTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SophisticatedDarkColorScheme,
        typography = Typography,
        content = content
    )
}
