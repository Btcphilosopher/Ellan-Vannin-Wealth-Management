package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Sydney Metro Palette
val MetroDeepBlack = Color(0xFF050608)
val MetroSurfaceDark = Color(0xFF0C1017)
val MetroCardDark = Color(0xFF111823)
val MetroCardBorder = Color(0x1AFFFFFF) // White 10%

// Line & Accent Colors
val MetroM1Teal = Color(0xFF0099A9)
val MetroM1TealGlow = Color(0xFF00E5E8)
val MetroM2Orange = Color(0xFFFF6D00)
val SydneyTrainsOrange = Color(0xFFF37021)
val LightRailRed = Color(0xFFDC241F)
val FerryGreen = Color(0xFF00875A)

// Status Indicators
val StatusGoodGreen = Color(0xFF22C55E)
val StatusWarningAmber = Color(0xFFF59E0B)
val StatusErrorRed = Color(0xFFEF4444)

// Text & Accents
val MetroWhite = Color(0xFFFFFFFF)
val MetroTextSecondary = Color(0xFF94A3B8)
val MetroTextMuted = Color(0xFF64748B)
val MetroAccentCyan = Color(0xFF00E5FF)
