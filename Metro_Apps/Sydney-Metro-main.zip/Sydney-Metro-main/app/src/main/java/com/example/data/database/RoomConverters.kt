package com.example.data.database

import androidx.room.TypeConverter
import com.example.data.model.Facility
import com.example.data.model.Platform
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class RoomConverters {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    @TypeConverter
    fromPlatformList(value: List<Platform>?): String {
        if (value == null) return "[]"
        val type = Types.newParameterizedType(List::class.java, Platform::class.java)
        val adapter = moshi.adapter<List<Platform>>(type)
        return adapter.toJson(value)
    }

    @TypeConverter
    fun toPlatformList(value: String): List<Platform> {
        val type = Types.newParameterizedType(List::class.java, Platform::class.java)
        val adapter = moshi.adapter<List<Platform>>(type)
        return adapter.fromJson(value) ?: emptyList()
    }

    @TypeConverter
    fun fromFacilityList(value: List<Facility>?): String {
        if (value == null) return "[]"
        val type = Types.newParameterizedType(List::class.java, Facility::class.java)
        val adapter = moshi.adapter<List<Facility>>(type)
        return adapter.toJson(value)
    }

    @TypeConverter
    fun toFacilityList(value: String): List<Facility> {
        val type = Types.newParameterizedType(List::class.java, Facility::class.java)
        val adapter = moshi.adapter<List<Facility>>(type)
        return adapter.fromJson(value) ?: emptyList()
    }

    @TypeConverter
    fun fromStringList(value: List<String>?): String {
        if (value == null) return "[]"
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        val adapter = moshi.adapter<List<String>>(type)
        return adapter.toJson(value)
    }

    @TypeConverter
    fun toStringList(value: String): List<String> {
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        val adapter = moshi.adapter<List<String>>(type)
        return adapter.fromJson(value) ?: emptyList()
    }
}
