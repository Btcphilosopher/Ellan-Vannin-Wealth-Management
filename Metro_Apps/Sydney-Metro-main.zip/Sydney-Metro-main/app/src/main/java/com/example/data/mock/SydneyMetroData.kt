package com.example.data.mock

import com.example.data.model.Facility
import com.example.data.model.FacilityStatus
import com.example.data.model.OccupancyLevel
import com.example.data.model.Platform
import com.example.data.model.Station
import com.example.data.model.StationFacilityType
import com.example.data.model.Train
import com.example.data.model.TrainDirection

object SydneyMetroData {

    val STATIONS: List<Station> = listOf(
        Station(
            id = "S01",
            name = "Tallawong",
            lineCode = "M1",
            latitude = -33.689,
            longitude = 150.902,
            mapXRatio = 0.08f,
            mapYRatio = 0.12f,
            platforms = listOf(
                Platform(1, "Towards Sydenham", "M1", 2, 7, "Sydenham"),
                Platform(2, "Terminating / Storage", "M1", 0, 0, "Tallawong")
            ),
            facilities = listOf(
                Facility("F01", "Lift A (Concourse)", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Concourse"),
                Facility("F02", "Escalator 1", StationFacilityType.ESCALATOR, FacilityStatus.OPERATIONAL, "Platform 1"),
                Facility("F03", "Bus Interchange", StationFacilityType.BUS_INTERCHANGE, FacilityStatus.OPERATIONAL, "Street Level")
            ),
            isInterchange = true,
            interchangeLines = listOf("Bus Routes 740, 742, 752")
        ),
        Station(
            id = "S02",
            name = "Rouse Hill",
            lineCode = "M1",
            latitude = -33.692,
            longitude = 150.923,
            mapXRatio = 0.12f,
            mapYRatio = 0.16f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 4, 9, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 3, 8, "Sydenham")
            ),
            facilities = listOf(
                Facility("F04", "Lift B", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Concourse"),
                Facility("F05", "Customer Service", StationFacilityType.CUSTOMER_SERVICE, FacilityStatus.OPERATIONAL, "Main Entrance")
            )
        ),
        Station(
            id = "S03",
            name = "Kellyville",
            lineCode = "M1",
            latitude = -33.704,
            longitude = 150.945,
            mapXRatio = 0.16f,
            mapYRatio = 0.20f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 6, 11, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 5, 10, "Sydenham")
            ),
            facilities = listOf(
                Facility("F06", "Lift A", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Concourse")
            )
        ),
        Station(
            id = "S04",
            name = "Bella Vista",
            lineCode = "M1",
            latitude = -33.729,
            longitude = 150.961,
            mapXRatio = 0.20f,
            mapYRatio = 0.24f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 8, 13, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 2, 7, "Sydenham")
            ),
            facilities = listOf(
                Facility("F07", "Lift A", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Platform")
            )
        ),
        Station(
            id = "S05",
            name = "Norwest",
            lineCode = "M1",
            latitude = -33.731,
            longitude = 150.996,
            mapXRatio = 0.25f,
            mapYRatio = 0.28f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 10, 15, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 4, 9, "Sydenham")
            ),
            facilities = listOf(
                Facility("F08", "Escalator 1", StationFacilityType.ESCALATOR, FacilityStatus.OPERATIONAL, "Platform")
            )
        ),
        Station(
            id = "S06",
            name = "Hills Showground",
            lineCode = "M1",
            latitude = -33.733,
            longitude = 151.002,
            mapXRatio = 0.30f,
            mapYRatio = 0.32f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 12, 17, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 1, 6, "Sydenham")
            ),
            facilities = listOf(
                Facility("F09", "Lift A", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Concourse")
            )
        ),
        Station(
            id = "S07",
            name = "Castle Hill",
            lineCode = "M1",
            latitude = -33.731,
            longitude = 151.006,
            mapXRatio = 0.35f,
            mapYRatio = 0.36f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 14, 19, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 3, 8, "Sydenham")
            ),
            facilities = listOf(
                Facility("F10", "Escalator Bank", StationFacilityType.ESCALATOR, FacilityStatus.OPERATIONAL, "Retail Level")
            )
        ),
        Station(
            id = "S08",
            name = "Cherrybrook",
            lineCode = "M1",
            latitude = -33.725,
            longitude = 151.031,
            mapXRatio = 0.40f,
            mapYRatio = 0.40f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 16, 21, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 5, 10, "Sydenham")
            ),
            facilities = listOf(
                Facility("F11", "Lift A", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Street")
            )
        ),
        Station(
            id = "S09",
            name = "Epping",
            lineCode = "M1",
            latitude = -33.772,
            longitude = 151.082,
            mapXRatio = 0.45f,
            mapYRatio = 0.46f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 3, 8, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 2, 7, "Sydenham")
            ),
            facilities = listOf(
                Facility("F12", "Interchange Concourse", StationFacilityType.TICKET_GATE, FacilityStatus.OPERATIONAL, "Concourse"),
                Facility("F13", "Lift C (Rail Interchange)", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Plat 5/6 Connect")
            ),
            isInterchange = true,
            interchangeLines = listOf("Sydney Trains T1 Northern Line", "T9 Northern Line")
        ),
        Station(
            id = "S10",
            name = "Macquarie University",
            lineCode = "M1",
            latitude = -33.775,
            longitude = 151.114,
            mapXRatio = 0.50f,
            mapYRatio = 0.50f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 5, 10, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 4, 9, "Sydenham")
            ),
            facilities = listOf(
                Facility("F14", "Campus Entrance Lift", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "University Square")
            )
        ),
        Station(
            id = "S11",
            name = "Macquarie Park",
            lineCode = "M1",
            latitude = -33.778,
            longitude = 151.127,
            mapXRatio = 0.55f,
            mapYRatio = 0.54f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 7, 12, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 6, 11, "Sydenham")
            ),
            facilities = listOf(
                Facility("F15", "Escalator 2", StationFacilityType.ESCALATOR, FacilityStatus.OPERATIONAL, "Lane Cove Rd")
            )
        ),
        Station(
            id = "S12",
            name = "Chatswood",
            lineCode = "M1",
            latitude = -33.797,
            longitude = 151.181,
            mapXRatio = 0.60f,
            mapYRatio = 0.58f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 2, 6, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 1, 5, "Sydenham")
            ),
            facilities = listOf(
                Facility("F16", "Platform 2 Lift", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Concourse"),
                Facility("F17", "Interchange Gates", StationFacilityType.TICKET_GATE, FacilityStatus.OPERATIONAL, "Concourse")
            ),
            isInterchange = true,
            interchangeLines = listOf("T1 North Shore Line", "T9 Northern Line", "Bus Interchange")
        ),
        Station(
            id = "S13",
            name = "Crows Nest",
            lineCode = "M1",
            latitude = -33.826,
            longitude = 151.201,
            mapXRatio = 0.64f,
            mapYRatio = 0.63f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 4, 9, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 2, 6, "Sydenham")
            ),
            facilities = listOf(
                Facility("F18", "Clarke St Lift", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Street Level")
            )
        ),
        Station(
            id = "S14",
            name = "Victoria Cross",
            lineCode = "M1",
            latitude = -33.838,
            longitude = 151.207,
            mapXRatio = 0.68f,
            mapYRatio = 0.67f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 6, 11, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 3, 8, "Sydenham")
            ),
            facilities = listOf(
                Facility("F19", "High Speed Elevator Bank", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Miller St"),
                Facility("F20", "Over-station Concourse", StationFacilityType.RETAIL, FacilityStatus.OPERATIONAL, "Level 1")
            ),
            nearbyAttractions = listOf("North Sydney CBD", "ACU Campus", "Greenwood Plaza")
        ),
        Station(
            id = "S15",
            name = "Barangaroo",
            lineCode = "M1",
            latitude = -33.863,
            longitude = 151.202,
            mapXRatio = 0.72f,
            mapYRatio = 0.72f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 8, 13, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 1, 5, "Sydenham")
            ),
            facilities = listOf(
                Facility("F21", "Ferry Connection Lift", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Wharf Walkway"),
                Facility("F22", "Escalator 3", StationFacilityType.ESCALATOR, FacilityStatus.OPERATIONAL, "Hickson Rd Entrance")
            ),
            isInterchange = true,
            interchangeLines = listOf("Barangaroo Ferry Wharf", "F3 Parramatta River Ferry"),
            nearbyAttractions = listOf("Barangaroo Reserve", "Crown Sydney", "Darling Harbour Walk", "Wynyard Tunnel")
        ),
        Station(
            id = "S16",
            name = "Martin Place",
            lineCode = "M1",
            latitude = -33.868,
            longitude = 151.211,
            mapXRatio = 0.77f,
            mapYRatio = 0.77f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 2, 7, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 3, 8, "Sydenham")
            ),
            facilities = listOf(
                Facility("F23", "Hunter St Portal Escalators", StationFacilityType.ESCALATOR, FacilityStatus.OPERATIONAL, "Hunter St Entrance"),
                Facility("F24", "Underground Pedestrian Tunnel Lift", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "T4 Line Connect")
            ),
            isInterchange = true,
            interchangeLines = listOf("T4 Eastern Suburbs Line", "Light Rail L2/L3 Bridge St"),
            nearbyAttractions = listOf("Sydney CBD", "State Library of NSW", "Hyde Park", "Art Gallery of NSW")
        ),
        Station(
            id = "S17",
            name = "Gadigal",
            lineCode = "M1",
            latitude = -33.875,
            longitude = 151.208,
            mapXRatio = 0.81f,
            mapYRatio = 0.81f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 4, 9, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 2, 6, "Sydenham")
            ),
            facilities = listOf(
                Facility("F25", "Park St Entrance Lift", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Park St"),
                Facility("F26", "Bathurst St Escalators", StationFacilityType.ESCALATOR, FacilityStatus.OPERATIONAL, "Bathurst St")
            ),
            nearbyAttractions = listOf("Pitt St Mall", "QVB Building", "Town Hall", "Hyde Park South")
        ),
        Station(
            id = "S18",
            name = "Central",
            lineCode = "M1",
            latitude = -33.883,
            longitude = 151.206,
            mapXRatio = 0.86f,
            mapYRatio = 0.86f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 2, 6, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 3, 7, "Sydenham")
            ),
            facilities = listOf(
                Facility("F27", "Central Walk Lift A", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Central Walk"),
                Facility("F28", "Central Walk Lift B", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Heavy Rail Connect"),
                Facility("F29", "Escalator 4", StationFacilityType.ESCALATOR, FacilityStatus.OPERATIONAL, "Grand Concourse")
            ),
            isInterchange = true,
            interchangeLines = listOf("Sydney Trains T1/T2/T3/T4/T8/T9", "Light Rail L1/L2/L3", "Regional NSW TrainLink"),
            nearbyAttractions = listOf("UTS", "Chinatown", "Capital Theatre", "Haymarket")
        ),
        Station(
            id = "S19",
            name = "Waterloo",
            lineCode = "M1",
            latitude = -33.898,
            longitude = 151.204,
            mapXRatio = 0.90f,
            mapYRatio = 0.90f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 5, 10, "Tallawong"),
                Platform(2, "Towards Sydenham", "M1", 4, 9, "Sydenham")
            ),
            facilities = listOf(
                Facility("F30", "Raglan St Lift", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Street Level")
            )
        ),
        Station(
            id = "S20",
            name = "Sydenham",
            lineCode = "M1",
            latitude = -33.916,
            longitude = 151.166,
            mapXRatio = 0.95f,
            mapYRatio = 0.95f,
            platforms = listOf(
                Platform(1, "Towards Tallawong", "M1", 3, 8, "Tallawong"),
                Platform(2, "Terminating / Turning", "M1", 0, 0, "Sydenham")
            ),
            facilities = listOf(
                Facility("F31", "Concourse Interchange Lift", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Concourse"),
                Facility("F32", "Platform 1/2 Ramp", StationFacilityType.LIFT, FacilityStatus.OPERATIONAL, "Accessible Platform Ramp")
            ),
            isInterchange = true,
            interchangeLines = listOf("T4 Illawarra Line", "T8 Airport Line Connection")
        )
    )

    val INITIAL_TRAINS: List<Train> = listOf(
        Train(
            id = "T101",
            lineCode = "M1",
            direction = TrainDirection.TOWARDS_SYDENHAM,
            currentStationId = "S12", // Chatswood
            nextStationId = "S13", // Crows Nest
            minutesToNextStation = 2,
            progressToNext = 0.45f,
            delayMinutes = 0,
            occupancy = OccupancyLevel.LOW,
            currentSpeedKmH = 82
        ),
        Train(
            id = "T102",
            lineCode = "M1",
            direction = TrainDirection.TOWARDS_SYDENHAM,
            currentStationId = "S15", // Barangaroo
            nextStationId = "S16", // Martin Place
            minutesToNextStation = 3,
            progressToNext = 0.20f,
            delayMinutes = 0,
            occupancy = OccupancyLevel.MEDIUM,
            currentSpeedKmH = 76
        ),
        Train(
            id = "T103",
            lineCode = "M1",
            direction = TrainDirection.TOWARDS_SYDENHAM,
            currentStationId = "S01", // Tallawong
            nextStationId = "S02", // Rouse Hill
            minutesToNextStation = 1,
            progressToNext = 0.70f,
            delayMinutes = 0,
            occupancy = OccupancyLevel.LOW,
            currentSpeedKmH = 88
        ),
        Train(
            id = "T104",
            lineCode = "M1",
            direction = TrainDirection.TOWARDS_TALLAWONG,
            currentStationId = "S18", // Central
            nextStationId = "S17", // Gadigal
            minutesToNextStation = 2,
            progressToNext = 0.55f,
            delayMinutes = 0,
            occupancy = OccupancyLevel.HIGH,
            currentSpeedKmH = 72
        ),
        Train(
            id = "T105",
            lineCode = "M1",
            direction = TrainDirection.TOWARDS_TALLAWONG,
            currentStationId = "S12", // Chatswood
            nextStationId = "S11", // Macquarie Park
            minutesToNextStation = 4,
            progressToNext = 0.15f,
            delayMinutes = 0,
            occupancy = OccupancyLevel.LOW,
            currentSpeedKmH = 85
        )
    )

    val INITIAL_ALERTS: List<ServiceAlert> = listOf(
        ServiceAlert(
            id = "ALT01",
            lineCode = "M1",
            lineName = "Sydney Metro M1",
            severity = AlertSeverity.GOOD,
            message = "Good Service across all Sydney Metro M1 stations.",
            affectedSection = "Tallawong ↔ Sydenham"
        ),
        ServiceAlert(
            id = "ALT02",
            lineCode = "T1",
            lineName = "Sydney Trains T1 / T9",
            severity = AlertSeverity.MINOR_DELAYS,
            message = "Minor delays due to track maintenance at Strathfield.",
            affectedSection = "Berowra to Hornsby via City",
            recommendedAlternative = "Use Sydney Metro M1 from Chatswood to Central for faster underground transit."
        ),
        ServiceAlert(
            id = "ALT03",
            lineCode = "L2",
            lineName = "Sydney Light Rail L2 / L3",
            severity = AlertSeverity.GOOD,
            message = "Normal service operating between Circular Quay and Randwick/Juniper.",
            affectedSection = "Circular Quay ↔ Randwick / Kingsford"
        )
    )
}
