package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class OccupancyLevel {
    LOW, MEDIUM, HIGH
}

enum class StationFacilityType {
    LIFT, ESCALATOR, TICKET_GATE, TOILET, RETAIL, CUSTOMER_SERVICE, BUS_INTERCHANGE, LIGHT_RAIL, FERRY
}

enum class FacilityStatus {
    OPERATIONAL, MAINTENANCE, CLOSED
}

data class Facility(
    val id: String,
    val name: String,
    val type: StationFacilityType,
    val status: FacilityStatus,
    val level: String,
    val details: String = ""
)

data class Platform(
    val platformNumber: Int,
    val directionName: String, // e.g. "Towards Sydenham" or "Towards Tallawong"
    val lineCode: String = "M1",
    val nextTrainArrivalMinutes: Int,
    val followingTrainArrivalMinutes: Int,
    val destination: String
)

@Entity(tableName = "favorite_stations")
data class Station(
    @PrimaryKey val id: String,
    val name: String,
    val lineCode: String = "M1",
    val latitude: Double,
    val longitude: Double,
    val mapXRatio: Float, // Relative X on 0..1 map canvas
    val mapYRatio: Float, // Relative Y on 0..1 map canvas
    val platforms: List<Platform>,
    val facilities: List<Facility>,
    val isInterchange: Boolean = false,
    val interchangeLines: List<String> = emptyList(),
    val nearbyAttractions: List<String> = emptyList(),
    val isClosed: Boolean = false,
    val isFavorite: Boolean = false
)

enum class TrainDirection {
    TOWARDS_SYDENHAM, TOWARDS_TALLAWONG
}

data class Train(
    val id: String, // e.g. "T123"
    val lineCode: String = "M1",
    val direction: TrainDirection,
    val currentStationId: String,
    val nextStationId: String,
    val minutesToNextStation: Int,
    val progressToNext: Float, // 0.0f..1.0f
    val delayMinutes: Int = 0,
    val occupancy: OccupancyLevel = OccupancyLevel.LOW,
    val carCount: Int = 6,
    val currentSpeedKmH: Int = 78,
    val carOccupancy: List<OccupancyLevel> = listOf(
        OccupancyLevel.LOW, OccupancyLevel.LOW, OccupancyLevel.MEDIUM,
        OccupancyLevel.LOW, OccupancyLevel.MEDIUM, OccupancyLevel.LOW
    )
)

data class JourneySegment(
    val mode: String, // "WALK", "METRO", "INTERCHANGE", "SYDNEY_TRAINS"
    val instruction: String,
    val fromStationName: String,
    val toStationName: String,
    val platform: String? = null,
    val durationMinutes: Int,
    val lineCode: String = "M1",
    val intermediateStops: List<String> = emptyList()
)

data class JourneyPlan(
    val id: String,
    val originStationId: String,
    val originName: String,
    val destinationStationId: String,
    val destinationName: String,
    val totalDurationMinutes: Int,
    val departureTime: String,
    val arrivalTime: String,
    val fareAud: Double,
    val isAccessible: Boolean,
    val segments: List<JourneySegment>,
    val alternativeNote: String? = null
)

enum class AlertSeverity {
    GOOD, MINOR_DELAYS, MAJOR_DELAYS, SUSPENDED
}

data class ServiceAlert(
    val id: String,
    val lineCode: String,
    val lineName: String,
    val severity: AlertSeverity,
    val message: String,
    val affectedSection: String,
    val recommendedAlternative: String? = null
)

@Entity(tableName = "opal_transactions")
data class OpalTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val fromStation: String,
    val toStation: String,
    val lineCode: String,
    val amountAud: Double,
    val timeFormatted: String
)

data class TravelAnalytics(
    val tripsThisMonth: Int = 42,
    val stationsVisited: Int = 27,
    val metroDistanceKm: Int = 184,
    val totalTimeSpentHours: Int = 11,
    val totalTimeSpentMinutes: Int = 42,
    val averageJourneyMinutes: Int = 26,
    val peakTripsPercentage: Int = 68,
    val weeklyDistanceSeries: List<Pair<String, Int>> = listOf(
        "Mon" to 12, "Tue" to 24, "Wed" to 18, "Thu" to 30, "Fri" to 22, "Sat" to 8, "Sun" to 14
    )
)
