package com.example.ui.boardingpass

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BoardingPassCard
import com.example.ui.theme.RiyadhBackground
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhSurface
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun BoardingPassScreen(
    viewModel: BoardingPassViewModel,
    pnr: String,
    onBackClick: () -> Unit,
    isArabic: Boolean = false
) {
    val booking by viewModel.booking.collectAsState()

    LaunchedEffect(pnr) {
        viewModel.loadBoardingPass(pnr)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RiyadhBackground)
            .verticalScroll(rememberScrollState())
    ) {
        // Top Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(RiyadhSurface)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBackClick, modifier = Modifier.testTag("boarding_pass_back_button")) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (isArabic) "بطاقة صعود الطائرة الرقمية" else "Digital Boarding Pass",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = RiyadhTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    )
                    Text(
                        text = "PNR: $pnr • Cached Offline Valid",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = RiyadhTextSecondary,
                            fontSize = 12.sp
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            if (booking == null) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = RiyadhIndigoPrimary)
                }
            } else {
                BoardingPassCard(
                    booking = booking!!,
                    isArabic = isArabic
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
