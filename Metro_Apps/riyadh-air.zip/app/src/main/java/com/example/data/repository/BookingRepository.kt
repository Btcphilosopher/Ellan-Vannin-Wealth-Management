package com.example.data.repository

import com.example.data.local.BookingDao
import com.example.data.local.BookingEntity
import com.example.data.remote.MockAirlineData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class BookingRepository(private val bookingDao: BookingDao) {

    val allBookingsFlow: Flow<List<BookingEntity>> = bookingDao.getAllBookings()
    val activeTripFlow: Flow<BookingEntity?> = bookingDao.getActiveTrip()

    suspend fun seedInitialBookingIfEmpty() {
        val count = bookingDao.getAllBookings().firstOrNull()?.size ?: 0
        if (count == 0) {
            bookingDao.insertBooking(MockAirlineData.INITIAL_ACTIVE_BOOKING)
        }
    }

    suspend fun getBookingByPnr(pnr: String): BookingEntity? {
        return bookingDao.getBookingByPnr(pnr)
    }

    suspend fun createBooking(booking: BookingEntity) {
        bookingDao.insertBooking(booking)
    }

    suspend fun performCheckIn(pnr: String, seatNumber: String): Boolean {
        val booking = bookingDao.getBookingByPnr(pnr) ?: return false
        val updated = booking.copy(
            status = "CHECKED_IN",
            seatNumber = seatNumber,
            qrCodeData = "RIYADHAIR-CHECKEDIN-${booking.bookingReference}-${booking.passengerName.replace(" ", "")}-${booking.originIata}${booking.destIata}-$seatNumber"
        )
        bookingDao.updateBooking(updated)
        return true
    }

    suspend fun updateSeat(pnr: String, seatNumber: String): Boolean {
        val booking = bookingDao.getBookingByPnr(pnr) ?: return false
        bookingDao.updateBooking(booking.copy(seatNumber = seatNumber))
        return true
    }

    suspend fun cancelBooking(pnr: String): Boolean {
        val booking = bookingDao.getBookingByPnr(pnr) ?: return false
        bookingDao.updateBooking(booking.copy(status = "CANCELLED"))
        return true
    }
}
