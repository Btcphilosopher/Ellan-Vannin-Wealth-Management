package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY createdTimestamp DESC")
    fun getAllBookings(): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE bookingReference = :pnr LIMIT 1")
    suspend fun getBookingByPnr(pnr: String): BookingEntity?

    @Query("SELECT * FROM bookings WHERE status IN ('CONFIRMED', 'CHECKED_IN', 'BOARDING') ORDER BY createdTimestamp DESC LIMIT 1")
    fun getActiveTrip(): Flow<BookingEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity)

    @Update
    suspend fun updateBooking(booking: BookingEntity)

    @Query("DELETE FROM bookings WHERE bookingReference = :pnr")
    suspend fun deleteBooking(pnr: String)
}
