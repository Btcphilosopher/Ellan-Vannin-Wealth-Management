package com.example.ui.loyalty

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.RiyadhBackground
import com.example.ui.theme.RiyadhGoldAccent
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurface
import com.example.ui.theme.RiyadhSurfaceCard
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun LoyaltyScreen(
    isArabic: Boolean = false
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RiyadhBackground)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(RiyadhSurface)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Text(
                text = if (isArabic) "برنامج ضيافة طيران الرياض" else "Riyadh Executive Loyalty",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = RiyadhTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            )
        }

        Column(modifier = Modifier.padding(16.dp)) {
            // Loyalty Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RiyadhGoldAccent, RoundedCornerShape(22.dp))
                    .testTag("loyalty_card"),
                colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "RIYADH EXECUTIVE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = RiyadhLavenderLight,
                                    letterSpacing = 1.2.sp,
                                    fontSize = 10.sp
                                )
                            )
                            Text(
                                text = "Gold Member",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    color = RiyadhGoldAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Gold Tier",
                            tint = RiyadhGoldAccent,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "Tariq Al-Mansoor",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = RiyadhTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Member ID: RX-8840219",
                        style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Riyadh Points", style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp))
                            Text(text = "128,400", style = MaterialTheme.typography.titleLarge.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Tier Status", style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp))
                            Text(text = "Gold Active", style = MaterialTheme.typography.titleMedium.copy(color = RiyadhGoldAccent, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = if (isArabic) "مزايا الفئة الذهبية" else "Gold Tier Privileges",
                style = MaterialTheme.typography.titleSmall.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(10.dp))

            val privileges = listOf(
                "Complimentary Riyadh Executive Lounge access globally",
                "Priority check-in & fast-track security lanes",
                "Additional 32kg checked baggage allowance",
                "100% bonus Riyadh points on every flight"
            )

            privileges.forEach { priv ->
                Row(
                    modifier = Modifier.padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(RiyadhGoldAccent)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = priv, style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary))
                }
            }
        }
    }
}
