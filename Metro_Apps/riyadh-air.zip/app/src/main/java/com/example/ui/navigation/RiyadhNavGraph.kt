package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.local.UserPreferencesManager
import com.example.data.repository.BookingRepository
import com.example.data.repository.FlightRepository
import com.example.ui.boardingpass.BoardingPassScreen
import com.example.ui.boardingpass.BoardingPassViewModel
import com.example.ui.booking.BookingFlowScreen
import com.example.ui.booking.BookingViewModel
import com.example.ui.checkin.CheckInScreen
import com.example.ui.checkin.CheckInViewModel
import com.example.ui.components.RiyadhBottomNavigation
import com.example.ui.components.RiyadhTopAppBar
import com.example.ui.discover.DiscoverScreen
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.loyalty.LoyaltyScreen
import com.example.ui.search.FlightResultsScreen
import com.example.ui.search.SearchViewModel
import com.example.ui.settings.SettingsScreen
import com.example.ui.trips.TripsScreen
import com.example.ui.trips.TripsViewModel

@Composable
fun RiyadhApp(
    flightRepository: FlightRepository,
    bookingRepository: BookingRepository,
    userPreferencesManager: UserPreferencesManager,
    navController: NavHostController = rememberNavController()
) {
    val homeViewModel = remember { HomeViewModel(bookingRepository, userPreferencesManager) }
    val searchViewModel = remember { SearchViewModel(flightRepository) }
    val bookingViewModel = remember { BookingViewModel(flightRepository, bookingRepository) }
    val tripsViewModel = remember { TripsViewModel(bookingRepository) }
    val checkInViewModel = remember { CheckInViewModel(bookingRepository) }
    val boardingPassViewModel = remember { BoardingPassViewModel(bookingRepository) }

    val currentLang by userPreferencesManager.languageFlow.collectAsState(initial = "en")
    val currentCurr by userPreferencesManager.currencyFlow.collectAsState(initial = "SAR")
    val isArabic = currentLang == "ar"

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: NavRoutes.Home.route

    val showBottomBar = currentRoute in listOf(
        NavRoutes.Home.route,
        NavRoutes.Trips.route,
        NavRoutes.CheckIn.route,
        NavRoutes.Discover.route,
        NavRoutes.Profile.route
    )

    Scaffold(
        topBar = {
            if (currentRoute == NavRoutes.Home.route) {
                RiyadhTopAppBar(
                    onLanguageClick = { homeViewModel.toggleLanguage() },
                    currentLanguage = currentLang
                )
            }
        },
        bottomBar = {
            if (showBottomBar) {
                RiyadhBottomNavigation(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        navController.navigate(route) {
                            popUpTo(NavRoutes.Home.route) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    isArabic = isArabic
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            NavHost(
                navController = navController,
                startDestination = NavRoutes.Home.route
            ) {
                composable(NavRoutes.Home.route) {
                    HomeScreen(
                        viewModel = homeViewModel,
                        onNavigateToSearch = { origin, dest, date, cabin ->
                            navController.navigate(NavRoutes.FlightResults.createRoute(origin, dest, date, cabin))
                        },
                        onNavigateToBoardingPass = { pnr ->
                            navController.navigate(NavRoutes.BoardingPass.createRoute(pnr))
                        },
                        onNavigateToTripDetails = { pnr ->
                            navController.navigate(NavRoutes.BoardingPass.createRoute(pnr))
                        },
                        onNavigateToDiscoverDetail = {
                            navController.navigate(NavRoutes.Discover.route)
                        },
                        isArabic = isArabic
                    )
                }

                composable(
                    route = NavRoutes.FlightResults.route,
                    arguments = listOf(
                        navArgument("origin") { type = NavType.StringType },
                        navArgument("dest") { type = NavType.StringType },
                        navArgument("date") { type = NavType.StringType },
                        navArgument("cabin") { type = NavType.StringType }
                    )
                ) { entry ->
                    val origin = entry.arguments?.getString("origin") ?: "RUH"
                    val dest = entry.arguments?.getString("dest") ?: "LHR"
                    val date = entry.arguments?.getString("date") ?: "12 Nov 2025"
                    val cabin = entry.arguments?.getString("cabin") ?: "BUSINESS"

                    FlightResultsScreen(
                        viewModel = searchViewModel,
                        originIata = origin,
                        destIata = dest,
                        date = date,
                        cabinClass = cabin,
                        onSelectFlight = { flight ->
                            val fareId = flight.fares[0].id
                            navController.navigate(NavRoutes.BookingFlow.createRoute(flight.id, fareId))
                        },
                        onBackClick = { navController.popBackStack() },
                        currency = currentCurr,
                        isArabic = isArabic
                    )
                }

                composable(
                    route = NavRoutes.BookingFlow.route,
                    arguments = listOf(
                        navArgument("flightId") { type = NavType.StringType },
                        navArgument("fareId") { type = NavType.StringType }
                    )
                ) { entry ->
                    val flightId = entry.arguments?.getString("flightId") ?: "RX102"
                    val fareId = entry.arguments?.getString("fareId") ?: "fare_bus_choice"

                    BookingFlowScreen(
                        viewModel = bookingViewModel,
                        flightId = flightId,
                        fareId = fareId,
                        onNavigateToBoardingPass = { pnr ->
                            navController.navigate(NavRoutes.BoardingPass.createRoute(pnr))
                        },
                        onNavigateToTrips = {
                            navController.navigate(NavRoutes.Trips.route) {
                                popUpTo(NavRoutes.Home.route)
                            }
                        },
                        onBackClick = { navController.popBackStack() },
                        currency = currentCurr,
                        isArabic = isArabic
                    )
                }

                composable(NavRoutes.Trips.route) {
                    TripsScreen(
                        viewModel = tripsViewModel,
                        onNavigateToBoardingPass = { pnr ->
                            navController.navigate(NavRoutes.BoardingPass.createRoute(pnr))
                        },
                        onNavigateToTripDetails = { pnr ->
                            navController.navigate(NavRoutes.BoardingPass.createRoute(pnr))
                        },
                        isArabic = isArabic
                    )
                }

                composable(NavRoutes.CheckIn.route) {
                    CheckInScreen(
                        viewModel = checkInViewModel,
                        onNavigateToBoardingPass = { pnr ->
                            navController.navigate(NavRoutes.BoardingPass.createRoute(pnr))
                        },
                        isArabic = isArabic
                    )
                }

                composable(
                    route = NavRoutes.BoardingPass.route,
                    arguments = listOf(navArgument("pnr") { type = NavType.StringType })
                ) { entry ->
                    val pnr = entry.arguments?.getString("pnr") ?: "RX8921"
                    BoardingPassScreen(
                        viewModel = boardingPassViewModel,
                        pnr = pnr,
                        onBackClick = { navController.popBackStack() },
                        isArabic = isArabic
                    )
                }

                composable(NavRoutes.Discover.route) {
                    DiscoverScreen(
                        onNavigateToSearch = { origin, dest, date, cabin ->
                            navController.navigate(NavRoutes.FlightResults.createRoute(origin, dest, date, cabin))
                        },
                        isArabic = isArabic
                    )
                }

                composable(NavRoutes.Profile.route) {
                    SettingsScreen(
                        homeViewModel = homeViewModel,
                        onNavigateToLoyalty = { navController.navigate(NavRoutes.Loyalty.route) },
                        isArabic = isArabic
                    )
                }

                composable(NavRoutes.Loyalty.route) {
                    LoyaltyScreen(isArabic = isArabic)
                }
            }
        }
    }
}
