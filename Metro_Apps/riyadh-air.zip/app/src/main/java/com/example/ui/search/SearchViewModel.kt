package com.example.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Flight
import com.example.data.repository.FlightRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SearchViewModel(
    private val flightRepository: FlightRepository
) : ViewModel() {

    private val _flightsState = MutableStateFlow<List<Flight>>(emptyList())
    val flightsState: StateFlow<List<Flight>> = _flightsState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _selectedFilter = MutableStateFlow("RECOMMENDED") // RECOMMENDED, PRICE, DURATION
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    fun searchFlights(
        originIata: String,
        destIata: String,
        date: String,
        cabinClass: String
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val results = flightRepository.searchFlights(originIata, destIata, date, cabinClass)
            _flightsState.value = results
            _isLoading.value = false
        }
    }

    fun applyFilter(filter: String) {
        _selectedFilter.value = filter
        val currentList = _flightsState.value
        _flightsState.value = when (filter) {
            "PRICE" -> currentList.sortedBy { flight -> flight.fares.minOfOrNull { it.priceSar } ?: 0.0 }
            "DURATION" -> currentList.sortedBy { it.durationText }
            else -> currentList.sortedBy { it.flightNumber }
        }
    }
}
