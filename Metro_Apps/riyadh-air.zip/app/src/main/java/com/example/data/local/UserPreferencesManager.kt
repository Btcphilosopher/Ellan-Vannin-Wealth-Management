package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "riyadh_air_preferences")

class UserPreferencesManager(private val context: Context) {

    companion object {
        val KEY_LANGUAGE = stringPreferencesKey("language") // "en" or "ar"
        val KEY_CURRENCY = stringPreferencesKey("currency") // "SAR", "USD", "EUR", "GBP"
        val KEY_USER_NAME = stringPreferencesKey("user_name")
        val KEY_USER_EMAIL = stringPreferencesKey("user_email")
        val KEY_PASSPORT_NUM = stringPreferencesKey("passport_num")
        val KEY_NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val KEY_LOYALTY_TIER = stringPreferencesKey("loyalty_tier") // "Riyadh Club - Gold"
        val KEY_LOYALTY_POINTS = stringPreferencesKey("loyalty_points") // "124,500"
    }

    val languageFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_LANGUAGE] ?: "en"
    }

    val currencyFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_CURRENCY] ?: "SAR"
    }

    val userNameFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_USER_NAME] ?: "Tariq Al-Mansoor"
    }

    val userEmailFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_USER_EMAIL] ?: "tariq.almansoor@riyadh.sa"
    }

    val passportNumFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_PASSPORT_NUM] ?: "N8942018"
    }

    val notificationsEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_NOTIFICATIONS_ENABLED] ?: true
    }

    val loyaltyTierFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_LOYALTY_TIER] ?: "Riyadh Executive Gold"
    }

    val loyaltyPointsFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_LOYALTY_POINTS] ?: "128,400"
    }

    suspend fun setLanguage(lang: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LANGUAGE] = lang
        }
    }

    suspend fun setCurrency(curr: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_CURRENCY] = curr
        }
    }

    suspend fun updateProfile(name: String, email: String, passport: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_USER_NAME] = name
            prefs[KEY_USER_EMAIL] = email
            prefs[KEY_PASSPORT_NUM] = passport
        }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_NOTIFICATIONS_ENABLED] = enabled
        }
    }
}
