package com.example.ui.navigation

sealed class NavRoutes(val route: String) {
    object Home : NavRoutes("home")
    object FlightSearch : NavRoutes("flight_search")
    object FlightResults : NavRoutes("flight_results/{origin}/{dest}/{date}/{cabin}") {
        fun createRoute(origin: String, dest: String, date: String, cabin: String) =
            "flight_results/$origin/$dest/$date/$cabin"
    }
    object BookingFlow : NavRoutes("booking_flow/{flightId}/{fareId}") {
        fun createRoute(flightId: String, fareId: String) = "booking_flow/$flightId/$fareId"
    }
    object Trips : NavRoutes("trips")
    object TripDetails : NavRoutes("trip_details/{pnr}") {
        fun createRoute(pnr: String) = "trip_details/$pnr"
    }
    object CheckIn : NavRoutes("check_in")
    object BoardingPass : NavRoutes("boarding_pass/{pnr}") {
        fun createRoute(pnr: String) = "boarding_pass/$pnr"
    }
    object Loyalty : NavRoutes("loyalty")
    object Discover : NavRoutes("discover")
    object DiscoverDetail : NavRoutes("discover_detail/{destId}") {
        fun createRoute(destId: String) = "discover_detail/$destId"
    }
    object Notifications : NavRoutes("notifications")
    object Profile : NavRoutes("profile")
    object Settings : NavRoutes("settings")
    object Support : NavRoutes("support")
}
