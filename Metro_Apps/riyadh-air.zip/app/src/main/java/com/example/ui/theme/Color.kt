package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Riyadh Air Palette - Deep Dark Luxury Theme
val RiyadhBackground = Color(0xFF0A0D18)
val RiyadhSurface = Color(0xFF13172B)
val RiyadhSurfaceElevated = Color(0xFF1C2038)
val RiyadhSurfaceCard = Color(0xFF161A30)
val RiyadhBorder = Color(0xFF2B3054)

// Brand Accents
val RiyadhIndigoPrimary = Color(0xFF5C5EE6)
val RiyadhLavenderLight = Color(0xFF8A82E6)
val RiyadhLavenderPill = Color(0xFF4A448C)
val RiyadhGoldAccent = Color(0xFFD4AF37)
val RiyadhChampagne = Color(0xFFE5C07B)

// Text Colors
val RiyadhTextPrimary = Color(0xFFFFFFFF)
val RiyadhTextSecondary = Color(0xFFB4B8D0)
val RiyadhTextMuted = Color(0xFF7B809E)

// Status Colors
val RiyadhSuccess = Color(0xFF10B981)
val RiyadhWarning = Color(0xFFF59E0B)
val RiyadhError = Color(0xFFEF4444)
