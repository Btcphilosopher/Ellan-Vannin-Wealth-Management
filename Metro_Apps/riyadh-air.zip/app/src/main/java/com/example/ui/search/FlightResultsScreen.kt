package com.example.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Flight
import com.example.ui.components.FlightCard
import com.example.ui.theme.RiyadhBackground
import com.example.ui.theme.RiyadhBorder
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurface
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun FlightResultsScreen(
    viewModel: SearchViewModel,
    originIata: String,
    destIata: String,
    date: String,
    cabinClass: String,
    onSelectFlight: (Flight) -> Unit,
    onBackClick: () -> Unit,
    currency: String = "SAR",
    isArabic: Boolean = false
) {
    val flights by viewModel.flightsState.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()

    var selectedDateTab by remember { mutableStateOf(date) }

    val dateStrip = remember {
        listOf("Tue 11 Nov", "Wed 12 Nov", "Thu 13 Nov", "Fri 14 Nov")
    }

    LaunchedEffect(originIata, destIata, date, cabinClass) {
        viewModel.searchFlights(originIata, destIata, date, cabinClass)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RiyadhBackground)
    ) {
        // Top Header Route Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(RiyadhSurface)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBackClick, modifier = Modifier.testTag("flight_results_back_button")) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "$originIata ➔ $destIata",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = RiyadhTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    )
                    Text(
                        text = "$selectedDateTab • $cabinClass",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = RiyadhTextSecondary,
                            fontSize = 12.sp
                        )
                    )
                }
            }
        }

        // Horizontal Date Strip Bar
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(RiyadhSurface.copy(alpha = 0.5f))
                .padding(vertical = 8.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(dateStrip) { dt ->
                val isSelected = dt == selectedDateTab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) RiyadhIndigoPrimary else Color.Transparent)
                        .border(1.dp, if (isSelected) Color.White else RiyadhBorder, RoundedCornerShape(12.dp))
                        .clickable { selectedDateTab = dt }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .testTag("date_strip_item_$dt"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = dt,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = if (isSelected) Color.White else RiyadhTextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    )
                }
            }
        }

        // Filter Chips Pill Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val filters = listOf(
                "RECOMMENDED" to if (isArabic) "الموصى بها" else "Recommended",
                "PRICE" to if (isArabic) "الأقل سعراً" else "Lowest Price",
                "DURATION" to if (isArabic) "الأقصر مدة" else "Shortest Duration"
            )

            filters.forEach { (key, label) ->
                val isSelected = selectedFilter == key
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) RiyadhIndigoPrimary else Color.White.copy(alpha = 0.05f))
                        .border(1.dp, if (isSelected) RiyadhIndigoPrimary else RiyadhBorder, RoundedCornerShape(16.dp))
                        .clickable { viewModel.applyFilter(key) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("filter_chip_$key")
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isSelected) Color.White else RiyadhTextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    )
                }
            }
        }

        // Demo Data Label
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp)
        ) {
            Text(
                text = if (isArabic) "• نتائج تجريبية متصلة بمنظومة حجز طيران الرياض" else "• Schedule and availability powered by Riyadh Air Demo inventory",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = RiyadhLavenderLight.copy(alpha = 0.7f),
                    fontSize = 11.sp
                )
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Results List
        if (isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = RiyadhIndigoPrimary)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                items(flights) { flight ->
                    FlightCard(
                        flight = flight,
                        onSelectFlight = onSelectFlight,
                        currency = currency,
                        isArabic = isArabic
                    )
                }
            }
        }
    }
}
