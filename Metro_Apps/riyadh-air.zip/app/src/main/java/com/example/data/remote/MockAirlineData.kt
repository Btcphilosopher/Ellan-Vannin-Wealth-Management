package com.example.data.remote

import com.example.data.local.BookingEntity
import com.example.data.model.Airport
import com.example.data.model.AncillaryOption
import com.example.data.model.Destination
import com.example.data.model.FareFamily
import com.example.data.model.Flight
import com.example.data.model.NotificationItem
import com.example.data.model.Seat
import com.example.data.model.SeatStatus

object MockAirlineData {

    val AIRPORTS = listOf(
        Airport("RUH", "Riyadh", "الرياض", "King Khalid International Airport", "مطار الملك خالد الدولي", "Saudi Arabia", "المملكة العربية السعودية"),
        Airport("JED", "Jeddah", "جدة", "King Abdulaziz International Airport", "مطار الملك عبدالعزيز الدولي", "Saudi Arabia", "المملكة العربية السعودية"),
        Airport("DMM", "Dammam", "الدمام", "King Fahd International Airport", "مطار الملك فهد الدولي", "Saudi Arabia", "المملكة العربية السعودية"),
        Airport("LHR", "London", "لندن", "London Heathrow Airport", "مطار مطار مطار هيثرو لندن", "United Kingdom", "المملكة المتحدة"),
        Airport("CDG", "Paris", "باريس", "Charles de Gaulle Airport", "مطار شارل ديغول باريس", "France", "فرنسا"),
        Airport("JFK", "New York", "نيويورك", "John F. Kennedy Intl Airport", "مطار جون إف كينيدي نيويورك", "United States", "الولايات المتحدة"),
        Airport("DXB", "Dubai", "دبي", "Dubai International Airport", "مطار دبي الدولي", "United Arab Emirates", "الإمارات العربية المتحدة"),
        Airport("HND", "Tokyo", "طوكيو", "Tokyo Haneda Airport", "مطار طوكيو هانيودا", "Japan", "اليابان"),
        Airport("IST", "Istanbul", "إسطنبول", "Istanbul Airport", "مطار إسطنبول الدولي", "Turkey", "تركيا"),
        Airport("FRA", "Frankfurt", "فرانکفورت", "Frankfurt Airport", "مطار فرانكفورت", "Germany", "ألمانيا")
    )

    fun getAirportByIata(iata: String): Airport {
        return AIRPORTS.firstOrNull { it.iataCode.equals(iata, ignoreCase = true) }
            ?: AIRPORTS[0]
    }

    val SAMPLE_FARES = listOf(
        FareFamily(
            id = "fare_econ_classic",
            nameEn = "Economy Classic",
            nameAr = "الاقتصادية الكلاسيكية",
            priceSar = 1850.0,
            cabinClass = "ECONOMY",
            baggageKg = 23,
            cabinBagKg = 7,
            seatSelectionFree = false,
            loungeAccess = false,
            refundable = false,
            flexibleChange = true
        ),
        FareFamily(
            id = "fare_econ_flex",
            nameEn = "Economy Flex",
            nameAr = "الاقتصادية المرنة",
            priceSar = 2450.0,
            cabinClass = "ECONOMY",
            baggageKg = 32,
            cabinBagKg = 10,
            seatSelectionFree = true,
            loungeAccess = false,
            refundable = true,
            flexibleChange = true
        ),
        FareFamily(
            id = "fare_bus_choice",
            nameEn = "Business Suite",
            nameAr = "جناح درجة الأعمال",
            priceSar = 4250.0,
            cabinClass = "BUSINESS",
            baggageKg = 64,
            cabinBagKg = 15,
            seatSelectionFree = true,
            loungeAccess = true,
            refundable = true,
            flexibleChange = true
        )
    )

    fun searchFlights(
        originIata: String,
        destIata: String,
        date: String,
        cabinClass: String
    ): List<Flight> {
        val origin = getAirportByIata(originIata)
        val dest = getAirportByIata(destIata)

        val priceMultiplier = when (cabinClass) {
            "BUSINESS" -> 2.1
            "FIRST" -> 3.5
            else -> 1.0
        }

        return listOf(
            Flight(
                id = "RX102",
                flightNumber = "RX 102",
                origin = origin,
                destination = dest,
                departureTime = "08:45",
                arrivalTime = "14:20",
                durationText = "6h 35m",
                stops = 0,
                aircraftType = "Boeing 787-9 Dreamliner",
                fares = SAMPLE_FARES.map { it.copy(priceSar = (it.priceSar * priceMultiplier).coerceAtLeast(1200.0)) },
                terminal = "2",
                isDemoData = true
            ),
            Flight(
                id = "RX108",
                flightNumber = "RX 108",
                origin = origin,
                destination = dest,
                departureTime = "14:30",
                arrivalTime = "20:10",
                durationText = "6h 40m",
                stops = 0,
                aircraftType = "Boeing 787-9 Dreamliner",
                fares = SAMPLE_FARES.map { it.copy(priceSar = ((it.priceSar - 200) * priceMultiplier).coerceAtLeast(1100.0)) },
                terminal = "2",
                isDemoData = true
            ),
            Flight(
                id = "RX214",
                flightNumber = "RX 214",
                origin = origin,
                destination = dest,
                departureTime = "22:15",
                arrivalTime = "06:55 (+1)",
                durationText = "7h 40m",
                stops = 1,
                aircraftType = "Boeing 787-9 Dreamliner",
                fares = SAMPLE_FARES.map { it.copy(priceSar = ((it.priceSar - 400) * priceMultiplier).coerceAtLeast(980.0)) },
                terminal = "2",
                isDemoData = true
            )
        )
    }

    val INITIAL_ACTIVE_BOOKING = BookingEntity(
        bookingReference = "RX8921",
        flightNumber = "RX 102",
        originIata = "RUH",
        originCity = "Riyadh",
        destIata = "LHR",
        destCity = "London",
        departureTime = "08:45",
        arrivalTime = "14:20",
        departureDate = "Wed, 12 Nov 2025",
        duration = "6h 35m",
        cabinClass = "BUSINESS",
        status = "CONFIRMED",
        passengerName = "Tariq Al-Mansoor",
        passportNumber = "N8942018",
        seatNumber = "12A",
        terminal = "2",
        gate = "A12",
        totalPriceSar = 4250.0,
        currency = "SAR",
        baggageIncluded = "2x 32kg Checked Bags",
        qrCodeData = "RIYADHAIR-PNR-RX8921-TARIQALMANSOOR-RUHLHR-SEAT12A-CLASSBUSINESS"
    )

    fun generateSeatMap(cabinClass: String): List<Seat> {
        val seats = mutableListOf<Seat>()
        val startRow = if (cabinClass == "BUSINESS") 1 else 10
        val endRow = if (cabinClass == "BUSINESS") 6 else 28
        val cols = if (cabinClass == "BUSINESS") listOf("A", "D", "G", "K") else listOf("A", "B", "C", "D", "E", "F")

        val occupiedSeats = setOf("1A", "1K", "2D", "3A", "4G", "12B", "12C", "14A", "15D", "16E")

        for (row in startRow..endRow) {
            for (col in cols) {
                val seatNo = "$row$col"
                val isOccupied = occupiedSeats.contains(seatNo)
                val isExit = row == 10 || row == 20
                val extraLegroom = isExit || cabinClass == "BUSINESS" || row == 11
                val extraPrice = if (isExit) 250.0 else if (extraLegroom && cabinClass != "BUSINESS") 150.0 else 0.0

                seats.add(
                    Seat(
                        seatNumber = seatNo,
                        rowNumber = row,
                        columnLetter = col,
                        cabinClass = cabinClass,
                        status = if (isOccupied) SeatStatus.OCCUPIED else SeatStatus.AVAILABLE,
                        priceExtraSar = extraPrice,
                        isExitRow = isExit,
                        hasExtraLegroom = extraLegroom
                    )
                )
            }
        }
        return seats
    }

    val ANCILLARY_OPTIONS = listOf(
        AncillaryOption(
            id = "anc_bag_32",
            titleEn = "Additional 32kg Checked Bag",
            titleAr = "حقيبة إضافية 32 كجم",
            subtitleEn = "Pre-book now & save 30% compared to airport rate",
            subtitleAr = "احجز مسبقاً ووفر 30% مقارنة بسعر المطار",
            priceSar = 220.0,
            iconType = "BAG"
        ),
        AncillaryOption(
            id = "anc_wifi",
            titleEn = "Full Flight High-Speed Wi-Fi",
            titleAr = "إنترنت عالي السرعة لجميع مراحل الرحلة",
            subtitleEn = "Unlimited streaming & messaging powered by satellite",
            subtitleAr = "تصفح وبث مباشر غير محدود عبر الأقمار الصناعية",
            priceSar = 95.0,
            iconType = "WIFI"
        ),
        AncillaryOption(
            id = "anc_lounge",
            titleEn = "Riyadh Lounge Access",
            titleAr = "الدخول لصالون الرياض للضيافة",
            subtitleEn = "Gourmet dining, spa showers & quiet relaxation pods",
            subtitleAr = "وجبات فاخرة وغرف استرخاء ومرافق خاصة",
            priceSar = 350.0,
            iconType = "LOUNGE"
        ),
        AncillaryOption(
            id = "anc_dining",
            titleEn = "Chef's Signature Dining",
            titleAr = "قائمة طعام الشيف الخاصة",
            subtitleEn = "Pre-order authentic Saudi fusion or gourmet international menu",
            subtitleAr = "اطلب مسبقاً قائمة المأكولات السعودية والعالمية الفاخرة",
            priceSar = 180.0,
            iconType = "DINING"
        )
    )

    val DESTINATIONS = listOf(
        Destination(
            id = "riyadh",
            nameEn = "Riyadh",
            nameAr = "الرياض",
            countryEn = "Saudi Arabia",
            countryAr = "المملكة العربية السعودية",
            taglineEn = "A city of opportunity and bold vision",
            taglineAr = "عاصمة المستقبل والفرص الواعدة",
            descriptionEn = "From its rich heritage at Diriyah to its skyline towers, Riyadh is a global hub where Saudi tradition meets tomorrow.",
            descriptionAr = "من الدرعية التاريخية إلى نطاقات السحاب المعاصرة، تشكل الرياض مركزاً عالمياً يجمع بين أصالة التراث ورؤية المستقبل.",
            iataCode = "RUH",
            startingPriceSar = 1200.0,
            imageDrawableRes = com.example.R.drawable.riyadh_city_1792914735592
        ),
        Destination(
            id = "london",
            nameEn = "London",
            nameAr = "لندن",
            countryEn = "United Kingdom",
            countryAr = "المملكة المتحدة",
            taglineEn = "Timeless elegance and global culture",
            taglineAr = "عاصمة الأناقة والمناطق الثقافية العالمية",
            descriptionEn = "Experience world-class theatre, iconic landmarks, shopping at Harrods, and seamless Riyadh Air connectivity.",
            descriptionAr = "استمتع بالمسارح العالمية والأحياء التاريخية وأفضل وجهات التسوق الراقية مع رحلات الرياض المباشرة.",
            iataCode = "LHR",
            startingPriceSar = 2850.0
        ),
        Destination(
            id = "paris",
            nameEn = "Paris",
            nameAr = "باريس",
            countryEn = "France",
            countryAr = "فرنسا",
            taglineEn = "The capital of haute couture and gastronomy",
            taglineAr = "عاصمة الأزياء الفاخرة والمطاعم المتميزة",
            descriptionEn = "Fly directly to the City of Light with incomparable luxury and Saudi hospitality on board.",
            descriptionAr = "سافر مباشرة إلى مدينة الأضواء والجمال وتذوق الفخامة السعودية والضيافة الرفيعة.",
            iataCode = "CDG",
            startingPriceSar = 3100.0
        ),
        Destination(
            id = "alula",
            nameEn = "AlUla",
            nameAr = "العلا",
            countryEn = "Saudi Arabia",
            countryAr = "المملكة العربية السعودية",
            taglineEn = "The world's masterpiece of living history",
            taglineAr = "تحفة العالم وعجيبة التاريخ الحي",
            descriptionEn = "Ancient Nabataean tombs at Hegra, dramatic sandstone canyons, and luxury eco-resorts.",
            descriptionAr = "مقابر النبطيين القديمة في الحجر، والجبال الرملية المهيبة، ومنتجعات الفخامة العالمية.",
            iataCode = "ULH",
            startingPriceSar = 850.0
        )
    )

    val NOTIFICATIONS = listOf(
        NotificationItem(
            id = "notif_1",
            titleEn = "Check-in Open for Flight RX 102",
            titleAr = "انطلاق تسجيل الوصول للرحلة RX 102",
            bodyEn = "Digital check-in is now active for your Riyadh (RUH) to London (LHR) flight.",
            bodyAr = "تسجيل الوصول الرقمي متاح الآن لرحلتك من الرياض إلى لندن.",
            timestamp = "10 mins ago",
            isRead = false,
            type = "CHECK_IN_OPEN"
        ),
        NotificationItem(
            id = "notif_2",
            titleEn = "Terminal & Gate Update",
            titleAr = "تحديث صالة وغيت المغادرة",
            bodyEn = "Flight RX 102 will depart from Terminal 2, Gate A12 at King Khalid Intl Airport.",
            bodyAr = "ستغادر الرحلة RX 102 من الصالة 2، بوابة A12 في مطار الملك خالد الدولي.",
            timestamp = "1 hour ago",
            isRead = true,
            type = "GATE_CHANGE"
        ),
        NotificationItem(
            id = "notif_3",
            titleEn = "Riyadh Air Executive Welcome",
            titleAr = "مرحباً بكم في طيران الرياض",
            bodyEn = "Your account is enrolled in Riyadh Air Executive. Enjoy priority booking & rewards.",
            bodyAr = "تم تفعيل حسابكم في برنامج ضيافة طيران الرياض. استمتع بأولوية الحجز والمكافآت.",
            timestamp = "Yesterday",
            isRead = true,
            type = "OFFER"
        )
    )
}
