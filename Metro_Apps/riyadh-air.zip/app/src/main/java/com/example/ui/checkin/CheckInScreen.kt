package com.example.ui.checkin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.RiyadhBackground
import com.example.ui.theme.RiyadhBorder
import com.example.ui.theme.RiyadhGoldAccent
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurface
import com.example.ui.theme.RiyadhSurfaceCard
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun CheckInScreen(
    viewModel: CheckInViewModel,
    onNavigateToBoardingPass: (String) -> Unit,
    isArabic: Boolean = false
) {
    val pnrQuery by viewModel.pnrQuery.collectAsState()
    val lastNameQuery by viewModel.lastNameQuery.collectAsState()
    val foundBooking by viewModel.foundBooking.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var isDeclarationAccepted by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RiyadhBackground)
            .verticalScroll(rememberScrollState())
    ) {
        // Top Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(RiyadhSurface)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Text(
                text = if (isArabic) "تسجيل الوصول الرقمي Digital Check-in" else "Digital Flight Check-in",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = RiyadhTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            )
        }

        Column(modifier = Modifier.padding(16.dp)) {
            // Search Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RiyadhBorder, RoundedCornerShape(20.dp))
                    .testTag("checkin_search_card"),
                colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = if (isArabic) "استرجاع الحجز بمرجع PNR" else "Retrieve Flight Booking",
                        style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = pnrQuery,
                        onValueChange = { viewModel.updatePnr(it) },
                        label = { Text("PNR / Booking Reference (e.g. RX8921)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("checkin_pnr_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = lastNameQuery,
                        onValueChange = { viewModel.updateLastName(it) },
                        label = { Text("Passenger Surname / Last Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("checkin_lastname_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { viewModel.searchBooking() },
                        colors = ButtonDefaults.buttonColors(containerColor = RiyadhIndigoPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("checkin_search_button")
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = if (isArabic) "البحث عن الحجز" else "Retrieve Booking", style = MaterialTheme.typography.labelLarge.copy(color = Color.White, fontWeight = FontWeight.Bold))
                    }
                }
            }

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = errorMessage!!,
                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFEF4444))
                )
            }

            // Retrieved Booking View
            if (foundBooking != null) {
                val booking = foundBooking!!
                Spacer(modifier = Modifier.height(20.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, RiyadhIndigoPrimary, RoundedCornerShape(20.dp))
                        .testTag("checkin_retrieved_card"),
                    colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${booking.originIata} ➔ ${booking.destIata}",
                                style = MaterialTheme.typography.titleLarge.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Black)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(RiyadhIndigoPrimary.copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = booking.status,
                                    style = MaterialTheme.typography.labelSmall.copy(color = RiyadhLavenderLight, fontWeight = FontWeight.Bold)
                                )
                            }
                        }

                        Text(
                            text = "${booking.passengerName} • ${booking.departureDate}",
                            style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Security & Dangerous Goods Declaration
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = isDeclarationAccepted,
                                onCheckedChange = { isDeclarationAccepted = it },
                                colors = CheckboxDefaults.colors(checkedColor = RiyadhIndigoPrimary),
                                modifier = Modifier.testTag("checkin_declaration_checkbox")
                            )
                            Text(
                                text = "I declare no prohibited dangerous goods or untagged liquids are in my cabin/checked luggage.",
                                style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary, fontSize = 11.sp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.submitCheckIn(booking.seatNumber) { pnr ->
                                    onNavigateToBoardingPass(pnr)
                                }
                            },
                            enabled = isDeclarationAccepted,
                            colors = ButtonDefaults.buttonColors(containerColor = RiyadhIndigoPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("complete_checkin_button")
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Check-in", tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (booking.status == "CHECKED_IN") "View Boarding Pass" else "Complete Check-in & Get Pass",
                                style = MaterialTheme.typography.labelLarge.copy(color = Color.White, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }
    }
}
