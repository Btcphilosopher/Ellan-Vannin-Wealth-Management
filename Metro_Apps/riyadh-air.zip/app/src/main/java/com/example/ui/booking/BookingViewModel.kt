package com.example.ui.booking

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BookingEntity
import com.example.data.model.AncillaryOption
import com.example.data.model.FareFamily
import com.example.data.model.Flight
import com.example.data.model.Passenger
import com.example.data.model.Seat
import com.example.data.remote.MockAirlineData
import com.example.data.repository.BookingRepository
import com.example.data.repository.FlightRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class BookingViewModel(
    private val flightRepository: FlightRepository,
    private val bookingRepository: BookingRepository
) : ViewModel() {

    private val _currentStep = MutableStateFlow(1) // 1..6
    val currentStep: StateFlow<Int> = _currentStep.asStateFlow()

    private val _selectedFlight = MutableStateFlow<Flight?>(null)
    val selectedFlight: StateFlow<Flight?> = _selectedFlight.asStateFlow()

    private val _selectedFare = MutableStateFlow<FareFamily?>(null)
    val selectedFare: StateFlow<FareFamily?> = _selectedFare.asStateFlow()

    private val _passenger = MutableStateFlow(Passenger(firstName = "Tariq", lastName = "Al-Mansoor", email = "tariq.almansoor@riyadh.sa", passportNumber = "N8942018", phone = "+966 50 123 4567"))
    val passenger: StateFlow<Passenger> = _passenger.asStateFlow()

    private val _seatsList = MutableStateFlow<List<Seat>>(emptyList())
    val seatsList: StateFlow<List<Seat>> = _seatsList.asStateFlow()

    private val _selectedSeatNumber = MutableStateFlow("12A")
    val selectedSeatNumber: StateFlow<String> = _selectedSeatNumber.asStateFlow()

    private val _ancillaries = MutableStateFlow<List<AncillaryOption>>(MockAirlineData.ANCILLARY_OPTIONS)
    val ancillaries: StateFlow<List<AncillaryOption>> = _ancillaries.asStateFlow()

    private val _createdBooking = MutableStateFlow<BookingEntity?>(null)
    val createdBooking: StateFlow<BookingEntity?> = _createdBooking.asStateFlow()

    fun loadBookingData(flightId: String, fareId: String) {
        viewModelScope.launch {
            val flight = flightRepository.getFlightById(flightId)
                ?: MockAirlineData.searchFlights("RUH", "LHR", "12 Nov 2025", "BUSINESS")[0]
            val fare = flight.fares.firstOrNull { it.id == fareId } ?: flight.fares[0]

            _selectedFlight.value = flight
            _selectedFare.value = fare
            _seatsList.value = MockAirlineData.generateSeatMap(fare.cabinClass)
        }
    }

    fun updatePassengerDetails(firstName: String, lastName: String, email: String, passport: String, phone: String) {
        _passenger.value = _passenger.value.copy(
            firstName = firstName,
            lastName = lastName,
            email = email,
            passportNumber = passport,
            phone = phone
        )
    }

    fun selectSeat(seatNumber: String) {
        _selectedSeatNumber.value = seatNumber
    }

    fun toggleAncillary(ancillaryId: String) {
        _ancillaries.value = _ancillaries.value.map {
            if (it.id == ancillaryId) it.copy(isSelected = !it.isSelected) else it
        }
    }

    fun nextStep() {
        if (_currentStep.value < 6) {
            _currentStep.value += 1
        }
    }

    fun previousStep() {
        if (_currentStep.value > 1) {
            _currentStep.value -= 1
        }
    }

    fun calculateTotalPrice(): Double {
        val baseFare = _selectedFare.value?.priceSar ?: 0.0
        val seatExtra = _seatsList.value.firstOrNull { it.seatNumber == _selectedSeatNumber.value }?.priceExtraSar ?: 0.0
        val ancillariesExtra = _ancillaries.value.filter { it.isSelected }.sumOf { it.priceSar }
        return baseFare + seatExtra + ancillariesExtra
    }

    fun confirmAndCreateBooking(onSuccess: (String) -> Unit) {
        viewModelScope.launch {
            val flight = _selectedFlight.value ?: return@launch
            val pnr = "RX" + (1000..9999).random()
            val pass = _passenger.value
            val total = calculateTotalPrice()

            val booking = BookingEntity(
                bookingReference = pnr,
                flightNumber = flight.flightNumber,
                originIata = flight.origin.iataCode,
                originCity = flight.origin.cityEn,
                destIata = flight.destination.iataCode,
                destCity = flight.destination.cityEn,
                departureTime = flight.departureTime,
                arrivalTime = flight.arrivalTime,
                departureDate = "Wed, 12 Nov 2025",
                duration = flight.durationText,
                cabinClass = _selectedFare.value?.cabinClass ?: "BUSINESS",
                status = "CONFIRMED",
                passengerName = "${pass.firstName} ${pass.lastName}",
                passportNumber = pass.passportNumber,
                seatNumber = _selectedSeatNumber.value,
                terminal = flight.terminal,
                gate = "A12",
                totalPriceSar = total,
                currency = "SAR",
                baggageIncluded = "${_selectedFare.value?.baggageKg ?: 32}kg Included",
                qrCodeData = "RIYADHAIR-CONFIRMED-$pnr-${pass.firstName}${pass.lastName}-${flight.origin.iataCode}${flight.destination.iataCode}-${_selectedSeatNumber.value}"
            )

            bookingRepository.createBooking(booking)
            _createdBooking.value = booking
            _currentStep.value = 6
            onSuccess(pnr)
        }
    }
}
