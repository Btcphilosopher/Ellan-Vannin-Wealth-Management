package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey val bookingReference: String,
    val flightNumber: String,
    val originIata: String,
    val originCity: String,
    val destIata: String,
    val destCity: String,
    val departureTime: String,
    val arrivalTime: String,
    val departureDate: String,
    val duration: String,
    val cabinClass: String,
    val status: String, // e.g. "CONFIRMED", "CHECKED_IN", "BOARDING", "COMPLETED"
    val passengerName: String,
    val passportNumber: String,
    val seatNumber: String,
    val terminal: String,
    val gate: String,
    val totalPriceSar: Double,
    val currency: String,
    val baggageIncluded: String,
    val qrCodeData: String,
    val createdTimestamp: Long = System.currentTimeMillis()
)
