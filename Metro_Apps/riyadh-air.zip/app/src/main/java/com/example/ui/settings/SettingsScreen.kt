package com.example.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.home.HomeViewModel
import com.example.ui.theme.RiyadhBackground
import com.example.ui.theme.RiyadhBorder
import com.example.ui.theme.RiyadhGoldAccent
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurface
import com.example.ui.theme.RiyadhSurfaceCard
import com.example.ui.theme.RiyadhTextPrimary

@Composable
fun SettingsScreen(
    homeViewModel: HomeViewModel,
    onNavigateToLoyalty: () -> Unit,
    isArabic: Boolean = false
) {
    var notificationsEnabled by remember { mutableStateOf(true) }
    var selectedCurrency by remember { mutableStateOf("SAR") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RiyadhBackground)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(RiyadhSurface)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Text(
                text = if (isArabic) "الإعدادات والحساب More & Settings" else "Account & Preferences",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = RiyadhTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            )
        }

        Column(modifier = Modifier.padding(16.dp)) {
            // Profile Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RiyadhBorder, RoundedCornerShape(18.dp))
                    .clickable { onNavigateToLoyalty() }
                    .testTag("settings_profile_card"),
                colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(RiyadhIndigoPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = "User", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(text = "Tariq Al-Mansoor", style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                        Text(text = "Riyadh Executive Gold Member", style = MaterialTheme.typography.bodySmall.copy(color = RiyadhLavenderLight))
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(text = if (isArabic) "التفضيلات والتطبيق App Preferences" else "App Preferences", style = MaterialTheme.typography.titleSmall.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))

            Spacer(modifier = Modifier.height(10.dp))

            // Language Switch Option
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(1.dp, RiyadhBorder, RoundedCornerShape(14.dp))
                    .clickable { homeViewModel.toggleLanguage() }
                    .testTag("settings_language_card"),
                colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Language, contentDescription = "Language", tint = RiyadhLavenderLight)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = if (isArabic) "اللغة (Language)" else "App Language", style = MaterialTheme.typography.bodyMedium.copy(color = RiyadhTextPrimary))
                    }
                    Text(text = if (isArabic) "العربية" else "English", style = MaterialTheme.typography.labelMedium.copy(color = RiyadhLavenderLight, fontWeight = FontWeight.Bold))
                }
            }

            // Currency Option
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(1.dp, RiyadhBorder, RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CardMembership, contentDescription = "Currency", tint = RiyadhLavenderLight)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = if (isArabic) "العملة" else "Display Currency", style = MaterialTheme.typography.bodyMedium.copy(color = RiyadhTextPrimary))
                    }
                    Text(text = selectedCurrency, style = MaterialTheme.typography.labelMedium.copy(color = RiyadhGoldAccent, fontWeight = FontWeight.Bold))
                }
            }

            // Notifications Option
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(1.dp, RiyadhBorder, RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Notifications, contentDescription = "Notifs", tint = RiyadhLavenderLight)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = if (isArabic) "تنبيهات الرحلات" else "Flight & Gate Alerts", style = MaterialTheme.typography.bodyMedium.copy(color = RiyadhTextPrimary))
                    }
                    Switch(
                        checked = notificationsEnabled,
                        onCheckedChange = { notificationsEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = RiyadhIndigoPrimary),
                        modifier = Modifier.testTag("settings_notif_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Support & FAQs
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, RiyadhBorder, RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.HelpOutline, contentDescription = "Help", tint = RiyadhLavenderLight)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(text = if (isArabic) "المساعدة والدعم" else "Help & Customer Assistance", style = MaterialTheme.typography.bodyMedium.copy(color = RiyadhTextPrimary))
                }
            }
        }
    }
}
