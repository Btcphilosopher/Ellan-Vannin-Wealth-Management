package com.example.ui.checkin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BookingEntity
import com.example.data.repository.BookingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CheckInViewModel(
    private val bookingRepository: BookingRepository
) : ViewModel() {

    private val _pnrQuery = MutableStateFlow("RX8921")
    val pnrQuery: StateFlow<String> = _pnrQuery.asStateFlow()

    private val _lastNameQuery = MutableStateFlow("Al-Mansoor")
    val lastNameQuery: StateFlow<String> = _lastNameQuery.asStateFlow()

    private val _foundBooking = MutableStateFlow<BookingEntity?>(null)
    val foundBooking: StateFlow<BookingEntity?> = _foundBooking.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _isCheckedInSuccess = MutableStateFlow(false)
    val isCheckedInSuccess: StateFlow<Boolean> = _isCheckedInSuccess.asStateFlow()

    fun updatePnr(pnr: String) {
        _pnrQuery.value = pnr
    }

    fun updateLastName(lastName: String) {
        _lastNameQuery.value = lastName
    }

    fun searchBooking() {
        viewModelScope.launch {
            _errorMessage.value = null
            val booking = bookingRepository.getBookingByPnr(_pnrQuery.value.trim().uppercase())
            if (booking != null) {
                _foundBooking.value = booking
            } else {
                _errorMessage.value = "No eligible booking found for PNR ${_pnrQuery.value}. Please check reference."
            }
        }
    }

    fun submitCheckIn(seatNumber: String, onSuccess: (String) -> Unit) {
        viewModelScope.launch {
            val pnr = _foundBooking.value?.bookingReference ?: return@launch
            val success = bookingRepository.performCheckIn(pnr, seatNumber)
            if (success) {
                _isCheckedInSuccess.value = true
                onSuccess(pnr)
            }
        }
    }
}
