package com.example.data.repository

import com.example.data.model.Airport
import com.example.data.model.Flight
import com.example.data.remote.MockAirlineData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FlightRepository {

    suspend fun getAirports(): List<Airport> = withContext(Dispatchers.IO) {
        MockAirlineData.AIRPORTS
    }

    suspend fun searchAirports(query: String): List<Airport> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext MockAirlineData.AIRPORTS
        MockAirlineData.AIRPORTS.filter {
            it.cityEn.contains(query, ignoreCase = true) ||
            it.cityAr.contains(query, ignoreCase = true) ||
            it.iataCode.contains(query, ignoreCase = true) ||
            it.nameEn.contains(query, ignoreCase = true)
        }
    }

    suspend fun searchFlights(
        originIata: String,
        destIata: String,
        date: String,
        cabinClass: String
    ): List<Flight> = withContext(Dispatchers.IO) {
        MockAirlineData.searchFlights(originIata, destIata, date, cabinClass)
    }

    suspend fun getFlightById(flightId: String): Flight? = withContext(Dispatchers.IO) {
        MockAirlineData.searchFlights("RUH", "LHR", "12 Nov 2025", "BUSINESS")
            .firstOrNull { it.id == flightId || it.flightNumber.replace(" ", "") == flightId.replace(" ", "") }
    }
}
