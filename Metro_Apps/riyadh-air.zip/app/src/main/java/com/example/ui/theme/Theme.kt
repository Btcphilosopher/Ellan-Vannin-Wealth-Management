package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RiyadhDarkColorScheme = darkColorScheme(
    primary = RiyadhIndigoPrimary,
    onPrimary = Color.White,
    primaryContainer = RiyadhLavenderPill,
    onPrimaryContainer = Color.White,
    secondary = RiyadhLavenderLight,
    onSecondary = Color.White,
    secondaryContainer = RiyadhSurfaceElevated,
    onSecondaryContainer = RiyadhTextPrimary,
    tertiary = RiyadhGoldAccent,
    onTertiary = Color.Black,
    background = RiyadhBackground,
    onBackground = RiyadhTextPrimary,
    surface = RiyadhSurface,
    onSurface = RiyadhTextPrimary,
    surfaceVariant = RiyadhSurfaceCard,
    onSurfaceVariant = RiyadhTextSecondary,
    outline = RiyadhBorder,
    error = RiyadhError
)

@Composable
fun RiyadhAirTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RiyadhDarkColorScheme,
        typography = Typography,
        content = content
    )
}

// Keep legacy alias for existing references
@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    RiyadhAirTheme(content = content)
}
