package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.local.AppDatabase
import com.example.data.local.UserPreferencesManager
import com.example.data.repository.BookingRepository
import com.example.data.repository.FlightRepository
import com.example.ui.navigation.RiyadhApp
import com.example.ui.theme.RiyadhAirTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val userPreferencesManager = UserPreferencesManager(applicationContext)
        val flightRepository = FlightRepository()
        val bookingRepository = BookingRepository(database.bookingDao())

        setContent {
            RiyadhAirTheme {
                RiyadhApp(
                    flightRepository = flightRepository,
                    bookingRepository = bookingRepository,
                    userPreferencesManager = userPreferencesManager
                )
            }
        }
    }
}
