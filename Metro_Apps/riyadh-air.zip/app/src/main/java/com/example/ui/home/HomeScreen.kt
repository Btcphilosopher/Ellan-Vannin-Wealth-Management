package com.example.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.FlightLand
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Airport
import com.example.data.remote.MockAirlineData
import com.example.ui.components.AirportPickerDialog
import com.example.ui.theme.RiyadhBackground
import com.example.ui.theme.RiyadhBorder
import com.example.ui.theme.RiyadhGoldAccent
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurfaceCard
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToSearch: (String, String, String, String) -> Unit,
    onNavigateToBoardingPass: (String) -> Unit,
    onNavigateToTripDetails: (String) -> Unit,
    onNavigateToDiscoverDetail: (String) -> Unit,
    isArabic: Boolean
) {
    val activeTrip by viewModel.activeTrip.collectAsState()

    var selectedTripType by remember { mutableIntStateOf(0) } // 0: One way, 1: Return, 2: Multi-city
    var originAirport by remember { mutableStateOf(MockAirlineData.AIRPORTS[0]) } // RUH
    var destAirport by remember { mutableStateOf(MockAirlineData.AIRPORTS[3]) } // LHR
    var selectedDate by remember { mutableStateOf("Wed, 12 Nov 2025") }
    var passengerCount by remember { mutableIntStateOf(1) }
    var cabinClass by remember { mutableStateOf("BUSINESS") }

    var showOriginPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RiyadhBackground)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        // Hero Section Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.riyadh_air_hero_1792914722367),
                contentDescription = "Riyadh Air Aircraft",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Dark Gradient Overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                RiyadhBackground.copy(alpha = 0.8f),
                                RiyadhBackground
                            )
                        )
                    )
            )

            // Welcome Text & CTA
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(20.dp)
            ) {
                Text(
                    text = if (isArabic) "مرحباً بكم على متن طيران الرياض" else "Welcome aboard",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = RiyadhTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp
                    )
                )
                Text(
                    text = if (isArabic) "رحلتك القادمة تبدأ من هنا" else "Your next journey starts here.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = RiyadhTextSecondary,
                        fontSize = 14.sp
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        onNavigateToSearch(
                            originAirport.iataCode,
                            destAirport.iataCode,
                            selectedDate,
                            cabinClass
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RiyadhIndigoPrimary),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.testTag("book_flight_hero_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isArabic) "حجز رحلة جديدة" else "Book a flight",
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Next",
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Flight Search Module
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, RiyadhBorder, RoundedCornerShape(20.dp))
                .testTag("search_module_card"),
            colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = if (isArabic) "إلى أين ترغب بالسفر؟" else "Where would you like to go?",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = RiyadhTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Trip Type Selector Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.05f))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val tripTypes = if (isArabic) listOf("اتجاه واحد", "ذهاب وإياد", "وجهات متعددة")
                    else listOf("One way", "Return", "Multi-city")

                    tripTypes.forEachIndexed { index, title ->
                        val isSelected = selectedTripType == index
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) RiyadhIndigoPrimary else Color.Transparent)
                                .clickable { selectedTripType = index }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isSelected) Color.White else RiyadhTextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // From & To Airport Box
                Box(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        // From Input
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.04f))
                                .border(1.dp, RiyadhBorder, RoundedCornerShape(12.dp))
                                .clickable { showOriginPicker = true }
                                .padding(14.dp)
                                .testTag("origin_airport_button"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.FlightTakeoff,
                                contentDescription = "From",
                                tint = RiyadhLavenderLight,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isArabic) "من" else "From",
                                    style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp)
                                )
                                Text(
                                    text = originAirport.getDisplayName(isArabic),
                                    style = MaterialTheme.typography.bodyMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // To Input
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.04f))
                                .border(1.dp, RiyadhBorder, RoundedCornerShape(12.dp))
                                .clickable { showDestPicker = true }
                                .padding(14.dp)
                                .testTag("dest_airport_button"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.FlightLand,
                                contentDescription = "To",
                                tint = RiyadhLavenderLight,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isArabic) "إلى" else "To",
                                    style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp)
                                )
                                Text(
                                    text = destAirport.getDisplayName(isArabic),
                                    style = MaterialTheme.typography.bodyMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }

                    // Swap Button
                    IconButton(
                        onClick = {
                            val temp = originAirport
                            originAirport = destAirport
                            destAirport = temp
                        },
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 12.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(RiyadhIndigoPrimary)
                            .testTag("swap_airports_button")
                    ) {
                        Icon(imageVector = Icons.Default.SwapVert, contentDescription = "Swap", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Date & Passengers Selectors
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Date
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .border(1.dp, RiyadhBorder, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = "Date", tint = RiyadhLavenderLight, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = if (isArabic) "المغادرة" else "Departure", style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp))
                            Text(text = selectedDate, style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                        }
                    }

                    // Passengers & Cabin
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .border(1.dp, RiyadhBorder, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = "Passengers", tint = RiyadhLavenderLight, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = if (isArabic) "المسافرون" else "Passengers", style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp))
                            Text(text = "$passengerCount Adult • $cabinClass", style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Search Action Button
                Button(
                    onClick = {
                        onNavigateToSearch(
                            originAirport.iataCode,
                            destAirport.iataCode,
                            selectedDate,
                            cabinClass
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RiyadhIndigoPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("search_flights_button")
                ) {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) "البحث عن الرحلات" else "Search flights",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Active Trip Card (if present)
        val trip = activeTrip
        if (trip != null) {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isArabic) "رحلتك القادمة Active Journey" else "Upcoming Trip",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = RiyadhTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    )
                    Text(
                        text = "PNR: ${trip.bookingReference}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = RiyadhLavenderLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, RiyadhBorder, RoundedCornerShape(20.dp))
                        .clickable { onNavigateToTripDetails(trip.bookingReference) }
                        .testTag("active_trip_card"),
                    colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${trip.originIata} ➔ ${trip.destIata}",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    color = RiyadhTextPrimary,
                                    fontWeight = FontWeight.Black
                                )
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(RiyadhIndigoPrimary.copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = trip.status,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = RiyadhLavenderLight,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }

                        Text(
                            text = "${trip.originCity} to ${trip.destCity} • ${trip.departureDate}",
                            style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = if (isArabic) "المغادرة" else "DEPARTS", style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp))
                                Text(text = trip.departureTime, style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                            }
                            Column {
                                Text(text = if (isArabic) "المقعد" else "SEAT", style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp))
                                Text(text = trip.seatNumber, style = MaterialTheme.typography.titleMedium.copy(color = RiyadhGoldAccent, fontWeight = FontWeight.Bold))
                            }
                            Column {
                                Text(text = if (isArabic) "البوابة" else "GATE", style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp))
                                Text(text = trip.gate, style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { onNavigateToBoardingPass(trip.bookingReference) },
                            colors = ButtonDefaults.buttonColors(containerColor = RiyadhIndigoPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("view_boarding_pass_button")
                        ) {
                            Icon(imageVector = Icons.Default.ConfirmationNumber, contentDescription = "Pass", tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isArabic) "عرض بطاقة صعود الطائرة" else "View boarding pass",
                                style = MaterialTheme.typography.labelLarge.copy(color = Color.White, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Discover Destinations Section
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
                text = if (isArabic) "وجهات استثنائية Discover Saudi Arabia" else "Discover Destinations",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = RiyadhTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(MockAirlineData.DESTINATIONS) { dest ->
                    Card(
                        modifier = Modifier
                            .width(220.dp)
                            .height(260.dp)
                            .border(1.dp, RiyadhBorder, RoundedCornerShape(18.dp))
                            .clickable { onNavigateToDiscoverDetail(dest.id) }
                            .testTag("destination_card_${dest.id}"),
                        colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            if (dest.imageDrawableRes != null) {
                                Image(
                                    painter = painterResource(id = dest.imageDrawableRes),
                                    contentDescription = dest.nameEn,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                                            )
                                        )
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(RiyadhIndigoPrimary.copy(alpha = 0.3f))
                                )
                            }

                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(14.dp)
                            ) {
                                Text(
                                    text = if (isArabic) dest.nameAr else dest.nameEn,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = if (isArabic) dest.taglineAr else dest.taglineEn,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Color.LightGray,
                                        fontSize = 11.sp
                                    ),
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog Pickers
    if (showOriginPicker) {
        AirportPickerDialog(
            title = if (isArabic) "اختر مطار المغادرة" else "Select Origin Airport",
            onDismiss = { showOriginPicker = false },
            onAirportSelected = { originAirport = it },
            isArabic = isArabic
        )
    }

    if (showDestPicker) {
        AirportPickerDialog(
            title = if (isArabic) "اختر مطار الوصول" else "Select Destination Airport",
            onDismiss = { showDestPicker = false },
            onAirportSelected = { destAirport = it },
            isArabic = isArabic
        )
    }
}
