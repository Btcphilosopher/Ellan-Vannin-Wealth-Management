package com.example.ui.booking

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookingEntity
import com.example.data.model.AncillaryOption
import com.example.data.model.FareFamily
import com.example.data.model.Flight
import com.example.data.model.Passenger
import com.example.data.model.Seat
import com.example.ui.components.SeatMap
import com.example.ui.theme.RiyadhBackground
import com.example.ui.theme.RiyadhBorder
import com.example.ui.theme.RiyadhGoldAccent
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurface
import com.example.ui.theme.RiyadhSurfaceCard
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun BookingFlowScreen(
    viewModel: BookingViewModel,
    flightId: String,
    fareId: String,
    onNavigateToBoardingPass: (String) -> Unit,
    onNavigateToTrips: () -> Unit,
    onBackClick: () -> Unit,
    currency: String = "SAR",
    isArabic: Boolean = false
) {
    val currentStep by viewModel.currentStep.collectAsState()
    val flight by viewModel.selectedFlight.collectAsState()
    val fare by viewModel.selectedFare.collectAsState()
    val passenger by viewModel.passenger.collectAsState()
    val seats by viewModel.seatsList.collectAsState()
    val selectedSeatNumber by viewModel.selectedSeatNumber.collectAsState()
    val ancillaries by viewModel.ancillaries.collectAsState()
    val createdBooking by viewModel.createdBooking.collectAsState()

    var selectedPaymentMethod by remember { mutableStateOf("MADA") }

    LaunchedEffect(flightId, fareId) {
        viewModel.loadBookingData(flightId, fareId)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RiyadhBackground)
    ) {
        // Top Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(RiyadhSurface)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (currentStep < 6) {
                    IconButton(
                        onClick = { if (currentStep > 1) viewModel.previousStep() else onBackClick() },
                        modifier = Modifier.testTag("booking_flow_back_button")
                    ) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (currentStep == 6) (if (isArabic) "تأكيد الحجز Confirmation" else "Booking Confirmed") else (if (isArabic) "إكمال الحجز Booking" else "Flight Booking"),
                        style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    )
                    if (currentStep < 6) {
                        Text(
                            text = "Step $currentStep of 5 • ${flight?.flightNumber ?: ""}",
                            style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary, fontSize = 12.sp)
                        )
                    }
                }
            }
        }

        // Progress Bar (Steps 1 to 5)
        if (currentStep < 6) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (step in 1..5) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(if (step <= currentStep) RiyadhIndigoPrimary else RiyadhBorder)
                    )
                }
            }
        }

        // Step Content Container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (currentStep) {
                1 -> StepItinerary(flight, fare, isArabic)
                2 -> StepPassengerDetails(passenger, onUpdate = { f, l, e, p, ph -> viewModel.updatePassengerDetails(f, l, e, p, ph) }, isArabic = isArabic)
                3 -> StepSeatSelection(seats, selectedSeatNumber, onSeatSelect = { viewModel.selectSeat(it.seatNumber) }, isArabic = isArabic)
                4 -> StepAncillaries(ancillaries, onToggle = { viewModel.toggleAncillary(it) }, isArabic = isArabic)
                5 -> StepPayment(flight, fare, passenger, selectedSeatNumber, ancillaries, selectedPaymentMethod, onSelectPayment = { selectedPaymentMethod = it }, isArabic = isArabic)
                6 -> StepConfirmation(createdBooking, onNavigateToBoardingPass, onNavigateToTrips, isArabic)
            }
        }

        // Bottom Fixed Price & Action Bar (for steps 1..5)
        if (currentStep < 6) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RiyadhSurface)
                    .border(1.dp, RiyadhBorder)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isArabic) "المبلغ الإجمالي" else "Total Amount",
                            style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 11.sp)
                        )
                        Text(
                            text = "$currency ${viewModel.calculateTotalPrice().toInt()}",
                            style = MaterialTheme.typography.titleLarge.copy(color = RiyadhGoldAccent, fontWeight = FontWeight.Bold)
                        )
                    }

                    Button(
                        onClick = {
                            if (currentStep == 5) {
                                viewModel.confirmAndCreateBooking { }
                            } else {
                                viewModel.nextStep()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RiyadhIndigoPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("booking_next_button")
                    ) {
                        Text(
                            text = if (currentStep == 5) (if (isArabic) "تأكيد والدفع Pay Now" else "Pay & Confirm") else (if (isArabic) "المتابعة Next" else "Continue"),
                            style = MaterialTheme.typography.labelLarge.copy(color = Color.White, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StepItinerary(
    flight: Flight?,
    fare: FareFamily?,
    isArabic: Boolean
) {
    if (flight == null || fare == null) return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = if (isArabic) "تفاصيل الرحلة والباكج" else "Review Itinerary & Inclusions",
            style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, RiyadhBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = flight.flightNumber, style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                    Text(text = flight.aircraftType, style = MaterialTheme.typography.bodySmall.copy(color = RiyadhLavenderLight))
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = flight.departureTime, style = MaterialTheme.typography.titleLarge.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                        Text(text = "${flight.origin.cityEn} (${flight.origin.iataCode})", style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = flight.arrivalTime, style = MaterialTheme.typography.titleLarge.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                        Text(text = "${flight.destination.cityEn} (${flight.destination.iataCode})", style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = if (isArabic) "الفئة المختارة" else "Selected Fare: ${fare.nameEn}", style = MaterialTheme.typography.titleSmall.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))

        Spacer(modifier = Modifier.height(8.dp))

        val inclusions = listOf(
            "${fare.baggageKg}kg Checked Baggage Allowance",
            "${fare.cabinBagKg}kg Cabin Hand Baggage",
            if (fare.seatSelectionFree) "Complimentary Seat Selection" else "Standard Seat Included",
            if (fare.loungeAccess) "Riyadh Executive Lounge Access" else "Lounge Access Purchase Option",
            if (fare.flexibleChange) "Flexible Date Modification Available" else "Standard Change Policy"
        )

        inclusions.forEach { inc ->
            Row(
                modifier = Modifier.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Inc", tint = RiyadhLavenderLight, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = inc, style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary))
            }
        }
    }
}

@Composable
private fun StepPassengerDetails(
    passenger: Passenger,
    onUpdate: (String, String, String, String, String) -> Unit,
    isArabic: Boolean
) {
    var fn by remember(passenger) { mutableStateOf(passenger.firstName) }
    var ln by remember(passenger) { mutableStateOf(passenger.lastName) }
    var email by remember(passenger) { mutableStateOf(passenger.email) }
    var passport by remember(passenger) { mutableStateOf(passenger.passportNumber) }
    var phone by remember(passenger) { mutableStateOf(passenger.phone) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = if (isArabic) "بيانات المسافر الرئيسي" else "Primary Passenger Details",
            style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = fn,
            onValueChange = {
                fn = it
                onUpdate(fn, ln, email, passport, phone)
            },
            label = { Text("First Name (Given Name)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("passenger_first_name_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = ln,
            onValueChange = {
                ln = it
                onUpdate(fn, ln, email, passport, phone)
            },
            label = { Text("Last Name (Surname)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("passenger_last_name_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = email,
            onValueChange = {
                email = it
                onUpdate(fn, ln, email, passport, phone)
            },
            label = { Text("Email Address") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("passenger_email_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = passport,
            onValueChange = {
                passport = it
                onUpdate(fn, ln, email, passport, phone)
            },
            label = { Text("Passport Number") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("passenger_passport_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = phone,
            onValueChange = {
                phone = it
                onUpdate(fn, ln, email, passport, phone)
            },
            label = { Text("Mobile Phone") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("passenger_phone_input")
        )
    }
}

@Composable
private fun StepSeatSelection(
    seats: List<Seat>,
    selectedSeatNumber: String,
    onSeatSelect: (Seat) -> Unit,
    isArabic: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = if (isArabic) "اختيار المقعد المناسب" else "Select Your Preferred Seat",
            style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
        )
        Text(
            text = "Currently selected: Seat $selectedSeatNumber",
            style = MaterialTheme.typography.bodySmall.copy(color = RiyadhLavenderLight)
        )

        Spacer(modifier = Modifier.height(12.dp))

        SeatMap(
            seats = seats,
            selectedSeatNumber = selectedSeatNumber,
            onSeatSelected = onSeatSelect,
            isArabic = isArabic
        )
    }
}

@Composable
private fun StepAncillaries(
    ancillaries: List<AncillaryOption>,
    onToggle: (String) -> Unit,
    isArabic: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = if (isArabic) "خدمات إضافية وتجارب الضيافة" else "Customise Your Experience & Ancillaries",
            style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(12.dp))

        ancillaries.forEach { anc ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .border(1.dp, if (anc.isSelected) RiyadhIndigoPrimary else RiyadhBorder, RoundedCornerShape(16.dp))
                    .clickable { onToggle(anc.id) }
                    .testTag("ancillary_card_${anc.id}"),
                colors = CardDefaults.cardColors(containerColor = if (anc.isSelected) RiyadhIndigoPrimary.copy(alpha = 0.15f) else RiyadhSurfaceCard)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isArabic) anc.titleAr else anc.titleEn,
                            style = MaterialTheme.typography.titleSmall.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = if (isArabic) anc.subtitleAr else anc.subtitleEn,
                            style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary, fontSize = 11.sp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "+ SAR ${anc.priceSar.toInt()}",
                            style = MaterialTheme.typography.labelMedium.copy(color = RiyadhGoldAccent, fontWeight = FontWeight.Bold)
                        )
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(if (anc.isSelected) RiyadhIndigoPrimary else Color.Transparent)
                                .border(1.dp, if (anc.isSelected) RiyadhIndigoPrimary else RiyadhBorder, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (anc.isSelected) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = "Check", tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StepPayment(
    flight: Flight?,
    fare: FareFamily?,
    passenger: Passenger,
    seatNumber: String,
    ancillaries: List<AncillaryOption>,
    selectedPaymentMethod: String,
    onSelectPayment: (String) -> Unit,
    isArabic: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = if (isArabic) "طريقة الدفع والتأكيد" else "Payment & Booking Summary",
            style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Summary Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, RiyadhBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Booking Overview", style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary))
                Text(text = "${flight?.origin?.cityEn} ➔ ${flight?.destination?.cityEn}", style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                Text(text = "Passenger: ${passenger.firstName} ${passenger.lastName}", style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary))
                Text(text = "Seat: $seatNumber • Cabin: ${fare?.cabinClass}", style = MaterialTheme.typography.bodySmall.copy(color = RiyadhLavenderLight))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = if (isArabic) "اختر وسيلة الدفع الآمنة" else "Select Secure Payment Method", style = MaterialTheme.typography.titleSmall.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))

        Spacer(modifier = Modifier.height(10.dp))

        val methods = listOf(
            "MADA" to "مدى MADA Debit Card (Saudi Arabia)",
            "CREDIT_CARD" to "Visa / Mastercard / AMEX",
            "APPLE_PAY" to "Apple Pay / Google Pay"
        )

        methods.forEach { (id, label) ->
            val isSelected = selectedPaymentMethod == id
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .border(1.dp, if (isSelected) RiyadhIndigoPrimary else RiyadhBorder, RoundedCornerShape(14.dp))
                    .clickable { onSelectPayment(id) }
                    .testTag("payment_method_$id"),
                colors = CardDefaults.cardColors(containerColor = if (isSelected) RiyadhIndigoPrimary.copy(alpha = 0.2f) else RiyadhSurfaceCard)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.CreditCard, contentDescription = "Card", tint = if (isSelected) RiyadhLavenderLight else RiyadhTextSecondary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(color = RiyadhTextPrimary, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Lock, contentDescription = "Lock", tint = RiyadhGoldAccent, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Encrypted PCI-DSS 256-bit secure checkout.",
                style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 11.sp)
            )
        }
    }
}

@Composable
private fun StepConfirmation(
    createdBooking: BookingEntity?,
    onNavigateToBoardingPass: (String) -> Unit,
    onNavigateToTrips: () -> Unit,
    isArabic: Boolean
) {
    if (createdBooking == null) return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(RiyadhIndigoPrimary),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = Icons.Default.Check, contentDescription = "Success", tint = Color.White, modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (isArabic) "تم مؤكد الحجز بنجاح!" else "Booking Confirmed!",
            style = MaterialTheme.typography.headlineSmall.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
        )
        Text(
            text = "Your booking reference is",
            style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary)
        )
        Text(
            text = createdBooking.bookingReference,
            style = MaterialTheme.typography.headlineLarge.copy(color = RiyadhGoldAccent, fontWeight = FontWeight.Black)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, RiyadhBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "${createdBooking.originCity} ➔ ${createdBooking.destCity}", style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                Text(text = "Passenger: ${createdBooking.passengerName}", style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary))
                Text(text = "Seat ${createdBooking.seatNumber} • ${createdBooking.departureDate}", style = MaterialTheme.typography.bodySmall.copy(color = RiyadhLavenderLight))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { onNavigateToBoardingPass(createdBooking.bookingReference) },
            colors = ButtonDefaults.buttonColors(containerColor = RiyadhIndigoPrimary),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("view_confirmation_boarding_pass")
        ) {
            Text(text = if (isArabic) "عرض بطاقة صعود الطائرة" else "View Digital Boarding Pass", style = MaterialTheme.typography.labelLarge.copy(color = Color.White, fontWeight = FontWeight.Bold))
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = onNavigateToTrips,
            colors = ButtonDefaults.buttonColors(containerColor = RiyadhSurfaceCard),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("go_to_trips_button")
        ) {
            Text(text = if (isArabic) "الانتقال إلى قائمة الرحلات" else "Go to My Trips", style = MaterialTheme.typography.labelLarge.copy(color = RiyadhTextPrimary))
        }
    }
}
