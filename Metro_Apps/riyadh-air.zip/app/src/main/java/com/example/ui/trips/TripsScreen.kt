package com.example.ui.trips

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookingEntity
import com.example.ui.theme.RiyadhBackground
import com.example.ui.theme.RiyadhBorder
import com.example.ui.theme.RiyadhGoldAccent
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurface
import com.example.ui.theme.RiyadhSurfaceCard
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun TripsScreen(
    viewModel: TripsViewModel,
    onNavigateToBoardingPass: (String) -> Unit,
    onNavigateToTripDetails: (String) -> Unit,
    isArabic: Boolean = false
) {
    val bookings by viewModel.allBookings.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RiyadhBackground)
    ) {
        // Header Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(RiyadhSurface)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Text(
                text = if (isArabic) "رحلاتي والحجوزات" else "My Trips & Bookings",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = RiyadhTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            )
        }

        if (bookings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FlightTakeoff,
                        contentDescription = "No Trips",
                        tint = RiyadhLavenderLight,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (isArabic) "لا توجد حجوزات حالية" else "No upcoming trips found",
                        style = MaterialTheme.typography.titleMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = if (isArabic) "ابحث عن رحلتك القادمة مع طيران الرياض" else "Search and book your next luxury flight with Riyadh Air.",
                        style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                items(bookings) { booking ->
                    TripItemCard(
                        booking = booking,
                        onNavigateToBoardingPass = onNavigateToBoardingPass,
                        onNavigateToTripDetails = onNavigateToTripDetails,
                        isArabic = isArabic
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
private fun TripItemCard(
    booking: BookingEntity,
    onNavigateToBoardingPass: (String) -> Unit,
    onNavigateToTripDetails: (String) -> Unit,
    isArabic: Boolean
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, RiyadhBorder, RoundedCornerShape(18.dp))
            .clickable { onNavigateToTripDetails(booking.bookingReference) }
            .testTag("trip_item_card_${booking.bookingReference}"),
        colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${booking.originIata} ➔ ${booking.destIata}",
                    style = MaterialTheme.typography.titleLarge.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Black)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(RiyadhIndigoPrimary.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = booking.status,
                        style = MaterialTheme.typography.labelSmall.copy(color = RiyadhLavenderLight, fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "PNR: ${booking.bookingReference} • ${booking.departureDate}",
                style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = if (isArabic) "المسافر" else "PASSENGER", style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp))
                    Text(text = booking.passengerName, style = MaterialTheme.typography.bodyMedium.copy(color = RiyadhTextPrimary, fontWeight = FontWeight.Bold))
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = if (isArabic) "المقعد" else "SEAT", style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp))
                    Text(text = booking.seatNumber, style = MaterialTheme.typography.bodyMedium.copy(color = RiyadhGoldAccent, fontWeight = FontWeight.Bold))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onNavigateToBoardingPass(booking.bookingReference) },
                    colors = ButtonDefaults.buttonColors(containerColor = RiyadhIndigoPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("trip_boarding_pass_button_${booking.bookingReference}")
                ) {
                    Icon(imageVector = Icons.Default.ConfirmationNumber, contentDescription = "Pass", tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = if (isArabic) "البطاقة الرقمية" else "Boarding Pass", style = MaterialTheme.typography.labelMedium.copy(color = Color.White))
                }

                Button(
                    onClick = { onNavigateToTripDetails(booking.bookingReference) },
                    colors = ButtonDefaults.buttonColors(containerColor = RiyadhSurfaceCard),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.border(1.dp, RiyadhBorder, RoundedCornerShape(12.dp))
                ) {
                    Text(text = if (isArabic) "التفاصيل" else "Manage", style = MaterialTheme.typography.labelMedium.copy(color = RiyadhTextPrimary))
                }
            }
        }
    }
}
