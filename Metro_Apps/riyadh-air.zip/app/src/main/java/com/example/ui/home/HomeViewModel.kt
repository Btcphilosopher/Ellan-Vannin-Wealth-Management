package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BookingEntity
import com.example.data.local.UserPreferencesManager
import com.example.data.repository.BookingRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(
    private val bookingRepository: BookingRepository,
    private val userPreferencesManager: UserPreferencesManager
) : ViewModel() {

    val activeTrip: StateFlow<BookingEntity?> = bookingRepository.activeTripFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val currentLanguage: StateFlow<String> = userPreferencesManager.languageFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = "en"
        )

    val currentCurrency: StateFlow<String> = userPreferencesManager.currencyFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = "SAR"
        )

    init {
        viewModelScope.launch {
            bookingRepository.seedInitialBookingIfEmpty()
        }
    }

    fun toggleLanguage() {
        viewModelScope.launch {
            val newLang = if (currentLanguage.value == "en") "ar" else "en"
            userPreferencesManager.setLanguage(newLang)
        }
    }
}
