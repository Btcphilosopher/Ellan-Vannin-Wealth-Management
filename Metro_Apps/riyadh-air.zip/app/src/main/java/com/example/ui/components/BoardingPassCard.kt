package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BookingEntity
import com.example.ui.theme.RiyadhBorder
import com.example.ui.theme.RiyadhGoldAccent
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurface
import com.example.ui.theme.RiyadhSurfaceCard
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun BoardingPassCard(
    booking: BookingEntity,
    isArabic: Boolean = false
) {
    var isBrightnessBoosted by remember { mutableStateOf(false) }

    val cardBg = if (isBrightnessBoosted) Color.White else RiyadhSurfaceCard
    val textColor = if (isBrightnessBoosted) Color.Black else RiyadhTextPrimary
    val secondaryTextColor = if (isBrightnessBoosted) Color.DarkGray else RiyadhTextSecondary
    val accentColor = if (isBrightnessBoosted) Color(0xFF3B38A0) else RiyadhLavenderLight

    Column(modifier = Modifier.fillMaxWidth()) {
        // Brightness Boost Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Lightbulb,
                    contentDescription = "Scanner Boost",
                    tint = RiyadhGoldAccent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isArabic) "إضاءة قراءة المطار High-Contrast" else "Airport Scanner Brightness Boost",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = RiyadhTextSecondary,
                        fontSize = 12.sp
                    )
                )
            }
            Switch(
                checked = isBrightnessBoosted,
                onCheckedChange = { isBrightnessBoosted = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = RiyadhIndigoPrimary
                ),
                modifier = Modifier.testTag("brightness_boost_switch")
            )
        }

        // Ticket Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, if (isBrightnessBoosted) Color.LightGray else RiyadhBorder, RoundedCornerShape(20.dp))
                .testTag("boarding_pass_card"),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header Brand
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(RiyadhIndigoPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "R",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isArabic) "بطاقة صعود الطائرة" else "BOARDING PASS",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = textColor,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(RiyadhIndigoPrimary.copy(alpha = 0.2f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = booking.cabinClass,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = accentColor,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Origin -> Destination
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = booking.originIata,
                            style = MaterialTheme.typography.headlineLarge.copy(
                                color = textColor,
                                fontWeight = FontWeight.Black
                            )
                        )
                        Text(
                            text = booking.originCity,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = secondaryTextColor
                            )
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.FlightTakeoff,
                        contentDescription = "Flight",
                        tint = accentColor,
                        modifier = Modifier.size(24.dp)
                    )

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = booking.destIata,
                            style = MaterialTheme.typography.headlineLarge.copy(
                                color = textColor,
                                fontWeight = FontWeight.Black
                            )
                        )
                        Text(
                            text = booking.destCity,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = secondaryTextColor
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Dashed Line Divider
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                ) {
                    drawLine(
                        color = if (isBrightnessBoosted) Color.LightGray else Color.Gray,
                        start = Offset(0f, 0f),
                        end = Offset(size.width, 0f),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Passenger Details Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (isArabic) "المسافر" else "PASSENGER",
                            style = MaterialTheme.typography.labelSmall.copy(color = secondaryTextColor, fontSize = 10.sp)
                        )
                        Text(
                            text = booking.passengerName,
                            style = MaterialTheme.typography.bodyMedium.copy(color = textColor, fontWeight = FontWeight.Bold)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (isArabic) "رقم الحجز" else "PNR / BOOKING REF",
                            style = MaterialTheme.typography.labelSmall.copy(color = secondaryTextColor, fontSize = 10.sp)
                        )
                        Text(
                            text = booking.bookingReference,
                            style = MaterialTheme.typography.bodyMedium.copy(color = accentColor, fontWeight = FontWeight.Bold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (isArabic) "رقم الرحلة" else "FLIGHT",
                            style = MaterialTheme.typography.labelSmall.copy(color = secondaryTextColor, fontSize = 10.sp)
                        )
                        Text(
                            text = booking.flightNumber,
                            style = MaterialTheme.typography.bodyMedium.copy(color = textColor, fontWeight = FontWeight.Bold)
                        )
                    }

                    Column {
                        Text(
                            text = if (isArabic) "التاريخ" else "DATE",
                            style = MaterialTheme.typography.labelSmall.copy(color = secondaryTextColor, fontSize = 10.sp)
                        )
                        Text(
                            text = booking.departureDate,
                            style = MaterialTheme.typography.bodyMedium.copy(color = textColor, fontWeight = FontWeight.Bold)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (isArabic) "وقت صعود الطائرة" else "BOARDING TIME",
                            style = MaterialTheme.typography.labelSmall.copy(color = secondaryTextColor, fontSize = 10.sp)
                        )
                        Text(
                            text = booking.departureTime,
                            style = MaterialTheme.typography.bodyMedium.copy(color = textColor, fontWeight = FontWeight.Bold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (isArabic) "المقعد" else "SEAT",
                            style = MaterialTheme.typography.labelSmall.copy(color = secondaryTextColor, fontSize = 10.sp)
                        )
                        Text(
                            text = booking.seatNumber.ifBlank { "TBD" },
                            style = MaterialTheme.typography.titleMedium.copy(color = accentColor, fontWeight = FontWeight.Black)
                        )
                    }

                    Column {
                        Text(
                            text = if (isArabic) "البوابة" else "GATE",
                            style = MaterialTheme.typography.labelSmall.copy(color = secondaryTextColor, fontSize = 10.sp)
                        )
                        Text(
                            text = booking.gate.ifBlank { "A12" },
                            style = MaterialTheme.typography.titleMedium.copy(color = textColor, fontWeight = FontWeight.Black)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (isArabic) "الصالة" else "TERMINAL",
                            style = MaterialTheme.typography.labelSmall.copy(color = secondaryTextColor, fontSize = 10.sp)
                        )
                        Text(
                            text = booking.terminal.ifBlank { "2" },
                            style = MaterialTheme.typography.titleMedium.copy(color = textColor, fontWeight = FontWeight.Black)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // QR Code Container
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isBrightnessBoosted) Color(0xFFF0F0F0) else Color.White)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Boarding Pass QR",
                            tint = Color.Black,
                            modifier = Modifier.size(160.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = booking.qrCodeData,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.DarkGray,
                                fontSize = 9.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
