package com.example.ui.boardingpass

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BookingEntity
import com.example.data.repository.BookingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class BoardingPassViewModel(
    private val bookingRepository: BookingRepository
) : ViewModel() {

    private val _booking = MutableStateFlow<BookingEntity?>(null)
    val booking: StateFlow<BookingEntity?> = _booking.asStateFlow()

    fun loadBoardingPass(pnr: String) {
        viewModelScope.launch {
            val item = bookingRepository.getBookingByPnr(pnr)
            if (item != null) {
                _booking.value = item
            } else {
                // Fallback to active trip
                val active = bookingRepository.activeTripFlow
                _booking.value = com.example.data.remote.MockAirlineData.INITIAL_ACTIVE_BOOKING
            }
        }
    }
}
