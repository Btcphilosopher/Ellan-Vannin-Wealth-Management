package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Airport
import com.example.data.remote.MockAirlineData
import com.example.ui.theme.RiyadhBorder
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurface
import com.example.ui.theme.RiyadhSurfaceCard
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun AirportPickerDialog(
    title: String,
    onDismiss: () -> Unit,
    onAirportSelected: (Airport) -> Unit,
    isArabic: Boolean = false
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredAirports = remember(searchQuery) {
        if (searchQuery.isBlank()) MockAirlineData.AIRPORTS
        else MockAirlineData.AIRPORTS.filter {
            it.cityEn.contains(searchQuery, ignoreCase = true) ||
            it.cityAr.contains(searchQuery, ignoreCase = true) ||
            it.iataCode.contains(searchQuery, ignoreCase = true) ||
            it.nameEn.contains(searchQuery, ignoreCase = true)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, RiyadhBorder, RoundedCornerShape(24.dp))
                .testTag("airport_picker_dialog"),
            color = RiyadhSurface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = RiyadhTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_airport_picker")) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = RiyadhTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = if (isArabic) "ابحث بالمدينة، المطار أو رمز IATA" else "Search city, airport or IATA code",
                            style = MaterialTheme.typography.bodySmall.copy(color = RiyadhTextSecondary)
                        )
                    },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = RiyadhLavenderLight)
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = RiyadhSurfaceCard,
                        unfocusedContainerColor = RiyadhSurfaceCard,
                        focusedBorderColor = RiyadhIndigoPrimary,
                        unfocusedBorderColor = RiyadhBorder,
                        focusedTextColor = RiyadhTextPrimary,
                        unfocusedTextColor = RiyadhTextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("airport_search_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // List
                LazyColumn(modifier = Modifier.height(300.dp)) {
                    items(filteredAirports) { airport ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    onAirportSelected(airport)
                                    onDismiss()
                                }
                                .padding(vertical = 12.dp, horizontal = 8.dp)
                                .testTag("airport_item_${airport.iataCode}"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(RiyadhIndigoPrimary.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FlightTakeoff,
                                        contentDescription = "Airport",
                                        tint = RiyadhLavenderLight,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (isArabic) airport.cityAr else airport.cityEn,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = RiyadhTextPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = if (isArabic) airport.nameAr else airport.nameEn,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = RiyadhTextSecondary,
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(RiyadhBorder.copy(alpha = 0.5f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = airport.iataCode,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = RiyadhLavenderLight,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
