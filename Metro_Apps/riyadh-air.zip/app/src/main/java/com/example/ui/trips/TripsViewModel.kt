package com.example.ui.trips

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BookingEntity
import com.example.data.repository.BookingRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TripsViewModel(
    private val bookingRepository: BookingRepository
) : ViewModel() {

    val allBookings: StateFlow<List<BookingEntity>> = bookingRepository.allBookingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun cancelBooking(pnr: String) {
        viewModelScope.launch {
            bookingRepository.cancelBooking(pnr)
        }
    }

    fun updateSeat(pnr: String, newSeat: String) {
        viewModelScope.launch {
            bookingRepository.updateSeat(pnr, newSeat)
        }
    }
}
