package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Seat
import com.example.data.model.SeatStatus
import com.example.ui.theme.RiyadhBorder
import com.example.ui.theme.RiyadhGoldAccent
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurfaceCard
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun SeatMap(
    seats: List<Seat>,
    selectedSeatNumber: String?,
    onSeatSelected: (Seat) -> Unit,
    currency: String = "SAR",
    isArabic: Boolean = false
) {
    val rows = seats.groupBy { it.rowNumber }

    Column(modifier = Modifier.fillMaxWidth()) {
        // Legend Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            LegendItem(color = RiyadhSurfaceCard, label = if (isArabic) "متاح" else "Available")
            LegendItem(color = RiyadhIndigoPrimary, label = if (isArabic) "محدد" else "Selected")
            LegendItem(color = Color.DarkGray, label = if (isArabic) "مشغول" else "Occupied")
            LegendItem(color = RiyadhGoldAccent, label = if (isArabic) "مساحة إضافية" else "Extra Legroom")
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Seats List by Rows
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(380.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(RiyadhSurfaceCard.copy(alpha = 0.5f))
                .border(1.dp, RiyadhBorder, RoundedCornerShape(16.dp))
                .padding(12.dp)
        ) {
            items(rows.entries.toList()) { (rowNum, rowSeats) ->
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Row $rowNum",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = RiyadhTextSecondary,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.width(48.dp)
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            rowSeats.forEach { seat ->
                                val isSelected = seat.seatNumber == selectedSeatNumber
                                val isOccupied = seat.status == SeatStatus.OCCUPIED

                                val bg = when {
                                    isSelected -> RiyadhIndigoPrimary
                                    isOccupied -> Color.DarkGray
                                    seat.hasExtraLegroom -> RiyadhGoldAccent.copy(alpha = 0.3f)
                                    else -> RiyadhSurfaceCard
                                }

                                val borderClr = when {
                                    isSelected -> Color.White
                                    seat.hasExtraLegroom -> RiyadhGoldAccent
                                    else -> RiyadhBorder
                                }

                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(bg)
                                        .border(1.dp, borderClr, RoundedCornerShape(8.dp))
                                        .clickable(enabled = !isOccupied) { onSeatSelected(seat) }
                                        .testTag("seat_button_${seat.seatNumber}"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = seat.columnLetter,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = if (isSelected) Color.White else if (isOccupied) Color.Gray else RiyadhTextPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(14.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(color)
                .border(1.dp, RiyadhBorder, RoundedCornerShape(4.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(color = RiyadhTextSecondary, fontSize = 10.sp)
        )
    }
}
