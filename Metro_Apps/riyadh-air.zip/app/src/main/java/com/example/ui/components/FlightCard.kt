package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Flight
import com.example.ui.theme.RiyadhBorder
import com.example.ui.theme.RiyadhIndigoPrimary
import com.example.ui.theme.RiyadhLavenderLight
import com.example.ui.theme.RiyadhSurfaceCard
import com.example.ui.theme.RiyadhTextPrimary
import com.example.ui.theme.RiyadhTextSecondary

@Composable
fun FlightCard(
    flight: Flight,
    onSelectFlight: (Flight) -> Unit,
    currency: String = "SAR",
    isArabic: Boolean = false
) {
    val lowestFare = flight.fares.minByOrNull { it.priceSar }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .border(1.dp, RiyadhBorder, RoundedCornerShape(16.dp))
            .clickable { onSelectFlight(flight) }
            .testTag("flight_card_${flight.id}"),
        colors = CardDefaults.cardColors(containerColor = RiyadhSurfaceCard),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Flight Number & Aircraft
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(RiyadhIndigoPrimary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "R",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = RiyadhLavenderLight,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) "طيران الرياض ${flight.flightNumber}" else "Riyadh Air ${flight.flightNumber}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = RiyadhTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.05f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = flight.aircraftType,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = RiyadhTextSecondary,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Departs -> Journey Line -> Arrives
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Departure
                Column {
                    Text(
                        text = flight.departureTime,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = RiyadhTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    )
                    Text(
                        text = flight.origin.iataCode,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = RiyadhLavenderLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                // Journey Duration Line
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = flight.durationText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = RiyadhTextSecondary,
                            fontSize = 11.sp
                        )
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(30.dp)
                                .height(1.dp)
                                .background(RiyadhLavenderLight.copy(alpha = 0.5f))
                        )
                        Icon(
                            imageVector = Icons.Default.FlightTakeoff,
                            contentDescription = "Flight",
                            tint = RiyadhLavenderLight,
                            modifier = Modifier.size(16.dp).padding(horizontal = 2.dp)
                        )
                        Box(
                            modifier = Modifier
                                .width(30.dp)
                                .height(1.dp)
                                .background(RiyadhLavenderLight.copy(alpha = 0.5f))
                        )
                    }
                    Text(
                        text = if (flight.stops == 0) (if (isArabic) "مباشر" else "Non-stop") else "${flight.stops} ${if (isArabic) "توقف" else "stop"}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = RiyadhLavenderLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }

                // Arrival
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = flight.arrivalTime,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = RiyadhTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    )
                    Text(
                        text = flight.destination.iataCode,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = RiyadhLavenderLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Price Pill & Fare Family
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = lowestFare?.let { if (isArabic) it.nameAr else it.nameEn } ?: "",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = RiyadhTextSecondary,
                        fontSize = 12.sp
                    )
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(RiyadhIndigoPrimary)
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "$currency ${lowestFare?.priceSar?.toInt() ?: 0}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    )
                }
            }
        }
    }
}
