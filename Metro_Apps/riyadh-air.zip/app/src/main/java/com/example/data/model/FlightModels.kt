package com.example.data.model

data class Airport(
    val iataCode: String,
    val cityEn: String,
    val cityAr: String,
    val nameEn: String,
    val nameAr: String,
    val countryEn: String,
    val countryAr: String
) {
    fun getDisplayName(isArabic: Boolean): String {
        return if (isArabic) "$cityAr ($iataCode)" else "$cityEn ($iataCode)"
    }
}

data class FareFamily(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val priceSar: Double,
    val cabinClass: String, // "ECONOMY", "BUSINESS", "FIRST"
    val baggageKg: Int,
    val cabinBagKg: Int,
    val seatSelectionFree: Boolean,
    val loungeAccess: Boolean,
    val refundable: Boolean,
    val flexibleChange: Boolean
)

data class Flight(
    val id: String,
    val flightNumber: String,
    val origin: Airport,
    val destination: Airport,
    val departureTime: String, // e.g. "08:45"
    val arrivalTime: String,   // e.g. "14:20"
    val durationText: String,  // e.g. "6h 35m"
    val stops: Int,
    val aircraftType: String,  // e.g. "Boeing 787-9 Dreamliner"
    val fares: List<FareFamily>,
    val terminal: String = "2",
    val isDemoData: Boolean = true
)

data class Passenger(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String = "Mr",
    val firstName: String = "",
    val lastName: String = "",
    val email: String = "",
    val phone: String = "",
    val passportNumber: String = "",
    val nationality: String = "Saudi Arabia",
    val passengerType: String = "ADULT"
)

data class Seat(
    val seatNumber: String,
    val rowNumber: Int,
    val columnLetter: String,
    val cabinClass: String, // "BUSINESS" or "ECONOMY"
    val status: SeatStatus,
    val priceExtraSar: Double = 0.0,
    val isExitRow: Boolean = false,
    val hasExtraLegroom: Boolean = false
)

enum class SeatStatus {
    AVAILABLE,
    OCCUPIED,
    SELECTED
}

data class AncillaryOption(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val subtitleEn: String,
    val subtitleAr: String,
    val priceSar: Double,
    val iconType: String,
    var isSelected: Boolean = false
)

data class Destination(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val countryEn: String,
    val countryAr: String,
    val taglineEn: String,
    val taglineAr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val iataCode: String,
    val startingPriceSar: Double,
    val imageDrawableRes: Int? = null,
    val imageUrl: String? = null
)

data class NotificationItem(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val bodyEn: String,
    val bodyAr: String,
    val timestamp: String,
    val isRead: Boolean = false,
    val type: String // "FLIGHT_STATUS", "GATE_CHANGE", "CHECK_IN_OPEN", "OFFER"
)
