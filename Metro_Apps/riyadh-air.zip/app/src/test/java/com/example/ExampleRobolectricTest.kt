package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.remote.MockAirlineData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string app_name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Riyadh Air", appName)
    }

    @Test
    fun `test flight search and airport lookup`() {
        val airports = MockAirlineData.AIRPORTS
        assertTrue(airports.any { it.iataCode == "RUH" })
        assertTrue(airports.any { it.iataCode == "LHR" })

        val flights = MockAirlineData.searchFlights("RUH", "LHR", "12 Nov 2025", "BUSINESS")
        assertTrue(flights.isNotEmpty())
        assertEquals("RUH", flights[0].origin.iataCode)
        assertEquals("LHR", flights[0].destination.iataCode)
    }

    @Test
    fun `test seat map generation for business class`() {
        val seats = MockAirlineData.generateSeatMap("BUSINESS")
        assertTrue(seats.isNotEmpty())
        val seat1A = seats.firstOrNull { it.seatNumber == "1A" }
        assertNotNull(seat1A)
        assertEquals("BUSINESS", seat1A?.cabinClass)
    }
}
