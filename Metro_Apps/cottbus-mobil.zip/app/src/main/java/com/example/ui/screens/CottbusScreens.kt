package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CottbusDataProvider
import com.example.ui.components.*
import com.example.ui.viewmodel.CottbusViewModel
import com.example.ui.viewmodel.Screen
import com.example.model.*
import java.time.format.DateTimeFormatter

@Composable
fun HomeScreenView(
    viewModel: CottbusViewModel,
    modifier: Modifier = Modifier
) {
    val currentTime by viewModel.currentTime.collectAsState()
    val savedPlaces by viewModel.savedPlaces.collectAsState()
    val favoriteLines by viewModel.favoriteLines.collectAsState()
    var searchInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Time overlay + Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "COTTBUS MOBIL",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Text(
                        text = "Guten Morgen",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(
                        text = currentTime.format(DateTimeFormatter.ofPattern("HH:mm")),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // Primary Question Search Field
        item {
            Column {
                Text(
                    text = "Wo möchtest du hin?",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                SearchBar(
                    value = searchInput,
                    onValueChange = {
                        searchInput = it
                        if (it.isNotEmpty()) {
                            viewModel.navigateTo(Screen.Search)
                        }
                    },
                    placeholder = "Haltestelle, Adresse oder Ziel..."
                )
            }
        }

        // Grid Menu Shortcuts
        item {
            Text(
                text = "Entdecken & Services",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Departures Shortcut
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(90.dp)
                        .clickable { viewModel.navigateTo(Screen.StationDetail("cottbus-hbf")) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(Icons.Default.DirectionsBus, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("Abfahrten", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    }
                }

                // Map Shortcut
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(90.dp)
                        .clickable { viewModel.navigateTo(Screen.MapNetzplan) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(Icons.Default.Map, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("Netzplan", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Service Alerts Shortcut
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(90.dp)
                        .clickable { viewModel.navigateTo(Screen.ServiceAlerts) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFD97706))
                        Text("Störungen", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    }
                }

                // Tickets Shortcut
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(90.dp)
                        .clickable { viewModel.navigateTo(Screen.Tickets) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = Color(0xFF16A34A))
                        Text("Tickets", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        // Saved destinations / Schnellziele
        item {
            Text(
                text = "Meine Ziele",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (savedPlaces.isEmpty()) {
            item {
                Text(
                    text = "Noch keine Ziele gespeichert.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        } else {
            items(savedPlaces) { place ->
                val station = viewModel.stations.value.find { it.id == place.stationId }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                        .clickable {
                            viewModel.selectedOrigin.value = viewModel.stations.value.find { it.id == "cottbus-hbf" }
                            viewModel.selectedDestination.value = station
                            viewModel.executeRouteSearch()
                            viewModel.navigateTo(Screen.RoutePlanner)
                        }
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = when (place.label) {
                                "Zuhause" -> Icons.Default.Home
                                "Arbeit" -> Icons.Default.Work
                                "Universität" -> Icons.Default.School
                                else -> Icons.Default.Star
                            },
                            contentDescription = place.label,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(place.label, fontWeight = FontWeight.Bold)
                            place.customName?.let {
                                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                }
            }
        }

        // Netzstatus / Overall system condition
        item {
            Text(
                text = "Netzstatus",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Straßenbahn", fontWeight = FontWeight.Bold)
                        Text("Eingeschränkt", color = Color(0xFFD97706), fontWeight = FontWeight.Bold)
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Busnetz", fontWeight = FontWeight.Bold)
                        Text("Normalbetrieb", color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Regionalverkehr", fontWeight = FontWeight.Bold)
                        Text("Normalbetrieb", color = Color(0xFF16A34A), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SearchScreenView(
    viewModel: CottbusViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler { viewModel.navigateBack() }
    var searchInput by remember { mutableStateOf("") }
    val stations = viewModel.stations.value

    val filtered = stations.filter {
        it.name.contains(searchInput, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        CottbusHeader(
            title = "Station suchen",
            onBackClick = { viewModel.navigateBack() }
        )

        SearchBar(
            value = searchInput,
            onValueChange = { searchInput = it },
            placeholder = "z.B. Cottbus Hauptbahnhof, Sandow, BTU..."
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filtered) { station ->
                StationCard(
                    station = station,
                    onClick = {
                        // Launch Route Planner directly from search
                        viewModel.selectedOrigin.value = stations.find { it.id == "cottbus-hbf" }
                        viewModel.selectedDestination.value = station
                        viewModel.executeRouteSearch()
                        viewModel.navigateTo(Screen.RoutePlanner)
                    }
                )
            }
        }
    }
}

@Composable
fun RoutePlannerView(
    viewModel: CottbusViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler { viewModel.navigateBack() }
    val origin by viewModel.selectedOrigin.collectAsState()
    val destination by viewModel.selectedDestination.collectAsState()
    val onlyAccessible by viewModel.onlyAccessibleRoute.collectAsState()
    val routes by viewModel.searchResults.collectAsState()

    var showOriginPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        CottbusHeader(
            title = "Verbindung planen",
            onBackClick = { viewModel.navigateBack() }
        )

        // Picker Row for Origin
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showOriginPicker = true },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = origin?.name ?: "Startpunkt wählen",
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (origin != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.secondary
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Picker Row for Destination
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showDestPicker = true },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Flag, contentDescription = null, tint = Color(0xFFDC2626))
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = destination?.name ?: "Zielpunkt wählen",
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (destination != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.secondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Toggle Barrier-free option
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Nur barrierefreie Verbindungen", fontWeight = FontWeight.Bold)
            Switch(
                checked = onlyAccessible,
                onCheckedChange = {
                    viewModel.onlyAccessibleRoute.value = it
                    viewModel.executeRouteSearch()
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Vorgeschlagene Routen", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        if (routes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Keine passenden Verbindungen gefunden.\nBitte wählen Sie unterschiedliche Haltestellen.",
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(routes) { journey ->
                    JourneyCard(
                        journey = journey,
                        onClick = { viewModel.navigateTo(Screen.JourneyDetail(journey)) }
                    )
                }
            }
        }
    }

    // Modal pickers
    if (showOriginPicker) {
        AlertDialog(
            onDismissRequest = { showOriginPicker = false },
            title = { Text("Startbahnhof wählen") },
            text = {
                LazyColumn {
                    items(CottbusDataProvider.stations) { station ->
                        Text(
                            text = station.name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectedOrigin.value = station
                                    showOriginPicker = false
                                    viewModel.executeRouteSearch()
                                }
                                .padding(16.dp)
                        )
                    }
                }
            },
            confirmButton = {}
        )
    }

    if (showDestPicker) {
        AlertDialog(
            onDismissRequest = { showDestPicker = false },
            title = { Text("Zielbahnhof wählen") },
            text = {
                LazyColumn {
                    items(CottbusDataProvider.stations) { station ->
                        Text(
                            text = station.name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectedDestination.value = station
                                    showDestPicker = false
                                    viewModel.executeRouteSearch()
                                }
                                .padding(16.dp)
                        )
                    }
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
fun JourneyDetailView(
    viewModel: CottbusViewModel,
    journey: Journey,
    modifier: Modifier = Modifier
) {
    BackHandler { viewModel.navigateBack() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        CottbusHeader(
            title = "Deine Verbindung",
            onBackClick = { viewModel.navigateBack() }
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Gesamtfahrpreis:", fontWeight = FontWeight.Bold)
                    Text(
                        text = String.format("%.2f €", journey.price),
                        color = Color(0xFF16A34A),
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        viewModel.buyDemoTicket("Einzelfahrt", "Erwachsener", journey.price)
                        viewModel.navigateTo(Screen.Tickets)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("buy_ticket_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                ) {
                    Text("Fahrkarte kaufen (DEMO)", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Verbindungsdetails", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {
            items(journey.legs) { leg ->
                RouteStep(leg = leg)
            }
        }

        Button(
            onClick = { viewModel.navigateTo(Screen.ActiveTrip(journey)) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
                .testTag("start_trip_button"),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Icon(Icons.Default.Navigation, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Fahrt starten (Live-Begleiter)", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ActiveTripView(
    viewModel: CottbusViewModel,
    journey: Journey,
    modifier: Modifier = Modifier
) {
    BackHandler { viewModel.navigateBack() }
    val exitWarningCount by viewModel.exitWarningStops.collectAsState()
    val isTriggered by viewModel.exitWarningTriggered.collectAsState()

    var currentStopIndex by remember { mutableStateOf(0) }
    val totalStops = 5

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            CottbusHeader(
                title = "DEINE AKTIVE FAHRT",
                onBackClick = { viewModel.navigateBack() }
            )

            // Live status card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Nächster Halt in 2 Min",
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Box(
                            modifier = Modifier
                                .background(Color.White, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "SIMULATION",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Linie 4 Richtung Sachsendorf",
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Stop visual progress
            Text("Fahrstrecke", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                listOf(
                    "Cottbus Hauptbahnhof" to true,
                    "Carl-Thiem-Klinikum" to false,
                    "Sachsendorf" to false
                ).forEachIndexed { idx, (stop, passed) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .background(
                                    color = if (idx <= currentStopIndex) Color(0xFF16A34A) else MaterialTheme.colorScheme.outline,
                                    shape = RoundedCornerShape(8.dp)
                                )
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = stop,
                            fontWeight = if (idx == currentStopIndex) FontWeight.Black else FontWeight.Bold,
                            color = if (idx == currentStopIndex) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Ausstiegswarnung configuration
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Ausstiegswarnung einrichten", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Benachrichtigen:")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(1, 2, 3).forEach { stopCount ->
                                FilterChip(
                                    selected = exitWarningCount == stopCount,
                                    onClick = { viewModel.exitWarningStops.value = stopCount },
                                    label = { Text("$stopCount Halt davor") }
                                )
                            }
                        }
                    }
                }
            }
        }

        Button(
            onClick = { viewModel.navigateBack() },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
        ) {
            Text("Fahrt beenden", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ServiceAlertsView(
    viewModel: CottbusViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler { viewModel.navigateBack() }
    val alerts by viewModel.alerts.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        CottbusHeader(
            title = "Aktuelle Störungen",
            onBackClick = { viewModel.navigateBack() }
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(alerts) { alert ->
                ServiceAlertItem(alert = alert, onClick = {})
            }
        }
    }
}

@Composable
fun MapNetzplanView(
    viewModel: CottbusViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler { viewModel.navigateBack() }
    val selectedStation by viewModel.selectedMapStation.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            CottbusHeader(
                title = "ÖPNV Netzplan Cottbus",
                onBackClick = { viewModel.navigateBack() }
            )

            Text(
                "Interaktive Karte der Tram- & Buslinien. Tippen Sie auf eine Station, um Echtzeit-Abfahrten anzuzeigen.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            MapPanel(onStationSelect = { viewModel.selectedMapStation.value = it })
        }

        // Context details on map tap
        selectedStation?.let { station ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(station.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        IconButton(onClick = { viewModel.selectedMapStation.value = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Schließen")
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            viewModel.selectedDestination.value = station
                            viewModel.navigateTo(Screen.RoutePlanner)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Hierhin navigieren", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TicketsView(
    viewModel: CottbusViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler { viewModel.navigateBack() }
    val tickets by viewModel.tickets.collectAsState()

    var showPurchaseDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            CottbusHeader(
                title = "Meine Fahrkarten",
                onBackClick = { viewModel.navigateBack() }
            )

            if (tickets.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Keine aktiven Tickets vorhanden.\nKaufen Sie ein Ticket über den Planer oder das Menü unten.",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(tickets) { ticket ->
                        TicketCard(ticket = ticket)
                    }
                }
            }
        }

        Button(
            onClick = { showPurchaseDialog = true },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Einzelfahrkarte kaufen (DEMO)", fontWeight = FontWeight.Bold)
        }
    }

    if (showPurchaseDialog) {
        AlertDialog(
            onDismissRequest = { showPurchaseDialog = false },
            title = { Text("Fahrkarte kaufen") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Achtung: Dies simuliert eine VBB-Transaktion. Es wird kein echtes Geld abgebucht.",
                        color = Color.Red,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Tarifgebiet: Cottbus AB\nPreis: 3,30 €")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.buyDemoTicket("Einzelfahrt", "Erwachsener", 3.30)
                        showPurchaseDialog = false
                    }
                ) {
                    Text("Kauf bestätigen")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPurchaseDialog = false }) {
                    Text("Abbrechen")
                }
            }
        )
    }
}

@Composable
fun StationDetailView(
    viewModel: CottbusViewModel,
    stationId: String,
    modifier: Modifier = Modifier
) {
    BackHandler { viewModel.navigateBack() }
    val station = viewModel.stations.value.find { it.id == stationId } ?: return
    val departures = viewModel.getDeparturesForStation(stationId)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        CottbusHeader(
            title = station.name,
            subtitle = "Abfahrtsmonitor",
            onBackClick = { viewModel.navigateBack() }
        )

        // Station info card showing accessibility
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Ausstattung & Barrierefreiheit", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (station.hasElevator) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Elevator, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Aufzug", fontSize = 12.sp)
                        }
                    }
                    if (station.hasRamp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Accessible, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Stufenfrei", fontSize = 12.sp)
                        }
                    }
                    if (station.hasTicketMachine) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Automat", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Abfahrten", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
            Text("LIVE", color = Color(0xFF16A34A), fontWeight = FontWeight.Black, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(12.dp))

        if (departures.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("Keine aktuellen Abfahrten geplant.", color = MaterialTheme.colorScheme.secondary)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(departures) { arrival ->
                    ArrivalRow(arrival = arrival)
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                }
            }
        }

        // Action Buttons
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        ) {
            Button(
                onClick = {
                    viewModel.selectedOrigin.value = station
                    viewModel.navigateTo(Screen.RoutePlanner)
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Von hier planen", fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = {
                    viewModel.selectedDestination.value = station
                    viewModel.navigateTo(Screen.RoutePlanner)
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
            ) {
                Text("Hierhin planen", fontWeight = FontWeight.Bold)
            }
        }
    }
}

