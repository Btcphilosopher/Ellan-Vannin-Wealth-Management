package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CottbusDataProvider
import com.example.model.*
import kotlin.math.sqrt

@Composable
fun CottbusHeader(
    title: String,
    subtitle: String? = null,
    onBackClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBackClick != null) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier
                    .padding(end = 8.dp)
                    .testTag("back_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Zurück",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
        Column(modifier = Modifier.weight(1.0f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 0.5.sp
                )
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.secondary
                    )
                )
            }
        }
    }
}

@Composable
fun SearchBar(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder) },
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Suche",
                tint = MaterialTheme.colorScheme.secondary
            )
        },
        trailingIcon = {
            if (value.isNotEmpty()) {
                IconButton(onClick = { onValueChange("") }) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Löschen",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        },
        modifier = modifier
            .fillMaxWidth()
            .testTag("search_bar"),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(12.dp)
    )
}

@Composable
fun LineBadge(
    lineId: String,
    lineName: String,
    colorHex: String,
    modifier: Modifier = Modifier
) {
    val color = try {
        Color(android.graphics.Color.parseColor(colorHex))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    Box(
        modifier = modifier
            .background(color, shape = RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = lineName,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
fun StationCard(
    station: Station,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("station_card_${station.id}"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (station.category == "Bahnhof") Icons.Default.Train else Icons.Default.DirectionsBus,
                        contentDescription = station.category,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = station.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                if (station.hasElevator || station.hasRamp) {
                    Icon(
                        imageVector = Icons.Default.Accessible,
                        contentDescription = "Barrierefrei",
                        tint = Color(0xFF16A34A),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                station.lines.forEach { lineId ->
                    val lineName = when (lineId) {
                        "tram-2" -> "2"
                        "tram-3" -> "3"
                        "tram-4" -> "4"
                        "bus-10" -> "10"
                        "bus-12" -> "12"
                        "rail-re10" -> "RE10"
                        "rail-rb43" -> "RB43"
                        else -> lineId
                    }
                    val colorHex = when (lineId) {
                        "tram-2" -> "#E30613"
                        "tram-3" -> "#FFDD00"
                        "tram-4" -> "#009640"
                        "bus-10" -> "#0070B8"
                        "bus-12" -> "#009EE0"
                        else -> "#800080"
                    }
                    LineBadge(lineId = lineId, lineName = lineName, colorHex = colorHex)
                }
            }
        }
    }
}

@Composable
fun ArrivalRow(
    arrival: Arrival,
    modifier: Modifier = Modifier
) {
    val lineName = when (arrival.lineId) {
        "tram-2" -> "2"
        "tram-3" -> "3"
        "tram-4" -> "4"
        "bus-10" -> "10"
        "bus-12" -> "12"
        "rail-re10" -> "RE10"
        "rail-rb43" -> "RB43"
        else -> arrival.lineId
    }
    val colorHex = when (arrival.lineId) {
        "tram-2" -> "#E30613"
        "tram-3" -> "#FFDD00"
        "tram-4" -> "#009640"
        "bus-10" -> "#0070B8"
        "bus-12" -> "#009EE0"
        else -> "#800080"
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LineBadge(lineId = arrival.lineId, lineName = lineName, colorHex = colorHex)
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = arrival.direction,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (arrival.source == "realtime") "LIVE" else "Fahrplan",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (arrival.source == "realtime") Color(0xFF16A34A) else MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold
                    )
                    if (arrival.delayMinutes > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "+${arrival.delayMinutes} Min",
                            color = Color(0xFFDC2626),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        Text(
            text = "${arrival.minutes} Min",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
fun ServiceAlertItem(
    alert: ServiceAlert,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = when (alert.status) {
                AlertStatus.VERSPÄTUNG, AlertStatus.EINSCHRÄNKUNG -> Color(0xFFFEF3C7) // Amber
                AlertStatus.AUSFALL, AlertStatus.TEILAUSFALL -> Color(0xFFFEE2E2) // Red
                else -> MaterialTheme.colorScheme.surface
            }
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Icon(
                imageVector = when (alert.status) {
                    AlertStatus.AUSFALL, AlertStatus.TEILAUSFALL -> Icons.Default.Cancel
                    else -> Icons.Default.Warning
                },
                contentDescription = "Alert Symbol",
                tint = when (alert.status) {
                    AlertStatus.AUSFALL, AlertStatus.TEILAUSFALL -> Color(0xFFDC2626)
                    else -> Color(0xFFD97706)
                },
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = alert.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.Black
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = alert.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.DarkGray,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Betrifft: ${alert.affectedRoute}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                    alert.expectedDuration?.let {
                        Text(
                            text = "Dauer: $it",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Black
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun JourneyCard(
    journey: Journey,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("journey_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Dauer: ${journey.totalDurationMinutes} Min.",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = String.format("%.2f €", journey.price),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                    color = Color(0xFF16A34A)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))

            // Draw route steps/line nodes
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                journey.legs.forEachIndexed { index, leg ->
                    if (index > 0) {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Anschluss",
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                    }
                    if (leg.mode == TransportMode.WALK) {
                        Icon(
                            imageVector = Icons.Default.DirectionsWalk,
                            contentDescription = "Fußweg",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(20.dp)
                        )
                    } else {
                        LineBadge(
                            lineId = leg.lineId ?: "",
                            lineName = when (leg.lineId) {
                                "tram-2" -> "2"
                                "tram-3" -> "3"
                                "tram-4" -> "4"
                                "bus-10" -> "10"
                                "bus-12" -> "12"
                                else -> leg.lineName ?: "Bus"
                            },
                            colorHex = leg.lineColor ?: "#000000"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Umstiege: ${journey.transfersCount}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
                if (journey.accessibilityScore >= 2) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Accessible,
                            contentDescription = "Barrierefreie Route",
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Barrierefrei",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF16A34A)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RouteStep(
    leg: JourneyLeg,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.Top
    ) {
        // Vertical indicator line and icon
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(40.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(
                        color = if (leg.mode == TransportMode.WALK) MaterialTheme.colorScheme.outline else Color(
                            android.graphics.Color.parseColor(leg.lineColor ?: "#CCCCCC")
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (leg.mode) {
                        TransportMode.WALK -> Icons.Default.DirectionsWalk
                        TransportMode.RAIL -> Icons.Default.Train
                        else -> Icons.Default.DirectionsBus
                    },
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(40.dp)
                    .background(
                        if (leg.mode == TransportMode.WALK) MaterialTheme.colorScheme.outline else Color(
                            android.graphics.Color.parseColor(leg.lineColor ?: "#CCCCCC")
                        )
                    )
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1.0f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = leg.originStationName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = leg.departureTime,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (leg.mode == TransportMode.WALK) "Fußweg (${leg.durationMinutes} Min.)"
                else "${leg.lineName} Richtung ${leg.destinationStationName} (${leg.durationMinutes} Min.)",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = leg.destinationStationName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = leg.arrivalTime,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun MapPanel(
    onStationSelect: (Station) -> Unit,
    modifier: Modifier = Modifier
) {
    // We will draw a beautiful geographical schematic representing Cottbus network
    val stations = CottbusDataProvider.stations

    // Hardcode some grid visual offsets for a beautiful layout map in Canvas
    val visualMapOffsets = mapOf(
        "neu-schmellwitz" to Offset(0.5f, 0.1f),
        "btu" to Offset(0.4f, 0.3f),
        "strobitz" to Offset(0.15f, 0.45f),
        "stadthalle" to Offset(0.5f, 0.45f),
        "altmarkt" to Offset(0.65f, 0.4f),
        "sandow" to Offset(0.85f, 0.45f),
        "cottbus-hbf" to Offset(0.4f, 0.65f),
        "klinikum" to Offset(0.55f, 0.75f),
        "sachsendorf" to Offset(0.3f, 0.9f),
        "madlow" to Offset(0.7f, 0.9f),
        "branitzer-park" to Offset(0.9f, 0.75f)
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(350.dp)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    // Find closest station visually
                    var closest: Station? = null
                    var minDist = 99999.0f
                    val sizeW = size.width
                    val sizeH = size.height

                    for (station in stations) {
                        val mapPos = visualMapOffsets[station.id] ?: Offset(0.5f, 0.5f)
                        val screenX = mapPos.x * sizeW
                        val screenY = mapPos.y * sizeH
                        val dist = sqrt((offset.x - screenX) * (offset.x - screenX) + (offset.y - screenY) * (offset.y - screenY))
                        if (dist < minDist && dist < 40.dp.toPx()) {
                            minDist = dist
                            closest = station
                        }
                    }

                    closest?.let {
                        onStationSelect(it)
                    }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Draw track connections (Lines)
            // Tram 4: green
            val t4Nodes = listOf("neu-schmellwitz", "btu", "stadthalle", "cottbus-hbf", "klinikum", "sachsendorf")
            for (i in 0 until t4Nodes.size - 1) {
                val p1 = visualMapOffsets[t4Nodes[i]]?.let { Offset(it.x * w, it.y * h) }
                val p2 = visualMapOffsets[t4Nodes[i + 1]]?.let { Offset(it.x * w, it.y * h) }
                if (p1 != null && p2 != null) {
                    drawLine(Color(0xFF009640), p1, p2, strokeWidth = 8f)
                }
            }

            // Tram 3: yellow
            val t3Nodes = listOf("strobitz", "stadthalle", "madlow")
            for (i in 0 until t3Nodes.size - 1) {
                val p1 = visualMapOffsets[t3Nodes[i]]?.let { Offset(it.x * w, it.y * h) }
                val p2 = visualMapOffsets[t3Nodes[i + 1]]?.let { Offset(it.x * w, it.y * h) }
                if (p1 != null && p2 != null) {
                    drawLine(Color(0xFFFFDD00), p1, p2, strokeWidth = 8f)
                }
            }

            // Tram 2: red
            val t2Nodes = listOf("stadthalle", "sandow")
            for (i in 0 until t2Nodes.size - 1) {
                val p1 = visualMapOffsets[t2Nodes[i]]?.let { Offset(it.x * w, it.y * h) }
                val p2 = visualMapOffsets[t2Nodes[i + 1]]?.let { Offset(it.x * w, it.y * h) }
                if (p1 != null && p2 != null) {
                    drawLine(Color(0xFFE30613), p1, p2, strokeWidth = 8f)
                }
            }

            // 2. Draw stations (circles)
            for (station in stations) {
                val mapPos = visualMapOffsets[station.id] ?: Offset(0.5f, 0.5f)
                val cx = mapPos.x * w
                val cy = mapPos.y * h

                // Outer circle
                drawCircle(
                    color = Color.White,
                    radius = 16f,
                    center = Offset(cx, cy)
                )
                // Inner center point
                drawCircle(
                    color = Color(0xFF1E3A8A),
                    radius = 10f,
                    center = Offset(cx, cy)
                )
            }
        }

        // Overlay text labels over canvas visually
        for (station in stations) {
            val mapPos = visualMapOffsets[station.id] ?: Offset(0.5f, 0.5f)
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(
                        x = (mapPos.x * 280).dp,
                        y = (mapPos.y * 310 + 12).dp
                    )
            ) {
                Text(
                    text = station.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 8.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
fun TicketCard(
    ticket: Ticket,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ticket_card"),
        colors = CardDefaults.cardColors(
            containerColor = if (ticket.isValid) Color(0xFFECFDF5) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, if (ticket.isValid) Color(0xFF10B981) else MaterialTheme.colorScheme.outline),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = ticket.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                if (ticket.isValid) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF10B981), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "AKTIV",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Gekauft am: ${ticket.purchasedAt}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                text = "Kategorie: ${ticket.passengerType}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = "DEMO TICKET",
                    color = Color.Red,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 2.dp)
                )
                Text(
                    text = String.format("%.2f €", ticket.price),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
