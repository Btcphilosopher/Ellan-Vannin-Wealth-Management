package com.example.model

import java.time.LocalDateTime

enum class TransportMode {
    TRAM, BUS, REGIONAL_BUS, RAIL, WALK, BIKE
}

enum class AlertStatus {
    NORMAL, VERSPÄTUNG, EINSCHRÄNKUNG, TEILAUSFALL, AUSFALL, GEPLANTE_ARBEITEN, UNBEKANNT
}

data class Location(
    val lat: Double,
    val lon: Double
)

data class Operator(
    val id: String,
    val name: String,
    val shortName: String
)

data class TransitLine(
    val id: String,
    val name: String,
    val mode: TransportMode,
    val color: String, // Hex string
    val operatorId: String
)

data class Route(
    val id: String,
    val lineId: String,
    val direction: String,
    val stopIds: List<String>
)

data class Station(
    val id: String,
    val name: String,
    val location: Location,
    val lines: List<String>,
    val hasElevator: Boolean = false,
    val hasRamp: Boolean = false,
    val hasTicketMachine: Boolean = false,
    val entranceCount: Int = 1,
    val category: String = "Haltestelle" // e.g. "Bahnhof", "Haltestelle", "POIs"
)

data class Stop(
    val id: String,
    val stationId: String,
    val name: String,
    val platform: String? = null
)

data class StopArea(
    val id: String,
    val stationId: String,
    val name: String
)

data class Trip(
    val id: String,
    val routeId: String,
    val serviceId: String,
    val headsign: String
)

data class StopTime(
    val tripId: String,
    val stopId: String,
    val stopSequence: Int,
    val arrivalTime: String, // "HH:MM"
    val departureTime: String // "HH:MM"
)

data class Vehicle(
    val id: String,
    val lineId: String,
    val currentStationId: String,
    val lat: Double,
    val lon: Double,
    val delayMinutes: Int = 0
)

data class Arrival(
    val lineId: String,
    val direction: String,
    val minutes: Int,
    val source: String, // "realtime" or "scheduled" or "simulation"
    val updatedAt: String,
    val delayMinutes: Int = 0,
    val isCancelled: Boolean = false
)

data class Transfer(
    val fromStopId: String,
    val toStopId: String,
    val durationMinutes: Int
)

data class FareRule(
    val id: String,
    val operator: String,
    val originZone: String,
    val destinationZone: String,
    val passengerType: String, // "Erwachsener", "Ermäßigt"
    val ticketType: String, // "Einzelfahrt", "Tageskarte", "Monatskarte"
    val validFrom: String,
    val validUntil: String,
    val price: Double
)

data class ServiceAlert(
    val id: String,
    val lineId: String?,
    val status: AlertStatus,
    val title: String,
    val description: String,
    val affectedRoute: String,
    val start: String,
    val expectedDuration: String?,
    val updatedAt: String
)

data class JourneyLeg(
    val mode: TransportMode,
    val lineId: String?, // null if Walk/Bike
    val lineName: String?,
    val lineColor: String?,
    val originStationId: String,
    val originStationName: String,
    val destinationStationId: String,
    val destinationStationName: String,
    val departureTime: String, // "HH:MM"
    val arrivalTime: String, // "HH:MM"
    val durationMinutes: Int,
    val stopCount: Int = 0,
    val intermediateStops: List<String> = emptyList()
)

data class Journey(
    val id: String,
    val legs: List<JourneyLeg>,
    val totalDurationMinutes: Int,
    val price: Double,
    val accessibilityScore: Int, // 0 = not accessible, 1 = partially, 2 = fully accessible
    val transfersCount: Int
)

data class Place(
    val id: String,
    val name: String,
    val category: String, // "Kultur", "Parks", "Universität", "Einkaufen", "Sport", "Bahnhof", "Haltestelle", "Innenstadt"
    val location: Location,
    val bestStopId: String,
    val walkTimeMinutes: Int
)

data class SavedPlace(
    val id: String,
    val label: String, // "Zuhause", "Arbeit", "Universität", "Familie" or custom
    val customName: String?,
    val stationId: String
)

data class Ticket(
    val id: String,
    val title: String,
    val price: Double,
    val type: String, // "Einzelfahrt", "Tageskarte", "Monatskarte"
    val passengerType: String, // "Erwachsener", "Ermäßigt"
    val isValid: Boolean,
    val purchasedAt: String,
    val isDemo: Boolean = true
)
