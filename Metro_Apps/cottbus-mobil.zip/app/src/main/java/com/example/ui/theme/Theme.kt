package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = DarkBlueAccent,
    secondary = SoftWhite,
    background = DarkBackground,
    surface = DarkSurface,
    onPrimary = SoftWhite,
    onSecondary = DarkBackground,
    onBackground = SoftWhite,
    onSurface = SoftWhite,
    outline = DarkWarmGrey
)

private val LightColorScheme = lightColorScheme(
    primary = DarkBlue,
    secondary = Graphite,
    background = LightBackground,
    surface = LightSurface,
    onPrimary = SoftWhite,
    onSecondary = SoftWhite,
    onBackground = Graphite,
    onSurface = Graphite,
    outline = WarmLightGrey
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Disabled to enforce consistent Cottbus theme identity
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
