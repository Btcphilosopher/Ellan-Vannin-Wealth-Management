package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors
val LightBackground = Color(0xFFF9F9FB)
val LightSurface = Color(0xFFFFFFFF)
val Graphite = Color(0xFF2C3E50)
val DarkBlue = Color(0xFF1E3A8A)
val WarmLightGrey = Color(0xFFE5E7EB)

val AccentRed = Color(0xFFDC2626)
val AccentOrange = Color(0xFFF97316)
val AccentGreen = Color(0xFF16A34A)

// Dark Colors
val DarkBackground = Color(0xFF111827)
val DarkSurface = Color(0xFF1F2937)
val SoftWhite = Color(0xFFF3F4F6)
val DarkWarmGrey = Color(0xFF374151)
val DarkBlueAccent = Color(0xFF3B82F6)
