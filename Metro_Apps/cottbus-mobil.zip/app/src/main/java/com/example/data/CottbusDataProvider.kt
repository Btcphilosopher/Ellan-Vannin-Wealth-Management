package com.example.data

import com.example.model.*
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.*

object CottbusDataProvider {

    val operators = listOf(
        Operator("cottbusverkehr", "Cottbusverkehr GmbH", "CV"),
        Operator("vbb", "Verkehrsverbund Berlin-Brandenburg", "VBB"),
        Operator("db", "DB Regio Nordost", "DB")
    )

    val lines = listOf(
        TransitLine("tram-2", "Tram 2", TransportMode.TRAM, "#E30613", "cottbusverkehr"),
        TransitLine("tram-3", "Tram 3", TransportMode.TRAM, "#FFDD00", "cottbusverkehr"),
        TransitLine("tram-4", "Tram 4", TransportMode.TRAM, "#009640", "cottbusverkehr"),
        TransitLine("bus-10", "Bus 10", TransportMode.BUS, "#0070B8", "cottbusverkehr"),
        TransitLine("bus-12", "Bus 12", TransportMode.BUS, "#009EE0", "cottbusverkehr"),
        TransitLine("rail-re10", "RE10", TransportMode.RAIL, "#800080", "db"),
        TransitLine("rail-rb43", "RB43", TransportMode.RAIL, "#8B008B", "db")
    )

    val stations = listOf(
        Station(
            id = "cottbus-hbf",
            name = "Cottbus Hauptbahnhof",
            location = Location(51.7486, 14.3228),
            lines = listOf("tram-3", "tram-4", "bus-10", "rail-re10", "rail-rb43"),
            hasElevator = true,
            hasRamp = true,
            hasTicketMachine = true,
            entranceCount = 3,
            category = "Bahnhof"
        ),
        Station(
            id = "stadthalle",
            name = "Stadthalle / Post",
            location = Location(51.7611, 14.3315),
            lines = listOf("tram-2", "tram-3", "tram-4", "bus-12"),
            hasElevator = false,
            hasRamp = true,
            hasTicketMachine = true,
            entranceCount = 2,
            category = "Haltestelle"
        ),
        Station(
            id = "sandow",
            name = "Bahnhof Cottbus-Sandow",
            location = Location(51.7614, 14.3512),
            lines = listOf("tram-2", "bus-12", "rail-re10", "rail-rb43"),
            hasElevator = true,
            hasRamp = true,
            hasTicketMachine = true,
            entranceCount = 2,
            category = "Bahnhof"
        ),
        Station(
            id = "btu",
            name = "BTU Cottbus-Senftenberg",
            location = Location(51.7675, 14.3265),
            lines = listOf("tram-4", "bus-12"),
            hasElevator = false,
            hasRamp = true,
            hasTicketMachine = false,
            entranceCount = 1,
            category = "Haltestelle"
        ),
        Station(
            id = "klinikum",
            name = "Carl-Thiem-Klinikum",
            location = Location(51.7423, 14.3325),
            lines = listOf("tram-4", "bus-10"),
            hasElevator = true,
            hasRamp = true,
            hasTicketMachine = true,
            entranceCount = 2,
            category = "Haltestelle"
        ),
        Station(
            id = "branitzer-park",
            name = "Branitzer Park",
            location = Location(51.7431, 14.3721),
            lines = listOf("bus-10"),
            hasElevator = false,
            hasRamp = false,
            hasTicketMachine = false,
            entranceCount = 1,
            category = "Haltestelle"
        ),
        Station(
            id = "altmarkt",
            name = "Altmarkt",
            location = Location(51.7602, 14.3341),
            lines = emptyList(), // Walk only
            hasElevator = false,
            hasRamp = true,
            hasTicketMachine = false,
            entranceCount = 1,
            category = "Haltestelle"
        ),
        Station(
            id = "madlow",
            name = "Madlow",
            location = Location(51.7185, 14.3412),
            lines = listOf("tram-3"),
            hasElevator = false,
            hasRamp = true,
            hasTicketMachine = true,
            entranceCount = 1,
            category = "Haltestelle"
        ),
        Station(
            id = "sachsendorf",
            name = "Sachsendorf",
            location = Location(51.7245, 14.3182),
            lines = listOf("tram-4"),
            hasElevator = false,
            hasRamp = true,
            hasTicketMachine = true,
            entranceCount = 1,
            category = "Haltestelle"
        ),
        Station(
            id = "neu-schmellwitz",
            name = "Neu Schmellwitz",
            location = Location(51.7852, 14.3298),
            lines = listOf("tram-4"),
            hasElevator = false,
            hasRamp = true,
            hasTicketMachine = true,
            entranceCount = 1,
            category = "Haltestelle"
        ),
        Station(
            id = "strobitz",
            name = "Ströbitz",
            location = Location(51.7592, 14.3015),
            lines = listOf("tram-3"),
            hasElevator = false,
            hasRamp = true,
            hasTicketMachine = false,
            entranceCount = 1,
            category = "Haltestelle"
        )
    )

    val places = listOf(
        Place("poi-altmarkt", "Altmarkt Cottbus", "Innenstadt", Location(51.7602, 14.3341), "stadthalle", 4),
        Place("poi-schloss-branitz", "Schloss & Park Branitz", "Parks", Location(51.7431, 14.3721), "branitzer-park", 2),
        Place("poi-staatstheater", "Staatstheater Cottbus", "Kultur", Location(51.7584, 14.3256), "stadthalle", 6),
        Place("poi-spreeufer", "Spreeufer Promenade", "Parks", Location(51.7581, 14.3412), "sandow", 7),
        Place("poi-btu-campus", "BTU Hauptcampus", "Universität", Location(51.7675, 14.3265), "btu", 1),
        Place("poi-blechen-carrer", "Blechen-Carré", "Einkaufen", Location(51.7594, 14.3308), "stadthalle", 2),
        Place("poi-ctk", "Sana Herzzentrum / CTK", "Sport", Location(51.7423, 14.3325), "klinikum", 2)
    )

    val baseAlerts = mutableListOf(
        ServiceAlert(
            id = "alert-001",
            lineId = "tram-4",
            status = AlertStatus.VERSPÄTUNG,
            title = "Verzögerungen wegen Gleisarbeiten",
            description = "Wegen dringender Gleisarbeiten im Bereich Neu Schmellwitz kommt es auf der Linie 4 zu Verspätungen von bis zu 10 Minuten.",
            affectedRoute = "Neu Schmellwitz ↔ Sachsendorf",
            start = "02.10.2026",
            expectedDuration = "ca. 2 Wochen",
            updatedAt = "02.10.2026 07:30"
        ),
        ServiceAlert(
            id = "alert-002",
            lineId = "bus-10",
            status = AlertStatus.EINSCHRÄNKUNG,
            title = "Umleitung im Spree-Lausitz-Park",
            description = "Die Buslinie 10 fährt eine Umleitung. Die Haltestelle Tierpark kann temporär nicht bedient werden.",
            affectedRoute = "Cottbus Hbf ↔ Branitzer Park",
            start = "01.10.2026",
            expectedDuration = "bis auf Weiteres",
            updatedAt = "01.10.2026 12:00"
        )
    )

    // Tarifregeln
    val fareRules = listOf(
        FareRule("fare-1", "VBB", "A", "A", "Erwachsener", "Einzelfahrt", "2026-01-01", "2026-12-31", 3.30),
        FareRule("fare-2", "VBB", "A", "A", "Ermäßigt", "Einzelfahrt", "2026-01-01", "2026-12-31", 2.20),
        FareRule("fare-3", "VBB", "A", "A", "Erwachsener", "Tageskarte", "2026-01-01", "2026-12-31", 8.80),
        FareRule("fare-4", "VBB", "A", "A", "Ermäßigt", "Tageskarte", "2026-01-01", "2026-12-31", 5.90),
        FareRule("fare-5", "VBB", "A", "A", "Erwachsener", "Monatskarte", "2026-01-01", "2026-12-31", 64.00)
    )

    // Adjacency graph for transit legs
    // Key: pair of (FromStationId, ToStationId), Value: list of paths with LineId and time in minutes
    data class Connection(val lineId: String, val durationMinutes: Int)

    private val graph: Map<String, List<Pair<String, Connection>>> = mapOf(
        "neu-schmellwitz" to listOf(
            "btu" to Connection("tram-4", 8)
        ),
        "btu" to listOf(
            "neu-schmellwitz" to Connection("tram-4", 8),
            "stadthalle" to Connection("tram-4", 3),
            "sandow" to Connection("bus-12", 5)
        ),
        "stadthalle" to listOf(
            "btu" to Connection("tram-4", 3),
            "cottbus-hbf" to Connection("tram-4", 4),
            "sandow" to Connection("tram-2", 4),
            "strobitz" to Connection("tram-3", 4),
            "madlow" to Connection("tram-3", 8)
        ),
        "strobitz" to listOf(
            "stadthalle" to Connection("tram-3", 4)
        ),
        "madlow" to listOf(
            "stadthalle" to Connection("tram-3", 8)
        ),
        "sandow" to listOf(
            "stadthalle" to Connection("tram-2", 4),
            "btu" to Connection("bus-12", 5),
            "cottbus-hbf" to Connection("rail-re10", 3)
        ),
        "cottbus-hbf" to listOf(
            "stadthalle" to Connection("tram-4", 4),
            "sandow" to Connection("rail-re10", 3),
            "klinikum" to Connection("tram-4", 3)
        ),
        "klinikum" to listOf(
            "cottbus-hbf" to Connection("tram-4", 3),
            "sachsendorf" to Connection("tram-4", 5),
            "branitzer-park" to Connection("bus-10", 8)
        ),
        "sachsendorf" to listOf(
            "klinikum" to Connection("tram-4", 5)
        ),
        "branitzer-park" to listOf(
            "klinikum" to Connection("bus-10", 8)
        )
    )

    /**
     * Highly functional Dijkstra-based transit routing engine.
     * Computes the fastest connection between start and end stations.
     */
    fun planJourney(
        originId: String,
        destinationId: String,
        time: LocalTime = LocalTime.now(),
        onlyAccessible: Boolean = false
    ): List<Journey> {
        if (originId == destinationId) return emptyList()

        // Core Dijkstra algorithm
        val distances = mutableMapOf<String, Int>().withDefault { Int.MAX_VALUE }
        val previous = mutableMapOf<String, Pair<String, Connection>?>()
        val unvisited = mutableSetOf<String>()

        stations.forEach {
            distances[it.id] = Int.MAX_VALUE
            previous[it.id] = null
            unvisited.add(it.id)
        }

        distances[originId] = 0

        while (unvisited.isNotEmpty()) {
            val u = unvisited.minByOrNull { distances.getValue(it) } ?: break
            if (distances[u] == Int.MAX_VALUE) break
            if (u == destinationId) break

            unvisited.remove(u)

            val neighbors = graph[u] ?: emptyList()
            for ((v, conn) in neighbors) {
                if (onlyAccessible) {
                    val destStation = stations.find { it.id == v }
                    if (destStation != null && !destStation.hasRamp && !destStation.hasElevator) {
                        continue // Skip non-accessible
                    }
                }

                val weight = conn.durationMinutes + 1 // Add 1 min penalty for potential wait/stop transition
                val alt = distances.getValue(u) + weight
                if (alt < distances.getValue(v)) {
                    distances[v] = alt
                    previous[v] = Pair(u, conn)
                }
            }
        }

        // Reconstruct path
        val legs = mutableListOf<JourneyLeg>()
        var curr = destinationId
        var currentTime = time

        while (previous[curr] != null) {
            val (prevNode, conn) = previous[curr]!!
            val originStation = stations.find { it.id == prevNode }!!
            val destStation = stations.find { it.id == curr }!!
            val line = lines.find { it.id == conn.lineId }!!

            val legDepTime = currentTime.minusMinutes(conn.durationMinutes.toLong())
            val legArrTime = currentTime

            legs.add(
                0,
                JourneyLeg(
                    mode = line.mode,
                    lineId = line.id,
                    lineName = line.name,
                    lineColor = line.color,
                    originStationId = originStation.id,
                    originStationName = originStation.name,
                    destinationStationId = destStation.id,
                    destinationStationName = destStation.name,
                    departureTime = legDepTime.format(DateTimeFormatter.ofPattern("HH:mm")),
                    arrivalTime = legArrTime.format(DateTimeFormatter.ofPattern("HH:mm")),
                    durationMinutes = conn.durationMinutes
                )
            )

            currentTime = legDepTime
            curr = prevNode
        }

        if (legs.isEmpty()) {
            // Fallback to walk if close
            val startLoc = stations.find { it.id == originId }?.location
            val endLoc = stations.find { it.id == destinationId }?.location
            if (startLoc != null && endLoc != null) {
                val distanceKm = calculateDistance(startLoc.lat, startLoc.lon, endLoc.lat, endLoc.lon)
                val walkMinutes = (distanceKm * 12).roundToInt() // roughly 5km/h
                if (walkMinutes < 30) {
                    val walkLeg = JourneyLeg(
                        mode = TransportMode.WALK,
                        lineId = null,
                        lineName = "Fußweg",
                        lineColor = "#CCCCCC",
                        originStationId = originId,
                        originStationName = stations.find { it.id == originId }!!.name,
                        destinationStationId = destinationId,
                        destinationStationName = stations.find { it.id == destinationId }!!.name,
                        departureTime = time.format(DateTimeFormatter.ofPattern("HH:mm")),
                        arrivalTime = time.plusMinutes(walkMinutes.toLong()).format(DateTimeFormatter.ofPattern("HH:mm")),
                        durationMinutes = walkMinutes
                    )
                    return listOf(
                        Journey(
                            id = "journey-walk",
                            legs = listOf(walkLeg),
                            totalDurationMinutes = walkMinutes,
                            price = 0.0,
                            accessibilityScore = 2,
                            transfersCount = 0
                        )
                    )
                }
            }
            return emptyList()
        }

        // Calculate total stats
        val totalMinutes = legs.sumOf { it.durationMinutes }
        val transfers = if (legs.size > 1) legs.size - 1 else 0
        val basePrice = if (transfers == 0) 2.20 else 3.30

        return listOf(
            Journey(
                id = "journey-${originId}-${destinationId}",
                legs = legs,
                totalDurationMinutes = totalMinutes,
                price = basePrice,
                accessibilityScore = if (onlyAccessible) 2 else 1,
                transfersCount = transfers
            )
        )
    }

    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0 // Earth's radius in km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    /**
     * Get Departures/Arrivals Monitor.
     * Incorporates real-time / simulator delay data.
     */
    fun getDepartures(stationId: String, currentSimulationTime: LocalTime): List<Arrival> {
        val station = stations.find { it.id == stationId } ?: return emptyList()
        val departures = mutableListOf<Arrival>()

        lines.forEach { line ->
            if (line.id in station.lines) {
                // Add 2 typical departures for this line from this station
                val direction1 = "Sachsendorf"
                val direction2 = "Neu Schmellwitz"
                val finalDir = if (line.id == "tram-4") direction1 else "Endhaltestelle"

                // We generate static schedule minutes
                val mins1 = (currentSimulationTime.minute % 15 + 4)
                val mins2 = (currentSimulationTime.minute % 15 + 14)

                // Simulated live status
                val isLive = (currentSimulationTime.minute % 2 == 0)
                val source = if (isLive) "realtime" else "scheduled"
                val delay = if (isLive && currentSimulationTime.minute % 4 == 0) 3 else 0

                departures.add(
                    Arrival(
                        lineId = line.id,
                        direction = finalDir,
                        minutes = mins1,
                        source = source,
                        updatedAt = LocalTime.now().toString(),
                        delayMinutes = delay
                    )
                )

                departures.add(
                    Arrival(
                        lineId = line.id,
                        direction = if (line.id == "tram-4") direction2 else "Hauptbahnhof",
                        minutes = mins2,
                        source = source,
                        updatedAt = LocalTime.now().toString(),
                        delayMinutes = 0
                    )
                )
            }
        }

        return departures.sortedBy { it.minutes }
    }
}
