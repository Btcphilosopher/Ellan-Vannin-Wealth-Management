package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.CottbusDataProvider
import com.example.data.db.CottbusDatabase
import com.example.data.db.SavedPlaceEntity
import com.example.data.db.TicketEntity
import com.example.data.db.FavoriteLineEntity
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalTime
import java.time.format.DateTimeFormatter

sealed class Screen {
    object Home : Screen()
    object Search : Screen()
    data class StationDetail(val stationId: String) : Screen()
    data class LineDetail(val lineId: String) : Screen()
    object RoutePlanner : Screen()
    data class JourneyDetail(val journey: Journey) : Screen()
    data class ActiveTrip(val journey: Journey) : Screen()
    object ServiceAlerts : Screen()
    object MapNetzplan : Screen()
    object Tickets : Screen()
}

class CottbusViewModel(context: Context) : ViewModel() {

    private val db = Room.databaseBuilder(
        context.applicationContext,
        CottbusDatabase::class.java, "cottbus-mobil-db"
    ).allowMainThreadQueries().build() // Allowed for simplicity in demo applet

    private val dao = db.dao()

    // Navigation and screen stack
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenStack = mutableListOf<Screen>()

    // Core application states
    private val _stations = MutableStateFlow<List<Station>>(CottbusDataProvider.stations)
    val stations = _stations.asStateFlow()

    private val _lines = MutableStateFlow<List<TransitLine>>(CottbusDataProvider.lines)
    val lines = _lines.asStateFlow()

    private val _savedPlaces = MutableStateFlow<List<SavedPlace>>(emptyList())
    val savedPlaces = _savedPlaces.asStateFlow()

    private val _tickets = MutableStateFlow<List<Ticket>>(emptyList())
    val tickets = _tickets.asStateFlow()

    private val _favoriteLines = MutableStateFlow<Set<String>>(emptySet())
    val favoriteLines = _favoriteLines.asStateFlow()

    // Service Alerts list
    private val _alerts = MutableStateFlow<List<ServiceAlert>>(CottbusDataProvider.baseAlerts)
    val alerts = _alerts.asStateFlow()

    // Simulator Time
    private val _currentTime = MutableStateFlow<LocalTime>(LocalTime.of(7, 40))
    val currentTime = _currentTime.asStateFlow()

    // Active Journey settings
    val selectedOrigin = MutableStateFlow<Station?>(null)
    val selectedDestination = MutableStateFlow<Station?>(null)
    val onlyAccessibleRoute = MutableStateFlow(false)
    val searchResults = MutableStateFlow<List<Journey>>(emptyList())

    // Active tracking warning stops count
    val exitWarningStops = MutableStateFlow(2) // Default 2 stops before
    val exitWarningTriggered = MutableStateFlow(false)

    // Current interactive map selection
    val selectedMapStation = MutableStateFlow<Station?>(null)

    init {
        loadFromDb()
        startClockSimulator()
    }

    fun navigateTo(screen: Screen) {
        screenStack.add(_currentScreen.value)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (screenStack.isNotEmpty()) {
            _currentScreen.value = screenStack.removeAt(screenStack.size - 1)
            return true
        }
        return false
    }

    private fun loadFromDb() {
        viewModelScope.launch(Dispatchers.IO) {
            val dbPlaces = dao.getAllSavedPlaces().map {
                SavedPlace(it.id, it.label, it.customName, it.stationId)
            }
            _savedPlaces.value = dbPlaces

            val dbTickets = dao.getAllTickets().map {
                Ticket(it.id, it.title, it.price, it.type, it.passengerType, it.isValid, it.purchasedAt, it.isDemo)
            }
            _tickets.value = dbTickets

            val dbFavs = dao.getAllFavoriteLines().filter { it.isFavorite }.map { it.id }.toSet()
            _favoriteLines.value = dbFavs

            // Add basic defaults if empty
            if (dbPlaces.isEmpty()) {
                dao.insertSavedPlace(SavedPlaceEntity("p-home", "Zuhause", "Spremberger Str. 12", "stadthalle"))
                dao.insertSavedPlace(SavedPlaceEntity("p-uni", "Universität", "BTU Hauptcampus", "btu"))
                val updated = dao.getAllSavedPlaces().map {
                    SavedPlace(it.id, it.label, it.customName, it.stationId)
                }
                _savedPlaces.value = updated
            }
        }
    }

    private fun startClockSimulator() {
        viewModelScope.launch {
            while (true) {
                delay(3000) // 3 seconds real-time is 1 minute in simulator
                _currentTime.value = _currentTime.value.plusMinutes(1)
            }
        }
    }

    fun toggleLineFavorite(lineId: String) {
        val current = _favoriteLines.value.toMutableSet()
        val isFav = if (current.contains(lineId)) {
            current.remove(lineId)
            false
        } else {
            current.add(lineId)
            true
        }
        _favoriteLines.value = current
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertFavoriteLine(FavoriteLineEntity(lineId, lineId, isFav))
        }
    }

    fun addSavedPlace(label: String, name: String, stationId: String) {
        val entity = SavedPlaceEntity("p-${System.currentTimeMillis()}", label, name, stationId)
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertSavedPlace(entity)
            loadFromDb()
        }
    }

    fun deleteSavedPlace(savedPlace: SavedPlace) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteSavedPlace(SavedPlaceEntity(savedPlace.id, savedPlace.label, savedPlace.customName, savedPlace.stationId))
            loadFromDb()
        }
    }

    fun buyDemoTicket(ticketType: String, passengerType: String, price: Double) {
        val timeStr = _currentTime.value.format(DateTimeFormatter.ofPattern("HH:mm"))
        val entity = TicketEntity(
            id = "ticket-${System.currentTimeMillis()}",
            title = "$ticketType Cottbus A",
            price = price,
            type = ticketType,
            passengerType = passengerType,
            isValid = true,
            purchasedAt = "Heute, $timeStr"
        )
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertTicket(entity)
            loadFromDb()
        }
    }

    fun executeRouteSearch() {
        val orig = selectedOrigin.value?.id ?: return
        val dest = selectedDestination.value?.id ?: return
        searchResults.value = CottbusDataProvider.planJourney(
            originId = orig,
            destinationId = dest,
            time = _currentTime.value,
            onlyAccessible = onlyAccessibleRoute.value
        )
    }

    fun getDeparturesForStation(stationId: String): List<Arrival> {
        return CottbusDataProvider.getDepartures(stationId, _currentTime.value)
    }
}
