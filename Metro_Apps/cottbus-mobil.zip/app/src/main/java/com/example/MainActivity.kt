package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.CottbusViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Initialize ViewModel
                val context = this
                val viewModel = CottbusViewModel(context)

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    CottbusMobilApp(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun CottbusMobilApp(
    viewModel: CottbusViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    when (val screen = currentScreen) {
        is Screen.Home -> HomeScreenView(viewModel = viewModel, modifier = modifier)
        is Screen.Search -> SearchScreenView(viewModel = viewModel, modifier = modifier)
        is Screen.StationDetail -> StationDetailView(viewModel = viewModel, stationId = screen.stationId, modifier = modifier)
        is Screen.RoutePlanner -> RoutePlannerView(viewModel = viewModel, modifier = modifier)
        is Screen.JourneyDetail -> JourneyDetailView(viewModel = viewModel, journey = screen.journey, modifier = modifier)
        is Screen.ActiveTrip -> ActiveTripView(viewModel = viewModel, journey = screen.journey, modifier = modifier)
        is Screen.ServiceAlerts -> ServiceAlertsView(viewModel = viewModel, modifier = modifier)
        is Screen.MapNetzplan -> MapNetzplanView(viewModel = viewModel, modifier = modifier)
        is Screen.Tickets -> TicketsView(viewModel = viewModel, modifier = modifier)
        else -> HomeScreenView(viewModel = viewModel, modifier = modifier)
    }
}
