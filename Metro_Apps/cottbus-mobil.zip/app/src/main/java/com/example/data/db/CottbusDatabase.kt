package com.example.data.db

import androidx.room.*

@Entity(tableName = "saved_places")
data class SavedPlaceEntity(
    @PrimaryKey val id: String,
    val label: String, // "Zuhause", "Arbeit", "Universität", "Familie"
    val customName: String?,
    val stationId: String
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val title: String,
    val price: Double,
    val type: String, // "Einzelfahrt", "Tageskarte", "Monatskarte"
    val passengerType: String, // "Erwachsener", "Ermäßigt"
    val isValid: Boolean,
    val purchasedAt: String,
    val isDemo: Boolean = true
)

@Entity(tableName = "favorite_lines")
data class FavoriteLineEntity(
    @PrimaryKey val id: String,
    val name: String,
    val isFavorite: Boolean
)

@Dao
interface CottbusDao {
    @Query("SELECT * FROM saved_places")
    fun getAllSavedPlaces(): List<SavedPlaceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertSavedPlace(place: SavedPlaceEntity)

    @Delete
    fun deleteSavedPlace(place: SavedPlaceEntity)

    @Query("SELECT * FROM tickets ORDER BY purchasedAt DESC")
    fun getAllTickets(): List<TicketEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertTicket(ticket: TicketEntity)

    @Query("SELECT * FROM favorite_lines")
    fun getAllFavoriteLines(): List<FavoriteLineEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertFavoriteLine(line: FavoriteLineEntity)
}

@Database(entities = [SavedPlaceEntity::class, TicketEntity::class, FavoriteLineEntity::class], version = 1, exportSchema = false)
abstract class CottbusDatabase : RoomDatabase() {
    abstract fun dao(): CottbusDao
}
