package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.data.TransitRepository
import com.example.model.TransportLine
import com.example.localization.stringResource
import com.example.ui.theme.*

@Composable
fun LinjerScreen(navController: NavController) {
    val repository = remember { TransitRepository() }
    val lines = remember { repository.allLines }
    val disruptions by repository.disruptions.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        item {
            Text(
                text = stringResource("TRAFIKSTÖRNINGAR", "DISRUPTIONS"),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(bottom = 16.dp, top = 8.dp)
            )
        }

        if (disruptions.isEmpty()) {
            item {
                Text(
                    text = stringResource("Inga kända störningar", "No known disruptions"),
                    style = MaterialTheme.typography.bodyLarge,
                    color = StatusGreen
                )
            }
        } else {
            items(disruptions) { disruption ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = stringResource(disruption.headerSv, disruption.headerEn),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = StatusOrange
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(disruption.descriptionSv, disruption.descriptionEn),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = stringResource("LINJER", "LINES"),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }

        items(lines) { line ->
            LineRow(line)
        }
    }
}

@Composable
fun LineRow(line: TransportLine) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(8.dp)
                .height(32.dp)
                .background(line.color, shape = RoundedCornerShape(4.dp))
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = stringResource(line.nameSv, line.nameEn),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}
