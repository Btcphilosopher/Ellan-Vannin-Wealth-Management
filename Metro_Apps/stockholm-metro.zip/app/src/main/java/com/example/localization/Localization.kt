package com.example.localization

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class Language {
    SVENSKA,
    ENGLISH
}

class LocalizationState(initialLanguage: Language = Language.SVENSKA) {
    var currentLanguage by mutableStateOf(initialLanguage)

    fun getString(sv: String, en: String): String {
        return if (currentLanguage == Language.SVENSKA) sv else en
    }
}

val LocalLocalization = compositionLocalOf { LocalizationState() }

@Composable
fun ProvideLocalization(
    localizationState: LocalizationState,
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalLocalization provides localizationState) {
        content()
    }
}

@Composable
fun stringResource(sv: String, en: String): String {
    return LocalLocalization.current.getString(sv, en)
}
