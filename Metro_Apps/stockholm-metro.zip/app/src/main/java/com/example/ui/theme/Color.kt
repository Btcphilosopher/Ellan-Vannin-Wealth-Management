package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nordic Palette
val NordicWhite = Color(0xFFF9FAFB)
val NordicWhiteDark = Color(0xFFF1F3F5)
val Graphite = Color(0xFF2C313C)
val GraphiteLight = Color(0xFF3F4652)
val Charcoal = Color(0xFF16181D)
val CoolGrey = Color(0xFF8A93A6)
val CoolGreyLight = Color(0xFFE5E7EB)

// Stockholm Blues
val StockholmBlue = Color(0xFF0079C1)
val MutedSkyBlue = Color(0xFF6B9AC4)
val PaleIceBlue = Color(0xFFE0EAF5)

// Transit Colors
val GreenLineColor = Color(0xFF5DB85C)
val RedLineColor = Color(0xFFE44C3D)
val BlueLineColor = Color(0xFF2C82C9)
val CommuterRailColor = Color(0xFFE67E22) // Pendeltåg
val BusColor = Color(0xFFD91A2A)
val TramColor = Color(0xFF7F8C8D) // Spårvagn
val FerryColor = Color(0xFF16A085) 

// Status Colors
val StatusGreen = Color(0xFF2ECC71)
val StatusYellow = Color(0xFFF1C40F)
val StatusOrange = Color(0xFFE67E22)
val StatusRed = Color(0xFFE74C3C)
val StatusBlue = Color(0xFF3498DB)
