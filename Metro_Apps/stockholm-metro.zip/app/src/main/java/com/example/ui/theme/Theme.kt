package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = StockholmBlue,
    onPrimary = NordicWhite,
    secondary = MutedSkyBlue,
    onSecondary = Charcoal,
    tertiary = PaleIceBlue,
    background = Charcoal,
    surface = Graphite,
    onBackground = NordicWhite,
    onSurface = NordicWhite,
    surfaceVariant = GraphiteLight,
    onSurfaceVariant = CoolGreyLight,
    outline = CoolGrey
  )

private val LightColorScheme =
  lightColorScheme(
    primary = StockholmBlue,
    onPrimary = NordicWhite,
    secondary = MutedSkyBlue,
    onSecondary = Charcoal,
    tertiary = PaleIceBlue,
    background = NordicWhite,
    surface = NordicWhiteDark,
    onBackground = Charcoal,
    onSurface = Charcoal,
    surfaceVariant = PaleIceBlue,
    onSurfaceVariant = Graphite,
    outline = CoolGreyLight
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color disabled to enforce Stockholm Metro brand
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

