package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.localization.stringResource
import com.example.ui.theme.*

enum class BottomNavItem(
    val route: String,
    val icon: ImageVector,
    val titleSv: String,
    val titleEn: String
) {
    RESA("resa", Icons.Filled.Search, "Resa", "Journey"),
    KARTA("karta", Icons.Filled.Map, "Karta", "Map"),
    AVGANGAR("avgangar", Icons.Filled.DirectionsTransit, "Avgångar", "Departures"),
    LINJER("linjer", Icons.AutoMirrored.Filled.List, "Linjer", "Lines"),
    MER("mer", Icons.Filled.MoreHoriz, "Mer", "More")
}

@Composable
fun MainScreen(navController: NavHostController = rememberNavController()) {
    Scaffold(
        bottomBar = {
            BottomNavigationBar(navController = navController)
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = BottomNavItem.RESA.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(BottomNavItem.RESA.route) { ResaScreen(navController) }
            composable(BottomNavItem.KARTA.route) { KartaScreen(navController) }
            composable(BottomNavItem.AVGANGAR.route) { AvgangarScreen(navController) }
            composable(BottomNavItem.LINJER.route) { LinjerScreen(navController) }
            composable(BottomNavItem.MER.route) { MerScreen(navController) }
            composable("art") { ArtScreen(navController) }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavHostController) {
    val items = BottomNavItem.values()
    val currentRoute = currentRoute(navController)

    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        items.forEach { item ->
            val label = stringResource(item.titleSv, item.titleEn)
            NavigationBarItem(
                icon = { Icon(item.icon, contentDescription = label) },
                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                selected = currentRoute == item.route,
                onClick = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        }
    }
}

@Composable
fun currentRoute(navController: NavHostController): String? {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    return navBackStackEntry?.destination?.route
}
