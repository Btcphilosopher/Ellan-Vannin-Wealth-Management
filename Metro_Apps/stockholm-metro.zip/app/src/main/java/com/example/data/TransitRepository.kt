package com.example.data

import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TransitRepository {
    // Simulated Lines
    val greenLine = TransportLine("1", "Gröna linjen", "Green Line", TransportMode.METRO, GreenLineColor)
    val redLine = TransportLine("2", "Röda linjen", "Red Line", TransportMode.METRO, RedLineColor)
    val blueLine = TransportLine("3", "Blå linjen", "Blue Line", TransportMode.METRO, BlueLineColor)
    val commuterRail = TransportLine("4", "Pendeltåg", "Commuter Rail", TransportMode.COMMUTER_RAIL, CommuterRailColor)
    val busLine = TransportLine("5", "Buss", "Bus", TransportMode.BUS, BusColor)
    val tramLine = TransportLine("6", "Spårvagn", "Tram", TransportMode.TRAM, TramColor)
    val ferryLine = TransportLine("7", "Färja", "Ferry", TransportMode.FERRY, FerryColor)

    val allLines = listOf(greenLine, redLine, blueLine, commuterRail, busLine, tramLine, ferryLine)

    // Simulated Stations
    val tCentralen = Station("t_centralen", "T-Centralen", listOf(greenLine, redLine, blueLine, commuterRail), hasArt = true)
    val slussen = Station("slussen", "Slussen", listOf(greenLine, redLine, busLine))
    val gamlaStan = Station("gamla_stan", "Gamla Stan", listOf(greenLine, redLine))
    val gullmarsplan = Station("gullmarsplan", "Gullmarsplan", listOf(greenLine, tramLine, busLine))
    val alvik = Station("alvik", "Alvik", listOf(greenLine, tramLine))
    val odenplan = Station("odenplan", "Odenplan", listOf(greenLine, commuterRail), hasArt = true)
    val kungstradgarden = Station("kungstradgarden", "Kungsträdgården", listOf(blueLine), hasArt = true)
    
    val allStations = listOf(tCentralen, slussen, gamlaStan, gullmarsplan, alvik, odenplan, kungstradgarden)

    private val _disruptions = MutableStateFlow<List<Disruption>>(emptyList())
    val disruptions: StateFlow<List<Disruption>> = _disruptions.asStateFlow()

    init {
        // Initial simulated disruptions
        _disruptions.value = listOf(
            Disruption(
                id = "d1",
                severity = DisruptionSeverity.MINOR,
                lines = listOf(redLine),
                headerSv = "Förseningar mellan Slussen och T-Centralen",
                headerEn = "Delays between Slussen and T-Centralen",
                descriptionSv = "Vagnfel orsakar oregelbunden trafik.",
                descriptionEn = "Train fault is causing irregular service.",
                updatedAt = "19:42"
            )
        )
    }

    fun getDeparturesForStation(stationId: String): List<Departure> {
        // Simulate departures based on station
        val station = allStations.find { it.id == stationId } ?: return emptyList()
        val departures = mutableListOf<Departure>()
        
        station.lines.forEach { line ->
            when (line.id) {
                "1" -> {
                    departures.add(Departure("d1", station.id, line, "Hässelby strand", 2, "1"))
                    departures.add(Departure("d2", station.id, line, "Alvik", 6, "1"))
                    departures.add(Departure("d3", station.id, line, "Skarpnäck", 9, "2"))
                }
                "2" -> {
                    departures.add(Departure("d4", station.id, line, "Mörby centrum", 3, "3"))
                    departures.add(Departure("d5", station.id, line, "Ropsten", 7, "3"))
                }
                "3" -> {
                    departures.add(Departure("d6", station.id, line, "Akalla", 5, "5"))
                }
            }
        }
        return departures.sortedBy { it.expectedTimeMinutes }
    }

    fun getStationArt(stationId: String): StationArt? {
        return when (stationId) {
            "t_centralen" -> StationArt(
                stationId = "t_centralen",
                artist = "Per Olov Ultvedt",
                titleSv = "Blåa mönster och silhuetter",
                titleEn = "Blue patterns and silhouettes",
                year = "1975",
                descriptionSv = "Ett av de mest kända verken i Stockholms tunnelbana med blå silhuetter av de arbetare som byggde stationen.",
                descriptionEn = "One of the most famous works in the Stockholm metro featuring blue silhouettes of the workers who built the station."
            )
            "kungstradgarden" -> StationArt(
                stationId = "kungstradgarden",
                artist = "Ulrik Samuelson",
                titleSv = "Underjordisk trädgård",
                titleEn = "Underground Garden",
                year = "1977",
                descriptionSv = "Stationen är utformad som en underjordisk trädgård och berättar historien om den gamla barockträdgården som låg ovan jord.",
                descriptionEn = "The station is designed as an underground garden and tells the story of the old baroque garden that was located above ground."
            )
            else -> null
        }
    }
}
