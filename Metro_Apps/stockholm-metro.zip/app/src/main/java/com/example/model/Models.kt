package com.example.model

import androidx.compose.ui.graphics.Color

enum class TransportMode {
    METRO, COMMUTER_RAIL, BUS, TRAM, FERRY, WALKING, BICYCLE
}

data class TransportLine(
    val id: String,
    val nameSv: String,
    val nameEn: String,
    val mode: TransportMode,
    val color: Color
)

data class Station(
    val id: String,
    val name: String,
    val lines: List<TransportLine>,
    val hasArt: Boolean = false,
    val lat: Double = 0.0,
    val lon: Double = 0.0
)

enum class DisruptionSeverity {
    PLANNED, MINOR, MAJOR, RESOLVED
}

data class Disruption(
    val id: String,
    val severity: DisruptionSeverity,
    val lines: List<TransportLine>,
    val headerSv: String,
    val headerEn: String,
    val descriptionSv: String,
    val descriptionEn: String,
    val updatedAt: String
)

data class Departure(
    val id: String,
    val stationId: String,
    val line: TransportLine,
    val destination: String,
    val expectedTimeMinutes: Int, // e.g., 2 for "2 min"
    val platform: String? = null,
    val isRealtime: Boolean = true
)

data class StationArt(
    val stationId: String,
    val artist: String,
    val titleSv: String,
    val titleEn: String,
    val year: String,
    val descriptionSv: String,
    val descriptionEn: String,
    val imageUrl: String? = null
)
