package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.remember
import com.example.localization.LocalizationState
import com.example.localization.ProvideLocalization
import com.example.ui.screens.MainScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val localizationState = remember { LocalizationState() }
      MyApplicationTheme { 
          ProvideLocalization(localizationState = localizationState) {
              MainScreen() 
          }
      }
    }
  }
}
