package com.example.data.model

import java.util.UUID

enum class OrderState {
    DRAFT,
    LOCKED,
    PAYMENT_PENDING,
    PAID,
    ISSUED,
    PENDING_ISSUANCE,
    CANCELLED
}

enum class PaymentReaderState {
    READY_TO_TAP,
    READING,
    PROCESSING,
    APPROVED,
    DECLINED,
    TIMED_OUT,
    CANCELLED,
    CONNECTION_INTERRUPTED,
    PAYMENT_STATUS_UNKNOWN
}

enum class PaymentDeclineReason(val displayMessage: String) {
    INSUFFICIENT_FUNDS("Card declined: Insufficient funds. Please try another card."),
    CHIP_ERROR("Card read error. Please hold firmly against the glass reader area."),
    PIN_REQUIRED("Card issuer requested PIN entry. Please use a contactless mobile wallet or another card."),
    COMMUNICATION_TIMEOUT("Bank host communication timed out. No charge was applied."),
    INTERRUPTED("Terminal connection interrupted during secure handshake.")
}

data class PaymentAttempt(
    val attemptId: String = "ATT-" + UUID.randomUUID().toString().take(8).uppercase(),
    val orderId: String,
    val idempotencyKey: String,
    val amountPence: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val readerState: PaymentReaderState,
    val maskedPan: String = "•••• 4092",
    val paymentBrand: String = "Contactless Visa / Apple Pay",
    val authCode: String? = null,
    val declineReason: PaymentDeclineReason? = null
)

data class IssuedTicket(
    val ticketNumber: String,
    val orderId: String,
    val qrPayload: String,
    val originName: String,
    val destinationName: String,
    val zonesDescription: String,
    val ticketTypeName: String,
    val passengerSummary: String,
    val totalPaidPence: Int,
    val issuedAtTimestamp: Long,
    val validUntilTimestamp: Long,
    val authCode: String,
    val isDemoWatermark: Boolean = true
) {
    fun formattedTotalPaid(): String = TicketProduct.formatPence(totalPaidPence)
}

data class TicketOrder(
    val orderId: String = "MLG-" + (1000..9999).random() + "-" + (100..999).random(),
    val origin: MetrolinkStation,
    val destination: MetrolinkStation,
    val ticketType: TicketType,
    val passengerCounts: Map<PassengerCategory, Int>,
    val totalPence: Int,
    val idempotencyKey: String = "IDEM-" + UUID.randomUUID().toString(),
    val state: OrderState = OrderState.DRAFT,
    val paymentAttempt: PaymentAttempt? = null,
    val issuedTicket: IssuedTicket? = null,
    val pendingIssuanceRef: String? = null
) {
    fun totalPassengers(): Int = passengerCounts.values.sum()
    fun formattedTotal(): String = TicketProduct.formatPence(totalPence)

    fun passengerBreakdownString(): String {
        val parts = mutableListOf<String>()
        val adults = passengerCounts[PassengerCategory.ADULT] ?: 0
        val children = passengerCounts[PassengerCategory.CHILD] ?: 0
        val concessions = passengerCounts[PassengerCategory.CONCESSION] ?: 0
        if (adults > 0) parts.add("$adults Adult${if (adults > 1) "s" else ""}")
        if (children > 0) parts.add("$children Child${if (children > 1) "ren" else ""}")
        if (concessions > 0) parts.add("$concessions Concession${if (concessions > 1) "s" else ""}")
        return if (parts.isEmpty()) "1 Adult" else parts.joinToString(", ")
    }
}

data class KioskDiagnostics(
    val shelterId: String = "STP-02 (St Peter's Square North)",
    val kioskIp: String = "10.44.18.22",
    val readerHardwareStatus: String = "ONLINE (NFC-EMV Glass Sensor v4.2)",
    val printerStatus: String = "READY (Thermal roll 88% remaining)",
    val networkLatencyMs: Int = 18,
    val offlineModeActive: Boolean = false,
    val cachedFareTablesVersion: String = "2026.11.02-METRO-PROD",
    val successfulTransactionsCount: Int = 142,
    val lastSyncTime: String = "Just now"
)
