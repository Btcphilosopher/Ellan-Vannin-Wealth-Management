package com.example.data.model

data class TramDeparture(
    val id: String,
    val line: MetrolinkLine,
    val destination: String,
    val platform: String,
    val minutesDue: Int, // 0 = "Due"
    val isDoubleTram: Boolean = true,
    val status: String = "On time",
    val departuresFromStation: String = "St Peter's Square"
) {
    fun displayMinutes(): String = if (minutesDue <= 0) "Due" else "${minutesDue}m"
}

data class JourneyStep(
    val instruction: String,
    val line: MetrolinkLine?,
    val stopsCount: Int,
    val intermediateStops: List<String>
)

data class JourneyPlanResult(
    val origin: MetrolinkStation,
    val destination: MetrolinkStation,
    val estimatedMinutes: Int,
    val interchangeStation: MetrolinkStation?,
    val steps: List<JourneyStep>,
    val zonesCrossed: Set<Int>,
    val recommendedTicketType: TicketType,
    val sampleAdultFare: String,
    val stepFreeAccessibility: String = "100% Step-free platform to tram boarding"
)

data class ServiceDisruption(
    val id: String,
    val line: MetrolinkLine?,
    val severity: DisruptionSeverity,
    val title: String,
    val message: String,
    val updatedAt: String
)

enum class DisruptionSeverity {
    GOOD_SERVICE,
    MINOR_DELAYS,
    SERVICE_SUSPENDED
}
