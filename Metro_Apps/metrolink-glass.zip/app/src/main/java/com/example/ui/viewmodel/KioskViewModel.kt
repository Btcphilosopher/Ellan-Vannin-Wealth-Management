package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.MetrolinkRepository
import com.example.data.repository.SimulatedPaymentReaderAdapter
import com.example.data.repository.SimulatedTicketIssuanceService
import com.example.data.repository.TicketIssuanceException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class KioskScreen {
    MAIN,
    BUY_TICKETS,
    REVIEW_ORDER,
    PAYMENT,
    TICKET_SUCCESS,
    PENDING_ISSUANCE,
    DEPARTURES,
    JOURNEY_PLANNER,
    HELP,
    DIAGNOSTICS
}

data class KioskUiState(
    val currentScreen: KioskScreen = KioskScreen.MAIN,
    val currentStation: MetrolinkStation,
    val selectedDestination: MetrolinkStation,
    val selectedTicketType: TicketType = TicketType.DAY_TRAVELCARD_OFF_PEAK,
    val passengerCounts: Map<PassengerCategory, Int> = mapOf(
        PassengerCategory.ADULT to 1,
        PassengerCategory.CHILD to 0,
        PassengerCategory.CONCESSION to 0
    ),
    val totalPence: Int = 0,
    val currentOrder: TicketOrder? = null,
    val paymentReaderState: PaymentReaderState = PaymentReaderState.READY_TO_TAP,
    val currentPaymentAttempt: PaymentAttempt? = null,
    val issuedTicket: IssuedTicket? = null,
    val pendingIssuanceRef: String? = null,
    val isPrinting: Boolean = false,
    val printedSuccessfully: Boolean = false,

    // Departures & Journey Planning
    val departures: List<TramDeparture> = emptyList(),
    val journeyPlan: JourneyPlanResult? = null,
    val serviceDisruptions: List<ServiceDisruption> = emptyList(),
    val activeDisruption: ServiceDisruption? = null,

    // Accessibility & UI Modes
    val highContrastMode: Boolean = false,
    val shelterBackgroundMode: String = "glass_dusk", // "glass_dusk", "glass_day", "opaque_dark"
    val seatedUserReachableMode: Boolean = false,
    val reducedMotion: Boolean = false,
    val largeText: Boolean = false,

    // Modals
    val isStationSearchOpen: Boolean = false,
    val isSelectingDestination: Boolean = true, // false = origin, true = destination
    val stationSearchQuery: String = "",

    // Telemetry & Inactivity
    val currentTimeString: String = "",
    val sessionSecondsRemaining: Int = 60,
    val showSessionWarning: Boolean = false,
    val diagnostics: KioskDiagnostics = KioskDiagnostics()
)

class KioskViewModel(
    val repository: MetrolinkRepository = MetrolinkRepository(),
    val paymentReader: SimulatedPaymentReaderAdapter = SimulatedPaymentReaderAdapter(),
    val ticketService: SimulatedTicketIssuanceService = SimulatedTicketIssuanceService()
) : ViewModel() {

    private val _uiState: MutableStateFlow<KioskUiState>

    init {
        val origin = repository.defaultStation
        val destination = repository.stations.first { it.id == "mediacityuk" }
        val initialTotal = repository.calculateTotalPence(
            origin,
            destination,
            TicketType.DAY_TRAVELCARD_OFF_PEAK,
            mapOf(PassengerCategory.ADULT to 1)
        )

        _uiState = MutableStateFlow(
            KioskUiState(
                currentStation = origin,
                selectedDestination = destination,
                totalPence = initialTotal,
                departures = repository.getLiveDepartures(origin),
                serviceDisruptions = repository.getServiceDisruptions(),
                activeDisruption = repository.getServiceDisruptions().firstOrNull { it.severity != DisruptionSeverity.GOOD_SERVICE },
                journeyPlan = repository.planJourney(origin, destination)
            )
        )

        startClockAndSessionTimer()
    }

    val uiState: StateFlow<KioskUiState> = _uiState.asStateFlow()

    private var sessionTimerJob: Job? = null

    private fun startClockAndSessionTimer() {
        sessionTimerJob?.cancel()
        sessionTimerJob = viewModelScope.launch {
            val timeFormat = SimpleDateFormat("HH:mm:ss • EEE d MMM", Locale.UK)
            while (true) {
                val nowStr = timeFormat.format(Date())
                _uiState.update { state ->
                    val nextSecs = state.sessionSecondsRemaining - 1
                    if (nextSecs <= 0 && state.currentScreen != KioskScreen.MAIN) {
                        // Inactivity reset for passenger privacy and kiosk readiness
                        resetSessionToMain()
                        state.copy(
                            currentTimeString = nowStr,
                            sessionSecondsRemaining = 60,
                            showSessionWarning = false
                        )
                    } else {
                        state.copy(
                            currentTimeString = nowStr,
                            sessionSecondsRemaining = nextSecs.coerceAtLeast(0),
                            showSessionWarning = nextSecs in 1..15 && state.currentScreen != KioskScreen.MAIN
                        )
                    }
                }
                delay(1000)
            }
        }
    }

    fun onUserActivity() {
        _uiState.update { it.copy(sessionSecondsRemaining = 60, showSessionWarning = false) }
    }

    fun extendSession() {
        _uiState.update { it.copy(sessionSecondsRemaining = 90, showSessionWarning = false) }
    }

    fun navigateTo(screen: KioskScreen) {
        onUserActivity()
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun resetSessionToMain() {
        paymentReader.reset()
        val origin = repository.defaultStation
        val destination = repository.stations.first { it.id == "mediacityuk" }
        val total = repository.calculateTotalPence(
            origin,
            destination,
            TicketType.DAY_TRAVELCARD_OFF_PEAK,
            mapOf(PassengerCategory.ADULT to 1)
        )
        _uiState.update {
            it.copy(
                currentScreen = KioskScreen.MAIN,
                selectedDestination = destination,
                selectedTicketType = TicketType.DAY_TRAVELCARD_OFF_PEAK,
                passengerCounts = mapOf(
                    PassengerCategory.ADULT to 1,
                    PassengerCategory.CHILD to 0,
                    PassengerCategory.CONCESSION to 0
                ),
                totalPence = total,
                currentOrder = null,
                currentPaymentAttempt = null,
                paymentReaderState = PaymentReaderState.READY_TO_TAP,
                issuedTicket = null,
                pendingIssuanceRef = null,
                isPrinting = false,
                printedSuccessfully = false,
                isStationSearchOpen = false,
                sessionSecondsRemaining = 60,
                showSessionWarning = false
            )
        }
    }

    // --- Ticket Selection & Calculation ---

    fun setTicketType(type: TicketType) {
        onUserActivity()
        _uiState.update { state ->
            val newTotal = repository.calculateTotalPence(
                state.currentStation,
                state.selectedDestination,
                type,
                state.passengerCounts
            )
            state.copy(selectedTicketType = type, totalPence = newTotal)
        }
    }

    fun setDestination(station: MetrolinkStation) {
        onUserActivity()
        _uiState.update { state ->
            val newTotal = repository.calculateTotalPence(
                state.currentStation,
                station,
                state.selectedTicketType,
                state.passengerCounts
            )
            val newPlan = repository.planJourney(state.currentStation, station)
            state.copy(
                selectedDestination = station,
                totalPence = newTotal,
                journeyPlan = newPlan,
                isStationSearchOpen = false,
                stationSearchQuery = ""
            )
        }
    }

    fun setOrigin(station: MetrolinkStation) {
        onUserActivity()
        _uiState.update { state ->
            val newTotal = repository.calculateTotalPence(
                station,
                state.selectedDestination,
                state.selectedTicketType,
                state.passengerCounts
            )
            val newPlan = repository.planJourney(station, state.selectedDestination)
            val newDepartures = repository.getLiveDepartures(station)
            state.copy(
                currentStation = station,
                totalPence = newTotal,
                journeyPlan = newPlan,
                departures = newDepartures,
                isStationSearchOpen = false,
                stationSearchQuery = ""
            )
        }
    }

    fun updatePassengerCount(category: PassengerCategory, delta: Int) {
        onUserActivity()
        _uiState.update { state ->
            val current = state.passengerCounts[category] ?: 0
            val next = (current + delta).coerceIn(0, 8)
            val updatedCounts = state.passengerCounts.toMutableMap()
            updatedCounts[category] = next

            // Ensure at least 1 passenger total
            if (updatedCounts.values.sum() == 0) {
                updatedCounts[PassengerCategory.ADULT] = 1
            }

            val newTotal = repository.calculateTotalPence(
                state.currentStation,
                state.selectedDestination,
                state.selectedTicketType,
                updatedCounts
            )
            state.copy(passengerCounts = updatedCounts, totalPence = newTotal)
        }
    }

    // --- Review and Lock Order ---

    fun proceedToReview() {
        onUserActivity()
        val state = _uiState.value
        val order = TicketOrder(
            origin = state.currentStation,
            destination = state.selectedDestination,
            ticketType = state.selectedTicketType,
            passengerCounts = state.passengerCounts,
            totalPence = state.totalPence,
            state = OrderState.LOCKED
        )
        _uiState.update {
            it.copy(
                currentOrder = order,
                currentScreen = KioskScreen.REVIEW_ORDER
            )
        }
    }

    // --- Payment Initiation ---

    fun proceedToPayment() {
        onUserActivity()
        val order = _uiState.value.currentOrder ?: return
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    currentScreen = KioskScreen.PAYMENT,
                    paymentReaderState = PaymentReaderState.READY_TO_TAP
                )
            }
            val startResult = paymentReader.startPayment(order)
            startResult.onSuccess { attempt ->
                _uiState.update {
                    it.copy(
                        currentPaymentAttempt = attempt,
                        paymentReaderState = attempt.readerState
                    )
                }
            }
        }
    }

    fun cancelPayment() {
        onUserActivity()
        viewModelScope.launch {
            paymentReader.cancelPayment()
            _uiState.update {
                it.copy(
                    paymentReaderState = PaymentReaderState.CANCELLED,
                    currentScreen = KioskScreen.BUY_TICKETS
                )
            }
        }
    }

    // --- Simulated Reader Triggers (for Kiosk Demonstration) ---

    fun triggerSimulatedApproval() {
        onUserActivity()
        viewModelScope.launch {
            val approvedAttempt = paymentReader.triggerApprove()
            _uiState.update {
                it.copy(
                    currentPaymentAttempt = approvedAttempt,
                    paymentReaderState = PaymentReaderState.APPROVED
                )
            }

            // Immediately proceed to issue ticket
            val order = _uiState.value.currentOrder ?: return@launch
            val issueResult = ticketService.issueTicket(order, approvedAttempt)
            issueResult.onSuccess { ticket ->
                _uiState.update {
                    it.copy(
                        issuedTicket = ticket,
                        currentOrder = order.copy(state = OrderState.ISSUED, issuedTicket = ticket),
                        currentScreen = KioskScreen.TICKET_SUCCESS
                    )
                }
            }.onFailure { ex ->
                val ref = (ex as? TicketIssuanceException)?.pendingReferenceCode ?: "PEND-ERR-01"
                _uiState.update {
                    it.copy(
                        pendingIssuanceRef = ref,
                        currentOrder = order.copy(
                            state = OrderState.PENDING_ISSUANCE,
                            pendingIssuanceRef = ref
                        ),
                        currentScreen = KioskScreen.PENDING_ISSUANCE
                    )
                }
            }
        }
    }

    fun triggerSimulatedDecline(reason: PaymentDeclineReason = PaymentDeclineReason.INSUFFICIENT_FUNDS) {
        onUserActivity()
        viewModelScope.launch {
            val declinedAttempt = paymentReader.triggerDecline(reason)
            _uiState.update {
                it.copy(
                    currentPaymentAttempt = declinedAttempt,
                    paymentReaderState = PaymentReaderState.DECLINED
                )
            }
        }
    }

    fun triggerSimulatedTimeout() {
        onUserActivity()
        viewModelScope.launch {
            val timedOut = paymentReader.triggerTimeout()
            _uiState.update {
                it.copy(
                    currentPaymentAttempt = timedOut,
                    paymentReaderState = PaymentReaderState.TIMED_OUT
                )
            }
        }
    }

    fun triggerSimulatedInterrupted() {
        onUserActivity()
        viewModelScope.launch {
            val interrupted = paymentReader.triggerInterrupted()
            _uiState.update {
                it.copy(
                    currentPaymentAttempt = interrupted,
                    paymentReaderState = PaymentReaderState.CONNECTION_INTERRUPTED
                )
            }
        }
    }

    fun triggerSimulatedStatusUnknown() {
        onUserActivity()
        viewModelScope.launch {
            val unknown = paymentReader.triggerStatusUnknown()
            _uiState.update {
                it.copy(
                    currentPaymentAttempt = unknown,
                    paymentReaderState = PaymentReaderState.PAYMENT_STATUS_UNKNOWN
                )
            }
        }
    }

    fun reconcilePaymentStatus() {
        onUserActivity()
        val attempt = _uiState.value.currentPaymentAttempt ?: return
        viewModelScope.launch {
            val reconciled = paymentReader.reconcileAttempt(attempt)
            _uiState.update {
                it.copy(
                    currentPaymentAttempt = reconciled,
                    paymentReaderState = reconciled.readerState
                )
            }
            if (reconciled.readerState == PaymentReaderState.APPROVED) {
                triggerSimulatedApproval()
            }
        }
    }

    fun simulateIssuanceFailureToggle() {
        ticketService.simulateIssuanceFailureNext = !ticketService.simulateIssuanceFailureNext
    }

    fun retryPendingIssuance() {
        onUserActivity()
        val order = _uiState.value.currentOrder ?: return
        val ref = _uiState.value.pendingIssuanceRef ?: "PEND-MANUAL"
        viewModelScope.launch {
            val recoveryResult = ticketService.recoverPendingIssuance(order.orderId, ref)
            recoveryResult.onSuccess { ticket ->
                _uiState.update {
                    it.copy(
                        issuedTicket = ticket,
                        currentOrder = order.copy(state = OrderState.ISSUED, issuedTicket = ticket),
                        currentScreen = KioskScreen.TICKET_SUCCESS
                    )
                }
            }
        }
    }

    fun printPhysicalReceipt() {
        onUserActivity()
        val ticket = _uiState.value.issuedTicket ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isPrinting = true) }
            ticketService.printPhysicalReceipt(ticket)
            _uiState.update { it.copy(isPrinting = false, printedSuccessfully = true) }
        }
    }

    // --- Station Search Dialog ---

    fun openStationSearch(isDestination: Boolean) {
        onUserActivity()
        _uiState.update {
            it.copy(
                isStationSearchOpen = true,
                isSelectingDestination = isDestination,
                stationSearchQuery = ""
            )
        }
    }

    fun updateStationSearchQuery(query: String) {
        onUserActivity()
        _uiState.update { it.copy(stationSearchQuery = query) }
    }

    fun closeStationSearch() {
        onUserActivity()
        _uiState.update { it.copy(isStationSearchOpen = false, stationSearchQuery = "") }
    }

    // --- Accessibility & UI Modes ---

    fun toggleHighContrast() {
        onUserActivity()
        _uiState.update { it.copy(highContrastMode = !it.highContrastMode) }
    }

    fun toggleReachableMode() {
        onUserActivity()
        _uiState.update { it.copy(seatedUserReachableMode = !it.seatedUserReachableMode) }
    }

    fun setShelterBackground(mode: String) {
        onUserActivity()
        _uiState.update { it.copy(shelterBackgroundMode = mode) }
    }

    fun toggleReducedMotion() {
        onUserActivity()
        _uiState.update { it.copy(reducedMotion = !it.reducedMotion) }
    }

    fun toggleLargeText() {
        onUserActivity()
        _uiState.update { it.copy(largeText = !it.largeText) }
    }
}
