package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.IssuedTicket
import com.example.ui.components.GlassPanel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@Composable
fun TicketSuccessScreen(
    ticket: IssuedTicket?,
    isPrinting: Boolean,
    printedSuccessfully: Boolean,
    highContrast: Boolean,
    reachableMode: Boolean,
    onPrintPhysicalTicket: () -> Unit,
    onFinishAndReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (ticket == null) return

    val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.UK)
    val validUntilStr = dateFormat.format(Date(ticket.validUntilTimestamp))

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = if (reachableMode) Arrangement.Bottom else Arrangement.SpaceBetween
    ) {
        // Top Banner: DEMO NOT VALID FOR TRAVEL + Success Check
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MetrolinkSuccess),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Check, contentDescription = "Success", tint = Color.White, modifier = Modifier.size(28.dp))
                }

                Column {
                    Text(
                        text = "Payment Approved • Ticket Issued",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 22.sp
                    )
                    Text(
                        text = "Ticket #${ticket.ticketNumber} • Auth: ${ticket.authCode}",
                        color = MetrolinkTextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            // Prominent DEMO Banner
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MetrolinkWarning)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "DEMO — NOT VALID FOR TRAVEL",
                    color = MetrolinkTextDark,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Center 2-Column: Left = Ticket Card with QR Code; Right = Delivery & Collection Options
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // LEFT: Virtual Metrolink Pass with Simulated Barcode / QR
            GlassPanel(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight(),
                highContrast = highContrast
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Ticket Header Card
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MetrolinkYellow)
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("M", color = MetrolinkTextDark, fontWeight = FontWeight.Black, fontSize = 20.sp)
                                Text("METROLINK PASS", color = MetrolinkTextDark, fontWeight = FontWeight.Black, fontSize = 14.sp)
                            }
                            Text(ticket.ticketTypeName.uppercase(), color = MetrolinkTextDark, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }

                        // Journey route
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("FROM", color = MetrolinkTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(ticket.originName, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
                            }
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MetrolinkYellow, modifier = Modifier.size(20.dp))
                            Column(horizontalAlignment = Alignment.End) {
                                Text("TO", color = MetrolinkTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(ticket.destinationName, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
                            }
                        }

                        Divider(color = Color(0x33FFFFFF))

                        // QR Matrix Barcode Canvas (Deterministic 2D matrix pattern)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(160.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White)
                                    .padding(10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val matrixSize = 17
                                    val cellSize = size.width / matrixSize
                                    val hash = ticket.qrPayload.hashCode()

                                    // Draw QR finder corners
                                    fun drawFinder(x: Int, y: Int) {
                                        drawRect(
                                            color = Color.Black,
                                            topLeft = Offset(x * cellSize, y * cellSize),
                                            size = Size(5 * cellSize, 5 * cellSize)
                                        )
                                        drawRect(
                                            color = Color.White,
                                            topLeft = Offset((x + 1) * cellSize, (y + 1) * cellSize),
                                            size = Size(3 * cellSize, 3 * cellSize)
                                        )
                                        drawRect(
                                            color = Color.Black,
                                            topLeft = Offset((x + 2) * cellSize, (y + 2) * cellSize),
                                            size = Size(cellSize, cellSize)
                                        )
                                    }

                                    drawFinder(0, 0)
                                    drawFinder(matrixSize - 5, 0)
                                    drawFinder(0, matrixSize - 5)

                                    // Draw data cells based on payload hash
                                    for (i in 0 until matrixSize) {
                                        for (j in 0 until matrixSize) {
                                            // Skip finders
                                            val inFinder = (i < 6 && j < 6) ||
                                                    (i >= matrixSize - 6 && j < 6) ||
                                                    (i < 6 && j >= matrixSize - 6)
                                            if (!inFinder) {
                                                val bit = (abs(hash + (i * 31) + (j * 17)) % 3) == 0
                                                if (bit) {
                                                    drawRect(
                                                        color = Color.Black,
                                                        topLeft = Offset(i * cellSize, j * cellSize),
                                                        size = Size(cellSize, cellSize)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Text(
                            text = "SCAN TO OPEN MOBILE TICKET",
                            color = MetrolinkYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Validity & Breakdown
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF141619))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Valid Until:", color = MetrolinkTextSecondary, fontSize = 11.sp)
                            Text(validUntilStr, color = MetrolinkSuccess, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Passengers:", color = MetrolinkTextSecondary, fontSize = 11.sp)
                            Text(ticket.passengerSummary, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Paid:", color = MetrolinkTextSecondary, fontSize = 11.sp)
                            Text(ticket.formattedTotalPaid(), color = MetrolinkYellow, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                    }
                }
            }

            // RIGHT: Collection Methods & Clear Explanation
            Column(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "HOW TO COLLECT YOUR TICKET",
                        color = MetrolinkYellow,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )

                    // Critical Explanation Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x2238BDF8))
                            .border(1.dp, Color(0x5538BDF8), RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.HelpOutline, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                                Text("Important Collection Notice", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Text(
                                text = "Tapping your bank card or mobile wallet only authorizes the payment. It does not automatically transfer a ticket into your card chip. Please scan the QR code with your camera or print a paper ticket below.",
                                color = Color(0xFFBAE6FD),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    // Option 1: Smartphone QR Scanner
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0x18FFFFFF)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x33FFD200)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = MetrolinkYellow)
                            }
                            Column {
                                Text("Option 1: Phone QR Scan", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Scan QR with camera to open secure browser pass", color = MetrolinkTextSecondary, fontSize = 11.sp)
                            }
                        }
                    }

                    // Option 2: Print Thermal Paper Ticket
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0x18FFFFFF)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color(0x3310B981)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = null, tint = MetrolinkSuccess)
                                }
                                Column {
                                    Text("Option 2: Print Paper Ticket", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(
                                        text = if (printedSuccessfully) "Printed! Take ticket below" else "Dispense thermal paper pass",
                                        color = if (printedSuccessfully) MetrolinkSuccess else MetrolinkTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Button(
                                onClick = onPrintPhysicalTicket,
                                enabled = !isPrinting,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (printedSuccessfully) Color(0x44FFFFFF) else MetrolinkYellow,
                                    contentColor = MetrolinkTextDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("print_physical_ticket_btn")
                            ) {
                                if (isPrinting) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MetrolinkTextDark)
                                } else {
                                    Text(if (printedSuccessfully) "Reprint" else "Print Pass", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Finish Action Button
                Button(
                    onClick = onFinishAndReset,
                    colors = ButtonDefaults.buttonColors(containerColor = MetrolinkYellow, contentColor = MetrolinkTextDark),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(vertical = 16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("finish_session_btn")
                ) {
                    Text("FINISH & READY FOR NEXT PASSENGER", fontWeight = FontWeight.Black, fontSize = 15.sp)
                }
            }
        }
    }
}
