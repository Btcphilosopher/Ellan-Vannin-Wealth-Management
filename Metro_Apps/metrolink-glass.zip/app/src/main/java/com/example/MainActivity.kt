package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.MetrolinkGlassTheme
import com.example.ui.viewmodel.KioskScreen
import com.example.ui.viewmodel.KioskViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: KioskViewModel = viewModel()
            val state by viewModel.uiState.collectAsStateWithLifecycle()

            MetrolinkGlassTheme(highContrast = state.highContrastMode) {
                // BackHandler to handle system back button appropriately
                BackHandler(enabled = state.currentScreen != KioskScreen.MAIN) {
                    when (state.currentScreen) {
                        KioskScreen.MAIN -> {}
                        KioskScreen.BUY_TICKETS -> viewModel.navigateTo(KioskScreen.MAIN)
                        KioskScreen.REVIEW_ORDER -> viewModel.navigateTo(KioskScreen.BUY_TICKETS)
                        KioskScreen.PAYMENT -> viewModel.cancelPayment()
                        KioskScreen.TICKET_SUCCESS -> viewModel.resetSessionToMain()
                        KioskScreen.PENDING_ISSUANCE -> viewModel.resetSessionToMain()
                        KioskScreen.DEPARTURES -> viewModel.navigateTo(KioskScreen.MAIN)
                        KioskScreen.JOURNEY_PLANNER -> viewModel.navigateTo(KioskScreen.MAIN)
                        KioskScreen.HELP -> viewModel.navigateTo(KioskScreen.MAIN)
                        KioskScreen.DIAGNOSTICS -> viewModel.navigateTo(KioskScreen.MAIN)
                    }
                }

                // Background backdrop based on shelter mode
                val backgroundBrush = if (state.highContrastMode) {
                    Brush.verticalGradient(listOf(Color(0xFF000000), Color(0xFF050505)))
                } else {
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFF0E1014),
                            Color(0xFF161920),
                            Color(0xFF111317)
                        )
                    )
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(backgroundBrush)
                        .testTag("kiosk_main_scaffold"),
                    containerColor = Color.Transparent,
                    contentWindowInsets = WindowInsets.safeDrawing,
                    topBar = {
                        MetrolinkKioskHeader(
                            currentStation = state.currentStation,
                            timeString = state.currentTimeString,
                            highContrast = state.highContrastMode,
                            activeDisruption = state.activeDisruption,
                            onStationClick = { viewModel.openStationSearch(isDestination = false) },
                            onDisruptionClick = { viewModel.navigateTo(KioskScreen.HELP) },
                            onResetClick = { viewModel.resetSessionToMain() },
                            onDiagnosticsClick = { viewModel.navigateTo(KioskScreen.DIAGNOSTICS) }
                        )
                    },
                    bottomBar = {
                        AccessibleFooterBar(
                            highContrast = state.highContrastMode,
                            reachableMode = state.seatedUserReachableMode,
                            sessionSeconds = state.sessionSecondsRemaining,
                            onToggleHighContrast = { viewModel.toggleHighContrast() },
                            onToggleReachableMode = { viewModel.toggleReachableMode() },
                            onExtendSession = { viewModel.extendSession() },
                            onResetSession = { viewModel.resetSessionToMain() },
                            onHelpClick = { viewModel.navigateTo(KioskScreen.HELP) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = state.currentScreen,
                            transitionSpec = {
                                if (state.reducedMotion) {
                                    EnterTransition.None togetherWith ExitTransition.None
                                } else {
                                    fadeIn() togetherWith fadeOut()
                                }
                            },
                            label = "screen_transition"
                        ) { screen ->
                            when (screen) {
                                KioskScreen.MAIN -> {
                                    MainKioskScreen(
                                        currentStation = state.currentStation,
                                        popularDestinations = viewModel.repository.stations.filter { it.isPopularHub() && it.id != state.currentStation.id },
                                        departures = state.departures,
                                        highContrast = state.highContrastMode,
                                        reachableMode = state.seatedUserReachableMode,
                                        onBuyTicketsClick = { viewModel.navigateTo(KioskScreen.BUY_TICKETS) },
                                        onSelectQuickDestination = { destination ->
                                            viewModel.setDestination(destination)
                                            viewModel.navigateTo(KioskScreen.BUY_TICKETS)
                                        },
                                        onPlanJourneyClick = { viewModel.navigateTo(KioskScreen.JOURNEY_PLANNER) },
                                        onDeparturesClick = { viewModel.navigateTo(KioskScreen.DEPARTURES) },
                                        onHelpClick = { viewModel.navigateTo(KioskScreen.HELP) }
                                    )
                                }

                                KioskScreen.BUY_TICKETS -> {
                                    TicketPurchaseScreen(
                                        currentStation = state.currentStation,
                                        selectedDestination = state.selectedDestination,
                                        selectedTicketType = state.selectedTicketType,
                                        passengerCounts = state.passengerCounts,
                                        totalPence = state.totalPence,
                                        highContrast = state.highContrastMode,
                                        reachableMode = state.seatedUserReachableMode,
                                        onSelectTicketType = { viewModel.setTicketType(it) },
                                        onOpenDestinationSearch = { viewModel.openStationSearch(isDestination = true) },
                                        onUpdatePassengerCount = { category, delta ->
                                            viewModel.updatePassengerCount(category, delta)
                                        },
                                        onProceedToPayment = { viewModel.proceedToReview() },
                                        onBackClick = { viewModel.navigateTo(KioskScreen.MAIN) }
                                    )
                                }

                                KioskScreen.REVIEW_ORDER -> {
                                    ReviewOrderScreen(
                                        order = state.currentOrder,
                                        highContrast = state.highContrastMode,
                                        reachableMode = state.seatedUserReachableMode,
                                        onConfirmProceedToReader = { viewModel.proceedToPayment() },
                                        onBackToEdit = { viewModel.navigateTo(KioskScreen.BUY_TICKETS) }
                                    )
                                }

                                KioskScreen.PAYMENT -> {
                                    PaymentScreen(
                                        order = state.currentOrder,
                                        readerState = state.paymentReaderState,
                                        currentAttempt = state.currentPaymentAttempt,
                                        highContrast = state.highContrastMode,
                                        reachableMode = state.seatedUserReachableMode,
                                        isIssuanceFailureArmed = viewModel.ticketService.simulateIssuanceFailureNext,
                                        onApprove = { viewModel.triggerSimulatedApproval() },
                                        onDecline = { reason -> viewModel.triggerSimulatedDecline(reason) },
                                        onTimeout = { viewModel.triggerSimulatedTimeout() },
                                        onInterrupted = { viewModel.triggerSimulatedInterrupted() },
                                        onReconcile = { viewModel.reconcilePaymentStatus() },
                                        onToggleIssuanceFailure = { viewModel.simulateIssuanceFailureToggle() },
                                        onCancelPayment = { viewModel.cancelPayment() }
                                    )
                                }

                                KioskScreen.TICKET_SUCCESS -> {
                                    TicketSuccessScreen(
                                        ticket = state.issuedTicket,
                                        isPrinting = state.isPrinting,
                                        printedSuccessfully = state.printedSuccessfully,
                                        highContrast = state.highContrastMode,
                                        reachableMode = state.seatedUserReachableMode,
                                        onPrintPhysicalTicket = { viewModel.printPhysicalReceipt() },
                                        onFinishAndReset = { viewModel.resetSessionToMain() }
                                    )
                                }

                                KioskScreen.PENDING_ISSUANCE -> {
                                    PendingIssuanceScreen(
                                        order = state.currentOrder,
                                        referenceCode = state.pendingIssuanceRef,
                                        highContrast = state.highContrastMode,
                                        reachableMode = state.seatedUserReachableMode,
                                        onRetryIssuance = { viewModel.retryPendingIssuance() },
                                        onFinishAndReport = { viewModel.resetSessionToMain() }
                                    )
                                }

                                KioskScreen.DEPARTURES -> {
                                    DeparturesScreen(
                                        currentStation = state.currentStation,
                                        departures = state.departures,
                                        highContrast = state.highContrastMode,
                                        reachableMode = state.seatedUserReachableMode,
                                        onBackClick = { viewModel.navigateTo(KioskScreen.MAIN) },
                                        onChangeStation = { viewModel.openStationSearch(isDestination = false) }
                                    )
                                }

                                KioskScreen.JOURNEY_PLANNER -> {
                                    JourneyPlannerScreen(
                                        origin = state.currentStation,
                                        destination = state.selectedDestination,
                                        journeyPlan = state.journeyPlan,
                                        highContrast = state.highContrastMode,
                                        reachableMode = state.seatedUserReachableMode,
                                        onOpenOriginSearch = { viewModel.openStationSearch(isDestination = false) },
                                        onOpenDestinationSearch = { viewModel.openStationSearch(isDestination = true) },
                                        onBuyTicketForJourney = {
                                            viewModel.navigateTo(KioskScreen.BUY_TICKETS)
                                        },
                                        onBackClick = { viewModel.navigateTo(KioskScreen.MAIN) }
                                    )
                                }

                                KioskScreen.HELP -> {
                                    HelpScreen(
                                        highContrast = state.highContrastMode,
                                        reachableMode = state.seatedUserReachableMode,
                                        onBackClick = { viewModel.navigateTo(KioskScreen.MAIN) }
                                    )
                                }

                                KioskScreen.DIAGNOSTICS -> {
                                    DiagnosticsModal(
                                        isOpen = true,
                                        diagnostics = state.diagnostics,
                                        onDismiss = { viewModel.navigateTo(KioskScreen.MAIN) },
                                        onResetKiosk = { viewModel.resetSessionToMain() }
                                    )
                                }
                            }
                        }

                        // Station Search Dialog
                        StationSearchModal(
                            isOpen = state.isStationSearchOpen,
                            isDestination = state.isSelectingDestination,
                            currentSelection = if (state.isSelectingDestination) state.selectedDestination else state.currentStation,
                            allStations = viewModel.repository.stations,
                            onSelectStation = { station ->
                                if (state.isSelectingDestination) {
                                    viewModel.setDestination(station)
                                } else {
                                    viewModel.setOrigin(station)
                                }
                            },
                            onDismiss = { viewModel.closeStationSearch() },
                            highContrast = state.highContrastMode
                        )

                        // Inactivity warning modal
                        SessionTimeoutWarningDialog(
                            isOpen = state.showSessionWarning,
                            secondsRemaining = state.sessionSecondsRemaining,
                            onExtend = { viewModel.extendSession() },
                            onEnd = { viewModel.resetSessionToMain() }
                        )
                    }
                }
            }
        }
    }
}
