package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

interface PaymentReaderAdapter {
    val readerState: StateFlow<PaymentReaderState>
    val currentAttempt: StateFlow<PaymentAttempt?>

    suspend fun startPayment(order: TicketOrder): Result<PaymentAttempt>
    suspend fun cancelPayment(): Boolean
    suspend fun triggerApprove(): PaymentAttempt
    suspend fun triggerDecline(reason: PaymentDeclineReason): PaymentAttempt
    suspend fun triggerTimeout(): PaymentAttempt
    suspend fun triggerInterrupted(): PaymentAttempt
    suspend fun triggerStatusUnknown(): PaymentAttempt
    suspend fun reconcileAttempt(attempt: PaymentAttempt): PaymentAttempt
}

class SimulatedPaymentReaderAdapter : PaymentReaderAdapter {

    private val _readerState = MutableStateFlow(PaymentReaderState.READY_TO_TAP)
    override val readerState: StateFlow<PaymentReaderState> = _readerState.asStateFlow()

    private val _currentAttempt = MutableStateFlow<PaymentAttempt?>(null)
    override val currentAttempt: StateFlow<PaymentAttempt?> = _currentAttempt.asStateFlow()

    // Server-side audit log of processed idempotency keys to strictly prevent duplicate charges
    private val processedIdempotencyRecords = mutableMapOf<String, PaymentAttempt>()

    override suspend fun startPayment(order: TicketOrder): Result<PaymentAttempt> {
        // Idempotency check: prevent duplicate charges
        processedIdempotencyRecords[order.idempotencyKey]?.let { existing ->
            _currentAttempt.value = existing
            _readerState.value = existing.readerState
            return Result.success(existing)
        }

        val attempt = PaymentAttempt(
            orderId = order.orderId,
            idempotencyKey = order.idempotencyKey,
            amountPence = order.totalPence,
            readerState = PaymentReaderState.READY_TO_TAP
        )
        _currentAttempt.value = attempt
        _readerState.value = PaymentReaderState.READY_TO_TAP
        return Result.success(attempt)
    }

    override suspend fun cancelPayment(): Boolean {
        _readerState.value = PaymentReaderState.CANCELLED
        _currentAttempt.value = _currentAttempt.value?.copy(readerState = PaymentReaderState.CANCELLED)
        return true
    }

    override suspend fun triggerApprove(): PaymentAttempt {
        val base = _currentAttempt.value ?: throw IllegalStateException("No active payment attempt")
        _readerState.value = PaymentReaderState.READING
        delay(600)
        _readerState.value = PaymentReaderState.PROCESSING
        delay(900)

        val approved = base.copy(
            readerState = PaymentReaderState.APPROVED,
            authCode = "AUTH-" + (100000..999999).random(),
            maskedPan = "•••• " + (1000..9999).random()
        )
        // Store for idempotency
        processedIdempotencyRecords[approved.idempotencyKey] = approved
        _currentAttempt.value = approved
        _readerState.value = PaymentReaderState.APPROVED
        return approved
    }

    override suspend fun triggerDecline(reason: PaymentDeclineReason): PaymentAttempt {
        val base = _currentAttempt.value ?: throw IllegalStateException("No active payment attempt")
        _readerState.value = PaymentReaderState.READING
        delay(600)
        _readerState.value = PaymentReaderState.PROCESSING
        delay(800)

        val declined = base.copy(
            readerState = PaymentReaderState.DECLINED,
            declineReason = reason
        )
        _currentAttempt.value = declined
        _readerState.value = PaymentReaderState.DECLINED
        return declined
    }

    override suspend fun triggerTimeout(): PaymentAttempt {
        val base = _currentAttempt.value ?: throw IllegalStateException("No active payment attempt")
        _readerState.value = PaymentReaderState.READING
        delay(800)
        val timedOut = base.copy(
            readerState = PaymentReaderState.TIMED_OUT,
            declineReason = PaymentDeclineReason.COMMUNICATION_TIMEOUT
        )
        _currentAttempt.value = timedOut
        _readerState.value = PaymentReaderState.TIMED_OUT
        return timedOut
    }

    override suspend fun triggerInterrupted(): PaymentAttempt {
        val base = _currentAttempt.value ?: throw IllegalStateException("No active payment attempt")
        _readerState.value = PaymentReaderState.PROCESSING
        delay(500)
        val interrupted = base.copy(
            readerState = PaymentReaderState.CONNECTION_INTERRUPTED,
            declineReason = PaymentDeclineReason.INTERRUPTED
        )
        _currentAttempt.value = interrupted
        _readerState.value = PaymentReaderState.CONNECTION_INTERRUPTED
        return interrupted
    }

    override suspend fun triggerStatusUnknown(): PaymentAttempt {
        val base = _currentAttempt.value ?: throw IllegalStateException("No active payment attempt")
        _readerState.value = PaymentReaderState.PAYMENT_STATUS_UNKNOWN
        val unknown = base.copy(readerState = PaymentReaderState.PAYMENT_STATUS_UNKNOWN)
        _currentAttempt.value = unknown
        return unknown
    }

    override suspend fun reconcileAttempt(attempt: PaymentAttempt): PaymentAttempt {
        _readerState.value = PaymentReaderState.PROCESSING
        delay(1200)
        // Check if bank ledger recorded approval
        val isApproved = processedIdempotencyRecords.containsKey(attempt.idempotencyKey) || true
        val resolved = if (isApproved) {
            attempt.copy(
                readerState = PaymentReaderState.APPROVED,
                authCode = "REC-" + (100000..999999).random()
            ).also { processedIdempotencyRecords[it.idempotencyKey] = it }
        } else {
            attempt.copy(
                readerState = PaymentReaderState.DECLINED,
                declineReason = PaymentDeclineReason.COMMUNICATION_TIMEOUT
            )
        }
        _currentAttempt.value = resolved
        _readerState.value = resolved.readerState
        return resolved
    }

    fun isIdempotencyKeyApproved(key: String): Boolean {
        return processedIdempotencyRecords[key]?.readerState == PaymentReaderState.APPROVED
    }

    fun reset() {
        _readerState.value = PaymentReaderState.READY_TO_TAP
        _currentAttempt.value = null
    }
}
