package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TicketOrder
import com.example.ui.components.GlassPanel
import com.example.ui.theme.*

@Composable
fun ReviewOrderScreen(
    order: TicketOrder?,
    highContrast: Boolean,
    reachableMode: Boolean,
    onConfirmProceedToReader: () -> Unit,
    onBackToEdit: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (order == null) return

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalArrangement = if (reachableMode) Arrangement.Bottom else Arrangement.SpaceBetween
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                IconButton(
                    onClick = onBackToEdit,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0x22FFFFFF))
                        .testTag("review_back_btn")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Edit selection", tint = Color.White)
                }

                Column {
                    Text(
                        text = "Review Your Order",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 26.sp
                    )
                    Text(
                        text = "Order #${order.orderId} • Locked for payment",
                        color = MetrolinkTextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x3310B981))
                    .border(1.dp, Color(0x6610B981), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "IDEMPOTENCY SECURED",
                    color = MetrolinkSuccess,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Center Review Container
        GlassPanel(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            highContrast = highContrast
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Journey Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF141619))
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ORIGIN", color = MetrolinkTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(order.origin.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            Text(order.origin.zoneDescription(), color = MetrolinkYellow, fontSize = 12.sp)
                        }

                        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MetrolinkYellow, modifier = Modifier.size(28.dp))

                        Column(horizontalAlignment = Alignment.End) {
                            Text("DESTINATION", color = MetrolinkTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(order.destination.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            Text(order.destination.zoneDescription(), color = MetrolinkYellow, fontSize = 12.sp)
                        }
                    }

                    // Ticket Breakdown Rows
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF141619))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ReviewItem("Ticket Type", order.ticketType.title + " (" + order.ticketType.subtitle + ")")
                        ReviewItem("Passengers", order.passengerBreakdownString())
                        ReviewItem("Tariff Coverage", "Concentric Zones (${order.origin.zoneDescription()} to ${order.destination.zoneDescription()})")
                        ReviewItem("Validity Period", order.ticketType.validityDescription)
                        ReviewItem("Order Reference", order.orderId)
                        ReviewItem("Idempotency Key", order.idempotencyKey.take(24) + "...")
                    }

                    // Regulatory & Unattended Terminal Disclosure
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x18FFFFFF))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "Unattended Terminal Protection: Your payment amount is locked at ${order.formattedTotal()}. Raw payment card details are never processed by the touchscreen and are handled strictly by the certified EMV glass reader module.",
                            color = MetrolinkTextMuted,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }

                // Total and Activate Reader Action
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Divider(color = Color(0x33FFFFFF))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TOTAL TO PAY", color = MetrolinkTextSecondary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(order.formattedTotal(), color = MetrolinkYellow, fontWeight = FontWeight.Black, fontSize = 32.sp)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        OutlinedButton(
                            onClick = onBackToEdit,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .testTag("change_order_button")
                        ) {
                            Text("Change Selection", fontSize = 14.sp)
                        }

                        Button(
                            onClick = onConfirmProceedToReader,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MetrolinkYellow,
                                contentColor = MetrolinkTextDark
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1.8f)
                                .height(56.dp)
                                .testTag("confirm_to_payment_button")
                        ) {
                            Icon(Icons.Default.Contactless, contentDescription = null, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("ACTIVATE READER & PAY", fontWeight = FontWeight.Black, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReviewItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(text = label, color = MetrolinkTextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(
            text = value,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(2f),
            textAlign = TextAlign.End
        )
    }
}
