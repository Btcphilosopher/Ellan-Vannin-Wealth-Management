package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Iconic Manchester Metrolink Brand Colors
val MetrolinkYellow = Color(0xFFFFD200)       // TfGM Metrolink Yellow
val MetrolinkYellowHover = Color(0xFFFFE042)
val MetrolinkYellowDark = Color(0xFFE5BD00)
val MetrolinkCharcoal = Color(0xFF141619)     // Deep kiosk enclosure charcoal
val MetrolinkSurfaceDark = Color(0xFF1C1F24)
val MetrolinkSurfaceCard = Color(0xFF252930)
val MetrolinkGlassPanel = Color(0xE6181B20)   // Frosted shelter glass base
val MetrolinkGlassOpaque = Color(0xFF0F1114)  // High-contrast daylight mode
val MetrolinkGlassBorder = Color(0x33FFFFFF)
val MetrolinkGlassHighlight = Color(0x14FFFFFF)

val MetrolinkTextPrimary = Color(0xFFF8F9FA)
val MetrolinkTextSecondary = Color(0xFFA6ABB6)
val MetrolinkTextMuted = Color(0xFF717684)
val MetrolinkTextDark = Color(0xFF121417)      // High-contrast text on yellow

val MetrolinkSuccess = Color(0xFF10B981)
val MetrolinkWarning = Color(0xFFF59E0B)
val MetrolinkError = Color(0xFFEF4444)
val MetrolinkNfcBlue = Color(0xFF38BDF8)

// Official Metrolink Line Route Colors
val MetrolinkLineGreen = Color(0xFF2E7D32)   // Bury - Altrincham
val MetrolinkLineBlue = Color(0xFF0288D1)    // Victoria - Manchester Airport
val MetrolinkLinePurple = Color(0xFF8E24AA)  // Shaw/Rochdale - East Didsbury
val MetrolinkLinePink = Color(0xFFD81B60)    // Ashton - Eccles
val MetrolinkLineOrange = Color(0xFFE65100)  // Rochdale Town Centre
val MetrolinkLineTeal = Color(0xFF00897B)    // MediaCityUK - Piccadilly
val MetrolinkLineRed = Color(0xFFC62828)     // Trafford Centre - Deansgate
