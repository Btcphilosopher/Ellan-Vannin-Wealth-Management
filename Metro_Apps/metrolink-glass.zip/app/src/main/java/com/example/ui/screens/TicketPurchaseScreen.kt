package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.GlassPanel
import com.example.ui.theme.*

@Composable
fun TicketPurchaseScreen(
    currentStation: MetrolinkStation,
    selectedDestination: MetrolinkStation,
    selectedTicketType: TicketType,
    passengerCounts: Map<PassengerCategory, Int>,
    totalPence: Int,
    highContrast: Boolean,
    reachableMode: Boolean,
    onSelectTicketType: (TicketType) -> Unit,
    onOpenDestinationSearch: () -> Unit,
    onUpdatePassengerCount: (PassengerCategory, Int) -> Unit,
    onProceedToPayment: () -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = if (reachableMode) Arrangement.Bottom else Arrangement.SpaceBetween
    ) {
        // Top Navigation Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0x22FFFFFF))
                        .testTag("ticket_purchase_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Column {
                    Text(
                        text = "Tickets",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 28.sp
                    )
                    Text(
                        text = "Select product, destination, and passengers",
                        color = MetrolinkTextSecondary,
                        fontSize = 14.sp
                    )
                }
            }

            // Zones summary pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x22FFFFFF))
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "Origin: ${currentStation.name} (${currentStation.zoneDescription()})",
                    color = MetrolinkYellow,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Main 2-Column Touch Layout
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // LEFT COLUMN: Destination + Ticket Types + Passenger Selection
            Column(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 1. Destination Selector Card
                GlassPanel(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenDestinationSearch() }
                        .testTag("destination_selector_card"),
                    highContrast = highContrast
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(MetrolinkYellow),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Place,
                                    contentDescription = null,
                                    tint = MetrolinkTextDark,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = "DESTINATION",
                                    color = MetrolinkTextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = selectedDestination.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp
                                )
                                Text(
                                    text = "${selectedDestination.zoneDescription()} • Step-free platform",
                                    color = MetrolinkTextMuted,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Button(
                            onClick = onOpenDestinationSearch,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0x33FFFFFF),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("change_destination_btn")
                        ) {
                            Text("Change Destination", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // 2. Ticket Product Selection Cards
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "TICKET PRODUCT",
                        color = MetrolinkTextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    TicketType.values().forEach { type ->
                        val isSelected = type == selectedTicketType
                        val isRecommended = type == TicketType.DAY_TRAVELCARD_OFF_PEAK

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isSelected) Color(0x33FFD200) else Color(0x18FFFFFF))
                                .border(
                                    1.5.dp,
                                    if (isSelected) MetrolinkYellow else Color(0x22FFFFFF),
                                    RoundedCornerShape(14.dp)
                                )
                                .clickable { onSelectTicketType(type) }
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .testTag("ticket_type_${type.name}")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { onSelectTicketType(type) },
                                        colors = RadioButtonDefaults.colors(
                                            selectedColor = MetrolinkYellow,
                                            unselectedColor = MetrolinkTextMuted
                                        )
                                    )

                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text(
                                                text = type.title,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp
                                            )
                                            if (isRecommended) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(MetrolinkYellow)
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        text = "BEST VALUE",
                                                        color = MetrolinkTextDark,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = type.subtitle,
                                            color = MetrolinkTextSecondary,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                Text(
                                    text = if (type == TicketType.DAY_TRAVELCARD_OFF_PEAK) "Unlimited" else "Valid in zones",
                                    color = MetrolinkTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // 3. Passenger Counts (+ / - controls)
                GlassPanel(
                    modifier = Modifier.fillMaxWidth(),
                    highContrast = highContrast
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "PASSENGERS",
                            color = MetrolinkTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        PassengerCategory.values().forEach { category ->
                            val count = passengerCounts[category] ?: 0
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = category.label,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = category.note,
                                        color = MetrolinkTextMuted,
                                        fontSize = 11.sp
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    IconButton(
                                        onClick = { onUpdatePassengerCount(category, -1) },
                                        enabled = count > 0,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(if (count > 0) Color(0x33FFFFFF) else Color(0x11FFFFFF))
                                            .testTag("decrement_${category.name}")
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = Color.White)
                                    }

                                    Text(
                                        text = count.toString(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 18.sp,
                                        modifier = Modifier.width(24.dp),
                                        textAlign = TextAlign.Center
                                    )

                                    IconButton(
                                        onClick = { onUpdatePassengerCount(category, 1) },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(Color(0x33FFFFFF))
                                            .testTag("increment_${category.name}")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Increase", tint = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // RIGHT COLUMN: Summary + Fare Comparison + Total Price + Big Pay Contactless Button
            Column(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Journey and Ticket Summary
                GlassPanel(
                    modifier = Modifier.fillMaxWidth(),
                    highContrast = highContrast
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ORDER SUMMARY",
                                color = MetrolinkYellow,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                letterSpacing = 1.sp
                            )

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0x33FFFFFF))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "DEMO TARIFF",
                                    color = MetrolinkTextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Origin -> Destination
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(currentStation.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MetrolinkYellow, modifier = Modifier.size(16.dp))
                            Text(selectedDestination.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        // Details
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF141619))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            SummaryItem("Zones Spanned", "${currentStation.zoneDescription()} to ${selectedDestination.zoneDescription()}")
                            SummaryItem("Ticket Product", selectedTicketType.title)
                            SummaryItem("Validity", selectedTicketType.validityDescription)
                        }

                        // Notice distinguishing ticket from contactless tap-in/out
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x2238BDF8))
                                .border(1.dp, Color(0x4438BDF8), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                                Text(
                                    text = "Purchasing issues a guaranteed digital or printed ticket. For pay-as-you-go tap-in/out without buying in advance, tap your card on platform smart readers.",
                                    color = Color(0xFFE0F2FE),
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Total Price & Primary Action
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TOTAL PRICE",
                            color = MetrolinkTextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = TicketProduct.formatPence(totalPence),
                            color = MetrolinkYellow,
                            fontWeight = FontWeight.Black,
                            fontSize = 34.sp
                        )
                    }

                    // Large "Pay contactless" Button
                    Button(
                        onClick = onProceedToPayment,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MetrolinkYellow,
                            contentColor = MetrolinkTextDark
                        ),
                        shape = RoundedCornerShape(16.dp),
                        contentPadding = PaddingValues(vertical = 18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pay_contactless_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Contactless,
                                contentDescription = null,
                                tint = MetrolinkTextDark,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "PAY CONTACTLESS",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(text = label, color = MetrolinkTextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(
            text = value,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1.8f),
            textAlign = TextAlign.End
        )
    }
}
