package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MetrolinkColorScheme = darkColorScheme(
    primary = MetrolinkYellow,
    onPrimary = MetrolinkTextDark,
    primaryContainer = MetrolinkYellowDark,
    onPrimaryContainer = MetrolinkTextDark,
    secondary = MetrolinkYellowHover,
    onSecondary = MetrolinkTextDark,
    background = MetrolinkCharcoal,
    onBackground = MetrolinkTextPrimary,
    surface = MetrolinkSurfaceDark,
    onSurface = MetrolinkTextPrimary,
    surfaceVariant = MetrolinkSurfaceCard,
    onSurfaceVariant = MetrolinkTextSecondary,
    outline = MetrolinkGlassBorder,
    error = MetrolinkError,
    onError = Color.White
)

@Composable
fun MetrolinkGlassTheme(
    highContrast: Boolean = false,
    content: @Composable () -> Unit
) {
    val scheme = if (highContrast) {
        MetrolinkColorScheme.copy(
            background = Color.Black,
            surface = Color(0xFF101010),
            surfaceVariant = Color(0xFF1A1A1A),
            outline = Color(0x66FFFFFF),
            onBackground = Color.White,
            onSurface = Color.White
        )
    } else {
        MetrolinkColorScheme
    }

    MaterialTheme(
        colorScheme = scheme,
        typography = Typography,
        content = content
    )
}
