package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MetrolinkStation
import com.example.data.model.TramDeparture
import com.example.ui.components.GlassPanel
import com.example.ui.theme.*

@Composable
fun MainKioskScreen(
    currentStation: MetrolinkStation,
    popularDestinations: List<MetrolinkStation>,
    departures: List<TramDeparture>,
    highContrast: Boolean,
    reachableMode: Boolean,
    onBuyTicketsClick: () -> Unit,
    onSelectQuickDestination: (MetrolinkStation) -> Unit,
    onPlanJourneyClick: () -> Unit,
    onDeparturesClick: () -> Unit,
    onHelpClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = if (reachableMode) Arrangement.Bottom else Arrangement.SpaceBetween
    ) {
        if (!reachableMode) {
            // Welcome & Shelter Information
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Touchscreen Tram Ticketing",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 28.sp
                    )
                    Text(
                        text = "Touch anywhere on this shelter glass pane to purchase Metrolink tickets",
                        color = MetrolinkTextSecondary,
                        fontSize = 15.sp
                    )
                }

                // Contactless Reader Badge indicator
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x22FFFFFF))
                        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Contactless, contentDescription = null, tint = MetrolinkYellow, modifier = Modifier.size(20.dp))
                        Column {
                            Text("Glass NFC Reader", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Apple Pay • Google Pay • Cards", color = MetrolinkTextMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Hero: PRIMARY "BUY TICKETS" ACTION
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .clickable { onBuyTicketsClick() }
                .testTag("hero_buy_tickets_btn"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (highContrast) MetrolinkYellow else Color(0xFFFFD200)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(MetrolinkTextDark),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ConfirmationNumber,
                            contentDescription = null,
                            tint = MetrolinkYellow,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "BUY TICKETS",
                                color = MetrolinkTextDark,
                                fontWeight = FontWeight.Black,
                                fontSize = 28.sp,
                                letterSpacing = 1.sp
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MetrolinkTextDark)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "FAST TOUCH",
                                    color = MetrolinkYellow,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Single, 1-Day Travelcard, Off-Peak & Weekend across Zones 1–4",
                            color = MetrolinkTextDark.copy(alpha = 0.85f),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MetrolinkTextDark),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Start ticket purchase",
                        tint = MetrolinkYellow,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Popular Destinations Strip
        Column {
            Text(
                text = "POPULAR DESTINATIONS FROM ${currentStation.name.uppercase()}",
                color = MetrolinkTextSecondary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(popularDestinations) { station ->
                    GlassPanel(
                        modifier = Modifier
                            .clickable { onSelectQuickDestination(station) }
                            .testTag("quick_destination_${station.id}"),
                        shape = RoundedCornerShape(14.dp),
                        highContrast = highContrast
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(station.lines.firstOrNull()?.color ?: MetrolinkYellow)
                            )
                            Column {
                                Text(
                                    text = station.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = station.zoneDescription(),
                                    color = MetrolinkTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Secondary Actions Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Plan Journey Card
            GlassPanel(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onPlanJourneyClick() }
                    .testTag("action_plan_journey"),
                highContrast = highContrast
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x3338BDF8)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AltRoute, contentDescription = null, tint = Color(0xFF38BDF8))
                        }
                        Column {
                            Text("Plan Journey", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Interchanges & travel times", color = MetrolinkTextMuted, fontSize = 12.sp)
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MetrolinkTextMuted)
                }
            }

            // Live Departures Card
            GlassPanel(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onDeparturesClick() }
                    .testTag("action_live_departures"),
                highContrast = highContrast
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x3310B981)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Tram, contentDescription = null, tint = MetrolinkSuccess)
                        }
                        Column {
                            Text("Live Departures", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Platforms & due minutes", color = MetrolinkTextMuted, fontSize = 12.sp)
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MetrolinkTextMuted)
                }
            }

            // Help & Guidance Card
            GlassPanel(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onHelpClick() }
                    .testTag("action_help_guidance"),
                highContrast = highContrast
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x33F59E0B)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = MetrolinkWarning)
                        }
                        Column {
                            Text("Help & Info", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Zones & contactless rules", color = MetrolinkTextMuted, fontSize = 12.sp)
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MetrolinkTextMuted)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Next Departures Compact Ticker
        GlassPanel(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onDeparturesClick() },
            shape = RoundedCornerShape(14.dp),
            highContrast = highContrast
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = MetrolinkYellow, modifier = Modifier.size(20.dp))
                    Text(
                        text = "NEXT TRAMS FROM ${currentStation.name.uppercase()}:",
                        color = MetrolinkTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    departures.take(3).forEach { dep ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0x22FFFFFF))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(dep.line.color))
                            Text(dep.destination, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(dep.displayMinutes(), color = MetrolinkYellow, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }

                Text(
                    text = "View all departures ›",
                    color = MetrolinkYellow,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
