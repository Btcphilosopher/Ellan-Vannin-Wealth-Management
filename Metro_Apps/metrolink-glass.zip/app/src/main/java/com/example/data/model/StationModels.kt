package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class MetrolinkLine(
    val lineName: String,
    val color: Color,
    val terminalStops: String
) {
    GREEN("Altrincham – Bury", MetrolinkLineGreen, "Altrincham ⇄ Bury"),
    BLUE("Manchester Airport – Victoria", MetrolinkLineBlue, "Manchester Airport ⇄ Victoria"),
    PURPLE("East Didsbury – Rochdale", MetrolinkLinePurple, "East Didsbury ⇄ Rochdale"),
    PINK("Ashton-under-Lyne – Eccles", MetrolinkLinePink, "Ashton ⇄ Eccles"),
    TEAL("MediaCityUK – Piccadilly", MetrolinkLineTeal, "MediaCityUK ⇄ Piccadilly"),
    RED("Trafford Centre – Deansgate", MetrolinkLineRed, "Trafford Centre ⇄ Deansgate-Castlefield")
}

data class MetrolinkStation(
    val id: String,
    val name: String,
    val primaryZone: Int,
    val secondaryZone: Int? = null,
    val lines: List<MetrolinkLine>,
    val stepFree: Boolean = true,
    val platforms: List<String> = listOf("1", "2")
) {
    fun zoneDescription(): String {
        return if (secondaryZone != null) {
            "Zones $primaryZone & $secondaryZone"
        } else {
            "Zone $primaryZone"
        }
    }

    fun isPopularHub(): Boolean {
        return id in listOf(
            "st_peters_square", "piccadilly", "mediacityuk",
            "manchester_airport", "trafford_centre", "victoria",
            "altrincham", "cornbrook"
        )
    }
}
