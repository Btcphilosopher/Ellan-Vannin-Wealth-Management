package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.JourneyPlanResult
import com.example.data.model.MetrolinkStation
import com.example.ui.components.GlassPanel
import com.example.ui.theme.*

@Composable
fun JourneyPlannerScreen(
    origin: MetrolinkStation,
    destination: MetrolinkStation,
    journeyPlan: JourneyPlanResult?,
    highContrast: Boolean,
    reachableMode: Boolean,
    onOpenOriginSearch: () -> Unit,
    onOpenDestinationSearch: () -> Unit,
    onBuyTicketForJourney: () -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var stepFreeOnly by remember { mutableStateOf(true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = if (reachableMode) Arrangement.Bottom else Arrangement.SpaceBetween
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0x22FFFFFF))
                        .testTag("journey_planner_back_btn")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }

                Column {
                    Text(
                        text = "Plan a Journey",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 26.sp
                    )
                    Text(
                        text = "Find optimal tram routes, interchanges, and fares",
                        color = MetrolinkTextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            // Step-free filter chip
            FilterChip(
                selected = stepFreeOnly,
                onClick = { stepFreeOnly = !stepFreeOnly },
                label = { Text("Step-Free Route: All Metrolink") },
                leadingIcon = { Icon(Icons.Default.Accessible, contentDescription = null, modifier = Modifier.size(16.dp)) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MetrolinkYellow,
                    selectedLabelColor = MetrolinkTextDark
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Station Selector bar
        GlassPanel(
            modifier = Modifier.fillMaxWidth(),
            highContrast = highContrast
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Origin
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x18FFFFFF))
                        .clickable { onOpenOriginSearch() }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.TripOrigin, contentDescription = null, tint = MetrolinkYellow, modifier = Modifier.size(20.dp))
                    Column {
                        Text("ORIGIN", color = MetrolinkTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(origin.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }

                Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = MetrolinkTextMuted, modifier = Modifier.padding(horizontal = 8.dp))

                // Destination
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x18FFFFFF))
                        .clickable { onOpenDestinationSearch() }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.Place, contentDescription = null, tint = MetrolinkYellow, modifier = Modifier.size(20.dp))
                    Column {
                        Text("DESTINATION", color = MetrolinkTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(destination.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Route details & recommendations
        if (journeyPlan != null) {
            GlassPanel(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                highContrast = highContrast
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        // Metrics strip
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF141619))
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("ESTIMATED TIME", color = MetrolinkTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text("${journeyPlan.estimatedMinutes} mins", color = MetrolinkYellow, fontWeight = FontWeight.Black, fontSize = 20.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("INTERCHANGE", color = MetrolinkTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(journeyPlan.interchangeStation?.name ?: "Direct (0 changes)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("ZONES CROSSED", color = MetrolinkTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text("Zones " + journeyPlan.zonesCrossed.sorted().joinToString(", "), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }

                        Text("STEP-BY-STEP ROUTE", color = MetrolinkTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                        // Step-by-step
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(journeyPlan.steps) { step ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0x18FFFFFF))
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(step.line?.color ?: MetrolinkYellow)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(step.instruction, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("${step.stopsCount} stops • ${step.intermediateStops.joinToString()}", color = MetrolinkTextMuted, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Bottom recommendation and buy button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF141619))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("RECOMMENDED TICKET", color = MetrolinkTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${journeyPlan.recommendedTicketType.title} • ${journeyPlan.sampleAdultFare} (Adult)", color = MetrolinkYellow, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        Button(
                            onClick = onBuyTicketForJourney,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MetrolinkYellow,
                                contentColor = MetrolinkTextDark
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("buy_ticket_for_journey_btn")
                        ) {
                            Text("BUY THIS TICKET", fontWeight = FontWeight.Black, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
