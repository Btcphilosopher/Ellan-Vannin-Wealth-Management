package com.example.data.repository

import com.example.data.model.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MetrolinkRepository {

    val defaultStation: MetrolinkStation
        get() = stations.first { it.id == "st_peters_square" }

    val stations: List<MetrolinkStation> = listOf(
        MetrolinkStation(
            id = "st_peters_square",
            name = "St Peter's Square",
            primaryZone = 1,
            lines = listOf(MetrolinkLine.GREEN, MetrolinkLine.BLUE, MetrolinkLine.PURPLE, MetrolinkLine.PINK, MetrolinkLine.TEAL),
            platforms = listOf("1", "2", "3", "4")
        ),
        MetrolinkStation(
            id = "piccadilly",
            name = "Piccadilly",
            primaryZone = 1,
            lines = listOf(MetrolinkLine.PINK, MetrolinkLine.TEAL),
            platforms = listOf("A", "B")
        ),
        MetrolinkStation(
            id = "piccadilly_gardens",
            name = "Piccadilly Gardens",
            primaryZone = 1,
            lines = listOf(MetrolinkLine.GREEN, MetrolinkLine.BLUE, MetrolinkLine.PINK, MetrolinkLine.TEAL),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "victoria",
            name = "Manchester Victoria",
            primaryZone = 1,
            lines = listOf(MetrolinkLine.GREEN, MetrolinkLine.BLUE, MetrolinkLine.PURPLE),
            platforms = listOf("1", "2", "3", "4")
        ),
        MetrolinkStation(
            id = "deansgate",
            name = "Deansgate-Castlefield",
            primaryZone = 1,
            lines = listOf(MetrolinkLine.GREEN, MetrolinkLine.BLUE, MetrolinkLine.PURPLE, MetrolinkLine.PINK, MetrolinkLine.RED),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "market_street",
            name = "Market Street",
            primaryZone = 1,
            lines = listOf(MetrolinkLine.GREEN, MetrolinkLine.BLUE),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "exchange_square",
            name = "Exchange Square",
            primaryZone = 1,
            lines = listOf(MetrolinkLine.PURPLE, MetrolinkLine.BLUE),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "cornbrook",
            name = "Cornbrook",
            primaryZone = 1,
            secondaryZone = 2,
            lines = listOf(MetrolinkLine.GREEN, MetrolinkLine.BLUE, MetrolinkLine.PURPLE, MetrolinkLine.PINK, MetrolinkLine.RED),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "mediacityuk",
            name = "MediaCityUK",
            primaryZone = 2,
            lines = listOf(MetrolinkLine.TEAL),
            platforms = listOf("1")
        ),
        MetrolinkStation(
            id = "trafford_bar",
            name = "Trafford Bar",
            primaryZone = 2,
            lines = listOf(MetrolinkLine.GREEN, MetrolinkLine.BLUE, MetrolinkLine.PURPLE),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "salford_quays",
            name = "Salford Quays",
            primaryZone = 2,
            lines = listOf(MetrolinkLine.PINK, MetrolinkLine.TEAL),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "trafford_centre",
            name = "The Trafford Centre",
            primaryZone = 2,
            lines = listOf(MetrolinkLine.RED),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "imperial_war_museum",
            name = "Imperial War Museum",
            primaryZone = 2,
            lines = listOf(MetrolinkLine.RED),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "chorlton",
            name = "Chorlton",
            primaryZone = 2,
            lines = listOf(MetrolinkLine.BLUE, MetrolinkLine.PURPLE),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "stretford",
            name = "Stretford",
            primaryZone = 2,
            secondaryZone = 3,
            lines = listOf(MetrolinkLine.GREEN),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "sale",
            name = "Sale",
            primaryZone = 3,
            lines = listOf(MetrolinkLine.GREEN),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "ashton_under_lyne",
            name = "Ashton-under-Lyne",
            primaryZone = 3,
            lines = listOf(MetrolinkLine.PINK),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "east_didsbury",
            name = "East Didsbury",
            primaryZone = 3,
            lines = listOf(MetrolinkLine.PURPLE),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "altrincham",
            name = "Altrincham",
            primaryZone = 4,
            lines = listOf(MetrolinkLine.GREEN),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "manchester_airport",
            name = "Manchester Airport",
            primaryZone = 4,
            lines = listOf(MetrolinkLine.BLUE),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "wythenshawe_centre",
            name = "Wythenshawe Town Centre",
            primaryZone = 4,
            lines = listOf(MetrolinkLine.BLUE),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "bury",
            name = "Bury",
            primaryZone = 4,
            lines = listOf(MetrolinkLine.GREEN),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "rochdale_centre",
            name = "Rochdale Town Centre",
            primaryZone = 4,
            lines = listOf(MetrolinkLine.PURPLE),
            platforms = listOf("1", "2")
        ),
        MetrolinkStation(
            id = "eccles",
            name = "Eccles",
            primaryZone = 2,
            lines = listOf(MetrolinkLine.PINK),
            platforms = listOf("1", "2")
        )
    )

    fun getStation(id: String): MetrolinkStation {
        return stations.find { it.id == id } ?: defaultStation
    }

    /**
     * Determines all zones spanned between origin and destination.
     * Manchester Metrolink has 4 concentric tariff zones.
     */
    fun calculateZonesSpanned(origin: MetrolinkStation, destination: MetrolinkStation): Set<Int> {
        val minZone = min(origin.primaryZone, destination.primaryZone)
        val maxZone = max(origin.primaryZone, destination.primaryZone)
        val zones = (minZone..maxZone).toMutableSet()
        if (origin.secondaryZone != null) zones.add(origin.secondaryZone)
        if (destination.secondaryZone != null) zones.add(destination.secondaryZone)
        return zones
    }

    /**
     * Official Manchester Metrolink zonal fare engine (in pence).
     */
    fun calculateFare(
        origin: MetrolinkStation,
        destination: MetrolinkStation,
        ticketType: TicketType
    ): FareCalculationResult {
        val zones = calculateZonesSpanned(origin, destination)
        val zoneCount = zones.size.coerceIn(1, 4)

        val adultPence = when (zoneCount) {
            1 -> when (ticketType) {
                TicketType.SINGLE -> 140
                TicketType.DAY_TRAVELCARD_OFF_PEAK -> 190
                TicketType.DAY_TRAVELCARD_ANYTIME -> 280
                TicketType.WEEKEND_TRAVELCARD -> 420
            }
            2 -> when (ticketType) {
                TicketType.SINGLE -> 280
                TicketType.DAY_TRAVELCARD_OFF_PEAK -> 350
                TicketType.DAY_TRAVELCARD_ANYTIME -> 440
                TicketType.WEEKEND_TRAVELCARD -> 500
            }
            3 -> when (ticketType) {
                TicketType.SINGLE -> 380
                TicketType.DAY_TRAVELCARD_OFF_PEAK -> 440
                TicketType.DAY_TRAVELCARD_ANYTIME -> 600
                TicketType.WEEKEND_TRAVELCARD -> 620
            }
            else -> when (ticketType) {
                TicketType.SINGLE -> 460
                TicketType.DAY_TRAVELCARD_OFF_PEAK -> 490
                TicketType.DAY_TRAVELCARD_ANYTIME -> 710
                TicketType.WEEKEND_TRAVELCARD -> 680
            }
        }

        val childPence = (adultPence * 0.50).toInt()
        val concessionPence = (adultPence * 0.50).toInt()

        return FareCalculationResult(
            origin = origin,
            destination = destination,
            zonesCrossed = zones,
            zoneCount = zoneCount,
            adultPricePence = adultPence,
            childPricePence = childPence,
            concessionPricePence = concessionPence
        )
    }

    fun calculateTotalPence(
        origin: MetrolinkStation,
        destination: MetrolinkStation,
        ticketType: TicketType,
        passengers: Map<PassengerCategory, Int>
    ): Int {
        val fare = calculateFare(origin, destination, ticketType)
        val adults = (passengers[PassengerCategory.ADULT] ?: 0).coerceAtLeast(0)
        val children = (passengers[PassengerCategory.CHILD] ?: 0).coerceAtLeast(0)
        val concessions = (passengers[PassengerCategory.CONCESSION] ?: 0).coerceAtLeast(0)

        val total = (adults * fare.adultPricePence) +
                (children * fare.childPricePence) +
                (concessions * fare.concessionPricePence)

        return total
    }

    fun getTicketProductsComparison(
        origin: MetrolinkStation,
        destination: MetrolinkStation
    ): List<TicketProduct> {
        val zones = calculateZonesSpanned(origin, destination)
        return listOf(
            TicketProduct(
                type = TicketType.SINGLE,
                origin = origin,
                destination = destination,
                zonesCovered = zones,
                unitPricePence = calculateFare(origin, destination, TicketType.SINGLE).adultPricePence,
                savingsNote = "Best for one-way journeys"
            ),
            TicketProduct(
                type = TicketType.DAY_TRAVELCARD_OFF_PEAK,
                origin = origin,
                destination = destination,
                zonesCovered = zones,
                unitPricePence = calculateFare(origin, destination, TicketType.DAY_TRAVELCARD_OFF_PEAK).adultPricePence,
                isRecommended = true,
                savingsNote = "Cheaper than 2 singles! Unlimited return"
            ),
            TicketProduct(
                type = TicketType.DAY_TRAVELCARD_ANYTIME,
                origin = origin,
                destination = destination,
                zonesCovered = zones,
                unitPricePence = calculateFare(origin, destination, TicketType.DAY_TRAVELCARD_ANYTIME).adultPricePence,
                savingsNote = "Unlimited travel anytime today"
            ),
            TicketProduct(
                type = TicketType.WEEKEND_TRAVELCARD,
                origin = origin,
                destination = destination,
                zonesCovered = zones,
                unitPricePence = calculateFare(origin, destination, TicketType.WEEKEND_TRAVELCARD).adultPricePence,
                savingsNote = "Unlimited Fri 18:00 to Mon 04:00"
            )
        )
    }

    fun getLiveDepartures(station: MetrolinkStation): List<TramDeparture> {
        return when (station.id) {
            "st_peters_square" -> listOf(
                TramDeparture("dep_1", MetrolinkLine.GREEN, "Altrincham", "Platform 1", 1, isDoubleTram = true),
                TramDeparture("dep_2", MetrolinkLine.BLUE, "Manchester Airport", "Platform 2", 3, isDoubleTram = true),
                TramDeparture("dep_3", MetrolinkLine.GREEN, "Bury (via Victoria)", "Platform 3", 5, isDoubleTram = true),
                TramDeparture("dep_4", MetrolinkLine.PURPLE, "Rochdale Town Centre", "Platform 3", 7, isDoubleTram = false),
                TramDeparture("dep_5", MetrolinkLine.TEAL, "MediaCityUK", "Platform 1", 9, isDoubleTram = false),
                TramDeparture("dep_6", MetrolinkLine.PINK, "Ashton-under-Lyne", "Platform 4", 12, isDoubleTram = true),
                TramDeparture("dep_7", MetrolinkLine.PURPLE, "East Didsbury", "Platform 2", 14, isDoubleTram = true)
            )
            "piccadilly" -> listOf(
                TramDeparture("p_1", MetrolinkLine.TEAL, "MediaCityUK", "Platform A", 2, isDoubleTram = false),
                TramDeparture("p_2", MetrolinkLine.PINK, "Eccles (via MediaCityUK)", "Platform A", 6, isDoubleTram = true),
                TramDeparture("p_3", MetrolinkLine.PINK, "Ashton-under-Lyne", "Platform B", 8, isDoubleTram = true)
            )
            "mediacityuk" -> listOf(
                TramDeparture("m_1", MetrolinkLine.TEAL, "Piccadilly", "Platform 1", 1, isDoubleTram = false),
                TramDeparture("m_2", MetrolinkLine.PINK, "Eccles", "Platform 1", 4, isDoubleTram = true),
                TramDeparture("m_3", MetrolinkLine.PINK, "Ashton-under-Lyne", "Platform 1", 11, isDoubleTram = true)
            )
            else -> listOf(
                TramDeparture("gen_1", station.lines.firstOrNull() ?: MetrolinkLine.GREEN, "City Centre (St Peter's Sq)", "Platform 1", 2, isDoubleTram = true),
                TramDeparture("gen_2", station.lines.firstOrNull() ?: MetrolinkLine.GREEN, "Altrincham", "Platform 2", 6, isDoubleTram = true),
                TramDeparture("gen_3", MetrolinkLine.BLUE, "Manchester Airport", "Platform 2", 11, isDoubleTram = false)
            )
        }
    }

    fun getServiceDisruptions(): List<ServiceDisruption> {
        return listOf(
            ServiceDisruption(
                id = "dis_1",
                line = MetrolinkLine.BLUE,
                severity = DisruptionSeverity.MINOR_DELAYS,
                title = "Airport Line: Minor delays",
                message = "Delays of up to 4 minutes due to essential signaling upgrade works near Cornbrook. Trams are operating normally through City Centre.",
                updatedAt = "3 mins ago"
            ),
            ServiceDisruption(
                id = "dis_2",
                line = MetrolinkLine.GREEN,
                severity = DisruptionSeverity.GOOD_SERVICE,
                title = "Altrincham & Bury Lines: Good Service",
                message = "Operating full double-unit frequency every 6 minutes.",
                updatedAt = "Just now"
            ),
            ServiceDisruption(
                id = "dis_3",
                line = MetrolinkLine.PINK,
                severity = DisruptionSeverity.GOOD_SERVICE,
                title = "Ashton & Eccles Lines: Good Service",
                message = "Regular service running on time.",
                updatedAt = "2 mins ago"
            )
        )
    }

    fun planJourney(origin: MetrolinkStation, destination: MetrolinkStation): JourneyPlanResult {
        val zones = calculateZonesSpanned(origin, destination)
        val zoneCount = zones.size
        val durationMins = (zoneCount * 8) + 4

        val sharedLines = origin.lines.intersect(destination.lines.toSet())
        val interchange = if (sharedLines.isEmpty()) {
            stations.firstOrNull { it.id == "cornbrook" || it.id == "st_peters_square" }
        } else null

        val steps = mutableListOf<JourneyStep>()
        if (interchange == null) {
            val line = sharedLines.firstOrNull() ?: origin.lines.first()
            steps.add(
                JourneyStep(
                    instruction = "Board ${line.lineName} tram towards ${destination.name}",
                    line = line,
                    stopsCount = max(1, zoneCount * 3),
                    intermediateStops = listOf("Calling at all intermediate stops")
                )
            )
        } else {
            steps.add(
                JourneyStep(
                    instruction = "Board ${origin.lines.first().lineName} at ${origin.name} towards ${interchange.name}",
                    line = origin.lines.first(),
                    stopsCount = 3,
                    intermediateStops = listOf("Cornbrook / City Centre link")
                )
            )
            steps.add(
                JourneyStep(
                    instruction = "Change platform at ${interchange.name} to ${destination.lines.first().lineName} towards ${destination.name}",
                    line = destination.lines.first(),
                    stopsCount = 4,
                    intermediateStops = listOf("Direct to ${destination.name}")
                )
            )
        }

        val recommendedTicket = if (zoneCount > 1) TicketType.DAY_TRAVELCARD_OFF_PEAK else TicketType.SINGLE
        val fare = calculateFare(origin, destination, recommendedTicket)

        return JourneyPlanResult(
            origin = origin,
            destination = destination,
            estimatedMinutes = durationMins,
            interchangeStation = interchange,
            steps = steps,
            zonesCrossed = zones,
            recommendedTicketType = recommendedTicket,
            sampleAdultFare = TicketProduct.formatPence(fare.adultPricePence)
        )
    }
}
