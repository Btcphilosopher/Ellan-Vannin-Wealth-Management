package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassPanel
import com.example.ui.theme.*

@Composable
fun HelpScreen(
    highContrast: Boolean,
    reachableMode: Boolean,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = if (reachableMode) Arrangement.Bottom else Arrangement.SpaceBetween
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0x22FFFFFF))
                        .testTag("help_back_btn")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }

                Column {
                    Text(
                        text = "Metrolink Help & Guidance",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 26.sp
                    )
                    Text(
                        text = "Everything you need to know about zones, tickets, and contactless travel",
                        color = MetrolinkTextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Content
        GlassPanel(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            highContrast = highContrast
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Topic 1: Buying a Ticket vs Contactless Tap-In/Tap-Out
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141619)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.CompareArrows, contentDescription = null, tint = MetrolinkYellow)
                                Text("Buying a Ticket vs. Tap-In / Tap-Out", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Text(
                                text = "• Buying a Ticket (This Kiosk): Gives you a fixed digital or printed travelcard with guaranteed validity before you board. Recommended if you travel in a group or want a paper receipt.\n" +
                                        "• Contactless Tap-in / Tap-out (Platform Readers): Simply tap your payment card/phone on the yellow smart readers on the platform BEFORE boarding and AFTER leaving your destination tram stop. The system automatically calculates the daily capped fare.",
                                color = MetrolinkTextSecondary,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                // Topic 2: Concentric Zone Tariff System
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141619)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.Layers, contentDescription = null, tint = MetrolinkYellow)
                                Text("Metrolink 4 Concentric Zones", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Text(
                                text = "Manchester Metrolink is divided into 4 concentric rings:\n" +
                                        "• Zone 1: City Centre (St Peter's Sq, Piccadilly, Victoria, Deansgate)\n" +
                                        "• Zone 2: Inner Ring (MediaCityUK, Trafford Bar, Salford Quays, Trafford Centre)\n" +
                                        "• Zone 3: Middle Suburbs (Sale, Ashton, East Didsbury, Brooklands)\n" +
                                        "• Zone 4: Outer Terminals (Manchester Airport, Altrincham, Bury, Rochdale)\n" +
                                        "Your fare is calculated strictly by the number of continuous zones your journey crosses.",
                                color = MetrolinkTextSecondary,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                // Topic 3: Accessibility & Assistance
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141619)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.Accessible, contentDescription = null, tint = MetrolinkYellow)
                                Text("Accessibility on Metrolink", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Text(
                                text = "• 100% Step-free: Every Metrolink platform is fully step-free from street level to tram floor.\n" +
                                        "• Wheelchair & Seated Mode: Tap 'Wheelchair / Seated Reach' in the bottom bar of this screen to lower all interactive buttons within easy reach.\n" +
                                        "• High Contrast / Sunlight Mode: Tap 'High Contrast' in the bottom bar for maximum visibility in direct sunlight.",
                                color = MetrolinkTextSecondary,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
