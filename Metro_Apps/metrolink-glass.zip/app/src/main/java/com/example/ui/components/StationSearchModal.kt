package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MetrolinkStation
import com.example.ui.theme.*

@Composable
fun StationSearchModal(
    isOpen: Boolean,
    isDestination: Boolean,
    currentSelection: MetrolinkStation,
    allStations: List<MetrolinkStation>,
    onSelectStation: (MetrolinkStation) -> Unit,
    onDismiss: () -> Unit,
    highContrast: Boolean = false
) {
    if (!isOpen) return

    var searchQuery by remember { mutableStateOf("") }
    var selectedZoneFilter by remember { mutableStateOf<Int?>(null) }

    val filteredStations = remember(searchQuery, selectedZoneFilter, allStations) {
        allStations.filter { station ->
            val matchesQuery = searchQuery.isBlank() ||
                    station.name.contains(searchQuery, ignoreCase = true)
            val matchesZone = selectedZoneFilter == null ||
                    station.primaryZone == selectedZoneFilter ||
                    station.secondaryZone == selectedZoneFilter
            matchesQuery && matchesZone
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xDD000000))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.94f)
                    .fillMaxHeight(0.92f)
                    .testTag("station_search_dialog"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = if (highContrast) Color.Black else MetrolinkSurfaceDark),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                        listOf(Color(0x66FFFFFF), Color(0x66FFFFFF))
                    )
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isDestination) "Select Destination Station" else "Select Origin Station",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp
                            )
                            Text(
                                text = "Search or select from 4 concentric Metrolink zones",
                                color = MetrolinkTextSecondary,
                                fontSize = 13.sp
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0x22FFFFFF))
                                .testTag("close_station_search_btn")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Search input display
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF16181C))
                            .border(1.5.dp, if (searchQuery.isNotEmpty()) MetrolinkYellow else Color(0x33FFFFFF), RoundedCornerShape(12.dp))
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = MetrolinkYellow, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (searchQuery.isEmpty()) "Tap on-screen keyboard below to type station name..." else searchQuery,
                            color = if (searchQuery.isEmpty()) MetrolinkTextMuted else Color.White,
                            fontSize = 16.sp,
                            fontWeight = if (searchQuery.isEmpty()) FontWeight.Normal else FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Zone Filter Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Filter Zone:", color = MetrolinkTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                        FilterChip(
                            selected = selectedZoneFilter == null,
                            onClick = { selectedZoneFilter = null },
                            label = { Text("All Zones") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MetrolinkYellow,
                                selectedLabelColor = MetrolinkTextDark
                            )
                        )

                        listOf(1, 2, 3, 4).forEach { zone ->
                            FilterChip(
                                selected = selectedZoneFilter == zone,
                                onClick = { selectedZoneFilter = if (selectedZoneFilter == zone) null else zone },
                                label = { Text("Zone $zone") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MetrolinkYellow,
                                    selectedLabelColor = MetrolinkTextDark
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Split view: Left = Filtered Station list; Right = Touch Keyboard
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Station List
                        LazyColumn(
                            modifier = Modifier
                                .weight(1.1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF131518))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (filteredStations.isEmpty()) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(32.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "No stations found matching '$searchQuery'",
                                            color = MetrolinkTextMuted,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }

                            items(filteredStations) { station ->
                                val isSelected = station.id == currentSelection.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) Color(0x33FFD200) else Color(0x18FFFFFF))
                                        .border(
                                            1.dp,
                                            if (isSelected) MetrolinkYellow else Color.Transparent,
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            onSelectStation(station)
                                            onDismiss()
                                        }
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(station.lines.firstOrNull()?.color ?: MetrolinkYellow)
                                        )
                                        Column {
                                            Text(
                                                text = station.name,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp
                                            )
                                            Text(
                                                text = station.lines.joinToString(" • ") { it.terminalStops.take(18) },
                                                color = MetrolinkTextMuted,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0x33FFFFFF))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = station.zoneDescription(),
                                            color = MetrolinkYellow,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        // On-Screen Accessible Touch Keyboard
                        Column(
                            modifier = Modifier
                                .weight(1.3f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF131518))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ON-SCREEN TOUCH KEYBOARD",
                                color = MetrolinkTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )

                            // Rows of Keys
                            val row1 = listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P")
                            val row2 = listOf("A", "S", "D", "F", "G", "H", "J", "K", "L")
                            val row3 = listOf("Z", "X", "C", "V", "B", "N", "M")

                            KeyRow(keys = row1) { key -> searchQuery += key }
                            KeyRow(keys = row2) { key -> searchQuery += key }
                            KeyRow(keys = row3) { key -> searchQuery += key }

                            // Bottom Controls: Space, Backspace, Clear
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { searchQuery = "" },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x33FFFFFF)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Clear", fontSize = 13.sp)
                                }

                                Button(
                                    onClick = { searchQuery += " " },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x44FFFFFF)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(2f)
                                ) {
                                    Text("Space", fontSize = 13.sp)
                                }

                                Button(
                                    onClick = { if (searchQuery.isNotEmpty()) searchQuery = searchQuery.dropLast(1) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MetrolinkError.copy(alpha = 0.6f)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1.2f)
                                ) {
                                    Icon(Icons.Default.Backspace, contentDescription = "Backspace", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KeyRow(
    keys: List<String>,
    onKeyPress: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        keys.forEach { key ->
            Button(
                onClick = { onKeyPress(key) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF22262E),
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(0.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
            ) {
                Text(text = key, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}
