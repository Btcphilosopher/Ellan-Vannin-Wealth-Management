package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TicketOrder
import com.example.ui.components.GlassPanel
import com.example.ui.theme.*

@Composable
fun PendingIssuanceScreen(
    order: TicketOrder?,
    referenceCode: String?,
    highContrast: Boolean,
    reachableMode: Boolean,
    onRetryIssuance: () -> Unit,
    onFinishAndReport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ref = referenceCode ?: "PEND-REF-7891"

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalArrangement = if (reachableMode) Arrangement.Bottom else Arrangement.SpaceBetween
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MetrolinkWarning),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.HourglassTop, contentDescription = null, tint = MetrolinkTextDark)
                }

                Column {
                    Text(
                        text = "Payment Confirmed • Ticket Pending",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 22.sp
                    )
                    Text(
                        text = "No duplicate charge will occur",
                        color = MetrolinkSuccess,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x33F59E0B))
                    .border(1.dp, MetrolinkWarning, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "RECOVERABLE TRANSACTION",
                    color = MetrolinkWarning,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Center Message Card
        GlassPanel(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            highContrast = highContrast
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.padding(vertical = 12.dp)
                ) {
                    Text(
                        text = "Your payment of ${order?.formattedTotal() ?: "fare"} was approved, but the digital ticket issuance server temporarily timed out.",
                        color = Color.White,
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.SemiBold
                    )

                    // Reference Box
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF141619))
                            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("RECOVERY REFERENCE NUMBER", color = MetrolinkTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(ref, color = MetrolinkYellow, fontWeight = FontWeight.Black, fontSize = 28.sp, letterSpacing = 2.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Order #${order?.orderId ?: "MLG"}", color = MetrolinkTextMuted, fontSize = 12.sp)
                    }

                    // Assurance Card
                    Card(
                        modifier = Modifier.fillMaxWidth(0.92f),
                        colors = CardDefaults.cardColors(containerColor = Color(0x18FFFFFF)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Default.SupportAgent, contentDescription = null, tint = MetrolinkYellow, modifier = Modifier.size(32.dp))
                            Column {
                                Text("Do Not Pay Again", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    "Tap 'Retry Issuance Now' below to immediately fetch your pass, or show this reference number to Metrolink customer service staff at the platform.",
                                    color = MetrolinkTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                // Bottom Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    OutlinedButton(
                        onClick = onFinishAndReport,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                    ) {
                        Text("Finish & Keep Reference", fontSize = 13.sp)
                    }

                    Button(
                        onClick = onRetryIssuance,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MetrolinkYellow,
                            contentColor = MetrolinkTextDark
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.4f)
                            .height(52.dp)
                            .testTag("retry_issuance_btn")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("RETRY ISSUANCE NOW", fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
