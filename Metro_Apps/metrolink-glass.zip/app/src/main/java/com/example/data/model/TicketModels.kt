package com.example.data.model

enum class TicketType(
    val title: String,
    val subtitle: String,
    val validityDescription: String
) {
    SINGLE(
        title = "1 Single",
        subtitle = "One-way journey",
        validityDescription = "Valid for 90 minutes from purchase. Single continuous journey in selected zones."
    ),
    DAY_TRAVELCARD_OFF_PEAK(
        title = "1-Day Off-Peak",
        subtitle = "Travelcard after 09:30",
        validityDescription = "Valid from 09:30 Monday-Friday and all day weekends until 04:00 the following morning. Unlimited travel."
    ),
    DAY_TRAVELCARD_ANYTIME(
        title = "1-Day Any-Time",
        subtitle = "Unlimited all-day",
        validityDescription = "Valid immediately for unlimited journeys in selected zones until 04:00 the following morning."
    ),
    WEEKEND_TRAVELCARD(
        title = "Weekend Pass",
        subtitle = "Fri 18:00 – Mon 04:00",
        validityDescription = "Unlimited travel from 18:00 Friday through 04:00 Monday across selected zones."
    )
}

enum class PassengerCategory(
    val label: String,
    val note: String
) {
    ADULT("Adult", "Ages 16+"),
    CHILD("Child", "Ages 5–15 (Under 5s free)"),
    CONCESSION("Concession", "ENCTS pass / TfGM permit")
}

data class FareCalculationResult(
    val origin: MetrolinkStation,
    val destination: MetrolinkStation,
    val zonesCrossed: Set<Int>,
    val zoneCount: Int,
    val adultPricePence: Int,
    val childPricePence: Int,
    val concessionPricePence: Int
)

data class TicketProduct(
    val type: TicketType,
    val origin: MetrolinkStation,
    val destination: MetrolinkStation,
    val zonesCovered: Set<Int>,
    val unitPricePence: Int,
    val isRecommended: Boolean = false,
    val savingsNote: String? = null
) {
    fun formattedUnitPrice(): String = formatPence(unitPricePence)

    companion object {
        fun formatPence(pence: Int): String {
            val pounds = pence / 100
            val p = pence % 100
            return "£$pounds.${p.toString().padStart(2, '0')}"
        }
    }
}
