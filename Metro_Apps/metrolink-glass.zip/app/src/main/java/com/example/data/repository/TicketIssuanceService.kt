package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.delay
import java.util.UUID

interface TicketIssuanceAdapter {
    suspend fun issueTicket(order: TicketOrder, paymentAttempt: PaymentAttempt): Result<IssuedTicket>
    suspend fun recoverPendingIssuance(orderId: String, referenceCode: String): Result<IssuedTicket>
    suspend fun printPhysicalReceipt(ticket: IssuedTicket): Boolean
}

class SimulatedTicketIssuanceService : TicketIssuanceAdapter {

    // Cache of issued tickets by orderId
    private val issuedTicketsMap = mutableMapOf<String, IssuedTicket>()
    var simulateIssuanceFailureNext: Boolean = false

    override suspend fun issueTicket(
        order: TicketOrder,
        paymentAttempt: PaymentAttempt
    ): Result<IssuedTicket> {
        delay(400) // simulated processing delay

        if (simulateIssuanceFailureNext) {
            simulateIssuanceFailureNext = false
            return Result.failure(
                TicketIssuanceException(
                    message = "Ticket token server timeout or paper jam. Payment was confirmed.",
                    pendingReferenceCode = "PEND-" + UUID.randomUUID().toString().take(6).uppercase()
                )
            )
        }

        val now = System.currentTimeMillis()
        val validityDurationMs = when (order.ticketType) {
            TicketType.SINGLE -> 90L * 60 * 1000 // 90 mins
            TicketType.DAY_TRAVELCARD_OFF_PEAK, TicketType.DAY_TRAVELCARD_ANYTIME -> 24L * 60 * 60 * 1000
            TicketType.WEEKEND_TRAVELCARD -> 72L * 60 * 60 * 1000
        }

        val ticketNumber = "TKT-" + (10000000..99999999).random()
        val qrPayload = "https://metrolink.tfgm.com/pass/v1?tkt=$ticketNumber&ord=${order.orderId}&auth=${paymentAttempt.authCode ?: "AUTH"}&valid=${now + validityDurationMs}"

        val ticket = IssuedTicket(
            ticketNumber = ticketNumber,
            orderId = order.orderId,
            qrPayload = qrPayload,
            originName = order.origin.name,
            destinationName = order.destination.name,
            zonesDescription = order.origin.zoneDescription() + " to " + order.destination.zoneDescription(),
            ticketTypeName = order.ticketType.title,
            passengerSummary = order.passengerBreakdownString(),
            totalPaidPence = order.totalPence,
            issuedAtTimestamp = now,
            validUntilTimestamp = now + validityDurationMs,
            authCode = paymentAttempt.authCode ?: "DEMO-AUTH",
            isDemoWatermark = true
        )

        issuedTicketsMap[order.orderId] = ticket
        return Result.success(ticket)
    }

    override suspend fun recoverPendingIssuance(
        orderId: String,
        referenceCode: String
    ): Result<IssuedTicket> {
        delay(700)
        val now = System.currentTimeMillis()
        val ticket = IssuedTicket(
            ticketNumber = "REC-" + (10000000..99999999).random(),
            orderId = orderId,
            qrPayload = "https://metrolink.tfgm.com/pass/recovered?ref=$referenceCode&ord=$orderId",
            originName = "St Peter's Square",
            destinationName = "Metrolink Network",
            zonesDescription = "Network Zones",
            ticketTypeName = "Recovered Travelcard",
            passengerSummary = "1 Passenger",
            totalPaidPence = 0,
            issuedAtTimestamp = now,
            validUntilTimestamp = now + (24L * 60 * 60 * 1000),
            authCode = referenceCode,
            isDemoWatermark = true
        )
        issuedTicketsMap[orderId] = ticket
        return Result.success(ticket)
    }

    override suspend fun printPhysicalReceipt(ticket: IssuedTicket): Boolean {
        delay(1200) // thermal printer simulation
        return true
    }
}

class TicketIssuanceException(
    override val message: String,
    val pendingReferenceCode: String
) : Exception(message)
