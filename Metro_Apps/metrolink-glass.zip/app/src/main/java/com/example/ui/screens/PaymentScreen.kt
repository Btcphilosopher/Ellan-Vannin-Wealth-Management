package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentAttempt
import com.example.data.model.PaymentDeclineReason
import com.example.data.model.PaymentReaderState
import com.example.data.model.TicketOrder
import com.example.ui.components.ContactlessPaymentTarget
import com.example.ui.components.GlassPanel
import com.example.ui.components.SimulatedReaderTestTray
import com.example.ui.theme.*

@Composable
fun PaymentScreen(
    order: TicketOrder?,
    readerState: PaymentReaderState,
    currentAttempt: PaymentAttempt?,
    highContrast: Boolean,
    reachableMode: Boolean,
    isIssuanceFailureArmed: Boolean,
    onApprove: () -> Unit,
    onDecline: (PaymentDeclineReason) -> Unit,
    onTimeout: () -> Unit,
    onInterrupted: () -> Unit,
    onReconcile: () -> Unit,
    onToggleIssuanceFailure: () -> Unit,
    onCancelPayment: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (order == null) return

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = if (reachableMode) Arrangement.Bottom else Arrangement.SpaceBetween
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                IconButton(
                    onClick = onCancelPayment,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0x22FFFFFF))
                        .testTag("cancel_payment_top_btn")
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel", tint = Color.White)
                }

                Column {
                    Text(
                        text = "Contactless Payment",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 26.sp
                    )
                    Text(
                        text = "Order #${order.orderId} • Amount locked at ${order.formattedTotal()}",
                        color = MetrolinkTextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            Button(
                onClick = onCancelPayment,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0x33FFFFFF)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Cancel Transaction", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Center: Interactive Glass NFC Reader Target
        GlassPanel(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            highContrast = highContrast
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                ContactlessPaymentTarget(
                    readerState = readerState,
                    amountText = order.formattedTotal(),
                    declineReason = currentAttempt?.declineReason
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Bottom: Hardware Emulation / Testing Tray
        SimulatedReaderTestTray(
            readerState = readerState,
            onApprove = onApprove,
            onDecline = onDecline,
            onTimeout = onTimeout,
            onInterrupted = onInterrupted,
            onReconcile = onReconcile,
            onToggleIssuanceFailure = onToggleIssuanceFailure,
            isIssuanceFailureArmed = isIssuanceFailureArmed
        )
    }
}
