package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MetrolinkStation
import com.example.data.model.ServiceDisruption
import com.example.ui.theme.*

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    highContrast: Boolean = false,
    borderWidth: Dp = 1.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val backgroundColor = if (highContrast) {
        MetrolinkGlassOpaque
    } else {
        MetrolinkGlassPanel
    }

    val borderColor = if (highContrast) {
        Color(0x66FFFFFF)
    } else {
        MetrolinkGlassBorder
    }

    Box(
        modifier = modifier
            .clip(shape)
            .background(backgroundColor)
            .border(borderWidth, borderColor, shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun MetrolinkKioskHeader(
    currentStation: MetrolinkStation,
    timeString: String,
    highContrast: Boolean,
    activeDisruption: ServiceDisruption?,
    onStationClick: () -> Unit,
    onDisruptionClick: () -> Unit,
    onResetClick: () -> Unit,
    onDiagnosticsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand & Location
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Metrolink M / Bee Symbol Pill
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MetrolinkYellow)
                        .clickable { onResetClick() }
                        .testTag("metrolink_home_logo"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "M",
                        color = MetrolinkTextDark,
                        fontWeight = FontWeight.Black,
                        fontSize = 26.sp
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "METROLINK GLASS",
                            color = MetrolinkYellow,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            letterSpacing = 1.5.sp
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0x33FFD200))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "CONCEPT KIOSK",
                                color = MetrolinkYellow,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Current Station pill
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onStationClick() }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Current stop",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = currentStation.name,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MetrolinkSurfaceCard)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = currentStation.zoneDescription(),
                                color = MetrolinkTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Change station",
                            tint = MetrolinkTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Right: Live Clock & Quick Diagnostics
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Live Clock
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = timeString,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Shelter Glass #STP-02 • Online",
                        color = MetrolinkTextMuted,
                        fontSize = 11.sp
                    )
                }

                // Diagnostics Gear Icon
                IconButton(
                    onClick = onDiagnosticsClick,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x22FFFFFF))
                        .testTag("kiosk_diagnostics_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Kiosk Diagnostics",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Active Disruption or Notice Banner
        if (activeDisruption != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x33F59E0B))
                    .border(1.dp, Color(0x66F59E0B), RoundedCornerShape(10.dp))
                    .clickable { onDisruptionClick() }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Service notice",
                    tint = MetrolinkWarning,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "${activeDisruption.title} — ${activeDisruption.message}",
                    color = Color.White,
                    fontSize = 12.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "Details ›",
                    color = MetrolinkYellow,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun AccessibleFooterBar(
    highContrast: Boolean,
    reachableMode: Boolean,
    sessionSeconds: Int,
    onToggleHighContrast: () -> Unit,
    onToggleReachableMode: () -> Unit,
    onExtendSession: () -> Unit,
    onResetSession: () -> Unit,
    onHelpClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xEE121417))
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(0.dp))
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .windowInsetsPadding(WindowInsets.navigationBars),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Accessibility quick toggles
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // High contrast button
            FilterChip(
                selected = highContrast,
                onClick = onToggleHighContrast,
                label = {
                    Text(
                        text = if (highContrast) "Sunlight Mode: ON" else "High Contrast",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = if (highContrast) Icons.Default.LightMode else Icons.Default.BrightnessMedium,
                        contentDescription = "Toggle high contrast",
                        modifier = Modifier.size(16.dp)
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MetrolinkYellow,
                    selectedLabelColor = MetrolinkTextDark,
                    selectedLeadingIconColor = MetrolinkTextDark
                ),
                modifier = Modifier.testTag("toggle_high_contrast_btn")
            )

            // Seated / Reachable mode
            FilterChip(
                selected = reachableMode,
                onClick = onToggleReachableMode,
                label = {
                    Text(
                        text = if (reachableMode) "Lowered UI: Active" else "Wheelchair / Seated Reach",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Accessible,
                        contentDescription = "Wheelchair reachable view",
                        modifier = Modifier.size(16.dp)
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MetrolinkYellow,
                    selectedLabelColor = MetrolinkTextDark,
                    selectedLeadingIconColor = MetrolinkTextDark
                ),
                modifier = Modifier.testTag("toggle_reachable_mode_btn")
            )

            // Help & Guidance
            OutlinedButton(
                onClick = onHelpClick,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(Color(0x44FFFFFF), Color(0x44FFFFFF)))),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                modifier = Modifier.testTag("footer_help_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.HelpOutline,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Help", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Session reset and countdown
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onExtendSession() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (sessionSeconds <= 15) MetrolinkError else MetrolinkSuccess)
                )
                Text(
                    text = "Session: ${sessionSeconds}s (Tap to extend)",
                    color = MetrolinkTextSecondary,
                    fontSize = 11.sp
                )
            }

            Button(
                onClick = onResetSession,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0x33FFFFFF),
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("reset_kiosk_session_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Start Over", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
