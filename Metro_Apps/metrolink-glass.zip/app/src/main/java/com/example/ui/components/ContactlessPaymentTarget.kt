package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentDeclineReason
import com.example.data.model.PaymentReaderState
import com.example.ui.theme.*

@Composable
fun ContactlessPaymentTarget(
    readerState: PaymentReaderState,
    amountText: String,
    declineReason: PaymentDeclineReason?,
    modifier: Modifier = Modifier
) {
    // Pulse animation for READY_TO_TAP
    val infiniteTransition = rememberInfiniteTransition(label = "nfc_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Spin animation for PROCESSING
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin"
    )

    val targetColor = when (readerState) {
        PaymentReaderState.READY_TO_TAP -> MetrolinkYellow
        PaymentReaderState.READING -> Color(0xFF38BDF8) // Bright Cyan
        PaymentReaderState.PROCESSING -> MetrolinkWarning
        PaymentReaderState.APPROVED -> MetrolinkSuccess
        PaymentReaderState.DECLINED, PaymentReaderState.TIMED_OUT, PaymentReaderState.CONNECTION_INTERRUPTED -> MetrolinkError
        PaymentReaderState.PAYMENT_STATUS_UNKNOWN -> Color(0xFFF97316)
        PaymentReaderState.CANCELLED -> MetrolinkTextMuted
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Physical glass reader badge
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0x22FFFFFF))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = "CONTACTLESS GLASS SENSOR AREA",
                color = MetrolinkTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Circular Glass Target with concentric LED arcs
        Box(
            modifier = Modifier
                .size(240.dp)
                .scale(if (readerState == PaymentReaderState.READY_TO_TAP) pulseScale else 1f)
                .testTag("contactless_nfc_target"),
            contentAlignment = Alignment.Center
        ) {
            // Background Canvas for concentric arcs and glass sheen
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.minDimension / 2f

                // Outer ambient glow ring
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(targetColor.copy(alpha = 0.25f), Color.Transparent),
                        center = center,
                        radius = radius
                    ),
                    radius = radius,
                    center = center
                )

                // Concentric boundary circles
                drawCircle(
                    color = targetColor.copy(alpha = 0.5f),
                    radius = radius - 8.dp.toPx(),
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )

                drawCircle(
                    color = targetColor.copy(alpha = 0.2f),
                    radius = radius - 24.dp.toPx(),
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // If processing, draw rotating segment
                if (readerState == PaymentReaderState.PROCESSING || readerState == PaymentReaderState.READING) {
                    drawArc(
                        color = targetColor,
                        startAngle = rotation,
                        sweepAngle = 90f,
                        useCenter = false,
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round),
                        topLeft = Offset(16.dp.toPx(), 16.dp.toPx()),
                        size = androidx.compose.ui.geometry.Size(
                            size.width - 32.dp.toPx(),
                            size.height - 32.dp.toPx()
                        )
                    )
                }
            }

            // Core center circle
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                targetColor.copy(alpha = 0.35f),
                                MetrolinkCharcoal
                            )
                        )
                    )
                    .border(2.dp, targetColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                when (readerState) {
                    PaymentReaderState.READY_TO_TAP -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Contactless,
                                contentDescription = "Contactless payment wave",
                                tint = MetrolinkYellow,
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "TAP HERE",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                    PaymentReaderState.READING -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Nfc,
                                contentDescription = "Reading card",
                                tint = targetColor,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "READING...",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                    PaymentReaderState.PROCESSING -> {
                        CircularProgressIndicator(
                            color = MetrolinkYellow,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                    PaymentReaderState.APPROVED -> {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Approved",
                            tint = MetrolinkSuccess,
                            modifier = Modifier.size(64.dp)
                        )
                    }
                    PaymentReaderState.DECLINED -> {
                        Icon(
                            imageVector = Icons.Default.Cancel,
                            contentDescription = "Declined",
                            tint = MetrolinkError,
                            modifier = Modifier.size(64.dp)
                        )
                    }
                    PaymentReaderState.TIMED_OUT -> {
                        Icon(
                            imageVector = Icons.Default.TimerOff,
                            contentDescription = "Timed out",
                            tint = MetrolinkError,
                            modifier = Modifier.size(54.dp)
                        )
                    }
                    PaymentReaderState.CONNECTION_INTERRUPTED -> {
                        Icon(
                            imageVector = Icons.Default.WifiOff,
                            contentDescription = "Interrupted",
                            tint = MetrolinkError,
                            modifier = Modifier.size(54.dp)
                        )
                    }
                    PaymentReaderState.PAYMENT_STATUS_UNKNOWN -> {
                        Icon(
                            imageVector = Icons.Default.Help,
                            contentDescription = "Reconciling",
                            tint = Color(0xFFF97316),
                            modifier = Modifier.size(54.dp)
                        )
                    }
                    PaymentReaderState.CANCELLED -> {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cancelled",
                            tint = MetrolinkTextMuted,
                            modifier = Modifier.size(54.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // State Text & Amount
        when (readerState) {
            PaymentReaderState.READY_TO_TAP -> {
                Text(
                    text = "Tap phone or card here",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Hold contactless card, Apple Pay, or Google Pay firmly against this pane",
                    color = MetrolinkTextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Total to charge: $amountText",
                    color = MetrolinkYellow,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp
                )
            }
            PaymentReaderState.READING -> {
                Text(
                    text = "Reading card...",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
                Text(
                    text = "Please do not remove card from glass area",
                    color = MetrolinkTextSecondary,
                    fontSize = 13.sp
                )
            }
            PaymentReaderState.PROCESSING -> {
                Text(
                    text = "Authorising payment...",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
                Text(
                    text = "Communicating with certified unattended payment terminal",
                    color = MetrolinkTextSecondary,
                    fontSize = 13.sp
                )
            }
            PaymentReaderState.APPROVED -> {
                Text(
                    text = "Payment Approved",
                    color = MetrolinkSuccess,
                    fontWeight = FontWeight.Black,
                    fontSize = 22.sp
                )
                Text(
                    text = "$amountText paid successfully. Generating ticket...",
                    color = MetrolinkTextSecondary,
                    fontSize = 14.sp
                )
            }
            PaymentReaderState.DECLINED -> {
                Text(
                    text = "Payment Declined",
                    color = MetrolinkError,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = declineReason?.displayMessage ?: "Card was declined. Please try another payment method.",
                    color = MetrolinkTextSecondary,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }
            PaymentReaderState.TIMED_OUT -> {
                Text(
                    text = "Reader Timed Out",
                    color = MetrolinkError,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
                Text(
                    text = "No card was detected within 30 seconds. No charge was made.",
                    color = MetrolinkTextSecondary,
                    fontSize = 13.sp
                )
            }
            PaymentReaderState.CONNECTION_INTERRUPTED -> {
                Text(
                    text = "Connection Interrupted",
                    color = MetrolinkError,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
                Text(
                    text = "Terminal lost communication with secure banking host. Idempotency protection active.",
                    color = MetrolinkTextSecondary,
                    fontSize = 13.sp
                )
            }
            PaymentReaderState.PAYMENT_STATUS_UNKNOWN -> {
                Text(
                    text = "Reconciling Transaction",
                    color = Color(0xFFF97316),
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
                Text(
                    text = "Verifying transaction status with payment gateway before allowing re-tap.",
                    color = MetrolinkTextSecondary,
                    fontSize = 13.sp
                )
            }
            PaymentReaderState.CANCELLED -> {
                Text(
                    text = "Payment Cancelled",
                    color = MetrolinkTextMuted,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            }
        }
    }
}

/**
 * Clearly labelled simulated payment reader test controls for demonstrating the kiosk terminal.
 */
@Composable
fun SimulatedReaderTestTray(
    readerState: PaymentReaderState,
    onApprove: () -> Unit,
    onDecline: (PaymentDeclineReason) -> Unit,
    onTimeout: () -> Unit,
    onInterrupted: () -> Unit,
    onReconcile: () -> Unit,
    onToggleIssuanceFailure: () -> Unit,
    isIssuanceFailureArmed: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("simulated_reader_tray"),
        colors = CardDefaults.cardColors(containerColor = Color(0xF0181A20)),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(Color(0x33FFD200), Color(0x33FFD200))))
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(MetrolinkYellow)
                    )
                    Text(
                        text = "DEMONSTRATION NFC READER CONTROLS",
                        color = MetrolinkYellow,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = "Hardware Emulation Mode",
                    color = MetrolinkTextMuted,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action triggers row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Approve button (Main positive flow)
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MetrolinkSuccess,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1.3f)
                        .testTag("sim_tap_approve_btn")
                ) {
                    Icon(Icons.Default.PhoneIphone, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Tap: Approve", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                // Decline button
                OutlinedButton(
                    onClick = { onDecline(PaymentDeclineReason.INSUFFICIENT_FUNDS) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MetrolinkError),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sim_tap_decline_btn")
                ) {
                    Text("Decline", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                // Timeout
                OutlinedButton(
                    onClick = onTimeout,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(0.9f)
                        .testTag("sim_timeout_btn")
                ) {
                    Text("Timeout", fontSize = 12.sp)
                }

                // Interrupted
                OutlinedButton(
                    onClick = onInterrupted,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sim_interrupted_btn")
                ) {
                    Text("Interrupted", fontSize = 12.sp)
                }

                // Reconcile if in unknown or error state
                if (readerState == PaymentReaderState.PAYMENT_STATUS_UNKNOWN || readerState == PaymentReaderState.CONNECTION_INTERRUPTED) {
                    Button(
                        onClick = onReconcile,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF97316)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1.1f)
                            .testTag("sim_reconcile_btn")
                    ) {
                        Text("Reconcile", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Test issuance failure recovery toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Test Recovery: Simulate ticket-issuance failure after successful charge",
                    color = MetrolinkTextSecondary,
                    fontSize = 11.sp
                )
                Switch(
                    checked = isIssuanceFailureArmed,
                    onCheckedChange = { onToggleIssuanceFailure() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MetrolinkYellow,
                        checkedTrackColor = MetrolinkYellow.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.testTag("toggle_issuance_failure_switch")
                )
            }
        }
    }
}
