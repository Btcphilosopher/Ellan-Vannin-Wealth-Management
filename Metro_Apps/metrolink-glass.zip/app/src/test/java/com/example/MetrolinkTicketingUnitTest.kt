package com.example

import com.example.data.model.*
import com.example.data.repository.MetrolinkRepository
import com.example.data.repository.SimulatedPaymentReaderAdapter
import com.example.data.repository.SimulatedTicketIssuanceService
import com.example.data.repository.TicketIssuanceException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class MetrolinkTicketingUnitTest {

    private lateinit var repository: MetrolinkRepository
    private lateinit var paymentAdapter: SimulatedPaymentReaderAdapter
    private lateinit var ticketService: SimulatedTicketIssuanceService

    @Before
    fun setUp() {
        repository = MetrolinkRepository()
        paymentAdapter = SimulatedPaymentReaderAdapter()
        ticketService = SimulatedTicketIssuanceService()
    }

    @Test
    fun `test zone calculation between St Peter's Square and MediaCityUK spans Zones 1 and 2`() {
        val stPeters = repository.getStation("st_peters_square") // Zone 1
        val mediaCity = repository.getStation("mediacityuk")     // Zone 2

        val zones = repository.calculateZonesSpanned(stPeters, mediaCity)
        assertEquals(setOf(1, 2), zones)
        assertEquals(2, zones.size)
    }

    @Test
    fun `test zone calculation between St Peter's Square and Manchester Airport spans Zones 1 to 4`() {
        val stPeters = repository.getStation("st_peters_square") // Zone 1
        val airport = repository.getStation("manchester_airport") // Zone 4

        val zones = repository.calculateZonesSpanned(stPeters, airport)
        assertEquals(setOf(1, 2, 3, 4), zones)
        assertEquals(4, zones.size)
    }

    @Test
    fun `test fare calculation for 2 Zones Adult vs Child fares`() {
        val stPeters = repository.getStation("st_peters_square")
        val mediaCity = repository.getStation("mediacityuk")

        val singleFare = repository.calculateFare(stPeters, mediaCity, TicketType.SINGLE)
        assertEquals(280, singleFare.adultPricePence) // £2.80
        assertEquals(140, singleFare.childPricePence) // £1.40 (50%)

        val dayFare = repository.calculateFare(stPeters, mediaCity, TicketType.DAY_TRAVELCARD_OFF_PEAK)
        assertEquals(350, dayFare.adultPricePence)    // £3.50
        assertEquals(175, dayFare.childPricePence)    // £1.75
    }

    @Test
    fun `test multiple passenger fare aggregation`() {
        val stPeters = repository.getStation("st_peters_square")
        val mediaCity = repository.getStation("mediacityuk")

        // 2 Adults + 1 Child for 1-Day Off-Peak (£3.50 * 2 + £1.75 = £8.75 = 875p)
        val passengers = mapOf(
            PassengerCategory.ADULT to 2,
            PassengerCategory.CHILD to 1,
            PassengerCategory.CONCESSION to 0
        )
        val totalPence = repository.calculateTotalPence(
            stPeters,
            mediaCity,
            TicketType.DAY_TRAVELCARD_OFF_PEAK,
            passengers
        )
        assertEquals(875, totalPence)
    }

    @Test
    fun `test order state machine locks amount and creates idempotency key`() = runBlocking {
        val origin = repository.getStation("st_peters_square")
        val destination = repository.getStation("mediacityuk")

        val order = TicketOrder(
            origin = origin,
            destination = destination,
            ticketType = TicketType.DAY_TRAVELCARD_OFF_PEAK,
            passengerCounts = mapOf(PassengerCategory.ADULT to 1),
            totalPence = 350,
            state = OrderState.LOCKED
        )

        assertEquals(OrderState.LOCKED, order.state)
        assertTrue(order.idempotencyKey.startsWith("IDEM-"))

        val attemptResult = paymentAdapter.startPayment(order)
        assertTrue(attemptResult.isSuccess)
        val attempt = attemptResult.getOrThrow()
        assertEquals(PaymentReaderState.READY_TO_TAP, attempt.readerState)
        assertEquals(350, attempt.amountPence)
    }

    @Test
    fun `test duplicate payment prevention via idempotency key`() = runBlocking {
        val origin = repository.getStation("st_peters_square")
        val destination = repository.getStation("piccadilly")

        val order = TicketOrder(
            origin = origin,
            destination = destination,
            ticketType = TicketType.SINGLE,
            passengerCounts = mapOf(PassengerCategory.ADULT to 1),
            totalPence = 140,
            state = OrderState.LOCKED
        )

        // First attempt approved
        paymentAdapter.startPayment(order)
        val approved = paymentAdapter.triggerApprove()
        assertEquals(PaymentReaderState.APPROVED, approved.readerState)
        assertTrue(paymentAdapter.isIdempotencyKeyApproved(order.idempotencyKey))

        // Second attempt with exact same idempotency key returns the existing approved record without charging again
        val duplicateAttemptResult = paymentAdapter.startPayment(order)
        assertTrue(duplicateAttemptResult.isSuccess)
        val duplicateAttempt = duplicateAttemptResult.getOrThrow()
        assertEquals(approved.attemptId, duplicateAttempt.attemptId)
        assertEquals(PaymentReaderState.APPROVED, duplicateAttempt.readerState)
    }

    @Test
    fun `test recoverable pending issuance without requiring customer to pay again`() = runBlocking {
        val origin = repository.getStation("st_peters_square")
        val destination = repository.getStation("altrincham")

        val order = TicketOrder(
            origin = origin,
            destination = destination,
            ticketType = TicketType.DAY_TRAVELCARD_ANYTIME,
            passengerCounts = mapOf(PassengerCategory.ADULT to 1),
            totalPence = 710,
            state = OrderState.LOCKED
        )

        paymentAdapter.startPayment(order)
        val approvedAttempt = paymentAdapter.triggerApprove()
        assertEquals(PaymentReaderState.APPROVED, approvedAttempt.readerState)

        // Arm failure to simulate temporary ticket token timeout
        ticketService.simulateIssuanceFailureNext = true
        val issueResult = ticketService.issueTicket(order, approvedAttempt)
        assertTrue(issueResult.isFailure)

        val exception = issueResult.exceptionOrNull() as TicketIssuanceException
        val referenceCode = exception.pendingReferenceCode
        assertTrue(referenceCode.startsWith("PEND-"))

        // Passenger transitions to pending issuance
        val pendingOrder = order.copy(
            state = OrderState.PENDING_ISSUANCE,
            pendingIssuanceRef = referenceCode
        )
        assertEquals(OrderState.PENDING_ISSUANCE, pendingOrder.state)

        // Customer retries issuance without re-initiating payment
        val recoveryResult = ticketService.recoverPendingIssuance(pendingOrder.orderId, referenceCode)
        assertTrue(recoveryResult.isSuccess)
        val recoveredTicket = recoveryResult.getOrThrow()
        assertTrue(recoveredTicket.ticketNumber.startsWith("REC-"))
        assertTrue(recoveredTicket.isDemoWatermark)
    }
}
