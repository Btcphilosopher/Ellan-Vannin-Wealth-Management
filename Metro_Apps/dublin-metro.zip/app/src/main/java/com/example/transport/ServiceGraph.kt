package com.example.transport

import com.example.core.Journey
import com.example.core.JourneyLeg
import com.example.core.TransportMode
import com.example.metrolink.MetroLinkData
import java.util.PriorityQueue

data class GraphNode(
    val id: String,
    val name: String,
    val mode: TransportMode,
    val latitude: Double,
    val longitude: Double,
    val isAccessible: Boolean = true
)

data class GraphEdge(
    val fromNodeId: String,
    val toNodeId: String,
    val mode: TransportMode,
    val costSeconds: Double,
    val distanceM: Int,
    val lineName: String,
    val intermediateStops: List<String> = emptyList(),
    val isAccessible: Boolean = true
)

object ServiceGraph {

    val NODES = mutableMapOf<String, GraphNode>()
    val ADJACENCY_LIST = mutableMapOf<String, MutableList<GraphEdge>>()

    init {
        // 1. Add MetroLink nodes from MetroLinkData
        for (station in MetroLinkData.STATIONS) {
            NODES[station.id] = GraphNode(
                id = station.id,
                name = station.name,
                mode = TransportMode.METROLINK,
                latitude = station.latitude,
                longitude = station.longitude,
                isAccessible = true // All new MetroLink facilities are 100% accessible
            )
        }

        // 2. Add extra non-metro nodes representing major transport hubs
        // Luas Red Line Nodes
        NODES["ST_LUAS_ABBEY"] = GraphNode("ST_LUAS_ABBEY", "Abbey Street (Luas Red)", TransportMode.LUAS, 53.3485, -6.2594, true)
        NODES["ST_LUAS_CONNOLLY"] = GraphNode("ST_LUAS_CONNOLLY", "Connolly Station (Luas/Rail)", TransportMode.LUAS, 53.3501, -6.2499, true)

        // DART Nodes
        NODES["ST_DART_CONNOLLY"] = GraphNode("ST_DART_CONNOLLY", "Connolly (DART)", TransportMode.DART, 53.3503, -6.2497, true)
        NODES["ST_DART_PEARSE"] = GraphNode("ST_DART_PEARSE", "Pearse (DART)", TransportMode.DART, 53.3435, -6.2478, true)
        NODES["ST_DART_TARA_ST"] = GraphNode("ST_DART_TARA_ST", "Tara Street (DART)", TransportMode.DART, 53.3472, -6.2541, true)

        // Dublin Bus major stops
        NODES["ST_BUS_TRINITY"] = GraphNode("ST_BUS_TRINITY", "Trinity College (Dublin Bus Stop)", TransportMode.DUBLIN_BUS, 53.3444, -6.2595, true)
        NODES["ST_BUS_AIRPORT_T1"] = GraphNode("ST_BUS_AIRPORT_T1", "Dublin Airport T1 Bus Stop", TransportMode.DUBLIN_BUS, 53.4270, -6.2415, true)
        NODES["ST_BUS_SWORDS_MAIN"] = GraphNode("ST_BUS_SWORDS_MAIN", "Swords Main St Bus Stop", TransportMode.DUBLIN_BUS, 53.4580, -6.2190, true)

        // --- EDGES ---
        
        // Helper to add bi-directional edge
        fun addEdge(
            fromId: String,
            toId: String,
            mode: TransportMode,
            durationSec: Double,
            distM: Int,
            line: String,
            stops: List<String> = emptyList(),
            accessible: Boolean = true
        ) {
            ADJACENCY_LIST.getOrPut(fromId) { mutableListOf() }.add(
                GraphEdge(fromId, toId, mode, durationSec, distM, line, stops, accessible)
            )
            ADJACENCY_LIST.getOrPut(toId) { mutableListOf() }.add(
                GraphEdge(toId, fromId, mode, durationSec, distM, line, stops.reversed(), accessible)
            )
        }

        // 1. MetroLink Edges (Swords -> Charlemont)
        // Average travel time is approx 1.5 - 2 mins between stations.
        addEdge("ST_SWORDS", "ST_SWORDS_CENTRAL", TransportMode.METROLINK, 110.0, 950, "MetroLink", listOf("Estuary Estuary Link"))
        addEdge("ST_SWORDS_CENTRAL", "ST_FOSTERSTOWN", TransportMode.METROLINK, 120.0, 1100, "MetroLink")
        addEdge("ST_FOSTERSTOWN", "ST_AIRPORT", TransportMode.METROLINK, 150.0, 1600, "MetroLink")
        addEdge("ST_AIRPORT", "ST_NORTHWOOD", TransportMode.METROLINK, 180.0, 2400, "MetroLink")
        addEdge("ST_NORTHWOOD", "ST_BALLYMUN", TransportMode.METROLINK, 110.0, 1100, "MetroLink")
        addEdge("ST_BALLYMUN", "ST_GRIFFITH_AVENUE", TransportMode.METROLINK, 130.0, 1300, "MetroLink")
        addEdge("ST_GRIFFITH_AVENUE", "ST_COLLINS_AVENUE", TransportMode.METROLINK, 90.0, 800, "MetroLink")
        addEdge("ST_COLLINS_AVENUE", "ST_DCU", TransportMode.METROLINK, 90.0, 750, "MetroLink")
        addEdge("ST_DCU", "ST_GLASNEVIN", TransportMode.METROLINK, 100.0, 900, "MetroLink")
        addEdge("ST_GLASNEVIN", "ST_MATER", TransportMode.METROLINK, 100.0, 850, "MetroLink")
        addEdge("ST_MATER", "ST_O_CONNELL_STREET", TransportMode.METROLINK, 110.0, 950, "MetroLink")
        addEdge("ST_O_CONNELL_STREET", "ST_TARA", TransportMode.METROLINK, 90.0, 750, "MetroLink")
        addEdge("ST_TARA", "ST_ST_STEPHENS_GREEN", TransportMode.METROLINK, 120.0, 1100, "MetroLink")
        addEdge("ST_ST_STEPHENS_GREEN", "ST_CHARLEMONT", TransportMode.METROLINK, 100.0, 850, "MetroLink")

        // 2. Luas Connections (Green Line / Red Line)
        // Luas Green Line
        addEdge("ST_CHARLEMONT", "ST_ST_STEPHENS_GREEN", TransportMode.LUAS, 150.0, 900, "Luas Green Line")
        addEdge("ST_ST_STEPHENS_GREEN", "ST_O_CONNELL_STREET", TransportMode.LUAS, 320.0, 1800, "Luas Green Line", listOf("Dawson", "Trinity", "Westmoreland", "O'Connell GPO"))
        
        // Luas Red Line
        addEdge("ST_LUAS_ABBEY", "ST_LUAS_CONNOLLY", TransportMode.LUAS, 180.0, 1100, "Luas Red Line", listOf("Busáras"))

        // 3. DART Edges
        addEdge("ST_DART_CONNOLLY", "ST_DART_TARA_ST", TransportMode.DART, 120.0, 900, "DART North/South Commuter")
        addEdge("ST_DART_TARA_ST", "ST_DART_PEARSE", TransportMode.DART, 110.0, 800, "DART North/South Commuter")

        // 4. Dublin Bus Edges (Representing key fast corridor connections)
        // Express Airport Bus to City Center (via Port Tunnel)
        addEdge("ST_BUS_AIRPORT_T1", "ST_O_CONNELL_STREET", TransportMode.DUBLIN_BUS, 900.0, 11000, "Dublin Bus 41 / 16", listOf("Drumcondra"))
        // Bus from Swords to Airport
        addEdge("ST_BUS_SWORDS_MAIN", "ST_BUS_AIRPORT_T1", TransportMode.DUBLIN_BUS, 480.0, 5000, "Dublin Bus 41")
        // Bus from Trinity to St Stephen's Green
        addEdge("ST_BUS_TRINITY", "ST_ST_STEPHENS_GREEN", TransportMode.DUBLIN_BUS, 180.0, 950, "Dublin Bus 140 / 83")

        // 5. Walking Interchange Connections (Transfer edges inside stations)
        // These represent physical connections with transfer times.
        addEdge("ST_TARA", "ST_DART_TARA_ST", TransportMode.WALKING, 120.0, 150, "Station Transfer Tunnel", emptyList(), true)
        addEdge("ST_O_CONNELL_STREET", "ST_LUAS_ABBEY", TransportMode.WALKING, 180.0, 220, "O'Connell St Walkway", emptyList(), true)
        addEdge("ST_O_CONNELL_STREET", "ST_BUS_TRINITY", TransportMode.WALKING, 420.0, 550, "Walk over Liffey", emptyList(), true)
        addEdge("ST_ST_STEPHENS_GREEN", "ST_BUS_TRINITY", TransportMode.WALKING, 480.0, 650, "Grafton St Walkway", emptyList(), true)
        addEdge("ST_AIRPORT", "ST_BUS_AIRPORT_T1", TransportMode.WALKING, 180.0, 200, "Airport Forecourt Walkway", emptyList(), true)
        addEdge("ST_SWORDS", "ST_BUS_SWORDS_MAIN", TransportMode.WALKING, 240.0, 300, "Swords Main St Access", emptyList(), true)
    }

    // --- DIJKSTRA Multimodal Router ---

    data class PathState(
        val nodeId: String,
        val costSeconds: Double,
        val edgeHistory: List<GraphEdge>
    ) : Comparable<PathState> {
        override fun compareTo(other: PathState): Int = costSeconds.compareTo(other.costSeconds)
    }

    fun findRoute(
        fromId: String,
        toId: String,
        accessibilityRequired: Boolean = false,
        disruptedStops: Set<String> = emptySet()
    ): Journey? {
        val startNode = NODES[fromId] ?: return null
        val endNode = NODES[toId] ?: return null

        val minCostMap = mutableMapOf<String, Double>()
        val queue = PriorityQueue<PathState>()

        minCostMap[fromId] = 0.0
        queue.add(PathState(fromId, 0.0, emptyList()))

        var bestState: PathState? = null

        while (queue.isNotEmpty()) {
            val current = queue.poll()

            if (current.costSeconds > (minCostMap[current.nodeId] ?: Double.MAX_VALUE)) continue

            if (current.nodeId == toId) {
                bestState = current
                break
            }

            val edges = ADJACENCY_LIST[current.nodeId] ?: emptyList()
            for (edge in edges) {
                // Filter disrupted stops if necessary
                if (disruptedStops.contains(edge.toNodeId) && edge.mode == TransportMode.METROLINK) continue

                // Check accessibility constraint
                if (accessibilityRequired) {
                    val targetNodeObj = NODES[edge.toNodeId]
                    if (targetNodeObj != null && !targetNodeObj.isAccessible) continue
                    if (!edge.isAccessible) continue
                }

                // Calculate transfer penalty: if mode changes, add 3 minutes (180 seconds) transfer overhead
                var extraPenalty = 0.0
                if (current.edgeHistory.isNotEmpty()) {
                    val lastEdge = current.edgeHistory.last()
                    if (lastEdge.mode != edge.mode) {
                        extraPenalty = 180.0 // 3 minutes penalty for swapping transport modes
                    }
                }

                val newCost = current.costSeconds + edge.costSeconds + extraPenalty
                val existingCost = minCostMap[edge.toNodeId] ?: Double.MAX_VALUE

                if (newCost < existingCost) {
                    minCostMap[edge.toNodeId] = newCost
                    val newHistory = current.edgeHistory + edge
                    queue.add(PathState(edge.toNodeId, newCost, newHistory))
                }
            }
        }

        val state = bestState ?: return null

        // Convert path history of Edges to Journey & JourneyLeg models
        val legs = mutableListOf<JourneyLeg>()
        var currentLegMode: TransportMode? = null
        var originName = ""
        var lineName = ""
        var currentLegDuration = 0.0
        var currentLegStops = mutableListOf<String>()
        var startOfLegNodeId = ""
        var distanceMeters = 0

        for (i in state.edgeHistory.indices) {
            val edge = state.edgeHistory[i]
            if (currentLegMode == null) {
                currentLegMode = edge.mode
                startOfLegNodeId = edge.fromNodeId
                originName = NODES[edge.fromNodeId]?.name ?: ""
                lineName = edge.lineName
                currentLegDuration = 0.0
                distanceMeters = 0
                currentLegStops.clear()
            }

            currentLegDuration += edge.costSeconds
            distanceMeters += edge.distanceM
            currentLegStops.addAll(edge.intermediateStops)
            currentLegStops.add(NODES[edge.toNodeId]?.name ?: "")

            // If it's the last edge or the next edge switches mode / line, finish the leg
            val isLast = i == state.edgeHistory.size - 1
            val nextSwitches = !isLast && (state.edgeHistory[i + 1].mode != currentLegMode || state.edgeHistory[i + 1].lineName != lineName)

            if (isLast || nextSwitches) {
                val destNodeName = NODES[edge.toNodeId]?.name ?: ""
                val durationMin = Math.ceil(currentLegDuration / 60.0).toInt()

                legs.add(
                    JourneyLeg(
                        mode = currentLegMode,
                        lineName = lineName,
                        originStationName = originName,
                        destinationStationName = destNodeName,
                        durationMin = durationMin,
                        stopCount = currentLegStops.size,
                        instructions = getInstructionForLeg(currentLegMode, lineName, originName, destNodeName, durationMin),
                        intermediateStops = currentLegStops.distinct(),
                        distanceM = distanceMeters
                    )
                )
                currentLegMode = null
            }
        }

        // Calculate cost based on Leap adult fare caps
        // TFI 90-min fare is €2.00
        val uniqueModes = legs.map { it.mode }.filter { it != TransportMode.WALKING && it != TransportMode.CYCLING }
        val totalCost = if (uniqueModes.isEmpty()) 0.0 else 2.00 // Standard flat Dublin adult 90-minute fare

        val totalDurationMin = Math.ceil(state.costSeconds / 60.0).toInt()

        val explanation = when {
            accessibilityRequired -> "Accessible route strictly avoiding stairs, optimized with elevator connections."
            legs.size <= 2 -> "Direct connection. Fastest journey with fewest transfers."
            else -> "Multi-modal optimal transit route. Saved approx 15 mins vs driving."
        }

        return Journey(
            id = "JR_${fromId}_${toId}_${System.currentTimeMillis()}",
            originName = startNode.name,
            destinationName = endNode.name,
            totalDurationMin = totalDurationMin,
            legs = legs,
            totalCostEuro = totalCost,
            explanation = explanation,
            isAccessible = legs.all { leg ->
                // Walking legs inside our database are step-free.
                // MetroLink is fully accessible. Luas and DART in our model are accessible.
                true
            }
        )
    }

    private fun getInstructionForLeg(
        mode: TransportMode,
        line: String,
        from: String,
        to: String,
        duration: Int
    ): String {
        return when (mode) {
            TransportMode.METROLINK -> "Board MetroLink at $from towards $to ($duration mins, high-frequency continuous service)."
            TransportMode.LUAS -> "Take Luas ($line) from $from to $to (runs every 6 mins)."
            TransportMode.DART -> "Board southbound/northbound DART commuter train at $from to $to."
            TransportMode.DUBLIN_BUS -> "Board Dublin Bus ($line) at $from to $to."
            TransportMode.WALKING -> "Walk approx. $from to $to ($duration mins through designated transit walkways)."
            else -> "Travel via $mode from $from to $to."
        }
    }
}
