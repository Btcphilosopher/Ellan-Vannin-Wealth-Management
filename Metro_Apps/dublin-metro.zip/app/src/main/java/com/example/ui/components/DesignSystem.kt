package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.Elevator
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.AlertSeverity
import com.example.core.Departure
import com.example.core.Journey
import com.example.core.ServiceAlert
import com.example.core.Station
import com.example.core.Train
import com.example.core.TransportMode
import com.example.ui.theme.CopperAccent
import com.example.ui.theme.DublinDarkGreen
import com.example.ui.theme.DublinLightStone
import com.example.ui.theme.DublinStone
import com.example.ui.theme.MutedRed
import com.example.ui.theme.DublinBlue
import com.example.ui.theme.DublinNavy

// --- TRANSPORT MODE CHIP ---
@Composable
fun TransportModeChip(
    mode: TransportMode,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(mode.color.copy(alpha = 0.15f))
            .border(1.dp, mode.color.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = mode.getIcon(),
            contentDescription = mode.displayName,
            tint = mode.color,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = mode.displayName,
            color = mode.color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// --- ACCESSIBILITY BADGE ---
@Composable
fun AccessibilityBadge(
    isStepFree: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isStepFree) Color(0xFFE8F5E9) else Color(0xFFFFEBEE))
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Accessible,
            contentDescription = if (isStepFree) "Step-Free" else "Limited Access",
            tint = if (isStepFree) Color(0xFF2E7D32) else MutedRed,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(2.dp))
        Text(
            text = if (isStepFree) "STEP-FREE" else "STAIRS ONLY",
            color = if (isStepFree) Color(0xFF2E7D32) else MutedRed,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black
        )
    }
}

// --- METRO STATION CARD ---
@Composable
fun MetroStationCard(
    station: Station,
    departures: List<Departure>,
    isFavorite: Boolean,
    onFavoriteToggle: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("station_card_${station.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = station.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = DublinDarkGreen
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TransportModeChip(station.mode)
                        if (station.connections.contains(TransportMode.DART)) {
                            TransportModeChip(TransportMode.DART)
                        }
                        if (station.connections.contains(TransportMode.LUAS)) {
                            TransportModeChip(TransportMode.LUAS)
                        }
                    }
                }
                
                IconButton(onClick = onFavoriteToggle) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) CopperAccent else DublinStone
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(8.dp))

            // Embedded departures preview
            if (departures.isEmpty()) {
                Text(
                    text = "No active departures scheduled.",
                    fontSize = 12.sp,
                    color = DublinStone
                )
            } else {
                Text(
                    text = "NEXT DEPARTURES",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = DublinStone,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    departures.take(2).forEach { dep ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(CopperAccent)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "to ${dep.destination}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Text(
                                text = if (dep.minutesAway == 0) "Due" else "${dep.minutesAway} min",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = DublinDarkGreen
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- DEPARTURE BOARD ---
@Composable
fun DepartureBoard(
    stationName: String,
    departures: List<Departure>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DublinNavy)
            .padding(16.dp)
    ) {
        // Board Header
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = stationName.uppercase(),
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 1.5.sp
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color.Green)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "LIVE DATA",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Green,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
        Spacer(modifier = Modifier.height(10.dp))

        if (departures.isEmpty()) {
            Text(
                text = "No immediate departures found. Please check timetables.",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 14.sp,
                modifier = Modifier.padding(vertical = 10.dp)
            )
        } else {
            // Header Row
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "DESTINATION", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row {
                    Text(text = "PLATFORM", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(24.dp))
                    Text(text = "TIME / DUE", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Departures Entries
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                departures.forEach { dep ->
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = dep.destination,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Service ${dep.status.label} • ${dep.occupancyPercent}% full",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 11.sp
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(24.dp)
                                    .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                            ) {
                                Text(
                                    text = dep.platform,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(28.dp))
                            Text(
                                text = if (dep.minutesAway == 0) "DUE" else "${dep.minutesAway}m",
                                color = if (dep.minutesAway <= 3) CopperAccent else Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.width(60.dp),
                                textAlign = TextAlign.End
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- JOURNEY CARD ---
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JourneyCard(
    journey: Journey,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${journey.totalDurationMin}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = DublinDarkGreen
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "MIN",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = DublinStone
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "€${String.format("%.2f", journey.totalCostEuro)}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = CopperAccent
                    )
                    Text(
                        text = "TFI Leap Fare",
                        fontSize = 10.sp,
                        color = DublinStone
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Route representation
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                journey.legs.forEachIndexed { idx, leg ->
                    TransportModeChip(leg.mode)
                    if (idx < journey.legs.size - 1) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "then",
                            tint = DublinStone,
                            modifier = Modifier
                                .size(14.dp)
                                .align(Alignment.CenterVertically)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = journey.explanation,
                fontSize = 12.sp,
                color = DublinStone,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(4.dp))

            if (journey.isAccessible) {
                AccessibilityBadge(isStepFree = true)
            }
        }
    }
}

// --- SERVICE ALERT CARD ---
@Composable
fun ServiceAlertCard(
    alert: ServiceAlert,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = when (alert.severity) {
                AlertSeverity.SEVERE -> MutedRed.copy(alpha = 0.08f)
                AlertSeverity.MINOR -> Color(0xFFFFF3E0)
                AlertSeverity.INFO -> Color(0xFFE0F7FA)
            },
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        border = border(alert.severity),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(14.dp)) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Alert",
                tint = when (alert.severity) {
                    AlertSeverity.SEVERE -> MutedRed
                    AlertSeverity.MINOR -> Color(0xFFEF6C00)
                    AlertSeverity.INFO -> Color(0xFF00838F)
                },
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = alert.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = when (alert.severity) {
                        AlertSeverity.SEVERE -> MutedRed
                        AlertSeverity.MINOR -> Color(0xFFD84315)
                        AlertSeverity.INFO -> Color(0xFF006064)
                    }
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = alert.description,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = Color.Black.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "ALTERNATIVE ADVICE:",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = DublinStone
                )
                Text(
                    text = alert.alternativeAdvice,
                    fontSize = 12.sp,
                    color = DublinStone
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Active: ${alert.startTime} – ${alert.expectedEnd} • Updated ${alert.lastUpdated}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = DublinStone.copy(alpha = 0.8f)
                )
            }
        }
    }
}

private fun border(severity: AlertSeverity): androidx.compose.foundation.BorderStroke {
    val color = when (severity) {
        AlertSeverity.SEVERE -> MutedRed.copy(alpha = 0.4f)
        AlertSeverity.MINOR -> Color(0xFFFFB74D)
        AlertSeverity.INFO -> Color(0xFF4DD0E1)
    }
    return androidx.compose.foundation.BorderStroke(1.dp, color)
}

// --- FARE CARD ---
@Composable
fun FareCard(
    leapBalance: Double,
    dailyCap: Double,
    weeklyCap: Double,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "TFI LEAP INTEGRATION",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = DublinStone
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(text = "CURRENT BALANCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DublinStone)
                    Text(text = "€${String.format("%.2f", leapBalance)}", fontSize = 32.sp, fontWeight = FontWeight.Black, color = DublinDarkGreen)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF8ADAA5))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(text = "LEAP ACTIVE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DublinDarkGreen)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(12.dp))

            // Caps Progress
            Text(
                text = "DAILY FARE CAP PROGRESS (€6.00 CAP)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DublinStone
            )
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.1f))
            ) {
                val ratio = (dailyCap / 6.00).coerceIn(0.0, 1.0).toFloat()
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(ratio)
                        .clip(RoundedCornerShape(4.dp))
                        .background(CopperAccent)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "€${String.format("%.2f", dailyCap)} spent today", fontSize = 11.sp, color = DublinStone)
                Text(text = "${(dailyCap / 6.00 * 100).toInt()}% cap reached", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CopperAccent)
            }
        }
    }
}

// --- TICKET CARD ---
@Composable
fun TicketCard(
    ticketCode: String,
    origin: String,
    destination: String,
    passengerType: String,
    status: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = DublinDarkGreen,
            contentColor = Color.White
        ),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "METROLINK MOBILE PASS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    color = Color.White.copy(alpha = 0.7f)
                )
                Text(
                    text = passengerType.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = CopperAccent
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(text = "FROM", fontSize = 9.sp, color = Color.White.copy(alpha = 0.5f))
                    Text(text = origin, fontSize = 18.sp, fontWeight = FontWeight.Black)
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "to",
                    tint = CopperAccent,
                    modifier = Modifier.size(20.dp)
                )
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "TO", fontSize = 9.sp, color = Color.White.copy(alpha = 0.5f))
                    Text(text = destination, fontSize = 18.sp, fontWeight = FontWeight.Black)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(text = "TOKEN ID", fontSize = 9.sp, color = Color.White.copy(alpha = 0.5f))
                    Text(text = ticketCode, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = status.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

// --- STATION WAYFINDING MAP ---
@Composable
fun StationMap(
    station: Station,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DublinLightStone)
            .border(1.dp, DublinStone.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "STATION WAYFINDING SCHEMATIC",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DublinStone,
                letterSpacing = 1.sp
            )
            Icon(
                imageVector = Icons.Default.Elevator,
                contentDescription = "Lift",
                tint = DublinDarkGreen,
                modifier = Modifier.size(16.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Simple structural diagram drawing inside a Canvas
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .background(Color.White, RoundedCornerShape(8.dp))
                .border(1.dp, DublinStone.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
        ) {
            val width = size.width
            val height = size.height

            // Levels markers
            val levelStreetY = height * 0.15f
            val levelConcourseY = height * 0.5f
            val levelPlatformY = height * 0.85f

            // Draw level dash lines
            drawLine(Color(0xFFE0E0E0), Offset(20f, levelStreetY), Offset(width - 20f, levelStreetY), strokeWidth = 2f)
            drawLine(Color(0xFFE0E0E0), Offset(20f, levelConcourseY), Offset(width - 20f, levelConcourseY), strokeWidth = 2f)
            drawLine(Color(0xFFE0E0E0), Offset(20f, levelPlatformY), Offset(width - 20f, levelPlatformY), strokeWidth = 2f)

            // Draw lift shaft
            val shaftX = width * 0.25f
            drawLine(DublinStone, Offset(shaftX, levelStreetY), Offset(shaftX, levelPlatformY), strokeWidth = 4f)
            drawCircle(DublinDarkGreen, radius = 8f, center = Offset(shaftX, levelStreetY))
            drawCircle(DublinDarkGreen, radius = 8f, center = Offset(shaftX, levelConcourseY))
            drawCircle(DublinDarkGreen, radius = 8f, center = Offset(shaftX, levelPlatformY))

            // Draw stairs diagonal
            val stairsStartStartX = width * 0.5f
            val stairsStartEndX = width * 0.7f
            drawLine(DublinStone, Offset(stairsStartStartX, levelStreetY), Offset(stairsStartEndX, levelConcourseY), strokeWidth = 3f)
            drawLine(DublinStone, Offset(stairsStartEndX, levelConcourseY), Offset(stairsStartStartX, levelPlatformY), strokeWidth = 3f)

            // Draw trains icons or platform tracks
            val trackY = levelPlatformY + 10f
            drawLine(Color.DarkGray, Offset(10f, trackY), Offset(width - 10f, trackY), strokeWidth = 6f)
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Legend details
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(text = "STREET LEVEL", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DublinStone)
                Text(text = "Entrances A & B", fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "CONCOURSE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DublinStone)
                Text(text = "Ticket Hall", fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(text = "PLATFORMS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DublinStone)
                Text(text = "Deep Level -3", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = DublinDarkGreen)
            }
        }
    }
}

// --- METRO ROUTE MAP (TRANSIT DIAGRAM) ---
@Composable
fun MetroMap(
    stations: List<Station>,
    activeTrains: List<Train>,
    selectedStationId: String?,
    onStationSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .border(1.dp, DublinStone.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "METROLINK DIAGRAM ROUTE MAP",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DublinStone,
                letterSpacing = 1.sp
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFFE8F5E9))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(text = "LIVE POSITION", fontSize = 8.sp, fontWeight = FontWeight.Black, color = Color(0xFF2E7D32))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Linear transit line map
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            stations.forEachIndexed { index, station ->
                val isSelected = station.id == selectedStationId
                val hasTrain = activeTrains.any { it.currentStationId == station.id }
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onStationSelect(station.id) }
                        .padding(vertical = 2.dp)
                ) {
                    // Line node graphic
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.width(36.dp)
                    ) {
                        // Background line segment
                        if (index < stations.size - 1) {
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(48.dp)
                                    .background(DublinDarkGreen)
                                    .align(Alignment.TopCenter)
                                    .offset(y = 12.dp)
                            )
                        }

                        // The node circle itself
                        Box(
                            modifier = Modifier
                                .size(if (isSelected) 18.dp else 12.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) CopperAccent else DublinDarkGreen)
                                .border(2.dp, Color.White, CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Station Details
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = station.name,
                            fontSize = if (isSelected) 16.sp else 14.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                            color = if (isSelected) CopperAccent else Color.Black
                        )
                        if (station.id == "ST_AIRPORT") {
                            Text(text = "✈ Direct Connections to T1 & T2", fontSize = 10.sp, color = DublinBlue, fontWeight = FontWeight.Bold)
                        } else if (station.connections.contains(TransportMode.DART)) {
                            Text(text = "Interchange: DART & Irish Rail", fontSize = 10.sp, color = DublinStone)
                        } else if (station.connections.contains(TransportMode.LUAS)) {
                            Text(text = "Interchange: Luas Green Line", fontSize = 10.sp, color = DublinStone)
                        }
                    }

                    // Display if train is approaching or stopped here
                    if (hasTrain) {
                        val trainObj = activeTrains.first { it.currentStationId == station.id }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFE0F7FA))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Train,
                                contentDescription = "Train at station",
                                tint = DublinBlue,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "TRAIN",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = DublinBlue
                            )
                        }
                    }
                }
            }
        }
    }
}
