package com.example.metrolink

import com.example.core.Platform
import com.example.core.Station
import com.example.core.StationEntrance
import com.example.core.StationFacility
import com.example.core.TransportMode

object MetroLinkData {

    val STATIONS = listOf(
        Station(
            id = "ST_SWORDS",
            name = "Swords",
            mode = TransportMode.METROLINK,
            latitude = 53.4601,
            longitude = -6.2185,
            distanceToAirportKm = 5.2,
            entrances = listOf(
                StationEntrance("EN_SWORDS_A", "Estuary Main Entrance", true, "Direct step-free escalator & lift down to concourse", 53.4602, -6.2183),
                StationEntrance("EN_SWORDS_B", "Balheary Road Entrance", false, "Stairs access, close to Swords Estuary Park", 53.4600, -6.2187)
            ),
            platforms = listOf(
                Platform("PL_SWORDS_1", "1", "Southbound (Charlemont)", "Level -1 (Ground)", true)
            ),
            facilities = listOf(StationFacility.TICKETING, StationFacility.BIKE_PARKING, StationFacility.WIFI, StationFacility.CAR_PARK),
            connections = listOf(TransportMode.DUBLIN_BUS),
            description = "The northern terminal of MetroLink, serving Swords Estuary and north county Dublin commuter networks."
        ),
        Station(
            id = "ST_SWORDS_CENTRAL",
            name = "Swords Central",
            mode = TransportMode.METROLINK,
            latitude = 53.4533,
            longitude = -6.2212,
            distanceToAirportKm = 4.1,
            entrances = listOf(
                StationEntrance("EN_SC_A", "Pavilions Shopping Centre Entrance", true, "Direct access into the shopping centre mall via concourse lift", 53.4534, -6.2209),
                StationEntrance("EN_SC_B", "Main Street Entrance", true, "Step-free ramp and lift down to the ticketing lobby", 53.4531, -6.2215)
            ),
            platforms = listOf(
                Platform("PL_SC_1", "1", "Southbound (Charlemont)", "Underground Level -1", true),
                Platform("PL_SC_2", "2", "Northbound (Swords)", "Underground Level -1", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.WIFI),
            connections = listOf(TransportMode.DUBLIN_BUS),
            description = "Serving the dense retail and business core of Swords, right next to the Pavilions Shopping Centre."
        ),
        Station(
            id = "ST_FOSTERSTOWN",
            name = "Fosterstown",
            mode = TransportMode.METROLINK,
            latitude = 53.4421,
            longitude = -6.2255,
            distanceToAirportKm = 2.8,
            entrances = listOf(
                StationEntrance("EN_FOST_A", "R132 West Side", true, "Ramp and lift from Swords Road west", 53.4423, -6.2253),
                StationEntrance("EN_FOST_B", "Boroimhe Link Road", false, "Stairway to platform concourse", 53.4419, -6.2257)
            ),
            platforms = listOf(
                Platform("PL_FOST_1", "1", "Southbound (Charlemont)", "Elevated Level 1", true),
                Platform("PL_FOST_2", "2", "Northbound (Swords)", "Elevated Level 1", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.TICKETING, StationFacility.BIKE_PARKING, StationFacility.WIFI),
            connections = listOf(TransportMode.DUBLIN_BUS),
            description = "Serving the business park, local residential developments, and airport long-term parking areas."
        ),
        Station(
            id = "ST_AIRPORT",
            name = "Dublin Airport",
            mode = TransportMode.METROLINK,
            latitude = 53.4264,
            longitude = -6.2407,
            distanceToAirportKm = 0.0,
            entrances = listOf(
                StationEntrance("EN_AP_T1", "Terminal 1 Arrivals Court", true, "Direct step-free high-speed elevators & travelators under Terminal 1", 53.4268, -6.2402),
                StationEntrance("EN_AP_T2", "Terminal 2 Link Bridge", true, "Pristine architectural glass corridor directly connected to Terminal 2", 53.4259, -6.2411)
            ),
            platforms = listOf(
                Platform("PL_AP_1", "1", "Southbound (Charlemont)", "Deep Underground Level -3", true),
                Platform("PL_AP_2", "2", "Northbound (Swords)", "Deep Underground Level -3", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.TOILETS, StationFacility.WIFI, StationFacility.DEFIBRILLATOR),
            connections = listOf(TransportMode.DUBLIN_BUS, TransportMode.WALKING),
            description = "Providing high-speed, 20-minute rail connectivity directly into the arrivals and departures of Dublin Airport Terminal 1 & 2."
        ),
        Station(
            id = "ST_NORTHWOOD",
            name = "Northwood",
            mode = TransportMode.METROLINK,
            latitude = 53.4012,
            longitude = -6.2482,
            distanceToAirportKm = 3.5,
            entrances = listOf(
                StationEntrance("EN_NW_A", "Northwood Business Park Entrance", true, "Step-free plaza entrance", 53.4015, -6.2480),
                StationEntrance("EN_NW_B", "Santry Road Entrance", true, "Direct escalator and stairways", 53.4009, -6.2484)
            ),
            platforms = listOf(
                Platform("PL_NW_1", "1", "Southbound (Charlemont)", "Underground Level -1", true),
                Platform("PL_NW_2", "2", "Northbound (Swords)", "Underground Level -1", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.BIKE_PARKING, StationFacility.WIFI),
            connections = listOf(TransportMode.DUBLIN_BUS),
            description = "Serving Northwood, Santry, local businesses, and dense high-quality residential communities."
        ),
        Station(
            id = "ST_BALLYMUN",
            name = "Ballymun",
            mode = TransportMode.METROLINK,
            latitude = 53.3912,
            longitude = -6.2642,
            distanceToAirportKm = 5.0,
            entrances = listOf(
                StationEntrance("EN_BM_A", "Ballymun Civic Plaza", true, "Integrated step-free plaza entrance", 53.3914, -6.2640),
                StationEntrance("EN_BM_B", "Main Street East Side", false, "Stairway to underground lobby", 53.3910, -6.2644)
            ),
            platforms = listOf(
                Platform("PL_BM_1", "1", "Southbound (Charlemont)", "Underground Level -2", true),
                Platform("PL_BM_2", "2", "Northbound (Swords)", "Underground Level -2", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.TOILETS, StationFacility.WIFI),
            connections = listOf(TransportMode.DUBLIN_BUS),
            description = "Serving the heart of Ballymun civic square, council chambers, shopping streets, and the surrounding residential developments."
        ),
        Station(
            id = "ST_GRIFFITH_AVENUE",
            name = "Griffith Avenue",
            mode = TransportMode.METROLINK,
            latitude = 53.3802,
            longitude = -6.2655,
            distanceToAirportKm = 6.4,
            entrances = listOf(
                StationEntrance("EN_GA_A", "Mobhi Road West Side", true, "Step-free ramp", 53.3804, -6.2653),
                StationEntrance("EN_GA_B", "Griffith Avenue South Side", false, "Stairs access only", 53.3800, -6.2657)
            ),
            platforms = listOf(
                Platform("PL_GA_1", "1", "Southbound (Charlemont)", "Underground Level -2", true),
                Platform("PL_GA_2", "2", "Northbound (Swords)", "Underground Level -2", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.BIKE_PARKING, StationFacility.WIFI),
            connections = listOf(TransportMode.DUBLIN_BUS),
            description = "Serving the famous, tree-lined avenue of Griffith, local GAA clubs, residential zones, and schools."
        ),
        Station(
            id = "ST_COLLINS_AVENUE",
            name = "Collins Avenue",
            mode = TransportMode.METROLINK,
            latitude = 53.3725,
            longitude = -6.2662,
            distanceToAirportKm = 7.3,
            entrances = listOf(
                StationEntrance("EN_CA_A", "Collins Avenue Corner", true, "Ramp and lift", 53.3727, -6.2660),
                StationEntrance("EN_CA_B", "Our Lady's Church Side", false, "Stairs to platform concourse", 53.3723, -6.2664)
            ),
            platforms = listOf(
                Platform("PL_CA_1", "1", "Southbound (Charlemont)", "Underground Level -2", true),
                Platform("PL_CA_2", "2", "Northbound (Swords)", "Underground Level -2", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.WIFI),
            connections = listOf(TransportMode.DUBLIN_BUS),
            description = "Serving the outer suburbs, providing connections for students and residents along Collins Avenue."
        ),
        Station(
            id = "ST_DCU",
            name = "DCU",
            mode = TransportMode.METROLINK,
            latitude = 53.3665,
            longitude = -6.2671,
            distanceToAirportKm = 8.0,
            entrances = listOf(
                StationEntrance("EN_DCU_A", "DCU Campus East Entrance", true, "Step-free ramp directly connected to the campus boulevard", 53.3668, -6.2668),
                StationEntrance("EN_DCU_B", "Albert College Park Entrance", true, "Scenic step-free entryway through Albert College parklands", 53.3662, -6.2674)
            ),
            platforms = listOf(
                Platform("PL_DCU_1", "1", "Southbound (Charlemont)", "Underground Level -2", true),
                Platform("PL_DCU_2", "2", "Northbound (Swords)", "Underground Level -2", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.BIKE_PARKING, StationFacility.WIFI, StationFacility.DEFIBRILLATOR),
            connections = listOf(TransportMode.DUBLIN_BUS),
            description = "The principal station for Dublin City University, facilitating easy transit for over 18,000 students and staff."
        ),
        Station(
            id = "ST_GLASNEVIN",
            name = "Glasnevin",
            mode = TransportMode.METROLINK,
            latitude = 53.3615,
            longitude = -6.2731,
            distanceToAirportKm = 8.9,
            entrances = listOf(
                StationEntrance("EN_GN_A", "Prospect Road Entrance", true, "Main multi-modal transfer hub concourse with full accessibility", 53.3618, -6.2729),
                StationEntrance("EN_GN_B", "Irish Rail Transfer Bridge", true, "Direct escalators to Irish Rail & DART commuter platforms", 53.3612, -6.2733)
            ),
            platforms = listOf(
                Platform("PL_GN_1", "1", "Southbound (Charlemont)", "Deep Underground Level -3", true),
                Platform("PL_GN_2", "2", "Northbound (Swords)", "Deep Underground Level -3", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.TOILETS, StationFacility.BIKE_PARKING, StationFacility.WIFI, StationFacility.DEFIBRILLATOR),
            connections = listOf(TransportMode.IRISH_RAIL, TransportMode.DART, TransportMode.DUBLIN_BUS),
            description = "A massive key interchange hub. Connecting MetroLink directly to Irish Rail Western Commuter lines, future DART networks, and Glasnevin."
        ),
        Station(
            id = "ST_MATER",
            name = "Mater",
            mode = TransportMode.METROLINK,
            latitude = 53.3575,
            longitude = -6.2675,
            distanceToAirportKm = 9.4,
            entrances = listOf(
                StationEntrance("EN_MA_A", "Mater Misericordiae Hospital Plaza", true, "Direct step-free high-speed elevator link from Hospital forecourt", 53.3577, -6.2672),
                StationEntrance("EN_MA_B", "Eccles Street Entrance", true, "Stairs and escalator, serving local medical facilities", 53.3573, -6.2678)
            ),
            platforms = listOf(
                Platform("PL_MA_1", "1", "Southbound (Charlemont)", "Underground Level -2", true),
                Platform("PL_MA_2", "2", "Northbound (Swords)", "Underground Level -2", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.WIFI, StationFacility.DEFIBRILLATOR),
            connections = listOf(TransportMode.DUBLIN_BUS),
            description = "Serving the Mater Hospital, Eccles Street, and surrounding inner-city Dublin neighborhoods."
        ),
        Station(
            id = "ST_O_CONNELL_STREET",
            name = "O'Connell Street",
            mode = TransportMode.METROLINK,
            latitude = 53.3512,
            longitude = -6.2605,
            distanceToAirportKm = 10.3,
            entrances = listOf(
                StationEntrance("EN_OCS_A", "O'Connell St Upper (Carlton)", true, "Integrated landmark glass pavilion entrance with elevators", 53.3514, -6.2602),
                StationEntrance("EN_OCS_B", "Henry Street Corner", true, "Direct escalator and lift, serving Dublin's primary retail avenue", 53.3509, -6.2608)
            ),
            platforms = listOf(
                Platform("PL_OCS_1", "1", "Southbound (Charlemont)", "Underground Level -2", true),
                Platform("PL_OCS_2", "2", "Northbound (Swords)", "Underground Level -2", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.WIFI, StationFacility.DEFIBRILLATOR),
            connections = listOf(TransportMode.LUAS, TransportMode.DUBLIN_BUS),
            description = "The central metropolitan retail core station, intersecting with Luas Green Line and numerous central bus networks."
        ),
        Station(
            id = "ST_TARA",
            name = "Tara",
            mode = TransportMode.METROLINK,
            latitude = 53.3468,
            longitude = -6.2543,
            distanceToAirportKm = 11.1,
            entrances = listOf(
                StationEntrance("EN_TA_A", "Tara Street Irish Rail Concourse", true, "Direct indoor step-free escalator & elevator tunnel to DART", 53.3470, -6.2540),
                StationEntrance("EN_TA_B", "Georges Quay Entrance", true, "Beautiful riverside glass structure facing the Liffey", 53.3466, -6.2546)
            ),
            platforms = listOf(
                Platform("PL_TA_1", "1", "Southbound (Charlemont)", "Deep Underground Level -3", true),
                Platform("PL_TA_2", "2", "Northbound (Swords)", "Deep Underground Level -3", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.TOILETS, StationFacility.BIKE_PARKING, StationFacility.WIFI, StationFacility.DEFIBRILLATOR),
            connections = listOf(TransportMode.DART, TransportMode.IRISH_RAIL, TransportMode.DUBLIN_BUS),
            description = "The principal river crossing station. Direct physical high-capacity transfer link to Tara Street DART/Irish Rail commuter network."
        ),
        Station(
            id = "ST_ST_STEPHENS_GREEN",
            name = "St Stephen's Green",
            mode = TransportMode.METROLINK,
            latitude = 53.3381,
            longitude = -6.2591,
            distanceToAirportKm = 12.1,
            entrances = listOf(
                StationEntrance("EN_SSG_A", "Stephen's Green West Plaza", true, "Integrated plaza gateway directly adjacent to the Luas Terminal", 53.3384, -6.2588),
                StationEntrance("EN_SSG_B", "Grafton Street Gateway", true, "Sleek granite-clad portal serving the foot of Grafton Street", 53.3378, -6.2594)
            ),
            platforms = listOf(
                Platform("PL_SSG_1", "1", "Southbound (Charlemont)", "Underground Level -2", true),
                Platform("PL_SSG_2", "2", "Northbound (Swords)", "Underground Level -2", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.TOILETS, StationFacility.BIKE_PARKING, StationFacility.WIFI, StationFacility.DEFIBRILLATOR),
            connections = listOf(TransportMode.LUAS, TransportMode.DUBLIN_BUS),
            description = "Serving south Dublin's prime parkland, Grafton Street retail district, and direct transfer link to Luas Green Line."
        ),
        Station(
            id = "ST_CHARLEMONT",
            name = "Charlemont",
            mode = TransportMode.METROLINK,
            latitude = 53.3308,
            longitude = -6.2582,
            distanceToAirportKm = 13.0,
            entrances = listOf(
                StationEntrance("EN_CH_A", "Grand Canal Walkway Entrance", true, "Canalside accessible ramp and plaza elevators", 53.3310, -6.2580),
                StationEntrance("EN_CH_B", "Charlemont Luas Platform Bridge", true, "Integrated bridge transfer directly to the elevated Luas platforms", 53.3306, -6.2584)
            ),
            platforms = listOf(
                Platform("PL_CH_2", "2", "Northbound (Swords)", "Level -1 (Ground)", true)
            ),
            facilities = listOf(StationFacility.LIFT, StationFacility.ESCALATOR, StationFacility.TICKETING, StationFacility.BIKE_PARKING, StationFacility.WIFI),
            connections = listOf(TransportMode.LUAS, TransportMode.DUBLIN_BUS),
            description = "The southern terminus of MetroLink. Connects seamlessly across Grand Canal to Luas Green Line southbound routes."
        )
    )

    fun getStationById(id: String): Station? {
        return STATIONS.find { it.id == id }
    }
}
