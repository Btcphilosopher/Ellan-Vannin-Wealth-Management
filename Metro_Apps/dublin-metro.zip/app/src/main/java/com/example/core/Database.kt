package com.example.core

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

// --- ROOM ENTITIES ---

@Entity(tableName = "favorite_stations")
data class FavoriteStationEntity(
    @PrimaryKey val stationId: String
)

@Entity(tableName = "leap_card")
data class LeapCardEntity(
    @PrimaryKey val cardNumber: String,
    val balance: Double,
    val dailyCapProgress: Double,
    val weeklyCapProgress: Double,
    val isNfcLinked: Boolean,
    val lastUpdated: Long
)

@Entity(tableName = "saved_commutes")
data class SavedCommuteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val fromStationId: String,
    val toStationId: String,
    val commuteTime: String // e.g. "08:15"
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val amount: Double,
    val isCredit: Boolean,
    val terminal: String,
    val mode: String
)

// --- ROOM DAOS ---

@Dao
interface FavoriteStationDao {
    @Query("SELECT * FROM favorite_stations")
    fun getFavoritesFlow(): Flow<List<FavoriteStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(favorite: FavoriteStationEntity)

    @Query("DELETE FROM favorite_stations WHERE stationId = :stationId")
    suspend fun removeFavorite(stationId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_stations WHERE stationId = :stationId)")
    suspend fun isFavorite(stationId: String): Boolean
}

@Dao
interface LeapCardDao {
    @Query("SELECT * FROM leap_card LIMIT 1")
    fun getLeapCardFlow(): Flow<LeapCardEntity?>

    @Query("SELECT * FROM leap_card LIMIT 1")
    suspend fun getLeapCardDirect(): LeapCardEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLeapCard(leapCard: LeapCardEntity)
}

@Dao
interface SavedCommuteDao {
    @Query("SELECT * FROM saved_commutes")
    fun getSavedCommutesFlow(): Flow<List<SavedCommuteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addCommute(commute: SavedCommuteEntity)

    @Query("DELETE FROM saved_commutes WHERE id = :id")
    suspend fun deleteCommute(id: Int)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getTransactionsFlow(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()
}

// --- DATABASE HOLDER ---

@Database(
    entities = [
        FavoriteStationEntity::class,
        LeapCardEntity::class,
        SavedCommuteEntity::class,
        TransactionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class DublinMetroDatabase : RoomDatabase() {
    abstract fun favoriteStationDao(): FavoriteStationDao
    abstract fun leapCardDao(): LeapCardDao
    abstract fun savedCommuteDao(): SavedCommuteDao
    abstract fun transactionDao(): TransactionDao

    companion object {
        @Volatile
        private var INSTANCE: DublinMetroDatabase? = null

        fun getDatabase(context: Context): DublinMetroDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DublinMetroDatabase::class.java,
                    "dublin_metro_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// --- REPOSITORY IMPLEMENTATION ---

class DublinMetroRepository(private val db: DublinMetroDatabase) {
    val favoriteStations: Flow<List<FavoriteStationEntity>> = db.favoriteStationDao().getFavoritesFlow()
    val leapCard: Flow<LeapCardEntity?> = db.leapCardDao().getLeapCardFlow()
    val savedCommutes: Flow<List<SavedCommuteEntity>> = db.savedCommuteDao().getSavedCommutesFlow()
    val transactions: Flow<List<TransactionEntity>> = db.transactionDao().getTransactionsFlow()

    suspend fun addFavorite(stationId: String) {
        db.favoriteStationDao().addFavorite(FavoriteStationEntity(stationId))
    }

    suspend fun removeFavorite(stationId: String) {
        db.favoriteStationDao().removeFavorite(stationId)
    }

    suspend fun isFavorite(stationId: String): Boolean {
        return db.favoriteStationDao().isFavorite(stationId)
    }

    suspend fun getLeapCardDirect(): LeapCardEntity? {
        return db.leapCardDao().getLeapCardDirect()
    }

    suspend fun saveLeapCard(leapCard: LeapCardEntity) {
        db.leapCardDao().saveLeapCard(leapCard)
    }

    suspend fun addCommute(title: String, fromStationId: String, toStationId: String, commuteTime: String) {
        db.savedCommuteDao().addCommute(
            SavedCommuteEntity(
                title = title,
                fromStationId = fromStationId,
                toStationId = toStationId,
                commuteTime = commuteTime
            )
        )
    }

    suspend fun deleteCommute(id: Int) {
        db.savedCommuteDao().deleteCommute(id)
    }

    suspend fun addTransaction(tx: TransactionEntity) {
        db.transactionDao().addTransaction(tx)
    }

    suspend fun initializeDefaultLeapCardIfNeeded() {
        val existing = db.leapCardDao().getLeapCardDirect()
        if (existing == null) {
            val defaultCard = LeapCardEntity(
                cardNumber = "3029 4810 5711 2049",
                balance = 12.50,
                dailyCapProgress = 2.00,
                weeklyCapProgress = 14.00,
                isNfcLinked = false,
                lastUpdated = System.currentTimeMillis()
            )
            db.leapCardDao().saveLeapCard(defaultCard)

            // Seed a couple of transactions
            val baseTime = System.currentTimeMillis()
            db.transactionDao().addTransaction(
                TransactionEntity(
                    id = "TX_101",
                    timestamp = baseTime - 3600000 * 2, // 2 hours ago
                    amount = -2.00,
                    isCredit = false,
                    terminal = "Tara St (MetroLink Platform 2)",
                    mode = "METROLINK"
                )
            )
            db.transactionDao().addTransaction(
                TransactionEntity(
                    id = "TX_102",
                    timestamp = baseTime - 3600000 * 24, // 1 day ago
                    amount = 10.00,
                    isCredit = true,
                    terminal = "App Top-Up (NFC)",
                    mode = "WALKING" // Generic top-up mode
                )
            )
        }
    }
}
