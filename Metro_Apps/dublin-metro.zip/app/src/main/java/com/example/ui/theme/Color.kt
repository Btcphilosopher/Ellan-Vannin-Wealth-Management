package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Dublin Metro Color Palette
val DublinDarkGreen = Color(0xFF0D2E1D)     // Deep rich Irish corporate green
val DublinStone = Color(0xFF4A4E51)         // Dublin stone gray / slate
val DublinLightStone = Color(0xFFECEFEF)    // Warm Limestone off-white
val CopperAccent = Color(0xFFD67B27)        // Warm metallic Irish copper / amber
val DublinNavy = Color(0xFF0B1B26)          // Deep night sky navy (Dark theme base)
val MutedRed = Color(0xFFB0382B)            // Restrained alert red
val DublinBlue = Color(0xFF1E527D)          // Restrained transport blue

// Light Theme
val LightPrimary = DublinDarkGreen
val LightOnPrimary = Color.White
val LightPrimaryContainer = Color(0xFFC6EAD1)
val LightOnPrimaryContainer = DublinDarkGreen
val LightSecondary = DublinStone
val LightOnSecondary = Color.White
val LightBackground = Color(0xFFF7F8F7)     // Soft stone-white
val LightSurface = Color.White
val LightOnSurface = Color(0xFF121413)
val LightSurfaceVariant = Color(0xFFE4E9E5)
val LightOnSurfaceVariant = DublinStone

// Dark Theme
val DarkPrimary = Color(0xFF8ADAA5)         // Highly legible soft sage green
val DarkOnPrimary = DublinDarkGreen
val DarkPrimaryContainer = Color(0xFF14472D)
val DarkOnPrimaryContainer = Color(0xFFC6EAD1)
val DarkBackground = DublinNavy
val DarkSurface = Color(0xFF132530)
val DarkOnSurface = Color(0xFFECEFEF)
val DarkSurfaceVariant = Color(0xFF243B48)
val DarkOnSurfaceVariant = Color(0xFFA6BAC5)
