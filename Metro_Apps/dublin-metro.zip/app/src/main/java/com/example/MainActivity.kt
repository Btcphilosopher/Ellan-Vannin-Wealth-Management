package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.core.DublinMetroDatabase
import com.example.core.DublinMetroRepository
import com.example.ui.screens.MainDashboardViewModel
import com.example.ui.screens.MetroAppLayout
import com.example.ui.theme.DublinMetroTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize SQLite Room Database
        val database = DublinMetroDatabase.getDatabase(applicationContext)
        val repository = DublinMetroRepository(database)

        // Initialize ViewModel via Android Factory
        val viewModelFactory = MainDashboardViewModel.Factory(application, repository)
        val viewModel = ViewModelProvider(this, viewModelFactory)[MainDashboardViewModel::class.java]

        setContent {
            DublinMetroTheme {
                MetroAppLayout(viewModel = viewModel)
            }
        }
    }
}
