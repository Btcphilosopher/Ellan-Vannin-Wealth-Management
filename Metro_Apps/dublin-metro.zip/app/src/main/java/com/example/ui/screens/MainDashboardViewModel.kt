package com.example.ui.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.Departure
import com.example.core.DublinMetroDatabase
import com.example.core.DublinMetroRepository
import com.example.core.FavoriteStationEntity
import com.example.core.Journey
import com.example.core.LeapCardEntity
import com.example.core.ServiceAlert
import com.example.core.TransactionEntity
import com.example.core.Train
import com.example.metrolink.MetroLinkData
import com.example.realtime.RealtimeEngine
import com.example.transport.ServiceGraph
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Screen {
    HOME,
    MAP,
    DIRECTORY,
    STATION_DETAIL,
    JOURNEY_PLANNER,
    LEAP_CARD,
    DISRUPTIONS,
    AIRPORT_MODE
}

class MainDashboardViewModel(
    application: Application,
    private val repository: DublinMetroRepository
) : AndroidViewModel(application) {

    // Current Navigation Screen State
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // History stack for back navigation
    private val navigationStack = mutableListOf<Screen>()

    // Selected station ID for detail view
    private val _selectedStationId = MutableStateFlow<String?>("ST_AIRPORT")
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    // Search query on stations list
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Live simulated trains position flow
    private val _liveTrains = MutableStateFlow<List<Train>>(emptyList())
    val liveTrains: StateFlow<List<Train>> = _liveTrains.asStateFlow()

    // Saved Commutes List
    val savedCommutes = repository.savedCommutes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Favorite stations set mapping
    val favoriteStationIds: StateFlow<Set<String>> = repository.favoriteStations
        .combine(_searchQuery) { entities, _ ->
            entities.map { it.stationId }.toSet()
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptySet()
        )

    // Leap Card state
    val leapCard: StateFlow<LeapCardEntity?> = repository.leapCard.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    // Recent transaction log
    val transactions: StateFlow<List<TransactionEntity>> = repository.transactions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Journey Planner Fields
    private val _journeyFromId = MutableStateFlow<String>("ST_AIRPORT")
    val journeyFromId: StateFlow<String> = _journeyFromId.asStateFlow()

    private val _journeyToId = MutableStateFlow<String>("ST_ST_STEPHENS_GREEN")
    val journeyToId: StateFlow<String> = _journeyToId.asStateFlow()

    private val _accessibilityRequired = MutableStateFlow(false)
    val accessibilityRequired: StateFlow<Boolean> = _accessibilityRequired.asStateFlow()

    private val _journeyResult = MutableStateFlow<Journey?>(null)
    val journeyResult: StateFlow<Journey?> = _journeyResult.asStateFlow()

    // Disruption Alerts
    private val _activeAlerts = MutableStateFlow<List<ServiceAlert>>(RealtimeEngine.SERVICE_ALERTS)
    val activeAlerts: StateFlow<List<ServiceAlert>> = _activeAlerts.asStateFlow()

    // Nearby Arrivals list
    private val _nearbyDepartures = MutableStateFlow<List<Departure>>(RealtimeEngine.getNearbyDepartures())
    val nearbyDepartures: StateFlow<List<Departure>> = _nearbyDepartures.asStateFlow()

    // Simulated ticket purchase scan active
    private val _scanFeedbackMessage = MutableStateFlow<String?>(null)
    val scanFeedbackMessage: StateFlow<String?> = _scanFeedbackMessage.asStateFlow()

    init {
        // Start simulated live train position ticks
        viewModelScope.launch {
            repository.initializeDefaultLeapCardIfNeeded()
            RealtimeEngine.getLiveTrainsFlow().collect { trains ->
                _liveTrains.value = trains
                // Update nearby estimates slightly dynamically
                _nearbyDepartures.value = RealtimeEngine.getNearbyDepartures()
            }
        }
        
        // Calculate initial journey plan
        calculateJourney()
    }

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            navigationStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        return if (navigationStack.isNotEmpty()) {
            _currentScreen.value = navigationStack.removeAt(navigationStack.size - 1)
            true
        } else {
            false
        }
    }

    fun selectStation(stationId: String) {
        _selectedStationId.value = stationId
        navigateTo(Screen.STATION_DETAIL)
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleFavorite(stationId: String) {
        viewModelScope.launch {
            if (favoriteStationIds.value.contains(stationId)) {
                repository.removeFavorite(stationId)
            } else {
                repository.addFavorite(stationId)
            }
        }
    }

    // Journey Planner actions
    fun setJourneyFrom(stationId: String) {
        _journeyFromId.value = stationId
        calculateJourney()
    }

    fun setJourneyTo(stationId: String) {
        _journeyToId.value = stationId
        calculateJourney()
    }

    fun toggleAccessibilityRequired(required: Boolean) {
        _accessibilityRequired.value = required
        calculateJourney()
    }

    fun calculateJourney() {
        val result = ServiceGraph.findRoute(
            fromId = _journeyFromId.value,
            toId = _journeyToId.value,
            accessibilityRequired = _accessibilityRequired.value
        )
        _journeyResult.value = result
    }

    // Top up Leap Card
    fun topUpLeapCard(amount: Double) {
        viewModelScope.launch {
            val current = repository.getLeapCardDirect() ?: return@launch
            val updated = current.copy(
                balance = current.balance + amount,
                lastUpdated = System.currentTimeMillis()
            )
            repository.saveLeapCard(updated)

            // Log top-up transaction
            repository.addTransaction(
                TransactionEntity(
                    id = "TX_TOP_${System.currentTimeMillis()}",
                    timestamp = System.currentTimeMillis(),
                    amount = amount,
                    isCredit = true,
                    terminal = "Mobile App Top-Up",
                    mode = "WALKING"
                )
            )
        }
    }

    // Simulate NFC Leap card touch-on gate validator
    fun simulateGateTouch() {
        viewModelScope.launch {
            val current = repository.getLeapCardDirect() ?: return@launch
            if (current.balance < 2.00) {
                _scanFeedbackMessage.value = "DECLINED: Insufficient Balance. Please Top-up."
                return@launch
            }

            // Deduct standard flat adult 90-minute fare €2.00
            val newBalance = current.balance - 2.00
            val newDailyCap = Math.min(6.00, current.dailyCapProgress + 2.00)
            val updated = current.copy(
                balance = newBalance,
                dailyCapProgress = newDailyCap,
                lastUpdated = System.currentTimeMillis()
            )
            repository.saveLeapCard(updated)

            // Log ticket transaction
            repository.addTransaction(
                TransactionEntity(
                    id = "TX_TOUCH_${System.currentTimeMillis()}",
                    timestamp = System.currentTimeMillis(),
                    amount = -2.00,
                    isCredit = false,
                    terminal = "Gate Validator (Terminal 1 Airport)",
                    mode = "METROLINK"
                )
            )

            _scanFeedbackMessage.value = "TOUCHED ON SUCCESS: €2.00 deducted. 90-min Transfer Active."
        }
    }

    fun clearFeedbackMessage() {
        _scanFeedbackMessage.value = null
    }

    // Get live departures for a station
    fun getDeparturesForStation(stationId: String): List<Departure> {
        return RealtimeEngine.getDeparturesForStation(stationId)
    }

    // Helper Factory
    class Factory(
        private val application: Application,
        private val repository: DublinMetroRepository
    ) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MainDashboardViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return MainDashboardViewModel(application, repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
