package com.example.core

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

// --- CORE MODELS ---

enum class TransportMode(val displayName: String, val color: Color) {
    METROLINK("MetroLink", Color(0xFF133B27)), // Emerald Dark Green
    LUAS("Luas", Color(0xFF6B2D5C)),        // Luas Purple
    DART("DART", Color(0xFF007A87)),        // Teal
    DUBLIN_BUS("Dublin Bus", Color(0xFFE2B13C)), // Amber/Yellow
    IRISH_RAIL("Irish Rail", Color(0xFFD65C2B)), // Orange-red
    WALKING("Walking", Color(0xFF757575)),  // Grey
    CYCLING("Cycling", Color(0xFF4CAF50));  // Light Green

    fun getIcon(): ImageVector {
        return when (this) {
            METROLINK -> Icons.Default.DirectionsSubway
            LUAS -> Icons.Default.DirectionsTransit
            DART -> Icons.Default.DirectionsTransit
            DUBLIN_BUS -> Icons.Default.DirectionsBus
            IRISH_RAIL -> Icons.Default.DirectionsTransit
            WALKING -> Icons.Default.DirectionsRun
            CYCLING -> Icons.Default.DirectionsTransit
        }
    }
}

data class Station(
    val id: String,
    val name: String,
    val mode: TransportMode,
    val latitude: Double,
    val longitude: Double,
    val distanceToAirportKm: Double,
    val entrances: List<StationEntrance>,
    val platforms: List<Platform>,
    val facilities: List<StationFacility>,
    val connections: List<TransportMode>,
    val description: String = ""
)

data class StationEntrance(
    val id: String,
    val name: String,
    val isStepFree: Boolean,
    val description: String,
    val latitude: Double,
    val longitude: Double
)

data class Platform(
    val id: String,
    val number: String,
    val direction: String, // e.g. "Southbound (Charlemont)" or "Northbound (Swords)"
    val level: String,      // e.g. "Underground Level -2"
    val isAccessible: Boolean
)

enum class StationFacility(val displayName: String) {
    LIFT("Lift (Step-Free Access)"),
    ESCALATOR("Escalator"),
    TOILETS("Public Toilets"),
    TICKETING("Ticketing Machines"),
    BIKE_PARKING("Secure Bike Facilities"),
    WIFI("Free TFI Wi-Fi"),
    DEFIBRILLATOR("AED Defibrillator"),
    CAR_PARK("Park & Ride");
}

data class Train(
    val id: String,
    val currentStationId: String,
    val nextStationId: String?,
    val progressToNext: Float, // 0.0 to 1.0 (0.0 is at currentStation, 1.0 is at nextStation)
    val direction: String,     // "Swords" or "Charlemont"
    val carCount: Int = 4,
    val occupancyPercent: Int, // e.g. 45%
    val status: TrainStatus = TrainStatus.ON_TIME
)

enum class TrainStatus(val label: String, val color: Color) {
    ON_TIME("On Time", Color(0xFF2E7D32)),
    MINOR_DELAY("Minor Delay", Color(0xFFEF6C00)),
    MAJOR_DELAY("Delayed", Color(0xFFC62828)),
    SERVICE_SUSPENDED("Suspended", Color(0xFFB71C1C))
}

data class Departure(
    val id: String,
    val stationId: String,
    val destination: String,
    val minutesAway: Int,
    val scheduledTime: String,
    val realTime: String,
    val platform: String,
    val mode: TransportMode,
    val status: TrainStatus = TrainStatus.ON_TIME,
    val occupancyPercent: Int = 30
)

data class Journey(
    val id: String,
    val originName: String,
    val destinationName: String,
    val totalDurationMin: Int,
    val legs: List<JourneyLeg>,
    val totalCostEuro: Double,
    val explanation: String,
    val isAccessible: Boolean
)

data class JourneyLeg(
    val mode: TransportMode,
    val lineName: String,
    val originStationName: String,
    val destinationStationName: String,
    val durationMin: Int,
    val stopCount: Int,
    val instructions: String,
    val intermediateStops: List<String> = emptyList(),
    val distanceM: Int = 0
)

data class LeapCardTransaction(
    val id: String,
    val timestamp: Long,
    val amount: Double,
    val isCredit: Boolean,
    val terminal: String,
    val mode: TransportMode
)

data class ServiceAlert(
    val id: String,
    val title: String,
    val description: String,
    val affectedMode: TransportMode,
    val affectedStations: List<String>,
    val severity: AlertSeverity,
    val alternativeAdvice: String,
    val startTime: String,
    val expectedEnd: String,
    val lastUpdated: String
)

enum class AlertSeverity(val displayName: String, val color: Color) {
    INFO("Info", Color(0xFF007A87)),
    MINOR("Minor", Color(0xFFEF6C00)),
    SEVERE("Severe", Color(0xFFC62828))
}
