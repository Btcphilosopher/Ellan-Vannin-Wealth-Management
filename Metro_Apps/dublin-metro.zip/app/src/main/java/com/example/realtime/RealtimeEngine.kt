package com.example.realtime

import com.example.core.Departure
import com.example.core.Train
import com.example.core.TrainStatus
import com.example.core.TransportMode
import com.example.metrolink.MetroLinkData
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

object RealtimeEngine {

    // Simulates a set of active trains on the MetroLink line
    // To make it look dynamic, we update their progress over time.
    private val activeTrains = mutableListOf<Train>()

    init {
        resetSimulation()
    }

    fun resetSimulation() {
        activeTrains.clear()
        val stations = MetroLinkData.STATIONS
        
        // Spawn 6 trains running along the track
        // Southbound train 1
        activeTrains.add(Train("TR_SB_101", "ST_SWORDS_CENTRAL", "ST_FOSTERSTOWN", 0.2f, "Charlemont", 4, 30))
        // Southbound train 2
        activeTrains.add(Train("TR_SB_102", "ST_BALLYMUN", "ST_GRIFFITH_AVENUE", 0.5f, "Charlemont", 4, 75))
        // Southbound train 3
        activeTrains.add(Train("TR_SB_103", "ST_MATER", "ST_O_CONNELL_STREET", 0.8f, "Charlemont", 4, 55))

        // Northbound train 1
        activeTrains.add(Train("TR_NB_201", "ST_CHARLEMONT", "ST_ST_STEPHENS_GREEN", 0.1f, "Swords", 4, 15))
        // Northbound train 2
        activeTrains.add(Train("TR_NB_202", "ST_TARA", "ST_O_CONNELL_STREET", 0.4f, "Swords", 4, 60))
        // Northbound train 3
        activeTrains.add(Train("TR_NB_203", "ST_DCU", "ST_COLLINS_AVENUE", 0.7f, "Swords", 4, 40))
    }

    // Updates train locations periodically
    fun tickSimulation() {
        val stations = MetroLinkData.STATIONS
        for (i in activeTrains.indices) {
            val train = activeTrains[i]
            val newProgress = train.progressToNext + 0.1f // Move 10% further
            
            if (newProgress >= 1.0f) {
                // The train has arrived at next station!
                val currentIdx = stations.indexOfFirst { it.id == train.currentStationId }
                val nextIdx = stations.indexOfFirst { it.id == train.nextStationId }
                
                if (train.direction == "Charlemont") {
                    // Southbound: moves forward in stations list (0 to 14)
                    val newCurrentIdx = nextIdx
                    val newNextIdx = if (newCurrentIdx < stations.size - 1) newCurrentIdx + 1 else null
                    
                    if (newNextIdx == null) {
                        // Reached Charlemont terminus, reverse to Northbound
                        activeTrains[i] = Train(
                            id = train.id,
                            currentStationId = "ST_CHARLEMONT",
                            nextStationId = "ST_ST_STEPHENS_GREEN",
                            progressToNext = 0.0f,
                            direction = "Swords",
                            occupancyPercent = Random.nextInt(10, 30)
                        )
                    } else {
                        activeTrains[i] = Train(
                            id = train.id,
                            currentStationId = stations[newCurrentIdx].id,
                            nextStationId = stations[newNextIdx].id,
                            progressToNext = 0.0f,
                            direction = "Charlemont",
                            occupancyPercent = Math.min(95, train.occupancyPercent + Random.nextInt(-10, 15))
                        )
                    }
                } else {
                    // Northbound: moves backward in stations list (14 to 0)
                    val newCurrentIdx = nextIdx
                    val newNextIdx = if (newCurrentIdx > 0) newCurrentIdx - 1 else null
                    
                    if (newNextIdx == null) {
                        // Reached Swords terminus, reverse to Southbound
                        activeTrains[i] = Train(
                            id = train.id,
                            currentStationId = "ST_SWORDS",
                            nextStationId = "ST_SWORDS_CENTRAL",
                            progressToNext = 0.0f,
                            direction = "Charlemont",
                            occupancyPercent = Random.nextInt(10, 30)
                        )
                    } else {
                        activeTrains[i] = Train(
                            id = train.id,
                            currentStationId = stations[newCurrentIdx].id,
                            nextStationId = stations[newNextIdx].id,
                            progressToNext = 0.0f,
                            direction = "Swords",
                            occupancyPercent = Math.min(95, train.occupancyPercent + Random.nextInt(-10, 15))
                        )
                    }
                }
            } else {
                activeTrains[i] = train.copy(progressToNext = newProgress)
            }
        }
    }

    // Returns flow of current simulated trains
    fun getLiveTrainsFlow(): Flow<List<Train>> = flow {
        while (true) {
            emit(activeTrains.toList())
            delay(1000) // Emit every second
            tickSimulation()
        }
    }

    // Generates realistic departures for a specific station based on simulated trains and scheduled timetables
    fun getDeparturesForStation(stationId: String): List<Departure> {
        val list = mutableListOf<Departure>()
        val station = MetroLinkData.getStationById(stationId) ?: return emptyList()

        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val baseTimeMs = System.currentTimeMillis()

        // Generate 3 departures for Southbound (to Charlemont) and 3 for Northbound (to Swords) if valid
        val isSwordsTerminus = stationId == "ST_SWORDS"
        val isCharlemontTerminus = stationId == "ST_CHARLEMONT"

        if (!isCharlemontTerminus) {
            // Southbound Departures
            list.add(
                Departure(
                    id = "DEP_SB_${stationId}_1",
                    stationId = stationId,
                    destination = "Charlemont",
                    minutesAway = 3,
                    scheduledTime = sdf.format(Date(baseTimeMs + 3 * 60000)),
                    realTime = sdf.format(Date(baseTimeMs + 3 * 60000)),
                    platform = "1",
                    mode = TransportMode.METROLINK,
                    status = TrainStatus.ON_TIME,
                    occupancyPercent = 40
                )
            )
            list.add(
                Departure(
                    id = "DEP_SB_${stationId}_2",
                    stationId = stationId,
                    destination = "Charlemont",
                    minutesAway = 11,
                    scheduledTime = sdf.format(Date(baseTimeMs + 11 * 60000)),
                    realTime = sdf.format(Date(baseTimeMs + 11 * 60000)),
                    platform = "1",
                    mode = TransportMode.METROLINK,
                    status = TrainStatus.ON_TIME,
                    occupancyPercent = 65
                )
            )
            list.add(
                Departure(
                    id = "DEP_SB_${stationId}_3",
                    stationId = stationId,
                    destination = "Charlemont",
                    minutesAway = 19,
                    scheduledTime = sdf.format(Date(baseTimeMs + 19 * 60000)),
                    realTime = sdf.format(Date(baseTimeMs + 19 * 60000)),
                    platform = "1",
                    mode = TransportMode.METROLINK,
                    status = TrainStatus.ON_TIME,
                    occupancyPercent = 15
                )
            )
        }

        if (!isSwordsTerminus) {
            // Northbound Departures
            list.add(
                Departure(
                    id = "DEP_NB_${stationId}_1",
                    stationId = stationId,
                    destination = "Swords",
                    minutesAway = 5,
                    scheduledTime = sdf.format(Date(baseTimeMs + 5 * 60000)),
                    realTime = sdf.format(Date(baseTimeMs + 5 * 60000)),
                    platform = if (isCharlemontTerminus) "2" else "2",
                    mode = TransportMode.METROLINK,
                    status = TrainStatus.ON_TIME,
                    occupancyPercent = 25
                )
            )
            list.add(
                Departure(
                    id = "DEP_NB_${stationId}_2",
                    stationId = stationId,
                    destination = "Swords",
                    minutesAway = 13,
                    scheduledTime = sdf.format(Date(baseTimeMs + 13 * 60000)),
                    realTime = sdf.format(Date(baseTimeMs + 13 * 60000)),
                    platform = "2",
                    mode = TransportMode.METROLINK,
                    status = TrainStatus.ON_TIME,
                    occupancyPercent = 50
                )
            )
            list.add(
                Departure(
                    id = "DEP_NB_${stationId}_3",
                    stationId = stationId,
                    destination = "Swords",
                    minutesAway = 21,
                    scheduledTime = sdf.format(Date(baseTimeMs + 21 * 60000)),
                    realTime = sdf.format(Date(baseTimeMs + 21 * 60000)),
                    platform = "2",
                    mode = TransportMode.METROLINK,
                    status = TrainStatus.ON_TIME,
                    occupancyPercent = 35
                )
            )
        }

        return list
    }

    // Generates nearby transport connections for home screen based on virtual user location
    fun getNearbyDepartures(): List<Departure> {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val baseTimeMs = System.currentTimeMillis()

        return listOf(
            Departure("NEAR_1", "ST_OCS", "Charlemont (MetroLink)", 4, sdf.format(Date(baseTimeMs + 4 * 60000)), sdf.format(Date(baseTimeMs + 4 * 60000)), "1", TransportMode.METROLINK, TrainStatus.ON_TIME),
            Departure("NEAR_2", "LUAS_ABBEY", "Tallaght (Luas Red)", 7, sdf.format(Date(baseTimeMs + 7 * 60000)), sdf.format(Date(baseTimeMs + 7 * 60000)), "A", TransportMode.LUAS, TrainStatus.ON_TIME),
            Departure("NEAR_3", "BUS_OCS", "Swords Express (Bus 41C)", 11, sdf.format(Date(baseTimeMs + 11 * 60000)), sdf.format(Date(baseTimeMs + 11 * 60000)), "Stop 284", TransportMode.DUBLIN_BUS, TrainStatus.ON_TIME)
        )
    }

    // Default simulation alerts
    val SERVICE_ALERTS = listOf(
        com.example.core.ServiceAlert(
            id = "ALT_101",
            title = "Minor delays near Glasnevin",
            description = "Slight signaling delay affecting trains operating between Glasnevin and Mater. Work crews are currently on-site fixing the issue.",
            affectedMode = TransportMode.METROLINK,
            affectedStations = listOf("ST_GLASNEVIN", "ST_MATER"),
            severity = com.example.core.AlertSeverity.MINOR,
            alternativeAdvice = "Expect 5-10 mins added journey time. Luas Green Line and Dublin Bus routes 4, 9, 83 remain fully operational as alternative conduits.",
            startTime = "08:15",
            expectedEnd = "11:30",
            lastUpdated = "10 mins ago"
        ),
        com.example.core.ServiceAlert(
            id = "ALT_102",
            title = "O'Connell St Lift Outage",
            description = "The elevator connecting O'Connell St Upper Carlton entrance (Entrance A) to underground Platform 1 is temporarily out of service for regular scheduled safety inspection.",
            affectedMode = TransportMode.METROLINK,
            affectedStations = listOf("ST_O_CONNELL_STREET"),
            severity = com.example.core.AlertSeverity.INFO,
            alternativeAdvice = "Please use Henry Street entrance (Entrance B) for full step-free access down to Platform 1 and 2.",
            startTime = "07:00",
            expectedEnd = "13:00",
            lastUpdated = "25 mins ago"
        )
    )
}
