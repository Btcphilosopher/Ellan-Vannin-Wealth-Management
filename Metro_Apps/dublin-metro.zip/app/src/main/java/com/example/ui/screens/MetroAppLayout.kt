package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.Elevator
import androidx.compose.material.icons.filled.LocalAirport
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.AlertSeverity
import com.example.core.Departure
import com.example.core.TransportMode
import com.example.core.Train
import com.example.metrolink.MetroLinkData
import com.example.ui.components.AccessibilityBadge
import com.example.ui.components.DepartureBoard
import com.example.ui.components.FareCard
import com.example.ui.components.JourneyCard
import com.example.ui.components.MetroMap
import com.example.ui.components.MetroStationCard
import com.example.ui.components.ServiceAlertCard
import com.example.ui.components.StationMap
import com.example.ui.components.TicketCard
import com.example.ui.components.TransportModeChip
import com.example.ui.theme.CopperAccent
import com.example.ui.theme.DublinDarkGreen
import com.example.ui.theme.DublinNavy
import com.example.ui.theme.DublinStone
import com.example.ui.theme.MutedRed
import com.example.ui.theme.DublinBlue
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetroAppLayout(
    viewModel: MainDashboardViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val liveTrains by viewModel.liveTrains.collectAsState()
    val favoriteStationIds by viewModel.favoriteStationIds.collectAsState()
    val leapCard by viewModel.leapCard.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val activeAlerts by viewModel.activeAlerts.collectAsState()
    val nearbyDepartures by viewModel.nearbyDepartures.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val scanFeedback by viewModel.scanFeedbackMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Monitor validator scanning feedback messages
    LaunchedEffect(scanFeedback) {
        scanFeedback?.let { msg ->
            scope.launch {
                snackbarHostState.showSnackbar(msg)
                viewModel.clearFeedbackMessage()
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.White)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsSubway,
                                contentDescription = "MetroLink",
                                tint = DublinDarkGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = when (currentScreen) {
                                Screen.HOME -> "DUBLIN METRO"
                                Screen.MAP -> "TRANSIT MAP"
                                Screen.DIRECTORY -> "STATION DIRECTORY"
                                Screen.STATION_DETAIL -> "STATION HUB"
                                Screen.JOURNEY_PLANNER -> "JOURNEY PLANNER"
                                Screen.LEAP_CARD -> "TFI LEAP CARD"
                                Screen.DISRUPTIONS -> "SERVICE UPDATE"
                                Screen.AIRPORT_MODE -> "AIRPORT EXPRESS"
                            },
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            letterSpacing = 1.sp
                        )
                    }
                },
                navigationIcon = {
                    if (currentScreen != Screen.HOME) {
                        IconButton(onClick = { viewModel.navigateBack() }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Go Back",
                                tint = Color.White
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.DISRUPTIONS) }) {
                        Box {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Alerts",
                                tint = Color.White
                            )
                            if (activeAlerts.isNotEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(CopperAccent)
                                        .align(Alignment.TopEnd)
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DublinDarkGreen,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DublinDarkGreen,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentScreen == Screen.HOME,
                    onClick = { viewModel.navigateTo(Screen.HOME) },
                    icon = { Icon(Icons.Default.DirectionsSubway, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = navigationBarItemColors()
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.DIRECTORY,
                    onClick = { viewModel.navigateTo(Screen.DIRECTORY) },
                    icon = { Icon(Icons.Default.Search, contentDescription = "Stations") },
                    label = { Text("Stations", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = navigationBarItemColors()
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.MAP,
                    onClick = { viewModel.navigateTo(Screen.MAP) },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                    label = { Text("Network", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = navigationBarItemColors()
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.LEAP_CARD,
                    onClick = { viewModel.navigateTo(Screen.LEAP_CARD) },
                    icon = { Icon(Icons.Default.CreditCard, contentDescription = "Leap") },
                    label = { Text("Leap", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = navigationBarItemColors()
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (currentScreen) {
                Screen.HOME -> HomeScreen(viewModel, nearbyDepartures)
                Screen.MAP -> MapScreen(viewModel, liveTrains)
                Screen.DIRECTORY -> StationDirectoryScreen(viewModel, favoriteStationIds, searchQuery)
                Screen.STATION_DETAIL -> StationDetailScreen(viewModel, selectedStationId, favoriteStationIds)
                Screen.JOURNEY_PLANNER -> JourneyPlannerScreen(viewModel)
                Screen.LEAP_CARD -> LeapCardScreen(viewModel, leapCard, transactions)
                Screen.DISRUPTIONS -> DisruptionsScreen(viewModel, activeAlerts)
                Screen.AIRPORT_MODE -> AirportModeScreen(viewModel)
            }
        }
    }
}

@Composable
private fun navigationBarItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = DublinDarkGreen,
    selectedTextColor = Color.White,
    indicatorColor = Color.White,
    unselectedIconColor = Color.White.copy(alpha = 0.6f),
    unselectedTextColor = Color.White.copy(alpha = 0.6f)
)

// --- SCREEN 1: HOME SCREEN ---
@Composable
fun HomeScreen(
    viewModel: MainDashboardViewModel,
    nearbyDepartures: List<Departure>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Hero Banner Illustration
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_dublin_metro_hero),
                contentDescription = "Dublin Metro train concept art",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Premium dark green / stone gradient over image
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, DublinDarkGreen.copy(alpha = 0.85f)),
                            startY = 100f
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
            ) {
                Text(
                    text = "SWORDS ━━━━ Charlemont",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    color = CopperAccent,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Dublin Metro Spine",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            // Search destination prompt
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo(Screen.JOURNEY_PLANNER) }
                    .testTag("search_dest_prompt")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = DublinDarkGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Where are you going in Dublin?",
                        color = DublinStone,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Quick Actions Matrix
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.navigateTo(Screen.AIRPORT_MODE) }
                        .testTag("action_airport"),
                    colors = CardDefaults.cardColors(containerColor = DublinDarkGreen),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.LocalAirport, contentDescription = "Airport", tint = Color.White, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Airport Mode", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.navigateTo(Screen.JOURNEY_PLANNER) }
                        .testTag("action_planner"),
                    colors = CardDefaults.cardColors(containerColor = DublinStone),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.DirectionsRun, contentDescription = "Planner", tint = Color.White, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Journey Planner", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Context-Aware commute widget
            Text(
                text = "YOUR SAVED COMMUTE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp,
                color = DublinStone
            )
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color.Green)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "MORNING ROUTE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Green)
                        }
                        Text(text = "08:15 Commute", fontSize = 12.sp, color = DublinStone)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Swords ➔ St Stephen's Green", fontSize = 18.sp, fontWeight = FontWeight.Black, color = DublinDarkGreen)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "MetroLink Spine • Next departure in 3 mins (08:18)", fontSize = 13.sp, color = DublinStone)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            viewModel.setJourneyFrom("ST_SWORDS")
                            viewModel.setJourneyTo("ST_ST_STEPHENS_GREEN")
                            viewModel.navigateTo(Screen.JOURNEY_PLANNER)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DublinDarkGreen),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("View Optimal Journey", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Nearby Departures Board
            DepartureBoard(stationName = "O'Connell St (Nearby Interchange)", departures = nearbyDepartures)
        }
    }
}

// --- SCREEN 2: MAP SCREEN (SIMULATION INTERACTIVE VIEW) ---
@Composable
fun MapScreen(
    viewModel: MainDashboardViewModel,
    liveTrains: List<Train>
) {
    var simulationActive by remember { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Simulation alert banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFE0F7FA))
                .padding(vertical = 10.dp, horizontal = 16.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Simulation mode",
                        tint = DublinBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SYNTHETIC SIMULATION ACTIVE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = DublinBlue,
                        letterSpacing = 1.sp
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ACTIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DublinBlue)
                    Spacer(modifier = Modifier.width(6.dp))
                    Switch(
                        checked = simulationActive,
                        onCheckedChange = { simulationActive = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = DublinBlue
                        ),
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Text(
                    text = "Dublin MetroLink is currently modeled from Swords to Charlemont. Observe simulated train locations below in real-time.",
                    fontSize = 13.sp,
                    color = DublinStone,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }
            item {
                MetroMap(
                    stations = MetroLinkData.STATIONS,
                    activeTrains = if (simulationActive) liveTrains else emptyList(),
                    selectedStationId = null,
                    onStationSelect = { stationId ->
                        viewModel.selectStation(stationId)
                    }
                )
            }
        }
    }
}

// --- SCREEN 3: STATION DIRECTORY SCREEN ---
@Composable
fun StationDirectoryScreen(
    viewModel: MainDashboardViewModel,
    favoriteStationIds: Set<String>,
    searchQuery: String
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                label = { Text("Search Dublin Stations...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = DublinDarkGreen,
                    focusedLabelColor = DublinDarkGreen
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        val filteredStations = remember(searchQuery) {
            MetroLinkData.STATIONS.filter {
                it.name.contains(searchQuery, ignoreCase = true)
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredStations) { station ->
                val isFavorite = favoriteStationIds.contains(station.id)
                MetroStationCard(
                    station = station,
                    departures = viewModel.getDeparturesForStation(station.id),
                    isFavorite = isFavorite,
                    onFavoriteToggle = { viewModel.toggleFavorite(station.id) },
                    onClick = { viewModel.selectStation(station.id) }
                )
            }
        }
    }
}

// --- SCREEN 4: STATION DETAIL SCREEN (WITH WAYFINDING & DEPARTURES) ---
@Composable
fun StationDetailScreen(
    viewModel: MainDashboardViewModel,
    stationId: String?,
    favoriteStationIds: Set<String>
) {
    val station = remember(stationId) {
        MetroLinkData.getStationById(stationId ?: "ST_AIRPORT") ?: MetroLinkData.STATIONS.first()
    }

    val departures = remember(station.id) {
        viewModel.getDeparturesForStation(station.id)
    }

    val isFavorite = favoriteStationIds.contains(station.id)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = station.name,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = DublinDarkGreen
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TransportModeChip(station.mode)
                    if (station.connections.contains(TransportMode.DART)) {
                        TransportModeChip(TransportMode.DART)
                    }
                    if (station.connections.contains(TransportMode.LUAS)) {
                        TransportModeChip(TransportMode.LUAS)
                    }
                }
            }
            IconButton(onClick = { viewModel.toggleFavorite(station.id) }) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) CopperAccent else DublinStone,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(text = station.description, fontSize = 14.sp, color = DublinStone)
        Spacer(modifier = Modifier.height(18.dp))

        // Live departures block
        DepartureBoard(stationName = station.name, departures = departures)

        Spacer(modifier = Modifier.height(20.dp))

        // Station wayfinding map
        StationMap(station = station)

        Spacer(modifier = Modifier.height(20.dp))

        // Entrances Details
        Text(
            text = "STATION ENTRANCES",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = DublinStone
        )
        Spacer(modifier = Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            station.entrances.forEach { ent ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = ent.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            AccessibilityBadge(isStepFree = ent.isStepFree)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = ent.description, fontSize = 12.sp, color = DublinStone)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Facilities List
        Text(
            text = "STATION FACILITIES",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = DublinStone
        )
        Spacer(modifier = Modifier.height(8.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                station.facilities.forEach { fac ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = when (fac) {
                                com.example.core.StationFacility.LIFT -> Icons.Default.Elevator
                                com.example.core.StationFacility.WIFI -> Icons.Default.Wifi
                                else -> Icons.Default.DirectionsSubway
                            },
                            contentDescription = null,
                            tint = DublinDarkGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = fac.displayName, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

// --- SCREEN 5: JOURNEY PLANNER ---
@Composable
fun JourneyPlannerScreen(
    viewModel: MainDashboardViewModel
) {
    val fromId by viewModel.journeyFromId.collectAsState()
    val toId by viewModel.journeyToId.collectAsState()
    val result by viewModel.journeyResult.collectAsState()
    val accessibleOnly by viewModel.accessibilityRequired.collectAsState()

    var showFromDropdown by remember { mutableStateOf(false) }
    var showToDropdown by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // From field
                Text(text = "FROM", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DublinStone)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showFromDropdown = !showFromDropdown }
                        .border(1.dp, DublinStone.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = MetroLinkData.getStationById(fromId)?.name ?: fromId,
                        fontWeight = FontWeight.Bold,
                        color = DublinDarkGreen
                    )
                    Icon(imageVector = Icons.Default.SwapVert, contentDescription = "Dropdown")
                }

                if (showFromDropdown) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .verticalScroll(rememberScrollState())
                            .border(1.dp, DublinStone.copy(alpha = 0.15f))
                    ) {
                        MetroLinkData.STATIONS.forEach { s ->
                            Text(
                                text = s.name,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.setJourneyFrom(s.id)
                                        showFromDropdown = false
                                    }
                                    .padding(10.dp),
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Swap buttons
                IconButton(
                    onClick = {
                        val temp = fromId
                        viewModel.setJourneyFrom(toId)
                        viewModel.setJourneyTo(temp)
                    },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Icon(imageVector = Icons.Default.SwapVert, contentDescription = "Swap Origin/Destination", tint = CopperAccent)
                }

                Spacer(modifier = Modifier.height(6.dp))

                // To field
                Text(text = "TO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DublinStone)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showToDropdown = !showToDropdown }
                        .border(1.dp, DublinStone.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = MetroLinkData.getStationById(toId)?.name ?: toId,
                        fontWeight = FontWeight.Bold,
                        color = DublinDarkGreen
                    )
                    Icon(imageVector = Icons.Default.SwapVert, contentDescription = "Dropdown")
                }

                if (showToDropdown) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .verticalScroll(rememberScrollState())
                            .border(1.dp, DublinStone.copy(alpha = 0.15f))
                    ) {
                        MetroLinkData.STATIONS.forEach { s ->
                            Text(
                                text = s.name,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.setJourneyTo(s.id)
                                        showToDropdown = false
                                    }
                                    .padding(10.dp),
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Accessibility toggle
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Accessible, contentDescription = null, tint = DublinDarkGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Step-Free Journeys Only", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Checkbox(
                        checked = accessibleOnly,
                        onCheckedChange = { viewModel.toggleAccessibilityRequired(it) },
                        colors = CheckboxDefaults.colors(checkedColor = DublinDarkGreen)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "RECOMMENDED JOURNEY ROUTE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = DublinStone
        )
        Spacer(modifier = Modifier.height(8.dp))

        val currentResult = result
        if (currentResult == null) {
            Text(
                text = "No optimal route found between selected points.",
                color = MutedRed,
                fontSize = 14.sp
            )
        } else {
            JourneyCard(journey = currentResult, onClick = {})

            Spacer(modifier = Modifier.height(16.dp))

            // Step-by-step Leg details
            Text(
                text = "ROUTE TIMELINE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = DublinStone
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                currentResult.legs.forEach { leg ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(14.dp)) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(leg.mode.color)
                            ) {
                                Icon(
                                    imageVector = leg.mode.getIcon(),
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = leg.lineName,
                                    fontWeight = FontWeight.Black,
                                    color = leg.mode.color,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = leg.instructions,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${leg.originStationName} ➔ ${leg.destinationStationName} (${leg.durationMin} mins)",
                                    fontSize = 12.sp,
                                    color = DublinStone
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 6: LEAP CARD SCREEN (WITH NFC SIMULATION) ---
@Composable
fun LeapCardScreen(
    viewModel: MainDashboardViewModel,
    leapCard: com.example.core.LeapCardEntity?,
    transactions: List<com.example.core.TransactionEntity>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        if (leapCard == null) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Text(text = "Initializing Leap Card Integration...", color = DublinStone)
            }
        } else {
            FareCard(
                leapBalance = leapCard.balance,
                dailyCap = leapCard.dailyCapProgress,
                weeklyCap = leapCard.weeklyCapProgress
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Action buttons
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { viewModel.topUpLeapCard(10.00) },
                    colors = ButtonDefaults.buttonColors(containerColor = DublinDarkGreen),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Top-Up €10.00", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { viewModel.simulateGateTouch() },
                    colors = ButtonDefaults.buttonColors(containerColor = CopperAccent),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Simulate NFC Scan", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Transaction History list
            Text(
                text = "RECENT LEAP TRANSACTIONS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp,
                color = DublinStone
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                transactions.take(5).forEach { tx ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Column {
                                Text(text = tx.terminal, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                val sdf = remember { java.text.SimpleDateFormat("dd MMM, HH:mm", java.util.Locale.getDefault()) }
                                Text(text = sdf.format(java.util.Date(tx.timestamp)), fontSize = 11.sp, color = DublinStone)
                            }
                            Text(
                                text = if (tx.isCredit) "+€${String.format("%.2f", tx.amount)}" else "-€${String.format("%.2f", Math.abs(tx.amount))}",
                                fontWeight = FontWeight.ExtraBold,
                                color = if (tx.isCredit) Color(0xFF2E7D32) else MutedRed,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 7: DISRUPTIONS SYSTEM ---
@Composable
fun DisruptionsScreen(
    viewModel: MainDashboardViewModel,
    alerts: List<com.example.core.ServiceAlert>
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "TFI LIVE SERVICE UPDATES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.2.sp,
                color = DublinStone
            )
        }
        if (alerts.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF2E7D32))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = "All MetroLink, Luas, DART, and Bus lines are operating normally.", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                    }
                }
            }
        } else {
            items(alerts) { alert ->
                ServiceAlertCard(alert = alert)
            }
        }
    }
}

// --- SCREEN 8: AIRPORT MODE EXPRESS ---
@Composable
fun AirportModeScreen(
    viewModel: MainDashboardViewModel
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = DublinDarkGreen),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.LocalAirport, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = "AIRPORT METROLINK EXPRESS", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "High-speed zero-emissions rapid transit connecting Dublin Airport directly into the city centre heart in 20 minutes.",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "EXPRESS ROUTE SELECTOR",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = DublinStone
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Quick Express Journeys
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Option 1
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.setJourneyFrom("ST_AIRPORT")
                            viewModel.setJourneyTo("ST_O_CONNELL_STREET")
                            viewModel.navigateTo(Screen.JOURNEY_PLANNER)
                        }
                        .padding(vertical = 4.dp)
                ) {
                    Column {
                        Text(text = "Airport ➔ O'Connell Street", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(text = "City Center Core • 20 mins", fontSize = 12.sp, color = DublinStone)
                    }
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = CopperAccent)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Option 2
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.setJourneyFrom("ST_AIRPORT")
                            viewModel.setJourneyTo("ST_ST_STEPHENS_GREEN")
                            viewModel.navigateTo(Screen.JOURNEY_PLANNER)
                        }
                        .padding(vertical = 4.dp)
                ) {
                    Column {
                        Text(text = "Airport ➔ St Stephen's Green", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(text = "Southside Retail District • 24 mins", fontSize = 12.sp, color = DublinStone)
                    }
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = CopperAccent)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Wayfinding
        Text(
            text = "HOW TO REACH AIRPORT METROLINK",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = DublinStone
        )
        Spacer(modifier = Modifier.height(8.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row {
                    Text(text = "❶", fontWeight = FontWeight.Bold, color = DublinDarkGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Arrive in T1 or T2 arrivals hall.", fontSize = 13.sp)
                }
                Row {
                    Text(text = "❷", fontWeight = FontWeight.Bold, color = DublinDarkGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Follow 'MetroLink' overhead signs towards physical transit plaza.", fontSize = 13.sp)
                }
                Row {
                    Text(text = "❸", fontWeight = FontWeight.Bold, color = DublinDarkGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Scan Leap Card at gates down to Level -3.", fontSize = 13.sp)
                }
            }
        }
    }
}
