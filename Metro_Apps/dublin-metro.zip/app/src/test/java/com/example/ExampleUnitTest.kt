package com.example

import com.example.core.TransportMode
import com.example.transport.ServiceGraph
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testDublinMetroLinkRouteCount() {
        // Verify that all 15 stations exist in the ServiceGraph
        val nodesCount = ServiceGraph.NODES.size
        assertTrue("Graph should contain the 15 MetroLink stations plus connections", nodesCount >= 15)
    }

    @Test
    fun testRouteAirportToOConnellStreet() {
        // Test route from Dublin Airport to O'Connell Street
        val journey = ServiceGraph.findRoute("ST_AIRPORT", "ST_O_CONNELL_STREET")
        assertNotNull("Journey should be found", journey)
        assertEquals("Dublin Airport", journey!!.originName)
        assertEquals("O'Connell Street", journey.destinationName)
        
        // Assert that MetroLink mode is used for this direct spine connection
        val containsMetroLink = journey.legs.any { it.mode == TransportMode.METROLINK }
        assertTrue("Should utilize the high-speed MetroLink spine", containsMetroLink)
        
        // Assert Dublin flat adult 90-minute fare €2.00
        assertEquals(2.00, journey.totalCostEuro, 0.01)
    }

    @Test
    fun testRouteSwordsToStephenGreen() {
        // Test route from Swords northern terminus to St Stephen's Green southside
        val journey = ServiceGraph.findRoute("ST_SWORDS", "ST_ST_STEPHENS_GREEN")
        assertNotNull(journey)
        assertEquals("Swords", journey!!.originName)
        assertEquals("St Stephen's Green", journey.destinationName)
        
        val totalLegs = journey.legs.size
        assertTrue("Should be completed with minimal legs", totalLegs >= 1)
        
        // Verify travel duration is realistic
        assertTrue("Swords to SSG should take between 15 and 35 mins", journey.totalDurationMin in 15..35)
    }

    @Test
    fun testDARTToMetroLinkTransfer() {
        // Test route from Tara Street (DART node) to Dublin Airport
        val journey = ServiceGraph.findRoute("ST_DART_TARA_ST", "ST_AIRPORT")
        assertNotNull(journey)
        
        // Verify that the path contains a transfer from DART to MetroLink via walking
        val modes = journey!!.legs.map { it.mode }
        assertTrue("Should contain walking transfer", modes.contains(TransportMode.WALKING))
        assertTrue("Should contain MetroLink leg", modes.contains(TransportMode.METROLINK))
    }

    @Test
    fun testLuasToMetroLinkTransfer() {
        // Test route from Abbey Street (Luas Red) to Dublin Airport
        val journey = ServiceGraph.findRoute("ST_LUAS_ABBEY", "ST_AIRPORT")
        assertNotNull(journey)
        
        val modes = journey!!.legs.map { it.mode }
        assertTrue("Should contain Luas mode", modes.contains(TransportMode.LUAS) || modes.contains(TransportMode.WALKING))
        assertTrue("Should contain MetroLink mode", modes.contains(TransportMode.METROLINK))
    }

    @Test
    fun testAccessibilityConstrainedRoute() {
        // Test that finding a route with accessibility required completes successfully
        val journey = ServiceGraph.findRoute("ST_AIRPORT", "ST_O_CONNELL_STREET", accessibilityRequired = true)
        assertNotNull(journey)
        assertTrue("Accessible journey must be accessible", journey!!.isAccessible)
    }
}
