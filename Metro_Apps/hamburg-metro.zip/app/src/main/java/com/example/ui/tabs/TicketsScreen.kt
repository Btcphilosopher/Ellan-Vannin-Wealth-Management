package com.example.ui.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.MetroViewModel

@Composable
fun TicketsScreen(viewModel: MetroViewModel) {
  val settings = viewModel.settings
  val isDe = settings.language == "de"
  var selectedTicket by remember { mutableStateOf<com.example.model.TicketProduct?>(null) }
  var checkoutSuccess by remember { mutableStateOf(false) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    Text(
      text = if (isDe) "HVV Tickets & Tarife" else "HVV Ticketing & Fares",
      fontSize = 20.sp,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.primary
    )

    if (checkoutSuccess) {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (isDe) "Demo-Ticket erfolgreich erworben!" else "Demo ticket purchased successfully!",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
            Text(
              text = if (isDe) "Gültig im gesamten Hamburger HVV-Netz." else "Valid across Hamburg HVV network.",
              fontSize = 12.sp
            )
          }
          TextButton(onClick = { checkoutSuccess = false }) {
            Text("OK")
          }
        }
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxWidth().weight(1f),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(viewModel.tickets) { ticket ->
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (isDe) ticket.titleDe else ticket.titleEn,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Text(
                text = ticket.price,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
              )
            }
            Text(
              text = if (isDe) ticket.descriptionDe else ticket.descriptionEn,
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
              onClick = {
                selectedTicket = ticket
                checkoutSuccess = true
              },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(Icons.Default.ShoppingCart, contentDescription = null)
              Spacer(modifier = Modifier.width(8.dp))
              Text(if (isDe) "Demo-Kauf starten" else "Start Demo Checkout")
            }
          }
        }
      }
    }
  }
}
