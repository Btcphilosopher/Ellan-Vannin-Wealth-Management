package com.example.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.data.HamburgRepository
import com.example.model.*

class MetroViewModel : ViewModel() {

  var currentTab by mutableStateOf(0) // 0: Home, 1: Map, 2: Departures, 3: Tickets, 4: Profile
    private set

  var settings by mutableStateOf(AppSettings())
    private set

  var stations by mutableStateOf(HamburgRepository.stations)
    private set

  var lines by mutableStateOf(HamburgRepository.lines)
    private set

  var disruptions by mutableStateOf(HamburgRepository.disruptions)
    private set

  var tickets by mutableStateOf(HamburgRepository.tickets)
    private set

  // Journey Planner State
  var originStationId by mutableStateOf("hbf")
  var destinationStationId by mutableStateOf("jungfernstieg")
  var journeyResults by mutableStateOf<List<JourneyOption>>(emptyList())
  var isSearchingJourney by mutableStateOf(false)

  // Active Live Journey Mode
  var activeJourney by mutableStateOf<JourneyOption?>(null)

  // Selected Station for Departures / Details
  var selectedStation by mutableStateOf<Station?>(null)
  var departuresForSelected by mutableStateOf<List<Departure>>(emptyList())

  // Saved favorites
  var favoriteStations by mutableStateOf(listOf("hbf", "jungfernstieg", "landungsbruecken"))
    private set

  init {
    loadDeparturesForStation(selectedStation?.id ?: "hbf")
  }

  fun setTab(index: Int) {
    currentTab = index
  }

  fun updateLanguage(lang: String) {
    settings = settings.copy(language = lang)
  }

  fun toggleStepFree() {
    settings = settings.copy(stepFreeOnly = !settings.stepFreeOnly)
  }

  fun toggleHighContrast() {
    settings = settings.copy(highContrast = !settings.highContrast)
  }

  fun toggleLargeText() {
    settings = settings.copy(largeText = !settings.largeText)
  }

  fun selectStation(station: Station) {
    selectedStation = station
    loadDeparturesForStation(station.id)
  }

  fun loadDeparturesForStation(stationId: String) {
    departuresForSelected = HamburgRepository.getDeparturesForStation(stationId)
  }

  fun planJourney() {
    isSearchingJourney = true
    journeyResults = HamburgRepository.planJourney(originStationId, destinationStationId, settings.stepFreeOnly)
    isSearchingJourney = false
  }

  fun startLiveJourney(option: JourneyOption) {
    activeJourney = option
  }

  fun stopLiveJourney() {
    activeJourney = null
  }

  fun toggleFavorite(stationId: String) {
    favoriteStations = if (favoriteStations.contains(stationId)) {
      favoriteStations - stationId
    } else {
      favoriteStations + stationId
    }
  }

  fun getStationName(id: String): String {
    return stations.find { it.id == id }?.name ?: id
  }
}
