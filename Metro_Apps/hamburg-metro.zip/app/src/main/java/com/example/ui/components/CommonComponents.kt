package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppSettings

@Composable
fun LineBadge(lineId: String) {
  val color = when (lineId) {
    "U1" -> Color(0xFF0065BD)
    "U2" -> Color(0xFFE30613)
    "U3" -> Color(0xFFFFCC00)
    "U4" -> Color(0xFF00A2E8)
    "S1" -> Color(0xFF009639)
    "S2" -> Color(0xFF8A2BE2)
    "S3" -> Color(0xFFE4007C)
    "S5" -> Color(0xFF00539F)
    "RE" -> Color(0xFF708090)
    else -> Color.DarkGray
  }
  val textColor = if (lineId == "U3") Color.Black else Color.White

  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(color)
      .padding(horizontal = 8.dp, vertical = 4.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = lineId,
      color = textColor,
      fontWeight = FontWeight.Bold,
      fontSize = 13.sp
    )
  }
}

@Composable
fun HamburgBottomBar(currentTab: Int, onTabSelected: (Int) -> Unit, settings: AppSettings) {
  val isDe = settings.language == "de"
  val homeLabel = if (isDe) "Start" else "Home"
  val mapLabel = if (isDe) "Karte" else "Map"
  val depLabel = if (isDe) "Abfahrten" else "Departures"
  val ticketLabel = if (isDe) "Tickets" else "Tickets"
  val profileLabel = if (isDe) "Profil" else "Profile"

  NavigationBar(
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 8.dp
  ) {
    NavigationBarItem(
      icon = { Icon(Icons.Default.Home, contentDescription = homeLabel) },
      label = { Text(homeLabel) },
      selected = currentTab == 0,
      onClick = { onTabSelected(0) }
    )
    NavigationBarItem(
      icon = { Icon(Icons.Default.Map, contentDescription = mapLabel) },
      label = { Text(mapLabel) },
      selected = currentTab == 1,
      onClick = { onTabSelected(1) }
    )
    NavigationBarItem(
      icon = { Icon(Icons.Default.Schedule, contentDescription = depLabel) },
      label = { Text(depLabel) },
      selected = currentTab == 2,
      onClick = { onTabSelected(2) }
    )
    NavigationBarItem(
      icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = ticketLabel) },
      label = { Text(ticketLabel) },
      selected = currentTab == 3,
      onClick = { onTabSelected(3) }
    )
    NavigationBarItem(
      icon = { Icon(Icons.Default.Person, contentDescription = profileLabel) },
      label = { Text(profileLabel) },
      selected = currentTab == 4,
      onClick = { onTabSelected(4) }
    )
  }
}
