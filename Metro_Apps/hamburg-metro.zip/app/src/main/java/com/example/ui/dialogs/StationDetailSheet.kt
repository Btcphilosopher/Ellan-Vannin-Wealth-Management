package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Station
import com.example.ui.components.LineBadge
import com.example.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationDetailSheet(viewModel: MetroViewModel, station: Station, onDismiss: () -> Unit) {
  val settings = viewModel.settings
  val isDe = settings.language == "de"

  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.8f)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = station.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
          Text(text = station.zone, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }

      Text(text = station.description, fontSize = 14.sp)

      // Platforms & Lifts
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(text = if (isDe) "Ausstattung & Barrierefreiheit" else "Facilities & Accessibility", fontWeight = FontWeight.Bold, fontSize = 13.sp)
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(
              if (station.isStepFree) Icons.Default.CheckCircle else Icons.Default.Warning,
              contentDescription = null,
              tint = if (station.isStepFree) Color(0xFF009639) else MaterialTheme.colorScheme.error
            )
            Text(
              text = if (station.isStepFree) (if (isDe) "Barrierefreier Zugang" else "Step-free access") else (if (isDe) "Eingeschränkter barrierefreier Zugang" else "Limited step-free access"),
              fontSize = 13.sp
            )
          }
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(
              if (station.isLiftOperational) Icons.Default.Elevator else Icons.Default.Warning,
              contentDescription = null,
              tint = if (station.isLiftOperational) Color(0xFF009639) else MaterialTheme.colorScheme.error
            )
            Text(
              text = if (station.isLiftOperational) (if (isDe) "Fahrstuhl in Betrieb" else "Elevator operational") else (if (isDe) "Fahrstuhl außer Betrieb!" else "Elevator out of service!"),
              fontSize = 13.sp
            )
          }
        }
      }

      Text(text = if (isDe) "Haltende Linien" else "Serving Lines", fontWeight = FontWeight.Bold, fontSize = 15.sp)
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        station.lines.forEach { line -> LineBadge(lineId = line) }
      }

      Text(text = if (isDe) "Nächste Abfahrten" else "Upcoming Departures", fontWeight = FontWeight.Bold, fontSize = 15.sp)

      LazyColumn(
        modifier = Modifier.fillMaxWidth().weight(1f),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(viewModel.departuresForSelected) { dep ->
          Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(12.dp).fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LineBadge(lineId = dep.lineId)
                Column {
                  Text(text = dep.destination, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  Text(text = dep.platform, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
              Text(text = dep.predictedTime, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }
    }
  }
}
