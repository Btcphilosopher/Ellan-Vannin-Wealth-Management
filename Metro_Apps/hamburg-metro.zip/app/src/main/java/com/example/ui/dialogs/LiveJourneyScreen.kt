package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.JourneyOption
import com.example.ui.components.LineBadge
import com.example.viewmodel.MetroViewModel

@Composable
fun LiveJourneyScreen(viewModel: MetroViewModel, journey: JourneyOption, onStop: () -> Unit) {
  val settings = viewModel.settings
  val isDe = settings.language == "de"

  Card(
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
    modifier = Modifier.fillMaxWidth().wrapContentHeight()
  ) {
    Column(
      modifier = Modifier.padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.Navigation, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Text(
            text = if (isDe) "Live-Fahrt aktiv" else "Live Journey Active",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.primary
          )
        }
        IconButton(onClick = onStop) {
          Icon(Icons.Default.Close, contentDescription = "Exit")
        }
      }

      // Route summary
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(text = journey.origin, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Text(text = journey.departureTime, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Column(horizontalAlignment = Alignment.End) {
          Text(text = journey.destination, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Text(text = journey.arrivalTime, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }

      Divider()

      // Current Step instructions
      Text(
        text = if (isDe) "Aktueller Schritt:" else "Current Step:",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      journey.legs.firstOrNull()?.let { leg ->
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          leg.lineName?.let { LineBadge(lineId = it) }
          Column {
            Text(
              text = if (isDe) leg.instructionDe else leg.instructionEn,
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp
            )
            Text(
              text = if (isDe) "Plattform ${leg.platform ?: "Gl. 1"} • Abfahrt in 3 Min" else "Platform ${leg.platform ?: "Gl. 1"} • Departs in 3 min",
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      }

      Button(
        onClick = onStop,
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.onErrorContainer),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp)
      ) {
        Icon(Icons.Default.Stop, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(if (isDe) "Fahrt beenden" else "End Journey")
      }
    }
  }
}
