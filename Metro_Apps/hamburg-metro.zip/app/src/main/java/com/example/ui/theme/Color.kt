package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val HamburgNavy = Color(0xFF0B192C)
val HamburgRed = Color(0xFFE30613)
val ElbeBlue = Color(0xFF006699)
val MutedTeal = Color(0xFF008A93)
val SoftGrey = Color(0xFFF4F6F9)
val TransitYellow = Color(0xFFFFCC00)

val LightPrimary = HamburgRed
val LightSecondary = ElbeBlue
val LightBackground = SoftGrey
val LightSurface = Color.White
val LightOnPrimary = Color.White
val LightOnSurface = Color(0xFF0B192C)

val DarkPrimary = Color(0xFFFF4D4F)
val DarkSecondary = Color(0xFF3399CC)
val DarkBackground = Color(0xFF07101B)
val DarkSurface = Color(0xFF0F1C2E)
val DarkOnPrimary = Color.White
val DarkOnSurface = Color(0xFFF4F6F9)
