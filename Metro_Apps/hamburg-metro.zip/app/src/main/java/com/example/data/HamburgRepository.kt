package com.example.data

import com.example.model.*

object HamburgRepository {

  val stations = listOf(
    Station(
      id = "hbf",
      name = "Hamburg Hauptbahnhof",
      modes = listOf("U", "S", "Bus", "RE"),
      lines = listOf("U1", "U2", "U3", "S1", "S2", "S3", "S5", "RE"),
      platforms = listOf("Gl. 1-4 (S-Bahn)", "Gl. 5-8 (U-Bahn)", "Gl. 11-14 (Fern/Regional)"),
      isStepFree = true,
      isLiftOperational = true,
      description = "Germany's busiest railway station and main HVV transit hub."
    ),
    Station(
      id = "jungfernstieg",
      name = "Jungfernstieg",
      modes = listOf("U", "S", "Ferry"),
      lines = listOf("U1", "U2", "U4", "S1", "S2", "S3", "S5"),
      platforms = listOf("Gl. 1-2 (U1/U2)", "Gl. 3-4 (U4)", "Gl. 5 (S-Bahn)", "Anleger (Fähre 62)"),
      isStepFree = true,
      isLiftOperational = true,
      description = "Central waterfront interchange station on the Alster."
    ),
    Station(
      id = "berliner_tor",
      name = "Berliner Tor",
      modes = listOf("U", "S"),
      lines = listOf("U2", "U3", "U4", "S1", "S2", "S3"),
      platforms = listOf("Gl. 1-2 (U-Bahn)", "Gl. 3-4 (S-Bahn)"),
      isStepFree = true,
      isLiftOperational = true,
      description = "Major east-city interchange station with cross-platform connections."
    ),
    Station(
      id = "altona",
      name = "Altona",
      modes = listOf("U", "S", "Bus", "RE"),
      lines = listOf("S1", "S2", "S3", "S5", "RE"),
      platforms = listOf("Gl. 1-5 (S/Regional)"),
      isStepFree = true,
      isLiftOperational = true,
      description = "Western transport hub connecting Hamburg to Schleswig-Holstein."
    ),
    Station(
      id = "barmbek",
      name = "Barmbek",
      modes = listOf("U", "S", "Bus"),
      lines = listOf("U3", "S1"),
      platforms = listOf("Gl. 1 (U-Bahn)", "Gl. 2 (S-Bahn)"),
      isStepFree = true,
      isLiftOperational = false, // simulating lift outage for accessibility test
      description = "Important northern ring and radial interchange."
    ),
    Station(
      id = "landungsbruecken",
      name = "Landungsbrücken",
      modes = listOf("U", "S", "Ferry"),
      lines = listOf("U3", "S1", "S3"),
      platforms = listOf("Gl. 1 (U-Bahn)", "Gl. 2 (S-Bahn)", "Brücke 1-3 (HADAG Fähren)"),
      isStepFree = true,
      isLiftOperational = true,
      description = "Historic harbor piers with direct ferry connections across the Elbe."
    ),
    Station(
      id = "dammtor",
      name = "Hamburg Dammtor",
      modes = listOf("S", "RE", "Bus"),
      lines = listOf("S1", "S2", "S5", "RE"),
      platforms = listOf("Gl. 1-2"),
      isStepFree = true,
      isLiftOperational = true,
      description = "Historic neoclassical station near University and CCH."
    ),
    Station(
      id = "sternschanze",
      name = "Sternschanze",
      modes = listOf("U", "S"),
      lines = listOf("U3", "S21", "S31"),
      platforms = listOf("Gl. 1 (U)", "Gl. 2 (S)"),
      isStepFree = true,
      isLiftOperational = true,
      description = "Vibrant cultural district station in central Hamburg."
    ),
    Station(
      id = "elbbruecken",
      name = "Elbbrücken",
      modes = listOf("U", "S"),
      lines = listOf("U4", "S3"),
      platforms = listOf("Gl. 1 (U4)", "Gl. 2 (S3)"),
      isStepFree = true,
      isLiftOperational = true,
      description = "Modern architectural landmark station in HafenCity."
    )
  )

  val lines = listOf(
    Line("U1", "U-Bahn U1", "U-Bahn", "#0065BD"),
    Line("U2", "U-Bahn U2", "U-Bahn", "#E30613"),
    Line("U3", "U-Bahn U3", "U-Bahn", "#FFCC00"),
    Line("U4", "U-Bahn U4", "U-Bahn", "#00A2E8"),
    Line("S1", "S-Bahn S1", "S-Bahn", "#009639"),
    Line("S2", "S-Bahn S2", "S-Bahn", "#8A2BE2"),
    Line("S3", "S-Bahn S3", "S-Bahn", "#E4007C"),
    Line("S5", "S-Bahn S5", "S-Bahn", "#00539F"),
    Line("RE", "Regionalbahn RE", "Regional", "#708090"),
    Line("F62", "HADAG Fähre 62", "Ferry", "#008A93")
  )

  fun getDeparturesForStation(stationId: String): List<Departure> {
    return when (stationId) {
      "hbf" -> listOf(
        Departure("d1", "hbf", "S1", "Wedel", "03:45", "03:45", "Gl. 1", 0, false),
        Departure("d2", "hbf", "U3", "Barmbek (Ring)", "03:47", "03:49", "Gl. 5", 2, false, "Leichte Verzögerung"),
        Departure("d3", "hbf", "U2", "Niendorf Nord", "03:50", "03:50", "Gl. 6", 0, false),
        Departure("d4", "hbf", "S3", "Pinneberg", "03:53", "03:56", "Gl. 3", 3, false),
        Departure("d5", "hbf", "RE", "Rostock Hbf", "04:02", "04:02", "Gl. 13", 0, false)
      )
      "jungfernstieg" -> listOf(
        Departure("d6", "jungfernstieg", "U1", "Ochsenzoll", "03:46", "03:46", "Gl. 1", 0, false),
        Departure("d7", "jungfernstieg", "U2", "Mümmelmannsberg", "03:48", "03:51", "Gl. 2", 3, false),
        Departure("d8", "jungfernstieg", "U4", "Elbbrücken", "03:52", "03:52", "Gl. 4", 0, false),
        Departure("d9", "jungfernstieg", "S3", "Stade", "03:55", "03:55", "Gl. 5", 0, false)
      )
      "landungsbruecken" -> listOf(
        Departure("d10", "landungsbruecken", "F62", "Finkenwerder", "03:45", "03:45", "Anleger 2", 0, false),
        Departure("d11", "landungsbruecken", "U3", "Wandsbek-Gartenstadt", "03:48", "03:48", "Gl. 1", 0, false),
        Departure("d12", "landungsbruecken", "S1", "Airport / Poppenbüttel", "03:51", "03:54", "Gl. 2", 3, false)
      )
      else -> listOf(
        Departure("d13", stationId, "U1", "Hauptbahnhof", "03:48", "03:48", "Gl. 1", 0, false),
        Departure("d14", stationId, "S1", "Wedel", "03:52", "03:55", "Gl. 2", 3, false)
      )
    }
  }

  fun planJourney(originId: String, destId: String, stepFree: Boolean): List<JourneyOption> {
    val originStation = stations.find { it.id == originId } ?: stations[0]
    val destStation = stations.find { it.id == destId } ?: stations[1]

    if (originStation.id == destStation.id) {
      return emptyList()
    }

    return listOf(
      JourneyOption(
        id = "opt_1",
        origin = originStation.name,
        destination = destStation.name,
        departureTime = "03:48",
        arrivalTime = "04:06",
        durationMinutes = 18,
        transfersCount = 0,
        walkingMeters = 150,
        priceEuro = 3.50,
        legs = listOf(
          JourneyLeg(
            mode = "U-Bahn",
            lineName = "U3",
            originStation = originStation.name,
            destinationStation = destStation.name,
            departureTime = "03:48",
            arrivalTime = "04:02",
            platform = "Gl. 1",
            durationMinutes = 14,
            instructionDe = "Direkte Fahrt mit U3 Richtung Wandsbek-Gartenstadt",
            instructionEn = "Direct trip on U3 towards Wandsbek-Gartenstadt"
          )
        ),
        warning = if (!originStation.isLiftOperational || !destStation.isLiftOperational) "Achtung: Aufzugsstörung auf der Strecke!" else null
      ),
      JourneyOption(
        id = "opt_2",
        origin = originStation.name,
        destination = destStation.name,
        departureTime = "03:51",
        arrivalTime = "04:12",
        durationMinutes = 21,
        transfersCount = 1,
        walkingMeters = 220,
        priceEuro = 3.50,
        legs = listOf(
          JourneyLeg(
            mode = "S-Bahn",
            lineName = "S1",
            originStation = originStation.name,
            destinationStation = "Hauptbahnhof",
            departureTime = "03:51",
            arrivalTime = "03:59",
            platform = "Gl. 2",
            durationMinutes = 8,
            instructionDe = "Mit S1 bis Hamburg Hauptbahnhof fahren",
            instructionEn = "Take S1 to Hamburg Hauptbahnhof"
          ),
          JourneyLeg(
            mode = "U-Bahn",
            lineName = "U2",
            originStation = "Hauptbahnhof",
            destinationStation = destStation.name,
            departureTime = "04:04",
            arrivalTime = "04:12",
            platform = "Gl. 6",
            durationMinutes = 8,
            instructionDe = "Umsteigen in U2 Richtung Niendorf Nord",
            instructionEn = "Transfer to U2 towards Niendorf Nord"
          )
        )
      )
    )
  }

  val disruptions = listOf(
    Disruption(
      id = "dis_1",
      lineId = "U3",
      titleDe = "Aufzugsstörung Barmbek",
      titleEn = "Elevator Outage Barmbek",
      descriptionDe = "Der Fahrstuhl zum U-Bahnsteig ist wegen Wartungsarbeiten außer Betrieb. Bitte nutzen Sie Hauptbahnhof als barrierefreie Alternative.",
      descriptionEn = "The elevator to the U-Bahn platform is out of service for maintenance. Please use Hauptbahnhof as a step-free alternative.",
      severity = "LiftOutage"
    ),
    Disruption(
      id = "dis_2",
      lineId = "S1",
      titleDe = "Gleisbauarbeiten Wedel",
      titleEn = "Track Maintenance Wedel",
      descriptionDe = "Zwischen Blankenese und Wedel kommt es zu Verzögerungen von ca. 5 Minuten.",
      descriptionEn = "Delays of approx. 5 minutes between Blankenese and Wedel.",
      severity = "Delay"
    )
  )

  val tickets = listOf(
    TicketProduct(
      id = "single",
      titleDe = "Einzelkarte Hamburg AB",
      titleEn = "Single Ticket Hamburg AB",
      price = "€ 3.50",
      descriptionDe = "Gültig für eine Einzelfahrt im Stadtgebiet Hamburg (AB). 2 Stunden Fahrzeit.",
      descriptionEn = "Valid for one single journey in Hamburg urban area (AB). 2 hours travel time.",
      category = "Single"
    ),
    TicketProduct(
      id = "day",
      titleDe = "9Uhr-Tageskarte AB",
      titleEn = "9 AM Day Ticket AB",
      price = "€ 8.40",
      descriptionDe = "Beliebig viele Fahrten ab 9 Uhr morgens bis 6 Uhr am Folgetag im HVV-Netz.",
      descriptionEn = "Unlimited travel from 9 AM until 6 AM the following day across the HVV network.",
      category = "Day"
    ),
    TicketProduct(
      id = "deutschlandticket",
      titleDe = "Deutschlandticket (D-Ticket)",
      titleEn = "Deutschlandticket (D-Ticket)",
      price = "€ 49.00 / Monat",
      descriptionDe = "Bundesweiter Nah- und Regionalverkehr im monatlichen Abo. Jederzeit kündbar.",
      descriptionEn = "Germany-wide local and regional transit in a monthly subscription. Cancel anytime.",
      category = "Subscription"
    ),
    TicketProduct(
      id = "semester",
      titleDe = "HVV-Semesterticket",
      titleEn = "HVV Semester Ticket",
      price = "Immatrikuliert",
      descriptionDe = "Das Solidarmodell für Studierende an Hamburger Hochschulen.",
      descriptionEn = "The solidarity model for students at Hamburg universities.",
      category = "Subscription"
    )
  )
}
