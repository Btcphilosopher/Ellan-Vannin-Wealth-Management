package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.HamburgBottomBar
import com.example.ui.dialogs.JourneyResultsDialog
import com.example.ui.dialogs.LiveJourneyScreen
import com.example.ui.dialogs.StationDetailSheet
import com.example.ui.tabs.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MetroViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: MetroViewModel = viewModel()
      val settings = viewModel.settings

      MyApplicationTheme(darkTheme = false) {
        var showJourneyResults by remember { mutableStateOf(false) }
        var showStationDetail by remember { mutableStateOf(false) }

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          bottomBar = {
            Column {
              viewModel.activeJourney?.let { journey ->
                LiveJourneyScreen(
                  viewModel = viewModel,
                  journey = journey,
                  onStop = { viewModel.stopLiveJourney() }
                )
              }
              HamburgBottomBar(
                currentTab = viewModel.currentTab,
                onTabSelected = { viewModel.setTab(it) },
                settings = settings
              )
            }
          }
        ) { innerPadding ->
          Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            when (viewModel.currentTab) {
              0 -> HomeScreen(
                viewModel = viewModel,
                onNavigateTab = { viewModel.setTab(it) },
                onOpenJourneyResults = { showJourneyResults = true }
              )
              1 -> MapScreen(
                viewModel = viewModel,
                onOpenStationDetail = { station ->
                  viewModel.selectStation(station)
                  showStationDetail = true
                }
              )
              2 -> DeparturesScreen(viewModel = viewModel)
              3 -> TicketsScreen(viewModel = viewModel)
              4 -> ProfileScreen(viewModel = viewModel)
            }

            if (showJourneyResults) {
              JourneyResultsDialog(
                viewModel = viewModel,
                onDismiss = { showJourneyResults = false },
                onStartLive = { journey ->
                  viewModel.startLiveJourney(journey)
                }
              )
            }

            if (showStationDetail && viewModel.selectedStation != null) {
              StationDetailSheet(
                viewModel = viewModel,
                station = viewModel.selectedStation!!,
                onDismiss = { showStationDetail = false }
              )
            }
          }
        }
      }
    }
  }
}
