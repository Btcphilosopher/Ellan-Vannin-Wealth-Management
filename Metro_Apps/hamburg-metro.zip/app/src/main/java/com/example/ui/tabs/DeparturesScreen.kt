package com.example.ui.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.LineBadge
import com.example.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeparturesScreen(viewModel: MetroViewModel) {
  val settings = viewModel.settings
  val isDe = settings.language == "de"
  var stationExpanded by remember { mutableStateOf(false) }

  val currentStation = viewModel.selectedStation ?: viewModel.stations[0]

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = if (isDe) "Live-Abfahrten" else "Live Departures",
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
      )
      IconButton(onClick = { viewModel.loadDeparturesForStation(currentStation.id) }) {
        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
      }
    }

    // Station selector dropdown
    ExposedDropdownMenuBox(
      expanded = stationExpanded,
      onExpandedChange = { stationExpanded = !stationExpanded }
    ) {
      OutlinedTextField(
        value = currentStation.name,
        onValueChange = {},
        readOnly = true,
        label = { Text(if (isDe) "Haltestelle wählen" else "Select Station") },
        leadingIcon = { Icon(Icons.Default.Train, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = stationExpanded) },
        modifier = Modifier
          .fillMaxWidth()
          .menuAnchor()
      )
      ExposedDropdownMenu(
        expanded = stationExpanded,
        onDismissRequest = { stationExpanded = false }
      ) {
        viewModel.stations.forEach { station ->
          DropdownMenuItem(
            text = { Text(station.name) },
            onClick = {
              viewModel.selectStation(station)
              stationExpanded = false
            }
          )
        }
      }
    }

    // Station info badge
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Text(text = currentStation.description, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          currentStation.platforms.forEach { platform ->
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = MaterialTheme.colorScheme.surface
            ) {
              Text(
                text = platform,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                fontSize = 11.sp
              )
            }
          }
        }
      }
    }

    Text(
      text = if (isDe) "Nächste Abfahrten" else "Upcoming Departures",
      fontWeight = FontWeight.Bold,
      fontSize = 16.sp
    )

    LazyColumn(
      modifier = Modifier.fillMaxWidth().weight(1f),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(viewModel.departuresForSelected) { dep ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              modifier = Modifier.weight(1f)
            ) {
              LineBadge(lineId = dep.lineId)
              Column {
                Text(
                  text = dep.destination,
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp
                )
                Text(
                  text = dep.platform,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                dep.serviceAlert?.let { alert ->
                  Text(
                    text = alert,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Medium
                  )
                }
              }
            }

            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = dep.predictedTime,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = if (dep.delayMinutes > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
              )
              if (dep.delayMinutes > 0) {
                Text(
                  text = "+${dep.delayMinutes} Min",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.error
                )
              } else {
                Text(
                  text = if (isDe) "pünktlich" else "on time",
                  fontSize = 11.sp,
                  color = Color(0xFF009639)
                )
              }
            }
          }
        }
      }
    }
  }
}
