package com.example.ui.tabs

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Station
import com.example.ui.components.LineBadge
import com.example.viewmodel.MetroViewModel

@Composable
fun MapScreen(viewModel: MetroViewModel, onOpenStationDetail: (Station) -> Unit) {
  val settings = viewModel.settings
  val isDe = settings.language == "de"
  var viewMode by remember { mutableStateOf("schematic") } // "schematic" or "list"

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = if (isDe) "HVV Liniennetz Hamburg" else "Hamburg Transit Map",
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
      )
      SingleChoiceSegmentedButtonRow {
        SegmentedButton(
          selected = viewMode == "schematic",
          onClick = { viewMode = "schematic" },
          shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
        ) {
          Text(if (isDe) "Schematisch" else "Schematic")
        }
        SegmentedButton(
          selected = viewMode == "list",
          onClick = { viewMode = "list" },
          shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
        ) {
          Text(if (isDe) "Liste" else "List")
        }
      }
    }

    if (viewMode == "schematic") {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      ) {
        Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Draw U3 Ring line
            drawCircle(
              color = Color(0xFFFFCC00),
              radius = w * 0.35f,
              center = Offset(w * 0.5f, h * 0.5f),
              style = Stroke(width = 8f)
            )

            // Draw U1/U2 axes
            drawLine(
              color = Color(0xFF0065BD),
              start = Offset(w * 0.2f, h * 0.2f),
              end = Offset(w * 0.8f, h * 0.8f),
              strokeWidth = 8f
            )
            drawLine(
              color = Color(0xFFE30613),
              start = Offset(w * 0.2f, h * 0.8f),
              end = Offset(w * 0.8f, h * 0.2f),
              strokeWidth = 8f
            )
          }

          Column(
            modifier = Modifier.align(Alignment.TopStart),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Text(
              text = if (isDe) "Tippen Sie auf Stationen für Live-Daten" else "Tap stations for live data",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          // Interactive Station Pins overlay
          Column(
            modifier = Modifier
              .align(Alignment.Center)
              .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            viewModel.stations.take(5).forEach { station ->
              Button(
                onClick = {
                  viewModel.selectStation(station)
                  onOpenStationDetail(station)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(station.name, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(viewModel.stations) { station ->
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                viewModel.selectStation(station)
                onOpenStationDetail(station)
              }
          ) {
            Row(
              modifier = Modifier.padding(16.dp).fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(text = station.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(text = station.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  station.lines.forEach { line -> LineBadge(lineId = line) }
                }
              }
              Icon(Icons.Default.ChevronRight, contentDescription = null)
            }
          }
        }
      }
    }
  }
}
