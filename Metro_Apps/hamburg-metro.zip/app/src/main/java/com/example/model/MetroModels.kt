package com.example.model

data class Station(
  val id: String,
  val name: String,
  val modes: List<String>, // "U", "S", "Bus", "Ferry"
  val lines: List<String>, // "U1", "U2", "S1", etc.
  val platforms: List<String>,
  val isStepFree: Boolean,
  val isLiftOperational: Boolean,
  val zone: String = "Hamburg AB",
  val description: String = ""
)

data class Line(
  val id: String,
  val name: String,
  val type: String, // "U-Bahn", "S-Bahn", "MetroBus", "Ferry"
  val colorHex: String
)

data class Departure(
  val id: String,
  val stationId: String,
  val lineId: String,
  val destination: String,
  val scheduledTime: String,
  val predictedTime: String,
  val platform: String,
  val delayMinutes: Int,
  val isCancelled: Boolean,
  val serviceAlert: String? = null
)

data class JourneyLeg(
  val mode: String, // "Walk", "U-Bahn", "S-Bahn", "Bus"
  val lineName: String?,
  val originStation: String,
  val destinationStation: String,
  val departureTime: String,
  val arrivalTime: String,
  val platform: String?,
  val durationMinutes: Int,
  val instructionDe: String,
  val instructionEn: String
)

data class JourneyOption(
  val id: String,
  val origin: String,
  val destination: String,
  val departureTime: String,
  val arrivalTime: String,
  val durationMinutes: Int,
  val transfersCount: Int,
  val walkingMeters: Int,
  val priceEuro: Double,
  val legs: List<JourneyLeg>,
  val warning: String? = null
)

data class Disruption(
  val id: String,
  val lineId: String,
  val titleDe: String,
  val titleEn: String,
  val descriptionDe: String,
  val descriptionEn: String,
  val severity: String, // "Delay", "Closure", "LiftOutage"
  val source: String = "HVV Betriebszentrale",
  val lastUpdated: String = "Vor 5 Min"
)

data class TicketProduct(
  val id: String,
  val titleDe: String,
  val titleEn: String,
  val price: String,
  val descriptionDe: String,
  val descriptionEn: String,
  val category: String // "Single", "Day", "Subscription"
)

data class AppSettings(
  val language: String = "de", // "de" or "en"
  val stepFreeOnly: Boolean = false,
  val highContrast: Boolean = false,
  val largeText: Boolean = false,
  val notificationsEnabled: Boolean = true
)
