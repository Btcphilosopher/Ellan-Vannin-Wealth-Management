package com.example.ui.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Station
import com.example.ui.components.LineBadge
import com.example.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: MetroViewModel, onNavigateTab: (Int) -> Unit, onOpenJourneyResults: () -> Unit) {
  val settings = viewModel.settings
  val isDe = settings.language == "de"

  var originExpanded by remember { mutableStateOf(false) }
  var destExpanded by remember { mutableStateOf(false) }

  val originStation = viewModel.stations.find { it.id == viewModel.originStationId } ?: viewModel.stations[0]
  val destStation = viewModel.stations.find { it.id == viewModel.destinationStationId } ?: viewModel.stations[1]

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(16.dp))
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "HAMBURG METRO",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = if (isDe) "Hamburg bewegt sich." else "Move through Hamburg, smarter.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        IconButton(onClick = { viewModel.updateLanguage(if (isDe) "en" else "de") }) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.secondaryContainer
          ) {
            Text(
              text = if (isDe) "EN" else "DE",
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }
        }
      }
    }

    // Disruption Banner if any
    if (viewModel.disruptions.isNotEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Warning, contentDescription = "Alert", tint = MaterialTheme.colorScheme.error)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (isDe) viewModel.disruptions[0].titleDe else viewModel.disruptions[0].titleEn,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onErrorContainer
              )
              Text(
                text = if (isDe) viewModel.disruptions[0].descriptionDe else viewModel.disruptions[0].descriptionEn,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onErrorContainer
              )
            }
          }
        }
      }
    }

    // Journey Planner Card
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Text(
            text = if (isDe) "Verbindung suchen" else "Plan Journey",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
          )

          // Origin selector
          ExposedDropdownMenuBox(
            expanded = originExpanded,
            onExpandedChange = { originExpanded = !originExpanded }
          ) {
            OutlinedTextField(
              value = originStation.name,
              onValueChange = {},
              readOnly = true,
              label = { Text(if (isDe) "Startbahnhof" else "Origin") },
              leadingIcon = { Icon(Icons.Default.MyLocation, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = originExpanded) },
              modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
            )
            ExposedDropdownMenu(
              expanded = originExpanded,
              onDismissRequest = { originExpanded = false }
            ) {
              viewModel.stations.forEach { station ->
                DropdownMenuItem(
                  text = { Text(station.name) },
                  onClick = {
                    viewModel.originStationId = station.id
                    originExpanded = false
                  }
                )
              }
            }
          }

          // Destination selector
          ExposedDropdownMenuBox(
            expanded = destExpanded,
            onExpandedChange = { destExpanded = !destExpanded }
          ) {
            OutlinedTextField(
              value = destStation.name,
              onValueChange = {},
              readOnly = true,
              label = { Text(if (isDe) "Zielbahnhof" else "Destination") },
              leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = destExpanded) },
              modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
            )
            ExposedDropdownMenu(
              expanded = destExpanded,
              onDismissRequest = { destExpanded = false }
            ) {
              viewModel.stations.forEach { station ->
                DropdownMenuItem(
                  text = { Text(station.name) },
                  onClick = {
                    viewModel.destinationStationId = station.id
                    destExpanded = false
                  }
                )
              }
            }
          }

          Button(
            onClick = {
              viewModel.planJourney()
              onOpenJourneyResults()
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
          ) {
            Icon(Icons.Default.Search, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(if (isDe) "Route berechnen" else "Find Connections")
          }
        }
      }
    }

    // Quick Actions Grid
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        QuickActionButton(
          title = if (isDe) "Abfahrten" else "Departures",
          icon = Icons.Default.Schedule,
          modifier = Modifier.weight(1f)
        ) {
          onNavigateTab(2)
        }
        QuickActionButton(
          title = if (isDe) "Liniennetz" else "Network Map",
          icon = Icons.Default.Map,
          modifier = Modifier.weight(1f)
        ) {
          onNavigateTab(1)
        }
        QuickActionButton(
          title = if (isDe) "Tickets" else "Tickets",
          icon = Icons.Default.ConfirmationNumber,
          modifier = Modifier.weight(1f)
        ) {
          onNavigateTab(3)
        }
      }
    }

    // Nearby Stations Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isDe) "Haltestellen in der Nähe" else "Nearby Stations",
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp
        )
        TextButton(onClick = { onNavigateTab(1) }) {
          Text(if (isDe) "Alle anzeigen" else "View all")
        }
      }
    }

    items(viewModel.stations.take(4)) { station ->
      StationCard(station = station, isDe = isDe, onClick = {
        viewModel.selectStation(station)
        onNavigateTab(2)
      })
    }
  }
}

@Composable
fun QuickActionButton(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    modifier = modifier.clickable { onClick() }
  ) {
    Column(
      modifier = Modifier
        .padding(12.dp)
        .fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary)
      Text(title, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
  }
}

@Composable
fun StationCard(station: Station, isDe: Boolean, onClick: () -> Unit) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
  ) {
    Row(
      modifier = Modifier
        .padding(12.dp)
        .fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.weight(1f)
      ) {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.primaryContainer,
          modifier = Modifier.size(40.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Default.DirectionsTransit, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          }
        }
        Column {
          Text(text = station.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            station.lines.take(4).forEach { line ->
              LineBadge(lineId = line)
            }
          }
        }
      }
      if (station.isStepFree) {
        Icon(Icons.Default.Accessible, contentDescription = "Step free", tint = androidx.compose.ui.graphics.Color(0xFF009639))
      }
    }
  }
}
