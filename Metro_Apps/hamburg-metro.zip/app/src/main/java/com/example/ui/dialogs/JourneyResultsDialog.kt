package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.JourneyOption
import com.example.ui.components.LineBadge
import com.example.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyResultsDialog(viewModel: MetroViewModel, onDismiss: () -> Unit, onStartLive: (JourneyOption) -> Unit) {
  val settings = viewModel.settings
  val isDe = settings.language == "de"

  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.85f)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isDe) "Verbindungsergebnisse" else "Journey Options",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary
        )
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }

      if (viewModel.journeyResults.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Text(text = if (isDe) "Keine Verbindungen gefunden." else "No connections found.")
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxWidth().weight(1f),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(viewModel.journeyResults) { option ->
            Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                      text = "${option.departureTime} -> ${option.arrivalTime}",
                      fontWeight = FontWeight.Bold,
                      fontSize = 16.sp
                    )
                  }
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                  ) {
                    Text(
                      text = "${option.durationMinutes} Min",
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp,
                      color = MaterialTheme.colorScheme.primary
                    )
                  }
                }

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = if (isDe) "${option.transfersCount} Umstieg(e) • ${option.walkingMeters}m Fußweg" else "${option.transfersCount} transfer(s) • ${option.walkingMeters}m walk",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                  Text(
                    text = "€ %.2f".format(option.priceEuro),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                  )
                }

                option.warning?.let { warning ->
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                  ) {
                    Text(
                      text = warning,
                      modifier = Modifier.padding(8.dp),
                      fontSize = 11.sp,
                      color = MaterialTheme.colorScheme.onErrorContainer
                    )
                  }
                }

                // Legs list
                option.legs.forEach { leg ->
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    leg.lineName?.let { LineBadge(lineId = it) }
                    Text(
                      text = if (isDe) leg.instructionDe else leg.instructionEn,
                      fontSize = 13.sp,
                      modifier = Modifier.weight(1f)
                    )
                  }
                }

                Button(
                  onClick = {
                    onStartLive(option)
                    onDismiss()
                  },
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Icon(Icons.Default.Navigation, contentDescription = null)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(if (isDe) "Live-Fahrt starten" else "Start Live Navigation")
                }
              }
            }
          }
        }
      }
    }
  }
}
