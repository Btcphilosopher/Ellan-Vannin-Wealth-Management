package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppLanguage
import com.example.data.Translations
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34]) // Use 34 to match typical JVM targets
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Moldova Rail", appName)
    }

    @Test
    fun `verify localizations and translations dictionary`() {
        // App title localizations
        assertEquals("MOLDOVA RAIL", Translations.get("app_title", AppLanguage.RO))
        assertEquals("MOLDOVA RAIL", Translations.get("app_title", AppLanguage.EN))
        
        // Form field from
        assertEquals("Plecare din", Translations.get("from", AppLanguage.RO))
        assertEquals("From", Translations.get("from", AppLanguage.EN))
        assertEquals("Откуда", Translations.get("from", AppLanguage.RU))

        // Check fallback for missing keys
        assertEquals("invalid_missing_key_demo", Translations.get("invalid_missing_key_demo", AppLanguage.EN))
    }

    @Test
    fun `verify secure anti-fraud hash determinism`() {
        // Deterministic generation algorithm verification
        val train = "047"
        val carriage = "03"
        val seat = "18"
        val passenger = "TOM LOVEITT"
        val date = "2026-10-02"

        val secretInput1 = "$train|$carriage|$seat|$passenger|$date|MOLDOVA_RAIL_KEY_2026"
        val code1 = secretInput1.hashCode().toLong()
        val hex1 = java.lang.Long.toHexString(code1).uppercase().takeLast(6)

        val secretInput2 = "$train|$carriage|$seat|$passenger|$date|MOLDOVA_RAIL_KEY_2026"
        val code2 = secretInput2.hashCode().toLong()
        val hex2 = java.lang.Long.toHexString(code2).uppercase().takeLast(6)

        assertEquals(hex1, hex2)
        assertTrue(hex1.length <= 6)
    }
}
