package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Dao
interface StationDao {
    @Query("SELECT * FROM stations")
    fun getAllStationsFlow(): Flow<List<StationEntity>>

    @Query("SELECT * FROM stations")
    suspend fun getAllStations(): List<StationEntity>

    @Query("SELECT * FROM stations WHERE code = :code LIMIT 1")
    suspend fun getStationByCode(code: String): StationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)
}

@Dao
interface TrainDao {
    @Query("SELECT * FROM trains")
    fun getAllTrainsFlow(): Flow<List<TrainEntity>>

    @Query("SELECT * FROM trains WHERE trainNumber = :trainNumber LIMIT 1")
    suspend fun getTrainByNumber(trainNumber: String): TrainEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrains(trains: List<TrainEntity>)
}

@Dao
interface ScheduleDao {
    @Query("SELECT * FROM schedules")
    fun getAllSchedulesFlow(): Flow<List<ScheduleEntity>>

    @Query("SELECT * FROM schedules WHERE fromStationCode = :fromCode AND toStationCode = :toCode")
    suspend fun searchSchedules(fromCode: String, toCode: String): List<ScheduleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedules(schedules: List<ScheduleEntity>)
}

@Dao
interface TicketDao {
    @Query("SELECT * FROM tickets ORDER BY purchaseTimestamp DESC")
    fun getAllTicketsFlow(): Flow<List<TicketEntity>>

    @Query("SELECT * FROM tickets WHERE id = :id LIMIT 1")
    suspend fun getTicketById(id: String): TicketEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Query("UPDATE tickets SET status = :status WHERE id = :id")
    suspend fun updateTicketStatus(id: String, status: String)
}

@Dao
interface PassengerDao {
    @Query("SELECT * FROM passengers")
    fun getAllPassengersFlow(): Flow<List<PassengerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPassenger(passenger: PassengerEntity)

    @Query("DELETE FROM passengers WHERE id = :id")
    suspend fun deletePassenger(id: Long)
}

@Database(
    entities = [
        StationEntity::class,
        TrainEntity::class,
        ScheduleEntity::class,
        TicketEntity::class,
        PassengerEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun stationDao(): StationDao
    abstract fun trainDao(): TrainDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun ticketDao(): TicketDao
    abstract fun passengerDao(): PassengerDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "moldova_rail_db"
                )
                .addCallback(DatabaseSeederCallback(context))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class DatabaseSeederCallback(private val context: Context) : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        // Seed database on creation in background thread
        CoroutineScope(Dispatchers.IO).launch {
            val database = AppDatabase.getDatabase(context)
            seedInitialData(database)
        }
    }

    private suspend fun seedInitialData(db: AppDatabase) {
        // 1. Seed Stations
        val stations = listOf(
            StationEntity(
                code = "CHISINAU",
                nameRo = "Chișinău Gara",
                nameEn = "Chisinau Central",
                nameRu = "Кишинёв Вокзал",
                latitude = 47.0131f,
                longitude = 28.8576f,
                addressRo = "Piața Gării 1, Chișinău",
                addressEn = "1 Station Square, Chisinau",
                addressRu = "Вокзальная площадь 1, Кишинёв",
                facilitiesRo = "Wi-Fi Gratuit • Cafenea • Birou de Informații • Dulapuri Bagaje • Case de Bilete Electronice • Bancomat",
                facilitiesEn = "Free Wi-Fi • Café • Info Desk • Luggage Lockers • Digital Ticketing Office • ATM",
                facilitiesRu = "Бесплатный Wi-Fi • Кафе • Справочное бюро • Камеры хранения • Электронные кассы • Банкомат",
                platformInfoRo = "Peronul 1: Curse Internaționale (București, Iași). Peronul 2 și 3: Curse Regionale.",
                platformInfoEn = "Platform 1: International Trains (Bucharest, Iasi). Platforms 2 & 3: Regional Connections.",
                platformInfoRu = "Платформа 1: Международные рейсы (Бухарест, Яссы). Платформы 2 и 3: Региональные рейсы.",
                connectionsRo = "Troleibuze: 1, 4, 5, 8, 17 • Autobuze: 19, 33, 44, 49 • Taxi autorizat",
                connectionsEn = "Trolleybuses: 1, 4, 5, 8, 17 • Buses: 19, 33, 44, 49 • Authorized Taxis",
                connectionsRu = "Троллейбусы: 1, 4, 5, 8, 17 • Автобусы: 19, 33, 44, 49 • Авторизованные такси",
                accessibilityRo = "Rampe de acces • Toalete adaptate • Personal de asistență dedicat • Ghidaj tactil",
                accessibilityEn = "Wheelchair ramps • Accessible restrooms • Assistance staff • Tactile paths",
                accessibilityRu = "Пандусы • Специальные уборные • Выделенный персонал поддержки • Тактильная разметка"
            ),
            StationEntity(
                code = "BALTI",
                nameRo = "Bălți-Slobozia",
                nameEn = "Balti-Slobozia",
                nameRu = "Бельцы-Слободзея",
                latitude = 47.7686f,
                longitude = 27.9514f,
                addressRo = "Strada Feroviarilor 18, Bălți",
                addressEn = "18 Feroviarilor St, Balti",
                addressRu = "ул. Железнодорожников 18, Бельцы",
                facilitiesRo = "Sală de Așteptare Încălzită • Magazin Alimentar • Case de Bilete • Parcare",
                facilitiesEn = "Heated Waiting Room • Grocery Store • Ticket Offices • Parking lot",
                facilitiesRu = "Отапливаемый зал ожидания • Продуктовый магазин • Билетные кассы • Парковка",
                platformInfoRo = "Peronul 1: Trenuri spre Chișinău și Ungheni. Peronul 2: Trenuri de marfă și regionale.",
                platformInfoEn = "Platform 1: Chisinau and Ungheni services. Platform 2: Local freight & regional lines.",
                platformInfoRu = "Платформа 1: Поезда в Кишинёв и Унгены. Платформа 2: Грузовые и местные поезда.",
                connectionsRo = "Troleibuzul: 2 • Microbuze locale • Taxi local",
                connectionsEn = "Trolleybus: 2 • Local minibuses • Local taxi dispatch",
                connectionsRu = "Троллейбус: 2 • Местные маршрутки • Служба такси",
                accessibilityRo = "Rampă mobilă disponibilă la cerere • Locuri de parcare dedicate",
                accessibilityEn = "Mobile ramp available on request • Dedicated parking bays",
                accessibilityRu = "Мобильный пандус по запросу • Выделенные парковочные места"
            ),
            StationEntity(
                code = "UNGHENI",
                nameRo = "Ungheni Gara de Frontieră",
                nameEn = "Ungheni Border Station",
                nameRu = "Унгены Пограничный вокзал",
                latitude = 47.2081f,
                longitude = 27.7947f,
                addressRo = "Strada Gării 2, Ungheni",
                addressEn = "2 Garii St, Ungheni",
                addressRu = "ул. Вокзальная 2, Унгены",
                facilitiesRo = "Control vamal și de frontieră • Schimb valutar • Zone Duty-Free • Case de bilete internaționale",
                facilitiesEn = "Customs & Border Control • Currency Exchange • Duty-free shop • International ticketing",
                facilitiesRu = "Таможенный и пограничный контроль • Обмен валют • Магазин Duty-Free • Международные кассы",
                platformInfoRo = "Peronul de ecartament dublu: Schimbare boghiu trenuri spre România • Linii locale spre Chișinău",
                platformInfoEn = "Dual-gauge platform: Bogie exchange for Romanian border crossing • Domestic lines to Chisinau",
                platformInfoRu = "Двухколейная платформа: Смена тележек вагонов в Румынию • Внутренние линии в Кишинёв",
                connectionsRo = "Microbuze interurbane • Taxiuri autorizate",
                connectionsEn = "Intercity minibuses • Authorized local taxis",
                connectionsRu = "Междугородние маршрутки • Авторизованные такси",
                accessibilityRo = "Lifturi la peroane • Personal disponibil 24/7 pentru asistență transfrontalieră",
                accessibilityEn = "Elevators to platforms • Support staff available 24/7 for cross-border transit",
                accessibilityRu = "Лифты к платформам • Круглосуточная поддержка при прохождении границы"
            ),
            StationEntity(
                code = "TIRASPOL",
                nameRo = "Tiraspol Gara",
                nameEn = "Tiraspol Central",
                nameRu = "Тирасполь Вокзал",
                latitude = 46.8485f,
                longitude = 29.6262f,
                addressRo = "Strada Lenin 1B, Tiraspol",
                addressEn = "1B Lenin St, Tiraspol",
                addressRu = "ул. Ленина 1Б, Тирасполь",
                facilitiesRo = "Sală de așteptare • Case de bilete • Punct informativ turistic",
                facilitiesEn = "Waiting Room • Ticketing Offices • Tourism Info point",
                facilitiesRu = "Зал ожидания • Билетные кассы • Туристический инфопункт",
                platformInfoRo = "Peronul 1: Deservește trenurile de pe ruta Chișinău-Odesa.",
                platformInfoEn = "Platform 1: Services running Chisinau-Odesa line.",
                platformInfoRu = "Платформа 1: Обслуживает поезда на линии Кишинёв-Одесса.",
                connectionsRo = "Troleibuze urbane • Taxi local",
                connectionsEn = "Urban trolleybuses • Local taxi services",
                connectionsRu = "Городские троллейбусы • Местное такси",
                accessibilityRo = "Nivel plat pe peronul principal",
                accessibilityEn = "Flat step-free entry on main platform",
                accessibilityRu = "Плоский безбарьерный вход на главную платформу"
            ),
            StationEntity(
                code = "CAHUL",
                nameRo = "Cahul Sud Gara",
                nameEn = "Cahul South Station",
                nameRu = "Кагул Южный Вокзал",
                latitude = 45.8941f,
                longitude = 28.1824f,
                addressRo = "Strada Gării 30, Cahul",
                addressEn = "30 Garii St, Cahul",
                addressRu = "ул. Вокзальная 30, Кагул",
                facilitiesRo = "Case de bilete • Cafenea locală • Sală de odihnă",
                facilitiesEn = "Ticket counters • Local Cafe • Rest area",
                facilitiesRu = "Билетные кассы • Местное кафе • Зона отдыха",
                platformInfoRo = "Peronul 1: Trenuri regionale de sud spre Basarabeasca și Cantemir.",
                platformInfoEn = "Platform 1: Southern regional trains towards Basarabeasca & Cantemir.",
                platformInfoRu = "Платформа 1: Южные региональные поезда в Басарабяску и Кантемир.",
                connectionsRo = "Autobuze locale • Taxi",
                connectionsEn = "Local city buses • Taxis",
                connectionsRu = "Местные городские автобусы • Такси",
                accessibilityRo = "Ghidaj tactil • Asistență la cerere",
                accessibilityEn = "Tactile guiding paths • Assistance on-demand",
                accessibilityRu = "Тактильная разметка • Поддержка по запросу"
            ),
            StationEntity(
                code = "BENDER",
                nameRo = "Bender-2 Gara",
                nameEn = "Bender-2 Station",
                nameRu = "Бендеры-2 Вокзал",
                latitude = 46.8288f,
                longitude = 29.4716f,
                addressRo = "Strada Gării 1, Bender",
                addressEn = "1 Garii St, Bender",
                addressRu = "ул. Вокзальная 1, Бендеры",
                facilitiesRo = "Servicii de expediere • Bileterie • Sală mică de așteptare",
                facilitiesEn = "Ticketing • Dispatch services • Compact waiting room",
                facilitiesRu = "Кассы • Службы отправки • Компактный зал ожидания",
                platformInfoRo = "Linii de legătură națională și regională de sud-est.",
                platformInfoEn = "Lines coordinating southeastern domestic & regional links.",
                platformInfoRu = "Линии, координирующие юго-восточные и региональные связи.",
                connectionsRo = "Troleibuze interurbane spre Tiraspol • Taxi",
                connectionsEn = "Intercity trolleybuses to Tiraspol • Local taxis",
                connectionsRu = "Междугородние троллейбусы в Тирасполь • Местные такси",
                accessibilityRo = "Platforme la nivel coborât",
                accessibilityEn = "Low-level step-free platform access",
                accessibilityRu = "Низкоуровневый доступ к платформам"
            ),
            StationEntity(
                code = "COMRAT",
                nameRo = "Comrat Gara",
                nameEn = "Comrat Station",
                nameRu = "Комрат Вокзал",
                latitude = 46.3015f,
                longitude = 28.6558f,
                addressRo = "Bulevardul Victoriei 45, Comrat",
                addressEn = "45 Victoriei Blvd, Comrat",
                addressRu = "Бульвар Победы 45, Комрат",
                facilitiesRo = "Bileterie • Magazin de proximitate",
                facilitiesEn = "Ticketing counter • Convenience store",
                facilitiesRu = "Касса • Удобный магазинчик",
                platformInfoRo = "Linii regionale spre sudul Moldovei.",
                platformInfoEn = "Regional lines towards southern Moldova routes.",
                platformInfoRu = "Региональные линии на южные направления Молдовы.",
                connectionsRo = "Rute de autobuz urban • Taxi local",
                connectionsEn = "Urban bus routes • Local taxi service",
                connectionsRu = "Городские автобусные маршруты • Местное такси",
                accessibilityRo = "Rampă de acces la intrarea principală",
                accessibilityEn = "Entrance ramp available",
                accessibilityRu = "Пандус на главном входе"
            ),
            StationEntity(
                code = "SOROCA",
                nameRo = "Soroca Nord (Terminal)",
                nameEn = "Soroca North (Terminal)",
                nameRu = "Сорока Северная (Терминал)",
                latitude = 48.1561f,
                longitude = 28.2848f,
                addressRo = "Strada Independenței 99, Soroca",
                addressEn = "99 Independentei St, Soroca",
                addressRu = "ул. Независимости 99, Сорока",
                facilitiesRo = "Birou turistic • Case de bilete • Zonă de odihnă",
                facilitiesEn = "Tourist information Desk • Ticketing • Comfortable seating",
                facilitiesRu = "Туристический стол информации • Кассы • Комфортный зал",
                platformInfoRo = "Platformă modernizată pentru rute rapide nord-sud.",
                platformInfoEn = "Modernized platform for fast north-south regional lines.",
                platformInfoRu = "Модернизированная платформа для быстрых северно-южных линий.",
                connectionsRo = "Autobuze municipale • Servicii de taxi",
                connectionsEn = "Municipal bus lines • Taxis",
                connectionsRu = "Муниципальные автобусы • Службы такси",
                accessibilityRo = "Complet accesibil în toate punctele publice",
                accessibilityEn = "Fully wheelchair accessible in all public zones",
                accessibilityRu = "Полная доступность для колясок во всех зонах"
            ),
            StationEntity(
                code = "IASI",
                nameRo = "Iași Gara Socola",
                nameEn = "Iasi Socola Station",
                nameRu = "Яссы Вокзал Сокола",
                latitude = 47.1471f,
                longitude = 27.6186f,
                addressRo = "Strada Gării Socola, Iași, România",
                addressEn = "Socola Station St, Iasi, Romania",
                addressRu = "ул. Вокзал Сокола, Яссы, Румыния",
                facilitiesRo = "Conexiune directă CFR • Case de bilete • Punct vamal RO • Cafenea",
                facilitiesEn = "Direct CFR Connections • Ticket offices • Romanian customs point • Cafe",
                facilitiesRu = "Прямое сообщение CFR • Кассы • Румынская таможня • Кафе",
                platformInfoRo = "Deservește trenul rapid direct CFM Chișinău - Iași (ecartament rusesc).",
                platformInfoEn = "Platform coordinating broad-gauge direct Chisinau - Iasi CFM service.",
                platformInfoRu = "Обслуживает прямой поезд CFM Кишинёв - Яссы (широкая колея).",
                connectionsRo = "Autobuze locale CTP spre Centrul Iașului • Taxiuri",
                connectionsEn = "CTP City buses directly to Iasi Center • Taxis",
                connectionsRu = "Городские автобусы CTP до центра Ясс • Такси",
                accessibilityRo = "Dotat conform standardelor Uniunii Europene",
                accessibilityEn = "Equipped to European Union accessibility standards",
                accessibilityRu = "Оборудован по стандартам доступности Европейского Союза"
            ),
            StationEntity(
                code = "BUCURESTI",
                nameRo = "București Gara de Nord",
                nameEn = "Bucharest North Station",
                nameRu = "Бухарест Северный вокзал",
                latitude = 44.4468f,
                longitude = 26.0750f,
                addressRo = "Piața Gării de Nord 1, București, România",
                addressEn = "1 Gara de Nord Square, Bucharest, Romania",
                addressRu = "Площадь Северного вокзала 1, Бухарест, Румыния",
                facilitiesRo = "Hub feroviar major • Restaurante • Lounge VIP • Servicii Bagaje • Metrou direct",
                facilitiesEn = "Major transport hub • Fine dining • First class lounge • Luggage deposit • Direct Metro",
                facilitiesRu = "Крупнейший вокзал • Рестораны • VIP-лаунж • Багажное отделение • Прямое метро",
                platformInfoRo = "Trenul international 'Prietenia' Chișinău-București sosește de obicei la Peronul 1-4.",
                platformInfoEn = "International sleeper train 'Prietenia' usually arrives at Platforms 1-4.",
                platformInfoRu = "Международный поезд 'Prietenia' обычно прибывает на платформы 1-4.",
                connectionsRo = "Metrou M1 & M4 • Troleibuze și Tramvaie • Autobuz Express spre Aeroport",
                connectionsEn = "Metro M1 & M4 • Trolleybuses & Trams • Express Bus to Otopeni Airport",
                connectionsRu = "Метро M1 и M4 • Троллейбусы и трамваи • Экспресс-автобус до аэропорта",
                accessibilityRo = "Standarde UE de top • Asistență dedicată pentru persoane cu dizabilități",
                accessibilityEn = "Premium EU Standards • Dedicated assistance desk for disabled travelers",
                accessibilityRu = "Европейские стандарты • Специальная стойка помощи маломобильным пассажирам"
            ),
            StationEntity(
                code = "ODESA",
                nameRo = "Odesa Gara Centrală",
                nameEn = "Odesa Central Station",
                nameRu = "Одесса Главный вокзал",
                latitude = 46.4664f,
                longitude = 30.7423f,
                addressRo = "Piața Privokzalna 2, Odesa, Ucraina",
                addressEn = "2 Pryvokzalna Sq, Odesa, Ukraine",
                addressRu = "Привокзальная площадь 2, Одесса, Украина",
                facilitiesRo = "Centru de servicii • Case de bilete • Zone de relaxare • Cafenele",
                facilitiesEn = "Service Center • International counters • Relax lounges • Cafes",
                facilitiesRu = "Сервисный центр • Международные кассы • Зоны отдыха • Кафе",
                platformInfoRo = "Trenul international de pasageri din Moldova sosește la Peronul 1.",
                platformInfoEn = "International passenger train from Moldova arrives at Platform 1.",
                platformInfoRu = "Международный поезд из Молдовы прибывает на платформу 1.",
                connectionsRo = "Tramvaie urbane • Troleibuze • Servicii de taxi autorizate",
                connectionsEn = "City trams • Trolleybuses • Authorized taxis",
                connectionsRu = "Городские трамваи • Троллейбусы • Авторизованные службы такси",
                accessibilityRo = "Rampe de acces modernizate • Personal de servicii disponibil",
                accessibilityEn = "Modernized access ramps • Ground team support available",
                accessibilityRu = "Модернизированные пандусы • Наземная поддержка персонала"
            ),
            StationEntity(
                code = "KYIV",
                nameRo = "Kyiv Gara Centrală",
                nameEn = "Kyiv Central Station",
                nameRu = "Киев Центральный вокзал",
                latitude = 50.4404f,
                longitude = 30.4897f,
                addressRo = "Piața Vokzalna 1, Kyiv, Ucraina",
                addressEn = "1 Vokzalna Square, Kyiv, Ukraine",
                addressRu = "Вокзальная площадь 1, Киев, Украина",
                facilitiesRo = "Cel mai mare hub din Ucraina • Lounge 'Fortress' • Restaurante • Conexiune Metrou direct",
                facilitiesEn = "Largest rail hub in Ukraine • 'Fortress' premium lounge • Food court • Metro connection",
                facilitiesRu = "Крупнейший вокзал Украины • Премиум-лаунж 'Крепость' • Фуд-корт • Станция метро",
                platformInfoRo = "Trenul international de noapte Chișinău - Kyiv sosește la Liniile 1-3.",
                platformInfoEn = "International sleeper Chisinau - Kyiv arrives at Tracks 1-3.",
                platformInfoRu = "Международный ночной поезд Кишинёв - Киев прибывает на пути 1-3.",
                connectionsRo = "Metrou Linia 1 (Vokzalna) • Autobuz Express spre Aeroport • Tramvai Rapid",
                connectionsEn = "Metro Line 1 (Vokzalna) • Express Airport bus • Rapid Tramway",
                connectionsRu = "Метро Линия 1 (Вокзальная) • Экспресс-автобус в аэропорт • Скоростной трамвай",
                accessibilityRo = "Facilități premium • Serviciu dedicat de asistență mobilă",
                accessibilityEn = "Premium accessible infrastructure • On-demand mobile assistance services",
                accessibilityRu = "Удобства премиум-класса • Мобильная помощь по запросу"
            )
        )
        db.stationDao().insertStations(stations)

        // 2. Seed Trains
        val trains = listOf(
            TrainEntity("105", "Prietenia Express", "International", 100, 12),
            TrainEntity("047", "Chisinau - Iasi Express", "InterCity", 120, 5),
            TrainEntity("341", "Chisinau - Balti Regional", "Regional", 80, 4),
            TrainEntity("063", "Kyiv-Chisinau Express", "International", 110, 10),
            TrainEntity("801", "Ungheni Fast Line", "InterCity", 120, 3),
            TrainEntity("451", "Chisinau - Odessa Link", "International", 90, 6),
            TrainEntity("502", "Basarabeasca-Cahul Local", "Regional", 60, 2),
            TrainEntity("221", "Bender-Tiraspol Shuttle", "Regional", 70, 2)
        )
        db.trainDao().insertTrains(trains)

        // 3. Seed Schedules (Timetable)
        val schedules = listOf(
            // CHISINAU -> UNGHENI (And return)
            ScheduleEntity(
                trainNumber = "047",
                fromStationCode = "CHISINAU",
                toStationCode = "UNGHENI",
                departureTime = "18:42",
                arrivalTime = "20:51",
                durationMinutes = 129,
                priceFirstClass = 180.0,
                priceSecondClass = 110.0,
                priceThirdClass = 75.0,
                changesRo = "Direct (Spre Iași)",
                changesEn = "Direct (Bound for Iasi)",
                changesRu = "Прямой (На Яссы)"
            ),
            ScheduleEntity(
                trainNumber = "801",
                fromStationCode = "CHISINAU",
                toStationCode = "UNGHENI",
                departureTime = "07:30",
                arrivalTime = "09:25",
                durationMinutes = 115,
                priceFirstClass = 190.0,
                priceSecondClass = 120.0,
                priceThirdClass = 80.0
            ),
            ScheduleEntity(
                trainNumber = "341",
                fromStationCode = "CHISINAU",
                toStationCode = "UNGHENI",
                departureTime = "14:15",
                arrivalTime = "16:40",
                durationMinutes = 145,
                priceFirstClass = 150.0,
                priceSecondClass = 95.0,
                priceThirdClass = 60.0
            ),
            ScheduleEntity(
                trainNumber = "801",
                fromStationCode = "UNGHENI",
                toStationCode = "CHISINAU",
                departureTime = "10:10",
                arrivalTime = "12:05",
                durationMinutes = 115,
                priceFirstClass = 190.0,
                priceSecondClass = 120.0,
                priceThirdClass = 80.0
            ),
            ScheduleEntity(
                trainNumber = "047",
                fromStationCode = "UNGHENI",
                toStationCode = "CHISINAU",
                departureTime = "21:30",
                arrivalTime = "23:40",
                durationMinutes = 130,
                priceFirstClass = 180.0,
                priceSecondClass = 110.0,
                priceThirdClass = 75.0
            ),

            // CHISINAU -> BALTI (And return)
            ScheduleEntity(
                trainNumber = "341",
                fromStationCode = "CHISINAU",
                toStationCode = "BALTI",
                departureTime = "14:15",
                arrivalTime = "18:05",
                durationMinutes = 230,
                priceFirstClass = 220.0,
                priceSecondClass = 140.0,
                priceThirdClass = 90.0,
                isDirect = false,
                changesRo = "1 schimb la Ungheni (20 min)",
                changesEn = "1 change at Ungheni (20 mins)",
                changesRu = "1 пересадка в Унгенах (20 мин)"
            ),
            ScheduleEntity(
                trainNumber = "341",
                fromStationCode = "BALTI",
                toStationCode = "CHISINAU",
                departureTime = "06:30",
                arrivalTime = "10:20",
                durationMinutes = 230,
                priceFirstClass = 220.0,
                priceSecondClass = 140.0,
                priceThirdClass = 90.0,
                isDirect = false,
                changesRo = "1 schimb la Ungheni (25 min)",
                changesEn = "1 change at Ungheni (25 mins)",
                changesRu = "1 пересадка в Унгенах (25 мин)"
            ),

            // CHISINAU -> IASI (Romania)
            ScheduleEntity(
                trainNumber = "047",
                fromStationCode = "CHISINAU",
                toStationCode = "IASI",
                departureTime = "18:42",
                arrivalTime = "22:15",
                durationMinutes = 213,
                priceFirstClass = 250.0,
                priceSecondClass = 170.0,
                priceThirdClass = 120.0,
                isDirect = true,
                changesRo = "Direct • Control de frontieră la Ungheni",
                changesEn = "Direct • Border control at Ungheni",
                changesRu = "Прямой • Пограничный контроль в Унгенах"
            ),
            ScheduleEntity(
                trainNumber = "047",
                fromStationCode = "IASI",
                toStationCode = "CHISINAU",
                departureTime = "08:15",
                arrivalTime = "11:50",
                durationMinutes = 215,
                priceFirstClass = 250.0,
                priceSecondClass = 170.0,
                priceThirdClass = 120.0,
                isDirect = true,
                changesRo = "Direct • Control de frontieră la Ungheni",
                changesEn = "Direct • Border control at Ungheni",
                changesRu = "Прямой • Пограничный контроль в Унгенах"
            ),

            // CHISINAU -> BUCURESTI (Romania)
            ScheduleEntity(
                trainNumber = "105",
                fromStationCode = "CHISINAU",
                toStationCode = "BUCURESTI",
                departureTime = "17:20",
                arrivalTime = "06:15",
                durationMinutes = 775,
                priceFirstClass = 690.0,
                priceSecondClass = 480.0,
                priceThirdClass = 340.0,
                isDirect = true,
                changesRo = "Tren Internațional de Noapte 'Prietenia'",
                changesEn = "International Sleeper Train 'Prietenia'",
                changesRu = "Международный спальный поезд 'Приетения'"
            ),
            ScheduleEntity(
                trainNumber = "105",
                fromStationCode = "BUCURESTI",
                toStationCode = "CHISINAU",
                departureTime = "19:20",
                arrivalTime = "08:10",
                durationMinutes = 770,
                priceFirstClass = 690.0,
                priceSecondClass = 480.0,
                priceThirdClass = 340.0,
                isDirect = true,
                changesRo = "Tren Internațional de Noapte 'Prietenia'",
                changesEn = "International Sleeper Train 'Prietenia'",
                changesRu = "Международный спальный поезд 'Приетения'"
            ),

            // CHISINAU -> TIRASPOL (And return)
            ScheduleEntity(
                trainNumber = "451",
                fromStationCode = "CHISINAU",
                toStationCode = "TIRASPOL",
                departureTime = "07:10",
                arrivalTime = "08:25",
                durationMinutes = 75,
                priceFirstClass = 95.0,
                priceSecondClass = 60.0,
                priceThirdClass = 40.0
            ),
            ScheduleEntity(
                trainNumber = "451",
                fromStationCode = "TIRASPOL",
                toStationCode = "CHISINAU",
                departureTime = "20:15",
                arrivalTime = "21:30",
                durationMinutes = 75,
                priceFirstClass = 95.0,
                priceSecondClass = 60.0,
                priceThirdClass = 40.0
            ),

            // CHISINAU -> ODESA (Ukraine)
            ScheduleEntity(
                trainNumber = "451",
                fromStationCode = "CHISINAU",
                toStationCode = "ODESA",
                departureTime = "07:10",
                arrivalTime = "11:20",
                durationMinutes = 250,
                priceFirstClass = 380.0,
                priceSecondClass = 260.0,
                priceThirdClass = 180.0,
                isDirect = true,
                changesRo = "Direct • Control de frontieră în tranzit",
                changesEn = "Direct • Transit border check",
                changesRu = "Прямой • Транзитный погранконтроль"
            ),
            ScheduleEntity(
                trainNumber = "451",
                fromStationCode = "ODESA",
                toStationCode = "CHISINAU",
                departureTime = "17:10",
                arrivalTime = "21:20",
                durationMinutes = 250,
                priceFirstClass = 380.0,
                priceSecondClass = 260.0,
                priceThirdClass = 180.0,
                isDirect = true,
                changesRo = "Direct • Control de frontieră în tranzit",
                changesEn = "Direct • Transit border check",
                changesRu = "Прямой • Транзитный погранконтроль"
            ),

            // CHISINAU -> KYIV (Ukraine)
            ScheduleEntity(
                trainNumber = "063",
                fromStationCode = "CHISINAU",
                toStationCode = "KYIV",
                departureTime = "13:35",
                arrivalTime = "06:10",
                durationMinutes = 995,
                priceFirstClass = 980.0,
                priceSecondClass = 650.0,
                priceThirdClass = 450.0,
                isDirect = true,
                changesRo = "Tren Internațional de Noapte 'Victory'",
                changesEn = "International Sleeper Train 'Victory'",
                changesRu = "Международный спальный поезд 'Победа'"
            ),
            ScheduleEntity(
                trainNumber = "063",
                fromStationCode = "KYIV",
                toStationCode = "CHISINAU",
                departureTime = "17:02",
                arrivalTime = "09:30",
                durationMinutes = 988,
                priceFirstClass = 980.0,
                priceSecondClass = 650.0,
                priceThirdClass = 450.0,
                isDirect = true,
                changesRo = "Tren Internațional de Noapte 'Victory'",
                changesEn = "International Sleeper Train 'Victory'",
                changesRu = "Международный спальный поезд 'Победа'"
            ),

            // CHISINAU -> CAHUL
            ScheduleEntity(
                trainNumber = "502",
                fromStationCode = "CHISINAU",
                toStationCode = "CAHUL",
                departureTime = "08:50",
                arrivalTime = "13:20",
                durationMinutes = 270,
                priceFirstClass = 190.0,
                priceSecondClass = 125.0,
                priceThirdClass = 80.0,
                isDirect = false,
                changesRo = "1 schimb la Basarabeasca (15 min)",
                changesEn = "1 change at Basarabeasca (15 mins)",
                changesRu = "1 пересадка в Басарабяске (15 мин)"
            )
        )
        db.scheduleDao().insertSchedules(schedules)

        // Seed an initial passenger (Tom Loveitt) as the user
        db.passengerDao().insertPassenger(
            PassengerEntity(name = "TOM LOVEITT", documentNumber = "MD987654321", isFavorite = true)
        )

        // Seed a default demo ticket so "My Tickets" has a gorgeous offline premium ticket on first launch!
        val offlineTicketId = UUID.randomUUID().toString()
        db.ticketDao().insertTicket(
            TicketEntity(
                id = offlineTicketId,
                passengerName = "TOM LOVEITT",
                passengerDoc = "MD987654321",
                trainNumber = "047",
                fromStationCode = "CHISINAU",
                toStationCode = "UNGHENI",
                fromStationNameRo = "Chișinău Gara",
                fromStationNameEn = "Chisinau Central",
                fromStationNameRu = "Кишинёв Вокзал",
                toStationNameRo = "Ungheni Gara de Frontieră",
                toStationNameEn = "Ungheni Border Station",
                toStationNameRu = "Унгены Пограничный вокзал",
                departureTime = "18:42",
                arrivalTime = "20:51",
                date = "2026-10-02",
                carriage = "03",
                seat = "18",
                price = 110.0,
                ticketClass = "Second Class",
                securityHash = "MR-MD-842-047-0318-7F",
                qrCodeContent = "MOLDOVA_RAIL:SEC_VALID:TRN=047:DEP=18:42:ARR=20:51:CAR=03:SEAT=18:PSG=TOM_LOVEITT:VAL=2026-10-02:ID=$offlineTicketId",
                purchaseTimestamp = System.currentTimeMillis(),
                status = "Active"
            )
        )
    }
}
