package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AppLanguage
import com.example.data.RailViewModel
import com.example.data.Screen
import com.example.data.StationEntity
import com.example.data.TicketEntity
import com.example.data.Translations
import com.example.data.getName
import com.example.ui.theme.MoldovaBlue
import com.example.ui.theme.MoldovaGold
import com.example.ui.theme.MoldovaRed

@Composable
fun HomeScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val stations by viewModel.stations.collectAsStateWithLifecycle()
    val tickets by viewModel.tickets.collectAsStateWithLifecycle()
    
    val fromCode by viewModel.searchFromStationCode.collectAsStateWithLifecycle()
    val toCode by viewModel.searchToStationCode.collectAsStateWithLifecycle()
    val travelDate by viewModel.searchTravelDate.collectAsStateWithLifecycle()
    val passengersCount by viewModel.searchPassengersCount.collectAsStateWithLifecycle()
    val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // 1. App Logo & Brand Header + Language Picker
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = Translations.get("app_title", lang),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MoldovaRed,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "Căile Ferate din Moldova",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }

            // Language Selector Pills
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(2.dp)
            ) {
                listOf(AppLanguage.RO, AppLanguage.EN, AppLanguage.RU).forEach { language ->
                    val isSelected = language == lang
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (isSelected) MoldovaRed else Color.Transparent)
                            .clickable { viewModel.selectLanguage(language) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = language.name,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2. Core Search Form Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Stations Dropdowns
                var fromExpanded by remember { mutableStateOf(false) }
                var toExpanded by remember { mutableStateOf(false) }

                val fromStation = stations.find { it.code == fromCode }
                val toStation = stations.find { it.code == toCode }

                Text(
                    text = Translations.get("from", lang),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MoldovaRed
                )

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = fromStation?.getName(lang) ?: fromCode,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { fromExpanded = true }
                            .testTag("from_station_picker"),
                        enabled = false,
                        leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = MoldovaRed) },
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledTextColor = MaterialTheme.colorScheme.onSurface,
                            disabledBorderColor = MaterialTheme.colorScheme.outline,
                            disabledLeadingIconColor = MoldovaRed
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                    DropdownMenu(
                        expanded = fromExpanded,
                        onDismissRequest = { fromExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.85f)
                    ) {
                        stations.forEach { station ->
                            DropdownMenuItem(
                                text = { Text(station.getName(lang), fontWeight = FontWeight.Bold) },
                                onClick = {
                                    viewModel.searchFromStationCode.value = station.code
                                    fromExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MoldovaRed.copy(alpha = 0.12f))
                            .clickable { viewModel.swapSearchStations() }
                            .padding(8.dp)
                    ) {
                        Icon(
                            Icons.Default.SwapVert,
                            contentDescription = "Swap Stations",
                            tint = MoldovaRed,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Text(
                    text = Translations.get("to", lang),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MoldovaRed
                )

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = toStation?.getName(lang) ?: toCode,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { toExpanded = true }
                            .testTag("to_station_picker"),
                        enabled = false,
                        leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = MoldovaBlue) },
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledTextColor = MaterialTheme.colorScheme.onSurface,
                            disabledBorderColor = MaterialTheme.colorScheme.outline,
                            disabledLeadingIconColor = MoldovaBlue
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                    DropdownMenu(
                        expanded = toExpanded,
                        onDismissRequest = { toExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.85f)
                    ) {
                        stations.forEach { station ->
                            DropdownMenuItem(
                                text = { Text(station.getName(lang), fontWeight = FontWeight.Bold) },
                                onClick = {
                                    viewModel.searchToStationCode.value = station.code
                                    toExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Date and Passengers
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = Translations.get("date", lang),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                        OutlinedTextField(
                            value = travelDate,
                            onValueChange = { viewModel.searchTravelDate.value = it },
                            leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null) },
                            textStyle = TextStyle(fontSize = 13.sp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(0.8f)) {
                        Text(
                            text = Translations.get("passengers", lang),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                        OutlinedTextField(
                            value = passengersCount.toString(),
                            onValueChange = {
                                val value = it.toIntOrNull() ?: 1
                                viewModel.searchPassengersCount.value = value.coerceIn(1, 9)
                            },
                            leadingIcon = { Icon(Icons.Default.Groups, contentDescription = null) },
                            textStyle = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Bold),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Search Action Button
                Button(
                    onClick = { viewModel.executeSearch() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("search_trains_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MoldovaRed,
                        contentColor = Color.White
                    ),
                    enabled = !isSearching
                ) {
                    Icon(Icons.Default.Train, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSearching) "..." else Translations.get("search_trains", lang),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // 3. Quick Action Row (Map / Live Board Shortcuts)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                onClick = { viewModel.navigateTo(Screen.LIVE_MAP) },
                modifier = Modifier
                    .weight(1f)
                    .height(80.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MoldovaBlue.copy(alpha = 0.08f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Map, contentDescription = null, tint = MoldovaBlue, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = Translations.get("map", lang),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MoldovaBlue
                    )
                }
            }

            Card(
                onClick = { viewModel.navigateTo(Screen.PASSENGERS_LIST) },
                modifier = Modifier
                    .weight(1f)
                    .height(80.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MoldovaRed.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Groups, contentDescription = null, tint = MoldovaRed, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = Translations.get("saved_passengers", lang),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MoldovaRed
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // 4. "My Tickets" Active Ticket Card
        val activeTickets = tickets.filter { it.status == "Active" }
        if (activeTickets.isNotEmpty()) {
            val upcomingTicket = activeTickets.first()
            Text(
                text = Translations.get("my_tickets", lang),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                onClick = { viewModel.navigateTo(Screen.TICKET_DETAIL(upcomingTicket.id)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("active_ticket_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.ConfirmationNumber,
                                contentDescription = null,
                                tint = MoldovaRed,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Train ${upcomingTicket.trainNumber} · ${upcomingTicket.ticketClass}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MoldovaRed
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "${upcomingTicket.departureTime} — ${upcomingTicket.arrivalTime}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Text(
                            text = "${upcomingTicket.fromStationCode} ➔ ${upcomingTicket.toStationCode}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "${upcomingTicket.passengerName} · Carriage ${upcomingTicket.carriage} / Seat ${upcomingTicket.seat}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.QrCode,
                            contentDescription = "Show QR Ticket",
                            tint = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = upcomingTicket.securityHash.takeLast(4),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // 5. Service Alerts banner
        Text(
            text = Translations.get("service_alerts", lang),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(
                containerColor = MoldovaGold.copy(alpha = 0.08f)
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, MoldovaGold.copy(alpha = 0.3f))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Warning,
                    contentDescription = null,
                    tint = MoldovaGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = Translations.get("disruption_alert", lang),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 6. Departures Today Schedule Board
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = Translations.get("departures_today", lang),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            TextButton(onClick = { viewModel.navigateTo(Screen.STATION_DETAIL("CHISINAU")) }) {
                Text(
                    text = "Chisinau Board ➔",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MoldovaRed
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Compact Schedule departures mock/static visual board
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Board headers
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Train / Route", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), modifier = Modifier.weight(1.5f))
                    Text("Time", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Text("Track", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), modifier = Modifier.weight(0.5f), textAlign = TextAlign.Center)
                    Text("Status", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                }

                val departures = listOf(
                    Triple("801 Fast · Ungheni", "07:30", "Line 2"),
                    Triple("502 Regional · Cahul", "08:50", "Line 3"),
                    Triple("341 Reg · Balti", "14:15", "Line 1"),
                    Triple("105 Prietenia · București", "17:20", "Line 1"),
                    Triple("047 Express · Iași Socola", "18:42", "Line 1")
                )

                departures.forEach { dep ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .clickable { viewModel.navigateTo(Screen.STATION_DETAIL("CHISINAU")) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Icon(Icons.Default.Train, contentDescription = null, tint = MoldovaBlue, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = dep.first,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                overflow = TextOverflow.Ellipsis,
                                maxLines = 1
                            )
                        }

                        Text(
                            text = dep.second,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = dep.third,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                            modifier = Modifier.weight(0.5f),
                            textAlign = TextAlign.Center
                        )

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFE2F0D9))
                                .padding(horizontal = 4.dp, vertical = 2.dp),
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            Text(
                                text = "On Time",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF385723),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 7. Popular Destinations Grid Section
        Text(
            text = Translations.get("popular_dest", lang),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        val destinationShortcuts = listOf(
            Triple("CHISINAU", "IASI", Translations.get("popular_chis_ias_desc", lang)),
            Triple("CHISINAU", "BUCURESTI", Translations.get("popular_chis_buc_desc", lang)),
            Triple("CHISINAU", "UNGHENI", Translations.get("popular_chis_ung_desc", lang))
        )

        destinationShortcuts.forEach { dest ->
            Card(
                onClick = {
                    viewModel.searchFromStationCode.value = dest.first
                    viewModel.searchToStationCode.value = dest.second
                    viewModel.executeSearch()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        val fromName = stations.find { it.code == dest.first }?.getName(lang) ?: dest.first
                        val toName = stations.find { it.code == dest.second }?.getName(lang) ?: dest.second
                        Text(
                            text = "$fromName ➔ $toName",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            color = MoldovaBlue
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = dest.third,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                    Icon(
                        Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = MoldovaRed,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
