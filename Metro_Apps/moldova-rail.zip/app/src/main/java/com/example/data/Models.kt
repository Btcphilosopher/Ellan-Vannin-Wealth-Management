package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val code: String, // e.g. "CHISINAU", "BALTI"
    val nameRo: String,
    val nameEn: String,
    val nameRu: String,
    val latitude: Float,
    val longitude: Float,
    val addressRo: String,
    val addressEn: String,
    val addressRu: String,
    val facilitiesRo: String,
    val facilitiesEn: String,
    val facilitiesRu: String,
    val platformInfoRo: String,
    val platformInfoEn: String,
    val platformInfoRu: String,
    val connectionsRo: String,
    val connectionsEn: String,
    val connectionsRu: String,
    val accessibilityRo: String,
    val accessibilityEn: String,
    val accessibilityRu: String
)

@Entity(tableName = "trains")
data class TrainEntity(
    @PrimaryKey val trainNumber: String, // e.g. "047", "341"
    val name: String,                    // e.g. "Prietenia" or "Ungheni Regional"
    val trainType: String,               // e.g. "InterCity", "Regional", "International"
    val speedKmh: Int,
    val totalCarriages: Int
)

@Entity(tableName = "schedules")
data class ScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trainNumber: String,
    val fromStationCode: String,
    val toStationCode: String,
    val departureTime: String, // "HH:mm"
    val arrivalTime: String,   // "HH:mm"
    val durationMinutes: Int,
    val priceFirstClass: Double,
    val priceSecondClass: Double,
    val priceThirdClass: Double,
    val isDirect: Boolean = true,
    val changesRo: String = "Direct",
    val changesEn: String = "Direct",
    val changesRu: String = "Прямой"
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String, // UUID string
    val passengerName: String,
    val passengerDoc: String,
    val trainNumber: String,
    val fromStationCode: String,
    val toStationCode: String,
    val fromStationNameRo: String,
    val fromStationNameEn: String,
    val fromStationNameRu: String,
    val toStationNameRo: String,
    val toStationNameEn: String,
    val toStationNameRu: String,
    val departureTime: String, // "HH:mm"
    val arrivalTime: String,   // "HH:mm"
    val date: String,          // "yyyy-MM-dd"
    val carriage: String,
    val seat: String,
    val price: Double,
    val ticketClass: String, // "First Class", "Second Class", "Third Class"
    val securityHash: String, // Offline anti-fraud verification token
    val qrCodeContent: String, // Structured inspection string
    val purchaseTimestamp: Long,
    val status: String // "Active", "Validated", "Cancelled"
)

@Entity(tableName = "passengers")
data class PassengerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val documentNumber: String,
    val isFavorite: Boolean = false
)

// UI View Models and Language helper
enum class AppLanguage {
    RO, EN, RU
}

// Help translation lookup
fun StationEntity.getName(lang: AppLanguage): String {
    return when (lang) {
        AppLanguage.RO -> nameRo
        AppLanguage.EN -> nameEn
        AppLanguage.RU -> nameRu
    }
}

fun StationEntity.getAddress(lang: AppLanguage): String {
    return when (lang) {
        AppLanguage.RO -> addressRo
        AppLanguage.EN -> addressEn
        AppLanguage.RU -> addressRu
    }
}

fun StationEntity.getFacilities(lang: AppLanguage): String {
    return when (lang) {
        AppLanguage.RO -> facilitiesRo
        AppLanguage.EN -> facilitiesEn
        AppLanguage.RU -> facilitiesRu
    }
}

fun StationEntity.getPlatformInfo(lang: AppLanguage): String {
    return when (lang) {
        AppLanguage.RO -> platformInfoRo
        AppLanguage.EN -> platformInfoEn
        AppLanguage.RU -> platformInfoRu
    }
}

fun StationEntity.getConnections(lang: AppLanguage): String {
    return when (lang) {
        AppLanguage.RO -> connectionsRo
        AppLanguage.EN -> connectionsEn
        AppLanguage.RU -> connectionsRu
    }
}

fun StationEntity.getAccessibility(lang: AppLanguage): String {
    return when (lang) {
        AppLanguage.RO -> accessibilityRo
        AppLanguage.EN -> accessibilityEn
        AppLanguage.RU -> accessibilityRu
    }
}

fun ScheduleEntity.getChanges(lang: AppLanguage): String {
    return when (lang) {
        AppLanguage.RO -> changesRo
        AppLanguage.EN -> changesEn
        AppLanguage.RU -> changesRu
    }
}
