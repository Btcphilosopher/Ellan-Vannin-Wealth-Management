package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AppDatabase
import com.example.data.RailRepository
import com.example.data.RailViewModel
import com.example.data.Screen
import com.example.ui.screens.BookingScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveMapScreen
import com.example.ui.screens.PassengersListScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.screens.StationDetailsScreen
import com.example.ui.screens.TicketDetailsScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Instantiate database, repository, and ViewModel offline architectures
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = RailRepository(database)
        val viewModel = RailViewModel(repository)

        setContent {
            MyApplicationTheme {
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

                // Register standard physical BackHandler interceptors
                BackHandler(enabled = currentScreen != Screen.HOME) {
                    viewModel.navigateBack()
                }

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentScreen) {
                            is Screen.HOME -> HomeScreen(viewModel = viewModel)
                            is Screen.RESULTS -> ResultsScreen(viewModel = viewModel)
                            is Screen.BOOKING -> BookingScreen(viewModel = viewModel)
                            is Screen.TICKET_DETAIL -> TicketDetailsScreen(viewModel = viewModel)
                            is Screen.STATION_DETAIL -> StationDetailsScreen(viewModel = viewModel)
                            is Screen.LIVE_MAP -> LiveMapScreen(viewModel = viewModel)
                            is Screen.PASSENGERS_LIST -> PassengersListScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
