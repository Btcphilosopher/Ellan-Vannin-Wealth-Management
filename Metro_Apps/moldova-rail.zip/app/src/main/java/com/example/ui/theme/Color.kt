package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Moldova Flag inspired luxury colors
val MoldovaRed = Color(0xFFC60C30)       // Main primary brand accent
val MoldovaBlue = Color(0xFF104F75)      // International / secondary accents
val MoldovaGold = Color(0xFFFFBF00)      // Highlight status / warning
val GraphiteDark = Color(0xFF1C1C1E)     // Core text color
val WarmGreyBackground = Color(0xFFFAF9F6) // Premium warm white background
val WarmGreySurface = Color(0xFFF2F0EC)    // Warm-grey surface container
val WarmGreySurfaceVariant = Color(0xFFE8E5E0)

// Dark theme options
val MoldovaRedLight = Color(0xFFFF4D6D)
val MoldovaBlueLight = Color(0xFF63B3ED)
val WarmGreyDarkBackground = Color(0xFF121214)
val WarmGreyDarkSurface = Color(0xFF1F1F23)
val GraphiteLight = Color(0xFFE2E2E6)
