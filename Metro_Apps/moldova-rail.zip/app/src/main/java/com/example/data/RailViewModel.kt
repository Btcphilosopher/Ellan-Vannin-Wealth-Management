package com.example.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Stack

sealed class Screen {
    object HOME : Screen()
    object RESULTS : Screen()
    object BOOKING : Screen()
    data class TICKET_DETAIL(val ticketId: String) : Screen()
    data class STATION_DETAIL(val stationCode: String) : Screen()
    object LIVE_MAP : Screen()
    object PASSENGERS_LIST : Screen()
}

class RailViewModel(private val repository: RailRepository) : ViewModel() {

    // Language state
    private val _currentLanguage = MutableStateFlow(AppLanguage.RO)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    // Screen navigation stack
    private val screenStack = Stack<Screen>().apply { push(Screen.HOME) }
    private val _currentScreen = MutableStateFlow<Screen>(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Search query parameters
    val searchFromStationCode = MutableStateFlow("CHISINAU")
    val searchToStationCode = MutableStateFlow("UNGHENI")
    val searchTravelDate = MutableStateFlow("2026-10-02")
    val searchPassengersCount = MutableStateFlow(1)

    // Search Results & Filters
    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _rawSearchResults = MutableStateFlow<List<ScheduleEntity>>(emptyList())
    private val _searchFilter = MutableStateFlow("fastest") // "fastest", "cheapest", "direct", "departure"
    val searchFilter: StateFlow<String> = _searchFilter.asStateFlow()

    val filteredSearchResults: StateFlow<List<ScheduleEntity>> = combine(
        _rawSearchResults,
        _searchFilter
    ) { results, filter ->
        when (filter) {
            "fastest" -> results.sortedBy { it.durationMinutes }
            "cheapest" -> results.sortedBy { it.priceSecondClass }
            "direct" -> results.filter { it.isDirect }
            "departure" -> results.sortedBy { it.departureTime }
            "arrival" -> results.sortedBy { it.arrivalTime }
            else -> results
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Booking Flow state
    val selectedScheduleForBooking = MutableStateFlow<ScheduleEntity?>(null)
    val selectedClassForBooking = MutableStateFlow("Second Class")
    val selectedSeatForBooking = MutableStateFlow<String?>(null)
    val passengerNameInput = MutableStateFlow("TOM LOVEITT")
    val passengerDocInput = MutableStateFlow("MD987654321")

    // Database Streams
    val stations: StateFlow<List<StationEntity>> = repository.allStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trains: StateFlow<List<TrainEntity>> = repository.allTrains
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<TicketEntity>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val passengers: StateFlow<List<PassengerEntity>> = repository.allPassengers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active detail references
    private val _activeTicket = MutableStateFlow<TicketEntity?>(null)
    val activeTicket: StateFlow<TicketEntity?> = _activeTicket.asStateFlow()

    private val _activeStation = MutableStateFlow<StationEntity?>(null)
    val activeStation: StateFlow<StationEntity?> = _activeStation.asStateFlow()

    // Map disruption details
    val activeDisruptionsCount = MutableStateFlow(1) // Shows repair work Ungheni-Balti

    fun selectLanguage(lang: AppLanguage) {
        _currentLanguage.value = lang
    }

    fun navigateTo(screen: Screen) {
        screenStack.push(screen)
        _currentScreen.value = screen

        // Automatically load data when navigating to specific screens
        when (screen) {
            is Screen.TICKET_DETAIL -> {
                viewModelScope.launch {
                    _activeTicket.value = repository.getTicketById(screen.ticketId)
                }
            }
            is Screen.STATION_DETAIL -> {
                viewModelScope.launch {
                    _activeStation.value = repository.getStationByCode(screen.stationCode)
                }
            }
            else -> {}
        }
    }

    fun navigateBack() {
        if (screenStack.size > 1) {
            screenStack.pop()
            _currentScreen.value = screenStack.peek()
        }
    }

    fun swapSearchStations() {
        val temp = searchFromStationCode.value
        searchFromStationCode.value = searchToStationCode.value
        searchToStationCode.value = temp
    }

    fun executeSearch() {
        _isSearching.value = true
        viewModelScope.launch {
            val results = repository.searchJourneys(
                searchFromStationCode.value,
                searchToStationCode.value
            )
            _rawSearchResults.value = results
            _isSearching.value = false
            navigateTo(Screen.RESULTS)
        }
    }

    fun updateSearchFilter(filter: String) {
        _searchFilter.value = filter
    }

    fun startBooking(schedule: ScheduleEntity) {
        selectedScheduleForBooking.value = schedule
        selectedClassForBooking.value = "Second Class"
        selectedSeatForBooking.value = null
        
        // Auto-populate from first favorite passenger if available
        val fav = passengers.value.firstOrNull()
        if (fav != null) {
            passengerNameInput.value = fav.name
            passengerDocInput.value = fav.documentNumber
        } else {
            passengerNameInput.value = "TOM LOVEITT"
            passengerDocInput.value = "MD987654321"
        }
        navigateTo(Screen.BOOKING)
    }

    fun selectClass(ticketClass: String) {
        selectedClassForBooking.value = ticketClass
        selectedSeatForBooking.value = null // reset seat to select new one in class coach
    }

    fun selectSeat(seat: String) {
        selectedSeatForBooking.value = seat
    }

    fun purchaseTicket() {
        val schedule = selectedScheduleForBooking.value ?: return
        viewModelScope.launch {
            val ticket = repository.buyTicket(
                passengerName = passengerNameInput.value.uppercase().trim(),
                passengerDoc = passengerDocInput.value.uppercase().trim(),
                schedule = schedule,
                selectedClass = selectedClassForBooking.value,
                selectedSeat = selectedSeatForBooking.value,
                travelDate = searchTravelDate.value
            )
            // Save passenger automatically to saved list if new
            if (passengers.value.none { it.documentNumber.equals(passengerDocInput.value, true) }) {
                repository.savePassenger(passengerNameInput.value, passengerDocInput.value)
            }
            navigateTo(Screen.TICKET_DETAIL(ticket.id))
        }
    }

    fun addPassenger(name: String, doc: String) {
        viewModelScope.launch {
            repository.savePassenger(name, doc)
        }
    }

    fun deletePassenger(id: Long) {
        viewModelScope.launch {
            repository.deletePassenger(id)
        }
    }

    fun simulateConductorCheck(ticketId: String) {
        viewModelScope.launch {
            repository.validateTicketOffline(ticketId)
            // Reload active ticket
            _activeTicket.value = repository.getTicketById(ticketId)
        }
    }
}
