package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.RailViewModel
import com.example.data.TicketEntity
import com.example.data.Translations
import com.example.ui.theme.MoldovaBlue
import com.example.ui.theme.MoldovaGold
import com.example.ui.theme.MoldovaRed
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketDetailsScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val ticket by viewModel.activeTicket.collectAsStateWithLifecycle()

    val scrollState = rememberScrollState()

    // Flashing anti-fraud indicator pulse
    var isPulseActive by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        while (true) {
            isPulseActive = !isPulseActive
            delay(1200)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Digital Inspection Ticket",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = Translations.get("back", lang),
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MoldovaRed,
                    titleContentColor = Color.White
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (ticket == null) {
                // Ticket Not Found State
                Column(
                    modifier = Modifier.padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MoldovaRed, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(Translations.get("ticket_not_found", lang), fontWeight = FontWeight.Bold)
                }
            } else {
                val currentTicket = ticket!!

                // 1. Tactile Boarding Ticket Layout (White premium paper look)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("inspection_ticket")
                        .border(
                            1.dp,
                            Color(0xFFE2E0D9),
                            RoundedCornerShape(16.dp)
                        ),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column {
                        // Ticket Header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF9F9F7))
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.BookmarkBorder,
                                    contentDescription = null,
                                    tint = MoldovaRed,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = Translations.get("app_title", lang),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MoldovaRed,
                                    letterSpacing = 1.sp
                                )
                            }

                            // Secure dynamic anti-fraud indicator
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isPulseActive) Color(0xFF4CAF50) else Color(0xFF81C784))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "SECURE",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF4CAF50)
                                )
                            }
                        }

                        // Journey route connection details (Chișinău -> Ungheni)
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = currentTicket.fromStationNameEn.uppercase(),
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF1C1C1E)
                                    )
                                    Text(
                                        text = "DEP ${currentTicket.departureTime}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MoldovaBlue
                                    )
                                }

                                Text(
                                    text = "➔",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MoldovaRed,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )

                                Column(
                                    modifier = Modifier.weight(1f),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Text(
                                        text = currentTicket.toStationNameEn.uppercase(),
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF1C1C1E),
                                        textAlign = TextAlign.End
                                    )
                                    Text(
                                        text = "ARR ${currentTicket.arrivalTime}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MoldovaBlue,
                                        textAlign = TextAlign.End
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(18.dp))
                            HorizontalDivider(
                                color = Color(0xFFE2E0D9),
                                thickness = 1.dp,
                                modifier = Modifier.drawBehind {
                                    // Make it look like a perforated ticket coupon tear line!
                                    val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                }
                            )
                            Spacer(modifier = Modifier.height(18.dp))

                            // Grid of Train specifications
                            Row(modifier = Modifier.fillMaxWidth()) {
                                TicketGridItem("TRAIN", currentTicket.trainNumber, Modifier.weight(1f))
                                TicketGridItem("DATE", currentTicket.date, Modifier.weight(1.3f))
                                TicketGridItem("CARRIAGE", currentTicket.carriage, Modifier.weight(1f))
                                TicketGridItem("SEAT", currentTicket.seat, Modifier.weight(1f))
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Passenger name
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF5F4EF))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = "PASSENGER",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray
                                )
                                Text(
                                    text = currentTicket.passengerName,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF1C1C1E)
                                )
                                Text(
                                    text = "DOC: ${currentTicket.passengerDoc}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.Gray
                                )
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            // QR Code Vector Drawing Canvas
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "SCAN QR ON BOARDING / CONDUCTOR INSPECTION",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MoldovaBlue,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                Box(
                                    modifier = Modifier
                                        .size(170.dp)
                                        .background(Color.White)
                                        .border(1.dp, Color(0xFFD0CFCA))
                                        .padding(10.dp)
                                ) {
                                    VectorQRCode(qrContent = currentTicket.qrCodeContent)
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Offline Watermark Anti-Fraud Token code
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFFFFF9E6))
                                        .border(1.dp, MoldovaGold.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Security, contentDescription = null, tint = MoldovaGold, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "VERIFIED ID: ${currentTicket.securityHash}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color(0xFF8A6D1C)
                                        )
                                    }
                                }
                            }
                        }

                        // Ticket Footer / Validation status bar
                        val isValidated = currentTicket.status == "Validated"
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (isValidated) Color(0xFFE2F0D9) else MoldovaRed.copy(alpha = 0.08f))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isValidated) Icons.Default.CheckCircle else Icons.Default.Info,
                                    contentDescription = null,
                                    tint = if (isValidated) Color(0xFF385723) else MoldovaRed,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isValidated) Translations.get("validated", lang).uppercase() else Translations.get("active", lang).uppercase(),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isValidated) Color(0xFF385723) else MoldovaRed
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // 2. Info Warning Boarding Tip
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MoldovaBlue, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = Translations.get("boarding_info", lang),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // 3. Simulated Offline validation button for the inspector / conductor!
                Button(
                    onClick = { viewModel.simulateConductorCheck(currentTicket.id) },
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .height(48.dp)
                        .testTag("simulate_validate_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MoldovaBlue,
                        contentColor = Color.White
                    )
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Simulate Conductor Offline Scan",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun TicketGridItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray
        )
        Text(
            text = value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            color = Color(0xFF1C1C1E)
        )
    }
}

@Composable
fun VectorQRCode(
    qrContent: String,
    modifier: Modifier = Modifier
) {
    // Generate deterministic black/white squares on Canvas based on qrContent hash for beautiful real QR effect
    val hash = qrContent.hashCode()
    Canvas(modifier = modifier.fillMaxSize()) {
        val sizePx = size.width
        val blocksCount = 15 // grid size
        val blockSize = sizePx / blocksCount

        // 1. Clear background
        drawRect(Color.White)

        // 2. Draw standard corner QR finder patterns
        fun drawFinder(offsetX: Int, offsetY: Int) {
            // Outer square (7x7 blocks)
            drawRect(
                color = Color.Black,
                topLeft = Offset(offsetX * blockSize, offsetY * blockSize),
                size = Size(4 * blockSize, 4 * blockSize)
            )
            drawRect(
                color = Color.White,
                topLeft = Offset((offsetX + 1) * blockSize, (offsetY + 1) * blockSize),
                size = Size(2 * blockSize, 2 * blockSize)
            )
            drawRect(
                color = Color.Black,
                topLeft = Offset((offsetX + 1.5f) * blockSize, (offsetY + 1.5f) * blockSize),
                size = Size(1 * blockSize, 1 * blockSize)
            )
        }

        // Top Left finder
        drawFinder(0, 0)
        // Top Right finder
        drawFinder(blocksCount - 4, 0)
        // Bottom Left finder
        drawFinder(0, blocksCount - 4)

        // 3. Draw random deterministic data blocks across remaining area
        for (row in 0 until blocksCount) {
            for (col in 0 until blocksCount) {
                // Skip finder pattern zones
                val isTopLeftFinder = row < 5 && col < 5
                val isTopRightFinder = row < 5 && col >= blocksCount - 5
                val isBottomLeftFinder = row >= blocksCount - 5 && col < 5
                if (isTopLeftFinder || isTopRightFinder || isBottomLeftFinder) continue

                // Pseudo-random selection based on coordinate and content hash
                val determinant = (row * 31 + col * 17 + hash) % 3 == 0
                if (determinant) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(col * blockSize, row * blockSize),
                        size = Size(blockSize + 0.5f, blockSize + 0.5f) // tiny overlap to prevent grid lines
                    )
                }
            }
        }
    }
}
