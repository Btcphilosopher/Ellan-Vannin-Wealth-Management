package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.EventSeat
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.RailViewModel
import com.example.data.Translations
import com.example.data.getName
import com.example.ui.theme.MoldovaBlue
import com.example.ui.theme.MoldovaGold
import com.example.ui.theme.MoldovaRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val stations by viewModel.stations.collectAsStateWithLifecycle()
    val schedule by viewModel.selectedScheduleForBooking.collectAsStateWithLifecycle()
    val selectedClass by viewModel.selectedClassForBooking.collectAsStateWithLifecycle()
    val selectedSeat by viewModel.selectedSeatForBooking.collectAsStateWithLifecycle()
    val passengerName by viewModel.passengerNameInput.collectAsStateWithLifecycle()
    val passengerDoc by viewModel.passengerDocInput.collectAsStateWithLifecycle()
    val savedPassengers by viewModel.passengers.collectAsStateWithLifecycle()

    val scrollState = rememberScrollState()

    if (schedule == null) {
        viewModel.navigateBack()
        return
    }

    val currentSchedule = schedule!!
    val fromStation = stations.find { it.code == currentSchedule.fromStationCode }
    val toStation = stations.find { it.code == currentSchedule.toStationCode }

    val ticketPrice = when (selectedClass) {
        "First Class" -> currentSchedule.priceFirstClass
        "Second Class" -> currentSchedule.priceSecondClass
        else -> currentSchedule.priceThirdClass
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Review & Book Seat",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = Translations.get("back", lang),
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MoldovaRed,
                    titleContentColor = Color.White
                )
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // 1. Brief Journey summary Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Train ${currentSchedule.trainNumber} · ${currentSchedule.departureTime} — ${currentSchedule.arrivalTime}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MoldovaRed
                        )
                        Text(
                            text = "${fromStation?.getName(lang) ?: currentSchedule.fromStationCode} ➔ ${toStation?.getName(lang) ?: currentSchedule.toStationCode}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(MoldovaBlue.copy(alpha = 0.08f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = selectedSeat?.let { "Seat $it" } ?: "Select Seat",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MoldovaBlue
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Class Selector Options
            Text(
                text = Translations.get("class", lang),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))

            val classes = listOf(
                Triple("First Class", currentSchedule.priceFirstClass, "Spacious (1-2 seats), hot drinks, power outlets"),
                Triple("Second Class", currentSchedule.priceSecondClass, "Standard (2-2 seats), air conditioning, tables"),
                Triple("Third Class", currentSchedule.priceThirdClass, "Budget (3-2 seats), local transit, spacious luggage area")
            )

            classes.forEach { classInfo ->
                val isSelected = selectedClass == classInfo.first
                Card(
                    onClick = { viewModel.selectClass(classInfo.first) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) MoldovaRed.copy(alpha = 0.04f) else MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) MoldovaRed else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = classInfo.first,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) MoldovaRed else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = classInfo.third,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }
                        Text(
                            text = "${classInfo.second.toInt()} MDL",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isSelected) MoldovaRed else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 3. Interactive Seat Coach Map Visualizer
            Text(
                text = "${Translations.get("seat", lang)} Selection (Carriage 02)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = Translations.get("seat_selection_info", lang),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Layout a graphical coach container representation
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Coach corridor indicator line
                    Text(
                        text = "◀ FRONT OF COACH (DIRECTION OF TRAVEL)",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = MoldovaBlue.copy(alpha = 0.6f),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Seed seat numbers 1 to 24 (compact list to keep UI fast and renderable inside the grid)
                    val seatMap = remember(selectedClass) {
                        List(24) { index ->
                            val seatNum = String.format("%02d", index + 1)
                            // Simulate that about 35% of seats are already occupied
                            val isOccupied = (index * 7 + 11) % 5 == 0 && index != 17 // Seat 18 is vacant for user!
                            Pair(seatNum, isOccupied)
                        }
                    }

                    // Simple custom seat grid layout
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        userScrollEnabled = false
                    ) {
                        items(seatMap) { seat ->
                            val isOccupied = seat.second
                            val seatNumber = seat.first
                            val isSelected = selectedSeat == seatNumber

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        when {
                                            isOccupied -> MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
                                            isSelected -> MoldovaRed
                                            else -> MaterialTheme.colorScheme.surface
                                        }
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = when {
                                            isOccupied -> Color.Transparent
                                            isSelected -> MoldovaRed
                                            else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                        },
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable(enabled = !isOccupied) { viewModel.selectSeat(seatNumber) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = seatNumber,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        isOccupied -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f)
                                        isSelected -> Color.White
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Seats Map Legend
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(2.dp)))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Available", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Occupied", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(MoldovaRed))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Selected", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MoldovaRed)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 4. Passenger Input Form
            Text(
                text = Translations.get("passenger_details", lang),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Quick choose from saved list if available
                    if (savedPassengers.isNotEmpty()) {
                        Text(
                            text = "⚡ QUICK PICK SAVED PASSENGER",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MoldovaBlue,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            savedPassengers.take(3).forEach { p ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(MoldovaBlue.copy(alpha = 0.06f))
                                        .border(
                                            1.dp,
                                            if (passengerName.equals(p.name, true)) MoldovaBlue else Color.Transparent,
                                            RoundedCornerShape(20.dp)
                                        )
                                        .clickable {
                                            viewModel.passengerNameInput.value = p.name
                                            viewModel.passengerDocInput.value = p.documentNumber
                                        }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = p.name,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MoldovaBlue
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = passengerName,
                        onValueChange = { viewModel.passengerNameInput.value = it },
                        label = { Text(Translations.get("full_name", lang)) },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("passenger_name_input"),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = passengerDoc,
                        onValueChange = { viewModel.passengerDocInput.value = it },
                        label = { Text(Translations.get("document_number", lang)) },
                        leadingIcon = { Icon(Icons.Default.CreditCard, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("passenger_doc_input"),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 5. Total Price & Payments Section
            Text(
                text = "Modern Secure Checkout",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = Translations.get("total_price", lang),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "${ticketPrice.toInt()} MDL",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                            color = MoldovaRed
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "💳 Google Pay • Card (Visa/MC) • local rPLaT / CFM-Pay",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Buy Action Button
            val isFormComplete = passengerName.isNotBlank() && passengerDoc.isNotBlank() && selectedSeat != null
            Button(
                onClick = { viewModel.purchaseTicket() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("pay_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MoldovaRed,
                    contentColor = Color.White
                ),
                enabled = isFormComplete
            ) {
                Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isFormComplete) Translations.get("pay", lang) else Translations.get("select_class_to_proceed", lang),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
