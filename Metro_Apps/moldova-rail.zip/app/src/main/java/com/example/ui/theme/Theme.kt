package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = MoldovaRedLight,
    secondary = MoldovaBlueLight,
    tertiary = MoldovaGold,
    background = WarmGreyDarkBackground,
    surface = WarmGreyDarkSurface,
    onPrimary = GraphiteDark,
    onSecondary = GraphiteDark,
    onTertiary = GraphiteDark,
    onBackground = GraphiteLight,
    onSurface = GraphiteLight
  )

private val LightColorScheme =
  lightColorScheme(
    primary = MoldovaRed,
    secondary = MoldovaBlue,
    tertiary = MoldovaGold,
    background = WarmGreyBackground,
    surface = WarmGreySurface,
    surfaceVariant = WarmGreySurfaceVariant,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = GraphiteDark,
    onBackground = GraphiteDark,
    onSurface = GraphiteDark,
    onSurfaceVariant = GraphiteDark
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // For standard branding we prefer our custom colors, disable dynamic color by default
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
