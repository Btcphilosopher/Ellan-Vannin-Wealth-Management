package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.random.Random

class RailRepository(private val database: AppDatabase) {

    val allStations: Flow<List<StationEntity>> = database.stationDao().getAllStationsFlow()
    val allTrains: Flow<List<TrainEntity>> = database.trainDao().getAllTrainsFlow()
    val allTickets: Flow<List<TicketEntity>> = database.ticketDao().getAllTicketsFlow()
    val allPassengers: Flow<List<PassengerEntity>> = database.passengerDao().getAllPassengersFlow()

    suspend fun searchJourneys(fromCode: String, toCode: String): List<ScheduleEntity> = withContext(Dispatchers.IO) {
        database.scheduleDao().searchSchedules(fromCode, toCode)
    }

    suspend fun getStationByCode(code: String): StationEntity? = withContext(Dispatchers.IO) {
        database.stationDao().getStationByCode(code)
    }

    suspend fun getTrainByNumber(number: String): TrainEntity? = withContext(Dispatchers.IO) {
        database.trainDao().getTrainByNumber(number)
    }

    suspend fun getTicketById(id: String): TicketEntity? = withContext(Dispatchers.IO) {
        database.ticketDao().getTicketById(id)
    }

    suspend fun buyTicket(
        passengerName: String,
        passengerDoc: String,
        schedule: ScheduleEntity,
        selectedClass: String,
        selectedSeat: String?,
        travelDate: String
    ): TicketEntity = withContext(Dispatchers.IO) {
        val fromStation = database.stationDao().getStationByCode(schedule.fromStationCode)
        val toStation = database.stationDao().getStationByCode(schedule.toStationCode)

        val ticketId = UUID.randomUUID().toString()
        val carriageNum = String.format("%02d", Random.nextInt(1, 6))
        val seatNum = selectedSeat ?: String.format("%02d", Random.nextInt(1, 48))

        // Create a secure validation hash containing important ticket metadata
        val securityHash = generateSecurityHash(
            schedule.trainNumber,
            carriageNum,
            seatNum,
            passengerName,
            travelDate
        )

        val price = when (selectedClass) {
            "First Class" -> schedule.priceFirstClass
            "Second Class" -> schedule.priceSecondClass
            else -> schedule.priceThirdClass
        }

        val qrContent = "MOLDOVA_RAIL:VERIFY:" +
                "ID=$ticketId:" +
                "TRN=${schedule.trainNumber}:" +
                "DEP=${schedule.departureTime}:" +
                "ARR=${schedule.arrivalTime}:" +
                "CAR=$carriageNum:" +
                "SEAT=$seatNum:" +
                "PSG=${passengerName.replace(" ", "_")}:" +
                "VAL=$travelDate:" +
                "SEC=$securityHash"

        val ticket = TicketEntity(
            id = ticketId,
            passengerName = passengerName,
            passengerDoc = passengerDoc,
            trainNumber = schedule.trainNumber,
            fromStationCode = schedule.fromStationCode,
            toStationCode = schedule.toStationCode,
            fromStationNameRo = fromStation?.nameRo ?: schedule.fromStationCode,
            fromStationNameEn = fromStation?.nameEn ?: schedule.fromStationCode,
            fromStationNameRu = fromStation?.nameRu ?: schedule.fromStationCode,
            toStationNameRo = toStation?.nameRo ?: schedule.toStationCode,
            toStationNameEn = toStation?.nameEn ?: schedule.toStationCode,
            toStationNameRu = toStation?.nameRu ?: schedule.toStationCode,
            departureTime = schedule.departureTime,
            arrivalTime = schedule.arrivalTime,
            date = travelDate,
            carriage = carriageNum,
            seat = seatNum,
            price = price,
            ticketClass = selectedClass,
            securityHash = securityHash,
            qrCodeContent = qrContent,
            purchaseTimestamp = System.currentTimeMillis(),
            status = "Active"
        )

        database.ticketDao().insertTicket(ticket)
        ticket
    }

    suspend fun savePassenger(name: String, documentNumber: String) = withContext(Dispatchers.IO) {
        val passenger = PassengerEntity(
            name = name.uppercase(),
            documentNumber = documentNumber.uppercase(),
            isFavorite = false
        )
        database.passengerDao().insertPassenger(passenger)
    }

    suspend fun deletePassenger(id: Long) = withContext(Dispatchers.IO) {
        database.passengerDao().deletePassenger(id)
    }

    suspend fun validateTicketOffline(ticketId: String) = withContext(Dispatchers.IO) {
        database.ticketDao().updateTicketStatus(ticketId, "Validated")
    }

    private fun generateSecurityHash(
        train: String,
        carriage: String,
        seat: String,
        passengerName: String,
        date: String
    ): String {
        // Simple fast deterministic offline hashing algorithm that can be verified on a conductor's device
        val secretInput = "$train|$carriage|$seat|$passengerName|$date|MOLDOVA_RAIL_KEY_2026"
        val code = secretInput.hashCode().toLong()
        val hex = java.lang.Long.toHexString(code).uppercase()
        return "MR-MD-" + hex.takeLast(6)
    }
}
