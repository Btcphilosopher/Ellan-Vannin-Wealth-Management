package com.example.data

object Translations {
    private val dictionary = mapOf(
        "app_title" to mapOf(
            AppLanguage.RO to "MOLDOVA RAIL",
            AppLanguage.EN to "MOLDOVA RAIL",
            AppLanguage.RU to "MOLDOVA RAIL"
        ),
        "from" to mapOf(
            AppLanguage.RO to "Plecare din",
            AppLanguage.EN to "From",
            AppLanguage.RU to "Откуда"
        ),
        "to" to mapOf(
            AppLanguage.RO to "Sosire la",
            AppLanguage.EN to "To",
            AppLanguage.RU to "Куда"
        ),
        "date" to mapOf(
            AppLanguage.RO to "Data călătoriei",
            AppLanguage.EN to "Travel Date",
            AppLanguage.RU to "Дата поездки"
        ),
        "passengers" to mapOf(
            AppLanguage.RO to "Pasageri",
            AppLanguage.EN to "Passengers",
            AppLanguage.RU to "Пассажиры"
        ),
        "search_trains" to mapOf(
            AppLanguage.RO to "Caută Trenuri",
            AppLanguage.EN to "Search Trains",
            AppLanguage.RU to "Найти поезда"
        ),
        "departures_today" to mapOf(
            AppLanguage.RO to "Plecări astăzi",
            AppLanguage.EN to "Departures Today",
            AppLanguage.RU to "Отправления сегодня"
        ),
        "live_status" to mapOf(
            AppLanguage.RO to "Live - Stare trenuri",
            AppLanguage.EN to "Live Train Status",
            AppLanguage.RU to "Живой статус поездов"
        ),
        "my_tickets" to mapOf(
            AppLanguage.RO to "Biletele mele",
            AppLanguage.EN to "My Tickets",
            AppLanguage.RU to "Мои билеты"
        ),
        "popular_dest" to mapOf(
            AppLanguage.RO to "Destinații populare",
            AppLanguage.EN to "Popular Destinations",
            AppLanguage.RU to "Популярные направления"
        ),
        "service_alerts" to mapOf(
            AppLanguage.RO to "Alerte de serviciu",
            AppLanguage.EN to "Service Alerts",
            AppLanguage.RU to "Оповещения службы"
        ),
        "fastest" to mapOf(
            AppLanguage.RO to "Cel mai rapid",
            AppLanguage.EN to "Fastest",
            AppLanguage.RU to "Самый быстрый"
        ),
        "cheapest" to mapOf(
            AppLanguage.RO to "Cel mai ieftin",
            AppLanguage.EN to "Cheapest",
            AppLanguage.RU to "Самый дешевый"
        ),
        "direct_only" to mapOf(
            AppLanguage.RO to "Doar directe",
            AppLanguage.EN to "Direct only",
            AppLanguage.RU to "Только прямые"
        ),
        "sort_departure" to mapOf(
            AppLanguage.RO to "Ora plecare",
            AppLanguage.EN to "Departure time",
            AppLanguage.RU to "Время отпр."
        ),
        "sort_arrival" to mapOf(
            AppLanguage.RO to "Ora sosire",
            AppLanguage.EN to "Arrival time",
            AppLanguage.RU to "Время приб."
        ),
        "duration" to mapOf(
            AppLanguage.RO to "Durată",
            AppLanguage.EN to "Duration",
            AppLanguage.RU to "Время в пути"
        ),
        "changes" to mapOf(
            AppLanguage.RO to "Schimburi",
            AppLanguage.EN to "Changes",
            AppLanguage.RU to "Пересадки"
        ),
        "class" to mapOf(
            AppLanguage.RO to "Clasă",
            AppLanguage.EN to "Class",
            AppLanguage.RU to "Класс"
        ),
        "seat" to mapOf(
            AppLanguage.RO to "Loc",
            AppLanguage.EN to "Seat",
            AppLanguage.RU to "Место"
        ),
        "carriage" to mapOf(
            AppLanguage.RO to "Vagon",
            AppLanguage.EN to "Carriage",
            AppLanguage.RU to "Вагон"
        ),
        "passenger_details" to mapOf(
            AppLanguage.RO to "Detalii Pasager",
            AppLanguage.EN to "Passenger Details",
            AppLanguage.RU to "Данные пассажира"
        ),
        "pay" to mapOf(
            AppLanguage.RO to "Plătește",
            AppLanguage.EN to "Pay Now",
            AppLanguage.RU to "Оплатить"
        ),
        "pay_subtitle" to mapOf(
            AppLanguage.RO to "Card, Google Pay, rPLaT sau CFM-Pay",
            AppLanguage.EN to "Card, Google Pay, rPLaT or CFM-Pay",
            AppLanguage.RU to "Карта, Google Pay, rPLaT или CFM-Pay"
        ),
        "saved_passengers" to mapOf(
            AppLanguage.RO to "Pasageri Salvați",
            AppLanguage.EN to "Saved Passengers",
            AppLanguage.RU to "Сохранённые пассажиры"
        ),
        "add_new_passenger" to mapOf(
            AppLanguage.RO to "Adaugă Pasager Nou",
            AppLanguage.EN to "Add New Passenger",
            AppLanguage.RU to "Добавить пассажира"
        ),
        "full_name" to mapOf(
            AppLanguage.RO to "Nume complet",
            AppLanguage.EN to "Full Name",
            AppLanguage.RU to "Полное имя"
        ),
        "document_number" to mapOf(
            AppLanguage.RO to "Număr document / ID",
            AppLanguage.EN to "Document Number / ID",
            AppLanguage.RU to "Номер документа / ID"
        ),
        "cancel" to mapOf(
            AppLanguage.RO to "Anulează",
            AppLanguage.EN to "Cancel",
            AppLanguage.RU to "Отмена"
        ),
        "save" to mapOf(
            AppLanguage.RO to "Salvează",
            AppLanguage.EN to "Save",
            AppLanguage.RU to "Сохранить"
        ),
        "select_class_to_proceed" to mapOf(
            AppLanguage.RO to "Selectați clasa și locul",
            AppLanguage.EN to "Select class and seat",
            AppLanguage.RU to "Выберите класс и место"
        ),
        "offline_validation" to mapOf(
            AppLanguage.RO to "VALIDARE OFFLINE ACTIVĂ",
            AppLanguage.EN to "ACTIVE OFFLINE VALIDATION",
            AppLanguage.RU to "АКТИВНАЯ ОФФЛАЙН ВАЛИДАЦИЯ"
        ),
        "sec_seal" to mapOf(
            AppLanguage.RO to "Sigiliu de securitate dinamic",
            AppLanguage.EN to "Dynamic security seal",
            AppLanguage.RU to "Динамическая печать безопасности"
        ),
        "no_tickets_yet" to mapOf(
            AppLanguage.RO to "Nu aveți bilete achiziționate",
            AppLanguage.EN to "No purchased tickets yet",
            AppLanguage.RU to "У вас ещё нет билетов"
        ),
        "buy_ticket_cta" to mapOf(
            AppLanguage.RO to "Cumpără un bilet acum pentru a călători rapid în Moldova!",
            AppLanguage.EN to "Buy a ticket now to travel fast across Moldova!",
            AppLanguage.RU to "Купите билет сейчас для быстрых путешествий по Молдове!"
        ),
        "results_for" to mapOf(
            AppLanguage.RO to "Rezultate pentru",
            AppLanguage.EN to "Results for",
            AppLanguage.RU to "Результаты для"
        ),
        "no_results" to mapOf(
            AppLanguage.RO to "Niciun tren găsit pentru această rută",
            AppLanguage.EN to "No trains found for this route",
            AppLanguage.RU to "Поездов по этому маршруту не найдено"
        ),
        "disruption_notice" to mapOf(
            AppLanguage.RO to "Anunț de întrerupere",
            AppLanguage.EN to "Disruption Notice",
            AppLanguage.RU to "Сообщение о сбоях"
        ),
        "disruptions_none" to mapOf(
            AppLanguage.RO to "Sistemul funcționează normal. Nu sunt semnalate întârzieri majore.",
            AppLanguage.EN to "All services running on time. No major delays reported.",
            AppLanguage.RU to "Система работает в штатном режиме. Задержек нет."
        ),
        "live_map" to mapOf(
            AppLanguage.RO to "Hartă Feroviară Interactivă",
            AppLanguage.EN to "Interactive Railway Map",
            AppLanguage.RU to "Интерактивная карта ЖД"
        ),
        "disruption_alert" to mapOf(
            AppLanguage.RO to "ALERTĂ: Lucrări de reparație pe tronsonul Ungheni-Bălți. Posibile întârzieri de 10-15 min.",
            AppLanguage.EN to "ALERT: Track maintenance on Ungheni-Balti line. Delays of 10-15 mins possible.",
            AppLanguage.RU to "ВНИМАНИЕ: Ремонт путей на линии Унгены-Бельцы. Возможны задержки 10-15 мин."
        ),
        "total_price" to mapOf(
            AppLanguage.RO to "Preț total",
            AppLanguage.EN to "Total price",
            AppLanguage.RU to "Итоговая цена"
        ),
        "active" to mapOf(
            AppLanguage.RO to "Activ",
            AppLanguage.EN to "Active",
            AppLanguage.RU to "Активен"
        ),
        "validated" to mapOf(
            AppLanguage.RO to "Validat de Controlor",
            AppLanguage.EN to "Validated by Conductor",
            AppLanguage.RU to "Проверено проводником"
        ),
        "seat_selection_info" to mapOf(
            AppLanguage.RO to "Atingeți un scaun liber pentru a-l rezerva în mod direct.",
            AppLanguage.EN to "Tap an empty seat to reserve it directly.",
            AppLanguage.RU to "Нажмите на свободное кресло, чтобы забронировать."
        ),
        "back" to mapOf(
            AppLanguage.RO to "Înapoi",
            AppLanguage.EN to "Back",
            AppLanguage.RU to "Назад"
        ),
        "home" to mapOf(
            AppLanguage.RO to "Acasă",
            AppLanguage.EN to "Home",
            AppLanguage.RU to "Главная"
        ),
        "map" to mapOf(
            AppLanguage.RO to "Hartă",
            AppLanguage.EN to "Map",
            AppLanguage.RU to "Карта"
        ),
        "settings" to mapOf(
            AppLanguage.RO to "Setări",
            AppLanguage.EN to "Settings",
            AppLanguage.RU to "Настройки"
        ),
        "popular_chis_ias_desc" to mapOf(
            AppLanguage.RO to "Zilnic spre Iași Socola din inima capitalei.",
            AppLanguage.EN to "Daily connections to Iasi Socola from the capital.",
            AppLanguage.RU to "Ежедневно в Яссы из сердца столицы."
        ),
        "popular_chis_buc_desc" to mapOf(
            AppLanguage.RO to "Călătoriți confortabil cu trenul istoric Prietenia.",
            AppLanguage.EN to "Travel in comfort with the historic sleeper Prietenia.",
            AppLanguage.RU to "Путешествуйте с комфортом на поезде 'Приетения'."
        ),
        "popular_chis_ung_desc" to mapOf(
            AppLanguage.RO to "Navetă rapidă cu trenuri modernizate.",
            AppLanguage.EN to "Rapid commute with modernized trains.",
            AppLanguage.RU to "Быстрые поездки на модернизированных поездах."
        ),
        "boarding_info" to mapOf(
            AppLanguage.RO to "Prezentați QR codul la îmbarcare împreună cu actul de identitate.",
            AppLanguage.EN to "Present this QR code on boarding along with your ID document.",
            AppLanguage.RU to "Предъявите QR-код при посадке вместе с удостоверением личности."
        ),
        "ticket_not_found" to mapOf(
            AppLanguage.RO to "Biletul nu a putut fi găsit.",
            AppLanguage.EN to "Ticket could not be found.",
            AppLanguage.RU to "Билет не найден."
        ),
        "national_routes" to mapOf(
            AppLanguage.RO to "Linii Naționale",
            AppLanguage.EN to "Domestic Lines",
            AppLanguage.RU to "Внутренние линии"
        ),
        "international_routes" to mapOf(
            AppLanguage.RO to "Linii Internaționale",
            AppLanguage.EN to "International Lines",
            AppLanguage.RU to "Международные линии"
        ),
        "next_departures" to mapOf(
            AppLanguage.RO to "Următoarele plecări",
            AppLanguage.EN to "Next Departures",
            AppLanguage.RU to "Ближайшие отправления"
        ),
        "next_arrivals" to mapOf(
            AppLanguage.RO to "Următoarele sosiri",
            AppLanguage.EN to "Next Arrivals",
            AppLanguage.RU to "Ближайшие прибытия"
        ),
        "station_facilities" to mapOf(
            AppLanguage.RO to "Facilitățile gării",
            AppLanguage.EN to "Station Facilities",
            AppLanguage.RU to "Услуги на вокзале"
        ),
        "station_accessibility" to mapOf(
            AppLanguage.RO to "Accesibilitate",
            AppLanguage.EN to "Accessibility",
            AppLanguage.RU to "Доступность"
        ),
        "platform_info" to mapOf(
            AppLanguage.RO to "Informații linii / peron",
            AppLanguage.EN to "Platform Information",
            AppLanguage.RU to "Информация о платформах"
        ),
        "local_connections" to mapOf(
            AppLanguage.RO to "Conexiuni locale și transport",
            AppLanguage.EN to "Local Connections & Transit",
            AppLanguage.RU to "Местный транспорт"
        ),
        "station_address" to mapOf(
            AppLanguage.RO to "Adresă",
            AppLanguage.EN to "Address",
            AppLanguage.RU to "Адрес"
        )
    )

    fun get(key: String, language: AppLanguage): String {
        return dictionary[key]?.get(language) ?: key
    }
}
