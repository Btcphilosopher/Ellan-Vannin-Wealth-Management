package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppLanguage
import com.example.data.StationEntity
import com.example.ui.theme.MoldovaBlue
import com.example.ui.theme.MoldovaGold
import com.example.ui.theme.MoldovaRed
import kotlinx.coroutines.delay
import kotlin.math.sin

data class MapNode(
    val code: String,
    val nameRo: String,
    val nameEn: String,
    val nameRu: String,
    val relX: Float, // 0.0 to 1.0 relative horizontal coordinate
    val relY: Float  // 0.0 to 1.0 relative vertical coordinate
) {
    fun getName(lang: AppLanguage): String = when (lang) {
        AppLanguage.RO -> nameRo
        AppLanguage.EN -> nameEn
        AppLanguage.RU -> nameRu
    }
}

data class MapEdge(
    val fromCode: String,
    val toCode: String,
    val isInternational: Boolean = false,
    val hasDisruption: Boolean = false
)

data class LiveTrainMarker(
    val id: String,
    val label: String,
    val fromCode: String,
    val toCode: String,
    val progress: Float, // 0.0 to 1.0 along the track
    val delayMinutes: Int = 0
)

@Composable
fun InteractiveMap(
    lang: AppLanguage,
    stationsList: List<StationEntity>,
    onStationSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    // Define geographic layout matching Moldovan coordinates relative to canvas size
    val mapNodes = remember {
        listOf(
            MapNode("CHISINAU", "Chișinău", "Chisinau", "Кишинёв", 0.55f, 0.45f),
            MapNode("BALTI", "Bălți", "Balti", "Бельцы", 0.38f, 0.26f),
            MapNode("UNGHENI", "Ungheni", "Ungheni", "Унгены", 0.28f, 0.40f),
            MapNode("TIRASPOL", "Tiraspol", "Tiraspol", "Тирасполь", 0.73f, 0.49f),
            MapNode("BENDER", "Bender", "Bender", "Бендеры", 0.65f, 0.51f),
            MapNode("CAHUL", "Cahul", "Cahul", "Кагул", 0.32f, 0.82f),
            MapNode("COMRAT", "Comrat", "Comrat", "Комрат", 0.45f, 0.69f),
            MapNode("SOROCA", "Soroca", "Soroca", "Сорока", 0.46f, 0.12f),
            // Border links
            MapNode("IASI", "Iași (RO)", "Iasi (RO)", "Яссы (RO)", 0.10f, 0.42f),
            MapNode("BUCURESTI", "București (RO)", "Bucharest (RO)", "Бухарест (RO)", 0.08f, 0.88f),
            MapNode("ODESA", "Odesa (UA)", "Odesa (UA)", "Одесса (UA)", 0.88f, 0.56f),
            MapNode("KYIV", "Kyiv (UA)", "Kyiv (UA)", "Киев (UA)", 0.85f, 0.16f)
        )
    }

    val mapEdges = remember {
        listOf(
            MapEdge("CHISINAU", "UNGHENI"),
            MapEdge("UNGHENI", "IASI", isInternational = true),
            MapEdge("UNGHENI", "BALTI", hasDisruption = true), // Maintenance on Ungheni-Balti
            MapNode("BALTI", "", "", "", 0f, 0f).let { MapEdge("BALTI", "SOROCA") },
            MapEdge("CHISINAU", "BENDER"),
            MapEdge("BENDER", "TIRASPOL"),
            MapEdge("TIRASPOL", "ODESA", isInternational = true),
            MapEdge("BENDER", "COMRAT"),
            MapEdge("COMRAT", "CAHUL"),
            MapEdge("CHISINAU", "KYIV", isInternational = true),
            MapEdge("CHISINAU", "BUCURESTI", isInternational = true)
        )
    }

    // Dynamic animation flow representing actual live operating trains in transit
    var timePulse by remember { mutableFloatStateOf(0.0f) }
    LaunchedEffect(Unit) {
        while (true) {
            timePulse += 0.015f
            if (timePulse > 2 * Math.PI) {
                timePulse = 0f
            }
            delay(100)
        }
    }

    // Map 3 live trains moving smoothly
    val liveTrains = remember(timePulse) {
        val t1Progress = (0.3f + sin(timePulse.toDouble()).toFloat() * 0.25f + 0.25f).coerceIn(0f, 1f)
        val t2Progress = (0.5f + sin(timePulse.toDouble() + 1.5).toFloat() * 0.35f + 0.35f).coerceIn(0f, 1f)
        val t3Progress = (0.5f + sin(timePulse.toDouble() * 0.8 - 0.5).toFloat() * 0.4f + 0.4f).coerceIn(0f, 1f)

        listOf(
            LiveTrainMarker("T1", "047", "CHISINAU", "UNGHENI", t1Progress, delayMinutes = 0),
            LiveTrainMarker("T2", "341", "UNGHENI", "BALTI", t2Progress, delayMinutes = 12), // delayed on disrupted segment
            LiveTrainMarker("T3", "105", "CHISINAU", "BUCURESTI", t3Progress, delayMinutes = 2)
        )
    }

    val textMeasurer = rememberTextMeasurer()
    val isDarkTheme = MaterialTheme.colorScheme.background.red < 0.5f

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        // Detect click on stations
                        val width = size.width
                        val height = size.height
                        mapNodes.forEach { node ->
                            val nX = node.relX * width
                            val nY = node.relY * height
                            val dist = (offset.x - nX) * (offset.x - nX) + (offset.y - nY) * (offset.y - nY)
                            // 24dp hit test radius
                            if (dist < 30 * 30) {
                                onStationSelected(node.code)
                            }
                        }
                    }
                }
        ) {
            val width = size.width
            val height = size.height

            // 1. Draw Country Border / Waterways or clean aesthetic background grids
            val gridColor = if (isDarkTheme) Color(0xFF232328) else Color(0xFFF1EFEA)
            for (i in 1..4) {
                val x = (i * 0.2f) * width
                drawLine(
                    color = gridColor,
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = 1.dp.toPx()
                )
                val y = (i * 0.2f) * height
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // 2. Draw Railway Lines
            mapEdges.forEach { edge ->
                val fromNode = mapNodes.find { it.code == edge.fromCode }
                val toNode = mapNodes.find { it.code == edge.toCode }

                if (fromNode != null && toNode != null) {
                    val pFrom = Offset(fromNode.relX * width, fromNode.relY * height)
                    val pTo = Offset(toNode.relX * width, toNode.relY * height)

                    val strokeColor = when {
                        edge.hasDisruption -> MoldovaGold
                        edge.isInternational -> MoldovaBlue.copy(alpha = 0.65f)
                        else -> if (isDarkTheme) Color(0xFF44444F) else Color(0xFF9E9EAE)
                    }

                    // For disrupted segment, draw a warning dashed line, otherwise a solid track
                    if (edge.hasDisruption) {
                        drawLine(
                            color = strokeColor,
                            start = pFrom,
                            end = pTo,
                            strokeWidth = 4.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                        )
                    } else {
                        // Standard beautiful train track drawing (solid line with small parallel track cross-ties)
                        drawLine(
                            color = strokeColor,
                            start = pFrom,
                            end = pTo,
                            strokeWidth = 3.dp.toPx()
                        )
                        // Optional cross ties for beautiful rail styling
                        drawLine(
                            color = if (isDarkTheme) Color(0xFF1E1E24) else Color.White,
                            start = pFrom,
                            end = pTo,
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 12f), 0f)
                        )
                    }
                }
            }

            // 3. Draw Active Maintenance / Disruption Icon Indicator Area
            mapEdges.filter { it.hasDisruption }.forEach { edge ->
                val fromNode = mapNodes.find { it.code == edge.fromCode }
                val toNode = mapNodes.find { it.code == edge.toCode }
                if (fromNode != null && toNode != null) {
                    val midX = (fromNode.relX + toNode.relX) / 2 * width
                    val midY = (fromNode.relY + toNode.relY) / 2 * height
                    
                    // Yellow exclamation halo
                    drawCircle(
                        color = MoldovaGold.copy(alpha = 0.25f),
                        radius = 16.dp.toPx(),
                        center = Offset(midX, midY)
                    )
                    drawCircle(
                        color = MoldovaGold,
                        radius = 4.dp.toPx(),
                        center = Offset(midX, midY)
                    )
                }
            }

            // 4. Draw Stations
            mapNodes.forEach { node ->
                val sX = node.relX * width
                val sY = node.relY * height

                val isSelectedHub = node.code == "CHISINAU" || node.code == "UNGHENI" || node.code == "BALTI"
                val stationColor = if (isDarkTheme) Color.White else Color(0xFF1C1C1E)

                // White backdrop circle
                drawCircle(
                    color = if (isDarkTheme) Color(0xFF121214) else Color.White,
                    radius = if (isSelectedHub) 8.dp.toPx() else 6.dp.toPx(),
                    center = Offset(sX, sY)
                )

                // Colored outline circle
                drawCircle(
                    color = if (isSelectedHub) MoldovaRed else MoldovaBlue,
                    radius = if (isSelectedHub) 6.dp.toPx() else 4.dp.toPx(),
                    center = Offset(sX, sY),
                    style = Stroke(width = 2.dp.toPx())
                )

                // Small center core
                drawCircle(
                    color = if (isSelectedHub) MoldovaRed else MoldovaBlue,
                    radius = 2.dp.toPx(),
                    center = Offset(sX, sY)
                )

                // Render localizable station label text cleanly
                val textStyle = TextStyle(
                    color = stationColor,
                    fontSize = if (isSelectedHub) 11.sp else 10.sp,
                    fontWeight = if (isSelectedHub) FontWeight.Bold else FontWeight.Medium
                )
                val textLayout = textMeasurer.measure(
                    text = node.getName(lang),
                    style = textStyle
                )
                
                // Position text intelligently on side of point
                val xOffset = when {
                    node.relX > 0.7f -> -textLayout.size.width - 8.dp.toPx()
                    else -> 8.dp.toPx()
                }
                val yOffset = -textLayout.size.height / 2f

                drawText(
                    textMeasurer = textMeasurer,
                    text = node.getName(lang),
                    style = textStyle,
                    topLeft = Offset(sX + xOffset, sY + yOffset)
                )
            }

            // 5. Draw Live Moving Train Markers
            liveTrains.forEach { train ->
                val fromNode = mapNodes.find { it.code == train.fromCode }
                val toNode = mapNodes.find { it.code == train.toCode }

                if (fromNode != null && toNode != null) {
                    val fX = fromNode.relX * width
                    val fY = fromNode.relY * height
                    val tX = toNode.relX * width
                    val tY = toNode.relY * height

                    // Linear interpolation progress along track
                    val currX = fX + (tX - fX) * train.progress
                    val currY = fY + (tY - fY) * train.progress

                    // Train colored point (Red for normal, Gold for delayed)
                    val trainColor = if (train.delayMinutes > 5) MoldovaGold else MoldovaRed

                    // Pulse border halo
                    drawCircle(
                        color = trainColor.copy(alpha = 0.35f),
                        radius = 11.dp.toPx(),
                        center = Offset(currX, currY)
                    )

                    drawCircle(
                        color = trainColor,
                        radius = 7.dp.toPx(),
                        center = Offset(currX, currY)
                    )

                    drawCircle(
                        color = Color.White,
                        radius = 2.dp.toPx(),
                        center = Offset(currX, currY)
                    )

                    // Draw train number label above the train dot
                    val trainLabelStyle = TextStyle(
                        color = if (isDarkTheme) Color(0xFFEEEEEE) else Color(0xFF1E1E24),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                    val labelLayout = textMeasurer.measure(
                        text = "Train ${train.label}",
                        style = trainLabelStyle
                    )
                    drawText(
                        textMeasurer = textMeasurer,
                        text = "Train ${train.label}",
                        style = trainLabelStyle,
                        topLeft = Offset(currX - labelLayout.size.width / 2f, currY - 18.dp.toPx() - labelLayout.size.height / 2f)
                    )
                }
            }
        }
    }
}
