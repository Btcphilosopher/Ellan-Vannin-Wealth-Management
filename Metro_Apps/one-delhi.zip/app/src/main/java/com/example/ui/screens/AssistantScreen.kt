package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.DelhiHeader
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue
import com.example.viewmodel.DelhiTransitViewModel

@Composable
fun AssistantScreen(viewModel: DelhiTransitViewModel) {
  val chatMessages by viewModel.chatMessages.collectAsState()
  var inputPrompt by remember { mutableStateOf("") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    DelhiHeader(
      title = "Delhi Transport Assistant",
      subtitle = "Natural language transport intelligence & multilingual queries (English / हिन्दी)"
    )

    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
      contentPadding = PaddingValues(vertical = 12.dp)
    ) {
      items(chatMessages) { msg ->
        val isUser = msg.first == "user"
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
          Surface(
            color = if (isUser) DelhiRed else MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.widthIn(max = 300.dp)
          ) {
            Text(
              text = msg.second,
              modifier = Modifier.padding(12.dp),
              color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
              style = MaterialTheme.typography.bodyMedium
            )
          }
        }
      }
    }

    Surface(
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier.fillMaxWidth(),
      shadowElevation = 8.dp
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = inputPrompt,
          onValueChange = { inputPrompt = it },
          modifier = Modifier.weight(1f),
          placeholder = { Text("Ask e.g. Fastest route to airport, Rajiv Chowk status...") },
          shape = RoundedCornerShape(8.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        IconButton(
          onClick = {
            if (inputPrompt.isNotBlank()) {
              viewModel.askAssistant(inputPrompt)
              inputPrompt = ""
            }
          },
          modifier = Modifier
            .background(DelhiRed, RoundedCornerShape(8.dp))
            .size(48.dp)
        ) {
          Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
        }
      }
    }
  }
}
