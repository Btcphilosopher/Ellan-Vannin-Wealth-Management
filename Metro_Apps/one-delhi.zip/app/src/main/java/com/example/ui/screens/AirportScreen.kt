package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.DelhiHeader
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue
import com.example.viewmodel.DelhiTransitViewModel

@Composable
fun AirportScreen(viewModel: DelhiTransitViewModel) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingBottomWindowInsets
  ) {
    item {
      DelhiHeader(
        title = "IGI Airport Transit Hub",
        subtitle = "Terminals 1, 2 & 3 • Airport Express Orange Line Non-Stop Service"
      )
    }

    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Flight, contentDescription = null, tint = DelhiRed)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Airport Express (Orange Line)",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "New Delhi Station ⇄ Shivaji Stadium ⇄ Dhaula Kuan ⇄ Delhi Aerocity ⇄ IGI Airport T3",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(12.dp))
          Divider(color = MaterialTheme.colorScheme.surfaceVariant)
          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(text = "Travel Time", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(text = "19 Minutes", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, color = MetroBlue)
            }
            Column {
              Text(text = "Frequency", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(text = "Every 10 min", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
            }
            Column {
              Text(text = "Fare", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(text = "₹60 Flat", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, color = DelhiRed)
            }
          }
        }
      }
    }

    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
          text = "TERMINAL SHUTTLES & CONNECTIONS",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        TerminalCard("Terminal 3 (T3)", "International & Domestic Mega Hub", "Connected directly via Airport Express Metro & feeder buses")
        TerminalCard("Terminal 2 (T2)", "Domestic Operations", "Free inter-terminal shuttle bus from T3 (Every 15 min)")
        TerminalCard("Terminal 1 (T1)", "Low-Cost Carrier Hub", "Magenta Line metro connection at Terminal 1 station")
      }
    }
  }
}

@Composable
fun TerminalCard(name: String, desc: String, connection: String) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(text = name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
      Text(text = desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      Spacer(modifier = Modifier.height(4.dp))
      Text(text = connection, style = MaterialTheme.typography.labelSmall, color = MetroBlue, fontWeight = FontWeight.Bold)
    }
  }
}
