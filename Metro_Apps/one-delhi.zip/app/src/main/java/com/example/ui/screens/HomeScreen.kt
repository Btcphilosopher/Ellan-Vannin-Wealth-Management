package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.AlertBanner
import com.example.ui.components.DelhiHeader
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue
import com.example.viewmodel.DelhiTransitViewModel

@Composable
fun HomeScreen(
  viewModel: DelhiTransitViewModel,
  onNavigateToJourney: () -> Unit,
  onNavigateToMetro: () -> Unit,
  onNavigateToBus: () -> Unit,
  onNavigateToTickets: () -> Unit,
  onNavigateToAirport: () -> Unit,
  onNavigateToEvParking: () -> Unit
) {
  val stations by viewModel.stations.collectAsState()
  val buses by viewModel.buses.collectAsState()
  val alerts by viewModel.alerts.collectAsState()
  val conditions by viewModel.conditions.collectAsState()

  var destinationQuery by remember { mutableStateOf("") }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingBottomWindowInsets
  ) {
    item {
      DelhiHeader(
        title = "Delhi, in motion.",
        subtitle = "Good afternoon • AQI ${conditions.aqiValue} (${conditions.aqiStatus.take(15)})"
      )
    }

    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Where are you going?",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = "Current location (Saket)",
            onValueChange = {},
            readOnly = true,
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.MyLocation, contentDescription = null, tint = DelhiRed) },
            label = { Text("FROM") },
            shape = RoundedCornerShape(8.dp)
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = destinationQuery,
            onValueChange = { destinationQuery = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search Delhi destination, station, or landmark") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MetroBlue) },
            label = { Text("TO") },
            shape = RoundedCornerShape(8.dp),
            trailingIcon = {
              IconButton(onClick = {
                if (destinationQuery.isNotEmpty()) {
                  viewModel.planJourney("Saket", destinationQuery)
                  onNavigateToJourney()
                }
              }) {
                Icon(Icons.Default.ArrowForward, contentDescription = "Plan", tint = DelhiRed)
              }
            }
          )
          Spacer(modifier = Modifier.height(12.dp))
          Button(
            onClick = { onNavigateToJourney() },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = DelhiRed),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Directions, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Plan Multimodal Journey")
          }
        }
      }
    }

    items(alerts) { alert ->
      AlertBanner(line = alert.line, message = alert.description, severity = alert.severity)
    }

    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
          text = "QUICK MODES",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          QuickActionButton(
            title = "Metro",
            icon = Icons.Default.Train,
            modifier = Modifier.weight(1f),
            onClick = onNavigateToMetro
          )
          QuickActionButton(
            title = "Bus OS",
            icon = Icons.Default.DirectionsBus,
            modifier = Modifier.weight(1f),
            onClick = onNavigateToBus
          )
          QuickActionButton(
            title = "Tickets",
            icon = Icons.Default.QrCode,
            modifier = Modifier.weight(1f),
            onClick = onNavigateToTickets
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          QuickActionButton(
            title = "Airport T3",
            icon = Icons.Default.Flight,
            modifier = Modifier.weight(1f),
            onClick = onNavigateToAirport
          )
          QuickActionButton(
            title = "EV & Park",
            icon = Icons.Default.EvStation,
            modifier = Modifier.weight(1f),
            onClick = onNavigateToEvParking
          )
          QuickActionButton(
            title = "Network",
            icon = Icons.Default.Hub,
            modifier = Modifier.weight(1f),
            onClick = onNavigateToJourney
          )
        }
      }
    }

    item {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "NEARBY STATIONS & STOPS",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        stations.take(3).forEach { station ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp)
              .clickable { onNavigateToMetro() },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(MetroBlue.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Train, contentDescription = null, tint = MetroBlue)
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(text = station.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                Text(text = "${station.lines.joinToString(", ")} • ${station.distanceWalkMin} min walk", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Surface(
                color = DelhiRed.copy(alpha = 0.1f),
                shape = RoundedCornerShape(4.dp)
              ) {
                Text(
                  text = "Next: ${station.nextTrainMinutes.first()}m",
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  color = DelhiRed,
                  fontWeight = FontWeight.Bold,
                  style = MaterialTheme.typography.labelSmall
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun QuickActionButton(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
  Card(
    modifier = modifier.clickable(onClick = onClick),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    shape = RoundedCornerShape(10.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Icon(icon, contentDescription = title, tint = DelhiRed, modifier = Modifier.size(24.dp))
      Spacer(modifier = Modifier.height(6.dp))
      Text(text = title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
  }
}

val PaddingBottomWindowInsets = PaddingValues(bottom = 80.dp)
