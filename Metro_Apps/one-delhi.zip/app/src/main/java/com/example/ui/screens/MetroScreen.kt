package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.DelhiHeader
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue
import com.example.viewmodel.DelhiTransitViewModel

@Composable
fun MetroScreen(viewModel: DelhiTransitViewModel) {
  val stations by viewModel.stations.collectAsState()
  var searchFilter by remember { mutableStateOf("") }

  val filteredStations = stations.filter {
    it.name.contains(searchFilter, ignoreCase = true) ||
      it.code.contains(searchFilter, ignoreCase = true) ||
      it.lines.any { l -> l.contains(searchFilter, ignoreCase = true) }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingBottomWindowInsets
  ) {
    item {
      DelhiHeader(
        title = "Delhi Metro (DMRC)",
        subtitle = "303 stations • 416 km network • Live departures & accessibility"
      )
    }

    item {
      Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
          value = searchFilter,
          onValueChange = { searchFilter = it },
          modifier = Modifier.fillMaxWidth(),
          placeholder = { Text("Search station name, code, or line (e.g. Rajiv Chowk, Yellow)") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MetroBlue) },
          shape = RoundedCornerShape(8.dp)
        )
      }
    }

    items(filteredStations) { station ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(10.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = station.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${station.hindiName} • Code: ${station.code}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Surface(
              color = MetroBlue.copy(alpha = 0.1f),
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = station.lines.joinToString(" / "),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                color = MetroBlue,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Divider(color = MaterialTheme.colorScheme.surfaceVariant)
          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "LIVE DEPARTURES (NEXT TRAINS)",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(4.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            station.nextTrainMinutes.forEach { min ->
              Surface(
                color = DelhiRed.copy(alpha = 0.1f),
                shape = RoundedCornerShape(6.dp)
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Default.Train, contentDescription = null, tint = DelhiRed, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "$min min",
                    color = DelhiRed,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Accessible, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "Lift: ${if (station.hasLift) "Available" else "N/A"} • Step-free",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            if (station.parkingAvailable) {
              Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(4.dp)
              ) {
                Text(
                  text = "Parking Available",
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                  style = MaterialTheme.typography.labelSmall
                )
              }
            }
          }
        }
      }
    }
  }
}
