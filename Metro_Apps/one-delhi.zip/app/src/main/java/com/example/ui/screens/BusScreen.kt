package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.DelhiHeader
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue
import com.example.viewmodel.DelhiTransitViewModel

@Composable
fun BusScreen(viewModel: DelhiTransitViewModel) {
  val buses by viewModel.buses.collectAsState()
  var searchFilter by remember { mutableStateOf("") }

  val filteredBuses = buses.filter {
    it.routeNumber.contains(searchFilter, ignoreCase = true) ||
      it.origin.contains(searchFilter, ignoreCase = true) ||
      it.destination.contains(searchFilter, ignoreCase = true)
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingBottomWindowInsets
  ) {
    item {
      DelhiHeader(
        title = "Delhi Buses (DTC & Cluster)",
        subtitle = "Open Transit Data ingestion • Realtime vehicle tracking & occupancy"
      )
    }

    item {
      Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
          value = searchFilter,
          onValueChange = { searchFilter = it },
          modifier = Modifier.fillMaxWidth(),
          placeholder = { Text("Search route number (e.g. 522, 534) or destination") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = DelhiRed) },
          shape = RoundedCornerShape(8.dp)
        )
      }
    }

    items(filteredBuses) { bus ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(10.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                color = DelhiRed,
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = bus.routeNumber,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  color = androidx.compose.ui.graphics.Color.White,
                  fontWeight = FontWeight.Bold,
                  style = MaterialTheme.typography.titleMedium
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "${bus.origin} → ${bus.destination}",
                  style = MaterialTheme.typography.bodyLarge,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "Agency: ${bus.agency} • Vehicle ID: ${bus.vehicleId}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Divider(color = MaterialTheme.colorScheme.surfaceVariant)
          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "LIVE ARRIVALS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(4.dp))
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                bus.nextArrivalsMin.forEach { min ->
                  Surface(
                    color = MetroBlue.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(4.dp)
                  ) {
                    Text(
                      text = "$min min",
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                      color = MetroBlue,
                      fontWeight = FontWeight.Bold,
                      style = MaterialTheme.typography.labelMedium
                    )
                  }
                }
              }
            }
            Column(horizontalAlignment = Alignment.End) {
              Text(text = "Currently near", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(text = bus.currentPosition, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = DelhiRed)
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Stops: ${bus.stops.joinToString(" → ")}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
