package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DelhiRed = Color(0xFFC8102E)
val MetroBlue = Color(0xFF003366)
val MetroYellow = Color(0xFFE6B800)
val MetroViolet = Color(0xFF660066)
val MetroPink = Color(0xFFD94D75)
val MetroMagenta = Color(0xFFB30059)
val MetroRedLine = Color(0xFFE60000)
val MetroGreenLine = Color(0xFF009933)
val MetroOrange = Color(0xFFFF6600)
val MetroGrey = Color(0xFF7F8C8D)

val WarmBackground = Color(0xFFF9F9F8)
val DarkBackground = Color(0xFF121315)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF1A1C1E)
val TextPrimaryLight = Color(0xFF1A1A1A)
val TextSecondaryLight = Color(0xFF555555)
val TextPrimaryDark = Color(0xFFF2F2F2)
val TextSecondaryDark = Color(0xFFB0B0B0)
