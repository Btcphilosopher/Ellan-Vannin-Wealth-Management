package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object DelhiTransitRepository {

  private val _stations =
    MutableStateFlow(
      listOf(
        MetroStation(
          id = "RAJIV_CHOWK",
          name = "Rajiv Chowk",
          hindiName = "राजीव चौक",
          code = "RJC",
          lines = listOf("Yellow Line", "Blue Line"),
          distanceWalkMin = 2,
          nextTrainMinutes = listOf(2, 5, 9),
          nearbyLandmarks = listOf("Connaught Place", "Central Park", "Janpath")
        ),
        MetroStation(
          id = "KASHMERE_GATE",
          name = "Kashmere Gate",
          hindiName = "कश्मीरी गेट",
          code = "KGM",
          lines = listOf("Red Line", "Yellow Line", "Violet Line"),
          distanceWalkMin = 4,
          nextTrainMinutes = listOf(1, 4, 8),
          nearbyLandmarks = listOf("ISBT", "Old Delhi", "Red Fort area")
        ),
        MetroStation(
          id = "HAUZ_KHAS",
          name = "Hauz Khas",
          hindiName = "हौज खास",
          code = "HZK",
          lines = listOf("Yellow Line", "Magenta Line"),
          distanceWalkMin = 3,
          nextTrainMinutes = listOf(3, 7, 12),
          nearbyLandmarks = listOf("IIT Delhi", "Deer Park", "Hauz Khas Village")
        ),
        MetroStation(
          id = "SAKET",
          name = "Saket",
          hindiName = "साकेत",
          code = "SKT",
          lines = listOf("Yellow Line"),
          distanceWalkMin = 5,
          nextTrainMinutes = listOf(2, 6, 11),
          nearbyLandmarks = listOf("Select Citywalk", "Max Hospital")
        ),
        MetroStation(
          id = "IGI_AIRPORT",
          name = "IGI Airport (T3)",
          hindiName = "इंदिरा गांधी अंतर्राष्ट्रीय हवाई अड्डा",
          code = "IGIA",
          lines = listOf("Airport Express (Orange)"),
          distanceWalkMin = 1,
          nextTrainMinutes = listOf(5, 15, 25),
          nearbyLandmarks = listOf("Terminal 3", "Airport Hotels")
        ),
        MetroStation(
          id = "NEW_DELHI",
          name = "New Delhi Railway Station",
          hindiName = "नई दिल्ली रेलवे स्टेशन",
          code = "NDLS",
          lines = listOf("Yellow Line", "Airport Express (Orange)"),
          distanceWalkMin = 3,
          nextTrainMinutes = listOf(3, 8, 14),
          nearbyLandmarks = listOf("Railway Station", "Pahar Ganj")
        ),
        MetroStation(
          id = "CHANDNI_CHOWK",
          name = "Chandni Chowk",
          hindiName = "चांदनी चौक",
          code = "CNC",
          lines = listOf("Yellow Line"),
          distanceWalkMin = 4,
          nextTrainMinutes = listOf(2, 6, 10),
          nearbyLandmarks = listOf("Town Hall", "Paranthe Wali Gali", "Red Fort")
        ),
        MetroStation(
          id = "AIIMS",
          name = "AIIMS",
          hindiName = "एम्स",
          code = "AIMS",
          lines = listOf("Yellow Line"),
          distanceWalkMin = 2,
          nextTrainMinutes = listOf(4, 9, 15),
          nearbyLandmarks = listOf("AIIMS Hospital", "Safdarjung Hospital", "Dilli Haat")
        )
      )
    )
  val stations: StateFlow<List<MetroStation>> = _stations.asStateFlow()

  private val _buses =
    MutableStateFlow(
      listOf(
        BusRoute(
          routeNumber = "522",
          agency = "DTC",
          origin = "Mehrauli",
          destination = "AIIMS",
          nextArrivalsMin = listOf(4, 11, 18),
          vehicleId = "DL-1PC-8912",
          currentPosition = "Lajpat Nagar",
          occupancy = "Moderate",
          stops = listOf("Mehrauli", "Saket Crossing", "Lajpat Nagar", "Moolchand", "AIIMS")
        ),
        BusRoute(
          routeNumber = "534",
          agency = "Cluster",
          origin = "Anand Vihar ISBT",
          destination = "Nehru Place",
          nextArrivalsMin = listOf(2, 9, 16),
          vehicleId = "DL-1PC-3304",
          currentPosition = "ITO",
          occupancy = "High",
          stops = listOf("Anand Vihar", "ITO", "Pragati Maidan", "Lodhi Road", "Nehru Place")
        ),
        BusRoute(
          routeNumber = "727",
          agency = "DTC",
          origin = "Uttam Nagar",
          destination = "Connaught Place",
          nextArrivalsMin = listOf(5, 14, 22),
          vehicleId = "DL-1PC-9921",
          currentPosition = "Rajouri Garden",
          occupancy = "Low",
          stops = listOf("Uttam Nagar", "Rajouri Garden", "Patel Nagar", "Connaught Place")
        )
      )
    )
  val buses: StateFlow<List<BusRoute>> = _buses.asStateFlow()

  private val _alerts =
    MutableStateFlow(
      listOf(
        ServiceAlert(
          id = "ALRT-1",
          line = "Blue Line",
          title = "Minor Congestion",
          description = "Due to heavy passenger volume at Rajiv Chowk, slight delays expected (+3 min).",
          severity = "DELAY",
          additionalDelayMin = 3
        ),
        ServiceAlert(
          id = "ALRT-2",
          line = "Yellow Line",
          title = "Normal Operations",
          description = "All trains running on regular schedule across Samaypur Badli to Millennium City Centre.",
          severity = "NORMAL",
          additionalDelayMin = 0
        )
      )
    )
  val alerts: StateFlow<List<ServiceAlert>> = _alerts.asStateFlow()

  private val _tickets =
    MutableStateFlow(
      listOf(
        TicketItem(
          id = "TKT-8841",
          transportType = "Delhi Metro QR Ticket",
          routeOrStations = "Rajiv Chowk → Hauz Khas",
          validityTime = "Valid till 18:30 Today",
          qrCodePayload = "DELHI-METRO-QR-8841-SECURE-TOKEN",
          priceInr = 40,
          isValid = true
        ),
        TicketItem(
          id = "TKT-9021",
          transportType = "DTC Bus Pass",
          routeOrStations = "All Route Non-AC Pass",
          validityTime = "Valid for 24 Hours",
          qrCodePayload = "DTC-BUS-PASS-9021-SECURE",
          priceInr = 50,
          isValid = true
        )
      )
    )
  val tickets: StateFlow<List<TicketItem>> = _tickets.asStateFlow()

  private val _evStations =
    MutableStateFlow(
      listOf(
        EvStation("EV-1", "Connaught Place EV Hub", "Tata Power", 60, 3, 4, 15.0),
        EvStation("EV-2", "Saket Metro EV Station", "BESCOM / DMRC", 30, 2, 2, 14.5),
        EvStation("EV-3", "IGI Airport T3 Charging Bay", "Statiq", 120, 5, 8, 18.0)
      )
    )
  val evStations: StateFlow<List<EvStation>> = _evStations.asStateFlow()

  private val _parkings =
    MutableStateFlow(
      listOf(
        ParkingFacility("PRK-1", "Rajiv Chowk Central Parking", 250, 42, 30),
        ParkingFacility("PRK-2", "Hauz Khas Metro Parking", 180, 15, 20),
        ParkingFacility("PRK-3", "Kashmere Gate Multi-level Parking", 500, 184, 25)
      )
    )
  val parkings: StateFlow<List<ParkingFacility>> = _parkings.asStateFlow()

  private val _conditions =
    MutableStateFlow(
      CityConditions(
        temperatureCelsius = 34,
        conditionText = "Hot & Sunny",
        aqiValue = 285,
        aqiStatus = "Poor (Avoid prolonged outdoor walking)",
        pm25 = 142.5,
        pm10 = 265.0
      )
    )
  val conditions: StateFlow<CityConditions> = _conditions.asStateFlow()

  private val _commutes =
    MutableStateFlow(
      listOf(
        CommuteRoute("C-1", "Home to Work", "Saket", "Connaught Place", 38, 42, "Slight Blue Line delay"),
        CommuteRoute("C-2", "Work to Gym", "Connaught Place", "Hauz Khas", 28, 28, "Normal operations")
      )
    )
  val commutes: StateFlow<List<CommuteRoute>> = _commutes.asStateFlow()

  fun addTicket(ticket: TicketItem) {
    _tickets.value = listOf(ticket) + _tickets.value
  }

  fun updateAlerts(newAlerts: List<ServiceAlert>) {
    _alerts.value = newAlerts
  }
}
