package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.DelhiTransitViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val viewModel: DelhiTransitViewModel = viewModel()
        var currentTab by remember { mutableStateOf("home") }

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          bottomBar = {
            NavigationBar(
              containerColor = MaterialTheme.colorScheme.surface
            ) {
              NavigationBarItem(
                selected = currentTab == "home",
                onClick = { currentTab = "home" },
                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                label = { Text("Home") },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = DelhiRed)
              )
              NavigationBarItem(
                selected = currentTab == "journey",
                onClick = { currentTab = "journey" },
                icon = { Icon(Icons.Default.Directions, contentDescription = "Journey") },
                label = { Text("Journey") },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = DelhiRed)
              )
              NavigationBarItem(
                selected = currentTab == "metro",
                onClick = { currentTab = "metro" },
                icon = { Icon(Icons.Default.Train, contentDescription = "Metro") },
                label = { Text("Metro") },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = DelhiRed)
              )
              NavigationBarItem(
                selected = currentTab == "tickets",
                onClick = { currentTab = "tickets" },
                icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Tickets") },
                label = { Text("Tickets") },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = DelhiRed)
              )
              NavigationBarItem(
                selected = currentTab == "more",
                onClick = { currentTab = "more" },
                icon = { Icon(Icons.Default.Menu, contentDescription = "More") },
                label = { Text("More") },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = DelhiRed)
              )
            }
          }
        ) { innerPadding ->
          Box(modifier = Modifier.padding(innerPadding)) {
            when (currentTab) {
              "home" -> HomeScreen(
                viewModel = viewModel,
                onNavigateToJourney = { currentTab = "journey" },
                onNavigateToMetro = { currentTab = "metro" },
                onNavigateToBus = { currentTab = "bus" },
                onNavigateToTickets = { currentTab = "tickets" },
                onNavigateToAirport = { currentTab = "airport" },
                onNavigateToEvParking = { currentTab = "ev" }
              )
              "journey" -> JourneyPlannerScreen(viewModel = viewModel, onNavigateToTickets = { currentTab = "tickets" })
              "metro" -> MetroScreen(viewModel = viewModel)
              "bus" -> BusScreen(viewModel = viewModel)
              "tickets" -> TicketsScreen(viewModel = viewModel)
              "network" -> NetworkControlScreen(viewModel = viewModel)
              "airport" -> AirportScreen(viewModel = viewModel)
              "ev" -> EvParkingScreen(viewModel = viewModel)
              "assistant" -> AssistantScreen(viewModel = viewModel)
              "more" -> MoreScreen(viewModel = viewModel)
            }
          }
        }
      }
    }
  }
}
