package com.example.model

data class MetroStation(
  val id: String,
  val name: String,
  val hindiName: String,
  val code: String,
  val lines: List<String>,
  val distanceWalkMin: Int = 3,
  val nextTrainMinutes: List<Int> = listOf(2, 6, 10),
  val hasLift: Boolean = true,
  val hasEscalator: Boolean = true,
  val isStepFree: Boolean = true,
  val parkingAvailable: Boolean = true,
  val nearbyLandmarks: List<String> = emptyList(),
  val lat: Double = 28.6139,
  val lon: Double = 77.2090
)

data class BusRoute(
  val routeNumber: String,
  val agency: String, // DTC or Cluster
  val origin: String,
  val destination: String,
  val nextArrivalsMin: List<Int> = listOf(6, 12, 19),
  val vehicleId: String = "DL-1PC-4821",
  val currentPosition: String = "Lajpat Nagar",
  val occupancy: String = "Moderate",
  val stops: List<String> = emptyList()
)

data class JourneyOption(
  val id: String,
  val title: String,
  val totalDurationMinutes: Int,
  val fareInr: Int,
  val changesCount: Int,
  val modes: List<String>,
  val steps: List<JourneyStep>,
  val tag: String = "Fastest"
)

data class JourneyStep(
  val mode: String, // Metro, Bus, Walk, Auto, Taxi
  val instruction: String,
  val detail: String,
  val durationMinutes: Int,
  val lineOrRoute: String? = null
)

data class TicketItem(
  val id: String,
  val transportType: String, // Metro QR, DTC Bus, Airport Express
  val routeOrStations: String,
  val validityTime: String,
  val qrCodePayload: String,
  val priceInr: Int,
  val isValid: Boolean = true
)

data class ServiceAlert(
  val id: String,
  val line: String,
  val title: String,
  val description: String,
  val severity: String, // NORMAL, DELAY, CLOSED
  val additionalDelayMin: Int = 0
)

data class EvStation(
  val id: String,
  val name: String,
  val provider: String,
  val powerKw: Int,
  val availablePlugs: Int,
  val totalPlugs: Int,
  val tariffPerKwh: Double
)

data class ParkingFacility(
  val id: String,
  val stationName: String,
  val totalSpaces: Int,
  val availableSpaces: Int,
  val hourlyRateInr: Int
)

data class CityConditions(
  val temperatureCelsius: Int,
  val conditionText: String,
  val aqiValue: Int,
  val aqiStatus: String,
  val pm25: Double,
  val pm10: Double
)

data class CommuteRoute(
  val id: String,
  val title: String,
  val origin: String,
  val destination: String,
  val typicalDurationMin: Int,
  val currentDurationMin: Int,
  val statusNote: String
)
