package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.DelhiHeader
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue
import com.example.viewmodel.DelhiTransitViewModel

@Composable
fun TicketsScreen(viewModel: DelhiTransitViewModel) {
  val tickets by viewModel.tickets.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingBottomWindowInsets
  ) {
    item {
      DelhiHeader(
        title = "My Tickets & Digital Passes",
        subtitle = "Secure QR ticketing wallet with DMRC & DTC provider integration"
      )
    }

    item {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "ACTIVE TICKETS (${tickets.size})",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Surface(
            color = DelhiRed.copy(alpha = 0.1f),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = "ENCRYPTED KEYSTORE",
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              color = DelhiRed,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }

    items(tickets) { ticket ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = MetroBlue)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = ticket.transportType,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
            }
            Surface(
              color = Color(0xFFD4EDDA),
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = "VALID",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                color = Color(0xFF155724),
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = ticket.routeOrStations,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = ticket.validityTime,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(16.dp))
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(110.dp)
              .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(Icons.Default.QrCode2, contentDescription = "QR Code", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(64.dp))
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = ticket.qrCodePayload,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Amount: ₹${ticket.priceInr}",
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.bodyMedium
            )
            Text(
              text = "Tap AFC Gates to Scan",
              style = MaterialTheme.typography.bodySmall,
              color = DelhiRed,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }
  }
}
