package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.AlertBanner
import com.example.ui.components.DelhiHeader
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue
import com.example.viewmodel.DelhiTransitViewModel

@Composable
fun NetworkControlScreen(viewModel: DelhiTransitViewModel) {
  val alerts by viewModel.alerts.collectAsState()
  val conditions by viewModel.conditions.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingBottomWindowInsets
  ) {
    item {
      DelhiHeader(
        title = "Live Network Control Centre",
        subtitle = "Delhi NCR transport telemetry, resilience, and disruption simulator"
      )
    }

    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "SYSTEM HEALTH OVERVIEW",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            StatusPill("Metro (303 Stns)", "NORMAL", MetroBlue)
            StatusPill("DTC Buses", "NORMAL", MetroBlue)
            StatusPill("Airport T3", "NORMAL", MetroBlue)
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            StatusPill("Air Quality", "POOR", DelhiRed)
            StatusPill("Weather", "34°C Hot", MetroBlue)
            StatusPill("Routing Engine", "OPTIMISED", MetroBlue)
          }
        }
      }
    }

    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Science, contentDescription = null, tint = DelhiRed)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Delhi Network Simulator",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Inject disruptions to test automated RAPTOR/A* routing adaptation.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = { viewModel.injectSimulatorDisruption("Blue Line Delay") },
              modifier = Modifier.weight(1f),
              colors = ButtonDefaults.buttonColors(containerColor = DelhiRed)
            ) {
              Text("Inject Blue Delay")
            }
            OutlinedButton(
              onClick = { viewModel.injectSimulatorDisruption("Reset Normal") },
              modifier = Modifier.weight(1f)
            ) {
              Text("Reset Normal")
            }
          }
        }
      }
    }

    item {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "ACTIVE SERVICE ALERTS (${alerts.size})",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
      }
    }

    items(alerts) { alert ->
      AlertBanner(line = alert.line, message = alert.description, severity = alert.severity)
    }
  }
}

@Composable
fun StatusPill(label: String, status: String, color: androidx.compose.ui.graphics.Color) {
  Surface(
    color = color.copy(alpha = 0.1f),
    shape = RoundedCornerShape(8.dp)
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      Spacer(modifier = Modifier.height(2.dp))
      Text(text = status, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = color)
    }
  }
}
