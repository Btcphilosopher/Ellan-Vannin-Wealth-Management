package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.DelhiTransitRepository
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class DelhiTransitViewModel : ViewModel() {

  val stations = DelhiTransitRepository.stations
  val buses = DelhiTransitRepository.buses
  val alerts = DelhiTransitRepository.alerts
  val tickets = DelhiTransitRepository.tickets
  val evStations = DelhiTransitRepository.evStations
  val parkings = DelhiTransitRepository.parkings
  val conditions = DelhiTransitRepository.conditions
  val commutes = DelhiTransitRepository.commutes

  // Journey Planner State
  private val _journeyResults = MutableStateFlow<List<JourneyOption>>(emptyList())
  val journeyResults: StateFlow<List<JourneyOption>> = _journeyResults.asStateFlow()

  private val _selectedJourney = MutableStateFlow<JourneyOption?>(null)
  val selectedJourney: StateFlow<JourneyOption?> = _selectedJourney.asStateFlow()

  // Assistant Chat State
  private val _chatMessages =
    MutableStateFlow<List<Pair<String, String>>>(
      listOf(
        Pair(
          "system",
          "नमस्ते! I am your One Delhi Assistant. Ask me about routes, metro delays, airport travel, or station facilities."
        )
      )
    )
  val chatMessages: StateFlow<List<Pair<String, String>>> = _chatMessages.asStateFlow()

  fun planJourney(from: String, to: String, preference: String = "Fastest") {
    val durationMultiplier = if (preference == "Cheapest") 1.3 else 1.0
    val fare = if (preference == "Cheapest") 30 else 50

    val options =
      listOf(
        JourneyOption(
          id = "J-1",
          title = "Fastest Metro Route",
          totalDurationMinutes = (34 * durationMultiplier).toInt(),
          fareInr = fare,
          changesCount = 1,
          modes = listOf("Walk", "Yellow Line", "Blue Line"),
          steps =
            listOf(
              JourneyStep("Walk", "Walk to $from Station", "Platform access via Gate 2", 3),
              JourneyStep(
                "Metro",
                "Board Yellow Line towards Samaypur Badli",
                "4 stations • 12 min",
                12,
                "Yellow Line"
              ),
              JourneyStep("Transfer", "Interchange at Rajiv Chowk", "Follow blue line boards", 4),
              JourneyStep(
                "Metro",
                "Board Blue Line towards Dwarka Sector 21",
                "5 stations • 11 min",
                11,
                "Blue Line"
              ),
              JourneyStep("Walk", "Walk to $to", "Exit Gate 3", 4)
            ),
          tag = "Fastest"
        ),
        JourneyOption(
          id = "J-2",
          title = "Multimodal (Metro + Bus 522)",
          totalDurationMinutes = 42,
          fareInr = 40,
          changesCount = 2,
          modes = listOf("Walk", "Metro", "Bus 522"),
          steps =
            listOf(
              JourneyStep("Walk", "Walk to station", "Near $from", 4),
              JourneyStep("Metro", "Yellow Line to AIIMS", "6 stations • 16 min", 16, "Yellow Line"),
              JourneyStep("Bus", "Board Bus 522 towards destination", "Route via Ring Road", 18, "Bus 522"),
              JourneyStep("Walk", "Final arrival walk", "Destination reached", 4)
            ),
          tag = "Fewer Crowds"
        ),
        JourneyOption(
          id = "J-3",
          title = "Airport Special Express",
          totalDurationMinutes = 26,
          fareInr = 60,
          changesCount = 0,
          modes = listOf("Walk", "Airport Express"),
          steps =
            listOf(
              JourneyStep("Walk", "Walk to New Delhi Station", "Airport Express concourse", 5),
              JourneyStep(
                "Metro",
                "Airport Express (Orange Line) to IGI Airport T3",
                "Non-stop express • 19 min",
                19,
                "Orange Line"
              ),
              JourneyStep("Walk", "Arrival at Terminal 3 departure gates", "Level 2 check-in", 2)
            ),
          tag = "Airport Direct"
        )
      )
    _journeyResults.value = options
  }

  fun selectJourney(journey: JourneyOption?) {
    _selectedJourney.value = journey
  }

  fun buyTicket(routeOrStations: String, price: Int) {
    val newTicket =
      TicketItem(
        id = "TKT-${(1000..9999).random()}",
        transportType = "Delhi Metro QR Ticket",
        routeOrStations = routeOrStations,
        validityTime = "Valid till end of today",
        qrCodePayload = "DELHI-QR-${System.currentTimeMillis()}-SECURE",
        priceInr = price,
        isValid = true
      )
    DelhiTransitRepository.addTicket(newTicket)
  }

  fun askAssistant(prompt: String) {
    val current = _chatMessages.value.toMutableList()
    current.add(Pair("user", prompt))

    val lower = prompt.lowercase()
    val reply =
      when {
        lower.contains("airport") || lower.contains("igi") ->
          "The Airport Express (Orange Line) runs every 10 minutes from New Delhi to IGI Airport T3 in just 19 minutes. Fare is ₹60."
        lower.contains("delay") || lower.contains("status") ->
          "Network status: Most lines operating normally. Blue Line has minor congestion (+3 min)."
        lower.contains("rajiv chowk") ->
          "Rajiv Chowk interchange connects Yellow and Blue lines. Next Yellow line train in 2 min, Blue line in 5 min."
        lower.contains("connot") || lower.contains("connaught") ->
          "Connaught Place is directly serviced by Rajiv Chowk metro station (Exits 1 through 7)."
        lower.contains("hindi") || lower.contains("कहाँ") || lower.contains("राजीव") ->
          "राजीव चौक स्टेशन पीली और नीली लाइन को जोड़ता है। सभी ट्रेनें सुचारू रूप से चल रही हैं।"
        else ->
          "I have checked Delhi transit intelligence for '$prompt'. You can plan a journey using the Journey tab or check live departures in Metro & Bus sections."
      }

    current.add(Pair("system", reply))
    _chatMessages.value = current
  }

  fun injectSimulatorDisruption(type: String) {
    when (type) {
      "Blue Line Delay" -> {
        DelhiTransitRepository.updateAlerts(
          listOf(
            ServiceAlert(
              id = "SIM-1",
              line = "Blue Line",
              title = "Major Disruption / Delay",
              description = "Simulated signal failure. Expected delay +15 min.",
              severity = "DELAY",
              additionalDelayMin = 15
            )
          )
        )
      }
      "Reset Normal" -> {
        DelhiTransitRepository.updateAlerts(
          listOf(
            ServiceAlert(
              id = "ALRT-2",
              line = "All Lines",
              title = "Normal Operations",
              description = "All DMRC lines and DTC buses operating normally.",
              severity = "NORMAL",
              additionalDelayMin = 0
            )
          )
        )
      }
    }
  }
}
