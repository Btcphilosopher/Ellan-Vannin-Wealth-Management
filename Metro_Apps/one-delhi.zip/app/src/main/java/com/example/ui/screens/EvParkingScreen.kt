package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.DelhiHeader
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue
import com.example.viewmodel.DelhiTransitViewModel

@Composable
fun EvParkingScreen(viewModel: DelhiTransitViewModel) {
  val evStations by viewModel.evStations.collectAsState()
  val parkings by viewModel.parkings.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingBottomWindowInsets
  ) {
    item {
      DelhiHeader(
        title = "EV Charging & Metro Parking",
        subtitle = "Zero-emission infrastructure & multi-level commuter parking"
      )
    }

    item {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "FAST EV CHARGERS (${evStations.size})",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
      }
    }

    items(evStations) { ev ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.EvStation, contentDescription = null, tint = DelhiRed, modifier = Modifier.size(32.dp))
          Spacer(modifier = Modifier.width(16.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(text = ev.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
            Text(text = "Provider: ${ev.provider} • ${ev.powerKw} kW", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = "₹${ev.tariffPerKwh} / kWh", style = MaterialTheme.typography.labelSmall, color = MetroBlue, fontWeight = FontWeight.Bold)
          }
          Surface(
            color = Color(0xFFD4EDDA),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = "${ev.availablePlugs}/${ev.totalPlugs} Free",
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              color = Color(0xFF155724),
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.labelSmall
            )
          }
        }
      }
    }

    item {
      Column(modifier = Modifier.padding(16.dp)) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "METRO STATION PARKING (${parkings.size})",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
      }
    }

    items(parkings) { parking ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.LocalParking, contentDescription = null, tint = MetroBlue, modifier = Modifier.size(32.dp))
          Spacer(modifier = Modifier.width(16.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(text = parking.stationName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
            Text(text = "₹${parking.hourlyRateInr} / hour • Total capacity: ${parking.totalSpaces}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = "${parking.availableSpaces} spots open",
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.labelSmall
            )
          }
        }
      }
    }
  }
}
