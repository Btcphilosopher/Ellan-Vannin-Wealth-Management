package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue

@Composable
fun DelhiHeader(title: String, subtitle: String, modifier: Modifier = Modifier) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(MaterialTheme.colorScheme.surface)
      .padding(horizontal = 16.dp, vertical = 12.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(10.dp)
          .clip(RoundedCornerShape(2.dp))
          .background(DelhiRed)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "ONE DELHI OS",
        style = MaterialTheme.typography.labelSmall,
        color = DelhiRed,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp
      )
      Spacer(modifier = Modifier.weight(1f))
      Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(4.dp)
      ) {
        Text(
          text = "LIVE NCR",
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
          style = MaterialTheme.typography.labelSmall,
          color = MetroBlue,
          fontWeight = FontWeight.Bold
        )
      }
    }
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = title,
      style = MaterialTheme.typography.headlineMedium,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onSurface
    )
    if (subtitle.isNotEmpty()) {
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}

@Composable
fun AlertBanner(line: String, message: String, severity: String) {
  val bg = if (severity == "DELAY") Color(0xFFFFF3CD) else Color(0xFFD4EDDA)
  val textColor = if (severity == "DELAY") Color(0xFF856404) else Color(0xFF155724)
  val badgeText = if (severity == "DELAY") "⚠ DELAY" else "✓ NORMAL"

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp),
    colors = CardDefaults.cardColors(containerColor = bg),
    shape = RoundedCornerShape(8.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = line,
            fontWeight = FontWeight.Bold,
            color = textColor,
            style = MaterialTheme.typography.bodyMedium
          )
          Spacer(modifier = Modifier.width(8.dp))
          Surface(
            color = textColor.copy(alpha = 0.2f),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = badgeText,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              color = textColor,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold
            )
          }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = message,
          color = textColor,
          style = MaterialTheme.typography.bodySmall
        )
      }
    }
  }
}
