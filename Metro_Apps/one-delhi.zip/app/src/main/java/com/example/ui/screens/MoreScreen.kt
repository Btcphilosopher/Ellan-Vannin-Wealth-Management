package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.DelhiHeader
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue
import com.example.viewmodel.DelhiTransitViewModel

@Composable
fun MoreScreen(viewModel: DelhiTransitViewModel) {
  val conditions by viewModel.conditions.collectAsState()
  val commutes by viewModel.commutes.collectAsState()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingBottomWindowInsets
  ) {
    item {
      DelhiHeader(
        title = "Commute & City Intelligence",
        subtitle = "Weather, AQI, Indian Railways nodes, and saved preferences"
      )
    }

    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.WbSunny, contentDescription = null, tint = MetroBlue)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Delhi Atmosphere & Climate",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
          }
          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(text = "Temperature", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(text = "${conditions.temperatureCelsius}°C (${conditions.conditionText})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
            }
            Column {
              Text(text = "Air Quality (AQI)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(text = "${conditions.aqiValue}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, color = DelhiRed)
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "PM2.5: ${conditions.pm25} µg/m³ • PM10: ${conditions.pm10} µg/m³",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = conditions.aqiStatus,
            style = MaterialTheme.typography.labelMedium,
            color = DelhiRed,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }

    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text(
          text = "SAVED COMMUTE ROUTES",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
      }
    }

    items(commutes) { commute ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = commute.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
            Text(text = "${commute.currentDurationMin} min", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, color = DelhiRed)
          }
          Text(text = "${commute.origin} → ${commute.destination}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Spacer(modifier = Modifier.height(4.dp))
          Text(text = "Status: ${commute.statusNote}", style = MaterialTheme.typography.labelSmall, color = MetroBlue, fontWeight = FontWeight.Bold)
        }
      }
    }

    item {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "INDIAN RAILWAYS NCR NODES",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        RailwayNodeItem("New Delhi (NDLS)", "Central hub connecting Yellow Line & Airport Express")
        RailwayNodeItem("Old Delhi (DLI)", "Historic railway terminal with Red & Yellow line access")
        RailwayNodeItem("Hazrat Nizamuddin (NZM)", "Major southern rail terminal with Pink line connectivity")
        RailwayNodeItem("Anand Vihar (ANVT)", "East Delhi multimodal transport hub (Rail + Metro + ISBT)")
      }
    }
  }
}

@Composable
fun RailwayNodeItem(name: String, desc: String) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(Icons.Default.DirectionsRailway, contentDescription = null, tint = DelhiRed)
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(text = name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
        Text(text = desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
  }
}
