package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.JourneyOption
import com.example.ui.components.DelhiHeader
import com.example.ui.theme.DelhiRed
import com.example.ui.theme.MetroBlue
import com.example.viewmodel.DelhiTransitViewModel

@Composable
fun JourneyPlannerScreen(viewModel: DelhiTransitViewModel, onNavigateToTickets: () -> Unit) {
  var fromText by remember { mutableStateOf("Saket") }
  var toText by remember { mutableStateOf("Connaught Place") }
  var selectedPref by remember { mutableStateOf("Fastest") }

  val journeyResults by viewModel.journeyResults.collectAsState()

  LaunchedEffect(Unit) {
    if (journeyResults.isEmpty()) {
      viewModel.planJourney(fromText, toText, selectedPref)
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingBottomWindowInsets
  ) {
    item {
      DelhiHeader(
        title = "Journey Planner",
        subtitle = "Multimodal graph routing (Metro + Bus + Rail + Walk)"
      )
    }

    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          OutlinedTextField(
            value = fromText,
            onValueChange = { fromText = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("FROM") },
            leadingIcon = { Icon(Icons.Default.TripOrigin, contentDescription = null, tint = DelhiRed) },
            shape = RoundedCornerShape(8.dp)
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = toText,
            onValueChange = { toText = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("TO") },
            leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = MetroBlue) },
            shape = RoundedCornerShape(8.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            listOf("Fastest", "Cheapest", "Fewer Changes").forEach { pref ->
              FilterChip(
                selected = selectedPref == pref,
                onClick = {
                  selectedPref = pref
                  viewModel.planJourney(fromText, toText, pref)
                },
                label = { Text(pref) }
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Button(
            onClick = { viewModel.planJourney(fromText, toText, selectedPref) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = DelhiRed),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Search, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Recompute Multimodal Routes")
          }
        }
      }
    }

    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "OPTIMISED ROUTES (${journeyResults.size})",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
          text = "AQI & Heat Adjusted",
          style = MaterialTheme.typography.labelSmall,
          color = MetroBlue
        )
      }
    }

    items(journeyResults) { option ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(10.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = option.title,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Surface(
              color = DelhiRed.copy(alpha = 0.1f),
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = option.tag,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                color = DelhiRed,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "${option.totalDurationMinutes} min", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.width(16.dp))
            Icon(Icons.Default.Payments, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "₹${option.fareInr}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = "${option.changesCount} interchanges", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }

          Spacer(modifier = Modifier.height(12.dp))
          Divider(color = MaterialTheme.colorScheme.surfaceVariant)
          Spacer(modifier = Modifier.height(8.dp))

          option.steps.forEach { step ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .background(DelhiRed, RoundedCornerShape(4.dp))
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(text = step.instruction, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                Text(text = step.detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Text(text = "${step.durationMinutes}m", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          Button(
            onClick = {
              viewModel.buyTicket("$fromText → $toText", option.fareInr)
              onNavigateToTickets()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MetroBlue),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.ConfirmationNumber, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Buy QR Ticket (₹${option.fareInr})")
          }
        }
      }
    }
  }
}
