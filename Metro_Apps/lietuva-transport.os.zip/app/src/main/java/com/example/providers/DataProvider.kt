package com.example.providers

import com.example.domain.*
import com.example.localisation.Language

object DataProvider {

    val cities = listOf(
        CityInfo("Lietuva", "Visa Lietuva", "All Lithuania", "LTG Link & Regional", isRailCenter = true),
        CityInfo("VILNIUS", "Vilnius", "Vilnius", "JUDU", isRailCenter = true),
        CityInfo("KAUNAS", "Kaunas", "Kaunas", "Kauno viešasis transportas", isRailCenter = true),
        CityInfo("KLAIPEDA", "Klaipėda", "Klaipėda", "Klaipėdos keleivinis transportas", isRailCenter = true, hasPort = true),
        CityInfo("SIAULIAI", "Šiauliai", "Šiauliai", "Busturas", isRailCenter = true),
        CityInfo("PANEVEZYS", "Panevėžys", "Panevėžys", "Panevėžio autobusų parkas", isRailCenter = true),
        CityInfo("ALYTUS", "Alytus", "Alytus", "Alytaus transportas"),
        CityInfo("MARIJAMPOLE", "Marijampolė", "Marijampolė", "Marijampolės autobusų parkas"),
        CityInfo("JONAVA", "Jonava", "Jonava", "Jonavos autobusai"),
        CityInfo("UTENA", "Utena", "Utena", "Utenos autobusų parkas"),
        CityInfo("TELSIAI", "Telšiai", "Telšiai", "Telšių autobusų parkas"),
        CityInfo("TAURAGE", "Tauragė", "Tauragė", "Tauragės autobusų parkas")
    )

    // Comprehensive stop dataset
    val stops = listOf(
        // Vilnius Stops
        Stop("VIL_STOTIS", "Vilniaus geležinkelio stotis", "VILNIUS", 54.6714f, 25.2842f, "1", "Šiaurė", isWheelchairAccessible = true),
        Stop("VIL_TILTAS", "Žaliasis tiltas", "VILNIUS", 54.6914f, 25.2798f, "A", "Centras", isWheelchairAccessible = true),
        Stop("VIL_UZUPIS", "Užupis", "VILNIUS", 54.6805f, 25.2970f, "B", "Rytas", isWheelchairAccessible = false),
        Stop("VIL_ORO_UOSTAS", "Vilniaus oro uostas", "VILNIUS", 54.6431f, 25.2795f, "3", "Pietūs", isWheelchairAccessible = true),
        Stop("VIL_ANTAKALNIS", "Antakalnis", "VILNIUS", 54.7183f, 25.3134f, "A", "Šiaurė-Rytai", isWheelchairAccessible = true),
        Stop("VIL_FABIJONISKES", "Fabijoniškės", "VILNIUS", 54.7348f, 25.2505f, "A", "Vakarai", isWheelchairAccessible = true),
        Stop("VIL_SNIPISKES", "Šnipiškės", "VILNIUS", 54.6997f, 25.2751f, "B", "Centras", isWheelchairAccessible = true),
        Stop("VIL_NAMAI", "Namai (Užupio krantinė)", "VILNIUS", 54.6821f, 25.2952f, "Walk", "", isWheelchairAccessible = true),

        // Kaunas Stops
        Stop("KAU_STOTIS", "Kauno geležinkelio stotis", "KAUNAS", 54.8894f, 23.9317f, "1", "Vakarai", isWheelchairAccessible = true),
        Stop("KAU_AUTO_STOTIS", "Kauno autobusų stotis", "KAUNAS", 54.8891f, 23.9281f, "5", "Rytai", isWheelchairAccessible = true),
        Stop("KAU_LAISVE", "Laisvės alėja", "KAUNAS", 54.8972f, 23.9125f, "A", "Centras", isWheelchairAccessible = true),
        Stop("KAU_UNI", "Universitetas (VDU)", "KAUNAS", 54.8990f, 23.9135f, "B", "Šiaurė", isWheelchairAccessible = true),
        Stop("KAU_ORO_UOSTAS", "Kauno oro uostas", "KAUNAS", 54.9632f, 24.0847f, "1", "Vakarai", isWheelchairAccessible = true),

        // Klaipėda Stops
        Stop("KLA_STOTIS", "Klaipėdos geležinkelio stotis", "KLAIPEDA", 55.7212f, 21.1398f, "1", "Šiaurė", isWheelchairAccessible = true),
        Stop("KLA_CENTRAS", "Klaipėdos centras", "KLAIPEDA", 55.7088f, 21.1345f, "A", "Pietūs", isWheelchairAccessible = true),
        Stop("KLA_UOSTAS", "Klaipėdos uostas", "KLAIPEDA", 55.6792f, 21.1340f, "Port", "Smiltynė", isWheelchairAccessible = true),
        Stop("KLA_UNI", "Klaipėdos Universitetas", "KLAIPEDA", 55.7247f, 21.1278f, "B", "Šiaurė", isWheelchairAccessible = true),
        Stop("KLA_PAJURIS", "Pajūris (Melnragė)", "KLAIPEDA", 55.7538f, 21.1022f, "C", "Jūra", isWheelchairAccessible = false),

        // Šiauliai Stops
        Stop("SIA_STOTIS", "Šiaulių geležinkelio stotis", "SIAULIAI", 55.9264f, 23.3155f, "1", "Centras", isWheelchairAccessible = true),
        Stop("SIA_CENTRAS", "Šiaulių centras", "SIAULIAI", 55.9320f, 23.3135f, "A", "Šiaurė", isWheelchairAccessible = true),

        // Panevėžys Stops
        Stop("PAN_STOTIS", "Panevėžio geležinkelio stotis", "PANEVEZYS", 55.7420f, 24.3592f, "1", "Centras", isWheelchairAccessible = true),
        Stop("PAN_CENTRAS", "Panevėžio centras", "PANEVEZYS", 55.7285f, 24.3630f, "A", "Pietūs", isWheelchairAccessible = true),

        // Other cities center stops
        Stop("ALY_CENTRAS", "Alytaus centras", "ALYTUS", 54.3962f, 24.0458f, "A", "Miestas", isWheelchairAccessible = true),
        Stop("MAR_CENTRAS", "Marijampolės centras", "MARIJAMPOLE", 54.5574f, 23.3512f, "A", "Miestas", isWheelchairAccessible = true),
        Stop("JON_CENTRAS", "Jonavos centras", "JONAVA", 55.0718f, 24.2750f, "A", "Miestas", isWheelchairAccessible = true),
        Stop("UTE_CENTRAS", "Utenos centras", "UTENA", 55.4975f, 25.6015f, "A", "Miestas", isWheelchairAccessible = true),
        Stop("TEL_CENTRAS", "Telšių centras", "TELSIAI", 55.9814f, 22.2471f, "A", "Miestas", isWheelchairAccessible = true),
        Stop("TAU_CENTRAS", "Tauragės centras", "TAURAGE", 55.2522f, 22.2897f, "A", "Miestas", isWheelchairAccessible = true)
    )

    // Complete synthetic route details
    val routes = listOf(
        // Vilnius Municipal Routes
        Route("VIL_1G", "VILNIUS", TransportMode.BUS, "1G", "Fabijoniškės – Oro uostas", listOf("VIL_FABIJONISKES", "VIL_SNIPISKES", "VIL_TILTAS", "VIL_STOTIS", "VIL_ORO_UOSTAS")),
        Route("VIL_3G", "VILNIUS", TransportMode.BUS, "3G", "Fabijoniškės – Oro uostas", listOf("VIL_FABIJONISKES", "VIL_TILTAS", "VIL_STOTIS", "VIL_ORO_UOSTAS")),
        Route("VIL_10", "VILNIUS", TransportMode.BUS, "10", "Fabijoniškės – Antakalnis", listOf("VIL_FABIJONISKES", "VIL_SNIPISKES", "VIL_TILTAS", "VIL_UZUPIS", "VIL_ANTAKALNIS")),
        Route("VIL_T2", "VILNIUS", TransportMode.TROLLEYBUS, "2", "Saulėtekis – Stotis", listOf("VIL_ANTAKALNIS", "VIL_TILTAS", "VIL_UZUPIS", "VIL_STOTIS")),

        // Kaunas Municipal Routes
        Route("KAU_29", "KAUNAS", TransportMode.BUS, "29", "Oro uostas – Geležinkelio stotis", listOf("KAU_ORO_UOSTAS", "KAU_UNI", "KAU_LAISVE", "KAU_AUTO_STOTIS", "KAU_STOTIS")),
        Route("KAU_T1", "KAUNAS", TransportMode.TROLLEYBUS, "1", "Laisvės alėja – Geležinkelio stotis", listOf("KAU_LAISVE", "KAU_AUTO_STOTIS", "KAU_STOTIS")),

        // Klaipėda Municipal Routes
        Route("KLA_8", "KLAIPEDA", TransportMode.BUS, "8", "Geležinkelio stotis – Pajūris", listOf("KLA_STOTIS", "KLA_CENTRAS", "KLA_UNI", "KLA_UOSTAS", "KLA_PAJURIS")),

        // Intercity Rail (LTG Link)
        Route("LTG_VIL_KAU", "Lietuva", TransportMode.TRAIN, "LTG1", "Vilnius – Kaunas", listOf("VIL_STOTIS", "KAU_STOTIS")),
        Route("LTG_VIL_KLA", "Lietuva", TransportMode.TRAIN, "LTG2", "Vilnius – Klaipėda", listOf("VIL_STOTIS", "SIA_STOTIS", "KLA_STOTIS")),
        Route("LTG_KAU_KLA", "Lietuva", TransportMode.TRAIN, "LTG3", "Kaunas – Klaipėda", listOf("KAU_STOTIS", "SIA_STOTIS", "KLA_STOTIS")),
        Route("LTG_VIL_SIA", "Lietuva", TransportMode.TRAIN, "LTG4", "Vilnius – Šiauliai", listOf("VIL_STOTIS", "SIA_STOTIS")),
        Route("LTG_VIL_PAN", "Lietuva", TransportMode.TRAIN, "LTG5", "Vilnius – Panevėžys", listOf("VIL_STOTIS", "PAN_STOTIS")),

        // Regional Buses
        Route("REG_VIL_KAU", "Lietuva", TransportMode.REGIONAL_BUS, "R-V-K", "Vilnius – Kaunas Regional", listOf("VIL_STOTIS", "KAU_AUTO_STOTIS")),
        Route("REG_KAU_KLA", "Lietuva", TransportMode.REGIONAL_BUS, "R-K-K", "Kaunas – Klaipėda Regional", listOf("KAU_AUTO_STOTIS", "KLA_STOTIS"))
    )

    // Vilnius JUDU Fares
    val fareProducts = listOf(
        FareProduct("VIL_30", "30 min. bilietas", "30 min. Ticket", 0.65, 30, "VILNIUS", "JUDU"),
        FareProduct("VIL_60", "60 min. bilietas", "60 min. Ticket", 0.90, 60, "VILNIUS", "JUDU"),
        FareProduct("VIL_24H", "24 val. bilietas", "24 Hour Ticket", 2.30, 1440, "VILNIUS", "JUDU"),
        FareProduct("VIL_72H", "3 parų bilietas", "3 Day Ticket", 5.60, 4320, "VILNIUS", "JUDU"),
        FareProduct("VIL_30D", "30 dienų bilietas", "30 Day Ticket", 29.00, 43200, "VILNIUS", "JUDU"),

        // Kaunas Fares
        FareProduct("KAU_SINGLE", "Vienkartinis bilietas", "Single Ticket", 1.00, 60, "KAUNAS", "Kauno viešasis transportas"),
        FareProduct("KAU_24H", "24 val. bilietas", "24 Hour Ticket", 2.00, 1440, "KAUNAS", "Kauno viešasis transportas"),

        // Klaipėda Fares
        FareProduct("KLA_SINGLE", "Miesto autobuso bilietas", "City Bus Ticket", 0.80, 60, "KLAIPEDA", "KKT"),

        // LTG Link Fares
        FareProduct("LTG_VIL_KAU_FARE", "LTG Vilnius – Kaunas", "LTG Vilnius – Kaunas", 7.50, 0, "Lietuva", "LTG Link"),
        FareProduct("LTG_VIL_KLA_FARE", "LTG Vilnius – Klaipėda", "LTG Vilnius – Klaipėda", 18.50, 0, "Lietuva", "LTG Link")
    )

    // Disruptions database
    val baseDisruptions = listOf(
        Disruption("D1", "VILNIUS", "1G", DisruptionType.DELAY, "Užfiksuotas vėlavimas iki 8 min. dėl spūsčių Kalvarijų g.", "Delay up to 8 min due to heavy traffic on Kalvarijų str.", 8, "10:42"),
        Disruption("D2", "KAUNAS", "29", DisruptionType.STOP_CLOSED, "Universiteto stotelė laikinai uždaryta dėl kelio darbų. Naudokitės Laisvės al. stotele.", "University stop is closed temporarily due to road works. Please use Laisvės al. stop.", 0, "09:15"),
        Disruption("D3", "VILNIUS", "10", DisruptionType.ROUTE_CHANGE, "Maršruto pakeitimas: važiuoja per Šnipiškes, aplenkiant Užupį.", "Route change: operates via Šnipiškės, bypassing Užupis.", 4, "11:20")
    )

    // Favourites locations
    val defaultFavourites = listOf(
        FavouritePlace("Namai", "Home", "VIL_NAMAI", "VILNIUS"),
        FavouritePlace("Darbas", "Work", "VIL_TILTAS", "VILNIUS"),
        FavouritePlace("Universitetas", "University", "KAU_UNI", "KAUNAS"),
        FavouritePlace("Vilniaus stotis", "Vilnius station", "VIL_STOTIS", "VILNIUS"),
        FavouritePlace("Kauno stotis", "Kaunas station", "KAU_STOTIS", "KAUNAS")
    )
}

data class FavouritePlace(
    val titleLt: String,
    val titleEn: String,
    val stopId: String,
    val cityKey: String
) {
    fun getTitle(lang: Language): String = if (lang == Language.LT) titleLt else titleEn
}
