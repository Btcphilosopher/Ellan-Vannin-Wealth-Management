package com.example.simulation

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.domain.*
import com.example.providers.DataProvider
import com.example.storage.AppStorage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

object SimulationManager {

    // Dynamic disruption lists (users can toggle or inject them)
    private val _disruptions = MutableStateFlow<List<Disruption>>(DataProvider.baseDisruptions)
    val disruptions: StateFlow<List<Disruption>> = _disruptions.asStateFlow()

    // Live vehicles simulation
    private val _vehicles = MutableStateFlow<List<Vehicle>>(emptyList())
    val vehicles: StateFlow<List<Vehicle>> = _vehicles.asStateFlow()

    // Track active journey simulation
    var activeJourneySim: Journey? by mutableStateOf(null)
    var activeLegIndex by mutableStateOf(0)
    var isJourneyActive by mutableStateOf(false)
    var isArrived by mutableStateOf(false)
    var elapsedMinutesInLeg by mutableStateOf(0)

    // Contactless payments state
    var contactlessStatusMessage by mutableStateOf<String?>(null)

    // Vilnius Disruption simulation toggle
    var vilnius1GDelayed by mutableStateOf(false)
    // Kaunas stop closed toggle
    var kaunasStopClosed by mutableStateOf(false)

    init {
        initializeVehicles()
    }

    fun initializeVehicles() {
        // Create live moving vehicles for Vilnius 1G, Kaunas 29, Klaipėda 8
        val baseVehicles = listOf(
            Vehicle(
                id = "V-1G-102",
                routeId = "VIL_1G",
                routeNumber = "1G",
                directionTo = "Fabijoniškės",
                currentStopId = "VIL_STOTIS",
                nextStopId = "VIL_TILTAS",
                progress = 0.4f,
                lat = 54.6814f,
                lon = 25.2820f,
                delayMin = if (vilnius1GDelayed) 8 else 0,
                mode = TransportMode.BUS
            ),
            Vehicle(
                id = "V-29-204",
                routeId = "KAU_29",
                routeNumber = "29",
                directionTo = "Kauno oro uostas",
                currentStopId = "KAU_STOTIS",
                nextStopId = "KAU_AUTO_STOTIS",
                progress = 0.7f,
                lat = 54.8892f,
                lon = 23.9300f,
                delayMin = 0,
                mode = TransportMode.BUS
            ),
            Vehicle(
                id = "V-8-301",
                routeId = "KLA_8",
                routeNumber = "8",
                directionTo = "Pajūris (Melnragė)",
                currentStopId = "KLA_CENTRAS",
                nextStopId = "KLA_UNI",
                progress = 0.2f,
                lat = 55.7140f,
                lon = 21.1320f,
                delayMin = 2,
                mode = TransportMode.BUS
            )
        )
        _vehicles.value = baseVehicles
    }

    // Toggle Vilnius 1G delay simulation
    fun toggleVilniusDisruption(delayed: Boolean) {
        vilnius1GDelayed = delayed
        val current = _disruptions.value.toMutableList()
        current.removeAll { it.id == "VIL_D_1G" }
        if (delayed) {
            current.add(
                Disruption(
                    id = "VIL_D_1G",
                    cityKey = "VILNIUS",
                    routeNumber = "1G",
                    type = DisruptionType.DELAY,
                    messageLt = "UŽFIKSUOTAS SUTRIKIMAS: Vilnius, 1G vėlavimas iki 8 min. dėl avarijos Konstitucijos pr.",
                    messageEn = "DISRUPTION DETECTED: Vilnius, 1G delay up to 8 min due to accident on Konstitucijos ave.",
                    delayMin = 8,
                    updatedTime = "10:42"
                )
            )
        }
        _disruptions.value = current
        initializeVehicles() // update delay min in vehicle
    }

    // Toggle Kaunas Stop Closed
    fun toggleKaunasDisruption(closed: Boolean) {
        kaunasStopClosed = closed
        val current = _disruptions.value.toMutableList()
        current.removeAll { it.id == "KAU_D_CLOSED" }
        if (closed) {
            current.add(
                Disruption(
                    id = "KAU_D_CLOSED",
                    cityKey = "KAUNAS",
                    routeNumber = "29",
                    type = DisruptionType.STOP_CLOSED,
                    messageLt = "UŽFIKSUOTAS SUTRIKIMAS: Kaunas, Universiteto (VDU) stotelė uždaryta.",
                    messageEn = "DISRUPTION DETECTED: Kaunas, University (VDU) stop is closed.",
                    delayMin = 0,
                    updatedTime = "11:05"
                )
            )
        }
        _disruptions.value = current
    }

    fun startJourneySimulation(journey: Journey) {
        activeJourneySim = journey
        activeLegIndex = 0
        isJourneyActive = true
        isArrived = false
        elapsedMinutesInLeg = 0
    }

    fun advanceJourneyLeg() {
        val journey = activeJourneySim ?: return
        if (activeLegIndex < journey.legs.size - 1) {
            activeLegIndex++
            elapsedMinutesInLeg = 0
        } else {
            isArrived = true
            isJourneyActive = false
        }
    }

    fun cancelJourney() {
        activeJourneySim = null
        isJourneyActive = false
        isArrived = false
        activeLegIndex = 0
        elapsedMinutesInLeg = 0
    }

    fun simulateContactlessPayment(type: String): Boolean {
        contactlessStatusMessage = "Nuskaitoma kortelė..."
        // simulate standard tap-to-ride payment
        val success = true
        if (success) {
            contactlessStatusMessage = "MOKĖJIMAS SĖKMINGAS (Demo: $type)"
            // Buy Vilnius 60 min ticket automatically as demonstration
            val product60 = DataProvider.fareProducts.first { it.id == "VIL_60" }
            val t = AppStorage.buyTicket(product60)
            AppStorage.activateTicket(t.id)
        } else {
            contactlessStatusMessage = "KLAIDA: Bandykite dar kartą"
        }
        return success
    }

    fun clearContactlessMessage() {
        contactlessStatusMessage = null
    }

    // Tick the simulation (move vehicles, increase delays, or progress countdowns)
    fun tickSimulation() {
        val currentVehicles = _vehicles.value.map { v ->
            var nextProgress = v.progress + 0.15f
            var currentStop = v.currentStopId
            var nextStop = v.nextStopId
            if (nextProgress >= 1.0f) {
                nextProgress = 0.0f
                // Swap stops or choose next stop along route
                val route = DataProvider.routes.firstOrNull { it.id == v.routeId }
                if (route != null) {
                    val currentIndex = route.stops.indexOf(currentStop)
                    val nextIndex = (currentIndex + 1) % route.stops.size
                    val afterNextIndex = (nextIndex + 1) % route.stops.size
                    currentStop = route.stops[nextIndex]
                    nextStop = route.stops[afterNextIndex]
                }
            }

            // Interpolate GPS coordinates roughly
            val stopA = DataProvider.stops.firstOrNull { it.id == currentStop }
            val stopB = DataProvider.stops.firstOrNull { it.id == nextStop }
            val currentLat = if (stopA != null && stopB != null) stopA.lat + (stopB.lat - stopA.lat) * nextProgress else v.lat
            val currentLon = if (stopA != null && stopB != null) stopA.lon + (stopB.lon - stopA.lon) * nextProgress else v.lon

            v.copy(
                progress = nextProgress,
                currentStopId = currentStop,
                nextStopId = nextStop,
                lat = currentLat,
                lon = currentLon
            )
        }
        _vehicles.value = currentVehicles
    }
}
