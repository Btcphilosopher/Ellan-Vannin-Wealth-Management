package com.example.routing

import com.example.domain.*
import com.example.providers.DataProvider
import java.util.UUID

object RoutingEngine {

    fun planJourney(
        fromQuery: String,
        toQuery: String,
        cityFilter: String, // "Lietuva" (Visa Lietuva) or "VILNIUS", etc.
        isAccessible: Boolean = false,
        hasDisruptionDelay: Boolean = false,
        disruptionDelayMin: Int = 0
    ): List<Journey> {
        val fromNormalized = fromQuery.trim().lowercase()
        val toNormalized = toQuery.trim().lowercase()

        if (fromNormalized.isEmpty() || toNormalized.isEmpty()) {
            return emptyList()
        }

        // Detect if it is an intercity journey (across different cities or national context)
        val isIntercity = cityFilter == "Lietuva" || 
                (fromNormalized.contains("vilnius") && toNormalized.contains("kaun")) ||
                (fromNormalized.contains("vilnius") && toNormalized.contains("klaip")) ||
                (fromNormalized.contains("kaun") && toNormalized.contains("klaip")) ||
                (fromNormalized.contains("klaip") && toNormalized.contains("viln"))

        return if (isIntercity) {
            generateIntercityJourneys(fromQuery, toQuery, isAccessible, hasDisruptionDelay, disruptionDelayMin)
        } else {
            generateLocalJourneys(fromQuery, toQuery, cityFilter, isAccessible, hasDisruptionDelay, disruptionDelayMin)
        }
    }

    private fun generateLocalJourneys(
        from: String,
        to: String,
        city: String,
        isAccessible: Boolean,
        hasDisruptionDelay: Boolean,
        disruptionDelayMin: Int
    ): List<Journey> {
        val currentCity = if (city == "Lietuva") "VILNIUS" else city

        // Determine stops in this city
        val cityStops = DataProvider.stops.filter { it.cityKey == currentCity }
        val stopFrom = cityStops.firstOrNull { it.name.lowercase().contains(from.lowercase()) } ?: cityStops.first()
        val stopTo = cityStops.firstOrNull { it.name.lowercase().contains(to.lowercase()) } ?: cityStops.last()

        if (stopFrom.id == stopTo.id) {
            return emptyList()
        }

        // Accessibility checks: if accessible, filter out stops with stairs (like Užupis) or modes
        val accessibleMultiplier = if (isAccessible) 1.2 else 1.0
        val baseDelay = if (hasDisruptionDelay) disruptionDelayMin else 0

        // Create Alternative 1: Greičiausia (Fastest)
        val alt1Legs = mutableListOf<JourneyLeg>()
        var currentMin = 0
        
        // Let's add walking/cycling leg to solve journey if needed
        if (from.lowercase().contains("namai")) {
            alt1Legs.add(
                JourneyLeg(
                    mode = TransportMode.WALKING,
                    operator = "Pėsčiomis",
                    routeNumber = "",
                    departureTime = "09:00",
                    arrivalTime = "09:06",
                    platform = "-",
                    fromStopName = "Namai (Užupio krantinė)",
                    toStopName = "Užupis",
                    durationMin = 6,
                    distanceKm = 0.4f,
                    isWheelchairAccessible = true
                )
            )
            currentMin += 6
        }

        // Main transport leg
        val mainDuration = (12 * accessibleMultiplier).toInt() + baseDelay
        alt1Legs.add(
            JourneyLeg(
                mode = TransportMode.BUS,
                operator = "JUDU",
                routeNumber = "1G",
                departureTime = "09:${String.format("%02d", currentMin)}",
                arrivalTime = "09:${String.format("%02d", currentMin + mainDuration)}",
                platform = "A",
                fromStopName = stopFrom.name,
                toStopName = stopTo.name,
                durationMin = mainDuration,
                distanceKm = 4.2f,
                isWheelchairAccessible = true
            )
        )
        currentMin += mainDuration

        val alt1 = Journey(
            id = "LOCAL_1_" + UUID.randomUUID().toString().take(6),
            from = stopFrom.name,
            to = stopTo.name,
            startHour = "09:00",
            endHour = "09:${String.format("%02d", currentMin)}",
            durationMin = currentMin,
            priceEur = 0.90,
            legs = alt1Legs,
            categoryLt = "Greičiausia",
            categoryEn = "Fastest"
        )

        // Create Alternative 2: Mažiausiai persėdimų (Direct or Less steps)
        val alt2Legs = listOf(
            JourneyLeg(
                mode = if (isAccessible) TransportMode.BUS else TransportMode.TROLLEYBUS,
                operator = "JUDU",
                routeNumber = if (isAccessible) "3G" else "2",
                departureTime = "09:05",
                arrivalTime = "09:22",
                platform = "B",
                fromStopName = stopFrom.name,
                toStopName = stopTo.name,
                durationMin = 17 + baseDelay,
                distanceKm = 4.8f,
                isWheelchairAccessible = !isAccessible || true
            )
        )

        val alt2 = Journey(
            id = "LOCAL_2_" + UUID.randomUUID().toString().take(6),
            from = stopFrom.name,
            to = stopTo.name,
            startHour = "09:05",
            endHour = "09:${22 + baseDelay}",
            durationMin = 17 + baseDelay,
            priceEur = 0.65,
            legs = alt2Legs,
            categoryLt = "Mažiausiai persėdimų",
            categoryEn = "Least transfers"
        )

        // Create Alternative 3: Mažiausiai vaikščiojimo / Dviratis + Transport (Cycling mode integrated for solving journeys)
        val alt3Legs = listOf(
            JourneyLeg(
                mode = TransportMode.CYCLING,
                operator = "Cyclocity",
                routeNumber = "Bike",
                departureTime = "09:00",
                arrivalTime = "09:08",
                platform = "-",
                fromStopName = stopFrom.name,
                toStopName = "Žaliasis tiltas",
                durationMin = 8,
                distanceKm = 1.8f,
                isWheelchairAccessible = false
            ),
            JourneyLeg(
                mode = TransportMode.BUS,
                operator = "JUDU",
                routeNumber = "10",
                departureTime = "09:12",
                arrivalTime = "09:23",
                platform = "A",
                fromStopName = "Žaliasis tiltas",
                toStopName = stopTo.name,
                durationMin = 11 + baseDelay,
                distanceKm = 2.4f,
                isWheelchairAccessible = true
            )
        )

        val alt3 = Journey(
            id = "LOCAL_3_" + UUID.randomUUID().toString().take(6),
            from = stopFrom.name,
            to = stopTo.name,
            startHour = "09:00",
            endHour = "09:${23 + baseDelay}",
            durationMin = 23 + baseDelay,
            priceEur = 1.55,
            legs = alt3Legs,
            categoryLt = "Mažiausiai vaikščiojimo",
            categoryEn = "Least walking"
        )

        return if (isAccessible) {
            // Filter out non-accessible alternatives
            listOf(alt1, alt2)
        } else {
            listOf(alt1, alt2, alt3)
        }
    }

    private fun generateIntercityJourneys(
        from: String,
        to: String,
        isAccessible: Boolean,
        hasDisruptionDelay: Boolean,
        disruptionDelayMin: Int
    ): List<Journey> {
        val baseDelay = if (hasDisruptionDelay) disruptionDelayMin else 0
        val isVilniusToKlaipeda = from.lowercase().contains("viln") && to.lowercase().contains("klaip")
        val isVilniusToKaunas = from.lowercase().contains("viln") && to.lowercase().contains("kaun")

        if (isVilniusToKaunas) {
            // Alternative 1: LTG Link Direct Train
            val alt1 = Journey(
                id = "INTER_1_" + UUID.randomUUID().toString().take(6),
                from = "Vilnius",
                to = "Kaunas",
                startHour = "09:20",
                endHour = "10:20",
                durationMin = 60 + baseDelay,
                priceEur = 7.50,
                legs = listOf(
                    JourneyLeg(
                        mode = TransportMode.TRAIN,
                        operator = "LTG Link",
                        routeNumber = "LTG1",
                        departureTime = "09:20",
                        arrivalTime = "10:20",
                        platform = "2",
                        fromStopName = "Vilniaus geležinkelio stotis",
                        toStopName = "Kauno geležinkelio stotis",
                        durationMin = 60 + baseDelay,
                        distanceKm = 104.0f,
                        isWheelchairAccessible = true
                    )
                ),
                categoryLt = "Greičiausia",
                categoryEn = "Fastest"
            )

            // Alternative 2: Complex multi-modal (the exact requested example)
            val alt2 = Journey(
                id = "INTER_2_" + UUID.randomUUID().toString().take(6),
                from = "Vilnius Namai",
                to = "Kauno Universitetas",
                startHour = "08:45",
                endHour = "10:55",
                durationMin = 130 + baseDelay,
                priceEur = 9.40,
                legs = listOf(
                    JourneyLeg(
                        mode = TransportMode.WALKING,
                        operator = "Pėsčiomis",
                        routeNumber = "",
                        departureTime = "08:45",
                        arrivalTime = "08:51",
                        platform = "-",
                        fromStopName = "Namai",
                        toStopName = "Užupis",
                        durationMin = 6,
                        distanceKm = 0.4f,
                        isWheelchairAccessible = true
                    ),
                    JourneyLeg(
                        mode = TransportMode.BUS,
                        operator = "JUDU",
                        routeNumber = "10",
                        departureTime = "08:53",
                        arrivalTime = "09:08",
                        platform = "B",
                        fromStopName = "Užupis",
                        toStopName = "Vilniaus stotis",
                        durationMin = 15,
                        distanceKm = 2.5f,
                        isWheelchairAccessible = true
                    ),
                    JourneyLeg(
                        mode = TransportMode.TRAIN,
                        operator = "LTG Link",
                        routeNumber = "LTG1",
                        departureTime = "09:20",
                        arrivalTime = "10:20",
                        platform = "2",
                        fromStopName = "Vilniaus geležinkelio stotis",
                        toStopName = "Kauno geležinkelio stotis",
                        durationMin = 60 + baseDelay,
                        distanceKm = 104.0f,
                        isWheelchairAccessible = true
                    ),
                    JourneyLeg(
                        mode = TransportMode.WALKING,
                        operator = "Pėsčiomis",
                        routeNumber = "",
                        departureTime = "10:22",
                        arrivalTime = "10:27",
                        platform = "-",
                        fromStopName = "Kauno geležinkelio stotis",
                        toStopName = "Kauno autobusų stotis",
                        durationMin = 5,
                        distanceKm = 0.3f,
                        isWheelchairAccessible = true
                    ),
                    JourneyLeg(
                        mode = TransportMode.BUS,
                        operator = "Kauno viešasis transportas",
                        routeNumber = "29",
                        departureTime = "10:35",
                        arrivalTime = "10:55",
                        platform = "1",
                        fromStopName = "Kauno autobusų stotis",
                        toStopName = "Universitetas (VDU)",
                        durationMin = 20,
                        distanceKm = 3.5f,
                        isWheelchairAccessible = true
                    )
                ),
                categoryLt = "Mažiausiai vaikščiojimo",
                categoryEn = "Least walking"
            )

            // Alternative 3: Regional Bus
            val alt3 = Journey(
                id = "INTER_3_" + UUID.randomUUID().toString().take(6),
                from = "Vilnius",
                to = "Kaunas",
                startHour = "09:10",
                endHour = "10:45",
                durationMin = 95 + baseDelay,
                priceEur = 8.20,
                legs = listOf(
                    JourneyLeg(
                        mode = TransportMode.REGIONAL_BUS,
                        operator = "Kautra",
                        routeNumber = "R-V-K",
                        departureTime = "09:10",
                        arrivalTime = "10:45",
                        platform = "12",
                        fromStopName = "Vilniaus autobusų stotis",
                        toStopName = "Kauno autobusų stotis",
                        durationMin = 95 + baseDelay,
                        distanceKm = 101.5f,
                        isWheelchairAccessible = true
                    )
                ),
                categoryLt = "Mažiausiai persėdimų",
                categoryEn = "Least transfers"
            )

            return if (isAccessible) listOf(alt1, alt2) else listOf(alt1, alt2, alt3)
        }

        // Default: Vilnius to Klaipėda (as requested in slice 3)
        val alt1 = Journey(
            id = "INTER_KLA_1_" + UUID.randomUUID().toString().take(6),
            from = "Vilnius",
            to = "Klaipėda",
            startHour = "09:20",
            endHour = "13:08",
            durationMin = 228 + baseDelay,
            priceEur = 18.50,
            legs = listOf(
                JourneyLeg(
                    mode = TransportMode.TRAIN,
                    operator = "LTG Link",
                    routeNumber = "LTG2",
                    departureTime = "09:20",
                    arrivalTime = "13:08",
                    platform = "1",
                    fromStopName = "Vilniaus geležinkelio stotis",
                    toStopName = "Klaipėdos geležinkelio stotis",
                    durationMin = 228 + baseDelay,
                    distanceKm = 310.0f,
                    isWheelchairAccessible = true
                )
            ),
            categoryLt = "Greičiausia",
            categoryEn = "Fastest"
        )

        val alt2 = Journey(
            id = "INTER_KLA_2_" + UUID.randomUUID().toString().take(6),
            from = "Vilnius",
            to = "Klaipėda",
            startHour = "08:40",
            endHour = "12:52",
            durationMin = 252 + baseDelay,
            priceEur = 16.80,
            legs = listOf(
                JourneyLeg(
                    mode = TransportMode.REGIONAL_BUS,
                    operator = "Toks",
                    routeNumber = "Bus-V-K",
                    departureTime = "08:40",
                    arrivalTime = "10:15",
                    platform = "14",
                    fromStopName = "Vilnius",
                    toStopName = "Kaunas",
                    durationMin = 95,
                    distanceKm = 101.0f,
                    isWheelchairAccessible = true
                ),
                JourneyLeg(
                    mode = TransportMode.TRAIN,
                    operator = "LTG Link",
                    routeNumber = "LTG3",
                    departureTime = "10:30",
                    arrivalTime = "12:52",
                    platform = "2",
                    fromStopName = "Kauno geležinkelio stotis",
                    toStopName = "Klaipėda",
                    durationMin = 142 + baseDelay,
                    distanceKm = 210.0f,
                    isWheelchairAccessible = true
                )
            ),
            categoryLt = "1 persėdimas",
            categoryEn = "1 transfer"
        )

        val alt3 = Journey(
            id = "INTER_KLA_3_" + UUID.randomUUID().toString().take(6),
            from = "Vilnius",
            to = "Klaipėda",
            startHour = "08:00",
            endHour = "12:30",
            durationMin = 270,
            priceEur = 15.00,
            legs = listOf(
                JourneyLeg(
                    mode = TransportMode.REGIONAL_BUS,
                    operator = "Kautra",
                    routeNumber = "Bus-Direct",
                    departureTime = "08:00",
                    arrivalTime = "12:30",
                    platform = "10",
                    fromStopName = "Vilniaus autobusų stotis",
                    toStopName = "Klaipėdos autobusų stotis",
                    durationMin = 270,
                    distanceKm = 312.0f,
                    isWheelchairAccessible = true
                )
            ),
            categoryLt = "Mažiausiai vaikščiojimo",
            categoryEn = "Least walking"
        )

        return if (isAccessible) listOf(alt1) else listOf(alt1, alt2, alt3)
    }
}
