package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Baltic / Northern European palette
val BalticDaylight = Color(0xFFF2F5F7)
val BalticDaylightDarker = Color(0xFFE6ECEF)
val DarkGraphite = Color(0xFF1E2122)
val RestrainedRed = Color(0xFFB22E2E)
val MutedBlue = Color(0xFF4C6A80)
val SoftBorder = Color(0xFFD4DFE2)

// Material definitions mapped
val PrimaryBaltic = DarkGraphite
val SecondaryBaltic = MutedBlue
val TertiaryBaltic = RestrainedRed
val BackgroundBaltic = BalticDaylight
val SurfaceBaltic = Color.White
