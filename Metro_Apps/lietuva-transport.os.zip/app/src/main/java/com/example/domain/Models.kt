package com.example.domain

import com.example.localisation.Language
import com.example.localisation.Localisation

enum class TransportMode {
    TRAIN, BUS, TROLLEYBUS, REGIONAL_BUS, WALKING, CYCLING
}

enum class DisruptionType {
    DELAY, GENERAL_DISRUPTION, ROUTE_CHANGE, STOP_CLOSED, REPAIR_WORKS
}

data class CityInfo(
    val key: String,
    val nameLt: String,
    val nameEn: String,
    val operatorName: String,
    val isRailCenter: Boolean = false,
    val hasPort: Boolean = false
) {
    fun getName(lang: Language): String = if (lang == Language.LT) nameLt else nameEn
}

data class Stop(
    val id: String,
    val name: String,
    val cityKey: String,
    val lat: Float,
    val lon: Float,
    val platform: String = "A",
    val direction: String = "",
    val hasStairs: Boolean = false,
    val hasElevator: Boolean = true,
    val isWheelchairAccessible: Boolean = true
)

data class Route(
    val id: String,
    val cityKey: String,
    val mode: TransportMode,
    val number: String,
    val name: String,
    val stops: List<String> // list of stop IDs
)

data class Vehicle(
    val id: String,
    val routeId: String,
    val routeNumber: String,
    val directionTo: String,
    val currentStopId: String,
    val nextStopId: String,
    val progress: Float, // 0.0 to 1.0 between current and next stop
    val lat: Float,
    val lon: Float,
    val delayMin: Int,
    val mode: TransportMode
)

data class Disruption(
    val id: String,
    val cityKey: String,
    val routeNumber: String,
    val type: DisruptionType,
    val messageLt: String,
    val messageEn: String,
    val delayMin: Int,
    val updatedTime: String
) {
    fun getMessage(lang: Language): String = if (lang == Language.LT) messageLt else messageEn
}

data class FareProduct(
    val id: String,
    val nameLt: String,
    val nameEn: String,
    val price: Double,
    val validityMinutes: Int,
    val cityKey: String,
    val operator: String
) {
    fun getName(lang: Language): String = if (lang == Language.LT) nameLt else nameEn
}

data class Ticket(
    val id: String,
    val fareProduct: FareProduct,
    val isActivated: Boolean = false,
    val activationTime: Long = 0L,
    val expiryTime: Long = 0L
)

data class JourneyLeg(
    val mode: TransportMode,
    val operator: String,
    val routeNumber: String,
    val departureTime: String,
    val arrivalTime: String,
    val platform: String,
    val fromStopName: String,
    val toStopName: String,
    val durationMin: Int,
    val distanceKm: Float,
    val isWheelchairAccessible: Boolean = true
)

data class Journey(
    val id: String,
    val from: String,
    val to: String,
    val startHour: String,
    val endHour: String,
    val durationMin: Int,
    val priceEur: Double,
    val legs: List<JourneyLeg>,
    val categoryLt: String,
    val categoryEn: String
) {
    fun getCategory(lang: Language): String = if (lang == Language.LT) categoryLt else categoryEn
}
