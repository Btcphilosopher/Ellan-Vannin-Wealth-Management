package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.*
import com.example.localisation.Language
import com.example.localisation.Localisation
import com.example.providers.DataProvider
import com.example.providers.FavouritePlace
import com.example.routing.RoutingEngine
import com.example.simulation.SimulationManager
import com.example.storage.AppStorage
import com.example.ui.components.MapCanvas
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen() {
    val coroutineScope = rememberCoroutineScope()

    // Central App States
    var selectedLanguage by remember { mutableStateOf(AppStorage.currentLanguage) }
    var selectedCityKey by remember { mutableStateOf(AppStorage.currentCity) }
    var isOffline by remember { mutableStateOf(AppStorage.isOffline) }

    // Navigation Tab
    var activeTab by remember { mutableStateOf("PLANNER") } // PLANNER, MAP, DEPARTURES, TICKETS, DISRUPTIONS

    // Planner fields
    var fromText by remember { mutableStateOf("") }
    var toText by remember { mutableStateOf("") }
    var searchPerformed by remember { mutableStateOf(false) }
    var searchResults by remember { mutableStateOf<List<Journey>>(emptyList()) }

    // Routing preference states
    var prefFastest by remember { mutableStateOf(true) }
    var prefLeastTransfers by remember { mutableStateOf(false) }
    var prefLeastWalking by remember { mutableStateOf(false) }
    var prefCarFree by remember { mutableStateOf(true) }
    var prefAccessible by remember { mutableStateOf(false) }

    // Selected stop / vehicle details overlay (Map screen)
    var selectedStop by remember { mutableStateOf<Stop?>(null) }
    var selectedVehicle by remember { mutableStateOf<Vehicle?>(null) }

    // Interactive Ticketing states
    val ticketsList = remember { mutableStateListOf<Ticket>().apply { addAll(AppStorage.purchasedTickets) } }
    var showPaymentDialog by remember { mutableStateOf<FareProduct?>(null) }
    var showActiveTicketDialog by remember { mutableStateOf<Ticket?>(null) }

    // Airport & Tourist filter overlays
    var isAirportMode by remember { mutableStateOf(false) }
    var isTouristMode by remember { mutableStateOf(false) }

    // Disruptions
    val liveDisruptions by SimulationManager.disruptions.collectAsState()
    var selectedDisruptionCityFilter by remember { mutableStateOf("Lietuva") }

    // Simulation Ticker
    LaunchedEffect(Unit) {
        while (true) {
            delay(4000) // tick coordinates and countdown simulation
            SimulationManager.tickSimulation()
        }
    }

    // Dynamic Route Recalculator when disruptions are toggled
    LaunchedEffect(SimulationManager.vilnius1GDelayed, SimulationManager.kaunasStopClosed, prefAccessible) {
        if (searchPerformed && fromText.isNotEmpty() && toText.isNotEmpty()) {
            searchResults = RoutingEngine.planJourney(
                fromQuery = fromText,
                toQuery = toText,
                cityFilter = selectedCityKey,
                isAccessible = prefAccessible,
                hasDisruptionDelay = SimulationManager.vilnius1GDelayed,
                disruptionDelayMin = if (SimulationManager.vilnius1GDelayed) 8 else 0
            )
        }
    }

    // Text Helper
    fun txt(key: String): String = Localisation.getString(key, selectedLanguage)

    Scaffold(
        topBar = {
            Column {
                // Offline Notice Banner
                AnimatedVisibility(visible = isOffline) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFB22E2E))
                            .padding(vertical = 6.dp, horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Filled.CloudOff, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${txt("offline")} — ${txt("offline_desc")}",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // National Baltic Header Area
                Surface(
                    color = Color(0xFF1E2122), // Dark graphite
                    contentColor = Color.White
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Logo / Title
                        Column {
                            Text(
                                text = "LIETUVA",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 3.sp,
                                    fontSize = 13.sp,
                                    color = Color(0xFFF2F5F7)
                                )
                            )
                            Text(
                                text = "TRANSPORT.OS",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    fontSize = 20.sp,
                                    color = Color.White
                                )
                            )
                        }

                        // Language & City Actions
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Language selector Button
                            Button(
                                onClick = {
                                    selectedLanguage = if (selectedLanguage == Language.LT) Language.EN else Language.LT
                                    AppStorage.currentLanguage = selectedLanguage
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2F30)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text(
                                    text = if (selectedLanguage == Language.LT) "EN" else "LT",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            // City Switcher dropdown selection
                            var cityMenuExpanded by remember { mutableStateOf(false) }
                            Box {
                                Button(
                                    onClick = { cityMenuExpanded = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2F30)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text(
                                        text = if (selectedCityKey == "Lietuva") txt("all_lithuania") else selectedCityKey,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Icon(
                                        Icons.Filled.ArrowDropDown,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = Color.White
                                    )
                                }
                                DropdownMenu(
                                    expanded = cityMenuExpanded,
                                    onDismissRequest = { cityMenuExpanded = false },
                                    modifier = Modifier.background(Color.White)
                                ) {
                                    DataProvider.cities.forEach { city ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = city.getName(selectedLanguage),
                                                    color = Color(0xFF1E2122),
                                                    fontWeight = FontWeight.Bold
                                                )
                                            },
                                            onClick = {
                                                selectedCityKey = city.key
                                                AppStorage.currentCity = selectedCityKey
                                                cityMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            // Adaptive M3 bottom navigation respects navigation bar system safe areas automatically
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = activeTab == "PLANNER",
                    onClick = { activeTab = "PLANNER" },
                    icon = { Icon(Icons.Filled.DirectionsTransit, contentDescription = null) },
                    label = { Text(txt("journey"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF1E2122),
                        indicatorColor = Color(0xFF1E2122),
                        unselectedIconColor = Color(0xFF5E6D75),
                        unselectedTextColor = Color(0xFF5E6D75)
                    )
                )
                NavigationBarItem(
                    selected = activeTab == "MAP",
                    onClick = { activeTab = "MAP" },
                    icon = { Icon(Icons.Filled.Map, contentDescription = null) },
                    label = { Text("Atlasas", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF1E2122),
                        indicatorColor = Color(0xFF1E2122),
                        unselectedIconColor = Color(0xFF5E6D75),
                        unselectedTextColor = Color(0xFF5E6D75)
                    )
                )
                NavigationBarItem(
                    selected = activeTab == "DEPARTURES",
                    onClick = { activeTab = "DEPARTURES" },
                    icon = { Icon(Icons.Filled.Schedule, contentDescription = null) },
                    label = { Text(txt("timetable"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF1E2122),
                        indicatorColor = Color(0xFF1E2122),
                        unselectedIconColor = Color(0xFF5E6D75),
                        unselectedTextColor = Color(0xFF5E6D75)
                    )
                )
                NavigationBarItem(
                    selected = activeTab == "TICKETS",
                    onClick = { activeTab = "TICKETS" },
                    icon = { Icon(Icons.Filled.ConfirmationNumber, contentDescription = null) },
                    label = { Text(txt("tickets"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF1E2122),
                        indicatorColor = Color(0xFF1E2122),
                        unselectedIconColor = Color(0xFF5E6D75),
                        unselectedTextColor = Color(0xFF5E6D75)
                    )
                )
                NavigationBarItem(
                    selected = activeTab == "DISRUPTIONS",
                    onClick = { activeTab = "DISRUPTIONS" },
                    icon = { Icon(Icons.Filled.Warning, contentDescription = null) },
                    label = { Text(txt("disruptions"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = Color(0xFF1E2122),
                        indicatorColor = Color(0xFF1E2122),
                        unselectedIconColor = Color(0xFF5E6D75),
                        unselectedTextColor = Color(0xFF5E6D75)
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF2F5F7)) // Pale Baltic daylight
        ) {
            // Main body content
            when (activeTab) {
                "PLANNER" -> PlannerTab(
                    selectedLanguage = selectedLanguage,
                    selectedCityKey = selectedCityKey,
                    fromText = fromText,
                    toText = toText,
                    onFromTextChange = { fromText = it },
                    onToTextChange = { toText = it },
                    searchPerformed = searchPerformed,
                    searchResults = searchResults,
                    prefFastest = prefFastest,
                    prefLeastTransfers = prefLeastTransfers,
                    prefLeastWalking = prefLeastWalking,
                    prefCarFree = prefCarFree,
                    prefAccessible = prefAccessible,
                    onPrefFastestChange = { prefFastest = it },
                    onPrefLeastTransfersChange = { prefLeastTransfers = it },
                    onPrefLeastWalkingChange = { prefLeastWalking = it },
                    onPrefCarFreeChange = { prefCarFree = it },
                    onPrefAccessibleChange = { prefAccessible = it },
                    onSearchAction = {
                        searchPerformed = true
                        searchResults = RoutingEngine.planJourney(
                            fromQuery = fromText,
                            toQuery = toText,
                            cityFilter = selectedCityKey,
                            isAccessible = prefAccessible,
                            hasDisruptionDelay = SimulationManager.vilnius1GDelayed,
                            disruptionDelayMin = if (SimulationManager.vilnius1GDelayed) 8 else 0
                        )
                    },
                    onTriggerSlice = { sliceIndex ->
                        when (sliceIndex) {
                            1 -> {
                                // Vilnius local
                                selectedCityKey = "VILNIUS"
                                fromText = "Vilniaus geležinkelio stotis"
                                toText = "Žaliasis tiltas"
                                searchPerformed = true
                                searchResults = RoutingEngine.planJourney("Vilniaus geležinkelio stotis", "Žaliasis tiltas", "VILNIUS", prefAccessible)
                            }
                            2 -> {
                                // Vilnius to Kaunas rail/bus
                                selectedCityKey = "Lietuva"
                                fromText = "Vilnius"
                                toText = "Kaunas"
                                searchPerformed = true
                                searchResults = RoutingEngine.planJourney("Vilnius", "Kaunas", "Lietuva", prefAccessible)
                            }
                            3 -> {
                                // Klaipėda to Vilnius
                                selectedCityKey = "Lietuva"
                                fromText = "Klaipėda"
                                toText = "Vilnius"
                                searchPerformed = true
                                searchResults = RoutingEngine.planJourney("Klaipėda", "Vilnius", "Lietuva", prefAccessible)
                            }
                        }
                    },
                    isAirportMode = isAirportMode,
                    isTouristMode = isTouristMode,
                    onToggleAirportMode = { isAirportMode = it },
                    onToggleTouristMode = { isTouristMode = it }
                )

                "MAP" -> MapTab(
                    selectedCityKey = selectedCityKey,
                    selectedLanguage = selectedLanguage,
                    selectedStop = selectedStop,
                    onStopSelected = { selectedStop = it },
                    selectedVehicle = selectedVehicle,
                    onVehicleSelected = { selectedVehicle = it }
                )

                "DEPARTURES" -> DeparturesTab(
                    selectedCityKey = selectedCityKey,
                    selectedLanguage = selectedLanguage
                )

                "TICKETS" -> TicketsTab(
                    selectedCityKey = selectedCityKey,
                    selectedLanguage = selectedLanguage,
                    ticketsList = ticketsList,
                    onBuyTicket = { showPaymentDialog = it },
                    onViewTicket = { showActiveTicketDialog = it }
                )

                "DISRUPTIONS" -> DisruptionsTab(
                    selectedLanguage = selectedLanguage,
                    liveDisruptions = liveDisruptions,
                    selectedCityFilter = selectedDisruptionCityFilter,
                    onCityFilterChange = { selectedDisruptionCityFilter = it }
                )
            }

            // --- DIALOGS & OVERLAYS ---

            // Contactless payment simulation dialog
            showPaymentDialog?.let { product ->
                AlertDialog(
                    onDismissRequest = { showPaymentDialog = null },
                    title = { Text(text = txt("demo_payment"), fontWeight = FontWeight.Bold, color = Color(0xFF1E2122)) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(text = "${txt("buy")}: ${product.getName(selectedLanguage)}", fontWeight = FontWeight.Bold)
                            Text(text = "Kaina: ${String.format("%.2f", product.price)} €")
                            Text(text = "Pasirinkite bekontakčio mokėjimo būdą (simuliacija):", fontSize = 13.sp, color = Color.Gray)

                            // Simulator logs
                            SimulationManager.contactlessStatusMessage?.let { status ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE6ECEF)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = status,
                                        modifier = Modifier.padding(12.dp),
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF1E2122),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        SimulationManager.simulateContactlessPayment("Bank Card")
                                        coroutineScope.launch {
                                            delay(1500)
                                            ticketsList.clear()
                                            ticketsList.addAll(AppStorage.purchasedTickets)
                                            showPaymentDialog = null
                                            SimulationManager.clearContactlessMessage()
                                            activeTab = "TICKETS"
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2122)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Banko kortelė", fontSize = 11.sp)
                                }
                                Button(
                                    onClick = {
                                        SimulationManager.simulateContactlessPayment("Apple Pay")
                                        coroutineScope.launch {
                                            delay(1500)
                                            ticketsList.clear()
                                            ticketsList.addAll(AppStorage.purchasedTickets)
                                            showPaymentDialog = null
                                            SimulationManager.clearContactlessMessage()
                                            activeTab = "TICKETS"
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2122)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Apple Pay", fontSize = 11.sp)
                                }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton(onClick = { showPaymentDialog = null }) {
                            Text("Atšaukti", color = Color(0xFFB22E2E))
                        }
                    },
                    shape = RoundedCornerShape(0.dp)
                )
            }

            // View active ticket details
            showActiveTicketDialog?.let { ticket ->
                val remainingSec = remember { mutableStateOf(0L) }
                LaunchedEffect(ticket) {
                    while (ticket.isActivated && System.currentTimeMillis() < ticket.expiryTime) {
                        remainingSec.value = (ticket.expiryTime - System.currentTimeMillis()) / 1000L
                        delay(1000)
                    }
                }

                AlertDialog(
                    onDismissRequest = { showActiveTicketDialog = null },
                    title = {
                        Column {
                            Text(
                                text = txt("ticket_wallet"),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = ticket.fareProduct.getName(selectedLanguage).uppercase(),
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF1E2122)
                            )
                        }
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Active indicator
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (ticket.isActivated && remainingSec.value > 0) Color(0xFF2ECC71).copy(alpha = 0.15f) else Color.LightGray.copy(alpha = 0.2f)
                                ),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(
                                                if (ticket.isActivated && remainingSec.value > 0) Color(0xFF2ECC71) else Color.Gray,
                                                RoundedCornerShape(4.dp)
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (ticket.isActivated && remainingSec.value > 0) txt("active").uppercase() else "PASIBAIGĘS",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (ticket.isActivated && remainingSec.value > 0) Color(0xFF27AE60) else Color.Gray
                                    )
                                }
                            }

                            // Dynamic remaining timer
                            if (ticket.isActivated && remainingSec.value > 0) {
                                val min = remainingSec.value / 60
                                val sec = remainingSec.value % 60
                                Text(
                                    text = String.format("%02d:%02d", min, sec),
                                    fontSize = 42.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF1E2122)
                                )
                                Text(
                                    text = "${txt("expires_at")}: ${java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date(ticket.expiryTime))}",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            }

                            Divider(color = Color(0xFFE6ECEF))

                            // Simulated high-fidelity Barcode / QR Code
                            Surface(
                                modifier = Modifier
                                    .size(160.dp)
                                    .padding(8.dp),
                                border = BorderStroke(1.dp, Color(0xFF1E2122))
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    // Custom visual pattern representing a public-transport ticket barcode
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val bars = 30
                                        val space = size.width / bars
                                        val r = java.util.Random(ticket.id.hashCode().toLong())
                                        for (i in 0 until bars) {
                                            val barWidth = if (r.nextBoolean()) space * 0.7f else space * 0.3f
                                            if (r.nextBoolean()) {
                                                drawRect(
                                                    color = Color(0xFF1E2122),
                                                    topLeft = Offset(i * space, 0f),
                                                    size = androidx.compose.ui.geometry.Size(barWidth, size.height)
                                                )
                                            }
                                        }
                                    }
                                    // Visual DEMO watermark
                                    Text(
                                        text = txt("demo_watermark"),
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFFB22E2E).copy(alpha = 0.5f),
                                        modifier = Modifier.border(4.dp, Color(0xFFB22E2E).copy(alpha = 0.5f)).padding(horizontal = 16.dp, vertical = 6.dp)
                                    )
                                }
                            }

                            Text(
                                text = "BILIETO ID: ${ticket.id}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E2122)
                            )
                            Text(
                                text = "Operatorius: ${ticket.fareProduct.operator} (${ticket.fareProduct.cityKey})",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton(onClick = { showActiveTicketDialog = null }) {
                            Text("Uždaryti", color = Color(0xFF1E2122), fontWeight = FontWeight.Bold)
                        }
                    },
                    shape = RoundedCornerShape(0.dp)
                )
            }
        }
    }
}

// ==========================================
// --- TAB 1: JOURNEY PLANNER & CORE UI ---
// ==========================================
@Composable
fun PlannerTab(
    selectedLanguage: Language,
    selectedCityKey: String,
    fromText: String,
    toText: String,
    onFromTextChange: (String) -> Unit,
    onToTextChange: (String) -> Unit,
    searchPerformed: Boolean,
    searchResults: List<Journey>,
    prefFastest: Boolean,
    prefLeastTransfers: Boolean,
    prefLeastWalking: Boolean,
    prefCarFree: Boolean,
    prefAccessible: Boolean,
    onPrefFastestChange: (Boolean) -> Unit,
    onPrefLeastTransfersChange: (Boolean) -> Unit,
    onPrefLeastWalkingChange: (Boolean) -> Unit,
    onPrefCarFreeChange: (Boolean) -> Unit,
    onPrefAccessibleChange: (Boolean) -> Unit,
    onSearchAction: () -> Unit,
    onTriggerSlice: (Int) -> Unit,
    isAirportMode: Boolean,
    isTouristMode: Boolean,
    onToggleAirportMode: (Boolean) -> Unit,
    onToggleTouristMode: (Boolean) -> Unit
) {
    fun txt(key: String): String = Localisation.getString(key, selectedLanguage)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // PERSONALISATION CARD based on city context
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2122)),
                shape = RoundedCornerShape(0.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (selectedCityKey == "Lietuva") "LIETUVA" else selectedCityKey,
                        color = Color(0xFFB22E2E), // Restrained red accent
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (selectedCityKey == "Lietuva") "Kelionės po Lietuvą" else "Artimiausios stotelės ir maršrutai",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = txt("tagline_primary") + " " + txt("tagline_secondary"),
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // INPUT CARD
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(0.dp),
                border = BorderStroke(1.dp, Color(0xFFD4DFE2))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = txt("search_title"),
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = Color(0xFF1E2122)
                    )

                    // IŠ (From Input)
                    OutlinedTextField(
                        value = fromText,
                        onValueChange = onFromTextChange,
                        label = { Text(txt("from"), fontSize = 12.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("from_input"),
                        leadingIcon = { Icon(Icons.Filled.MyLocation, contentDescription = null, tint = Color(0xFF1E2122)) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        )
                    )

                    // Swap Button
                    IconButton(
                        onClick = {
                            val temp = fromText
                            onFromTextChange(toText)
                            onToTextChange(temp)
                        },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Icon(Icons.Filled.SwapVert, contentDescription = "Sukeisti vietomis", tint = Color(0xFF1E2122))
                    }

                    // Į (To Input)
                    OutlinedTextField(
                        value = toText,
                        onValueChange = onToTextChange,
                        label = { Text(txt("to"), fontSize = 12.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("to_input"),
                        leadingIcon = { Icon(Icons.Filled.Place, contentDescription = null, tint = Color(0xFFB22E2E)) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        )
                    )

                    // PREFERENCE OPTION SWITCHES
                    Text(
                        text = txt("options").uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color.Gray,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    Column {
                        PreferenceRow(txt("fastest"), prefFastest, onPrefFastestChange)
                        PreferenceRow(txt("least_transfers"), prefLeastTransfers, onPrefLeastTransfersChange)
                        PreferenceRow(txt("least_walking"), prefLeastWalking, onPrefLeastWalkingChange)
                        PreferenceRow(txt("car_free"), prefCarFree, onPrefCarFreeChange)
                        PreferenceRow(txt("accessible"), prefAccessible, onPrefAccessibleChange)
                    }

                    // Primary search action
                    Button(
                        onClick = onSearchAction,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2122)),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("submit_button")
                    ) {
                        Text(
                            text = txt("search_button"),
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // FAVORITES / MANO VIETOS
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(0.dp),
                border = BorderStroke(1.dp, Color(0xFFD4DFE2))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = txt("my_places"),
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = Color(0xFF1E2122),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AppStorage.favoritePlaces.take(3).forEach { place ->
                            Button(
                                onClick = {
                                    val stopName = DataProvider.stops.firstOrNull { it.id == place.stopId }?.name ?: ""
                                    onToTextChange(stopName)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF2F5F7)),
                                border = BorderStroke(1.dp, Color(0xFFD4DFE2)),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = place.getTitle(selectedLanguage),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E2122)
                                )
                            }
                        }
                    }
                }
            }
        }

        // AIRPORT AND TOURIST MODE FILTER BUTTONS
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Airport button
                Button(
                    onClick = { onToggleAirportMode(!isAirportMode) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isAirportMode) Color(0xFFB22E2E) else Color.White
                    ),
                    shape = RoundedCornerShape(0.dp),
                    border = BorderStroke(1.dp, if (isAirportMode) Color.Transparent else Color(0xFFD4DFE2)),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.LocalAirport,
                            contentDescription = null,
                            tint = if (isAirportMode) Color.White else Color(0xFF1E2122),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = txt("airport"),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isAirportMode) Color.White else Color(0xFF1E2122)
                        )
                    }
                }

                // Tourist button
                Button(
                    onClick = { onToggleTouristMode(!isTouristMode) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isTouristMode) Color(0xFF4C6A80) else Color.White
                    ),
                    shape = RoundedCornerShape(0.dp),
                    border = BorderStroke(1.dp, if (isTouristMode) Color.Transparent else Color(0xFFD4DFE2)),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Map,
                            contentDescription = null,
                            tint = if (isTouristMode) Color.White else Color(0xFF1E2122),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = txt("tourist"),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isTouristMode) Color.White else Color(0xFF1E2122)
                        )
                    }
                }
            }
        }

        // DYNAMIC AIRPORT DETAILS
        if (isAirportMode) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFDE8E8)),
                    border = BorderStroke(1.dp, Color(0xFFB22E2E)),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("ORO UOSTŲ JUNGTIS", fontWeight = FontWeight.Bold, color = Color(0xFFB22E2E), fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Vilniaus (VNO), Kauno (KUN) ir Palangos (PLQ) oro uostai. Artimiausi tiesioginiai maršrutai:",
                            fontSize = 12.sp,
                            color = Color(0xFF1E2122)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("• Vilnius VNO: Autobusas 1G (Fabijoniškės-Oro uostas)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("• Kaunas KUN: Autobusas 29 (Stotis-Universitetas-Oro uostas)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("• LTG Link: Tiesioginis traukinys Vilnius-VNO Oro uosto stotelė", fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                onFromTextChange("Vilniaus geležinkelio stotis")
                                onToTextChange("Vilniaus oro uostas")
                                onToggleAirportMode(false)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2122))
                        ) {
                            Text("Planuoti kelionę į VNO", fontSize = 11.sp, color = Color.White)
                        }
                    }
                }
            }
        }

        // DYNAMIC TOURIST DETAILS
        if (isTouristMode) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF2F8)),
                    border = BorderStroke(1.dp, Color(0xFF4C6A80)),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("KELIAUTOJAMS (TOURIST NETWORK)", fontWeight = FontWeight.Bold, color = Color(0xFF4C6A80), fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Pasirinkite istorinę ar pajūrio vietovę kelionei per Lietuvą:",
                            fontSize = 12.sp,
                            color = Color(0xFF1E2122)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    onFromTextChange("Vilnius")
                                    onToTextChange("Klaipėda")
                                    onToggleTouristMode(false)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4C6A80)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("VNO ➔ Pajūris", fontSize = 10.sp)
                            }
                            Button(
                                onClick = {
                                    onFromTextChange("Kaunas")
                                    onToTextChange("Klaipėda")
                                    onToggleTouristMode(false)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4C6A80)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Kaunas ➔ Uostas", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // VERTICAL SLICES / DEMO CONTROL PANEL
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE6ECEF)),
                shape = RoundedCornerShape(0.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DEMO VERTIKALŪS PJŪVIAI (Slices)",
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp,
                        color = Color(0xFF1E2122),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Greiti nuorodos taškai demonstracijai pagal reikalavimus:",
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { onTriggerSlice(1) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2122)),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("1 Pjūvis: VNO", fontSize = 9.sp, color = Color.White)
                        }
                        Button(
                            onClick = { onTriggerSlice(2) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2122)),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("2 Pjūvis: VNO➔KAU", fontSize = 9.sp, color = Color.White)
                        }
                        Button(
                            onClick = { onTriggerSlice(3) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2122)),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("3 Pjūvis: KLA➔VNO", fontSize = 9.sp, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "SUTRIKIMŲ ĮŠVIRKŠTIMAS (Disruption Injections)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color(0xFFB22E2E)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Vilnius 1G delay (+8 min):", fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Switch(
                            checked = SimulationManager.vilnius1GDelayed,
                            onCheckedChange = { SimulationManager.toggleVilniusDisruption(it) }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Kaunas stop closed (VDU):", fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Switch(
                            checked = SimulationManager.kaunasStopClosed,
                            onCheckedChange = { SimulationManager.toggleKaunasDisruption(it) }
                        )
                    }
                }
            }
        }

        // CORE PLANNER SEARCH RESULTS
        if (searchPerformed) {
            item {
                Text(
                    text = "KELIONĖS ALTERNATYVOS",
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    color = Color(0xFF1E2122),
                    letterSpacing = 2.sp,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }

            if (searchResults.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Apgailestaujame, maršrutų nerasta pagal pasirinktus filtrus.",
                            modifier = Modifier.padding(16.dp),
                            color = Color.Gray,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                items(searchResults) { journey ->
                    JourneyResultCard(
                        journey = journey,
                        selectedLanguage = selectedLanguage,
                        onEnterJourneyMode = { SimulationManager.startJourneySimulation(journey) }
                    )
                }
            }
        }
    }

    // ACTIVE JOURNEY MODE VIEW OVERLAY (KELIONĖS REŽIMAS)
    if (SimulationManager.isJourneyActive) {
        val journey = SimulationManager.activeJourneySim
        if (journey != null) {
            AlertDialog(
                onDismissRequest = { SimulationManager.cancelJourney() },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = txt("journey_mode"),
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFB22E2E),
                            fontSize = 14.sp,
                            letterSpacing = 1.sp
                        )
                        Button(
                            onClick = { SimulationManager.cancelJourney() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color.Gray),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("✕", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Header info
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2122)),
                            shape = RoundedCornerShape(0.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = txt("your_journey").uppercase(),
                                    color = Color.LightGray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${journey.from} ➔ ${journey.to}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp
                                )
                            }
                        }

                        // LIKUSI KELIONĖ (Remaining Duration)
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(0.dp),
                            border = BorderStroke(1.dp, Color(0xFFB22E2E))
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = txt("remaining_journey").uppercase(),
                                    color = Color.Gray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${journey.durationMin - SimulationManager.elapsedMinutesInLeg} ${txt("minutes_short")}",
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFB22E2E)
                                )
                            }
                        }

                        // NEXT ACTION (NOW, NEXT, TRANSFER ACTIONS)
                        val activeLeg = journey.legs.getOrNull(SimulationManager.activeLegIndex)
                        if (activeLeg != null) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF2F5F7)),
                                shape = RoundedCornerShape(0.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    // 1. NOW
                                    Row(verticalAlignment = Alignment.Top) {
                                        Text(
                                            text = txt("next_action"),
                                            fontWeight = FontWeight.Black,
                                            color = Color(0xFF1E2122),
                                            fontSize = 12.sp,
                                            modifier = Modifier.width(60.dp)
                                        )
                                        Column {
                                            Text(
                                                text = when (activeLeg.mode) {
                                                    TransportMode.WALKING -> "Eikite į ${activeLeg.toStopName}"
                                                    TransportMode.CYCLING -> "Važiuokite dviračiu link ${activeLeg.toStopName}"
                                                    else -> "Įlipkite į ${activeLeg.operator} ${activeLeg.routeNumber} stotelėje ${activeLeg.fromStopName}"
                                                },
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                text = "Trukmė: ${activeLeg.durationMin} min. (atstumas: ${activeLeg.distanceKm} km)",
                                                fontSize = 12.sp,
                                                color = Color.Gray
                                            )
                                        }
                                    }

                                    // 2. NEXT
                                    val nextLeg = journey.legs.getOrNull(SimulationManager.activeLegIndex + 1)
                                    if (nextLeg != null) {
                                        Divider(color = Color.LightGray)
                                        Row(verticalAlignment = Alignment.Top) {
                                            Text(
                                                text = txt("next_step"),
                                                fontWeight = FontWeight.Bold,
                                                color = Color.Gray,
                                                fontSize = 12.sp,
                                                modifier = Modifier.width(60.dp)
                                            )
                                            Column {
                                                Text(
                                                    text = "${nextLeg.operator} ${nextLeg.routeNumber} stotelėje ${nextLeg.fromStopName}",
                                                    fontWeight = FontWeight.Medium,
                                                    fontSize = 13.sp
                                                )
                                                Text(
                                                    text = "Išvyksta: ${nextLeg.departureTime} (Platforma: ${nextLeg.platform})",
                                                    fontSize = 12.sp,
                                                    color = Color.Gray
                                                )
                                            }
                                        }
                                    }

                                    // 3. TRANSFER GUIDANCE (e.g. Kaune, etc.)
                                    if (journey.legs.size > 1 && SimulationManager.activeLegIndex == 0) {
                                        val destinationCity = if (journey.to.contains("Kaun")) "KAUNE" else "KLAIPĖDOJE"
                                        val transferLeg = journey.legs.firstOrNull { it.operator.contains("viešasis") || it.routeNumber.isNotEmpty() && !it.operator.contains("LTG") }
                                        if (transferLeg != null) {
                                            Divider(color = Color.LightGray)
                                            Row {
                                                Text(
                                                    text = destinationCity,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFB22E2E),
                                                    fontSize = 12.sp,
                                                    modifier = Modifier.width(80.dp)
                                                )
                                                Text(
                                                    text = "Persėskite į maršrutą ${transferLeg.routeNumber} (${transferLeg.fromStopName})",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Simulation interactive button step-forward
                        Button(
                            onClick = {
                                SimulationManager.elapsedMinutesInLeg += 5
                                if (SimulationManager.elapsedMinutesInLeg >= (activeLeg?.durationMin ?: 10)) {
                                    SimulationManager.advanceJourneyLeg()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB22E2E)),
                            shape = RoundedCornerShape(0.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("SIMULIUOTI KELIONĖS PROGRESSĄ (+5 min.)", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                },
                confirmButton = {},
                shape = RoundedCornerShape(0.dp)
            )
        }
    }

    // Success dialog for arrival
    if (SimulationManager.isArrived) {
        AlertDialog(
            onDismissRequest = { SimulationManager.isArrived = false },
            title = { Text("KELIONĖ BAIGTA!", fontWeight = FontWeight.Bold, color = Color(0xFF2ECC71)) },
            text = { Text("Sėkmingai atvykote į galutinį tikslą. Ačiū, kad keliaujate su LIETUVA TRANSPORT.OS!") },
            confirmButton = {
                Button(onClick = { SimulationManager.isArrived = false }) {
                    Text("Gerai")
                }
            },
            shape = RoundedCornerShape(0.dp)
        )
    }
}

@Composable
fun PreferenceRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(36.dp)
            .clickable { onCheckedChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = title, fontSize = 13.sp, color = Color(0xFF1E2122), fontWeight = FontWeight.Medium)
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
fun JourneyResultCard(
    journey: Journey,
    selectedLanguage: Language,
    onEnterJourneyMode: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(0.dp),
        border = BorderStroke(1.dp, Color(0xFFD4DFE2)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Category tag and duration
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2122)),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text(
                        text = journey.getCategory(selectedLanguage).uppercase(),
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Text(
                    text = "${journey.durationMin} min. (${journey.startHour} – ${journey.endHour})",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = Color(0xFF1E2122)
                )
            }

            // Route visual representation list
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                journey.legs.forEachIndexed { index, leg ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Visual Mode symbol
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = when (leg.mode) {
                                    TransportMode.TRAIN -> Color(0xFF1E2122)
                                    TransportMode.TROLLEYBUS -> Color(0xFFB22E2E)
                                    TransportMode.REGIONAL_BUS -> Color(0xFF4C6A80)
                                    TransportMode.BUS -> Color(0xFF5E6D75)
                                    else -> Color.LightGray
                                }
                            ),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = when (leg.mode) {
                                        TransportMode.TRAIN -> Icons.Filled.DirectionsTransit
                                        TransportMode.TROLLEYBUS -> Icons.Filled.Tram
                                        TransportMode.REGIONAL_BUS -> Icons.Filled.DirectionsBus
                                        TransportMode.BUS -> Icons.Filled.DirectionsBus
                                        TransportMode.WALKING -> Icons.Filled.DirectionsWalk
                                        TransportMode.CYCLING -> Icons.Filled.DirectionsBike
                                    },
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                                if (leg.routeNumber.isNotEmpty()) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = leg.routeNumber, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        if (index < journey.legs.size - 1) {
                            Icon(
                                Icons.Filled.ChevronRight,
                                contentDescription = null,
                                tint = Color.LightGray,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }

            Divider(color = Color(0xFFE6ECEF))

            // Price and Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Bendra kaina: ${String.format("%.2f", journey.priceEur)} €",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E2122)
                )
                Button(
                    onClick = onEnterJourneyMode,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB22E2E)),
                    shape = RoundedCornerShape(0.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("VAŽIUOTI", fontWeight = FontWeight.Black, fontSize = 11.sp, color = Color.White)
                }
            }
        }
    }
}

// ==========================================
// --- TAB 2: INTERACTIVE NATIONAL MAP ---
// ==========================================
@Composable
fun MapTab(
    selectedCityKey: String,
    selectedLanguage: Language,
    selectedStop: Stop?,
    onStopSelected: (Stop?) -> Unit,
    selectedVehicle: Vehicle?,
    onVehicleSelected: (Vehicle?) -> Unit
) {
    fun txt(key: String): String = Localisation.getString(key, selectedLanguage)

    Box(modifier = Modifier.fillMaxSize()) {
        MapCanvas(
            selectedCityKey = selectedCityKey,
            onStopSelected = {
                onStopSelected(it)
                onVehicleSelected(null)
            },
            onVehicleSelected = {
                onVehicleSelected(it)
                onStopSelected(null)
            },
            trackedVehicleId = selectedVehicle?.id
        )

        // Overlay Interactive Details panel (Bottom overlay)
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 56.dp, start = 16.dp, end = 16.dp)
        ) {
            // If stop details selected
            selectedStop?.let { stop ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    border = BorderStroke(2.dp, Color(0xFF1E2122)),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = stop.name.uppercase(),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 14.sp,
                                    color = Color(0xFF1E2122)
                                )
                                Text(
                                    text = "Platforma: ${stop.platform} • Kryptis: ${stop.direction}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                            IconButton(onClick = { onStopSelected(null) }) {
                                Text("✕", fontWeight = FontWeight.Bold, color = Color.Gray)
                            }
                        }

                        Divider(color = Color(0xFFE6ECEF))

                        // Digital simulated departure table
                        Text(
                            text = "SKAITMENINĖ ŠVIESLENTĖ (SIMULIACIJA)",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB22E2E),
                            fontSize = 10.sp
                        )

                        // Sample departures countdown
                        val sampleRoutes = DataProvider.routes.filter { it.stops.contains(stop.id) }
                        if (sampleRoutes.isEmpty()) {
                            Text("Departures planned via schedules.", fontSize = 11.sp, color = Color.Gray)
                        } else {
                            sampleRoutes.forEachIndexed { i, route ->
                                val countdown = (i * 4 + 2)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Card(
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (route.mode == TransportMode.TROLLEYBUS) Color(0xFFB22E2E) else Color(0xFF1E2122)
                                            ),
                                            shape = RoundedCornerShape(2.dp)
                                        ) {
                                            Text(
                                                text = route.number,
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = route.name, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                    }
                                    Text(
                                        text = "$countdown min.",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 12.sp,
                                        color = Color(0xFF1E2122)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // If vehicle tracker selected
            selectedVehicle?.let { vehicle ->
                val route = DataProvider.routes.firstOrNull { it.id == vehicle.routeId }
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    border = BorderStroke(2.dp, Color(0xFFB22E2E)),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFB22E2E)),
                                    shape = RoundedCornerShape(2.dp)
                                ) {
                                    Text(
                                        text = vehicle.routeNumber,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Kryptis: ${vehicle.directionTo}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            IconButton(onClick = { onVehicleSelected(null) }) {
                                Text("✕", fontWeight = FontWeight.Bold, color = Color.Gray)
                            }
                        }

                        Divider(color = Color(0xFFE6ECEF))

                        Text(
                            text = "LIVE SEKIKLIS (SIMULIACIJA)",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB22E2E),
                            fontSize = 10.sp
                        )

                        Text(
                            text = "Dabartinė stotelė: ${DataProvider.stops.firstOrNull { it.id == vehicle.currentStopId }?.name ?: "Nežinoma"}",
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Kita stotelė: ${DataProvider.stops.firstOrNull { it.id == vehicle.nextStopId }?.name ?: "Nežinoma"}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// --- TAB 3: DIGITAL DEPARTURE BOARDS ---
// ==========================================
@Composable
fun DeparturesTab(
    selectedCityKey: String,
    selectedLanguage: Language
) {
    fun txt(key: String): String = Localisation.getString(key, selectedLanguage)

    val currentCity = if (selectedCityKey == "Lietuva") "VILNIUS" else selectedCityKey
    val stopsList = DataProvider.stops.filter { it.cityKey == currentCity }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "TVARKARAŠČIAI IR IŠVYKIMAI",
            fontWeight = FontWeight.Black,
            fontSize = 14.sp,
            letterSpacing = 2.sp,
            color = Color(0xFF1E2122)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(0.dp),
            border = BorderStroke(1.dp, Color(0xFFD4DFE2))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "REALAUS LAIKO DUOMENYS (${currentCity})",
                    color = Color(0xFFB22E2E),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Šaltinis: SIMULIACIJA. Žemiau pateikiami artimiausi virtualūs autobusų ir troleibusų išvykimai:",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(stopsList) { stop ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(0.dp),
                    border = BorderStroke(1.dp, Color(0xFFE6ECEF))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stop.name.uppercase(),
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = Color(0xFF1E2122)
                            )
                            Text(
                                text = "Platforma ${stop.platform}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        // Render departures countdown simulation
                        val stopRoutes = DataProvider.routes.filter { it.stops.contains(stop.id) }
                        if (stopRoutes.isEmpty()) {
                            Text("Schedules are cached offline.", fontSize = 11.sp, color = Color.Gray)
                        } else {
                            stopRoutes.forEachIndexed { i, route ->
                                val mins = (i * 5 + 3)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Card(
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (route.mode == TransportMode.TROLLEYBUS) Color(0xFFB22E2E) else Color(0xFF1E2122)
                                            ),
                                            shape = RoundedCornerShape(2.dp)
                                        ) {
                                            Text(
                                                text = route.number,
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = route.name, fontSize = 12.sp)
                                    }
                                    Text(
                                        text = "$mins min.",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 12.sp,
                                        color = Color(0xFF1E2122)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// --- TAB 4: TICKETS STORE & WALLET ---
// ==========================================
@Composable
fun TicketsTab(
    selectedCityKey: String,
    selectedLanguage: Language,
    ticketsList: List<Ticket>,
    onBuyTicket: (FareProduct) -> Unit,
    onViewTicket: (Ticket) -> Unit
) {
    fun txt(key: String): String = Localisation.getString(key, selectedLanguage)

    val currentCity = if (selectedCityKey == "Lietuva") "VILNIUS" else selectedCityKey
    val products = DataProvider.fareProducts.filter { it.cityKey == currentCity || it.cityKey == "Lietuva" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // WALLET MANO BILIETAI
        item {
            Text(
                text = txt("ticket_wallet"),
                fontWeight = FontWeight.Black,
                fontSize = 14.sp,
                letterSpacing = 2.sp,
                color = Color(0xFF1E2122)
            )
        }

        // Active ticket items
        val activeTickets = ticketsList.filter { it.isActivated && System.currentTimeMillis() < it.expiryTime }
        if (activeTickets.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(0.dp),
                    border = BorderStroke(1.dp, Color(0xFFE6ECEF))
                ) {
                    Text(
                        text = "Neturite aktyvių bilietų. Įsigykite ir aktyvuokite žemiau.",
                        modifier = Modifier.padding(16.dp),
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            items(activeTickets) { ticket ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF2F8)),
                    shape = RoundedCornerShape(0.dp),
                    border = BorderStroke(1.dp, Color(0xFF4C6A80)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onViewTicket(ticket) }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = ticket.fareProduct.getName(selectedLanguage).uppercase(),
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = Color(0xFF1E2122)
                            )
                            Text(
                                text = "Bilieto ID: ${ticket.id} • ${ticket.fareProduct.operator}",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF27AE60)),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = txt("active").uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // UN-ACTIVATED / INACTIVE TICKETS
        val inactiveTickets = ticketsList.filter { !it.isActivated }
        if (inactiveTickets.isNotEmpty()) {
            item {
                Text(
                    text = "NEAKTYVUOTI BILIETAI (Spauskite aktyvuoti)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
            items(inactiveTickets) { ticket ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(0.dp),
                    border = BorderStroke(1.dp, Color(0xFFE6ECEF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = ticket.fareProduct.getName(selectedLanguage),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(text = "Kaina: ${String.format("%.2f", ticket.fareProduct.price)} €", fontSize = 11.sp, color = Color.Gray)
                        }
                        Button(
                            onClick = { AppStorage.activateTicket(ticket.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB22E2E)),
                            shape = RoundedCornerShape(0.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text(txt("activate").uppercase(), fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // STORE / PIRKTI BILIETĄ
        item {
            Text(
                text = "PIRKTI NAUJĄ BILIETĄ",
                fontWeight = FontWeight.Black,
                fontSize = 14.sp,
                letterSpacing = 2.sp,
                color = Color(0xFF1E2122),
                modifier = Modifier.padding(top = 16.dp)
            )
        }

        items(products) { product ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(0.dp),
                border = BorderStroke(1.dp, Color(0xFFD4DFE2))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = product.getName(selectedLanguage),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF1E2122)
                        )
                        Text(
                            text = "Galioja: ${product.validityMinutes} min. | Operatorius: ${product.operator}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                    Button(
                        onClick = { onBuyTicket(product) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2122)),
                        shape = RoundedCornerShape(0.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(
                            text = "${String.format("%.2f", product.price)} €",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // HISTORY / ISTORIJA
        val historyTickets = ticketsList.filter { it.isActivated && System.currentTimeMillis() >= it.expiryTime }
        if (historyTickets.isNotEmpty()) {
            item {
                Text(
                    text = txt("history").uppercase(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }
            items(historyTickets) { ticket ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(0.dp),
                    border = BorderStroke(1.dp, Color(0xFFE6ECEF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = ticket.fareProduct.getName(selectedLanguage),
                                fontSize = 12.sp,
                                color = Color.Gray,
                                textDecoration = TextDecoration.LineThrough
                            )
                            Text(text = "ID: ${ticket.id}", fontSize = 10.sp, color = Color.Gray)
                        }
                        Text(text = "PASIBAIGĘS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    }
                }
            }
        }
    }
}

// ==========================================
// --- TAB 5: DISRUPTIONS REPORTS PANEL ---
// ==========================================
@Composable
fun DisruptionsTab(
    selectedLanguage: Language,
    liveDisruptions: List<Disruption>,
    selectedCityFilter: String,
    onCityFilterChange: (String) -> Unit
) {
    fun txt(key: String): String = Localisation.getString(key, selectedLanguage)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = txt("disruptions_title"),
            fontWeight = FontWeight.Black,
            fontSize = 14.sp,
            letterSpacing = 2.sp,
            color = Color(0xFF1E2122)
        )

        // National sutrikimai counter
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2122)),
            shape = RoundedCornerShape(0.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "LIETUVA",
                    color = Color.LightGray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                val totalDisruptions = liveDisruptions.size
                Text(
                    text = "$totalDisruptions SUTRIKIMAI UŽFIKSUOTI",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )

                Spacer(modifier = Modifier.height(12.dp))
                // Row counts for Vilnius, Kaunas, Klaipėda
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    DisruptionCityCounter("Vilnius", liveDisruptions.count { it.cityKey == "VILNIUS" }) { onCityFilterChange("VILNIUS") }
                    DisruptionCityCounter("Kaunas", liveDisruptions.count { it.cityKey == "KAUNAS" }) { onCityFilterChange("KAUNAS") }
                    DisruptionCityCounter("Klaipėda", liveDisruptions.count { it.cityKey == "KLAIPEDA" }) { onCityFilterChange("KLAIPEDA") }
                }
            }
        }

        // Active Disruption details list
        val filteredList = if (selectedCityFilter == "Lietuva") liveDisruptions else liveDisruptions.filter { it.cityKey == selectedCityFilter }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SUTRIKIMŲ SĄRAŠAS (${if (selectedCityFilter == "Lietuva") "Visa Lietuva" else selectedCityFilter})",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = Color.Gray
            )
            if (selectedCityFilter != "Lietuva") {
                TextButton(onClick = { onCityFilterChange("Lietuva") }) {
                    Text("Rodyti visus", fontSize = 11.sp, color = Color(0xFFB22E2E))
                }
            }
        }

        if (filteredList.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text(
                    text = "Eismas vyksta pagal tvarkaraštį. Sutrikimų neužfiksuota.",
                    modifier = Modifier.padding(16.dp),
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filteredList) { d ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(0.dp),
                        border = BorderStroke(1.dp, Color(0xFFB22E2E))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFFB22E2E)),
                                        shape = RoundedCornerShape(2.dp)
                                    ) {
                                        Text(
                                            text = d.routeNumber,
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = d.cityKey,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp,
                                        color = Color(0xFF1E2122)
                                    )
                                }
                                Text(
                                    text = d.updatedTime,
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = d.getMessage(selectedLanguage),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E2122)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DisruptionCityCounter(
    cityName: String,
    count: Int,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2C2F30)),
        shape = RoundedCornerShape(0.dp),
        modifier = Modifier
            .width(90.dp)
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = cityName, fontSize = 11.sp, color = Color.LightGray)
            Text(text = count.toString(), fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
        }
    }
}
