package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Stop
import com.example.domain.TransportMode
import com.example.domain.Vehicle
import com.example.providers.DataProvider
import com.example.simulation.SimulationManager
import kotlin.math.absoluteValue

@OptIn(ExperimentalTextApi::class)
@Composable
fun MapCanvas(
    selectedCityKey: String,
    onStopSelected: (Stop) -> Unit,
    onVehicleSelected: (Vehicle) -> Unit,
    trackedVehicleId: String? = null,
    modifier: Modifier = Modifier
) {
    // Coordinate mapping bounds for Lithuania
    // Latitude: 53.9f to 56.5f
    // Longitude: 20.9f to 26.9f
    val minLat = 53.9f
    val maxLat = 56.5f
    val minLon = 20.9f
    val maxLon = 26.9f

    // Pan and zoom states
    var scale by remember { mutableStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    // Auto center map on city switch
    LaunchedEffect(selectedCityKey) {
        scale = when (selectedCityKey) {
            "VILNIUS" -> 5.5f
            "KAUNAS" -> 5.5f
            "KLAIPEDA" -> 5.5f
            "SIAULIAI" -> 5.5f
            "PANEVEZYS" -> 5.5f
            "Lietuva" -> 1.0f
            else -> 1.5f
        }
        offset = when (selectedCityKey) {
            "VILNIUS" -> Offset(-150f, 300f)
            "KAUNAS" -> Offset(100f, 150f)
            "KLAIPEDA" -> Offset(450f, -200f)
            "SIAULIAI" -> Offset(100f, -150f)
            "PANEVEZYS" -> Offset(-50f, -100f)
            else -> Offset.Zero
        }
    }

    val vehicles by SimulationManager.vehicles.collectAsState()
    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFE6ECEF)) // Pale Baltic daylight background
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.8f, 12.0f)
                    offset += pan
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Helper function to project geo to canvas coordinate
            fun project(lat: Float, lon: Float): Offset {
                // Lat maps to Y (inverted), Lon maps to X
                val x = ((lon - minLon) / (maxLon - minLon)) * width
                val y = (1.0f - (lat - minLat) / (maxLat - minLat)) * height
                return Offset(x, y)
            }

            withTransform({
                translate(offset.x, offset.y)
                scale(scale, scale, Offset(width / 2, height / 2))
            }) {
                // 1. Draw national boundaries & geography (subtle topographic lines / water)
                val curonLagoon = Path().apply {
                    val p1 = project(55.72f, 21.13f)
                    val p2 = project(55.55f, 21.12f)
                    val p3 = project(55.30f, 21.00f)
                    val p4 = project(55.30f, 21.20f)
                    moveTo(p1.x, p1.y)
                    lineTo(p2.x, p2.y)
                    lineTo(p3.x, p3.y)
                    lineTo(p4.x, p4.y)
                    close()
                }
                drawPath(curonLagoon, color = Color(0xFFD0DFE5))

                // Draw Baltic Sea corner
                val sea = Path().apply {
                    val p1 = project(56.5f, 20.9f)
                    val p2 = project(55.6f, 21.0f)
                    val p3 = project(55.6f, 20.9f)
                    moveTo(p1.x, p1.y)
                    lineTo(p2.x, p2.y)
                    lineTo(p3.x, p3.y)
                    close()
                }
                drawPath(sea, color = Color(0xFFC0D5DD))

                // Draw major geographic connections
                // 2. Draw Rail Network (strong lines, high contrast)
                val railColor = Color(0xFF1E2122) // Dark graphite
                val railStroke = 4f / scale

                val nodes = mapOf(
                    "VILNIUS" to project(54.6714f, 25.2842f),
                    "KAUNAS" to project(54.8894f, 23.9317f),
                    "KLAIPEDA" to project(55.7212f, 21.1398f),
                    "SIAULIAI" to project(55.9264f, 23.3155f),
                    "PANEVEZYS" to project(55.7420f, 24.3592f)
                )

                // Vilnius - Kaunas rail line
                drawLine(
                    color = railColor,
                    start = nodes["VILNIUS"]!!,
                    end = nodes["KAUNAS"]!!,
                    strokeWidth = railStroke * 1.5f
                )

                // Vilnius - Siauliai - Klaipėda rail line
                drawLine(
                    color = railColor,
                    start = nodes["VILNIUS"]!!,
                    end = nodes["SIAULIAI"]!!,
                    strokeWidth = railStroke * 1.2f
                )
                drawLine(
                    color = railColor,
                    start = nodes["SIAULIAI"]!!,
                    end = nodes["KLAIPEDA"]!!,
                    strokeWidth = railStroke * 1.2f
                )

                // Kaunas - Siauliai line
                drawLine(
                    color = railColor,
                    start = nodes["KAUNAS"]!!,
                    end = nodes["SIAULIAI"]!!,
                    strokeWidth = railStroke
                )

                // Vilnius - Panevėžys
                drawLine(
                    color = railColor,
                    start = nodes["VILNIUS"]!!,
                    end = nodes["PANEVEZYS"]!!,
                    strokeWidth = railStroke
                )

                // 3. Draw intercity regional bus lines (moderate muted blue lines)
                val regionalColor = Color(0xFF4C6A80) // Muted blue
                val regionalStroke = 2.5f / scale
                drawLine(
                    color = regionalColor,
                    start = nodes["VILNIUS"]!!,
                    end = nodes["KAUNAS"]!!,
                    strokeWidth = regionalStroke,
                    pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f / scale, 10f / scale))
                )
                drawLine(
                    color = regionalColor,
                    start = nodes["KAUNAS"]!!,
                    end = nodes["KLAIPEDA"]!!,
                    strokeWidth = regionalStroke,
                    pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f / scale, 10f / scale))
                )

                // 4. Draw detailed city stops and local lines if zoomed in
                val isCityZoom = scale > 3.0f
                val activeStops = if (isCityZoom && selectedCityKey != "Lietuva") {
                    DataProvider.stops.filter { it.cityKey == selectedCityKey }
                } else {
                    DataProvider.stops.filter { it.id.endsWith("STOTIS") } // Only major stations at national zoom
                }

                // Draw local routes as background lines inside cities if zoomed
                if (isCityZoom && selectedCityKey != "Lietuva") {
                    val localBusColor = Color(0xFF5E6D75)
                    val trolleybusColor = Color(0xFFC0392B) // Restrained red for Trolleybuses
                    DataProvider.routes.filter { it.cityKey == selectedCityKey }.forEach { route ->
                        val routeColor = if (route.mode == TransportMode.TROLLEYBUS) trolleybusColor else localBusColor
                        val points = route.stops.mapNotNull { stopId ->
                            DataProvider.stops.firstOrNull { it.id == stopId }?.let { project(it.lat, it.lon) }
                        }
                        for (i in 0 until points.size - 1) {
                            drawLine(
                                color = routeColor,
                                start = points[i],
                                end = points[i + 1],
                                strokeWidth = 3f / scale
                            )
                        }
                    }
                }

                // Draw stops / stations nodes
                activeStops.forEach { stop ->
                    val pos = project(stop.lat, stop.lon)
                    val radius = if (stop.id.contains("STOTIS")) 8f / scale else 5f / scale
                    val strokeColor = if (stop.id.contains("STOTIS")) Color(0xFF1E2122) else Color(0xFF4C6A80)
                    val fillColor = if (stop.id.contains("STOTIS")) Color(0xFFB22E2E) else Color.White // Restrained red accents for central stations

                    drawCircle(
                        color = strokeColor,
                        radius = radius + (2f / scale),
                        center = pos
                    )
                    drawCircle(
                        color = fillColor,
                        radius = radius,
                        center = pos
                    )

                    // Stop Labels (Precise, neat Northern typography layout)
                    val labelSize = if (stop.id.contains("STOTIS")) 12f else 9f
                    val labelText = if (selectedCityKey == "Lietuva") {
                        stop.name.substringBefore(" ") // Vilnius / Kaunas / Klaipėda
                    } else {
                        stop.name
                    }

                    // Render precise clean text label above or below the node
                    val textLayoutResult = textMeasurer.measure(
                        text = AnnotatedString(labelText),
                        style = TextStyle(
                            fontSize = (labelSize / scale).sp,
                            fontWeight = if (stop.id.contains("STOTIS")) FontWeight.Bold else FontWeight.Medium,
                            color = Color(0xFF1E2122)
                        )
                    )
                    drawText(
                        textLayoutResult,
                        topLeft = Offset(pos.x - (textLayoutResult.size.width / 2), pos.y - (radius * 2.5f) - textLayoutResult.size.height)
                    )
                }

                // 5. Draw live tracked moving vehicles
                vehicles.forEach { vehicle ->
                    // Only render vehicles associated with the active city context
                    val routeInfo = DataProvider.routes.firstOrNull { it.id == vehicle.routeId }
                    val vehicleCityKey = routeInfo?.cityKey ?: "Lietuva"
                    if (selectedCityKey == "Lietuva" || vehicleCityKey == selectedCityKey) {
                        val pos = project(vehicle.lat, vehicle.lon)
                        val isTracked = vehicle.id == trackedVehicleId
                        val vehicleColor = if (vehicle.mode == TransportMode.TROLLEYBUS) Color(0xFFC0392B) else Color(0xFF1E2122)
                        
                        // Blinking/Tracked pulsing accent rings
                        if (isTracked) {
                            drawCircle(
                                color = Color(0xFFB22E2E).copy(alpha = 0.4f),
                                radius = 20f / scale,
                                center = pos
                            )
                        }

                        // Vehicle dot
                        drawCircle(
                            color = vehicleColor,
                            radius = 9f / scale,
                            center = pos
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 6f / scale,
                            center = pos
                        )

                        // Vehicle route letter
                        val vehicleText = textMeasurer.measure(
                            text = AnnotatedString(vehicle.routeNumber),
                            style = TextStyle(
                                fontSize = (8f / scale).sp,
                                fontWeight = FontWeight.Black,
                                color = vehicleColor
                            )
                        )
                        drawText(
                            vehicleText,
                            topLeft = Offset(pos.x - (vehicleText.size.width / 2), pos.y - (vehicleText.size.height / 2))
                        )
                    }
                }
            }
        }

        // Overlay Map Controls
        Card(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                IconButton(onClick = { scale = (scale * 1.3f).coerceAtMost(12.0f) }) {
                    Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2122))
                }
                Divider(color = Color(0xFFE6ECEF), thickness = 1.dp, modifier = Modifier.width(32.dp))
                IconButton(onClick = { scale = (scale / 1.3f).coerceAtLeast(0.8f) }) {
                    Text("−", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2122))
                }
                Divider(color = Color(0xFFE6ECEF), thickness = 1.dp, modifier = Modifier.width(32.dp))
                IconButton(onClick = {
                    scale = 1.0f
                    offset = Offset.Zero
                }) {
                    Text("⌂", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E2122))
                }
            }
        }

        // Clickable interactive zones for demonstrative testing
        // Users can tap stops/stations from list below, but drawing small buttons overlay helps!
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 16.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val showCityStops = DataProvider.stops.filter { selectedCityKey == "Lietuva" || it.cityKey == selectedCityKey }.take(4)
            showCityStops.forEach { stop ->
                Button(
                    onClick = { onStopSelected(stop) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2122)),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(
                        stop.name.substringBefore(" (").take(15) + (if (stop.name.length > 15) ".." else ""),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
