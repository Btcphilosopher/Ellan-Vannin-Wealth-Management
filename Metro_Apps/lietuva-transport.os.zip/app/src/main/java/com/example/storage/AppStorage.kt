package com.example.storage

import android.content.Context
import com.example.domain.FareProduct
import com.example.domain.Ticket
import com.example.localisation.Language
import com.example.providers.DataProvider
import java.util.UUID

object AppStorage {
    // In-memory backing state for rapid reactive updates
    var currentLanguage: Language = Language.LT
    var currentCity: String = "Lietuva"
    var isOffline: Boolean = false
    val purchasedTickets = mutableListOf<Ticket>()
    val favoritePlaces = mutableListOf<com.example.providers.FavouritePlace>()
    val recentSearches = mutableListOf<Pair<String, String>>()

    init {
        // Prepopulate favorites
        favoritePlaces.addAll(DataProvider.defaultFavourites)

        // Prepopulate ticket history for demonstration
        purchasedTickets.add(
            Ticket(
                id = "TK-" + UUID.randomUUID().toString().take(6).uppercase(),
                fareProduct = DataProvider.fareProducts.first { it.id == "VIL_24H" },
                isActivated = true,
                activationTime = System.currentTimeMillis() - 86400000L, // 24 hours ago
                expiryTime = System.currentTimeMillis() - 600000L // Expired 10 min ago
            )
        )
        purchasedTickets.add(
            Ticket(
                id = "TK-" + UUID.randomUUID().toString().take(6).uppercase(),
                fareProduct = DataProvider.fareProducts.first { it.id == "LTG_VIL_KAU_FARE" },
                isActivated = true,
                activationTime = System.currentTimeMillis() - 7200000L,
                expiryTime = System.currentTimeMillis() - 3600000L
            )
        )
    }

    fun buyTicket(product: FareProduct): Ticket {
        val ticket = Ticket(
            id = "TK-" + UUID.randomUUID().toString().take(6).uppercase(),
            fareProduct = product,
            isActivated = false
        )
        purchasedTickets.add(0, ticket)
        return ticket
    }

    fun activateTicket(ticketId: String): Ticket? {
        val index = purchasedTickets.indexOfFirst { it.id == ticketId }
        if (index != -1) {
            val t = purchasedTickets[index]
            val activated = t.copy(
                isActivated = true,
                activationTime = System.currentTimeMillis(),
                expiryTime = System.currentTimeMillis() + (t.fareProduct.validityMinutes * 60000L)
            )
            purchasedTickets[index] = activated
            return activated
        }
        return null
    }

    fun addFavorite(titleLt: String, titleEn: String, stopId: String, cityKey: String) {
        if (!favoritePlaces.any { it.stopId == stopId }) {
            favoritePlaces.add(
                com.example.providers.FavouritePlace(
                    titleLt, titleEn, stopId, cityKey
                )
            )
        }
    }

    fun removeFavorite(stopId: String) {
        favoritePlaces.removeAll { it.stopId == stopId }
    }
}
