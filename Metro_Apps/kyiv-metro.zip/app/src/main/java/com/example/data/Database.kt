package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- ROOM ENTITIES ---

@Entity(tableName = "saved_places")
data class SavedPlaceEntity(
    @PrimaryKey val id: String, // "home", "work", or random uuid
    val labelUa: String,
    val labelEn: String,
    val stationId: String,
    val isSystemType: Boolean = false // home, work
)

@Entity(tableName = "user_tickets")
data class TicketEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val typeName: String, // SINGLE_QR, MONTHLY_PASS, etc.
    val titleUa: String,
    val titleEn: String,
    val priceUah: Double,
    val qrCodePayload: String, // mock data UUID
    val timestamp: Long = System.currentTimeMillis(),
    val isValidated: Boolean = false,
    val validatedAt: Long? = null
)

@Entity(tableName = "transport_cards")
data class TransportCardEntity(
    @PrimaryKey val cardNumber: String, // 10 digit number
    val name: String,
    val balanceUah: Double,
    val ridesCount: Int,
    val isDigital: Boolean = false,
    val isActive: Boolean = true,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "recent_journeys")
data class RecentJourneyEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fromStationId: String,
    val toStationId: String,
    val timestamp: Long = System.currentTimeMillis()
)

// --- DAO INTERFACE ---

@Dao
interface AppDao {
    // Saved Places
    @Query("SELECT * FROM saved_places")
    fun getSavedPlaces(): Flow<List<SavedPlaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedPlace(place: SavedPlaceEntity)

    @Query("DELETE FROM saved_places WHERE id = :id")
    suspend fun deleteSavedPlace(id: String)

    // User Tickets
    @Query("SELECT * FROM user_tickets ORDER BY timestamp DESC")
    fun getTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Update
    suspend fun updateTicket(ticket: TicketEntity)

    @Query("DELETE FROM user_tickets WHERE id = :id")
    suspend fun deleteTicket(id: Int)

    // Transport Cards
    @Query("SELECT * FROM transport_cards")
    fun getTransportCards(): Flow<List<TransportCardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransportCard(card: TransportCardEntity)

    @Update
    suspend fun updateTransportCard(card: TransportCardEntity)

    @Query("DELETE FROM transport_cards WHERE cardNumber = :cardNumber")
    suspend fun deleteTransportCard(cardNumber: String)

    // Recent Journeys
    @Query("SELECT * FROM recent_journeys ORDER BY timestamp DESC LIMIT 10")
    fun getRecentJourneys(): Flow<List<RecentJourneyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentJourney(journey: RecentJourneyEntity)

    @Query("DELETE FROM recent_journeys")
    suspend fun clearRecentJourneys()
}

// --- DATABASE CLASS ---

@Database(
    entities = [
        SavedPlaceEntity::class,
        TicketEntity::class,
        TransportCardEntity::class,
        RecentJourneyEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kyiv_metro_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// --- REPOSITORY ---

class MetroRepository(private val appDao: AppDao) {

    val savedPlaces: Flow<List<SavedPlaceEntity>> = appDao.getSavedPlaces()
    val tickets: Flow<List<TicketEntity>> = appDao.getTickets()
    val transportCards: Flow<List<TransportCardEntity>> = appDao.getTransportCards()
    val recentJourneys: Flow<List<RecentJourneyEntity>> = appDao.getRecentJourneys()

    suspend fun savePlace(place: SavedPlaceEntity) {
        appDao.insertSavedPlace(place)
    }

    suspend fun removePlace(id: String) {
        appDao.deleteSavedPlace(id)
    }

    suspend fun addTicket(ticket: TicketEntity) {
        appDao.insertTicket(ticket)
    }

    suspend fun updateTicketState(ticket: TicketEntity) {
        appDao.updateTicket(ticket)
    }

    suspend fun deleteTicket(id: Int) {
        appDao.deleteTicket(id)
    }

    suspend fun saveCard(card: TransportCardEntity) {
        appDao.insertTransportCard(card)
    }

    suspend fun updateCard(card: TransportCardEntity) {
        appDao.updateTransportCard(card)
    }

    suspend fun removeCard(cardNumber: String) {
        appDao.deleteTransportCard(cardNumber)
    }

    suspend fun recordJourney(fromId: String, toId: String) {
        appDao.insertRecentJourney(RecentJourneyEntity(fromStationId = fromId, toStationId = toId))
    }

    suspend fun clearHistory() {
        appDao.clearRecentJourneys()
    }
}
