package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.components.GradientBackground
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: AppViewModel by viewModels {
                AppViewModelFactory(application)
            }

            MyApplicationTheme {
                val currentScreen = viewModel.navigationStack.lastOrNull() ?: Screen.Home

                // Dynamic system back button handler
                BackHandler(enabled = viewModel.navigationStack.size > 1) {
                    viewModel.navigateBack()
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    GradientBackground(isDark = MaterialTheme.colorScheme.background.red < 0.2f) {
                        Scaffold(
                            modifier = Modifier.fillMaxSize(),
                            containerColor = Color.Transparent,
                            topBar = {
                                if (currentScreen == Screen.Home) {
                                    AppHeader(
                                        viewModel = viewModel,
                                        onOpenAdmin = { viewModel.navigateTo(Screen.AdminDashboard) }
                                    )
                                }
                            },
                            bottomBar = {
                                // Persistent elegant bottom wayfinding navigation bar
                                NavigationBar(
                                    modifier = Modifier
                                        .windowInsetsPadding(WindowInsets.navigationBars)
                                        .testTag("app_bottom_nav"),
                                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                                    tonalElevation = 8.dp
                                ) {
                                    val lang = viewModel.currentLanguage.value

                                    NavigationBarItem(
                                        selected = currentScreen == Screen.Home,
                                        onClick = {
                                            while (viewModel.navigationStack.size > 1) viewModel.navigateBack()
                                        },
                                        icon = { Icon(Icons.Filled.Home, "Home") },
                                        label = { Text(if (lang == AppLanguage.UA) "Головна" else "Home", fontSize = 10.sp) },
                                        modifier = Modifier.testTag("nav_tab_home")
                                    )

                                    NavigationBarItem(
                                        selected = currentScreen == Screen.Map,
                                        onClick = {
                                            if (currentScreen != Screen.Map) {
                                                viewModel.navigateTo(Screen.Map)
                                            }
                                        },
                                        icon = { Icon(Icons.Filled.Map, "Map") },
                                        label = { Text(Trans.get("metro_map", lang), fontSize = 10.sp) },
                                        modifier = Modifier.testTag("nav_tab_map")
                                    )

                                    NavigationBarItem(
                                        selected = currentScreen == Screen.Departures,
                                        onClick = {
                                            if (currentScreen != Screen.Departures) {
                                                viewModel.navigateTo(Screen.Departures)
                                            }
                                        },
                                        icon = { Icon(Icons.Filled.Schedule, "Departures") },
                                        label = { Text(if (lang == AppLanguage.UA) "Поїзди" else "Trains", fontSize = 10.sp) },
                                        modifier = Modifier.testTag("nav_tab_departures")
                                    )

                                    NavigationBarItem(
                                        selected = currentScreen == Screen.Tickets,
                                        onClick = {
                                            if (currentScreen != Screen.Tickets) {
                                                viewModel.navigateTo(Screen.Tickets)
                                            }
                                        },
                                        icon = { Icon(Icons.Filled.ConfirmationNumber, "Tickets") },
                                        label = { Text(Trans.get("tickets", lang), fontSize = 10.sp) },
                                        modifier = Modifier.testTag("nav_tab_tickets")
                                    )

                                    NavigationBarItem(
                                        selected = currentScreen == Screen.Account,
                                        onClick = {
                                            if (currentScreen != Screen.Account) {
                                                viewModel.navigateTo(Screen.Account)
                                            }
                                        },
                                        icon = { Icon(Icons.Filled.Settings, "Settings") },
                                        label = { Text(Trans.get("settings", lang), fontSize = 10.sp) },
                                        modifier = Modifier.testTag("nav_tab_settings")
                                    )
                                }
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                AnimatedContent(
                                    targetState = currentScreen,
                                    transitionSpec = {
                                        fadeIn() togetherWith fadeOut()
                                    },
                                    label = "screen_transition"
                                ) { target ->
                                    when (target) {
                                        is Screen.Home -> HomeScreen(viewModel = viewModel)
                                        is Screen.RoutePlanner -> RoutePlannerScreen(viewModel = viewModel)
                                        is Screen.Map -> MapScreen(viewModel = viewModel)
                                        is Screen.Departures -> DeparturesScreen(viewModel = viewModel)
                                        is Screen.Alerts -> AlertsScreen(viewModel = viewModel)
                                        is Screen.Tickets -> TicketsScreen(viewModel = viewModel)
                                        is Screen.ActiveJourney -> ActiveJourneyScreen(viewModel = viewModel)
                                        is Screen.Saved -> SavedScreen(viewModel = viewModel)
                                        is Screen.TouristMode -> TouristModeScreen(viewModel = viewModel)
                                        is Screen.Account -> AccountScreen(viewModel = viewModel)
                                        is Screen.AdminDashboard -> AdminDashboardScreen(viewModel = viewModel)
                                        else -> HomeScreen(viewModel = viewModel)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
