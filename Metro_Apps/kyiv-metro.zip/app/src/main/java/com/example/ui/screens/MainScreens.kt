package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.data.*
import com.example.ui.*
import com.example.ui.theme.*
import com.example.ui.components.*

// --- HEADER NAVIGATION BAR ---
@Composable
fun AppHeader(viewModel: AppViewModel, onOpenAdmin: () -> Unit) {
    val lang = viewModel.currentLanguage.value
    val isOnline = viewModel.isOnline.value

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = Trans.get("app_title", lang),
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = Trans.get("tagline", lang),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 0.5.sp
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            // Online/Offline status badge
            Box(
                modifier = Modifier
                    .padding(end = 8.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isOnline) Color(0xFF22C55E).copy(alpha = 0.15f) else Color(0xFFEF4444).copy(alpha = 0.15f))
                    .border(1.dp, if (isOnline) Color(0xFF22C55E) else Color(0xFFEF4444), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .clickable { viewModel.isOnline.value = !viewModel.isOnline.value }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(if (isOnline) Color(0xFF22C55E) else Color(0xFFEF4444), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isOnline) "LIVE" else "OFFLINE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isOnline) Color(0xFF15803D) else Color(0xFFB91C1C)
                    )
                }
            }

            // Quick Admin panel button
            IconButton(
                onClick = onOpenAdmin,
                modifier = Modifier.size(40.dp).testTag("admin_button")
            ) {
                Icon(
                    Icons.Filled.Build,
                    contentDescription = "Admin Overrides",
                    tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
            }
        }
    }
}

// --- HOME SCREEN ---
@Composable
fun HomeScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value
    var showFromDropdown by remember { mutableStateOf(false) }
    var showToDropdown by remember { mutableStateOf(false) }

    val fromQuery = viewModel.searchFromQuery.value
    val toQuery = viewModel.searchToQuery.value

    val fromSuggestions = remember(fromQuery) { Router.searchStations(fromQuery) }
    val toSuggestions = remember(toQuery) { Router.searchStations(toQuery) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Hero Section "Where are you going?"
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = Trans.get("where_going", lang),
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(horizontal = 16.dp),
            color = MaterialTheme.colorScheme.onBackground
        )

        // Journey Search Glass Box
        Spacer(modifier = Modifier.height(12.dp))
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("journey_search_card")
        ) {
            // From field
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = fromQuery,
                    onValueChange = {
                        viewModel.searchFromQuery.value = it
                        showFromDropdown = true
                        if (it.isEmpty()) viewModel.selectedFromStation.value = null
                    },
                    label = { Text(Trans.get("from", lang)) },
                    leadingIcon = { Icon(Icons.Filled.TripOrigin, "From origin", tint = MetroData.BlueLineColor) },
                    trailingIcon = {
                        if (viewModel.selectedFromStation.value != null) {
                            Icon(Icons.Filled.CheckCircle, "Selected", tint = Color(0xFF22C55E))
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("search_from_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                    )
                )

                // Autocomplete dropdown suggestions
                if (showFromDropdown && fromSuggestions.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 56.dp)
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .zIndex(10f)
                            .heightIn(max = 200.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Column {
                            fromSuggestions.forEach { station ->
                                val sName = if (lang == AppLanguage.UA) station.nameUa else station.nameEn
                                val line = MetroData.Lines.find { it.id == station.lineId }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.selectedFromStation.value = station
                                            viewModel.searchFromQuery.value = sName
                                            showFromDropdown = false
                                        }
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(modifier = Modifier.size(8.dp).background(line?.color ?: Color.Gray, CircleShape))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(sName, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // To field
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = toQuery,
                    onValueChange = {
                        viewModel.searchToQuery.value = it
                        showToDropdown = true
                        if (it.isEmpty()) viewModel.selectedToStation.value = null
                    },
                    label = { Text(Trans.get("to", lang)) },
                    leadingIcon = { Icon(Icons.Filled.LocationOn, "To destination", tint = MetroData.RedLineColor) },
                    trailingIcon = {
                        if (viewModel.selectedToStation.value != null) {
                            Icon(Icons.Filled.CheckCircle, "Selected", tint = Color(0xFF22C55E))
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("search_to_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                    )
                )

                // Autocomplete dropdown suggestions
                if (showToDropdown && toSuggestions.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 56.dp)
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                            .zIndex(10f)
                            .heightIn(max = 200.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Column {
                            toSuggestions.forEach { station ->
                                val sName = if (lang == AppLanguage.UA) station.nameUa else station.nameEn
                                val line = MetroData.Lines.find { it.id == station.lineId }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.selectedToStation.value = station
                                            viewModel.searchToQuery.value = sName
                                            showToDropdown = false
                                        }
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(modifier = Modifier.size(8.dp).background(line?.color ?: Color.Gray, CircleShape))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(sName, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Build Route Button CTA
            Button(
                onClick = {
                    showFromDropdown = false
                    showToDropdown = false
                    if (viewModel.selectedFromStation.value != null && viewModel.selectedToStation.value != null) {
                        viewModel.performRoutePlanning()
                        viewModel.navigateTo(Screen.RoutePlanner)
                    }
                },
                enabled = viewModel.selectedFromStation.value != null && viewModel.selectedToStation.value != null,
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("plan_route_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Filled.Directions, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = Trans.get("plan_route", lang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }

        // --- GRID QUICK ACTIONS ---
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = if (lang == AppLanguage.UA) "Швидкі дії" else "Quick Actions",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            GlassTile(
                modifier = Modifier.weight(1f).height(74.dp).testTag("action_map"),
                onClick = { viewModel.navigateTo(Screen.Map) }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Map, "Map", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(Trans.get("metro_map", lang), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            GlassTile(
                modifier = Modifier.weight(1f).height(74.dp).testTag("action_departures"),
                onClick = { viewModel.navigateTo(Screen.Departures) }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Schedule, "Departures", tint = MetroData.GreenLineColor, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(Trans.get("departures", lang), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            GlassTile(
                modifier = Modifier.weight(1f).height(74.dp).testTag("action_tickets"),
                onClick = { viewModel.navigateTo(Screen.Tickets) }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.ConfirmationNumber, "Tickets", tint = MetroData.RedLineColor, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(Trans.get("tickets", lang), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            GlassTile(
                modifier = Modifier.weight(1f).height(74.dp).testTag("action_tourist"),
                onClick = { viewModel.navigateTo(Screen.TouristMode) }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Explore, "Tourist", tint = Color(0xFFF59E0B), modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(Trans.get("tourist_mode", lang), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            GlassTile(
                modifier = Modifier.weight(1f).height(74.dp).testTag("action_saved"),
                onClick = { viewModel.navigateTo(Screen.Saved) }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Favorite, "Saved", tint = Color(0xFFEC4899), modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(Trans.get("saved", lang), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            GlassTile(
                modifier = Modifier.weight(1f).height(74.dp).testTag("action_alerts"),
                onClick = { viewModel.navigateTo(Screen.Alerts) }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Warning, "Alerts", tint = Color(0xFFEF4444), modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(Trans.get("service_status", lang), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        // --- LINE SERVICE STATUS ROW ---
        Spacer(modifier = Modifier.height(20.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = Trans.get("service_status", lang),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = Trans.get("demo_data_indicator", lang),
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("red" to "M1", "blue" to "M2", "green" to "M3").forEach { (id, tag) ->
                val lineObj = MetroData.Lines.find { it.id == id }
                val status = viewModel.lineStatuses[id]?.value ?: NetworkStatus.NORMAL
                val isSuspended = viewModel.suspendedLines.contains(id)

                val (statusTextKey, statusColor) = when {
                    isSuspended -> Pair("suspended", Color(0xFFEF4444))
                    status == NetworkStatus.NORMAL -> Pair("normal_service", Color(0xFF22C55E))
                    status == NetworkStatus.MINOR_DELAY -> Pair("minor_delay", Color(0xFFF59E0B))
                    status == NetworkStatus.MAJOR_DELAY -> Pair("major_delay", Color(0xFFEF4444))
                    else -> Pair("reduced_service", Color(0xFF6B7280))
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(lineObj?.color ?: Color.Gray),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(tag, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (lang == AppLanguage.UA) lineObj?.nameUa ?: "" else lineObj?.nameEn ?: "",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(statusColor, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = Trans.get(statusTextKey, lang),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusColor
                        )
                    }
                }
            }
        }
    }
}

// --- JOURNEY PLANNER RESULTS ---
@Composable
fun RoutePlannerScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value
    val from = viewModel.selectedFromStation.value
    val to = viewModel.selectedToStation.value
    val legs = viewModel.plannedRouteLegs.value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = if (lang == AppLanguage.UA) "Маршрут сплановано" else "Planned Route",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Brief details
        if (from != null && to != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.TripOrigin, contentDescription = null, tint = MetroData.BlueLineColor, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            if (lang == AppLanguage.UA) from.nameUa else from.nameEn,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.LocationOn, contentDescription = null, tint = MetroData.RedLineColor, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            if (lang == AppLanguage.UA) to.nameUa else to.nameEn,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (legs == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.SearchOff, "Not found", tint = Color.Gray, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = Trans.get("route_not_found", lang),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                }
            }
        } else {
            // Calculate total time
            val totalTime = legs.sumOf {
                when (it) {
                    is RouteLeg.TrainRide -> it.timeMinutes
                    is RouteLeg.Interchange -> it.timeMinutes
                    is RouteLeg.WalkToStation -> it.timeMinutes
                    is RouteLeg.WalkToDestination -> it.timeMinutes
                }
            }

            // Summary Card
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (lang == AppLanguage.UA) "Час у дорозі" else "Travel Time",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$totalTime ${Trans.get("minutes", lang)}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Button(
                        onClick = { viewModel.startJourneyTracking(legs) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.testTag("start_journey_cta")
                    ) {
                        Icon(Icons.Filled.Navigation, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (lang == AppLanguage.UA) "ПОЇХАЛИ" else "START",
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = if (lang == AppLanguage.UA) "ДЕТАЛІ МАРШРУТУ" else "ROUTE DETAILS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                color = Color.Gray,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Leg details timeline
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                legs.forEachIndexed { index, leg ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        // Graphic Timeline bar
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.width(36.dp)
                        ) {
                            val dotColor = when (leg) {
                                is RouteLeg.TrainRide -> {
                                    val l = MetroData.Lines.find { it.id == leg.lineId }
                                    l?.color ?: Color.DarkGray
                                }
                                is RouteLeg.Interchange -> KyvYellow
                                else -> Color.Gray
                            }

                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(dotColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (leg) {
                                        is RouteLeg.TrainRide -> Icons.Filled.Subway
                                        is RouteLeg.Interchange -> Icons.Filled.DirectionsWalk
                                        else -> Icons.Filled.DirectionsWalk
                                    },
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }

                            if (index < legs.size - 1) {
                                Box(
                                    modifier = Modifier
                                        .width(3.dp)
                                        .height(50.dp)
                                        .background(Color.LightGray.copy(alpha = 0.5f))
                                )
                            }
                        }

                        // Leg description details
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 10.dp)
                        ) {
                            when (leg) {
                                is RouteLeg.TrainRide -> {
                                    val l = MetroData.Lines.find { it.id == leg.lineId }
                                    val lName = if (lang == AppLanguage.UA) l?.nameUa else l?.nameEn
                                    Text(
                                        text = "${Trans.get("directions", lang)}: ${lName ?: ""}",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${viewModel.getStationName(leg.fromId, lang)} → ${viewModel.getStationName(leg.toId, lang)}",
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = "${leg.stationsPassedCount} ${Trans.get("stations", lang)} • ${leg.timeMinutes} ${Trans.get("minutes", lang)}",
                                        fontSize = 11.sp,
                                        color = l?.color ?: Color.Gray,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                is RouteLeg.Interchange -> {
                                    Text(
                                        text = Trans.get("interchanges", lang),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = KyvYellow
                                    )
                                    Text(
                                        text = "${viewModel.getStationName(leg.stationFromId, lang)} ⇄ ${viewModel.getStationName(leg.stationToId, lang)}",
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = "${leg.timeMinutes} ${Trans.get("minutes", lang)} ${Trans.get("walk", lang)}",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                                is RouteLeg.WalkToStation -> {
                                    Text(
                                        text = "${Trans.get("walk", lang)} до станції",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = viewModel.getStationName(leg.stationId, lang),
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                }
                                is RouteLeg.WalkToDestination -> {
                                    Text(
                                        text = "${Trans.get("walk", lang)} до пункту призначення",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = viewModel.getStationName(leg.stationId, lang),
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- DEPARTURES SCREEN ---
@Composable
fun DeparturesScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value
    var selectedStationId by remember { mutableStateOf("vokzalna") }
    var expandedStationMenu by remember { mutableStateOf(false) }

    val station = MetroData.Stations[selectedStationId]
    val list = viewModel.getDeparturesForStation(selectedStationId)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = Trans.get("departures", lang),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Dropdown Station Selector
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Button(
                onClick = { expandedStationMenu = true },
                modifier = Modifier.fillMaxWidth().testTag("station_selector_trigger"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = station?.let { if (lang == AppLanguage.UA) it.nameUa else it.nameEn } ?: "Select Station",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            DropdownMenu(
                expanded = expandedStationMenu,
                onDismissRequest = { expandedStationMenu = false },
                modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp)
            ) {
                MetroData.Stations.values.forEach { s ->
                    val sName = if (lang == AppLanguage.UA) s.nameUa else s.nameEn
                    DropdownMenuItem(
                        text = { Text(sName) },
                        onClick = {
                            selectedStationId = s.id
                            expandedStationMenu = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (list.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Timer, "No data", tint = Color.Gray, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (lang == AppLanguage.UA) "Поїздів немає у розкладі" else "No scheduled trains",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(list) { dep ->
                    val line = MetroData.Lines.find { it.id == dep.lineId }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .border(1.dp, line?.color?.copy(alpha = 0.3f) ?: Color.Transparent, RoundedCornerShape(12.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .background(line?.color ?: Color.Gray, RoundedCornerShape(6.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.Subway, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (lang == AppLanguage.UA) dep.directionNameUa else dep.directionNameEn,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = dep.platform,
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${dep.minutesLeft} ${Trans.get("minutes", lang)}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = line?.color ?: MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- TICKETS SCREEN ---
@Composable
fun TicketsScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value
    val listTickets by viewModel.tickets.collectAsState()
    val listCards by viewModel.transportCards.collectAsState()

    var showBuyModal by remember { mutableStateOf<FareProduct?>(null) }
    var inputCardName by remember { mutableStateOf("") }
    var inputTopUpAmount by remember { mutableStateOf("") }
    var activeTopUpCard by remember { mutableStateOf<TransportCardEntity?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = Trans.get("tickets", lang),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // --- ACTIVE QR TICKETS ---
        Text(
            text = if (lang == AppLanguage.UA) "АКТИВНІ КВИТКИ" else "ACTIVE QR TICKETS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        if (listTickets.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (lang == AppLanguage.UA) "У вас немає активних квитків" else "No active tickets",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listTickets.forEach { t ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (lang == AppLanguage.UA) t.titleUa else t.titleEn,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = t.qrCodePayload,
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                                if (t.isValidated) {
                                    Text(
                                        text = if (lang == AppLanguage.UA) "ВИКОРИСТАНО" else "VALIDATED",
                                        color = Color.Gray,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            if (!t.isValidated) {
                                Button(
                                    onClick = { viewModel.validateTicket(t) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MetroData.GreenLineColor)
                                ) {
                                    Icon(Icons.Filled.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (lang == AppLanguage.UA) "СКАНУВАТИ" else "SCAN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.Gray)
                            }
                        }
                    }
                }
            }
        }

        // --- MY TRANSPORT CARDS ---
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = Trans.get("my_cards", lang).uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        if (listCards.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Button(
                    onClick = { viewModel.registerNewTransportCard("Kyiv Smart Card", false) },
                    modifier = Modifier.testTag("add_physical_card")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(Trans.get("add_card", lang))
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listCards.forEach { card ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(card.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("№ ${card.cardNumber}", fontSize = 10.sp, color = Color.Gray)
                                Text(
                                    text = "${card.balanceUah} UAH • ${card.ridesCount} ${Trans.get("stations", lang)}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Row {
                                IconButton(onClick = { activeTopUpCard = card }) {
                                    Icon(Icons.Filled.AddCard, "Top Up", tint = MetroData.GreenLineColor)
                                }
                                IconButton(onClick = { viewModel.useCardRide(card) }) {
                                    Icon(Icons.Filled.DirectionsTransit, "Use Ride", tint = MetroData.BlueLineColor)
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- BUY PRODUCTS CATALOG ---
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = if (lang == AppLanguage.UA) "ПРИДБАТИ КВИТОК" else "PURCHASE PRODUCTS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetroData.Fares.forEach { fare ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .clickable { showBuyModal = fare }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (lang == AppLanguage.UA) fare.nameUa else fare.nameEn,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (lang == AppLanguage.UA) fare.descriptionUa else fare.descriptionEn,
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                    Text(
                        text = "${fare.priceUah} UAH",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Simulating Modals
        if (showBuyModal != null) {
            val product = showBuyModal!!
            AlertDialog(
                onDismissRequest = { showBuyModal = null },
                title = { Text(if (lang == AppLanguage.UA) "Оплата" else "Simulated Payment") },
                text = {
                    Column {
                        Text(
                            text = if (lang == AppLanguage.UA) "Оплатити ${product.priceUah} UAH за ${product.nameUa}?"
                            else "Pay ${product.priceUah} UAH for ${product.nameEn}?"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "SIMULATED PAYMENT",
                            color = KyvYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.purchaseTicket(product)
                            showBuyModal = null
                        }
                    ) {
                        Text(if (lang == AppLanguage.UA) "Оплатити" else "Pay")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showBuyModal = null }) {
                        Text("Cancel")
                    }
                }
            )
        }

        if (activeTopUpCard != null) {
            val card = activeTopUpCard!!
            AlertDialog(
                onDismissRequest = { activeTopUpCard = null },
                title = { Text(if (lang == AppLanguage.UA) "Поповнення" else "Top Up Card") },
                text = {
                    Column {
                        OutlinedTextField(
                            value = inputTopUpAmount,
                            onValueChange = { inputTopUpAmount = it },
                            label = { Text("Amount UAH") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Trips will be calculated at 8.00 UAH per ride.", fontSize = 10.sp, color = Color.Gray)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val amt = inputTopUpAmount.toDoubleOrNull() ?: 0.0
                            if (amt > 0) {
                                viewModel.topUpTransportCard(card, amt)
                                inputTopUpAmount = ""
                                activeTopUpCard = null
                            }
                        }
                    ) {
                        Text("Confirm")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { activeTopUpCard = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

// --- ACTIVE JOURNEY TIMELINE TRACKER ---
@Composable
fun ActiveJourneyScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value
    val route = viewModel.activeJourney.value
    val activeState = viewModel.activeJourneyState.value
    val targetStationId = viewModel.activeJourneyTargetStationId.value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                viewModel.activeJourney.value = null
                viewModel.navigateBack()
            }) {
                Icon(Icons.Filled.Close, contentDescription = "Cancel tracking")
            }
            Text(
                text = Trans.get("active_journey", lang),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (route == null) return

        // Large status block
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = when (activeState) {
                    "AT_STATION" -> if (lang == AppLanguage.UA) "ОЧІКУЙТЕ НА СТАНЦІЇ" else "WAIT AT THE STATION"
                    "ON_TRAIN" -> if (lang == AppLanguage.UA) "ВИ НА ШЛЯХУ" else "YOU ARE ON THE WAY"
                    "ARRIVING" -> if (lang == AppLanguage.UA) "ПОЇЗД ПРИБУВАЄ" else "TRAIN ARRIVING"
                    else -> if (lang == AppLanguage.UA) "ВИ ПРИБУЛИ!" else "YOU HAVE ARRIVED!"
                },
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = viewModel.getStationName(targetStationId, lang),
                fontSize = 26.sp,
                fontWeight = FontWeight.Black
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Progressive state guide buttons
            Button(
                onClick = { viewModel.progressJourneyState() },
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("journey_progress_cta"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when (activeState) {
                        "AT_STATION" -> MetroData.BlueLineColor
                        "ON_TRAIN" -> KyvYellow
                        else -> MetroData.GreenLineColor
                    }
                )
            ) {
                Text(
                    text = when (activeState) {
                        "AT_STATION" -> Trans.get("on_train", lang).uppercase()
                        "ON_TRAIN" -> Trans.get("arriving", lang).uppercase()
                        "ARRIVING" -> Trans.get("arrived", lang).uppercase()
                        else -> "DONE"
                    },
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = if (lang == AppLanguage.UA) "ПРОГРЕС МАРШРУТУ" else "ROUTE TIMELINE PROGRESS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Horizontal/Vertical progressive map timeline
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
        ) {
            route.forEachIndexed { idx, leg ->
                val isActiveLeg = idx == viewModel.currentLegIndex.value
                val isPassed = idx < viewModel.currentLegIndex.value

                Row(
                    modifier = Modifier.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(
                                when {
                                    isActiveLeg -> MaterialTheme.colorScheme.primary
                                    isPassed -> Color.Gray
                                    else -> Color.LightGray.copy(alpha = 0.5f)
                                },
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPassed) Icons.Filled.Check else Icons.Filled.PlayArrow,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Text(
                        text = when (leg) {
                            is RouteLeg.TrainRide -> "${viewModel.getStationName(leg.fromId, lang)} ➔ ${viewModel.getStationName(leg.toId, lang)}"
                            is RouteLeg.Interchange -> "${viewModel.getStationName(leg.stationFromId, lang)} ⇄ ${viewModel.getStationName(leg.stationToId, lang)}"
                            is RouteLeg.WalkToStation -> "Walk to ${viewModel.getStationName(leg.stationId, lang)}"
                            is RouteLeg.WalkToDestination -> "Arrive at destination"
                        },
                        fontSize = 14.sp,
                        fontWeight = if (isActiveLeg) FontWeight.Bold else FontWeight.Normal,
                        color = if (isActiveLeg) MaterialTheme.colorScheme.onBackground else Color.Gray
                    )
                }
            }
        }
    }
}

// --- SAVED FAVOURITES SCREEN ---
@Composable
fun SavedScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value
    val listPlaces by viewModel.savedPlaces.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = Trans.get("saved", lang),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        listPlaces.forEach { place ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .clickable {
                        val stat = MetroData.Stations[place.stationId]
                        if (stat != null) {
                            viewModel.selectedToStation.value = stat
                            viewModel.searchToQuery.value = if (lang == AppLanguage.UA) stat.nameUa else stat.nameEn
                            viewModel.navigateTo(Screen.Home)
                        }
                    }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (place.id == "home") Icons.Filled.Home else Icons.Filled.Work,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (lang == AppLanguage.UA) place.labelUa else place.labelEn,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = viewModel.getStationName(place.stationId, lang),
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Color.Gray)
            }
        }
    }
}

// --- TOURIST MODE ("VISIT KYIV") ---
@Composable
fun TouristModeScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = Trans.get("tourist_mode", lang),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Arrival context banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFE0F2FE))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.FlightLand, contentDescription = null, tint = Color(0xFF0369A1), modifier = Modifier.size(34.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = if (lang == AppLanguage.UA) "Прибуття до Києва" else "Arriving in Kyiv",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0369A1)
                    )
                    Text(
                        text = if (lang == AppLanguage.UA) "З Центрального залізничного вокзалу переходьте на станцію метро Вокзальна."
                        else "From the Central Railway Station, walk directly into Vokzalna Metro station.",
                        fontSize = 12.sp,
                        color = Color(0xFF0C5A85)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = Trans.get("landmark_mode", lang).uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        // Landmarks list
        MetroData.Landmarks.forEach { landmark ->
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFFFEF3C7), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.LocationCity, contentDescription = null, tint = Color(0xFFD97706))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (lang == AppLanguage.UA) landmark.nameUa else landmark.nameEn,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (lang == AppLanguage.UA) landmark.descriptionUa else landmark.descriptionEn,
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.DirectionsTransit, contentDescription = null, tint = MetroData.BlueLineColor, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${viewModel.getStationName(landmark.nearestStationId, lang)} • ${landmark.walkMinutes} ${Trans.get("minutes", lang)} walk",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MetroData.BlueLineColor
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- ALERTS SCREEN ---
@Composable
fun AlertsScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value
    val alerts = viewModel.activeAlerts

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = Trans.get("service_status", lang),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (alerts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.VerifiedUser, "Normal", tint = Color(0xFF22C55E), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (lang == AppLanguage.UA) "Всі системи працюють у штатному режимі" else "All transit systems running normally",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(alerts) { alert ->
                    val line = alert.lineId?.let { lid -> MetroData.Lines.find { it.id == lid } }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFFEF2F2))
                            .border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(12.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(line?.color ?: Color(0xFFEF4444)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.NotificationImportant, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (lang == AppLanguage.UA) alert.titleUa else alert.titleEn,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF991B1B)
                            )
                            Text(
                                text = if (lang == AppLanguage.UA) alert.descriptionUa else alert.descriptionEn,
                                fontSize = 12.sp,
                                color = Color(0xFF7F1D1D)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${Trans.get("directions", lang)}: ${if (lang == AppLanguage.UA) alert.alternativeUa else alert.alternativeEn}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF991B1B)
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- ACCESSIBILITY / SETTINGS SCREEN ---
@Composable
fun AccountScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value
    var selectedLanguage by viewModel.currentLanguage
    var stepFree by viewModel.accessibilityStepFree
    var avoidStairs by viewModel.accessibilityAvoidStairs
    var highContrast by viewModel.accessibilityHighContrast

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = Trans.get("settings", lang),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- INSTANT LANGUAGE TOGGLE ---
        Text(
            text = Trans.get("language", lang).uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { selectedLanguage = AppLanguage.UA },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedLanguage == AppLanguage.UA) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier.weight(1f).testTag("lang_ua")
            ) {
                Text("Українська", color = if (selectedLanguage == AppLanguage.UA) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Button(
                onClick = { selectedLanguage = AppLanguage.EN },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedLanguage == AppLanguage.EN) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier.weight(1f).testTag("lang_en")
            ) {
                Text("English", color = if (selectedLanguage == AppLanguage.EN) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // --- ACCESSIBILITY TOGGLES ---
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = Trans.get("accessibility_profile", lang).uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(Trans.get("step_free", lang), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Switch(checked = stepFree, onCheckedChange = { stepFree = it }, modifier = Modifier.testTag("switch_step_free"))
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(Trans.get("fewest_transfers", lang), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Switch(checked = avoidStairs, onCheckedChange = { avoidStairs = it })
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(if (lang == AppLanguage.UA) "Високий контраст" else "High contrast display", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Switch(checked = highContrast, onCheckedChange = { highContrast = it })
            }
        }
    }
}

// --- ADMIN / SIMULATOR PANEL ---
@Composable
fun AdminDashboardScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value

    var customTitleUa by remember { mutableStateOf("") }
    var customTitleEn by remember { mutableStateOf("") }
    var customDescUa by remember { mutableStateOf("") }
    var customDescEn by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = Trans.get("admin", lang),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- LINE SIMULATOR OVERRIDES ---
        Text(
            text = "LINE SIMULATION OVERRIDES",
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("red" to "M1 Red", "blue" to "M2 Blue", "green" to "M3 Green").forEach { (id, tag) ->
                val lineObj = MetroData.Lines.find { it.id == id }
                val isSuspended = viewModel.suspendedLines.contains(id)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(tag, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row {
                        Button(
                            onClick = { viewModel.updateLineStatus(id, if (isSuspended) NetworkStatus.NORMAL else NetworkStatus.SUSPENDED) },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isSuspended) Color(0xFFEF4444) else Color(0xFF22C55E)),
                            modifier = Modifier.testTag("toggle_line_$id")
                        ) {
                            Text(if (isSuspended) "SUSPENDED" else "NORMAL")
                        }
                    }
                }
            }
        }

        // --- CUSTOM ALERTS POSTER ---
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "POST EMERGENCY NOTICE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = customTitleUa,
                onValueChange = { customTitleUa = it },
                label = { Text("Title (Ukrainian)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = customTitleEn,
                onValueChange = { customTitleEn = it },
                label = { Text("Title (English)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = customDescUa,
                onValueChange = { customDescUa = it },
                label = { Text("Description (Ukrainian)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = customDescEn,
                onValueChange = { customDescEn = it },
                label = { Text("Description (English)") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    if (customTitleUa.isNotEmpty() && customTitleEn.isNotEmpty()) {
                        viewModel.addCustomAlert(customTitleUa, customTitleEn, customDescUa, customDescEn)
                        customTitleUa = ""
                        customTitleEn = ""
                        customDescUa = ""
                        customDescEn = ""
                    }
                },
                modifier = Modifier.fillMaxWidth().testTag("post_alert_cta")
            ) {
                Text("Publish Alert")
            }
        }
    }
}

// --- COMPOSABLE EMBEDDED MAP PANEL SCREEN ---
@Composable
fun MapScreen(viewModel: AppViewModel) {
    val lang = viewModel.currentLanguage.value
    val disabled = viewModel.disabledStations
    val suspended = viewModel.suspendedLines
    val highlightedLegs = viewModel.plannedRouteLegs.value

    var isSchematic by remember { mutableStateOf(true) }
    var activeStationInfoModal by remember { mutableStateOf<Station?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = Trans.get("metro_map", lang),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Map schematic/geographic selector tab
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Text(
                    text = if (lang == AppLanguage.UA) "Схема" else "Schematic",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { isSchematic = true }
                        .background(if (isSchematic) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    color = if (isSchematic) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (lang == AppLanguage.UA) "Гео" else "Geographic",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { isSchematic = false }
                        .background(if (!isSchematic) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    color = if (!isSchematic) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Box(modifier = Modifier.weight(1f).padding(horizontal = 16.dp)) {
            if (isSchematic) {
                SchematicMapView(
                    lang = lang,
                    disabledStations = disabled,
                    suspendedLines = suspended,
                    highlightedLegs = highlightedLegs,
                    onStationSelected = { activeStationInfoModal = it }
                )
            } else {
                GeographicMapView(
                    lang = lang,
                    onStationClick = { activeStationInfoModal = it }
                )
            }
        }

        // Tap info Dialog Modal
        if (activeStationInfoModal != null) {
            val station = activeStationInfoModal!!
            val line = MetroData.Lines.find { it.id == station.lineId }
            val deps = viewModel.getDeparturesForStation(station.id)

            AlertDialog(
                onDismissRequest = { activeStationInfoModal = null },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(12.dp).background(line?.color ?: Color.Gray, CircleShape))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (lang == AppLanguage.UA) station.nameUa else station.nameEn, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        Text(
                            text = if (lang == AppLanguage.UA) "Наступні відправлення:" else "Next departures:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        deps.take(3).forEach { d ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(if (lang == AppLanguage.UA) d.directionNameUa else d.directionNameEn, fontSize = 12.sp)
                                Text("${d.minutesLeft} min", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (lang == AppLanguage.UA) "Профіль доступності:" else "Accessibility features:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Elevator, null, tint = MetroData.GreenLineColor, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (station.accessibility.hasElevators) "Elevators available" else "No elevators", fontSize = 12.sp)
                        }

                        if (station.landmarks.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = Trans.get("nearby_landmarks", lang),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            station.landmarks.forEach { lm ->
                                Text("• $lm", fontSize = 11.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { activeStationInfoModal = null }) {
                        Text("OK")
                    }
                }
            )
        }
    }
}
