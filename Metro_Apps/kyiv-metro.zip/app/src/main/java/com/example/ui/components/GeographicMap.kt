package com.example.ui.components

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.AppLanguage
import com.example.ui.theme.*

// Real-world geographic approximate locations of Kyiv centers
data class GeoPoint(val x: Float, val y: Float, val labelUa: String, val labelEn: String, val type: String)

object GeographicData {
    val Landmarks = listOf(
        GeoPoint(400f, 400f, "Залізничний Вокзал", "Railway Station", "rail"),
        GeoPoint(600f, 320f, "Золоті Ворота", "Golden Gate", "landmark"),
        GeoPoint(680f, 260f, "Софійська Площа", "Sophia Square", "landmark"),
        GeoPoint(730f, 350f, "Майдан Незалежності", "Independence Square", "landmark"),
        GeoPoint(700f, 200f, "Київський Фунікулер", "Kyiv Funicular", "funicular"),
        GeoPoint(710f, 150f, "Поштова Площа", "Poshtova Square", "metro"),
        GeoPoint(690f, 90f, "Контрактова Площа", "Kontraktova Square", "metro"),
        GeoPoint(830f, 420f, "Арсенальна", "Arsenalna", "metro"),
        GeoPoint(950f, 500f, "Києво-Печерська Лавра", "Pechersk Lavra", "landmark")
    )

    val TransitStops = listOf(
        GeoPoint(430f, 380f, "Трамвай 18", "Tram 18 Stop", "tram"),
        GeoPoint(690f, 100f, "Трамвай 12", "Tram 12 Stop", "tram"),
        GeoPoint(730f, 370f, "Тролейбус 16", "Trolleybus 16 Stop", "trolleybus"),
        GeoPoint(830f, 450f, "Автобус 24", "Bus 24 Stop", "bus"),
        GeoPoint(610f, 340f, "Каса самообслуговування", "Self-service Ticket Terminal", "ticket")
    )
}

@Composable
fun GeographicMapView(
    lang: AppLanguage,
    onStationClick: (Station) -> Unit
) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val transformState = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.5f, 3f)
        offset += offsetChange
    }

    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    // Clean restrained geographic map palette
    val landColor = if (isDark) Color(0xFF181B1F) else Color(0xFFFAF9F6)
    val riverColor = if (isDark) Color(0xFF1E2E3D) else Color(0xFFD6E4F0)
    val gridColor = if (isDark) Color(0xFF262A30) else Color(0xFFEBEAE4)
    val railColor = if (isDark) Color(0xFF3F4E5A) else Color(0xFF94A3B8)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(landColor)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
            .transformable(state = transformState)
            .horizontalScroll(rememberScrollState())
            .verticalScroll(rememberScrollState())
    ) {
        Box(
            modifier = Modifier
                .width(1300.dp)
                .height(1000.dp)
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
                .drawBehind {
                    // Draw restrained cartography: 1. Dnipro River winding from top-right to bottom-right
                    val riverPath = Path().apply {
                        moveTo(900f, 0f)
                        quadraticTo(820f, 250f, 890f, 450f)
                        quadraticTo(980f, 650f, 920f, 1000f)
                    }
                    drawPath(
                        path = riverPath,
                        color = riverColor,
                        style = Stroke(width = 110.dp.toPx())
                    )

                    // Trukhaniv Island shape
                    drawCircle(
                        color = landColor,
                        radius = 80.dp.toPx(),
                        center = Offset(970f, 280f)
                    )

                    // Draw primary street grids (Podil network and Khreshchatyk corridor)
                    // Podil street grid
                    for (i in 0..5) {
                        drawLine(
                            color = gridColor,
                            start = Offset(600f + i * 30f, 40f),
                            end = Offset(660f + i * 30f, 180f),
                            strokeWidth = 2.dp.toPx()
                        )
                        drawLine(
                            color = gridColor,
                            start = Offset(580f, 50f + i * 24f),
                            end = Offset(810f, 80f + i * 24f),
                            strokeWidth = 2.dp.toPx()
                        )
                    }

                    // Khreshchatyk corridor
                    drawLine(
                        color = gridColor,
                        start = Offset(730f, 350f),
                        end = Offset(830f, 420f),
                        strokeWidth = 6.dp.toPx()
                    )

                    // Funicular track (dashed orange cableway)
                    drawLine(
                        color = Color(0xFFF97316),
                        start = Offset(700f, 200f),
                        end = Offset(710f, 150f),
                        strokeWidth = 3.dp.toPx(),
                        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
                    )

                    // Railway tracks
                    drawLine(
                        color = railColor,
                        start = Offset(300f, 500f),
                        end = Offset(400f, 400f),
                        strokeWidth = 4.dp.toPx()
                    )
                    drawLine(
                        color = railColor,
                        start = Offset(400f, 400f),
                        end = Offset(500f, 250f),
                        strokeWidth = 4.dp.toPx()
                    )
                }
        ) {
            // Draw Transit Icons & Labels
            for (p in GeographicData.Landmarks) {
                Box(
                    modifier = Modifier
                        .offset(x = p.x.dp - 12.dp, y = p.y.dp - 12.dp)
                        .size(24.dp)
                ) {
                    val badgeColor = when (p.type) {
                        "metro" -> KyivBlue
                        "funicular" -> Color(0xFFF97316)
                        "rail" -> Color(0xFF64748B)
                        else -> KyvYellow
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(badgeColor, RoundedCornerShape(4.dp))
                            .border(1.dp, Color.White, RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = p.type.take(1).uppercase(),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Landmark texts
                val label = if (lang == AppLanguage.UA) p.labelUa else p.labelEn
                Text(
                    text = label,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                    modifier = Modifier.offset(x = p.x.dp + 16.dp, y = p.y.dp - 6.dp)
                )
            }

            // Draw surface stops (tram, bus, trolleybus, tickets)
            for (stop in GeographicData.TransitStops) {
                val iconColor = when (stop.type) {
                    "tram" -> KyivGreen
                    "bus" -> KyivRed
                    "trolleybus" -> KyivBlue
                    "ticket" -> Color(0xFF0EA5E9)
                    else -> Color.DarkGray
                }

                Box(
                    modifier = Modifier
                        .offset(x = stop.x.dp - 6.dp, y = stop.y.dp - 6.dp)
                        .size(12.dp)
                        .background(iconColor, RoundedCornerShape(2.dp))
                        .border(1.dp, Color.White, RoundedCornerShape(2.dp))
                )

                val label = if (lang == AppLanguage.UA) stop.labelUa else stop.labelEn
                Text(
                    text = label,
                    fontSize = 8.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    modifier = Modifier.offset(x = stop.x.dp + 10.dp, y = stop.y.dp - 4.dp)
                )
            }
        }
    }
}
