package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 16.dp,
    borderWidth: Dp = 1.dp,
    glowOpacity: Float = 0.12f,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    
    // Choose backing color base depending on light/dark mode for ultimate legibility in dark/underground stations
    val baseColor = if (isDark) {
        Color(0x2A1D2025) // Translucent deep charcoal
    } else {
        Color(0xB0FFFFFF) // Translucent pure white
    }
    
    val borderColor = if (isDark) {
        Color(0x33FFFFFF) // Subtle glowing white border
    } else {
        Color(0x26121417) // Soft graphite outline
    }

    var cardModifier = modifier
        .clip(shape)
        .background(baseColor)
        .border(borderWidth, borderColor, shape)
        
    if (onClick != null) {
        cardModifier = cardModifier.clickable(onClick = onClick)
    }

    Column(
        modifier = cardModifier.padding(16.dp),
        content = content
    )
}

@Composable
fun GlassTile(
    modifier: Modifier = Modifier,
    isActive: Boolean = false,
    activeColor: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f
    val shape = RoundedCornerShape(12.dp)
    
    val baseColor = when {
        isActive -> activeColor.copy(alpha = 0.25f)
        isDark -> Color(0x1F2A2E35)
        else -> Color(0xF2F3F4F6)
    }

    val borderColor = when {
        isActive -> activeColor.copy(alpha = 0.6f)
        isDark -> Color(0x26FFFFFF)
        else -> Color(0x1A121417)
    }

    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clip(shape)
            .background(baseColor)
            .border(1.2.dp, borderColor, shape)
            .clickable(onClick = onClick)
            .padding(12.dp),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
fun GradientBackground(
    isDark: Boolean,
    content: @Composable BoxScope.() -> Unit
) {
    val colors = if (isDark) {
        listOf(
            Color(0xFF0F1113), // Deep basalt graphite
            Color(0xFF1B1D20), // Dark stone
            Color(0xFF121417)  // Pure charcoal
        )
    } else {
        listOf(
            Color(0xFFFAF8F5), // Warm white
            Color(0xFFF1EDE6), // Soft sand stone
            Color(0xFFEFECE5)  // Warm riverbed clay
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(
                    brush = Brush.radialGradient(
                        colors = if (isDark) {
                            listOf(Color(0xFF0D253A), Color(0xFF121417)) // Glow of Kyiv blue from bottom
                        } else {
                            listOf(Color(0xFFFBF9F6), Color(0xFFE5DFD4))
                        },
                        center = Offset(size.width * 0.5f, size.height * 1.1f),
                        radius = size.width * 1.3f
                    )
                )
            },
        content = content
    )
}
