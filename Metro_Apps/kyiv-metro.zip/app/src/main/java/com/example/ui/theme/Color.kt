package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kyiv Civic Branding Colors
val WarmWhite = Color(0xFFFAF8F5)
val Graphite = Color(0xFF121417)
val DeepCharcoal = Color(0xFF1D2025)
val LightGrey = Color(0xFFF3F4F6)
val CoolGrey = Color(0xFFE5E7EB)
val DarkGrey = Color(0xFF374151)

val KyivBlue = Color(0xFF005BAA)  // Blue Line Obolonsko-Teremkivska
val KyivRed = Color(0xFFD61827)   // Red Line Sviatoshynsko-Brovarska
val KyivGreen = Color(0xFF009C5A) // Green Line Syretsko-Pecherska
val KyvYellow = Color(0xFFEAAA08)  // Accent Yellow Wayfinding

// Light Scheme Colors
val LightPrimary = KyivBlue
val LightOnPrimary = Color.White
val LightPrimaryContainer = Color(0xFFE0F2FE)
val LightOnPrimaryContainer = Color(0xFF0369A1)
val LightSecondary = KyivGreen
val LightBackground = WarmWhite
val LightSurface = Color.White
val LightOnBackground = Graphite
val LightOnSurface = Graphite

// Dark Scheme Colors
val DarkPrimary = Color(0xFF38BDF8)
val DarkOnPrimary = Graphite
val DarkPrimaryContainer = Color(0xFF0C4A6E)
val DarkOnPrimaryContainer = Color(0xFFE0F2FE)
val DarkSecondary = Color(0xFF4ADE80)
val DarkBackground = Graphite
val DarkSurface = DeepCharcoal
val DarkOnBackground = WarmWhite
val DarkOnSurface = WarmWhite
