package com.example.ui.components

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.AppLanguage

// Coordinates for schematic stations (scaled coordinates)
data class MapCoord(val x: Float, val y: Float)

object MapCoords {
    val positions = mapOf(
        // Red Line (Horizontal, top to bottom sweep)
        "akademmistechko" to MapCoord(50f, 100f),
        "zhytomyrska" to MapCoord(120f, 150f),
        "sviatoshyn" to MapCoord(190f, 200f),
        "nyvky" to MapCoord(260f, 250f),
        "beresteiska" to MapCoord(330f, 300f),
        "shuliavska" to MapCoord(400f, 350f),
        "politekhnichnyi" to MapCoord(470f, 400f),
        "vokzalna" to MapCoord(540f, 450f),
        "universytet" to MapCoord(610f, 500f),
        "teatralna" to MapCoord(700f, 500f), // Intersection with Zoloti Vorota (700, 560)
        "khreshchatyk" to MapCoord(790f, 500f), // Intersection with Maidan (790, 420)
        "arsenalna" to MapCoord(870f, 550f),
        "dnipro" to MapCoord(940f, 600f),
        "hidropark" to MapCoord(1010f, 650f),
        "livoberezhna" to MapCoord(1080f, 700f),
        "darnytsia" to MapCoord(1150f, 750f),
        "chernihivska" to MapCoord(1220f, 800f),
        "lisova" to MapCoord(1290f, 850f),

        // Blue Line (Vertical sweep, left side of center to bottom-right)
        "heroiv_dnipra" to MapCoord(790f, 50f),
        "minska" to MapCoord(790f, 110f),
        "obolon" to MapCoord(790f, 170f),
        "pochaina" to MapCoord(790f, 230f),
        "tarasa_shevchenka" to MapCoord(790f, 290f),
        "kontraktova" to MapCoord(790f, 350f),
        "poshtova" to MapCoord(790f, 410f),
        "maidan" to MapCoord(790f, 470f), // Intersection with Khreshchatyk
        "ploshcha_heroyiv" to MapCoord(790f, 590f), // Intersection with Palats Sportu (700, 590)
        "olimpiiska" to MapCoord(790f, 670f),
        "palats_ukraina" to MapCoord(790f, 730f),
        "lybidska" to MapCoord(790f, 790f),
        "demiivska" to MapCoord(790f, 850f),
        "holosiivska" to MapCoord(790f, 910f),
        "vasylkivska" to MapCoord(790f, 970f),
        "vystavkovyi" to MapCoord(790f, 1030f),
        "ipodrom" to MapCoord(790f, 1090f),
        "teremky" to MapCoord(790f, 1150f),

        // Green Line (Diagonal sweep, bottom-left to bottom-right)
        "syrets" to MapCoord(430f, 200f),
        "dorogozhychi" to MapCoord(500f, 270f),
        "lukianivska" to MapCoord(580f, 370f),
        "zoloti_vorota" to MapCoord(700f, 470f), // Interchange with Teatralna
        "palats_sportu" to MapCoord(740f, 590f), // Interchange with Ploshcha Heroyiv
        "klovska" to MapCoord(870f, 650f),
        "pecherska" to MapCoord(940f, 710f),
        "zvirynetska" to MapCoord(1010f, 770f),
        "vydubychi" to MapCoord(1080f, 830f),
        "slavutych" to MapCoord(1150f, 890f),
        "osokorky" to MapCoord(1220f, 950f),
        "pozniaky" to MapCoord(1290f, 1010f),
        "kharkivska" to MapCoord(1360f, 1070f),
        "vyrlytsia" to MapCoord(1430f, 1130f),
        "boryspilska" to MapCoord(1500f, 1190f),
        "chervonyi_khutir" to MapCoord(1570f, 1250f)
    )
}

@Composable
fun SchematicMapView(
    lang: AppLanguage,
    disabledStations: List<String>,
    suspendedLines: List<String>,
    highlightedLegs: List<RouteLeg>? = null,
    onStationSelected: (Station) -> Unit
) {
    // Collect active highlighted stations from routing
    val highlightedStationIds = remember(highlightedLegs) {
        val set = mutableSetOf<String>()
        highlightedLegs?.forEach { leg ->
            when (leg) {
                is RouteLeg.TrainRide -> {
                    val line = MetroData.Lines.find { it.id == leg.lineId }
                    if (line != null) {
                        val startIndex = line.stations.indexOf(leg.fromId)
                        val endIndex = line.stations.indexOf(leg.toId)
                        if (startIndex != -1 && endIndex != -1) {
                            val step = if (startIndex < endIndex) 1 else -1
                            var i = startIndex
                            while (i != endIndex + step) {
                                set.add(line.stations[i])
                                i += step
                            }
                        }
                    }
                    set.add(leg.fromId)
                    set.add(leg.toId)
                }
                is RouteLeg.Interchange -> {
                    set.add(leg.stationFromId)
                    set.add(leg.stationToId)
                }
                is RouteLeg.WalkToStation -> set.add(leg.stationId)
                is RouteLeg.WalkToDestination -> set.add(leg.stationId)
            }
        }
        set
    }

    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val transformState = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.6f, 2.5f)
        offset += offsetChange
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
            .transformable(state = transformState)
            .horizontalScroll(rememberScrollState())
            .verticalScroll(rememberScrollState())
    ) {
        // Draw the main schematic map
        Box(
            modifier = Modifier
                .width(1700.dp)
                .height(1300.dp)
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
                .drawBehind {
                    // 1. Draw static metro track lines
                    for (line in MetroData.Lines) {
                        val isSuspended = suspendedLines.contains(line.id)
                        val strokeColor = if (isSuspended) Color.Gray.copy(alpha = 0.5f) else line.color

                        for (i in 0 until line.stations.size - 1) {
                            val s1 = line.stations[i]
                            val s2 = line.stations[i + 1]

                            val coord1 = MapCoords.positions[s1]
                            val coord2 = MapCoords.positions[s2]

                            if (coord1 != null && coord2 != null) {
                                val isTrackHighlighted = highlightedStationIds.contains(s1) && highlightedStationIds.contains(s2)
                                drawLine(
                                    color = if (highlightedLegs != null && !isTrackHighlighted) strokeColor.copy(alpha = 0.2f) else strokeColor,
                                    start = Offset(coord1.x.dp.toPx(), coord1.y.dp.toPx()),
                                    end = Offset(coord2.x.dp.toPx(), coord2.y.dp.toPx()),
                                    strokeWidth = if (isTrackHighlighted) 8.dp.toPx() else 4.dp.toPx()
                                )
                            }
                        }
                    }

                    // 2. Draw interchange dashed bridges
                    val interchanges = listOf(
                        Pair("khreshchatyk", "maidan"),
                        Pair("teatralna", "zoloti_vorota"),
                        Pair("ploshcha_heroyiv", "palats_sportu")
                    )

                    for (bridge in interchanges) {
                        val c1 = MapCoords.positions[bridge.first]
                        val c2 = MapCoords.positions[bridge.second]
                        if (c1 != null && c2 != null) {
                            val isBridgeHighlighted = highlightedStationIds.contains(bridge.first) && highlightedStationIds.contains(bridge.second)
                            drawLine(
                                color = if (highlightedLegs != null && !isBridgeHighlighted) Color.LightGray.copy(alpha = 0.3f) else Color.DarkGray,
                                start = Offset(c1.x.dp.toPx(), c1.y.dp.toPx()),
                                end = Offset(c2.x.dp.toPx(), c2.y.dp.toPx()),
                                strokeWidth = 3.dp.toPx(),
                                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                            )
                        }
                    }
                }
        ) {
            // 3. Place clickable stations on top of the tracks
            for (station in MetroData.Stations.values) {
                val coord = MapCoords.positions[station.id] ?: continue
                val line = MetroData.Lines.find { it.id == station.lineId }
                val isDisabled = disabledStations.contains(station.id)
                val isHighlighted = highlightedStationIds.contains(station.id)

                val nodeColor = when {
                    isDisabled -> Color.DarkGray
                    line != null -> line.color
                    else -> Color.Gray
                }

                Box(
                    modifier = Modifier
                        .offset(x = coord.x.dp - 24.dp, y = coord.y.dp - 24.dp)
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable { onStationSelected(station) }
                        .testTag("station_node_${station.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .background(
                                if (highlightedLegs != null && !isHighlighted) nodeColor.copy(alpha = 0.3f) else nodeColor,
                                CircleShape
                            )
                            .border(2.dp, Color.White, CircleShape)
                    )
                }

                // Station labels (Beautiful multilingual Grotesk wayfinding labels)
                val labelText = if (lang == AppLanguage.UA) station.nameUa else station.nameEn
                Box(
                    modifier = Modifier
                        .offset(x = coord.x.dp + 18.dp, y = coord.y.dp - 10.dp)
                        .width(130.dp)
                ) {
                    Text(
                        text = labelText,
                        fontSize = 11.sp,
                        fontWeight = if (station.isInterchange) FontWeight.Bold else FontWeight.Normal,
                        color = when {
                            isDisabled -> Color.Gray
                            highlightedLegs != null && !isHighlighted -> MaterialTheme.colorScheme.onBackground.copy(alpha = 0.25f)
                            else -> MaterialTheme.colorScheme.onBackground
                        },
                        lineHeight = 12.sp
                    )
                }
            }

            // Directional Labels & Terminal Labels
            Box(
                modifier = Modifier
                    .offset(x = 30.dp, y = 80.dp)
                    .background(Color.Black.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                    .padding(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.East, contentDescription = null, tint = MetroData.RedLineColor, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (lang == AppLanguage.UA) "М1 СВЯТОШИНСЬКО-БРОВАРСЬКА" else "M1 SVIATOSHYNSKO-BROVARSKA",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroData.RedLineColor
                    )
                }
            }

            Box(
                modifier = Modifier
                    .offset(x = 810.dp, y = 15.dp)
                    .background(Color.Black.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                    .padding(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.South, contentDescription = null, tint = MetroData.BlueLineColor, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (lang == AppLanguage.UA) "М2 ОБЛОНСЬКО-ТЕРЕМКІВСЬКА" else "M2 OBOLONSKO-TEREMKIVSKA",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroData.BlueLineColor
                    )
                }
            }

            Box(
                modifier = Modifier
                    .offset(x = 380.dp, y = 160.dp)
                    .background(Color.Black.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                    .padding(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.SouthEast, contentDescription = null, tint = MetroData.GreenLineColor, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (lang == AppLanguage.UA) "М3 СИРЕЦЬКО-ПЕЧЕРСЬКА" else "M3 SYRETSKO-PECHERSKA",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroData.GreenLineColor
                    )
                }
            }
        }
    }
}
