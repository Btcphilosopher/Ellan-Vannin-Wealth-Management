package com.example.data

import java.util.PriorityQueue

// --- ROUTER GRAPH MODELS ---

data class RouteNode(
    val stationId: String,
    val totalTime: Int,
    val path: List<RouteLeg>
) : Comparable<RouteNode> {
    override fun compareTo(other: RouteNode): Int = this.totalTime.compareTo(other.totalTime)
}

sealed class RouteLeg {
    data class WalkToStation(val stationId: String, val timeMinutes: Int) : RouteLeg()
    data class TrainRide(val lineId: String, val fromId: String, val toId: String, val stationsPassedCount: Int, val timeMinutes: Int) : RouteLeg()
    data class Interchange(val fromLineId: String, val toLineId: String, val stationFromId: String, val stationToId: String, val timeMinutes: Int) : RouteLeg()
    data class WalkToDestination(val stationId: String, val timeMinutes: Int) : RouteLeg()
}

// Router Preferences
data class RoutingPreference(
    val fastest: Boolean = true,
    val fewestTransfers: Boolean = false,
    val stepFreeOnly: Boolean = false,
    val leastWalking: Boolean = false,
    val metroOnly: Boolean = false
)

object Router {

    // Helper to perform transliteration-aware search
    fun searchStations(query: String): List<Station> {
        val cleanQuery = query.trim().lowercase()
        if (cleanQuery.isEmpty()) return emptyList()

        return MetroData.Stations.values.filter { station ->
            val nameUa = station.nameUa.lowercase()
            val nameEn = station.nameEn.lowercase()
            
            // Text matching
            nameUa.contains(cleanQuery) ||
            nameEn.contains(cleanQuery) ||
            station.transliterations.any { it.lowercase().contains(cleanQuery) } ||
            // Simple transliteration mappings
            transliterate(cleanQuery).contains(cleanQuery) ||
            transliterate(nameUa).contains(cleanQuery) ||
            // Custom station synonyms
            (cleanQuery == "vokzal" && station.id == "vokzalna") ||
            (cleanQuery == "вокзал" && station.id == "vokzalna") ||
            (cleanQuery == "майдан" && station.id == "maidan") ||
            (cleanQuery == "хрещатик" && station.id == "khreshchatyk") ||
            (cleanQuery == "центр" && (station.id == "khreshchatyk" || station.id == "maidan" || station.id == "zoloti_vorota"))
        }
    }

    // Transliterate cyrillic to latin for smart search mapping
    private fun transliterate(input: String): String {
        val uaLetters = mapOf(
            'а' to "a", 'б' to "b", 'в' to "v", 'г' to "h", 'ґ' to "g", 'д' to "d",
            'е' to "e", 'є' to "ye", 'ж' to "zh", 'з' to "z", 'и' to "y", 'і' to "i",
            'ї' to "yi", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n",
            'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u",
            'ф' to "f", 'х' to "kh", 'ц' to "ts", 'ч' to "ch", 'ш' to "sh", 'щ' to "shch",
            'ь' to "", 'ю' to "yu", 'я' to "ya", '\'' to ""
        )
        val sb = StringBuilder()
        for (char in input) {
            val mapped = uaLetters[char]
            if (mapped != null) {
                sb.append(mapped)
            } else {
                sb.append(char)
            }
        }
        return sb.toString()
    }

    // --- DIJKSTRA'S SHORTEST PATH ROUTING ENGINE ---

    fun planRoute(
        fromId: String,
        toId: String,
        preference: RoutingPreference = RoutingPreference(),
        disabledStations: Set<String> = emptySet(),
        suspendedLines: Set<String> = emptySet()
    ): List<RouteLeg>? {
        if (!MetroData.Stations.containsKey(fromId) || !MetroData.Stations.containsKey(toId)) return null
        if (fromId == toId) return listOf(RouteLeg.WalkToDestination(fromId, 0))

        // Build Graph representation dynamically to account for service alerts / closures
        val adjacency = mutableMapOf<String, MutableList<GraphEdge>>()

        // 1. Train edges (adjacent stations on the same line)
        for (line in MetroData.Lines) {
            if (suspendedLines.contains(line.id)) continue

            for (i in 0 until line.stations.size - 1) {
                val s1 = line.stations[i]
                val s2 = line.stations[i + 1]

                if (disabledStations.contains(s1) || disabledStations.contains(s2)) continue

                // Under normal service, typical travel time is 2 minutes
                val normalWeight = 2 
                
                adjacency.getOrPut(s1) { mutableListOf() }.add(GraphEdge(s2, normalWeight, line.id, isInterchange = false))
                adjacency.getOrPut(s2) { mutableListOf() }.add(GraphEdge(s1, normalWeight, line.id, isInterchange = false))
            }
        }

        // 2. Physical interchanges
        for (station in MetroData.Stations.values) {
            if (disabledStations.contains(station.id)) continue

            if (station.isInterchange && station.interchangeStationId != null && station.interchangeLineId != null) {
                val targetStationId = station.interchangeStationId
                val targetLineId = station.interchangeLineId

                if (!disabledStations.contains(targetStationId) && !suspendedLines.contains(station.lineId) && !suspendedLines.contains(targetLineId)) {
                    // Check step-free accessibility filter
                    val fromAcc = station.accessibility
                    val targetStation = MetroData.Stations[targetStationId]
                    val toAcc = targetStation?.accessibility

                    val isStepFreeInterchange = fromAcc.hasElevators || fromAcc.hasRamps
                    
                    if (preference.stepFreeOnly && !isStepFreeInterchange) {
                        // Skip or heavily penalize this physical transfer
                        continue
                    }

                    // A standard interchange walk takes about 4 minutes.
                    // If fewestTransfers is enabled, we add a transfer penalty of 15 minutes to deter transfers.
                    val weight = if (preference.fewestTransfers) 20 else 4

                    adjacency.getOrPut(station.id) { mutableListOf() }.add(
                        GraphEdge(targetStationId, weight, lineId = station.lineId, isInterchange = true, targetLineId = targetLineId)
                    )
                    adjacency.getOrPut(targetStationId) { mutableListOf() }.add(
                        GraphEdge(station.id, weight, lineId = targetLineId, isInterchange = true, targetLineId = station.lineId)
                    )
                }
            }
        }

        // --- DIJKSTRA ALGORITHM ---
        val pq = PriorityQueue<RouteNode>()
        val minTimes = mutableMapOf<String, Int>()

        pq.add(RouteNode(fromId, 0, emptyList()))
        minTimes[fromId] = 0

        while (pq.isNotEmpty()) {
            val current = pq.poll()
            val u = current.stationId

            if (u == toId) {
                return current.path
            }

            if (current.totalTime > (minTimes[u] ?: Int.MAX_VALUE)) continue

            val edges = adjacency[u] ?: emptyList()
            for (edge in edges) {
                val v = edge.targetStationId
                val edgeWeight = edge.weight

                // Accessibility check on target station
                val targetStation = MetroData.Stations[v]
                if (preference.stepFreeOnly && targetStation != null) {
                    val acc = targetStation.accessibility
                    if (!acc.hasElevators && !acc.hasRamps && !acc.hasTactilePaving) {
                        // Skip if totally inaccessible
                        continue
                    }
                }

                val newTime = current.totalTime + edgeWeight

                if (newTime < (minTimes[v] ?: Int.MAX_VALUE)) {
                    minTimes[v] = newTime

                    // Construct new route leg list
                    val newPath = current.path.toMutableList()
                    if (edge.isInterchange) {
                        newPath.add(
                            RouteLeg.Interchange(
                                fromLineId = edge.lineId,
                                toLineId = edge.targetLineId ?: "",
                                stationFromId = u,
                                stationToId = v,
                                timeMinutes = edgeWeight
                            )
                        )
                    } else {
                        // Consolidate adjacent train rides if possible to make the leg list cleaner
                        val lastLeg = newPath.lastOrNull()
                        if (lastLeg is RouteLeg.TrainRide && lastLeg.lineId == edge.lineId && lastLeg.toId == u) {
                            // Update last ride to go further
                            newPath.removeAt(newPath.size - 1)
                            newPath.add(
                                RouteLeg.TrainRide(
                                    lineId = edge.lineId,
                                    fromId = lastLeg.fromId,
                                    toId = v,
                                    stationsPassedCount = lastLeg.stationsPassedCount + 1,
                                    timeMinutes = lastLeg.timeMinutes + edgeWeight
                                )
                            )
                        } else {
                            newPath.add(
                                RouteLeg.TrainRide(
                                    lineId = edge.lineId,
                                    fromId = u,
                                    toId = v,
                                    stationsPassedCount = 1,
                                    timeMinutes = edgeWeight
                                )
                            )
                        }
                    }

                    pq.add(RouteNode(v, newTime, newPath))
                }
            }
        }

        return null // No path found (isolated network)
    }

    private data class GraphEdge(
        val targetStationId: String,
        val weight: Int,
        val lineId: String,
        val isInterchange: Boolean,
        val targetLineId: String? = null
    )
}
