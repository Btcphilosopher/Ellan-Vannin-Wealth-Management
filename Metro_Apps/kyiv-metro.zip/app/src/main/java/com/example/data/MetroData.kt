package com.example.data

import androidx.compose.ui.graphics.Color

// --- DOMAIN MODELS ---

data class MetroLine(
    val id: String,
    val nameUa: String,
    val nameEn: String,
    val color: Color,
    val stations: List<String> // list of station IDs
)

data class Station(
    val id: String,
    val nameUa: String,
    val nameEn: String,
    val transliterations: List<String>,
    val lineId: String,
    val isInterchange: Boolean,
    val interchangeStationId: String? = null,
    val interchangeLineId: String? = null,
    val accessibility: StationAccessibility,
    val exits: List<StationExit>,
    val landmarks: List<String>,
    val isTerminal: Boolean = false,
    val directions: List<String> = emptyList() // Next major stations / terminals
)

data class StationExit(
    val id: String,
    val nameUa: String,
    val nameEn: String,
    val landmarksUa: List<String>,
    val landmarksEn: List<String>,
    val streetUa: String,
    val streetEn: String,
    val isAccessible: Boolean,
    val walkTimeMinutes: Int
)

data class StationAccessibility(
    val hasElevators: Boolean,
    val hasRamps: Boolean,
    val hasTactilePaving: Boolean,
    val audioFriendly: Boolean,
    val notesUa: String,
    val notesEn: String
)

enum class NetworkStatus {
    NORMAL,
    MINOR_DELAY,
    MAJOR_DELAY,
    SUSPENDED,
    STATION_CLOSED,
    PLANNED_WORKS,
    REDUCED_SERVICE
}

data class ServiceAlert(
    val id: String,
    val lineId: String?,
    val stationId: String?,
    val typeUa: String,
    val typeEn: String,
    val titleUa: String,
    val titleEn: String,
    val descriptionUa: String,
    val descriptionEn: String,
    val affectedRoutesUa: String,
    val affectedRoutesEn: String,
    val alternativeUa: String,
    val alternativeEn: String,
    val timestamp: Long,
    val expectedDurationUa: String,
    val expectedDurationEn: String,
    val isDemo: Boolean = true
)

data class Departure(
    val lineId: String,
    val stationId: String,
    val directionId: String, // Destination Station ID
    val directionNameUa: String,
    val directionNameEn: String,
    val minutesLeft: Int,
    val platform: String,
    val isSimulated: Boolean = true
)

// --- TICKET MODELS ---

enum class TicketType {
    SINGLE_QR,
    TRANSPORT_CARD,
    DIGITAL_CARD,
    MONTHLY_PASS
}

data class FareProduct(
    val id: String,
    val type: TicketType,
    val nameUa: String,
    val nameEn: String,
    val priceUah: Double,
    val descriptionUa: String,
    val descriptionEn: String
)

data class Landmark(
    val id: String,
    val nameUa: String,
    val nameEn: String,
    val descriptionUa: String,
    val descriptionEn: String,
    val nearestStationId: String,
    val walkMinutes: Int,
    val howToGetUa: String,
    val howToGetEn: String,
    val category: String // "culture", "nature", "transport", "historic"
)

// --- REPOSITORY LAYER ---

object MetroData {

    val RedLineColor = Color(0xFFD61827)   // Red Sviatoshynsko-Brovarska
    val BlueLineColor = Color(0xFF005BAA)  // Blue Obolonsko-Teremkivska
    val GreenLineColor = Color(0xFF009C5A) // Green Syretsko-Pecherska

    val Lines = listOf(
        MetroLine("red", "Святошинсько-Броварська", "Sviatoshynsko-Brovarska", RedLineColor, listOf(
            "akademmistechko", "zhytomyrska", "sviatoshyn", "nyvky", "beresteiska", "shuliavska",
            "politekhnichnyi", "vokzalna", "universytet", "teatralna", "khreshchatyk",
            "arsenalna", "dnipro", "hidropark", "livoberezhna", "darnytsia", "chernihivska", "lisova"
        )),
        MetroLine("blue", "Оболонсько-Теремківська", "Obolonsko-Teremkivska", BlueLineColor, listOf(
            "heroiv_dnipra", "minska", "obolon", "pochaina", "tarasa_shevchenka", "kontraktova",
            "poshtova", "maidan", "ploshcha_heroyiv", "olimpiiska", "palats_ukraina", "lybidska",
            "demiivska", "holosiivska", "vasylkivska", "vystavkovyi", "ipodrom", "teremky"
        )),
        MetroLine("green", "Сирецько-Печерська", "Syretsko-Pecherska", GreenLineColor, listOf(
            "syrets", "dorogozhychi", "lukianivska", "zoloti_vorota", "palats_sportu", "klovska",
            "pecherska", "zvirynetska", "vydubychi", "slavutych", "osokorky", "pozniaky",
            "kharkivska", "vyrlytsia", "boryspilska", "chervonyi_khutir"
        ))
    )

    val Stations = mapOf(
        // --- RED LINE ---
        "akademmistechko" to Station(
            "akademmistechko", "Академмістечко", "Akademmistechko",
            listOf("akadem", "akademgorodok"), "red", false, null, null,
            StationAccessibility(true, true, true, true, "Обладнано ліфтами та пандусами", "Equipped with elevators and ramps"),
            listOf(
                StationExit("1", "Вихід 1", "Exit 1", listOf("Проспект Палладіна"), listOf("Palladina Avenue"), "Проспект Палладіна", "Palladina Avenue", true, 2)
            ),
            listOf("Академмістечко житловий масив"), isTerminal = true, directions = listOf("Лісова")
        ),
        "zhytomyrska" to Station(
            "zhytomyrska", "Житомирська", "Zhytomyrska",
            listOf("jitomirska"), "red", false, null, null,
            StationAccessibility(true, false, true, true, "Частково пристосовано", "Partially accessible"),
            listOf(
                StationExit("1", "Вихід 1", "Exit 1", listOf("ТЦ VMB"), listOf("VMB Mall"), "Перемоги проспект", "Peremohy Avenue", false, 3)
            ),
            listOf("ТЦ VMB")
        ),
        "sviatoshyn" to Station(
            "sviatoshyn", "Святошин", "Sviatoshyn",
            listOf("sviatoshino"), "red", false, null, null,
            StationAccessibility(true, true, true, true, "Повна доступність, ліфти до залізничної платформи", "Full accessibility, elevators to railway platform"),
            listOf(
                StationExit("1", "Вихід 1", "Exit 1", listOf("Залізнична станція Святошин", "Регіональні поїзди"), listOf("Sviatoshyn Railway Station", "Regional trains"), "Депутатська вулиця", "Deputatska Street", true, 1),
                StationExit("2", "Вихід 2", "Exit 2", listOf("Ринок Святошин"), listOf("Sviatoshyn Market"), "проспект Перемоги", "Peremohy Avenue", true, 2)
            ),
            listOf("Залізнична станція Святошин")
        ),
        "nyvky" to Station(
            "nyvky", "Нивки", "Nyvky",
            listOf("nivki"), "red", false, null, null,
            StationAccessibility(false, true, true, true, "Пандуси на виходах", "Ramps at exits"),
            listOf(),
            listOf("Парк Нивки")
        ),
        "beresteiska" to Station(
            "beresteiska", "Берестейська", "Beresteiska",
            listOf(), "red", false, null, null,
            StationAccessibility(false, false, true, true, "Тільки сходи", "Stairs only"),
            listOf(),
            listOf("Парк Нивки", "Київський національний економічний університет")
        ),
        "shuliavska" to Station(
            "shuliavska", "Шулявська", "Shuliavska",
            listOf("shulyavka"), "red", false, null, null,
            StationAccessibility(false, false, true, true, "Глибоке закладення, ескалатори", "Deep station, escalators only"),
            listOf(),
            listOf("Парк ім. Пушкіна", "КПІ корпус 18")
        ),
        "politekhnichnyi" to Station(
            "politekhnichnyi", "Політехнічний інститут", "Politekhnichnyi Instytut",
            listOf("kpi", "polytech"), "red", false, null, null,
            StationAccessibility(false, false, true, true, "Ескалатори, без ліфтів", "Escalators, no elevators"),
            listOf(),
            listOf("Київський політехнічний інститут імені Ігоря Сікорського", "Київський зоопарк")
        ),
        "vokzalna" to Station(
            "vokzalna", "Вокзальна", "Vokzalna",
            listOf("vokzal", "train station", "central station"), "red", false, null, null,
            StationAccessibility(false, false, true, true, "Надзвичайно високий потік. Сходи та ескалатори. Допомога супроводу доступна", "Extremely busy. Stairs and escalators. Assistance staff available"),
            listOf(
                StationExit("1", "Центральний вихід", "Main Exit", listOf("Центральний залізничний вокзал", "Вокзальна площа", "Трамвай"), listOf("Central Railway Station", "Vokzalna Square", "Tramway"), "Вокзальна площа", "Vokzalna Square", false, 1)
            ),
            listOf("Центральний залізничний вокзал", "Приміський вокзал", "Швидкісний трамвай")
        ),
        "universytet" to Station(
            "universytet", "Університет", "Universytet",
            listOf("university"), "red", false, null, null,
            StationAccessibility(false, false, true, true, "Архітектурна пам'ятка. Тільки ескалатори", "Architectural landmark. Escalators only"),
            listOf(),
            listOf("Київський національний університет імені Тараса Шевченка", "Ботанічний сад ім. Фоміна")
        ),
        "teatralna" to Station(
            "teatralna", "Театральна", "Teatralna",
            listOf("theater"), "red", true, "zoloti_vorota", "green",
            StationAccessibility(false, false, true, true, "Пересадка через підземний перехід (сходи та ескалатор)", "Transfer via underground passage (stairs and escalator)"),
            listOf(
                StationExit("1", "Вихід до вул. Богдана Хмельницького", "Exit to Bohdana Khmelnytskoho St", listOf("Музей Історії Києва", "Театр Лесі Українки"), listOf("Museum of Kyiv History", "Lesia Ukrainka Theater"), "Вулиця Богдана Хмельницького", "Bohdana Khmelnytskoho Street", false, 2)
            ),
            listOf("Національний академічний театр російської драми ім. Лесі Українки", "Музей Історії Києва")
        ),
        "khreshchatyk" to Station(
            "khreshchatyk", "Хрещатик", "Khreshchatyk",
            listOf("khreschatyk", "kreshchatik", "crestatic"), "red", true, "maidan", "blue",
            StationAccessibility(false, false, true, true, "Центральний вузол пересадки. Ескалатори", "Central interchange hub. Escalators only"),
            listOf(
                StationExit("1", "Вихід 1 — вул. Хрещатик", "Exit 1 — Khreshchatyk St", listOf("Вулиця Хрещатик", "Пасаж", "ЦУМ"), listOf("Khreshchatyk Street", "Passage", "TSUM"), "Вулиця Хрещатик", "Khreshchatyk Street", false, 1),
                StationExit("2", "Вихід 2 — вул. Інститутська", "Exit 2 — Instytutska St", listOf("Вулиця Інститутська", "Національний Банк України"), listOf("Instytutska Street", "National Bank of Ukraine"), "Вулиця Інститутська", "Instytutska Street", false, 3),
                StationExit("3", "Вихід 3 — вул. Городецького", "Exit 3 — Horodetskoho St", listOf("Театр Івана Франка", "Майдан Незалежності"), listOf("Ivan Franko Theater", "Independence Square"), "Вулиця Архітектора Городецького", "Arkhitektora Horodetskoho Street", false, 4)
            ),
            listOf("Вулиця Хрещатик", "Майдан Незалежності", "Київський Пасаж", "ЦУМ")
        ),
        "arsenalna" to Station(
            "arsenalna", "Арсенальна", "Arsenalna",
            listOf(), "red", false, null, null,
            StationAccessibility(false, false, true, true, "Найглибша станція метро у світі (105.5 м). Тільки ескалатори. Довгий спуск (близько 5 хвилин)", "Deepest metro station in the world (105.5m). Escalators only. Long descent (approx. 5 mins)"),
            listOf(
                StationExit("1", "Вихід до Арсенальної площі", "Exit to Arsenalna Square", listOf("Києво-Печерська Лавра", "Парк Вічної Слави", "A-Station"), listOf("Kyiv-Pechersk Lavra", "Park of Eternal Glory", "A-Station"), "Арсенальна площа", "Arsenalna Square", false, 1)
            ),
            listOf("Києво-Печерська Лавра", "Маріїнський парк", "Художній Арсенал", "A-Station")
        ),
        "dnipro" to Station(
            "dnipro", "Дніпро", "Dnipro",
            listOf("dnepr"), "red", false, null, null,
            StationAccessibility(true, false, true, true, "Естакадна відкрита станція. Обладнана підйомниками за запитом", "Elevated open station. Equipped with lifts upon request"),
            listOf(),
            listOf("Річка Дніпро", "Набережна", "Пам'ятник засновникам Києва")
        ),
        "hidropark" to Station(
            "hidropark", "Гідропарк", "Hidropark",
            listOf("gidropark"), "red", false, null, null,
            StationAccessibility(false, true, true, true, "Наземна станція. Доступна через пандуси", "Ground-level station. Accessible via ramps"),
            listOf(),
            listOf("Парк розваг Гідропарк", "Пляжі Дніпра", "Київ у мініатюрі")
        ),
        "livoberezhna" to Station(
            "livoberezhna", "Лівобережна", "Livoberezhna",
            listOf("levoberezhnaya"), "red", false, null, null,
            StationAccessibility(true, true, true, true, "Наземна станція з ліфтами та тактильними смугами", "Ground-level station with elevators and tactile lines"),
            listOf(),
            listOf("Міжнародний виставковий центр (МВЦ)", "Русанівка")
        ),
        "darnytsia" to Station(
            "darnytsia", "Дарниця", "Darnytsia",
            listOf("darnitsa"), "red", false, null, null,
            StationAccessibility(false, true, true, true, "Частково пристосовано", "Partially accessible"),
            listOf(),
            listOf("Парк Перемога", "ТЦ Дитячий Світ")
        ),
        "chernihivska" to Station(
            "chernihivska", "Чернігівська", "Chernihivska",
            listOf("chernigovskaya"), "red", false, null, null,
            StationAccessibility(false, true, true, true, "Наземна станція", "Ground-level station"),
            listOf(),
            listOf("ТЦ Даринок", "Арт-завод Платформа")
        ),
        "lisova" to Station(
            "lisova", "Лісова", "Lisova",
            listOf("lesovaya"), "red", false, null, null,
            StationAccessibility(true, true, true, true, "Обладнано підйомниками та пандусами", "Equipped with lifts and ramps"),
            listOf(),
            listOf("Маркет-молл Даринок", "Автостанція Дарниця"), isTerminal = true, directions = listOf("Академмістечко")
        ),

        // --- BLUE LINE ---
        "heroiv_dnipra" to Station(
            "heroiv_dnipra", "Героїв Дніпра", "Heroiv Dnipra",
            listOf("geroev dnepra"), "blue", false, null, null,
            StationAccessibility(false, true, true, true, "Мілка станція, обладнана пандусами", "Shallow station equipped with ramps"),
            listOf(),
            listOf("Ринок Героїв Дніпра", "ТЦ Оазис"), isTerminal = true, directions = listOf("Теремки")
        ),
        "minska" to Station(
            "minska", "Мінська", "Minska",
            listOf(), "blue", false, null, null,
            StationAccessibility(false, true, true, true, "Обладнано пандусами на виходах", "Equipped with ramps at exits"),
            listOf(),
            listOf("Мінська площа", "ТЦ Dream Town 1")
        ),
        "obolon" to Station(
            "obolon", "Оболонь", "Obolon",
            listOf(), "blue", false, null, null,
            StationAccessibility(false, true, true, true, "Частково пристосовано", "Partially accessible"),
            listOf(),
            listOf("ТЦ Dream Town 2", "Оболонська набережна")
        ),
        "pochaina" to Station(
            "pochaina", "Почайна", "Pochaina",
            listOf("petrivka", "petrovka"), "blue", false, null, null,
            StationAccessibility(true, true, true, true, "Обладнана тактильною плиткою та ліфтами", "Equipped with tactile paving and elevators"),
            listOf(
                StationExit("1", "Вихід до залізничної станції Почайна", "Exit to Pochaina Railway Station", listOf("Книжковий ринок Петрівка", "Залізнична зупинка Почайна"), listOf("Petrivka Book Market", "Pochaina Train Stop"), "вулиця Вербова", "Verbova Street", true, 2)
            ),
            listOf("Книжковий ринок Петрівка", "ТЦ Городок", "Блошиний ринок")
        ),
        "tarasa_shevchenka" to Station(
            "tarasa_shevchenka", "Тараса Шевченка", "Tarasa Shevchenka",
            listOf("shevchenka"), "blue", false, null, null,
            StationAccessibility(false, true, true, true, "Частково пристосовано", "Partially accessible"),
            listOf(),
            listOf("Поділ промисловий", "Тенісний клуб Корт")
        ),
        "kontraktova" to Station(
            "kontraktova", "Контрактова площа", "Kontraktova Ploshcha",
            listOf("kontraktova ploshcha", "podil"), "blue", false, null, null,
            StationAccessibility(false, true, true, true, "Мілка станція. Тільки сходи та пандуси", "Shallow station. Stairs and ramps only"),
            listOf(
                StationExit("1", "Вихід до Контрактової площі", "Exit to Kontraktova Square", listOf("Києво-Могилянська Академія", "Гостинний Двір", "Колесо огляду"), listOf("Kyiv-Mohyla Academy", "Hostynnyi Dvor", "Ferris Wheel"), "Контрактова площа", "Kontraktova Square", false, 1)
            ),
            listOf("Києво-Могилянська Академія", "Гостинний Двір", "Андріївський узвіз", "Поділ")
        ),
        "poshtova" to Station(
            "poshtova", "Поштова площа", "Poshtova Ploshcha",
            listOf("poshtova", "funicular"), "blue", false, null, null,
            StationAccessibility(false, true, true, true, "Тільки сходи, поруч фунікулер", "Stairs only, funicular is nearby"),
            listOf(
                StationExit("1", "Вихід до Річкового вокзалу", "Exit to River Port", listOf("Київський річковий вокзал", "Фунікулер"), listOf("Kyiv River Port", "Funicular"), "Поштова площа", "Poshtova Square", false, 1)
            ),
            listOf("Річковий вокзал", "Київський Фунікулер (зв'язок з Верхнім містом)", "Пішохідний міст")
        ),
        "maidan" to Station(
            "maidan", "Майдан Незалежності", "Maidan Nezalezhnosti",
            listOf("maidan", "independence square"), "blue", true, "khreshchatyk", "red",
            StationAccessibility(false, false, true, true, "Центральна площа міста. Великий пересадочний хаб. Ескалатори", "Central city square. Major transfer hub. Escalators only"),
            listOf(
                StationExit("1", "Вихід до Майдану Незалежності", "Exit to Maidan Nezalezhnosti", listOf("Стелла Незалежності", "ТЦ Глобус"), listOf("Independence Monument", "Globus Mall"), "Майдан Незалежності", "Maidan Nezalezhnosti", false, 1)
            ),
            listOf("Майдан Незалежності", "Готель Україна", "Вулиця Інститутська", "ТЦ Глобус")
        ),
        "ploshcha_heroyiv" to Station(
            "ploshcha_heroyiv", "Площа Українських Героїв", "Ploshcha Ukrainskykh Heroiv",
            listOf("ploshcha lva tolstoho", "lva tolstoho"), "blue", true, "palats_sportu", "green",
            StationAccessibility(false, false, true, true, "Тільки ескалатори, пересадка на Зелену лінію", "Escalators only, transfer to Green line"),
            listOf(),
            listOf("Парк імені Тараса Шевченка", "Вулиця Велика Васильківська", "Кінотеатр Київ")
        ),
        "olimpiiska" to Station(
            "olimpiiska", "Олімпійська", "Olimpiiska",
            listOf("olympic", "respublika stadium"), "blue", false, null, null,
            StationAccessibility(false, false, true, true, "Ескалатори та сходи", "Escalators and stairs"),
            listOf(
                StationExit("1", "Вихід до НСК Олімпійський", "Exit to NSC Olimpiyskiy", listOf("НСК Олімпійський", "Троїцька площа"), listOf("NSC Olimpiyskiy", "Troitska Square"), "Велика Васильківська вулиця", "Velyka Vasylkivska Street", false, 2)
            ),
            listOf("НСК Олімпійський", "Тайота Центр", "Театр оперети")
        ),
        "palats_ukraina" to Station(
            "palats_ukraina", "Палац \"Україна\"", "Palats Ukraina",
            listOf("palace ukraine"), "blue", false, null, null,
            StationAccessibility(false, false, true, true, "Ескалатори", "Escalators"),
            listOf(),
            listOf("Національний палац мистецтв \"Україна\"", "Володимирський ринок")
        ),
        "lybidska" to Station(
            "lybidska", "Либідська", "Lybidska",
            listOf("lybedskaya"), "blue", false, null, null,
            StationAccessibility(false, false, true, true, "Сходи та ескалатори, великий транспортний вузол", "Stairs and escalators, big transport interchange hub"),
            listOf(),
            listOf("ТЦ Ocean Plaza", "Автостанція Либідська")
        ),
        "demiivska" to Station(
            "demiivska", "Деміївська", "Demiivska",
            listOf(), "blue", false, null, null,
            StationAccessibility(true, true, true, true, "Обладнано ліфтами та пандусами", "Equipped with elevators and ramps"),
            listOf(),
            listOf("Центральний автовокзал", "Деміївський ринок")
        ),
        "holosiivska" to Station(
            "holosiivska", "Голосіївська", "Holosiivska",
            listOf(), "blue", false, null, null,
            StationAccessibility(true, true, true, true, "Обладнано ліфтами", "Equipped with elevators"),
            listOf(),
            listOf("Голосіївський парк", "Голосіївська площа")
        ),
        "vasylkivska" to Station(
            "vasylkivska", "Васильківська", "Vasylkivska",
            listOf(), "blue", false, null, null,
            StationAccessibility(true, true, true, true, "Повна доступність з ліфтами", "Fully accessible with elevators"),
            listOf(),
            listOf("Васильківська площа", "Інститут післядипломної освіти")
        ),
        "vystavkovyi" to Station(
            "vystavkovyi", "Виставковий центр", "Vystavkovyi Tsentr",
            listOf("vdng", "vdnh"), "blue", false, null, null,
            StationAccessibility(true, true, true, true, "Прямий підземний вихід до ВДНГ з підйомниками", "Direct underground exit to VDNG with lifts"),
            listOf(
                StationExit("1", "Вихід до ВДНГ", "Exit to VDNG", listOf("Експоцентр України (ВДНГ)", "Парковка"), listOf("Expocenter of Ukraine (VDNG)", "Parking"), "проспект Академіка Глушкова", "Akademika Hlushkova Avenue", true, 2)
            ),
            listOf("Національний експоцентр України (ВДНГ)", "Київський іподром (поруч)", "Корпуси КНУ ім. Шевченка")
        ),
        "ipodrom" to Station(
            "ipodrom", "Іподром", "Ipodrom",
            listOf("hippodrome"), "blue", false, null, null,
            StationAccessibility(true, true, true, true, "Сучасна станція, повністю доступна", "Modern station, fully accessible"),
            listOf(),
            listOf("Київський іподром", "Льодовий стадіон", "Храм святих Бориса і Гліба")
        ),
        "teremky" to Station(
            "teremky", "Теремки", "Terenky",
            listOf(), "blue", false, null, null,
            StationAccessibility(true, true, true, true, "Повністю доступна станція з ліфтами", "Fully accessible station with elevators"),
            listOf(),
            listOf("ТЦ Магеллан", "Одеська площа"), isTerminal = true, directions = listOf("Героїв Дніпра")
        ),

        // --- GREEN LINE ---
        "syrets" to Station(
            "syrets", "Сирець", "Syrets",
            listOf(), "green", false, null, null,
            StationAccessibility(true, true, true, true, "Обладнана ліфтами та тактильними смугами", "Equipped with elevators and tactile lines"),
            listOf(),
            listOf("Залізнична станція Сирець (Київська міська електричка)", "Сирецький парк"), isTerminal = true, directions = listOf("Червоний хутір")
        ),
        "dorogozhychi" to Station(
            "dorogozhychi", "Дорогожичі", "Dorogozhychi",
            listOf(), "green", false, null, null,
            StationAccessibility(false, false, true, true, "Тільки ескалатори", "Escalators only"),
            listOf(),
            listOf("Бабин Яр меморіал", "Київська телевежа")
        ),
        "lukianivska" to Station(
            "lukianivska", "Лук'янівська", "Lukianivska",
            listOf("lukyanivska"), "green", false, null, null,
            StationAccessibility(false, false, true, true, "Глибока станція. Тільки ескалатори", "Deep station. Escalators only"),
            listOf(),
            listOf("Лук'янівський ринок", "ТЦ Квадрат")
        ),
        "zoloti_vorota" to Station(
            "zoloti_vorota", "Золоті ворота", "Zoloti Vorota",
            listOf("golden gate"), "green", true, "teatralna", "red",
            StationAccessibility(false, false, true, true, "Одна з найкрасивіших станцій світу. Архітектурна пам'ятка. Ескалатори", "One of the most beautiful stations in the world. Architectural monument. Escalators only"),
            listOf(
                StationExit("1", "Вихід до Золотих Воріт", "Exit to Golden Gate", listOf("Золоті Ворота пам'ятка", "Вулиця Ярославів Вал"), listOf("Golden Gate Monument", "Yaroslaviv Val Street"), "Вулиця Володимирська", "Volodymyrska Street", false, 1)
            ),
            listOf("Золоті Ворота історичний павільйон", "Софійський собор (10 хв пішки)", "Вулиця Ярославів Вал", "Оперний театр")
        ),
        "palats_sportu" to Station(
            "palats_sportu", "Палац спорту", "Palats Sportu",
            listOf("palace of sports"), "green", true, "ploshcha_heroyiv", "blue",
            StationAccessibility(false, false, true, true, "Ескалатори, пересадка на Синя лінію", "Escalators only, transfer to Blue line"),
            listOf(
                StationExit("1", "Вихід до Палацу Спорту", "Exit to Palace of Sports", listOf("Палац Спорту", "ТЦ Гулівер"), listOf("Palace of Sports", "Gulliver Mall"), "Еспланадна вулиця", "Esplanadna Street", false, 1)
            ),
            listOf("Київський Палац Спорту", "ТЦ Gulliver", "Синагога Бродського")
        ),
        "klovska" to Station(
            "klovska", "Кловська", "Klovska",
            listOf(), "green", false, null, null,
            StationAccessibility(false, false, true, true, "Ескалатори", "Escalators"),
            listOf(),
            listOf("Печерський районний суд", "Кловський палац")
        ),
        "pecherska" to Station(
            "pecherska", "Печерська", "Pecherska",
            listOf(), "green", false, null, null,
            StationAccessibility(false, false, true, true, "Ескалатори", "Escalators"),
            listOf(),
            listOf("Печерська площа", "Центральна виборча комісія")
        ),
        "zvirynetska" to Station(
            "zvirynetska", "Звіринецька", "Zvirynetska",
            listOf("druzhby narodiv", "druzhba narodov"), "green", false, null, null,
            StationAccessibility(false, false, true, true, "Ескалатори", "Escalators"),
            listOf(),
            listOf("Національний ботанічний сад ім. М.М. Гришка (15 хв пішки)", "Печерський міст")
        ),
        "vydubychi" to Station(
            "vydubychi", "Видубичі", "Vydubychi",
            listOf(), "green", false, null, null,
            StationAccessibility(true, true, true, true, "Великий мультимодальний вузол. Обладнано пандусами та підйомниками", "Major multimodal hub. Equipped with ramps and lifts"),
            listOf(
                StationExit("1", "Вихід до автостанції Видубичі", "Exit to Vydubychi Bus Station", listOf("Автостанція Видубичі", "Залізнична станція Видубичі", "Поїзди до Аеропорту Бориспіль"), listOf("Vydubychi Bus Station", "Vydubychi Train Station", "Trains to Boryspil Airport"), "Залізничне шосе", "Zaliznychne Highway", true, 2)
            ),
            listOf("Автостанція Видубичі", "Приміські та міжміські поїзди", "Kyiv Boryspil Express stop")
        ),
        "slavutych" to Station(
            "slavutych", "Славутич", "Slavutych",
            listOf(), "green", false, null, null,
            StationAccessibility(false, true, true, true, "Пандуси", "Ramps"),
            listOf(),
            listOf("Затока Дніпра", "Кооператив Сади")
        ),
        "osokorky" to Station(
            "osokorky", "Осокорки", "Osokorky",
            listOf(), "green", false, null, null,
            StationAccessibility(false, true, true, true, "Пандуси, тактильна плитка", "Ramps, tactile paving"),
            listOf(),
            listOf("Житловий масив Осокорки", "ТЦ Аркадія")
        ),
        "pozniaky" to Station(
            "pozniaky", "Позняки", "Pozniaky",
            listOf("poznyaki"), "green", false, null, null,
            StationAccessibility(false, true, true, true, "Пандуси на виходах", "Ramps at exits"),
            listOf(),
            listOf("ТЦ Аладдін", "ТЦ Піраміда", "Парк Позняки")
        ),
        "kharkivska" to Station(
            "kharkivska", "Харківська", "Kharkivska",
            listOf(), "green", false, null, null,
            StationAccessibility(false, true, true, true, "Пандуси", "Ramps"),
            listOf(),
            listOf("Озеро Вирлиця", "Транспортна розв'язка на Бориспіль")
        ),
        "vyrlytsia" to Station(
            "vyrlytsia", "Вирлиця", "Vyrlytsia",
            listOf(), "green", false, null, null,
            StationAccessibility(true, true, true, true, "Обладнана ліфтами та пандусами, перша повністю безбар'єрна підземна станція в Києві", "Equipped with elevators and ramps, the first fully barrier-free underground station in Kyiv"),
            listOf(),
            listOf("Озеро Вирлиця", "Житловий масив Харківський")
        ),
        "boryspilska" to Station(
            "boryspilska", "Бориспільська", "Boryspilska",
            listOf("boryspil train connection"), "green", false, null, null,
            StationAccessibility(true, true, true, true, "Сучасна безбар'єрна станція з ліфтами", "Modern barrier-free station with elevators"),
            listOf(),
            listOf("В'їзд до міста з аеропорту Бориспіль", "Парк Партизанської Слави")
        ),
        "chervonyi_khutir" to Station(
            "chervonyi_khutir", "Червоний хутір", "Chervonyi Khutir",
            listOf(), "green", false, null, null,
            StationAccessibility(true, true, true, true, "Кінцева станція з ліфтами", "Terminal station with elevators"),
            listOf(),
            listOf("Метродепо Харківське", "Парк Партизанської Слави"), isTerminal = true, directions = listOf("Сирець")
        )
    )

    val Fares = listOf(
        FareProduct("single_qr", TicketType.SINGLE_QR, "Разовий QR-квиток", "Single Journey QR Ticket", 8.00, "Дійсний на одну поїздку в метро, трамваї, тролейбусі або автобусі", "Valid for 1 ride in metro, tram, trolleybus, or bus"),
        FareProduct("transport_card_empty", TicketType.TRANSPORT_CARD, "Придбати транспортну картку", "Purchase Transport Card", 50.00, "Фізична пластикова картка, яку можна поповнювати", "Physical plastic card that can be topped up"),
        FareProduct("digital_card", TicketType.DIGITAL_CARD, "Цифрова транспортна картка", "Digital Transport Card", 40.00, "Віртуальна картка у вашому смартфоні", "Virtual card inside your smartphone"),
        FareProduct("monthly_unlimited", TicketType.MONTHLY_PASS, "Безлімітний проїзний на місяць", "Monthly Unlimited Pass", 325.00, "Безлімітні поїздки на всі види муніципального транспорту", "Unlimited trips on all municipal transit modes")
    )

    val Landmarks = listOf(
        Landmark("maidan", "Майдан Незалежності", "Independence Square", "Головна площа Києва, серце політичного та культурного життя України.", "The main square of Kyiv, the heart of Ukraine's political and cultural life.", "maidan", 1, "Вийдіть через Вихід 1 та підніміться сходами вгору на площу.", "Exit via Exit 1 and go up the stairs straight onto the square.", "historic"),
        Landmark("zoloti", "Золоті Ворота", "Golden Gate", "Оборонна споруда стародавнього Києва XI століття, відбудована у первинному вигляді.", "Defensive structure of ancient 11th-century Kyiv, reconstructed in its original style.", "zoloti_vorota", 1, "Вийдіть через єдиний вихід зі станції та обійдіть павільйон ліворуч.", "Exit the station and go around the pavilion to the left.", "historic"),
        Landmark("lavra", "Києво-Печерська Лавра", "Kyiv-Pechersk Lavra", "Найдавніший та найважливіший православний монастирський комплекс України, об'єкт ЮНЕСКО.", "The oldest and most crucial Orthodox monastery complex in Ukraine, a UNESCO world heritage site.", "arsenalna", 15, "З виходу метро поверніть праворуч, ідіть по вул. Лаврській повз Парк Слави.", "From the exit turn right, walk along Lavrska St past the Park of Glory.", "historic"),
        Landmark("nsc_olimp", "НСК \"Олімпійський\"", "NSC \"Olimpiyskiy\"", "Головна спортивна та концертна арена України, місце проведення фіналу Євро-2012.", "Ukraine's premier sports and concert arena, venue of the UEFA Euro 2012 final.", "olimpiiska", 3, "Вийдіть через вихід 1 та пройдіть прямо до воріт стадіону.", "Exit via Exit 1 and walk straight to the stadium gates.", "culture"),
        Landmark("sofia", "Софійський Собор", "St. Sophia's Cathedral", "Шедевр візантійської архітектури XI століття з унікальними автентичними мозаїками та фресками.", "An 11th-century Byzantine masterpiece with unique authentic mosaics and frescoes.", "zoloti_vorota", 8, "Ідіть прямо вулицею Володимирською на північ до Софійської площі.", "Walk straight north along Volodymyrska Street to Sofia Square.", "historic"),
        Landmark("podil", "Поділ та Контрактова", "Podil & Kontraktova Square", "Історичний район ремісників та торговців з неповторною малоповерховою архітектурою.", "Historic merchant district with unique low-rise architecture, cafes, and creative spaces.", "kontraktova", 1, "Прямий вихід на площу з метро.", "Direct exit from the metro onto the square.", "culture")
    )
}
