package com.example.ui

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// --- APP NAVIGATION SCREENS ---
sealed class Screen {
    object Home : Screen()
    object RoutePlanner : Screen()
    object Map : Screen()
    object Departures : Screen()
    object Alerts : Screen()
    data class StationDetails(val stationId: String) : Screen()
    object Tickets : Screen()
    object ActiveJourney : Screen()
    object TouristMode : Screen()
    object Saved : Screen()
    object Account : Screen()
    object AdminDashboard : Screen()
}

// --- LOCALIZATION DICTIONARY ---
enum class AppLanguage {
    UA, EN
}

object Trans {
    private val dict = mapOf(
        "app_title" to Pair("КИЇВСЬКИЙ МЕТРОПОЛІТЕН", "KYIV METRO"),
        "tagline" to Pair("РУХАЙСЯ КИЄВОМ.", "MOVE THROUGH KYIV."),
        "where_going" to Pair("Куди їдемо?", "Where are you going?"),
        "from" to Pair("Звідки", "From"),
        "to" to Pair("Куди", "To"),
        "plan_route" to Pair("Побудувати маршрут", "PLAN ROUTE"),
        "departures" to Pair("Відправлення", "DEPARTURES"),
        "metro_map" to Pair("Карта метро", "METRO MAP"),
        "tickets" to Pair("Квитки", "TICKETS"),
        "nearby" to Pair("Найближчі станції", "NEARBY"),
        "service_status" to Pair("Статус ліній", "SERVICE STATUS"),
        "saved" to Pair("Збережене", "SAVED"),
        "tourist_mode" to Pair("ВІЗИТ ДО КИЄВА", "VISIT KYIV"),
        "tourist_tagline" to Pair("Гід для гостей столиці", "A lightweight guide for visitors"),
        "settings" to Pair("Налаштування", "SETTINGS"),
        "language" to Pair("Мова", "Language"),
        "accessibility" to Pair("Доступність", "Accessibility"),
        "profile" to Pair("Профіль", "Profile"),
        "admin" to Pair("Адмін панель", "Admin Panel"),
        "offline_indicator" to Pair("Останнє оновлення: ", "Last updated: "),
        "offline_title" to Pair("Автономний режим", "Offline Mode"),
        "normal_service" to Pair("Рух регулярний", "Normal service"),
        "minor_delay" to Pair("Незначні затримки", "Minor delay"),
        "major_delay" to Pair("Серйозні затримки", "Major delay"),
        "suspended" to Pair("Рух призупинено", "Suspended"),
        "station_closed" to Pair("Станцію зачинено", "Station closed"),
        "planned_works" to Pair("Планові роботи", "Planned works"),
        "reduced_service" to Pair("Скорочений рух", "Reduced service"),
        "buy_ticket" to Pair("Придбати QR-квиток", "Buy QR Ticket"),
        "my_cards" to Pair("Транспортні картки", "Transport Cards"),
        "add_card" to Pair("Додати картку", "Add Card"),
        "top_up" to Pair("Поповнити", "Top Up"),
        "active_journey" to Pair("Активна поїздка", "Active Journey"),
        "at_station" to Pair("Я на станції", "I'm at the station"),
        "on_train" to Pair("Я в поїзді", "I'm on the train"),
        "arriving" to Pair("Прибуваю", "Arriving"),
        "arrived" to Pair("Я на місці", "I've arrived"),
        "step_free" to Pair("Безбар'єрний маршрут", "Step-free route"),
        "fewest_transfers" to Pair("Мінімум пересадок", "Fewest transfers"),
        "least_walking" to Pair("Мінімум ходьби", "Least walking"),
        "metro_only" to Pair("Тільки метро", "Metro only"),
        "route_not_found" to Pair("Маршрут не знайдено", "Route not found"),
        "minutes" to Pair("хв", "min"),
        "seconds" to Pair("сек", "sec"),
        "stations" to Pair("станцій", "stations"),
        "transfers" to Pair("пересадок", "transfers"),
        "exit" to Pair("Вихід", "Exit"),
        "nearby_landmarks" to Pair("Визначні місця поруч", "Nearby landmarks"),
        "accessibility_profile" to Pair("Профіль доступності", "Accessibility profile"),
        "next_trains" to Pair("Наступні поїзди", "Next departures"),
        "directions" to Pair("Напрямки", "Directions"),
        "interchanges" to Pair("Пересадки", "Interchanges"),
        "landmark_mode" to Pair("Пам'ятки Києва", "Kyiv Landmarks"),
        "landmark_how_to" to Pair("Як дістатися транспортом:", "How to reach by transport:"),
        "simulation_mode" to Pair("СИМУЛЯЦІЯ РЕАЛЬНОГО ЧАСУ", "REAL-TIME SIMULATION"),
        "demo_data_indicator" to Pair("ДЕМО ДАНІ", "DEMO DATA")
    )

    fun get(key: String, lang: AppLanguage): String {
        val pair = dict[key] ?: return key
        return if (lang == AppLanguage.UA) pair.first else pair.second
    }
}

// --- VIEWMODEL ---

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = MetroRepository(database.appDao())

    // --- LANGUAGES & ACCESSIBILITY STATES ---
    var currentLanguage = mutableStateOf(AppLanguage.UA)
    var accessibilityStepFree = mutableStateOf(false)
    var accessibilityAvoidStairs = mutableStateOf(false)
    var accessibilityHighContrast = mutableStateOf(false)

    // --- NAVIGATION STATE ---
    private val _navigationStack = mutableStateListOf<Screen>(Screen.Home)
    val navigationStack: List<Screen> get() = _navigationStack

    fun navigateTo(screen: Screen) {
        _navigationStack.add(screen)
    }

    fun navigateBack(): Boolean {
        if (_navigationStack.size > 1) {
            _navigationStack.removeAt(_navigationStack.size - 1)
            return true
        }
        return false
    }

    // --- OFFLINE / RESILIENCE STATES ---
    var isOnline = mutableStateOf(true)
    var lastCacheUpdateTime = mutableStateOf(SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))

    // --- SEARCH STATE ---
    var searchFromQuery = mutableStateOf("")
    var searchToQuery = mutableStateOf("")
    var selectedFromStation = mutableStateOf<Station?>(null)
    var selectedToStation = mutableStateOf<Station?>(null)

    // --- PLANNED ROUTE STATE ---
    var plannedRouteLegs = mutableStateOf<List<RouteLeg>?>(null)

    // --- ACTIVE JOURNEY TRACKING ---
    var activeJourney = mutableStateOf<List<RouteLeg>?>(null)
    var currentLegIndex = mutableStateOf(0)
    var activeJourneyState = mutableStateOf("NOT_STARTED") // "NOT_STARTED", "AT_STATION", "ON_TRAIN", "ARRIVING", "ARRIVED"
    var activeJourneyTargetStationId = mutableStateOf("")

    // --- SIMULATED DEPARTURES & NETWORK STATUS ---
    // User or simulation can disable stations or lines
    val disabledStations = mutableStateListOf<String>()
    val suspendedLines = mutableStateListOf<String>()
    val lineStatuses = mutableMapOf(
        "red" to mutableStateOf(NetworkStatus.NORMAL),
        "blue" to mutableStateOf(NetworkStatus.NORMAL),
        "green" to mutableStateOf(NetworkStatus.NORMAL)
    )

    // Live departures list generated dynamically and ticking
    val liveDeparturesList = mutableStateListOf<Departure>()

    // Service Alerts (Simulated alerts + admin posted alerts)
    val activeAlerts = mutableStateListOf<ServiceAlert>()

    // Local DB Caches
    val savedPlaces: StateFlow<List<SavedPlaceEntity>> = repository.savedPlaces.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val tickets: StateFlow<List<TicketEntity>> = repository.tickets.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val transportCards: StateFlow<List<TransportCardEntity>> = repository.transportCards.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentJourneys: StateFlow<List<RecentJourneyEntity>> = repository.recentJourneys.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        // Hydrate default data and start a background ticker to simulate live departures and crowding
        populateDefaultSavedPlaces()
        populateDefaultAlerts()
        startDepartureSimulatorTicker()
    }

    private fun populateDefaultSavedPlaces() {
        viewModelScope.launch {
            repository.savePlace(SavedPlaceEntity("home", "Дім", "Home", "vokzalna", true))
            repository.savePlace(SavedPlaceEntity("work", "Робота", "Work", "khreshchatyk", true))
        }
    }

    private fun populateDefaultAlerts() {
        activeAlerts.add(
            ServiceAlert(
                id = "alert_1",
                lineId = "blue",
                stationId = null,
                typeUa = "ПЛАНОВІ РОБОТИ",
                typeEn = "PLANNED WORKS",
                titleUa = "Обмеження швидкості на Синій лінії",
                titleEn = "Speed restriction on Blue Line",
                descriptionUa = "Проводяться планові профілактичні роботи колійного полотна між станціями Либідська та Деміївська.",
                descriptionEn = "Planned maintenance work is being carried out between Lybidska and Demiivska stations.",
                affectedRoutesUa = "Оболонсько-Теремківська лінія",
                affectedRoutesEn = "Obolonsko-Teremkivska line",
                alternativeUa = "Поїзди курсують із затримкою до 2 хвилин.",
                alternativeEn = "Trains run with minor delays of up to 2 minutes.",
                timestamp = System.currentTimeMillis() - 3600000,
                expectedDurationUa = "До 15 жовтня",
                expectedDurationEn = "Until Oct 15"
            )
        )
    }

    private fun startDepartureSimulatorTicker() {
        viewModelScope.launch {
            while (true) {
                // Periodically update departure timers or simulate live movements
                generateSimulatedDepartures()
                delay(30000) // Update every 30 seconds
            }
        }
    }

    fun generateSimulatedDepartures() {
        liveDeparturesList.clear()
        val random = Random()

        // Generate departures for every station
        for (station in MetroData.Stations.values) {
            val lineId = station.lineId
            if (suspendedLines.contains(lineId) || disabledStations.contains(station.id)) continue

            val nextStations = station.directions
            for (dest in nextStations) {
                val m1 = random.nextInt(3) + 1
                val m2 = m1 + random.nextInt(4) + 3

                liveDeparturesList.add(Departure(lineId, station.id, dest, getStationName(dest, AppLanguage.UA), getStationName(dest, AppLanguage.EN), m1, "Платформа 1"))
                liveDeparturesList.add(Departure(lineId, station.id, dest, getStationName(dest, AppLanguage.UA), getStationName(dest, AppLanguage.EN), m2, "Платформа 1"))
            }

            // In Kyiv metro, most stations are linear, meaning they have two platforms. If they are not terminal, they have two directions.
            if (nextStations.isEmpty()) {
                // If directions not specified, just mock default terminal directions
                val line = MetroData.Lines.find { it.id == lineId }
                if (line != null) {
                    val firstStat = line.stations.first()
                    val lastStat = line.stations.last()

                    if (station.id != firstStat) {
                        val m1 = random.nextInt(3) + 2
                        liveDeparturesList.add(Departure(lineId, station.id, firstStat, getStationName(firstStat, AppLanguage.UA), getStationName(firstStat, AppLanguage.EN), m1, "Платформа 1"))
                    }
                    if (station.id != lastStat) {
                        val m2 = random.nextInt(4) + 3
                        liveDeparturesList.add(Departure(lineId, station.id, lastStat, getStationName(lastStat, AppLanguage.UA), getStationName(lastStat, AppLanguage.EN), m2, "Платформа 2"))
                    }
                }
            }
        }
    }

    // Get live departures for a specific station
    fun getDeparturesForStation(stationId: String): List<Departure> {
        return liveDeparturesList.filter { it.stationId == stationId }.sortedBy { it.minutesLeft }
    }

    // Get display name of a station
    fun getStationName(stationId: String, lang: AppLanguage): String {
        val s = MetroData.Stations[stationId] ?: return stationId
        return if (lang == AppLanguage.UA) s.nameUa else s.nameEn
    }

    // --- INTERACTIVE ACTIONS ---

    // Plan Multimodal Journey
    fun performRoutePlanning() {
        val from = selectedFromStation.value
        val to = selectedToStation.value
        if (from == null || to == null) return

        val pref = RoutingPreference(
            fastest = true,
            fewestTransfers = accessibilityAvoidStairs.value,
            stepFreeOnly = accessibilityStepFree.value,
            leastWalking = accessibilityAvoidStairs.value,
            metroOnly = false
        )

        val path = Router.planRoute(
            fromId = from.id,
            toId = to.id,
            preference = pref,
            disabledStations = disabledStations.toSet(),
            suspendedLines = suspendedLines.toSet()
        )

        plannedRouteLegs.value = path

        if (path != null) {
            viewModelScope.launch {
                repository.recordJourney(from.id, to.id)
            }
        }
    }

    // Start tracking journey
    fun startJourneyTracking(route: List<RouteLeg>) {
        activeJourney.value = route
        currentLegIndex.value = 0
        activeJourneyState.value = "AT_STATION"
        
        // Find first station
        val firstLeg = route.firstOrNull()
        activeJourneyTargetStationId.value = when (firstLeg) {
            is RouteLeg.TrainRide -> firstLeg.fromId
            is RouteLeg.Interchange -> firstLeg.stationFromId
            is RouteLeg.WalkToStation -> firstLeg.stationId
            is RouteLeg.WalkToDestination -> firstLeg.stationId
            null -> ""
        }
        navigateTo(Screen.ActiveJourney)
    }

    fun progressJourneyState() {
        val route = activeJourney.value ?: return
        val currentLeg = route.getOrNull(currentLegIndex.value) ?: return

        when (activeJourneyState.value) {
            "AT_STATION" -> {
                activeJourneyState.value = "ON_TRAIN"
                activeJourneyTargetStationId.value = when (currentLeg) {
                    is RouteLeg.TrainRide -> currentLeg.toId
                    is RouteLeg.Interchange -> currentLeg.stationToId
                    is RouteLeg.WalkToStation -> currentLeg.stationId
                    is RouteLeg.WalkToDestination -> currentLeg.stationId
                }
            }
            "ON_TRAIN" -> {
                activeJourneyState.value = "ARRIVING"
            }
            "ARRIVING" -> {
                if (currentLegIndex.value < route.size - 1) {
                    currentLegIndex.value += 1
                    activeJourneyState.value = "AT_STATION"
                    val nextLeg = route[currentLegIndex.value]
                    activeJourneyTargetStationId.value = when (nextLeg) {
                        is RouteLeg.TrainRide -> nextLeg.fromId
                        is RouteLeg.Interchange -> nextLeg.stationFromId
                        is RouteLeg.WalkToStation -> nextLeg.stationId
                        is RouteLeg.WalkToDestination -> nextLeg.stationId
                    }
                } else {
                    activeJourneyState.value = "ARRIVED"
                }
            }
            "ARRIVED" -> {
                activeJourney.value = null
                navigateBack()
            }
        }
    }

    // Ticketing Simulated Buy
    fun purchaseTicket(product: FareProduct) {
        viewModelScope.launch {
            val qrPayload = "KYIVMETRO-QR-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
            val entity = TicketEntity(
                typeName = product.type.name,
                titleUa = product.nameUa,
                titleEn = product.nameEn,
                priceUah = product.priceUah,
                qrCodePayload = qrPayload
            )
            repository.addTicket(entity)
        }
    }

    // Custom physical/digital transport card registration
    fun registerNewTransportCard(customName: String, isDigital: Boolean) {
        viewModelScope.launch {
            val randomNum = (1000000000L..9999999999L).random().toString()
            val entity = TransportCardEntity(
                cardNumber = randomNum,
                name = customName.ifEmpty { if (isDigital) "Digital Card" else "Physical Card" },
                balanceUah = 0.0,
                ridesCount = 0,
                isDigital = isDigital
            )
            repository.saveCard(entity)
        }
    }

    fun topUpTransportCard(card: TransportCardEntity, amountUah: Double) {
        viewModelScope.launch {
            val addedRides = (amountUah / 8.0).toInt()
            val updated = card.copy(
                balanceUah = card.balanceUah + amountUah,
                ridesCount = card.ridesCount + addedRides,
                lastUpdated = System.currentTimeMillis()
            )
            repository.updateCard(updated)
        }
    }

    fun useCardRide(card: TransportCardEntity) {
        if (card.ridesCount > 0) {
            viewModelScope.launch {
                val updated = card.copy(
                    ridesCount = card.ridesCount - 1,
                    balanceUah = (card.balanceUah - 8.0).coerceAtLeast(0.0),
                    lastUpdated = System.currentTimeMillis()
                )
                repository.updateCard(updated)
            }
        }
    }

    fun validateTicket(ticket: TicketEntity) {
        viewModelScope.launch {
            val updated = ticket.copy(
                isValidated = true,
                validatedAt = System.currentTimeMillis()
            )
            repository.updateTicketState(updated)
        }
    }

    // --- ADMIN OVERRIDES ---
    fun toggleStationDisabled(stationId: String) {
        if (disabledStations.contains(stationId)) {
            disabledStations.remove(stationId)
        } else {
            disabledStations.add(stationId)
        }
        generateSimulatedDepartures()
    }

    fun toggleLineSuspended(lineId: String) {
        if (suspendedLines.contains(lineId)) {
            suspendedLines.remove(lineId)
            lineStatuses[lineId]?.value = NetworkStatus.NORMAL
        } else {
            suspendedLines.add(lineId)
            lineStatuses[lineId]?.value = NetworkStatus.SUSPENDED
        }
        generateSimulatedDepartures()
    }

    fun updateLineStatus(lineId: String, status: NetworkStatus) {
        lineStatuses[lineId]?.value = status
        if (status == NetworkStatus.SUSPENDED) {
            if (!suspendedLines.contains(lineId)) suspendedLines.add(lineId)
        } else {
            suspendedLines.remove(lineId)
        }
        generateSimulatedDepartures()
    }

    fun addCustomAlert(titleUa: String, titleEn: String, descUa: String, descEn: String) {
        activeAlerts.add(
            ServiceAlert(
                id = "custom_" + UUID.randomUUID().toString().substring(0, 4),
                lineId = null,
                stationId = null,
                typeUa = "ОФІЦІЙНЕ ПОВІДОМЛЕННЯ",
                typeEn = "OFFICIAL NOTICE",
                titleUa = titleUa,
                titleEn = titleEn,
                descriptionUa = descUa,
                descriptionEn = descEn,
                affectedRoutesUa = "Муніципальний транспорт",
                affectedRoutesEn = "Municipal Transit",
                alternativeUa = "Слідкуйте за оновленнями на інформаційних екранах.",
                alternativeEn = "Follow updates on wayfinding screens.",
                timestamp = System.currentTimeMillis(),
                expectedDurationUa = "До завершення робіт",
                expectedDurationEn = "Until further notice"
            )
        )
    }

    fun removeAlert(id: String) {
        activeAlerts.removeAll { it.id == id }
    }
}

// --- FACTORY PROVISION ---

class AppViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AppViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AppViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
