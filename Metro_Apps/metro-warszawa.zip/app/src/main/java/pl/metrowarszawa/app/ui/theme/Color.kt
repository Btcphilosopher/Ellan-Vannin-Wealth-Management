package pl.metrowarszawa.app.ui.theme

import androidx.compose.ui.graphics.Color

val MetroM1Red = Color(0xFFD32F2F)
val MetroM2Blue = Color(0xFF1976D2)
val MetroCharcoal = Color(0xFF121212)
val MetroGraphite = Color(0xFF212121)
val MetroConcrete = Color(0xFFF3F4F6)
val MetroWarmWhite = Color(0xFFFAFAFA)
val MetroAmber = Color(0xFFFFB300)
val MetroGreen = Color(0xFF388E3C)
val MetroSurfaceDark = Color(0xFF1E1E1E)
val MetroCardDark = Color(0xFF2D2D2D)
