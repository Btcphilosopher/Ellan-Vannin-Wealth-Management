package pl.metrowarszawa.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import pl.metrowarszawa.app.ui.screens.*
import pl.metrowarszawa.app.ui.theme.WarsawMetroTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WarsawMetroTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()

                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            HomeScreen(
                                onNavigateToMap = { navController.navigate("map") },
                                onNavigateToRoute = { navController.navigate("route") },
                                onNavigateToStation = { stationId -> navController.navigate("station/$stationId") },
                                onNavigateToTickets = { navController.navigate("tickets") },
                                onNavigateToAlerts = { navController.navigate("alerts") },
                                onNavigateToSettings = { navController.navigate("settings") },
                                onNavigateToLines = { navController.navigate("lines") }
                            )
                        }
                        composable("map") {
                            MapScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToStation = { stationId -> navController.navigate("station/$stationId") }
                            )
                        }
                        composable("route") {
                            RoutePlannerScreen(
                                onBack = { navController.popBackStack() },
                                onStartJourney = { result -> navController.navigate("journey/${result.originName}/${result.destinationName}") }
                            )
                        }
                        composable(
                            route = "station/{stationId}",
                            arguments = listOf(navArgument("stationId") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val stationId = backStackEntry.arguments?.getString("stationId") ?: "m1_centrum"
                            StationScreen(
                                stationId = stationId,
                                onBack = { navController.popBackStack() },
                                onNavigateToJourney = { origin, dest -> navController.navigate("journey/$origin/$dest") }
                            )
                        }
                        composable(
                            route = "journey/{origin}/{destination}",
                            arguments = listOf(
                                navArgument("origin") { type = NavType.StringType },
                                navArgument("destination") { type = NavType.StringType }
                            )
                        ) { backStackEntry ->
                            val origin = backStackEntry.arguments?.getString("origin") ?: "Centrum"
                            val destination = backStackEntry.arguments?.getString("destination") ?: "Dworzec Gdański"
                            JourneyScreen(
                                origin = origin,
                                destination = destination,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("lines") {
                            LinesScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToStation = { stationId -> navController.navigate("station/$stationId") }
                            )
                        }
                        composable("tickets") {
                            TicketsScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("alerts") {
                            AlertsScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
