package pl.metrowarszawa.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontWeight.Companion.Bold
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pl.metrowarszawa.app.data.WarsawMetroRepository
import pl.metrowarszawa.app.domain.model.Departure
import pl.metrowarszawa.app.domain.model.FavouriteItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToMap: () -> Unit,
    onNavigateToRoute: () -> Unit,
    onNavigateToStation: (String) -> Unit,
    onNavigateToTickets: () -> Unit,
    onNavigateToAlerts: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToLines: () -> Unit
) {
    val departures by WarsawMetroRepository.departures.collectAsState()
    val favourites by WarsawMetroRepository.favourites.collectAsState()
    val alerts by WarsawMetroRepository.serviceAlerts.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("METRO WARSZAWA", fontWeight = Bold, fontSize = 20.sp)
                        Text("Warsaw Underground Railway System", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToAlerts, modifier = Modifier.testTag("alerts_button")) {
                        Icon(Icons.Default.Notifications, contentDescription = "Service Alerts")
                    }
                    IconButton(onClick = onNavigateToSettings, modifier = Modifier.testTag("settings_button")) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings & Privacy")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    selected = true,
                    onClick = {}
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                    label = { Text("Map") },
                    selected = false,
                    onClick = onNavigateToMap
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Route, contentDescription = "Route") },
                    label = { Text("Route") },
                    selected = false,
                    onClick = onNavigateToRoute
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Tickets") },
                    label = { Text("Tickets") },
                    selected = false,
                    onClick = onNavigateToTickets
                )
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Nearest Station Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToStation("m1_centrum") },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("NEAREST STATION / NAJBLIŻSZA STACJA", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("CENTRUM", fontSize = 22.sp, fontWeight = Bold)
                            Text("M1 • Marszałkowska", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primary,
                            shape = MaterialTheme.shapes.small
                        ) {
                            Text(
                                "3 min walk",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontSize = 12.sp,
                                fontWeight = Bold
                            )
                        }
                    }
                }
            }

            // Route Planner Quick Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToRoute() },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ROUTE PLANNER / PLANUJ TRASĘ", fontSize = 11.sp, fontWeight = Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Dokąd jedziesz? / Where to?", fontSize = 18.sp, fontWeight = Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Dijkstra routing, M1/M2, accessibility & transfers", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                        }
                        Icon(Icons.Default.Search, contentDescription = "Search Route", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }

            // Network Status Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToAlerts() },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(Color(0xFF388E3C), shape = MaterialTheme.shapes.extraSmall)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("NETWORK STATUS / STAN SIECI", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("M1 & M2 Normal Service", fontSize = 15.sp, fontWeight = Bold)
                            }
                        }
                        TextButton(onClick = onNavigateToLines) {
                            Text("Lines M1/M2")
                        }
                    }
                }
            }

            // Next Departures Header & List
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("NEXT DEPARTURES / ODJAZDY", fontSize = 16.sp, fontWeight = Bold)
                    Text("Live Feed", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                }
            }

            items(departures) { dep ->
                DepartureCard(dep = dep, onClick = { onNavigateToStation(dep.stationId) })
            }

            // Favourites Header & Row
            item {
                Text("FAVOURITES / ULUBIONE", fontSize = 16.sp, fontWeight = Bold)
            }

            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(favourites) { fav ->
                        FavouriteCard(fav = fav, onClick = { onNavigateToStation("m1_centrum") })
                    }
                }
            }
        }
    }
}

@Composable
fun DepartureCard(dep: Departure, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = if (dep.lineId == "M1") Color(0xFFD32F2F) else Color(0xFF1976D2),
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        dep.lineId,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        color = Color.White,
                        fontWeight = Bold,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Direction: ${dep.directionName}", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Text("Platform ${dep.platform} • Scheduled ${dep.scheduledTime}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${dep.minutesLeft} min", fontWeight = Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                Text(dep.quality, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun FavouriteCard(fav: FavouriteItem, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(150.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Icon(Icons.Default.Star, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
            Text(fav.title, fontWeight = Bold, fontSize = 14.sp, maxLines = 1)
            Spacer(modifier = Modifier.height(2.dp))
            Text(fav.subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}
