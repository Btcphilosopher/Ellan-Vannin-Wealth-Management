package pl.metrowarszawa.app.domain.model

data class Station(
    val id: String,
    val name: String,
    val englishName: String,
    val lineId: String, // "M1" or "M2"
    val latitude: Double,
    val longitude: Double,
    val isInterchange: Boolean = false,
    val isAccessible: Boolean = true,
    val entrances: List<StationEntrance> = emptyList(),
    val platforms: List<Platform> = emptyList()
)

data class StationEntrance(
    val id: String,
    val stationId: String,
    val name: String,
    val street: String,
    val distanceMeters: Int,
    val hasElevator: Boolean,
    val hasEscalator: Boolean,
    val isOpen: Boolean = true
)

data class Platform(
    val id: String,
    val stationId: String,
    val lineId: String,
    val direction: String,
    val isAccessible: Boolean
)

data class Departure(
    val stationId: String,
    val lineId: String,
    val directionName: String,
    val minutesLeft: Int,
    val scheduledTime: String,
    val delaySeconds: Int = 0,
    val platform: String = "1",
    val isCancelled: Boolean = false,
    val isRealtime: Boolean = true,
    val quality: String = "LIVE" // LIVE, TIMETABLE, DEMO
)

data class ServiceAlert(
    val id: String,
    val severity: AlertSeverity,
    val lines: List<String>,
    val title: String,
    val description: String,
    val alternativeRoute: String? = null
)

enum class AlertSeverity {
    INFO, MINOR, MAJOR, CRITICAL
}

data class RouteStep(
    val mode: TransportMode,
    val fromStationName: String,
    val toStationName: String,
    val lineOrRouteName: String,
    val durationMinutes: Int,
    val stopsCount: Int = 0,
    val instructions: String,
    val isAccessible: Boolean = true
)

enum class TransportMode {
    METRO_M1, METRO_M2, TRAM, BUS, RAIL, WALK, TRANSFER
}

data class JourneyResult(
    val originName: String,
    val destinationName: String,
    val totalMinutes: Int,
    val steps: List<RouteStep>,
    val isAccessible: Boolean,
    val confidence: String = "High"
)

data class DigitalTicket(
    val id: String,
    val productTitle: String,
    val passengerCategory: String,
    val validFrom: String,
    val validUntil: String,
    val status: TicketStatus,
    val validationCode: String
)

enum class TicketStatus {
    NOT_YET_VALID, VALID, EXPIRED, CANCELLED
}

data class FavouriteItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val type: String // STATION, JOURNEY
)
