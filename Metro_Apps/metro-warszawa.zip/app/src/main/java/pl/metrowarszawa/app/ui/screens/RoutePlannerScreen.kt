package pl.metrowarszawa.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pl.metrowarszawa.app.data.WarsawMetroRepository
import pl.metrowarszawa.app.domain.model.JourneyResult

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutePlannerScreen(
    onBack: () -> Unit,
    onStartJourney: (JourneyResult) -> Unit
) {
    var origin by remember { mutableStateOf("Centrum") }
    var destination by remember { mutableStateOf("Dworzec Gdański") }
    var accessibleOnly by remember { mutableStateOf(false) }
    var journeyResult by remember { mutableStateOf<JourneyResult?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("ROUTE PLANNER / PLANUJ TRASĘ", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("Dijkstra & Timetable Graph Engine", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        OutlinedTextField(
                            value = origin,
                            onValueChange = { origin = it },
                            label = { Text("Origin / Skąd") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("origin_input")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = destination,
                            onValueChange = { destination = it },
                            label = { Text("Destination / Dokąd") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("destination_input")
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Step-free access only", fontWeight = FontWeight.SemiBold)
                            Switch(
                                checked = accessibleOnly,
                                onCheckedChange = { accessibleOnly = it },
                                modifier = Modifier.testTag("accessibility_switch")
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                journeyResult = WarsawMetroRepository.calculateRoute(origin, destination, accessibleOnly)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("calculate_route_button")
                        ) {
                            Text("Calculate Route / Znajdź Trasę")
                        }
                    }
                }
            }

            journeyResult?.let { result ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("FASTEST ROUTE / NAJSZYBSZA", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("${result.totalMinutes} min", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            result.steps.forEach { step ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.SwapVert, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(step.lineOrRouteName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(step.instructions, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { onStartJourney(result) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("start_journey_button")
                            ) {
                                Text("Start Journey Mode / Rozpocznij Podróż")
                            }
                        }
                    }
                }
            }
        }
    }
}
