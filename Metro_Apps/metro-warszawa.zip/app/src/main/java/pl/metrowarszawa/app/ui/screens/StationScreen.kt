package pl.metrowarszawa.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pl.metrowarszawa.app.data.WarsawMetroRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationScreen(
    stationId: String,
    onBack: () -> Unit,
    onNavigateToJourney: (String, String) -> Unit
) {
    val station = WarsawMetroRepository.getStation(stationId) ?: WarsawMetroRepository.allStations.first()
    val departures by WarsawMetroRepository.departures.collectAsState()
    val stationDepartures = departures.filter { it.stationId == station.id || station.id == "m1_centrum" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(station.name, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("Line ${station.lineId} • Station Intelligence", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Station Header Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = if (station.lineId == "M1") Color(0xFFD32F2F) else Color(0xFF1976D2),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Text(
                                    station.lineId,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(station.englishName, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Accessible, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF388E3C))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Step-free access", fontSize = 12.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Elevator, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Elevators operational", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Entrances Section
            item {
                Text("STATION ENTRANCES / WEJŚCIA", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            items(station.entrances) { entrance ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(entrance.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("${entrance.street} • ${entrance.distanceMeters}m away", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = { /* Navigate to entrance */ },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("Navigate", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Live Departures Section
            item {
                Text("REALTIME DEPARTURES / ODJAZDY", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            items(stationDepartures) { dep ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Direction: ${dep.directionName}", fontWeight = FontWeight.SemiBold)
                            Text("Platform ${dep.platform} • Scheduled ${dep.scheduledTime}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("${dep.minutesLeft} min", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}
