package pl.metrowarszawa.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = MetroM1Red,
    secondary = MetroM2Blue,
    background = MetroCharcoal,
    surface = MetroSurfaceDark,
    onPrimary = MetroWarmWhite,
    onSecondary = MetroWarmWhite,
    onBackground = MetroWarmWhite,
    onSurface = MetroWarmWhite
)

private val LightColorScheme = lightColorScheme(
    primary = MetroM1Red,
    secondary = MetroM2Blue,
    background = MetroWarmWhite,
    surface = MetroConcrete,
    onPrimary = MetroWarmWhite,
    onSecondary = MetroWarmWhite,
    onBackground = MetroCharcoal,
    onSurface = MetroGraphite
)

@Composable
fun WarsawMetroTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = WarsawTypography,
        content = content
    )
}
