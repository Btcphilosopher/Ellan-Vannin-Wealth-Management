package pl.metrowarszawa.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pl.metrowarszawa.app.data.WarsawMetroRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LinesScreen(
    onBack: () -> Unit,
    onNavigateToStation: (String) -> Unit
) {
    var selectedLine by remember { mutableStateOf("M1") }
    val stations = WarsawMetroRepository.allStations.filter { it.lineId == selectedLine }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("METRO LINES / LINIE METRO", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("M1 (Kabaty-Młociny) & M2 (Bemowo-Bródno)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(
                    onClick = { selectedLine = "M1" },
                    colors = ButtonDefaults.buttonColors(containerColor = if (selectedLine == "M1") Color(0xFFD32F2F) else MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Line M1", color = if (selectedLine == "M1") Color.White else MaterialTheme.colorScheme.onSurface)
                }
                Button(
                    onClick = { selectedLine = "M2" },
                    colors = ButtonDefaults.buttonColors(containerColor = if (selectedLine == "M2") Color(0xFF1976D2) else MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Line M2", color = if (selectedLine == "M2") Color.White else MaterialTheme.colorScheme.onSurface)
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(stations) { station ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        onClick = { onNavigateToStation(station.id) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(station.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("${station.englishName} • Line ${station.lineId}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (station.isInterchange) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = MaterialTheme.shapes.small
                                ) {
                                    Text("Interchange", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
