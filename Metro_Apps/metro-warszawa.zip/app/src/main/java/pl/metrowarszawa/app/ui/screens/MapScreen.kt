package pl.metrowarszawa.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pl.metrowarszawa.app.data.WarsawMetroRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    onBack: () -> Unit,
    onNavigateToStation: (String) -> Unit
) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val m1Stations = WarsawMetroRepository.allStations.filter { it.lineId == "M1" }
    val m2Stations = WarsawMetroRepository.allStations.filter { it.lineId == "M2" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("METRO MAP / SCHEMAT SIECI", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("M1 (Red) & M2 (Blue) Warsaw Network", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.5f, 4f)
                        offset += pan
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                scale(scale = scale, pivot = center + offset) {
                    val m1Points = listOf(
                        Offset(size.width * 0.4f, size.height * 0.1f),
                        Offset(size.width * 0.4f, size.height * 0.3f),
                        Offset(size.width * 0.4f, size.height * 0.55f),
                        Offset(size.width * 0.4f, size.height * 0.7f),
                        Offset(size.width * 0.4f, size.height * 0.9f)
                    )

                    for (i in 0 until m1Points.size - 1) {
                        drawLine(
                            color = Color(0xFFD32F2F),
                            start = m1Points[i],
                            end = m1Points[i + 1],
                            strokeWidth = 8f
                        )
                    }

                    val m2Points = listOf(
                        Offset(size.width * 0.1f, size.height * 0.55f),
                        Offset(size.width * 0.25f, size.height * 0.55f),
                        Offset(size.width * 0.4f, size.height * 0.55f),
                        Offset(size.width * 0.6f, size.height * 0.55f),
                        Offset(size.width * 0.85f, size.height * 0.55f)
                    )

                    for (i in 0 until m2Points.size - 1) {
                        drawLine(
                            color = Color(0xFF1976D2),
                            start = m2Points[i],
                            end = m2Points[i + 1],
                            strokeWidth = 8f
                        )
                    }

                    drawCircle(
                        color = Color.Yellow,
                        radius = 16f,
                        center = Offset(size.width * 0.4f, size.height * 0.55f)
                    )
                }
            }

            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(12.dp).background(Color(0xFFD32F2F)))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("M1 Kabaty - Młociny", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(12.dp).background(Color(0xFF1976D2)))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("M2 Bemowo - Bródno", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
