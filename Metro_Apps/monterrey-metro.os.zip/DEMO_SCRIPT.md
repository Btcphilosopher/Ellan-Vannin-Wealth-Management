# DEMO_SCRIPT.md

## Prototype Flagship Demo Scripts

To facilitate easy evaluation, we have built 5 completely automated scenarios right into the Home Screen under the "DEMOS INTERACTIVOS" panel.

### DEMO 01: Universidad ➔ Centro
1. Tap the **DEMO 01** button.
2. The search fields automatically input "Universidad" as origin and "Macroplaza" as destination.
3. The routing engine calculates the path and displays options.
4. The simulator navigates into the "Universidad" Station Detail page to check upcoming train departures.
5. "EMPEZAR VIAJE" is pressed, launching "TU VIAJE" (Journey Active Mode).
6. It cycles through station steps (Universidad -> Regina -> Zaragoza) showing stop progress.
7. Displays arrival confirmation!

### DEMO 02: San Bernabé ➔ Fundidora (With Transfer)
1. Tap **DEMO 02**.
2. Searches routing from Line 1 (San Bernabé) to Fundidora.
3. Shows the transfer node at Cuauhtémoc, highlighting the free transbordo.
4. Transitions automatically to the Me Muevo digital ledger history to verify transaction logs.

### DEMO 03: Centro ➔ Transmetro
1. Tap **DEMO 03**.
2. Calculates travel from General Zaragoza to Anáhuac.
3. Shows the integrated transfer leg transitioning from Line 2 Metro to the Transmetro bus route.
4. Highlights the integrated fare cap of $15.00 MXN.

### DEMO 04: Disruption Recalculation
1. Tap **DEMO 04**.
2. Shows a normal search between Sendero and Cuauhtémoc.
3. Triggers an alert "Línea 2 Delay / Suspended".
4. The graph router recalculates and automatically prompts the traveler with an alternative path (Line 1 + Transmetro Sendero-Escobedo).

### DEMO 05: URBANI QR Payment
1. Tap **DEMO 05**.
2. Opens the PAGO screen.
3. Generates the QR ticket with high-contrast transportation design patterns.
4. Simulates reading and validation: transitions to "VALIDADO" -> "TORNQUETE LIBERADO" with saldo deduction.
