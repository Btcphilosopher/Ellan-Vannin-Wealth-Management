# MONTERREY METRO.OS

## METRORREY PASSENGER APPLICATION

**MONTERREY METRO.OS** is a complete, production-quality passenger mobile application engineered specifically for the Metrorrey Metro and Transmetro transit network of Monterrey, Nuevo León, Mexico. 

Designed under the theme of **Monterrey Industrial Modernism**, the application combines the practicality of a public-transport operating system with the authentic character of the Monterrey valley: Sierra Madre Oriental, elevated concrete viaducts, heavy engineering steel, and northern Mexican sunlight.

---

## 🏗️ SYSTEM ARCHITECTURE & COMPONENTS

For complete details on each component of the Passenger OS, please consult the dedicated documentation files below:

1. **[ARCHITECTURE.md](ARCHITECTURE.md)**: Design patterns, Clean Architecture (MVVM), and state machinery.
2. **[DESIGN_SYSTEM.md](DESIGN_SYSTEM.md)**: Color tokens, Material 3 configurations, and typography.
3. **[MOTION_SPEC.md](MOTION_SPEC.md)**: Spring physics, transit visual animations, and state transitions.
4. **[NETWORK_MODEL.md](NETWORK_MODEL.md)**: Structured representations of Lines 1-6 and Transmetro.
5. **[FARE_ENGINE.md](FARE_ENGINE.md)**: Cost optimization, policy definitions, and payment abstractions.
6. **[ROUTING_ENGINE.md](ROUTING_ENGINE.md)**: Dijkstra/BFS graph implementation with disruption & weather weights.
7. **[DATA_MODEL.md](DATA_MODEL.md)**: Schema descriptions for local database (Room) entities.
8. **[API.md](API.md)**: Synthetic provider definitions and future production API mappings.
9. **[TESTING.md](TESTING.md)**: Playwright, Unit, and Roborazzi visual regression test blueprints.
10. **[DEMO_SCRIPT.md](DEMO_SCRIPT.md)**: Complete step-by-step scripts to reproduce flagship user journeys.

---

## 🛠️ DEVELOPMENT & RUNTIME COMMANDS

### Frontend (Android applet)
- **Compile applet**: `compile_applet`
- **Run Unit and Robolectric tests**: `gradle :app:testDebugUnitTest`
- **Record new reference screenshots**: `gradle :app:recordRoborazziDebug`
- **Verify screenshots / Visual regression**: `gradle :app:verifyRoborazziDebug`

### Backend (Python FastAPI production ready)
- **Create environment**: `python -m venv .venv`
- **Install dependencies**: `pip install -r requirements.txt`
- **Run server**: `uvicorn app.main:app --reload`
- **Run test suite**: `pytest`

---

## ⛰️ THE MONTERREY PRINCIPLE
Monterrey is a city of infrastructure. The software respects this: no gimmicky SaaS templates or purple AI gradients. The interface is graphite, concrete gray, off-white, and bold high-contrast black typography. Like the steel mills and concrete viaducts of Nuevo León, the application is solid, precise, and beautiful.
