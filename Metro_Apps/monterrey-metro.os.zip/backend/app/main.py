from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI(title="Monterrey Metro OS - Transit API", version="1.0.0")

class Station(BaseModel):
    id: str
    name: str
    line_id: str
    has_elevator: bool
    has_escalator: bool

class JourneyLeg(BaseModel):
    type: str
    routeName: Optional[str] = None
    startStationName: Optional[str] = None
    endStationName: Optional[str] = None
    durationMinutes: int
    instruction: str

class Journey(BaseModel):
    id: str
    originName: str
    destinationName: str
    totalDurationMinutes: int
    totalFareMxn: float
    legs: List[JourneyLeg]
    isAccessible: bool

@app.get("/")
def read_root():
    return {"status": "MONTERREY METRO.OS API ONLINE", "system": "Metrorrey"}

@app.get("/api/stations", response_model=List[Station])
def get_stations():
    return [
        Station(id="UNIVERSIDAD", name="Universidad", line_id="L2", has_elevator=True, has_escalator=True),
        Station(id="CUAUHTEMOC_L1", name="Cuauhtémoc (L1)", line_id="L1", has_elevator=True, has_escalator=True),
        Station(id="EXPOSICION", name="Exposición", line_id="L1", has_elevator=True, has_escalator=True)
    ]

@app.post("/api/route", response_model=List[Journey])
def calculate_route(origin: str, destination: str):
    # Dummy route responder matching the Android applet
    return [
        Journey(
            id="J-DUMMY",
            originName=origin,
            destinationName=destination,
            totalDurationMinutes=22,
            totalFareMxn=15.00,
            legs=[
                JourneyLeg(type="METRO", routeName="Línea 2", startStationName="Universidad", endStationName="Cuauhtémoc", durationMinutes=10, instruction="Toma la Línea 2"),
                JourneyLeg(type="TRANSMETRO", routeName="Transmetro", startStationName="Cuauhtémoc", endStationName=destination, durationMinutes=12, instruction="Toma el Transmetro")
            ],
            isAccessible=True
        )
    ]
