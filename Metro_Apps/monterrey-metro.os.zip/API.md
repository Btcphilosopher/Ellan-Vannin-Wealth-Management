# API.md

## Service & Provider API Integration Blueprint

To make the application enterprise-ready, all core features are abstracted into clean interfaces.

### 1. Abstract Providers

```kotlin
interface TransitProvider {
    fun getLines(): List<MetroLine>
    fun getStation(id: String): Station?
    fun getTransmetroRoutes(): List<TransmetroRoute>
}

interface FareProvider {
    fun getFarePolicy(): FarePolicy
    fun calculateJourneyFare(legs: List<JourneyLeg>, paymentMethod: String): Double
}
```

### 2. Transitioning to Live Production APIs
Currently, the system uses `SyntheticTransitProvider`, `SyntheticFareProvider`, and `SyntheticVehicleProvider` seeded with deterministic data simulating 100+ active trains and departures.

To deploy live real-time Metrorrey data, replace these classes with Network-backed implementations:
- **GTFS / GTFS-RT Realtime**: Connect `VehicleProvider` to the state's GTFS-RT feed for exact vehicle positions.
- **URBANI API gateway**: Integrate Retrofit endpoints inside the `PaymentProvider` to fetch actual QR tokens and sync Me Muevo balances with the central database.
