# ROUTING_ENGINE.md

## Graph-based Routing Engine

The core navigation experience in MONTERREY METRO.OS is powered by a graph-based router using **Dijkstra's Algorithm**.

### 1. Nodes & Edges
- **Nodes**: High-fidelity representations of transit platform nodes (e.g., `UNIVERSIDAD`, `CUAUHTEMOC_L1`, `CUAUHTEMOC_L2`, `APODACA`).
- **Edges**: Connections corresponding to subway tracks, walking transitions, or bus legs.

### 2. Multi-Preference Optimization Weights
The weight of each edge (expressed in minutes) is adjusted dynamically based on passenger preferences:
- **MÁS RÁPIDO**: Returns the path with the absolute lowest cumulative travel and transfer weights.
- **MENOS TRANSBORDOS**: Adds a massive penalty (+15 min) to transfer edges to avoid changes.
- **MENOS CAMINATA**: Applies penalties to walking edges.
- **ACCESIBLE**: Filters out segments that contain non-accessible stations (missing elevators/escalators).

### 3. Dynamic Environmental Layer Inputs
Edge weights are modified on the fly by operational alerts and climate feeds:
- **Disruptions**: Active delayed lines add delay weights (e.g. +6 min) to their segments, causing the engine to automatically recommend alternative lines (e.g., Line 1 + Transmetro).
- **Weather**: Rain increases walking times by +6 minutes, and heat triggers hydration prompts.
