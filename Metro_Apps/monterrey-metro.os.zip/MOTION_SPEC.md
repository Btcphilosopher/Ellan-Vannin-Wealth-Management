# MOTION_SPEC.md

## Motion Design & Animation Specification

Animations communicate transit movement. Unnecessary, distracting elements are omitted to maintain an efficient operational user experience.

### 1. Spring Physics Parameters
All list expansions and chip interactions use precise, stiff spring physics to feel solid and mechanical:
- `dampingRatio` = `Spring.DampingRatioMediumBouncy` (0.85)
- `stiffness` = `Spring.StiffnessMedium` (1500f)

### 2. Map Zoom & Drawing
- **Route Draw**: Journey route vectors draw themselves sequentially along track segments (0.0f -> 1.0f progress) to guide the traveler's eyes.
- **Train Movement**: Simulated active trains transition smoothly between station nodes with progress interpolation, flashing a subtle pulse ring to indicate live status.
- **Torniquete QR Scan**: High contrast credential animation transitions clearly from `READY` -> `VALIDATING` -> `GRANTED` -> `ACTIVE` to signify gate unlocking.
