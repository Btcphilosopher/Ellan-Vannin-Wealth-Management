# TESTING.md

## Testing and Verification Specification

Quality is guaranteed via a multi-tiered test architecture.

### 1. Local JVM Unit Tests (`ExampleUnitTest.kt`)
Tests transit domain logic directly, running instantly without requiring emulators:
- **Routing Engine Tests**: Verifies pathfinding, transfers, and disruption penalties.
- **Fare Cap Engine Tests**: Assures correct $9.90 / $15.00 MXN integrated fare computation.
- **Accessibility Tests**: Checks that elevator presence constraints are evaluated correctly.

### 2. Instrumented & Playwright Blueprints
To run end-to-end user journeys:
- **Playwright Test Plans**: Included in our specification to simulate the following flows:
  - Search ➔ Choose Journey ➔ Start travel.
  - Generar Boleto QR URBANI ➔ Scan simulation ➔ Unlock gate.

### 3. Screenshot Visual Regression (`GreetingScreenshotTest.kt`)
Powered by **Roborazzi** and **Robolectric**, this renders the actual Jetpack Compose UI under NATIVE graphics mode and records a pixel-perfect snapshot to compare against reference assets:
- **Command**: `gradle :app:verifyRoborazziDebug` to compare, and `gradle :app:recordRoborazziDebug` to update references.
