# DESIGN_SYSTEM.md

## Monterrey Industrial Modernism Design System

The visual design is structured as a dedicated transportation operating system, mirroring the heavy engineering character of Nuevo León.

### 1. Color Palette Tokens

- `--monterrey-graphite` (`0xFF16181A`): Primary deep background token, robust like raw cast iron.
- `--concrete` (`0xFFE2E4E6`): Warm architectural grey, representing viaduct columns and platform slabs.
- `--paper` (`0xFFF9FAFB`): High contrast off-white for legible typography.
- `--sun` (`0xFFF2ECE4`): Neutral background tone reflecting the intense northern Mexican sun.

### 2. Line Colors (Configurable via Metadata)

- **Línea 1**: `#FFC72C` (Gold)
- **Línea 2**: `#008A4B` (Green)
- **Línea 3**: `#E37222` (Orange)
- **Línea 4**: `#00A3E0` (Cyan)
- **Línea 5**: `#DA291C` (Red)
- **Línea 6**: `#7A3E97` (Purple)

### 3. Typography
Display texts are large, confident, and high-contrast, utilizing bold sans-serif pairings with comfortable letter-spacing for quick scanning while walking inside terminals.
- **Header Displays**: 28sp to 32sp, Black weight.
- **Operational Data**: 12sp to 14sp, bold and centered.
