# FARE_ENGINE.md

## Metrorrey Fare & Transfer Engine Specification

Metrorrey uses a zoned integrated ticketing scheme based on URBANI QR codes and physical Me Muevo cards.

### 1. Fare Rules Matrix

- **Metro Only Segment**: $9.90 MXN (current official rate sequence).
- **Transmetro Only Segment**: $15.00 MXN.
- **Metro + Transmetro Integrated**: $15.00 MXN capped maximum.

### 2. Transfer Calculation Logic
When passengers transfer between Metro and Transmetro:
- If using Me Muevo or QR, the system validates the **120-minute transfer window**.
- The second leg is charged as a top-up delta (e.g. Metro $9.90 + Transmetro $5.10 delta = $15.00 total) instead of charging double fares, saving the passenger money.
- Transfers inside the Metro network (Metro to Metro, e.g. L1 to L2 at Cuauhtémoc) are completely free.
- The entire logic is thoroughly unit-tested under `ExampleUnitTest.kt`.
