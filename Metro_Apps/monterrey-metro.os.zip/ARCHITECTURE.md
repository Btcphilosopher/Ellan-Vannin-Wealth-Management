# ARCHITECTURE.md

## MONTERREY METRO.OS Architecture Design

MONTERREY METRO.OS utilizes a clean, decoupled **MVVM (Model-View-ViewModel)** architectural pattern. It is designed to be fully testable, highly performant (targeting 60-120 FPS), and adaptable to production APIs with minimal changes.

### 1. Layers

- **UI Layer (Jetpack Compose)**: Houses purely declarative layout screens.
- **State Holder (MetroViewModel)**: Exposes a single unified state `AppUiState` as a reactive `StateFlow`. Contains simulation tickers and trigger hooks.
- **Domain & Service Layer**: Custom algorithms (Dijkstra graph router, Fares and Transfers engine) and Provider abstractions.
- **Data Layer (Room Database)**: Persists favorites, contactless card balance, and transaction history using KSP-generated DAOs.

### 2. Provider Abstraction
To ensure that the application is not tightly coupled to mock data, we implemented a complete provider-based abstraction model:
- `TransitProvider`: Stations, Lines 1-6, and Transmetro routes data.
- `FareProvider`: Integrated price engines.
- `VehicleProvider`: Live vehicle position and telemetry.
- `ServiceAlertProvider`: Incident records.
- `WeatherProvider`: Contextual weather layers.

All UI screens read exclusively from these providers. A real production Metrorrey API can replace these synthetic providers with zero impact on UI or ViewModel files.
