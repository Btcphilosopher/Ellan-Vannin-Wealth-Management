package com.example

import com.example.model.*
import com.example.service.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    private val transitProvider = SyntheticTransitProvider()
    private val alertProvider = SyntheticAlertProvider()
    private val weatherProvider = SyntheticWeatherProvider()
    private val routingEngine = RoutingEngine(transitProvider, alertProvider, weatherProvider)
    private val fareProvider = SyntheticFareProvider()
    private val vehicleProvider = SyntheticVehicleProvider()

    @Test
    fun testStationLookup() {
        val uanl = transitProvider.getStation("UNIVERSIDAD")
        assertNotNull(uanl)
        assertEquals("Universidad", uanl?.name)
        assertEquals("L2", uanl?.lineId)
    }

    @Test
    fun testFareCalculation() {
        // Metro leg only
        val legsMetro = listOf(
            JourneyLeg("METRO", "L2", "Línea 2", "UNIVERSIDAD", "Universidad", "ALAMEDA", "Alameda", 10, "Toma la L2")
        )
        val fareMetro = fareProvider.calculateJourneyFare(legsMetro, "ME MUEVO")
        assertEquals(9.90, fareMetro, 0.01)

        // Transmetro only
        val legsTransmetro = listOf(
            JourneyLeg("TRANSMETRO", null, "Transmetro Universidad", "UNIVERSIDAD", "Universidad", "Anáhuac", "Anáhuac", 8, "Toma el Transmetro")
        )
        val fareTransmetro = fareProvider.calculateJourneyFare(legsTransmetro, "ME MUEVO")
        assertEquals(15.00, fareTransmetro, 0.01)

        // Integrated Transfer (Metro + Transmetro)
        val legsIntegrated = listOf(
            JourneyLeg("METRO", "L2", "Línea 2", "ZARAGOZA_L2", "General Zaragoza", "UNIVERSIDAD", "Universidad", 12, "Toma la L2"),
            JourneyLeg("TRANSFER", null, "Transbordo", "UNIVERSIDAD", "Universidad", "UNIVERSIDAD", "Universidad", 3, "Transbordo"),
            JourneyLeg("TRANSMETRO", null, "Transmetro Universidad", "UNIVERSIDAD", "Universidad", "Anáhuac", "Anáhuac", 8, "Toma el Transmetro")
        )
        val fareIntegrated = fareProvider.calculateJourneyFare(legsIntegrated, "ME MUEVO")
        assertEquals(15.00, fareIntegrated, 0.01) // Capped at $15.00 integrated transfer fare
    }

    @Test
    fun testRoutingEngineNormal() {
        // Normal routing Universidad to General Zaragoza
        val journeys = routingEngine.calculateJourneys("Universidad", "General Zaragoza", JourneyPreference.MAS_RAPIDO)
        assertFalse(journeys.isEmpty())
        
        val best = journeys.first()
        assertTrue(best.totalDurationMinutes > 0)
        assertTrue(best.legs.any { it.type == "METRO" })
    }

    @Test
    fun testAccessibilityRouting() {
        // Alameda has hasElevator = false. Under accessible routing, we prefer accessible routes.
        val stations = transitProvider.getLines().flatMap { it.stations }
        val alameda = stations.find { it.id == "ALAMEDA" }
        assertNotNull(alameda)
        assertFalse(alameda!!.hasElevator)

        val journeys = routingEngine.calculateJourneys("Universidad", "Alameda", JourneyPreference.ACCESIBLE)
        assertFalse(journeys.isEmpty())
        // Accessible journey should evaluate accessible flags
        assertTrue(journeys.first().legs.isNotEmpty())
    }

    @Test
    fun testVehicleSimulation() {
        val initialVehicles = vehicleProvider.getVehicles("NORMAL")
        assertFalse(initialVehicles.isEmpty())

        val alerts = alertProvider.getActiveAlerts()
        val tickedVehicles = vehicleProvider.tickSimulation("NORMAL", alerts)
        assertEquals(initialVehicles.size, tickedVehicles.size)
        
        // Progress should have updated
        val v0_initial = initialVehicles.first()
        val v0_ticked = tickedVehicles.first()
        assertNotEquals(v0_initial.progress, v0_ticked.progress)
    }

    @Test
    fun testDisruptionRerouting() {
        // Inject critical alert to Line 2
        alertProvider.addAlert(
            ServiceAlert(
                id = "ALERT_L2_SUSPENDED",
                incidentType = "Falla técnica",
                severity = "CRITICAL",
                affectedLineId = "L2",
                affectedStationId = "UNIVERSIDAD",
                cause = "Falla de energía total",
                description = "Línea 2 suspendida",
                expectedRecovery = "Indefinido",
                alternativeRoute = "Línea 1"
            )
        )

        // Routing from Universidad to Padre Mier should show different behavior or be penalized/rerouted
        val journeys = routingEngine.calculateJourneys("Universidad", "Padre Mier", JourneyPreference.MAS_RAPIDO)
        // Clean up alert
        alertProvider.removeAlert("ALERT_L2_SUSPENDED")
        
        assertNotNull(journeys)
    }
}
