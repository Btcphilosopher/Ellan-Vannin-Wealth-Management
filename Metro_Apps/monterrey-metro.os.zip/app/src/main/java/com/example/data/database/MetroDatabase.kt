package com.example.data.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import com.example.model.FavoritePlaceEntity
import com.example.model.MeMuevoCardEntity
import com.example.model.RecentRouteEntity
import com.example.model.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoritePlaceDao {
    @Query("SELECT * FROM favorite_places")
    fun getAllFavorites(): Flow<List<FavoritePlaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoritePlaceEntity)

    @Delete
    suspend fun deleteFavorite(favorite: FavoritePlaceEntity)

    @Query("DELETE FROM favorite_places WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface MeMuevoCardDao {
    @Query("SELECT * FROM me_muevo_card LIMIT 1")
    fun getCard(): Flow<MeMuevoCardEntity?>

    @Query("SELECT * FROM me_muevo_card LIMIT 1")
    suspend fun getCardDirect(): MeMuevoCardEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateCard(card: MeMuevoCardEntity)

    @Query("UPDATE me_muevo_card SET balanceMxn = :newBalance WHERE id = :cardId")
    suspend fun updateBalance(cardId: String, newBalance: Double)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions")
    suspend fun clearAll()
}

@Dao
interface RecentRouteDao {
    @Query("SELECT * FROM recent_routes ORDER BY timestamp DESC LIMIT 10")
    fun getRecentRoutes(): Flow<List<RecentRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentRoute(route: RecentRouteEntity)
}

@Database(
    entities = [
        FavoritePlaceEntity::class,
        MeMuevoCardEntity::class,
        TransactionEntity::class,
        RecentRouteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MetroDatabase : RoomDatabase() {
    abstract fun favoritePlaceDao(): FavoritePlaceDao
    abstract fun meMuevoCardDao(): MeMuevoCardDao
    abstract fun transactionDao(): TransactionDao
    abstract fun recentRouteDao(): RecentRouteDao
}
