package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = Color.White,
    onPrimary = MonterreyGraphite,
    secondary = ConcreteGray,
    onSecondary = MonterreyGraphite,
    background = MonterreyGraphite,
    onBackground = OffWhite,
    surface = Color(0xFF222528),
    onSurface = OffWhite,
    error = AlertRed
)

private val LightColorScheme = lightColorScheme(
    primary = MonterreyGraphite,
    onPrimary = Color.White,
    secondary = EngineeringSteel,
    onSecondary = Color.White,
    background = OffWhite,
    onBackground = MonterreyGraphite,
    surface = Color.White,
    onSurface = MonterreyGraphite,
    error = AlertRed,
    secondaryContainer = ConcreteGray,
    onSecondaryContainer = MonterreyGraphite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep it false to preserve our custom Monterrey brand colors!
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
