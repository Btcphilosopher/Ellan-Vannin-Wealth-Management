package com.example.service

import com.example.model.*
import kotlin.math.abs
import kotlin.random.Random

// --- Provider Abstractions (as requested by the user prompt) ---

interface TransitProvider {
    fun getLines(): List<MetroLine>
    fun getStation(id: String): Station?
    fun getTransmetroRoutes(): List<TransmetroRoute>
    fun getDestinations(): List<DestinationInfo>
}

interface FareProvider {
    fun getFarePolicy(): FarePolicy
    fun calculateJourneyFare(legs: List<JourneyLeg>, paymentMethod: String): Double
}

interface VehicleProvider {
    fun getVehicles(simulationMode: String): List<Vehicle>
    fun tickSimulation(simulationMode: String, alerts: List<ServiceAlert>): List<Vehicle>
}

interface ServiceAlertProvider {
    fun getActiveAlerts(): List<ServiceAlert>
    fun addAlert(alert: ServiceAlert)
    fun removeAlert(id: String)
}

interface WeatherProvider {
    fun getCurrentWeather(): WeatherState
    fun setWeather(state: WeatherState)
}

// Destination info helper
data class DestinationInfo(
    val id: String,
    val name: String,
    val type: String, // "Universidad", "Estadio", "Parque", "Centro", "Hospital", "Negocios"
    val nearestStationId: String,
    val distanceMinutesWalking: Int,
    val coordinates: Pair<Float, Float>,
    val description: String
)

// --- Implementation of Providers (Synthetic implementations, fully deterministic and flexible) ---

class SyntheticTransitProvider : TransitProvider {
    private val stationsMap = mutableMapOf<String, Station>()
    private val linesList = mutableListOf<MetroLine>()
    private val transmetroList = mutableListOf<TransmetroRoute>()
    private val destinationsList = mutableListOf<DestinationInfo>()

    init {
        // Modeled Monterrey stations (Lines 1 to 6)
        // Let's model X,Y on a relative grid (0 to 100) to represent the Monterrey Metropolitan Valley
        
        // LINE 1 (Yellow-Gold): Talleres <-> Exposición. 
        val l1Stations = listOf(
            Station("TALLERES", "Talleres", "L1", false, false, false, false, listOf("Av. Solidaridad"), listOf("Talleres Talleres"), listOf("Mercado local"), Pair(20f, 20f)),
            Station("SAN_BERNABE", "San Bernabé", "L1", true, true, true, true, listOf("Av. Aztlán"), listOf("Zona Norte"), listOf("Clínica IMSS"), Pair(28f, 22f)),
            Station("MITRAS", "Mitras", "L1", true, true, true, true, listOf("Av. Rodrigo Gómez"), listOf("Mitras Centro"), listOf("UANL Área Médica"), Pair(35f, 28f)),
            Station("CUAUHTEMOC_L1", "Cuauhtémoc (L1)", "L1", true, true, true, true, listOf("Av. Colón", "Av. Cuauhtémoc"), listOf("Centro de Monterrey"), listOf("Zona Comercial Centro"), Pair(50f, 40f)),
            Station("FELIX_U_GOMEZ_L1", "Félix U. Gómez (L1)", "L1", true, true, true, true, listOf("Av. Colón", "Av. Félix U. Gómez"), listOf("Col. Industrial"), listOf("Hospital de Zona IMSS"), Pair(65f, 40f)),
            Station("Y_GRIEGA", "Y Griega", "L1", true, false, true, true, listOf("Av. Colón"), listOf("Parque Fundidora"), listOf("Cintermex", "Arena Monterrey"), Pair(75f, 42f)),
            Station("EXPOSICION", "Exposición", "L1", true, true, true, true, listOf("Av. Benito Juárez"), listOf("Guadalupe Centro"), listOf("Estadio BBVA", "Expo Guadalupe"), Pair(88f, 48f))
        )
        l1Stations.forEach { stationsMap[it.id] = it }
        linesList.add(MetroLine("L1", "Línea 1", "L1", "#FFC72C", l1Stations, "Talleres", "Exposición"))

        // LINE 2 (Green): Sendero <-> General Zaragoza
        val l2Stations = listOf(
            Station("SENDERO", "Sendero", "L2", true, true, true, true, listOf("Av. Sendero Divisorio"), listOf("Escobedo / San Nicolás"), listOf("Plaza Sendero"), Pair(50f, 10f)),
            Station("SAN_NICOLAS", "San Nicolás", "L2", true, true, true, true, listOf("Av. Universidad"), listOf("San Nicolás Centro"), listOf("Plaza de San Nicolás"), Pair(50f, 18f)),
            Station("UNIVERSIDAD", "Universidad", "L2", true, true, true, true, listOf("Av. Universidad"), listOf("Ciudad Universitaria"), listOf("UANL Campus San Nicolás", "Estadio Universitario"), Pair(50f, 25f)),
            Station("REGINA", "Regina", "L2", true, false, true, true, listOf("Av. Alfonso Reyes"), listOf("Col. Regina"), listOf("Parque Niños Héroes"), Pair(50f, 32f)),
            Station("CUAUHTEMOC_L2", "Cuauhtémoc (L2)", "L2", true, true, true, true, listOf("Av. Colón", "Av. Cuauhtémoc"), listOf("Centro de Monterrey"), listOf("Interconexión L1"), Pair(50f, 40f)),
            Station("ALAMEDA", "Alameda", "L2", false, true, false, false, listOf("Av. Pino Suárez"), listOf("Alameda Mariano Escobedo"), listOf("Centro Comercial Alameda"), Pair(50f, 47f)),
            Station("PADRE_MIER", "Padre Mier", "L2", true, true, true, true, listOf("Av. Padre Mier"), listOf("Zona Rosa"), listOf("Morelos Pedestrian Street"), Pair(50f, 54f)),
            Station("ZARAGOZA_L2", "General Zaragoza (L2)", "L2", true, true, true, true, listOf("Av. Padre Mier", "Calle Zaragoza"), listOf("Macroplaza"), listOf("Palacio de Gobierno", "MARCO"), Pair(50f, 60f))
        )
        l2Stations.forEach { stationsMap[it.id] = it }
        linesList.add(MetroLine("L2", "Línea 2", "L2", "#008A4B", l2Stations, "Sendero", "General Zaragoza"))

        // LINE 3 (Orange): Hospital Metropolitano <-> General Zaragoza
        val l3Stations = listOf(
            Station("HOSPITAL_METROPOLITANO", "Hospital Metropolitano", "L3", true, true, true, true, listOf("Av. López Mateos"), listOf("San Nicolás Sur"), listOf("Hospital Metropolitano"), Pair(65f, 20f)),
            Station("RUIZ_CORTINES", "Ruiz Cortines", "L3", true, true, true, true, listOf("Av. Felix U. Gómez", "Av. Ruiz Cortines"), listOf("Col. Industrial"), listOf("Ecovía Connection"), Pair(65f, 30f)),
            Station("FELIX_U_GOMEZ_L3", "Félix U. Gómez (L3)", "L3", true, true, true, true, listOf("Av. Colón", "Av. Félix U. Gómez"), listOf("Col. Industrial"), listOf("Interconexión L1"), Pair(65f, 40f)),
            Station("SANTA_LUCIA", "Santa Lucía", "L3", true, true, true, true, listOf("Av. Félix U. Gómez"), listOf("Paseo Santa Lucía"), listOf("Museo de Historia Mexicana", "Paseo Santa Lucía"), Pair(65f, 50f)),
            Station("ZARAGOZA_L3", "General Zaragoza (L3)", "L3", true, true, true, true, listOf("Calle Zaragoza"), listOf("Macroplaza"), listOf("Interconexión L2"), Pair(50f, 60f))
        )
        l3Stations.forEach { stationsMap[it.id] = it }
        linesList.add(MetroLine("L3", "Línea 3", "L3", "#E37222", l3Stations, "Hospital Metropolitano", "General Zaragoza"))

        // LINE 4 (Cyan - Under Construction / Future modeled): San Jerónimo <-> Monterrey Centro (Zaragoza)
        val l4Stations = listOf(
            Station("SAN_JERONIMO", "San Jerónimo", "L4", true, true, true, true, listOf("Av. Constitución"), listOf("San Jerónimo"), listOf("Doctor's Hospital"), Pair(30f, 60f)),
            Station("OBISPADO", "Obispado", "L4", true, false, true, true, listOf("Av. Constitución"), listOf("Col. Obispado"), listOf("Cerro del Obispado", "Mirador"), Pair(40f, 60f)),
            Station("ZARAGOZA_L4", "General Zaragoza (L4)", "L4", true, true, true, true, listOf("Calle Zaragoza"), listOf("Macroplaza"), listOf("Interconexión L2/L3"), Pair(50f, 60f))
        )
        l4Stations.forEach { stationsMap[it.id] = it }
        linesList.add(MetroLine("L4", "Línea 4 (Planeada)", "L4", "#00A3E0", l4Stations, "San Jerónimo", "General Zaragoza"))

        // LINE 5 (Red - Under Construction / Future modeled): Zaragoza <-> Mederos
        val l5Stations = listOf(
            Station("ZARAGOZA_L5", "General Zaragoza (L5)", "L5", true, true, true, true, listOf("Calle Zaragoza"), listOf("Macroplaza"), listOf("Interconexión L2/L3/L4"), Pair(50f, 60f)),
            Station("TECNOLOGICO", "Tecnológico", "L5", true, true, true, true, listOf("Av. Eugenio Garza Sada"), listOf("Distrito Tec"), listOf("Tec de Monterrey (ITESM)"), Pair(55f, 75f)),
            Station("MEDEROS", "Mederos", "L5", true, true, true, true, listOf("Av. Eugenio Garza Sada"), listOf("Mederos"), listOf("UANL Campus Mederos"), Pair(60f, 90f))
        )
        l5Stations.forEach { stationsMap[it.id] = it }
        linesList.add(MetroLine("L5", "Línea 5 (Planeada)", "L5", "#DA291C", l5Stations, "General Zaragoza", "Mederos"))

        // LINE 6 (Purple - Under Construction / Future modeled): Zaragoza <-> Apodaca
        val l6Stations = listOf(
            Station("ZARAGOZA_L6", "General Zaragoza (L6)", "L6", true, true, true, true, listOf("Calle Zaragoza"), listOf("Macroplaza"), listOf("Interconexión L2/L3/L4/L5"), Pair(50f, 60f)),
            Station("PROLONGACION_MADERO", "Prolongación Madero", "L6", true, true, true, true, listOf("Av. Miguel Alemán"), listOf("Col. Lindavista"), listOf("Parque Industrial Guadalupe"), Pair(70f, 50f)),
            Station("APODACA", "Apodaca Centro", "L6", true, true, true, true, listOf("Av. Miguel Alemán"), listOf("Apodaca"), listOf("Centro de Apodaca"), Pair(90f, 30f))
        )
        l6Stations.forEach { stationsMap[it.id] = it }
        linesList.add(MetroLine("L6", "Línea 6 (Planeada)", "L6", "#7A3E97", l6Stations, "General Zaragoza", "Apodaca Centro"))

        // --- Transmetro Routes ---
        transmetroList.add(TransmetroRoute("TM_UNIV_SN", "Transmetro Universidad - San Nicolás", "Universidad", "San Nicolás", "UNIVERSIDAD", 6, 15.0, 5, listOf("Ciudad Universitaria", "Anáhuac", "San Nicolás Centro")))
        transmetroList.add(TransmetroRoute("TM_HOSP_LIND", "Transmetro Hospital Metropolitano - Lindavista", "Hospital Metropolitano", "Lindavista", "HOSPITAL_METROPOLITANO", 8, 15.0, 4, listOf("Hospital Metropolitano", "La Fe", "Lindavista")))
        transmetroList.add(TransmetroRoute("TM_EXPO_JUAREZ", "Transmetro Exposición - Juárez", "Exposición", "Villa de Juárez", "EXPOSICION", 7, 15.0, 6, listOf("Exposición", "Guadalupe Centro", "Villa de Juárez")))
        transmetroList.add(TransmetroRoute("TM_SEND_ESCOBEDO", "Transmetro Sendero - Escobedo", "Sendero", "Escobedo", "SENDERO", 5, 15.0, 6, listOf("Sendero", "Col. Pedregal", "Escobedo Centro")))
        transmetroList.add(TransmetroRoute("TM_AEROPUERTO", "Express Transmetro Aeropuerto", "Y Griega", "Aeropuerto Monterrey", "Y_GRIEGA", 15, 15.0, 3, listOf("Y Griega", "Prolec", "Aeropuerto Terminal A", "Aeropuerto Terminal B")))

        // --- Destinations (City Layer - Monterrey landmarks) ---
        destinationsList.add(DestinationInfo("CU_UANL", "Ciudad Universitaria (UANL)", "Universidad", "UNIVERSIDAD", 3, Pair(50f, 25f), "Campus principal de la Universidad Autónoma de Nuevo León, Estadio Universitario."))
        destinationsList.add(DestinationInfo("FUNDIDORA", "Parque Fundidora / Cintermex", "Parque", "Y_GRIEGA", 5, Pair(73f, 44f), "Antigua fundidora de acero convertida en parque público, centro de exposiciones Cintermex y Arena Monterrey."))
        destinationsList.add(DestinationInfo("ESTADIO_BBVA", "Estadio BBVA (El Gigante de Acero)", "Estadio", "EXPOSICION", 8, Pair(90f, 50f), "Estadio del Club de Fútbol Monterrey con vista espectacular al Cerro de la Silla."))
        destinationsList.add(DestinationInfo("MACROPLAZA", "Macroplaza y Barrio Antiguo", "Centro", "ZARAGOZA_L2", 2, Pair(50f, 60f), "Plaza central de Monterrey, Museos MARCO y de Historia, oficinas gubernamentales y Barrio Antiguo."))
        destinationsList.add(DestinationInfo("TEC_MTY", "Tec de Monterrey (Campus Monterrey)", "Universidad", "TECNOLOGICO", 6, Pair(55f, 75f), "Prestigioso instituto de tecnología y negocios del norte del país."))
        destinationsList.add(DestinationInfo("HOSP_ZONA", "Hospital de Zona No. 21 IMSS", "Hospital", "FELIX_U_GOMEZ_L1", 4, Pair(65f, 40f), "Centro de atención médica de alta especialidad en el centro de la ciudad."))
        destinationsList.add(DestinationInfo("PABELLON_M", "Pabellón M y Centro de Negocios", "Negocios", "PADRE_MIER", 3, Pair(50f, 54f), "Rascacielos céntrico, centro de convenciones y auditorio principal."))
        destinationsList.add(DestinationInfo("AEROPUERTO", "Aeropuerto Internacional de Monterrey (MTY)", "Aeropuerto", "Y_GRIEGA", 35, Pair(95f, 20f), "Aeropuerto internacional que conecta al estado con el mundo."))
        destinationsList.add(DestinationInfo("CERRO_SILLA", "Cerro de la Silla (Mirador)", "Parque", "EXPOSICION", 25, Pair(98f, 70f), "El ícono natural de Monterrey, cumbre y senderismo montañoso."))
    }

    override fun getLines(): List<MetroLine> = linesList
    override fun getStation(id: String): Station? = stationsMap[id] ?: stationsMap[id + "_L1"] ?: stationsMap[id + "_L2"] ?: stationsMap[id + "_L3"] ?: stationsMap[id + "_L4"] ?: stationsMap[id + "_L5"] ?: stationsMap[id + "_L6"]
    override fun getTransmetroRoutes(): List<TransmetroRoute> = transmetroList
    override fun getDestinations(): List<DestinationInfo> = destinationsList
}

class SyntheticFareProvider : FareProvider {
    private val policy = FarePolicy()

    override fun getFarePolicy(): FarePolicy = policy

    override fun calculateJourneyFare(legs: List<JourneyLeg>, paymentMethod: String): Double {
        // Transfer Engine Logic:
        // Metro only: $9.90 MXN (Me Muevo/QR)
        // Transmetro only: $15.00 MXN
        // Integrated (Metro -> Transmetro or Transmetro -> Metro):
        // If paymentMethod is Me Muevo or QR, the integrated fare is capped at $15.00 MXN.
        // If they did a transfer, first fare is charged, then difference is charged up to max integrated.
        // Let's check legs
        val hasMetro = legs.any { it.type == "METRO" }
        val hasTransmetro = legs.any { it.type == "TRANSMETRO" }

        return when {
            hasMetro && hasTransmetro -> policy.integratedFareMxn
            hasTransmetro -> policy.currentTransmetroFareMxn
            hasMetro -> policy.currentMetroFareMxn
            else -> 0.0
        }
    }
}

class SyntheticVehicleProvider : VehicleProvider {
    private var simulatedVehicles = mutableListOf<Vehicle>()
    private val random = Random(42)

    init {
        // Initialize synthetic vehicles on the lines
        // Lines 1, 2, 3 have real simulated vehicles. Lines 4, 5, 6 under construction have lesser or static simulated.
        val provider = SyntheticTransitProvider()
        val lines = provider.getLines()
        var idCounter = 100

        lines.forEach { line ->
            // Let's create 4-8 vehicles for each line
            val numVehicles = if (line.id == "L1" || line.id == "L2") 6 else 4
            val stations = line.stations
            if (stations.size >= 2) {
                for (i in 0 until numVehicles) {
                    val currentIdx = random.nextInt(stations.size - 1)
                    val nextIdx = currentIdx + 1
                    simulatedVehicles.add(
                        Vehicle(
                            id = "V-${line.id}-${idCounter++}",
                            routeId = line.id,
                            lineId = line.id,
                            direction = line.directionSecondary,
                            currentStationId = stations[currentIdx].id,
                            nextStationId = stations[nextIdx].id,
                            progress = random.nextFloat(),
                            speedKmh = 40 + random.nextInt(15),
                            status = "En Movimiento",
                            occupancy = listOf("BAJA", "MEDIA", "ALTA", "MUY ALTA").random(random)
                        )
                    )
                }
            }
        }

        // Add some Transmetro vehicles
        provider.getTransmetroRoutes().forEach { tm ->
            simulatedVehicles.add(
                Vehicle(
                    id = "V-${tm.id}-201",
                    routeId = tm.id,
                    lineId = null,
                    direction = tm.destination,
                    currentStationId = tm.connectedMetroStationId,
                    nextStationId = tm.destination,
                    progress = 0.4f,
                    speedKmh = 30,
                    status = "En Movimiento",
                    occupancy = "MEDIA"
                )
            )
        }
    }

    override fun getVehicles(simulationMode: String): List<Vehicle> {
        return simulatedVehicles
    }

    override fun tickSimulation(simulationMode: String, alerts: List<ServiceAlert>): List<Vehicle> {
        // Updates progress of vehicles. Apply speed reduction if simulationMode is "DELAY" or "INCIDENT" on specific lines!
        val provider = SyntheticTransitProvider()
        val updated = simulatedVehicles.map { v ->
            val isAffectedByAlert = alerts.any { alert -> alert.affectedLineId == v.lineId }
            
            // Advance progress
            val step = when (simulationMode) {
                "RUSH_HOUR" -> 0.12f
                "DELAY" -> if (isAffectedByAlert) 0.02f else 0.08f
                "INCIDENT" -> if (isAffectedByAlert) 0.00f else 0.07f // stops vehicles if critical incident
                else -> 0.07f // NORMAL
            }

            var nextProgress = v.progress + step
            var currStation = v.currentStationId
            var nextStation = v.nextStationId
            var dir = v.direction

            if (nextProgress >= 1.0f) {
                nextProgress = 0.0f
                // Swap stations / bounce back or advance
                val line = provider.getLines().find { it.id == v.lineId }
                if (line != null) {
                    val stations = line.stations
                    val currIdx = stations.indexOfFirst { it.id == v.currentStationId }
                    val nextIdx = stations.indexOfFirst { it.id == v.nextStationId }

                    if (currIdx != -1 && nextIdx != -1) {
                        if (v.direction == line.directionSecondary) {
                            if (nextIdx == stations.size - 1) {
                                // Reached end, reverse direction
                                dir = line.directionPrimary
                                currStation = stations[nextIdx].id
                                nextStation = stations[nextIdx - 1].id
                            } else {
                                currStation = stations[nextIdx].id
                                nextStation = stations[nextIdx + 1].id
                            }
                        } else {
                            if (nextIdx == 0) {
                                dir = line.directionSecondary
                                currStation = stations[nextIdx].id
                                nextStation = stations[nextIdx + 1].id
                            } else {
                                currStation = stations[nextIdx].id
                                nextStation = stations[nextIdx - 1].id
                            }
                        }
                    }
                } else {
                    // Transmetro bounce
                    val tm = provider.getTransmetroRoutes().find { it.id == v.routeId }
                    if (tm != null) {
                        if (v.currentStationId == tm.connectedMetroStationId) {
                            currStation = tm.destination
                            nextStation = tm.connectedMetroStationId
                            dir = tm.origin
                        } else {
                            currStation = tm.connectedMetroStationId
                            nextStation = tm.destination
                            dir = tm.destination
                        }
                    }
                }
            }

            v.copy(
                progress = nextProgress,
                currentStationId = currStation,
                nextStationId = nextStation,
                direction = dir,
                status = if (nextProgress < 0.1f) "Detenido en Estación" else "En Movimiento"
            )
        }
        simulatedVehicles = updated.toMutableList()
        return simulatedVehicles
    }
}

class SyntheticAlertProvider : ServiceAlertProvider {
    private val alertsList = mutableListOf<ServiceAlert>()

    init {
        // Pre-populate some illustrative alerts typical of operational transit (e.g., delays on L2)
        alertsList.add(
            ServiceAlert(
                id = "ALERT_L2_DELAY",
                incidentType = "Falla técnica",
                severity = "WARN",
                affectedLineId = "L2",
                affectedStationId = "UNIVERSIDAD",
                cause = "Mantenimiento preventivo de vías elevado",
                description = "Línea 2 presenta retrasos de 6–10 min entre Universidad y Sendero.",
                expectedRecovery = "Próximas 2 horas",
                alternativeRoute = "Línea 1 + Transmetro Sendero-Escobedo"
            )
        )
    }

    override fun getActiveAlerts(): List<ServiceAlert> = alertsList

    override fun addAlert(alert: ServiceAlert) {
        alertsList.add(alert)
    }

    override fun removeAlert(id: String) {
        alertsList.removeAll { it.id == id }
    }
}

class SyntheticWeatherProvider : WeatherProvider {
    private var state = WeatherState.CLEAR_SKY

    override fun getCurrentWeather(): WeatherState = state

    override fun setWeather(state: WeatherState) {
        this.state = state
    }
}

// --- Routing Engine (Dijkstra/BFS graph implementation with weights, transfers & disruptions) ---

class RoutingEngine(
    private val transitProvider: TransitProvider,
    private val serviceAlertProvider: ServiceAlertProvider,
    private val weatherProvider: WeatherProvider
) {
    // A node in our routing graph represents a station or a transfer point
    data class GraphNode(
        val stationId: String,
        val lineId: String,
        val isTransmetro: Boolean = false
    )

    data class GraphEdge(
        val fromNode: GraphNode,
        val toNode: GraphNode,
        val weightMinutes: Int,
        val type: String, // "METRO_TRAVEL", "TRANSMETRO_TRAVEL", "TRANSFER", "WALKING"
        val lineId: String? = null,
        val transmetroRouteId: String? = null
    )

    fun calculateJourneys(
        originName: String,
        destinationName: String,
        preference: JourneyPreference
    ): List<Journey> {
        // Map destination names or addresses back to stations
        val stations = transitProvider.getLines().flatMap { it.stations }
        
        // Find best match for origin and destination station IDs
        val originStation = findStationByNameOrLandmark(originName) ?: return emptyList()
        val destinationStation = findStationByNameOrLandmark(destinationName) ?: return emptyList()

        if (originStation.id == destinationStation.id) {
            return listOf(
                Journey(
                    id = "J-SAME",
                    originName = originName,
                    destinationName = destinationName,
                    totalDurationMinutes = 0,
                    totalFareMxn = 0.0,
                    legs = listOf(
                        JourneyLeg("WALKING", null, "Origen igual a destino", originStation.id, originStation.name, destinationStation.id, destinationStation.name, 0, "Ya estás en tu destino")
                    ),
                    isAccessible = true,
                    preference = preference
                )
            )
        }

        // Build the current network graph dynamically
        val graph = mutableMapOf<GraphNode, MutableList<GraphEdge>>()

        // 1. Add Metro edges
        transitProvider.getLines().forEach { line ->
            val lineStations = line.stations
            // Check if this line is currently suspended or delayed
            val alert = serviceAlertProvider.getActiveAlerts().find { it.affectedLineId == line.id && it.severity == "CRITICAL" }
            val isSuspended = alert != null

            if (!isSuspended) {
                for (i in 0 until lineStations.size - 1) {
                    val stA = lineStations[i]
                    val stB = lineStations[i + 1]

                    val nodeA = GraphNode(stA.id, line.id)
                    val nodeB = GraphNode(stB.id, line.id)

                    // Base weight: 2 minutes per station stop
                    var weight = 2

                    // Disruption penalty
                    val lineAlert = serviceAlertProvider.getActiveAlerts().find { it.affectedLineId == line.id && it.severity == "WARN" }
                    if (lineAlert != null) {
                        weight += 6 // Add 6 minutes delay penalty
                    }

                    // Weather impact (e.g. heavy rain slow down elevated viaducts)
                    val weather = weatherProvider.getCurrentWeather()
                    if (weather == WeatherState.HEAVY_RAIN || weather == WeatherState.STORM) {
                        weight += 1
                    }

                    val edgeAB = GraphEdge(nodeA, nodeB, weight, "METRO_TRAVEL", line.id)
                    val edgeBA = GraphEdge(nodeB, nodeA, weight, "METRO_TRAVEL", line.id)

                    graph.getOrPut(nodeA) { mutableListOf() }.add(edgeAB)
                    graph.getOrPut(nodeB) { mutableListOf() }.add(edgeBA)
                }
            }
        }

        // 2. Add Transfer Interconnections at identical-name stations across lines
        // In Monterrey, e.g. "CUAUHTEMOC_L1" and "CUAUHTEMOC_L2", or "FELIX_U_GOMEZ_L1" and "FELIX_U_GOMEZ_L3"
        val allNodes = graph.keys.toList()
        for (i in allNodes.indices) {
            for (j in i + 1 until allNodes.size) {
                val nodeA = allNodes[i]
                val nodeB = allNodes[j]
                
                // If station names are related or they are interchange points
                val sameStation = nodeA.stationId.substringBefore("_") == nodeB.stationId.substringBefore("_")
                if (sameStation && nodeA.lineId != nodeB.lineId) {
                    // Transfer penalty: Base 3 minutes
                    var transferWeight = 3
                    if (preference == JourneyPreference.MENOS_TRANSBORDOS) {
                        transferWeight += 15 // massive penalty to avoid transfers
                    }
                    if (preference == JourneyPreference.ACCESIBLE) {
                        // Check if elevator exists for transfers
                        val stA = transitProvider.getStation(nodeA.stationId)
                        val stB = transitProvider.getStation(nodeB.stationId)
                        if (stA?.hasElevator == false || stB?.hasElevator == false) {
                            transferWeight += 20 // heavily penalize non-accessible transfer
                        }
                    }

                    val edgeAB = GraphEdge(nodeA, nodeB, transferWeight, "TRANSFER")
                    val edgeBA = GraphEdge(nodeB, nodeA, transferWeight, "TRANSFER")

                    graph.getOrPut(nodeA) { mutableListOf() }.add(edgeAB)
                    graph.getOrPut(nodeB) { mutableListOf() }.add(edgeBA)
                }
            }
        }

        // 3. Add Transmetro routes edges
        transitProvider.getTransmetroRoutes().forEach { tm ->
            val metroNode = graph.keys.find { it.stationId.substringBefore("_") == tm.connectedMetroStationId.substringBefore("_") }
            if (metroNode != null) {
                // Add Transmetro node
                val tmNode = GraphNode(tm.id, "TRANSMETRO", isTransmetro = true)
                // Edge from connected metro station to transmetro (waiting time)
                var waitWeight = tm.frequencyMinutes
                if (preference == JourneyPreference.MENOS_CAMINATA) {
                    waitWeight += 2 // slight penalty
                }

                val edgeMetroToTM = GraphEdge(metroNode, tmNode, waitWeight, "TRANSFER", transmetroRouteId = tm.id)
                val edgeTMToMetro = GraphEdge(tmNode, metroNode, 3, "TRANSFER") // walking transfer to platform

                graph.getOrPut(metroNode) { mutableListOf() }.add(edgeMetroToTM)
                graph.getOrPut(tmNode) { mutableListOf() }.add(edgeTMToMetro)

                // Add edge to final destination stop of Transmetro
                val destNode = GraphNode(tm.destination, "TRANSMETRO_STOP")
                val edgeTravel = GraphEdge(tmNode, destNode, 10, "TRANSMETRO_TRAVEL", transmetroRouteId = tm.id)
                graph.getOrPut(tmNode) { mutableListOf() }.add(edgeTravel)
            }
        }

        // 4. Run Dijkstra algorithm from origin station nodes
        val originNodes = graph.keys.filter { it.stationId.substringBefore("_") == originStation.id.substringBefore("_") }
        val destNodes = graph.keys.filter { it.stationId.substringBefore("_") == destinationStation.id.substringBefore("_") }

        if (originNodes.isEmpty() || destNodes.isEmpty()) {
            // Fallback simple static 1-leg journey if graph lookup fails
            return createFallbackJourney(originStation, destinationStation, preference)
        }

        val journeys = mutableListOf<Journey>()

        originNodes.forEach { startNode ->
            val (distances, predecessors) = runDijkstra(graph, startNode)

            destNodes.forEach { endNode ->
                val dist = distances[endNode]
                if (dist != null && dist < Int.MAX_VALUE / 2) {
                    val pathEdges = reconstructPath(predecessors, endNode)
                    val legs = mutableListOf<JourneyLeg>()

                    // First leg: entry walking
                    legs.add(
                        JourneyLeg(
                            type = "WALKING",
                            startStationId = "ORIGIN",
                            startStationName = originName,
                            endStationId = startNode.stationId,
                            endStationName = transitProvider.getStation(startNode.stationId)?.name ?: startNode.stationId,
                            durationMinutes = 3,
                            instruction = "Entra a la estación ${transitProvider.getStation(startNode.stationId)?.name ?: startNode.stationId}"
                        )
                    )

                    pathEdges.forEach { edge ->
                        val fromStationName = transitProvider.getStation(edge.fromNode.stationId)?.name ?: edge.fromNode.stationId
                        val toStationName = transitProvider.getStation(edge.toNode.stationId)?.name ?: edge.toNode.stationId

                        when (edge.type) {
                            "METRO_TRAVEL" -> {
                                val line = transitProvider.getLines().find { it.id == edge.lineId }
                                legs.add(
                                    JourneyLeg(
                                        type = "METRO",
                                        lineId = edge.lineId,
                                        routeName = line?.name ?: "Metro",
                                        startStationId = edge.fromNode.stationId,
                                        startStationName = fromStationName,
                                        endStationId = edge.toNode.stationId,
                                        endStationName = toStationName,
                                        durationMinutes = edge.weightMinutes,
                                        instruction = "Toma la ${line?.name ?: "Metro"} con dirección a ${line?.directionSecondary ?: "Terminal"}"
                                    )
                                )
                            }
                            "TRANSMETRO_TRAVEL" -> {
                                val tm = transitProvider.getTransmetroRoutes().find { it.id == edge.transmetroRouteId }
                                legs.add(
                                    JourneyLeg(
                                        type = "TRANSMETRO",
                                        routeName = tm?.name ?: "Transmetro",
                                        startStationId = edge.fromNode.stationId,
                                        startStationName = fromStationName,
                                        endStationId = edge.toNode.stationId,
                                        endStationName = toStationName,
                                        durationMinutes = edge.weightMinutes,
                                        instruction = "Toma el Transmetro con dirección a ${tm?.destination ?: "Destino"}"
                                    )
                                )
                            }
                            "TRANSFER" -> {
                                legs.add(
                                    JourneyLeg(
                                        type = "TRANSFER",
                                        startStationId = edge.fromNode.stationId,
                                        startStationName = fromStationName,
                                        endStationId = edge.toNode.stationId,
                                        endStationName = toStationName,
                                        durationMinutes = edge.weightMinutes,
                                        instruction = "Cambio de línea: Sigue los letreros de transbordo hacia $toStationName"
                                    )
                                )
                            }
                        }
                    }

                    // Post-process walking time based on weather
                    var weatherNote = ""
                    var extraWalking = 0
                    val weather = weatherProvider.getCurrentWeather()
                    if (weather == WeatherState.EXTREME_HEAT) {
                        extraWalking = 2
                        weatherNote = " (Calor extremo: camina despacio e hidrátate)"
                    } else if (weather == WeatherState.HEAVY_RAIN) {
                        extraWalking = 6
                        weatherNote = " (Lluvia intensa: usa paraguas y ten precaución)"
                    }

                    // Add final walking segment
                    legs.add(
                        JourneyLeg(
                            type = "WALKING",
                            startStationId = endNode.stationId,
                            startStationName = transitProvider.getStation(endNode.stationId)?.name ?: endNode.stationId,
                            endStationId = "DEST",
                            endStationName = destinationName,
                            durationMinutes = 5 + extraWalking,
                            instruction = "Camina hacia tu destino: $destinationName$weatherNote"
                        )
                    )

                    // Calculate total duration and fare
                    val totalDur = legs.sumOf { it.durationMinutes }
                    val totalFare = SyntheticFareProvider().calculateJourneyFare(legs, "ME MUEVO")

                    // Accessibility check
                    val isAcc = legs.none { leg ->
                        if (leg.type == "METRO") {
                            val stStart = transitProvider.getStation(leg.startStationId ?: "")
                            val stEnd = transitProvider.getStation(leg.endStationId ?: "")
                            stStart?.hasElevator == false || stEnd?.hasElevator == false
                        } else false
                    }

                    journeys.add(
                        Journey(
                            id = "J-${startNode.stationId}-${endNode.stationId}-${preference.name}",
                            originName = originName,
                            destinationName = destinationName,
                            totalDurationMinutes = totalDur,
                            totalFareMxn = totalFare,
                            legs = consolidateLegs(legs),
                            isAccessible = isAcc,
                            preference = preference
                        )
                    )
                }
            }
        }

        // Sort by preference
        return when (preference) {
            JourneyPreference.MAS_RAPIDO -> journeys.sortedBy { it.totalDurationMinutes }
            JourneyPreference.MENOS_TRANSBORDOS -> journeys.sortedBy { j -> j.legs.count { it.type == "TRANSFER" } }
            JourneyPreference.MENOS_CAMINATA -> journeys.sortedBy { j -> j.legs.filter { it.type == "WALKING" }.sumOf { it.durationMinutes } }
            JourneyPreference.ACCESIBLE -> journeys.filter { it.isAccessible }.sortedBy { it.totalDurationMinutes }.ifEmpty { journeys.sortedBy { it.totalDurationMinutes } }
        }
    }

    private fun runDijkstra(
        graph: Map<GraphNode, List<GraphEdge>>,
        startNode: GraphNode
    ): Pair<Map<GraphNode, Int>, Map<GraphNode, GraphEdge?>> {
        val distances = mutableMapOf<GraphNode, Int>().withDefault { Int.MAX_VALUE }
        val predecessors = mutableMapOf<GraphNode, GraphEdge?>()
        val visited = mutableSetOf<GraphNode>()

        distances[startNode] = 0
        predecessors[startNode] = null

        val unvisited = graph.keys.toMutableSet()

        while (unvisited.isNotEmpty()) {
            // Find unvisited node with minimum distance
            val currNode = unvisited.minByOrNull { distances.getValue(it) } ?: break
            if (distances.getValue(currNode) == Int.MAX_VALUE) break

            unvisited.remove(currNode)
            visited.add(currNode)

            val edges = graph[currNode] ?: emptyList()
            for (edge in edges) {
                val neighbor = edge.toNode
                if (neighbor in visited) continue

                val newDist = distances.getValue(currNode) + edge.weightMinutes
                if (newDist < distances.getValue(neighbor)) {
                    distances[neighbor] = newDist
                    predecessors[neighbor] = edge
                    unvisited.add(neighbor) // Ensure neighbor is in graph set
                }
            }
        }

        return Pair(distances, predecessors)
    }

    private fun reconstructPath(
        predecessors: Map<GraphNode, GraphEdge?>,
        endNode: GraphNode
    ): List<GraphEdge> {
        val path = mutableListOf<GraphEdge>()
        var curr: GraphNode? = endNode
        while (curr != null) {
            val edge = predecessors[curr]
            if (edge != null) {
                path.add(0, edge)
                curr = edge.fromNode
            } else {
                break
            }
        }
        return path
    }

    private fun consolidateLegs(legs: List<JourneyLeg>): List<JourneyLeg> {
        // Consolidate consecutive METRO segments of same LineId or consecutive WALKING
        val consolidated = mutableListOf<JourneyLeg>()
        legs.forEach { leg ->
            if (consolidated.isEmpty()) {
                consolidated.add(leg)
            } else {
                val last = consolidated.last()
                if (last.type == "METRO" && leg.type == "METRO" && last.lineId == leg.lineId) {
                    // Merge
                    val merged = last.copy(
                        endStationId = leg.endStationId,
                        endStationName = leg.endStationName,
                        durationMinutes = last.durationMinutes + leg.durationMinutes,
                        stopsList = last.stopsList + (last.endStationName ?: "")
                    )
                    consolidated[consolidated.size - 1] = merged
                } else {
                    consolidated.add(leg)
                }
            }
        }
        return consolidated
    }

    private fun findStationByNameOrLandmark(name: String): Station? {
        val cleanName = name.lowercase().trim()
        val provider = SyntheticTransitProvider()
        
        // 1. Direct station name match
        val lines = provider.getLines()
        for (line in lines) {
            for (station in line.stations) {
                if (station.name.lowercase() == cleanName || station.id.lowercase() == cleanName) {
                    return station
                }
            }
        }

        // 2. Contains search
        for (line in lines) {
            for (station in line.stations) {
                if (station.name.lowercase().contains(cleanName) || cleanName.contains(station.name.lowercase())) {
                    return station
                }
            }
        }

        // 3. Landmark match
        val landmark = provider.getDestinations().find { it.name.lowercase().contains(cleanName) || cleanName.contains(it.name.lowercase()) || it.id.lowercase() == cleanName }
        if (landmark != null) {
            return provider.getStation(landmark.nearestStationId)
        }

        // Fallbacks
        return when {
            cleanName.contains("univ") || cleanName.contains("estadio") -> provider.getStation("UNIVERSIDAD")
            cleanName.contains("fundidora") -> provider.getStation("Y_GRIEGA")
            cleanName.contains("centro") || cleanName.contains("cuauh") -> provider.getStation("CUAUHTEMOC_L1")
            cleanName.contains("plaza") || cleanName.contains("zaragoza") -> provider.getStation("ZARAGOZA_L2")
            cleanName.contains("aeropuerto") -> provider.getStation("Y_GRIEGA")
            cleanName.contains("silla") -> provider.getStation("EXPOSICION")
            cleanName.contains("bernabe") -> provider.getStation("SAN_BERNABE")
            else -> lines.first().stations.first() // default safety fallback
        }
    }

    private fun createFallbackJourney(
        origin: Station,
        dest: Station,
        pref: JourneyPreference
    ): List<Journey> {
        val legs = listOf(
            JourneyLeg("WALKING", null, "Entrar a la estación", origin.id, origin.name, origin.id, origin.name, 3, "Entra a la estación ${origin.name}"),
            JourneyLeg("METRO", "L1", "Línea 1", origin.id, origin.name, dest.id, dest.name, 15, "Toma la Línea 1 con dirección a Exposición"),
            JourneyLeg("WALKING", null, "Camina a destino", dest.id, dest.name, dest.id, dest.name, 5, "Camina a tu destino")
        )
        return listOf(
            Journey(
                id = "J-FALLBACK",
                originName = origin.name,
                destinationName = dest.name,
                totalDurationMinutes = 23,
                totalFareMxn = 9.90,
                legs = legs,
                isAccessible = origin.hasElevator && dest.hasElevator,
                preference = pref
            )
        )
    }
}
