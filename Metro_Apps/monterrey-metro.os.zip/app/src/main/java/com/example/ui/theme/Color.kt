package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Monterrey Industrial Modernism color system
val MonterreyGraphite = Color(0xFF16181A) // Deep industrial graphite
val ConcreteGray = Color(0xFFE2E4E6)      // Warm engineering concrete
val EngineeringSteel = Color(0xFF4C555C)  // Solid industrial steel
val OffWhite = Color(0xFFF9FAFB)          // Clean concrete paper
val WarmNeutral = Color(0xFFF2ECE4)       // Monterrey sunlight neutral

val LineYellow = Color(0xFFFFAE00)        // Line 1: Gold
val LineGreen = Color(0xFF00A550)         // Line 2: Green
val LineOrange = Color(0xFFFF5E00)        // Line 3: Orange
val LineCyan = Color(0xFF00A9E0)          // Line 4: Cyan
val LineRed = Color(0xFFE31B23)           // Line 5: Red
val LinePurple = Color(0xFF8A2BE2)        // Line 6: Purple

val AlertRed = Color(0xFFD9383A)
val SuccessGreen = Color(0xFF2E7D32)
val InfoBlue = Color(0xFF0288D1)
