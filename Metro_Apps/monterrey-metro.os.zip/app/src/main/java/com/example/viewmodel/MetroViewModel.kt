package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.database.MetroDatabase
import com.example.model.*
import com.example.service.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppScreen {
    HOME,
    MONTERREY_AHORA,
    STATION_DETAILS,
    JOURNEY_PLANNER,
    JOURNEY_ACTIVE,
    PAGO,
    SETTINGS
}

enum class QRPaymentState {
    READY,
    QR_GENERATED,
    VALIDATED,
    ACCESS_GRANTED,
    JOURNEY_ACTIVE
}

data class AppUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val selectedStationId: String? = null,
    val selectedLineId: String? = null,
    val searchOrigin: String = "Universidad",
    val searchDestination: String = "",
    val searchResults: List<Journey> = emptyList(),
    val selectedJourney: Journey? = null,
    val isTravelling: Boolean = false,
    val travellingStepIndex: Int = 0,
    val currentLanguage: String = "ES", // "ES" or "EN"
    val reducedMotion: Boolean = false,
    val highContrast: Boolean = false,
    val accessibleRoutingOnly: Boolean = false,
    
    // Payment & Cards
    val meMuevoBalance: Double = 84.20,
    val meMuevoStatus: String = "Activa",
    val recentTransactions: List<TransactionEntity> = emptyList(),
    val qrState: QRPaymentState = QRPaymentState.READY,
    val qrCodePayload: String? = null,
    val showQRDialog: Boolean = false,
    
    // Favorites
    val favoritePlaces: List<FavoritePlaceEntity> = emptyList(),
    val favoriteRoutes: List<RecentRouteEntity> = emptyList(),

    // Service Alerts & Weather
    val activeAlerts: List<ServiceAlert> = emptyList(),
    val weatherState: WeatherState = WeatherState.CLEAR_SKY,

    // Simulation
    val simulationMode: String = "NORMAL", // NORMAL, RUSH_HOUR, DELAY, INCIDENT
    val liveVehicles: List<Vehicle> = emptyList(),

    // Notifications banner
    val activeNotification: String? = null,

    // Active Demo Step Info
    val activeDemoIndex: Int = 0, // 0 = none, 1 = Demo 1, 2 = Demo 2, etc.
    val demoStepMessage: String? = null
)

class MetroViewModel(application: Application) : AndroidViewModel(application) {

    // Providers & Services
    val transitProvider: TransitProvider = SyntheticTransitProvider()
    val fareProvider: FareProvider = SyntheticFareProvider()
    val alertProvider: ServiceAlertProvider = SyntheticAlertProvider()
    val weatherProvider: WeatherProvider = SyntheticWeatherProvider()
    val vehicleProvider: VehicleProvider = SyntheticVehicleProvider()
    val routingEngine = RoutingEngine(transitProvider, alertProvider, weatherProvider)

    // Room Database
    private val database: MetroDatabase by lazy {
        Room.databaseBuilder(
            application,
            MetroDatabase::class.java,
            "metrorrey_os_database"
        ).fallbackToDestructiveMigration().build()
    }

    private val _uiState = MutableStateFlow(AppUiState())
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

    private var simulationJob: Job? = null

    init {
        // Load initial service status, weather, and alerts
        _uiState.update {
            it.copy(
                activeAlerts = alertProvider.getActiveAlerts(),
                weatherState = weatherProvider.getCurrentWeather(),
                liveVehicles = vehicleProvider.getVehicles("NORMAL")
            )
        }

        // Setup Local Room DB reactive observers
        observeDatabase()

        // Seed initial Room DB data if empty
        seedInitialDatabase()

        // Start simulated live-vehicle ticker (moving trains every 2.5 seconds)
        startSimulationLoop()
    }

    private fun observeDatabase() {
        viewModelScope.launch {
            database.favoritePlaceDao().getAllFavorites().collect { favorites ->
                _uiState.update { it.copy(favoritePlaces = favorites) }
            }
        }
        viewModelScope.launch {
            database.meMuevoCardDao().getCard().collect { card ->
                if (card != null) {
                    _uiState.update { it.copy(meMuevoBalance = card.balanceMxn, meMuevoStatus = card.cardStatus) }
                }
            }
        }
        viewModelScope.launch {
            database.transactionDao().getAllTransactions().collect { list ->
                _uiState.update { it.copy(recentTransactions = list) }
            }
        }
        viewModelScope.launch {
            database.recentRouteDao().getRecentRoutes().collect { routes ->
                _uiState.update { it.copy(favoriteRoutes = routes) }
            }
        }
    }

    private fun seedInitialDatabase() {
        viewModelScope.launch {
            // Seed a simulated Me Muevo Card
            val existing = database.meMuevoCardDao().getCardDirect()
            if (existing == null) {
                database.meMuevoCardDao().insertOrUpdateCard(
                    MeMuevoCardEntity(
                        id = "MM-98317-092",
                        cardNumber = "9831 7092 1102 5481",
                        balanceMxn = 84.20,
                        cardStatus = "Activa",
                        linkedAccountEmail = "pasajero@metrorrey.mx"
                    )
                )
                // Seed initial favorites
                database.favoritePlaceDao().insertFavorite(FavoritePlaceEntity("FAV_CASA", "Casa", "Casa", "UNIVERSIDAD", "San Nicolás Centro"))
                database.favoritePlaceDao().insertFavorite(FavoritePlaceEntity("FAV_TRABAJO", "Trabajo", "Trabajo", "CUAUHTEMOC_L1", "Monterrey Centro"))
                database.favoritePlaceDao().insertFavorite(FavoritePlaceEntity("FAV_UNIV", "UANL", "Universidad", "UNIVERSIDAD", "Ciudad Universitaria"))

                // Seed some initial transaction logs
                database.transactionDao().insertTransaction(TransactionEntity(timestamp = System.currentTimeMillis() - 7200000, description = "Ingreso Línea 2 - Universidad", amountMxn = -9.90, paymentMethod = "ME MUEVO", isSimulated = true))
                database.transactionDao().insertTransaction(TransactionEntity(timestamp = System.currentTimeMillis() - 86400000, description = "Recarga Tarjeta - OXXO Centro", amountMxn = 100.00, paymentMethod = "ME MUEVO", isSimulated = true))
                database.transactionDao().insertTransaction(TransactionEntity(timestamp = System.currentTimeMillis() - 172800000, description = "Ingreso Transmetro - San Nicolás", amountMxn = -15.00, paymentMethod = "QR URBANI", isSimulated = true))
            }
        }
    }

    private fun startSimulationLoop() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            while (true) {
                delay(2500)
                val mode = _uiState.value.simulationMode
                val alerts = _uiState.value.activeAlerts
                val updatedVehicles = vehicleProvider.tickSimulation(mode, alerts)
                _uiState.update { it.copy(liveVehicles = updatedVehicles) }
            }
        }
    }

    // --- UI Interactions ---

    fun navigateTo(screen: AppScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun selectStation(stationId: String) {
        _uiState.update { it.copy(selectedStationId = stationId, currentScreen = AppScreen.STATION_DETAILS) }
    }

    fun selectLine(lineId: String) {
        _uiState.update { it.copy(selectedLineId = lineId) }
    }

    fun updateSearchOrigin(origin: String) {
        _uiState.update { it.copy(searchOrigin = origin) }
    }

    fun updateSearchDestination(destination: String) {
        _uiState.update { it.copy(searchDestination = destination) }
    }

    fun changeLanguage() {
        _uiState.update { it.copy(currentLanguage = if (it.currentLanguage == "ES") "EN" else "ES") }
    }

    fun toggleReducedMotion() {
        _uiState.update { it.copy(reducedMotion = !it.reducedMotion) }
    }

    fun toggleHighContrast() {
        _uiState.update { it.copy(highContrast = !it.highContrast) }
    }

    fun toggleAccessibleRoutingOnly() {
        _uiState.update { it.copy(accessibleRoutingOnly = !it.accessibleRoutingOnly) }
    }

    fun setSimulationMode(mode: String) {
        _uiState.update { it.copy(simulationMode = mode) }
        showNotification("Modo de simulación cambiado a: $mode")
    }

    fun setWeather(state: WeatherState) {
        weatherProvider.setWeather(state)
        _uiState.update { it.copy(weatherState = state) }
        val msg = when (state) {
            WeatherState.CLEAR_SKY -> "Clima: Despejado, cielo azul"
            WeatherState.EXTREME_HEAT -> "Clima: Calor Extremo 41°C. Precaución."
            WeatherState.HEAVY_RAIN -> "Clima: Lluvia Intensa. Retrasos operacionales posibles."
            WeatherState.STORM -> "Clima: Tormenta Eléctrica."
            WeatherState.FLOODING -> "Clima: Inundación en vialidades."
        }
        showNotification(msg)
        // Recalculate if there is a search active
        if (_uiState.value.searchDestination.isNotEmpty()) {
            planJourney()
        }
    }

    fun showNotification(message: String) {
        _uiState.update { it.copy(activeNotification = message) }
        viewModelScope.launch {
            delay(4000)
            if (_uiState.value.activeNotification == message) {
                _uiState.update { it.copy(activeNotification = null) }
            }
        }
    }

    fun planJourney() {
        val state = _uiState.value
        if (state.searchOrigin.isEmpty() || state.searchDestination.isEmpty()) return

        val pref = if (state.accessibleRoutingOnly) JourneyPreference.ACCESIBLE else JourneyPreference.MAS_RAPIDO
        val results = routingEngine.calculateJourneys(state.searchOrigin, state.searchDestination, pref)

        _uiState.update {
            it.copy(
                searchResults = results,
                selectedJourney = results.firstOrNull(),
                currentScreen = AppScreen.JOURNEY_PLANNER
            )
        }

        // Store in recent routes
        viewModelScope.launch {
            database.recentRouteDao().insertRecentRoute(
                RecentRouteEntity(
                    originName = state.searchOrigin,
                    destinationName = state.searchDestination,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    fun startJourney(journey: Journey) {
        _uiState.update {
            it.copy(
                selectedJourney = journey,
                isTravelling = true,
                travellingStepIndex = 0,
                currentScreen = AppScreen.JOURNEY_ACTIVE
            )
        }
    }

    fun nextJourneyStep() {
        val state = _uiState.value
        val journey = state.selectedJourney ?: return
        val maxSteps = journey.legs.size
        if (state.travellingStepIndex < maxSteps - 1) {
            _uiState.update { it.copy(travellingStepIndex = it.travellingStepIndex + 1) }
        } else {
            // Arrived
            _uiState.update {
                it.copy(
                    isTravelling = false,
                    currentScreen = AppScreen.HOME,
                    searchDestination = ""
                )
            }
            showNotification("¡Has llegado a tu destino!")
        }
    }

    // --- Favorites Actions ---

    fun addFavorite(name: String, type: String, stationId: String?, address: String) {
        viewModelScope.launch {
            val fav = FavoritePlaceEntity(
                id = "FAV_${System.currentTimeMillis()}",
                name = name,
                type = type,
                stationId = stationId,
                address = address
            )
            database.favoritePlaceDao().insertFavorite(fav)
            showNotification("Favorito '$name' agregado")
        }
    }

    fun removeFavorite(fav: FavoritePlaceEntity) {
        viewModelScope.launch {
            database.favoritePlaceDao().deleteFavorite(fav)
            showNotification("Favorito removido")
        }
    }

    // --- Payment Me Muevo & QR State Machine ---

    fun generateQRCode() {
        val state = _uiState.value
        if (state.meMuevoBalance < 9.90) {
            showNotification("Saldo insuficiente para generar QR ($9.90 MXN mínimo)")
            return
        }

        val payload = "URBANI-METRO-${System.currentTimeMillis()}-DETERMINISTIC-KEY"
        _uiState.update {
            it.copy(
                qrState = QRPaymentState.QR_GENERATED,
                qrCodePayload = payload,
                showQRDialog = true
            )
        }

        // Simulate validation and granting access
        viewModelScope.launch {
            delay(2000)
            if (_uiState.value.qrState == QRPaymentState.QR_GENERATED) {
                _uiState.update { it.copy(qrState = QRPaymentState.VALIDATED) }
                delay(1200)
                _uiState.update { it.copy(qrState = QRPaymentState.ACCESS_GRANTED) }
                
                // Deduct fare
                val currentCard = database.meMuevoCardDao().getCardDirect()
                if (currentCard != null) {
                    val finalBalance = currentCard.balanceMxn - 9.90
                    database.meMuevoCardDao().updateBalance(currentCard.id, finalBalance)
                    database.transactionDao().insertTransaction(
                        TransactionEntity(
                            timestamp = System.currentTimeMillis(),
                            description = "Boleto QR - Acceso Torniquete",
                            amountMxn = -9.90,
                            paymentMethod = "QR URBANI"
                        )
                    )
                }

                delay(1500)
                _uiState.update { it.copy(qrState = QRPaymentState.JOURNEY_ACTIVE, showQRDialog = false) }
                showNotification("Torniquete Liberado. ¡Buen viaje!")
            }
        }
    }

    fun recargarTarjeta(amount: Double) {
        viewModelScope.launch {
            val currentCard = database.meMuevoCardDao().getCardDirect()
            if (currentCard != null) {
                val newBal = currentCard.balanceMxn + amount
                database.meMuevoCardDao().updateBalance(currentCard.id, newBal)
                database.transactionDao().insertTransaction(
                    TransactionEntity(
                        timestamp = System.currentTimeMillis(),
                        description = "Recarga Tarjeta Me Muevo",
                        amountMxn = amount,
                        paymentMethod = "ME MUEVO"
                    )
                )
                showNotification("Recarga de $$amount MXN exitosa (SIMULADO)")
            }
        }
    }

    fun dismissQR() {
        _uiState.update { it.copy(showQRDialog = false, qrState = QRPaymentState.READY) }
    }

    // --- Demo Scenarios Actions ---

    fun runDemo(demoId: Int) {
        viewModelScope.launch {
            _uiState.update { it.copy(activeDemoIndex = demoId) }
            when (demoId) {
                1 -> runDemo01()
                2 -> runDemo02()
                3 -> runDemo03()
                4 -> runDemo04()
                5 -> runDemo05()
            }
        }
    }

    private suspend fun runDemo01() {
        // DEMO 01: Universidad -> Centro
        // Search destination, calculate journey, select L2, show station, departures, enter journey mode, transfer, arrive
        updateDemoMsg("Demo 01 Iniciado: Buscando viaje desde 'Universidad' a 'Centro'")
        delay(1500)
        _uiState.update { it.copy(searchOrigin = "Universidad", searchDestination = "Macroplaza") }
        planJourney()
        
        updateDemoMsg("Plan de viaje calculado. Seleccionando la opción recomendada (Línea 2 Directa)")
        delay(2000)
        val journey = _uiState.value.searchResults.firstOrNull()
        if (journey != null) {
            updateDemoMsg("Estudiando departures en la estación 'Universidad'. Próximo tren en 2 min.")
            delay(1500)
            selectStation("UNIVERSIDAD")
            
            delay(2000)
            updateDemoMsg("Presionando 'EMPEZAR VIAJE' para iniciar la asistencia de navegación.")
            delay(1500)
            startJourney(journey)
            
            delay(2000)
            updateDemoMsg("A bordo de Línea 2. Próxima parada: Regina.")
            _uiState.update { it.copy(travellingStepIndex = 1) }
            
            delay(2500)
            updateDemoMsg("Llegando a General Zaragoza. ¡Destino alcanzado exitosamente!")
            _uiState.update { it.copy(travellingStepIndex = 2) }
            
            delay(2000)
            _uiState.update { it.copy(isTravelling = false, currentScreen = AppScreen.HOME, activeDemoIndex = 0, demoStepMessage = null) }
            showNotification("Demo 01 completado")
        }
    }

    private suspend fun runDemo02() {
        // DEMO 02: San Bernabé -> Fundidora (Metro + transfer, show fare, show history)
        updateDemoMsg("Demo 02: Buscando ruta de San Bernabé a Fundidora con transbordo")
        delay(1500)
        _uiState.update { it.copy(searchOrigin = "San Bernabé", searchDestination = "Fundidora") }
        planJourney()

        updateDemoMsg("Calculado. Tarifa integrada: $9.90 MXN (Transbordo Metro-Metro sin costo adicional)")
        delay(2500)
        
        updateDemoMsg("Visualizando historial de viajes de la tarjeta Me Muevo")
        delay(2000)
        navigateTo(AppScreen.PAGO)

        delay(3000)
        _uiState.update { it.copy(activeDemoIndex = 0, demoStepMessage = null, currentScreen = AppScreen.HOME) }
        showNotification("Demo 02 completado")
    }

    private suspend fun runDemo03() {
        // DEMO 03: Centro -> Transmetro (Metro -> Transmetro, integrated transfer cost)
        updateDemoMsg("Demo 03: Viaje integrado Centro (Zaragoza) a Transmetro Universidad-San Nicolás")
        delay(1500)
        _uiState.update { it.copy(searchOrigin = "General Zaragoza", searchDestination = "Anáhuac") }
        planJourney()

        updateDemoMsg("Tarifa calculada: $15.00 MXN (Incluye Línea 2 + Transmetro Integrado de Me Muevo)")
        delay(3000)
        
        _uiState.update { it.copy(activeDemoIndex = 0, demoStepMessage = null, currentScreen = AppScreen.HOME) }
        showNotification("Demo 03 completado")
    }

    private suspend fun runDemo04() {
        // DEMO 04: Disruption (Línea 2 delay, passenger route affected, system recalculates alternative)
        updateDemoMsg("Demo 04: Pasajero planeando viaje 'Sendero' a 'Cuauhtémoc' con Línea 2 operativa")
        _uiState.update { it.copy(searchOrigin = "Sendero", searchDestination = "Cuauhtémoc") }
        planJourney()
        
        delay(2500)
        updateDemoMsg("¡Alerta de servicio detectada! Simulando falla en Línea 2 con retrasos graves")
        setSimulationMode("DELAY")
        
        delay(2000)
        updateDemoMsg("Vectores de ruta recalculados. El sistema propone alternativa acelerada evitando Línea 2")
        // Trigger planJourney again under disrupted state
        planJourney()

        delay(3000)
        _uiState.update { it.copy(activeDemoIndex = 0, demoStepMessage = null, currentScreen = AppScreen.HOME, simulationMode = "NORMAL") }
        showNotification("Demo 04 completado")
    }

    private suspend fun runDemo05() {
        // DEMO 05: QR Payment (Generate QR, Validate, Start travel)
        updateDemoMsg("Demo 05: Simulando proceso de pago digital QR URBANI")
        navigateTo(AppScreen.PAGO)
        delay(1500)

        updateDemoMsg("Generando ticket QR con saldo de la cuenta...")
        generateQRCode()

        delay(2500)
        updateDemoMsg("Código QR leído por torniquete. Validando credencial...")
        
        delay(2000)
        updateDemoMsg("¡Acceso concedido! Saldo descontado -$9.90 MXN. Torniquete abierto.")
        
        delay(2000)
        _uiState.update { it.copy(activeDemoIndex = 0, demoStepMessage = null, currentScreen = AppScreen.HOME) }
        showNotification("Demo 05 completado")
    }

    private fun updateDemoMsg(msg: String) {
        _uiState.update { it.copy(demoStepMessage = msg) }
    }
}
