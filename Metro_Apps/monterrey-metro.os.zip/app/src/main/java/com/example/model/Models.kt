package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- Domain Models ---

data class Station(
    val id: String,
    val name: String,
    val lineId: String,
    val hasElevator: Boolean,
    val hasEscalator: Boolean,
    val stepFreeAccess: Boolean,
    val accessibleRoute: Boolean,
    val entrances: List<String> = emptyList(),
    val exits: List<String> = emptyList(),
    val nearbyDestinations: List<String> = emptyList(),
    val coordinates: Pair<Float, Float> // For custom vector map rendering (X, Y percentage 0..100)
)

data class MetroLine(
    val id: String,
    val name: String,
    val shortName: String, // e.g. "L1", "L2"
    val colorHex: String,
    val stations: List<Station>,
    val directionPrimary: String, // terminal A
    val directionSecondary: String, // terminal B
    val operatingStatus: String = "NORMAL", // NORMAL, RETRASOS, SUSPENDIDO
    val frequencyMinutes: Int = 5,
    val frequencyRushHourMinutes: Int = 3
)

data class TransmetroRoute(
    val id: String,
    val name: String,
    val origin: String,
    val destination: String,
    val connectedMetroStationId: String,
    val frequencyMinutes: Int = 8,
    val fareMxn: Double = 15.0,
    val activeVehicles: Int = 4,
    val stops: List<String> = emptyList()
)

data class Vehicle(
    val id: String,
    val routeId: String, // lineId or transmetroRouteId
    val lineId: String?, // Null if Transmetro
    val direction: String, // Terminal name
    val currentStationId: String,
    val nextStationId: String,
    val progress: Float, // 0.0 to 1.0 between stations
    val speedKmh: Int = 45,
    val status: String = "En Movimiento", // Detenido, En Movimiento, En Estación
    val occupancy: String = "BAJA" // BAJA, MEDIA, ALTA, MUY ALTA
)

data class Departure(
    val id: String,
    val stationId: String,
    val lineId: String,
    val direction: String,
    val minutesLeft: Int,
    val isSimulated: Boolean = true
)

// --- Journey Planner Models ---

enum class JourneyPreference {
    MAS_RAPIDO,
    MENOS_TRANSBORDOS,
    MENOS_CAMINATA,
    ACCESIBLE
}

data class JourneyLeg(
    val type: String, // "WALKING", "METRO", "TRANSMETRO", "TRANSFER", "WAITING"
    val lineId: String? = null,
    val routeName: String? = null, // e.g. "Línea 2" or "Transmetro San Nicolás"
    val startStationId: String? = null,
    val startStationName: String? = null,
    val endStationId: String? = null,
    val endStationName: String? = null,
    val durationMinutes: Int,
    val instruction: String,
    val stopsList: List<String> = emptyList()
)

data class Journey(
    val id: String,
    val originName: String,
    val destinationName: String,
    val totalDurationMinutes: Int,
    val totalFareMxn: Double,
    val legs: List<JourneyLeg>,
    val isAccessible: Boolean,
    val preference: JourneyPreference
)

// --- Fares Engine Models ---

data class Fare(
    val id: String,
    val name: String,
    val basePriceMxn: Double,
    val transferDiscountMxn: Double,
    val maxTransferWindowMinutes: Int = 120
)

data class FarePolicy(
    val currentMetroFareMxn: Double = 9.90, // current real Metrorrey fare approx
    val currentTransmetroFareMxn: Double = 15.00,
    val integratedFareMxn: Double = 15.00, // Metro + Transmetro combined when using Me Muevo / URBANI
    val lastUpdated: String = "2026-09-23",
    val validity: String = "Vigente"
)

// --- Service Alert & Disruption Models ---

data class ServiceAlert(
    val id: String,
    val incidentType: String, // "Falla técnica", "Señales", "Clima", "Afluencia", "Obras"
    val severity: String, // "INFO", "WARN", "CRITICAL"
    val affectedLineId: String,
    val affectedStationId: String? = null,
    val cause: String,
    val description: String,
    val expectedRecovery: String,
    val alternativeRoute: String
)

// --- Weather Layer Models ---

enum class WeatherState {
    CLEAR_SKY,
    EXTREME_HEAT, // very typical in Monterrey!
    HEAVY_RAIN, // can cause viaduct checks or delays
    STORM,
    FLOODING
}

// --- Local Database Room Entities ---

@Entity(tableName = "favorite_places")
data class FavoritePlaceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String, // "Casa", "Trabajo", "Universidad", "Estadio", "Aeropuerto", "Otro"
    val stationId: String?,
    val address: String
)

@Entity(tableName = "me_muevo_card")
data class MeMuevoCardEntity(
    @PrimaryKey val id: String,
    val cardNumber: String,
    val balanceMxn: Double,
    val cardStatus: String, // "Activa", "Bloqueada"
    val linkedAccountEmail: String
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val description: String, // e.g. "Ingreso Línea 2 - Universidad"
    val amountMxn: Double, // e.g. -9.90 or +100.00 (reload)
    val paymentMethod: String, // "ME MUEVO" or "QR URBANI"
    val isSimulated: Boolean = true
)

@Entity(tableName = "recent_routes")
data class RecentRouteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originName: String,
    val destinationName: String,
    val timestamp: Long
)
