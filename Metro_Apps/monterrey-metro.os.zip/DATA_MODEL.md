# DATA_MODEL.md

## Persistent Data Model (Room Database)

MONTERREY METRO.OS utilizes an offline-first storage strategy. User preferences, cards, and transaction records are persisted locally.

### 1. Room Entities

- **`FavoritePlaceEntity`** (Table: `favorite_places`):
  - `id`: `String` (Primary Key)
  - `name`: `String` (e.g. "Casa", "Trabajo")
  - `type`: `String` (for icons)
  - `stationId`: `String?`
  - `address`: `String`

- **`MeMuevoCardEntity`** (Table: `me_muevo_card`):
  - `id`: `String` (Primary Key)
  - `cardNumber`: `String` (formatted)
  - `balanceMxn`: `Double`
  - `cardStatus`: `String`
  - `linkedAccountEmail`: `String`

- **`TransactionEntity`** (Table: `transactions`):
  - `id`: `Int` (Autogenerate Primary Key)
  - `timestamp`: `Long`
  - `description`: `String`
  - `amountMxn`: `Double`
  - `paymentMethod`: `String`
  - `isSimulated`: `Boolean`

- **`RecentRouteEntity`** (Table: `recent_routes`):
  - `id`: `Int` (Autogenerate Primary Key)
  - `originName`: `String`
  - `destinationName`: `String`
  - `timestamp`: `Long`

### 2. Repository Pattern
DAO queries return reactive `Flow<List<T>>` objects so that UI components redraw instantly whenever cards are topped-up or transactions occur.
