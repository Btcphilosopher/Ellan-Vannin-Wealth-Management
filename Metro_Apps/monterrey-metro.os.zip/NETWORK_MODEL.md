# NETWORK_MODEL.md

## Monterrey Metropolitan Transit Network Model

We have built the entire Monterrey Metro network model as decoupled, structural metadata.

### 1. Metro Lines Model

The system fully supports **Line 1 to Line 6** including modeled stations, future projected coordinates on the Monterrey valley grid, frequencies, and directions:
- **Línea 1**: Talleres to Exposición. Interchange: Cuauhtémoc (L1/L2), Félix U. Gómez (L1/L3), Y Griega (Transmetro Airport connection).
- **Línea 2**: Sendero to General Zaragoza. Interchange: Universidad (Transmetro), Cuauhtémoc (L1/L2), General Zaragoza (L3/L4/L5/L6).
- **Línea 3**: Hospital Metropolitano to General Zaragoza. Interchange: Félix U. Gómez (L1/L3), Ruiz Cortines (Ecovía), Zaragoza (L2/L3).
- **Línea 4 (Planeada)**: San Jerónimo to General Zaragoza.
- **Línea 5 (Planeada)**: General Zaragoza to Mederos (UANL).
- **Línea 6 (Planeada)**: General Zaragoza to Apodaca Centro.

### 2. Transmetro First-Class Integration
Transmetro routes are fully represented as objects with physical route directions, frequencies, operating fares, and connection nodes:
- **Transmetro Universidad - San Nicolás**
- **Transmetro Hospital Metropolitano - Lindavista**
- **Transmetro Exposición - Juárez**
- **Transmetro Sendero - Escobedo**
- **Express Transmetro Aeropuerto** (connects Y Griega terminal to MTY International Airport Terminals A & B).
