package com.example.data.model

import java.util.Locale
import kotlin.math.abs

object RailwayData {
    val STATIONS = listOf(
        Station("LST", "London Liverpool Street", "Ticket Office, Waiting Room, Café, Wi-Fi, Restrooms, First Class Lounge", isPopular = true),
        Station("SRA", "Stratford", "Ticket Office, Wi-Fi, Restrooms, Café", isPopular = true),
        Station("CHM", "Chelmsford", "Ticket Office, Waiting Room, Wi-Fi, Restrooms", isPopular = false),
        Station("COL", "Colchester", "Ticket Office, Waiting Room, Café, Wi-Fi, Restrooms", isPopular = true),
        Station("IPS", "Ipswich", "Ticket Office, Waiting Room, Café, Wi-Fi, Restrooms", isPopular = true),
        Station("NRW", "Norwich", "Ticket Office, Waiting Room, Café, Wi-Fi, Restrooms, First Class Lounge", isPopular = true),
        Station("CBG", "Cambridge", "Ticket Office, Waiting Room, Café, Wi-Fi, Restrooms", isPopular = true),
        Station("ELY", "Ely", "Ticket Office, Waiting Room, Wi-Fi, Restrooms", isPopular = false),
        Station("NWM", "Newmarket", "Ticket Machine, Wi-Fi", isPopular = false),
        Station("SSD", "Stansted Airport", "Ticket Office, Waiting Room, Café, Wi-Fi, Restrooms", isPopular = true),
        Station("KLN", "King's Lynn", "Ticket Office, Waiting Room, Wi-Fi", isPopular = false),
        Station("PBO", "Peterborough", "Ticket Office, Waiting Room, Café, Wi-Fi, Restrooms", isPopular = false),
        Station("GTY", "Great Yarmouth", "Ticket Office, Waiting Room, Wi-Fi", isPopular = false),
        Station("LWT", "Lowestoft", "Ticket Office, Waiting Room, Wi-Fi", isPopular = false),
        Station("CMR", "Cromer", "Ticket Machine, Waiting Shelter", isPopular = false),
        Station("SHM", "Sheringham", "Ticket Machine, Waiting Shelter", isPopular = false),
        Station("BSE", "Bury St Edmunds", "Ticket Office, Waiting Room, Wi-Fi", isPopular = false),
        Station("CLN", "Clacton-on-Sea", "Ticket Office, Waiting Room, Wi-Fi, Restrooms", isPopular = false),
        Station("WON", "Walton-on-the-Naze", "Ticket Machine, Waiting Shelter", isPopular = false),
        Station("HWH", "Harwich Town", "Ticket Machine, Waiting Shelter", isPopular = false),
        Station("BTR", "Braintree", "Ticket Office, Waiting Room", isPopular = false),
        Station("SUB", "Sudbury", "Ticket Machine, Waiting Shelter", isPopular = false),
        Station("MKT", "Marks Tey", "Ticket Office, Waiting Room, Wi-Fi", isPopular = false),
        Station("SNF", "Shenfield", "Ticket Office, Waiting Room, Wi-Fi, Restrooms", isPopular = false),
        Station("SOV", "Southend Victoria", "Ticket Office, Waiting Room, Wi-Fi, Restrooms", isPopular = false),
        Station("SMN", "Southminster", "Ticket Machine, Waiting Shelter", isPopular = false)
    )

    private val stationsByCode = STATIONS.associateBy { it.code }

    fun getStationByCode(code: String): Station? = stationsByCode[code.uppercase(Locale.ROOT)]

    // Major routes and segments to simulate realistic train networks
    // Each route consists of an ordered list of station codes.
    val ROUTES = listOf(
        // Great Eastern Main Line
        listOf("LST", "SRA", "CHM", "COL", "IPS", "NRW"),
        // Cambridge Line / West Anglia Main Line
        listOf("LST", "SRA", "SSD", "CBG", "ELY", "KLN"),
        // Norwich local branches
        listOf("NRW", "GTY"),
        listOf("NRW", "LWT"),
        listOf("NRW", "CMR", "SHM"),
        // Colchester branches
        listOf("COL", "CLN"),
        listOf("COL", "WON"),
        listOf("COL", "HWH"),
        // Marks Tey Branch
        listOf("MKT", "SUB"),
        // Shenfield branches
        listOf("SNF", "SOV"),
        listOf("SNF", "SMN"),
        // Cross country East Anglia
        listOf("CBG", "NWM", "BSE", "IPS"),
        listOf("CBG", "ELY", "PBO")
    )

    /**
     * Finds if there's a route path between fromCode and toCode, returning the ordered intermediate stop codes.
     * For simplistic demo data, if they are directly on the same list, we can extract the path.
     * If they are not on the same list, we can create a composite routing (e.g. connecting at Ipswich, Ely, or Colchester).
     */
    fun getRoutePath(fromCode: String, toCode: String): List<String> {
        val directRoute = ROUTES.find { route ->
            val fromIdx = route.indexOf(fromCode)
            val toIdx = route.indexOf(toCode)
            fromIdx != -1 && toIdx != -1
        }

        if (directRoute != null) {
            val fromIdx = directRoute.indexOf(fromCode)
            val toIdx = directRoute.indexOf(toCode)
            return if (fromIdx < toIdx) {
                directRoute.subList(fromIdx, toIdx + 1)
            } else {
                directRoute.subList(toIdx, fromIdx + 1).reversed()
            }
        }

        // Check if there is an intersection point to connect
        // Popular hubs are IPS, NRW, CBG, COL, ELY, LST, SRA
        val hubs = listOf("IPS", "NRW", "CBG", "COL", "ELY", "LST")
        for (hub in hubs) {
            val fromToHub = ROUTES.find { it.contains(fromCode) && it.contains(hub) }
            val hubToTo = ROUTES.find { it.contains(hub) && it.contains(toCode) }
            if (fromToHub != null && hubToTo != null) {
                val p1 = getRoutePath(fromCode, hub)
                val p2 = getRoutePath(hub, toCode)
                return p1.dropLast(1) + p2
            }
        }

        // Fallback direct mock connection
        return listOf(fromCode, toCode)
    }

    /**
     * Deterministic service generator based on fromCode, toCode, date and target hour.
     * Generates a realistic set of trains.
     */
    fun generateServices(fromCode: String, toCode: String, dateString: String, targetHour: Int = 12): List<TrainService> {
        val fromStation = getStationByCode(fromCode) ?: return emptyList()
        val toStation = getStationByCode(toCode) ?: return emptyList()

        // We want to generate multiple services during the day.
        // Let's generate a list of services spread around the target hour, e.g. targetHour-1, targetHour, targetHour+1, targetHour+2, etc.
        val baseHours = listOf(targetHour - 1, targetHour, targetHour + 1, targetHour + 2, targetHour + 3)
            .map { if (it < 0) it + 24 else if (it >= 24) it - 24 else it }
            .distinct()

        val path = getRoutePath(fromCode, toCode)
        val stopsCount = path.size

        // Deterministic seed factors based on codes
        val codeHash = abs((fromCode + toCode + dateString).hashCode())

        return baseHours.mapIndexed { idx, hour ->
            // Let's say departure minute is determined by code hash and index
            val isSig = fromCode == "LST" && toCode == "NRW" && hour == 17
            val depMin = if (isSig) 42 else ((codeHash + idx * 17) % 45 + 5) // e.g. between 05 and 50
            val departureStr = String.format(Locale.ROOT, "%02d:%02d", hour, depMin)

            // Duration is roughly proportional to the path size, let's say 25-35 minutes per segment
            val durationMin = if (isSig) 109 else if (stopsCount <= 2) {
                (codeHash % 15) + 20 // 20-35 mins
            } else {
                (stopsCount - 1) * 22 + (codeHash % 10)
            }

            val arrHour = (hour + (depMin + durationMin) / 60) % 24
            val arrMin = (depMin + durationMin) % 60
            val arrivalStr = String.format(Locale.ROOT, "%02d:%02d", arrHour, arrMin)

            val durationHoursText = if (durationMin >= 60) "${durationMin / 60}h ${durationMin % 60}m" else "${durationMin}m"

            // Live delay and status (deterministic)
            // 17:42 Norwich train gets exactly +8 mins delay as requested in Signature Demo!
            val isSignatureDemo = fromCode == "LST" && toCode == "NRW" && departureStr == "17:42"
            val isCambridgeDemo = fromCode == "CBG" && toCode == "SSD"

            val delayMins = when {
                isSignatureDemo -> 8
                (codeHash + idx) % 7 == 0 -> (codeHash % 12) + 2 // 2-13 mins delay
                else -> 0
            }

            val isCancelled = !isSignatureDemo && ((codeHash + idx) % 23 == 0) // rare cancellations
            val platformChanged = !isSignatureDemo && ((codeHash + idx) % 13 == 0)

            val basePlatform = if (isSignatureDemo) "10" else ((codeHash + idx) % 12 + 1).toString()
            val livePlatform = if (platformChanged) {
                ((codeHash + idx + 3) % 12 + 1).toString()
            } else {
                basePlatform
            }

            // Price: roughly 0.18 GBP per minute of duration, base min is 4.50
            val basePrice = if (isSignatureDemo) 28.40 else {
                val computedPrice = 4.50 + (durationMin * 0.16)
                Math.round(computedPrice * 10.0) / 10.0
            }

            // Generate intermediate stops
            val stopStations = path.mapNotNull { getStationByCode(it) }
            val stopsList = stopStations.mapIndexed { stopIdx, station ->
                val ratio = stopIdx.toDouble() / (stopStations.size - 1)
                val stopMinutes = (durationMin * ratio).toInt()
                val stopHour = (hour + (depMin + stopMinutes) / 60) % 24
                val stopMin = (depMin + stopMinutes) % 60
                val schedTime = String.format(Locale.ROOT, "%02d:%02d", stopHour, stopMin)

                // expected time
                val expTime = if (delayMins > 0) {
                    val expHour = (stopHour + (stopMin + delayMins) / 60) % 24
                    val expMin = (stopMin + delayMins) % 60
                    String.format(Locale.ROOT, "%02d:%02d", expHour, expMin)
                } else {
                    schedTime
                }

                val stopPlatform = if (stopIdx == 0) basePlatform else if (stopIdx == stopStations.size - 1) "3" else ((codeHash + stopIdx) % 4 + 1).toString()

                val status = when {
                    isCancelled -> "Cancelled"
                    delayMins > 0 -> "Delayed"
                    platformChanged -> "Platform Change"
                    else -> "On Time"
                }

                Stop(station, schedTime, expTime, stopPlatform, status)
            }

            TrainService(
                id = "$fromCode-$toCode-$hour$depMin",
                origin = fromStation,
                destination = toStation,
                departureTime = departureStr,
                arrivalTime = arrivalStr,
                duration = durationHoursText,
                stops = stopsList,
                basePlatform = basePlatform,
                livePlatform = livePlatform,
                basePrice = basePrice,
                isDirect = stopsCount <= 2 || (codeHash % 3 != 0),
                delayMinutes = delayMins,
                isCancelled = isCancelled,
                platformChanged = platformChanged
            )
        }.sortedBy { it.departureTime }
    }
}
