package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TicketType
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.RailwayViewModel

@Composable
fun CheckoutScreen(viewModel: RailwayViewModel) {
    val service by viewModel.selectedService.collectAsState()
    val railcard by viewModel.selectedRailcard.collectAsState()
    val passengerText by viewModel.passengerCountText.collectAsState()
    val selectedType by viewModel.selectedTicketType.collectAsState()

    val currentService = service ?: return

    val finalPrice = viewModel.calculatePrice(currentService.basePrice, selectedType, railcard, passengerText)
    var selectedPayment by remember { mutableStateOf("CARD") } // "CARD", "GOOGLE_PAY", "APPLE_PAY"

    BackHandler {
        viewModel.navigateBack()
    }

    Scaffold(
        topBar = {
            PremiumHeader(
                title = "SIMULATED CHECKOUT",
                subtitle = "Booking Review",
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(innerPadding)
        ) {
            SimulatedBanner()

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "REVIEW YOUR TICKET",
                    style = MaterialTheme.typography.labelLarge.copy(color = DeepNavy, letterSpacing = 1.sp)
                )

                // Ticket summary card
                PremiumCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "${currentService.origin.name} ➔ ${currentService.destination.name}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                                )
                                Text(
                                    text = "Date: ${viewModel.searchDate.value} • Departure: ${currentService.departureTime}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .background(DeepNavy, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = selectedType.displayName,
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        CustomTicketDottedDivider()
                        Spacer(modifier = Modifier.height(12.dp))

                        // Passengers and railcard lines
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Passengers", style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray))
                            Text(text = passengerText, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Railcard", style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray))
                            Text(text = railcard.displayName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Train operator", style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray))
                            Text(text = currentService.operator, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }

                Text(
                    text = "SELECT METHOD (DEMO PAYMENT)",
                    style = MaterialTheme.typography.labelLarge.copy(color = DeepNavy, letterSpacing = 1.sp)
                )

                // Demo payment card options
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaymentOptionRow(
                        label = "Debit or Credit Card",
                        icon = Icons.Default.CreditCard,
                        isSelected = selectedPayment == "CARD",
                        onSelect = { selectedPayment = "CARD" }
                    )
                    PaymentOptionRow(
                        label = "Google Pay (Demo)",
                        icon = Icons.Default.Payment,
                        isSelected = selectedPayment == "GOOGLE_PAY",
                        onSelect = { selectedPayment = "GOOGLE_PAY" }
                    )
                    PaymentOptionRow(
                        label = "Apple Pay (Demo)",
                        icon = Icons.Default.Payment,
                        isSelected = selectedPayment == "APPLE_PAY",
                        onSelect = { selectedPayment = "APPLE_PAY" }
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Price & payment validation
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = "TOTAL AMOUNT DUE",
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = String.format("£%.2f", finalPrice),
                            style = TimetablePriceStyle.copy(fontSize = 28.sp, color = DeepNavy)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.completeSimulatedPurchase(currentService, selectedType) },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("pay_and_confirm_button")
                    ) {
                        Text(
                            text = "PAY AND CONFIRM BOOKING",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentOptionRow(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    PremiumCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() },
        backgroundColor = if (isSelected) DeepNavy.copy(alpha = 0.03f) else Color.White,
        borderStroke = BorderStroke(1.5.dp, if (isSelected) DeepNavy else BorderGrey)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) DeepNavy else Color.Gray,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) DeepNavy else Graphite
                )
            )
            Spacer(modifier = Modifier.weight(1f))
            RadioButton(
                selected = isSelected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(selectedColor = DeepNavy)
            )
        }
    }
}
