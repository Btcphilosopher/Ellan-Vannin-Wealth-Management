package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.BookingEntity
import com.example.data.database.SavedStationEntity
import com.example.data.model.*
import com.example.data.repository.RailwayRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.random.Random

sealed class Screen {
    object Home : Screen()
    object SearchResults : Screen()
    data class FareComparison(val serviceId: String) : Screen()
    data class Checkout(val serviceId: String, val ticketTypeName: String) : Screen()
    data class TicketConfirmation(val bookingRef: String) : Screen()
    object MyTickets : Screen()
    object Timetables : Screen()
    data class StationBoard(val stationCode: String, val isArrivals: Boolean = false) : Screen()
    data class JourneyTracker(val bookingRef: String) : Screen()
}

class RailwayViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = RailwayRepository(application)

    // Backstack for custom state-based navigation
    private val _navStack = MutableStateFlow<List<Screen>>(listOf(Screen.Home))
    val currentScreen: StateFlow<Screen> = _navStack.map { it.lastOrNull() ?: Screen.Home }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Screen.Home)

    // Form selection states
    val fromStation = MutableStateFlow(RailwayData.getStationByCode("LST")!!)
    val toStation = MutableStateFlow(RailwayData.getStationByCode("NRW")!!)
    val searchDate = MutableStateFlow("Friday 25 Sep 2026")
    val searchTime = MutableStateFlow("17:30")
    val passengerCountText = MutableStateFlow("1 Adult")
    val selectedRailcard = MutableStateFlow(Railcard.NONE)

    // Search advanced parameters
    val directOnly = MutableStateFlow(false)
    val accessibleJourney = MutableStateFlow(false)
    val firstClass = MutableStateFlow(false)

    // Loaded results
    private val _searchResults = MutableStateFlow<List<TrainService>>(emptyList())
    val searchResults: StateFlow<List<TrainService>> = _searchResults.asStateFlow()

    // Selected items
    val selectedService = MutableStateFlow<TrainService?>(null)
    val selectedTicketType = MutableStateFlow<TicketType>(TicketType.ADVANCE)

    // DB backed flows
    val bookings: StateFlow<List<BookingEntity>> = repository.allBookingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedStations: StateFlow<List<SavedStationEntity>> = repository.savedStationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Static station query
    val stationSearchQuery = MutableStateFlow("")
    val stationSearchResults: StateFlow<List<Station>> = stationSearchQuery
        .map { repository.searchStations(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Pre-populate some history/favorites
        viewModelScope.launch {
            repository.saveRecentStation(RailwayData.getStationByCode("LST")!!, isFavourite = true)
            repository.saveRecentStation(RailwayData.getStationByCode("NRW")!!, isFavourite = true)
            repository.saveRecentStation(RailwayData.getStationByCode("CBG")!!, isFavourite = false)
            repository.saveRecentStation(RailwayData.getStationByCode("IPS")!!, isFavourite = false)
        }
    }

    // Navigation triggers
    fun navigateTo(screen: Screen) {
        val current = _navStack.value.toMutableList()
        current.add(screen)
        _navStack.value = current
    }

    fun navigateBack(): Boolean {
        val current = _navStack.value.toMutableList()
        if (current.size > 1) {
            current.removeAt(current.size - 1)
            _navStack.value = current
            return true
        }
        return false
    }

    fun navigateToHome() {
        _navStack.value = listOf(Screen.Home)
    }

    // Form inputs and triggers
    fun swapStations() {
        val temp = fromStation.value
        fromStation.value = toStation.value
        toStation.value = temp
    }

    fun performSearch() {
        val results = repository.searchTrainServices(
            fromStation.value.code,
            toStation.value.code,
            searchDate.value,
            searchTime.value
        )
        // Filter direct if requested
        _searchResults.value = if (directOnly.value) results.filter { it.isDirect } else results
        navigateTo(Screen.SearchResults)

        // Save search in recent
        viewModelScope.launch {
            repository.saveRecentStation(fromStation.value)
            repository.saveRecentStation(toStation.value)
        }
    }

    // Pricing calculation utility
    fun calculatePrice(basePrice: Double, type: TicketType, rc: Railcard, passengerText: String): Double {
        var multiplier = when (type) {
            TicketType.ADVANCE -> 1.0
            TicketType.OFF_PEAK -> 1.35
            TicketType.ANYTIME -> 2.15
        }
        // First Class surcharge
        if (firstClass.value) {
            multiplier *= 1.5
        }

        val rcFactor = rc.discountFactor

        val pricePerAdult = basePrice * multiplier * rcFactor
        val pricePerChild = basePrice * multiplier * 0.5 // Child always 50% off base rate

        return when (passengerText) {
            "1 Adult" -> pricePerAdult
            "2 Adults" -> pricePerAdult * 2
            "1 Adult + 1 Child" -> pricePerAdult + pricePerChild
            "2 Adults + 2 Children" -> (pricePerAdult * 2) + (pricePerChild * 2)
            else -> pricePerAdult
        }
    }

    // Toggle Station Bookmark
    fun toggleStationFavourite(code: String, currentlyFav: Boolean) {
        viewModelScope.launch {
            repository.toggleFavouriteStation(code, !currentlyFav)
        }
    }

    // Purchase ticket flow
    fun completeSimulatedPurchase(service: TrainService, type: TicketType) {
        viewModelScope.launch {
            val price = calculatePrice(service.basePrice, type, selectedRailcard.value, passengerCountText.value)
            val refCode = "EAC-" + (100000 + Random.nextInt(900000))

            val booking = BookingEntity(
                bookingReference = refCode,
                originCode = service.origin.code,
                originName = service.origin.name,
                destinationCode = service.destination.code,
                destinationName = service.destination.name,
                date = searchDate.value,
                departureTime = service.departureTime,
                arrivalTime = service.arrivalTime,
                duration = service.duration,
                platform = service.livePlatform,
                operator = service.operator,
                ticketType = type.name,
                passengerCountText = passengerCountText.value,
                railcardName = if (selectedRailcard.value != Railcard.NONE) selectedRailcard.value.displayName else null,
                price = price
            )

            repository.createBooking(booking)
            navigateTo(Screen.TicketConfirmation(refCode))
        }
    }

    // Refund Booking
    fun refundTicket(ref: String) {
        viewModelScope.launch {
            repository.refundBooking(ref)
        }
    }

    // Change Booking (simulate selecting standard next hour)
    fun changeTicket(ref: String) {
        viewModelScope.launch {
            val current = repository.getBooking(ref) ?: return@launch
            // Simulate adding 1 hour to departure and arrival
            val depParts = current.departureTime.split(":")
            val arrParts = current.arrivalTime.split(":")
            val newDepHour = (depParts[0].toInt() + 1) % 24
            val newArrHour = (arrParts[0].toInt() + 1) % 24
            val newDep = String.format(Locale.ROOT, "%02d:%s", newDepHour, depParts[1])
            val newArr = String.format(Locale.ROOT, "%02d:%s", newArrHour, arrParts[1])

            // Change ticket fee is standard £5
            repository.changeBooking(ref, newDep, newArr, current.price + 5.0)
        }
    }
}
