package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.BookingEntity
import com.example.data.model.RailwayData
import com.example.data.model.TicketType
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.RailwayViewModel

@Composable
fun JourneyTrackerScreen(viewModel: RailwayViewModel, bookingRef: String) {
    val bookings by viewModel.bookings.collectAsState()
    val booking = bookings.find { it.bookingReference == bookingRef }

    BackHandler {
        viewModel.navigateBack()
    }

    var selectedTab by remember { mutableStateOf("TICKET") } // "TICKET", "STOPS", "MANAGE"

    Scaffold(
        topBar = {
            PremiumHeader(
                title = "YOUR JOURNEY",
                subtitle = "EAC-$bookingRef",
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(innerPadding)
        ) {
            SimulatedBanner()

            if (booking == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = DeepNavy)
                }
            } else {
                // Transit Live status banner
                val stopsPath = RailwayData.getRoutePath(booking.originCode, booking.destinationCode)
                val isSignatureDemo = booking.originCode == "LST" && booking.destinationCode == "NRW" && booking.departureTime == "17:42"

                // Compute simulated active delay
                val delayMins = if (isSignatureDemo) 8 else 0

                // Tab selectors
                TabRow(
                    selectedTabIndex = when (selectedTab) {
                        "TICKET" -> 0
                        "STOPS" -> 1
                        "MANAGE" -> 2
                        else -> 0
                    },
                    containerColor = Color.White,
                    contentColor = DeepNavy
                ) {
                    Tab(
                        selected = selectedTab == "TICKET",
                        onClick = { selectedTab = "TICKET" },
                        text = { Text("DIGITAL TICKET", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)) },
                        icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("tab_ticket")
                    )
                    Tab(
                        selected = selectedTab == "STOPS",
                        onClick = { selectedTab = "STOPS" },
                        text = { Text("LIVE STOPS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)) },
                        icon = { Icon(Icons.Default.DirectionsTransit, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("tab_stops")
                    )
                    Tab(
                        selected = selectedTab == "MANAGE",
                        onClick = { selectedTab = "MANAGE" },
                        text = { Text("MANAGE PASS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)) },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("tab_manage")
                    )
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(16.dp)
                ) {
                    when (selectedTab) {
                        "TICKET" -> DigitalTicketTab(booking = booking)
                        "STOPS" -> LiveStopsTab(booking = booking, delayMins = delayMins, stopCodes = stopsPath)
                        "MANAGE" -> ManageTicketTab(booking = booking, onRefund = { viewModel.refundTicket(booking.bookingReference) }, onChange = { viewModel.changeTicket(booking.bookingReference) })
                    }
                }
            }
        }
    }
}

@Composable
fun DigitalTicketTab(booking: BookingEntity) {
    val scrollState = rememberScrollState()
    var isWalletAdded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Physical ticket representation
        Card(
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.5.dp, DeepNavy),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                // Top header band of ticket
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DeepNavy)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "EAST ANGLIA CONNECT",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            )
                        )
                        Text(
                            text = "e-TICKET",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = CoastalBlue,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                Column(modifier = Modifier.padding(16.dp)) {
                    // Origin and destination block
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "FROM", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                            Text(text = booking.originCode, style = TimetableTimeStyle.copy(fontSize = 28.sp, color = DeepNavy))
                            Text(text = booking.originName, style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray))
                        }

                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = null,
                            tint = BorderGrey,
                            modifier = Modifier.size(32.dp)
                        )

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "TO", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                            Text(text = booking.destinationCode, style = TimetableTimeStyle.copy(fontSize = 28.sp, color = DeepNavy))
                            Text(text = booking.destinationName, style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    CustomTicketDottedDivider()
                    Spacer(modifier = Modifier.height(14.dp))

                    // Date and validity lines
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "DATE", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                            Text(text = booking.date.uppercase(), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "DEPARTURE", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                            Text(text = booking.departureTime, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "CLASS", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                            Text(text = "STANDARD CLASS", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "TICKET TYPE", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                            Text(text = booking.ticketType, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = SignalGreen))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    CustomTicketDottedDivider()
                    Spacer(modifier = Modifier.height(14.dp))

                    // Simulated eTicket QR barcode box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            // Authentic simulated QR matrix
                            Canvas(modifier = Modifier.size(130.dp)) {
                                val gridCount = 9
                                val cellSize = size.width / gridCount
                                val seed = booking.bookingReference.hashCode()

                                for (row in 0 until gridCount) {
                                    for (col in 0 until gridCount) {
                                        // Specific corner squares for QR targets
                                        val isTarget = (row < 3 && col < 3) || (row < 3 && col >= gridCount - 3) || (row >= gridCount - 3 && col < 3)
                                        val isBitActive = if (isTarget) {
                                            // Render hollow QR targeting squares
                                            (row == 0 || row == 2 || col == 0 || col == 2) ||
                                            (row == 0 || row == 2 || col == gridCount - 1 || col == gridCount - 3) ||
                                            (row == gridCount - 1 || row == gridCount - 3 || col == 0 || col == 2)
                                        } else {
                                            // Deterministic filler bits based on booking code hash
                                            (row * col + seed + row + col) % 2 == 0
                                        }

                                        if (isBitActive) {
                                            drawRect(
                                                color = DeepNavy,
                                                topLeft = Offset(col * cellSize, row * cellSize),
                                                size = Size(cellSize + 0.5f, cellSize + 0.5f)
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "VALID FOR TRAVEL • EAC-${booking.bookingReference}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp,
                                    color = Color.Gray
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    CustomTicketDottedDivider()
                    Spacer(modifier = Modifier.height(14.dp))

                    // Final pricing details inside ticket
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "PASSENGERS", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                            Text(text = booking.passengerCountText, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "PRICE", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                            Text(text = String.format("£%.2f", booking.price), style = TimetablePriceStyle.copy(color = DeepNavy, fontSize = 20.sp))
                        }
                    }

                    // Show Refund/Change status indicator
                    if (booking.isRefunded) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SignalRed, RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "VOID / REFUNDED",
                                style = MaterialTheme.typography.labelLarge.copy(color = Color.White, fontWeight = FontWeight.Bold)
                            )
                        }
                    } else if (booking.isChanged) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SignalAmber, RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "REBOOKED / TICKET CHANGED",
                                style = MaterialTheme.typography.labelLarge.copy(color = Color.White, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Wallet simulated integrations
        if (!booking.isRefunded) {
            if (!isWalletAdded) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { isWalletAdded = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ADD TO GOOGLE", style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold))
                    }

                    Button(
                        onClick = { isWalletAdded = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.PhoneIphone, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ADD TO APPLE", style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold))
                    }
                }
            } else {
                Surface(
                    color = SignalGreen.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = SignalGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ADDED TO SMART WALLET",
                            style = MaterialTheme.typography.labelSmall.copy(color = SignalGreen, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LiveStopsTab(booking: BookingEntity, delayMins: Int, stopCodes: List<String>) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Active delay alert banner
        if (delayMins > 0) {
            Surface(
                color = SignalAmber.copy(alpha = 0.12f),
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, SignalAmber),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = SignalAmber)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "⚠ DELAY ANNOUNCEMENT: +$delayMins MINUTES",
                            style = MaterialTheme.typography.labelSmall.copy(color = SignalAmber, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Your service is running slightly behind schedule. Expected times updated.",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                        )
                    }
                }
            }
        } else {
            Surface(
                color = SignalGreen.copy(alpha = 0.12f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SignalGreen)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "SERVICE ON TIME • EXPECTED AS SCHEDULED",
                        style = MaterialTheme.typography.labelSmall.copy(color = SignalGreen, fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        // Timeline of calling points
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            items(stopCodes.size) { index ->
                val code = stopCodes[index]
                val station = RailwayData.getStationByCode(code)!!
                val isFirst = index == 0
                val isLast = index == stopCodes.size - 1

                // Simulate scheduled time offsets
                val offsetMins = index * 20
                val (schedH, schedM) = try {
                    val p = booking.departureTime.split(":")
                    Pair(p[0].toInt(), p[1].toInt())
                } catch (e: Exception) {
                    Pair(17, 42)
                }
                val totalSchedM = schedH * 60 + schedM + offsetMins
                val sTime = String.format("%02d:%02d", (totalSchedM / 60) % 24, totalSchedM % 60)

                val totalExpM = totalSchedM + delayMins
                val eTime = String.format("%02d:%02d", (totalExpM / 60) % 24, totalExpM % 60)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                ) {
                    // Timeline visual line
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(40.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .width(2.dp)
                                .background(if (isFirst) Color.Transparent else DeepNavy)
                        )
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .border(2.dp, DeepNavy, RoundedCornerShape(6.dp))
                                .background(if (isFirst || isLast) DeepNavy else Color.White)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .width(2.dp)
                                .background(if (isLast) Color.Transparent else DeepNavy)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Station detail text row
                    Row(
                        modifier = Modifier.fillMaxHeight(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = station.name,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = if (isFirst || isLast) FontWeight.Bold else FontWeight.Medium,
                                    color = DeepNavy
                                )
                            )
                            Text(
                                text = "Platform ${if (isFirst) booking.platform else "3"}",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = sTime,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                )
                            )
                            if (delayMins > 0) {
                                Text(
                                    text = "Exp $eTime",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = SignalAmber,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                    )
                                )
                            } else {
                                Text(
                                    text = "On Time",
                                    style = MaterialTheme.typography.bodySmall.copy(color = SignalGreen)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ManageTicketTab(
    booking: BookingEntity,
    onRefund: () -> Unit,
    onChange: () -> Unit
) {
    var showRefundConfirm by remember { mutableStateOf(false) }
    var showChangeConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "TICKET ACTIONS",
            style = MaterialTheme.typography.labelLarge.copy(color = DeepNavy, letterSpacing = 1.sp)
        )

        if (booking.isRefunded) {
            Surface(
                color = SignalRed.copy(alpha = 0.1f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "This ticket has been cancelled and refunded. No further operations are allowed.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = SignalRed, fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            // Action cards
            // Change ticket card
            PremiumCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showChangeConfirm = true }
                    .testTag("action_change_ticket")
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Update, contentDescription = null, tint = DeepNavy, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "CHANGE JOURNEY", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Text(text = "Rebook on the next hourly train. Subject to a £5 fee plus fare difference.", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                }
            }

            // Refund ticket card
            val isAdvance = booking.ticketType == "ADVANCE"
            PremiumCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showRefundConfirm = true }
                    .testTag("action_refund_ticket")
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Cancel, contentDescription = null, tint = SignalRed, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "REFUND TICKET", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Text(
                            text = if (isAdvance) "Advance fares are legally non-refundable." else "Cancel ticket for a complete refund.",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                        )
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                }
            }
        }

        // Dialog sheets for confirms
        if (showRefundConfirm) {
            val isAdvance = booking.ticketType == "ADVANCE"
            AlertDialog(
                onDismissRequest = { showRefundConfirm = false },
                title = { Text("REFUND TICKET") },
                text = {
                    Text(
                        if (isAdvance) {
                            "Advance Single tickets are non-refundable according to National Rail Conditions of Travel.\n\nYou cannot process a refund for this ticket."
                        } else {
                            "Are you sure you want to cancel and refund your ${booking.ticketType} ticket?\n\nA full refund of £${String.format("%.2f", booking.price)} will be returned to your payment method."
                        }
                    )
                },
                confirmButton = {
                    if (!isAdvance) {
                        Button(
                            onClick = {
                                onRefund()
                                showRefundConfirm = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SignalRed),
                            modifier = Modifier.testTag("confirm_refund_btn")
                        ) {
                            Text("CONFIRM REFUND")
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showRefundConfirm = false }) {
                        Text("CLOSE")
                    }
                }
            )
        }

        if (showChangeConfirm) {
            AlertDialog(
                onDismissRequest = { showChangeConfirm = false },
                title = { Text("CHANGE DEPARTURE") },
                text = {
                    Text("Rebook this ticket onto the next scheduled hourly service?\n\nA £5 change fee will be charged. Your new price will be adjusted.")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onChange()
                            showChangeConfirm = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                        modifier = Modifier.testTag("confirm_change_btn")
                    ) {
                        Text("CONFIRM & REBOOK")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showChangeConfirm = false }) {
                        Text("CANCEL")
                    }
                }
            )
        }
    }
}
