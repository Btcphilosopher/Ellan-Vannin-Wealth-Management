package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Railcard
import com.example.data.model.RailwayData
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.RailwayViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun HomeScreen(viewModel: RailwayViewModel) {
    val fromStat by viewModel.fromStation.collectAsState()
    val toStat by viewModel.toStation.collectAsState()
    val date by viewModel.searchDate.collectAsState()
    val time by viewModel.searchTime.collectAsState()
    val passengers by viewModel.passengerCountText.collectAsState()
    val railcard by viewModel.selectedRailcard.collectAsState()

    val directOnly by viewModel.directOnly.collectAsState()
    val accessible by viewModel.accessibleJourney.collectAsState()
    val isFirstClass by viewModel.firstClass.collectAsState()

    val savedStations by viewModel.savedStations.collectAsState()
    val searchResults by viewModel.stationSearchResults.collectAsState()
    val searchQuery by viewModel.stationSearchQuery.collectAsState()

    var activeSelector by remember { mutableStateOf<String?>(null) } // "FROM", "TO", "PASSENGERS", "RAILCARD"
    var showAdvanced by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            PremiumHeader(
                title = "East Anglia",
                subtitle = "Connect",
                onTicketsClick = { viewModel.navigateTo(Screen.MyTickets) }
            )
        },
        bottomBar = {
            BottomNavigationBar(
                activeTab = "home",
                onTabSelected = { tab ->
                    when (tab) {
                        "home" -> viewModel.navigateToHome()
                        "times" -> viewModel.navigateTo(Screen.Timetables)
                        "tickets" -> viewModel.navigateTo(Screen.MyTickets)
                        "departures" -> viewModel.navigateTo(Screen.StationBoard("LST"))
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(innerPadding)
        ) {
            SimulatedBanner()

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scrollState)
                    .padding(16.dp)
            ) {
                // Intro tagline
                Text(
                    text = "WHERE ARE YOU GOING?",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = DeepNavy,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    ),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Main search block
                PremiumCard(
                    backgroundColor = Color.White,
                    borderStroke = BorderStroke(1.5.dp, DeepNavy),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Origin Field
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { activeSelector = "FROM" }
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = "FROM",
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MyLocation, contentDescription = null, tint = DeepNavy, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = fromStat.name,
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = fromStat.code,
                                    style = MaterialTheme.typography.labelLarge.copy(color = Color.Gray)
                                )
                            }
                        }

                        // Divider with Swap icon
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Box(modifier = Modifier.weight(1f).height(1.dp).background(BorderGrey))
                            IconButton(
                                onClick = { viewModel.swapStations() },
                                modifier = Modifier
                                    .testTag("swap_stations_button")
                                    .size(36.dp)
                                    .border(1.dp, BorderGrey, RoundedCornerShape(18.dp))
                                    .background(Color.White)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwapVert,
                                    contentDescription = "Swap Stations",
                                    tint = DeepNavy,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Box(modifier = Modifier.weight(1f).height(1.dp).background(BorderGrey))
                        }

                        // Destination Field
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { activeSelector = "TO" }
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = "TO",
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Place, contentDescription = null, tint = CoastalBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = toStat.name,
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = toStat.code,
                                    style = MaterialTheme.typography.labelLarge.copy(color = Color.Gray)
                                )
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = BorderGrey)

                        // Date & Time Selectors
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "DATE",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = date,
                                    onValueChange = { viewModel.searchDate.value = it },
                                    leadingIcon = { Icon(Icons.Default.Today, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("date_input"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = DeepNavy,
                                        cursorColor = DeepNavy
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(0.7f)) {
                                Text(
                                    text = "TIME",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = time,
                                    onValueChange = { viewModel.searchTime.value = it },
                                    leadingIcon = { Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("time_input"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = DeepNavy,
                                        cursorColor = DeepNavy
                                    )
                                )
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = BorderGrey)

                        // Passengers & Railcards
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { activeSelector = "PASSENGERS" }
                                    .border(1.dp, BorderGrey, RoundedCornerShape(4.dp))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "PASSENGERS",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(16.dp), tint = DeepNavy)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = passengers, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(
                                modifier = Modifier
                                    .weight(1.2f)
                                    .clickable { activeSelector = "RAILCARD" }
                                    .border(1.dp, BorderGrey, RoundedCornerShape(4.dp))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "RAILCARD",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CardMembership, contentDescription = null, modifier = Modifier.size(16.dp), tint = DeepNavy)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (railcard == Railcard.NONE) "Add Railcard" else railcard.displayName,
                                        maxLines = 1,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Advanced options expander
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showAdvanced = !showAdvanced }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = if (showAdvanced) "HIDE ADVANCED OPTIONS" else "SHOW ADVANCED OPTIONS",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                            )
                            Icon(
                                imageVector = if (showAdvanced) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = DeepNavy,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        if (showAdvanced) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = directOnly,
                                        onCheckedChange = { viewModel.directOnly.value = it },
                                        colors = CheckboxDefaults.colors(checkedColor = DeepNavy)
                                    )
                                    Text(text = "Direct Trains Only", style = MaterialTheme.typography.bodyMedium)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = isFirstClass,
                                        onCheckedChange = { viewModel.firstClass.value = it },
                                        colors = CheckboxDefaults.colors(checkedColor = DeepNavy)
                                    )
                                    Text(text = "First Class Journey", style = MaterialTheme.typography.bodyMedium)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = accessible,
                                        onCheckedChange = { viewModel.accessibleJourney.value = it },
                                        colors = CheckboxDefaults.colors(checkedColor = DeepNavy)
                                    )
                                    Text(text = "Step-free / Accessible Journey", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Hero search button
                        Button(
                            onClick = { viewModel.performSearch() },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("search_trains_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Search, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "SEARCH TRAINS",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp,
                                        color = Color.White
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Short and fast regional links
                Text(
                    text = "REGIONAL HUB SHORTCUTS",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val hubPairs = listOf(
                        Triple("CBG", "SSD", "Cambridge ➔ Airport"),
                        Triple("COL", "CLN", "Colchester ➔ Clacton"),
                        Triple("NRW", "GTY", "Norwich ➔ Yarmouth")
                    )
                    hubPairs.forEach { (fromCode, toCode, label) ->
                        Button(
                            onClick = {
                                viewModel.fromStation.value = RailwayData.getStationByCode(fromCode)!!
                                viewModel.toStation.value = RailwayData.getStationByCode(toCode)!!
                                viewModel.performSearch()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TimetableBeige),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = label,
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelSmall.copy(color = DeepNavy, fontWeight = FontWeight.Bold),
                                maxLines = 2
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Feature grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FeatureCard(
                        title = "LIVE TIMES",
                        icon = Icons.Default.LiveTv,
                        description = "Station departures board",
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(Screen.StationBoard("LST")) }
                    )
                    FeatureCard(
                        title = "MY TICKETS",
                        icon = Icons.Default.ConfirmationNumber,
                        description = "View wallet & active passes",
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateTo(Screen.MyTickets) }
                    )
                }
            }
        }

        // Overlay dialog triggers
        when (activeSelector) {
            "FROM" -> {
                StationSelectorDialog(
                    title = "SELECT ORIGIN",
                    searchQuery = searchQuery,
                    onQueryChange = { viewModel.stationSearchQuery.value = it },
                    searchResults = searchResults,
                    savedStations = savedStations,
                    onStationSelected = {
                        viewModel.fromStation.value = it
                        activeSelector = null
                    },
                    onToggleFavourite = { code, isFav -> viewModel.toggleStationFavourite(code, isFav) },
                    onDismiss = { activeSelector = null }
                )
            }
            "TO" -> {
                StationSelectorDialog(
                    title = "SELECT DESTINATION",
                    searchQuery = searchQuery,
                    onQueryChange = { viewModel.stationSearchQuery.value = it },
                    searchResults = searchResults,
                    savedStations = savedStations,
                    onStationSelected = {
                        viewModel.toStation.value = it
                        activeSelector = null
                    },
                    onToggleFavourite = { code, isFav -> viewModel.toggleStationFavourite(code, isFav) },
                    onDismiss = { activeSelector = null }
                )
            }
            "PASSENGERS" -> {
                PassengerSelectorDialog(
                    currentSelection = passengers,
                    onSelected = { viewModel.passengerCountText.value = it },
                    onDismiss = { activeSelector = null }
                )
            }
            "RAILCARD" -> {
                RailcardSelectorDialog(
                    currentSelection = railcard,
                    onSelected = { viewModel.selectedRailcard.value = it },
                    onDismiss = { activeSelector = null }
                )
            }
        }
    }
}

@Composable
fun FeatureCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, BorderGrey),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = modifier
            .height(110.dp)
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = DeepNavy, modifier = Modifier.size(24.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = DeepNavy))
                Text(text = description, style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
            }
        }
    }
}

@Composable
fun BottomNavigationBar(activeTab: String, onTabSelected: (String) -> Unit) {
    NavigationBar(
        containerColor = Color.White,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = activeTab == "home",
            onClick = { onTabSelected("home") },
            label = { Text("Search") },
            icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = DeepNavy,
                indicatorColor = DeepNavy
            )
        )
        NavigationBarItem(
            selected = activeTab == "times",
            onClick = { onTabSelected("times") },
            label = { Text("Timetables") },
            icon = { Icon(Icons.Default.FormatListBulleted, contentDescription = "Timetables") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = DeepNavy,
                indicatorColor = DeepNavy
            )
        )
        NavigationBarItem(
            selected = activeTab == "tickets",
            onClick = { onTabSelected("tickets") },
            label = { Text("Tickets") },
            icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Tickets") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = DeepNavy,
                indicatorColor = DeepNavy
            )
        )
        NavigationBarItem(
            selected = activeTab == "departures",
            onClick = { onTabSelected("departures") },
            label = { Text("Departures") },
            icon = { Icon(Icons.Default.LiveTv, contentDescription = "Departures") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = DeepNavy,
                indicatorColor = DeepNavy
            )
        )
    }
}
