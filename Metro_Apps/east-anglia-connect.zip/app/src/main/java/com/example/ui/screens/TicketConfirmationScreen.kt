package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.RailwayViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun TicketConfirmationScreen(viewModel: RailwayViewModel, bookingRef: String) {
    val bookings by viewModel.bookings.collectAsState()
    val currentBooking = bookings.find { it.bookingReference == bookingRef }

    // Always intercept Back button to go directly to Home (rather than back in the purchase flow!)
    BackHandler {
        viewModel.navigateToHome()
    }

    Scaffold(
        topBar = {
            PremiumHeader(
                title = "BOOKING CONFIRMED",
                subtitle = "EAC-$bookingRef",
                onBackClick = { viewModel.navigateToHome() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(innerPadding)
        ) {
            SimulatedBanner()

            if (currentBooking == null) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = DeepNavy)
                }
            } else {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = SignalGreen,
                        modifier = Modifier.size(72.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "BOOKING CONFIRMED",
                        style = MaterialTheme.typography.displayMedium.copy(
                            color = DeepNavy,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )

                    Text(
                        text = "Thank you for your purchase. Your digital e-ticket is ready.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Physical ticket booking info card
                    PremiumCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .background(TimetableBeige)
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "BOOKING REFERENCE",
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, letterSpacing = 1.sp)
                            )
                            Text(
                                text = currentBooking.bookingReference,
                                style = TicketReferenceStyle.copy(fontSize = 24.sp, color = DeepNavy)
                            )

                            Spacer(modifier = Modifier.height(14.dp))
                            CustomTicketDottedDivider(color = BorderGrey)
                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "${currentBooking.originName} ➔ ${currentBooking.destinationName}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "${currentBooking.departureTime} • ${currentBooking.date}",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = Graphite)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${currentBooking.ticketType} • ${currentBooking.passengerCountText}",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray)
                                )
                                Text(
                                    text = String.format("£%.2f", currentBooking.price),
                                    style = TimetablePriceStyle.copy(color = DeepNavy)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    Button(
                        onClick = {
                            viewModel.navigateTo(Screen.JourneyTracker(currentBooking.bookingReference))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("view_ticket_success_button")
                    ) {
                        Text(
                            text = "VIEW TICKET",
                            style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    TextButton(
                        onClick = { viewModel.navigateToHome() },
                        modifier = Modifier.testTag("back_to_home_button")
                    ) {
                        Text(
                            text = "RETURN TO HOME",
                            style = MaterialTheme.typography.labelLarge.copy(color = DeepNavy, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}
