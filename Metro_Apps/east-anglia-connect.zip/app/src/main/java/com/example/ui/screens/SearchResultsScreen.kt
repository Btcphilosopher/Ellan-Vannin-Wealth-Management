package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Train
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TicketType
import com.example.data.model.TrainService
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.RailwayViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun SearchResultsScreen(viewModel: RailwayViewModel) {
    val fromStat by viewModel.fromStation.collectAsState()
    val toStat by viewModel.toStation.collectAsState()
    val date by viewModel.searchDate.collectAsState()
    val results by viewModel.searchResults.collectAsState()
    val railcard by viewModel.selectedRailcard.collectAsState()
    val passengerText by viewModel.passengerCountText.collectAsState()

    // Add back handler to support returning to home correctly
    BackHandler {
        viewModel.navigateBack()
    }

    Scaffold(
        topBar = {
            PremiumHeader(
                title = "${fromStat.code} ➔ ${toStat.code}",
                subtitle = date,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(innerPadding)
        ) {
            SimulatedBanner()

            // Route search summary header
            Surface(
                color = TimetableBeige,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${fromStat.name} to ${toStat.name}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                        )
                        Text(
                            text = "Fares calculated for $passengerText • ${railcard.displayName}",
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(DeepNavy, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${results.size} TRAINS",
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }

            if (results.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Train,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No services scheduled for this route & time.\nTry selecting LST (London) and NRW (Norwich).",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyLarge.copy(color = Color.Gray)
                        )
                    }
                }
            } else {
                // List of results
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(results) { service ->
                        val advancePrice = viewModel.calculatePrice(service.basePrice, TicketType.ADVANCE, railcard, passengerText)

                        TrainResultCard(
                            service = service,
                            price = advancePrice,
                            onSelect = {
                                viewModel.selectedService.value = service
                                viewModel.navigateTo(Screen.FareComparison(service.id))
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TrainResultCard(
    service: TrainService,
    price: Double,
    onSelect: () -> Unit
) {
    PremiumCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("train_result_${service.departureTime}"),
        backgroundColor = Color.White,
        borderStroke = BorderStroke(1.dp, if (service.delayMinutes > 0) SignalAmber else BorderGrey)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Status alert at the top of card if delayed/cancelled
            if (service.isCancelled) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SignalRed.copy(alpha = 0.1f))
                        .padding(8.dp)
                        .padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = SignalRed, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SERVICE CANCELLED — VIEW ALTERNATIVES",
                        style = MaterialTheme.typography.labelSmall.copy(color = SignalRed, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            } else if (service.delayMinutes > 0) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SignalAmber.copy(alpha = 0.1f))
                        .padding(8.dp)
                        .padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = SignalAmber, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "⚠ ${service.delayMinutes} MINUTES LATE — EXPECTED DEPARTURE ${service.stops.first().expectedDeparture}",
                        style = MaterialTheme.typography.labelSmall.copy(color = SignalAmber, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Main Timetable Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Departure details
                Column(modifier = Modifier.weight(1.2f)) {
                    Text(
                        text = service.departureTime,
                        style = TimetableTimeStyle.copy(fontSize = 24.sp, color = DeepNavy)
                    )
                    Text(
                        text = service.origin.name,
                        style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray),
                        maxLines = 1
                    )
                }

                // Middle arrow and duration
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = service.duration,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = BorderGrey,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (service.isDirect) "DIRECT" else "STOPS: ${service.stops.size - 2}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (service.isDirect) SignalGreen else Color.Gray,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                // Arrival details
                Column(
                    modifier = Modifier.weight(1.2f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = service.arrivalTime,
                        style = TimetableTimeStyle.copy(fontSize = 24.sp, color = DeepNavy)
                    )
                    Text(
                        text = service.destination.name,
                        style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray),
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            CustomTicketDottedDivider()
            Spacer(modifier = Modifier.height(10.dp))

            // Footer pricing & details
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = service.operator,
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    PlatformPill(platform = service.livePlatform)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(end = 12.dp)) {
                        Text(
                            text = "FROM",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = Color.Gray)
                        )
                        Text(
                            text = String.format("£%.2f", price),
                            style = TimetablePriceStyle.copy(fontSize = 20.sp, color = DeepNavy)
                        )
                        Text(
                            text = "Advance",
                            style = MaterialTheme.typography.labelSmall.copy(color = SignalGreen, fontWeight = FontWeight.Bold)
                        )
                    }

                    Button(
                        onClick = onSelect,
                        colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(text = "SELECT", style = MaterialTheme.typography.labelLarge.copy(color = Color.White))
                    }
                }
            }
        }
    }
}
