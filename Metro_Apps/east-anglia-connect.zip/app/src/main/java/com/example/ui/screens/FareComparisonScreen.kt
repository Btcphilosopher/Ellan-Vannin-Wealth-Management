package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TicketType
import com.example.data.model.TrainService
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.RailwayViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun FareComparisonScreen(viewModel: RailwayViewModel) {
    val service by viewModel.selectedService.collectAsState()
    val railcard by viewModel.selectedRailcard.collectAsState()
    val passengerText by viewModel.passengerCountText.collectAsState()
    val selectedType by viewModel.selectedTicketType.collectAsState()

    val currentService = service ?: return

    val advancePrice = viewModel.calculatePrice(currentService.basePrice, TicketType.ADVANCE, railcard, passengerText)
    val offPeakPrice = viewModel.calculatePrice(currentService.basePrice, TicketType.OFF_PEAK, railcard, passengerText)
    val anytimePrice = viewModel.calculatePrice(currentService.basePrice, TicketType.ANYTIME, railcard, passengerText)

    val prices = mapOf(
        TicketType.ADVANCE to advancePrice,
        TicketType.OFF_PEAK to offPeakPrice,
        TicketType.ANYTIME to anytimePrice
    )

    BackHandler {
        viewModel.navigateBack()
    }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            PremiumHeader(
                title = "Choose Ticket",
                subtitle = "${currentService.departureTime} ${currentService.origin.code} ➔ ${currentService.destination.code}",
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(innerPadding)
        ) {
            SimulatedBanner()

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scrollState)
                    .padding(16.dp)
            ) {
                // Route Summary Card
                PremiumCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = Color.White
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "YOUR JOURNEY",
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${currentService.origin.name} ➔ ${currentService.destination.name}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                            )
                            Text(
                                text = currentService.duration,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "DEPARTS ${currentService.departureTime} • ${currentService.operator}",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            PlatformPill(platform = currentService.livePlatform)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = "CHOOSE YOUR TICKET TYPE",
                    style = MaterialTheme.typography.labelLarge.copy(color = DeepNavy, letterSpacing = 1.sp)
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Fares Choice Options
                TicketType.values().forEach { type ->
                    val price = prices[type] ?: 0.0
                    val isCheapest = type == TicketType.ADVANCE
                    val isSelected = selectedType == type

                    val cardBorder = when {
                        isSelected -> BorderStroke(2.dp, DeepNavy)
                        isCheapest -> BorderStroke(1.dp, CoastalBlue)
                        else -> BorderStroke(1.dp, BorderGrey)
                    }

                    PremiumCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clickable { viewModel.selectedTicketType.value = type }
                            .testTag("ticket_option_${type.name}"),
                        backgroundColor = if (isSelected) DeepNavy.copy(alpha = 0.03f) else Color.White,
                        borderStroke = cardBorder
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = type.displayName.uppercase(),
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) DeepNavy else Graphite
                                            )
                                        )
                                        if (isCheapest) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(CoastalBlue, RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = "BEST VALUE",
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        color = Color.White,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        fontSize = 8.sp
                                                    )
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = type.description,
                                        style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = String.format("£%.2f", price),
                                        style = TimetablePriceStyle.copy(
                                            fontSize = 22.sp,
                                            color = if (isSelected) DeepNavy else Graphite
                                        )
                                    )
                                    if (isCheapest && anytimePrice > advancePrice) {
                                        val saving = anytimePrice - advancePrice
                                        Text(
                                            text = String.format("SAVE £%.2f", saving),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = SignalGreen,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            CustomTicketDottedDivider()
                            Spacer(modifier = Modifier.height(8.dp))

                            // Validity details
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = if (isSelected) DeepNavy else Color.Gray,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Validity: ${type.restriction}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Summary of selected item
                val finalPrice = prices[selectedType] ?: 0.0
                PremiumCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = DeepNavy,
                    borderStroke = null
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "SELECTED: ${selectedType.displayName.uppercase()}",
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.8f))
                            )
                            Text(
                                text = String.format("Total price: £%.2f", finalPrice),
                                style = TimetablePriceStyle.copy(color = Color.White, fontSize = 20.sp)
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.navigateTo(Screen.Checkout(currentService.id, selectedType.name))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.testTag("checkout_continue_button")
                        ) {
                            Text(
                                text = "CONTINUE",
                                style = MaterialTheme.typography.labelLarge.copy(color = DeepNavy)
                            )
                        }
                    }
                }
            }
        }
    }
}
