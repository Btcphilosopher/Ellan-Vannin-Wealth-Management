package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RailwayData
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.RailwayViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun TimetablesScreen(viewModel: RailwayViewModel) {
    BackHandler {
        viewModel.navigateToHome()
    }

    var selectedRouteIdx by remember { mutableStateOf(0) }

    // Defined corridors for timetable selection
    val corridors = listOf(
        Pair("Norwich ↔ London Liverpool Street", listOf("LST", "SRA", "CHM", "COL", "IPS", "NRW")),
        Pair("Cambridge ↔ London Liverpool Street", listOf("LST", "SRA", "SSD", "CBG")),
        Pair("Norwich ↔ Sheringham", listOf("NRW", "CMR", "SHM")),
        Pair("Colchester ↔ Clacton-on-Sea", listOf("COL", "CLN")),
        Pair("Marks Tey ↔ Sudbury", listOf("MKT", "SUB"))
    )

    val (corridorLabel, routeCodes) = corridors[selectedRouteIdx]

    // Generate times for 5 train columns deterministic
    val trainsCount = 6
    val timesDataset = remember(selectedRouteIdx) {
        (0 until trainsCount).map { trainIdx ->
            val baseHour = 10 + trainIdx * 2 // e.g. 10:00, 12:00, 14:00, 16:00, 18:00, 20:00
            routeCodes.mapIndexed { stationIdx, code ->
                val offsetMins = stationIdx * 18 + (trainIdx * 3) % 11
                val totalMins = baseHour * 60 + offsetMins
                val h = (totalMins / 60) % 24
                val m = totalMins % 60
                String.format("%02d:%02d", h, m)
            }
        }
    }

    Scaffold(
        topBar = {
            PremiumHeader(
                title = "WORKING TIMETABLES",
                subtitle = "EAST ANGLIA NETWORK",
                onBackClick = { viewModel.navigateToHome() }
            )
        },
        bottomBar = {
            BottomNavigationBar(
                activeTab = "times",
                onTabSelected = { tab ->
                    when (tab) {
                        "home" -> viewModel.navigateToHome()
                        "times" -> viewModel.navigateTo(Screen.Timetables)
                        "tickets" -> viewModel.navigateTo(Screen.MyTickets)
                        "departures" -> viewModel.navigateTo(Screen.StationBoard("LST"))
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(innerPadding)
        ) {
            SimulatedBanner()

            // Corridor selector tabs
            ScrollableTabRow(
                selectedTabIndex = selectedRouteIdx,
                containerColor = Color.White,
                contentColor = DeepNavy,
                edgePadding = 16.dp
            ) {
                corridors.forEachIndexed { index, pair ->
                    Tab(
                        selected = selectedRouteIdx == index,
                        onClick = { selectedRouteIdx = index },
                        text = { Text(pair.first, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)) }
                    )
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ROUTE SERVICE SCHEDULES",
                    style = MaterialTheme.typography.labelLarge.copy(color = DeepNavy, letterSpacing = 1.5.sp)
                )
                Text(
                    text = "Tap on any corridor above to switch lines. Standard working times are shown.",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Render the physical working timetable grid
                PremiumCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.White)
                    ) {
                        // Header row of the table
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DeepNavy)
                                .padding(vertical = 12.dp, horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "STATION",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                                modifier = Modifier.weight(1.3f)
                            )

                            // Dynamic column count
                            Row(
                                modifier = Modifier.weight(3f),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                for (i in 1..trainsCount) {
                                    Text(
                                        text = "TR-$i",
                                        color = CoastalBlue,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }

                        // Table rows list
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            items(routeCodes.size) { stationIdx ->
                                val code = routeCodes[stationIdx]
                                val station = RailwayData.getStationByCode(code)!!

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp)
                                        .background(if (stationIdx % 2 == 0) TimetableBeige.copy(alpha = 0.3f) else Color.Transparent),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Station code and name
                                    Column(modifier = Modifier.weight(1.3f)) {
                                        Text(
                                            text = station.code,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                                        )
                                        Text(
                                            text = station.name,
                                            style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray),
                                            maxLines = 1
                                        )
                                    }

                                    // Scheduled times for each column train
                                    Row(
                                        modifier = Modifier.weight(3f),
                                        horizontalArrangement = Arrangement.SpaceAround
                                    ) {
                                        timesDataset.forEach { columnTimes ->
                                            val tStr = columnTimes[stationIdx]
                                            Text(
                                                text = tStr,
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Graphite
                                                )
                                            )
                                        }
                                    }
                                }

                                Divider(color = BorderGrey.copy(alpha = 0.5f))
                            }
                        }

                        // Legibility notice at bottom
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TimetableBeige)
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = DeepNavy, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "WDT mode formats times in standard 24h monospace to prevent digital clutter.",
                                    style = MaterialTheme.typography.labelSmall.copy(color = DeepNavy, fontSize = 9.sp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
