package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.database.SavedStationEntity
import com.example.data.model.Railcard
import com.example.data.model.RailwayData
import com.example.data.model.Station
import com.example.ui.theme.*

@Composable
fun StationSelectorDialog(
    title: String,
    searchQuery: String,
    onQueryChange: (String) -> Unit,
    searchResults: List<Station>,
    savedStations: List<SavedStationEntity>,
    onStationSelected: (Station) -> Unit,
    onToggleFavourite: (String, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = WarmWhite,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title.uppercase(),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = DeepNavy,
                            letterSpacing = 1.sp
                        )
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onQueryChange,
                    placeholder = { Text("Search station name or code...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("station_search_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DeepNavy,
                        cursorColor = DeepNavy
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (searchQuery.trim().isEmpty()) {
                    // Show Favourites & Recents
                    Text(
                        text = "RECENT & FAVOURITES",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = DeepNavy.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(modifier = Modifier.weight(1f)) {
                        val favourites = savedStations.filter { it.isFavourite }
                        val recents = savedStations.filter { !it.isFavourite }

                        if (favourites.isEmpty() && recents.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No recent searches yet.\nTry searching Norwich or Ipswich!",
                                        textAlign = TextAlign.Center,
                                        style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray)
                                    )
                                }
                            }
                        } else {
                            if (favourites.isNotEmpty()) {
                                item {
                                    Text(
                                        text = "FAVOURITES",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = Color.Gray),
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    )
                                }
                                items(favourites) { entity ->
                                    StationRowItem(
                                        code = entity.code,
                                        name = entity.name,
                                        isFavourite = true,
                                        onSelected = {
                                            RailwayData.getStationByCode(entity.code)?.let { onStationSelected(it) }
                                        },
                                        onToggleFav = { onToggleFavourite(entity.code, true) }
                                    )
                                }
                            }

                            if (recents.isNotEmpty()) {
                                item {
                                    Text(
                                        text = "RECENT SEARCHES",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = Color.Gray),
                                        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                                    )
                                }
                                items(recents) { entity ->
                                    StationRowItem(
                                        code = entity.code,
                                        name = entity.name,
                                        isFavourite = false,
                                        onSelected = {
                                            RailwayData.getStationByCode(entity.code)?.let { onStationSelected(it) }
                                        },
                                        onToggleFav = { onToggleFavourite(entity.code, false) }
                                    )
                                }
                            }
                        }

                        // Also list some popular hubs for quick access
                        item {
                            Text(
                                text = "POPULAR EAST ANGLIA STATIONS",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(top = 20.dp, bottom = 4.dp)
                            )
                        }
                        val populars = RailwayData.STATIONS.filter { it.isPopular }
                        items(populars) { station ->
                            val isFav = savedStations.find { it.code == station.code }?.isFavourite ?: false
                            StationRowItem(
                                code = station.code,
                                name = station.name,
                                isFavourite = isFav,
                                onSelected = { onStationSelected(station) },
                                onToggleFav = { onToggleFavourite(station.code, isFav) }
                            )
                        }
                    }
                } else {
                    // Show Search Results
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        if (searchResults.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No station found matching \"$searchQuery\"",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray)
                                    )
                                }
                            }
                        } else {
                            items(searchResults) { station ->
                                val isFav = savedStations.find { it.code == station.code }?.isFavourite ?: false
                                StationRowItem(
                                    code = station.code,
                                    name = station.name,
                                    isFavourite = isFav,
                                    onSelected = { onStationSelected(station) },
                                    onToggleFav = { onToggleFavourite(station.code, isFav) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StationRowItem(
    code: String,
    name: String,
    isFavourite: Boolean,
    onSelected: () -> Unit,
    onToggleFav: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelected() }
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Box(
                modifier = Modifier
                    .background(DeepNavy.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = code,
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = DeepNavy,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = name,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)
            )
        }

        IconButton(onClick = onToggleFav, modifier = Modifier.size(44.dp)) {
            Icon(
                imageVector = if (isFavourite) Icons.Default.Star else Icons.Default.StarBorder,
                contentDescription = "Favourite",
                tint = if (isFavourite) SignalAmber else Color.Gray
            )
        }
    }
}

@Composable
fun PassengerSelectorDialog(
    currentSelection: String,
    onSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val options = listOf("1 Adult", "2 Adults", "1 Adult + 1 Child", "2 Adults + 2 Children")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = WarmWhite,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SELECT PASSENGERS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = DeepNavy
                    ),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                options.forEach { option ->
                    val isSelected = option == currentSelection
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelected(option)
                                onDismiss()
                            }
                            .background(
                                if (isSelected) DeepNavy.copy(alpha = 0.08f) else Color.Transparent,
                                RoundedCornerShape(8.dp)
                            )
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = option,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        )
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = DeepNavy
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
        }
    }
}

@Composable
fun RailcardSelectorDialog(
    currentSelection: Railcard,
    onSelected: (Railcard) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = WarmWhite,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.7f)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ADD RAILCARD",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = DeepNavy
                    ),
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "Railcards offer up to 1/3 (34%) off standard rail fares.",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(Railcard.values()) { card ->
                        val isSelected = card == currentSelection
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelected(card)
                                    onDismiss()
                                }
                                .background(
                                    if (isSelected) DeepNavy.copy(alpha = 0.08f) else Color.Transparent,
                                    RoundedCornerShape(8.dp)
                               )
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = card.displayName,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                )
                                if (card != Railcard.NONE) {
                                    Text(
                                        text = "34% discount applied to eligible fares",
                                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray)
                                    )
                                }
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = DeepNavy
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                }
            }
        }
    }
}
