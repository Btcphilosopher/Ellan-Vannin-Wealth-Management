package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun PremiumHeader(
    title: String = "EAST ANGLIA",
    subtitle: String = "CONNECT",
    onBackClick: (() -> Unit)? = null,
    onTicketsClick: (() -> Unit)? = null
) {
    Surface(
        color = DeepNavy,
        contentColor = Color.White,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onBackClick != null) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .testTag("back_button")
                            .padding(end = 8.dp)
                            .size(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                }

                Column {
                    Text(
                        text = title.uppercase(),
                        style = MaterialTheme.typography.labelLarge.copy(
                            letterSpacing = 3.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    )
                    Text(
                        text = subtitle.uppercase(),
                        style = MaterialTheme.typography.displayMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 22.sp,
                            lineHeight = 24.sp
                        )
                    )
                }
            }

            if (onTicketsClick != null) {
                IconButton(
                    onClick = onTicketsClick,
                    modifier = Modifier.testTag("header_tickets_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ConfirmationNumber,
                        contentDescription = "My Tickets",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun SimulatedBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFFEF9C3)) // soft yellow
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Simulated Mode",
                tint = SignalAmber,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "DEMO DATA ONLY • RAILWAY SIMULATION ACTIVE",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF854D0E)
                )
            )
        }
    }
}

@Composable
fun CustomTicketDottedDivider(color: Color = BorderGrey) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .drawBehind {
                val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                drawLine(
                    color = color,
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    strokeWidth = 2.dp.toPx(),
                    pathEffect = pathEffect
                )
            }
    )
}

@Composable
fun PremiumCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = Color.White,
    borderStroke: BorderStroke? = BorderStroke(1.dp, BorderGrey),
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        border = borderStroke,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        content = content
    )
}

@Composable
fun PlatformPill(platform: String) {
    Box(
        modifier = Modifier
            .background(Graphite, RoundedCornerShape(4.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "PLATFORM",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 7.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    lineHeight = 8.sp
                )
            )
            Text(
                text = platform,
                style = TimetableTimeStyle.copy(
                    fontSize = 15.sp,
                    color = Color.White,
                    lineHeight = 16.sp
                )
            )
        }
    }
}

@Composable
fun StatusIndicator(status: String, delayMinutes: Int = 0) {
    val (bgColor, textColor, text) = when {
        status == "Cancelled" -> Triple(SignalRed.copy(alpha = 0.1f), SignalRed, "CANCELLED")
        delayMinutes > 0 -> Triple(SignalAmber.copy(alpha = 0.1f), SignalAmber, "${delayMinutes} MIN LATE")
        else -> Triple(SignalGreen.copy(alpha = 0.1f), SignalGreen, "ON TIME")
    }

    Box(
        modifier = Modifier
            .background(bgColor, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = textColor,
                fontSize = 11.sp
            )
        )
    }
}
