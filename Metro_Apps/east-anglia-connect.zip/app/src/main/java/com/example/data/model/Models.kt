package com.example.data.model

data class Station(
    val code: String,
    val name: String,
    val facilities: String = "Ticket Office, Waiting Room, Café, Toilets, Wi-Fi",
    val isPopular: Boolean = false
)

enum class TicketType(val displayName: String, val description: String, val restriction: String) {
    ADVANCE("Advance", "Valid on this selected train only.", "Travel on booked train only. Limited availability."),
    OFF_PEAK("Off-Peak", "Flexible travel on off-peak services.", "Valid on eligible off-peak services as scheduled."),
    ANYTIME("Anytime", "Maximum travel flexibility on any service.", "No time restrictions. Travel at any hour.")
}

enum class Railcard(val displayName: String, val discountFactor: Double) {
    NONE("No Railcard", 1.0),
    CARD_16_25("16-25 Railcard", 0.66),
    CARD_26_30("26-30 Railcard", 0.66),
    FAMILY_FRIENDS("Family & Friends Railcard", 0.66),
    SENIOR("Senior Railcard", 0.66),
    TWO_TOGETHER("Two Together Railcard", 0.66),
    NETWORK("Network Railcard", 0.66)
}

data class Stop(
    val station: Station,
    val scheduledDeparture: String, // e.g. "17:42" or "19:31" (Arrival for destination)
    val expectedDeparture: String,  // e.g. "17:49" or "+7 MIN"
    val platform: String,
    val status: String // "On Time", "Delayed", "Cancelled", "Platform Change"
)

data class TrainService(
    val id: String,
    val origin: Station,
    val destination: Station,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val stops: List<Stop>,
    val operator: String = "Greater Anglia",
    val basePlatform: String,
    val livePlatform: String,
    val basePrice: Double,
    val isDirect: Boolean = true,
    val delayMinutes: Int = 0,
    val isCancelled: Boolean = false,
    val platformChanged: Boolean = false
)
