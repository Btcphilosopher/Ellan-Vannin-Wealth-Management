package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_stations")
data class SavedStationEntity(
    @PrimaryKey val code: String,
    val name: String,
    val isFavourite: Boolean,
    val lastSearchedTimestamp: Long
)

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey val bookingReference: String,
    val originCode: String,
    val originName: String,
    val destinationCode: String,
    val destinationName: String,
    val date: String,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val platform: String,
    val operator: String,
    val ticketType: String, // ADVANCE, OFF_PEAK, ANYTIME, etc.
    val passengerCountText: String, // "1 Adult", "2 Adults + 1 Child", etc.
    val railcardName: String?,
    val price: Double,
    val isRefunded: Boolean = false,
    val isChanged: Boolean = false,
    val bookingTimestamp: Long = System.currentTimeMillis()
)
