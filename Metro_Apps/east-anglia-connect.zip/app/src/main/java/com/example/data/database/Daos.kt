package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedStationDao {
    @Query("SELECT * FROM saved_stations ORDER BY lastSearchedTimestamp DESC")
    fun getAllSavedStations(): Flow<List<SavedStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedStation(station: SavedStationEntity)

    @Query("UPDATE saved_stations SET isFavourite = :isFavourite WHERE code = :code")
    suspend fun updateFavouriteStatus(code: String, isFavourite: Boolean)

    @Query("DELETE FROM saved_stations WHERE code = :code")
    suspend fun deleteSavedStation(code: String)
}

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY bookingTimestamp DESC")
    fun getAllBookings(): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE bookingReference = :ref")
    suspend fun getBookingByReference(ref: String): BookingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity)

    @Query("UPDATE bookings SET isRefunded = 1 WHERE bookingReference = :ref")
    suspend fun refundBooking(ref: String)

    @Query("UPDATE bookings SET isChanged = 1, departureTime = :newDep, arrivalTime = :newArr, price = :newPrice WHERE bookingReference = :ref")
    suspend fun changeBooking(ref: String, newDep: String, newArr: String, newPrice: Double)
}
