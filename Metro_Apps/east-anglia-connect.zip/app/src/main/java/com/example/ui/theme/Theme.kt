package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = DeepNavy,
    onPrimary = Color.White,
    primaryContainer = RailwayBlue,
    onPrimaryContainer = Color.White,
    secondary = CoastalBlue,
    onSecondary = Color.White,
    background = WarmWhite,
    onBackground = Graphite,
    surface = Color.White,
    onSurface = Graphite,
    error = SignalRed,
    onError = Color.White,
    surfaceVariant = TimetableBeige,
    onSurfaceVariant = Graphite,
    outline = BorderGrey
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF90CAF9),
    onPrimary = DeepNavy,
    primaryContainer = DeepNavy,
    onPrimaryContainer = Color.White,
    secondary = CoastalBlue,
    onSecondary = Color.White,
    background = Graphite,
    onBackground = WarmWhite,
    surface = Color(0xFF1F242D),
    onSurface = Color.White,
    error = SignalRed,
    onError = Color.White,
    surfaceVariant = RailwayBlue,
    onSurfaceVariant = Color.White,
    outline = Color(0xFF3A3F47)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Force Light theme by default for that clean, classic, beautiful physical timetable aesthetic!
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
