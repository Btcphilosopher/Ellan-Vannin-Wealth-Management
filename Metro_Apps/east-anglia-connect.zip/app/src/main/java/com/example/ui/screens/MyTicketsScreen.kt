package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.BookingEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.RailwayViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun MyTicketsScreen(viewModel: RailwayViewModel) {
    val bookings by viewModel.bookings.collectAsState()

    BackHandler {
        viewModel.navigateToHome()
    }

    var selectedSubTab by remember { mutableStateOf("UPCOMING") } // "UPCOMING", "PAST", "REFUNDED"

    Scaffold(
        topBar = {
            PremiumHeader(
                title = "MY WALLET",
                subtitle = "TICKETS",
                onBackClick = { viewModel.navigateToHome() }
            )
        },
        bottomBar = {
            BottomNavigationBar(
                activeTab = "tickets",
                onTabSelected = { tab ->
                    when (tab) {
                        "home" -> viewModel.navigateToHome()
                        "times" -> viewModel.navigateTo(Screen.Timetables)
                        "tickets" -> viewModel.navigateTo(Screen.MyTickets)
                        "departures" -> viewModel.navigateTo(Screen.StationBoard("LST"))
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(innerPadding)
        ) {
            SimulatedBanner()

            TabRow(
                selectedTabIndex = when (selectedSubTab) {
                    "UPCOMING" -> 0
                    "PAST" -> 1
                    "REFUNDED" -> 2
                    else -> 0
                },
                containerColor = Color.White,
                contentColor = DeepNavy
            ) {
                Tab(
                    selected = selectedSubTab == "UPCOMING",
                    onClick = { selectedSubTab = "UPCOMING" },
                    text = { Text("UPCOMING") }
                )
                Tab(
                    selected = selectedSubTab == "PAST",
                    onClick = { selectedSubTab = "PAST" },
                    text = { Text("PAST") }
                )
                Tab(
                    selected = selectedSubTab == "REFUNDED",
                    onClick = { selectedSubTab = "REFUNDED" },
                    text = { Text("REFUNDED") }
                )
            }

            val filteredBookings = when (selectedSubTab) {
                "UPCOMING" -> bookings.filter { !it.isRefunded } // simplified, active ones
                "PAST" -> emptyList() // synthetic empty past list
                "REFUNDED" -> bookings.filter { it.isRefunded }
                else -> emptyList()
            }

            if (filteredBookings.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.ConfirmationNumber,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No tickets in this section.\nFind schedules and book your next trip now!",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyLarge.copy(color = Color.Gray)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { viewModel.navigateToHome() },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("BOOK NOW")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredBookings) { booking ->
                        BookingItemCard(
                            booking = booking,
                            onView = { viewModel.navigateTo(Screen.JourneyTracker(booking.bookingReference)) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BookingItemCard(booking: BookingEntity, onView: () -> Unit) {
    PremiumCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onView() },
        backgroundColor = Color.White
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${booking.originCode} ➔ ${booking.destinationCode}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                    )
                    Text(
                        text = "${booking.departureTime} • Standard Class",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                    )
                }

                Box(
                    modifier = Modifier
                        .background(
                            if (booking.isRefunded) SignalRed.copy(alpha = 0.1f) else DeepNavy.copy(alpha = 0.1f),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (booking.isRefunded) "VOID" else booking.ticketType,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (booking.isRefunded) SignalRed else DeepNavy,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            CustomTicketDottedDivider()
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "DATE", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                    Text(text = booking.date, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                }

                Button(
                    onClick = onView,
                    colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text("VIEW PASS", style = MaterialTheme.typography.labelMedium.copy(color = Color.White))
                }
            }
        }
    }
}
