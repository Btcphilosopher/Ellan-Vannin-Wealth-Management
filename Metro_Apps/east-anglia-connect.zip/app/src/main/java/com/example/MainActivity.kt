package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.RailwayViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {
    private val viewModel: RailwayViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainContent(viewModel: RailwayViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        // Render current screen with animated Crossfade transition (elegant, responsive, under 300ms)
        Crossfade(
            targetState = currentScreen,
            animationSpec = androidx.compose.animation.core.tween(durationMillis = 250),
            label = "screen_transition"
        ) { screen ->
            when (screen) {
                is Screen.Home -> HomeScreen(viewModel = viewModel)
                is Screen.SearchResults -> SearchResultsScreen(viewModel = viewModel)
                is Screen.FareComparison -> FareComparisonScreen(viewModel = viewModel)
                is Screen.Checkout -> CheckoutScreen(viewModel = viewModel)
                is Screen.TicketConfirmation -> TicketConfirmationScreen(viewModel = viewModel, bookingRef = screen.bookingRef)
                is Screen.MyTickets -> MyTicketsScreen(viewModel = viewModel)
                is Screen.Timetables -> TimetablesScreen(viewModel = viewModel)
                is Screen.StationBoard -> StationBoardScreen(viewModel = viewModel, initialStationCode = screen.stationCode, initialIsArrivals = screen.isArrivals)
                is Screen.JourneyTracker -> JourneyTrackerScreen(viewModel = viewModel, bookingRef = screen.bookingRef)
            }
        }
    }
}
