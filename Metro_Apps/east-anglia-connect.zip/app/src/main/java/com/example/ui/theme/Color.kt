package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepNavy = Color(0xFF0A1931)
val RailwayBlue = Color(0xFF15305B)
val WarmWhite = Color(0xFFFBF9F6)
val TimetableBeige = Color(0xFFF5EFEB)
val Graphite = Color(0xFF222831)
val LightGrey = Color(0xFFEFEFEF)
val BorderGrey = Color(0xFFD0D3D4)

val CoastalBlue = Color(0xFF3A86C8)
val SignalRed = Color(0xFFC0392B)
val SignalAmber = Color(0xFFD35400)
val SignalGreen = Color(0xFF27AE60)

// Standard theme mappings for Light and Dark Schemes
val PrimaryNavy = DeepNavy
val SecondaryBlue = RailwayBlue
val BackgroundWarm = WarmWhite
val CardBackground = Color(0xFFFFFFFF)
