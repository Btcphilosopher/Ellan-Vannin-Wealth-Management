package com.example.data.repository

import android.content.Context
import com.example.data.database.AppDatabase
import com.example.data.database.BookingEntity
import com.example.data.database.SavedStationEntity
import com.example.data.model.RailwayData
import com.example.data.model.Station
import com.example.data.model.TrainService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Locale

class RailwayRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val savedStationDao = db.savedStationDao()
    private val bookingDao = db.bookingDao()

    // ----------------------------------------------------
    // STATION METADATA & SEARCH
    // ----------------------------------------------------

    fun getAllStations(): List<Station> = RailwayData.STATIONS

    fun getPopularStations(): List<Station> = RailwayData.STATIONS.filter { it.isPopular }

    fun searchStations(query: String): List<Station> {
        val q = query.trim().uppercase(Locale.ROOT)
        if (q.isEmpty()) return emptyList()
        return RailwayData.STATIONS.filter {
            it.code.contains(q) || it.name.uppercase(Locale.ROOT).contains(q)
        }
    }

    // ----------------------------------------------------
    // ROOM PERSISTED RECENT / FAVORITE STATIONS
    // ----------------------------------------------------

    val savedStationsFlow: Flow<List<SavedStationEntity>> = savedStationDao.getAllSavedStations()

    suspend fun saveRecentStation(station: Station, isFavourite: Boolean = false) {
        val existingSaved = savedStationDao.getAllSavedStations()
        // Simple search and insert/update timestamp
        val entity = SavedStationEntity(
            code = station.code,
            name = station.name,
            isFavourite = isFavourite,
            lastSearchedTimestamp = System.currentTimeMillis()
        )
        savedStationDao.insertSavedStation(entity)
    }

    suspend fun toggleFavouriteStation(code: String, isFavourite: Boolean) {
        savedStationDao.updateFavouriteStatus(code, isFavourite)
    }

    suspend fun deleteSavedStation(code: String) {
        savedStationDao.deleteSavedStation(code)
    }

    // ----------------------------------------------------
    // BOOKINGS (ROOM DATABASE)
    // ----------------------------------------------------

    val allBookingsFlow: Flow<List<BookingEntity>> = bookingDao.getAllBookings()

    suspend fun getBooking(reference: String): BookingEntity? {
        return bookingDao.getBookingByReference(reference)
    }

    suspend fun createBooking(booking: BookingEntity) {
        bookingDao.insertBooking(booking)
    }

    suspend fun refundBooking(reference: String) {
        bookingDao.refundBooking(reference)
    }

    suspend fun changeBooking(reference: String, newDepTime: String, newArrTime: String, newPrice: Double) {
        bookingDao.changeBooking(reference, newDepTime, newArrTime, newPrice)
    }

    // ----------------------------------------------------
    // SIMULATED SERVICES SEARCH
    // ----------------------------------------------------

    fun searchTrainServices(
        fromCode: String,
        toCode: String,
        dateString: String,
        timeString: String
    ): List<TrainService> {
        // Parse time string e.g. "17:30" to get target hour
        val hour = try {
            timeString.split(":")[0].toInt()
        } catch (e: Exception) {
            12
        }
        return RailwayData.generateServices(fromCode, toCode, dateString, hour)
    }
}
