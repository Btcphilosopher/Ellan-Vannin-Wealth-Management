package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RailwayData
import com.example.data.model.Station
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.RailwayViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun StationBoardScreen(viewModel: RailwayViewModel, initialStationCode: String, initialIsArrivals: Boolean = false) {
    BackHandler {
        viewModel.navigateToHome()
    }

    var selectedStationCode by remember { mutableStateOf(initialStationCode) }
    val currentStation = RailwayData.getStationByCode(selectedStationCode) ?: RailwayData.STATIONS.first()

    var isArrivals by remember { mutableStateOf(initialIsArrivals) }
    var showStationSelector by remember { mutableStateOf(false) }

    // Stations dropdown list search state
    var queryText by remember { mutableStateOf("") }
    val filteredStations = remember(queryText) {
        if (queryText.trim().isEmpty()) {
            RailwayData.STATIONS.filter { it.isPopular }
        } else {
            RailwayData.STATIONS.filter {
                it.code.contains(queryText, ignoreCase = true) || it.name.contains(queryText, ignoreCase = true)
            }
        }
    }

    // Deterministic services board list based on station and time "17:00"
    val boardServices = remember(selectedStationCode, isArrivals) {
        // Find segments connecting to/from selected station
        val connections = RailwayData.STATIONS.filter { it.code != selectedStationCode }
        connections.take(8).mapIndexed { idx, targetStation ->
            val hour = 17 + (idx / 3)
            val min = 10 + (idx * 13) % 48
            val depTime = String.format("%02d:%02d", hour, min)

            val basePlatform = ((idx + 2) % 4 + 1).toString()
            val delayMin = if (idx == 1) 2 else if (idx == 3) 0 else if (idx == 5) 7 else 0
            val isCancelled = idx == 4
            val isPlatformChange = idx == 2

            // Compute expected arrival / departure offset
            val totalMins = hour * 60 + min + delayMin
            val expTime = String.format("%02d:%02d", (totalMins / 60) % 24, totalMins % 60)

            Pair(
                targetStation,
                depTime to (expTime to (basePlatform to (delayMin to (isCancelled to isPlatformChange))))
            )
        }
    }

    Scaffold(
        topBar = {
            PremiumHeader(
                title = "LIVE BOARDS",
                subtitle = currentStation.name,
                onBackClick = { viewModel.navigateToHome() }
            )
        },
        bottomBar = {
            BottomNavigationBar(
                activeTab = "departures",
                onTabSelected = { tab ->
                    when (tab) {
                        "home" -> viewModel.navigateToHome()
                        "times" -> viewModel.navigateTo(Screen.Timetables)
                        "tickets" -> viewModel.navigateTo(Screen.MyTickets)
                        "departures" -> viewModel.navigateTo(Screen.StationBoard("LST"))
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(innerPadding)
        ) {
            SimulatedBanner()

            // Header Selector Button for Station
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepNavy)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showStationSelector = true }
                        .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = currentStation.code,
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = currentStation.name,
                            color = Color.White,
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Select Station",
                        tint = Color.White
                    )
                }
            }

            // Departures / Arrivals Sub Tabs
            TabRow(
                selectedTabIndex = if (isArrivals) 1 else 0,
                containerColor = Color.White,
                contentColor = DeepNavy
            ) {
                Tab(
                    selected = !isArrivals,
                    onClick = { isArrivals = false },
                    text = { Text("DEPARTURES", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)) }
                )
                Tab(
                    selected = isArrivals,
                    onClick = { isArrivals = true },
                    text = { Text("ARRIVALS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main board lists
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isArrivals) "ARRIVING SERVICES" else "DEPARTING SERVICES",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "17:00 – 19:30",
                        style = MaterialTheme.typography.labelSmall.copy(color = DeepNavy, fontWeight = FontWeight.Bold)
                    )
                }

                // Render calling list
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(boardServices) { item ->
                        val targetStation = item.first
                        val (timeStr, data) = item.second
                        val (expTime, nestedData) = data
                        val (basePlat, extraData) = nestedData
                        val (delayMin, states) = extraData
                        val (isCancelled, isPlatformChange) = states

                        LiveBoardItemCard(
                            time = timeStr,
                            expectedTime = expTime,
                            stationName = targetStation.name,
                            stationCode = targetStation.code,
                            platform = if (isPlatformChange) "12" else basePlat,
                            delayMin = delayMin,
                            isCancelled = isCancelled,
                            isPlatformChange = isPlatformChange,
                            isArrivals = isArrivals,
                            onSelect = {
                                // Simulate click: Set search form inputs and trigger search!
                                if (isArrivals) {
                                    viewModel.fromStation.value = targetStation
                                    viewModel.toStation.value = currentStation
                                } else {
                                    viewModel.fromStation.value = currentStation
                                    viewModel.toStation.value = targetStation
                                }
                                viewModel.performSearch()
                            }
                        )
                    }
                }
            }
        }

        // Dropdown Selection Dialog Overlay
        if (showStationSelector) {
            AlertDialog(
                onDismissRequest = { showStationSelector = false },
                title = { Text("SELECT STATION BOARD") },
                text = {
                    Column(modifier = Modifier.fillMaxWidth().height(320.dp)) {
                        OutlinedTextField(
                            value = queryText,
                            onValueChange = { queryText = it },
                            placeholder = { Text("Search name/code...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = DeepNavy, cursorColor = DeepNavy)
                        )

                        LazyColumn(modifier = Modifier.weight(1f)) {
                            items(filteredStations) { station ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedStationCode = station.code
                                            showStationSelector = false
                                        }
                                        .padding(vertical = 12.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = station.name,
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)
                                    )
                                    Text(
                                        text = station.code,
                                        style = MaterialTheme.typography.labelLarge.copy(color = Color.Gray)
                                    )
                                }
                                Divider(color = BorderGrey.copy(alpha = 0.5f))
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showStationSelector = false }) {
                        Text("CANCEL")
                    }
                }
            )
        }
    }
}

@Composable
fun LiveBoardItemCard(
    time: String,
    expectedTime: String,
    stationName: String,
    stationCode: String,
    platform: String,
    delayMin: Int,
    isCancelled: Boolean,
    isPlatformChange: Boolean,
    isArrivals: Boolean,
    onSelect: () -> Unit
) {
    val outlineBorder = when {
        isCancelled -> BorderStroke(1.dp, SignalRed)
        isPlatformChange -> BorderStroke(1.dp, SignalAmber)
        delayMin > 0 -> BorderStroke(1.dp, SignalAmber)
        else -> BorderStroke(1.dp, BorderGrey)
    }

    PremiumCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() },
        backgroundColor = Color.White,
        borderStroke = outlineBorder
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1.5f)) {
                    Text(
                        text = time,
                        style = TimetableTimeStyle.copy(fontSize = 18.sp, color = DeepNavy)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stationName,
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
                            maxLines = 1
                        )
                        Text(
                            text = if (isArrivals) "From $stationCode" else "Towards $stationCode",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.weight(1.2f)
                ) {
                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(end = 10.dp)) {
                        val statusText = when {
                            isCancelled -> "CANCELLED"
                            isPlatformChange -> "PLATFORM CHANGE"
                            delayMin > 0 -> "$delayMin MIN LATE"
                            else -> "ON TIME"
                        }
                        val statusColor = when {
                            isCancelled -> SignalRed
                            isPlatformChange -> SignalAmber
                            delayMin > 0 -> SignalAmber
                            else -> SignalGreen
                        }

                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                fontSize = 10.sp
                            )
                        )
                        if (delayMin > 0 && !isCancelled) {
                            Text(
                                text = "Exp $expectedTime",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.Gray,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                )
                            )
                        }
                    }

                    PlatformPill(platform = platform)

                    Icon(
                        imageVector = Icons.Default.KeyboardArrowRight,
                        contentDescription = "View",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
