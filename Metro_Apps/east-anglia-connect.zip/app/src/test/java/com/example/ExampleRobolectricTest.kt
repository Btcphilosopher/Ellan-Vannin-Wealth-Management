package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Railcard
import com.example.data.model.RailwayData
import com.example.data.model.TicketType
import com.example.ui.viewmodel.RailwayViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34]) // Robolectric runs beautifully on 34
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("East Anglia Connect", appName)
    }

    @Test
    fun `test railway stations lists`() {
        val stations = RailwayData.STATIONS
        assertTrue(stations.isNotEmpty())
        // Popular hubs exist
        val lst = RailwayData.getStationByCode("LST")
        assertNotNull(lst)
        assertEquals("London Liverpool Street", lst?.name)
    }

    @Test
    fun `test deterministic services simulation`() {
        val services = RailwayData.generateServices("LST", "NRW", "Friday 25 Sep 2026", 17)
        assertTrue(services.isNotEmpty())
        
        // Find signature 17:42 Norwich service
        val signatureService = services.find { it.departureTime == "17:42" }
        assertNotNull(signatureService)
        assertEquals(8, signatureService?.delayMinutes)
        assertEquals("10", signatureService?.basePlatform)
    }
}
