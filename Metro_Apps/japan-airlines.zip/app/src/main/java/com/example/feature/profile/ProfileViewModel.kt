package com.example.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.data.UserPreferencesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProfileUiState(
    val userName: String = "Taro Yamada",
    val jmbNumber: String = "7829-1092-348",
    val passportNumber: String = "TR891024",
    val currentLanguage: String = "EN",
    val currentCurrency: String = "JPY",
    val highContrastEnabled: Boolean = false,
    val savedSuccessMsg: String? = null
)

class ProfileViewModel(private val userPreferencesRepository: UserPreferencesRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            userPreferencesRepository.languageFlow.collect { lang ->
                _uiState.value = _uiState.value.copy(currentLanguage = lang)
            }
        }
        viewModelScope.launch {
            userPreferencesRepository.currencyFlow.collect { curr ->
                _uiState.value = _uiState.value.copy(currentCurrency = curr)
            }
        }
    }

    fun setLanguage(language: String) {
        viewModelScope.launch {
            userPreferencesRepository.setLanguage(language)
            _uiState.value = _uiState.value.copy(currentLanguage = language, savedSuccessMsg = "Language set to $language")
        }
    }

    fun setCurrency(currency: String) {
        viewModelScope.launch {
            userPreferencesRepository.setCurrency(currency)
            _uiState.value = _uiState.value.copy(currentCurrency = currency, savedSuccessMsg = "Currency set to $currency")
        }
    }

    fun toggleHighContrast(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(highContrastEnabled = enabled)
    }

    fun clearSavedMsg() {
        _uiState.value = _uiState.value.copy(savedSuccessMsg = null)
    }
}
