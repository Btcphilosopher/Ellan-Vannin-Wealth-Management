package com.example.feature.airport

import androidx.lifecycle.ViewModel
import com.example.core.repository.AirportGuide
import com.example.core.repository.AirportRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AirportUiState(
    val selectedAirportCode: String = "HND",
    val airportGuide: AirportGuide
)

class AirportViewModel(private val airportRepository: AirportRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(
        AirportUiState(airportGuide = airportRepository.getAirportGuide("HND"))
    )
    val uiState: StateFlow<AirportUiState> = _uiState.asStateFlow()

    fun selectAirport(code: String) {
        val guide = airportRepository.getAirportGuide(code)
        _uiState.value = _uiState.value.copy(
            selectedAirportCode = code,
            airportGuide = guide
        )
    }
}
