package com.example.core.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.data.AppContainer
import com.example.core.designsystem.component.JalBottomNavigationBar
import com.example.core.designsystem.component.JalTab
import com.example.core.designsystem.component.JalTopAppBar
import com.example.feature.airport.AirportScreen
import com.example.feature.airport.AirportViewModel
import com.example.feature.booking.BookingFlowScreen
import com.example.feature.booking.BookingViewModel
import com.example.feature.checkin.BoardingPassScreen
import com.example.feature.checkin.CheckInScreen
import com.example.feature.checkin.CheckInViewModel
import com.example.feature.home.HomeScreen
import com.example.feature.home.HomeViewModel
import com.example.feature.loyalty.LoyaltyScreen
import com.example.feature.loyalty.LoyaltyViewModel
import com.example.feature.notifications.NotificationScreen
import com.example.feature.notifications.NotificationViewModel
import com.example.feature.profile.ProfileScreen
import com.example.feature.profile.ProfileViewModel
import com.example.feature.search.SearchResultScreen
import com.example.feature.search.SearchViewModel
import com.example.feature.status.FlightStatusScreen
import com.example.feature.status.FlightStatusViewModel
import com.example.feature.trips.MyTripsScreen
import com.example.feature.trips.TripDetailScreen
import com.example.feature.trips.TripsViewModel

@Composable
fun JalAppMain(
    appContainer: AppContainer,
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Home.route

    // ViewModels
    val homeViewModel: HomeViewModel = viewModel {
        HomeViewModel(appContainer.bookingRepository, appContainer.loyaltyRepository, appContainer.userPreferencesRepository)
    }
    val searchViewModel: SearchViewModel = viewModel {
        SearchViewModel(appContainer.flightRepository)
    }
    val bookingViewModel: BookingViewModel = viewModel {
        BookingViewModel(appContainer.flightRepository, appContainer.bookingRepository)
    }
    val tripsViewModel: TripsViewModel = viewModel {
        TripsViewModel(appContainer.bookingRepository)
    }
    val checkInViewModel: CheckInViewModel = viewModel {
        CheckInViewModel(appContainer.bookingRepository)
    }
    val airportViewModel: AirportViewModel = viewModel {
        AirportViewModel(appContainer.airportRepository)
    }
    val statusViewModel: FlightStatusViewModel = viewModel {
        FlightStatusViewModel(appContainer.flightRepository)
    }
    val loyaltyViewModel: LoyaltyViewModel = viewModel {
        LoyaltyViewModel(appContainer.loyaltyRepository)
    }
    val notificationViewModel: NotificationViewModel = viewModel {
        NotificationViewModel(appContainer.notificationRepository)
    }
    val profileViewModel: ProfileViewModel = viewModel {
        ProfileViewModel(appContainer.userPreferencesRepository)
    }

    val homeUiState by homeViewModel.uiState.collectAsState()
    val language by homeViewModel.languageFlow.collectAsState()

    val showBottomBar = currentRoute in listOf(
        Screen.Home.route,
        Screen.Search.route,
        Screen.Trips.route,
        Screen.Airport.route,
        Screen.Loyalty.route
    )

    Scaffold(
        topBar = {
            JalTopAppBar(
                currentLanguage = language,
                onNotificationClick = { navController.navigate(Screen.Notifications.route) },
                onProfileClick = { navController.navigate(Screen.Profile.route) },
                onLanguageToggle = { homeViewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            if (showBottomBar) {
                JalBottomNavigationBar(
                    currentRoute = currentRoute,
                    currentLanguage = language,
                    onTabSelected = { tab ->
                        navController.navigate(tab.route) {
                            popUpTo(Screen.Home.route) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = homeViewModel,
                        onSearchClick = { origin, dest, date, cabin, passengers ->
                            searchViewModel.performSearch(origin, dest, date, cabin, passengers)
                            navController.navigate(Screen.SearchResults.createRoute(origin, dest, date, cabin, passengers))
                        },
                        onUpcomingTripClick = { pnr -> navController.navigate(Screen.TripDetail.createRoute(pnr)) },
                        onCheckInClick = { pnr -> navController.navigate(Screen.CheckIn.createRoute(pnr)) },
                        onBoardingPassClick = { pnr -> navController.navigate(Screen.BoardingPass.createRoute(pnr)) },
                        onFlightStatusClick = { navController.navigate(Screen.Status.route) }
                    )
                }

                composable(Screen.Search.route) {
                    HomeScreen(
                        viewModel = homeViewModel,
                        onSearchClick = { origin, dest, date, cabin, passengers ->
                            searchViewModel.performSearch(origin, dest, date, cabin, passengers)
                            navController.navigate(Screen.SearchResults.createRoute(origin, dest, date, cabin, passengers))
                        },
                        onUpcomingTripClick = { pnr -> navController.navigate(Screen.TripDetail.createRoute(pnr)) },
                        onCheckInClick = { pnr -> navController.navigate(Screen.CheckIn.createRoute(pnr)) },
                        onBoardingPassClick = { pnr -> navController.navigate(Screen.BoardingPass.createRoute(pnr)) },
                        onFlightStatusClick = { navController.navigate(Screen.Status.route) }
                    )
                }

                composable(Screen.SearchResults.route) { backStackEntry ->
                    SearchResultScreen(
                        viewModel = searchViewModel,
                        onFlightSelected = { flightNum, cabin ->
                            bookingViewModel.initBookingFlow(flightNum, cabin)
                            navController.navigate(Screen.BookingFlow.createRoute(flightNum, cabin))
                        },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(Screen.BookingFlow.route) {
                    BookingFlowScreen(
                        viewModel = bookingViewModel,
                        onBookingFinished = { pnr ->
                            navController.navigate(Screen.BoardingPass.createRoute(pnr)) {
                                popUpTo(Screen.Home.route)
                            }
                        },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(Screen.Trips.route) {
                    MyTripsScreen(
                        viewModel = tripsViewModel,
                        onTripClick = { pnr -> navController.navigate(Screen.TripDetail.createRoute(pnr)) },
                        onCheckInClick = { pnr -> navController.navigate(Screen.CheckIn.createRoute(pnr)) },
                        onBoardingPassClick = { pnr -> navController.navigate(Screen.BoardingPass.createRoute(pnr)) }
                    )
                }

                composable(Screen.TripDetail.route) { backStackEntry ->
                    val pnr = backStackEntry.arguments?.getString("pnr") ?: ""
                    TripDetailScreen(
                        pnr = pnr,
                        viewModel = tripsViewModel,
                        onBackClick = { navController.popBackStack() },
                        onBoardingPassClick = { p -> navController.navigate(Screen.BoardingPass.createRoute(p)) }
                    )
                }

                composable(Screen.CheckIn.route) { backStackEntry ->
                    val pnr = backStackEntry.arguments?.getString("pnr") ?: ""
                    CheckInScreen(
                        pnr = pnr,
                        viewModel = checkInViewModel,
                        onBackClick = { navController.popBackStack() },
                        onViewPass = { p -> navController.navigate(Screen.BoardingPass.createRoute(p)) }
                    )
                }

                composable(Screen.BoardingPass.route) { backStackEntry ->
                    val pnr = backStackEntry.arguments?.getString("pnr") ?: ""
                    BoardingPassScreen(
                        pnr = pnr,
                        viewModel = checkInViewModel,
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(Screen.Airport.route) {
                    AirportScreen(viewModel = airportViewModel)
                }

                composable(Screen.Status.route) {
                    FlightStatusScreen(
                        viewModel = statusViewModel,
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(Screen.Loyalty.route) {
                    LoyaltyScreen(viewModel = loyaltyViewModel)
                }

                composable(Screen.Notifications.route) {
                    NotificationScreen(
                        viewModel = notificationViewModel,
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(Screen.Profile.route) {
                    ProfileScreen(
                        viewModel = profileViewModel,
                        onBackClick = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
