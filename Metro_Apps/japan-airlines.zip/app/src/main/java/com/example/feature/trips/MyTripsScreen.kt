package com.example.feature.trips

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.ConfirmationNumber
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.theme.*
import com.example.core.model.Booking

@Composable
fun MyTripsScreen(
    viewModel: TripsViewModel,
    onTripClick: (pnr: String) -> Unit,
    onCheckInClick: (pnr: String) -> Unit,
    onBoardingPassClick: (pnr: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory)
    ) {
        // Top Header
        Surface(
            color = JalCrimson,
            contentColor = PureWhite,
            shadowElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp)
            ) {
                Text(
                    text = "MY TRIPS & ITINERARIES",
                    style = MaterialTheme.typography.titleLarge,
                    color = PureWhite,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Manage your Japan Airlines bookings",
                    style = MaterialTheme.typography.bodyMedium,
                    color = PureWhite.copy(alpha = 0.85f)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Search Bar for PNR or Last Name
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Retrieve booking by PNR or Last Name") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = JalMediumGrey) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = PureWhite,
                        unfocusedContainerColor = PureWhite,
                        focusedBorderColor = PureWhite,
                        unfocusedBorderColor = PureWhite
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("retrieve_booking_input")
                )
            }
        }

        // Tab Row: Active Trips vs Past/Cancelled
        TabRow(
            selectedTabIndex = uiState.selectedTab,
            containerColor = PureWhite,
            contentColor = JalCrimson
        ) {
            Tab(
                selected = uiState.selectedTab == 0,
                onClick = { viewModel.setSelectedTab(0) },
                text = { Text("Active Trips", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("active_trips_tab")
            )
            Tab(
                selected = uiState.selectedTab == 1,
                onClick = { viewModel.setSelectedTab(1) },
                text = { Text("Past & Cancelled", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("past_trips_tab")
            )
        }

        if (uiState.filteredBookings.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.ConfirmationNumber,
                        contentDescription = null,
                        tint = JalMediumGrey,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No bookings found", style = MaterialTheme.typography.titleMedium, color = JalMediumGrey)
                    Text("Search above or create a new booking", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(uiState.filteredBookings) { booking ->
                    TripCardItem(
                        booking = booking,
                        onClick = { onTripClick(booking.pnr) },
                        onCheckIn = { onCheckInClick(booking.pnr) },
                        onBoardingPass = { onBoardingPassClick(booking.pnr) },
                        onCancelPrompt = { viewModel.promptCancelBooking(booking.pnr) }
                    )
                }
            }
        }
    }

    if (uiState.showCancelDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissCancelDialog() },
            title = { Text("Cancel Booking?") },
            text = { Text("Are you sure you want to cancel booking ${uiState.actionPnr}? Fare rules and cancellation policies will apply.") },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmCancelBooking() },
                    colors = ButtonDefaults.buttonColors(containerColor = JalErrorRed)
                ) {
                    Text("Confirm Cancel")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { viewModel.dismissCancelDialog() }) {
                    Text("Keep Booking")
                }
            }
        )
    }
}

@Composable
fun TripCardItem(
    booking: Booking,
    onClick: () -> Unit,
    onCheckIn: () -> Unit,
    onBoardingPass: () -> Unit,
    onCancelPrompt: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("trip_card_${booking.pnr}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(JalCrimsonLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("JL", color = JalCrimson, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(booking.outboundFlight.flightNumber, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                        Text("PNR: ${booking.pnr}", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                    }
                }

                Surface(
                    color = when (booking.status) {
                        "CONFIRMED" -> JalSuccessGreenBg
                        "CHECKED_IN" -> JalCrimsonLight
                        else -> JalErrorRedBg
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = booking.status,
                        color = when (booking.status) {
                            "CONFIRMED" -> JalSuccessGreen
                            "CHECKED_IN" -> JalCrimson
                            else -> JalErrorRed
                        },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(booking.outboundFlight.origin.code, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Text(booking.outboundFlight.origin.city, style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                    Text(booking.outboundFlight.departureTime, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.TrendingFlat, contentDescription = null, tint = JalCrimson, modifier = Modifier.size(28.dp))
                    Text("${booking.outboundFlight.durationMinutes / 60}h ${booking.outboundFlight.durationMinutes % 60}m", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(booking.outboundFlight.destination.code, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Text(booking.outboundFlight.destination.city, style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                    Text(booking.outboundFlight.arrivalTime, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = JalBorderGrey)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Seat: ${booking.ancillary.seatNumber} • ${booking.cabinClass.displayName}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = JmbGold
                )

                if (booking.status != "CANCELLED") {
                    Row {
                        OutlinedButton(
                            onClick = onCheckIn,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Check-In", fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = onBoardingPass,
                            colors = ButtonDefaults.buttonColors(containerColor = JalCrimson),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Pass", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
