package com.example.core.repository

import com.example.core.model.Airport
import com.example.core.model.SampleAirports

data class SakuraLoungeInfo(
    val name: String,
    val terminal: String,
    val location: String,
    val openingHours: String,
    val amenities: List<String>,
    val highlights: String
)

data class JourneyTimelineStep(
    val stepNumber: Int,
    val title: String,
    val estimatedTime: String,
    val description: String,
    val location: String
)

data class AirportGuide(
    val airport: Airport,
    val terminalName: String,
    val checkInCounters: String,
    val sakuraLounge: SakuraLoungeInfo,
    val transitGuide: String,
    val timeline: List<JourneyTimelineStep>
)

class AirportRepository {

    fun getAirportGuide(airportCode: String): AirportGuide {
        return when (airportCode.uppercase()) {
            "NRT" -> createNaritaGuide()
            "KIX" -> createKansaiGuide()
            "JFK" -> createJfkGuide()
            "LHR" -> createHeathrowGuide()
            else -> createHanedaGuide() // Default to Haneda HND
        }
    }

    private fun createHanedaGuide() = AirportGuide(
        airport = SampleAirports.HND,
        terminalName = "Terminal 3 (International)",
        checkInCounters = "A & B Counters (Departure Level 3F)",
        sakuraLounge = SakuraLoungeInfo(
            name = "JAL Sakura Lounge & First Class Lounge",
            terminal = "Terminal 3, 4th & 5th Floor (Near Gate 112)",
            location = "Post-security near Gate 112",
            openingHours = "06:00 - 01:30 Daily",
            amenities = listOf("Fresh Japanese Curry Buffet", "Sake Bar & Wine Selection", "Private Shower Suites", "Massage Chairs", "Quiet Work Booths"),
            highlights = "Featuring the signature JAL Beef Curry and panoramic views of Haneda runways and Mt. Fuji."
        ),
        transitGuide = "Monorail directly to Hamamatsucho (13 min) or Keikyu Line to Shinagawa (11 min). Terminal transfer bus available every 5 mins.",
        timeline = listOf(
            JourneyTimelineStep(1, "Arrive at Haneda Terminal 3", "2.5h before flight", "Proceed to Departure Hall 3F", "3F Departure Floor"),
            JourneyTimelineStep(2, "JAL Priority Check-In & Bag Drop", "2h before flight", "Counters A/B for First/Business & JMB Status", "Counters A & B"),
            JourneyTimelineStep(3, "Fast Track Security & Passport Control", "1.5h before flight", "Clear security through JAL Fast Track lane", "3F Security Area"),
            JourneyTimelineStep(4, "Relax at JAL Sakura Lounge", "1h before flight", "Enjoy chef-prepared Japanese meals and beverages", "4F Gate 112 Area"),
            JourneyTimelineStep(5, "Proceed to Departure Gate", "30 min before flight", "Boarding begins by Groups 1-5", "Gate 112"),
            JourneyTimelineStep(6, "In-Flight Service & Destination Arrival", "Post Departure", "Collect baggage at carousel upon landing", "Arrival Hall")
        )
    )

    private fun createNaritaGuide() = AirportGuide(
        airport = SampleAirports.NRT,
        terminalName = "Terminal 2",
        checkInCounters = "JAL Island B & C",
        sakuraLounge = SakuraLoungeInfo(
            name = "JAL Sakura Lounge Main Hall",
            terminal = "Terminal 2, 3rd Floor",
            location = "Central Building post-security",
            openingHours = "07:30 - 22:00 Daily",
            amenities = listOf("Chef Dining Counter", "Shower Rooms", "Relaxation Room", "Bar Service"),
            highlights = "Spacious multi-level dining zone overlooking international aircraft stands."
        ),
        transitGuide = "JR Narita Express (N'EX) to Tokyo Station (53 min) or Keisei Skyliner to Ueno (36 min).",
        timeline = listOf(
            JourneyTimelineStep(1, "Arrive at Narita Terminal 2", "3h before flight", "Enter 3F Departure Lobby", "3F Departure"),
            JourneyTimelineStep(2, "Bag Drop & Document Verification", "2.5h before flight", "Self bag drop machines available", "Island B"),
            JourneyTimelineStep(3, "Security & Automated Gates", "2h before flight", "Face Express biometrics available", "3F Gate Control"),
            JourneyTimelineStep(4, "Sakura Lounge Visit", "1h before flight", "Savor Japanese sake and refreshments", "3F Lounge"),
            JourneyTimelineStep(5, "Boarding Gate", "35 min before flight", "Priority boarding for Groups 1 & 2", "Gate 61-75")
        )
    )

    private fun createKansaiGuide() = AirportGuide(
        airport = SampleAirports.KIX,
        terminalName = "Terminal 1",
        checkInCounters = "Island F",
        sakuraLounge = SakuraLoungeInfo(
            name = "Lounge Kansai / JAL Partner Lounge",
            terminal = "Terminal 1 International",
            location = "Post Security International Gates",
            openingHours = "07:00 - 23:00",
            amenities = listOf("Japanese Bento Snacks", "Draft Beer Dispenser", "Wi-Fi"),
            highlights = "Comfortable seating close to international departure gates."
        ),
        transitGuide = "JR Haruka Express to Osaka Station (45 min) or Nankai Rapi:t to Namba (34 min).",
        timeline = listOf(
            JourneyTimelineStep(1, "Arrive at Kansai T1", "2.5h before flight", "Head to 4F International Departures", "4F"),
            JourneyTimelineStep(2, "JAL Counter Check-in", "2h before flight", "Check bags and confirm seats", "Island F"),
            JourneyTimelineStep(3, "Security Clearance", "1.5h before flight", "Proceed through security checkpoints", "4F Center"),
            JourneyTimelineStep(4, "Lounge & Boarding", "40 min before flight", "Boarding starts promptly", "Gate 12")
        )
    )

    private fun createJfkGuide() = AirportGuide(
        airport = SampleAirports.JFK,
        terminalName = "Terminal 8",
        checkInCounters = "Zone 1-2 JAL Class Island",
        sakuraLounge = SakuraLoungeInfo(
            name = "Soho Lounge & Greenwich Lounge (JAL / OneWorld Partner)",
            terminal = "Terminal 8, Level 3",
            location = "Post security near Gate 14",
            openingHours = "04:30 - 22:30",
            amenities = listOf("A la carte Dining", "Cocktail Lounge", "Shower Facilities", "Buffet"),
            highlights = "Joint premium experience with OneWorld partner American Airlines."
        ),
        transitGuide = "JFK AirTrain connects to Jamaica Station for Long Island Rail Road (20 min to Manhattan) or Subway E Line.",
        timeline = listOf(
            JourneyTimelineStep(1, "Arrive at JFK Terminal 8", "3h before flight", "Departures Level", "Level 3"),
            JourneyTimelineStep(2, "JAL Check-In Counter", "2.5h before flight", "Check-in Zone 1", "T8 Check-in"),
            JourneyTimelineStep(3, "TSA PreCheck / Security", "2h before flight", "Security checkpoint", "T8 Center"),
            JourneyTimelineStep(4, "Soho / Greenwich Lounge", "1h before flight", "Pre-flight dining and cocktails", "Near Gate 14"),
            JourneyTimelineStep(5, "Boarding Flight JL005 to Tokyo", "40 min before flight", "Boarding by Group", "Gate 16")
        )
    )

    private fun createHeathrowGuide() = AirportGuide(
        airport = SampleAirports.LHR,
        terminalName = "Terminal 3",
        checkInCounters = "Zone E (JAL Class)",
        sakuraLounge = SakuraLoungeInfo(
            name = "Cathay Pacific & Qantas Lounge (JAL Partner Lounges)",
            terminal = "Terminal 3, Lounge Area C & D",
            location = "Post security Lounge Concourse",
            openingHours = "05:30 - 22:00",
            amenities = listOf("Noodle Bar", "A la carte Dining", "Barista Coffee", "Showers"),
            highlights = "World-class OneWorld lounges featuring fresh ramen and British afternoon tea."
        ),
        transitGuide = "Elizabeth Line to Central London (30 min) or Heathrow Express to Paddington (15 min).",
        timeline = listOf(
            JourneyTimelineStep(1, "Arrive at London Heathrow T3", "3h before flight", "Terminal 3 Departures", "Zone E"),
            JourneyTimelineStep(2, "JAL Counter Check-in", "2.5h before flight", "Bag drop and passport check", "Zone E"),
            JourneyTimelineStep(3, "Fast Track Security", "2h before flight", "T3 Security", "Level 1"),
            JourneyTimelineStep(4, "OneWorld Lounge Visit", "1h before flight", "Noodle bar and relaxation", "Lounge Area C"),
            JourneyTimelineStep(5, "Board Flight JL044 to Haneda", "45 min before flight", "Boarding starts", "Gate 24")
        )
    )
}
