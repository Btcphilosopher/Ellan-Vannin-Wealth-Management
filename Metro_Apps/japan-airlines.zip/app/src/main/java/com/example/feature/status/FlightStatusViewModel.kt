package com.example.feature.status

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.FlightSegment
import com.example.core.repository.FlightRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class StatusUiState(
    val searchQuery: String = "",
    val flights: List<FlightSegment> = emptyList(),
    val isLoading: Boolean = false
)

class FlightStatusViewModel(private val flightRepository: FlightRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(StatusUiState())
    val uiState: StateFlow<StatusUiState> = _uiState.asStateFlow()

    init {
        searchStatus("")
    }

    fun searchStatus(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query, isLoading = true)
        viewModelScope.launch {
            val results = flightRepository.getFlightStatus(query)
            _uiState.value = _uiState.value.copy(flights = results, isLoading = false)
        }
    }
}
