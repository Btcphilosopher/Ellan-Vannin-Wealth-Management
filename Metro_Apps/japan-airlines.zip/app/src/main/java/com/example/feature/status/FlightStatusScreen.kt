package com.example.feature.status

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.component.StatusBadge
import com.example.core.designsystem.theme.*
import com.example.core.model.FlightSegment

@Composable
fun FlightStatusScreen(
    viewModel: FlightStatusViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory)
    ) {
        // Header
        Surface(
            color = JalCrimson,
            contentColor = PureWhite,
            shadowElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("FLIGHT STATUS LOOKUP", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = PureWhite, letterSpacing = 1.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.searchStatus(it) },
                    placeholder = { Text("Flight number or airport (e.g. JL005, HND, JFK)") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = JalMediumGrey) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = PureWhite,
                        unfocusedContainerColor = PureWhite,
                        focusedBorderColor = PureWhite,
                        unfocusedBorderColor = PureWhite
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("flight_status_search_input")
                )
            }
        }

        if (uiState.isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = JalCrimson)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(uiState.flights) { flight ->
                    FlightStatusCard(flight = flight)
                }
            }
        }
    }
}

@Composable
fun FlightStatusCard(flight: FlightSegment) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(flight.flightNumber, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = JalCharcoal)
                StatusBadge(status = flight.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(flight.origin.code, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Text("${flight.origin.city} (${flight.departureTime})", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                    Text("Gate ${flight.gate} • T${flight.terminal}", style = MaterialTheme.typography.labelMedium, color = JalCrimson, fontWeight = FontWeight.Bold)
                }

                Icon(Icons.Default.TrendingFlat, contentDescription = null, tint = JalCrimson, modifier = Modifier.size(28.dp))

                Column(horizontalAlignment = Alignment.End) {
                    Text(flight.destination.code, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Text("${flight.destination.city} (${flight.arrivalTime})", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                    Text("Baggage Belt: ${flight.baggageClaimBelt}", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                }
            }
        }
    }
}
