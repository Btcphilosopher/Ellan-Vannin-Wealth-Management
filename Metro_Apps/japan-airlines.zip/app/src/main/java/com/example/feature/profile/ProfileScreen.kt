package com.example.feature.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.theme.*

@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory)
    ) {
        // Header
        Surface(
            color = JalCrimson,
            contentColor = PureWhite,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("PROFILE & SETTINGS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = PureWhite, letterSpacing = 1.sp)
                    Text("Passenger info, language & app preferences", style = MaterialTheme.typography.bodyMedium, color = PureWhite.copy(alpha = 0.85f))
                }
            }
        }

        uiState.savedSuccessMsg?.let { msg ->
            Surface(color = JalSuccessGreenBg, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(msg, color = JalSuccessGreen, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { viewModel.clearSavedMsg() }) {
                        Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = JalSuccessGreen)
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Saved Passenger Info
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(JalCrimsonLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = JalCrimson)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(uiState.userName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = JalCharcoal)
                                Text("JMB Diamond Member", style = MaterialTheme.typography.bodyMedium, color = JmbGold, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = JalBorderGrey)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Passport Number", color = JalMediumGrey)
                            Text(uiState.passportNumber, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("JMB Number", color = JalMediumGrey)
                            Text(uiState.jmbNumber, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 2. Language & Localisation Controls
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("LANGUAGE & REGION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Display Language", fontWeight = FontWeight.Medium)
                            Row {
                                FilterChip(
                                    selected = uiState.currentLanguage == "EN",
                                    onClick = { viewModel.setLanguage("EN") },
                                    label = { Text("English") },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = JalCrimson, selectedLabelColor = PureWhite),
                                    modifier = Modifier.testTag("language_chip_en")
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                FilterChip(
                                    selected = uiState.currentLanguage == "JA",
                                    onClick = { viewModel.setLanguage("JA") },
                                    label = { Text("日本語") },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = JalCrimson, selectedLabelColor = PureWhite),
                                    modifier = Modifier.testTag("language_chip_ja")
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Preferred Currency", fontWeight = FontWeight.Medium)
                            Row {
                                listOf("JPY", "USD", "EUR").forEach { curr ->
                                    FilterChip(
                                        selected = uiState.currentCurrency == curr,
                                        onClick = { viewModel.setCurrency(curr) },
                                        label = { Text(curr) },
                                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = JalCrimson, selectedLabelColor = PureWhite),
                                        modifier = Modifier.padding(horizontal = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. Accessibility & System Settings
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("ACCESSIBILITY & PRIVACY", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("High Contrast Mode", fontWeight = FontWeight.Medium)
                            Switch(
                                checked = uiState.highContrastEnabled,
                                onCheckedChange = { viewModel.toggleHighContrast(it) },
                                colors = SwitchDefaults.colors(checkedThumbColor = PureWhite, checkedTrackColor = JalCrimson)
                            )
                        }
                    }
                }
            }
        }
    }
}
