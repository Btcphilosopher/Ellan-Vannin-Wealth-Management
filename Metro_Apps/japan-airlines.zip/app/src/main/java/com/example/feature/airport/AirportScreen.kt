package com.example.feature.airport

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.designsystem.theme.*

@Composable
fun AirportScreen(viewModel: AirportViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val guide = uiState.airportGuide
    val airports = listOf("HND" to "Tokyo Haneda", "NRT" to "Tokyo Narita", "KIX" to "Osaka Kansai", "JFK" to "New York JFK", "LHR" to "London Heathrow")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        // Header
        item {
            Surface(
                color = JalCrimson,
                contentColor = PureWhite,
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(16.dp)
                ) {
                    Text("AIRPORT COMPANION", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = PureWhite, letterSpacing = 1.sp)
                    Text("Terminal guides, Sakura Lounge & Journey Timeline", style = MaterialTheme.typography.bodyMedium, color = PureWhite.copy(alpha = 0.85f))

                    Spacer(modifier = Modifier.height(12.dp))

                    // Airport Selector Chips
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(airports) { (code, name) ->
                            val selected = uiState.selectedAirportCode == code
                            FilterChip(
                                selected = selected,
                                onClick = { viewModel.selectAirport(code) },
                                label = { Text("$name ($code)") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PureWhite,
                                    selectedLabelColor = JalCrimson,
                                    containerColor = PureWhite.copy(alpha = 0.2f),
                                    labelColor = PureWhite
                                )
                            )
                        }
                    }
                }
            }
        }

        // 1. Terminal Overview
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Place, contentDescription = null, tint = JalCrimson)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(guide.airport.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Terminal: ${guide.terminalName}", style = MaterialTheme.typography.titleMedium, color = JalCrimson, fontWeight = FontWeight.Bold)
                    Text("Check-In Counters: ${guide.checkInCounters}", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Transit: ${guide.transitGuide}", style = MaterialTheme.typography.bodyMedium, color = JalCharcoal)
                }
            }
        }

        // 2. Sakura Lounge Section with Generated Lounge Image
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column {
                    Box(modifier = Modifier.height(140.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.jal_sakura_lounge_1792910441725),
                            contentDescription = "JAL Sakura Lounge",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    androidx.compose.ui.graphics.Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, JalCharcoal.copy(alpha = 0.85f))
                                    )
                                )
                        ) {
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(12.dp)
                            ) {
                                Text(guide.sakuraLounge.name, style = MaterialTheme.typography.titleMedium, color = PureWhite, fontWeight = FontWeight.Bold)
                                Text("Hours: ${guide.sakuraLounge.openingHours}", style = MaterialTheme.typography.labelMedium, color = JmbGold)
                            }
                        }
                    }

                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(guide.sakuraLounge.highlights, style = MaterialTheme.typography.bodyMedium, color = JalCharcoal, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("LOUNGE AMENITIES", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = JalMediumGrey)
                        Spacer(modifier = Modifier.height(6.dp))
                        guide.sakuraLounge.amenities.forEach { amenity ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = JalSuccessGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(amenity, style = MaterialTheme.typography.bodyMedium, color = JalCharcoal)
                            }
                        }
                    }
                }
            }
        }

        // 3. Step-by-Step Journey Timeline
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    text = "DEPARTURE JOURNEY TIMELINE",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = JalCharcoal,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                guide.timeline.forEach { step ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(JalCrimson),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${step.stepNumber}", color = PureWhite, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(step.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                                Text(step.description, style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                                Text("${step.location} • ${step.estimatedTime}", style = MaterialTheme.typography.labelMedium, color = JalCrimson, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}
