package com.example.core.repository

import com.example.core.model.CabinClass
import com.example.core.model.LoyaltyAccount
import com.example.core.model.LoyaltyTransaction

data class AwardRequirement(
    val route: String,
    val economyMiles: Int,
    val premiumEcoMiles: Int,
    val businessMiles: Int,
    val firstMiles: Int
)

class LoyaltyRepository {

    fun getLoyaltyAccount(): LoyaltyAccount {
        return LoyaltyAccount(
            jmbNumber = "7829-1092-348",
            name = "TARO YAMADA",
            tier = "JMB DIAMOND",
            milesBalance = 128400,
            flyOnPoints = 84200,
            flyOnNextTier = 100000,
            expiringMiles = 12000,
            expiryDate = "2027-03-31"
        )
    }

    fun getRecentTransactions(): List<LoyaltyTransaction> {
        return listOf(
            LoyaltyTransaction("2026-10-18", "JL006 Tokyo Haneda - New York JFK (Business)", 13420, 13420),
            LoyaltyTransaction("2026-10-10", "JAL Pay Card Double Miles Promotion", 2500, 0),
            LoyaltyTransaction("2026-09-28", "JL043 Tokyo Haneda - London Heathrow (Business)", 12800, 12800),
            LoyaltyTransaction("2026-09-15", "Hotel Nikko Tokyo Stay Bonus", 1500, 0),
            LoyaltyTransaction("2026-08-30", "JL501 Tokyo Haneda - Sapporo CTS (Class J)", 1200, 1800)
        )
    }

    fun calculateAwardMilesRequired(originCode: String, destCode: String): AwardRequirement {
        val routeStr = "$originCode to $destCode"
        val isDomestic = (originCode == "HND" || originCode == "NRT" || originCode == "ITM" || originCode == "KIX") &&
                (destCode == "CTS" || destCode == "FUK" || destCode == "OKA" || destCode == "ITM")

        return if (isDomestic) {
            AwardRequirement(routeStr, economyMiles = 6000, premiumEcoMiles = 8000, businessMiles = 10000, firstMiles = 14000)
        } else {
            AwardRequirement(routeStr, economyMiles = 25000, premiumEcoMiles = 35000, businessMiles = 50000, firstMiles = 70000)
        }
    }

    fun getTierBenefits(tierName: String): List<String> {
        return when {
            tierName.contains("DIAMOND", ignoreCase = true) -> listOf(
                "Exclusive JAL First Class Lounge Access",
                "130% Sector Mileage Bonus",
                "Dedicated JMB Diamond Support Desk",
                "3 Piece Checked Baggage Allowance (+32kg each)",
                "Priority Boarding (Group 1 Always)",
                "Complimentary Seat Selection in all cabins including JAL Suite"
            )
            tierName.contains("PREMIER", ignoreCase = true) -> listOf(
                "JAL First Class Lounge & Sakura Lounge Access",
                "105% Sector Mileage Bonus",
                "Priority Baggage Handling (First Class tag)",
                "Group 1 Boarding Privilege"
            )
            tierName.contains("SAPPHIRE", ignoreCase = true) -> listOf(
                "JAL Sakura Lounge Access worldwide",
                "105% Sector Mileage Bonus",
                "Extra 1 Piece Baggage Allowance",
                "Group 2 Priority Boarding"
            )
            else -> listOf(
                "Basic JMB Miles Earning & Redemption",
                "Advance Seat Selection",
                "Waitlist Priority for JAL Flights"
            )
        }
    }
}
