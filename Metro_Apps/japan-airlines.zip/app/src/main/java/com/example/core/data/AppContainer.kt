package com.example.core.data

import android.content.Context
import androidx.room.Room
import com.example.core.database.AppDatabase
import com.example.core.repository.AirportRepository
import com.example.core.repository.BookingRepository
import com.example.core.repository.FlightRepository
import com.example.core.repository.LoyaltyRepository
import com.example.core.repository.NotificationRepository

class AppContainer(private val context: Context) {

    val database: AppDatabase by lazy {
        Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "jal_app_database"
        ).fallbackToDestructiveMigration().build()
    }

    val userPreferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(context.applicationContext)
    }

    val flightRepository: FlightRepository by lazy {
        FlightRepository()
    }

    val bookingRepository: BookingRepository by lazy {
        BookingRepository(database.bookingDao())
    }

    val airportRepository: AirportRepository by lazy {
        AirportRepository()
    }

    val loyaltyRepository: LoyaltyRepository by lazy {
        LoyaltyRepository()
    }

    val notificationRepository: NotificationRepository by lazy {
        NotificationRepository(database.notificationDao())
    }
}
