package com.example.feature.trips

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.Booking
import com.example.core.repository.BookingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class TripsUiState(
    val bookings: List<Booking> = emptyList(),
    val filteredBookings: List<Booking> = emptyList(),
    val searchQuery: String = "",
    val selectedTab: Int = 0, // 0: Active, 1: Past/Cancelled
    val selectedBookingDetail: Booking? = null,
    val showCancelDialog: Boolean = false,
    val actionPnr: String? = null
)

class TripsViewModel(private val bookingRepository: BookingRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(TripsUiState())
    val uiState: StateFlow<TripsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            bookingRepository.allBookings.collect { list ->
                _uiState.value = _uiState.value.copy(
                    bookings = list,
                    filteredBookings = filterBookings(list, _uiState.value.selectedTab, _uiState.value.searchQuery)
                )
            }
        }
    }

    fun setSelectedTab(tabIndex: Int) {
        _uiState.value = _uiState.value.copy(
            selectedTab = tabIndex,
            filteredBookings = filterBookings(_uiState.value.bookings, tabIndex, _uiState.value.searchQuery)
        )
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(
            searchQuery = query,
            filteredBookings = filterBookings(_uiState.value.bookings, _uiState.value.selectedTab, query)
        )
    }

    fun loadTripDetail(pnr: String) {
        viewModelScope.launch {
            val booking = bookingRepository.getBookingByPnr(pnr)
            _uiState.value = _uiState.value.copy(selectedBookingDetail = booking)
        }
    }

    fun promptCancelBooking(pnr: String) {
        _uiState.value = _uiState.value.copy(showCancelDialog = true, actionPnr = pnr)
    }

    fun dismissCancelDialog() {
        _uiState.value = _uiState.value.copy(showCancelDialog = false, actionPnr = null)
    }

    fun confirmCancelBooking() {
        val pnr = _uiState.value.actionPnr ?: return
        viewModelScope.launch {
            bookingRepository.cancelBooking(pnr)
            _uiState.value = _uiState.value.copy(showCancelDialog = false, actionPnr = null)
        }
    }

    private fun filterBookings(list: List<Booking>, tab: Int, query: String): List<Booking> {
        val tabFiltered = if (tab == 0) {
            list.filter { it.status != "CANCELLED" && it.status != "COMPLETED" }
        } else {
            list.filter { it.status == "CANCELLED" || it.status == "COMPLETED" }
        }

        if (query.isBlank()) return tabFiltered

        val clean = query.trim().uppercase()
        return tabFiltered.filter {
            it.pnr.contains(clean) ||
            it.outboundFlight.flightNumber.contains(clean) ||
            it.outboundFlight.origin.code.contains(clean) ||
            it.outboundFlight.destination.code.contains(clean) ||
            it.passengers.any { p -> p.lastName.uppercase().contains(clean) }
        }
    }
}
