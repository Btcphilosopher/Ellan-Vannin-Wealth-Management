package com.example.core.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Search : Screen("search")
    object SearchResults : Screen("search_results/{origin}/{dest}/{date}/{cabin}/{passengers}") {
        fun createRoute(origin: String, dest: String, date: String, cabin: String, passengers: Int) =
            "search_results/$origin/$dest/$date/$cabin/$passengers"
    }
    object BookingFlow : Screen("booking_flow/{flightNum}/{cabin}") {
        fun createRoute(flightNum: String, cabin: String) = "booking_flow/$flightNum/$cabin"
    }
    object Trips : Screen("trips")
    object TripDetail : Screen("trip_detail/{pnr}") {
        fun createRoute(pnr: String) = "trip_detail/$pnr"
    }
    object CheckIn : Screen("checkin/{pnr}") {
        fun createRoute(pnr: String) = "checkin/$pnr"
    }
    object BoardingPass : Screen("boarding_pass/{pnr}") {
        fun createRoute(pnr: String) = "boarding_pass/$pnr"
    }
    object Airport : Screen("airport")
    object Status : Screen("status")
    object Loyalty : Screen("loyalty")
    object Notifications : Screen("notifications")
    object Profile : Screen("profile")
}
