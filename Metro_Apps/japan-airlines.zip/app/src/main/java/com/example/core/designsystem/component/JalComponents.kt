package com.example.core.designsystem.component

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.theme.*
import com.example.core.model.FlightStatusType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JalTopAppBar(
    title: String = "JAPAN AIRLINES",
    unreadCount: Int = 1,
    currentLanguage: String = "EN",
    onNotificationClick: () -> Unit = {},
    onProfileClick: () -> Unit = {},
    onLanguageToggle: () -> Unit = {}
) {
    Surface(
        color = JalCrimson,
        contentColor = PureWhite,
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // JAL Crane emblem indicator
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(PureWhite),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "JAL",
                        color = JalCrimson,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        color = PureWhite,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (currentLanguage == "JA") "日本航空" else "Premium World Class",
                        style = MaterialTheme.typography.labelMedium,
                        color = PureWhite.copy(alpha = 0.85f)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Language Switcher Chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(PureWhite.copy(alpha = 0.2f))
                        .clickable { onLanguageToggle() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("language_toggle_button")
                ) {
                    Text(
                        text = currentLanguage,
                        color = PureWhite,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Notification Badge Button
                IconButton(
                    onClick = onNotificationClick,
                    modifier = Modifier.testTag("notification_icon_button")
                ) {
                    Box {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = PureWhite
                        )
                        if (unreadCount > 0) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(PureWhite)
                                    .align(Alignment.TopEnd),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$unreadCount",
                                    color = JalCrimson,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Profile shortcut
                IconButton(
                    onClick = onProfileClick,
                    modifier = Modifier.testTag("profile_icon_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AccountCircle,
                        contentDescription = "Profile",
                        tint = PureWhite
                    )
                }
            }
        }
    }
}

enum class JalTab(val route: String, val titleEn: String, val titleJa: String, val icon: ImageVector) {
    HOME("home", "Home", "ホーム", Icons.Default.Home),
    SEARCH("search", "Book", "予約", Icons.Default.FlightTakeoff),
    TRIPS("trips", "My Trips", "ご予約", Icons.Default.ConfirmationNumber),
    AIRPORT("airport", "Airport", "空港案内", Icons.Default.Place),
    LOYALTY("loyalty", "JMB Loyalty", "マイル", Icons.Default.Stars)
}

@Composable
fun JalBottomNavigationBar(
    currentRoute: String,
    currentLanguage: String = "EN",
    onTabSelected: (JalTab) -> Unit
) {
    Surface(
        color = PureWhite,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            JalTab.entries.forEach { tab ->
                val isSelected = currentRoute == tab.route
                val label = if (currentLanguage == "JA") tab.titleJa else tab.titleEn

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("tab_${tab.route}")
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) JalCrimsonLight else Color.Transparent)
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = label,
                            tint = if (isSelected) JalCrimson else JalMediumGrey,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isSelected) JalCrimson else JalMediumGrey,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: FlightStatusType) {
    val (bgColor, textColor) = when (status) {
        FlightStatusType.SCHEDULED -> JalLightGrey to JalDarkGrey
        FlightStatusType.BOARDING -> JalCrimsonLight to JalCrimson
        FlightStatusType.DEPARTED -> JalSuccessGreenBg to JalSuccessGreen
        FlightStatusType.ARRIVED -> JalSuccessGreenBg to JalSuccessGreen
        FlightStatusType.DELAYED -> JalWarningAmberBg to JalWarningAmber
        FlightStatusType.CANCELLED -> JalErrorRedBg to JalErrorRed
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = status.label,
            color = textColor,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun JalPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    testTag: String = "jal_primary_button"
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = JalCrimson,
            contentColor = PureWhite,
            disabledContainerColor = JalBorderGrey,
            disabledContentColor = JalMediumGrey
        ),
        shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .testTag(testTag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
