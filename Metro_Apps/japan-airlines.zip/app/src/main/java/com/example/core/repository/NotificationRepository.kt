package com.example.core.repository

import com.example.core.database.NotificationDao
import com.example.core.database.NotificationEntity
import com.example.core.model.NotificationMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class NotificationRepository(private val notificationDao: NotificationDao) {

    val allNotifications: Flow<List<NotificationMessage>> = notificationDao.getAllNotifications().map { entities ->
        entities.map { entity ->
            NotificationMessage(
                id = entity.id,
                title = entity.title,
                body = entity.body,
                timestamp = entity.timestamp,
                category = entity.category,
                relatedPnr = entity.relatedPnr,
                isRead = entity.isRead
            )
        }
    }

    suspend fun markAsRead(id: String) {
        notificationDao.markAsRead(id)
    }

    suspend fun seedInitialNotificationsIfEmpty() {
        val initial = listOf(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Check-In Open for JL005",
                body = "Online check-in is now available for your flight to New York (JFK). Tap to confirm seat 12A.",
                timestamp = "2026-10-24 11:00",
                category = "CheckIn",
                relatedPnr = "JAL88K",
                isRead = false
            ),
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "JMB Diamond Miles Credited",
                body = "13,420 FLY ON Points credited for flight JL006 (Tokyo Haneda to New York JFK).",
                timestamp = "2026-10-20 18:30",
                category = "Loyalty",
                relatedPnr = null,
                isRead = true
            ),
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Gate Update: JL043",
                body = "Departure gate for JL043 to London Heathrow assigned to Gate 114 at Haneda T3.",
                timestamp = "2026-10-18 08:15",
                category = "GateChange",
                relatedPnr = null,
                isRead = true
            )
        )
        initial.forEach { notificationDao.insertNotification(it) }
    }
}
