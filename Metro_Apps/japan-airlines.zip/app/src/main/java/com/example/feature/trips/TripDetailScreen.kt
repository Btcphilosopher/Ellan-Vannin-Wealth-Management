package com.example.feature.trips

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.component.JalPrimaryButton
import com.example.core.designsystem.theme.*

@Composable
fun TripDetailScreen(
    pnr: String,
    viewModel: TripsViewModel,
    onBackClick: () -> Unit,
    onBoardingPassClick: (pnr: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(pnr) {
        viewModel.loadTripDetail(pnr)
    }

    val booking = uiState.selectedBookingDetail

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory)
    ) {
        // Top Bar
        Surface(
            color = JalCrimson,
            contentColor = PureWhite,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("BOOKING DETAILS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = PureWhite)
                    Text("PNR: $pnr", style = MaterialTheme.typography.bodyMedium, color = PureWhite.copy(alpha = 0.85f))
                }
            }
        }

        if (booking == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = JalCrimson)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Flight Segment Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("FLIGHT SEGMENT", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = JalMediumGrey)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("${booking.outboundFlight.operatingAirline} • ${booking.outboundFlight.flightNumber}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = JalCharcoal)
                            Text("Aircraft: ${booking.outboundFlight.aircraftType}", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)

                            Spacer(modifier = Modifier.height(14.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(booking.outboundFlight.origin.code, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCrimson)
                                    Text(booking.outboundFlight.origin.name, style = MaterialTheme.typography.bodyMedium, color = JalCharcoal)
                                    Text("Terminal ${booking.outboundFlight.terminal} • ${booking.outboundFlight.departureTime}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(booking.outboundFlight.destination.code, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCrimson)
                                    Text(booking.outboundFlight.destination.name, style = MaterialTheme.typography.bodyMedium, color = JalCharcoal)
                                    Text(booking.outboundFlight.arrivalTime, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Passenger & In-Flight Details
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("PASSENGER & IN-FLIGHT SERVICES", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = JalMediumGrey)
                            Spacer(modifier = Modifier.height(10.dp))

                            booking.passengers.forEach { p ->
                                Text("${p.firstName} ${p.lastName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                                Text("Passport: ${p.passportNumber} • JMB: ${p.jmbNumber}", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = JalBorderGrey)
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Assigned Seat", color = JalMediumGrey)
                                Text(booking.ancillary.seatNumber, fontWeight = FontWeight.Bold, color = JalCrimson)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Gourmet Meal Choice", color = JalMediumGrey)
                                Text(booking.ancillary.selectedMeal, fontWeight = FontWeight.Bold, color = JalCharcoal)
                            }
                        }
                    }
                }

                // Digital Receipt Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("DIGITAL RECEIPT & TAX INVOICE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = JalMediumGrey)
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Fare Family", color = JalMediumGrey)
                                Text(booking.fareFamilyName, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Paid", color = JalMediumGrey)
                                Text("¥${String.format("%,d", booking.totalPriceJpy)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = JalCrimson)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Payment Status", color = JalMediumGrey)
                                Text("AUTHORIZED & PAID", color = JalSuccessGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                item {
                    JalPrimaryButton(
                        text = "VIEW DIGITAL BOARDING PASS",
                        onClick = { onBoardingPassClick(booking.pnr) },
                        testTag = "view_boarding_pass_detail_button"
                    )
                }
            }
        }
    }
}
