package com.example.core.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "jal_user_settings")

class UserPreferencesRepository(private val context: Context) {

    companion object {
        val LANGUAGE_KEY = stringPreferencesKey("app_language") // "EN", "JA"
        val CURRENCY_KEY = stringPreferencesKey("app_currency") // "JPY", "USD", "EUR"
        val USER_NAME_KEY = stringPreferencesKey("user_name")
        val JMB_NUMBER_KEY = stringPreferencesKey("jmb_number")
    }

    val languageFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[LANGUAGE_KEY] ?: "EN"
    }

    val currencyFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[CURRENCY_KEY] ?: "JPY"
    }

    val userNameFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[USER_NAME_KEY] ?: "Taro Yamada"
    }

    val jmbNumberFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[JMB_NUMBER_KEY] ?: "7829-1092-348"
    }

    suspend fun setLanguage(language: String) {
        context.dataStore.edit { preferences ->
            preferences[LANGUAGE_KEY] = language
        }
    }

    suspend fun setCurrency(currency: String) {
        context.dataStore.edit { preferences ->
            preferences[CURRENCY_KEY] = currency
        }
    }

    suspend fun updateProfile(name: String, jmbNumber: String) {
        context.dataStore.edit { preferences ->
            preferences[USER_NAME_KEY] = name
            preferences[JMB_NUMBER_KEY] = jmbNumber
        }
    }
}
