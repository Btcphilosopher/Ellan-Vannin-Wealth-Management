package com.example.feature.booking

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.component.JalPrimaryButton
import com.example.core.designsystem.theme.*

@Composable
fun BookingFlowScreen(
    viewModel: BookingViewModel,
    onBookingFinished: (pnr: String) -> Unit,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory)
    ) {
        // Step Indicator Top Bar
        Surface(
            color = JalCrimson,
            contentColor = PureWhite,
            shadowElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        if (uiState.currentStep > 1 && !uiState.isBookingCompleted) {
                            viewModel.goToPreviousStep()
                        } else {
                            onBackClick()
                        }
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (uiState.currentStep) {
                            1 -> "Flight Review"
                            2 -> "Passenger Details"
                            3 -> "Select Seats"
                            4 -> "Gourmet & Services"
                            5 -> "Booking Confirmed"
                            else -> "Booking"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PureWhite
                    )
                }

                if (!uiState.isBookingCompleted) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        (1..4).forEach { stepNum ->
                            val active = uiState.currentStep >= stepNum
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(4.dp)
                                    .padding(horizontal = 2.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (active) PureWhite else PureWhite.copy(alpha = 0.3f))
                            )
                        }
                    }
                }
            }
        }

        uiState.validationError?.let { err ->
            Surface(color = JalErrorRedBg, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = err,
                    color = JalErrorRed,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (uiState.currentStep) {
                1 -> FlightSummaryStep(uiState, onNext = { viewModel.goToNextStep() })
                2 -> PassengerDetailsStep(uiState, viewModel, onNext = { viewModel.goToNextStep() })
                3 -> SeatSelectionStep(uiState, viewModel, onNext = { viewModel.goToNextStep() })
                4 -> AncillaryStep(uiState, viewModel, onConfirmPayment = { viewModel.processPaymentAndConfirm() })
                5 -> ConfirmationStep(uiState, onFinish = { pnr -> onBookingFinished(pnr) })
            }
        }
    }
}

@Composable
fun FlightSummaryStep(uiState: BookingFlowUiState, onNext: () -> Unit) {
    val flight = uiState.selectedFlight ?: return
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("SELECTED ITINERARY", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("${flight.operatingAirline} • ${flight.flightNumber}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Text("Aircraft: ${flight.aircraftType}", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(flight.origin.code, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCrimson)
                            Text(flight.origin.city, style = MaterialTheme.typography.bodyMedium, color = JalCharcoal)
                            Text(flight.departureTime, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${flight.durationMinutes / 60}h ${flight.durationMinutes % 60}m", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = JalCrimson)
                            Text("Direct", style = MaterialTheme.typography.labelMedium, color = JalSuccessGreen)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(flight.destination.code, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCrimson)
                            Text(flight.destination.city, style = MaterialTheme.typography.bodyMedium, color = JalCharcoal)
                            Text(flight.arrivalTime, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = JalBorderGrey)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Selected Cabin", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                        Text(uiState.selectedCabin.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JmbGold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Fare Features", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                        Text("JAL Sky Suite • 2x Checked Bags", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, color = JalCharcoal)
                    }
                }
            }
        }

        item {
            JalPrimaryButton(
                text = "CONTINUE TO PASSENGER DETAILS",
                onClick = onNext,
                testTag = "continue_to_passengers_button"
            )
        }
    }
}

@Composable
fun PassengerDetailsStep(
    uiState: BookingFlowUiState,
    viewModel: BookingViewModel,
    onNext: () -> Unit
) {
    val pass = uiState.passenger
    var firstName by remember { mutableStateOf(pass.firstName) }
    var lastName by remember { mutableStateOf(pass.lastName) }
    var passport by remember { mutableStateOf(pass.passportNumber) }
    var jmb by remember { mutableStateOf(pass.jmbNumber) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("PASSENGER 1 (ADULT)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = firstName,
                        onValueChange = {
                            firstName = it
                            viewModel.updatePassengerInfo(pass.title, it, lastName, passport, jmb, pass.mealPreference)
                        },
                        label = { Text("First Name (Given Name)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("passenger_first_name_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = lastName,
                        onValueChange = {
                            lastName = it
                            viewModel.updatePassengerInfo(pass.title, firstName, it, passport, jmb, pass.mealPreference)
                        },
                        label = { Text("Last Name (Family Name)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("passenger_last_name_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = passport,
                        onValueChange = {
                            passport = it
                            viewModel.updatePassengerInfo(pass.title, firstName, lastName, it, jmb, pass.mealPreference)
                        },
                        label = { Text("Passport Number") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("passenger_passport_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = jmb,
                        onValueChange = {
                            jmb = it
                            viewModel.updatePassengerInfo(pass.title, firstName, lastName, passport, it, pass.mealPreference)
                        },
                        label = { Text("JAL Mileage Bank (JMB) Number") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("passenger_jmb_input"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }

        item {
            JalPrimaryButton(
                text = "CONTINUE TO SEAT SELECTION",
                onClick = onNext,
                testTag = "continue_to_seats_button"
            )
        }
    }
}

@Composable
fun SeatSelectionStep(
    uiState: BookingFlowUiState,
    viewModel: BookingViewModel,
    onNext: () -> Unit
) {
    val seats = remember {
        listOf(
            "1A", "1D", "1G", "1K",
            "2A", "2D", "2G", "2K",
            "3A", "3D", "3G", "3K",
            "11A", "11D", "11G", "11K",
            "12A", "12D", "12G", "12K",
            "14A", "14D", "14G", "14K",
            "15A", "15D", "15G", "15K"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("JAL SKY SUITE CABIN SEAT MAP", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                Text("Selected Seat: ${uiState.ancillary.seatNumber}", style = MaterialTheme.typography.bodyMedium, color = JalCrimson, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(12.dp))

                // Legend
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                    SeatLegendItem("Selected", JalCrimson)
                    SeatLegendItem("Available", JalLightGrey)
                    SeatLegendItem("Occupied", JalMediumGrey)
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(seats) { seatCode ->
                        val isSelected = uiState.ancillary.seatNumber == seatCode
                        val isOccupied = seatCode == "1D" || seatCode == "2G" || seatCode == "11K"

                        Box(
                            modifier = Modifier
                                .height(50.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    when {
                                        isSelected -> JalCrimson
                                        isOccupied -> JalMediumGrey
                                        else -> JalLightGrey
                                    }
                                )
                                .clickable(enabled = !isOccupied) { viewModel.setSelectedSeat(seatCode) }
                                .testTag("seat_$seatCode"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = seatCode,
                                color = if (isSelected || isOccupied) PureWhite else JalCharcoal,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        JalPrimaryButton(
            text = "CONFIRM SEAT ${uiState.ancillary.seatNumber}",
            onClick = onNext,
            testTag = "confirm_seat_button"
        )
    }
}

@Composable
fun SeatLegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(14.dp).clip(RoundedCornerShape(3.dp)).background(color))
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = JalCharcoal)
    }
}

@Composable
fun AncillaryStep(
    uiState: BookingFlowUiState,
    viewModel: BookingViewModel,
    onConfirmPayment: () -> Unit
) {
    var extraBaggage by remember { mutableIntStateOf(uiState.ancillary.extraBaggageCount) }
    var selectedMeal by remember { mutableStateOf(uiState.ancillary.selectedMeal) }
    var loungePass by remember { mutableStateOf(uiState.ancillary.loungePassCount > 0) }

    val meals = listOf(
        "RED U-35 Japanese Kaiseki Menu",
        "Western Beef Tenderloin & Wine",
        "Shojin Ryori Vegetarian",
        "Low Sodium In-Flight Meal"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("JAPANESE GOURMET IN-FLIGHT DINING", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Spacer(modifier = Modifier.height(10.dp))
                    meals.forEach { meal ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    selectedMeal = meal
                                    viewModel.updateAncillary(extraBaggage, meal, loungePass)
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedMeal == meal,
                                onClick = {
                                    selectedMeal = meal
                                    viewModel.updateAncillary(extraBaggage, meal, loungePass)
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = JalCrimson)
                            )
                            Text(meal, style = MaterialTheme.typography.bodyMedium, color = JalCharcoal)
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("EXTRA BAGGAGE & LOUNGE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Additional Baggage (+1 Piece 23kg)", fontWeight = FontWeight.Bold, color = JalCharcoal)
                            Text("+¥15,000 / piece", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = {
                                if (extraBaggage > 0) {
                                    extraBaggage--
                                    viewModel.updateAncillary(extraBaggage, selectedMeal, loungePass)
                                }
                            }) {
                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease")
                            }
                            Text("$extraBaggage", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                            IconButton(onClick = {
                                extraBaggage++
                                viewModel.updateAncillary(extraBaggage, selectedMeal, loungePass)
                            }) {
                                Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase")
                            }
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("TOTAL FARE & PAYMENT REVIEW", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Spacer(modifier = Modifier.height(10.dp))
                    val baseFare = 580000
                    val baggageTotal = extraBaggage * 15000
                    val total = baseFare + baggageTotal

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("JAL Business Base Fare", color = JalMediumGrey)
                        Text("¥${String.format("%,d", baseFare)}", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Extra Baggage ($extraBaggage)", color = JalMediumGrey)
                        Text("¥${String.format("%,d", baggageTotal)}", fontWeight = FontWeight.Bold)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = JalBorderGrey)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Amount Due", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                        Text("¥${String.format("%,d", total)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = JalCrimson)
                    }
                }
            }
        }

        item {
            JalPrimaryButton(
                text = if (uiState.isPaymentProcessing) "PROCESSING AUTHORIZATION..." else "PAY & CONFIRM BOOKING",
                onClick = onConfirmPayment,
                enabled = !uiState.isPaymentProcessing,
                testTag = "pay_and_confirm_button"
            )
        }
    }
}

@Composable
fun ConfirmationStep(uiState: BookingFlowUiState, onFinish: (pnr: String) -> Unit) {
    val booking = uiState.createdBooking ?: return
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(JalSuccessGreenBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = JalSuccessGreen, modifier = Modifier.size(48.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("BOOKING CONFIRMED", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
        Text("Thank you for choosing Japan Airlines", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(3.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("BOOKING REFERENCE (PNR)", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                Text(
                    text = booking.pnr,
                    style = MaterialTheme.typography.displayLarge,
                    color = JalCrimson,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = JalBorderGrey)
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Passenger", color = JalMediumGrey)
                    Text("${booking.passengers.first().firstName} ${booking.passengers.first().lastName}", fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Flight Number", color = JalMediumGrey)
                    Text(booking.outboundFlight.flightNumber, fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Assigned Seat", color = JalMediumGrey)
                    Text(booking.ancillary.seatNumber, fontWeight = FontWeight.Bold, color = JalCrimson)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        JalPrimaryButton(
            text = "VIEW BOARDING PASS",
            onClick = { onFinish(booking.pnr) },
            testTag = "view_boarding_pass_confirm_button"
        )
    }
}
