package com.example.core.designsystem.theme

import androidx.compose.ui.graphics.Color

// JAL Brand Colors
val JalCrimson = Color(0xFFD91424) // JAL Brand Primary Crimson Red
val JalDarkCrimson = Color(0xFFA60C19)
val JalCrimsonLight = Color(0xFFFFF0F2)

val JalCharcoal = Color(0xFF1A1A1A) // Primary Typography
val JalDarkGrey = Color(0xFF333333)
val JalMediumGrey = Color(0xFF70757A)
val JalLightGrey = Color(0xFFF4F5F7)
val JalBorderGrey = Color(0xFFE2E8F0)

val WarmIvory = Color(0xFFFAF8F5) // Japanese Editorial Surface
val PureWhite = Color(0xFFFFFFFF)

// Premium Accents
val JmbGold = Color(0xFFC5A059) // JMB Diamond / Sakura Lounge accent
val JmbGoldLight = Color(0xFFFFFBF0)
val SapphireBlue = Color(0xFF1E40AF) // JMB Sapphire
val CrystalSilver = Color(0xFF64748B)

// Status Colors
val JalSuccessGreen = Color(0xFF0F766E)
val JalSuccessGreenBg = Color(0xFFECFDF5)
val JalWarningAmber = Color(0xFFB45309)
val JalWarningAmberBg = Color(0xFFFFFBEB)
val JalErrorRed = Color(0xFFB91C1C)
val JalErrorRedBg = Color(0xFFFEF2F2)
