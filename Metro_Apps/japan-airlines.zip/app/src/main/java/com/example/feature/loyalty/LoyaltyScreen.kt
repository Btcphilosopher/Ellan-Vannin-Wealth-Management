package com.example.feature.loyalty

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.theme.*

@Composable
fun LoyaltyScreen(viewModel: LoyaltyViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val account = uiState.account

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        // Top Header
        item {
            Surface(
                color = JalCrimson,
                contentColor = PureWhite,
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(16.dp)
                ) {
                    Text("JAL MILEAGE BANK (JMB)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = PureWhite, letterSpacing = 1.sp)
                    Text("Loyalty Rewards & Tier Status", style = MaterialTheme.typography.bodyMedium, color = PureWhite.copy(alpha = 0.85f))
                }
            }
        }

        // 1. Digital JMB Diamond Loyalty Member Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = JalCharcoal),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("jmb_digital_member_card")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(JmbGold),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("JAL", color = JalCharcoal, fontSize = 10.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("JAL MILEAGE BANK", color = PureWhite, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }

                        Surface(color = JmbGold, shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = account.tier,
                                color = PureWhite,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(account.name, style = MaterialTheme.typography.displayMedium, color = PureWhite, fontWeight = FontWeight.Bold)
                    Text("JMB No. ${account.jmbNumber}", style = MaterialTheme.typography.titleMedium, color = JmbGold, fontWeight = FontWeight.SemiBold)

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("REDEEMABLE MILES", style = MaterialTheme.typography.labelMedium, color = PureWhite.copy(alpha = 0.7f))
                            Text("${String.format("%,d", account.milesBalance)} mi", style = MaterialTheme.typography.titleLarge, color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("FLY ON POINTS", style = MaterialTheme.typography.labelMedium, color = PureWhite.copy(alpha = 0.7f))
                            Text("${String.format("%,d", account.flyOnPoints)} FOP", style = MaterialTheme.typography.titleLarge, color = JmbGold, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Progress bar to next tier
                    LinearProgressIndicator(
                        progress = { account.flyOnPoints.toFloat() / account.flyOnNextTier.toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = JmbGold,
                        trackColor = PureWhite.copy(alpha = 0.2f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${100000 - account.flyOnPoints} FOP remaining for 2027 Diamond Renewal", style = MaterialTheme.typography.labelMedium, color = PureWhite.copy(alpha = 0.8f))
                }
            }
        }

        // 2. Award Ticket Miles Calculator
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("AWARD FLIGHT MILEAGE CALCULATOR", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.calculateAward("HND", "JFK") },
                            colors = ButtonDefaults.buttonColors(containerColor = JalCrimson)
                        ) {
                            Text("Tokyo → New York")
                        }
                        OutlinedButton(onClick = { viewModel.calculateAward("HND", "CTS") }) {
                            Text("Tokyo → Sapporo")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Economy Class", color = JalMediumGrey)
                        Text("${String.format("%,d", uiState.awardReq.economyMiles)} miles", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("JAL Business Class", color = JalMediumGrey)
                        Text("${String.format("%,d", uiState.awardReq.businessMiles)} miles", fontWeight = FontWeight.Bold, color = JmbGold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("JAL First Class Suite", color = JalMediumGrey)
                        Text("${String.format("%,d", uiState.awardReq.firstMiles)} miles", fontWeight = FontWeight.Bold, color = JalCrimson)
                    }
                }
            }
        }

        // 3. JMB Diamond Tier Benefits List
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("JMB DIAMOND TIER BENEFITS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Spacer(modifier = Modifier.height(10.dp))

                    uiState.tierBenefits.forEach { benefit ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                            Icon(Icons.Default.Stars, contentDescription = null, tint = JmbGold, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(benefit, style = MaterialTheme.typography.bodyMedium, color = JalCharcoal)
                        }
                    }
                }
            }
        }

        // 4. Recent Mileage Activity
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text("RECENT MILEAGE TRANSACTIONS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                Spacer(modifier = Modifier.height(8.dp))

                uiState.transactions.forEach { tx ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(tx.description, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                                Text(tx.date, style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                            }
                            Text("+${String.format("%,d", tx.milesEarned)} mi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalSuccessGreen)
                        }
                    }
                }
            }
        }
    }
}
