package com.example.core.repository

import com.example.core.database.BookingDao
import com.example.core.database.BookingEntity
import com.example.core.model.AncillarySelection
import com.example.core.model.Booking
import com.example.core.model.CabinClass
import com.example.core.model.Passenger
import com.example.core.model.SampleAirports
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class BookingRepository(private val bookingDao: BookingDao) {

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    val allBookings: Flow<List<Booking>> = bookingDao.getAllBookings().map { entities ->
        entities.map { entityToBooking(it) }
    }

    suspend fun getBookingByPnr(pnr: String): Booking? {
        val entity = bookingDao.getBookingByPnr(pnr) ?: return null
        return entityToBooking(entity)
    }

    suspend fun createBooking(booking: Booking) {
        val entity = bookingToEntity(booking)
        bookingDao.insertBooking(entity)
    }

    suspend fun updateBookingSeat(pnr: String, newSeat: String) {
        bookingDao.updateBookingSeat(pnr, newSeat)
    }

    suspend fun cancelBooking(pnr: String) {
        bookingDao.updateBookingStatus(pnr, "CANCELLED")
    }

    suspend fun checkInBooking(pnr: String) {
        bookingDao.updateBookingStatus(pnr, "CHECKED_IN")
    }

    suspend fun seedSampleBookingIfEmpty() {
        // Pre-populate demo trip if database has 0 items
        val samplePnr = "JAL88K"
        if (bookingDao.getBookingByPnr(samplePnr) == null) {
            val samplePassenger = Passenger(
                firstName = "Taro",
                lastName = "Yamada",
                passportNumber = "TR891024",
                jmbNumber = "7829-1092-348"
            )
            val flightRepo = FlightRepository()
            val flights = flightRepo.searchFlights("HND", "JFK", "2026-10-28", CabinClass.BUSINESS, 1)
            if (flights.isNotEmpty()) {
                val sampleBooking = Booking(
                    pnr = samplePnr,
                    status = "CONFIRMED",
                    passengers = listOf(samplePassenger),
                    outboundFlight = flights.first(),
                    cabinClass = CabinClass.BUSINESS,
                    fareFamilyName = "JAL SKY SUITE Business",
                    ancillary = AncillarySelection(
                        extraBaggageCount = 0,
                        selectedMeal = "RED U-35 Japanese Kaiseki Menu",
                        seatNumber = "12A",
                        priorityBoarding = true
                    ),
                    totalPriceJpy = 580000,
                    bookedDate = "2026-10-24"
                )
                createBooking(sampleBooking)
            }
        }
    }

    private fun bookingToEntity(booking: Booking): BookingEntity {
        val passAdapter = moshi.adapter(Passenger::class.java)
        val flightAdapter = moshi.adapter(com.example.core.model.FlightSegment::class.java)

        return BookingEntity(
            pnr = booking.pnr,
            passengerJson = passAdapter.toJson(booking.passengers.firstOrNull() ?: Passenger()),
            outboundFlightJson = flightAdapter.toJson(booking.outboundFlight),
            returnFlightJson = booking.returnFlight?.let { flightAdapter.toJson(it) },
            cabinClass = booking.cabinClass.name,
            fareFamilyName = booking.fareFamilyName,
            seatNumber = booking.ancillary.seatNumber,
            mealPreference = booking.ancillary.selectedMeal,
            totalPriceJpy = booking.totalPriceJpy,
            status = booking.status,
            bookedDate = booking.bookedDate
        )
    }

    private fun entityToBooking(entity: BookingEntity): Booking {
        val passAdapter = moshi.adapter(Passenger::class.java)
        val flightAdapter = moshi.adapter(com.example.core.model.FlightSegment::class.java)

        val passenger = try {
            passAdapter.fromJson(entity.passengerJson) ?: Passenger(firstName = "Taro", lastName = "Yamada")
        } catch (e: Exception) {
            Passenger(firstName = "Taro", lastName = "Yamada")
        }

        val outboundFlight = try {
            flightAdapter.fromJson(entity.outboundFlightJson) ?: FlightRepository().getFallbackFlight()
        } catch (e: Exception) {
            FlightRepository().getFallbackFlight()
        }

        val cabinClass = try {
            CabinClass.valueOf(entity.cabinClass)
        } catch (e: Exception) {
            CabinClass.BUSINESS
        }

        return Booking(
            pnr = entity.pnr,
            status = entity.status,
            passengers = listOf(passenger),
            outboundFlight = outboundFlight,
            cabinClass = cabinClass,
            fareFamilyName = entity.fareFamilyName,
            ancillary = AncillarySelection(
                seatNumber = entity.seatNumber,
                selectedMeal = entity.mealPreference
            ),
            totalPriceJpy = entity.totalPriceJpy,
            bookedDate = entity.bookedDate
        )
    }

    fun generateUniquePnr(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val pnrStr = (1..5).map { chars.random() }.joinToString("")
        return "JAL$pnrStr"
    }
}
