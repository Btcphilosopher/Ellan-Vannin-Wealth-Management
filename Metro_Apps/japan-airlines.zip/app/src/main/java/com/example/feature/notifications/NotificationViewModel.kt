package com.example.feature.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.NotificationMessage
import com.example.core.repository.NotificationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class NotificationUiState(
    val notifications: List<NotificationMessage> = emptyList(),
    val filterCategory: String = "ALL"
)

class NotificationViewModel(private val notificationRepository: NotificationRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(NotificationUiState())
    val uiState: StateFlow<NotificationUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            notificationRepository.seedInitialNotificationsIfEmpty()
            notificationRepository.allNotifications.collect { list ->
                _uiState.value = _uiState.value.copy(notifications = list)
            }
        }
    }

    fun markAsRead(id: String) {
        viewModelScope.launch {
            notificationRepository.markAsRead(id)
        }
    }

    fun setFilter(category: String) {
        _uiState.value = _uiState.value.copy(filterCategory = category)
    }
}
