package com.example.feature.loyalty

import androidx.lifecycle.ViewModel
import com.example.core.model.LoyaltyAccount
import com.example.core.model.LoyaltyTransaction
import com.example.core.repository.AwardRequirement
import com.example.core.repository.LoyaltyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class LoyaltyUiState(
    val account: LoyaltyAccount,
    val transactions: List<LoyaltyTransaction>,
    val tierBenefits: List<String>,
    val awardOrigin: String = "HND",
    val awardDest: String = "JFK",
    val awardReq: AwardRequirement
)

class LoyaltyViewModel(private val loyaltyRepository: LoyaltyRepository) : ViewModel() {

    private val account = loyaltyRepository.getLoyaltyAccount()
    private val transactions = loyaltyRepository.getRecentTransactions()
    private val benefits = loyaltyRepository.getTierBenefits(account.tier)
    private val defaultAward = loyaltyRepository.calculateAwardMilesRequired("HND", "JFK")

    private val _uiState = MutableStateFlow(
        LoyaltyUiState(
            account = account,
            transactions = transactions,
            tierBenefits = benefits,
            awardReq = defaultAward
        )
    )
    val uiState: StateFlow<LoyaltyUiState> = _uiState.asStateFlow()

    fun calculateAward(origin: String, dest: String) {
        val req = loyaltyRepository.calculateAwardMilesRequired(origin, dest)
        _uiState.value = _uiState.value.copy(
            awardOrigin = origin,
            awardDest = dest,
            awardReq = req
        )
    }
}
