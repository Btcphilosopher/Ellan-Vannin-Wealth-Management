package com.example.core.repository

import com.example.core.model.Airport
import com.example.core.model.CabinClass
import com.example.core.model.FareFamily
import com.example.core.model.FlightSegment
import com.example.core.model.FlightStatusType
import com.example.core.model.SampleAirports
import kotlinx.coroutines.delay

class FlightRepository {

    suspend fun searchFlights(
        originCode: String,
        destinationCode: String,
        departureDate: String,
        cabinClass: CabinClass,
        passengerCount: Int
    ): List<FlightSegment> {
        delay(300) // Simulate network response time

        val origin = SampleAirports.allAirports.find { it.code.equals(originCode, ignoreCase = true) }
            ?: SampleAirports.HND
        val dest = SampleAirports.allAirports.find { it.code.equals(destinationCode, ignoreCase = true) }
            ?: SampleAirports.JFK

        return generateSampleSchedule(origin, dest, departureDate, cabinClass)
    }

    fun getFallbackFlight(): FlightSegment {
        return generateSampleSchedule(SampleAirports.HND, SampleAirports.JFK, "2026-10-28", CabinClass.BUSINESS).first()
    }

    suspend fun getFlightStatus(query: String): List<FlightSegment> {
        delay(200)
        val allFlights = listOf(
            createFlightSegment("JL005", SampleAirports.HND, SampleAirports.JFK, "2026-10-25", "11:05", "11:00", durationMinutes = 775, aircraft = "Airbus A350-1000", status = FlightStatusType.SCHEDULED, gate = "112", terminal = "3"),
            createFlightSegment("JL043", SampleAirports.HND, SampleAirports.LHR, "2026-10-25", "09:55", "16:15", durationMinutes = 860, aircraft = "Airbus A350-1000", status = FlightStatusType.BOARDING, gate = "114", terminal = "3"),
            createFlightSegment("JL006", SampleAirports.JFK, SampleAirports.HND, "2026-10-25", "13:15", "16:35", durationMinutes = 800, aircraft = "Airbus A350-1000", status = FlightStatusType.DEPARTED, gate = "8", terminal = "8"),
            createFlightSegment("JL501", SampleAirports.HND, SampleAirports.CTS, "2026-10-25", "06:30", "08:00", durationMinutes = 90, aircraft = "Boeing 787-9", status = FlightStatusType.ARRIVED, gate = "15", terminal = "1"),
            createFlightSegment("JL033", SampleAirports.HND, SampleAirports.BKK, "2026-10-25", "00:05", "05:05", durationMinutes = 420, aircraft = "Boeing 787-9", status = FlightStatusType.DELAYED, gate = "142", terminal = "3")
        )

        val cleanQuery = query.trim().uppercase()
        if (cleanQuery.isEmpty()) return allFlights

        return allFlights.filter { flight ->
            flight.flightNumber.contains(cleanQuery) ||
            flight.origin.code.contains(cleanQuery) ||
            flight.origin.city.uppercase().contains(cleanQuery) ||
            flight.destination.code.contains(cleanQuery) ||
            flight.destination.city.uppercase().contains(cleanQuery)
        }
    }

    private fun generateSampleSchedule(
        origin: Airport,
        dest: Airport,
        date: String,
        selectedCabin: CabinClass
    ): List<FlightSegment> {
        val isLongHaul = origin.country != dest.country
        val aircraft = if (isLongHaul) "Airbus A350-1000" else "Boeing 787-9"
        val duration = if (isLongHaul) 740 else 90

        val basePrice = when (selectedCabin) {
            CabinClass.ECONOMY -> if (isLongHaul) 148000 else 24000
            CabinClass.PREMIUM_ECONOMY -> if (isLongHaul) 268000 else 38000
            CabinClass.BUSINESS -> if (isLongHaul) 580000 else 72000
            CabinClass.FIRST -> if (isLongHaul) 1250000 else 140000
        }

        return listOf(
            createFlightSegment("JL005", origin, dest, date, "11:05", "11:00", durationMinutes = duration, aircraft = aircraft, status = FlightStatusType.SCHEDULED, gate = "112", terminal = "3", basePrice = basePrice),
            createFlightSegment("JL003", origin, dest, date, "18:30", "18:25", durationMinutes = duration, aircraft = aircraft, status = FlightStatusType.SCHEDULED, gate = "114", terminal = "3", basePrice = (basePrice * 1.08).toInt()),
            createFlightSegment("JL011", origin, dest, date, "21:50", "21:40", durationMinutes = duration + 45, aircraft = aircraft, status = FlightStatusType.SCHEDULED, gate = "110", terminal = "3", stops = 1, connectionAirport = SampleAirports.NRT, basePrice = (basePrice * 0.92).toInt())
        )
    }

    private fun createFlightSegment(
        flightNumber: String,
        origin: Airport,
        dest: Airport,
        date: String,
        depTime: String,
        arrTime: String,
        durationMinutes: Int = 740,
        aircraft: String = "Airbus A350-1000",
        status: FlightStatusType = FlightStatusType.SCHEDULED,
        gate: String = "112",
        terminal: String = "3",
        stops: Int = 0,
        connectionAirport: Airport? = null,
        basePrice: Int = 148000
    ): FlightSegment {
        val fareFamilies = listOf(
            FareFamily(
                name = "Special Saver",
                cabinClass = CabinClass.ECONOMY,
                priceJpy = basePrice,
                checkedBagsAllowed = 2,
                isChangeable = false,
                isRefundable = false,
                seatSelectionIncluded = false,
                loungeAccessIncluded = false
            ),
            FareFamily(
                name = "Standard Flex",
                cabinClass = CabinClass.ECONOMY,
                priceJpy = (basePrice * 1.15).toInt(),
                checkedBagsAllowed = 2,
                isChangeable = true,
                isRefundable = true,
                seatSelectionIncluded = true,
                loungeAccessIncluded = false
            ),
            FareFamily(
                name = "JAL SKY SUITE Business",
                cabinClass = CabinClass.BUSINESS,
                priceJpy = basePrice * 3,
                checkedBagsAllowed = 3,
                isChangeable = true,
                isRefundable = true,
                seatSelectionIncluded = true,
                loungeAccessIncluded = true
            ),
            FareFamily(
                name = "JAL FIRST CLASS Suite",
                cabinClass = CabinClass.FIRST,
                priceJpy = basePrice * 6,
                checkedBagsAllowed = 3,
                isChangeable = true,
                isRefundable = true,
                seatSelectionIncluded = true,
                loungeAccessIncluded = true
            )
        )

        return FlightSegment(
            flightNumber = flightNumber,
            origin = origin,
            destination = dest,
            departureTime = depTime,
            arrivalTime = arrTime,
            departureDate = date,
            arrivalDate = date,
            durationMinutes = durationMinutes,
            aircraftType = aircraft,
            stopsCount = stops,
            connectionAirport = connectionAirport,
            status = status,
            gate = gate,
            terminal = terminal,
            fareFamilies = fareFamilies
        )
    }
}
