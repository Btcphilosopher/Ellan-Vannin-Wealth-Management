package com.example.feature.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.designsystem.component.JalPrimaryButton
import com.example.core.designsystem.theme.*
import com.example.core.model.Airport
import com.example.core.model.CabinClass
import com.example.core.model.SampleAirports
import com.example.core.model.TripType

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onSearchClick: (origin: String, dest: String, date: String, cabin: String, passengers: Int) -> Unit,
    onUpcomingTripClick: (pnr: String) -> Unit,
    onCheckInClick: (pnr: String) -> Unit,
    onBoardingPassClick: (pnr: String) -> Unit,
    onFlightStatusClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var showOriginPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory)
            .padding(bottom = 16.dp),
        contentPadding = PaddingValues(0.dp)
    ) {
        // 1. Editorial JAL Hero Banner & Welcome Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.jal_hero_banner_1792910441887),
                    contentDescription = "Japan Airlines Flagship",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(Color.Transparent, JalCharcoal.copy(alpha = 0.85f))
                            )
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "WELCOME ABOARD",
                                style = MaterialTheme.typography.labelMedium,
                                color = JmbGold,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = JmbGold,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = uiState.loyaltyAccount.tier,
                                    color = PureWhite,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Taro Yamada",
                            style = MaterialTheme.typography.displayLarge,
                            color = PureWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "JMB Miles: ${uiState.loyaltyAccount.milesBalance} | FLY ON Points: ${uiState.loyaltyAccount.flyOnPoints}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = PureWhite.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // 2. Upcoming Active Trip Hero Card (If Available)
        uiState.upcomingBooking?.let { booking ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .testTag("upcoming_trip_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(JalCrimsonLight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FlightTakeoff,
                                        contentDescription = null,
                                        tint = JalCrimson,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "UPCOMING TRIP • ${booking.pnr}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = JalCrimson,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                color = JalSuccessGreenBg,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = booking.status,
                                    color = JalSuccessGreen,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = booking.outboundFlight.origin.code,
                                    style = MaterialTheme.typography.displayMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = JalCharcoal
                                )
                                Text(
                                    text = booking.outboundFlight.origin.city,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = JalMediumGrey
                                )
                                Text(
                                    text = booking.outboundFlight.departureTime,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = JalCharcoal
                                )
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = booking.outboundFlight.flightNumber,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = JalCrimson
                                )
                                Icon(
                                    imageVector = Icons.Default.TrendingFlat,
                                    contentDescription = null,
                                    tint = JalMediumGrey,
                                    modifier = Modifier.size(28.dp)
                                )
                                Text(
                                    text = "${booking.outboundFlight.durationMinutes / 60}h ${booking.outboundFlight.durationMinutes % 60}m",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = JalMediumGrey
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = booking.outboundFlight.destination.code,
                                    style = MaterialTheme.typography.displayMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = JalCharcoal
                                )
                                Text(
                                    text = booking.outboundFlight.destination.city,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = JalMediumGrey
                                )
                                Text(
                                    text = booking.outboundFlight.arrivalTime,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = JalCharcoal
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = JalBorderGrey)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            OutlinedButton(
                                onClick = { onCheckInClick(booking.pnr) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = JalCrimson),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("upcoming_checkin_button")
                            ) {
                                Text("Online Check-In")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onBoardingPassClick(booking.pnr) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = JalCrimson),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("upcoming_boarding_pass_button")
                            ) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Boarding Pass")
                            }
                        }
                    }
                }
            }
        }

        // 3. Primary Flight Search Module
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "FLIGHT SEARCH",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = JalCharcoal,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Trip Type Segment Control
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(JalLightGrey)
                            .padding(4.dp)
                    ) {
                        TripType.entries.forEach { type ->
                            val selected = uiState.tripType == type
                            val label = when (type) {
                                TripType.ROUND_TRIP -> "Round Trip"
                                TripType.ONE_WAY -> "One Way"
                                TripType.MULTI_CITY -> "Multi-City"
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selected) PureWhite else Color.Transparent)
                                    .clickable { viewModel.setTripType(type) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selected) JalCrimson else JalMediumGrey
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Origin & Destination Selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Origin Field
                        OutlinedCard(
                            onClick = { showOriginPicker = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("origin_airport_picker"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("FROM", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                                Text(uiState.originCode, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = JalCharcoal)
                                Text(
                                    text = SampleAirports.allAirports.find { it.code == uiState.originCode }?.city ?: "Tokyo",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = JalMediumGrey
                                )
                            }
                        }

                        // Swap Button
                        IconButton(
                            onClick = { viewModel.swapAirports() },
                            modifier = Modifier
                                .padding(horizontal = 4.dp)
                                .clip(CircleShape)
                                .background(JalLightGrey)
                                .testTag("swap_airports_button")
                        ) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = "Swap", tint = JalCrimson)
                        }

                        // Destination Field
                        OutlinedCard(
                            onClick = { showDestPicker = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("destination_airport_picker"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("TO", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                                Text(uiState.destinationCode, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = JalCharcoal)
                                Text(
                                    text = SampleAirports.allAirports.find { it.code == uiState.destinationCode }?.city ?: "New York",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = JalMediumGrey
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Dates and Passengers
                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedCard(
                            onClick = {},
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("DEPARTURE DATE", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                                Text(uiState.departureDate, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = JalCharcoal)
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        OutlinedCard(
                            onClick = {},
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("PASSENGERS", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                                Text("${uiState.passengerCount} Adult", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = JalCharcoal)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Cabin Class Selector Chips
                    Text("CABIN CLASS", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(CabinClass.entries) { cabin ->
                            val isSelected = uiState.selectedCabin == cabin
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setCabinClass(cabin) },
                                label = { Text(cabin.displayName) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = JalCrimson,
                                    selectedLabelColor = PureWhite,
                                    containerColor = JalLightGrey,
                                    labelColor = JalCharcoal
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Search Button
                    JalPrimaryButton(
                        text = "SEARCH FLIGHTS",
                        icon = Icons.Default.Search,
                        testTag = "search_flights_button",
                        onClick = {
                            onSearchClick(
                                uiState.originCode,
                                uiState.destinationCode,
                                uiState.departureDate,
                                uiState.selectedCabin.name,
                                uiState.passengerCount
                            )
                        }
                    )
                }
            }
        }

        // 4. Quick Actions Row (Flight Status, Airport Guide, Lounge)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    text = "TRAVEL TOOLS",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = JalCharcoal,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ToolTile(
                        title = "Flight Status",
                        icon = Icons.Default.Schedule,
                        modifier = Modifier.weight(1f),
                        onClick = onFlightStatusClick
                    )
                    ToolTile(
                        title = "Sakura Lounge",
                        icon = Icons.Default.LocalBar,
                        modifier = Modifier.weight(1f),
                        onClick = {}
                    )
                    ToolTile(
                        title = "In-Flight Menu",
                        icon = Icons.Default.Restaurant,
                        modifier = Modifier.weight(1f),
                        onClick = {}
                    )
                }
            }
        }

        // 5. Destination Inspiration Carousel
        item {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text(
                    text = "DESTINATION INSPIRATION",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = JalCharcoal,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        DestinationCard("Tokyo (HND/NRT)", "Japan Flagship Hub", R.drawable.tokyo_destination_1792910441810)
                    }
                    item {
                        DestinationCard("Kyoto & Kansai", "Culture & Cuisine", R.drawable.jal_sakura_lounge_1792910441725)
                    }
                    item {
                        DestinationCard("New York (JFK)", "Daily A350-1000 Suites", R.drawable.jal_hero_banner_1792910441887)
                    }
                }
            }
        }
    }

    // Modal Airport Picker for Origin
    if (showOriginPicker) {
        AirportPickerModal(
            onDismiss = { showOriginPicker = false },
            onSelect = { airport ->
                viewModel.setOrigin(airport.code)
                showOriginPicker = false
            }
        )
    }

    // Modal Airport Picker for Destination
    if (showDestPicker) {
        AirportPickerModal(
            onDismiss = { showDestPicker = false },
            onSelect = { airport ->
                viewModel.setDestination(airport.code)
                showDestPicker = false
            }
        )
    }
}

@Composable
fun ToolTile(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(JalCrimsonLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = JalCrimson, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
        }
    }
}

@Composable
fun DestinationCard(title: String, subtitle: String, imageResId: Int) {
    Card(
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.width(220.dp)
    ) {
        Box(modifier = Modifier.height(140.dp)) {
            Image(
                painter = painterResource(id = imageResId),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(Color.Transparent, JalCharcoal.copy(alpha = 0.8f))
                        )
                    )
            ) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                ) {
                    Text(title, style = MaterialTheme.typography.titleMedium, color = PureWhite, fontWeight = FontWeight.Bold)
                    Text(subtitle, style = MaterialTheme.typography.labelMedium, color = PureWhite.copy(alpha = 0.85f))
                }
            }
        }
    }
}

@Composable
fun AirportPickerModal(
    onDismiss: () -> Unit,
    onSelect: (Airport) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredAirports = SampleAirports.allAirports.filter {
        it.code.contains(searchQuery, ignoreCase = true) ||
        it.name.contains(searchQuery, ignoreCase = true) ||
        it.city.contains(searchQuery, ignoreCase = true)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        title = {
            Text("Select Airport", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.height(380.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by city or airport code (e.g. HND, JFK)") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("airport_search_input"),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(filteredAirports) { airport ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelect(airport) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("${airport.city} (${airport.code})", fontWeight = FontWeight.Bold, color = JalCharcoal)
                                Text(airport.name, style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                            }
                            Text(airport.code, style = MaterialTheme.typography.titleMedium, color = JalCrimson, fontWeight = FontWeight.Bold)
                        }
                        HorizontalDivider(color = JalBorderGrey)
                    }
                }
            }
        }
    )
}
