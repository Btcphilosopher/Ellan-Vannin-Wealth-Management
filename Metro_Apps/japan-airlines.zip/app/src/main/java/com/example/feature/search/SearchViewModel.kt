package com.example.feature.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.CabinClass
import com.example.core.model.FlightSegment
import com.example.core.repository.FlightRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SearchUiState(
    val isLoading: Boolean = true,
    val origin: String = "HND",
    val destination: String = "JFK",
    val departureDate: String = "2026-10-28",
    val selectedCabin: CabinClass = CabinClass.BUSINESS,
    val passengerCount: Int = 1,
    val flights: List<FlightSegment> = emptyList(),
    val filteredFlights: List<FlightSegment> = emptyList(),
    val sortBy: String = "RECOMMENDED", // RECOMMENDED, LOWEST_PRICE, DEPARTURE_TIME, SHORTEST_DURATION
    val maxStopsFilter: Int = 2
)

class SearchViewModel(private val flightRepository: FlightRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    fun performSearch(origin: String, dest: String, date: String, cabinStr: String, passengers: Int) {
        val cabin = try { CabinClass.valueOf(cabinStr) } catch (e: Exception) { CabinClass.BUSINESS }
        _uiState.value = _uiState.value.copy(
            isLoading = true,
            origin = origin,
            destination = dest,
            departureDate = date,
            selectedCabin = cabin,
            passengerCount = passengers
        )

        viewModelScope.launch {
            val results = flightRepository.searchFlights(origin, dest, date, cabin, passengers)
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                flights = results,
                filteredFlights = sortFlights(results, _uiState.value.sortBy)
            )
        }
    }

    fun setSortBy(sortBy: String) {
        _uiState.value = _uiState.value.copy(
            sortBy = sortBy,
            filteredFlights = sortFlights(_uiState.value.flights, sortBy)
        )
    }

    private fun sortFlights(list: List<FlightSegment>, sort: String): List<FlightSegment> {
        return when (sort) {
            "LOWEST_PRICE" -> list.sortedBy { it.fareFamilies.firstOrNull()?.priceJpy ?: 0 }
            "DEPARTURE_TIME" -> list.sortedBy { it.departureTime }
            "SHORTEST_DURATION" -> list.sortedBy { it.durationMinutes }
            else -> list // RECOMMENDED
        }
    }
}
