package com.example.feature.checkin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.BoardingPassData
import com.example.core.model.Booking
import com.example.core.repository.BookingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class CheckInUiState(
    val booking: Booking? = null,
    val isEligible: Boolean = true,
    val passportConfirmed: Boolean = true,
    val emergencyContact: String = "+81 90-1234-5678",
    val selectedSeat: String = "12A",
    val isCheckInDone: Boolean = false,
    val boardingPassData: BoardingPassData? = null
)

class CheckInViewModel(private val bookingRepository: BookingRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(CheckInUiState())
    val uiState: StateFlow<CheckInUiState> = _uiState.asStateFlow()

    fun loadCheckInForPnr(pnr: String) {
        viewModelScope.launch {
            val booking = bookingRepository.getBookingByPnr(pnr)
            if (booking != null) {
                _uiState.value = _uiState.value.copy(
                    booking = booking,
                    selectedSeat = booking.ancillary.seatNumber,
                    boardingPassData = generatePassData(booking)
                )
            }
        }
    }

    fun updatePassportConsent(confirmed: Boolean) {
        _uiState.value = _uiState.value.copy(passportConfirmed = confirmed)
    }

    fun completeCheckIn(pnr: String) {
        viewModelScope.launch {
            bookingRepository.checkInBooking(pnr)
            val updatedBooking = bookingRepository.getBookingByPnr(pnr)
            _uiState.value = _uiState.value.copy(
                isCheckInDone = true,
                booking = updatedBooking,
                boardingPassData = updatedBooking?.let { generatePassData(it) }
            )
        }
    }

    private fun generatePassData(booking: Booking): BoardingPassData {
        val passenger = booking.passengers.firstOrNull()
        val flight = booking.outboundFlight

        return BoardingPassData(
            pnr = booking.pnr,
            passengerName = "${passenger?.firstName?.uppercase()} / ${passenger?.lastName?.uppercase()}",
            flightNumber = flight.flightNumber,
            originCode = flight.origin.code,
            originCity = flight.origin.city,
            destCode = flight.destination.code,
            destCity = flight.destination.city,
            departureDate = flight.departureDate,
            departureTime = flight.departureTime,
            boardingTime = "10:25",
            gate = flight.gate,
            seat = booking.ancillary.seatNumber,
            boardingGroup = "GROUP 1",
            cabinClass = booking.cabinClass,
            loungeAccess = true,
            isDemo = true
        )
    }
}
