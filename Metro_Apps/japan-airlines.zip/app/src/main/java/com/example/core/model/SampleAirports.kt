package com.example.core.model

// Additional helper list of standard JAL airports
object SampleAirports {
    val HND = Airport("HND", "Tokyo Haneda Airport", "Tokyo", "Japan", "Terminal 3")
    val NRT = Airport("NRT", "Tokyo Narita Airport", "Tokyo", "Japan", "Terminal 2")
    val KIX = Airport("KIX", "Kansai International Airport", "Osaka", "Japan", "Terminal 1")
    val ITM = Airport("ITM", "Osaka Itami Airport", "Osaka", "Japan", "Main Terminal")
    val CTS = Airport("CTS", "New Chitose Airport", "Sapporo", "Japan", "Domestic Terminal")
    val FUK = Airport("FUK", "Fukuoka Airport", "Fukuoka", "Japan", "Domestic Terminal")
    val OKA = Airport("OKA", "Naha Airport", "Okinawa", "Japan", "Main Terminal")
    val JFK = Airport("JFK", "John F. Kennedy Intl", "New York", "United States", "Terminal 8")
    val LHR = Airport("LHR", "London Heathrow Airport", "London", "United Kingdom", "Terminal 3")
    val CDG = Airport("CDG", "Paris Charles de Gaulle", "Paris", "France", "Terminal 2E")
    val SFO = Airport("SFO", "San Francisco Intl", "San Francisco", "United States", "International Terminal")
    val HNL = Airport("HNL", "Daniel K. Inouye Intl", "Honolulu", "United States", "Terminal 2")
    val SIN = Airport("SIN", "Singapore Changi Airport", "Singapore", "Singapore", "Terminal 1")
    val BKK = Airport("BKK", "Suvarnabhumi Airport", "Bangkok", "Thailand", "Main Terminal")

    val allAirports = listOf(HND, NRT, KIX, ITM, CTS, FUK, OKA, JFK, LHR, CDG, SFO, HNL, SIN, BKK)
}
