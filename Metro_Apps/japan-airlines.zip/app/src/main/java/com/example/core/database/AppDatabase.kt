package com.example.core.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey val pnr: String,
    val passengerJson: String,
    val outboundFlightJson: String,
    val returnFlightJson: String?,
    val cabinClass: String,
    val fareFamilyName: String,
    val seatNumber: String,
    val mealPreference: String,
    val totalPriceJpy: Int,
    val status: String,
    val bookedDate: String
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val timestamp: String,
    val category: String,
    val relatedPnr: String?,
    val isRead: Boolean
)

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY bookedDate DESC")
    fun getAllBookings(): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE pnr = :pnr LIMIT 1")
    suspend fun getBookingByPnr(pnr: String): BookingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity)

    @Query("UPDATE bookings SET status = :status WHERE pnr = :pnr")
    suspend fun updateBookingStatus(pnr: String, status: String)

    @Query("UPDATE bookings SET seatNumber = :seat WHERE pnr = :pnr")
    suspend fun updateBookingSeat(pnr: String, seat: String)

    @Query("DELETE FROM bookings WHERE pnr = :pnr")
    suspend fun deleteBooking(pnr: String)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)
}

@Database(entities = [BookingEntity::class, NotificationEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun bookingDao(): BookingDao
    abstract fun notificationDao(): NotificationDao
}
