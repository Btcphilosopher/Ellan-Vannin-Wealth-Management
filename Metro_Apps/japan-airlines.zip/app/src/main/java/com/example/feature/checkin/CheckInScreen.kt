package com.example.feature.checkin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.component.JalPrimaryButton
import com.example.core.designsystem.theme.*

@Composable
fun CheckInScreen(
    pnr: String,
    viewModel: CheckInViewModel,
    onBackClick: () -> Unit,
    onViewPass: (pnr: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(pnr) {
        viewModel.loadCheckInForPnr(pnr)
    }

    val booking = uiState.booking

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory)
    ) {
        // Header
        Surface(
            color = JalCrimson,
            contentColor = PureWhite,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("ONLINE CHECK-IN", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = PureWhite)
                    Text("PNR: $pnr", style = MaterialTheme.typography.bodyMedium, color = PureWhite.copy(alpha = 0.85f))
                }
            }
        }

        if (booking == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = JalCrimson)
            }
        } else if (uiState.isCheckInDone) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = JalSuccessGreen, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text("CHECK-IN COMPLETE!", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                Text("Boarding pass issued for seat ${booking.ancillary.seatNumber}", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)

                Spacer(modifier = Modifier.height(24.dp))

                JalPrimaryButton(
                    text = "OPEN BOARDING PASS",
                    onClick = { onViewPass(pnr) },
                    testTag = "open_boarding_pass_after_checkin"
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("FLIGHT CHECK-IN CONFIRMATION", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = JalMediumGrey)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("${booking.outboundFlight.operatingAirline} • ${booking.outboundFlight.flightNumber}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = JalCharcoal)
                            Text("Route: ${booking.outboundFlight.origin.code} → ${booking.outboundFlight.destination.code}", style = MaterialTheme.typography.bodyMedium, color = JalCrimson, fontWeight = FontWeight.Bold)
                            Text("Departure: ${booking.outboundFlight.departureTime} • Terminal ${booking.outboundFlight.terminal}", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                        }
                    }
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("TRAVEL DOCUMENTATION DECLARATION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                            Spacer(modifier = Modifier.height(8.dp))

                            booking.passengers.forEach { p ->
                                Text("Passenger: ${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                                Text("Passport: ${p.passportNumber} (Verified)", style = MaterialTheme.typography.bodyMedium, color = JalSuccessGreen)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = uiState.passportConfirmed,
                                    onCheckedChange = { viewModel.updatePassportConsent(it) },
                                    colors = CheckboxDefaults.colors(checkedColor = JalCrimson)
                                )
                                Text("I declare that passport and visa details are valid for travel.", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }

                item {
                    JalPrimaryButton(
                        text = "CONFIRM & ISSUE BOARDING PASS",
                        onClick = { viewModel.completeCheckIn(pnr) },
                        enabled = uiState.passportConfirmed,
                        testTag = "confirm_checkin_button"
                    )
                }
            }
        }
    }
}
