package com.example.core.model

import java.util.UUID

enum class TripType {
    ROUND_TRIP, ONE_WAY, MULTI_CITY
}

enum class CabinClass(val displayName: String, val code: String) {
    ECONOMY("Economy", "Y"),
    PREMIUM_ECONOMY("Premium Economy", "W"),
    BUSINESS("Business Class", "J"),
    FIRST("First Class", "F")
}

enum class FlightStatusType(val label: String) {
    SCHEDULED("Scheduled"),
    BOARDING("Boarding"),
    DEPARTED("Departed"),
    ARRIVED("Arrived"),
    DELAYED("Delayed"),
    CANCELLED("Cancelled")
}

data class Airport(
    val code: String, // e.g., HND
    val name: String, // e.g., Tokyo Haneda Airport
    val city: String, // e.g., Tokyo
    val country: String, // e.g., Japan
    val terminal: String = "Terminal 3"
)

data class FareFamily(
    val name: String, // e.g., Special Saver, Standard, Flex
    val cabinClass: CabinClass,
    val priceJpy: Int,
    val checkedBagsAllowed: Int,
    val isChangeable: Boolean,
    val isRefundable: Boolean,
    val seatSelectionIncluded: Boolean,
    val loungeAccessIncluded: Boolean
)

data class FlightSegment(
    val flightNumber: String, // e.g., JL005
    val operatingAirline: String = "Japan Airlines",
    val origin: Airport,
    val destination: Airport,
    val departureTime: String, // HH:mm
    val arrivalTime: String, // HH:mm
    val departureDate: String, // YYYY-MM-DD
    val arrivalDate: String,
    val durationMinutes: Int,
    val aircraftType: String, // e.g. Airbus A350-1000
    val stopsCount: Int = 0,
    val connectionAirport: Airport? = null,
    val status: FlightStatusType = FlightStatusType.SCHEDULED,
    val gate: String = "112",
    val terminal: String = "3",
    val baggageClaimBelt: String = "B6",
    val fareFamilies: List<FareFamily>
)

data class Passenger(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Mr",
    val firstName: String = "",
    val lastName: String = "",
    val passportNumber: String = "",
    val nationality: String = "Japan",
    val isChild: Boolean = false,
    val mealPreference: String = "Standard Japanese Menu",
    val specialAssistance: String = "None",
    val jmbNumber: String = ""
)

data class AncillarySelection(
    val extraBaggageCount: Int = 0, // Bags
    val selectedMeal: String = "RED U-35 Japanese Gourmet In-Flight",
    val loungePassCount: Int = 0,
    val priorityBoarding: Boolean = false,
    val seatNumber: String = "12A"
)

data class Booking(
    val pnr: String, // 6-char booking reference e.g., JAL88K
    val status: String = "CONFIRMED", // CONFIRMED, CHECKED_IN, CANCELLED
    val passengers: List<Passenger>,
    val outboundFlight: FlightSegment,
    val returnFlight: FlightSegment? = null,
    val cabinClass: CabinClass,
    val fareFamilyName: String,
    val ancillary: AncillarySelection,
    val totalPriceJpy: Int,
    val currency: String = "JPY",
    val bookedDate: String = "2026-10-25"
)

data class BoardingPassData(
    val pnr: String,
    val passengerName: String,
    val flightNumber: String,
    val originCode: String,
    val originCity: String,
    val destCode: String,
    val destCity: String,
    val departureDate: String,
    val departureTime: String,
    val boardingTime: String,
    val gate: String,
    val seat: String,
    val boardingGroup: String, // Group 1, Group 2, etc.
    val cabinClass: CabinClass,
    val loungeAccess: Boolean,
    val isDemo: Boolean = true
)

data class LoyaltyAccount(
    val jmbNumber: String = "7829-1092-348",
    val name: String = "TARO YAMADA",
    val tier: String = "JMB DIAMOND", // JMB Diamond, JGC Premier, Sapphire, Crystal, Member
    val milesBalance: Int = 128400,
    val flyOnPoints: Int = 84200,
    val flyOnNextTier: Int = 100000,
    val expiringMiles: Int = 12000,
    val expiryDate: String = "2027-03-31"
)

data class LoyaltyTransaction(
    val date: String,
    val description: String,
    val milesEarned: Int,
    val flyOnEarned: Int
)

data class NotificationMessage(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val body: String,
    val timestamp: String,
    val category: String, // CheckIn, FlightAlert, GateChange, Loyalty
    val relatedPnr: String? = null,
    val isRead: Boolean = false
)
