package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.core.data.AppContainer
import com.example.core.designsystem.theme.JalTheme
import com.example.core.navigation.JalAppMain

class MainActivity : ComponentActivity() {

    private lateinit var appContainer: AppContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        appContainer = AppContainer(applicationContext)

        setContent {
            JalTheme {
                JalAppMain(appContainer = appContainer)
            }
        }
    }
}
