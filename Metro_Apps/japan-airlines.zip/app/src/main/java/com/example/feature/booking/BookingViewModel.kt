package com.example.feature.booking

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.AncillarySelection
import com.example.core.model.Booking
import com.example.core.model.CabinClass
import com.example.core.model.FlightSegment
import com.example.core.model.Passenger
import com.example.core.repository.BookingRepository
import com.example.core.repository.FlightRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class BookingFlowUiState(
    val currentStep: Int = 1, // 1: Flight, 2: Passenger, 3: Seat, 4: Ancillary, 5: Payment/Confirmation
    val selectedFlight: FlightSegment? = null,
    val selectedCabin: CabinClass = CabinClass.BUSINESS,
    val passenger: Passenger = Passenger(title = "Mr", firstName = "Taro", lastName = "Yamada", passportNumber = "TR891024", jmbNumber = "7829-1092-348"),
    val ancillary: AncillarySelection = AncillarySelection(seatNumber = "12A", selectedMeal = "RED U-35 Japanese Kaiseki Menu"),
    val createdBooking: Booking? = null,
    val isPaymentProcessing: Boolean = false,
    val isBookingCompleted: Boolean = false,
    val validationError: String? = null
)

class BookingViewModel(
    private val flightRepository: FlightRepository,
    private val bookingRepository: BookingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(BookingFlowUiState())
    val uiState: StateFlow<BookingFlowUiState> = _uiState.asStateFlow()

    fun initBookingFlow(flightNumber: String, cabinName: String) {
        val cabin = try { CabinClass.valueOf(cabinName) } catch (e: Exception) { CabinClass.BUSINESS }
        viewModelScope.launch {
            val statusFlights = flightRepository.getFlightStatus(flightNumber)
            val flight = statusFlights.firstOrNull() ?: flightRepository.searchFlights("HND", "JFK", "2026-10-28", cabin, 1).first()
            _uiState.value = _uiState.value.copy(
                selectedFlight = flight,
                selectedCabin = cabin,
                currentStep = 1
            )
        }
    }

    fun updatePassengerInfo(title: String, firstName: String, lastName: String, passport: String, jmb: String, meal: String) {
        val updatedPass = _uiState.value.passenger.copy(
            title = title,
            firstName = firstName,
            lastName = lastName,
            passportNumber = passport,
            jmbNumber = jmb,
            mealPreference = meal
        )
        _uiState.value = _uiState.value.copy(passenger = updatedPass, validationError = null)
    }

    fun setSelectedSeat(seatNumber: String) {
        val updatedAncillary = _uiState.value.ancillary.copy(seatNumber = seatNumber)
        _uiState.value = _uiState.value.copy(ancillary = updatedAncillary)
    }

    fun updateAncillary(extraBaggage: Int, meal: String, loungePass: Boolean) {
        val updatedAncillary = _uiState.value.ancillary.copy(
            extraBaggageCount = extraBaggage,
            selectedMeal = meal,
            loungePassCount = if (loungePass) 1 else 0
        )
        _uiState.value = _uiState.value.copy(ancillary = updatedAncillary)
    }

    fun goToNextStep() {
        val currentState = _uiState.value
        if (currentState.currentStep == 2) {
            // Validate Passenger Form
            if (currentState.passenger.firstName.isBlank() || currentState.passenger.lastName.isBlank()) {
                _uiState.value = currentState.copy(validationError = "Please enter valid passenger first and last name")
                return
            }
        }
        _uiState.value = currentState.copy(currentStep = currentState.currentStep + 1, validationError = null)
    }

    fun goToPreviousStep() {
        if (_uiState.value.currentStep > 1) {
            _uiState.value = _uiState.value.copy(currentStep = _uiState.value.currentStep - 1)
        }
    }

    fun processPaymentAndConfirm() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isPaymentProcessing = true)
            val flight = _uiState.value.selectedFlight ?: return@launch
            val newPnr = bookingRepository.generateUniquePnr()

            val farePrice = flight.fareFamilies.find { it.cabinClass == _uiState.value.selectedCabin }?.priceJpy ?: 580000
            val ancillaryPrice = (_uiState.value.ancillary.extraBaggageCount * 15000) + (_uiState.value.ancillary.loungePassCount * 12000)
            val totalPrice = farePrice + ancillaryPrice

            val newBooking = Booking(
                pnr = newPnr,
                status = "CONFIRMED",
                passengers = listOf(_uiState.value.passenger),
                outboundFlight = flight,
                cabinClass = _uiState.value.selectedCabin,
                fareFamilyName = "${flight.operatingAirline} ${_uiState.value.selectedCabin.displayName}",
                ancillary = _uiState.value.ancillary,
                totalPriceJpy = totalPrice,
                bookedDate = "2026-10-25"
            )

            bookingRepository.createBooking(newBooking)

            _uiState.value = _uiState.value.copy(
                isPaymentProcessing = false,
                isBookingCompleted = true,
                createdBooking = newBooking,
                currentStep = 5
            )
        }
    }
}
