package com.example.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.data.UserPreferencesRepository
import com.example.core.model.Booking
import com.example.core.model.CabinClass
import com.example.core.model.LoyaltyAccount
import com.example.core.model.SampleAirports
import com.example.core.model.TripType
import com.example.core.repository.BookingRepository
import com.example.core.repository.LoyaltyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val tripType: TripType = TripType.ROUND_TRIP,
    val originCode: String = "HND",
    val destinationCode: String = "JFK",
    val departureDate: String = "2026-10-28",
    val returnDate: String = "2026-11-05",
    val passengerCount: Int = 1,
    val selectedCabin: CabinClass = CabinClass.BUSINESS,
    val flexibleDates: Boolean = true,
    val upcomingBooking: Booking? = null,
    val loyaltyAccount: LoyaltyAccount = LoyaltyAccount(),
    val language: String = "EN"
)

class HomeViewModel(
    private val bookingRepository: BookingRepository,
    private val loyaltyRepository: LoyaltyRepository,
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    val languageFlow: StateFlow<String> = userPreferencesRepository.languageFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "EN"
    )

    init {
        viewModelScope.launch {
            bookingRepository.seedSampleBookingIfEmpty()
            bookingRepository.allBookings.collect { bookings ->
                _uiState.value = _uiState.value.copy(
                    upcomingBooking = bookings.firstOrNull { it.status != "CANCELLED" }
                )
            }
        }
        _uiState.value = _uiState.value.copy(
            loyaltyAccount = loyaltyRepository.getLoyaltyAccount()
        )
    }

    fun setTripType(type: TripType) { _uiState.value = _uiState.value.copy(tripType = type) }
    fun setOrigin(code: String) { _uiState.value = _uiState.value.copy(originCode = code) }
    fun setDestination(code: String) { _uiState.value = _uiState.value.copy(destinationCode = code) }
    fun setDepartureDate(date: String) { _uiState.value = _uiState.value.copy(departureDate = date) }
    fun setPassengerCount(count: Int) { if (count in 1..9) _uiState.value = _uiState.value.copy(passengerCount = count) }
    fun setCabinClass(cabin: CabinClass) { _uiState.value = _uiState.value.copy(selectedCabin = cabin) }
    fun toggleFlexibleDates(flexible: Boolean) { _uiState.value = _uiState.value.copy(flexibleDates = flexible) }
    fun swapAirports() {
        val orig = _uiState.value.originCode
        val dest = _uiState.value.destinationCode
        _uiState.value = _uiState.value.copy(originCode = dest, destinationCode = orig)
    }

    fun toggleLanguage() {
        viewModelScope.launch {
            val next = if (_uiState.value.language == "EN") "JA" else "EN"
            userPreferencesRepository.setLanguage(next)
            _uiState.value = _uiState.value.copy(language = next)
        }
    }
}
