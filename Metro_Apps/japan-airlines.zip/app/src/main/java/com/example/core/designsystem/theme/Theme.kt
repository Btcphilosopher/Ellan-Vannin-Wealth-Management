package com.example.core.designsystem.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = JalCrimson,
    onPrimary = PureWhite,
    primaryContainer = JalCrimsonLight,
    onPrimaryContainer = JalDarkCrimson,
    secondary = JalCharcoal,
    onSecondary = PureWhite,
    secondaryContainer = JalLightGrey,
    onSecondaryContainer = JalCharcoal,
    tertiary = JmbGold,
    onTertiary = PureWhite,
    background = PureWhite,
    onBackground = JalCharcoal,
    surface = PureWhite,
    onSurface = JalCharcoal,
    surfaceVariant = WarmIvory,
    onSurfaceVariant = JalDarkGrey,
    outline = JalBorderGrey,
    error = JalErrorRed,
    onError = PureWhite
)

private val DarkColorScheme = darkColorScheme(
    primary = JalCrimson,
    onPrimary = PureWhite,
    primaryContainer = JalDarkCrimson,
    onPrimaryContainer = JalCrimsonLight,
    secondary = PureWhite,
    onSecondary = JalCharcoal,
    secondaryContainer = JalDarkGrey,
    onSecondaryContainer = PureWhite,
    tertiary = JmbGold,
    onTertiary = PureWhite,
    background = JalCharcoal,
    onBackground = PureWhite,
    surface = JalDarkGrey,
    onSurface = PureWhite,
    surfaceVariant = JalCharcoal,
    onSurfaceVariant = JalLightGrey,
    outline = JalMediumGrey,
    error = JalErrorRed,
    onError = PureWhite
)

@Composable
fun JalTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
