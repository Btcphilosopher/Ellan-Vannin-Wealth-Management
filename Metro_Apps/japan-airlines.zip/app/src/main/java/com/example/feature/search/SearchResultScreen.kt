package com.example.feature.search

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.component.JalPrimaryButton
import com.example.core.designsystem.theme.*
import com.example.core.model.FlightSegment

@Composable
fun SearchResultScreen(
    viewModel: SearchViewModel,
    onFlightSelected: (flightNum: String, cabin: String) -> Unit,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory)
    ) {
        // Header Bar
        Surface(
            color = JalCrimson,
            contentColor = PureWhite,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "${uiState.origin} → ${uiState.destination}",
                        style = MaterialTheme.typography.titleLarge,
                        color = PureWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${uiState.departureDate} • ${uiState.passengerCount} Passenger • ${uiState.selectedCabin.displayName}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = PureWhite.copy(alpha = 0.85f)
                    )
                }
            }
        }

        // Sort Options
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PureWhite)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Sort:", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
            val sortOptions = listOf("RECOMMENDED" to "Recommended", "LOWEST_PRICE" to "Price", "DEPARTURE_TIME" to "Departure")
            sortOptions.forEach { (key, label) ->
                val selected = uiState.sortBy == key
                FilterChip(
                    selected = selected,
                    onClick = { viewModel.setSortBy(key) },
                    label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = JalCrimson,
                        selectedLabelColor = PureWhite,
                        containerColor = JalLightGrey,
                        labelColor = JalCharcoal
                    )
                )
            }
        }

        HorizontalDivider(color = JalBorderGrey)

        if (uiState.isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = JalCrimson)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Searching JAL Schedules...", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                }
            }
        } else if (uiState.filteredFlights.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No flights found for this route.", style = MaterialTheme.typography.titleMedium, color = JalMediumGrey)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(uiState.filteredFlights) { flight ->
                    FlightSearchResultCard(
                        flight = flight,
                        selectedCabinName = uiState.selectedCabin.displayName,
                        onSelect = { fareFamilyName ->
                            onFlightSelected(flight.flightNumber, uiState.selectedCabin.name)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun FlightSearchResultCard(
    flight: FlightSegment,
    selectedCabinName: String,
    onSelect: (fareFamilyName: String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Flight Airline & Aircraft
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(JalCrimson),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("JL", color = PureWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${flight.operatingAirline} • ${flight.flightNumber}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = JalCharcoal
                    )
                }
                Surface(
                    color = JalLightGrey,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = flight.aircraftType,
                        style = MaterialTheme.typography.labelMedium,
                        color = JalMediumGrey,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Flight Schedule Times & Route
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(flight.departureTime, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Text("${flight.origin.city} (${flight.origin.code})", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                    Text("Terminal ${flight.terminal}", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${flight.durationMinutes / 60}h ${flight.durationMinutes % 60}m", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        HorizontalDivider(modifier = Modifier.width(30.dp), color = JalMediumGrey)
                        Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = JalCrimson, modifier = Modifier.size(18.dp))
                        HorizontalDivider(modifier = Modifier.width(30.dp), color = JalMediumGrey)
                    }
                    Text(
                        text = if (flight.stopsCount == 0) "Direct Flight" else "1 Stop (${flight.connectionAirport?.code})",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (flight.stopsCount == 0) JalSuccessGreen else JalWarningAmber,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(flight.arrivalTime, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                    Text("${flight.destination.city} (${flight.destination.code})", style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                    Text("JAL Sky Suite", style = MaterialTheme.typography.labelMedium, color = JmbGold, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = JalBorderGrey)
            Spacer(modifier = Modifier.height(12.dp))

            // Fare Family Cards Matrix (Economy / Business / First)
            Text(
                text = "CABIN FARE SELECTION",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = JalMediumGrey
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                flight.fareFamilies.forEach { fare ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.dp, JalBorderGrey, RoundedCornerShape(10.dp))
                            .background(WarmIvory)
                            .clickable { onSelect(fare.name) }
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = fare.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = JalCharcoal
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = if (fare.cabinClass.name == "BUSINESS") JmbGold else JalCrimson,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = fare.cabinClass.displayName,
                                        color = PureWhite,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Checked Bags: ${fare.checkedBagsAllowed}x • ${if (fare.isChangeable) "Flexible Changes" else "Non-changeable"}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = JalMediumGrey
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "¥${String.format("%,d", fare.priceJpy)}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = JalCrimson
                            )
                            Button(
                                onClick = { onSelect(fare.name) },
                                colors = ButtonDefaults.buttonColors(containerColor = JalCrimson),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("Select", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
