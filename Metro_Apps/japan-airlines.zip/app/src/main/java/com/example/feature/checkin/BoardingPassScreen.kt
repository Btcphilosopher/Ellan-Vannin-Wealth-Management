package com.example.feature.checkin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.component.JalPrimaryButton
import com.example.core.designsystem.theme.*

@Composable
fun BoardingPassScreen(
    pnr: String,
    viewModel: CheckInViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(pnr) {
        viewModel.loadCheckInForPnr(pnr)
    }

    val pass = uiState.boardingPassData

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JalCharcoal)
    ) {
        // Top Bar
        Surface(
            color = JalCharcoal,
            contentColor = PureWhite
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("DIGITAL BOARDING PASS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = PureWhite)
                    Text("JAPAN AIRLINES • PNR $pnr", style = MaterialTheme.typography.bodyMedium, color = PureWhite.copy(alpha = 0.8f))
                }
            }
        }

        if (pass == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = PureWhite)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    // Boarding Pass Ticket Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(20.dp),
                        elevation = CardDefaults.cardElevation(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("digital_boarding_pass_card")
                    ) {
                        Column {
                            // Red JAL Header
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(JalCrimson)
                                    .padding(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(PureWhite),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("JAL", color = JalCrimson, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("JAPAN AIRLINES", color = PureWhite, fontWeight = FontWeight.Bold)
                                    }

                                    Surface(color = JmbGold, shape = RoundedCornerShape(4.dp)) {
                                        Text("SAKURA LOUNGE", color = PureWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                            }

                            // Route & Flight
                            Column(modifier = Modifier.padding(20.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(pass.originCode, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold, color = JalCharcoal)
                                        Text(pass.originCity, style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                                    }

                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(pass.flightNumber, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCrimson)
                                        Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = JalCrimson, modifier = Modifier.size(28.dp))
                                        Text("28 OCT 2026", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(pass.destCode, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold, color = JalCharcoal)
                                        Text(pass.destCity, style = MaterialTheme.typography.bodyMedium, color = JalMediumGrey)
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))
                                HorizontalDivider(color = JalBorderGrey)
                                Spacer(modifier = Modifier.height(16.dp))

                                // Passenger & Gate & Seat Matrix
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("PASSENGER", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                                        Text(pass.passengerName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("BOARDING GROUP", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                                        Text(pass.boardingGroup, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JalCrimson)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text("GATE", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                                        Text(pass.gate, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCharcoal)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("BOARDING TIME", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                                        Text(pass.boardingTime, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JalCrimson)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("SEAT", style = MaterialTheme.typography.labelMedium, color = JalMediumGrey)
                                        Text(pass.seat, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = JmbGold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                // QR Code Scannable Simulation Box
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(WarmIvory)
                                        .border(1.dp, JalBorderGrey, RoundedCornerShape(12.dp))
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.QrCode2, contentDescription = "Boarding Pass QR", modifier = Modifier.size(140.dp), tint = JalCharcoal)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("DEMO BOARDING PASS • NOT FOR OPERATIONAL USE", style = MaterialTheme.typography.labelMedium, color = JalErrorRed, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {},
                        colors = ButtonDefaults.buttonColors(containerColor = PureWhite, contentColor = JalCharcoal),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Smartphone, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SAVED TO DEVICE (OFFLINE READY)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
