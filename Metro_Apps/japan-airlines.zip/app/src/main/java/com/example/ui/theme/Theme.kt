package com.example.ui.theme

import androidx.compose.runtime.Composable
import com.example.core.designsystem.theme.JalTheme

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    JalTheme(darkTheme = darkTheme, content = content)
}
