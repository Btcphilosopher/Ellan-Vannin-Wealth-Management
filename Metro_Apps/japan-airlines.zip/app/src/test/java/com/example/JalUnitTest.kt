package com.example

import com.example.core.model.CabinClass
import com.example.core.repository.AirportRepository
import com.example.core.repository.FlightRepository
import com.example.core.repository.LoyaltyRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class JalUnitTest {

    private val flightRepository = FlightRepository()
    private val loyaltyRepository = LoyaltyRepository()
    private val airportRepository = AirportRepository()

    @Test
    fun testFlightSearch_returnsSchedules() = runBlocking {
        val flights = flightRepository.searchFlights("HND", "JFK", "2026-10-28", CabinClass.BUSINESS, 1)
        assertTrue(flights.isNotEmpty())
        assertEquals("HND", flights.first().origin.code)
        assertEquals("JFK", flights.first().destination.code)
    }

    @Test
    fun testLoyaltyAccount_tierDetails() {
        val account = loyaltyRepository.getLoyaltyAccount()
        assertEquals("JMB DIAMOND", account.tier)
        assertEquals(128400, account.milesBalance)
        assertEquals(84200, account.flyOnPoints)
    }

    @Test
    fun testAwardCalculation_longHaulVsDomestic() {
        val intlAward = loyaltyRepository.calculateAwardMilesRequired("HND", "JFK")
        assertEquals(50000, intlAward.businessMiles)

        val domAward = loyaltyRepository.calculateAwardMilesRequired("HND", "CTS")
        assertEquals(10000, domAward.businessMiles)
    }

    @Test
    fun testAirportGuide_hanedaSakuraLounge() {
        val guide = airportRepository.getAirportGuide("HND")
        assertEquals("HND", guide.airport.code)
        assertTrue(guide.sakuraLounge.name.contains("Sakura Lounge"))
        assertTrue(guide.timeline.size >= 5)
    }
}
