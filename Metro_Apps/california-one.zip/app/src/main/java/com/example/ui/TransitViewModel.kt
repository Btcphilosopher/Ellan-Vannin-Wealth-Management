package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.routing.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

enum class TransitScreen {
    HOME,
    TRIP_PLANNER,
    LIVE_MAP,
    MY_WALLET,
    STATION_DETAIL,
    ALERTS_BOARD,
    ACTIVE_JOURNEY,
    SETTINGS_DIAGNOSTICS
}

class TransitViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = TransitRepository(database)

    // Screen navigation state
    private val _currentScreen = MutableStateFlow(TransitScreen.HOME)
    val currentScreen: StateFlow<TransitScreen> = _currentScreen.asStateFlow()

    private val _backstack = MutableStateFlow<List<TransitScreen>>(emptyList())
    val backstack: StateFlow<List<TransitScreen>> = _backstack.asStateFlow()

    // Form search fields
    var searchFromText = MutableStateFlow("LA Union Station")
    var searchToText = MutableStateFlow("San Jose Diridon")
    var selectedOptimization = MutableStateFlow("Fastest") // "Fastest", "Fewest Transfers", "Lowest Fare", "Least Walking", "Elevator Required"
    var leaveNowOrArriveBy = MutableStateFlow("LEAVE NOW") // "LEAVE NOW", "ARRIVE BY"
    var accessibilityRequired = MutableStateFlow(false)
    var bringBike = MutableStateFlow(false)

    // Searched Journeys state
    private val _plannedJourneys = MutableStateFlow<List<Journey>>(emptyList())
    val plannedJourneys: StateFlow<List<Journey>> = _plannedJourneys.asStateFlow()

    private val _selectedJourney = MutableStateFlow<Journey?>(null)
    val selectedJourney: StateFlow<Journey?> = _selectedJourney.asStateFlow()

    // Station focus
    private val _focusedStation = MutableStateFlow<Stop>(MockTransitData.stops.first { it.id == "LA_UNION" })
    val focusedStation: StateFlow<Stop> = _focusedStation.asStateFlow()

    // Live map tracking simulation
    private val _simulatedVehicles = MutableStateFlow<List<VehicleSimulation>>(MockTransitData.vehicles)
    val simulatedVehicles: StateFlow<List<VehicleSimulation>> = _simulatedVehicles.asStateFlow()

    private val _selectedVehicle = MutableStateFlow<VehicleSimulation?>(null)
    val selectedVehicle: StateFlow<VehicleSimulation?> = _selectedVehicle.asStateFlow()

    // Active Journey tracking (Onboard mode)
    private val _onboardLeg = MutableStateFlow<JourneyLeg?>(null)
    val onboardLeg: StateFlow<JourneyLeg?> = _onboardLeg.asStateFlow()

    private val _arrivalReminderSet = MutableStateFlow(false)
    val arrivalReminderSet: StateFlow<Boolean> = _arrivalReminderSet.asStateFlow()

    // Toast banner notifications
    private val _bannerNotification = MutableStateFlow<String?>(null)
    val bannerNotification: StateFlow<String?> = _bannerNotification.asStateFlow()

    // Boarding countdown simulation (Next trip card)
    private val _boardingMinutesRemaining = MutableStateFlow(8)
    val boardingMinutesRemaining: StateFlow<Int> = _boardingMinutesRemaining.asStateFlow()

    // Wallet transaction state
    private val _walletBalance = MutableStateFlow(24.50)
    val walletBalance: StateFlow<Double> = _walletBalance.asStateFlow()

    // Collect Room Live flows
    val savedPlaces: StateFlow<List<SavedPlace>> = repository.allSavedPlaces
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedCommutes: StateFlow<List<SavedCommute>> = repository.allSavedCommutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val travelHistory: StateFlow<List<TravelHistory>> = repository.allTravelHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val digitalTickets: StateFlow<List<Ticket>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            // Seed database
            repository.prepopulateDatabaseIfEmpty()
            
            // Periodically tick vehicle positions on the map to show real simulation activity
            launch {
                while (true) {
                    delay(4000) // update every 4 seconds
                    updateSimulatedVehicles()
                }
            }

            // Boarding countdown ticking
            launch {
                while (true) {
                    delay(60000) // minute countdown
                    if (_boardingMinutesRemaining.value > 1) {
                        _boardingMinutesRemaining.value -= 1
                    } else {
                        _boardingMinutesRemaining.value = 15 // reset to simulate next train loop
                    }
                }
            }
        }
    }

    // Navigation helper
    fun navigateTo(screen: TransitScreen) {
        val current = _currentScreen.value
        if (current != screen) {
            _backstack.value = _backstack.value + current
            _currentScreen.value = screen
        }
    }

    fun popScreen() {
        val stack = _backstack.value
        if (stack.isNotEmpty()) {
            _currentScreen.value = stack.last()
            _backstack.value = stack.dropLast(1)
        } else {
            _currentScreen.value = TransitScreen.HOME
        }
    }

    // Trigger local search & trip planning
    fun performSearch() {
        viewModelScope.launch {
            val results = RoutingEngine.planTrip(
                originQuery = searchFromText.value,
                destinationQuery = searchToText.value,
                optimization = selectedOptimization.value,
                accessibilityRequired = accessibilityRequired.value,
                bringBike = bringBike.value
            )
            _plannedJourneys.value = results
            if (results.isNotEmpty()) {
                _selectedJourney.value = results.first()
            }
            navigateTo(TransitScreen.TRIP_PLANNER)
        }
    }

    // Quick Actions
    fun handleQuickAction(action: String) {
        when (action) {
            "NEARBY" -> {
                // Focus on closest station (LA Union Station)
                setFocusedStation("LA_UNION")
                navigateTo(TransitScreen.STATION_DETAIL)
            }
            "DEPARTURES" -> {
                setFocusedStation("LA_UNION")
                navigateTo(TransitScreen.STATION_DETAIL)
            }
            "TICKETS" -> navigateTo(TransitScreen.MY_WALLET)
            "SERVICE ALERTS" -> navigateTo(TransitScreen.ALERTS_BOARD)
            "SAVED PLACES" -> {
                // Pre-populate search from a saved place
                viewModelScope.launch {
                    val places = savedPlaces.value
                    if (places.isNotEmpty()) {
                        searchFromText.value = "Home"
                        searchToText.value = "Work"
                        performSearch()
                    }
                }
            }
        }
    }

    fun setFocusedStation(stationId: String) {
        val stop = MockTransitData.stops.find { it.id == stationId }
        if (stop != null) {
            _focusedStation.value = stop
        }
    }

    // Active Onboard Mode
    fun startOnboardJourney(leg: JourneyLeg) {
        _onboardLeg.value = leg
        _arrivalReminderSet.value = false
        navigateTo(TransitScreen.ACTIVE_JOURNEY)
        showToast("Now On Board ${leg.routeName}!")
    }

    fun toggleArrivalReminder() {
        _arrivalReminderSet.value = !_arrivalReminderSet.value
        if (_arrivalReminderSet.value) {
            showToast("Arrival reminder set! We'll alert you 1 stop before ${onboardLeg.value?.toStop?.name}.")
        }
    }

    // Purchase tickets directly
    fun purchaseTicket(agency: String, origin: String, destination: String, fare: Double) {
        viewModelScope.launch {
            if (_walletBalance.value >= fare) {
                _walletBalance.value -= fare
                val newTicket = Ticket(
                    ticketId = "CA-ONE-${(1000..9999).random()}",
                    agencyName = agency,
                    origin = origin,
                    destination = destination,
                    departureTime = "10:42 AM",
                    fare = fare,
                    passengerName = "Jane Doe"
                )
                repository.insertTicket(newTicket)
                showToast("Ticket purchased successfully!")
                navigateTo(TransitScreen.MY_WALLET)
            } else {
                showToast("Insufficient balance! Add funds to your transit card.")
            }
        }
    }

    fun addWalletFunds(amount: Double) {
        _walletBalance.value += amount
        showToast("$$amount added to Transit Wallet")
    }

    // Complete a journey (Record in Travel History)
    fun completeOnboardJourney() {
        val currentLeg = _onboardLeg.value ?: return
        viewModelScope.launch {
            val history = TravelHistory(
                origin = currentLeg.fromStop.name,
                destination = currentLeg.toStop.name,
                miles = (currentLeg.durationMinutes * 0.65).let { Math.round(it * 10) / 10.0 },
                carbonSaved = (currentLeg.durationMinutes * 0.22).let { Math.round(it * 10) / 10.0 },
                agenciesUsed = currentLeg.agencyId ?: "Local Transit"
            )
            repository.insertTravelHistory(history)
            _onboardLeg.value = null
            showToast("Journey complete! CO2 Saved recorded in history.")
            navigateTo(TransitScreen.MY_WALLET)
        }
    }

    // Simulated GPS movements
    private fun updateSimulatedVehicles() {
        val updated = _simulatedVehicles.value.map { vehicle ->
            // Shift coordinates very slightly to simulate motion
            val speedDelta = 0.0003
            val dLat = (if ((0..1).random() == 0) speedDelta else -speedDelta)
            val dLng = (if ((0..1).random() == 0) speedDelta else -speedDelta)
            
            val newLat = (vehicle.latitude + dLat).coerceIn(32.0, 42.0)
            val newLng = (vehicle.longitude + dLng).coerceIn(-125.0, -114.0)

            vehicle.copy(
                latitude = newLat,
                longitude = newLng,
                minutesToArrival = if (vehicle.minutesToArrival > 1) vehicle.minutesToArrival - 1 else (2..20).random()
            )
        }
        _simulatedVehicles.value = updated

        // Keep selected vehicle in sync
        _selectedVehicle.value?.let { currentSel ->
            _selectedVehicle.value = updated.find { it.vehicleId == currentSel.vehicleId }
        }
    }

    fun selectVehicleOnMap(vehicle: VehicleSimulation?) {
        _selectedVehicle.value = vehicle
    }

    // Save a custom commute
    fun saveCommute(title: String, from: String, to: String, time: String, optimization: String) {
        viewModelScope.launch {
            repository.insertSavedCommute(
                SavedCommute(
                    title = title,
                    origin = from,
                    destination = to,
                    preferredDeparture = time,
                    preferredOptimization = optimization
                )
            )
            showToast("Commute saved to travel intelligence board!")
        }
    }

    fun deleteCommute(commute: SavedCommute) {
        viewModelScope.launch {
            repository.deleteSavedCommute(commute)
            showToast("Commute removed.")
        }
    }

    // Toggle saved places
    fun addSavedPlace(name: String, address: String, lat: Double, lng: Double, icon: String) {
        viewModelScope.launch {
            repository.insertSavedPlace(SavedPlace(name, address, lat, lng, icon))
            showToast("Location saved.")
        }
    }

    fun removeSavedPlace(place: SavedPlace) {
        viewModelScope.launch {
            repository.deleteSavedPlace(place)
            showToast("Saved place deleted.")
        }
    }

    private fun showToast(msg: String) {
        viewModelScope.launch {
            _bannerNotification.value = msg
            delay(3000)
            if (_bannerNotification.value == msg) {
                _bannerNotification.value = null
            }
        }
    }

    fun clearBanner() {
        _bannerNotification.value = null
    }
}
