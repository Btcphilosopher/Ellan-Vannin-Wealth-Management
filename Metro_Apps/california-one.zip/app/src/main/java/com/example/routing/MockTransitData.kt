package com.example.routing

object MockTransitData {

    val agencies = listOf(
        Agency("LA_METRO", "LA Metro", "Southern California", listOf("METRO", "BUS", "LIGHT_RAIL"), "🚇", "#0072CE"),
        Agency("METROLINK", "Metrolink", "Southern California", listOf("RAIL"), "🚆", "#00A3E0"),
        Agency("AMTRAK_CA", "Amtrak California", "Statewide", listOf("RAIL"), "🚄", "#002F6C"),
        Agency("BART", "BART", "Bay Area", listOf("METRO"), "🚇", "#0079C1"),
        Agency("CALTRAIN", "Caltrain", "Bay Area", listOf("RAIL"), "🚆", "#EB1C24"),
        Agency("SF_MUNI", "SF Muni", "Bay Area", listOf("LIGHT_RAIL", "BUS", "CABLE_CAR"), "🚋", "#F20505"),
        Agency("VTA", "VTA", "Bay Area", listOf("LIGHT_RAIL", "BUS"), "🚋", "#002F6C"),
        Agency("SD_MTS", "San Diego MTS", "San Diego", listOf("LIGHT_RAIL", "BUS"), "🚋", "#FFC72C"),
        Agency("NCTD", "NCTD Coaster", "San Diego", listOf("RAIL", "BUS"), "🚆", "#003B46"),
        Agency("SAC_RT", "Sacramento RT", "Sacramento", listOf("LIGHT_RAIL", "BUS"), "🚋", "#00539B"),
        Agency("SF_FERRIES", "San Francisco Bay Ferry", "Bay Area", listOf("FERRY"), "⛴", "#002F6C")
    )

    val stops = listOf(
        // Southern California
        Stop("SD_DEPOT", "San Diego Santa Fe Depot", 32.7165, -117.1702, "San Diego"),
        Stop("OCEANSIDE", "Oceanside Transit Center", 33.1950, -117.3789, "San Diego / Southern California"),
        Stop("FULLERTON", "Fullerton Transit Center", 33.8688, -117.9234, "Southern California"),
        Stop("LA_UNION", "Los Angeles Union Station", 34.0562, -118.2365, "Southern California"),
        Stop("LAX_AIRPORT", "LAX Tom Bradley Terminal", 33.9416, -118.4085, "Southern California"),
        Stop("DODGER_STADIUM", "Dodger Stadium", 34.0739, -118.2400, "Southern California"),
        Stop("HOLLYWOOD", "Hollywood / Highland", 34.1016, -118.3387, "Southern California"),
        Stop("LONG_BEACH", "Downtown Long Beach", 33.7681, -118.1955, "Southern California"),
        Stop("RIVERSIDE", "Riverside Downtown Station", 33.9754, -117.3682, "Southern California"),
        Stop("SAN_BERNARDINO", "San Bernardino Transit Center", 34.1025, -117.3005, "Southern California"),
        Stop("SANTA_BARBARA", "Santa Barbara Station", 34.4143, -119.6917, "Central Coast"),

        // Central Valley
        Stop("BAKERSFIELD", "Bakersfield Amtrak Station", 35.3733, -119.0181, "Central Valley"),
        Stop("FRESNO", "Fresno Santa Fe Depot", 36.7360, -119.7836, "Central Valley"),
        Stop("STOCKTON", "Stockton Downtown Station", 37.9577, -121.2908, "Central Valley"),

        // Bay Area
        Stop("SJ_DIRIDON", "San Jose Diridon Station", 37.3301, -121.9022, "Bay Area"),
        Stop("PALO_ALTO", "Palo Alto Caltrain Station", 37.4430, -122.1649, "Bay Area"),
        Stop("SF_4TH_KING", "San Francisco 4th & King", 37.7764, -122.3944, "Bay Area"),
        Stop("SF_CIVIC_CENTER", "SF Civic Center / UN Plaza", 37.7798, -122.4137, "Bay Area"),
        Stop("SF_FERRY_BLDG", "San Francisco Ferry Building", 37.7955, -122.3937, "Bay Area"),
        Stop("OAK_COLISEUM", "Oakland Coliseum Station", 37.7538, -122.1968, "Bay Area"),
        Stop("OAK_JACK_LONDON", "Oakland Jack London Square", 37.7937, -122.2715, "Bay Area"),
        Stop("BERKELEY", "Downtown Berkeley", 37.8701, -122.2681, "Bay Area"),

        // Sacramento / North
        Stop("SAC_VALLEY", "Sacramento Valley Station", 38.5841, -121.5007, "Sacramento"),
        Stop("DAVIS", "Davis Amtrak Station", 38.5442, -121.7374, "Sacramento / Northern California"),
        Stop("REDDING", "Redding Amtrak Station", 40.5815, -122.3888, "Northern California"),
        Stop("EUREKA", "Eureka Transit Center", 40.8021, -124.1637, "North Coast")
    )

    val routes = listOf(
        Route("SURFLINER", "AMTRAK_CA", "763", "Pacific Surfliner", "RAIL", "#002F6C"),
        Route("METROLINK_SB", "METROLINK", "SB_LINE", "San Bernardino Line", "RAIL", "#00A3E0"),
        Route("METROLINK_OC", "METROLINK", "OC_LINE", "Orange County Line", "RAIL", "#F26522"),
        Route("CALTRAIN_LTD", "CALTRAIN", "CAL_LTD", "Caltrain Limited", "RAIL", "#EB1C24"),
        Route("BART_YELLOW", "BART", "BART_YEL", "BART Yellow Line (Antioch - SFO)", "METRO", "#FDB913"),
        Route("BART_RED", "BART", "BART_RED", "BART Red Line (Richmond - Millbrae)", "METRO", "#ED1C24"),
        Route("LA_RED_LINE", "LA_METRO", "B_LINE", "Metro B Line (Red)", "METRO", "#DA291C"),
        Route("LA_BLUE_LINE", "LA_METRO", "A_LINE", "Metro A Line (Blue)", "LIGHT_RAIL", "#0072CE"),
        Route("SF_MUNI_M", "SF_MUNI", "M_LINE", "M Ocean View Light Rail", "LIGHT_RAIL", "#F20505"),
        Route("VTA_BLUE", "VTA", "VTA_BL", "VTA Blue Line (Alum Rock - Santa Teresa)", "LIGHT_RAIL", "#002F6C"),
        Route("SD_BLUE", "SD_MTS", "SD_BL", "UC San Diego Blue Line Trolley", "LIGHT_RAIL", "#FFC72C"),
        Route("COASTER", "NCTD", "COAST", "Coaster Commuter Rail", "RAIL", "#003B46"),
        Route("CAPITOL_CORR", "AMTRAK_CA", "CAP_CORR", "Capitol Corridor Rail", "RAIL", "#C49A45"),
        Route("SF_OAK_FERRY", "SF_FERRIES", "FERRY_OAK", "SF Ferry (SF - Oakland)", "FERRY", "#002F6C")
    )

    // Predefined connections in the graph: (fromStopId, toStopId, routeId, duration, cost, accessible, mode)
    val connections = listOf(
        // San Diego Coaster
        Connection("SD_DEPOT", "OCEANSIDE", "COASTER", 52, 6.50, true, "RAIL"),
        Connection("SD_DEPOT", "OCEANSIDE", "SURFLINER", 42, 19.00, true, "RAIL"),

        // Surfliner Corridor
        Connection("OCEANSIDE", "FULLERTON", "SURFLINER", 55, 14.00, true, "RAIL"),
        Connection("FULLERTON", "LA_UNION", "SURFLINER", 30, 9.50, true, "RAIL"),
        Connection("OCEANSIDE", "LA_UNION", "SURFLINER", 85, 23.00, true, "RAIL"),
        Connection("LA_UNION", "SANTA_BARBARA", "SURFLINER", 125, 29.00, true, "RAIL"),

        // Metrolink Connections
        Connection("LA_UNION", "FULLERTON", "METROLINK_OC", 35, 7.50, true, "RAIL"),
        Connection("LA_UNION", "RIVERSIDE", "METROLINK_OC", 70, 10.50, true, "RAIL"),
        Connection("LA_UNION", "SAN_BERNARDINO", "METROLINK_SB", 60, 9.75, true, "RAIL"),
        Connection("RIVERSIDE", "SAN_BERNARDINO", "METROLINK_SB", 15, 3.50, true, "RAIL"),

        // LA Metro local connections
        Connection("LA_UNION", "HOLLYWOOD", "LA_RED_LINE", 18, 1.75, true, "METRO"),
        Connection("LA_UNION", "LONG_BEACH", "LA_BLUE_LINE", 50, 1.75, true, "LIGHT_RAIL"),
        Connection("LA_UNION", "LAX_AIRPORT", null, 40, 9.75, true, "BUS"), // FlyAway Shuttle
        Connection("LA_UNION", "DODGER_STADIUM", null, 10, 0.00, true, "BUS"), // Dodger Stadium Express

        // San Jose to SF Corridor (Caltrain)
        Connection("SJ_DIRIDON", "PALO_ALTO", "CALTRAIN_LTD", 22, 6.00, true, "RAIL"),
        Connection("PALO_ALTO", "SF_4TH_KING", "CALTRAIN_LTD", 38, 7.50, true, "RAIL"),
        Connection("SJ_DIRIDON", "SF_4TH_KING", "CALTRAIN_LTD", 60, 10.50, true, "RAIL"),

        // Bay Area local metro transfers
        Connection("SF_4TH_KING", "SF_CIVIC_CENTER", "SF_MUNI_M", 12, 2.50, true, "LIGHT_RAIL"),
        Connection("SF_4TH_KING", "SF_FERRY_BLDG", null, 10, 2.50, true, "WALK"),
        Connection("SF_CIVIC_CENTER", "SF_FERRY_BLDG", "BART_YELLOW", 6, 2.10, true, "METRO"),
        Connection("SF_FERRY_BLDG", "OAK_JACK_LONDON", "SF_OAK_FERRY", 25, 6.00, true, "FERRY"),
        Connection("SF_CIVIC_CENTER", "OAK_COLISEUM", "BART_RED", 18, 4.65, true, "METRO"),
        Connection("SF_CIVIC_CENTER", "BERKELEY", "BART_RED", 22, 4.80, true, "METRO"),

        // San Jose local VTA
        Connection("SJ_DIRIDON", "PALO_ALTO", "VTA_BLUE", 45, 2.50, true, "LIGHT_RAIL"),

        // Long Distance Central Valley Link (Amtrak San Joaquin)
        Connection("LA_UNION", "BAKERSFIELD", null, 110, 15.00, true, "BUS"), // Amtrak Thruway
        Connection("BAKERSFIELD", "FRESNO", "AMTRAK_CA", 115, 22.00, true, "RAIL"),
        Connection("FRESNO", "STOCKTON", "AMTRAK_CA", 120, 24.00, true, "RAIL"),
        Connection("STOCKTON", "OAK_JACK_LONDON", "AMTRAK_CA", 80, 18.00, true, "RAIL"),
        Connection("STOCKTON", "SAC_VALLEY", "AMTRAK_CA", 60, 14.00, true, "RAIL"),

        // Sacramento Corridor
        Connection("SF_FERRY_BLDG", "SAC_VALLEY", "CAPITOL_CORR", 110, 32.00, true, "RAIL"),
        Connection("SJ_DIRIDON", "OAK_JACK_LONDON", "CAPITOL_CORR", 65, 18.00, true, "RAIL"),
        Connection("OAK_JACK_LONDON", "SAC_VALLEY", "CAPITOL_CORR", 100, 28.00, true, "RAIL"),
        Connection("SAC_VALLEY", "DAVIS", "CAPITOL_CORR", 15, 9.00, true, "RAIL"),

        // North Coast rural connections
        Connection("SAC_VALLEY", "REDDING", "AMTRAK_CA", 180, 35.00, true, "RAIL"), // Coast Starlight
        Connection("REDDING", "EUREKA", null, 150, 24.00, false, "BUS") // Redwood Transit bus
    )

    // Real-Time Alert Simulation
    val alerts = listOf(
        ServiceAlert(
            id = "ALERT_001",
            agencyId = "METROLINK",
            routeId = "SB_LINE",
            category = "DELAYS",
            title = "Track Maintenance Delays",
            description = "San Bernardino Line trains are experiencing 12-18 minute delays near Covina due to track work.",
            affectedTrips = listOf("Train 763", "Train 765"),
            expectedResolution = "Today, 5:00 PM",
            alternativeRoute = "Use Foothill Transit Bus Line 492 to connect to LA Metro Gold Line."
        ),
        ServiceAlert(
            id = "ALERT_002",
            agencyId = "BART",
            routeId = "BART_RED",
            category = "ELEVATOR_OUTAGES",
            title = "Civic Center Elevator Out of Service",
            description = "The street-to-concourse elevator at Civic Center Station is temporarily out of service. Platform elevators remain active.",
            affectedTrips = emptyList(),
            expectedResolution = "Oct 2, 2026",
            alternativeRoute = "Wheelchair passengers should disembark at Powell Street Station and use street-level pathways."
        ),
        ServiceAlert(
            id = "ALERT_003",
            agencyId = "CALTRAIN",
            routeId = "CAL_LTD",
            category = "TRACK_WORK",
            title = "Weekend Single-Tracking",
            description = "Caltrain is single-tracking between Redwood City and Palo Alto for electrification tuning. Expect minor delays of up to 10 minutes.",
            affectedTrips = listOf("Train 203", "Train 205", "Train 207"),
            expectedResolution = "Tonight, 11:30 PM",
            alternativeRoute = "None required, trains continue running on altered schedule."
        ),
        ServiceAlert(
            id = "ALERT_004",
            agencyId = "SF_MUNI",
            routeId = "M_LINE",
            category = "DETOURS",
            title = "M Ocean View Bus Substitution",
            description = "Buses are substituting for M Ocean View light rail cars between West Portal and Balboa Park due to overhead wire replacement.",
            affectedTrips = emptyList(),
            expectedResolution = "Oct 4, 2026",
            alternativeRoute = "Follow signages at West Portal to board 'M Subway Shuttle' bus coach."
        )
    )

    // Moving Vehicles Simulation (10 Active Vehicles for statewide visual appeal)
    val vehicles = listOf(
        VehicleSimulation("V_301", "LA_BLUE_LINE", "LA_METRO", "Metro A Line", "Downtown Long Beach", "LA_UNION", "LONG_BEACH", 33.9210, -118.2120, 2, "ON TIME"),
        VehicleSimulation("V_102", "METROLINK_SB", "METROLINK", "San Bernardino Line", "San Bernardino", "LA_UNION", "SAN_BERNARDINO", 34.0780, -117.8900, 8, "ON TIME"),
        VehicleSimulation("V_452", "SURFLINER", "AMTRAK_CA", "Pacific Surfliner", "San Diego Depot", "LA_UNION", "SD_DEPOT", 33.3520, -117.5120, 15, "MINOR DELAY", 4),
        VehicleSimulation("V_77", "CALTRAIN_LTD", "CALTRAIN", "Caltrain Limited", "San Francisco 4th & King", "SJ_DIRIDON", "SF_4TH_KING", 37.5810, -122.3120, 6, "ON TIME"),
        VehicleSimulation("V_90", "BART_YELLOW", "BART", "BART Yellow Line", "SFO Airport", "SF_CIVIC_CENTER", "SF_FERRY_BLDG", 37.7120, -122.4250, 4, "ON TIME"),
        VehicleSimulation("V_210", "COASTER", "NCTD", "Coaster Rail", "Oceanside Transit Center", "SD_DEPOT", "OCEANSIDE", 32.9520, -117.2650, 12, "ON TIME"),
        VehicleSimulation("V_403", "CAPITOL_CORR", "AMTRAK_CA", "Capitol Corridor", "Sacramento Valley Station", "SF_FERRY_BLDG", "SAC_VALLEY", 38.2520, -122.0120, 22, "ON TIME"),
        VehicleSimulation("V_14", "SF_OAK_FERRY", "SF_FERRIES", "SF-Oakland Ferry", "Oakland Jack London Sq", "SF_FERRY_BLDG", "OAK_JACK_LONDON", 37.7950, -122.3320, 9, "ON TIME")
    )

    // Airport Connections quick reference
    val airportConnections = mapOf(
        "LAX" to listOf("FlyAway Shuttle (LA Union Station to LAX) - Departs every 15 min", "Metro C Line Shuttle from Aviation/LAX Station"),
        "SFO" to listOf("BART Red/Yellow Lines direct to SFO International Terminal", "Caltrain transfer to BART at Millbrae Station"),
        "SAN" to listOf("MTS Bus Route 992 direct from Santa Fe Depot - 10 min ride", "Amtrak Pacific Surfliner connection to Santa Fe Depot"),
        "OAK" to listOf("BART Oakland Airport Connector (OAC) from Coliseum Station", "Amtrak Capitol Corridor to Coliseum Station transfer")
    )

    // Events Quick Navigation
    val eventVenues = listOf(
        EventVenue("Dodger Stadium", "Los Angeles", "LA Union Station", "Dodger Stadium Express (Free with Game Ticket) departs every 10 min", "LA_UNION"),
        EventVenue("SoFi Stadium", "Inglewood", "Hawthorne/Lennox Metro Station", "SoFi Stadium Express Bus from Hawthorne/Lennox Station", "LA_UNION"),
        Stop("CHASE_CENTER", "Chase Center", 37.7680, -122.3877, "Bay Area").let {
            EventVenue("Chase Center", "San Francisco", "SF 4th & King", "Walk 15 min south or take SF Muni T-Third Light Rail", "SF_4TH_KING")
        },
        EventVenue("Oracle Park", "San Francisco", "SF 4th & King", "Walk 3 min east from 4th & King Station", "SF_4TH_KING"),
        EventVenue("Levi's Stadium", "Santa Clara", "San Jose Diridon", "VTA Great America Light Rail direct from Downtown San Jose / Diridon", "SJ_DIRIDON"),
        EventVenue("Petco Park", "San Diego", "San Diego Depot", "Walk 10 min southeast or take MTS Sycuan Green Line Trolley", "SD_DEPOT")
    )
}

data class EventVenue(
    val name: String,
    val city: String,
    val nearestStation: String,
    val transitGuide: String,
    val stationStopId: String
)
