package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class Ticket(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val ticketId: String,
    val agencyName: String,
    val origin: String,
    val destination: String,
    val departureTime: String,
    val fare: Double,
    val passengerName: String,
    val purchaseTimestamp: Long = System.currentTimeMillis(),
    val isValid: Boolean = true
)

@Entity(tableName = "saved_places")
data class SavedPlace(
    @PrimaryKey val name: String, // Home, Work, Favorites, etc.
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val iconName: String // "home", "work", "favorite", "event"
)

@Entity(tableName = "travel_history")
data class TravelHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val origin: String,
    val destination: String,
    val miles: Double,
    val carbonSaved: Double, // in kg of CO2
    val timestamp: Long = System.currentTimeMillis(),
    val agenciesUsed: String // Comma separated list of agencies
)

@Entity(tableName = "saved_commutes")
data class SavedCommute(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val origin: String,
    val destination: String,
    val preferredDeparture: String,
    val preferredOptimization: String, // "Fastest", "Fewest Transfers", "Lowest Fare"
    val averageDurationMinutes: Int = 38
)
