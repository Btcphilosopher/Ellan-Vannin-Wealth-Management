package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = CalRedOrange,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF5D1302),
    onPrimaryContainer = Color(0xFFFFDAD3),
    secondary = OceanBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF003F6E),
    onSecondaryContainer = Color(0xFFD4E3FF),
    tertiary = PacificGreen,
    onTertiary = Color.White,
    background = GraphiteDark,
    onBackground = Color(0xFFE6E1DC),
    surface = GraphiteSurface,
    onSurface = Color(0xFFE6E1DC),
    surfaceVariant = Color(0xFF2C2A29),
    onSurfaceVariant = Color(0xFFCDC5BF),
    error = SignalAlert,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = CalRedOrange,
    onPrimary = Color.White,
    primaryContainer = CalRedOrangeLight,
    onPrimaryContainer = CalRedOrangeDark,
    secondary = OceanBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD4E3FF),
    onSecondaryContainer = Color(0xFF001C3A),
    tertiary = PacificGreen,
    onTertiary = Color.White,
    background = WarmWhite,
    onBackground = GraphiteDark,
    surface = WarmSurface,
    onSurface = GraphiteDark,
    surfaceVariant = Color(0xFFEDE8E0),
    onSurfaceVariant = Color(0xFF4E473F),
    error = SignalAlert,
    onError = Color.White
)

@Composable
fun CaliforniaOneTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set to false to prefer our beautiful California color system
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
