package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Ticket
import com.example.ui.TransitViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(viewModel: TransitViewModel) {
    val tickets by viewModel.digitalTickets.collectAsState()
    val balance by viewModel.walletBalance.collectAsState()
    val history by viewModel.travelHistory.collectAsState()

    // Calculate total statistics
    val totalMiles = remember(history) { history.sumOf { it.miles } }
    val totalCarbonSaved = remember(history) { history.sumOf { it.carbonSaved } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // Core Wallet Header & Glossy Transit Card
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "MY TRANSIT CARD",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                // High-Fidelity Contactless Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF2C3E50),
                                    Color(0xFF3498DB),
                                    CalRedOrange
                                )
                            )
                        )
                        .padding(24.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "CALIFORNIA ONE",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.titleMedium,
                                letterSpacing = 2.sp
                            )
                            Icon(Icons.Default.Contactless, contentDescription = null, tint = Color.White)
                        }

                        Column {
                            Text("BALANCE", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = String.format("$%.2f", balance),
                                color = Color.White,
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.testTag("wallet_balance")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Jane Doe", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Cal-ITP INTEROPERABLE", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Balance Quick Refills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.addWalletFunds(10.0) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
                    ) {
                        Text("+ $10", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { viewModel.addWalletFunds(25.0) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant)
                    ) {
                        Text("+ $25", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { viewModel.addWalletFunds(50.0) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("+ $50", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Active Tickets & Passes
        item {
            Text(
                text = "ACTIVE TICKETS & PASSES (${tickets.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        if (tickets.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("🎫", fontSize = 36.sp)
                        Text("No Active Tickets", fontWeight = FontWeight.Bold)
                        Text(
                            "Plan a journey to purchase single tickets or buy passes.",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(tickets) { ticket ->
                TicketCardView(ticket)
            }
        }

        // Environmental travel statistics
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "YOUR CALIFORNIA TRAVEL INTELLIGENCE",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(history.size.toString(), fontSize = 24.sp, fontWeight = FontWeight.Black, color = CalRedOrange)
                                Text("COMPLETED TRIPS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(String.format("%.1f mi", totalMiles), fontSize = 24.sp, fontWeight = FontWeight.Black, color = OceanBlue)
                                Text("TOTAL MILES", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(String.format("%.1f kg", totalCarbonSaved), fontSize = 24.sp, fontWeight = FontWeight.Black, color = PacificGreen)
                                Text("CO2 SAVED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                        // Mini Canvas Chart representing Carbon emissions avoided
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("WEEKLY CARBON REDUCTION CO2", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Canvas(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(60.dp)
                            ) {
                                val chartWidth = size.width
                                val chartHeight = size.height
                                val points = listOf(1.2f, 2.5f, 0.8f, 3.4f, 2.9f, 4.2f, totalCarbonSaved.toFloat().coerceAtMost(5.5f))

                                val maxVal = 6.0f
                                val pointDistance = chartWidth / (points.size - 1)

                                val chartPath = Path().apply {
                                    points.forEachIndexed { idx, valPct ->
                                        val x = idx * pointDistance
                                        val y = chartHeight - (valPct / maxVal) * chartHeight
                                        if (idx == 0) moveTo(x, y) else lineTo(x, y)
                                    }
                                }

                                drawPath(
                                    path = chartPath,
                                    color = PacificGreen,
                                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                                )

                                // Draw anchor dots
                                points.forEachIndexed { idx, valPct ->
                                    val x = idx * pointDistance
                                    val y = chartHeight - (valPct / maxVal) * chartHeight
                                    drawCircle(
                                        color = CalRedOrange,
                                        radius = 4f,
                                        center = Offset(x, y)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TicketCardView(ticket: Ticket) {
    // Pulse animation for visual security
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alphaPulse by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ticket_${ticket.ticketId}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
    ) {
        Column {
            // Main Ticket Segment
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = ticket.agencyName.uppercase(),
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = ticket.ticketId,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("FROM", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text(ticket.origin, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("TO", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text(ticket.destination, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("PASSENGER", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text(ticket.passengerName, fontSize = 13.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("DEPARTS", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text(ticket.departureTime, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Ticket Tear divider
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.background)
                )
                Canvas(
                    modifier = Modifier
                        .weight(1f)
                        .height(1.dp)
                ) {
                    val width = size.width
                    var x = 0f
                    while (x < width) {
                        drawLine(
                            color = Color.Gray.copy(alpha = 0.3f),
                            start = Offset(x, 0f),
                            end = Offset(x + 5f, 0f),
                            strokeWidth = 2f
                        )
                        x += 10f
                    }
                }
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.background)
                )
            }

            // Ticket Bottom Segment: QR and Shimmer secure element
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shimmer visual security bar
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                        .clip(CircleShape)
                                .background(SignalOnTime.copy(alpha = alphaPulse))
                        )
                        Text("ACTIVE VALID SECURITY", fontSize = 10.sp, fontWeight = FontWeight.Black, color = SignalOnTime)
                    }
                    // Animated gradient security bar
                    Box(
                        modifier = Modifier
                            .width(130.dp)
                            .height(14.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        CalRedOrange,
                                        OceanBlue,
                                        PacificGreen
                                    )
                                )
                            )
                    )
                }

                // QR Code Placeholder
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .border(1.dp, Color.LightGray, RoundedCornerShape(8.dp))
                        .padding(6.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Drawing abstract QR square nodes
                        val w = size.width
                        val h = size.height
                        drawRect(Color.Black, Offset(0f, 0f), size = androidx.compose.ui.geometry.Size(w * 0.35f, h * 0.35f))
                        drawRect(Color.Black, Offset(w * 0.65f, 0f), size = androidx.compose.ui.geometry.Size(w * 0.35f, h * 0.35f))
                        drawRect(Color.Black, Offset(0f, h * 0.65f), size = androidx.compose.ui.geometry.Size(w * 0.35f, h * 0.35f))
                        drawRect(Color.Black, Offset(w * 0.4f, h * 0.4f), size = androidx.compose.ui.geometry.Size(w * 0.2f, h * 0.2f))
                    }
                }
            }
        }
    }
}
