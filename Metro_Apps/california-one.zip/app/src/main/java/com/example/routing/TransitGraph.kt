package com.example.routing

data class Agency(
    val id: String,
    val name: String,
    val region: String,
    val modes: List<String>,
    val logoEmoji: String,
    val colorHex: String,
    val hasContactless: Boolean = true,
    val isGtfshHealthy: Boolean = true,
    val hasGtfsRt: Boolean = true,
    val lastUpdated: String = "10:42 AM"
)

data class Stop(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val region: String,
    val isAccessible: Boolean = true,
    val facilities: List<String> = listOf("Elevators", "Escalators", "Restrooms", "Wi-Fi", "Bike Racks")
)

data class Route(
    val id: String,
    val agencyId: String,
    val shortName: String,
    val longName: String,
    val mode: String, // "RAIL", "METRO", "BUS", "LIGHT_RAIL", "FERRY", "CABLE_CAR"
    val colorHex: String
)

data class Trip(
    val id: String,
    val routeId: String,
    val tripHeadsign: String,
    val schedule: List<ScheduleTime>
)

data class ScheduleTime(
    val stopId: String,
    val arrivalTime: String, // e.g., "10:42 AM"
    val departureTime: String,
    val stopSequence: Int
)

data class Connection(
    val fromStopId: String,
    val toStopId: String,
    val routeId: String?, // null if walking transfer
    val durationMinutes: Int,
    val costDollars: Double,
    val isAccessible: Boolean = true,
    val mode: String // "TRANSIT", "WALK", "BIKE"
)

data class VehicleSimulation(
    val vehicleId: String,
    val routeId: String,
    val agencyId: String,
    val routeName: String,
    val headsign: String,
    val currentStopId: String,
    val nextStopId: String,
    val latitude: Double,
    val longitude: Double,
    val minutesToArrival: Int,
    val status: String, // "ON TIME", "MINOR DELAY", "MAJOR DELAY", "UNCERTAIN"
    val delayMinutes: Int = 0
)

data class ServiceAlert(
    val id: String,
    val agencyId: String,
    val routeId: String?,
    val category: String, // "DELAYS", "CANCELLATIONS", "DETOURS", "STATION_CLOSURES", "ELEVATOR_OUTAGES"
    val title: String,
    val description: String,
    val affectedTrips: List<String>,
    val expectedResolution: String,
    val alternativeRoute: String
)
