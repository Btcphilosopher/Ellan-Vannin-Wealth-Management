package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TransitViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActiveJourneyScreen(viewModel: TransitViewModel) {
    val leg by viewModel.onboardLeg.collectAsState()
    val isReminderSet by viewModel.arrivalReminderSet.collectAsState()

    if (leg == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("📭", fontSize = 54.sp)
            Spacer(Modifier.height(16.dp))
            Text("No Active Journey Boarded", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(
                "Plan a route in the Trip Planner and click 'On Board' to activate real-time Journey Mode.",
                color = Color.Gray,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
        }
    } else {
        val currentLeg = leg!!
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
        ) {
            // "ON BOARD" Headline Status Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("onboard_headline_card"),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(SignalOnTime)
                                )
                                Text(
                                    text = "LIVE TRACKING RUNNING",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = SignalOnTime
                                )
                            }
                            Badge(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer) {
                                Text("ON BOARD", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Text(
                            text = currentLeg.routeName?.uppercase() ?: "ACTIVE LINE",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black
                        )

                        Text(
                            text = "${currentLeg.fromStop.name} → ${currentLeg.toStop.name}",
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            // Next Stop countdown ticker
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("NEXT STATION STOP", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(currentLeg.toStop.name, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("Scheduled Arrival: ${currentLeg.endTime}", fontSize = 12.sp, color = Color.Gray)
                        }

                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${(currentLeg.durationMinutes / 3).coerceAtLeast(1)}",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text("MIN ETA", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.8f))
                            }
                        }
                    }
                }
            }

            // Transit Progress Canvas Map representation
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("ROUTE PROGRESS TRACKER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)

                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp)
                        ) {
                            val w = size.width
                            val h = size.height

                            // Draw track line
                            drawLine(
                                color = Color.Gray.copy(alpha = 0.3f),
                                start = Offset(w * 0.1f, h * 0.5f),
                                end = Offset(w * 0.9f, h * 0.5f),
                                strokeWidth = 8f
                            )

                            // Highlight completed route segment
                            drawLine(
                                color = CalRedOrange,
                                start = Offset(w * 0.1f, h * 0.5f),
                                end = Offset(w * 0.65f, h * 0.5f),
                                strokeWidth = 8f
                            )

                            // Start point node
                            drawCircle(Color.LightGray, radius = 10f, center = Offset(w * 0.1f, h * 0.5f))
                            // Current passenger train position node
                            drawCircle(CalRedOrange, radius = 12f, center = Offset(w * 0.65f, h * 0.5f))
                            // Pulsing glow outer dot
                            drawCircle(CalRedOrange.copy(alpha = 0.3f), radius = 20f, center = Offset(w * 0.65f, h * 0.5f))
                            // Destination node
                            drawCircle(OceanBlue, radius = 10f, center = Offset(w * 0.9f, h * 0.5f))
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(currentLeg.fromStop.name.take(15) + "...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Speed: 79 MPH", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text(currentLeg.toStop.name.take(15) + "...", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OceanBlue)
                        }
                    }
                }
            }

            // Amenities row & Get Off Here reminder
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Coach Amenities
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("COACH DETAILS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            AmenityRowItem(Icons.Default.Wifi, "Wi-Fi Active")
                            AmenityRowItem(Icons.Default.DirectionsBike, "Bikes Welcome")
                            AmenityRowItem(Icons.Default.Restaurant, "Café Car Open")
                            AmenityRowItem(Icons.Default.Wc, "Restroom OK")
                        }
                    }

                    // Get Off Here Reminder Alarm
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("reminder_alarm_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isReminderSet) SignalOnTime.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isReminderSet) SignalOnTime else Color.Transparent
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = if (isReminderSet) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                                contentDescription = null,
                                tint = if (isReminderSet) SignalOnTime else Color.Gray,
                                modifier = Modifier.size(36.dp)
                            )

                            Spacer(Modifier.height(8.dp))

                            Text(
                                text = "GET OFF HERE",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = if (isReminderSet) SignalOnTime else MaterialTheme.colorScheme.onSurface
                            )

                            Text(
                                text = "Ring alarm 1 stop before arrival.",
                                fontSize = 10.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )

                            Spacer(Modifier.height(10.dp))

                            Button(
                                onClick = { viewModel.toggleArrivalReminder() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isReminderSet) SignalOnTime else GraphiteDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(if (isReminderSet) "ALARM ON" else "SET REMINDER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }

            // Completer Section: Complete Journey & Log Savings
            item {
                Button(
                    onClick = { viewModel.completeOnboardJourney() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("complete_journey_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("ARRIVED · LOG CARBON SAVINGS", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun AmenityRowItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = PacificGreen)
        Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}
