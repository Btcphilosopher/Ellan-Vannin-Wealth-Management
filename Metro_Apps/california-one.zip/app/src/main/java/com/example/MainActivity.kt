package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.screens.*
import com.example.ui.theme.CaliforniaOneTheme

class MainActivity : ComponentActivity() {
    private val viewModel: TransitViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CaliforniaOneTheme {
                MainAppFrame(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppFrame(viewModel: TransitViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val bannerNotification by viewModel.bannerNotification.collectAsState()

    // Central back gesture controller (Pop screen stack safely)
    BackHandler(enabled = currentScreen != TransitScreen.HOME) {
        viewModel.popScreen()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Material 3 Bottom Navigation bar with pill selectors
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("app_navigation_bar"),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                NavigationBarItem(
                    selected = currentScreen == TransitScreen.HOME,
                    onClick = { viewModel.navigateTo(TransitScreen.HOME) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_home")
                )

                NavigationBarItem(
                    selected = currentScreen == TransitScreen.TRIP_PLANNER,
                    onClick = { viewModel.navigateTo(TransitScreen.TRIP_PLANNER) },
                    icon = { Icon(Icons.Default.Route, contentDescription = "Routes") },
                    label = { Text("Trip", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_trip")
                )

                NavigationBarItem(
                    selected = currentScreen == TransitScreen.LIVE_MAP,
                    onClick = { viewModel.navigateTo(TransitScreen.LIVE_MAP) },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                    label = { Text("Map", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_map")
                )

                NavigationBarItem(
                    selected = currentScreen == TransitScreen.MY_WALLET,
                    onClick = { viewModel.navigateTo(TransitScreen.MY_WALLET) },
                    icon = { Icon(Icons.Default.Wallet, contentDescription = "Wallet") },
                    label = { Text("Wallet", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_wallet")
                )

                NavigationBarItem(
                    selected = currentScreen == TransitScreen.STATION_DETAIL,
                    onClick = { viewModel.navigateTo(TransitScreen.STATION_DETAIL) },
                    icon = { Icon(Icons.Default.DepartureBoard, contentDescription = "Stations") },
                    label = { Text("Stations", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_stations")
                )

                NavigationBarItem(
                    selected = currentScreen == TransitScreen.SETTINGS_DIAGNOSTICS,
                    onClick = { viewModel.navigateTo(TransitScreen.SETTINGS_DIAGNOSTICS) },
                    icon = { Icon(Icons.Default.DeveloperMode, contentDescription = "Settings") },
                    label = { Text("OS", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_settings")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Animated transitions between screen states
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "screen_navigation"
            ) { targetScreen ->
                when (targetScreen) {
                    TransitScreen.HOME -> HomeScreen(viewModel)
                    TransitScreen.TRIP_PLANNER -> TripPlannerScreen(viewModel)
                    TransitScreen.LIVE_MAP -> MapScreen(viewModel)
                    TransitScreen.MY_WALLET -> WalletScreen(viewModel)
                    TransitScreen.STATION_DETAIL -> StationScreen(viewModel)
                    TransitScreen.SETTINGS_DIAGNOSTICS -> SettingsScreen(viewModel)
                    TransitScreen.ACTIVE_JOURNEY -> ActiveJourneyScreen(viewModel)
                    TransitScreen.ALERTS_BOARD -> AlertsScreen(viewModel)
                }
            }

            // Top Floating banner alert toast
            AnimatedVisibility(
                visible = bannerNotification != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                bannerNotification?.let { msg ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.clearBanner() }
                            .testTag("banner_notification"),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        tonalElevation = 6.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = msg,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
