package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.routing.MockTransitData
import com.example.ui.TransitViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: TransitViewModel) {
    var isOfflineTripCached by remember { mutableStateOf(true) }
    var isOfflineTicketsCached by remember { mutableStateOf(true) }
    var isAlertsNotificationOn by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // Settings Headline
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_header_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "PREFERENCES & DIAGNOSTICS",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "CALIFORNIA ONE OS",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Manage local caches, notification alerts, and inspect federated agency data streams.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }
        }

        // Offline Cache Prefs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("OFFLINE COMPLIANCE CACHES", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Cache Current Trip", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Preloads routing nodes for offline use.", fontSize = 11.sp, color = Color.Gray)
                        }
                        Switch(checked = isOfflineTripCached, onCheckedChange = { isOfflineTripCached = it })
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Store Active Tickets Offline", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Retains encrypted QR ticket keys.", fontSize = 11.sp, color = Color.Gray)
                        }
                        Switch(checked = isOfflineTicketsCached, onCheckedChange = { isOfflineTicketsCached = it })
                    }
                }
            }
        }

        // Diagnostic registry header
        item {
            Text(
                text = "FEDERATED OPERATORS FEED STATUS (Cal-ITP)",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = Color.Gray
            )
        }

        // List mock agencies with ingestion health statuses
        items(MockTransitData.agencies) { agency ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(agency.logoEmoji, fontSize = 16.sp)
                            Text(agency.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        Badge(
                            containerColor = if (agency.isGtfshHealthy) SignalOnTime else SignalAlert,
                            contentColor = Color.White
                        ) {
                            Text(if (agency.isGtfshHealthy) "HEALTHY" else "ERROR FEED", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                    // Feed Details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("GTFS INGESTION", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text(if (agency.isGtfshHealthy) "Ingested (Schedule)" else "Feed Offline", fontSize = 11.sp)
                        }
                        Column {
                            Text("GTFS-RT UPDATES", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text(if (agency.hasGtfsRt) "Active (Trip Updates)" else "Schedule Only", fontSize = 11.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("LAST REFRESHED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text(agency.lastUpdated, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
