package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TicketDao {
    @Query("SELECT * FROM tickets ORDER BY purchaseTimestamp DESC")
    fun getAllTickets(): Flow<List<Ticket>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: Ticket)

    @Delete
    suspend fun deleteTicket(ticket: Ticket)

    @Query("DELETE FROM tickets")
    suspend fun clearTickets()
}

@Dao
interface SavedPlaceDao {
    @Query("SELECT * FROM saved_places")
    fun getAllSavedPlaces(): Flow<List<SavedPlace>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedPlace(place: SavedPlace)

    @Delete
    suspend fun deleteSavedPlace(place: SavedPlace)
}

@Dao
interface TravelHistoryDao {
    @Query("SELECT * FROM travel_history ORDER BY timestamp DESC")
    fun getAllTravelHistory(): Flow<List<TravelHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTravelHistory(history: TravelHistory)

    @Query("DELETE FROM travel_history")
    suspend fun clearHistory()
}

@Dao
interface SavedCommuteDao {
    @Query("SELECT * FROM saved_commutes")
    fun getAllSavedCommutes(): Flow<List<SavedCommute>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedCommute(commute: SavedCommute)

    @Delete
    suspend fun deleteSavedCommute(commute: SavedCommute)
}
