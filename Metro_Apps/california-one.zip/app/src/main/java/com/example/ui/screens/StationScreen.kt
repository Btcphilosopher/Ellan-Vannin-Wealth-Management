package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.routing.MockTransitData
import com.example.routing.Stop
import com.example.ui.TransitScreen
import com.example.ui.TransitViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationScreen(viewModel: TransitViewModel) {
    val station by viewModel.focusedStation.collectAsState()
    var selectedTab by remember { mutableStateOf("DEPARTURES") } // DEPARTURES, ARRIVALS, DIGITAL_TWIN

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // Station Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("station_header"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STATION EXPERIENCES",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Badge(containerColor = SignalOnTime, contentColor = Color.White) {
                            Text("ALL SYSTEMS OK", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = station.name.uppercase(),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )

                    Text(
                        text = "Region: ${station.region} · Accessible Platforms ♿",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    // Facility quick indicators
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        FacilityIcon(Icons.Default.Wifi, "Wi-Fi")
                        FacilityIcon(Icons.Default.DirectionsBike, "Bike Park")
                        FacilityIcon(Icons.Default.Escalator, "Escalators")
                        FacilityIcon(Icons.Default.Wc, "Restrooms")
                        FacilityIcon(Icons.Default.Elevator, "Elevators")
                    }
                }
            }
        }

        // Action Tabs (Departures, Arrivals, Digital Twin)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                StationTabButton("DEPARTURES", active = selectedTab == "DEPARTURES", modifier = Modifier.weight(1f)) { selectedTab = "DEPARTURES" }
                StationTabButton("ARRIVALS", active = selectedTab == "ARRIVALS", modifier = Modifier.weight(1f)) { selectedTab = "ARRIVALS" }
                StationTabButton("DIGITAL TWIN", active = selectedTab == "DIGITAL_TWIN", modifier = Modifier.weight(1.2f)) { selectedTab = "DIGITAL_TWIN" }
            }
        }

        // Tab Views
        when (selectedTab) {
            "DEPARTURES" -> {
                // Live Board Items
                item {
                    Text(
                        text = "LIVE DEPARTURE BOARD",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                }

                // Inject station specific real-time records
                val departuresList = getMockDeparturesForStation(station.id)
                items(departuresList) { dep ->
                    DepartureRow(dep)
                }
            }

            "ARRIVALS" -> {
                item {
                    Text(
                        text = "LIVE ARRIVALS BOARD",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                }

                val arrivalsList = getMockArrivalsForStation(station.id)
                items(arrivalsList) { arr ->
                    ArrivalRow(arr)
                }
            }

            "DIGITAL_TWIN" -> {
                item {
                    DigitalTwinSection(station)
                }
            }
        }
    }
}

@Composable
fun DigitalTwinSection(station: Stop) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("station_digital_twin"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "STATION TWIN FLOORPLAN",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Badge(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer) {
                    Text("LEVEL 1 - PLATFORMS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Digital Twin Station model drawn inside a Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(GraphiteDark)
            ) {
                val w = size.width
                val h = size.height

                // Draw main concourse platform track grids
                val trackY1 = h * 0.25f
                val trackY2 = h * 0.5f
                val trackY3 = h * 0.75f

                // Track lines
                drawLine(Color.Gray.copy(alpha = 0.3f), Offset(0f, trackY1), Offset(w, trackY1), strokeWidth = 8f)
                drawLine(Color.Gray.copy(alpha = 0.3f), Offset(0f, trackY2), Offset(w, trackY2), strokeWidth = 8f)
                drawLine(Color.Gray.copy(alpha = 0.3f), Offset(0f, trackY3), Offset(w, trackY3), strokeWidth = 8f)

                // Draw passenger platforms
                drawRect(
                    color = ConcreteGrey.copy(alpha = 0.15f),
                    topLeft = Offset(w * 0.15f, trackY1 + 8f),
                    size = androidx.compose.ui.geometry.Size(w * 0.7f, 25f)
                )
                drawRect(
                    color = ConcreteGrey.copy(alpha = 0.15f),
                    topLeft = Offset(w * 0.15f, trackY2 + 8f),
                    size = androidx.compose.ui.geometry.Size(w * 0.7f, 25f)
                )

                // Walkway vector outline path
                val walkwayPath = Path().apply {
                    moveTo(w * 0.2f, h * 0.15f)
                    lineTo(w * 0.2f, h * 0.85f)
                    lineTo(w * 0.8f, h * 0.85f)
                }
                drawPath(walkwayPath, CalRedOrange, style = Stroke(width = 3f))

                // Elevators nodes
                drawCircle(PacificGreen, radius = 8f, center = Offset(w * 0.2f, h * 0.15f))
                drawCircle(PacificGreen, radius = 8f, center = Offset(w * 0.5f, h * 0.85f))

                // Current passenger marker dot
                drawCircle(Color.White, radius = 6f, center = Offset(w * 0.8f, h * 0.85f))
            }

            // Route directions instructions
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("INTELLIGENT INTERCHANGE NAVIGATOR", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                    Column {
                        Text("Platform 4 → VTA Light Rail", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("4 min walk via Main Concourse escalator.", fontSize = 12.sp, color = Color.Gray)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(PacificGreen.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Accessible, contentDescription = null, tint = PacificGreen)
                    }
                    Column {
                        Text("Accessible Elevator Route", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PacificGreen)
                        Text("6 min. Outage check verified clear. Use South Elevator A.", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun StationTabButton(text: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) MaterialTheme.colorScheme.surface else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = if (active) MaterialTheme.colorScheme.primary else Color.Gray)
    }
}

@Composable
fun FacilityIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, name: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = name, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun DepartureRow(dep: MockDeparture) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(dep.color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(dep.logo, fontSize = 16.sp)
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(dep.agency, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Badge(containerColor = dep.statusColor, contentColor = Color.White) {
                            Text(dep.status, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(dep.destination, fontSize = 12.sp, color = Color.Gray)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(dep.time, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text("Track ${dep.track}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            }
        }
    }
}

@Composable
fun ArrivalRow(arr: MockArrival) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(arr.color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(arr.logo, fontSize = 16.sp)
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(arr.agency, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Badge(containerColor = SignalOnTime, contentColor = Color.White) {
                            Text(arr.status, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("From ${arr.origin}", fontSize = 12.sp, color = Color.Gray)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(arr.time, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text("Platform ${arr.platform}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            }
        }
    }
}

// Helpers for mock schedule generators
data class MockDeparture(
    val time: String,
    val agency: String,
    val destination: String,
    val track: String,
    val logo: String,
    val color: Color,
    val status: String,
    val statusColor: Color
)

data class MockArrival(
    val time: String,
    val agency: String,
    val origin: String,
    val platform: String,
    val logo: String,
    val color: Color,
    val status: String
)

fun getMockDeparturesForStation(stationId: String): List<MockDeparture> {
    return when (stationId) {
        "LA_UNION" -> listOf(
            MockDeparture("10:42 AM", "Metrolink", "San Bernardino", "6", "🚆", OceanBlue, "ON TIME", SignalOnTime),
            MockDeparture("10:47 AM", "Amtrak Surfliner", "San Diego", "2", "🚄", CalRedOrange, "ON TIME", SignalOnTime),
            MockDeparture("10:53 AM", "Metro B Line", "Hollywood", "Platform 1", "🚇", PacificGreen, "ON TIME", SignalOnTime),
            MockDeparture("11:05 AM", "Metro A Line", "Long Beach", "Platform 3", "🚋", MutedYellow, "DELAY 4M", SignalMinorDelay)
        )
        "SJ_DIRIDON" -> listOf(
            MockDeparture("10:45 AM", "Caltrain", "San Francisco", "4", "🚆", CalRedOrange, "ON TIME", SignalOnTime),
            MockDeparture("10:58 AM", "VTA Light Rail", "Alum Rock", "Platform B", "🚋", OceanBlue, "ON TIME", SignalOnTime),
            MockDeparture("11:12 AM", "Capitol Corridor", "Sacramento", "Track 1", "🚄", MutedYellow, "ON TIME", SignalOnTime)
        )
        else -> listOf(
            MockDeparture("10:42 AM", "Amtrak California", "Statewide Corridor", "Track 1", "🚄", CalRedOrange, "ON TIME", SignalOnTime),
            MockDeparture("10:55 AM", "Local Transit", "Downtown Hub", "Platform A", "🚌", Color.Gray, "ON TIME", SignalOnTime)
        )
    }
}

fun getMockArrivalsForStation(stationId: String): List<MockArrival> {
    return when (stationId) {
        "LA_UNION" -> listOf(
            MockArrival("10:38 AM", "Metrolink", "Ventura County", "5", "🚆", OceanBlue, "ARRIVED"),
            MockArrival("10:45 AM", "Amtrak Surfliner", "San Luis Obispo", "1", "🚄", CalRedOrange, "ON TIME"),
            MockArrival("10:51 AM", "Metro A Line", "Azusa", "Platform 4", "🚋", MutedYellow, "ON TIME")
        )
        else -> listOf(
            MockArrival("10:35 AM", "State Link", "Intercity Depot", "Platform A", "🚄", CalRedOrange, "ARRIVED")
        )
    }
}
