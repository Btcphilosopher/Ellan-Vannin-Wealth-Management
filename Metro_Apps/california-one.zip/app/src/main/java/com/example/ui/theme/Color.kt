package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// California modern colors
val CalRedOrange = Color(0xFFFF4E26)       // Primary California Sunset/Signage Red-Orange
val CalRedOrangeDark = Color(0xFFD8340E)   // For dark backgrounds or text
val CalRedOrangeLight = Color(0xFFFFEAE6)  // Light tint for container backgrounds

// Natural Tones
val WarmWhite = Color(0xFFFCFAF7)         // Primary Warm White Background
val WarmSurface = Color(0xFFF6F3ED)       // Secondary surface, concrete look
val GraphiteDark = Color(0xFF141413)      // Warm Charcoal / Dark background
val GraphiteSurface = Color(0xFF1D1D1C)   // Secondary dark surface

// Accent colors representing agencies & utilities
val PacificGreen = Color(0xFF1B4D3E)       // Eucalyptus/Redwood forest
val OceanBlue = Color(0xFF005A9C)          // Pacific Coast
val DesertSand = Color(0xFFE6D7C3)         // Mojave / Joshua Tree sand
val MutedYellow = Color(0xFFDCAE1D)        // California Golden poppy yellow
val ConcreteGrey = Color(0xFFB0BEC5)       // Station concrete
val SignalAlert = Color(0xFFE53935)        // Delayed / Emergency red
val SignalOnTime = Color(0xFF2E7D32)       // On time green
val SignalMinorDelay = Color(0xFFEF6C00)   // Minor delay orange
