package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.routing.Journey
import com.example.routing.JourneyLeg
import com.example.ui.TransitScreen
import com.example.ui.TransitViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TripPlannerScreen(viewModel: TransitViewModel) {
    val fromText by viewModel.searchFromText.collectAsState()
    val toText by viewModel.searchToText.collectAsState()
    val plannedJourneys by viewModel.plannedJourneys.collectAsState()
    val selectedJourney by viewModel.selectedJourney.collectAsState()
    val optimization by viewModel.selectedOptimization.collectAsState()
    val accessibilityRequired by viewModel.accessibilityRequired.collectAsState()
    val bringBike by viewModel.bringBike.collectAsState()

    val options = listOf("Fastest", "Fewest Transfers", "Lowest Fare", "Least Walking", "Elevator Required")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trip Planner", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.popScreen() },
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Options Panel Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Search route overview
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp), tint = CalRedOrange)
                        Text(fromText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                        Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(16.dp), tint = OceanBlue)
                        Text(toText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                    // Optimization selection chips
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("SORT & OPTIMIZE BY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(38.dp),
                                horizontalAlignment = Alignment.Start
                            ) {
                                item {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        options.forEach { opt ->
                                            val isSelected = opt == optimization
                                            FilterChip(
                                                selected = isSelected,
                                                onClick = {
                                                    viewModel.selectedOptimization.value = opt
                                                    viewModel.performSearch()
                                                },
                                                label = { Text(opt, fontSize = 11.sp) },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                                    selectedLabelColor = Color.White
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Toggles Row (Bicycle, Accessibility)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Accessible, contentDescription = null, modifier = Modifier.size(18.dp), tint = OceanBlue)
                            Text("Accessible Profile", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Switch(
                                checked = accessibilityRequired,
                                onCheckedChange = {
                                    viewModel.accessibilityRequired.value = it
                                    viewModel.performSearch()
                                },
                                modifier = Modifier.scale(0.7f)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.DirectionsBike, contentDescription = null, modifier = Modifier.size(18.dp), tint = PacificGreen)
                            Text("Bring Bicycle", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Switch(
                                checked = bringBike,
                                onCheckedChange = {
                                    viewModel.bringBike.value = it
                                    viewModel.performSearch()
                                },
                                modifier = Modifier.scale(0.7f)
                            )
                        }
                    }
                }
            }

            // Results List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                if (plannedJourneys.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(36.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("🚆", fontSize = 48.sp)
                            Text(
                                "No connections found.",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                "Please verify spelling or check service alerts for line disruptions.",
                                fontSize = 13.sp,
                                color = Color.Gray,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                } else {
                    item {
                        Text(
                            text = "${plannedJourneys.size} TRANSIT OPTIMIZATIONS",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray,
                            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                        )
                    }

                    items(plannedJourneys) { journey ->
                        val isSelected = selectedJourney?.id == journey.id
                        JourneyResultItem(
                            journey = journey,
                            isSelected = isSelected,
                            onClick = {
                                // Select this journey
                                viewModel.performSearch() 
                            }
                        )

                        if (isSelected) {
                            ExpandedJourneyTimeline(
                                journey = journey,
                                viewModel = viewModel,
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun JourneyResultItem(
    journey: Journey,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("journey_option_${journey.id.take(4)}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = formatDuration(journey.totalDurationMinutes),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                    )
                    Badge(
                        containerColor = if (journey.isAccessible) PacificGreen else SignalMinorDelay,
                        contentColor = Color.White
                    ) {
                        Text(if (journey.isAccessible) "Accessible" else "Alert Outage", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Text(
                    text = String.format("$%.2f", journey.totalFare),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                journey.legs.forEach { leg ->
                    val logo = when (leg.mode) {
                        "RAIL" -> "🚆"
                        "METRO" -> "🚇"
                        "BUS" -> "🚌"
                        "LIGHT_RAIL" -> "🚋"
                        "FERRY" -> "⛴"
                        else -> "🚶"
                    }
                    val badgeColor = when (leg.agencyId) {
                        "CALTRAIN" -> Color(0xFFEB1C24)
                        "BART" -> Color(0xFF0079C1)
                        "METROLINK" -> Color(0xFF00A3E0)
                        "LA_METRO" -> Color(0xFF0072CE)
                        "AMTRAK_CA" -> Color(0xFF002F6C)
                        else -> Color.Gray
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(badgeColor.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 3.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("$logo ${leg.routeName?.split(" ")?.firstOrNull() ?: ""}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = badgeColor)
                        }
                    }

                    if (leg != journey.legs.last()) {
                        Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Leaves ${journey.legs.firstOrNull()?.startTime ?: "10:42 AM"} · ${journey.transferCount} transfers",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )

                if (isSelected) {
                    Text("Selected Option", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("View Details", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(2.dp))
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ExpandedJourneyTimeline(
    journey: Journey,
    viewModel: TransitViewModel,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("JOURNEY TIMELINE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold)

            journey.legs.forEachIndexed { index, leg ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(55.dp)) {
                        Text(leg.startTime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Box(
                            modifier = Modifier
                                .width(2.dp)
                                .height(50.dp)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                        )
                        if (index == journey.legs.size - 1) {
                            Text(leg.endTime, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = if (leg.mode == "WALK") "Walk ${leg.durationMinutes} min" else "Board ${leg.routeName}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "${leg.fromStop.name} → ${leg.toStop.name}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        if (leg.accessibilityNote != null) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.Accessible, contentDescription = null, modifier = Modifier.size(12.dp), tint = PacificGreen)
                                Text(leg.accessibilityNote, fontSize = 11.sp, color = PacificGreen)
                            }
                        }

                        if (leg.mode != "WALK") {
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { viewModel.startOnboardJourney(leg) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Icon(Icons.Default.DirectionsTransit, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("On Board", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        viewModel.purchaseTicket(
                                            agency = leg.agencyId ?: "California One",
                                            origin = leg.fromStop.name,
                                            destination = leg.toStop.name,
                                            fare = leg.fare
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GraphiteDark, contentColor = Color.White),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text(String.format("Buy $%.2f", leg.fare), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun formatDuration(minutes: Int): String {
    if (minutes < 60) return "$minutes min"
    val hrs = minutes / 60
    val remaining = minutes % 60
    return if (remaining == 0) "${hrs}h" else "${hrs}h ${remaining}m"
}
