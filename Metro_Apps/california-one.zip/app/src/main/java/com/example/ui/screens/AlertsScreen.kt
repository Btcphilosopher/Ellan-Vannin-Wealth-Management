package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.routing.MockTransitData
import com.example.routing.ServiceAlert
import com.example.ui.TransitViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlertsScreen(viewModel: TransitViewModel) {
    var selectedCategory by remember { mutableStateOf("ALL") }
    val categories = listOf("ALL", "DELAYS", "DETOURS", "TRACK_WORK", "ELEVATOR_OUTAGES")

    val alerts = MockTransitData.alerts
    val filteredAlerts = remember(selectedCategory) {
        if (selectedCategory == "ALL") alerts else {
            alerts.filter { it.category == selectedCategory }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // Active Alerts Headline Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("alerts_headline_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "STATEWIDE ALERTS NETWORK",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "312 SERVICE DISRUPTIONS",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Covers delayed lines, detours, and equipment outages for all 230+ California transit operators.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }
        }

        // Horizontal Category Row
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(30.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = cat.replace("_", " "),
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Active Alerts List
        if (filteredAlerts.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("✅", fontSize = 48.sp)
                    Text("All Lines Running Clear", fontWeight = FontWeight.Bold)
                    Text("No alerts found for this category.", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else {
            items(filteredAlerts) { alert ->
                AlertItemCard(alert)
            }
        }
    }
}

@Composable
fun AlertItemCard(alert: ServiceAlert) {
    val agency = MockTransitData.agencies.find { it.id == alert.agencyId }
    val alertColor = when (alert.category) {
        "DELAYS" -> SignalMinorDelay
        "CANCELLATIONS" -> SignalAlert
        "ELEVATOR_OUTAGES" -> OceanBlue
        else -> MutedYellow
    }

    val categoryIcon = when (alert.category) {
        "DELAYS" -> Icons.Default.Schedule
        "CANCELLATIONS" -> Icons.Default.Cancel
        "ELEVATOR_OUTAGES" -> Icons.Default.Elevator
        else -> Icons.Default.Construction
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("alert_card_${alert.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, alertColor.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Header Row: Category Badge & Agency Label
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(alertColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(categoryIcon, contentDescription = null, tint = alertColor, modifier = Modifier.size(14.dp))
                    }
                    Text(
                        text = alert.category.replace("_", " "),
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp,
                        color = alertColor
                    )
                }

                Text(
                    text = agency?.name ?: alert.agencyId,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            // Title and Description
            Text(
                text = alert.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = alert.description,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )

            // Affected list
            if (alert.affectedTrips.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("AFFECTED TRIPS:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    alert.affectedTrips.forEach { trip ->
                        Badge(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurfaceVariant) {
                            Text(trip, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

            // Expected resolution and Alternative route suggestions
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.Timer, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                    Text("EXPECTED RESOLUTION:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Text(alert.expectedResolution, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(2.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(14.dp), tint = PacificGreen)
                            Text("SUGGESTED ALTERNATIVE OPTIONS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PacificGreen)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = alert.alternativeRoute,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }
    }
}
