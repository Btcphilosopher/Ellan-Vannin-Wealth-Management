package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.take

class TransitRepository(private val database: AppDatabase) {
    val ticketDao = database.ticketDao()
    val savedPlaceDao = database.savedPlaceDao()
    val travelHistoryDao = database.travelHistoryDao()
    val savedCommuteDao = database.savedCommuteDao()

    val allTickets: Flow<List<Ticket>> = ticketDao.getAllTickets()
    val allSavedPlaces: Flow<List<SavedPlace>> = savedPlaceDao.getAllSavedPlaces()
    val allTravelHistory: Flow<List<TravelHistory>> = travelHistoryDao.getAllTravelHistory()
    val allSavedCommutes: Flow<List<SavedCommute>> = savedCommuteDao.getAllSavedCommutes()

    // Tickets
    suspend fun insertTicket(ticket: Ticket) = ticketDao.insertTicket(ticket)
    suspend fun deleteTicket(ticket: Ticket) = ticketDao.deleteTicket(ticket)
    suspend fun clearTickets() = ticketDao.clearTickets()

    // Saved Places
    suspend fun insertSavedPlace(place: SavedPlace) = savedPlaceDao.insertSavedPlace(place)
    suspend fun deleteSavedPlace(place: SavedPlace) = savedPlaceDao.deleteSavedPlace(place)

    // Travel History
    suspend fun insertTravelHistory(history: TravelHistory) = travelHistoryDao.insertTravelHistory(history)
    suspend fun clearHistory() = travelHistoryDao.clearHistory()

    // Saved Commutes
    suspend fun insertSavedCommute(commute: SavedCommute) = savedCommuteDao.insertSavedCommute(commute)
    suspend fun deleteSavedCommute(commute: SavedCommute) = savedCommuteDao.deleteSavedCommute(commute)

    /**
     * Seed initial demo data if database is empty.
     */
    suspend fun prepopulateDatabaseIfEmpty() {
        val existingPlaces = allSavedPlaces.take(1).firstOrNull()
        if (existingPlaces.isNullOrEmpty()) {
            // Seed Saved Places
            savedPlaceDao.insertSavedPlace(SavedPlace("Home", "3456 Redwood Ave, Los Angeles", 34.0123, -118.4231, "home"))
            savedPlaceDao.insertSavedPlace(SavedPlace("Work", "555 Mission St, San Francisco", 37.7876, -122.4012, "work"))
            savedPlaceDao.insertSavedPlace(SavedPlace("Dodger Stadium", "1000 Vin Scully Ave, Los Angeles", 34.0739, -118.2400, "event"))
            savedPlaceDao.insertSavedPlace(SavedPlace("Oracle Park", "24 Willie Mays Plaza, San Francisco", 37.7786, -122.3893, "event"))
            savedPlaceDao.insertSavedPlace(SavedPlace("LA Union Station", "800 N Alameda St, Los Angeles", 34.0562, -118.2365, "favorite"))
            savedPlaceDao.insertSavedPlace(SavedPlace("San Jose Diridon", "65 Cahill St, San Jose", 37.3301, -121.9022, "favorite"))
            savedPlaceDao.insertSavedPlace(SavedPlace("SFO Airport", "San Francisco International Airport", 37.6213, -122.3790, "favorite"))

            // Seed Initial Commutes
            savedCommuteDao.insertSavedCommute(
                SavedCommute(
                    title = "Home → Work",
                    origin = "Home (LA)",
                    destination = "Work (SF)",
                    preferredDeparture = "07:34 AM",
                    preferredOptimization = "Fastest",
                    averageDurationMinutes = 345 // Long distance
                )
            )
            savedCommuteDao.insertSavedCommute(
                SavedCommute(
                    title = "Daily Office",
                    origin = "Riverside",
                    destination = "Los Angeles Union Station",
                    preferredDeparture = "06:50 AM",
                    preferredOptimization = "Least Walking",
                    averageDurationMinutes = 68
                )
            )

            // Seed some past completed travel history
            travelHistoryDao.insertTravelHistory(
                TravelHistory(
                    origin = "San Diego Depot",
                    destination = "Los Angeles Union Station",
                    miles = 126.0,
                    carbonSaved = 42.5,
                    timestamp = System.currentTimeMillis() - 86400000 * 2,
                    agenciesUsed = "MTS, NCTD, Amtrak Pacific Surfliner"
                )
            )
            travelHistoryDao.insertTravelHistory(
                TravelHistory(
                    origin = "Oakland Coliseum",
                    destination = "Sacramento Valley Station",
                    miles = 85.4,
                    carbonSaved = 28.8,
                    timestamp = System.currentTimeMillis() - 86400000 * 5,
                    agenciesUsed = "BART, Amtrak Capitol Corridor"
                )
            )
            travelHistoryDao.insertTravelHistory(
                TravelHistory(
                    origin = "San Jose Diridon",
                    destination = "San Francisco 4th & King",
                    miles = 46.8,
                    carbonSaved = 15.6,
                    timestamp = System.currentTimeMillis() - 86400000 * 7,
                    agenciesUsed = "Caltrain"
                )
            )

            // Seed an active digital ticket so the wallet is populated
            ticketDao.insertTicket(
                Ticket(
                    ticketId = "CA-ONE-7629",
                    agencyName = "Caltrain",
                    origin = "San Jose Diridon",
                    destination = "San Francisco 4th & King",
                    departureTime = "10:42 AM",
                    fare = 10.50,
                    passengerName = "Jane Doe"
                )
            )
            ticketDao.insertTicket(
                Ticket(
                    ticketId = "CA-ONE-0914",
                    agencyName = "Metrolink",
                    origin = "Riverside",
                    destination = "LA Union Station",
                    departureTime = "06:50 AM",
                    fare = 8.75,
                    passengerName = "Jane Doe"
                )
            )
        }
    }
}
