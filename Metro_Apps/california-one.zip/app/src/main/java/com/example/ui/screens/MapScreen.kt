package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.routing.MockTransitData
import com.example.routing.VehicleSimulation
import com.example.ui.TransitScreen
import com.example.ui.TransitViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(viewModel: TransitViewModel) {
    val vehicles by viewModel.simulatedVehicles.collectAsState()
    val selectedVehicle by viewModel.selectedVehicle.collectAsState()
    var mapZoom by remember { mutableStateOf(1.0f) } // 1.0 = STATE, 2.0 = REGION, 4.0 = CITY, 8.0 = STATION
    var mapOffset by remember { mutableStateOf(Offset(0f, 0f)) }

    // Mode Filter state
    var selectedModeFilter by remember { mutableStateOf("ALL") } // ALL, RAIL, METRO, BUS, FERRY
    val modes = listOf("ALL", "🚆 RAIL", "🚇 METRO", "🚌 BUS", "⛴ FERRY")

    val filteredVehicles = remember(vehicles, selectedModeFilter) {
        if (selectedModeFilter == "ALL") vehicles else {
            val rawFilter = selectedModeFilter.split(" ").last()
            vehicles.filter { it.routeName.lowercase().contains(rawFilter.lowercase()) || it.routeName.lowercase().contains("surfliner") && rawFilter == "RAIL" }
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .testTag("map_screen")
    ) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()

        // Statewide interactive canvas map
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        mapZoom = (mapZoom * zoom).coerceIn(1.0f, 10.0f)
                        mapOffset = Offset(
                            x = (mapOffset.x + pan.x).coerceIn(-width * mapZoom, width * mapZoom),
                            y = (mapOffset.y + pan.y).coerceIn(-height * mapZoom, height * mapZoom)
                        )
                    }
                }
        ) {
            // Draw California Background Silhouette (Geometric Approximation for abstract modernism)
            val calPath = Path().apply {
                // Approximate coordinate mapping (from Eureka to San Diego)
                val eureka = scaleCoords(40.8, -124.1, width, height, mapZoom, mapOffset)
                val shasta = scaleCoords(41.3, -122.3, width, height, mapZoom, mapOffset)
                val tahoe = scaleCoords(39.0, -120.0, width, height, mapZoom, mapOffset)
                val needles = scaleCoords(34.8, -114.6, width, height, mapZoom, mapOffset)
                val sd = scaleCoords(32.5, -117.1, width, height, mapZoom, mapOffset)
                val la = scaleCoords(34.0, -118.4, width, height, mapZoom, mapOffset)
                val sb = scaleCoords(34.4, -119.7, width, height, mapZoom, mapOffset)
                val monterey = scaleCoords(36.6, -121.9, width, height, mapZoom, mapOffset)
                val sf = scaleCoords(37.8, -122.4, width, height, mapZoom, mapOffset)

                moveTo(eureka.x, eureka.y)
                lineTo(shasta.x, shasta.y)
                lineTo(tahoe.x, tahoe.y)
                lineTo(needles.x, needles.y)
                lineTo(sd.x, sd.y)
                lineTo(la.x, la.y)
                lineTo(sb.x, sb.y)
                lineTo(monterey.x, monterey.y)
                lineTo(sf.x, sf.y)
                close()
            }

            // Draw Coastline Fill
            drawPath(
                path = calPath,
                color = WarmSurface.copy(alpha = 0.08f)
            )
            // Draw Border
            drawPath(
                path = calPath,
                color = ConcreteGrey.copy(alpha = 0.2f),
                style = Stroke(width = 2f)
            )

            // Draw major transit corridors connecting cities
            val surflinerRoute = listOf("SD_DEPOT", "OCEANSIDE", "FULLERTON", "LA_UNION", "SANTA_BARBARA")
            drawCorridor(surflinerRoute, OceanBlue, width, height, mapZoom, mapOffset)

            val caltrainRoute = listOf("SJ_DIRIDON", "PALO_ALTO", "SF_4TH_KING")
            drawCorridor(caltrainRoute, CalRedOrange, width, height, mapZoom, mapOffset)

            val capitolRoute = listOf("SJ_DIRIDON", "OAK_JACK_LONDON", "SF_FERRY_BLDG", "SAC_VALLEY", "DAVIS")
            drawCorridor(capitolRoute, MutedYellow, width, height, mapZoom, mapOffset)

            val valleyRoute = listOf("LA_UNION", "BAKERSFIELD", "FRESNO", "STOCKTON", "SAC_VALLEY")
            drawCorridor(valleyRoute, PacificGreen, width, height, mapZoom, mapOffset)

            // Draw Stations (Stops)
            MockTransitData.stops.forEach { stop ->
                val pos = scaleCoords(stop.latitude, stop.longitude, width, height, mapZoom, mapOffset)
                // Draw Stop Indicator Glow
                drawCircle(
                    color = Color.White.copy(alpha = 0.15f),
                    radius = 12f * mapZoom,
                    center = pos
                )
                // Core dot
                drawCircle(
                    color = if (stop.id == "LA_UNION" || stop.id == "SF_4TH_KING" || stop.id == "SJ_DIRIDON") CalRedOrange else Color.White,
                    radius = 4f * mapZoom.coerceAtMost(3f),
                    center = pos
                )
            }
        }

        // Floating Overlay Controllers: Top Mode selector
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Live counters banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GraphiteSurface.copy(alpha = 0.95f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("2,481", color = CalRedOrange, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("VEHICLES", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    VerticalDivider(color = Color.Gray.copy(alpha = 0.3f), modifier = Modifier.height(20.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("14,832", color = OceanBlue, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("ACTIVE TRIPS", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    VerticalDivider(color = Color.Gray.copy(alpha = 0.3f), modifier = Modifier.height(20.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("98.2%", color = SignalOnTime, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("ON SCHEDULE", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    VerticalDivider(color = Color.Gray.copy(alpha = 0.3f), modifier = Modifier.height(20.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("312", color = SignalMinorDelay, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("ALERTS", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Mode horizontal list
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(modes) { mode ->
                    val plainMode = mode.split(" ").last()
                    val isSelected = selectedModeFilter == plainMode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(30.dp))
                            .background(if (isSelected) CalRedOrange else GraphiteSurface.copy(alpha = 0.85f))
                            .clickable { selectedModeFilter = plainMode }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(mode, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        // Live Vehicles Indicators (drawn as overlay composables on top of canvas for easy tap interaction!)
        filteredVehicles.forEach { vehicle ->
            val pos = scaleCoords(vehicle.latitude, vehicle.longitude, width, height, mapZoom, mapOffset)

            // Ensure pos is inside view bounds
            if (pos.x in 0f..width && pos.y in 0f..height) {
                Box(
                    modifier = Modifier
                        .offset(
                            x = (pos.x / 3).dp, // Scale down screen offset coordinates
                            y = (pos.y / 3).dp
                        )
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(
                            if (selectedVehicle?.vehicleId == vehicle.vehicleId) CalRedOrange else OceanBlue
                        )
                        .border(1.5.dp, Color.White, CircleShape)
                        .clickable { viewModel.selectVehicleOnMap(vehicle) },
                    contentAlignment = Alignment.Center
                ) {
                    val icon = when {
                        vehicle.routeName.lowercase().contains("bus") -> "🚌"
                        vehicle.routeName.lowercase().contains("ferry") -> "⛴"
                        else -> "🚆"
                    }
                    Text(icon, fontSize = 10.sp)
                }
            }
        }

        // Zoom & Pan Controllers (Bottom Left)
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
                .width(48.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FloatingActionButton(
                onClick = { mapZoom = (mapZoom + 0.5f).coerceAtMost(10f) },
                containerColor = GraphiteSurface,
                contentColor = Color.White,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In")
            }
            FloatingActionButton(
                onClick = { mapZoom = (mapZoom - 0.5f).coerceAtLeast(1.0f) },
                containerColor = GraphiteSurface,
                contentColor = Color.White,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out")
            }
            FloatingActionButton(
                onClick = {
                    mapZoom = 1.0f
                    mapOffset = Offset(0f, 0f)
                    viewModel.selectVehicleOnMap(null)
                },
                containerColor = GraphiteSurface,
                contentColor = Color.White,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Reset View")
            }
        }

        // Segmented Zoom Presets: STATE, REGION, CITY, STATION (Bottom center overlay)
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 90.dp)
                .background(GraphiteSurface.copy(alpha = 0.95f), RoundedCornerShape(20.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ZoomPresetButton("STATE", active = mapZoom < 2.0f) {
                mapZoom = 1.0f
                mapOffset = Offset(0f, 0f)
            }
            ZoomPresetButton("REGION", active = mapZoom in 2.0f..3.9f) {
                mapZoom = 3.0f
                mapOffset = Offset(-50f, -100f)
            }
            ZoomPresetButton("CITY", active = mapZoom in 4.0f..6.9f) {
                mapZoom = 5.0f
                mapOffset = Offset(-150f, -250f)
            }
            ZoomPresetButton("STATION", active = mapZoom >= 7.0f) {
                mapZoom = 8.0f
                mapOffset = Offset(-250f, -400f)
            }
        }

        // Vehicle Detail Info Sheet (Sliding from bottom when selected)
        AnimatedVisibility(
            visible = selectedVehicle != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
                .padding(bottom = 70.dp)
        ) {
            selectedVehicle?.let { vehicle ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("🛰", fontSize = 18.sp)
                                Text(
                                    text = vehicle.routeName.uppercase(),
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            Badge(
                                containerColor = if (vehicle.status == "ON TIME") SignalOnTime else SignalMinorDelay,
                                contentColor = Color.White
                            ) {
                                Text(vehicle.status, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }

                        Text(
                            text = "NEXT STOP: ${MockTransitData.stops.find { it.id == vehicle.nextStopId }?.name ?: vehicle.nextStopId}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("VEHICLE ID: ${vehicle.vehicleId}", fontSize = 11.sp, color = Color.Gray)
                                Text("ETA: In ${vehicle.minutesToArrival} minutes", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    // Focus transit screen to station departures
                                    viewModel.setFocusedStation(vehicle.nextStopId)
                                    viewModel.navigateTo(TransitScreen.STATION_DETAIL)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CalRedOrange)
                            ) {
                                Text("STATION DETAILS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Text(
                            text = "DEMO REALTIME FEED ACTIVE",
                            fontSize = 9.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ZoomPresetButton(text: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (active) CalRedOrange else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
    }
}

// Coordinate Scaling function to fit California bounding box elegantly inside screen constraints
fun scaleCoords(
    lat: Double,
    lng: Double,
    width: Float,
    height: Float,
    zoom: Float,
    offset: Offset
): Offset {
    // California bounds approx: Lat 32.5 to 42.0, Lng -124.5 to -114.0
    val latMin = 32.0
    val latMax = 42.0
    val lngMin = -125.0
    val lngMax = -113.0

    // Map percentage coordinates
    val xPct = (lng - lngMin) / (lngMax - lngMin)
    val yPct = 1.0 - ((lat - latMin) / (latMax - latMin)) // Flip Y for screen canvas coords

    val baseWidth = width * 0.8f
    val baseHeight = height * 0.8f
    val startX = width * 0.1f
    val startY = height * 0.1f

    val x = (startX + xPct * baseWidth).toFloat()
    val y = (startY + yPct * baseHeight).toFloat()

    // Apply Zoom & Pan Offset around center of screen
    val centerX = width / 2
    val centerY = height / 2

    val zoomedX = (x - centerX) * zoom + centerX + offset.x
    val zoomedY = (y - centerY) * zoom + centerY + offset.y

    return Offset(zoomedX, zoomedY)
}

// Draws corridor connectors with glow paths on map
fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCorridor(
    stopsSeq: List<String>,
    color: Color,
    width: Float,
    height: Float,
    zoom: Float,
    offset: Offset
) {
    if (stopsSeq.size < 2) return
    for (i in 0 until stopsSeq.size - 1) {
        val s1 = MockTransitData.stops.find { it.id == stopsSeq[i] } ?: continue
        val s2 = MockTransitData.stops.find { it.id == stopsSeq[i + 1] } ?: continue

        val p1 = scaleCoords(s1.latitude, s1.longitude, width, height, zoom, offset)
        val p2 = scaleCoords(s2.latitude, s2.longitude, width, height, zoom, offset)

        drawLine(
            color = color.copy(alpha = 0.5f),
            start = p1,
            end = p2,
            strokeWidth = 3f * zoom.coerceAtMost(2.5f)
        )
    }
}
