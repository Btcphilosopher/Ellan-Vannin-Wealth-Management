package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MetroRed = Color(0xFFFF3B30)
val MetroRedDark = Color(0xFFCC2E26)
val SurfaceDark = Color(0xFF0F1115)
val SurfaceDarkElevated = Color(0xFF1E293B) // slate-800
val SurfaceDarkElevatedHigher = Color(0xFF334155) // slate-700
val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFF94A3B8) // slate-400
val NavBackground = Color(0xFF16191F)
val BorderDark = Color(0xFF334155) // slate-700

val LineCore = Color(0xFFFF3B30)
val LineRhymney = Color(0xFF10B981) // emerald-500
val LineBarry = Color(0xFF3B82F6) // blue-500
val LineTreherbert = Color(0xFFEF4444) // red-500

val BackgroundLight = Color(0xFF0F1115) // Force dark mode
val SurfaceLight = Color(0xFF0F1115)
val SurfaceLightElevated = Color(0xFF1E293B)
val TextPrimaryLight = Color(0xFFFFFFFF)
val TextSecondaryLight = Color(0xFF94A3B8)

val SuccessGreen = Color(0xFF34D399) // emerald-400
val WarningOrange = Color(0xFFF59E0B) // amber-500
val ErrorRed = Color(0xFFEF4444) // red-500
