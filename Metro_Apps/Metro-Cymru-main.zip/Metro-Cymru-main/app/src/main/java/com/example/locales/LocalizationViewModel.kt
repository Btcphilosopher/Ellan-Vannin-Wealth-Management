package com.example.locales

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.InputStream

class LocalizationViewModel(application: Application) : AndroidViewModel(application) {
    private val _currentLanguage = MutableStateFlow("en")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    private val _strings = MutableStateFlow<Map<String, String>>(emptyMap())
    val strings: StateFlow<Map<String, String>> = _strings.asStateFlow()

    init {
        loadStrings("en")
    }

    fun setLanguage(lang: String) {
        if (_currentLanguage.value != lang) {
            _currentLanguage.value = lang
            loadStrings(lang)
        }
    }

    fun toggleLanguage() {
        val newLang = if (_currentLanguage.value == "en") "cy" else "en"
        setLanguage(newLang)
    }

    private fun loadStrings(lang: String) {
        try {
            val inputStream: InputStream = getApplication<Application>().assets.open("locales/$lang/common.json")
            val jsonString = inputStream.bufferedReader().use { it.readText() }
            val jsonObject = JSONObject(jsonString)
            
            val map = mutableMapOf<String, String>()
            val keys = jsonObject.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                map[key] = jsonObject.getString(key)
            }
            _strings.value = map
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback to empty if fails
        }
    }
}
