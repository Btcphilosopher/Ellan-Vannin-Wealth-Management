package com.example.ui.screens.more

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.locales.LocalizationViewModel
import com.example.ui.theme.MetroRed
import com.example.ui.theme.SurfaceDarkElevated

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(locVM: LocalizationViewModel) {
    val strings by locVM.strings.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(strings["nav_more"] ?: "More", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Spacer(modifier = Modifier.height(8.dp)) }
            
            item {
                Text(strings["language"] ?: "Language", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    ListItem(
                        headlineContent = { Text(strings["english"] ?: "English") },
                        leadingContent = { Icon(Icons.Filled.Language, contentDescription = null, tint = MetroRed) },
                        colors = ListItemDefaults.colors(containerColor = SurfaceDarkElevated),
                        modifier = Modifier.clickable { locVM.setLanguage("en") }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f))
                    ListItem(
                        headlineContent = { Text(strings["welsh"] ?: "Cymraeg") },
                        leadingContent = { Icon(Icons.Filled.Language, contentDescription = null, tint = MetroRed) },
                        colors = ListItemDefaults.colors(containerColor = SurfaceDarkElevated),
                        modifier = Modifier.clickable { locVM.setLanguage("cy") }
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
            
            item {
                Text("NETWORK", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    ListItem(
                        headlineContent = { Text(strings["network_status"] ?: "Network Status") },
                        leadingContent = { Icon(Icons.Filled.Info, contentDescription = null, tint = MetroRed) },
                        colors = ListItemDefaults.colors(containerColor = SurfaceDarkElevated),
                        modifier = Modifier.clickable { }
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
            
            item {
                Text("ACCESSIBILITY", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    ListItem(
                        headlineContent = { Text("Accessibility Preferences") },
                        leadingContent = { Icon(Icons.Filled.AccessibilityNew, contentDescription = null, tint = MetroRed) },
                        colors = ListItemDefaults.colors(containerColor = SurfaceDarkElevated),
                        modifier = Modifier.clickable { }
                    )
                }
            }
        }
    }
}
