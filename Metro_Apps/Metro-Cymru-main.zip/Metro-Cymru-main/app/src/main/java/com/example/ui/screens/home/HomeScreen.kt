package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.data.mock.DemoData
import com.example.locales.LocalizationViewModel
import com.example.ui.theme.MetroRed
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.SurfaceDarkElevatedHigher

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(locVM: LocalizationViewModel, navController: NavController) {
    val strings by locVM.strings.collectAsState()
    val isWelsh by locVM.currentLanguage.collectAsState()

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("METRO CYMRU", style = MaterialTheme.typography.labelMedium, color = com.example.ui.theme.TextSecondaryDark, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row {
                        Text("Bore da, ", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Caerdydd", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MetroRed)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Good morning, Cardiff", style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.TextSecondaryDark)
                }
                
                Row(
                    modifier = Modifier
                        .background(SurfaceDarkElevated, RoundedCornerShape(24.dp))
                        .border(1.dp, com.example.ui.theme.BorderDark, RoundedCornerShape(24.dp))
                        .padding(4.dp)
                ) {
                    val cyColor = if (isWelsh == "cy") Color.White else Color.Transparent
                    val cyTextColor = if (isWelsh == "cy") Color.Black else com.example.ui.theme.TextSecondaryDark
                    val enColor = if (isWelsh == "en") Color.White else Color.Transparent
                    val enTextColor = if (isWelsh == "en") Color.Black else com.example.ui.theme.TextSecondaryDark

                    TextButton(
                        onClick = { locVM.setLanguage("cy") },
                        colors = ButtonDefaults.textButtonColors(containerColor = cyColor, contentColor = cyTextColor),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.height(32.dp).padding(horizontal = 4.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                    ) {
                        Text("CY", fontWeight = FontWeight.Bold)
                    }
                    TextButton(
                        onClick = { locVM.setLanguage("en") },
                        colors = ButtonDefaults.textButtonColors(containerColor = enColor, contentColor = enTextColor),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.height(32.dp).padding(horizontal = 4.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                    ) {
                        Text("EN", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                HeroPlannerCard(strings)
            }
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF10B981).copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFF10B981).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(8.dp).background(Color(0xFF10B981), RoundedCornerShape(4.dp)))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Gwasanaeth arferol", color = Color(0xFF34D399), fontWeight = FontWeight.Medium, style = MaterialTheme.typography.labelLarge)
                    Text(" • ", color = Color(0xFF34D399), style = MaterialTheme.typography.labelLarge)
                    Text("Service running normally", color = Color(0xFF34D399).copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge)
                }
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = (strings["near_you"] ?: "Yn agos atat / Near you").uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = com.example.ui.theme.TextSecondaryDark,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "LIVE 10:42",
                        style = MaterialTheme.typography.labelSmall,
                        color = com.example.ui.theme.TextSecondaryDark
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                NearYouCard(strings, "Caerdydd Canolog", "Cardiff Central • Platfform 3", MetroRed, 2)
                Spacer(modifier = Modifier.height(12.dp))
                NearYouCard(strings, "Queen Street", "Heol y Frenhines • Platfform 2", SurfaceDarkElevatedHigher, 5)
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f).height(96.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF059669)), // emerald-600
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp).fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(Icons.Filled.Home, contentDescription = "Home", tint = Color.White)
                            Column {
                                Text("Adref", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.White)
                                Text("GO HOME", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f))
                            }
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f).height(96.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevatedHigher.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, com.example.ui.theme.BorderDark)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp).fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(Icons.Filled.Nfc, contentDescription = "PAYG", tint = com.example.ui.theme.SuccessGreen)
                            Column {
                                Text("PAYG", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.White)
                                Text("TAP & TRAVEL", style = MaterialTheme.typography.labelSmall, color = com.example.ui.theme.TextSecondaryDark)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HeroPlannerCard(strings: Map<String, String>) {
    OutlinedTextField(
        value = "",
        onValueChange = {},
        placeholder = { Text("Ble wyt ti'n mynd? / Where are you going?", color = com.example.ui.theme.TextSecondaryDark) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = com.example.ui.theme.TextSecondaryDark) },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = SurfaceDarkElevatedHigher.copy(alpha = 0.5f),
            focusedContainerColor = SurfaceDarkElevatedHigher.copy(alpha = 0.5f),
            unfocusedBorderColor = com.example.ui.theme.BorderDark,
            focusedBorderColor = MetroRed
        )
    )
}

@Composable
fun NearYouCard(strings: Map<String, String>, title: String, subtitle: String, iconBgColor: Color, nextMins: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, com.example.ui.theme.BorderDark)
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(iconBgColor, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.DirectionsTransit, contentDescription = "Train", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(subtitle, style = MaterialTheme.typography.labelMedium, color = com.example.ui.theme.TextSecondaryDark)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.Bottom) {
                    val color = if (nextMins <= 2) com.example.ui.theme.SuccessGreen else MaterialTheme.colorScheme.onBackground
                    Text(nextMins.toString(), style = MaterialTheme.typography.headlineMedium, color = color, fontWeight = FontWeight.Bold)
                    Text(" mun", style = MaterialTheme.typography.labelMedium, color = color, modifier = Modifier.padding(bottom = 6.dp))
                }
                Text("NEXT", style = MaterialTheme.typography.labelSmall, color = com.example.ui.theme.TextSecondaryDark, fontWeight = FontWeight.Bold)
            }
        }
    }
}
