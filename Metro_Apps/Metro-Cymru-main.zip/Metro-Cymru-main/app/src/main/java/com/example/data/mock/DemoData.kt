package com.example.data.mock

import com.example.data.models.*

object DemoData {
    val stations = listOf(
        Station("crd", "Cardiff Central", "Caerdydd Canolog", listOf("core")),
        Station("cqs", "Cardiff Queen Street", "Caerdydd Heol y Frenhines", listOf("core")),
        Station("cdb", "Cardiff Bay", "Bae Caerdydd", listOf("core")),
        Station("cth", "Cathays", "Cathays", listOf("core")),
        Station("hth", "Heath High Level", "Lefel Uchel y Mynydd Bychan", listOf("core")),
        Station("cph", "Caerphilly", "Caerffili", listOf("rhymney")),
        Station("pty", "Pontypridd", "Pontypridd", listOf("core", "treherbert")),
        // more stations could be added
    )

    val networkStatus = listOf(
        LineStatus("core", "Cardiff Core", "Craidd Caerdydd", "running_normally", 0xFFD31145),
        LineStatus("rhymney", "Rhymney", "Rhymni", "minor_delays", 0xFF007A33),
        LineStatus("barry", "Barry", "Y Barri", "running_normally", 0xFF005EB8),
        LineStatus("treherbert", "Treherbert", "Treherbert", "major_disruption", 0xFFE03C31)
    )

    val departuresCardiffCentral = listOf(
        Departure("1", "Pontypridd", "Pontypridd", "1", 2, "core"),
        Departure("2", "Barry", "Y Barri", "4", 7, "barry"),
        Departure("3", "Caerphilly", "Caerffili", "3", 12, "rhymney"),
        Departure("4", "Cardiff Bay", "Bae Caerdydd", "6", 15, "core")
    )
    
    val departuresQueenStreet = listOf(
        Departure("5", "Cardiff Bay", "Bae Caerdydd", "2", 4, "core"),
        Departure("6", "Treherbert", "Treherbert", "3", 9, "treherbert")
    )
}
