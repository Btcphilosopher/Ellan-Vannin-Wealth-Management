package com.example.ui.screens.journey

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.locales.LocalizationViewModel
import com.example.ui.theme.MetroRed
import com.example.ui.theme.SurfaceDarkElevated

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyScreen(locVM: LocalizationViewModel) {
    val strings by locVM.strings.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(strings["plan_journey"] ?: "Plan Journey", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(strings["fastest"] ?: "FASTEST", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            JourneyResultCard(
                strings = strings,
                title = "Cardiff Central  →  Pontypridd",
                mode = "Metro",
                duration = "27 min",
                leaves = "18:14",
                arrives = "18:41",
                isFastest = true
            )

            Text(strings["cheapest"] ?: "CHEAPEST", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            JourneyResultCard(
                strings = strings,
                title = "Cardiff Central  →  Pontypridd",
                mode = "Metro + Bus",
                duration = "34 min",
                price = "£3.30",
                isFastest = false
            )

            Text(strings["least_walking"] ?: "LEAST WALKING", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            JourneyResultCard(
                strings = strings,
                title = "Cardiff Central  →  Pontypridd",
                mode = "Metro",
                duration = "31 min",
                walking = "320m",
                isFastest = false
            )
        }
    }
}

@Composable
fun JourneyResultCard(
    strings: Map<String, String>,
    title: String,
    mode: String,
    duration: String,
    leaves: String? = null,
    arrives: String? = null,
    price: String? = null,
    walking: String? = null,
    isFastest: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceDarkElevated),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(mode, color = MetroRed, fontWeight = FontWeight.Medium)
                Text(duration, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(12.dp))
            if (leaves != null && arrives != null) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${strings["leaves"] ?: "Leaves"} $leaves", style = MaterialTheme.typography.bodyMedium)
                    Text("${strings["arrives"] ?: "Arrives"} $arrives", style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (price != null) {
                Text(price, style = MaterialTheme.typography.bodyMedium)
            }
            if (walking != null) {
                Text("$walking ${strings["walk"]?.lowercase() ?: "walking"}", style = MaterialTheme.typography.bodyMedium)
            }
            
            if (isFastest) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), contentColor = MetroRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(strings["view_journey"] ?: "VIEW JOURNEY", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
