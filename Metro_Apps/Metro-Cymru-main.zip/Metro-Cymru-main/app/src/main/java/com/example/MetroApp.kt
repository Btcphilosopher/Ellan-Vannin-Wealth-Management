package com.example

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.locales.LocalizationViewModel
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.journey.JourneyScreen
import com.example.ui.screens.map.MapScreen
import com.example.ui.screens.tickets.TicketsScreen
import com.example.ui.screens.more.MoreScreen

sealed class Screen(val route: String, val icon: ImageVector, val labelKey: String) {
    object Home : Screen("home", Icons.Filled.Home, "nav_home")
    object Journey : Screen("journey", Icons.Filled.DirectionsTransit, "nav_journey")
    object Map : Screen("map", Icons.Filled.Map, "nav_map")
    object Tickets : Screen("tickets", Icons.Filled.ConfirmationNumber, "nav_tickets")
    object More : Screen("more", Icons.Filled.MoreHoriz, "nav_more")
}

@Composable
fun MetroApp(locVM: LocalizationViewModel = viewModel()) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Home.route

    val strings by locVM.strings.collectAsState()

    val screens = listOf(
        Screen.Home,
        Screen.Journey,
        Screen.Map,
        Screen.Tickets,
        Screen.More
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = com.example.ui.theme.NavBackground,
                contentColor = com.example.ui.theme.TextSecondaryDark,
                windowInsets = WindowInsets.navigationBars
            ) {
                screens.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = strings[screen.labelKey] ?: screen.route) },
                        label = { androidx.compose.material3.Text(strings[screen.labelKey] ?: screen.route, style = androidx.compose.material3.MaterialTheme.typography.labelMedium) },
                        selected = currentRoute == screen.route,
                        colors = androidx.compose.material3.NavigationBarItemDefaults.colors(
                            selectedIconColor = com.example.ui.theme.MetroRed,
                            selectedTextColor = com.example.ui.theme.MetroRed,
                            unselectedIconColor = com.example.ui.theme.TextSecondaryDark,
                            unselectedTextColor = com.example.ui.theme.TextSecondaryDark,
                            indicatorColor = androidx.compose.ui.graphics.Color.Transparent
                        ),
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            NavHost(navController = navController, startDestination = Screen.Home.route) {
                composable(Screen.Home.route) { HomeScreen(locVM, navController) }
                composable(Screen.Journey.route) { JourneyScreen(locVM) }
                composable(Screen.Map.route) { MapScreen(locVM) }
                composable(Screen.Tickets.route) { TicketsScreen(locVM) }
                composable(Screen.More.route) { MoreScreen(locVM) }
            }
        }
    }
}
