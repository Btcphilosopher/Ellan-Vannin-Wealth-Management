package com.example.data.models

data class Station(
    val id: String,
    val nameEn: String,
    val nameCy: String,
    val lines: List<String>
) {
    fun name(lang: String) = if (lang == "cy") nameCy else nameEn
}

data class LineStatus(
    val id: String,
    val nameEn: String,
    val nameCy: String,
    val statusKey: String, // "running_normally", "minor_delays", "major_disruption"
    val color: Long
)

data class Departure(
    val id: String,
    val destinationEn: String,
    val destinationCy: String,
    val platform: String,
    val expectedInMins: Int,
    val lineId: String
) {
    fun destination(lang: String) = if (lang == "cy") destinationCy else destinationEn
}

data class Journey(
    val fromStationId: String,
    val toStationId: String,
    val durationMins: Int,
    val leavesAt: String,
    val arrivesAt: String,
    val price: String = "£3.30",
    val changes: Int = 0
)
