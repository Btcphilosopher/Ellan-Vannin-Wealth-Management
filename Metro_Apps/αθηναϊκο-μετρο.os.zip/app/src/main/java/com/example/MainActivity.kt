package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.data.MetroRepository
import com.example.data.db.MetroDatabase
import com.example.ui.AthensMetroOSApp
import com.example.ui.MainViewModel
import com.example.ui.MainViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Core dependency provisioning
        val database = MetroDatabase.getDatabase(applicationContext, lifecycleScope)
        val repository = MetroRepository(database.metroDao(), lifecycleScope)
        
        // Instantiate central MainViewModel cleanly
        val viewModel: MainViewModel by viewModels {
            MainViewModelFactory(repository)
        }

        setContent {
            MyApplicationTheme {
                AthensMetroOSApp(viewModel = viewModel)
            }
        }
    }
}
