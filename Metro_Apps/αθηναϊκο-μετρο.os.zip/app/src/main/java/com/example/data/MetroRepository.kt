package com.example.data

import android.content.Context
import com.example.data.db.MetroDao
import com.example.data.db.MetroDatabase
import com.example.data.model.AuditLogEntity
import com.example.data.model.LineEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.SavedRouteEntity
import com.example.data.model.StationEntity
import com.example.data.model.StationLineCrossRef
import com.example.data.model.TrackSegment
import com.example.routing.MetroRoutingEngine
import com.example.routing.RoutePlan
import com.example.routing.RoutePreference
import com.example.simulation.MetroSimulationEngine
import com.example.simulation.SimArrival
import com.example.simulation.SimTrain
import com.example.simulation.SimWeather
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MetroRepository(
    private val dao: MetroDao,
    private val scope: CoroutineScope
) {
    // Database Flows
    val allLines: Flow<List<LineEntity>> = dao.getAllLines()
    val allStations: Flow<List<StationEntity>> = dao.getAllStations()
    val crossRefs: Flow<List<StationLineCrossRef>> = dao.getStationLineCrossRefs()
    val trackSegments: Flow<List<TrackSegment>> = dao.getAllTrackSegments()
    val savedRoutes: Flow<List<SavedRouteEntity>> = dao.getSavedRoutes()
    val notifications: Flow<List<NotificationEntity>> = dao.getNotifications()
    val auditLogs: Flow<List<AuditLogEntity>> = dao.getAuditLogs()

    // Simulation State Flows (MutableStateFlows to allow interactive scrubbing!)
    private val _simMinutes = MutableStateFlow(480) // default 08:00 AM (8 * 60)
    val simMinutes: StateFlow<Int> = _simMinutes.asStateFlow()

    private val _simWeather = MutableStateFlow(SimWeather.SUNNY)
    val simWeather: StateFlow<SimWeather> = _simWeather.asStateFlow()

    private val _simSeed = MutableStateFlow(12345L)
    val simSeed: StateFlow<Long> = _simSeed.asStateFlow()

    // Active simulated disruptions & delays (sets of line IDs)
    private val _disruptedLines = MutableStateFlow<Set<String>>(emptySet()) // suspended
    val disruptedLines: StateFlow<Set<String>> = _disruptedLines.asStateFlow()

    private val _delayedLines = MutableStateFlow<Set<String>>(emptySet()) // minor delays
    val delayedLines: StateFlow<Set<String>> = _delayedLines.asStateFlow()

    fun updateSimMinutes(minutes: Int) {
        _simMinutes.value = minutes.coerceIn(0, 1439)
        scope.launch {
            dao.insertAuditLog(
                AuditLogEntity(
                    action = "SIMULATION_TIME_SCRUB",
                    details = "Simulation time adjusted to ${formatMinutesToTime(minutes)}."
                )
            )
        }
    }

    fun updateSimWeather(weather: SimWeather) {
        _simWeather.value = weather
        scope.launch {
            dao.insertAuditLog(
                AuditLogEntity(
                    action = "WEATHER_CHANGE",
                    details = "Weather condition set to ${weather.name}."
                )
            )
        }
    }

    fun toggleDisruption(lineId: String) {
        val current = _disruptedLines.value
        val updated = if (current.contains(lineId)) current - lineId else current + lineId
        _disruptedLines.value = updated
        scope.launch {
            val status = if (updated.contains(lineId)) "SUSPENDED" else "RESTORED"
            dao.insertAuditLog(
                AuditLogEntity(
                    action = "DISRUPTION_TOGGLE",
                    details = "Service status of $lineId set to $status."
                )
            )
            // Trigger in-app notification
            if (status == "SUSPENDED") {
                dao.insertNotification(
                    NotificationEntity(
                        titleKey = "disruption_alert",
                        bodyKey = "suspended_service"
                    )
                )
            } else {
                dao.insertNotification(
                    NotificationEntity(
                        titleKey = "normal_service",
                        bodyKey = "normal_service"
                    )
                )
            }
        }
    }

    fun toggleDelay(lineId: String) {
        val current = _delayedLines.value
        val updated = if (current.contains(lineId)) current - lineId else current + lineId
        _delayedLines.value = updated
        scope.launch {
            val status = if (updated.contains(lineId)) "DELAYED" else "NORMAL"
            dao.insertAuditLog(
                AuditLogEntity(
                    action = "DELAY_TOGGLE",
                    details = "Traffic status of $lineId set to $status."
                )
            )
            if (status == "DELAYED") {
                dao.insertNotification(
                    NotificationEntity(
                        titleKey = "minor_delay",
                        bodyKey = "minor_delay"
                    )
                )
            }
        }
    }

    // Database Actions
    suspend fun saveRoute(from: String, to: String, label: String, pref: RoutePreference) {
        dao.insertSavedRoute(
            SavedRouteEntity(
                fromStationId = from,
                toStationId = to,
                label = label,
                preference = pref.name
            )
        )
        dao.insertAuditLog(
            AuditLogEntity(
                action = "ROUTE_SAVED",
                details = "Saved journey from $from to $to as '$label' with preference ${pref.name}."
            )
        )
    }

    suspend fun deleteSavedRoute(id: Int) {
        dao.deleteSavedRoute(id)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "ROUTE_DELETED",
                details = "Deleted saved journey ID $id."
            )
        )
    }

    suspend fun clearNotifications() {
        dao.clearAllNotifications()
    }

    // Routing Calculation Wrapper
    suspend fun planRoute(
        fromId: String,
        toId: String,
        preference: RoutePreference
    ): RoutePlan? {
        val stationsMap = allStations.first().associateBy { it.id }
        val segs = trackSegments.first()
        val refs = crossRefs.first()
        return MetroRoutingEngine.findRoute(
            startId = fromId,
            endId = toId,
            stations = stationsMap,
            segments = segs,
            crossRefs = refs,
            preference = preference,
            disruptedLines = _disruptedLines.value,
            delayedLines = _delayedLines.value
        )
    }

    // Simulation Output Wrappers
    suspend fun getSimulatedTrainsOnLine(lineId: String): List<SimTrain> {
        return MetroSimulationEngine.getSimulatedTrains(
            lineId = lineId,
            simMinutes = _simMinutes.value,
            seed = _simSeed.value,
            stations = allStations.first(),
            crossRefs = crossRefs.first(),
            segments = trackSegments.first()
        )
    }

    suspend fun getArrivalsAtStation(stationId: String): List<SimArrival> {
        return MetroSimulationEngine.getSimulatedArrivals(
            stationId = stationId,
            simMinutes = _simMinutes.value,
            seed = _simSeed.value,
            stations = allStations.first(),
            crossRefs = crossRefs.first(),
            segments = trackSegments.first()
        )
    }

    private fun formatMinutesToTime(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return String.format("%02d:%02d", h, m)
    }
}
