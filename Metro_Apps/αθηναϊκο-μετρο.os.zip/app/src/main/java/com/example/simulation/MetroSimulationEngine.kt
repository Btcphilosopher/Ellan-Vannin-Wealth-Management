package com.example.simulation

import com.example.data.model.LineEntity
import com.example.data.model.StationEntity
import com.example.data.model.StationLineCrossRef
import com.example.data.model.TrackSegment
import com.example.localisation.AppLanguage
import java.util.Random

enum class SimWeather {
    SUNNY,
    RAINY,
    HEATWAVE,
    STRONG_WINDS
}

enum class SimDemand {
    LOW,
    MEDIUM,
    HIGH,
    PEAK
}

data class SimTrain(
    val id: String,
    val lineId: String,
    val direction: String, // Destination station name/id
    val currentStationId: String,
    val nextStationId: String,
    val progressPercent: Float, // 0.0f..1.0f on current segment
    val occupancy: String, // Low, Medium, High, Very High
    val currentTrackSegmentId: String
)

data class SimArrival(
    val destinationEl: String,
    val minutesAway: Int,
    val platform: Int,
    val occupancy: String
)

object MetroSimulationEngine {

    /**
     * Determines the global demand level based on simulation minutes since midnight.
     */
    fun getDemandLevel(minutes: Int): SimDemand {
        return when {
            minutes in 450..570 -> SimDemand.PEAK   // 07:30 - 09:30
            minutes in 1020..1140 -> SimDemand.PEAK // 17:00 - 19:00
            minutes in 571..1019 -> SimDemand.HIGH  // Daytime
            minutes in 360..449 -> SimDemand.MEDIUM // Early Morning
            minutes in 1141..1440 -> SimDemand.LOW  // Late Night
            else -> SimDemand.LOW                   // Overnight (00:00 - 06:00)
        }
    }

    /**
     * Estimates headway frequency (in minutes) based on line ID and demand level.
     */
    fun getHeadwayMinutes(lineId: String, demand: SimDemand): Int {
        return when (lineId) {
            "L1" -> when (demand) {
                SimDemand.PEAK -> 4
                SimDemand.HIGH -> 6
                SimDemand.MEDIUM -> 8
                SimDemand.LOW -> 12
            }
            "L2" -> when (demand) {
                SimDemand.PEAK -> 3
                SimDemand.HIGH -> 5
                SimDemand.MEDIUM -> 7
                SimDemand.LOW -> 10
            }
            "L3" -> when (demand) {
                SimDemand.PEAK -> 4
                SimDemand.HIGH -> 5
                SimDemand.MEDIUM -> 6
                SimDemand.LOW -> 10
            }
            else -> 6
        }
    }

    /**
     * Generates a deterministic list of simulated trains on a line for a given timestamp.
     */
    fun getSimulatedTrains(
        lineId: String,
        simMinutes: Int,
        seed: Long,
        stations: List<StationEntity>,
        crossRefs: List<StationLineCrossRef>,
        segments: List<TrackSegment>
    ): List<SimTrain> {
        val rand = Random(seed + lineId.hashCode() + simMinutes / 5) // stable seed for window

        // Filter stations and cross-refs belonging to this line, sorted by order
        val lineCrossRefs = crossRefs.filter { it.lineId == lineId }.sortedBy { it.sequenceOrder }
        if (lineCrossRefs.size < 2) return emptyList()

        val orderedStationIds = lineCrossRefs.map { it.stationId }
        val lineStations = orderedStationIds.mapNotNull { id -> stations.find { it.id == id } }

        // Find track segments along the line
        val forwardSegments = mutableListOf<TrackSegment>()
        for (i in 0 until orderedStationIds.size - 1) {
            val from = orderedStationIds[i]
            val to = orderedStationIds[i + 1]
            val seg = segments.find { it.fromStationId == from && it.toStationId == to && it.lineId == lineId }
                ?: TrackSegment("${from}_${to}", from, to, 180, lineId)
            forwardSegments.add(seg)
        }

        val backwardSegments = mutableListOf<TrackSegment>()
        for (i in orderedStationIds.size - 1 downTo 1) {
            val from = orderedStationIds[i]
            val to = orderedStationIds[i - 1]
            val seg = segments.find { it.fromStationId == from && it.toStationId == to && it.lineId == lineId }
                ?: TrackSegment("${from}_${to}", from, to, 180, lineId)
            backwardSegments.add(seg)
        }

        val forwardDuration = forwardSegments.sumOf { it.travelTimeSeconds }
        val backwardDuration = backwardSegments.sumOf { it.travelTimeSeconds }
        val totalRoundTripTime = forwardDuration + backwardDuration + 120 // add terminal dwell times

        val demand = getDemandLevel(simMinutes)
        val headwaySeconds = getHeadwayMinutes(lineId, demand) * 60
        val numTrains = (totalRoundTripTime / headwaySeconds).coerceAtLeast(2)

        val trains = mutableListOf<SimTrain>()

        for (k in 0 until numTrains) {
            // Compute deterministic offset for this train
            val trainOffset = k * headwaySeconds
            val simSeconds = (simMinutes * 60) + (seed % 300).toInt() // shift with seed slightly
            val currentProgressSec = (simSeconds + trainOffset) % totalRoundTripTime

            // Map progress time to a specific segment and position
            var currentStationId: String
            var nextStationId: String
            var progressPercent: Float
            var direction: String
            var currentTrackId: String

            if (currentProgressSec < forwardDuration) {
                // Forward direction
                direction = lineStations.last().nameEl
                var accumulated = 0
                var segmentIndex = 0
                while (segmentIndex < forwardSegments.size && accumulated + forwardSegments[segmentIndex].travelTimeSeconds <= currentProgressSec) {
                    accumulated += forwardSegments[segmentIndex].travelTimeSeconds
                    segmentIndex++
                }
                val activeSeg = if (segmentIndex < forwardSegments.size) forwardSegments[segmentIndex] else forwardSegments.last()
                val segmentProgress = currentProgressSec - accumulated
                progressPercent = segmentProgress.toFloat() / activeSeg.travelTimeSeconds.toFloat()
                currentStationId = activeSeg.fromStationId
                nextStationId = activeSeg.toStationId
                currentTrackId = activeSeg.id
            } else {
                // Backward direction
                direction = lineStations.first().nameEl
                val backwardProgress = currentProgressSec - forwardDuration - 60 // account for dwell
                if (backwardProgress <= 0) {
                    // Dwell at end terminal
                    currentStationId = lineStations.last().id
                    nextStationId = lineStations[lineStations.size - 2].id
                    progressPercent = 0.0f
                    currentTrackId = backwardSegments.first().id
                } else {
                    var accumulated = 0
                    var segmentIndex = 0
                    while (segmentIndex < backwardSegments.size && accumulated + backwardSegments[segmentIndex].travelTimeSeconds <= backwardProgress) {
                        accumulated += backwardSegments[segmentIndex].travelTimeSeconds
                        segmentIndex++
                    }
                    val activeSeg = if (segmentIndex < backwardSegments.size) backwardSegments[segmentIndex] else backwardSegments.last()
                    val segmentProgress = backwardProgress - accumulated
                    progressPercent = segmentProgress.coerceAtLeast(0).toFloat() / activeSeg.travelTimeSeconds.toFloat()
                    currentStationId = activeSeg.fromStationId
                    nextStationId = activeSeg.toStationId
                    currentTrackId = activeSeg.id
                }
            }

            // Determine occupancy based on time and a random seed-based variance
            val occupancyRand = (rand.nextInt(100) + k * 7) % 100
            val occupancy = when {
                demand == SimDemand.PEAK -> if (occupancyRand < 70) "occupancy_very_high" else "occupancy_high"
                demand == SimDemand.HIGH -> if (occupancyRand < 50) "occupancy_high" else "occupancy_medium"
                demand == SimDemand.MEDIUM -> if (occupancyRand < 60) "occupancy_medium" else "occupancy_low"
                else -> "occupancy_low"
            }

            trains.add(
                SimTrain(
                    id = "TRN-${lineId}-${k + 1}",
                    lineId = lineId,
                    direction = direction,
                    currentStationId = currentStationId,
                    nextStationId = nextStationId,
                    progressPercent = progressPercent.coerceIn(0f, 1f),
                    occupancy = occupancy,
                    currentTrackSegmentId = currentTrackId
                )
            )
        }

        return trains
    }

    /**
     * Calculates simulated upcoming arrivals at a station.
     */
    fun getSimulatedArrivals(
        stationId: String,
        simMinutes: Int,
        seed: Long,
        stations: List<StationEntity>,
        crossRefs: List<StationLineCrossRef>,
        segments: List<TrackSegment>
    ): List<SimArrival> {
        val stationLines = crossRefs.filter { it.stationId == stationId }.map { it.lineId }
        val arrivals = mutableListOf<SimArrival>()

        for (lineId in stationLines) {
            val trains = getSimulatedTrains(lineId, simMinutes, seed, stations, crossRefs, segments)
            // Filter trains moving towards this station
            for (train in trains) {
                // Find station orders
                val lineStations = crossRefs.filter { it.lineId == lineId }.sortedBy { it.sequenceOrder }.map { it.stationId }
                val targetIndex = lineStations.indexOf(stationId)
                val currentTrainIndex = lineStations.indexOf(train.currentStationId)
                val nextTrainIndex = lineStations.indexOf(train.nextStationId)

                // Check if train is headed towards our station
                val isHeadedToUs = if (train.direction == lineStations.last()) {
                    // Train going forward (ascending index)
                    currentTrainIndex <= targetIndex && targetIndex >= nextTrainIndex
                } else {
                    // Train going backward (descending index)
                    currentTrainIndex >= targetIndex && targetIndex <= nextTrainIndex
                }

                if (isHeadedToUs) {
                    // Estimate travel seconds remaining
                    var timeRemainingSeconds = 0
                    if (train.currentStationId == stationId) {
                        timeRemainingSeconds = ((1f - train.progressPercent) * 15).toInt() // very close, dwell or exiting
                    } else {
                        // Accumulate track times
                        val path = mutableListOf<String>()
                        if (train.direction == lineStations.last()) {
                            for (i in nextTrainIndex..targetIndex) {
                                path.add(lineStations[i])
                            }
                        } else {
                            for (i in nextTrainIndex downTo targetIndex) {
                                path.add(lineStations[i])
                            }
                        }

                        var seconds = 0
                        // Segment we are currently on:
                        val activeSeg = segments.find { it.fromStationId == train.currentStationId && it.toStationId == train.nextStationId && it.lineId == lineId }
                        if (activeSeg != null) {
                            seconds += ((1f - train.progressPercent) * activeSeg.travelTimeSeconds).toInt()
                        }
                        // Rest of the segments:
                        for (j in 0 until path.size - 1) {
                            val from = path[j]
                            val to = path[j + 1]
                            val seg = segments.find { it.fromStationId == from && it.toStationId == to && it.lineId == lineId }
                            seconds += (seg?.travelTimeSeconds ?: 180) + 30 // add 30s dwell at each stop
                        }
                        timeRemainingSeconds = seconds
                    }

                    val minutesAway = (timeRemainingSeconds / 60).coerceAtLeast(1)
                    if (minutesAway < 20) {
                        arrivals.add(
                            SimArrival(
                                destinationEl = train.direction,
                                minutesAway = minutesAway,
                                platform = if (train.direction == lineStations.last()) 1 else 2,
                                occupancy = train.occupancy
                            )
                        )
                    }
                }
            }
        }

        // Return sorted by arrival time
        val sorted = arrivals.sortedBy { it.minutesAway }
        if (sorted.isEmpty()) {
            // Generate some default deterministic fallbacks if none are moving towards us right now
            val rand = Random((stationId.hashCode() + simMinutes).toLong())
            val fallbackDestinations = when (stationId) {
                "syntagma" -> listOf("Ελληνικό", "Ανθούπολη", "Δημοτικό Θέατρο", "Αεροδρόμιο")
                "monastiraki" -> listOf("Κηφισιά", "Πειραιάς", "Δημοτικό Θέατρο", "Αεροδρόμιο")
                else -> listOf("Κηφισιά", "Πειραιάς", "Ανθούπολη", "Ελληνικό", "Δημοτικό Θέατρο", "Αεροδρόμιο")
            }
            val destination = fallbackDestinations[rand.nextInt(fallbackDestinations.size)]
            return listOf(
                SimArrival(destination, 2, 1, "occupancy_low"),
                SimArrival(destination, 8, 1, "occupancy_medium"),
                SimArrival(destination, 13, 2, "occupancy_low")
            )
        }
        return sorted
    }
}
