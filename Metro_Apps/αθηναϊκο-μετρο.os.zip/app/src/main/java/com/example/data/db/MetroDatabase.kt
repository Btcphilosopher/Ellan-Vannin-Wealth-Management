package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AuditLogEntity
import com.example.data.model.LineEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.SavedRouteEntity
import com.example.data.model.StationEntity
import com.example.data.model.StationLineCrossRef
import com.example.data.model.TrackSegment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        LineEntity::class,
        StationEntity::class,
        StationLineCrossRef::class,
        TrackSegment::class,
        SavedRouteEntity::class,
        NotificationEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MetroDatabase : RoomDatabase() {
    abstract fun metroDao(): MetroDao

    companion object {
        @Volatile
        private var INSTANCE: MetroDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): MetroDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MetroDatabase::class.java,
                    "athens_metro_os_db"
                )
                .addCallback(MetroDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class MetroDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDb(database.metroDao())
                }
            }
        }

        suspend fun populateDb(dao: MetroDao) {
            // 1. Pre-seed lines
            val lines = listOf(
                LineEntity("L1", "Γραμμή 1: Πειραιάς - Κηφισιά", "0xFF00A14B", "L1"),
                LineEntity("L2", "Γραμμή 2: Ανθούπολη - Ελληνικό", "0xFFDA291C", "L2"),
                LineEntity("L3", "Γραμμή 3: Δημοτικό Θέατρο - Αεροδρόμιο", "0xFF0065BD", "L3")
            )
            dao.insertLines(lines)

            // 2. Pre-seed Stations (with coordinates on our relative grid 0..100)
            val stations = listOf(
                // Line 1 Stations
                StationEntity(
                    "piraeus", "Πειραιάς", "PIR", 15.0, 80.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Λιμάνι Πειραιά. Ανταπόκριση με Προαστιακό και Πλοία.",
                    infoDetailsAn = "Λιμὴν Πειραιῶς. Μετάβασις εἰς τὸν προαστιακὸν σιδηρόδρομον καὶ τὰ πλοῖα.",
                    exitsList = "Έξοδος Α: Λιμάνι (Πύλες Ε5/Ε6),Έξοδος Β: Πλατεία Οδησσού",
                    nearbyPlaces = "piraeus_port"
                ),
                StationEntity(
                    "thiseio", "Θησείο", "THI", 32.0, 68.0,
                    hasElevator = false, hasEscalator = false, isStepFree = false,
                    infoDetailsEl = "Ιστορικό κέντρο. Θέα προς την Ακρόπολη και Αρχαία Αγορά.",
                    infoDetailsAn = "Ἱστορικὸν κέντρον. Θέα πρὸς τὴν Ἀκρόπολιν καὶ τὴν Ἀρχαίαν Ἀγοράν.",
                    exitsList = "Έξοδος Α: Οδός Αδριανού",
                    nearbyPlaces = "acropolis"
                ),
                StationEntity(
                    "monastiraki", "Μοναστηράκι", "MON", 40.0, 60.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Κεντρικός κόμβος. Σύνδεση Γ1 και Γ3. Αρχαιολογικά ευρήματα εντός.",
                    infoDetailsAn = "Κεντρικὸς κόμβος. Σύνδεσμος Γ1 καὶ Γ3. Ἀρχαιολογικὰ εὑρήματα ἐντός.",
                    exitsList = "Έξοδος Α: Πλατεία Μοναστηρακίου,Έξοδος Β: Οδός Αθηνάς",
                    nearbyPlaces = "monastiraki_flea,acropolis"
                ),
                StationEntity(
                    "omonia", "Ομόνοια", "OMO", 40.0, 45.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Κεντρική πλατεία. Σύνδεση Γ1 και Γ2.",
                    infoDetailsAn = "Κεντρικὴ πλατεῖα. Σύνδεσμος Γ1 καὶ Γ2.",
                    exitsList = "Έξοδος Α: Πλατεία Ομονοίας,Έξοδος Β: Οδός Σταδίου",
                    nearbyPlaces = "national_library"
                ),
                StationEntity(
                    "victoria", "Βικτώρια", "VIC", 40.0, 35.0,
                    hasElevator = false, hasEscalator = true, isStepFree = false,
                    infoDetailsEl = "Περιοχή Πατησίων. Κοντά στο Εθνικό Αρχαιολογικό Μουσείο.",
                    infoDetailsAn = "Πλησίον τοῦ Ἐθνικοῦ Ἀρχαιολογικοῦ Μουσείου.",
                    exitsList = "Έξοδος Α: Πλατεία Βικτωρίας",
                    nearbyPlaces = "museums"
                ),
                StationEntity(
                    "attiki", "Αττική", "ATT", 40.0, 25.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Συγκοινωνιακός κόμβος Γ1 και Γ2.",
                    infoDetailsAn = "Σύνδεσμος Γ1 καὶ Γ2.",
                    exitsList = "Έξοδος Α: Οδός Λιοσίων",
                    nearbyPlaces = ""
                ),
                StationEntity(
                    "neratziotissa", "Νερατζιώτισσα", "NER", 65.0, 20.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Σύνδεση με Προαστιακό σιδηρόδρομο και εμπορικά κέντρα.",
                    infoDetailsAn = "Μετάβασις εἰς τὸν προαστιακόν.",
                    exitsList = "Έξοδος Α: Εμπορικό Κέντρο,Έξοδος Β: Οδός Νερατζιωτίσσης",
                    nearbyPlaces = ""
                ),
                StationEntity(
                    "kifisia", "Κηφισιά", "KIF", 80.0, 15.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Βόρεια προάστια. Τερματικός Γραμμής 1.",
                    infoDetailsAn = "Βόρεια προάστεια. Τέρμα τῆς Γραμμῆς 1.",
                    exitsList = "Έξοδος Α: Πλατεία Πλατάνου,Έξοδος Β: Οδός Κηφισίας",
                    nearbyPlaces = ""
                ),

                // Line 2 Stations
                StationEntity(
                    "anthoupoli", "Ανθούπολη", "ANT", 15.0, 25.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Τερματικός σταθμός Γραμμής 2 στα δυτικά προάστια.",
                    infoDetailsAn = "Τέρμα τῆς Γραμμῆς 2 πρὸς δυσμάς.",
                    exitsList = "Έξοδος Α: Οδός Αναπαύσεως",
                    nearbyPlaces = ""
                ),
                StationEntity(
                    "peristeri", "Περιστέρι", "PER", 23.0, 25.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Κεντρικός σταθμός Δήμου Περιστερίου.",
                    infoDetailsAn = "Κέντρον τοῦ Περιστερίου.",
                    exitsList = "Έξοδος Α: Δημαρχείο Περιστερίου",
                    nearbyPlaces = ""
                ),
                StationEntity(
                    "sepolia", "Σεπόλια", "SEP", 31.0, 25.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Ιστορική γειτονιά της Αθήνας. Κοντά στο αμαξοστάσιο.",
                    infoDetailsAn = "Ἱστορικὴ γειτονία τῆς Ἀττικῆς.",
                    exitsList = "Έξοδος Α: Οδός Αντιγόνης",
                    nearbyPlaces = ""
                ),
                StationEntity(
                    "panepistimio", "Πανεπιστήμιο", "UNI", 45.0, 50.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Νεοκλασική Τριλογία της Αθήνας. Εθνική Βιβλιοθήκη.",
                    infoDetailsAn = "Νεοκλασικὴ Τριλογία. Ἐθνικὴ Βιβλιοθήκη καὶ Ἀκαδημία.",
                    exitsList = "Έξοδος Α: Πανεπιστημίου,Έξοδος Β: Οδός Ακαδημίας",
                    nearbyPlaces = "national_library,academic_hub"
                ),
                StationEntity(
                    "syntagma", "Σύνταγμα", "SYN", 50.0, 60.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Η καρδιά της Αθήνας. Βουλή των Ελλήνων. Μουσείο Σταθμού.",
                    infoDetailsAn = "Ἡ καρδία τῶν Ἀθηνῶν. Βουλὴ τῶν Ἑλλήνων. Μουσεῖον Σταθμοῦ.",
                    exitsList = "Έξοδος Α: Πλατεία Συντάγματος,Έξοδος Β: Οδός Αμαλίας (Βουλή)",
                    nearbyPlaces = "syntagma_sq,museums"
                ),
                StationEntity(
                    "akropoli", "Ακρόπολη", "ACR", 50.0, 70.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Κάτω από τον Ιερό Βράχο. Δίπλα στο Μουσείο Ακρόπολης.",
                    infoDetailsAn = "Ὑπὸ τὸν Ἱερὸν Βράχον. Πλησίον τοῦ Μουσείου Ἀκροπόλεως.",
                    exitsList = "Έξοδος Α: Οδός Μακρυγιάννη,Έξοδος Β: Οδός Διονυσίου Αρεοπαγίτου",
                    nearbyPlaces = "acropolis_museum,acropolis"
                ),
                StationEntity(
                    "syngrou_fix", "Συγγρού-Φιξ", "FIX", 50.0, 78.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Ανταπόκριση με Τραμ. Εθνικό Μουσείο Σύγχρονης Τέχνης.",
                    infoDetailsAn = "Μετάβασις εἰς τὸν τροχιόδρομον (Τράμ).",
                    exitsList = "Έξοδος Α: Λεωφόρος Συγγρού,Έξοδος Β: Οδός Δράκου",
                    nearbyPlaces = "museums"
                ),
                StationEntity(
                    "elliniko", "Ελληνικό", "ELL", 50.0, 90.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Νότια προάστια. Τερματικός Γ2. Μητροπολιτικό Πάρκο.",
                    infoDetailsAn = "Νότια προάστεια. Τέρμα τῆς Γραμμῆς 2.",
                    exitsList = "Έξοδος Α: Λεωφόρος Βουλιαγμένης",
                    nearbyPlaces = ""
                ),

                // Line 3 Stations
                StationEntity(
                    "dimotiko_theatro", "Δημοτικό Θέατρο", "THE", 10.0, 85.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Κέντρο Πειραιά. Νεοκλασικό Δημοτικό Θέατρο.",
                    infoDetailsAn = "Κέντρον Πειραιῶς. Νεοκλασικὸν Δημοτικὸν Θέατρον.",
                    exitsList = "Έξοδος Α: Πλατεία Κοραή,Έξοδος Β: Δημοτικό Θέατρο",
                    nearbyPlaces = "piraeus_port"
                ),
                StationEntity(
                    "evangelismos", "Ευαγγελισμός", "EVA", 58.0, 60.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Περιοχή Κολωνακίου. Εθνική Πινακοθήκη και νοσοκομεία.",
                    infoDetailsAn = "Πλησίον τῆς Ἐθνικῆς Πινακοθήκης.",
                    exitsList = "Έξοδος Α: Λεωφόρος Βασιλίσσης Σοφίας",
                    nearbyPlaces = "museums"
                ),
                StationEntity(
                    "megaro_moussikis", "Μέγαρο Μουσικής", "MEG", 66.0, 60.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Μέγαρο Μουσικής Αθηνών. Πρεσβείες.",
                    infoDetailsAn = "Μέγαρον Μουσικῆς Ἀθηνῶν.",
                    exitsList = "Έξοδος Α: Μέγαρο Μουσικής",
                    nearbyPlaces = ""
                ),
                StationEntity(
                    "ambelokipi", "Αμπελόκηποι", "AMB", 74.0, 60.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Κοντά στη ΓΑΔΑ και τα δικαστήρια.",
                    infoDetailsAn = "Δικαστήρια καὶ ἀστυνομικὸν μέγαρον.",
                    exitsList = "Έξοδος Α: Λεωφόρος Αλεξάνδρας",
                    nearbyPlaces = ""
                ),
                StationEntity(
                    "doukissis_plakentias", "Δουκίσσης Πλακεντίας", "PLA", 82.0, 60.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Κόμβος με Προαστιακό. Σημείο διακλάδωσης προς Αεροδρόμιο.",
                    infoDetailsAn = "Σύνδεσμος πρὸς τὸν προαστιακόν.",
                    exitsList = "Έξοδος Α: Οδός Ηρακλείτου",
                    nearbyPlaces = ""
                ),
                StationEntity(
                    "pallini", "Παλλήνη", "PAL", 88.0, 65.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Σταθμός στην Ανατολική Αττική. Κοινή χρήση με Προαστιακό.",
                    infoDetailsAn = "Σταθμὸς ἐν τῇ Ἀνατολικῇ Ἀττικῇ.",
                    exitsList = "Έξοδος Α: Λεωφόρος Μαραθώνος",
                    nearbyPlaces = ""
                ),
                StationEntity(
                    "airport", "Αεροδρόμιο", "AIR", 92.0, 75.0,
                    hasElevator = true, hasEscalator = true, isStepFree = true,
                    infoDetailsEl = "Διεθνής Αερολιμένας Αθηνών «Ελευθέριος Βενιζέλος».",
                    infoDetailsAn = "Διεθνὴς Ἀερολιμὴν Ἀθηνῶν «Ἐλευθέριος Βενιζέλος».",
                    exitsList = "Έξοδος Α: Αεροδρόμιο (Αφίξεις/Αναχωρήσεις)",
                    nearbyPlaces = "airport"
                )
            )
            dao.insertStations(stations)

            // 3. Pre-seed junction cross-references representing lines structure
            val crossRefs = listOf(
                // Line 1 CrossRefs
                StationLineCrossRef("piraeus", "L1", 1),
                StationLineCrossRef("thiseio", "L1", 2),
                StationLineCrossRef("monastiraki", "L1", 3),
                StationLineCrossRef("omonia", "L1", 4),
                StationLineCrossRef("victoria", "L1", 5),
                StationLineCrossRef("attiki", "L1", 6),
                StationLineCrossRef("neratziotissa", "L1", 7),
                StationLineCrossRef("kifisia", "L1", 8),

                // Line 2 CrossRefs
                StationLineCrossRef("anthoupoli", "L2", 1),
                StationLineCrossRef("peristeri", "L2", 2),
                StationLineCrossRef("sepolia", "L2", 3),
                StationLineCrossRef("attiki", "L2", 4),
                StationLineCrossRef("omonia", "L2", 5),
                StationLineCrossRef("panepistimio", "L2", 6),
                StationLineCrossRef("syntagma", "L2", 7),
                StationLineCrossRef("akropoli", "L2", 8),
                StationLineCrossRef("syngrou_fix", "L2", 9),
                StationLineCrossRef("elliniko", "L2", 10),

                // Line 3 CrossRefs
                StationLineCrossRef("dimotiko_theatro", "L3", 1),
                StationLineCrossRef("monastiraki", "L3", 2),
                StationLineCrossRef("syntagma", "L3", 3),
                StationLineCrossRef("evangelismos", "L3", 4),
                StationLineCrossRef("megaro_moussikis", "L3", 5),
                StationLineCrossRef("ambelokipi", "L3", 6),
                StationLineCrossRef("doukissis_plakentias", "L3", 7),
                StationLineCrossRef("pallini", "L3", 8),
                StationLineCrossRef("airport", "L3", 9)
            )
            dao.insertCrossRefs(crossRefs)

            // 4. Pre-seed Track Segments
            val segments = listOf(
                // Line 1 connections
                TrackSegment("piraeus_thiseio", "piraeus", "thiseio", 360, "L1"),
                TrackSegment("thiseio_piraeus", "thiseio", "piraeus", 360, "L1"),
                TrackSegment("thiseio_monastiraki", "thiseio", "monastiraki", 120, "L1"),
                TrackSegment("monastiraki_thiseio", "monastiraki", "thiseio", 120, "L1"),
                TrackSegment("monastiraki_omonia", "monastiraki", "omonia", 120, "L1"),
                TrackSegment("omonia_monastiraki", "omonia", "monastiraki", 120, "L1"),
                TrackSegment("omonia_victoria", "omonia", "victoria", 120, "L1"),
                TrackSegment("victoria_omonia", "victoria", "omonia", 120, "L1"),
                TrackSegment("victoria_attiki", "victoria", "attiki", 120, "L1"),
                TrackSegment("attiki_victoria", "attiki", "victoria", 120, "L1"),
                TrackSegment("attiki_neratziotissa", "attiki", "neratziotissa", 720, "L1"),
                TrackSegment("neratziotissa_attiki", "neratziotissa", "attiki", 720, "L1"),
                TrackSegment("neratziotissa_kifisia", "neratziotissa", "kifisia", 300, "L1"),
                TrackSegment("kifisia_neratziotissa", "kifisia", "neratziotissa", 300, "L1"),

                // Line 2 connections
                TrackSegment("anthoupoli_peristeri", "anthoupoli", "peristeri", 120, "L2"),
                TrackSegment("peristeri_anthoupoli", "peristeri", "anthoupoli", 120, "L2"),
                TrackSegment("peristeri_sepolia", "peristeri", "sepolia", 120, "L2"),
                TrackSegment("sepolia_peristeri", "sepolia", "peristeri", 120, "L2"),
                TrackSegment("sepolia_attiki", "sepolia", "attiki", 120, "L2"),
                TrackSegment("attiki_sepolia", "attiki", "sepolia", 120, "L2"),
                TrackSegment("attiki_omonia", "attiki", "omonia", 180, "L2"),
                TrackSegment("omonia_attiki", "omonia", "attiki", 180, "L2"),
                TrackSegment("omonia_panepistimio", "omonia", "panepistimio", 120, "L2"),
                TrackSegment("panepistimio_omonia", "panepistimio", "omonia", 120, "L2"),
                TrackSegment("panepistimio_syntagma", "panepistimio", "syntagma", 120, "L2"),
                TrackSegment("syntagma_panepistimio", "syntagma", "panepistimio", 120, "L2"),
                TrackSegment("syntagma_akropoli", "syntagma", "akropoli", 120, "L2"),
                TrackSegment("akropoli_syntagma", "akropoli", "syntagma", 120, "L2"),
                TrackSegment("akropoli_syngrou_fix", "akropoli", "syngrou_fix", 120, "L2"),
                TrackSegment("syngrou_fix_akropoli", "syngrou_fix", "akropoli", 120, "L2"),
                TrackSegment("syngrou_fix_elliniko", "syngrou_fix", "elliniko", 720, "L2"),
                TrackSegment("elliniko_syngrou_fix", "elliniko", "syngrou_fix", 720, "L2"),

                // Line 3 connections
                TrackSegment("dimotiko_theatro_monastiraki", "dimotiko_theatro", "monastiraki", 600, "L3"),
                TrackSegment("monastiraki_dimotiko_theatro", "monastiraki", "dimotiko_theatro", 600, "L3"),
                TrackSegment("monastiraki_syntagma", "monastiraki", "syntagma", 120, "L3"),
                TrackSegment("syntagma_monastiraki", "syntagma", "monastiraki", 120, "L3"),
                TrackSegment("syntagma_evangelismos", "syntagma", "evangelismos", 120, "L3"),
                TrackSegment("evangelismos_syntagma", "evangelismos", "syntagma", 120, "L3"),
                TrackSegment("evangelismos_megaro_moussikis", "evangelismos", "megaro_moussikis", 120, "L3"),
                TrackSegment("megaro_moussikis_evangelismos", "megaro_moussikis", "evangelismos", 120, "L3"),
                TrackSegment("megaro_moussikis_ambelokipi", "megaro_moussikis", "ambelokipi", 120, "L3"),
                TrackSegment("ambelokipi_megaro_moussikis", "ambelokipi", "megaro_moussikis", 120, "L3"),
                TrackSegment("ambelokipi_doukissis_plakentias", "ambelokipi", "doukissis_plakentias", 480, "L3"),
                TrackSegment("doukissis_plakentias_ambelokipi", "doukissis_plakentias", "ambelokipi", 480, "L3"),
                TrackSegment("doukissis_plakentias_pallini", "doukissis_plakentias", "pallini", 300, "L3"),
                TrackSegment("pallini_doukissis_plakentias", "pallini", "doukissis_plakentias", 300, "L3"),
                TrackSegment("pallini_airport", "pallini", "airport", 900, "L3"),
                TrackSegment("airport_pallini", "airport", "pallini", 900, "L3")
            )
            dao.insertTrackSegments(segments)

            // 5. Audit Log Seed
            dao.insertAuditLog(
                AuditLogEntity(
                    action = "INITIALIZATION",
                    details = "Athens Metro OS database initialized successfully. Pre-seeded 3 lines, 23 stations, and track topology."
                )
            )

            // 6. Pre-seed welcome notification
            dao.insertNotification(
                NotificationEntity(
                    titleKey = "normal_service",
                    bodyKey = "normal_service"
                )
            )
        }
    }
}
