package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Athenian architectural stone palette
val AthenianMarbleWhite = Color(0xFFFAF9F6)
val AthenianPnyxStone = Color(0xFFE6E2DA)
val AthenianWarmSand = Color(0xFFDCD6CD)
val AthenianGraphite = Color(0xFF1E2120)
val AthenianDeepCharcoal = Color(0xFF141615)

// Metro line colors
val MetroLine1Green = Color(0xFF00A14B)
val MetroLine2Red = Color(0xFFDA291C)
val MetroLine3Blue = Color(0xFF0065BD)

// Accent and status highlights
val MetroAthensBlue = Color(0xFF005DA6)
val MetroAmberCaution = Color(0xFFF39200)
val MetroDarkSlate = Color(0xFF2C3230)
val MetroPistachioLight = Color(0xFFE2F0D9)
val MetroPistachioText = Color(0xFF385723)
val MetroRedLight = Color(0xFFFCE4D6)
val MetroRedText = Color(0xFFC00000)
