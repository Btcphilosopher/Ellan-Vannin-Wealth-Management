package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.AuditLogEntity
import com.example.data.model.LineEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.SavedRouteEntity
import com.example.data.model.StationEntity
import com.example.data.model.StationLineCrossRef
import com.example.data.model.TrackSegment
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {
    // Lines
    @Query("SELECT * FROM lines")
    fun getAllLines(): Flow<List<LineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLines(lines: List<LineEntity>)

    // Stations
    @Query("SELECT * FROM stations")
    fun getAllStations(): Flow<List<StationEntity>>

    @Query("SELECT * FROM stations WHERE id = :id")
    suspend fun getStationById(id: String): StationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)

    // CrossRefs
    @Query("SELECT * FROM station_line_cross_ref")
    fun getStationLineCrossRefs(): Flow<List<StationLineCrossRef>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCrossRefs(crossRefs: List<StationLineCrossRef>)

    // Track Segments
    @Query("SELECT * FROM track_segments")
    fun getAllTrackSegments(): Flow<List<TrackSegment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrackSegments(segments: List<TrackSegment>)

    // Saved Routes
    @Query("SELECT * FROM saved_routes ORDER BY createdAt DESC")
    fun getSavedRoutes(): Flow<List<SavedRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedRoute(route: SavedRouteEntity)

    @Query("DELETE FROM saved_routes WHERE id = :id")
    suspend fun deleteSavedRoute(id: Int)

    // Notifications
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationAsRead(id: Int)

    @Query("DELETE FROM notifications")
    suspend fun clearAllNotifications()

    // Audit Logs
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 50")
    fun getAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)
}
