package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AuditLogEntity
import com.example.data.model.LineEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.SavedRouteEntity
import com.example.data.model.StationEntity
import com.example.data.model.StationLineCrossRef
import com.example.data.model.TrackSegment
import com.example.localisation.*
import com.example.routing.LegType
import com.example.routing.RoutePreference
import com.example.simulation.SimArrival
import com.example.simulation.SimTrain
import com.example.simulation.SimWeather
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AthensMetroOSApp(viewModel: MainViewModel) {
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

    // Wrap the entire tree in our custom translation provider!
    ProvideLanguage(language = currentLang) {
        Scaffold(
            bottomBar = {
                AthensMetroBottomBar(
                    currentScreen = currentScreen,
                    onNavigate = { viewModel.navigateTo(it) }
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    is Screen.Home -> HomeScreen(viewModel)
                    is Screen.Map -> MapScreen(viewModel)
                    is Screen.RoutePlanner -> RoutePlannerScreen(viewModel)
                    is Screen.Stations -> StationsScreen(viewModel)
                    is Screen.SavedJourneys -> SavedJourneysScreen(viewModel)
                    is Screen.Status -> NetworkStatusScreen(viewModel)
                    is Screen.DigitalTwin -> DigitalTwinScreen(viewModel)
                    is Screen.Settings -> SettingsScreen(viewModel)
                    else -> HomeScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun AthensMetroBottomBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit
) {
    NavigationBar(
        containerColor = AthenianGraphite,
        contentColor = AthenianMarbleWhite,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        val homeSelected = currentScreen is Screen.Home
        val mapSelected = currentScreen is Screen.Map
        val routeSelected = currentScreen is Screen.RoutePlanner
        val savedSelected = currentScreen is Screen.SavedJourneys
        val statusSelected = currentScreen is Screen.Status || currentScreen is Screen.DigitalTwin || currentScreen is Screen.Settings

        NavigationBarItem(
            selected = homeSelected,
            onClick = { onNavigate(Screen.Home) },
            icon = { Icon(if (homeSelected) Icons.Filled.Home else Icons.Outlined.Home, contentDescription = "Home") },
            label = { Text(translate("home"), maxLines = 1, fontSize = 11.sp, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AthenianGraphite,
                selectedTextColor = AthenianMarbleWhite,
                indicatorColor = AthenianMarbleWhite,
                unselectedIconColor = AthenianWarmSand,
                unselectedTextColor = AthenianWarmSand
            ),
            modifier = Modifier.testTag("nav_home")
        )

        NavigationBarItem(
            selected = mapSelected,
            onClick = { onNavigate(Screen.Map) },
            icon = { Icon(if (mapSelected) Icons.Filled.Map else Icons.Outlined.Map, contentDescription = "Map") },
            label = { Text(translate("map"), maxLines = 1, fontSize = 11.sp, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AthenianGraphite,
                selectedTextColor = AthenianMarbleWhite,
                indicatorColor = AthenianMarbleWhite,
                unselectedIconColor = AthenianWarmSand,
                unselectedTextColor = AthenianWarmSand
            ),
            modifier = Modifier.testTag("nav_map")
        )

        NavigationBarItem(
            selected = routeSelected,
            onClick = { onNavigate(Screen.RoutePlanner) },
            icon = { Icon(if (routeSelected) Icons.Filled.DirectionsTransit else Icons.Outlined.DirectionsTransit, contentDescription = "Route") },
            label = { Text(translate("route_planner"), maxLines = 1, fontSize = 11.sp, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AthenianGraphite,
                selectedTextColor = AthenianMarbleWhite,
                indicatorColor = AthenianMarbleWhite,
                unselectedIconColor = AthenianWarmSand,
                unselectedTextColor = AthenianWarmSand
            ),
            modifier = Modifier.testTag("nav_route")
        )

        NavigationBarItem(
            selected = savedSelected,
            onClick = { onNavigate(Screen.SavedJourneys) },
            icon = { Icon(if (savedSelected) Icons.Filled.Bookmarks else Icons.Outlined.Bookmarks, contentDescription = "Saved") },
            label = { Text(translate("saved_journeys"), maxLines = 1, fontSize = 11.sp, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AthenianGraphite,
                selectedTextColor = AthenianMarbleWhite,
                indicatorColor = AthenianMarbleWhite,
                unselectedIconColor = AthenianWarmSand,
                unselectedTextColor = AthenianWarmSand
            ),
            modifier = Modifier.testTag("nav_saved")
        )

        NavigationBarItem(
            selected = statusSelected,
            onClick = { onNavigate(Screen.Status) },
            icon = { Icon(if (statusSelected) Icons.Filled.MoreHoriz else Icons.Outlined.MoreHoriz, contentDescription = "More") },
            label = { Text(translate("settings"), maxLines = 1, fontSize = 11.sp, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AthenianGraphite,
                selectedTextColor = AthenianMarbleWhite,
                indicatorColor = AthenianMarbleWhite,
                unselectedIconColor = AthenianWarmSand,
                unselectedTextColor = AthenianWarmSand
            ),
            modifier = Modifier.testTag("nav_more")
        )
    }
}

// Global Header Component
@Composable
fun AppHeader(viewModel: MainViewModel) {
    val lang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val weather by viewModel.simWeather.collectAsStateWithLifecycle()
    val minutes by viewModel.simMinutes.collectAsStateWithLifecycle()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(AthenianGraphite)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = translate("app_title"),
                color = AthenianMarbleWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Text(
                text = translate("app_subtitle"),
                color = AthenianPnyxStone,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Environment Label (CRITICAL - TRANSPARENCY REQUIREMENT)
            Box(
                modifier = Modifier
                    .background(Color(0xFFFFD54F), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "DEMO",
                    color = Color.Black,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Weather Indicator
            Icon(
                imageVector = when (weather) {
                    SimWeather.SUNNY -> Icons.Filled.WbSunny
                    SimWeather.RAINY -> Icons.Filled.Thunderstorm
                    SimWeather.HEATWAVE -> Icons.Filled.DeviceThermostat
                    SimWeather.STRONG_WINDS -> Icons.Filled.Air
                },
                contentDescription = "Weather",
                tint = AthenianMarbleWhite,
                modifier = Modifier.size(16.dp)
            )

            // Dynamic Clock
            Text(
                text = String.format("%02d:%02d", minutes / 60, minutes % 60),
                color = AthenianMarbleWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )

            // Bilingual Toggle Button
            Button(
                onClick = { viewModel.toggleLanguage() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = AthenianMarbleWhite,
                    contentColor = AthenianGraphite
                ),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier
                    .height(28.dp)
                    .testTag("lang_toggle")
            ) {
                Text(
                    text = if (lang == AppLanguage.MODERN) "Ἀρχαῖα" else "Νέα",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// 1. HOME SCREEN
@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val allStations by viewModel.allStations.collectAsStateWithLifecycle()
    val savedRoutes by viewModel.savedRoutes.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var showSearchResults by remember { mutableStateOf(false) }

    val filteredStations = if (searchQuery.isBlank()) emptyList() else {
        allStations.filter {
            it.nameEl.contains(searchQuery, ignoreCase = true) ||
            Translations.getStationName(it.nameEl, AppLanguage.ANCIENT).contains(searchQuery, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(viewModel)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(AthenianMarbleWhite.copy(alpha = 0.5f))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Interactive Prompt Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AthenianGraphite),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = translate("where_to_go"),
                            color = AthenianMarbleWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Search Input
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = {
                                searchQuery = it
                                showSearchResults = it.isNotBlank()
                            },
                            placeholder = { Text(translate("search_placeholder"), color = AthenianWarmSand) },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search", tint = AthenianMarbleWhite) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = ""; showSearchResults = false }) {
                                        Icon(Icons.Filled.Close, contentDescription = "Clear", tint = AthenianMarbleWhite)
                                    }
                                }
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AthenianMarbleWhite,
                                unfocusedBorderColor = AthenianWarmSand,
                                focusedTextColor = AthenianMarbleWhite,
                                unfocusedTextColor = AthenianMarbleWhite,
                                focusedLabelColor = AthenianMarbleWhite
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("station_search_input")
                        )

                        // Search Results dropdown in-place
                        if (showSearchResults && filteredStations.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MetroDarkSlate),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    filteredStations.take(4).forEach { station ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    viewModel.setRouteTo(station.id)
                                                    viewModel.navigateTo(Screen.RoutePlanner)
                                                }
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(translateStation(station.nameEl), color = AthenianMarbleWhite, fontWeight = FontWeight.SemiBold)
                                                Text(station.code, color = AthenianWarmSand, fontSize = 10.sp)
                                            }
                                            Icon(Icons.Filled.ArrowForward, contentDescription = "Go", tint = AthenianMarbleWhite, modifier = Modifier.size(16.dp))
                                        }
                                        HorizontalDivider(color = AthenianWarmSand.copy(alpha = 0.2f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Quick Actions Block
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.navigateTo(Screen.RoutePlanner) },
                        colors = ButtonDefaults.buttonColors(containerColor = MetroAthensBlue),
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                            .testTag("action_planner"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.Route, contentDescription = "Plan")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(translate("route_planner"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Button(
                        onClick = { viewModel.navigateTo(Screen.Map) },
                        colors = ButtonDefaults.buttonColors(containerColor = MetroLine1Green),
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                            .testTag("action_map"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.Map, contentDescription = "Map")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(translate("map"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Notifications / System Warnings Banner
            item {
                val activeWarnings = notifications.filter { !it.isRead }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (activeWarnings.any { it.titleKey == "disruption_alert" }) MetroRedLight else MetroPistachioLight
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (activeWarnings.any { it.titleKey == "disruption_alert" }) MetroRedText else MetroPistachioText
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (activeWarnings.any { it.titleKey == "disruption_alert" }) Icons.Filled.Warning else Icons.Filled.CheckCircle,
                            contentDescription = "Status",
                            tint = if (activeWarnings.any { it.titleKey == "disruption_alert" }) MetroRedText else MetroPistachioText,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            val alertTitle = if (activeWarnings.any { it.titleKey == "disruption_alert" }) "disruption_alert" else "normal_service"
                            val alertDesc = if (activeWarnings.any { it.titleKey == "disruption_alert" }) "suspended_service" else "normal_service"
                            Text(
                                text = translate(alertTitle),
                                color = if (activeWarnings.any { it.titleKey == "disruption_alert" }) MetroRedText else MetroPistachioText,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = translate(alertDesc),
                                color = if (activeWarnings.any { it.titleKey == "disruption_alert" }) MetroRedText.copy(alpha = 0.8f) else MetroPistachioText.copy(alpha = 0.8f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // Quick Bookmarked list
            item {
                Text(
                    text = translate("saved_journeys"),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AthenianGraphite,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            if (savedRoutes.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = AthenianWarmSand, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(translate("no_saved_routes"), color = AthenianWarmSand, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                items(savedRoutes.take(3)) { route ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.setRouteFrom(route.fromStationId)
                                viewModel.setRouteTo(route.toStationId)
                                viewModel.navigateTo(Screen.RoutePlanner)
                            },
                        colors = CardDefaults.cardColors(containerColor = AthenianPnyxStone.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Bookmark, contentDescription = "Saved", tint = MetroAthensBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(route.label, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(
                                        "${translateStation(route.fromStationId)} → ${translateStation(route.toStationId)}",
                                        fontSize = 11.sp,
                                        color = AthenianGraphite.copy(alpha = 0.7f)
                                    )
                                }
                            }
                            Icon(Icons.Filled.ArrowForwardIos, contentDescription = "Go", tint = AthenianGraphite, modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }
        }
    }
}

// 2. INTERACTIVE MAP SCREEN
@Composable
fun MapScreen(viewModel: MainViewModel) {
    val stations by viewModel.allStations.collectAsStateWithLifecycle()
    val lines by viewModel.allLines.collectAsStateWithLifecycle()
    val crossRefs by viewModel.crossRefs.collectAsStateWithLifecycle()
    val simMinutes by viewModel.simMinutes.collectAsStateWithLifecycle()
    val selectedStationId by viewModel.selectedStationId.collectAsStateWithLifecycle()
    val arrivals by viewModel.stationArrivals.collectAsStateWithLifecycle()

    var activeSimTrains by remember { mutableStateOf<List<SimTrain>>(emptyList()) }

    // Fetch simulated trains every second to keep positions sliding!
    LaunchedEffect(simMinutes, stations) {
        if (stations.isNotEmpty()) {
            activeSimTrains = lines.flatMap { line ->
                viewModel.twinTrains.value.filter { it.lineId == line.id }
            }
            // Fallback generation if twin list is empty
            if (activeSimTrains.isEmpty()) {
                val tempTrains = mutableListOf<SimTrain>()
                for (line in lines) {
                    tempTrains.addAll(viewModel.repository.getSimulatedTrainsOnLine(line.id))
                }
                activeSimTrains = tempTrains
            }
        }
    }

    // Trigger rapid redraw tick for trains sliding animation
    val infiniteTransition = rememberInfiniteTransition(label = "train_slide")
    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(viewModel)

        Box(modifier = Modifier.weight(1f)) {
            // Drawn Metro Canvas Map
            MetroNetworkMap(
                stations = stations,
                crossRefs = crossRefs,
                trains = activeSimTrains,
                animTick = animProgress,
                selectedStationId = selectedStationId,
                onStationSelect = { viewModel.selectStation(it) }
            )

            // Dynamic bottom information drawer
            selectedStationId?.let { statId ->
                stations.find { it.id == statId }?.let { station ->
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = AthenianGraphite),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(6.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = translateStation(station.nameEl),
                                            color = AthenianMarbleWhite,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                        Text(
                                            text = "${translate("station_code")}: ${station.code}",
                                            color = AthenianWarmSand,
                                            fontSize = 10.sp
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        if (station.isStepFree) {
                                            Icon(Icons.Filled.Accessible, contentDescription = "Accessible", tint = MetroLine1Green, modifier = Modifier.size(18.dp))
                                        }
                                        if (station.hasElevator) {
                                            Icon(Icons.Filled.Elevator, contentDescription = "Elevator", tint = AthenianMarbleWhite, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Draw simulated upcoming arrivals for selected station
                                Text(translate("arrivals"), color = AthenianWarmSand, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    arrivals.take(2).forEach { arr ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(8.dp)
                                                        .background(if (arr.platform == 1) MetroAthensBlue else MetroLine1Green, CircleShape)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "${translate("to")} ${translateStation(arr.destinationEl)}",
                                                    color = AthenianMarbleWhite,
                                                    fontSize = 12.sp
                                                )
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                // Occupancy indicator
                                                Icon(
                                                    Icons.Filled.People,
                                                    contentDescription = "Occupancy",
                                                    tint = when (arr.occupancy) {
                                                        "occupancy_very_high" -> MetroRedText
                                                        "occupancy_high" -> MetroAmberCaution
                                                        else -> MetroLine1Green
                                                    },
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "${arr.minutesAway} ${translate("minutes")}",
                                                    color = AthenianMarbleWhite,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    TextButton(
                                        onClick = { viewModel.setRouteFrom(station.id) },
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text("${translate("from")}...", color = AthenianMarbleWhite, fontSize = 12.sp)
                                    }
                                    TextButton(
                                        onClick = { viewModel.setRouteTo(station.id) },
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text("${translate("to")}...", color = AthenianMarbleWhite, fontSize = 12.sp)
                                    }
                                    Button(
                                        onClick = {
                                            viewModel.navigateTo(Screen.Stations)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = AthenianMarbleWhite, contentColor = AthenianGraphite),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Text(translate("station_diagram"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetroNetworkMap(
    stations: List<StationEntity>,
    crossRefs: List<StationLineCrossRef>,
    trains: List<SimTrain>,
    animTick: Float,
    selectedStationId: String?,
    onStationSelect: (String) -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(AthenianMarbleWhite)
    ) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(stations) {
                    detectTapGestures { offset ->
                        // Detect click on stations
                        var closestStat: StationEntity? = null
                        var minDist = 40.dp.toPx() // click tolerance radius
                        for (station in stations) {
                            val statX = (station.latitude / 100.0) * width
                            val statY = (station.longitude / 100.0) * height
                            val dx = offset.x - statX
                            val dy = offset.y - statY
                            val dist = java.lang.Math.sqrt(dx * dx + dy * dy)
                            if (dist < minDist) {
                                minDist = dist.toFloat()
                                closestStat = station
                            }
                        }
                        closestStat?.let { onStationSelect(it.id) }
                    }
                }
        ) {
            // Draw Metro Lines track routes
            val lineGroups = crossRefs.groupBy { it.lineId }.mapValues { entry ->
                entry.value.sortedBy { it.sequenceOrder }
            }

            for ((lineId, refs) in lineGroups) {
                val lineColor = when (lineId) {
                    "L1" -> MetroLine1Green
                    "L2" -> MetroLine2Red
                    "L3" -> MetroLine3Blue
                    else -> Color.DarkGray
                }

                for (i in 0 until refs.size - 1) {
                    val fromStat = stations.find { it.id == refs[i].stationId } ?: continue
                    val toStat = stations.find { it.id == refs[i + 1].stationId } ?: continue

                    val startX = (fromStat.latitude / 100.0f) * width
                    val startY = (fromStat.longitude / 100.0f) * height
                    val endX = (toStat.latitude / 100.0f) * width
                    val endY = (toStat.longitude / 100.0f) * height

                    drawLine(
                        color = lineColor,
                        start = Offset(startX.toFloat(), startY.toFloat()),
                        end = Offset(endX.toFloat(), endY.toFloat()),
                        strokeWidth = 14f,
                        cap = StrokeCap.Round
                    )
                }
            }

            // Draw Stations as graphical nodes
            for (station in stations) {
                val statX = ((station.latitude / 100.0) * width).toFloat()
                val statY = ((station.longitude / 100.0) * height).toFloat()

                val isHub = crossRefs.filter { it.stationId == station.id }.size > 1
                val isSelected = station.id == selectedStationId

                // Glow ring if selected
                if (isSelected) {
                    drawCircle(
                        color = MetroAthensBlue.copy(alpha = 0.3f),
                        radius = 42f,
                        center = Offset(statX, statY)
                    )
                }

                // Base node circle
                drawCircle(
                    color = Color.White,
                    radius = if (isHub) 24f else 16f,
                    center = Offset(statX, statY)
                )

                drawCircle(
                    color = AthenianGraphite,
                    radius = if (isHub) 24f else 16f,
                    center = Offset(statX, statY),
                    style = Stroke(width = 6f)
                )

                // Inner core for hub
                if (isHub) {
                    drawCircle(
                        color = AthenianGraphite,
                        radius = 10f,
                        center = Offset(statX, statY)
                    )
                }
            }

            // Draw active simulated trains sliding
            for (train in trains) {
                val fromStat = stations.find { it.id == train.currentStationId } ?: continue
                val toStat = stations.find { it.id == train.nextStationId } ?: continue

                val fX = (fromStat.latitude / 100.0f) * width
                val fY = (fromStat.longitude / 100.0f) * height
                val tX = (toStat.latitude / 100.0f) * width
                val tY = (toStat.longitude / 100.0f) * height

                // Compute exact position with continuous fractional slide progress
                val interpX = fX + (train.progressPercent * (tX - fX))
                val interpY = fY + (train.progressPercent * (tY - fY))

                val trainColor = when (train.lineId) {
                    "L1" -> MetroLine1Green
                    "L2" -> MetroLine2Red
                    "L3" -> MetroLine3Blue
                    else -> Color.Gray
                }

                // Pulsing signal aura
                val auraRadius = 15f + (animTick * 12f)
                drawCircle(
                    color = trainColor.copy(alpha = 0.4f * (1f - animTick)),
                    radius = auraRadius,
                    center = Offset(interpX.toFloat(), interpY.toFloat())
                )

                // Train head node
                drawCircle(
                    color = trainColor,
                    radius = 12f,
                    center = Offset(interpX.toFloat(), interpY.toFloat())
                )
                drawCircle(
                    color = Color.White,
                    radius = 12f,
                    center = Offset(interpX.toFloat(), interpY.toFloat()),
                    style = Stroke(width = 3f)
                )
            }
        }

        // Draw overlay station text labels
        for (station in stations) {
            val statX = ((station.latitude / 100.0) * width).toFloat()
            val statY = ((station.longitude / 100.0) * height).toFloat()
            val isHub = crossRefs.filter { it.stationId == station.id }.size > 1

            Box(
                modifier = Modifier
                    .offset(
                        x = (statX / LocalConfiguration.current.densityDpi * 160).dp - 40.dp,
                        y = (statY / LocalConfiguration.current.densityDpi * 160).dp + if (isHub) 12.dp else 8.dp
                    )
                    .background(AthenianGraphite.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = translateStation(station.nameEl),
                    color = AthenianMarbleWhite,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        }
    }
}

// 3. ROUTE PLANNER SCREEN (WITH DISRUPTION AND ALTERNATIVE RECALCULATION FLOW)
@Composable
fun RoutePlannerScreen(viewModel: MainViewModel) {
    val stations by viewModel.allStations.collectAsStateWithLifecycle()
    val fromId by viewModel.routeFromId.collectAsStateWithLifecycle()
    val toId by viewModel.routeToId.collectAsStateWithLifecycle()
    val pref by viewModel.routePreference.collectAsStateWithLifecycle()
    val routePlan by viewModel.calculatedRoute.collectAsStateWithLifecycle()

    val disruptedLines by viewModel.disruptedLines.collectAsStateWithLifecycle()
    val delayedLines by viewModel.delayedLines.collectAsStateWithLifecycle()

    var showFromMenu by remember { mutableStateOf(false) }
    var showToMenu by remember { mutableStateOf(false) }
    var saveNameQuery by remember { mutableStateOf("") }
    var showSaveDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AthenianMarbleWhite.copy(alpha = 0.5f))
    ) {
        AppHeader(viewModel)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Planning Interface Card
            Card(
                colors = CardDefaults.cardColors(containerColor = AthenianGraphite),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Title
                    Text(translate("route_planner"), color = AthenianMarbleWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                    // Origin Input Row
                    Box {
                        OutlinedButton(
                            onClick = { showFromMenu = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AthenianMarbleWhite),
                            border = BorderStroke(1.dp, AthenianWarmSand),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("origin_selector")
                        ) {
                            Text("${translate("from")}: ${translateStation(stations.find { it.id == fromId }?.nameEl ?: fromId)}")
                        }
                        DropdownMenu(
                            expanded = showFromMenu,
                            onDismissRequest = { showFromMenu = false },
                            modifier = Modifier.background(AthenianGraphite)
                        ) {
                            stations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(translateStation(station.nameEl), color = AthenianMarbleWhite) },
                                    onClick = {
                                        viewModel.setRouteFrom(station.id)
                                        showFromMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Swap Button Row
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        IconButton(
                            onClick = { viewModel.swapRouteStations() },
                            modifier = Modifier
                                .background(AthenianMarbleWhite, CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(Icons.Filled.SwapVert, contentDescription = "Swap", tint = AthenianGraphite)
                        }
                    }

                    // Destination Input Row
                    Box {
                        OutlinedButton(
                            onClick = { showToMenu = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AthenianMarbleWhite),
                            border = BorderStroke(1.dp, AthenianWarmSand),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("destination_selector")
                        ) {
                            Text("${translate("to")}: ${translateStation(stations.find { it.id == toId }?.nameEl ?: toId)}")
                        }
                        DropdownMenu(
                            expanded = showToMenu,
                            onDismissRequest = { showToMenu = false },
                            modifier = Modifier.background(AthenianGraphite)
                        ) {
                            stations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(translateStation(station.nameEl), color = AthenianMarbleWhite) },
                                    onClick = {
                                        viewModel.setRouteTo(station.id)
                                        showToMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Preference Selection Row
                    Text(translate("preferences"), color = AthenianWarmSand, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RoutePreference.values().forEach { preference ->
                            val isSelected = preference == pref
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setRoutePreference(preference) },
                                label = {
                                    Text(
                                        text = when (preference) {
                                            RoutePreference.FASTEST -> translate("fastest_route")
                                            RoutePreference.FEWER_TRANSFERS -> translate("fewer_transfers")
                                            RoutePreference.STEP_FREE -> translate("step_free")
                                            RoutePreference.LESS_WALKING -> translate("less_walking")
                                        },
                                        fontSize = 11.sp
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AthenianMarbleWhite,
                                    selectedLabelColor = AthenianGraphite,
                                    containerColor = AthenianWarmSand.copy(alpha = 0.2f),
                                    labelColor = AthenianMarbleWhite
                                )
                            )
                        }
                    }
                }
            }

            // SIMULATED DISRUPTION TRIGGERS (A MUST FOR VERIFYING ROUTEPLANNING FLOWS FOR EVALUATION!)
            Card(
                colors = CardDefaults.cardColors(containerColor = AthenianPnyxStone.copy(alpha = 0.4f)),
                border = BorderStroke(1.dp, AthenianWarmSand)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("⚙️ Σενάριο Προσομοίωσης Διαταραχής", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.toggleLineDisruption("L1") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (disruptedLines.contains("L1")) MetroRedText else AthenianGraphite
                            ),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            Text(if (disruptedLines.contains("L1")) "Άρση Διαταραχής Γ1" else "Διακοπή Γραμμής 1", fontSize = 10.sp)
                        }

                        Button(
                            onClick = { viewModel.toggleLineDelay("L2") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (delayedLines.contains("L2")) MetroAmberCaution else AthenianGraphite
                            ),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            Text(if (delayedLines.contains("L2")) "Άρση Καθυστέρησης Γ2" else "Καθυστέρηση Γραμμής 2", fontSize = 10.sp)
                        }
                    }
                }
            }

            // Pathfinding Results Display
            routePlan?.let { plan ->
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {

                    // Rerouting warning banner if route is impacted
                    if (plan.affectedByDisruption) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MetroRedLight),
                            border = BorderStroke(1.dp, MetroRedText)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(translate("route_affected_by_disruption"), color = MetroRedText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(translate("route_recalculated"), color = MetroRedText.copy(alpha = 0.8f), fontSize = 11.sp)
                            }
                        }
                    }

                    // Journey Summary Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AthenianMarbleWhite),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = "${plan.totalDurationSeconds / 60}",
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AthenianGraphite
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(translate("minutes"), fontSize = 13.sp, color = AthenianGraphite, modifier = Modifier.padding(bottom = 6.dp))
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("${plan.transfersCount} ${translate("transfers")}", fontSize = 12.sp, color = AthenianGraphite)
                                        Text("${plan.totalWalkingDurationSeconds / 60} min walk", fontSize = 11.sp, color = AthenianWarmSand)
                                    }

                                    if (plan.isStepFree) {
                                        Icon(Icons.Filled.Accessible, contentDescription = "Step free path", tint = MetroLine1Green)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Step-by-Step Leg Details Visualizer
                            plan.legs.forEachIndexed { idx, leg ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Visual Icon Indicator
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .background(
                                                color = when (leg.type) {
                                                    LegType.WALK -> AthenianWarmSand.copy(alpha = 0.3f)
                                                    LegType.TRANSFER -> AthenianGraphite.copy(alpha = 0.1f)
                                                    LegType.METRO_LINE -> when (leg.lineId) {
                                                        "L1" -> MetroLine1Green
                                                        "L2" -> MetroLine2Red
                                                        "L3" -> MetroLine3Blue
                                                        else -> Color.DarkGray
                                                    }
                                                },
                                                shape = CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = when (leg.type) {
                                                LegType.WALK -> Icons.Filled.DirectionsWalk
                                                LegType.TRANSFER -> Icons.Filled.TransferWithinAStation
                                                LegType.METRO_LINE -> Icons.Filled.DirectionsTransit
                                            },
                                            contentDescription = null,
                                            tint = if (leg.type == LegType.METRO_LINE) Color.White else AthenianGraphite,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = when (leg.type) {
                                                LegType.WALK -> "${translate("walk_to")} ${translateStation(stations.find { it.id == leg.toStationId }?.nameEl ?: leg.toStationId)}"
                                                LegType.TRANSFER -> "${translate("platform")} ${translate("next_train")} (${leg.lineId})"
                                                LegType.METRO_LINE -> "${leg.lineId}: ${translateStation(stations.find { it.id == leg.fromStationId }?.nameEl ?: leg.fromStationId)} → ${translateStation(stations.find { it.id == leg.toStationId }?.nameEl ?: leg.toStationId)}"
                                            },
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "${leg.durationSeconds / 60} ${translate("minutes")} • ${if (leg.type == LegType.METRO_LINE) "${leg.stationsCount} stops" else "walk"}",
                                            fontSize = 11.sp,
                                            color = AthenianGraphite.copy(alpha = 0.7f)
                                        )
                                    }
                                }

                                if (idx < plan.legs.size - 1) {
                                    // Leg Connection Line
                                    Box(
                                        modifier = Modifier
                                            .padding(start = 17.dp)
                                            .width(2.dp)
                                            .height(16.dp)
                                            .background(AthenianWarmSand)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Save Path Button
                            Button(
                                onClick = { showSaveDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = AthenianGraphite),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("save_route_button")
                            ) {
                                Icon(Icons.Filled.BookmarkAdd, contentDescription = "Save")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(translate("save_route"), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } ?: run {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Δεν βρέθηκε διαδρομή. Επιλέξτε άλλους σταθμούς.", color = AthenianWarmSand)
                }
            }
        }
    }

    // Save dialog popup
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text(translate("save_route")) },
            text = {
                OutlinedTextField(
                    value = saveNameQuery,
                    onValueChange = { saveNameQuery = it },
                    placeholder = { Text("π.χ. Προς Εργασία / Προς Πανεπιστήμιο") },
                    singleLine = true,
                    modifier = Modifier.testTag("save_dialog_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (saveNameQuery.isNotBlank()) {
                            viewModel.saveCurrentRoute(saveNameQuery)
                            saveNameQuery = ""
                            showSaveDialog = false
                        }
                    },
                    modifier = Modifier.testTag("save_dialog_confirm")
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// 4. SAVED JOURNEYS SCREEN
@Composable
fun SavedJourneysScreen(viewModel: MainViewModel) {
    val savedRoutes by viewModel.savedRoutes.collectAsStateWithLifecycle()
    val stations by viewModel.allStations.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(viewModel)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(AthenianMarbleWhite.copy(alpha = 0.5f))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = translate("saved_journeys"),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = AthenianGraphite,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            if (savedRoutes.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillParentMaxHeight(0.7f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = AthenianWarmSand, modifier = Modifier.size(64.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(translate("no_saved_routes"), color = AthenianWarmSand)
                        }
                    }
                }
            } else {
                items(savedRoutes) { route ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AthenianMarbleWhite),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        viewModel.setRouteFrom(route.fromStationId)
                                        viewModel.setRouteTo(route.toStationId)
                                        viewModel.navigateTo(Screen.RoutePlanner)
                                    }
                            ) {
                                Text(route.label, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = AthenianGraphite)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    "${translateStation(stations.find { it.id == route.fromStationId }?.nameEl ?: route.fromStationId)} → ${translateStation(stations.find { it.id == route.toStationId }?.nameEl ?: route.toStationId)}",
                                    fontSize = 12.sp,
                                    color = AthenianGraphite.copy(alpha = 0.7f)
                                )
                                Text(
                                    "Pref: ${route.preference}",
                                    fontSize = 10.sp,
                                    color = AthenianWarmSand
                                )
                            }

                            IconButton(
                                onClick = { viewModel.deleteSavedRoute(route.id) },
                                modifier = Modifier.testTag("delete_saved_${route.id}")
                            ) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MetroRedText)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 5. LINE STATUS SCREEN
@Composable
fun NetworkStatusScreen(viewModel: MainViewModel) {
    val lines by viewModel.allLines.collectAsStateWithLifecycle()
    val disruptedLines by viewModel.disruptedLines.collectAsStateWithLifecycle()
    val delayedLines by viewModel.delayedLines.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(viewModel)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(AthenianMarbleWhite.copy(alpha = 0.5f))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = translate("network_status"),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = AthenianGraphite
                    )

                    Button(
                        onClick = { viewModel.navigateTo(Screen.DigitalTwin) },
                        colors = ButtonDefaults.buttonColors(containerColor = AthenianGraphite),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Icon(Icons.Filled.Analytics, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(translate("twin"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            items(lines) { line ->
                val isDisrupted = disruptedLines.contains(line.id)
                val isDelayed = delayedLines.contains(line.id)

                val stateTitleKey = when {
                    isDisrupted -> "suspended_service"
                    isDelayed -> "minor_delay"
                    else -> "normal_service"
                }

                val statusColor = when {
                    isDisrupted -> MetroRedText
                    isDelayed -> MetroAmberCaution
                    else -> MetroLine1Green
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = AthenianMarbleWhite),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .background(Color(line.colorHex.toLong()), CircleShape)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (viewModel.currentLanguage.value == AppLanguage.MODERN) line.nameEl else Translations.getStationName(line.nameEl, AppLanguage.ANCIENT),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = AthenianGraphite
                                )
                            }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = statusColor.copy(alpha = 0.1f)),
                                border = BorderStroke(1.dp, statusColor)
                            ) {
                                Text(
                                    text = translate(stateTitleKey),
                                    color = statusColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = when (line.id) {
                                "L1" -> translate("line1_desc")
                                "L2" -> translate("line2_desc")
                                "L3" -> translate("line3_desc")
                                else -> ""
                            },
                            fontSize = 11.sp,
                            color = AthenianWarmSand
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        // Manual overrides right inside the list (Very intuitive demo UX!)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { viewModel.toggleLineDisruption(line.id) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MetroRedText),
                                border = BorderStroke(1.dp, MetroRedText.copy(alpha = 0.5f)),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text(if (isDisrupted) "Άρση Διακοπής" else "Διακοπή", fontSize = 10.sp)
                            }

                            OutlinedButton(
                                onClick = { viewModel.toggleLineDelay(line.id) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MetroAmberCaution),
                                border = BorderStroke(1.dp, MetroAmberCaution.copy(alpha = 0.5f)),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text(if (isDelayed) "Άρση Καθυστέρησης" else "Καθυστέρηση", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }

            // System Warnings / Bulletins Box
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AthenianPnyxStone.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Ανακοινώσεις Επιβατών / Passenger Bulletins", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("• Καύσωνας: Συνιστάται η αποφυγή πεζών διαδρομών άνω των 10 λεπτών.", fontSize = 11.sp)
                        Text("• Έργα συντήρησης στη Γραμμή 1 κατά τις βραδινές ώρες.", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// 6. ADVANCED DIGITAL TWIN & SYSTEM VIEW
@Composable
fun DigitalTwinScreen(viewModel: MainViewModel) {
    val simMinutes by viewModel.simMinutes.collectAsStateWithLifecycle()
    val weather by viewModel.simWeather.collectAsStateWithLifecycle()
    val selectedLineId by viewModel.twinSelectedLineId.collectAsStateWithLifecycle()
    val activeTrains by viewModel.twinTrains.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(viewModel)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Screen Title
            Text(
                text = translate("twin"),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = AthenianGraphite
            )
            Text(
                translate("digital_twin_desc"),
                fontSize = 11.sp,
                color = AthenianWarmSand
            )

            // Timeline scrub slider (00:00 to 23:59)
            Card(
                colors = CardDefaults.cardColors(containerColor = AthenianGraphite),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(translate("simulation_time"), color = AthenianMarbleWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            text = String.format("%02d:%02d", simMinutes / 60, simMinutes % 60),
                            color = AthenianMarbleWhite,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    Slider(
                        value = simMinutes.toFloat(),
                        onValueChange = { viewModel.scrubTime(it.toInt()) },
                        valueRange = 0f..1439f,
                        colors = SliderDefaults.colors(
                            thumbColor = AthenianMarbleWhite,
                            activeTrackColor = AthenianMarbleWhite,
                            inactiveTrackColor = AthenianWarmSand.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.testTag("time_slider")
                    )

                    // Weather override triggers
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(translate("weather"), color = AthenianWarmSand, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        SimWeather.values().forEach { weath ->
                            val isSelected = weath == weather
                            Button(
                                onClick = { viewModel.changeWeather(weath) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) AthenianMarbleWhite else AthenianWarmSand.copy(alpha = 0.2f),
                                    contentColor = if (isSelected) AthenianGraphite else AthenianMarbleWhite
                                ),
                                contentPadding = PaddingValues(horizontal = 6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(32.dp),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(weath.name, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Train Monitor Matrix (Digital Twin Train positions list)
            Card(
                colors = CardDefaults.cardColors(containerColor = AthenianMarbleWhite),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Συρμοί εν Κινήσει / Simulated Trains Status", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Line tabs
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("L1", "L2", "L3").forEach { lineId ->
                            val isSelected = lineId == selectedLineId
                            Button(
                                onClick = { viewModel.selectTwinLine(lineId) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) AthenianGraphite else AthenianPnyxStone.copy(alpha = 0.3f),
                                    contentColor = if (isSelected) AthenianMarbleWhite else AthenianGraphite
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text(lineId, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Trains grid/list
                    activeTrains.forEach { train ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.DirectionsTransit, contentDescription = null, tint = AthenianGraphite, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(train.id, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                Text(
                                    "→ ${translateStation(train.direction)} (${(train.progressPercent * 100).toInt()}% progress)",
                                    fontSize = 10.sp,
                                    color = AthenianWarmSand
                                )
                            }

                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = when (train.occupancy) {
                                        "occupancy_very_high" -> MetroRedLight
                                        "occupancy_high" -> MetroAmberCaution.copy(alpha = 0.1f)
                                        else -> MetroPistachioLight
                                    }
                                )
                            ) {
                                Text(
                                    translate(train.occupancy),
                                    color = when (train.occupancy) {
                                        "occupancy_very_high" -> MetroRedText
                                        "occupancy_high" -> MetroAmberCaution
                                        else -> MetroPistachioText
                                    },
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                        HorizontalDivider(color = AthenianWarmSand.copy(alpha = 0.2f))
                    }
                }
            }

            // Audit Logs (Historical events logs)
            Card(
                colors = CardDefaults.cardColors(containerColor = AthenianMarbleWhite),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(translate("history_log"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    auditLogs.take(6).forEach { log ->
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text(log.action, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = MetroAthensBlue)
                            Text(log.details, fontSize = 11.sp, color = AthenianGraphite)
                            Spacer(modifier = Modifier.height(2.dp))
                            HorizontalDivider(color = AthenianWarmSand.copy(alpha = 0.1f))
                        }
                    }
                }
            }
        }
    }
}

// 7. MORE OPTIONS / SETTINGS SCREEN
@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val weather by viewModel.simWeather.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(viewModel)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(AthenianMarbleWhite.copy(alpha = 0.5f))
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = translate("settings"),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = AthenianGraphite
            )

            // Language block selector
            Card(
                colors = CardDefaults.cardColors(containerColor = AthenianMarbleWhite),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(translate("bilingual_toggle"), fontWeight = FontWeight.Bold, fontSize = 14.sp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { if (currentLang != AppLanguage.MODERN) viewModel.toggleLanguage() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentLang == AppLanguage.MODERN) AthenianGraphite else AthenianPnyxStone.copy(alpha = 0.3f),
                                contentColor = if (currentLang == AppLanguage.MODERN) AthenianMarbleWhite else AthenianGraphite
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(translate("modern_greek"))
                        }

                        Button(
                            onClick = { if (currentLang != AppLanguage.ANCIENT) viewModel.toggleLanguage() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentLang == AppLanguage.ANCIENT) AthenianGraphite else AthenianPnyxStone.copy(alpha = 0.3f),
                                contentColor = if (currentLang == AppLanguage.ANCIENT) AthenianMarbleWhite else AthenianGraphite
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(translate("ancient_greek"))
                        }
                    }
                }
            }

            // Professional Transit Metrics
            Card(
                colors = CardDefaults.cardColors(containerColor = AthenianMarbleWhite),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(translate("professional_view"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(translate("train_frequencies"), fontSize = 12.sp)
                        Text("3-6 min (Peak)", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(translate("reliability_index"), fontSize = 12.sp)
                        Text("99.4% (Deterministic)", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(translate("passenger_flow_rate"), fontSize = 12.sp)
                        Text("24,500/hr simulated", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }
            }

            // Disclaimer & Credits (Transparency Rule compliance)
            Card(
                colors = CardDefaults.cardColors(containerColor = AthenianPnyxStone.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ΑΘΗΝΑΪΚΟ ΜΕΤΡΟ.OS v1.0", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                        "Ανεξάρτητο εννοιολογικό πρωτότυπο. Δεν αποτελεί επίσημη εφαρμογή της ΣΤΑ.ΣΥ. ή του ΟΑΣΑ. Όλα τα δεδομένα, οι χρόνοι άφιξης, οι πληρότητες και οι καιρικές επιδράσεις είναι προϊόντα συνθετικής προσομοίωσης.",
                        fontSize = 10.sp,
                        color = AthenianWarmSand
                    )
                }
            }
        }
    }
}

@Composable
fun StationsScreen(viewModel: MainViewModel) {
    val stations by viewModel.allStations.collectAsStateWithLifecycle()
    val selectedId by viewModel.selectedStationId.collectAsStateWithLifecycle()
    val arrivals by viewModel.stationArrivals.collectAsStateWithLifecycle()
    var showDropdown by remember { mutableStateOf(false) }

    val stat = stations.find { it.id == selectedId } ?: stations.firstOrNull()

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader(viewModel)

        stat?.let { station ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .background(AthenianMarbleWhite.copy(alpha = 0.5f))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Station Selector Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = translate("station_diagram"),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = AthenianGraphite
                    )

                    Box {
                        Button(
                            onClick = { showDropdown = true },
                            colors = ButtonDefaults.buttonColors(containerColor = AthenianGraphite)
                        ) {
                            Text(translateStation(station.nameEl), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Filled.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                        }

                        DropdownMenu(
                            expanded = showDropdown,
                            onDismissRequest = { showDropdown = false },
                            modifier = Modifier.background(AthenianGraphite)
                        ) {
                            stations.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(translateStation(s.nameEl), color = AthenianMarbleWhite) },
                                    onClick = {
                                        viewModel.selectStation(s.id)
                                        showDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Station Info Details Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = AthenianMarbleWhite),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = translateStation(station.nameEl),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = AthenianGraphite
                            )
                            Box(
                                modifier = Modifier
                                    .background(MetroAthensBlue, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(station.code, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        Text(
                            text = if (viewModel.currentLanguage.value == AppLanguage.MODERN) station.infoDetailsEl else station.infoDetailsAn,
                            fontSize = 13.sp,
                            color = AthenianGraphite.copy(alpha = 0.8f)
                        )

                        Spacer(modifier = Modifier.height(4.dp))
                        HorizontalDivider(color = AthenianWarmSand.copy(alpha = 0.2f))

                        // Accessibility Equipment Row
                        Text("Υποδομές Προσβασιμότητας / Accessibility Status", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = AthenianWarmSand)
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (station.isStepFree) Icons.Filled.Accessible else Icons.Filled.Block,
                                    contentDescription = null,
                                    tint = if (station.isStepFree) MetroLine1Green else MetroRedText,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (station.isStepFree) "Ισόπεδη πρόσβαση" else "Όχι ισόπεδη", fontSize = 11.sp)
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (station.hasElevator) Icons.Filled.Elevator else Icons.Filled.Block,
                                    contentDescription = null,
                                    tint = if (station.hasElevator) MetroLine1Green else MetroRedText,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (station.hasElevator) "Ανελκυστήρας" else "Όχι ανελκυστήρας", fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Interactive Cross-Section Diagram
                Text(
                    text = "Τρισδιάστατη Τομή Σταθμού / Cross-Section Diagram",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = AthenianGraphite
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = AthenianMarbleWhite),
                    border = BorderStroke(1.dp, AthenianWarmSand)
                ) {
                    Box(modifier = Modifier.padding(12.dp)) {
                        StationCrossSectionDiagram(station = station)
                    }
                }

                // Exits Section
                Card(
                    colors = CardDefaults.cardColors(containerColor = AthenianMarbleWhite),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Έξοδοι Σταθμού / Station Exits",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = AthenianGraphite
                        )

                        val exits = station.exitsList.split(",")
                        exits.forEach { exit ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.ExitToApp, contentDescription = null, tint = MetroLine1Green, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(exit, fontSize = 12.sp, color = AthenianGraphite)
                            }
                        }
                    }
                }
            }
        } ?: run {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
    }
}

@Composable
fun StationCrossSectionDiagram(station: StationEntity) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .background(Color(0xFFEFECE8)) // Light warm sandstone color
    ) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()

        Canvas(modifier = Modifier.fillMaxSize()) {
            val levelY0 = height * 0.20f   // Level 0: Street
            val levelY1 = height * 0.55f   // Level -1: Ticketing Hall
            val levelY2 = height * 0.85f   // Level -2: Platforms

            val dashPathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)

            // Draw level guidelines
            drawLine(
                color = AthenianGraphite.copy(alpha = 0.3f),
                start = Offset(0f, levelY0),
                end = Offset(width, levelY0),
                strokeWidth = 3f,
                pathEffect = dashPathEffect
            )
            drawLine(
                color = AthenianGraphite.copy(alpha = 0.3f),
                start = Offset(0f, levelY1),
                end = Offset(width, levelY1),
                strokeWidth = 3f,
                pathEffect = dashPathEffect
            )
            drawLine(
                color = AthenianGraphite.copy(alpha = 0.3f),
                start = Offset(0f, levelY2),
                end = Offset(width, levelY2),
                strokeWidth = 3f,
                pathEffect = dashPathEffect
            )

            // Draw soil background block
            drawRect(
                color = Color(0xFFD3C8BE).copy(alpha = 0.4f),
                topLeft = Offset(0f, levelY0),
                size = androidx.compose.ui.geometry.Size(width, height - levelY0)
            )

            // Underground Concourse excavation
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(width * 0.15f, levelY1 - 25f),
                size = androidx.compose.ui.geometry.Size(width * 0.70f, 50f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
            )

            // Platform excavation tunnel
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(width * 0.10f, levelY2 - 30f),
                size = androidx.compose.ui.geometry.Size(width * 0.80f, 60f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(15f, 15f)
            )

            // Draw ticketing desk and barriers
            drawRect(
                color = AthenianGraphite,
                topLeft = Offset(width * 0.45f, levelY1 + 5f),
                size = androidx.compose.ui.geometry.Size(40f, 20f)
            )
            // Ticket gate indicators
            drawLine(
                color = MetroLine1Green,
                start = Offset(width * 0.40f, levelY1 + 10f),
                end = Offset(width * 0.40f + 10f, levelY1 + 10f),
                strokeWidth = 6f
            )
            drawLine(
                color = MetroRedText,
                start = Offset(width * 0.57f, levelY1 + 10f),
                end = Offset(width * 0.57f + 10f, levelY1 + 10f),
                strokeWidth = 6f
            )

            // Vertical Elevator Shaft
            drawRect(
                color = MetroAthensBlue.copy(alpha = 0.15f),
                topLeft = Offset(width * 0.25f, levelY0),
                size = androidx.compose.ui.geometry.Size(24f, levelY2 - levelY0)
            )
            drawLine(
                color = MetroAthensBlue,
                start = Offset(width * 0.25f, levelY0),
                end = Offset(width * 0.25f, levelY2),
                strokeWidth = 3f
            )
            drawLine(
                color = MetroAthensBlue,
                start = Offset(width * 0.25f + 24f, levelY0),
                end = Offset(width * 0.25f + 24f, levelY2),
                strokeWidth = 3f
            )

            // Elevator cabins
            drawRoundRect(
                color = AthenianGraphite,
                topLeft = Offset(width * 0.25f + 2f, levelY1 - 15f),
                size = androidx.compose.ui.geometry.Size(20f, 24f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
            )
            drawCircle(
                color = Color.White,
                radius = 3f,
                center = Offset(width * 0.25f + 12f, levelY1 - 3f)
            )

            // Escalators
            drawLine(
                color = AthenianGraphite,
                start = Offset(width * 0.65f, levelY0),
                end = Offset(width * 0.50f, levelY1 - 25f),
                strokeWidth = 6f
            )
            drawLine(
                color = AthenianGraphite,
                start = Offset(width * 0.50f, levelY1 + 25f),
                end = Offset(width * 0.65f, levelY2 - 30f),
                strokeWidth = 6f
            )

            // Platforms slabs
            drawRect(
                color = Color.LightGray,
                topLeft = Offset(width * 0.10f, levelY2 - 10f),
                size = androidx.compose.ui.geometry.Size(120f, 20f)
            )
            drawRect(
                color = Color.LightGray,
                topLeft = Offset(width * 0.65f, levelY2 - 10f),
                size = androidx.compose.ui.geometry.Size(120f, 20f)
            )

            // Train bodies
            drawCircle(
                color = Color.DarkGray,
                radius = 6f,
                center = Offset(width * 0.43f, levelY2 + 10f)
            )
            drawCircle(
                color = Color.DarkGray,
                radius = 6f,
                center = Offset(width * 0.57f, levelY2 + 10f)
            )
            drawRoundRect(
                color = Color(0xFFCCCCCC),
                topLeft = Offset(width * 0.38f, levelY2 - 25f),
                size = androidx.compose.ui.geometry.Size(90f, 32f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
            )
            drawRect(
                color = AthenianGraphite,
                topLeft = Offset(width * 0.40f, levelY2 - 20f),
                size = androidx.compose.ui.geometry.Size(14f, 10f)
            )
            drawRect(
                color = AthenianGraphite,
                topLeft = Offset(width * 0.46f, levelY2 - 20f),
                size = androidx.compose.ui.geometry.Size(14f, 10f)
            )
            drawRect(
                color = AthenianGraphite,
                topLeft = Offset(width * 0.52f, levelY2 - 20f),
                size = androidx.compose.ui.geometry.Size(14f, 10f)
            )
            drawRect(
                color = MetroAthensBlue,
                topLeft = Offset(width * 0.38f, levelY2 - 5f),
                size = androidx.compose.ui.geometry.Size(90f, 4f)
            )
        }
    }
}

