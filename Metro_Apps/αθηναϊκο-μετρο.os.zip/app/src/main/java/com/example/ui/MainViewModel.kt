package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.MetroRepository
import com.example.data.model.AuditLogEntity
import com.example.data.model.LineEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.SavedRouteEntity
import com.example.data.model.StationEntity
import com.example.data.model.StationLineCrossRef
import com.example.localisation.AppLanguage
import com.example.routing.RoutePlan
import com.example.routing.RoutePreference
import com.example.simulation.SimArrival
import com.example.simulation.SimTrain
import com.example.simulation.SimWeather
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    object Map : Screen()
    object RoutePlanner : Screen()
    object Stations : Screen()
    object Status : Screen()
    object SavedJourneys : Screen()
    object Settings : Screen()
    object DigitalTwin : Screen()
}

class MainViewModel(val repository: MetroRepository) : ViewModel() {

    // Central UI State - Language & Navigation Screen
    private val _currentLanguage = MutableStateFlow(AppLanguage.MODERN)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Station View Mode State
    private val _selectedStationId = MutableStateFlow<String?>("syntagma") // default view Syntagma
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    // Route Planner State
    private val _routeFromId = MutableStateFlow("monastiraki")
    val routeFromId: StateFlow<String> = _routeFromId.asStateFlow()

    private val _routeToId = MutableStateFlow("syntagma")
    val routeToId: StateFlow<String> = _routeToId.asStateFlow()

    private val _routePreference = MutableStateFlow(RoutePreference.FASTEST)
    val routePreference: StateFlow<RoutePreference> = _routePreference.asStateFlow()

    private val _calculatedRoute = MutableStateFlow<RoutePlan?>(null)
    val calculatedRoute: StateFlow<RoutePlan?> = _calculatedRoute.asStateFlow()

    // Station specific data states (dynamic arrivals and details)
    private val _stationArrivals = MutableStateFlow<List<SimArrival>>(emptyList())
    val stationArrivals: StateFlow<List<SimArrival>> = _stationArrivals.asStateFlow()

    // Twin line selection state
    private val _twinSelectedLineId = MutableStateFlow("L3") // Default Line 3
    val twinSelectedLineId: StateFlow<String> = _twinSelectedLineId.asStateFlow()

    private val _twinTrains = MutableStateFlow<List<SimTrain>>(emptyList())
    val twinTrains: StateFlow<List<SimTrain>> = _twinTrains.asStateFlow()

    // Combine multiple flows to create unified UI view states from DB!
    val allStations: StateFlow<List<StationEntity>> = repository.allStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLines: StateFlow<List<LineEntity>> = repository.allLines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val crossRefs: StateFlow<List<StationLineCrossRef>> = repository.crossRefs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedRoutes: StateFlow<List<SavedRouteEntity>> = repository.savedRoutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = repository.notifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.auditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Simulation Flow state hooks
    val simMinutes: StateFlow<Int> = repository.simMinutes
    val simWeather: StateFlow<SimWeather> = repository.simWeather
    val disruptedLines: StateFlow<Set<String>> = repository.disruptedLines
    val delayedLines: StateFlow<Set<String>> = repository.delayedLines

    init {
        // Automatically calculate initial route (Monastiraki -> Syntagma) on startup!
        viewModelScope.launch {
            calculateJourney()
            updateStationArrivals()
            updateTwinTrains()
        }

        // Keep simulated data in sync when time or disruption sets are scrubbed
        viewModelScope.launch {
            combine(simMinutes, disruptedLines, delayedLines) { _, _, _ -> }.collect {
                updateStationArrivals()
                updateTwinTrains()
                calculateJourney() // Recalculate route in background if things change!
            }
        }
    }

    // Interactive UI Handlers
    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == AppLanguage.MODERN) {
            AppLanguage.ANCIENT
        } else {
            AppLanguage.MODERN
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun selectStation(stationId: String?) {
        _selectedStationId.value = stationId
        updateStationArrivals()
    }

    fun setRouteFrom(stationId: String) {
        _routeFromId.value = stationId
        viewModelScope.launch { calculateJourney() }
    }

    fun setRouteTo(stationId: String) {
        _routeToId.value = stationId
        viewModelScope.launch { calculateJourney() }
    }

    fun setRoutePreference(pref: RoutePreference) {
        _routePreference.value = pref
        viewModelScope.launch { calculateJourney() }
    }

    fun swapRouteStations() {
        val temp = _routeFromId.value
        _routeFromId.value = _routeToId.value
        _routeToId.value = temp
        viewModelScope.launch { calculateJourney() }
    }

    suspend fun calculateJourney() {
        val from = _routeFromId.value
        val to = _routeToId.value
        val pref = _routePreference.value
        val plan = repository.planRoute(from, to, pref)
        _calculatedRoute.value = plan
    }

    fun saveCurrentRoute(label: String) {
        val from = _routeFromId.value
        val to = _routeToId.value
        val pref = _routePreference.value
        viewModelScope.launch {
            repository.saveRoute(from, to, label, pref)
        }
    }

    fun deleteSavedRoute(id: Int) {
        viewModelScope.launch {
            repository.deleteSavedRoute(id)
        }
    }

    fun clearNotifications() {
        viewModelScope.launch {
            repository.clearNotifications()
        }
    }

    // Simulation scrubbers
    fun scrubTime(minutes: Int) {
        repository.updateSimMinutes(minutes)
    }

    fun changeWeather(weather: SimWeather) {
        repository.updateSimWeather(weather)
    }

    fun toggleLineDisruption(lineId: String) {
        repository.toggleDisruption(lineId)
    }

    fun toggleLineDelay(lineId: String) {
        repository.toggleDelay(lineId)
    }

    fun selectTwinLine(lineId: String) {
        _twinSelectedLineId.value = lineId
        updateTwinTrains()
    }

    // Async simulated state updates
    fun updateStationArrivals() {
        val id = _selectedStationId.value ?: return
        viewModelScope.launch {
            _stationArrivals.value = repository.getArrivalsAtStation(id)
        }
    }

    fun updateTwinTrains() {
        val lineId = _twinSelectedLineId.value
        viewModelScope.launch {
            _twinTrains.value = repository.getSimulatedTrainsOnLine(lineId)
        }
    }
}

// Custom ViewModel Factory to pass our dependency cleanly
class MainViewModelFactory(private val repository: MetroRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
