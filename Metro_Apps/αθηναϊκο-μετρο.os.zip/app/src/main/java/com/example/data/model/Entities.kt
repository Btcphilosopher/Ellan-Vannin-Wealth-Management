package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lines")
data class LineEntity(
    @PrimaryKey val id: String,
    val nameEl: String,
    val colorHex: String,
    val shortName: String
)

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val nameEl: String,
    val code: String,
    val latitude: Double,
    val longitude: Double,
    val hasElevator: Boolean,
    val hasEscalator: Boolean,
    val isStepFree: Boolean,
    val infoDetailsEl: String,
    val infoDetailsAn: String,
    val exitsList: String, // Comma-separated (e.g. "Exit A: Syntagma Sq,Exit B: Parliament")
    val nearbyPlaces: String // Comma-separated keys
)

@Entity(tableName = "station_line_cross_ref", primaryKeys = ["stationId", "lineId"])
data class StationLineCrossRef(
    val stationId: String,
    val lineId: String,
    val sequenceOrder: Int // Order along the line
)

@Entity(tableName = "track_segments")
data class TrackSegment(
    @PrimaryKey val id: String,
    val fromStationId: String,
    val toStationId: String,
    val travelTimeSeconds: Int,
    val lineId: String
)

@Entity(tableName = "saved_routes")
data class SavedRouteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fromStationId: String,
    val toStationId: String,
    val label: String,
    val preference: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val titleKey: String,
    val bodyKey: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val action: String,
    val timestamp: Long = System.currentTimeMillis(),
    val details: String
)
