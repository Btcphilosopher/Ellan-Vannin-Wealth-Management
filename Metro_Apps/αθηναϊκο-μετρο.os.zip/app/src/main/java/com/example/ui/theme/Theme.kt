package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MetroAthensBlue,
    secondary = AthenianWarmSand,
    tertiary = MetroLine1Green,
    background = AthenianDeepCharcoal,
    surface = AthenianGraphite,
    onPrimary = Color.White,
    onSecondary = AthenianDeepCharcoal,
    onTertiary = Color.White,
    onBackground = AthenianMarbleWhite,
    onSurface = AthenianMarbleWhite
)

private val LightColorScheme = lightColorScheme(
    primary = MetroAthensBlue,
    secondary = AthenianPnyxStone,
    tertiary = MetroLine1Green,
    background = Color(0xFFFFFBFA), // warm paper white
    surface = AthenianPnyxStone,
    onPrimary = Color.White,
    onSecondary = AthenianDeepCharcoal,
    onTertiary = Color.White,
    onBackground = AthenianDeepCharcoal,
    onSurface = AthenianDeepCharcoal
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        DarkColorScheme
    } else {
        LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
