package com.example.routing

import com.example.data.model.StationEntity
import com.example.data.model.TrackSegment
import com.example.data.model.StationLineCrossRef
import java.util.PriorityQueue

enum class RoutePreference {
    FASTEST,
    FEWER_TRANSFERS,
    STEP_FREE,
    LESS_WALKING
}

enum class LegType {
    WALK,
    METRO_LINE,
    TRANSFER
}

data class RouteLeg(
    val type: LegType,
    val fromStationId: String,
    val toStationId: String,
    val lineId: String?,
    val durationSeconds: Int,
    val stationsCount: Int = 0,
    val intermediateStations: List<String> = emptyList()
)

data class RoutePlan(
    val legs: List<RouteLeg>,
    val totalDurationSeconds: Int,
    val totalWalkingDurationSeconds: Int,
    val transfersCount: Int,
    val isStepFree: Boolean,
    val affectedByDisruption: Boolean = false
)

object MetroRoutingEngine {

    // Helper class for Dijkstra node search
    // We search on (StationID, LineID) state to accurately model line transfers!
    private data class SearchNode(
        val stationId: String,
        val currentLineId: String?, // null if walking or just starting
        val costSeconds: Int,
        val path: List<RouteLeg>,
        val transfers: Int,
        val stepFree: Boolean
    ) : Comparable<SearchNode> {
        override fun compareTo(other: SearchNode): Int {
            return this.costSeconds.compareTo(other.costSeconds)
        }
    }

    /**
     * Finds the optimal path from [startId] to [endId] using Dijkstra search.
     * @param stations Map of station ID -> StationEntity
     * @param segments List of all track segments in the database
     * @param crossRefs List of station-line junction definitions
     * @param preference User preference filter
     * @param disruptedLines Set of line IDs with active service disruptions (suspensions)
     * @param delayedLines Set of line IDs with active delays (slow traffic)
     */
    fun findRoute(
        startId: String,
        endId: String,
        stations: Map<String, StationEntity>,
        segments: List<TrackSegment>,
        crossRefs: List<StationLineCrossRef>,
        preference: RoutePreference = RoutePreference.FASTEST,
        disruptedLines: Set<String> = emptySet(),
        delayedLines: Set<String> = emptySet()
    ): RoutePlan? {
        if (startId == endId) {
            return RoutePlan(emptyList(), 0, 0, 0, true)
        }

        val startStation = stations[startId] ?: return null
        val endStation = stations[endId] ?: return null

        // Group lines by station for easy transfer queries
        val stationLinesMap = crossRefs.groupBy { it.stationId }.mapValues { entry ->
            entry.value.map { it.lineId }.toSet()
        }

        // Build adjacency map of tracks: stationId -> list of TrackSegments going FROM it
        val trackAdjacency = segments.groupBy { it.fromStationId }

        // Priority Queue for Dijkstra search
        val pq = PriorityQueue<SearchNode>()
        // Keeps track of the minimum cost to reach a (stationId, lineId) state
        val visited = mutableMapOf<Pair<String, String?>, Int>()

        // Initialize queue with all lines available at start station
        val startLines = stationLinesMap[startId] ?: emptySet()
        for (line in startLines) {
            pq.add(SearchNode(
                stationId = startId,
                currentLineId = line,
                costSeconds = 0,
                path = emptyList(),
                transfers = 0,
                stepFree = startStation.isStepFree
            ))
        }
        // Also allow starting with no line (e.g. walking)
        pq.add(SearchNode(
            stationId = startId,
            currentLineId = null,
            costSeconds = 0,
            path = emptyList(),
            transfers = 0,
            stepFree = startStation.isStepFree
        ))

        while (pq.isNotEmpty()) {
            val curr = pq.poll()

            // Reached destination!
            if (curr.stationId == endId) {
                // If we ended with a transfer or empty node, clean up
                return RoutePlan(
                    legs = curr.path,
                    totalDurationSeconds = curr.costSeconds,
                    totalWalkingDurationSeconds = curr.path.filter { it.type == LegType.WALK }.sumOf { it.durationSeconds },
                    transfersCount = curr.transfers,
                    isStepFree = curr.stepFree,
                    affectedByDisruption = curr.path.any { leg -> leg.lineId != null && (disruptedLines.contains(leg.lineId) || delayedLines.contains(leg.lineId)) }
                )
            }

            val stateKey = Pair(curr.stationId, curr.currentLineId)
            val bestCost = visited[stateKey]
            if (bestCost != null && bestCost <= curr.costSeconds) {
                continue
            }
            visited[stateKey] = curr.costSeconds

            val currStation = stations[curr.stationId] ?: continue

            // 1. Traverse tracks if we are on a specific line
            if (curr.currentLineId != null) {
                val currentLine = curr.currentLineId
                // Is this line completely disrupted (suspended)?
                val lineSuspended = disruptedLines.contains(currentLine)

                val availableTracks = trackAdjacency[curr.stationId]?.filter { it.lineId == currentLine } ?: emptyList()
                for (track in availableTracks) {
                    val nextStation = stations[track.toStationId] ?: continue

                    // Factor in preferences and service disruptions
                    var edgeCost = track.travelTimeSeconds

                    // Disruptions & Delays
                    if (lineSuspended) {
                        // Apply severe penalty or block (Dijkstra can route through if no alternative, but with giant penalty)
                        edgeCost += 7200 // 2 hours penalty
                    } else if (delayedLines.contains(currentLine)) {
                        edgeCost += 480 // +8 minutes delay penalty
                    }

                    // Preference adjustments
                    if (preference == RoutePreference.STEP_FREE && !nextStation.isStepFree) {
                        edgeCost += 3600 // Heavy penalty for non-accessible stations
                    }

                    val isNextStepFree = curr.stepFree && nextStation.isStepFree

                    // Create or extend a METRO_LINE leg
                    val lastLeg = curr.path.lastOrNull()
                    val newPath = if (lastLeg != null && lastLeg.type == LegType.METRO_LINE && lastLeg.lineId == currentLine) {
                        // Merge with previous leg
                        val updatedLeg = lastLeg.copy(
                            toStationId = nextStation.id,
                            durationSeconds = lastLeg.durationSeconds + edgeCost,
                            stationsCount = lastLeg.stationsCount + 1,
                            intermediateStations = lastLeg.intermediateStations + listOf(curr.stationId)
                        )
                        curr.path.dropLast(1) + listOf(updatedLeg)
                    } else {
                        // Start new leg
                        curr.path + listOf(
                            RouteLeg(
                                type = LegType.METRO_LINE,
                                fromStationId = curr.stationId,
                                toStationId = nextStation.id,
                                lineId = currentLine,
                                durationSeconds = edgeCost,
                                stationsCount = 1,
                                intermediateStations = emptyList()
                            )
                        )
                    }

                    pq.add(SearchNode(
                        stationId = nextStation.id,
                        currentLineId = currentLine,
                        costSeconds = curr.costSeconds + edgeCost,
                        path = newPath,
                        transfers = curr.transfers,
                        stepFree = isNextStepFree
                    ))
                }

                // 2. Allow transferring to other lines at this station
                val otherLines = (stationLinesMap[curr.stationId] ?: emptySet()) - setOf(currentLine)
                for (otherLine in otherLines) {
                    var transferPenalty = 180 // 3 minutes standard transfer walk
                    if (preference == RoutePreference.FEWER_TRANSFERS) {
                        transferPenalty += 600 // +10 minutes transfer aversion penalty
                    }
                    if (preference == RoutePreference.LESS_WALKING) {
                        transferPenalty += 300 // +5 minutes walk aversion penalty
                    }
                    if (preference == RoutePreference.STEP_FREE && (!currStation.hasElevator || !currStation.isStepFree)) {
                        transferPenalty += 1800 // High penalty if transfer needs stairs
                    }

                    pq.add(SearchNode(
                        stationId = curr.stationId,
                        currentLineId = otherLine,
                        costSeconds = curr.costSeconds + transferPenalty,
                        path = curr.path + listOf(
                            RouteLeg(
                                type = LegType.TRANSFER,
                                fromStationId = curr.stationId,
                                toStationId = curr.stationId,
                                lineId = otherLine,
                                durationSeconds = transferPenalty
                            )
                        ),
                        transfers = curr.transfers + 1,
                        stepFree = curr.stepFree && currStation.isStepFree
                    ))
                }
            } else {
                // If currentLineId is null, we can board any line available at this station
                val availableLines = stationLinesMap[curr.stationId] ?: emptySet()
                for (line in availableLines) {
                    pq.add(SearchNode(
                        stationId = curr.stationId,
                        currentLineId = line,
                        costSeconds = curr.costSeconds,
                        path = curr.path,
                        transfers = curr.transfers,
                        stepFree = curr.stepFree
                    ))
                }
            }

            // 3. Allow virtual walking between stations within reasonable "closeness"
            // For this conceptual prototype, let's allow virtual walks if stations are extremely close.
            // E.g., Syntagma to Akropoli or Monastiraki can be a short walk if preferred.
            for ((otherId, otherStation) in stations) {
                if (otherId != curr.stationId) {
                    val dist = calculateGridDistance(currStation.latitude, currStation.longitude, otherStation.latitude, otherStation.longitude)
                    // If distance is less than 15 units on our grid, allow a walking transfer
                    if (dist < 15.0) {
                        val walkTimeSeconds = (dist * 40).toInt() // 40 seconds per grid unit walk speed
                        var walkCost = walkTimeSeconds
                        if (preference == RoutePreference.LESS_WALKING) {
                            walkCost *= 3 // Triple penalty for walking
                        }
                        if (preference == RoutePreference.STEP_FREE && (!currStation.isStepFree || !otherStation.isStepFree)) {
                            walkCost += 1800 // Penalty if sidewalks are not step-free
                        }

                        pq.add(SearchNode(
                            stationId = otherId,
                            currentLineId = null, // switch to no line after walk
                            costSeconds = curr.costSeconds + walkCost,
                            path = curr.path + listOf(
                                RouteLeg(
                                    type = LegType.WALK,
                                    fromStationId = curr.stationId,
                                    toStationId = otherId,
                                    lineId = null,
                                    durationSeconds = walkCost
                                )
                            ),
                            transfers = curr.transfers,
                            stepFree = curr.stepFree && otherStation.isStepFree
                        ))
                    }
                }
            }
        }

        return null // No path found
    }

    private fun calculateGridDistance(x1: Double, y1: Double, x2: Double, y2: Double): Double {
        return java.lang.Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2))
    }
}
