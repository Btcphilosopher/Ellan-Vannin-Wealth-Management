package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.ui.AthensMetroBottomBar
import com.example.ui.Screen
import com.example.ui.theme.MyApplicationTheme
import com.example.localisation.ProvideLanguage
import com.example.localisation.AppLanguage
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun bottom_bar_screenshot() {
    composeTestRule.setContent { 
      MyApplicationTheme { 
        ProvideLanguage(language = AppLanguage.MODERN) {
          AthensMetroBottomBar(
            currentScreen = Screen.Home,
            onNavigate = {}
          )
        }
      } 
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/bottom_bar.png")
  }
}
