/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MonteCarloInputs, SimulationSeries, MonteCarloResults, ClientProfile, AssetAllocation } from '../types';

/**
 * Standard Box-Muller transform to generate normally distributed random variables.
 */
function randomNormal(mean: number, stdDev: number): number {
  let u = 0, v = 0;
  while(u === 0) u = Math.random(); 
  while(v === 0) v = Math.random();
  const num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return num * stdDev + mean;
}

/**
 * Runs a 10,000-run Monte Carlo simulation.
 * Optimized for speed and responsiveness in-browser.
 */
export function runMonteCarloSimulation(
  profile: ClientProfile,
  assets: AssetAllocation,
  inputs: MonteCarloInputs,
  annualTaxRateEstimate: number // pass in the effective tax rate from deterministic projection
): MonteCarloResults {
  const numScenarios = inputs.numScenarios || 5000;
  const horizon = profile.investmentHorizon || 20;
  const initialWealth = Object.values(assets).reduce((sum, val) => sum + val, 0);
  
  if (initialWealth <= 0) {
    return {
      series: Array.from({ length: horizon }, (_, i) => ({
        year: i + 1,
        percentiles: { p10: 0, p25: 0, p50: 0, p75: 0, p90: 0 }
      })),
      probPreserve: 0,
      probDouble: 0,
      probDepletion: 0
    };
  }

  // To track ending wealth for all runs across all years
  // matrix: [year][scenario_wealth]
  const yearlyResults: number[][] = Array.from({ length: horizon }, () => []);
  
  let preserveCount = 0;
  let doubleCount = 0;
  let depletionCount = 0;

  const baseLivingCost = 60000;

  for (let s = 0; s < numScenarios; s++) {
    let currentWealth = initialWealth;
    let accumulatedInflation = 1.0;
    let inRecoveryMode = 0; // if > 0, market is recovering from a crash

    for (let y = 0; y < horizon; y++) {
      // 1. Model random inflation (mean is inputs.inflation, sd is 1.5%)
      const yearInflation = Math.max(-0.01, randomNormal(inputs.inflation, 0.015));
      accumulatedInflation *= (1 + yearInflation);
      
      // 2. Model random investment return (mean inputs.avgReturn, sd inputs.volatility)
      let yearReturn = randomNormal(inputs.avgReturn, inputs.volatility);
      
      // 3. Black Swan Market Crash Risk (2.5% chance of crash per year)
      const crashRoll = Math.random();
      if (crashRoll < 0.025 && inRecoveryMode === 0) {
        // Market crash! -30% drop
        yearReturn = -0.30 + randomNormal(0, 0.05);
        inRecoveryMode = 3; // 3 years of subsequent recovery
      } else if (inRecoveryMode > 0) {
        // Recovery bonus (bull phase post crash)
        yearReturn += 0.05;
        inRecoveryMode--;
      }
      
      // 4. Political Tax Change Shock (Random adjustment of effective tax by -3% to +5%)
      const politicalShock = randomNormal(0.01, 0.02);
      const activeTaxRate = Math.max(0, annualTaxRateEstimate + politicalShock);
      
      // 5. Living Costs (scale with inflation + asset performance fee proxy)
      const yearLivingCosts = baseLivingCost * accumulatedInflation + (currentWealth * 0.012);
      
      // 6. Growth compounding
      const returns = currentWealth * yearReturn;
      const taxDragAmount = Math.max(0, returns * activeTaxRate);
      
      currentWealth = Math.max(0, currentWealth + returns - taxDragAmount - yearLivingCosts);
      yearlyResults[y].push(currentWealth);
    }

    // Evaluate final wealth achievements
    const nominalFinalWealth = currentWealth;
    const realFinalWealth = currentWealth / accumulatedInflation;

    // Preserved: Real final wealth >= 90% of initial starting wealth
    if (realFinalWealth >= initialWealth * 0.9) {
      preserveCount++;
    }
    
    // Doubled: Nominal wealth doubled at any point or final nominal >= 2x initial
    if (nominalFinalWealth >= initialWealth * inputs.targetWealthMultiplier) {
      doubleCount++;
    }

    // Depleted: nominal wealth falls below 10% of starting wealth
    if (nominalFinalWealth < initialWealth * 0.10) {
      depletionCount++;
    }
  }

  // Compile percentiles for each year
  const series: SimulationSeries[] = [];
  for (let y = 0; y < horizon; y++) {
    const sortedRunWealths = [...yearlyResults[y]].sort((a, b) => a - b);
    
    // Percentile indices
    const idx10 = Math.floor(numScenarios * 0.10);
    const idx25 = Math.floor(numScenarios * 0.25);
    const idx50 = Math.floor(numScenarios * 0.50);
    const idx75 = Math.floor(numScenarios * 0.75);
    const idx90 = Math.floor(numScenarios * 0.90);

    series.push({
      year: y + 1,
      percentiles: {
        p10: sortedRunWealths[idx10],
        p25: sortedRunWealths[idx25],
        p50: sortedRunWealths[idx50],
        p75: sortedRunWealths[idx75],
        p90: sortedRunWealths[idx90],
      }
    });
  }

  return {
    series,
    probPreserve: preserveCount / numScenarios,
    probDouble: doubleCount / numScenarios,
    probDepletion: depletionCount / numScenarios
  };
}
