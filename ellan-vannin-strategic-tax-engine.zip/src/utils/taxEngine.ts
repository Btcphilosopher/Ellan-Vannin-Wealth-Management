/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ClientProfile, IncomeInputs, AssetAllocation, TaxRates, Scenario } from '../types';

// Default asset class annual nominal returns & inflation rates
export const DEFAULT_ASSET_METRICS = {
  property: { yield: 0.04, growth: 0.02, totalReturn: 0.06, volatility: 0.08 },
  shares: { yield: 0.02, growth: 0.06, totalReturn: 0.08, volatility: 0.16 },
  etfs: { yield: 0.02, growth: 0.055, totalReturn: 0.075, volatility: 0.15 },
  bonds: { yield: 0.04, growth: 0.00, totalReturn: 0.04, volatility: 0.06 },
  cash: { yield: 0.03, growth: 0.00, totalReturn: 0.03, volatility: 0.01 },
  gold: { yield: 0.00, growth: 0.045, totalReturn: 0.045, volatility: 0.12 },
  privateCompanies: { yield: 0.05, growth: 0.07, totalReturn: 0.12, volatility: 0.25 },
  bitcoin: { yield: 0.00, growth: 0.22, totalReturn: 0.22, volatility: 0.65 },
  privateEquity: { yield: 0.02, growth: 0.11, totalReturn: 0.13, volatility: 0.22 },
  collectibles: { yield: 0.00, growth: 0.05, totalReturn: 0.05, volatility: 0.15 },
};

/**
 * Calculates progressive income tax for a given amount and set of brackets.
 */
export function calculateProgressiveTax(income: number, brackets: { bracket: number; rate: number }[]): number {
  if (brackets.length === 0) return 0;
  
  // Sort brackets by threshold ascending
  const sorted = [...brackets].sort((a, b) => a.bracket - b.bracket);
  
  let tax = 0;
  let previousBracket = 0;
  
  for (const b of sorted) {
    if (income > previousBracket) {
      const taxableInThisBand = Math.min(income - previousBracket, b.bracket - previousBracket);
      tax += taxableInThisBand * b.rate;
      previousBracket = b.bracket;
    } else {
      break;
    }
  }
  
  return tax;
}

export interface YearProjection {
  year: number;
  age: number;
  startingWealth: number;
  grossReturns: number;
  grossIncome: number;
  taxPaid: number;
  livingCosts: number;
  endingWealth: number;
  cumulativeTax: number;
  realEndingWealth: number;
}

export interface SimulationSummary {
  projection: YearProjection[];
  finalWealth: number;
  realFinalWealth: number;
  totalTaxPaid: number;
  effectiveTaxRate: number;
  totalGrowth: number;
  taxDrag: number; // Final difference between zero-tax wealth growth and taxed wealth growth
  estateTaxExposure: number;
}

/**
 * Runs a deterministic projection of wealth and tax over a specified horizon.
 */
export function runDeterministicProjection(
  profile: ClientProfile,
  income: IncomeInputs,
  assets: AssetAllocation,
  taxRates: TaxRates,
  scenario: Scenario
): SimulationSummary {
  const horizon = profile.investmentHorizon || 20;
  const inflationRate = 0.025; // 2.5% default inflation
  
  // Starting wealth is sum of all assets
  const initialWealth = Object.values(assets).reduce((sum, val) => sum + val, 0);
  
  // Compute blended portfolio growth and yield
  let totalAssetVal = 0;
  let weightedReturn = 0;
  let weightedYield = 0;
  
  const assetTypes = Object.keys(assets) as (keyof AssetAllocation)[];
  for (const t of assetTypes) {
    const val = assets[t] || 0;
    totalAssetVal += val;
    if (DEFAULT_ASSET_METRICS[t]) {
      weightedReturn += val * DEFAULT_ASSET_METRICS[t].totalReturn;
      weightedYield += val * DEFAULT_ASSET_METRICS[t].yield;
    }
  }
  
  const portfolioReturnRate = totalAssetVal > 0 ? weightedReturn / totalAssetVal : 0.06;
  const portfolioYieldRate = totalAssetVal > 0 ? weightedYield / totalAssetVal : 0.02;
  const capitalGrowthRate = portfolioReturnRate - portfolioYieldRate;
  
  let currentWealth = initialWealth;
  let cumulativeTax = 0;
  const projection: YearProjection[] = [];
  
  // Create a zero-tax simulation track to calculate the exact tax drag
  let zeroTaxWealth = initialWealth;

  // Living expenses scale with wealth & age (rough HNWI lifestyle cost proxy)
  const baseLifestyleCost = 60000; 

  for (let y = 1; y <= horizon; y++) {
    const age = profile.age + y - 1;
    const isRetired = age >= profile.retirementAge;
    
    // 1. Calculate Gross Income for the Year
    // In retirement, employment, bonus, and business incomes are halved or removed
    const empInc = isRetired ? 0 : (income.employmentIncome + income.bonus);
    const busInc = isRetired ? 0 : income.businessIncome;
    const rentalInc = income.rentalIncome;
    const interestInc = currentWealth * portfolioYieldRate * 0.3; // Interest part of portfolio
    const divInc = currentWealth * portfolioYieldRate * 0.7; // Dividend part of portfolio
    const pensionInc = isRetired ? income.pensionIncome + 25000 : 0; // State pension proxy + private pension
    const foreignInc = income.foreignIncome;
    
    const grossIncome = empInc + busInc + rentalInc + interestInc + divInc + pensionInc + foreignInc;
    
    // 2. Calculate Investment Returns (Capital growth part)
    const grossReturns = currentWealth * capitalGrowthRate;
    
    // 3. Tax Engine Calculations based on Wrapper/Structure
    let yearTax = 0;
    
    // Compute taxes according to structural wrapper
    if (scenario.businessStructure === 'Individual') {
      // Direct Personal Taxation
      // Employment, pension, business, and rental taxed progressively
      const ordinaryIncome = empInc + busInc + rentalInc + pensionInc + foreignInc + interestInc;
      const ordinaryTax = calculateProgressiveTax(ordinaryIncome, taxRates.incomeTax);
      
      // Dividends and CGT taxed at dedicated rates
      const dividendTax = divInc * taxRates.dividendTax;
      const cgtTax = (currentWealth * capitalGrowthRate * 0.2) * taxRates.capitalGainsTax; // assume 20% of returns are realized as capital gains
      
      // Annual wealth tax if applicable
      const wealthTax = currentWealth * taxRates.wealthTaxRate;
      
      yearTax = ordinaryTax + dividendTax + cgtTax + wealthTax;
      
      // Isle of Man Specific Tax Cap modelling
      if (taxRates.jurisdiction === 'Isle of Man') {
        const taxCapLimit = 200000;
        if (yearTax > taxCapLimit) {
          yearTax = taxCapLimit;
        }
      }
    } else {
      // Corporate wrapping: Corporate Tax applies inside corporate envelope
      // Active business income, interest, and CGT taxed corporate rate
      const corpIncome = busInc + interestInc + (currentWealth * capitalGrowthRate * 0.2);
      const corpTax = corpIncome * taxRates.corporationTax;
      
      // Gearing / extraction: Assume 40% of remaining income is extracted as dividends or salary
      const netCorpCompoundingIncome = (corpIncome - corpTax) + divInc; // Dividends between corps are usually exempt
      const extractionAmount = netCorpCompoundingIncome * 0.4;
      
      // Extraction taxed at personal dividend rate
      const extractionTax = extractionAmount * taxRates.dividendTax;
      
      // Personal salary income tax on regular salary / employment
      const personalOrdinary = empInc + rentalInc + pensionInc;
      const personalTax = calculateProgressiveTax(personalOrdinary, taxRates.incomeTax);
      
      // Structure-specific discounts (FIC, Holding Co, Trusts)
      let structuralMultiplier = 1.0;
      if (scenario.businessStructure === 'Holding Company') {
        // Exclude inter-corp gains and lower corporate rate slightly through optimal intercompany charges
        structuralMultiplier = 0.90; 
      } else if (scenario.businessStructure === 'Family Investment Company') {
        // Multi-share extraction and growth freezing
        structuralMultiplier = 0.85;
      } else if (scenario.businessStructure === 'Trust-Style') {
        // Direct trustee flat tax (often high initially but zero extraction layers and long-term benefits)
        structuralMultiplier = 0.95;
      }
      
      yearTax = (corpTax + extractionTax) * structuralMultiplier + personalTax;
      
      // Tax Cap applies on the final computed personal bill
      if (taxRates.jurisdiction === 'Isle of Man') {
        const taxCapLimit = 200000;
        if (yearTax > taxCapLimit) {
          yearTax = taxCapLimit;
        }
      }
    }
    
    cumulativeTax += yearTax;
    
    // 4. Compute Living Expenses
    const inflationMultiplier = Math.pow(1 + inflationRate, y - 1);
    const yearLifestyleCost = baseLifestyleCost * inflationMultiplier + (currentWealth * 0.015); // scales with assets
    
    // 5. Ending wealth
    const startingWealth = currentWealth;
    const netGrowth = grossReturns + grossIncome - yearTax - yearLifestyleCost;
    currentWealth = Math.max(0, currentWealth + netGrowth);
    
    // Zero Tax Track computation
    const zeroTaxReturns = zeroTaxWealth * capitalGrowthRate;
    const zeroTaxIncome = empInc + busInc + rentalInc + interestInc + divInc + pensionInc + foreignInc;
    zeroTaxWealth = Math.max(0, zeroTaxWealth + zeroTaxReturns + zeroTaxIncome - yearLifestyleCost);
    
    // Store projection
    projection.push({
      year: y,
      age,
      startingWealth,
      grossReturns,
      grossIncome,
      taxPaid: yearTax,
      livingCosts: yearLifestyleCost,
      endingWealth: currentWealth,
      cumulativeTax,
      realEndingWealth: currentWealth / Math.pow(1 + inflationRate, y)
    });
  }
  
  // Calculate final tax drag
  const taxDrag = zeroTaxWealth - currentWealth;
  
  // Inheritance tax exposure (IHT)
  let estateTaxExposure = 0;
  if (taxRates.inheritanceTax > 0 && currentWealth > taxRates.inheritanceThreshold) {
    let taxableEstate = currentWealth - taxRates.inheritanceThreshold;
    
    // Apply structural discounts
    if (scenario.businessStructure === 'Family Investment Company') {
      taxableEstate *= 0.40; // Gifting / freezing structure cuts taxable estate dramatically
    } else if (scenario.businessStructure === 'Trust-Style') {
      taxableEstate *= 0.15; // Trusts insulate assets from primary direct estate tax charges
    } else if (scenario.businessStructure === 'Holding Company') {
      taxableEstate *= 0.80; // Business property relief (BPR) options on active holdings
    }
    
    estateTaxExposure = taxableEstate * taxRates.inheritanceTax;
  }
  
  const finalWealth = currentWealth;
  const realFinalWealth = currentWealth / Math.pow(1 + inflationRate, horizon);
  const totalGrowth = currentWealth - initialWealth;
  const effectiveTaxRate = initialWealth > 0 ? (cumulativeTax / (weightedReturn * horizon + cumulativeTax || 1)) : 0;
  
  return {
    projection,
    finalWealth,
    realFinalWealth,
    totalTaxPaid: cumulativeTax,
    effectiveTaxRate,
    totalGrowth,
    taxDrag,
    estateTaxExposure
  };
}
