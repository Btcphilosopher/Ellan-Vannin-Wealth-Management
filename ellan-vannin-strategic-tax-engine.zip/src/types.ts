/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ClientProfile {
  age: number;
  countryOfResidence: string;
  taxResidence: string;
  familyStatus: 'Single' | 'Married' | 'Civil Partnership' | 'Divorced';
  dependants: number;
  retirementAge: number;
  investmentHorizon: number;
  currency: string;
}

export interface IncomeInputs {
  employmentIncome: number;
  bonus: number;
  dividends: number;
  interest: number;
  rentalIncome: number;
  capitalGains: number;
  businessIncome: number;
  foreignIncome: number;
  pensionIncome: number;
}

export interface AssetAllocation {
  property: number;      // value in currency
  shares: number;
  etfs: number;
  bonds: number;
  cash: number;
  gold: number;
  privateCompanies: number;
  bitcoin: number;
  privateEquity: number;
  collectibles: number;
}

export interface TaxRates {
  jurisdiction: string;
  incomeTax: { bracket: number; rate: number }[]; // progressive brackets
  corporationTax: number;
  dividendTax: number;
  capitalGainsTax: number;
  inheritanceTax: number;
  inheritanceThreshold: number;
  propertyTaxRate: number; // Stamp duty / transfer tax or annual land tax
  wealthTaxRate: number; // Annual net wealth tax
}

export interface SovereignResidencyParams {
  name: string;
  housingAvgCost: number;     // Annual average high-end rent or housing upkeep
  lifestyleCost: number;      // Annual high-end lifestyle cost
  relocationCost: number;     // One-time relocation fee
  taxFavourableStatus: string; // e.g., "Non-Dom", "HNW Scheme", "Tax Haven"
  effectiveTaxMultiplier: number; // rough scale compared to UK base
}

export interface FamilyOfficeProfile {
  portfolioSize: '10m' | '50m' | '250m';
  assetAllocationPreset: 'Conservative' | 'Balanced' | 'Growth' | 'Institutional';
  trustStructure: boolean;
  philanthropyRate: number; // % annual allocation
  successionReady: boolean;
}

export interface InfrastructureProject {
  id: string;
  name: string;
  category: 'Port' | 'Railway' | 'Energy' | 'Forestry' | 'Data Center';
  initialCapital: number;
  constructionYears: number;
  targetIRR: number;
  operationalYield: number;
  nationalEconomicMultiplier: number;
  carbonOffsetTons: number;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  residence: string;
  businessStructure: 'Individual' | 'Limited Company' | 'Holding Company' | 'Family Investment Company' | 'Trust-Style';
  customTaxRates?: TaxRates; // If set, overrides the default for the residence
}

export interface MonteCarloInputs {
  numScenarios: number;
  targetWealthMultiplier: number; // e.g. 2.0 for doubling
  volatility: number;            // Annual standard deviation of returns
  avgReturn: number;             // Expected nominal return
  inflation: number;             // Annual inflation rate
}

export interface SimulationSeries {
  year: number;
  percentiles: {
    p10: number; // 10th percentile (bear/crashed)
    p25: number;
    p50: number; // 50th percentile (median)
    p75: number;
    p90: number; // 90th percentile (bull/optimal)
  };
}

export interface MonteCarloResults {
  series: SimulationSeries[];
  probPreserve: number; // Prob of keeping starting wealth adjusted for inflation
  probDouble: number;   // Prob of doubling initial nominal wealth
  probDepletion: number; // Prob of wealth dropping below 10% of starting wealth
}
