/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { InfrastructureProject } from '../types';

export const INFRASTRUCTURE_PROJECTS: InfrastructureProject[] = [
  {
    id: 'port_douglas',
    name: 'Douglas Harbour Deep-Water Upgrade',
    category: 'Port',
    initialCapital: 125000000, // £125m
    constructionYears: 3,
    targetIRR: 0.115, // 11.5%
    operationalYield: 0.055, // 5.5% annual yield post-construction
    nationalEconomicMultiplier: 3.2, // 3.2x impact on local commerce and tourism
    carbonOffsetTons: -4500 // cargo efficiency gains offsetting some shipping CO2
  },
  {
    id: 'manx_railway',
    name: 'Manx Strategic Electric Railway Extension',
    category: 'Railway',
    initialCapital: 45000000, // £45m
    constructionYears: 2,
    targetIRR: 0.082, // 8.2% (lower risk, state-backed utility profile)
    operationalYield: 0.040, // 4.0%
    nationalEconomicMultiplier: 2.8,
    carbonOffsetTons: 12000 // commuter car emission diversion
  },
  {
    id: 'offshore_wind',
    name: 'Ellan Vannin Offshore Wind & Solar Array',
    category: 'Energy',
    initialCapital: 350000000, // £350m
    constructionYears: 4,
    targetIRR: 0.138, // 13.8% (high yield, structural power-purchase agreements)
    operationalYield: 0.075, // 7.5%
    nationalEconomicMultiplier: 2.5,
    carbonOffsetTons: 180000 // heavy clean power contribution
  },
  {
    id: 'glen_helen_forest',
    name: 'Glen Helen Strategic Timber & Forestry',
    category: 'Forestry',
    initialCapital: 15000000, // £15m
    constructionYears: 1,
    targetIRR: 0.068, // 6.8% (very stable biological asset growth)
    operationalYield: 0.025, // 2.5% (supplemented by carbon credits)
    nationalEconomicMultiplier: 1.8,
    carbonOffsetTons: 35000 // direct carbon capture
  },
  {
    id: 'ronaldsway_data',
    name: 'Ronaldsway Green AI Data Centre',
    category: 'Data Center',
    initialCapital: 180000000, // £180m
    constructionYears: 2,
    targetIRR: 0.155, // 15.5% (high-demand digital infrastructure)
    operationalYield: 0.080, // 8.0%
    nationalEconomicMultiplier: 4.1, // huge high-tech job and IT ecosystem multiplier
    carbonOffsetTons: -8500 // waste heat recapture and solar-cooling offset
  }
];
