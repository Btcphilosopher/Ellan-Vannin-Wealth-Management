/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TaxRates, SovereignResidencyParams } from '../types';

export const DEFAULT_TAX_RATES: TaxRates[] = [
  {
    jurisdiction: 'Isle of Man',
    incomeTax: [
      { bracket: 14500, rate: 0.0 },
      { bracket: 21000, rate: 0.10 },
      { bracket: 999999999, rate: 0.20 }
    ],
    corporationTax: 0.0,
    dividendTax: 0.0,
    capitalGainsTax: 0.0,
    inheritanceTax: 0.0,
    inheritanceThreshold: 0,
    propertyTaxRate: 0.0,
    wealthTaxRate: 0.0
  },
  {
    jurisdiction: 'United Kingdom',
    incomeTax: [
      { bracket: 12570, rate: 0.0 },
      { bracket: 50270, rate: 0.20 },
      { bracket: 125140, rate: 0.40 },
      { bracket: 999999999, rate: 0.45 }
    ],
    corporationTax: 0.25,
    dividendTax: 0.28, // blended average for mid-to-high earners (33.75% / 39.35% with allowances)
    capitalGainsTax: 0.20,
    inheritanceTax: 0.40,
    inheritanceThreshold: 325000,
    propertyTaxRate: 0.02, // Stamp duty average
    wealthTaxRate: 0.0
  },
  {
    jurisdiction: 'Ireland',
    incomeTax: [
      { bracket: 42000, rate: 0.20 },
      { bracket: 999999999, rate: 0.40 }
    ],
    corporationTax: 0.125,
    dividendTax: 0.40,
    capitalGainsTax: 0.33,
    inheritanceTax: 0.33,
    inheritanceThreshold: 335000,
    propertyTaxRate: 0.01,
    wealthTaxRate: 0.0
  },
  {
    jurisdiction: 'Singapore',
    incomeTax: [
      { bracket: 20000, rate: 0.0 },
      { bracket: 40000, rate: 0.02 },
      { bracket: 80000, rate: 0.07 },
      { bracket: 160000, rate: 0.115 },
      { bracket: 320000, rate: 0.18 },
      { bracket: 500000, rate: 0.22 },
      { bracket: 999999999, rate: 0.24 }
    ],
    corporationTax: 0.17,
    dividendTax: 0.0,
    capitalGainsTax: 0.0,
    inheritanceTax: 0.0,
    inheritanceThreshold: 0,
    propertyTaxRate: 0.04,
    wealthTaxRate: 0.0
  },
  {
    jurisdiction: 'Switzerland',
    incomeTax: [
      { bracket: 14800, rate: 0.0 },
      { bracket: 50900, rate: 0.08 },
      { bracket: 150000, rate: 0.15 },
      { bracket: 500000, rate: 0.25 },
      { bracket: 999999999, rate: 0.32 } // blended cantonal/federal average
    ],
    corporationTax: 0.14,
    dividendTax: 0.15, // blended after refunds/reliefs
    capitalGainsTax: 0.0, // 0% on private capital gains
    inheritanceTax: 0.05, // highly cantonal (0% for direct descendants in most cantons, slight charge otherwise)
    inheritanceThreshold: 200000,
    propertyTaxRate: 0.005,
    wealthTaxRate: 0.003 // 0.3% average wealth tax
  },
  {
    jurisdiction: 'UAE',
    incomeTax: [
      { bracket: 999999999, rate: 0.0 }
    ],
    corporationTax: 0.09, // 9% above AED 375,000 threshold for operational business
    dividendTax: 0.0,
    capitalGainsTax: 0.0,
    inheritanceTax: 0.0,
    inheritanceThreshold: 0,
    propertyTaxRate: 0.04, // 4% Dubai Land Dept fee
    wealthTaxRate: 0.0
  },
  {
    jurisdiction: 'USA',
    incomeTax: [
      { bracket: 11600, rate: 0.10 },
      { bracket: 47150, rate: 0.12 },
      { bracket: 100525, rate: 0.22 },
      { bracket: 191950, rate: 0.24 },
      { bracket: 243725, rate: 0.32 },
      { bracket: 609350, rate: 0.35 },
      { bracket: 999999999, rate: 0.37 }
    ],
    corporationTax: 0.25, // combined federal + state
    dividendTax: 0.238, // 20% federal + 3.8% NIIT
    capitalGainsTax: 0.238,
    inheritanceTax: 0.40,
    inheritanceThreshold: 13610000, // Very high lifetime exclusion
    propertyTaxRate: 0.015,
    wealthTaxRate: 0.0
  }
];

export const SOVEREIGN_RESIDENCY_PARAMS: SovereignResidencyParams[] = [
  {
    name: 'Isle of Man',
    housingAvgCost: 35000,
    lifestyleCost: 45000,
    relocationCost: 15000,
    taxFavourableStatus: '0/10% Business, £200k Tax Cap, No CGT/IHT',
    effectiveTaxMultiplier: 0.15
  },
  {
    name: 'United Kingdom',
    housingAvgCost: 80000, // Premium London housing
    lifestyleCost: 95000,
    relocationCost: 0,
    taxFavourableStatus: 'Standard Progressive (Non-Dom phased out)',
    effectiveTaxMultiplier: 1.0
  },
  {
    name: 'Ireland',
    housingAvgCost: 60000,
    lifestyleCost: 70000,
    relocationCost: 10000,
    taxFavourableStatus: 'Remittance Basis (Non-Dom status options)',
    effectiveTaxMultiplier: 0.8
  },
  {
    name: 'Singapore',
    housingAvgCost: 120000,
    lifestyleCost: 110000,
    relocationCost: 40000,
    taxFavourableStatus: 'No CGT, No Dividend Tax, Global HQ Hub',
    effectiveTaxMultiplier: 0.25
  },
  {
    name: 'Switzerland',
    housingAvgCost: 100000,
    lifestyleCost: 120000,
    relocationCost: 30000,
    taxFavourableStatus: 'Lump-Sum Taxation (Forfait) available',
    effectiveTaxMultiplier: 0.45
  },
  {
    name: 'UAE',
    housingAvgCost: 90000,
    lifestyleCost: 100000,
    relocationCost: 25000,
    taxFavourableStatus: '0% Income Tax, Golden Visa Options',
    effectiveTaxMultiplier: 0.05
  },
  {
    name: 'USA',
    housingAvgCost: 95000,
    lifestyleCost: 90000,
    relocationCost: 20000,
    taxFavourableStatus: 'Global Tax on Citizenship, High IHT threshold',
    effectiveTaxMultiplier: 0.95
  }
];
