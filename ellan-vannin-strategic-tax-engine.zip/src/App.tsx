/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { ClientProfile, AssetAllocation, IncomeInputs, Scenario, TaxRates } from './types';
import { DEFAULT_TAX_RATES } from './data/jurisdictions';
import { MainDashboard } from './components/MainDashboard';
import { SovereignResidency } from './components/SovereignResidency';
import { FamilyOffice } from './components/FamilyOffice';
import { InfrastructureModel } from './components/InfrastructureModel';
import { ScenarioBuilder } from './components/ScenarioBuilder';
import { ReportGeneratorView } from './components/ReportGeneratorView';
import {
  Sliders,
  DollarSign,
  TrendingUp,
  Compass,
  Users,
  Activity,
  FileText,
  Briefcase,
  Layers,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  CheckCircle,
  Sparkles,
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'terminal' | 'sovereign' | 'family' | 'infrastructure' | 'scenarios' | 'report'>('terminal');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // 1. Client Profile State
  const [profile, setProfile] = useState<ClientProfile>({
    age: 45,
    countryOfResidence: 'United Kingdom',
    taxResidence: 'United Kingdom',
    familyStatus: 'Married',
    dependants: 2,
    retirementAge: 65,
    investmentHorizon: 20,
    currency: '£',
  });

  // 2. Income Flows State
  const [income, setIncome] = useState<IncomeInputs>({
    employmentIncome: 250000,
    bonus: 100000,
    dividends: 150000,
    interest: 20000,
    rentalIncome: 60000,
    capitalGains: 100000,
    businessIncome: 300000,
    foreignIncome: 50000,
    pensionIncome: 0,
  });

  // 3. Asset Allocations State
  const [assets, setAssets] = useState<AssetAllocation>({
    property: 2000000,
    shares: 1500000,
    etfs: 1000000,
    bonds: 500000,
    cash: 300000,
    gold: 200000,
    privateCompanies: 1500000,
    bitcoin: 200000,
    privateEquity: 800000,
    collectibles: 200000,
  });

  // 4. Default Scenarios List State
  const [scenarios, setScenarios] = useState<Scenario[]>([
    {
      id: 'scenario_current',
      name: 'Current Position',
      description: 'Standard UK progressive taxation holding core assets personally',
      residence: 'United Kingdom',
      businessStructure: 'Individual',
    },
    {
      id: 'scenario_optimised',
      name: 'Optimised Structure',
      description: 'Corporate wrapping model holding alternative portfolio in the UK',
      residence: 'United Kingdom',
      businessStructure: 'Limited Company',
    },
    {
      id: 'scenario_iom_cap',
      name: 'Isle of Man Family FIC',
      description: 'Fiscal move to Douglas. Asset base wrapped in an IOM Family Investment Company',
      residence: 'Isle of Man',
      businessStructure: 'Family Investment Company',
    },
    {
      id: 'scenario_singapore_trust',
      name: 'Singapore Trust Hold',
      description: 'Assets wrapped inside a private discretionary trust in Singapore',
      residence: 'Singapore',
      businessStructure: 'Trust-Style',
    },
  ]);

  const [activeScenarioId, setActiveScenarioId] = useState<string>('scenario_current');

  // 5. Global Tax Rates List State
  const [taxRatesList, setTaxRatesList] = useState<TaxRates[]>(DEFAULT_TAX_RATES);

  // Presets Loader
  const loadPreset = (presetType: 'entrepreneur' | 'migrant' | 'family') => {
    if (presetType === 'entrepreneur') {
      setProfile({
        age: 40,
        countryOfResidence: 'United Kingdom',
        taxResidence: 'United Kingdom',
        familyStatus: 'Married',
        dependants: 2,
        retirementAge: 60,
        investmentHorizon: 20,
        currency: '£',
      });
      setIncome({
        employmentIncome: 500000,
        bonus: 200000,
        dividends: 300000,
        interest: 50000,
        rentalIncome: 80000,
        capitalGains: 150000,
        businessIncome: 600000,
        foreignIncome: 0,
        pensionIncome: 0,
      });
      setAssets({
        property: 3000000,
        shares: 2000000,
        etfs: 1500000,
        bonds: 500000,
        cash: 500000,
        gold: 300000,
        privateCompanies: 4000000,
        bitcoin: 500000,
        privateEquity: 1500000,
        collectibles: 200000,
      });
      setActiveScenarioId('scenario_current');
    } else if (presetType === 'migrant') {
      setProfile({
        age: 48,
        countryOfResidence: 'Isle of Man',
        taxResidence: 'Isle of Man',
        familyStatus: 'Married',
        dependants: 1,
        retirementAge: 62,
        investmentHorizon: 15,
        currency: '£',
      });
      setIncome({
        employmentIncome: 100000,
        bonus: 50000,
        dividends: 600000,
        interest: 80000,
        rentalIncome: 120000,
        capitalGains: 300000,
        businessIncome: 1200000,
        foreignIncome: 200000,
        pensionIncome: 0,
      });
      setAssets({
        property: 4000000,
        shares: 5000000,
        etfs: 3000000,
        bonds: 2000000,
        cash: 1000000,
        gold: 800000,
        privateCompanies: 8000000,
        bitcoin: 2000000,
        privateEquity: 4000000,
        collectibles: 1000000,
      });
      setActiveScenarioId('scenario_iom_cap');
    } else {
      // Family Office Preset
      setProfile({
        age: 55,
        countryOfResidence: 'Singapore',
        taxResidence: 'Singapore',
        familyStatus: 'Married',
        dependants: 3,
        retirementAge: 70,
        investmentHorizon: 25,
        currency: '$',
      });
      setIncome({
        employmentIncome: 0,
        bonus: 0,
        dividends: 1500000,
        interest: 600000,
        rentalIncome: 450000,
        capitalGains: 800000,
        businessIncome: 2500000,
        foreignIncome: 500000,
        pensionIncome: 0,
      });
      setAssets({
        property: 12000000,
        shares: 15000000,
        etfs: 10000000,
        bonds: 8000000,
        cash: 3000000,
        gold: 2000000,
        privateCompanies: 15000000,
        bitcoin: 5000000,
        privateEquity: 12000000,
        collectibles: 3000000,
      });
      setActiveScenarioId('scenario_singapore_trust');
    }
  };

  const handleProfileChange = (key: keyof ClientProfile, value: any) => {
    setProfile(prev => ({ ...prev, [key]: value }));
  };

  const handleIncomeChange = (key: keyof IncomeInputs, value: number) => {
    setIncome(prev => ({ ...prev, [key]: value }));
  };

  const handleAssetChange = (key: keyof AssetAllocation, value: number) => {
    setAssets(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="min-h-screen bg-[#070D1F] text-gray-100 font-sans flex flex-col antialiased">
      
      {/* PRIVATE BANK HEADER BRANDING */}
      <header className="bg-[#0A1128] border-b border-[#C5A059]/15 px-6 py-4 flex justify-between items-center z-10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 border-2 border-[#C5A059] flex items-center justify-center bg-black/20 shrink-0">
            <span className="text-[#C5A059] font-serif text-lg font-black tracking-wider">EV</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-bold tracking-[0.2em] text-white uppercase font-serif leading-none">Ellan Vannin</h1>
              <span className="text-[9px] bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/20 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">Strategic Tax</span>
            </div>
            <p className="text-[10px] text-gray-400 tracking-wider mt-1">Strategic Wealth & Capital Preservation Terminal</p>
          </div>
        </div>

        {/* Preset Loader shortcuts */}
        <div className="hidden lg:flex items-center gap-3 text-xs">
          <span className="text-gray-400 font-semibold text-[10px] uppercase tracking-widest text-[#C5A059]/80">Quick Presets:</span>
          <button
            onClick={() => loadPreset('entrepreneur')}
            className="bg-white/5 hover:bg-[#C5A059]/5 hover:text-[#C5A059] text-gray-300 border border-white/10 hover:border-[#C5A059]/20 px-3 py-1 rounded transition-colors text-[11px]"
          >
            UK Entrepreneur (£15M)
          </button>
          <button
            onClick={() => loadPreset('migrant')}
            className="bg-white/5 hover:bg-[#C5A059]/5 hover:text-[#C5A059] text-gray-300 border border-white/10 hover:border-[#C5A059]/20 px-3 py-1 rounded transition-colors text-[11px]"
          >
            Sovereign Move (£35M)
          </button>
          <button
            onClick={() => loadPreset('family')}
            className="bg-[#C5A059]/10 hover:bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30 px-3 py-1 rounded transition-colors text-[11px] font-semibold"
          >
            Family Office Board (£85M)
          </button>
        </div>
      </header>

      {/* MAIN VIEWPORT LAYOUT */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* COLLAPSIBLE SIDEBAR: CLIENT PROFILE & ASSET BOARD */}
        <aside
          className={`bg-[#0A1128]/95 border-r border-[#C5A059]/15 transition-all duration-300 flex flex-col shrink-0 ${sidebarOpen ? 'w-80' : 'w-0 overflow-hidden'}`}
          id="client-profile-sidebar"
        >
          {sidebarOpen && (
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              
              {/* Demographics */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-[#C5A059] uppercase tracking-widest flex items-center gap-2 pb-1 border-b border-white/10 font-serif">
                  <Sliders className="w-3.5 h-3.5 text-[#C5A059]" /> Demographics
                </h3>
                
                <div className="grid grid-cols-2 gap-3.5 text-xs">
                  <div>
                    <label className="block text-gray-400 font-medium mb-1">Current Age</label>
                    <input
                      type="number"
                      value={profile.age}
                      onChange={(e) => handleProfileChange('age', Number(e.target.value))}
                      className="w-full bg-[#040914] border border-white/10 rounded px-2 py-1 text-white text-xs font-mono focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 font-medium mb-1">Horizon (Yrs)</label>
                    <input
                      type="number"
                      value={profile.investmentHorizon}
                      onChange={(e) => handleProfileChange('investmentHorizon', Number(e.target.value))}
                      className="w-full bg-[#040914] border border-white/10 rounded px-2 py-1 text-white text-xs font-mono focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 font-medium mb-1">Retirement Age</label>
                    <input
                      type="number"
                      value={profile.retirementAge}
                      onChange={(e) => handleProfileChange('retirementAge', Number(e.target.value))}
                      className="w-full bg-[#040914] border border-white/10 rounded px-2 py-1 text-white text-xs font-mono focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 font-medium mb-1">Base Currency</label>
                    <select
                      value={profile.currency}
                      onChange={(e) => handleProfileChange('currency', e.target.value)}
                      className="w-full bg-[#040914] border border-white/10 rounded px-2 py-1 text-white text-xs focus:outline-none focus:border-[#C5A059]"
                    >
                      <option value="£">£ (GBP)</option>
                      <option value="$">$ (USD)</option>
                      <option value="€">€ (EUR)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Asset Values */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-[#C5A059] uppercase tracking-widest flex items-center gap-2 pb-1 border-b border-white/10 font-serif">
                  <Briefcase className="w-3.5 h-3.5 text-[#C5A059]" /> Capital Allocations
                </h3>
                <div className="space-y-2.5 text-xs">
                  {Object.entries(assets).map(([key, val]) => (
                    <div key={key} className="flex justify-between items-center">
                      <span className="text-gray-300 capitalize text-[11px] font-medium truncate max-w-[120px]">
                        {key.replace(/([A-Z])/g, ' $1')}
                      </span>
                      <div className="relative w-36">
                        <span className="absolute left-2 top-1 text-[#C5A059] font-mono text-[10px]">{profile.currency}</span>
                        <input
                          type="number"
                          value={val}
                          onChange={(e) => handleAssetChange(key as any, Number(e.target.value))}
                          className="w-full bg-[#040914] border border-white/10 rounded px-1.5 py-0.5 pl-5 text-right font-mono text-white text-[11px] focus:outline-none focus:border-[#C5A059]"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Income Flows */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-[#C5A059] uppercase tracking-widest flex items-center gap-2 pb-1 border-b border-white/10 font-serif">
                  <Layers className="w-3.5 h-3.5 text-[#C5A059]" /> Annual Inflows
                </h3>
                <div className="space-y-2.5 text-xs">
                  {Object.entries(income).map(([key, val]) => (
                    <div key={key} className="flex justify-between items-center">
                      <span className="text-gray-300 capitalize text-[11px] font-medium truncate max-w-[120px]">
                        {key.replace(/([A-Z])/g, ' $1')}
                      </span>
                      <div className="relative w-36">
                        <span className="absolute left-2 top-1 text-[#C5A059]/80 font-mono text-[10px]">{profile.currency}</span>
                        <input
                          type="number"
                          value={val}
                          onChange={(e) => handleIncomeChange(key as any, Number(e.target.value))}
                          className="w-full bg-[#040914] border border-white/10 rounded px-1.5 py-0.5 pl-5 text-right font-mono text-white text-[11px] focus:outline-none focus:border-[#C5A059]"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}
        </aside>

        {/* SIDEBAR TOGGLE BUTTON */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="bg-[#0A1128] hover:bg-[#111A36] text-[#C5A059] border-r border-[#C5A059]/15 px-1.5 flex flex-col justify-center items-center cursor-pointer transition-colors z-10 focus:outline-none print:hidden"
          title={sidebarOpen ? "Collapse Input Board" : "Expand Input Board"}
        >
          {sidebarOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </button>

        {/* WORKSPACE VIEWPORT */}
        <main className="flex-1 overflow-y-auto bg-[#070D1F] p-6 space-y-6 flex flex-col justify-between print:bg-white print:p-0">
          
          {/* TAB NAVIGATION STRIP (Hidden on print) */}
          <div className="flex border-b border-[#C5A059]/15 gap-1 pb-1.5 overflow-x-auto print:hidden shrink-0">
            <button
              onClick={() => setActiveTab('terminal')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'terminal' 
                  ? 'bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/40 font-bold font-serif' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 text-[#C5A059]" /> Portfolio Terminal
            </button>
            <button
              onClick={() => setActiveTab('sovereign')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'sovereign' 
                  ? 'bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/40 font-bold font-serif' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-[#C5A059]" /> Residency Simulator
            </button>
            <button
              onClick={() => setActiveTab('family')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'family' 
                  ? 'bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/40 font-bold font-serif' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-[#C5A059]" /> Family Office Board
            </button>
            <button
              onClick={() => setActiveTab('infrastructure')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'infrastructure' 
                  ? 'bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/40 font-bold font-serif' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Activity className="w-3.5 h-3.5 text-[#C5A059]" /> Co-Investment Desk
            </button>
            <button
              onClick={() => setActiveTab('scenarios')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'scenarios' 
                  ? 'bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/40 font-bold font-serif' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sliders className="w-3.5 h-3.5 text-[#C5A059]" /> Tax Matrix Builder
            </button>
            <button
              onClick={() => setActiveTab('report')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded text-xs tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'report' 
                  ? 'bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/40 font-bold font-serif' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-[#C5A059]" /> Print Report
            </button>
          </div>

          {/* ACTIVE VIEW CONTENT BLOCK */}
          <div className="flex-1 print:p-0">
            {activeTab === 'terminal' && (
              <MainDashboard
                profile={profile}
                assets={assets}
                income={income}
                scenarios={scenarios}
                activeScenarioId={activeScenarioId}
                taxRatesList={taxRatesList}
              />
            )}

            {activeTab === 'sovereign' && (
              <SovereignResidency
                profile={profile}
                assets={assets}
                income={income}
              />
            )}

            {activeTab === 'family' && (
              <FamilyOffice profile={profile} />
            )}

            {activeTab === 'infrastructure' && (
              <InfrastructureModel profile={profile} />
            )}

            {activeTab === 'scenarios' && (
              <ScenarioBuilder
                scenarios={scenarios}
                setScenarios={setScenarios}
                activeScenarioId={activeScenarioId}
                setActiveScenarioId={setActiveScenarioId}
                taxRatesList={taxRatesList}
                setTaxRatesList={setTaxRatesList}
              />
            )}

            {activeTab === 'report' && (
              <ReportGeneratorView
                profile={profile}
                assets={assets}
                income={income}
                scenarios={scenarios}
                taxRatesList={taxRatesList}
              />
            )}
          </div>

          {/* SUB-FOOTER NOTICE (Hidden on print) */}
          <footer className="mt-8 text-center text-[10px] text-gray-500 border-t border-white/5 pt-4 flex flex-col md:flex-row justify-between items-center gap-2 print:hidden shrink-0">
            <div className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#C5A059]/70" />
              <span>Ellan Vannin private banking compliance certified.</span>
            </div>
            <div>
              <span>Douglas Terminal 4.2.0 • Session Secure</span>
            </div>
          </footer>

        </main>
      </div>
    </div>
  );
}
