/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SOVEREIGN_RESIDENCY_PARAMS, DEFAULT_TAX_RATES } from '../data/jurisdictions';
import { ClientProfile, IncomeInputs, AssetAllocation } from '../types';
import { runDeterministicProjection } from '../utils/taxEngine';
import { Landmark, Compass, DollarSign, Home, Plane, ShieldAlert } from 'lucide-react';

interface SovereignResidencyProps {
  profile: ClientProfile;
  assets: AssetAllocation;
  income: IncomeInputs;
}

export const SovereignResidency: React.FC<SovereignResidencyProps> = ({ profile, assets, income }) => {
  const startingWealth = 
    ((assets.property || 0) +
    (assets.shares || 0) +
    (assets.etfs || 0) +
    (assets.bonds || 0) +
    (assets.cash || 0) +
    (assets.gold || 0) +
    (assets.privateCompanies || 0) +
    (assets.bitcoin || 0) +
    (assets.privateEquity || 0) +
    (assets.collectibles || 0)) || 5000000; // default £5m
  const [localWealthInput, setLocalWealthInput] = useState<number>(startingWealth);
  const [selectedDestinations, setSelectedDestinations] = useState<string[]>(['United Kingdom', 'Isle of Man', 'Singapore', 'UAE']);

  // Format Helper
  const fmt = (v: number) => {
    let currencyCode = 'GBP';
    if (profile.currency === '£') currencyCode = 'GBP';
    else if (profile.currency === '$') currencyCode = 'USD';
    else if (profile.currency === '€') currencyCode = 'EUR';
    else if (profile.currency && profile.currency.length === 3) currencyCode = profile.currency;

    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currencyCode,
      maximumFractionDigits: 0,
    }).format(v);
  };

  // Compute comparative results
  const comparisonResults = SOVEREIGN_RESIDENCY_PARAMS.map(param => {
    // Find matching default tax rates
    const taxRates = DEFAULT_TAX_RATES.find(r => r.jurisdiction === param.name) || DEFAULT_TAX_RATES[0];
    
    // Simulate 20-year projection with this jurisdiction's tax rates
    // To represent local lifestyle costs, we override living costs or model them.
    // Let's run a custom projection where starting assets are net of relocation,
    // and we subtract the local housing + lifestyle costs each year.
    const horizon = profile.investmentHorizon || 20;
    const inflationRate = 0.025;
    
    // Starting wealth adjusted for relocation cost
    let currentWealth = localWealthInput - param.relocationCost;
    let cumulativeTaxPaid = 0;
    let cumulativeLivingCosts = 0;

    // Blended portfolio rates
    const portfolioGrowthRate = 0.05; // 5% base capital growth
    const portfolioYieldRate = 0.025; // 2.5% yield

    for (let y = 1; y <= horizon; y++) {
      // Return and yields
      const returns = currentWealth * portfolioGrowthRate;
      const yieldInc = currentWealth * portfolioYieldRate;
      
      // Local living costs adjusted for inflation
      const localHousing = param.housingAvgCost * Math.pow(1 + inflationRate, y - 1);
      const localLifestyle = param.lifestyleCost * Math.pow(1 + inflationRate, y - 1);
      const annualCosts = localHousing + localLifestyle;
      cumulativeLivingCosts += annualCosts;

      // Local taxes paid
      const ordinaryIncome = income.employmentIncome + income.rentalIncome + yieldInc * 0.3; // part of yield taxed as ordinary interest
      const divIncome = income.dividends + yieldInc * 0.7; // part of yield taxed as div
      
      // Personal ordinary income tax
      const ordTax = taxRates.incomeTax.reduce((taxSum, b, idx, arr) => {
        const prev = idx === 0 ? 0 : arr[idx-1].bracket;
        if (ordinaryIncome > prev) {
          const taxable = Math.min(ordinaryIncome - prev, b.bracket - prev);
          return taxSum + taxable * b.rate;
        }
        return taxSum;
      }, 0);
      
      const divTax = divIncome * taxRates.dividendTax;
      const wealthTax = currentWealth * taxRates.wealthTaxRate;
      
      let yearTax = ordTax + divTax + wealthTax;
      
      // Isle of Man Tax Cap
      if (param.name === 'Isle of Man' && yearTax > 200000) {
        yearTax = 200000;
      }

      cumulativeTaxPaid += yearTax;

      // Net accumulation
      currentWealth = Math.max(0, currentWealth + returns + ordinaryIncome + divIncome - yearTax - annualCosts);
    }

    return {
      name: param.name,
      param,
      finalWealth: currentWealth,
      relocationCost: param.relocationCost,
      annualHousing: param.housingAvgCost,
      annualLifestyle: param.lifestyleCost,
      taxStatus: param.taxFavourableStatus,
      totalTax: cumulativeTaxPaid,
      totalLiving: cumulativeLivingCosts
    };
  });

  return (
    <div className="space-y-6" id="sovereign-residency-panel">
      {/* Module Title */}
      <div className="border-b border-white/10 pb-4">
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2 font-serif">
          <Compass className="w-5 h-5 text-[#C5A059]" />
          Sovereign Residency Simulator
        </h2>
        <p className="text-xs text-gray-400">
          Quantify the capital preservation and quality-of-life arbitrage of relocating household residency and physical asset bases.
        </p>
      </div>

      {/* Inputs Header */}
      <div className="bg-[#0A1128]/95 border border-[#C5A059]/15 p-5 rounded-lg grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
        <div>
          <label className="block text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Simulated Asset Base</label>
          <div className="relative">
            <span className="absolute left-3 top-2.5 text-[#C5A059] font-mono text-sm">{profile.currency}</span>
            <input
              type="number"
              value={localWealthInput}
              onChange={(e) => setLocalWealthInput(Number(e.target.value))}
              className="w-full bg-[#040914] border border-white/10 rounded px-3 py-2 pl-8 text-sm font-mono text-white focus:outline-none focus:border-[#C5A059]"
            />
          </div>
          <span className="text-[10px] text-gray-500 mt-1 block">Adjust capital footprint to simulate household migration</span>
        </div>
        
        <div className="col-span-2">
          <label className="block text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Target Jurisdictions</label>
          <div className="flex flex-wrap gap-2">
            {SOVEREIGN_RESIDENCY_PARAMS.map(param => {
              const active = selectedDestinations.includes(param.name);
              return (
                <button
                  key={param.name}
                  onClick={() => {
                    if (active) {
                      setSelectedDestinations(selectedDestinations.filter(d => d !== param.name));
                    } else {
                      setSelectedDestinations([...selectedDestinations, param.name]);
                    }
                  }}
                  className={`px-3 py-1.5 rounded text-xs transition-colors ${active ? 'bg-[#C5A059] text-black font-semibold font-serif shadow' : 'bg-white/5 text-gray-400 hover:bg-white/10 border border-white/10'}`}
                >
                  {param.name}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Comparison Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {comparisonResults
          .filter(r => selectedDestinations.includes(r.name))
          .map(r => {
            const isOptimal = r.name === 'Isle of Man';
            return (
              <div
                key={r.name}
                className={`bg-[#0A1128]/90 border rounded-lg p-5 shadow-lg relative flex flex-col justify-between min-h-[460px] ${isOptimal ? 'border-[#C5A059]/50 bg-[#111A36]' : 'border-white/10'}`}
              >
                {isOptimal && (
                  <span className="absolute -top-2.5 right-4 bg-[#C5A059] text-black text-[9px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    Douglas Focus
                  </span>
                )}
                
                {/* Header */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <h3 className="text-base font-bold text-white font-serif">{r.name}</h3>
                    <Landmark className={`w-4 h-4 ${isOptimal ? 'text-[#C5A059]' : 'text-gray-400'}`} />
                  </div>
                  <div className="bg-white/5 border border-white/10 px-2 py-1 rounded">
                    <span className="block text-[8px] uppercase text-gray-400 font-semibold tracking-wider">Sovereign Profile</span>
                    <span className="text-[10px] text-[#C5A059] font-medium truncate block">{r.taxStatus}</span>
                  </div>
                </div>

                {/* Relocation Metrics */}
                <div className="border-y border-white/10 py-4 my-4 space-y-3 flex-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400 flex items-center gap-1">
                      <Plane className="w-3 h-3 text-[#C5A059]/80" /> Relocation Cost
                    </span>
                    <span className="font-mono text-white font-semibold">{fmt(r.relocationCost)}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400 flex items-center gap-1">
                      <Home className="w-3 h-3 text-[#C5A059]/80" /> Annual Housing Rent
                    </span>
                    <span className="font-mono text-white font-semibold">{fmt(r.annualHousing)}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400 flex items-center gap-1">
                      <DollarSign className="w-3 h-3 text-[#C5A059]/80" /> Annual High-End Lifestyle
                    </span>
                    <span className="font-mono text-white font-semibold">{fmt(r.annualLifestyle)}</span>
                  </div>
                  <div className="flex justify-between text-xs pt-2 border-t border-white/5 text-red-400/90">
                    <span>Simulated 20-Yr Tax Drag</span>
                    <span className="font-mono font-bold">{fmt(r.totalTax)}</span>
                  </div>
                  <div className="flex justify-between text-xs text-gray-400">
                    <span>Simulated 20-Yr Lifestyle Cost</span>
                    <span className="font-mono font-medium">{fmt(r.totalLiving)}</span>
                  </div>
                </div>

                {/* Final Accumulation Card */}
                <div className="bg-white/5 border border-white/10 p-3 rounded text-center">
                  <span className="block text-[9px] uppercase tracking-wider text-gray-400">Final Compounded Portfolio</span>
                  <span className="text-lg font-bold text-emerald-400 font-mono mt-1 block">{fmt(r.finalWealth)}</span>
                  <span className="text-[9px] text-gray-500">Net of relocations, taxes, & housing</span>
                </div>
              </div>
            );
          })}
      </div>

      {/* Advisory Note */}
      <div className="bg-[#C5A059]/5 border border-[#C5A059]/25 p-4 rounded-lg flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-[#C5A059] shrink-0 mt-0.5" />
        <div className="text-xs text-gray-400 space-y-1">
          <span className="font-semibold text-[#C5A059] block font-serif">Sovereign Compliance & Statutory Requirements</span>
          <p>
            Relocating fiscal residency requires statutory compliance (e.g. the UK "statutory residence test" or the US "substantial presence test"). The Isle of Man offers HNW status under the "Tax Cap" system, limiting total personal income tax exposure to £200,000 per annum. Seek formal compliance clearance from EVWM specialists prior to executing physical transfers.
          </p>
        </div>
      </div>
    </div>
  );
};
