/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ClientProfile } from '../types';
import { Landmark, Award, ShieldCheck, FileText, TrendingUp, AlertTriangle, Users } from 'lucide-react';

interface FamilyOfficeProps {
  profile: ClientProfile;
}

export const FamilyOffice: React.FC<FamilyOfficeProps> = ({ profile }) => {
  const [portfolioSize, setPortfolioSize] = useState<number>(50000000); // default £50m
  const [allocationPreset, setAllocationPreset] = useState<'Conservative' | 'Balanced' | 'Growth' | 'Institutional'>('Institutional');
  const [trustWrapped, setTrustWrapped] = useState<boolean>(true);
  const [philanthropyRate, setPhilanthropyRate] = useState<number>(0.02); // 2% annual giving
  const [successionReady, setSuccessionReady] = useState<boolean>(false);

  // Allocation models
  const allocationPresets = {
    Conservative: { property: 0.20, shares: 0.25, etfs: 0.15, bonds: 0.30, cash: 0.08, gold: 0.02, privateEquity: 0.00 },
    Balanced: { property: 0.15, shares: 0.35, etfs: 0.20, bonds: 0.15, cash: 0.05, gold: 0.05, privateEquity: 0.05 },
    Growth: { property: 0.10, shares: 0.40, etfs: 0.20, bonds: 0.05, cash: 0.02, gold: 0.03, privateEquity: 0.20 },
    Institutional: { property: 0.15, shares: 0.20, etfs: 0.15, bonds: 0.10, cash: 0.05, gold: 0.05, privateEquity: 0.30 }, // heavy alternative private equity weight (family office standard)
  };

  const selectedAlloc = allocationPresets[allocationPreset];

  // Calculations
  const annualPhilanthropy = portfolioSize * philanthropyRate;
  const trustWrapperMitigation = trustWrapped ? portfolioSize * 0.40 : 0; // 40% primary estate tax shield
  const alternativeYield = portfolioSize * 0.068; // average institutional yield (6.8%)

  // Format helper
  const fmt = (v: number) => {
    let currencyCode = 'GBP';
    if (profile.currency === '£') currencyCode = 'GBP';
    else if (profile.currency === '$') currencyCode = 'USD';
    else if (profile.currency === '€') currencyCode = 'EUR';
    else if (profile.currency && profile.currency.length === 3) currencyCode = profile.currency;

    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currencyCode,
      maximumFractionDigits: 0,
    }).format(v);
  };

  return (
    <div className="space-y-6" id="family-office-panel">
      {/* Module Title */}
      <div className="border-b border-white/10 pb-4">
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2 font-serif">
          <Users className="w-5 h-5 text-[#C5A059]" />
          Family Office Simulator
        </h2>
        <p className="text-xs text-gray-400">
          Orchestrate multi-generational wealth preservation, trust governance structures, and philanthropic foundations.
        </p>
      </div>

      {/* Profile Parameters */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Control Board */}
        <div className="lg:col-span-4 bg-[#0A1128]/95 border border-[#C5A059]/15 p-5 rounded-lg space-y-6">
          <h3 className="text-sm font-semibold tracking-wider text-[#C5A059] uppercase font-serif pb-1 border-b border-white/10">Board Parameters</h3>
          
          {/* Portfolio Size Selector */}
          <div className="space-y-2">
            <label className="block text-xs text-gray-400 font-medium">Core Asset Footprint</label>
            <div className="grid grid-cols-3 gap-2">
              {[10000000, 50000000, 250000000].map(val => (
                <button
                  key={val}
                  onClick={() => setPortfolioSize(val)}
                  className={`py-2 rounded text-xs font-mono transition-all ${portfolioSize === val ? 'bg-[#C5A059] text-black font-bold font-serif shadow-md' : 'bg-white/5 text-gray-400 border border-white/10 hover:border-[#C5A059]/25'}`}
                >
                  {fmt(val)}
                </button>
              ))}
            </div>
          </div>

          {/* Allocation Preset */}
          <div className="space-y-2">
            <label className="block text-xs text-gray-400 font-medium">Asset Allocation Archetype</label>
            <select
              value={allocationPreset}
              onChange={(e) => setAllocationPreset(e.target.value as any)}
              className="w-full bg-[#040914] border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C5A059]"
            >
              <option value="Conservative">Conservative (Wealth Preservation)</option>
              <option value="Balanced">Balanced Strategy</option>
              <option value="Growth">Growth Focus</option>
              <option value="Institutional">Institutional (Yale Endowment style)</option>
            </select>
          </div>

          {/* Wrapper structures */}
          <div className="space-y-3 pt-2">
            <label className="flex items-center gap-2.5 text-xs text-gray-300 cursor-pointer">
              <input
                type="checkbox"
                checked={trustWrapped}
                onChange={(e) => setTrustWrapped(e.target.checked)}
                className="rounded text-[#C5A059] bg-[#040914] border-white/20 focus:ring-0 focus:ring-offset-0 accent-[#C5A059]"
              />
              Settle Assets in Discretionary Trust wrappers
            </label>
            <label className="flex items-center gap-2.5 text-xs text-gray-300 cursor-pointer">
              <input
                type="checkbox"
                checked={successionReady}
                onChange={(e) => setSuccessionReady(e.target.checked)}
                className="rounded text-[#C5A059] bg-[#040914] border-white/20 focus:ring-0 focus:ring-offset-0 accent-[#C5A059]"
              />
              Formal Family Succession Constitution ratified
            </label>
          </div>

          {/* Philanthropy rate */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-gray-400">
              <span>Annual Philanthropy Allocation</span>
              <span className="text-[#C5A059] font-semibold font-mono">{(philanthropyRate * 100).toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="0.10"
              step="0.005"
              value={philanthropyRate}
              onChange={(e) => setPhilanthropyRate(Number(e.target.value))}
              className="w-full accent-[#C5A059] bg-[#040914] h-1.5 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Right Dashboard & Report */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Key Metric Blocks */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#0A1128] border border-[#C5A059]/15 p-4 rounded-lg relative overflow-hidden shadow-lg">
              <div className="absolute top-0 left-0 w-full h-[2px] bg-slate-500/30" />
              <span className="block text-[10px] text-gray-400 uppercase tracking-wider font-semibold">Target Annual Yield</span>
              <span className="text-base font-bold text-white font-mono mt-1 block">{fmt(alternativeYield)}</span>
              <span className="text-[9px] text-emerald-400 mt-1 block">~6.8% institutional yield proxy</span>
            </div>
            
            <div className="bg-[#0A1128] border border-[#C5A059]/15 p-4 rounded-lg relative overflow-hidden shadow-lg">
              <div className="absolute top-0 left-0 w-full h-[2px] bg-[#C5A059]" />
              <span className="block text-[10px] text-gray-400 uppercase tracking-wider font-semibold">Annual Giving Foundation</span>
              <span className="text-base font-bold text-[#C5A059] font-mono mt-1 block">{fmt(annualPhilanthropy)}</span>
              <span className="text-[9px] text-gray-400 mt-1 block">To settled foundations</span>
            </div>

            <div className="bg-[#0A1128] border border-[#C5A059]/15 p-4 rounded-lg relative overflow-hidden shadow-lg">
              <div className="absolute top-0 left-0 w-full h-[2px] bg-purple-500/50" />
              <span className="block text-[10px] text-gray-400 uppercase tracking-wider font-semibold">Estate Shield Protection</span>
              <span className="text-base font-bold text-purple-400 font-mono mt-1 block">
                {trustWrapped ? fmt(trustWrapperMitigation) : 'Nil'}
              </span>
              <span className="text-[9px] text-gray-400 mt-1 block">
                {trustWrapped ? 'Trust wrapping active' : 'Subject to full personal estate IHT'}
              </span>
            </div>
          </div>

          {/* Investment Committee Report card */}
          <div className="bg-[#0A1128] border border-[#C5A059]/15 p-5 rounded-lg space-y-4 shadow-xl">
            <div className="flex items-center gap-2 border-b border-white/10 pb-3">
              <FileText className="w-4 h-4 text-[#C5A059]" />
              <h4 className="text-xs font-bold uppercase tracking-widest text-white font-serif">Investment Committee Report Briefing</h4>
            </div>

            <div className="space-y-4 text-xs text-gray-300 leading-relaxed">
              <div className="flex items-center gap-1.5 font-bold text-[#C5A059] text-sm font-serif">
                <Landmark className="w-4 h-4 text-[#C5A059]" /> Ellan Vannin Wealth Management Portfolio Review
              </div>
              
              <p>
                The Investment Committee has reviewed the structured asset base of <span className="text-white font-semibold font-mono">{fmt(portfolioSize)}</span> under the <span className="text-[#C5A059] font-semibold font-serif">{allocationPreset} strategy</span>.
              </p>

              {/* Allocation list visual */}
              <div className="bg-[#040914] p-4 rounded border border-white/5 grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                {Object.entries(selectedAlloc).map(([k, pct]) => (
                  <div key={k} className="border-l border-[#C5A059]/30 pl-2">
                    <span className="block text-[9px] uppercase text-gray-500 font-semibold">{k.replace(/([A-Z])/g, ' $1')}</span>
                    <span className="font-mono text-white font-bold">{((pct as number) * 100).toFixed(0)}%</span>
                  </div>
                ))}
              </div>

              {/* Specific Findings */}
              <div className="space-y-3 pt-2">
                <h5 className="font-semibold text-white uppercase text-[10px] tracking-wider font-serif">Primary Strategic Findings:</h5>
                
                <div className="flex gap-2.5 items-start">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <p>
                    {trustWrapped
                      ? "Assets settled in discretionary trusts bypass primary estate probate charges. This isolates family capital from direct inheritance calculations, shielding approximately 40% of the aggregate net worth upon transition events."
                      : "Action Required: High direct estate tax exposure detected. Transitioning assets under a holding wrapper or family trust structure is strongly recommended to insulate family wealth."}
                  </p>
                </div>

                <div className="flex gap-2.5 items-start">
                  <Award className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <p>
                    Annual philanthropic distribution of <span className="text-[#C5A059] font-bold font-serif">{fmt(annualPhilanthropy)}</span> structured through donor-advised corporate funds allows complete deferral of capital gains on liquidated shares before contribution.
                  </p>
                </div>

                <div className="flex gap-2.5 items-start">
                  {successionReady ? (
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  )}
                  <p>
                    {successionReady
                      ? "A ratified Family Constitution establishes clean governance rules and distribution mechanics across descendants, mitigating legal friction or sudden dissolution pressures."
                      : "Warning: Family constitution not ratified. Lack of formalized family governance leaves multi-generational assets highly exposed to dispute risks. Ratify succession charters before next tax cycle."}
                  </p>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
