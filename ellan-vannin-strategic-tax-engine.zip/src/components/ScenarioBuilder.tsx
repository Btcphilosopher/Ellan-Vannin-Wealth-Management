/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Scenario, TaxRates } from '../types';
import { DEFAULT_TAX_RATES } from '../data/jurisdictions';
import { Sliders, Plus, Trash2, Edit3, Check, Globe, RefreshCw } from 'lucide-react';

interface ScenarioBuilderProps {
  scenarios: Scenario[];
  setScenarios: React.Dispatch<React.SetStateAction<Scenario[]>>;
  activeScenarioId: string;
  setActiveScenarioId: (id: string) => void;
  taxRatesList: TaxRates[];
  setTaxRatesList: React.Dispatch<React.SetStateAction<TaxRates[]>>;
}

export const ScenarioBuilder: React.FC<ScenarioBuilderProps> = ({
  scenarios,
  setScenarios,
  activeScenarioId,
  setActiveScenarioId,
  taxRatesList,
  setTaxRatesList,
}) => {
  const [editingScenarioId, setEditingScenarioId] = useState<string | null>(null);
  const [scenarioName, setScenarioName] = useState('');
  const [scenarioDesc, setScenarioDesc] = useState('');
  const [scenarioResidence, setScenarioResidence] = useState('United Kingdom');
  const [scenarioStructure, setScenarioStructure] = useState<any>('Individual');

  // Custom tax rate editor states
  const [editingTaxRates, setEditingTaxRates] = useState<TaxRates | null>(null);

  const startEditScenario = (s: Scenario) => {
    setEditingScenarioId(s.id);
    setScenarioName(s.name);
    setScenarioDesc(s.description);
    setScenarioResidence(s.residence);
    setScenarioStructure(s.businessStructure);
    
    // Find rates matching this scenario or default
    const currentRates = s.customTaxRates || taxRatesList.find(r => r.jurisdiction === s.residence) || taxRatesList[0];
    setEditingTaxRates(JSON.parse(JSON.stringify(currentRates))); // deep copy
  };

  const saveScenarioEdits = () => {
    if (!editingScenarioId || !editingTaxRates) return;

    setScenarios(prev => prev.map(s => {
      if (s.id === editingScenarioId) {
        return {
          ...s,
          name: scenarioName,
          description: scenarioDesc,
          residence: scenarioResidence,
          businessStructure: scenarioStructure,
          customTaxRates: editingTaxRates
        };
      }
      return s;
    }));

    setEditingScenarioId(null);
    setEditingTaxRates(null);
  };

  const addNewScenario = () => {
    const id = `scenario_${Date.now()}`;
    const newS: Scenario = {
      id,
      name: `Scenario ${scenarios.length + 1}`,
      description: 'Custom wealth planning scenario',
      residence: 'Isle of Man',
      businessStructure: 'Individual'
    };
    setScenarios(prev => [...prev, newS]);
    setActiveScenarioId(id);
    startEditScenario(newS);
  };

  const deleteScenario = (id: string) => {
    if (scenarios.length <= 1) return; // keep at least one
    setScenarios(prev => prev.filter(s => s.id !== id));
    if (activeScenarioId === id) {
      setActiveScenarioId(scenarios[0].id);
    }
  };

  const handleRateChange = (field: keyof TaxRates, val: any) => {
    if (!editingTaxRates) return;
    setEditingTaxRates({
      ...editingTaxRates,
      [field]: val
    });
  };

  const handleBracketChange = (bracketIdx: number, field: 'bracket' | 'rate', val: number) => {
    if (!editingTaxRates) return;
    const nextBrackets = [...editingTaxRates.incomeTax];
    nextBrackets[bracketIdx] = {
      ...nextBrackets[bracketIdx],
      [field]: val
    };
    setEditingTaxRates({
      ...editingTaxRates,
      incomeTax: nextBrackets
    });
  };

  const resetRatesToDefault = () => {
    if (!editingTaxRates) return;
    const defaults = DEFAULT_TAX_RATES.find(r => r.jurisdiction === scenarioResidence) || DEFAULT_TAX_RATES[0];
    setEditingTaxRates(JSON.parse(JSON.stringify(defaults)));
  };

  return (
    <div className="space-y-6" id="scenario-builder-panel">
      {/* Title */}
      <div className="border-b border-white/10 pb-4">
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2 font-serif">
          <Sliders className="w-5 h-5 text-[#C5A059]" />
          Scenario & Tax Matrix Builder
        </h2>
        <p className="text-xs text-gray-400">
          Create comparative financial scenarios, change progressive tax rates, and modify business wrap options.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Scenario List Left */}
        <div className="lg:col-span-5 bg-[#0A1128]/95 border border-[#C5A059]/15 p-5 rounded-lg space-y-4 shadow-xl">
          <div className="flex justify-between items-center pb-2 border-b border-white/10">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#C5A059] font-serif">Planning Scenarios</h3>
            <button
              onClick={addNewScenario}
              className="flex items-center gap-1.5 bg-[#C5A059] text-black px-2.5 py-1 rounded text-xs font-bold shadow hover:bg-[#C5A059]/90 transition-colors font-serif"
            >
              <Plus className="w-3.5 h-3.5" /> New Scenario
            </button>
          </div>

          <div className="space-y-2">
            {scenarios.map(s => {
              const isActive = s.id === activeScenarioId;
              const isEditing = s.id === editingScenarioId;
              return (
                <div
                  key={s.id}
                  className={`p-3.5 rounded-lg border transition-all flex flex-col justify-between gap-3 ${isActive ? 'bg-[#111A36] border-[#C5A059]/50 shadow-md' : 'bg-[#040914] border-white/5 hover:border-[#C5A059]/20'}`}
                >
                  <div className="flex justify-between items-start">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-white font-serif">{s.name}</h4>
                        <span className="text-[9px] uppercase tracking-wider bg-white/10 text-gray-300 px-1.5 py-0.5 rounded font-semibold font-mono">
                          {s.residence}
                        </span>
                      </div>
                      <p className="text-[10px] text-gray-400 max-w-[200px]">{s.description}</p>
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      <button
                        onClick={() => setActiveScenarioId(s.id)}
                        className={`px-2 py-1 rounded text-[10px] font-semibold transition-colors ${isActive ? 'bg-[#C5A059] text-black font-serif' : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'}`}
                      >
                        Select
                      </button>
                      <button
                        onClick={() => startEditScenario(s)}
                        className="p-1 rounded bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 transition-colors"
                        title="Edit Structure & Rates"
                      >
                        <Edit3 className="w-3.5 h-3.5 text-[#C5A059]" />
                      </button>
                      <button
                        onClick={() => deleteScenario(s.id)}
                        disabled={scenarios.length <= 1}
                        className="p-1 rounded bg-white/5 hover:bg-red-950/40 border border-white/10 hover:border-red-900/40 text-gray-400 hover:text-red-400 disabled:opacity-30 transition-colors"
                        title="Delete Scenario"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex gap-4 text-[9px] text-gray-500 uppercase tracking-wider border-t border-white/5 pt-1.5">
                    <span>Wrapper: <strong className="text-[#C5A059] font-semibold font-mono">{s.businessStructure}</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Matrix Editor Right */}
        <div className="lg:col-span-7 bg-[#0A1128]/95 border border-[#C5A059]/15 p-5 rounded-lg space-y-6 min-h-[400px] shadow-xl">
          {editingScenarioId && editingTaxRates ? (
            <div className="space-y-6">
              <div className="flex justify-between items-center pb-2 border-b border-white/10">
                <h3 className="text-xs font-bold uppercase tracking-widest text-[#C5A059] font-serif">Edit Scenario Details & Tax Coefficients</h3>
                <div className="flex gap-2">
                  <button
                    onClick={resetRatesToDefault}
                    className="flex items-center gap-1 bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 px-2 py-1 rounded text-[10px] font-semibold transition-colors"
                  >
                    <RefreshCw className="w-3 h-3" /> Reset default
                  </button>
                  <button
                    onClick={saveScenarioEdits}
                    className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1 rounded text-[10px] font-bold shadow transition-colors"
                  >
                    <Check className="w-3.5 h-3.5" /> Save
                  </button>
                </div>
              </div>

              {/* Identity fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Scenario Name</label>
                  <input
                    type="text"
                    value={scenarioName}
                    onChange={(e) => setScenarioName(e.target.value)}
                    className="w-full bg-[#040914] border border-white/10 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#C5A059]"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Description Summary</label>
                  <input
                    type="text"
                    value={scenarioDesc}
                    onChange={(e) => setScenarioDesc(e.target.value)}
                    className="w-full bg-[#040914] border border-white/10 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#C5A059]"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Jurisdiction of Residence</label>
                  <select
                    value={scenarioResidence}
                    onChange={(e) => {
                      setScenarioResidence(e.target.value);
                      // Apply default tax rates for the newly selected jurisdiction
                      const defaults = DEFAULT_TAX_RATES.find(r => r.jurisdiction === e.target.value) || DEFAULT_TAX_RATES[0];
                      setEditingTaxRates(JSON.parse(JSON.stringify(defaults)));
                    }}
                    className="w-full bg-[#040914] border border-white/10 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#C5A059]"
                  >
                    {DEFAULT_TAX_RATES.map(r => (
                      <option key={r.jurisdiction} value={r.jurisdiction}>{r.jurisdiction}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Business / Wrapper Structure</label>
                  <select
                    value={scenarioStructure}
                    onChange={(e) => setScenarioStructure(e.target.value as any)}
                    className="w-full bg-[#040914] border border-white/10 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#C5A059]"
                  >
                    <option value="Individual">Individual ownership (Direct Hold)</option>
                    <option value="Limited Company">Limited Company Hold</option>
                    <option value="Holding Company">Holding Company wrapper</option>
                    <option value="Family Investment Company">Family Investment Company Hold</option>
                    <option value="Trust-Style">Protected Discretionary Trust Hold</option>
                  </select>
                </div>
              </div>

              {/* Flat Rates Grid */}
              <div className="border-t border-white/10 pt-4 space-y-4">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#C5A059] flex items-center gap-1.5 font-serif">
                  <Globe className="w-3.5 h-3.5 text-[#C5A059]" /> Flat Tax Rates Override
                </h4>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-[9px] text-gray-400 uppercase font-semibold mb-1">Corporate Tax</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="1"
                      value={editingTaxRates.corporationTax}
                      onChange={(e) => handleRateChange('corporationTax', Number(e.target.value))}
                      className="w-full bg-[#040914] border border-white/10 rounded px-2.5 py-1.5 text-xs font-mono text-white focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-gray-400 uppercase font-semibold mb-1">Dividend Tax</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="1"
                      value={editingTaxRates.dividendTax}
                      onChange={(e) => handleRateChange('dividendTax', Number(e.target.value))}
                      className="w-full bg-[#040914] border border-white/10 rounded px-2.5 py-1.5 text-xs font-mono text-white focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-gray-400 uppercase font-semibold mb-1">Capital Gains</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="1"
                      value={editingTaxRates.capitalGainsTax}
                      onChange={(e) => handleRateChange('capitalGainsTax', Number(e.target.value))}
                      className="w-full bg-[#040914] border border-white/10 rounded px-2.5 py-1.5 text-xs font-mono text-white focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-gray-400 uppercase font-semibold mb-1">Estate/IHT Rate</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="1"
                      value={editingTaxRates.inheritanceTax}
                      onChange={(e) => handleRateChange('inheritanceTax', Number(e.target.value))}
                      className="w-full bg-[#040914] border border-white/10 rounded px-2.5 py-1.5 text-xs font-mono text-white focus:outline-none focus:border-[#C5A059]"
                    />
                  </div>
                </div>
              </div>

              {/* Progressive brackets */}
              <div className="border-t border-white/10 pt-4 space-y-3">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#C5A059] font-serif">Progressive Income Tax Brackets</h4>
                <div className="space-y-2 bg-[#040914] p-3 rounded border border-white/5">
                  {editingTaxRates.incomeTax.map((b, idx) => (
                    <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                      <span className="col-span-2 text-[10px] text-gray-500">Band {idx + 1} Limit</span>
                      <input
                        type="number"
                        value={b.bracket}
                        onChange={(e) => handleBracketChange(idx, 'bracket', Number(e.target.value))}
                        className="col-span-4 bg-[#040914] border border-white/10 rounded px-2 py-1 text-xs font-mono text-white focus:outline-none focus:border-[#C5A059]"
                      />
                      <span className="col-span-2 text-[10px] text-gray-500 text-center">Tax Rate</span>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        max="1"
                        value={b.rate}
                        onChange={(e) => handleBracketChange(idx, 'rate', Number(e.target.value))}
                        className="col-span-4 bg-[#040914] border border-white/10 rounded px-2 py-1 text-xs font-mono text-white focus:outline-none focus:border-[#C5A059]"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-center text-gray-500 space-y-2">
              <Sliders className="w-10 h-10 text-gray-700 animate-pulse-slow" />
              <p className="text-xs">No active scenario editor. Select a scenario edit pencil on the left to configure tax coefficients.</p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
