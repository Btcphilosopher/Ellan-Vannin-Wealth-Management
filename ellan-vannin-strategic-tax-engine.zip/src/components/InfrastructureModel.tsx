/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { INFRASTRUCTURE_PROJECTS } from '../data/infrastructure';
import { ClientProfile } from '../types';
import { Landmark, Leaf, TrendingUp, ShieldAlert, Award, ChevronRight, Activity } from 'lucide-react';

interface InfrastructureModelProps {
  profile: ClientProfile;
}

export const InfrastructureModel: React.FC<InfrastructureModelProps> = ({ profile }) => {
  const [selectedProjectId, setSelectedProjectId] = useState<string>(INFRASTRUCTURE_PROJECTS[0].id);
  const [investorAllocation, setInvestorAllocation] = useState<number>(2000000); // default £2m
  const [wrapperType, setWrapperType] = useState<'Personal' | 'Corporate'>('Corporate');

  const project = INFRASTRUCTURE_PROJECTS.find(p => p.id === selectedProjectId) || INFRASTRUCTURE_PROJECTS[0];

  // Calculations
  const investorEquityPct = investorAllocation / project.initialCapital;
  const targetYieldAmount = investorAllocation * project.operationalYield;
  const projectTotalReturns = investorAllocation * project.targetIRR;
  
  // Tax calculations inside the infrastructure project vs investor levels
  // Infrastructure project often benefits from capital allowances (depreciation offsets)
  const capitalAllowanceOffset = 0.40; // 40% tax shield on green infra construction
  const rawProjectTax = projectTotalReturns * 0.19; // standard base project tax rate
  const projectTaxPaid = rawProjectTax * (1 - capitalAllowanceOffset);
  
  // Investor payout taxation
  let investorTaxDrag = 0;
  if (wrapperType === 'Personal') {
    // taxed at full dividend or income tax rates
    investorTaxDrag = targetYieldAmount * 0.3375; // average high-earner UK div rate
  } else {
    // corporate wrapper (e.g. holding inside IOM FIC)
    investorTaxDrag = targetYieldAmount * 0.00; // 0% inter-company or local corporate holding tax drag!
  }

  const netInvestorYield = targetYieldAmount - investorTaxDrag;

  // National Economic impact
  const totalEconomicImpact = investorAllocation * project.nationalEconomicMultiplier;

  // Carbon credits offset matching investor equity
  const annualCarbonOffset = project.carbonOffsetTons * investorEquityPct;

  // Format Helper
  const fmt = (v: number) => {
    let currencyCode = 'GBP';
    if (profile.currency === '£') currencyCode = 'GBP';
    else if (profile.currency === '$') currencyCode = 'USD';
    else if (profile.currency === '€') currencyCode = 'EUR';
    else if (profile.currency && profile.currency.length === 3) currencyCode = profile.currency;

    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currencyCode,
      maximumFractionDigits: 0,
    }).format(v);
  };
  return (
    <div className="space-y-6" id="infrastructure-model-panel">
      {/* Module Title */}
      <div className="border-b border-white/10 pb-4">
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2 font-serif">
          <Activity className="w-5 h-5 text-[#C5A059]" />
          Infrastructure Investor Tax Model
        </h2>
        <p className="text-xs text-gray-400">
          Model target yields, capital allowances, national economic multipliers, and environmental carbon credits inside EVWM co-investment portfolios.
        </p>
      </div>

      {/* Selector & Allocation board */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Project Choice Left */}
        <div className="lg:col-span-4 space-y-4">
          <h3 className="text-sm font-semibold tracking-wider text-[#C5A059] uppercase font-serif pb-1 border-b border-white/10">Strategic Co-Investment Select</h3>
          
          <div className="space-y-2">
            {INFRASTRUCTURE_PROJECTS.map(p => {
              const active = p.id === selectedProjectId;
              return (
                <button
                  key={p.id}
                  onClick={() => setSelectedProjectId(p.id)}
                  className={`w-full text-left p-3.5 rounded-lg border transition-all flex justify-between items-center ${active ? 'bg-[#111A36] border-[#C5A059]/60 shadow-md' : 'bg-white/5 border-white/5 hover:border-white/10 text-gray-300'}`}
                >
                  <div className="space-y-1">
                    <span className="text-[9px] uppercase tracking-wider text-[#C5A059]/80 font-bold">{p.category}</span>
                    <h4 className="text-xs font-bold text-white truncate max-w-[180px] font-serif">{p.name}</h4>
                  </div>
                  <ChevronRight className={`w-4 h-4 ${active ? 'text-[#C5A059]' : 'text-gray-500'}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Investment Details Right */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-[#0A1128]/95 border border-[#C5A059]/15 p-5 rounded-lg grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">My Co-Investment Allocation</label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-[#C5A059] font-mono text-sm">{profile.currency}</span>
                <input
                  type="number"
                  value={investorAllocation}
                  onChange={(e) => setInvestorAllocation(Number(e.target.value))}
                  className="w-full bg-[#040914] border border-white/10 rounded px-3 py-2 pl-8 text-sm font-mono text-white focus:outline-none focus:border-[#C5A059]"
                />
              </div>
              <span className="text-[10px] text-gray-500 mt-1 block">Project cap: {fmt(project.initialCapital)}</span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">My Asset Wrap Structure</label>
              <div className="grid grid-cols-2 gap-2">
                {(['Personal', 'Corporate'] as const).map(type => (
                  <button
                    key={type}
                    onClick={() => setWrapperType(type)}
                    className={`py-2 rounded text-xs font-semibold transition-all ${wrapperType === type ? 'bg-[#C5A059] text-black font-bold font-serif shadow' : 'bg-white/5 text-gray-400 border border-white/10 hover:border-[#C5A059]/25'}`}
                  >
                    {type} Hold
                  </button>
                ))}
              </div>
              <span className="text-[10px] text-gray-500 mt-1 block">Corporate wrapper mitigates immediate distribution tax drag</span>
            </div>
          </div>

          {/* Institutional Dashboard cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-[#0A1128] border border-[#C5A059]/15 p-4 rounded-lg shadow-md">
              <span className="block text-[10px] text-gray-400 uppercase tracking-wider">Equity Allocation Share</span>
              <span className="text-base font-bold text-white font-mono mt-1 block">{(investorEquityPct * 100).toFixed(4)}%</span>
            </div>
            
            <div className="bg-[#0A1128] border border-[#C5A059]/15 p-4 rounded-lg shadow-md">
              <span className="block text-[10px] text-gray-400 uppercase tracking-wider">Target Project IRR</span>
              <span className="text-base font-bold text-[#C5A059] font-mono mt-1 block">{(project.targetIRR * 100).toFixed(1)}%</span>
            </div>

            <div className="bg-[#0A1128] border border-[#C5A059]/15 p-4 rounded-lg shadow-md">
              <span className="block text-[10px] text-gray-400 uppercase tracking-wider">Net Yield Payout</span>
              <span className="text-base font-bold text-emerald-400 font-mono mt-1 block">{fmt(netInvestorYield)}</span>
            </div>

            <div className="bg-[#0A1128] border border-[#C5A059]/15 p-4 rounded-lg shadow-md">
              <span className="block text-[10px] text-gray-400 uppercase tracking-wider">Economic Multiplier</span>
              <span className="text-base font-bold text-purple-400 font-mono mt-1 block">{project.nationalEconomicMultiplier}x</span>
            </div>
          </div>

          {/* Economic and ESG Summary */}
          <div className="bg-[#0A1128] border border-[#C5A059]/15 p-5 rounded-lg space-y-4 shadow-xl">
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#C5A059] flex items-center gap-1.5 pb-2 border-b border-white/10 font-serif">
              <Activity className="w-4 h-4 text-[#C5A059]" />
              Socio-Economic & Green Impact Accounting
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-gray-300">
              <div className="space-y-2">
                <span className="text-white font-semibold block font-serif">National Economic Stimulus</span>
                <p className="leading-relaxed">
                  Your allocation of <span className="text-white font-bold">{fmt(investorAllocation)}</span> directly stimulates commercial spending, labor supply chains, and peripheral tax revenues totaling <span className="text-purple-400 font-bold">{fmt(totalEconomicImpact)}</span> across the sovereign economy.
                </p>
                <div className="flex items-center gap-1 text-emerald-400 font-bold font-mono">
                  <Award className="w-4 h-4" /> Regional multiplier active
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-white font-semibold block font-serif">Environmental Offset Accounting</span>
                <p className="leading-relaxed">
                  Under strict ESG definitions, this green infrastructure investment accounts for a proportional net environmental offset of <span className="text-emerald-400 font-bold font-mono">{annualCarbonOffset.toFixed(1)} tons</span> of CO2 equivalent per annum.
                </p>
                <div className="flex items-center gap-1 text-emerald-400 font-bold font-mono">
                  <Leaf className="w-4 h-4" /> Carbon offset certified
                </div>
              </div>
            </div>
          </div>

          {/* Tax Warning Allowances */}
          <div className="bg-[#C5A059]/5 border border-[#C5A059]/25 p-4 rounded-lg flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-[#C5A059] shrink-0 mt-0.5" />
            <div className="text-xs text-gray-400 space-y-1">
              <span className="font-semibold text-[#C5A059] block font-serif">Sovereign Capital Allowances & Tax Relief</span>
              <p>
                Infrastructure co-investments qualify for advanced Capital Allowances, shielding up to 100% of construction capital expenditure against corporate profits. Green energy allocations (such as solar arrays) also trigger Enterprise Investment Schemes (EIS) or Manx Development exemptions depending on the legal wrap structure. Consult our infrastructure desk for optimal corporate structuring.
              </p>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
