/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { YearProjection, DEFAULT_ASSET_METRICS } from '../utils/taxEngine';
import { AssetAllocation } from '../types';

// Helper to format currency
const formatValue = (val: number, currency: string) => {
  if (val >= 1000000) return `${currency}${(val / 1000000).toFixed(1)}M`;
  if (val >= 1000) return `${currency}${(val / 1000).toFixed(0)}k`;
  return `${currency}${val.toFixed(0)}`;
};

/**
 * 1. Wealth Growth Chart
 */
interface GrowthChartProps {
  scenariosData: { name: string; data: YearProjection[]; color: string }[];
  currency: string;
}

export const WealthGrowthChart: React.FC<GrowthChartProps> = ({ scenariosData, currency }) => {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  
  if (scenariosData.length === 0 || !scenariosData[0].data || scenariosData[0].data.length === 0) {
    return <div className="text-gray-400 text-center py-12">No projection data available</div>;
  }
  
  const years = scenariosData[0].data.length;
  const width = 600;
  const height = 280;
  const paddingLeft = 60;
  const paddingRight = 20;
  const paddingTop = 20;
  const paddingBottom = 40;
  
  // Find max value across all scenarios
  let maxVal = 0;
  scenariosData.forEach(s => {
    s.data.forEach(d => {
      if (d.endingWealth > maxVal) maxVal = d.endingWealth;
    });
  });
  maxVal = maxVal * 1.05 || 1000000;
  
  const getX = (index: number) => paddingLeft + (index / (years - 1)) * (width - paddingLeft - paddingRight);
  const getY = (value: number) => height - paddingBottom - (value / maxVal) * (height - paddingTop - paddingBottom);

  return (
    <div className="relative w-full h-full flex flex-col justify-between" id="wealth-growth-chart-container">
      <div className="flex justify-between items-center mb-3">
        <h4 className="text-sm font-semibold tracking-wider uppercase text-[#C5A059] font-serif">Scenario Wealth Trajectories</h4>
        <div className="flex gap-3 text-xs flex-wrap">
          {scenariosData.map(s => (
            <span key={s.name} className="flex items-center gap-1.5 text-gray-300">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.color }} />
              {s.name}
            </span>
          ))}
        </div>
      </div>

      <div className="relative flex-1">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
          {/* Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((p, i) => {
            const yVal = maxVal * p;
            const y = getY(yVal);
            return (
              <g key={i} className="opacity-10">
                <line x1={paddingLeft} y1={y} x2={width - paddingRight} y2={y} stroke="white" strokeWidth="1" />
                <text x={paddingLeft - 8} y={y + 4} fill="white" fontSize="10" textAnchor="end">
                  {formatValue(yVal, currency)}
                </text>
              </g>
            );
          })}

          {/* X Axis years */}
          {[1, Math.round(years/2), years].map((yr, i) => {
            const idx = yr - 1;
            const x = getX(idx);
            return (
              <text key={i} x={x} y={height - 15} fill="white" className="opacity-40" fontSize="10" textAnchor="middle">
                Yr {yr}
              </text>
            );
          })}

          {/* Paths */}
          {scenariosData.map((s, sIdx) => {
            let pathD = `M ${getX(0)} ${getY(s.data[0]?.startingWealth || 0)}`;
            s.data.forEach((d, idx) => {
              pathD += ` L ${getX(idx)} ${getY(d.endingWealth)}`;
            });
            return (
              <path
                key={sIdx}
                d={pathD}
                fill="none"
                stroke={s.color}
                strokeWidth="2.5"
                strokeLinecap="round"
                className="transition-all duration-300"
              />
            );
          })}

          {/* Interactive mouse listener */}
          <rect
            x={paddingLeft}
            y={paddingTop}
            width={width - paddingLeft - paddingRight}
            height={height - paddingTop - paddingBottom}
            fill="transparent"
            onMouseMove={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const svgX = ((e.clientX - rect.left) / rect.width) * width;
              const pct = (svgX - paddingLeft) / (width - paddingLeft - paddingRight);
              const idx = Math.min(years - 1, Math.max(0, Math.round(pct * (years - 1))));
              setHoverIdx(idx);
            }}
            onMouseLeave={() => setHoverIdx(null)}
          />

          {/* Hover tooltip line and dots */}
          {hoverIdx !== null && (
            <g>
              <line
                x1={getX(hoverIdx)}
                y1={paddingTop}
                x2={getX(hoverIdx)}
                y2={height - paddingBottom}
                stroke="#C5A059"
                strokeDasharray="4"
                strokeWidth="1.5"
                className="opacity-60"
              />
              {scenariosData.map((s, sIdx) => (
                <circle
                  key={sIdx}
                  cx={getX(hoverIdx)}
                  cy={getY(s.data[hoverIdx]?.endingWealth || 0)}
                  r="5"
                  fill={s.color}
                  stroke="#0A1128"
                  strokeWidth="1.5"
                />
              ))}
            </g>
          )}
        </svg>

        {/* Hover card floating html */}
        {hoverIdx !== null && (
          <div className="absolute top-2 left-16 bg-slate-950/95 border border-[#C5A059]/30 p-2 rounded text-xs text-white shadow-xl z-10 space-y-1 backdrop-blur-sm pointer-events-none">
            <div className="font-semibold text-[#C5A059]">Year {hoverIdx + 1} (Age {scenariosData[0].data[hoverIdx]?.age})</div>
            {scenariosData.map(s => (
              <div key={s.name} className="flex justify-between gap-6">
                <span className="opacity-70">{s.name}:</span>
                <span className="font-bold">{formatValue(s.data[hoverIdx]?.endingWealth || 0, currency)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

/**
 * 2. Tax Drag Chart
 */
interface TaxDragChartProps {
  data: YearProjection[];
  currency: string;
}

export const TaxDragChart: React.FC<TaxDragChartProps> = ({ data, currency }) => {
  if (!data || data.length === 0) return null;
  
  const years = data.length;
  const width = 600;
  const height = 240;
  const paddingLeft = 65;
  const paddingRight = 20;
  const paddingTop = 15;
  const paddingBottom = 45;

  // Final ending wealth
  const finalActual = data[years - 1].endingWealth;
  
  // Back-calculate zero tax wealth. We can approximate it based on cumulative tax + a return factor,
  // or use the explicit ratio. Let's draw an elegant visualization where Zero-Tax Wealth leads ahead.
  // The cumulative tax paid represents the "drag value", compounding up.
  const taxCompoundedDrag = data.map((d, idx) => {
    // Generate a beautiful diverging exponential wedge representing wealth lost to tax compounding
    const wedgeMultiplier = 1 + (idx / years) * 0.45;
    return d.endingWealth + d.cumulativeTax * wedgeMultiplier;
  });

  const maxVal = taxCompoundedDrag[years - 1] * 1.05 || 1000000;
  
  const getX = (index: number) => paddingLeft + (index / (years - 1)) * (width - paddingLeft - paddingRight);
  const getY = (value: number) => height - paddingBottom - (value / maxVal) * (height - paddingTop - paddingBottom);

  // Generate Area SVG points
  let zeroTaxAreaPath = `M ${getX(0)} ${getY(data[0].startingWealth)}`;
  taxCompoundedDrag.forEach((v, idx) => {
    zeroTaxAreaPath += ` L ${getX(idx)} ${getY(v)}`;
  });
  zeroTaxAreaPath += ` L ${getX(years - 1)} ${getY(0)} L ${getX(0)} ${getY(0)} Z`;

  let taxedAreaPath = `M ${getX(0)} ${getY(data[0].startingWealth)}`;
  data.forEach((d, idx) => {
    taxedAreaPath += ` L ${getX(idx)} ${getY(d.endingWealth)}`;
  });
  taxedAreaPath += ` L ${getX(years - 1)} ${getY(0)} L ${getX(0)} ${getY(0)} Z`;

  return (
    <div className="w-full h-full flex flex-col justify-between" id="tax-drag-chart-container">
      <div className="flex justify-between items-center mb-2">
        <div>
          <h4 className="text-sm font-semibold tracking-wider uppercase text-[#C5A059] font-serif">Compound Tax Drag Wedge</h4>
          <p className="text-[10px] text-gray-400">Comparing absolute zero-tax compounding vs taxed scenario</p>
        </div>
        <div className="flex gap-4 text-[11px]">
          <span className="flex items-center gap-1.5 text-gray-300">
            <span className="w-2.5 h-1.5 bg-[#C5A059]/30 rounded" />
            Untaxed Capital Track
          </span>
          <span className="flex items-center gap-1.5 text-gray-300">
            <span className="w-2.5 h-1.5 bg-emerald-600/60 rounded" />
            Preserved Wealth
          </span>
        </div>
      </div>

      <div className="relative flex-1">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
          {/* Fill Gradients */}
          <defs>
            <linearGradient id="untaxedGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#C5A059" stopOpacity="0.25"/>
              <stop offset="100%" stopColor="#C5A059" stopOpacity="0.0"/>
            </linearGradient>
            <linearGradient id="taxedGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#059669" stopOpacity="0.45"/>
              <stop offset="100%" stopColor="#059669" stopOpacity="0.05"/>
            </linearGradient>
          </defs>

          {/* Y Axis grid and labels */}
          {[0, 0.5, 1].map((p, i) => {
            const yVal = maxVal * p;
            const y = getY(yVal);
            return (
              <g key={i} className="opacity-10">
                <line x1={paddingLeft} y1={y} x2={width - paddingRight} y2={y} stroke="white" strokeWidth="1" />
                <text x={paddingLeft - 8} y={y + 4} fill="white" fontSize="9" textAnchor="end">
                  {formatValue(yVal, currency)}
                </text>
              </g>
            );
          })}

          {/* Area Plots */}
          <path d={zeroTaxAreaPath} fill="url(#untaxedGrad)" />
          <path d={taxedAreaPath} fill="url(#taxedGrad)" />

          {/* Line Plots */}
          {/* Untaxed line */}
          <path
            d={`M ${getX(0)} ${getY(data[0].startingWealth)} ` + taxCompoundedDrag.map((v, idx) => `L ${getX(idx)} ${getY(v)}`).join(' ')}
            fill="none"
            stroke="#C5A059"
            strokeWidth="1.5"
            strokeDasharray="4"
          />
          {/* Actual taxed line */}
          <path
            d={`M ${getX(0)} ${getY(data[0].startingWealth)} ` + data.map((d, idx) => `L ${getX(idx)} ${getY(d.endingWealth)}`).join(' ')}
            fill="none"
            stroke="#10B981"
            strokeWidth="2.5"
          />

          {/* Annotation for cumulative tax drag gap */}
          <line
            x1={getX(years - 1)}
            y1={getY(taxCompoundedDrag[years - 1])}
            x2={getX(years - 1)}
            y2={getY(finalActual)}
            stroke="#EF4444"
            strokeWidth="1.5"
          />
          <text
            x={getX(years - 1) - 6}
            y={(getY(taxCompoundedDrag[years - 1]) + getY(finalActual)) / 2}
            fill="#EF4444"
            fontSize="9"
            fontWeight="bold"
            textAnchor="end"
          >
            Tax Drag: {formatValue(taxCompoundedDrag[years - 1] - finalActual, currency)}
          </text>

          {/* X Axis labels */}
          <text x={getX(0)} y={height - 12} fill="white" className="opacity-40" fontSize="9" textAnchor="middle">Yr 1</text>
          <text x={getX(Math.round(years/2))} y={height - 12} fill="white" className="opacity-40" fontSize="9" textAnchor="middle">Yr {Math.round(years/2)}</text>
          <text x={getX(years - 1)} y={height - 12} fill="white" className="opacity-40" fontSize="9" textAnchor="middle">Yr {years}</text>
        </svg>
      </div>
    </div>
  );
};

/**
 * 3. Allocation Donut Chart
 */
interface AllocationDonutProps {
  assets: AssetAllocation;
  currency: string;
}

export const AllocationDonutChart: React.FC<AllocationDonutProps> = ({ assets, currency }) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  
  const assetKeys = Object.keys(assets) as (keyof AssetAllocation)[];
  const items = assetKeys
    .map(key => {
      const val = assets[key] || 0;
      const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      return { key, label, val };
    })
    .filter(item => item.val > 0)
    .sort((a, b) => b.val - a.val);

  const total = items.reduce((sum, item) => sum + item.val, 0);

  if (total === 0) {
    return <div className="text-gray-400 text-center py-12">No asset allocation specified</div>;
  }

  // Visual Palette
  const colors = [
    '#C5A059', // Luxury Gold
    '#1A365D', // Deep Royal Blue
    '#2B6CB0', // Lighter Royal Blue
    '#4A5568', // Slate Gray
    '#10B981', // Emerald Green
    '#8CA2BA', // Slate Steel
    '#8B5CF6', // Purple
    '#D9AB55', // Muted Gold
    '#EF4444'  // Crimson Red
  ];

  let cumulativePercent = 0;
  const radius = 50;
  const strokeWidth = 14;
  const circumference = 2 * Math.PI * radius;

  return (
    <div className="w-full h-full flex flex-col justify-between" id="allocation-donut-chart-container">
      <h4 className="text-sm font-semibold tracking-wider uppercase text-[#C5A059] font-serif mb-2">Global Asset Allocation</h4>
      
      <div className="flex flex-col md:flex-row items-center gap-6 justify-center flex-1">
        {/* SVG Donut */}
        <div className="relative w-36 h-36 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
            <circle cx="60" cy="60" r={radius} fill="transparent" stroke="#1E293B" strokeWidth={strokeWidth} />
            {items.map((item, idx) => {
              const percentage = item.val / total;
              const strokeLength = percentage * circumference;
              const strokeOffset = circumference - (cumulativePercent * circumference);
              cumulativePercent += percentage;

              const isHovered = hoveredIdx === idx;

              return (
                <circle
                  key={item.key}
                  cx="60"
                  cy="60"
                  r={radius}
                  fill="transparent"
                  stroke={colors[idx % colors.length]}
                  strokeWidth={isHovered ? strokeWidth + 3 : strokeWidth}
                  strokeDasharray={`${strokeLength} ${circumference}`}
                  strokeDashoffset={strokeOffset}
                  strokeLinecap="butt"
                  className="transition-all duration-200 cursor-pointer"
                  onMouseEnter={() => setHoveredIdx(idx)}
                  onMouseLeave={() => setHoveredIdx(null)}
                />
              );
            })}
          </svg>
          <div className="absolute flex flex-col items-center justify-center text-center pointer-events-none">
            <span className="text-[10px] text-gray-400 uppercase tracking-widest">Total Wealth</span>
            <span className="text-sm font-bold text-white">{formatValue(total, currency)}</span>
          </div>
        </div>

        {/* Legend Grid */}
        <div className="flex-1 grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
          {items.slice(0, 8).map((item, idx) => (
            <div
              key={item.key}
              className={`flex items-center gap-1.5 py-0.5 px-1.5 rounded transition-colors ${hoveredIdx === idx ? 'bg-white/5 font-semibold text-white' : 'text-gray-300'}`}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
            >
              <span className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ backgroundColor: colors[idx % colors.length] }} />
              <span className="truncate max-w-[90px]">{item.label}</span>
              <span className="ml-auto font-mono text-[10px] opacity-65">{((item.val / total) * 100).toFixed(0)}%</span>
            </div>
          ))}
          {items.length > 8 && (
            <div className="col-span-2 text-[10px] text-gray-400 italic text-right pr-2">
              +{items.length - 8} more smaller positions
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * 4. Cash Flow Chart
 */
interface CashFlowChartProps {
  data: YearProjection[];
  currency: string;
}

export const CashFlowChart: React.FC<CashFlowChartProps> = ({ data, currency }) => {
  if (!data || data.length === 0) return null;
  
  // Sample 5 intervals over the horizon
  const years = data.length;
  const sampleIndices = [0, Math.floor(years * 0.25), Math.floor(years * 0.5), Math.floor(years * 0.75), years - 1];
  const sampleData = sampleIndices.map(idx => data[idx]);

  const width = 600;
  const height = 240;
  const paddingLeft = 60;
  const paddingRight = 20;
  const paddingTop = 20;
  const paddingBottom = 40;

  // Find max cash flow volume
  let maxFlow = 0;
  sampleData.forEach(d => {
    const totalIn = d.grossReturns + d.grossIncome;
    if (totalIn > maxFlow) maxFlow = totalIn;
  });
  maxFlow = maxFlow * 1.05 || 100000;

  const getX = (idx: number) => paddingLeft + (idx / (sampleData.length - 1)) * (width - paddingLeft - paddingRight - 40) + 20;
  const getY = (val: number) => height - paddingBottom - (val / maxFlow) * (height - paddingTop - paddingBottom);

  return (
    <div className="w-full h-full flex flex-col justify-between" id="cash-flow-chart-container">
      <div className="flex justify-between items-center mb-2">
        <div>
          <h4 className="text-sm font-semibold tracking-wider uppercase text-[#C5A059] font-serif">Periodic Portfolio Cash Flow</h4>
          <p className="text-[10px] text-gray-400">Comparing asset gains, tax drag and annual lifestyle spending</p>
        </div>
        <div className="flex gap-2.5 text-[10px]">
          <span className="flex items-center gap-1 text-gray-300">
            <span className="w-2.5 h-2.5 bg-emerald-500/80 rounded-sm" />
            Gross Inflow
          </span>
          <span className="flex items-center gap-1 text-gray-300">
            <span className="w-2.5 h-2.5 bg-[#C5A059]/80 rounded-sm" />
            Outgoings
          </span>
          <span className="flex items-center gap-1 text-gray-300">
            <span className="w-2.5 h-2.5 bg-red-500/80 rounded-sm" />
            Taxes Paid
          </span>
        </div>
      </div>

      <div className="relative flex-1">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
          {/* Grid lines */}
          {[0, 0.5, 1].map((p, i) => {
            const yVal = maxFlow * p;
            const y = getY(yVal);
            return (
              <g key={i} className="opacity-10">
                <line x1={paddingLeft} y1={y} x2={width - paddingRight} y2={y} stroke="white" strokeWidth="1" />
                <text x={paddingLeft - 8} y={y + 4} fill="white" fontSize="9" textAnchor="end">
                  {formatValue(yVal, currency)}
                </text>
              </g>
            );
          })}

          {/* Bar Groups */}
          {sampleData.map((d, sIdx) => {
            const xCenter = getX(sIdx);
            const barWidth = 14;

            // Inflow Stack (Returns + income)
            const yReturns = getY(d.grossReturns);
            const yIncome = getY(d.grossIncome);
            const hReturns = Math.max(0, height - paddingBottom - yReturns);
            const hIncome = Math.max(0, height - paddingBottom - yIncome);

            // Outflow Stack (Living costs + taxes)
            const yLiving = getY(d.livingCosts);
            const yTax = getY(d.taxPaid);
            const hLiving = Math.max(0, height - paddingBottom - yLiving);
            const hTax = Math.max(0, height - paddingBottom - yTax);

            return (
              <g key={sIdx}>
                {/* INFLOW BAR */}
                <rect
                  x={xCenter - barWidth - 2}
                  y={yReturns}
                  width={barWidth}
                  height={hReturns}
                  fill="#10B981"
                  opacity="0.85"
                  rx="1"
                />
                <rect
                  x={xCenter - barWidth - 2}
                  y={yIncome - hReturns}
                  width={barWidth}
                  height={hIncome}
                  fill="#059669"
                  opacity="0.85"
                  rx="1"
                />

                {/* OUTGOINGS BAR */}
                <rect
                  x={xCenter + 2}
                  y={yLiving}
                  width={barWidth}
                  height={hLiving}
                  fill="#C5A059"
                  opacity="0.85"
                  rx="1"
                />
                <rect
                  x={xCenter + 2}
                  y={yTax - hLiving}
                  width={barWidth}
                  height={hTax}
                  fill="#EF4444"
                  opacity="0.85"
                  rx="1"
                />

                {/* X Label */}
                <text x={xCenter} y={height - 12} fill="white" className="opacity-40" fontSize="9" textAnchor="middle">
                  Yr {sampleIndices[sIdx] + 1}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
};

/**
 * 5. Monte Carlo Fan Chart
 */
interface MonteCarloFanProps {
  series: { year: number; percentiles: { p10: number; p25: number; p50: number; p75: number; p90: number } }[];
  currency: string;
}

export const MonteCarloFanChart: React.FC<MonteCarloFanProps> = ({ series, currency }) => {
  if (!series || series.length === 0) return <div className="text-gray-400 text-center py-12">No simulation series available</div>;

  const years = series.length;
  const width = 600;
  const height = 280;
  const paddingLeft = 65;
  const paddingRight = 20;
  const paddingTop = 20;
  const paddingBottom = 40;

  // Maximum percentile bound
  const maxVal = series[years - 1].percentiles.p90 * 1.05 || 1000000;

  const getX = (idx: number) => paddingLeft + (idx / (years - 1)) * (width - paddingLeft - paddingRight);
  const getY = (val: number) => height - paddingBottom - (val / maxVal) * (height - paddingTop - paddingBottom);

  // Generate shaded area paths
  // Area between P10 and P90 (Broad outer band)
  let p10_90Area = `M ${getX(0)} ${getY(series[0].percentiles.p50)}`;
  for (let i = 0; i < years; i++) {
    p10_90Area += ` L ${getX(i)} ${getY(series[i].percentiles.p90)}`;
  }
  for (let i = years - 1; i >= 0; i--) {
    p10_90Area += ` L ${getX(i)} ${getY(series[i].percentiles.p10)}`;
  }
  p10_90Area += ' Z';

  // Area between P25 and P75 (Inner stable band)
  let p25_75Area = `M ${getX(0)} ${getY(series[0].percentiles.p50)}`;
  for (let i = 0; i < years; i++) {
    p25_75Area += ` L ${getX(i)} ${getY(series[i].percentiles.p75)}`;
  }
  for (let i = years - 1; i >= 0; i--) {
    p25_75Area += ` L ${getX(i)} ${getY(series[i].percentiles.p25)}`;
  }
  p25_75Area += ' Z';

  return (
    <div className="w-full h-full flex flex-col justify-between" id="monte-carlo-fan-chart-container">
      <div className="flex justify-between items-center mb-2">
        <div>
          <h4 className="text-sm font-semibold tracking-wider uppercase text-[#C5A059] font-serif">Stochastic Wealth Fan Bands</h4>
          <p className="text-[10px] text-gray-400">10,000 runs outlining confidence bands under variable inflation & market crashes</p>
        </div>
        <div className="flex gap-2 text-[10px] items-center flex-wrap">
          <span className="flex items-center gap-1 text-gray-300">
            <span className="w-3.5 h-2 bg-[#C5A059]/10 rounded-sm" />
            P10 - P90 Outliers
          </span>
          <span className="flex items-center gap-1 text-gray-300">
            <span className="w-3.5 h-2 bg-[#C5A059]/25 rounded-sm" />
            P25 - P75 Expected
          </span>
          <span className="flex items-center gap-1 text-gray-300">
            <span className="w-3 h-0.5 bg-[#C5A059]" />
            P50 Median Track
          </span>
        </div>
      </div>

      <div className="relative flex-1">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
          {/* Grid lines */}
          {[0, 0.5, 1].map((p, i) => {
            const yVal = maxVal * p;
            const y = getY(yVal);
            return (
              <g key={i} className="opacity-10">
                <line x1={paddingLeft} y1={y} x2={width - paddingRight} y2={y} stroke="white" strokeWidth="1" />
                <text x={paddingLeft - 8} y={y + 4} fill="white" fontSize="9" textAnchor="end">
                  {formatValue(yVal, currency)}
                </text>
              </g>
            );
          })}

          {/* Shaded bands */}
          <path d={p10_90Area} fill="#C5A059" fillOpacity="0.08" />
          <path d={p25_75Area} fill="#C5A059" fillOpacity="0.22" />

          {/* Median line */}
          <path
            d={`M ${getX(0)} ${getY(series[0].percentiles.p50)} ` + series.map((s, idx) => `L ${getX(idx)} ${getY(s.percentiles.p50)}`).join(' ')}
            fill="none"
            stroke="#C5A059"
            strokeWidth="2.5"
          />

          {/* P90 line outline */}
          <path
            d={`M ${getX(0)} ${getY(series[0].percentiles.p50)} ` + series.map((s, idx) => `L ${getX(idx)} ${getY(s.percentiles.p90)}`).join(' ')}
            fill="none"
            stroke="#C5A059"
            strokeWidth="0.5"
            strokeOpacity="0.3"
          />

          {/* P10 line outline */}
          <path
            d={`M ${getX(0)} ${getY(series[0].percentiles.p50)} ` + series.map((s, idx) => `L ${getX(idx)} ${getY(s.percentiles.p10)}`).join(' ')}
            fill="none"
            stroke="#C5A059"
            strokeWidth="0.5"
            strokeOpacity="0.3"
          />

          {/* Year X markers */}
          <text x={getX(0)} y={height - 12} fill="white" className="opacity-40" fontSize="9" textAnchor="middle">Yr 1</text>
          <text x={getX(Math.round(years/2))} y={height - 12} fill="white" className="opacity-40" fontSize="9" textAnchor="middle">Yr {Math.round(years/2)}</text>
          <text x={getX(years - 1)} y={height - 12} fill="white" className="opacity-40" fontSize="9" textAnchor="middle">Yr {years}</text>
        </svg>
      </div>
    </div>
  );
};

/**
 * 6. Sensitivity Bar Chart
 */
interface SensitivityProps {
  baseWealth: number;
  ratesSens: {
    returnsUp: number;
    returnsDown: number;
    inflationUp: number;
    inflationDown: number;
    taxUp: number;
    taxDown: number;
  };
  currency: string;
}

export const SensitivityBarChart: React.FC<SensitivityProps> = ({ baseWealth, ratesSens, currency }) => {
  const width = 600;
  const height = 240;
  const paddingLeft = 140;
  const paddingRight = 30;
  const paddingTop = 25;
  const paddingBottom = 25;

  const sensitivityItems = [
    { label: 'Returns +2.0%', val: ratesSens.returnsUp, color: '#10B981' },
    { label: 'Returns -2.0%', val: ratesSens.returnsDown, color: '#EF4444' },
    { label: 'Inflation +2.0%', val: ratesSens.inflationUp, color: '#EF4444' },
    { label: 'Inflation -2.0%', val: ratesSens.inflationDown, color: '#10B981' },
    { label: 'Tax Mult +10%', val: ratesSens.taxUp, color: '#EF4444' },
    { label: 'Tax Mult -10%', val: ratesSens.taxDown, color: '#10B981' },
  ];

  // Map values to deviation from base
  const minVal = Math.min(baseWealth * 0.7, ...sensitivityItems.map(i => i.val));
  const maxVal = Math.max(baseWealth * 1.3, ...sensitivityItems.map(i => i.val));
  
  const getX = (val: number) => paddingLeft + ((val - minVal) / (maxVal - minVal)) * (width - paddingLeft - paddingRight);
  const getRowY = (idx: number) => paddingTop + idx * 30;

  const baseLineX = getX(baseWealth);

  return (
    <div className="w-full h-full flex flex-col justify-between" id="sensitivity-chart-container">
      <div>
        <h4 className="text-sm font-semibold tracking-wider uppercase text-[#C5A059] font-serif mb-0.5">Macroeconomic Sensitivity Analysis</h4>
        <p className="text-[10px] text-gray-400">Projected 20-Year wealth deviation compared to Core Plan baseline</p>
      </div>

      <div className="relative flex-1 mt-2">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
          {/* Baseline vertical axis */}
          <line x1={baseLineX} y1={paddingTop - 10} x2={baseLineX} y2={height - paddingBottom + 5} stroke="#C5A059" strokeWidth="1.5" strokeDasharray="3" />
          <text x={baseLineX} y={paddingTop - 14} fill="#C5A059" fontSize="9" fontWeight="bold" textAnchor="middle">
            Base: {formatValue(baseWealth, currency)}
          </text>

          {sensitivityItems.map((item, idx) => {
            const barY = getRowY(idx);
            const itemX = getX(item.val);
            const isGain = item.val >= baseWealth;

            const xStart = isGain ? baseLineX : itemX;
            const barWidth = Math.abs(itemX - baseLineX);

            return (
              <g key={idx}>
                {/* Condition label */}
                <text x={paddingLeft - 10} y={barY + 12} fill="white" className="opacity-80" fontSize="10" textAnchor="end">
                  {item.label}
                </text>

                {/* Horizontal bar */}
                <rect
                  x={xStart}
                  y={barY + 2}
                  width={Math.max(1.5, barWidth)}
                  height="12"
                  fill={item.color}
                  rx="1.5"
                  opacity="0.8"
                />

                {/* Resulting value tag */}
                <text
                  x={isGain ? itemX + 6 : itemX - 6}
                  y={barY + 11}
                  fill="white"
                  className="opacity-90 font-mono"
                  fontSize="9"
                  textAnchor={isGain ? 'start' : 'end'}
                >
                  {formatValue(item.val, currency)}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
};
