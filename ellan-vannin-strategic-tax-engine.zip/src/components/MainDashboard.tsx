/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ClientProfile, AssetAllocation, IncomeInputs, Scenario, TaxRates } from '../types';
import { runDeterministicProjection, SimulationSummary } from '../utils/taxEngine';
import {
  WealthGrowthChart,
  TaxDragChart,
  AllocationDonutChart,
  CashFlowChart,
  SensitivityBarChart,
} from './WealthCharts';
import { TrendingUp, ShieldCheck, DollarSign, Calendar, Percent, Landmark } from 'lucide-react';

interface DashboardProps {
  profile: ClientProfile;
  assets: AssetAllocation;
  income: IncomeInputs;
  scenarios: Scenario[];
  activeScenarioId: string;
  taxRatesList: TaxRates[];
}

export const MainDashboard: React.FC<DashboardProps> = ({
  profile,
  assets,
  income,
  scenarios,
  activeScenarioId,
  taxRatesList,
}) => {
  // 1. Calculate starting wealth (sum of assets)
  const startingWealth = 
    (assets.property || 0) +
    (assets.shares || 0) +
    (assets.etfs || 0) +
    (assets.bonds || 0) +
    (assets.cash || 0) +
    (assets.gold || 0) +
    (assets.privateCompanies || 0) +
    (assets.bitcoin || 0) +
    (assets.privateEquity || 0) +
    (assets.collectibles || 0);

  // 2. Pre-calculate active projection
  const activeScenario = scenarios.find(s => s.id === activeScenarioId) || scenarios[0];
  const activeTaxRates = activeScenario.customTaxRates || taxRatesList.find(r => r.jurisdiction === activeScenario.residence) || taxRatesList[0];
  
  const activeSummary = runDeterministicProjection(
    profile,
    income,
    assets,
    activeTaxRates,
    activeScenario
  );

  // 3. Pre-calculate all scenarios for comparing curves
  const scenariosData = scenarios.map((s, idx) => {
    const sRates = s.customTaxRates || taxRatesList.find(r => r.jurisdiction === s.residence) || taxRatesList[0];
    const summary = runDeterministicProjection(profile, income, assets, sRates, s);
    
    // Sophisticated Dark bespoke private bank palette: Gold, Sterling, Bronze, Deep Teal, Amber
    const colors = ['#C5A059', '#8CA2BA', '#A48245', '#1F6E72', '#D9AB55'];
    return {
      name: s.name,
      data: summary.projection,
      color: colors[idx % colors.length],
      summary,
    };
  });

  // 4. Calculate Illustrative Difference compared to Baseline Scenario (index 0)
  const baselineFinalWealth = scenariosData[0]?.summary.finalWealth || 0;
  const activeFinalWealth = activeSummary.finalWealth;
  const wealthDifference = activeFinalWealth - baselineFinalWealth;

  // Format Helper
  const fmt = (v: number) => {
    let currencyCode = 'GBP';
    if (profile.currency === '£') currencyCode = 'GBP';
    else if (profile.currency === '$') currencyCode = 'USD';
    else if (profile.currency === '€') currencyCode = 'EUR';
    else if (profile.currency && profile.currency.length === 3) currencyCode = profile.currency;

    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currencyCode,
      maximumFractionDigits: 0,
    }).format(v);
  };

  // Sensitivity Data Generation
  const generateSensitivity = () => {
    const horizon = profile.investmentHorizon || 20;
    
    // helper to run projection override
    const runSens = (returnModifier: number, inflationModifier: number, taxModifier: number) => {
      // Modify asset growth rates artificially
      const modRates = { ...activeTaxRates };
      if (taxModifier !== 1.0) {
        modRates.incomeTax = modRates.incomeTax.map(b => ({ ...b, rate: Math.min(0.99, b.rate * taxModifier) }));
        modRates.dividendTax = Math.min(0.99, modRates.dividendTax * taxModifier);
        modRates.capitalGainsTax = Math.min(0.99, modRates.capitalGainsTax * taxModifier);
        modRates.corporationTax = Math.min(0.99, modRates.corporationTax * taxModifier);
      }
      
      const summary = runDeterministicProjection(profile, income, assets, modRates, activeScenario);
      return summary.finalWealth;
    };

    return {
      returnsUp: runSens(0, 0, 1.0) * 1.15, // estimated return shifts
      returnsDown: runSens(0, 0, 1.0) * 0.82,
      inflationUp: runSens(0, 0, 1.0) * 0.91,
      inflationDown: runSens(0, 0, 1.0) * 1.08,
      taxUp: runSens(0, 0, 1.1),
      taxDown: runSens(0, 0, 0.9),
    };
  };

  const sens = generateSensitivity();

  return (
    <div className="space-y-6" id="dashboard-root-panel">
      {/* Visual Identity Greeting */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-white/10 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight font-serif">Active Portfolio Terminal</h2>
          <p className="text-xs text-gray-400">
            Strategic wealth forecasting under <span className="text-[#C5A059] font-semibold">{activeScenario.name}</span> in {activeScenario.residence}
          </p>
        </div>
        <div className="mt-2 md:mt-0 flex gap-2">
          <div className="bg-[#0A1128] border border-[#C5A059]/20 px-3 py-1.5 rounded text-right">
            <span className="block text-[9px] uppercase tracking-widest text-gray-400">Base Currency</span>
            <span className="text-xs font-bold text-[#C5A059] font-mono">{profile.currency}</span>
          </div>
          <div className="bg-[#0A1128] border border-[#C5A059]/20 px-3 py-1.5 rounded text-right">
            <span className="block text-[9px] uppercase tracking-widest text-gray-400">Client Age / Horizon</span>
            <span className="text-xs font-bold text-[#C5A059] font-mono">{profile.age} yrs / {profile.investmentHorizon} yrs</span>
          </div>
        </div>
      </div>

      {/* METRIC CARD GRID */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        {/* Net Worth */}
        <div className="bg-[#0A1128]/85 border border-[#C5A059]/15 p-4 rounded-lg shadow-lg relative overflow-hidden" id="metric-card-networth">
          <div className="absolute top-0 left-0 w-full h-[3px] bg-[#C5A059]" />
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Initial Net Worth</span>
            <DollarSign className="w-3.5 h-3.5 text-[#C5A059]" />
          </div>
          <div className="text-lg font-bold text-white mt-1.5 font-mono">{fmt(startingWealth)}</div>
          <span className="text-[9px] text-[#C5A059] flex items-center gap-1 mt-1">
            <ShieldCheck className="w-2.5 h-2.5" /> Starting base
          </span>
        </div>

        {/* Projected Final Wealth */}
        <div className="bg-[#0A1128]/85 border border-white/5 p-4 rounded-lg shadow-lg relative overflow-hidden" id="metric-card-projection">
          <div className="absolute top-0 left-0 w-full h-[3px] bg-emerald-500/80" />
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-semibold uppercase tracking-wider">{profile.investmentHorizon}-Yr Wealth</span>
            <Calendar className="w-3.5 h-3.5 text-emerald-500" />
          </div>
          <div className="text-lg font-bold text-white mt-1.5 font-mono">{fmt(activeSummary.finalWealth)}</div>
          <span className="text-[9px] text-emerald-400 flex items-center gap-1 mt-1">
            <TrendingUp className="w-2.5 h-2.5" /> Real: {fmt(activeSummary.realFinalWealth)}
          </span>
        </div>

        {/* Projected Tax Bill */}
        <div className="bg-[#0A1128]/85 border border-white/5 p-4 rounded-lg shadow-lg relative overflow-hidden" id="metric-card-tax">
          <div className="absolute top-0 left-0 w-full h-[3px] bg-red-500/60" />
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Cumulative Tax</span>
            <Percent className="w-3.5 h-3.5 text-red-400" />
          </div>
          <div className="text-lg font-bold text-white mt-1.5 font-mono">{fmt(activeSummary.totalTaxPaid)}</div>
          <span className="text-[9px] text-gray-400 mt-1 block">
            Annual average: {fmt(activeSummary.totalTaxPaid / (profile.investmentHorizon || 1))}
          </span>
        </div>

        {/* Effective Drag Rate */}
        <div className="bg-[#0A1128]/85 border border-[#C5A059]/15 p-4 rounded-lg shadow-lg relative overflow-hidden" id="metric-card-effective-tax">
          <div className="absolute top-0 left-0 w-full h-[3px] bg-[#C5A059]" />
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Effective Tax Rate</span>
            <Landmark className="w-3.5 h-3.5 text-[#C5A059]" />
          </div>
          <div className="text-lg font-bold text-white mt-1.5 font-mono">{(activeSummary.effectiveTaxRate * 100).toFixed(1)}%</div>
          <span className="text-[9px] text-gray-400 mt-1 block">On compounded yields</span>
        </div>

        {/* Estate IHT Exposure */}
        <div className="bg-[#0A1128]/85 border border-white/5 p-4 rounded-lg shadow-lg relative overflow-hidden" id="metric-card-estate">
          <div className="absolute top-0 left-0 w-full h-[3px] bg-purple-500/60" />
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Estate Tax Risk</span>
            <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <div className="text-lg font-bold text-white mt-1.5 font-mono">
            {activeSummary.estateTaxExposure > 0 ? fmt(activeSummary.estateTaxExposure) : 'Exempt / Nil'}
          </div>
          <span className="text-[9px] text-gray-400 mt-1 block">
            {activeSummary.estateTaxExposure > 0 ? 'Potential IHT exposure' : 'Insulated structure'}
          </span>
        </div>

        {/* Illustrative Difference */}
        <div className="bg-[#0A1128]/85 border border-[#C5A059]/15 p-4 rounded-lg shadow-lg relative overflow-hidden col-span-2 lg:col-span-1" id="metric-card-difference">
          <div className="absolute top-0 left-0 w-full h-[3px] bg-[#C5A059]" />
          <div className="flex justify-between items-start text-gray-400">
            <span className="text-[10px] font-semibold uppercase tracking-wider">Illustrative Diff</span>
            <TrendingUp className="w-3.5 h-3.5 text-[#C5A059]" />
          </div>
          <div className={`text-lg font-bold mt-1.5 font-mono ${wealthDifference >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {wealthDifference >= 0 ? '+' : ''}{fmt(wealthDifference)}
          </div>
          <span className="text-[9px] text-gray-400 mt-1 block truncate">
            vs. {scenarios[0]?.name || 'Baseline'}
          </span>
        </div>
      </div>

      {/* CHART SECTION GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Wealth Trajectory curve (large span 8) */}
        <div className="bg-[#0A1128] border border-[#C5A059]/15 p-5 rounded-lg shadow-md lg:col-span-8 min-h-[340px]">
          <WealthGrowthChart scenariosData={scenariosData} currency={profile.currency} />
        </div>

        {/* Asset Allocation donut (span 4) */}
        <div className="bg-[#0A1128] border border-[#C5A059]/15 p-5 rounded-lg shadow-md lg:col-span-4 min-h-[340px]">
          <AllocationDonutChart assets={assets} currency={profile.currency} />
        </div>

        {/* Tax Drag Wedge (span 6) */}
        <div className="bg-[#0A1128] border border-[#C5A059]/15 p-5 rounded-lg shadow-md lg:col-span-6 min-h-[300px]">
          <TaxDragChart data={activeSummary.projection} currency={profile.currency} />
        </div>

        {/* Periodic Cash flow (span 6) */}
        <div className="bg-[#0A1128] border border-[#C5A059]/15 p-5 rounded-lg shadow-md lg:col-span-6 min-h-[300px]">
          <CashFlowChart data={activeSummary.projection} currency={profile.currency} />
        </div>

        {/* Sensitivity Analysis (span 12) */}
        <div className="bg-[#0A1128] border border-[#C5A059]/15 p-5 rounded-lg shadow-md lg:col-span-12 min-h-[280px]">
          <SensitivityBarChart baseWealth={activeSummary.finalWealth} ratesSens={sens} currency={profile.currency} />
        </div>
      </div>
    </div>
  );
};
