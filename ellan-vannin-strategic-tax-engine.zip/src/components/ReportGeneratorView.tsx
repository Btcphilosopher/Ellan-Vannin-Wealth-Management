/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ClientProfile, AssetAllocation, IncomeInputs, Scenario, TaxRates } from '../types';
import { runDeterministicProjection } from '../utils/taxEngine';
import { FileText, Printer, Download, Sparkles, Brain, Loader2, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface ReportProps {
  profile: ClientProfile;
  assets: AssetAllocation;
  income: IncomeInputs;
  scenarios: Scenario[];
  taxRatesList: TaxRates[];
}

export const ReportGeneratorView: React.FC<ReportProps> = ({
  profile,
  assets,
  income,
  scenarios,
  taxRatesList,
}) => {
  const [aiBriefing, setAiBriefing] = useState<string>('');
  const [loadingAi, setLoadingAi] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string>('');

  // Starting capital
  const startingCapital = 
    (assets.property || 0) +
    (assets.shares || 0) +
    (assets.etfs || 0) +
    (assets.bonds || 0) +
    (assets.cash || 0) +
    (assets.gold || 0) +
    (assets.privateCompanies || 0) +
    (assets.bitcoin || 0) +
    (assets.privateEquity || 0) +
    (assets.collectibles || 0);

  // Precompute projections for reporting
  const reportsData = scenarios.map(s => {
    const sRates = s.customTaxRates || taxRatesList.find(r => r.jurisdiction === s.residence) || taxRatesList[0];
    const summary = runDeterministicProjection(profile, income, assets, sRates, s);
    return {
      scenario: s,
      summary,
    };
  });

  // Print trigger
  const handlePrint = () => {
    window.print();
  };

  // Trigger Gemini AI advisor summary on Express backend
  const fetchAiBriefing = async () => {
    setLoadingAi(true);
    setAiError('');
    setAiBriefing('');

    try {
      const response = await fetch('/api/gemini/advisor', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          profile,
          income,
          assets,
          scenarios: scenarios.map(s => ({
            name: s.name,
            residence: s.residence,
            structure: s.businessStructure
          }))
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to retrieve AI Advisory analysis');
      }

      const data = await response.json();
      if (data.briefing) {
        setAiBriefing(data.briefing);
      } else {
        setAiBriefing('The wealth committee advisory is compiled and ready.');
      }
    } catch (err: any) {
      setAiError(err.message || 'An error occurred while compiling AI analysis.');
    } finally {
      setLoadingAi(false);
    }
  };

  const fmt = (v: number) => {
    let currencyCode = 'GBP';
    if (profile.currency === '£') currencyCode = 'GBP';
    else if (profile.currency === '$') currencyCode = 'USD';
    else if (profile.currency === '€') currencyCode = 'EUR';
    else if (profile.currency && profile.currency.length === 3) currencyCode = profile.currency;

    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currencyCode,
      maximumFractionDigits: 0,
    }).format(v);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto" id="report-panel-container">
      {/* Report Controls bar (Hidden on print) */}
      <div className="bg-[#0A1128]/95 border border-[#C5A059]/15 p-4 rounded-lg flex flex-col md:flex-row justify-between items-center gap-4 print:hidden shadow-xl">
        <div>
          <h3 className="text-sm font-bold text-white tracking-tight font-serif">Report Distribution Desk</h3>
          <p className="text-[10px] text-gray-400">Compile formal planning document. Supported print layouts and PDF-ready styling.</p>
        </div>
        <div className="flex gap-2.5">
          <button
            onClick={fetchAiBriefing}
            disabled={loadingAi}
            className="flex items-center gap-2 bg-[#C5A059] hover:bg-[#C5A059]/95 text-black px-4 py-2 rounded text-xs font-bold shadow-md disabled:opacity-50 transition-all cursor-pointer font-serif"
          >
            {loadingAi ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                Compiling EVWM AI Briefing...
              </>
            ) : (
              <>
                <Brain className="w-3.5 h-3.5 text-black" />
                Query AI Advisor briefing
              </>
            )}
          </button>
          
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 px-3 py-2 rounded text-xs font-semibold transition-colors cursor-pointer hover:border-[#C5A059]/20"
          >
            <Printer className="w-3.5 h-3.5 text-[#C5A059]" /> Print Report / PDF
          </button>
        </div>
      </div>

      {/* Formal Executive PDF Sheet */}
      <div className="bg-white text-slate-900 p-8 md:p-12 rounded-lg shadow-2xl space-y-8 print:shadow-none print:p-0" id="formal-print-sheet">
        {/* Header Branding */}
        <div className="flex justify-between items-start border-b-2 border-slate-900 pb-6">
          <div className="space-y-1">
            <h1 className="text-lg font-black tracking-widest uppercase text-slate-900 font-serif">Ellan Vannin</h1>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-[#C5A059]">Wealth Management</p>
            <p className="text-[9px] text-slate-500 italic">Strategic Tax & Capital Preservation Engine</p>
          </div>
          <div className="text-right text-[10px] font-semibold text-slate-500 space-y-0.5">
            <p>Formal Report Ref: EVWM-TAX-2026</p>
            <p>Date: {new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
            <p>Analyst: tom@ahyx.org</p>
          </div>
        </div>

        {/* Executive summary block */}
        <div className="space-y-3">
          <h2 className="text-xs font-extrabold uppercase tracking-widest text-slate-900 border-b border-slate-300 pb-1">I. Executive Summary</h2>
          <p className="text-xs leading-relaxed text-slate-700">
            This confidential strategic tax review has been prepared for the designated household assets totaling <strong className="text-slate-900">{fmt(startingCapital)}</strong>. This review evaluates capital preservation horizons under progressive tax structures across designated legal environments (including the Isle of Man, United Kingdom, and offshore jurisdictions). The comparative models demonstrate the mathematical efficiency of corporate wrapping wrappers and trust shields to insulate multi-generational compounding from excessive fiscal drag.
          </p>
        </div>

        {/* Client Demographic Profile */}
        <div className="space-y-3">
          <h2 className="text-xs font-extrabold uppercase tracking-widest text-slate-900 border-b border-slate-300 pb-1">II. Client Fact-Find Assumptions</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-50 p-4 rounded border border-slate-200 text-xs">
            <div>
              <span className="block text-[9px] uppercase tracking-wider text-slate-500 font-bold">Client Age / Horizon</span>
              <span className="font-mono text-slate-900 font-bold">{profile.age} Years / {profile.investmentHorizon} Years</span>
            </div>
            <div>
              <span className="block text-[9px] uppercase tracking-wider text-slate-500 font-bold">Tax Residence Target</span>
              <span className="text-slate-900 font-bold">{profile.taxResidence}</span>
            </div>
            <div>
              <span className="block text-[9px] uppercase tracking-wider text-slate-500 font-bold">Retirement Target Age</span>
              <span className="font-mono text-slate-900 font-bold">{profile.retirementAge} Years</span>
            </div>
            <div>
              <span className="block text-[9px] uppercase tracking-wider text-slate-500 font-bold">Reporting Currency</span>
              <span className="font-mono text-slate-900 font-bold">{profile.currency}</span>
            </div>
          </div>
        </div>

        {/* Scenario Comparison metrics */}
        <div className="space-y-4">
          <h2 className="text-xs font-extrabold uppercase tracking-widest text-slate-900 border-b border-slate-300 pb-1">III. Comparative Planning Scenarios Table</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b-2 border-slate-900 text-[10px] font-bold uppercase tracking-wider text-slate-600">
                  <th className="py-2">Planning Scenario</th>
                  <th className="py-2">Jurisdiction</th>
                  <th className="py-2">Structure hold</th>
                  <th className="py-2 text-right">Cumulative Tax</th>
                  <th className="py-2 text-right">Final Wealth</th>
                  <th className="py-2 text-right">Preserved Capital</th>
                </tr>
              </thead>
              <tbody>
                {reportsData.map((rd, idx) => {
                  const finalWealth = rd.summary.finalWealth;
                  const ratio = finalWealth / startingCapital;
                  return (
                    <tr key={rd.scenario.id} className="border-b border-slate-200 text-slate-800">
                      <td className="py-2.5 font-bold text-slate-950 font-serif">{rd.scenario.name}</td>
                      <td className="py-2.5 font-mono">{rd.scenario.residence}</td>
                      <td className="py-2.5">{rd.scenario.businessStructure}</td>
                      <td className="py-2.5 text-right font-mono text-red-700">{fmt(rd.summary.totalTaxPaid)}</td>
                      <td className="py-2.5 text-right font-mono text-slate-950 font-bold">{fmt(finalWealth)}</td>
                      <td className="py-2.5 text-right font-mono text-emerald-700 font-bold">
                        {(ratio * 100).toFixed(0)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* AI Advisory Briefing Section (Renders only if loaded) */}
        {aiBriefing && (
          <div className="bg-[#C5A059]/5 border-l-4 border-[#C5A059] p-5 rounded space-y-3" id="ai-advisor-briefing-sheet">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold uppercase tracking-widest text-xs">
              <Sparkles className="w-4 h-4 text-[#C5A059]" />
              EVWM AI Wealth Advisory Committee Briefing
            </div>
            <div className="text-xs text-slate-800 leading-relaxed space-y-2 whitespace-pre-wrap font-sans">
              {aiBriefing}
            </div>
            <span className="text-[9px] text-slate-500 block italic">Compiled dynamically on behalf of Ellan Vannin Wealth Management using Gemini AI models.</span>
          </div>
        )}

        {aiError && (
          <div className="bg-red-50 text-red-800 border-l-4 border-red-500 p-3 rounded text-xs">
            <p className="font-semibold">Briefing Error:</p>
            <p>{aiError}</p>
          </div>
        )}

        {/* Risk Assessment Matrix */}
        <div className="space-y-3">
          <h2 className="text-xs font-extrabold uppercase tracking-widest text-slate-900 border-b border-slate-300 pb-1">IV. Risk and Compliance Factors</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px] text-slate-700 leading-relaxed">
            <div className="border border-slate-200 p-3 rounded">
              <span className="font-bold text-slate-900 block mb-1">Tax Legislation Risk</span>
              <p>
                Sovereign states modify income tax brackets, corporate exemptions, and inheritance rules periodically. Holding wealth in the Isle of Man offers stability through cross-party constitutional treaties, though direct modifications by the UK Treasury can impact offshore wrapper treaty relationships.
              </p>
            </div>
            <div className="border border-slate-200 p-3 rounded">
              <span className="font-bold text-slate-900 block mb-1">Anti-Avoidance (GAAR) Compliance</span>
              <p>
                Any strategic wrapping structure must exhibit clear commercial substance rather than sole tax avoidance intent. General Anti-Abuse Rules (GAAR) require family offices to demonstrate structural board meetings, operational costs, and physical presence in jurisdictions like Douglas.
              </p>
            </div>
          </div>
        </div>

        {/* Institutional Disclaimer */}
        <div className="border-t border-slate-300 pt-6 text-[9px] text-slate-500 leading-relaxed space-y-2">
          <span className="font-bold text-slate-900 uppercase block">Confidential Wealth Advisory Disclaimer:</span>
          <p>
            The strategic models, tax multipliers, and final projections generated in this strategic wealth review are for illustrative purposes only and do not constitute formal, binding legal or tax advice. Past asset yields are not indicative of future performance. Legal planning must be reviewed by independent certified advocates in the respective jurisdictions prior to capital relocation or structural settlement.
          </p>
          <p className="text-center font-bold tracking-widest text-slate-400 pt-4">ELLAN VANNIN WEALTH MANAGEMENT © {new Date().getFullYear()}</p>
        </div>
      </div>
    </div>
  );
};
