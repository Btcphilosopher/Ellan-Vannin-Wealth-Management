/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Google Gen AI server-side using telemetry headers
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Server-side Gemini endpoint for wealth briefing
app.post('/api/gemini/advisor', async (req, res) => {
  try {
    const { profile, income, assets, scenarios } = req.body;

    const prompt = `
      You are the Elite Investment Committee of Ellan Vannin Wealth Management, an institutional private wealth bank in Douglas, Isle of Man.
      Analyze the following client wealth planning scenarios and write a professional, highly sophisticated executive briefing.
      
      Client Demographic:
      - Age: ${profile?.age}
      - Investment Horizon: ${profile?.investmentHorizon} Years
      - Retirement Age: ${profile?.retirementAge}
      - Target Currency: ${profile?.currency}
      
      Simulated Asset Base:
      ${JSON.stringify(assets || {}, null, 2)}
      
      Annual Inflow Profile:
      ${JSON.stringify(income || {}, null, 2)}
      
      Simulated Scenarios:
      ${JSON.stringify(scenarios || [], null, 2)}
      
      Please structure your response with:
      - 1. STRATEGIC OVERVIEW: Summarize how shifting residency (such as to the Isle of Man) or utilizing corporate Family Investment Companies protects capital compounding.
      - 2. WRAPPER EFFICIENCY: Compare Direct Ownership vs Corporate wrappers, explaining the concept of 'tax drag' and corporate dividend compounding.
      - 3. MULTI-GENERATIONAL INSULATION: Address Trust shielding and Family Succession readiness, identifying steps to freeze inheritance exposure.
      
      Use a highly professional, conservative, and polished tone. Speak as an elite wealth advisor. Avoid generic SaaS adjectives or fluff. Maintain precision.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
    });

    res.json({ briefing: response.text });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    res.status(500).json({ error: 'Failed to generate advisory briefing', details: error.message });
  }
});

// Setup static files or development Vite middleware
async function setupServer() {
  if (process.env.NODE_ENV !== 'production') {
    console.log('Starting server in development mode (Vite middleware enabled)...');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    console.log('Starting server in production mode (Serving pre-built static assets)...');
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Ellan Vannin Strategic Tax Engine running at http://localhost:${PORT}`);
  });
}

setupServer();
