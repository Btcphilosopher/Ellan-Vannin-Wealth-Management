import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Health Check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", system: "AirportOS Digital Twin Engine", timestamp: new Date().toISOString() });
  });

  // Gemini AI Operations Assistant Endpoint
  app.post("/api/ai/analyze-operations", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({
          error: "GEMINI_API_KEY is not configured in the environment variables.",
        });
      }

      const { prompt, airportContext } = req.body;

      const ai = new GoogleGenAI({ apiKey });
      const systemInstruction = `You are AirportOS Control Tower AI, an expert airport operations, slot allocation, and disruption recovery AI decision-support assistant.
You specialize in evaluating runway throughput, aircraft turnaround critical paths, wake turbulence separation, stand conflict mitigation, passenger connection risk, and economic capacity trade-offs.
Provide concise, highly actionable, expert operational advice in clear markdown format.
Never claim to be a certified air-traffic controller; emphasize that recommendations are for operational decision support.`;

      const userPrompt = `AIRPORT CONTEXT:
${JSON.stringify(airportContext, null, 2)}

USER QUERY / OPERATIONAL ISSUE:
${prompt}

Provide a structured operational assessment and recommended optimisation or recovery plan:`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: userPrompt,
        config: {
          systemInstruction,
          temperature: 0.3,
        },
      });

      res.json({ analysis: response.text });
    } catch (err: any) {
      console.error("Gemini AI API Error:", err);
      res.status(500).json({ error: err.message || "Failed to process AI operations analysis." });
    }
  });

  // Vite middleware setup for dev vs static in prod
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[AirportOS Engine] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
