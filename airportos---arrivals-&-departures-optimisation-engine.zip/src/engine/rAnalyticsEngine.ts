import {
  Flight,
  ConnectingPassengerGroup,
  SecurityCapacityState,
  ImmigrationCapacityState,
  CapacityInvestmentProject,
} from "../types/airport";

/**
 * R ANALYTICS & STATISTICAL ENGINE SIMULATOR
 * Emulates R's statistical distributions (fable, forecast, survival, igraph, duckdb)
 * for Monte Carlo simulations, queueing models (M/M/c), delay propagation, and economics.
 */

export class RAnalyticsEngine {
  /**
   * Monte Carlo Delay Forecast
   * Runs 1,000 statistical iterations using Log-Normal distribution to estimate delay probability curve
   */
  public static runMonteCarloDelaySimulation(
    flight: Flight,
    iterations: number = 1000
  ): {
    p50DelayMinutes: number;
    p90DelayMinutes: number;
    p99DelayMinutes: number;
    holdingProbabilityPercent: number;
    distribution: { delayRange: string; frequencyPercent: number }[];
  } {
    const baseDelay = flight.delayMinutes || 0;
    const mu = Math.log(Math.max(1, baseDelay + 5));
    const sigma = 0.45; // Turnaround delay variance parameter

    const simulatedDelays: number[] = [];
    let holdingCount = 0;

    for (let i = 0; i < iterations; i++) {
      // Box-Muller transform for normal random variable
      const u1 = Math.random();
      const u2 = Math.random();
      const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);

      const logNormalVal = Math.exp(mu + sigma * z0) - 5;
      const delay = Math.max(0, Math.round(logNormalVal));
      simulatedDelays.push(delay);

      if (delay > 15) holdingCount++;
    }

    simulatedDelays.sort((a, b) => a - b);

    const p50 = simulatedDelays[Math.floor(iterations * 0.5)];
    const p90 = simulatedDelays[Math.floor(iterations * 0.9)];
    const p99 = simulatedDelays[Math.floor(iterations * 0.99)];
    const holdingProb = Math.round((holdingCount / iterations) * 100);

    // Group into histogram buckets
    const histogram = [
      { delayRange: "0-5 min", frequencyPercent: 0 },
      { delayRange: "6-15 min", frequencyPercent: 0 },
      { delayRange: "16-30 min", frequencyPercent: 0 },
      { delayRange: "31-60 min", frequencyPercent: 0 },
      { delayRange: "> 60 min", frequencyPercent: 0 },
    ];

    simulatedDelays.forEach((d) => {
      if (d <= 5) histogram[0].frequencyPercent++;
      else if (d <= 15) histogram[1].frequencyPercent++;
      else if (d <= 30) histogram[2].frequencyPercent++;
      else if (d <= 60) histogram[3].frequencyPercent++;
      else histogram[4].frequencyPercent++;
    });

    histogram.forEach((h) => {
      h.frequencyPercent = Math.round((h.frequencyPercent / iterations) * 100);
    });

    return {
      p50DelayMinutes: p50,
      p90DelayMinutes: p90,
      p99DelayMinutes: p99,
      holdingProbabilityPercent: holdingProb,
      distribution: histogram,
    };
  }

  /**
   * M/M/c Queueing Theory Forecast for Terminal Security & Border Control
   * Models arrival rate (lambda), service rate per lane (mu), and open lanes (c)
   */
  public static calculateQueueingForecast(
    arrivalRatePaxPerHr: number,
    serviceRatePerLanePaxPerHr: number,
    openLanes: number
  ): {
    serverUtilisationPercent: number;
    averageQueueLength: number;
    averageWaitTimeMinutes: number;
    recommendedLanesToMaintainSub5MinWait: number;
  } {
    const lambda = arrivalRatePaxPerHr / 60; // pax per min
    const mu = serviceRatePerLanePaxPerHr / 60; // pax per min per lane
    const c = openLanes;

    const rho = lambda / (c * mu);
    const utilisation = Math.min(99, Math.round(rho * 100));

    // Erlang-C approximation for average queue length
    let avgQueue = 0;
    if (rho < 1) {
      avgQueue = Math.round((Math.pow(c * rho, c) * rho) / (1 - rho));
    } else {
      avgQueue = Math.round(lambda * 25); // Over-capacity building queue
    }

    const avgWaitMins = Math.max(1, Number((avgQueue / (lambda || 1)).toFixed(1)));

    // Calculate required lanes for < 5 min wait
    let requiredLanes = c;
    if (avgWaitMins > 5) {
      requiredLanes = Math.ceil(arrivalRatePaxPerHr / serviceRatePerLanePaxPerHr) + 2;
    }

    return {
      serverUtilisationPercent: utilisation,
      averageQueueLength: Math.max(12, avgQueue),
      averageWaitTimeMinutes: avgWaitMins,
      recommendedLanesToMaintainSub5MinWait: requiredLanes,
    };
  }

  /**
   * Connection Risk Probability Evaluator
   * Calculates probability that connecting passenger group misses outbound flight
   */
  public static evaluateConnectionRisk(
    group: ConnectingPassengerGroup,
    inboundDelayMinutes: number
  ): {
    missProbabilityPercent: number;
    remainingBufferMinutes: number;
    actionRecommendation: string;
  } {
    const effectiveAvailableTime = group.minimumConnectionTimeMinutes - inboundDelayMinutes;
    const requiredTime = group.estimatedTransferTimeMinutes;

    const remainingBuffer = effectiveAvailableTime - requiredTime;

    let missProb = 0;
    if (remainingBuffer <= 0) {
      missProb = Math.min(99, 85 + Math.abs(remainingBuffer) * 3);
    } else if (remainingBuffer < 10) {
      missProb = 45 + (10 - remainingBuffer) * 4;
    } else if (remainingBuffer < 20) {
      missProb = 15;
    } else {
      missProb = 2;
    }

    let recommendation = "Standard transfer flow; no operational intervention required.";
    if (missProb > 75) {
      recommendation = "CRITICAL: Dispatch priority electric buggy & fast-track luggage escort at inbound gate.";
    } else if (missProb > 40) {
      recommendation = "HIGH RISK: Request 7-minute departure hold on outbound flight or assign priority transfer lane.";
    }

    return {
      missProbabilityPercent: Math.round(missProb),
      remainingBufferMinutes: remainingBuffer,
      actionRecommendation: recommendation,
    };
  }

  /**
   * Network Delay Propagation Model (Downstream Flight Rotations)
   * Predicts how a delay on Flight 1 cascades across 4 downstream legs
   */
  public static simulateRotationDelayPropagation(
    initialFlightNumber: string,
    initialDelayMinutes: number,
    rotationChain: string[] = ["BA101 (LHR-CDG)", "BA102 (CDG-LHR)", "BA103 (LHR-FCO)", "BA104 (FCO-LHR)"]
  ): { flight: string; predictedDelayMinutes: number; recoveredMinutes: number }[] {
    const results = [];
    let currentDelay = initialDelayMinutes;

    for (let i = 0; i < rotationChain.length; i++) {
      const flightName = rotationChain[i];
      // Buffer absorption in schedule (~10 mins schedule buffer per leg)
      const bufferRecovered = Math.min(currentDelay, 10);
      currentDelay = Math.max(0, currentDelay - bufferRecovered);

      results.push({
        flight: flightName,
        predictedDelayMinutes: currentDelay,
        recoveredMinutes: bufferRecovered,
      });

      // Compound operational noise
      currentDelay += Math.floor(Math.random() * 4);
    }

    return results;
  }

  /**
   * Capital Investment Financial Model (NPV / IRR / Capacity Value)
   */
  public static calculateInvestmentReturn(
    capexPounds: number,
    annualOpexPounds: number,
    annualRevenuePounds: number,
    discountRate: number = 0.08,
    years: number = 20
  ): { npv: number; irr: number; paybackYears: number; valueRatio: number } {
    const netAnnualCashFlow = annualRevenuePounds - annualOpexPounds;

    // Discounted Cash Flow NPV
    let npv = -capexPounds;
    for (let t = 1; t <= years; t++) {
      npv += netAnnualCashFlow / Math.pow(1 + discountRate, t);
    }

    const simplePayback = Number((capexPounds / (netAnnualCashFlow || 1)).toFixed(1));
    const irrEstimate = Number(((netAnnualCashFlow / capexPounds) * 100).toFixed(1));
    const valueRatio = Number((npv / capexPounds).toFixed(2));

    return {
      npv: Math.round(npv),
      irr: irrEstimate,
      paybackYears: simplePayback,
      valueRatio,
    };
  }
}
