/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Navbar } from "./components/Navbar";
import { ControlTower } from "./components/ControlTower";
import { DigitalTwinMap } from "./components/DigitalTwinMap";
import { ArrivalsBoard } from "./components/ArrivalsBoard";
import { DeparturesBoard } from "./components/DeparturesBoard";
import { TurnaroundView } from "./components/TurnaroundView";
import { CapacityHeatmaps } from "./components/CapacityHeatmaps";
import { DisruptionSimulator } from "./components/DisruptionSimulator";
import { InvestmentPlanner } from "./components/InvestmentPlanner";
import { GeminiAssistantModal } from "./components/GeminiAssistantModal";

import {
  INITIAL_RUNWAYS,
  INITIAL_GATES,
  INITIAL_TAXI_NODES,
  INITIAL_TAXI_EDGES,
  INITIAL_FLIGHTS,
  INITIAL_TURNAROUNDS,
  INITIAL_DISRUPTIONS,
  INITIAL_INVESTMENT_PROJECTS,
  INITIAL_HEATMAP,
  INITIAL_WEATHER,
} from "./engine/mockAirportData";

import {
  Flight,
  Runway,
  GateStand,
  TurnaroundProcess,
  TurnaroundTask,
  DisruptionEvent,
  ControlTowerMetrics,
} from "./types/airport";

import { RustEngineSimulator } from "./engine/rustEngineSimulation";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("tower");
  const [isSimRunning, setIsSimRunning] = useState<boolean>(true);
  const [simSpeed, setSimSpeed] = useState<number>(1);
  const [selectedFlightId, setSelectedFlightId] = useState<string>("FL-EK008");
  const [isGeminiAiOpen, setIsGeminiAiOpen] = useState<boolean>(false);

  // Core Digital Twin State
  const [runways, setRunways] = useState<Runway[]>(INITIAL_RUNWAYS);
  const [gates, setGates] = useState<GateStand[]>(INITIAL_GATES);
  const [flights, setFlights] = useState<Flight[]>(INITIAL_FLIGHTS);
  const [turnarounds, setTurnarounds] = useState<Record<string, TurnaroundProcess>>(INITIAL_TURNAROUNDS);
  const [disruptions, setDisruptions] = useState<DisruptionEvent[]>(INITIAL_DISRUPTIONS);
  const [eventLog, setEventLog] = useState<string[]>([
    "[18:00:00] AirportOS Digital Twin initialized. All 3 runways active.",
    "[18:01:20] FL-EK008 (A380-800) entering arrival approach corridor 09L.",
    "[18:02:45] Wake turbulence separation calculated: 180s between EK008 & BA210.",
    "[18:04:10] Stand Conflict Detected: Gate 201 occupied by EK008.",
    "[18:05:00] Disruption: T3 Catering truck hydraulic pump leak reported.",
  ]);

  // Simulation Clock Tick Loop
  useEffect(() => {
    if (!isSimRunning) return;

    const interval = setInterval(() => {
      // Periodic event generation
      const timeStr = new Date().toTimeString().substring(0, 8);
      const sampleEvents = [
        `[${timeStr}] FL-BA210 taxiing on Alpha 1 towards Gate 102 (Speed 14 kts).`,
        `[${timeStr}] Baggage unload task completed for FL-AA100 on Stand G301.`,
        `[${timeStr}] RWY 09R departure queue: 2 aircraft holding short.`,
        `[${timeStr}] M/M/c Queueing model update: Terminal 2 Security wait time 9.2 mins.`,
      ];

      const randomEvent = sampleEvents[Math.floor(Math.random() * sampleEvents.length)];
      setEventLog((prev) => [randomEvent, ...prev.slice(0, 40)]);
    }, 5000 / simSpeed);

    return () => clearInterval(interval);
  }, [isSimRunning, simSpeed]);

  // Calculate Control Tower Overview Metrics
  const metrics: ControlTowerMetrics = {
    arrivalsNext60m: flights.filter((f) => f.flightType === "Arrival").length,
    departuresNext60m: flights.filter((f) => f.flightType === "Departure").length,
    runwayUtilisationPercent: 88,
    gateUtilisationPercent: Math.round(
      (gates.filter((g) => g.status === "Occupied").length / gates.length) * 100
    ),
    standUtilisationPercent: 58,
    averageDelayMinutes: 7.4,
    aircraftAtRiskCount: flights.filter((f) => f.delayMinutes > 10).length,
    missedConnectionRiskPaxCount: 32,
    turnaroundCriticalRiskCount: 2,
    activeDisruptionsCount: disruptions.length,
    onTimeDepartureRatePercent: 91.2,
  };

  const handleTriggerOptimisation = () => {
    const optimizedArrivals = RustEngineSimulator.optimizeArrivalSequence(flights, runways[0]);
    const standConflicts = RustEngineSimulator.detectStandConflicts(flights, gates);

    const timeStr = new Date().toTimeString().substring(0, 8);
    setEventLog((prev) => [
      `[${timeStr}] RE-OPTIMISATION COMPLETE: Saved 42 minutes total delay across 9 flights.`,
      `[${timeStr}] Stand Conflicts Identified: ${standConflicts.length}. Reassigned FL-AA100 → Gate 303.`,
      ...prev,
    ]);

    // Update flight target landing times
    setFlights((prev) =>
      prev.map((f) => {
        const match = optimizedArrivals.find((o) => o.flightId === f.id);
        if (match) {
          return {
            ...f,
            targetLandingTime: match.optimizedTime,
            delayMinutes: match.delayMinutes,
          };
        }
        return f;
      })
    );
  };

  const handleUpdateTurnaroundTask = (flightId: string, taskId: string, status: TurnaroundTask["status"]) => {
    setTurnarounds((prev) => {
      const existing = prev[flightId];
      if (!existing) return prev;

      const updatedTasks = existing.tasks.map((t) =>
        t.id === taskId ? { ...t, status, progressPercent: status === "Completed" ? 100 : 50 } : t
      );

      const recalculated = RustEngineSimulator.calculateTurnaroundCriticalPath({
        ...existing,
        tasks: updatedTasks,
      });

      return {
        ...prev,
        [flightId]: recalculated,
      };
    });
  };

  const handleAddDisruption = (dis: DisruptionEvent) => {
    setDisruptions((prev) => [dis, ...prev]);
  };

  const handleResolveDisruption = (id: string) => {
    setDisruptions((prev) => prev.filter((d) => d.id !== id));
  };

  const handleResetData = () => {
    setRunways(INITIAL_RUNWAYS);
    setGates(INITIAL_GATES);
    setFlights(INITIAL_FLIGHTS);
    setTurnarounds(INITIAL_TURNAROUNDS);
    setDisruptions(INITIAL_DISRUPTIONS);
    setEventLog(["[SYSTEM] Digital twin state reset to baseline."]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-blue-600 selection:text-white pb-12">
      {/* Top Main Navigation Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        simSpeed={simSpeed}
        setSimSpeed={setSimSpeed}
        isSimRunning={isSimRunning}
        setIsSimRunning={setIsSimRunning}
        onResetData={handleResetData}
        onOpenGeminiAi={() => setIsGeminiAiOpen(true)}
        activeDisruptionsCount={disruptions.length}
        weatherCondition={INITIAL_WEATHER.condition}
      />

      {/* Main Container View Switcher */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === "tower" && (
          <ControlTower
            metrics={metrics}
            runways={runways}
            gates={gates}
            flights={flights}
            disruptions={disruptions}
            eventLog={eventLog}
            onTriggerOptimisation={handleTriggerOptimisation}
            onSelectFlight={(fId) => {
              setSelectedFlightId(fId);
              setActiveTab("turnaround");
            }}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === "twin" && (
          <DigitalTwinMap
            flights={flights}
            nodes={INITIAL_TAXI_NODES}
            edges={INITIAL_TAXI_EDGES}
            gates={gates}
            onSelectFlight={(fId) => {
              setSelectedFlightId(fId);
              setActiveTab("turnaround");
            }}
          />
        )}

        {activeTab === "arrivals" && (
          <ArrivalsBoard
            flights={flights}
            onSelectFlight={(fId) => {
              setSelectedFlightId(fId);
              setActiveTab("turnaround");
            }}
          />
        )}

        {activeTab === "departures" && (
          <DeparturesBoard
            flights={flights}
            onSelectFlight={(fId) => {
              setSelectedFlightId(fId);
              setActiveTab("turnaround");
            }}
          />
        )}

        {activeTab === "turnaround" && (
          <TurnaroundView
            flights={flights}
            turnarounds={turnarounds}
            selectedFlightId={selectedFlightId}
            onSelectFlight={setSelectedFlightId}
            onUpdateTurnaroundTask={handleUpdateTurnaroundTask}
          />
        )}

        {activeTab === "heatmaps" && <CapacityHeatmaps heatmapData={INITIAL_HEATMAP} />}

        {activeTab === "disruption" && (
          <DisruptionSimulator
            disruptions={disruptions}
            flights={flights}
            gates={gates}
            onAddDisruption={handleAddDisruption}
            onResolveDisruption={handleResolveDisruption}
          />
        )}

        {activeTab === "investment" && <InvestmentPlanner projects={INITIAL_INVESTMENT_PROJECTS} />}
      </main>

      {/* Gemini AI Operations Assistant Modal */}
      <GeminiAssistantModal
        isOpen={isGeminiAiOpen}
        onClose={() => setIsGeminiAiOpen(false)}
        metrics={metrics}
        flights={flights}
        disruptions={disruptions}
      />
    </div>
  );
}
