import React, { useState } from "react";
import {
  RotateCcw,
  Clock,
  AlertTriangle,
  CheckCircle2,
  CheckCircle,
  TrendingUp,
  Zap,
  ArrowRight,
  ShieldAlert,
  Users,
  Wrench,
  ChevronRight,
} from "lucide-react";
import { Flight, TurnaroundProcess, TurnaroundTask } from "../types/airport";
import { RustEngineSimulator } from "../engine/rustEngineSimulation";

interface TurnaroundViewProps {
  flights: Flight[];
  turnarounds: Record<string, TurnaroundProcess>;
  selectedFlightId: string;
  onSelectFlight: (flightId: string) => void;
  onUpdateTurnaroundTask: (flightId: string, taskId: string, status: TurnaroundTask["status"]) => void;
}

export const TurnaroundView: React.FC<TurnaroundViewProps> = ({
  flights,
  turnarounds,
  selectedFlightId,
  onSelectFlight,
  onUpdateTurnaroundTask,
}) => {
  const currentFlight = flights.find((f) => f.id === selectedFlightId) || flights[0];
  const rawTurnaround = turnarounds[currentFlight.id] || {
    flightId: currentFlight.id,
    scheduledDurationMinutes: 75,
    predictedDurationMinutes: 82,
    actualDurationMinutes: 20,
    minimumFeasibleMinutes: 65,
    riskLevel: "Medium",
    criticalConstraint: "Catering & Passenger Boarding",
    predictedDepartureDelayMinutes: 7,
    tasks: [
      { id: "T1", taskName: "Deplane Passengers", durationMinutes: 15, dependencies: [], status: "Completed", progressPercent: 100, criticalPath: true },
      { id: "T2", taskName: "Unload Baggage", durationMinutes: 20, dependencies: ["T1"], status: "In-Progress", progressPercent: 70, criticalPath: false },
      { id: "T3", taskName: "Cabin Cleaning", durationMinutes: 20, dependencies: ["T1"], status: "In-Progress", progressPercent: 50, criticalPath: false },
      { id: "T4", taskName: "Catering Replenishment", durationMinutes: 25, dependencies: ["T1"], status: "In-Progress", progressPercent: 40, criticalPath: true },
      { id: "T5", taskName: "Refuelling", durationMinutes: 25, dependencies: ["T1"], status: "Pending", progressPercent: 0, criticalPath: false },
      { id: "T9", taskName: "Passenger Boarding", durationMinutes: 30, dependencies: ["T3", "T4"], status: "Pending", progressPercent: 0, criticalPath: true },
      { id: "T10", taskName: "Doors Closure & Checks", durationMinutes: 10, dependencies: ["T9"], status: "Pending", progressPercent: 0, criticalPath: true },
      { id: "T11", taskName: "Tug Attachment & Pushback", durationMinutes: 8, dependencies: ["T10"], status: "Pending", progressPercent: 0, criticalPath: true },
    ],
  };

  const turnaround = RustEngineSimulator.calculateTurnaroundCriticalPath(rawTurnaround);

  return (
    <div className="space-y-6">
      {/* Top Header & Flight Switcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center">
            <RotateCcw className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">Aircraft Turnaround Digital Twin & DAG</h3>
            <p className="text-xs text-slate-400">Critical Path Analysis • Task Dependencies • Off-Block Delay Prediction</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <label className="text-xs text-slate-400 font-medium">Select Flight:</label>
          <select
            value={currentFlight.id}
            onChange={(e) => onSelectFlight(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-bold text-slate-200 focus:outline-none focus:border-blue-500"
          >
            {flights.map((f) => (
              <option key={f.id} value={f.id}>
                {f.flightNumber} ({f.airline} • {f.aircraftType})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Flight Summary Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Flight & Aircraft Info */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Aircraft / Stand</span>
          <div className="text-lg font-bold text-slate-100">{currentFlight.flightNumber}</div>
          <p className="text-xs text-slate-300">
            {currentFlight.aircraftType} • Stand <strong className="text-blue-400">{currentFlight.gateId}</strong>
          </p>
        </div>

        {/* Scheduled vs Predicted Duration */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Turnaround Time</span>
          <div className="text-lg font-bold text-slate-100">
            {turnaround.predictedDurationMinutes}m <span className="text-xs font-normal text-slate-400">(Sched: {turnaround.scheduledDurationMinutes}m)</span>
          </div>
          <p className="text-xs text-slate-300">Minimum Feasible: {turnaround.minimumFeasibleMinutes}m</p>
        </div>

        {/* Risk Level */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Turnaround Risk</span>
          <div>
            <span
              className={`px-2.5 py-1 rounded text-xs font-bold ${
                turnaround.riskLevel === "Critical"
                  ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                  : turnaround.riskLevel === "High"
                  ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                  : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
              }`}
            >
              {turnaround.riskLevel} Risk
            </span>
          </div>
          <p className="text-[11px] text-amber-400 font-medium pt-0.5">
            Predicted Delay: +{turnaround.predictedDepartureDelayMinutes} mins
          </p>
        </div>

        {/* Critical Constraint */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-1">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Critical Bottleneck</span>
          <div className="text-xs font-bold text-amber-300 line-clamp-2">{turnaround.criticalConstraint}</div>
          <p className="text-[11px] text-slate-400">Resource Allocated: Ramp Crew 4</p>
        </div>
      </div>

      {/* Turnaround Task Dependency Graph & Gantt */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-slate-100">
              Turnaround Dependency Graph (DAG Critical Path)
            </h3>
          </div>
          <div className="flex items-center space-x-3 text-xs">
            <span className="flex items-center space-x-1.5 text-amber-400 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <span>Critical Path</span>
            </span>
            <span className="flex items-center space-x-1.5 text-slate-400">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-600" />
              <span>Parallel Operation</span>
            </span>
          </div>
        </div>

        <div className="space-y-3">
          {turnaround.tasks.map((task) => (
            <div
              key={task.id}
              className={`border rounded-xl p-3.5 transition-all ${
                task.criticalPath
                  ? "bg-amber-950/20 border-amber-500/40 shadow-sm"
                  : "bg-slate-950/60 border-slate-800"
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => {
                      const nextStatus =
                        task.status === "Pending"
                          ? "In-Progress"
                          : task.status === "In-Progress"
                          ? "Completed"
                          : "Pending";
                      onUpdateTurnaroundTask(currentFlight.id, task.id, nextStatus);
                    }}
                    className={`w-6 h-6 rounded-full border flex items-center justify-center transition-colors ${
                      task.status === "Completed"
                        ? "bg-emerald-600 text-white border-emerald-500"
                        : task.status === "In-Progress"
                        ? "bg-amber-500/20 text-amber-400 border-amber-500 animate-pulse"
                        : "bg-slate-800 text-slate-500 border-slate-700"
                    }`}
                  >
                    {task.status === "Completed" ? (
                      <CheckCircle className="w-4 h-4" />
                    ) : (
                      <span className="text-[10px] font-bold">{task.id}</span>
                    )}
                  </button>

                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-bold text-slate-100">{task.taskName}</span>
                      {task.criticalPath && (
                        <span className="px-2 py-0.5 rounded text-[9px] font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">
                          Critical Path
                        </span>
                      )}
                    </div>
                    <div className="flex items-center space-x-3 text-xs text-slate-400 mt-0.5">
                      <span>Duration: <strong>{task.durationMinutes} mins</strong></span>
                      {task.dependencies.length > 0 && (
                        <span>Prereqs: <strong className="text-slate-300">{task.dependencies.join(", ")}</strong></span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Progress Bar & Status Switcher */}
                <div className="flex items-center space-x-4">
                  <div className="w-32 sm:w-48 space-y-1">
                    <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                      <span>{task.status}</span>
                      <span>{task.status === "Completed" ? 100 : task.progressPercent}%</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          task.status === "Completed"
                            ? "bg-emerald-500"
                            : task.status === "In-Progress"
                            ? "bg-amber-400"
                            : "bg-slate-700"
                        }`}
                        style={{ width: `${task.status === "Completed" ? 100 : task.progressPercent}%` }}
                      />
                    </div>
                  </div>

                  <select
                    value={task.status}
                    onChange={(e) =>
                      onUpdateTurnaroundTask(currentFlight.id, task.id, e.target.value as TurnaroundTask["status"])
                    }
                    className="bg-slate-900 border border-slate-700 rounded-md px-2.5 py-1 text-xs text-slate-200 focus:outline-none"
                  >
                    <option value="Pending">Pending</option>
                    <option value="In-Progress">In-Progress</option>
                    <option value="Completed">Completed</option>
                    <option value="Delayed">Delayed</option>
                  </select>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
