import React, { useState } from "react";
import {
  Sparkles,
  TrendingUp,
  DollarSign,
  Building2,
  PieChart,
  CheckCircle2,
  ArrowRight,
  Zap,
} from "lucide-react";
import { CapacityInvestmentProject } from "../types/airport";

interface InvestmentPlannerProps {
  projects: CapacityInvestmentProject[];
}

export const InvestmentPlanner: React.FC<InvestmentPlannerProps> = ({ projects }) => {
  const [demandGrowth, setDemandGrowth] = useState<number>(25);

  const sortedProjects = [...projects].sort((a, b) => b.valuePerPoundInvested - a.valuePerPoundInvested);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">Airport Capacity Investment Optimiser</h3>
            <p className="text-xs text-slate-400">CAPEX Evaluation • NPV & IRR Ranking • Marginal Capacity Value per £ Invested</p>
          </div>
        </div>
      </div>

      {/* Demand Growth Scenario Simulator */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="text-sm font-bold text-slate-100">Simulate Long-Term Airport Demand Growth</h4>
            <p className="text-xs text-slate-400">Evaluate runway, terminal and baggage bottlenecks under future traffic growth</p>
          </div>

          {/* Growth Selector */}
          <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setDemandGrowth(10)}
              className={`px-3 py-1.5 rounded text-xs font-bold font-mono transition-colors ${
                demandGrowth === 10 ? "bg-blue-600 text-white" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              +10% Traffic
            </button>
            <button
              onClick={() => setDemandGrowth(25)}
              className={`px-3 py-1.5 rounded text-xs font-bold font-mono transition-colors ${
                demandGrowth === 25 ? "bg-blue-600 text-white" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              +25% Traffic
            </button>
            <button
              onClick={() => setDemandGrowth(50)}
              className={`px-3 py-1.5 rounded text-xs font-bold font-mono transition-colors ${
                demandGrowth === 50 ? "bg-blue-600 text-white" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              +50% Traffic
            </button>
          </div>
        </div>

        {/* Forecast Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 font-mono uppercase">Forecast Daily Movements</span>
            <div className="text-xl font-bold text-slate-100">
              {Math.round(1240 * (1 + demandGrowth / 100))} <span className="text-xs font-normal text-emerald-400">(+{demandGrowth}%)</span>
            </div>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 font-mono uppercase">Unmitigated Avg Delay</span>
            <div className="text-xl font-bold text-amber-400">
              {Math.round(8.2 * (1 + (demandGrowth / 100) * 1.8))} mins
            </div>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 font-mono uppercase">Incremental Revenue Potential</span>
            <div className="text-xl font-bold text-emerald-400">
              +£{Math.round(42 * (demandGrowth / 10))}M / Year
            </div>
          </div>
        </div>
      </div>

      {/* Capital Investment Ranking Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm space-y-4 p-5">
        <h4 className="text-sm font-bold text-slate-100">Capital Projects Ranked by Value Created per £ Invested</h4>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="bg-slate-800/90 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Rank / Project Title</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">CAPEX</th>
                <th className="py-3 px-4">Capacity Gain</th>
                <th className="py-3 px-4">Annual Revenue</th>
                <th className="py-3 px-4">NPV (20 yr)</th>
                <th className="py-3 px-4">IRR %</th>
                <th className="py-3 px-4">Payback</th>
                <th className="py-3 px-4 text-right">Value Ratio</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {sortedProjects.map((proj, idx) => (
                <tr key={proj.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-semibold text-slate-100 flex items-center space-x-2">
                    <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-300 font-bold flex items-center justify-center text-[10px]">
                      #{idx + 1}
                    </span>
                    <span>{proj.title}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {proj.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-200">£{(proj.capexPounds / 1e6).toFixed(1)}M</td>
                  <td className="py-3 px-4 font-mono text-emerald-400">
                    +{proj.capacityGainMovementsPerHour > 0 ? `${proj.capacityGainMovementsPerHour} mov/hr` : `${proj.capacityGainPaxPerHour} pax/hr`}
                  </td>
                  <td className="py-3 px-4 font-mono text-emerald-400">£{(proj.annualAdditionalRevenuePounds / 1e6).toFixed(1)}M/yr</td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-100">£{(proj.npvPounds / 1e6).toFixed(1)}M</td>
                  <td className="py-3 px-4 font-mono font-bold text-emerald-400">{proj.irrPercent}%</td>
                  <td className="py-3 px-4 font-mono text-slate-300">{proj.paybackYears} yrs</td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-amber-400">
                    {proj.valuePerPoundInvested.toFixed(2)}x
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
