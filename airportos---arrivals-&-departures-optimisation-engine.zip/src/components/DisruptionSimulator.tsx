import React, { useState } from "react";
import {
  ShieldAlert,
  Zap,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  DollarSign,
  Users,
} from "lucide-react";
import { DisruptionEvent, DisruptionRecoveryPlan, Flight, GateStand } from "../types/airport";
import { RustEngineSimulator } from "../engine/rustEngineSimulation";

interface DisruptionSimulatorProps {
  disruptions: DisruptionEvent[];
  flights: Flight[];
  gates: GateStand[];
  onAddDisruption: (disruption: DisruptionEvent) => void;
  onResolveDisruption: (id: string) => void;
}

export const DisruptionSimulator: React.FC<DisruptionSimulatorProps> = ({
  disruptions,
  flights,
  gates,
  onAddDisruption,
  onResolveDisruption,
}) => {
  const [activePlan, setActivePlan] = useState<DisruptionRecoveryPlan | null>(null);

  const presets = [
    {
      type: "Runway_Closure",
      title: "Runway 09R Hydraulic Fluid Spill (45m Closure)",
      description: "Hydraulic oil leak requires emergency runway scrubbing on 09R/27L. Shift departures to RWY 09L.",
      impactedResourceIds: ["RW09R_27L"],
      severity: "Critical",
    },
    {
      type: "Ground_Crew_Shortage",
      title: "Terminal 3 Catering Ramp Truck Failure",
      description: "Hydraulic pump breakdown on catering loader serving widebody gates 301-303.",
      impactedResourceIds: ["G301", "G302"],
      severity: "Moderate",
    },
    {
      type: "Severe_Weather",
      title: "CAT III Fog & Low Visibility Flow Restriction",
      description: "Visibility drops below 200m. Mandatory 3.0NM separation increases landing interval by +40s.",
      impactedResourceIds: ["RW09L_27R", "RW09R_27L"],
      severity: "Major",
    },
    {
      type: "Baggage_System_Fault",
      title: "T2 Transfer Baggage Sorter Jam",
      description: "Main conveyor line 4 jammed. Manual baggage tug transport required for international connections.",
      impactedResourceIds: ["T2"],
      severity: "Moderate",
    },
  ];

  const handleRunRecoverySolver = (disruption: DisruptionEvent) => {
    const plan = RustEngineSimulator.solveDisruptionRecovery(disruption, flights, gates);
    setActivePlan(plan);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-rose-600/20 text-rose-400 flex items-center justify-center">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">Disruption Engine & Recovery Optimiser</h3>
            <p className="text-xs text-slate-400">Simulate Operational Shocks • Calculate Self-Correcting Recovery Plans</p>
          </div>
        </div>
      </div>

      {/* Trigger Disruption Preset Cards */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h4 className="text-sm font-bold text-slate-100">Inject Operational Disruption Scenario</h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {presets.map((preset, idx) => (
            <div
              key={idx}
              className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2.5 hover:border-slate-700 transition-colors"
            >
              <div className="flex justify-between items-start">
                <h5 className="text-sm font-bold text-slate-100">{preset.title}</h5>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    preset.severity === "Critical"
                      ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                      : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                  }`}
                >
                  {preset.severity}
                </span>
              </div>
              <p className="text-xs text-slate-400">{preset.description}</p>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => {
                    const newDis: DisruptionEvent = {
                      id: `DIS-${Date.now()}`,
                      type: preset.type as any,
                      title: preset.title,
                      description: preset.description,
                      impactedResourceIds: preset.impactedResourceIds,
                      startTime: "18:00",
                      estimatedEndTime: "18:45",
                      severity: preset.severity as any,
                      status: "Active",
                    };
                    onAddDisruption(newDis);
                    handleRunRecoverySolver(newDis);
                  }}
                  className="bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-300" />
                  <span>Simulate Scenario</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Disruptions & Generated Recovery Plan */}
      {disruptions.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h4 className="text-sm font-bold text-rose-300 flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-rose-400 animate-pulse" />
              <span>Active Disruption: {disruptions[0].title}</span>
            </h4>
            <button
              onClick={() => onResolveDisruption(disruptions[0].id)}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold"
            >
              Mark Disruption Resolved
            </button>
          </div>

          {activePlan && (
            <div className="space-y-4 pt-2">
              <div className="bg-emerald-950/30 border border-emerald-800/80 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h5 className="text-sm font-bold text-emerald-200">
                    Rolling-Horizon Recovery Solution Calculated
                  </h5>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Total Saved Delay: <strong className="text-emerald-400">{activePlan.totalSavedDelayMinutes} mins</strong> • Missed Connections Prevented: <strong className="text-emerald-400">{activePlan.totalPreventedMissedConnections} Pax</strong>
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400 block">Net Economic Benefit</span>
                  <span className="text-lg font-bold text-emerald-400">+£{activePlan.netEconomicBenefitPounds.toLocaleString()}</span>
                </div>
              </div>

              {/* Recovery Action Steps */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                  <span className="font-bold text-slate-200">Reassigned Stand / Gate Assignments</span>
                  <p className="text-slate-400">
                    Flight FL-AA100 reassigned from Gate 301 → <strong className="text-blue-400">Gate 303</strong>.
                  </p>
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                  <span className="font-bold text-slate-200">Arrival Runway Sequencing Shift</span>
                  <p className="text-slate-400">
                    Flow shifted to RWY 09L with 110s wake separation interval.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
