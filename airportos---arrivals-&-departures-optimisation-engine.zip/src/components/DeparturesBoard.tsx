import React, { useState } from "react";
import {
  PlaneTakeoff,
  Search,
  Clock,
  ArrowRight,
  Users,
  AlertTriangle,
  RotateCcw,
  Zap,
} from "lucide-react";
import { Flight } from "../types/airport";

interface DeparturesBoardProps {
  flights: Flight[];
  onSelectFlight: (flightId: string) => void;
}

export const DeparturesBoard: React.FC<DeparturesBoardProps> = ({ flights, onSelectFlight }) => {
  const [searchQuery, setSearchQuery] = useState("");

  const departures = flights.filter(
    (f) =>
      (f.flightType === "Departure" || f.flightType === "Turnaround") &&
      (f.flightNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.airline.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center">
            <PlaneTakeoff className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">Live Outbound Departures Board</h3>
            <p className="text-xs text-slate-400">Pushback Sequencing • Taxi Queue • Connection-Aware Hold Optimisation</p>
          </div>
        </div>

        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search flight, destination, airline..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 w-64"
          />
        </div>
      </div>

      {/* Connection Hold Recommendation Banner */}
      <div className="bg-blue-950/40 border border-blue-800/80 rounded-xl p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-blue-500/20 text-blue-300 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
          <div className="text-xs">
            <h4 className="font-bold text-slate-100">Connection-Aware Departure Hold Recommendation</h4>
            <p className="text-slate-300">
              Flight <strong className="text-amber-300">FL-AA100</strong> (LHR → MIA): Delaying pushback by <strong className="text-amber-300">7 minutes</strong> enables <strong className="text-emerald-400">32 connecting passengers</strong> from inbound FL-EK008 to board.
            </p>
          </div>
        </div>
        <button className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap">
          Authorize 7m Hold (+£14,500 Net Benefit)
        </button>
      </div>

      {/* Departures Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="bg-slate-800/90 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Flight / Airline</th>
                <th className="py-3 px-4">Aircraft / Class</th>
                <th className="py-3 px-4">Destination</th>
                <th className="py-3 px-4">STD</th>
                <th className="py-3 px-4">Target Off-Block</th>
                <th className="py-3 px-4">Gate</th>
                <th className="py-3 px-4">Runway</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {departures.map((f) => (
                <tr key={f.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-semibold text-slate-100">
                    {f.flightNumber}
                    <span className="block text-[10px] text-slate-400 font-normal">{f.airline}</span>
                  </td>
                  <td className="py-3 px-4">
                    {f.aircraftType}
                    <span className="block text-[10px] text-indigo-400 font-semibold">{f.wakeCategory}</span>
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-200">{f.destination}</td>
                  <td className="py-3 px-4 font-mono text-slate-400">{f.departureTime}</td>
                  <td className="py-3 px-4 font-mono font-bold text-blue-400">
                    {f.targetOffBlockTime || f.departureTime}
                    {f.delayMinutes > 0 && (
                      <span className="block text-[10px] text-amber-400 font-normal">+{f.delayMinutes}m delay</span>
                    )}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300">{f.gateId}</td>
                  <td className="py-3 px-4 font-mono text-slate-300">{f.runwayId}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2.5 py-1 rounded-full text-[11px] font-semibold border ${
                        f.status === "Ready" || f.status === "Boarding"
                          ? "bg-amber-500/10 text-amber-400 border-amber-500/20"
                          : f.status === "Pushback" || f.status === "Taxiing"
                          ? "bg-blue-500/10 text-blue-400 border-blue-500/20"
                          : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                      }`}
                    >
                      {f.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => onSelectFlight(f.id)}
                      className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium px-3 py-1.5 rounded-lg transition-colors inline-flex items-center space-x-1"
                    >
                      <span>Turnaround DAG</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
