import React, { useState } from "react";
import { CloudSun, Activity, Flame, ShieldAlert, BarChart3, TrendingUp } from "lucide-react";
import { HeatmapHorizon } from "../types/airport";

interface CapacityHeatmapsProps {
  heatmapData: HeatmapHorizon[];
}

export const CapacityHeatmaps: React.FC<CapacityHeatmapsProps> = ({ heatmapData }) => {
  const [activeHorizon, setActiveHorizon] = useState<string>("NOW");

  const currentHorizonData = heatmapData.find((h) => h.timeOffsetLabel === activeHorizon) || heatmapData[0];

  const getHeatColor = (val: number) => {
    if (val >= 90) return "bg-rose-500 text-white font-bold border-rose-400";
    if (val >= 75) return "bg-amber-500 text-white font-bold border-amber-400";
    if (val >= 60) return "bg-blue-600 text-white font-semibold border-blue-400";
    return "bg-emerald-600/20 text-emerald-300 font-semibold border-emerald-500/30";
  };

  return (
    <div className="space-y-6">
      {/* Header & Horizon Time Selectors */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
            <Flame className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">Airport Predictive Capacity Heatmaps</h3>
            <p className="text-xs text-slate-400">Runway, Taxiway, Gate, Baggage, Security & Border Utilization Forecasting</p>
          </div>
        </div>

        {/* Time Horizon Selector Buttons */}
        <div className="flex items-center space-x-1.5 bg-slate-950 p-1.5 rounded-lg border border-slate-800">
          {heatmapData.map((h) => (
            <button
              key={h.timeOffsetLabel}
              onClick={() => setActiveHorizon(h.timeOffsetLabel)}
              className={`px-3 py-1.5 rounded-md text-xs font-mono font-bold transition-all ${
                activeHorizon === h.timeOffsetLabel
                  ? "bg-blue-600 text-white shadow-md shadow-blue-600/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
              }`}
            >
              {h.timeOffsetLabel}
            </button>
          ))}
        </div>
      </div>

      {/* Heatmap Grid Overview */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h4 className="text-sm font-bold text-slate-100">Horizon Comparison Matrix</h4>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="bg-slate-800/90 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Airport System / Facility</th>
                {heatmapData.map((h) => (
                  <th key={h.timeOffsetLabel} className="py-3 px-3 text-center font-mono">
                    {h.timeOffsetLabel}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-100 font-sans">Runway Movements</td>
                {heatmapData.map((h) => (
                  <td key={h.timeOffsetLabel} className="py-3 px-3 text-center">
                    <span className={`px-2.5 py-1 rounded border text-[11px] ${getHeatColor(h.runwayUtilisationPercent)}`}>
                      {h.runwayUtilisationPercent}%
                    </span>
                  </td>
                ))}
              </tr>

              <tr>
                <td className="py-3 px-4 font-semibold text-slate-100 font-sans">Taxiway Surface Congestion</td>
                {heatmapData.map((h) => (
                  <td key={h.timeOffsetLabel} className="py-3 px-3 text-center">
                    <span className={`px-2.5 py-1 rounded border text-[11px] ${getHeatColor(h.taxiwayCongestionPercent)}`}>
                      {h.taxiwayCongestionPercent}%
                    </span>
                  </td>
                ))}
              </tr>

              <tr>
                <td className="py-3 px-4 font-semibold text-slate-100 font-sans">Gate & Terminal Occupancy</td>
                {heatmapData.map((h) => (
                  <td key={h.timeOffsetLabel} className="py-3 px-3 text-center">
                    <span className={`px-2.5 py-1 rounded border text-[11px] ${getHeatColor(h.gateUtilisationPercent)}`}>
                      {h.gateUtilisationPercent}%
                    </span>
                  </td>
                ))}
              </tr>

              <tr>
                <td className="py-3 px-4 font-semibold text-slate-100 font-sans">Stand Capacity</td>
                {heatmapData.map((h) => (
                  <td key={h.timeOffsetLabel} className="py-3 px-3 text-center">
                    <span className={`px-2.5 py-1 rounded border text-[11px] ${getHeatColor(h.standUtilisationPercent)}`}>
                      {h.standUtilisationPercent}%
                    </span>
                  </td>
                ))}
              </tr>

              <tr>
                <td className="py-3 px-4 font-semibold text-slate-100 font-sans">Passenger Security Queues</td>
                {heatmapData.map((h) => (
                  <td key={h.timeOffsetLabel} className="py-3 px-3 text-center">
                    <span className={`px-2.5 py-1 rounded border text-[11px] ${getHeatColor(h.securityQueueUtilisationPercent)}`}>
                      {h.securityQueueUtilisationPercent}%
                    </span>
                  </td>
                ))}
              </tr>

              <tr>
                <td className="py-3 px-4 font-semibold text-slate-100 font-sans">Baggage Conveyor Systems</td>
                {heatmapData.map((h) => (
                  <td key={h.timeOffsetLabel} className="py-3 px-3 text-center">
                    <span className={`px-2.5 py-1 rounded border text-[11px] ${getHeatColor(h.baggageConveyorUtilisationPercent)}`}>
                      {h.baggageConveyorUtilisationPercent}%
                    </span>
                  </td>
                ))}
              </tr>

              <tr>
                <td className="py-3 px-4 font-semibold text-slate-100 font-sans">Immigration & Passport Control</td>
                {heatmapData.map((h) => (
                  <td key={h.timeOffsetLabel} className="py-3 px-3 text-center">
                    <span className={`px-2.5 py-1 rounded border text-[11px] ${getHeatColor(h.immigrationUtilisationPercent)}`}>
                      {h.immigrationUtilisationPercent}%
                    </span>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
