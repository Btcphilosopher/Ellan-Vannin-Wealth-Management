import React, { useState } from "react";
import { Bot, Sparkles, X, Send, RotateCcw, Zap, AlertTriangle, CheckCircle2 } from "lucide-react";
import { ControlTowerMetrics, Flight, DisruptionEvent } from "../types/airport";

interface GeminiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  metrics: ControlTowerMetrics;
  flights: Flight[];
  disruptions: DisruptionEvent[];
}

export const GeminiAssistantModal: React.FC<GeminiAssistantModalProps> = ({
  isOpen,
  onClose,
  metrics,
  flights,
  disruptions,
}) => {
  const [prompt, setPrompt] = useState("");
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const quickPrompts = [
    "Analyze current runway throughput and wake turbulence bottlenecks",
    "Recommend recovery strategy for FL-EK008 A380 turnaround delay",
    "Evaluate economic tradeoff of holding FL-AA100 for 32 connecting passengers",
    "Rank airport capital expansion projects for +25% traffic growth scenario",
  ];

  const handleSubmitPrompt = async (selectedPrompt?: string) => {
    const query = selectedPrompt || prompt;
    if (!query.trim()) return;

    setLoading(true);
    setError(null);
    setResponse(null);

    try {
      const res = await fetch("/api/ai/analyze-operations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: query,
          airportContext: {
            metrics,
            disruptions,
            activeFlightCount: flights.length,
            sampleFlight: flights[0],
          },
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to generate AI operational analysis.");
      }

      setResponse(data.analysis);
    } catch (err: any) {
      setError(err.message || "An error occurred while contacting the Gemini AI Advisor.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-900/60 to-indigo-900/60 border-b border-slate-800 p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center space-x-2">
                <span>AirportOS Control Tower AI Advisor</span>
                <span className="text-[10px] bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2 py-0.5 rounded-full font-mono">
                  Gemini 2.5 Flash
                </span>
              </h3>
              <p className="text-xs text-slate-300">Decision-support operational AI intelligence</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
          {/* Quick Prompts */}
          <div className="space-y-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Suggested AI Operational Analyses:
            </span>
            <div className="flex flex-wrap gap-2">
              {quickPrompts.map((qp, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPrompt(qp);
                    handleSubmitPrompt(qp);
                  }}
                  className="bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 rounded-lg px-3 py-1.5 text-xs text-left transition-colors"
                >
                  {qp}
                </button>
              ))}
            </div>
          </div>

          {/* AI Response Box */}
          {loading && (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 text-center space-y-3">
              <Bot className="w-8 h-8 text-blue-400 animate-bounce mx-auto" />
              <p className="text-slate-300 font-medium animate-pulse">
                Analyzing Airport Digital Twin telemetry, wake constraints, and economics...
              </p>
            </div>
          )}

          {error && (
            <div className="bg-rose-950/40 border border-rose-800 rounded-xl p-4 text-rose-300 text-xs">
              <strong>Error:</strong> {error}
            </div>
          )}

          {response && (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2 text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
              <div className="flex items-center space-x-2 text-blue-400 font-bold border-b border-slate-800 pb-2 mb-2">
                <Sparkles className="w-4 h-4" />
                <span>AI Operational Recommendation</span>
              </div>
              {response}
            </div>
          )}
        </div>

        {/* Footer Input */}
        <div className="border-t border-slate-800 p-4 bg-slate-950/60 flex items-center space-x-3">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSubmitPrompt()}
            placeholder="Ask AI Tower Advisor any operational question..."
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
          <button
            onClick={() => handleSubmitPrompt()}
            disabled={loading || !prompt.trim()}
            className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white px-4 py-2.5 rounded-xl font-semibold text-xs transition-colors flex items-center space-x-1.5"
          >
            <Send className="w-4 h-4" />
            <span>Analyze</span>
          </button>
        </div>
      </div>
    </div>
  );
};
