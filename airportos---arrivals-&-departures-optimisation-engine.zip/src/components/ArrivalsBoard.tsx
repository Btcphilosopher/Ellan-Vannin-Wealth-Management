import React, { useState } from "react";
import {
  PlaneLanding,
  Search,
  Filter,
  Users,
  AlertTriangle,
  Clock,
  ArrowRight,
  ShieldCheck,
  TrendingUp,
} from "lucide-react";
import { Flight } from "../types/airport";
import { RAnalyticsEngine } from "../engine/rAnalyticsEngine";

interface ArrivalsBoardProps {
  flights: Flight[];
  onSelectFlight: (flightId: string) => void;
}

export const ArrivalsBoard: React.FC<ArrivalsBoardProps> = ({ flights, onSelectFlight }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAirline, setSelectedAirline] = useState("All");

  const arrivals = flights.filter(
    (f) =>
      (f.flightType === "Arrival" || f.flightType === "Turnaround") &&
      (f.flightNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.origin.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.airline.toLowerCase().includes(searchQuery.toLowerCase())) &&
      (selectedAirline === "All" || f.airline === selectedAirline)
  );

  const airlines = Array.from(new Set(flights.map((f) => f.airline)));

  return (
    <div className="space-y-4">
      {/* Search & Filter Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
            <PlaneLanding className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">Live Inbound Arrivals Board</h3>
            <p className="text-xs text-slate-400">Optimised Arrival Sequences • Wake Separation • Connection Risk</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search flight, origin, airline..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 w-52 sm:w-64"
            />
          </div>

          {/* Airline Filter */}
          <select
            value={selectedAirline}
            onChange={(e) => setSelectedAirline(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
          >
            <option value="All">All Airlines</option>
            {airlines.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Arrivals Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="bg-slate-800/90 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Flight / Airline</th>
                <th className="py-3 px-4">Aircraft / Wake</th>
                <th className="py-3 px-4">Origin</th>
                <th className="py-3 px-4">STA</th>
                <th className="py-3 px-4">ETA (Optimised)</th>
                <th className="py-3 px-4">Runway</th>
                <th className="py-3 px-4">Gate</th>
                <th className="py-3 px-4">Connection Risk</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {arrivals.map((f) => {
                const mc = RAnalyticsEngine.runMonteCarloDelaySimulation(f, 200);
                return (
                  <tr key={f.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-100">
                      {f.flightNumber}
                      <span className="block text-[10px] text-slate-400 font-normal">{f.airline}</span>
                    </td>
                    <td className="py-3 px-4">
                      {f.aircraftType}
                      <span className="block text-[10px] text-indigo-400 font-semibold">{f.wakeCategory} Wake</span>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-200">{f.origin}</td>
                    <td className="py-3 px-4 font-mono text-slate-400">{f.arrivalTime}</td>
                    <td className="py-3 px-4 font-mono font-bold text-emerald-400">
                      {f.targetLandingTime || f.arrivalTime}
                      {f.delayMinutes > 0 && (
                        <span className="block text-[10px] text-amber-400 font-normal">+{f.delayMinutes}m delay</span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-300">{f.runwayId}</td>
                    <td className="py-3 px-4 font-mono text-slate-300">{f.gateId}</td>
                    <td className="py-3 px-4">
                      {f.connectionRiskCount > 30 ? (
                        <span className="px-2 py-1 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                          {f.connectionRiskCount} At Risk
                        </span>
                      ) : (
                        <span className="px-2 py-1 rounded text-[10px] font-medium bg-emerald-500/10 text-emerald-400">
                          Low Risk
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        {f.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onSelectFlight(f.id)}
                        className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium px-3 py-1.5 rounded-lg transition-colors inline-flex items-center space-x-1"
                      >
                        <span>Inspect DAG</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
