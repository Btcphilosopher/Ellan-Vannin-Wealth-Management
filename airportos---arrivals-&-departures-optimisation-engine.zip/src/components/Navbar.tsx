import React from "react";
import {
  Activity,
  Bot,
  Play,
  Pause,
  RotateCcw,
  CloudSun,
  ShieldAlert,
  Plane,
  Layers,
  Sparkles,
} from "lucide-react";

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  simSpeed: number;
  setSimSpeed: (speed: number) => void;
  isSimRunning: boolean;
  setIsSimRunning: (running: boolean) => void;
  onResetData: () => void;
  onOpenGeminiAi: () => void;
  activeDisruptionsCount: number;
  weatherCondition: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  simSpeed,
  setSimSpeed,
  isSimRunning,
  setIsSimRunning,
  onResetData,
  onOpenGeminiAi,
  activeDisruptionsCount,
  weatherCondition,
}) => {
  const tabs = [
    { id: "tower", label: "Control Tower", icon: Activity },
    { id: "twin", label: "Digital Twin 2D", icon: Layers },
    { id: "arrivals", label: "Arrivals Board", icon: Plane },
    { id: "departures", label: "Departures Board", icon: Plane },
    { id: "turnaround", label: "Turnaround DAG", icon: RotateCcw },
    { id: "heatmaps", label: "Capacity Heatmaps", icon: CloudSun },
    { id: "disruption", label: "Disruption Recovery", icon: ShieldAlert },
    { id: "investment", label: "Investment CAPEX", icon: Sparkles },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-50 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand Title */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab("tower")}>
            <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center font-bold text-white shadow-md shadow-indigo-500/20">
              A
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight uppercase text-slate-100">
                AirportOS <span className="text-indigo-400">Digital Twin</span>
              </h1>
            </div>
          </div>

          {/* System Status & Operational Time */}
          <div className="hidden lg:flex items-center space-x-6 text-sm">
            <div className="flex flex-col items-end">
              <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">System Status</span>
              <div className="flex items-center">
                <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2 animate-pulse"></span>
                <span className="font-mono text-xs text-slate-200">RUST-ENGINE: OPTIMIZING (0.003s)</span>
              </div>
            </div>

            <div className="flex flex-col items-end">
              <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Operational Time</span>
              <span className="font-mono text-xs font-bold text-slate-100">18:00:00 UTC</span>
            </div>
          </div>

          {/* Simulation Time & Speed Controls */}
          <div className="flex items-center space-x-2 bg-slate-950 px-2.5 py-1.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setIsSimRunning(!isSimRunning)}
              className={`p-1.5 rounded-md transition-colors ${
                isSimRunning ? "bg-amber-500/20 text-amber-400 hover:bg-amber-500/30" : "bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
              }`}
              title={isSimRunning ? "Pause Simulation" : "Start Simulation"}
            >
              {isSimRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>

            <div className="flex items-center space-x-1 text-xs font-mono text-slate-300">
              <button
                onClick={() => setSimSpeed(1)}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${simSpeed === 1 ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-slate-200"}`}
              >
                1x
              </button>
              <button
                onClick={() => setSimSpeed(10)}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${simSpeed === 10 ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-slate-200"}`}
              >
                10x
              </button>
              <button
                onClick={() => setSimSpeed(60)}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${simSpeed === 60 ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-slate-200"}`}
              >
                60x
              </button>
            </div>

            <button
              onClick={onResetData}
              className="p-1.5 text-slate-400 hover:text-slate-200 rounded-md hover:bg-slate-800 transition-colors"
              title="Reset Airport State to Initial Twin Baseline"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Badges & Gemini AI Action */}
          <div className="flex items-center space-x-2">
            {/* Active Disruption Alert */}
            {activeDisruptionsCount > 0 && (
              <div className="flex items-center space-x-1.5 text-xs bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2.5 py-1 rounded-md animate-pulse">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                <span className="font-bold text-[11px]">{activeDisruptionsCount} Disruption</span>
              </div>
            )}

            {/* Gemini AI Operations Assistant Button */}
            <button
              onClick={onOpenGeminiAi}
              className="flex items-center space-x-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold uppercase tracking-wider px-3 py-2 rounded-lg shadow-md shadow-indigo-500/20 transition-all"
            >
              <Bot className="w-4 h-4 text-white" />
              <span className="hidden sm:inline">AI Advisor</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="flex space-x-1 overflow-x-auto pb-2.5 scrollbar-none border-t border-slate-800/80 pt-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-bold tracking-tight uppercase whitespace-nowrap transition-all ${
                  isActive
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/20"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? "text-white" : "text-slate-400"}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};

