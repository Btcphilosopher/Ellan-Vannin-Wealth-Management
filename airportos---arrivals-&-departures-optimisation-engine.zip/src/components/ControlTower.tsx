import React from "react";
import {
  Activity,
  Gauge,
  Clock,
  PlaneLanding,
  PlaneTakeoff,
  Users,
  Zap,
  TrendingUp,
  ShieldAlert,
  ArrowRight,
  RotateCcw,
  Building2,
  CloudSun,
  DollarSign,
  Sparkles,
} from "lucide-react";
import { Flight, Runway, GateStand, ControlTowerMetrics, DisruptionEvent } from "../types/airport";

interface ControlTowerProps {
  metrics: ControlTowerMetrics;
  runways: Runway[];
  gates: GateStand[];
  flights: Flight[];
  disruptions: DisruptionEvent[];
  eventLog: string[];
  onTriggerOptimisation: () => void;
  onSelectFlight: (flightId: string) => void;
  onNavigateTab: (tab: string) => void;
}

export const ControlTower: React.FC<ControlTowerProps> = ({
  metrics,
  runways,
  gates,
  flights,
  disruptions,
  eventLog,
  onTriggerOptimisation,
  onSelectFlight,
  onNavigateTab,
}) => {
  const arrivingFlights = flights.filter((f) => f.flightType === "Arrival");
  const departingFlights = flights.filter((f) => f.flightType === "Departure");

  return (
    <div className="space-y-4">
      {/* Active Operational Disruption Alert Banner */}
      {disruptions.length > 0 && (
        <div className="bg-rose-950/40 border border-rose-800/80 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-lg bg-rose-500/20 flex items-center justify-center text-rose-400">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-rose-200">
                ACTIVE OPERATIONAL DISRUPTION DETECTED
              </h3>
              <p className="text-xs text-rose-300/80 mt-0.5">
                {disruptions[0].title}: {disruptions[0].description}
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab("disruption")}
            className="flex items-center space-x-1 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-lg transition-colors"
          >
            <span>Resolve Disruption</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Bento Grid Layout */}
      <div className="grid grid-cols-12 gap-3">
        {/* Bento 1: Live Arrivals List (col-span-12 md:col-span-3) */}
        <section className="col-span-12 md:col-span-3 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col shadow-sm">
          <div className="px-4 py-3 border-b border-slate-800 bg-slate-800/50 flex justify-between items-center">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
              <PlaneLanding className="w-3.5 h-3.5 text-indigo-400" />
              <span>Live Inbound Arrivals</span>
            </h2>
            <span className="bg-emerald-500/10 text-emerald-400 text-[10px] px-2 py-0.5 rounded border border-emerald-500/20 font-mono">
              +{metrics.arrivalsNext60m} 60m
            </span>
          </div>

          <div className="flex-1 p-2 space-y-2 overflow-y-auto max-h-[380px]">
            {arrivingFlights.slice(0, 4).map((f) => (
              <div
                key={f.id}
                onClick={() => onSelectFlight(f.id)}
                className={`p-3 bg-slate-950 rounded border-l-2 cursor-pointer hover:bg-slate-800/60 transition-colors flex justify-between items-center ${
                  f.delayMinutes > 5
                    ? "border-l-amber-500"
                    : f.connectionRiskCount > 20
                    ? "border-l-indigo-500"
                    : "border-l-emerald-500"
                }`}
              >
                <div>
                  <div className="text-xs font-bold text-slate-100 flex items-center space-x-1">
                    <span>{f.flightNumber}</span>
                    <span className="text-[10px] font-normal text-slate-500">({f.aircraftType})</span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {f.origin} → LHR • Gate {f.gateId}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-mono font-bold text-indigo-400">{f.arrivalTime}</div>
                  <div className={`text-[10px] font-bold ${f.delayMinutes > 0 ? "text-amber-400" : "text-emerald-400"}`}>
                    {f.delayMinutes > 0 ? `+${f.delayMinutes}m DELAY` : "ON TIME"}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-2 border-t border-slate-800/80 text-center bg-slate-950/40">
            <button
              onClick={() => onNavigateTab("arrivals")}
              className="text-[11px] font-bold uppercase tracking-wider text-indigo-400 hover:text-indigo-300"
            >
              View Full Arrivals Board →
            </button>
          </div>
        </section>

        {/* Bento 2: Surface Movement Digital Twin Canvas (col-span-12 md:col-span-6) */}
        <section className="col-span-12 md:col-span-6 bg-slate-900 border border-slate-800 rounded-xl relative overflow-hidden flex flex-col shadow-sm">
          {/* Radial Dot Grid Background Overlay */}
          <div
            className="absolute inset-0 opacity-25 pointer-events-none"
            style={{
              backgroundImage: "radial-gradient(#334155 1px, transparent 1px)",
              backgroundSize: "20px 20px",
            }}
          />

          <div className="relative z-10 p-4 flex-1 flex flex-col justify-between space-y-4">
            <div className="flex flex-wrap justify-between items-start gap-2">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100 flex items-center space-x-2">
                  <Activity className="w-4 h-4 text-indigo-400" />
                  <span>Surface Movement Digital Twin</span>
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">Real-time taxiway flow and active runway occupancy.</p>
              </div>

              <div className="bg-slate-950/80 border border-slate-800 p-2 rounded-lg flex space-x-4">
                <div className="text-center">
                  <div className="text-[9px] uppercase font-bold text-slate-400">Throughput</div>
                  <div className="text-xs font-mono font-bold text-indigo-400">78 mv/h</div>
                </div>
                <div className="text-center border-l border-slate-800 pl-4">
                  <div className="text-[9px] uppercase font-bold text-slate-400">Avg. Separation</div>
                  <div className="text-xs font-mono font-bold text-indigo-400">180s</div>
                </div>
              </div>
            </div>

            {/* Interactive Surface Graphic / Preview */}
            <div className="flex-1 min-h-[140px] bg-slate-950/80 border border-slate-800/80 rounded-xl relative p-3 flex flex-col justify-center items-center">
              {/* Simulated Runway Tracks */}
              <div className="w-full space-y-3">
                {runways.map((r) => {
                  const utilPct = Math.round(
                    (r.currentMovementsPerHour / (r.arrivalCapacityPerHour + r.departureCapacityPerHour)) * 100
                  );
                  return (
                    <div key={r.id} className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-300 font-mono">
                        <span className="font-bold text-indigo-300">{r.name}</span>
                        <span>
                          {r.currentMovementsPerHour} mov/h ({utilPct}%)
                        </span>
                      </div>
                      <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 rounded-full ${
                            utilPct > 80 ? "bg-amber-500" : "bg-indigo-500"
                          }`}
                          style={{ width: `${utilPct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-3 flex items-center space-x-2 text-[11px]">
                <button
                  onClick={onTriggerOptimisation}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold uppercase tracking-wider text-[10px] px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1"
                >
                  <Zap className="w-3 h-3 text-amber-300" />
                  <span>Run Arrival Sequencing Optimizer</span>
                </button>
                <button
                  onClick={() => onNavigateTab("twin")}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold uppercase tracking-wider text-[10px] px-3 py-1.5 rounded-lg transition-colors"
                >
                  Full 2D Surface Map →
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Bento 3: Resource Capacity (col-span-12 md:col-span-3) */}
        <section className="col-span-12 md:col-span-3 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm space-y-3">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">Resource Capacity</h2>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between items-end mb-1">
                <span className="text-xs text-slate-300">Gate Utilization</span>
                <span className="text-sm font-mono font-bold text-indigo-400">
                  {metrics.gateUtilisationPercent}%
                </span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-indigo-500 rounded-full"
                  style={{ width: `${metrics.gateUtilisationPercent}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-end mb-1">
                <span className="text-xs text-slate-300">Runway Throughput</span>
                <span className="text-sm font-mono font-bold text-emerald-400">
                  {metrics.runwayUtilisationPercent}%
                </span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{ width: `${metrics.runwayUtilisationPercent}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-end mb-1">
                <span className="text-xs text-slate-300">Ground Crew Availability</span>
                <span className="text-sm font-mono font-bold text-rose-400">24%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-rose-500 rounded-full w-[24%]" />
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 flex justify-between">
            <span>Stand Utilisation: {metrics.standUtilisationPercent}%</span>
            <span>OTP Rate: {metrics.onTimeDepartureRatePercent}%</span>
          </div>
        </section>

        {/* Bento 4: Economic Optimization Highlight Card (col-span-12 md:col-span-3) */}
        <section className="col-span-12 md:col-span-3 bg-indigo-600 rounded-xl p-4 flex flex-col justify-between shadow-lg shadow-indigo-500/20 text-white">
          <div>
            <div className="flex justify-between items-center mb-1">
              <h2 className="text-xs font-bold uppercase tracking-wider text-indigo-100">Economic Optimization</h2>
              <Sparkles className="w-4 h-4 text-indigo-200" />
            </div>
            <div className="text-2xl font-extrabold font-mono">
              +£14,500 <span className="text-xs font-normal opacity-90">saved / hold</span>
            </div>
          </div>

          <p className="text-[11px] leading-snug text-indigo-100/90 my-2">
            Connection-aware scheduling identified a 7-minute recovery hold for <span className="font-bold text-white">FL-AA100</span>, preventing 32 missed passenger connections.
          </p>

          <button
            onClick={() => onNavigateTab("turnaround")}
            className="w-full py-2 bg-white/20 hover:bg-white/30 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
          >
            View Turnaround Recovery Plan
          </button>
        </section>

        {/* Bento 5: Optimized Departures List (col-span-12 md:col-span-3) */}
        <section className="col-span-12 md:col-span-3 bg-slate-900 border border-slate-800 rounded-xl flex flex-col overflow-hidden shadow-sm">
          <div className="px-4 py-3 border-b border-slate-800 bg-slate-800/50 flex justify-between items-center">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
              <PlaneTakeoff className="w-3.5 h-3.5 text-indigo-400" />
              <span>Optimized Departures</span>
            </h2>
            <span className="bg-indigo-500/10 text-indigo-400 text-[10px] px-2 py-0.5 rounded border border-indigo-500/20 font-mono">
              +{metrics.departuresNext60m} 60m
            </span>
          </div>

          <div className="flex-1 p-2 space-y-2 overflow-y-auto max-h-[380px]">
            {departingFlights.slice(0, 4).map((f) => (
              <div
                key={f.id}
                onClick={() => onSelectFlight(f.id)}
                className={`p-3 bg-slate-950 rounded border-l-2 cursor-pointer hover:bg-slate-800/60 transition-colors flex justify-between items-center ${
                  f.status === "Delayed"
                    ? "border-l-rose-500"
                    : f.status === "Boarding"
                    ? "border-l-amber-500"
                    : "border-l-emerald-500"
                }`}
              >
                <div>
                  <div className="text-xs font-bold text-slate-100 flex items-center space-x-1">
                    <span>{f.flightNumber}</span>
                    <span className="text-[10px] font-normal text-slate-500">({f.aircraftType})</span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    LHR → {f.destination} • Gate {f.gateId}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-slate-500">STD: {f.departureTime}</div>
                  <div
                    className={`text-xs font-mono font-bold ${
                      f.status === "Delayed" ? "text-rose-400" : "text-emerald-400"
                    }`}
                  >
                    {f.status === "Delayed" ? "CONFLICT" : f.departureTime}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-2 border-t border-slate-800/80 text-center bg-slate-950/40">
            <button
              onClick={() => onNavigateTab("departures")}
              className="text-[11px] font-bold uppercase tracking-wider text-indigo-400 hover:text-indigo-300"
            >
              View Departures Board →
            </button>
          </div>
        </section>

        {/* Bento 6: R-Analytics Delay Propagation Forecast (col-span-12 md:col-span-4) */}
        <section className="col-span-12 md:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              R-Analytics: Delay Propagation Forecast
            </h2>
            <div className="flex space-x-2 text-[10px]">
              <span className="flex items-center text-slate-300">
                <span className="w-2 h-2 rounded-full bg-indigo-500 mr-1"></span> Forecast
              </span>
              <span className="flex items-center text-slate-400">
                <span className="w-2 h-2 rounded-full bg-slate-700 mr-1"></span> Historical
              </span>
            </div>
          </div>

          {/* Histogram Chart */}
          <div className="flex-1 flex items-end space-x-1.5 px-2 min-h-[110px]">
            <div className="flex-1 bg-slate-800 h-[20%] rounded-t" title="14:00 (4m delay)" />
            <div className="flex-1 bg-slate-800 h-[35%] rounded-t" title="16:00 (7m delay)" />
            <div className="flex-1 bg-slate-800 h-[25%] rounded-t" title="18:00 (5m delay)" />
            <div className="flex-1 bg-indigo-500 h-[45%] rounded-t" title="20:00 (9m forecast)" />
            <div className="flex-1 bg-indigo-500 h-[65%] rounded-t" title="22:00 (12m forecast)" />
            <div className="flex-1 bg-indigo-500 h-[80%] rounded-t" title="00:00 (16m peak)" />
            <div className="flex-1 bg-indigo-500 h-[55%] rounded-t" title="02:00 (10m forecast)" />
            <div className="flex-1 bg-indigo-500 h-[30%] rounded-t" title="04:00 (6m forecast)" />
            <div className="flex-1 bg-slate-700 h-[15%] rounded-t opacity-40" />
            <div className="flex-1 bg-slate-700 h-[10%] rounded-t opacity-40" />
          </div>

          <div className="flex justify-between text-[10px] text-slate-500 mt-2 font-mono uppercase border-t border-slate-800 pt-1.5">
            <span>14:00</span>
            <span>18:00</span>
            <span>22:00</span>
            <span>02:00</span>
            <span>06:00</span>
          </div>
        </section>

        {/* Bento 7: Weather & Operational Constraints (col-span-12 md:col-span-2) */}
        <section className="col-span-12 md:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div className="text-center">
            <div className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1">
              Weather Constraint
            </div>
            <div className="text-xl font-light mb-1 text-slate-100">
              CLEAR <span className="text-indigo-400 font-bold">12°C</span>
            </div>
            <div className="text-[10px] text-emerald-400 font-mono font-bold">CAT-I OPS | WIND 040/08</div>
          </div>

          <div className="mt-3 flex justify-between border-t border-slate-800 pt-3 text-center">
            <div className="px-1">
              <div className="text-[9px] text-slate-400 font-bold uppercase">VFR</div>
              <div className="w-2 h-2 bg-emerald-500 rounded-full mx-auto mt-1"></div>
            </div>
            <div className="px-1">
              <div className="text-[9px] text-slate-400 font-bold uppercase">LVO</div>
              <div className="w-2 h-2 bg-slate-700 rounded-full mx-auto mt-1"></div>
            </div>
            <div className="px-1">
              <div className="text-[9px] text-slate-400 font-bold uppercase">ATC SLOTS</div>
              <div className="w-2 h-2 bg-amber-500 rounded-full mx-auto mt-1"></div>
            </div>
          </div>
        </section>
      </div>

      {/* Live Event Stream Feed Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-indigo-400 animate-pulse" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Real-Time Event Stream Log
            </h3>
          </div>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 max-h-[160px] overflow-y-auto text-xs">
          {eventLog.slice(0, 6).map((log, idx) => (
            <div
              key={idx}
              className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 font-mono text-[11px] text-slate-300 flex items-start space-x-2"
            >
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1 shrink-0" />
              <span className="leading-snug">{log}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

