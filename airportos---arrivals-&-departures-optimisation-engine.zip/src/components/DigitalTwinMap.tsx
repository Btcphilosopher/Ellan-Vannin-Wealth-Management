import React, { useState, useEffect, useRef } from "react";
import {
  Layers,
  Plane,
  Maximize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Info,
  MapPin,
  Compass,
  AlertTriangle,
  Zap,
} from "lucide-react";
import { Flight, TaxiNode, TaxiEdge, GateStand } from "../types/airport";

interface DigitalTwinMapProps {
  flights: Flight[];
  nodes: TaxiNode[];
  edges: TaxiEdge[];
  gates: GateStand[];
  onSelectFlight: (flightId: string) => void;
}

export const DigitalTwinMap: React.FC<DigitalTwinMapProps> = ({
  flights,
  nodes,
  edges,
  gates,
  onSelectFlight,
}) => {
  const [showTaxiGraph, setShowTaxiGraph] = useState(true);
  const [showGateLabels, setShowGateLabels] = useState(true);
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [selectedAircraftId, setSelectedAircraftId] = useState<string | null>("FL-EK008");
  const [zoomLevel, setZoomLevel] = useState(1);

  // Position animated positions for aircraft on map
  const [aircraftPositions, setAircraftPositions] = useState<Record<string, { x: number; y: number; status: string; angle: number }>>({
    "FL-EK008": { x: 22, y: 25, status: "Landing 09L", angle: 90 },
    "FL-BA210": { x: 30, y: 55, status: "At Gate 102", angle: 0 },
    "FL-VS003": { x: 50, y: 55, status: "At Gate 202", angle: 0 },
    "FL-LH450": { x: 35, y: 35, status: "Taxiing Alpha", angle: 135 },
    "FL-AA100": { x: 70, y: 55, status: "At Gate 301", angle: 0 },
    "FL-UA920": { x: 45, y: 70, status: "Holding RW09R", angle: 180 },
    "FL-FX077": { x: 80, y: 75, status: "Cargo Stand 402", angle: 270 },
  });

  // Simple animation loop moving taxiing aircraft
  useEffect(() => {
    const interval = setInterval(() => {
      setAircraftPositions((prev) => {
        const next = { ...prev };
        // Move FL-LH450 along taxiway
        if (next["FL-LH450"]) {
          let currX = next["FL-LH450"].x;
          let currY = next["FL-LH450"].y;
          currX += 0.15;
          if (currX > 55) currX = 35;
          next["FL-LH450"] = { ...next["FL-LH450"], x: currX, y: currY };
        }
        // Move FL-EK008 down runway
        if (next["FL-EK008"]) {
          let currX = next["FL-EK008"].x;
          currX += 0.2;
          if (currX > 45) currX = 22;
          next["FL-EK008"] = { ...next["FL-EK008"], x: currX };
        }
        return next;
      });
    }, 200);

    return () => clearInterval(interval);
  }, []);

  const selectedFlight = flights.find((f) => f.id === selectedAircraftId);

  return (
    <div className="space-y-4">
      {/* Top Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100">Airport Surface Movement Digital Twin</h3>
            <p className="text-xs text-slate-400">Live 2D Surface Map • Runways, Taxiways, Apron, Stands & Movements</p>
          </div>
        </div>

        {/* Controls & Layer Toggles */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <button
            onClick={() => setShowTaxiGraph(!showTaxiGraph)}
            className={`px-3 py-1.5 rounded-lg border font-medium transition-colors ${
              showTaxiGraph ? "bg-blue-600/20 text-blue-300 border-blue-500/40" : "bg-slate-800 text-slate-400 border-slate-700"
            }`}
          >
            Taxi Graph
          </button>
          <button
            onClick={() => setShowGateLabels(!showGateLabels)}
            className={`px-3 py-1.5 rounded-lg border font-medium transition-colors ${
              showGateLabels ? "bg-blue-600/20 text-blue-300 border-blue-500/40" : "bg-slate-800 text-slate-400 border-slate-700"
            }`}
          >
            Gate Labels
          </button>
          <button
            onClick={() => setShowHeatmap(!showHeatmap)}
            className={`px-3 py-1.5 rounded-lg border font-medium transition-colors ${
              showHeatmap ? "bg-amber-500/20 text-amber-300 border-amber-500/40" : "bg-slate-800 text-slate-400 border-slate-700"
            }`}
          >
            Congestion Heatmap
          </button>

          <div className="h-4 w-px bg-slate-800 my-auto" />

          {/* Zoom controls */}
          <div className="flex items-center space-x-1 bg-slate-800 rounded-lg p-1 border border-slate-700">
            <button
              onClick={() => setZoomLevel((z) => Math.max(0.8, z - 0.2))}
              className="p-1 hover:bg-slate-700 text-slate-300 rounded"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-2 font-mono text-[11px] text-slate-300">{Math.round(zoomLevel * 100)}%</span>
            <button
              onClick={() => setZoomLevel((z) => Math.min(2.0, z + 0.2))}
              className="p-1 hover:bg-slate-700 text-slate-300 rounded"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel(1.0)}
              className="p-1 hover:bg-slate-700 text-slate-300 rounded"
              title="Reset Zoom"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main 2D Surface Map Container */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Map Canvas Box (3/4 width) */}
        <div className="lg:col-span-3 bg-slate-950 border border-slate-800 rounded-xl p-4 relative overflow-hidden min-h-[520px] flex items-center justify-center shadow-inner">
          <div
            className="w-full h-full relative transition-transform duration-300"
            style={{ transform: `scale(${zoomLevel})`, transformOrigin: "center center" }}
          >
            {/* Background Grid Lines */}
            <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-30 pointer-events-none" />

            {/* Runways */}
            {/* Runway 09L / 27R (North) */}
            <div className="absolute left-[10%] top-[22%] w-[80%] h-8 bg-slate-800 border-y-2 border-dashed border-amber-400/80 rounded flex items-center justify-between px-3 text-[10px] font-mono text-slate-400 font-bold shadow-md">
              <span>09L</span>
              <span className="text-slate-500 font-normal">RUNWAY 09L / 27R (3,901m x 50m)</span>
              <span>27R</span>
            </div>

            {/* Runway 09R / 27L (South) */}
            <div className="absolute left-[10%] top-[72%] w-[80%] h-8 bg-slate-800 border-y-2 border-dashed border-amber-400/80 rounded flex items-center justify-between px-3 text-[10px] font-mono text-slate-400 font-bold shadow-md">
              <span>09R</span>
              <span className="text-slate-500 font-normal">RUNWAY 09R / 27L (3,658m x 50m)</span>
              <span>27L</span>
            </div>

            {/* Runway 18 / 36 (Cross) */}
            <div className="absolute left-[48%] top-[15%] w-7 h-[70%] bg-slate-800 border-x-2 border-dashed border-slate-600 rounded flex flex-col justify-between items-center py-2 text-[10px] font-mono text-slate-400 font-bold shadow-md">
              <span>18</span>
              <span className="text-[9px] -rotate-90 text-slate-500 font-normal whitespace-nowrap">RWY 18/36</span>
              <span>36</span>
            </div>

            {/* Taxiway Edges & Graph Lines */}
            {showTaxiGraph && (
              <svg className="absolute inset-0 w-full h-full pointer-events-none stroke-blue-500/40 stroke-2">
                {/* Alpha Taxiway line */}
                <line x1="22%" y1="25%" x2="35%" y2="35%" strokeDasharray="4 4" />
                <line x1="45%" y1="25%" x2="35%" y2="35%" strokeDasharray="4 4" />
                <line x1="35%" y1="35%" x2="55%" y2="45%" strokeWidth="3" className="stroke-indigo-400/60" />
                <line x1="35%" y1="35%" x2="30%" y2="55%" />
                <line x1="55%" y1="45%" x2="50%" y2="55%" />
                <line x1="55%" y1="45%" x2="70%" y2="55%" />
                <line x1="55%" y1="45%" x2="45%" y2="70%" strokeWidth="3" className="stroke-rose-500/60" />
                <line x1="45%" y1="70%" x2="15%" y2="75%" />
                <line x1="55%" y1="45%" x2="80%" y2="75%" />
              </svg>
            )}

            {/* Heatmap Overlays */}
            {showHeatmap && (
              <>
                <div className="absolute left-[40%] top-[40%] w-32 h-32 rounded-full bg-rose-500/20 blur-xl pointer-events-none animate-pulse" />
                <div className="absolute left-[40%] top-[65%] w-24 h-24 rounded-full bg-amber-500/20 blur-lg pointer-events-none" />
              </>
            )}

            {/* Taxiway Nodes */}
            {showTaxiGraph &&
              nodes.map((node) => (
                <div
                  key={node.id}
                  className="absolute w-3 h-3 rounded-full bg-blue-500 border-2 border-slate-900 -translate-x-1/2 -translate-y-1/2 cursor-pointer hover:scale-125 transition-transform"
                  style={{ left: `${node.x}%`, top: `${node.y}%` }}
                  title={`${node.name} (${node.type})`}
                />
              ))}

            {/* Terminals & Gate Blocks */}
            {/* Terminal 1 */}
            <div className="absolute left-[26%] top-[52%] w-[12%] h-[12%] bg-slate-800/90 border border-slate-700 rounded-lg p-2 text-[10px] text-center font-bold text-slate-300 shadow-md">
              Terminal 1
            </div>
            {/* Terminal 2 */}
            <div className="absolute left-[46%] top-[52%] w-[12%] h-[12%] bg-slate-800/90 border border-slate-700 rounded-lg p-2 text-[10px] text-center font-bold text-slate-300 shadow-md">
              Terminal 2 (Alliance)
            </div>
            {/* Terminal 3 */}
            <div className="absolute left-[66%] top-[52%] w-[12%] h-[12%] bg-slate-800/90 border border-slate-700 rounded-lg p-2 text-[10px] text-center font-bold text-slate-300 shadow-md">
              Terminal 3 (Long-Haul)
            </div>
            {/* Terminal 4 / Cargo */}
            <div className="absolute left-[76%] top-[72%] w-[12%] h-[12%] bg-slate-800/90 border border-slate-700 rounded-lg p-2 text-[10px] text-center font-bold text-slate-300 shadow-md">
              Terminal 4 (Cargo)
            </div>

            {/* Gate Labels */}
            {showGateLabels &&
              gates.map((g) => {
                let gx = 30;
                let gy = 55;
                if (g.id === "G101") { gx = 25; gy = 48; }
                if (g.id === "G102") { gx = 30; gy = 48; }
                if (g.id === "G201") { gx = 45; gy = 48; }
                if (g.id === "G202") { gx = 50; gy = 48; }
                if (g.id === "G301") { gx = 65; gy = 48; }
                if (g.id === "G302") { gx = 70; gy = 48; }
                if (g.id === "S402") { gx = 82; gy = 68; }

                return (
                  <div
                    key={g.id}
                    className={`absolute px-1.5 py-0.5 rounded text-[9px] font-mono border font-semibold -translate-x-1/2 -translate-y-1/2 ${
                      g.status === "Occupied"
                        ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                        : "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                    }`}
                    style={{ left: `${gx}%`, top: `${gy}%` }}
                  >
                    {g.name.split(" ")[0]} {g.name.split(" ")[1]}
                  </div>
                );
              })}

            {/* Animated Aircraft Pins */}
            {Object.entries(aircraftPositions).map(([fId, pos]: [string, { x: number; y: number; status: string; angle: number }]) => {
              const flight = flights.find((f) => f.id === fId);
              const isSelected = selectedAircraftId === fId;

              return (
                <div
                  key={fId}
                  onClick={() => {
                    setSelectedAircraftId(fId);
                    onSelectFlight(fId);
                  }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-300 z-20 ${
                    isSelected ? "scale-125 z-30" : "hover:scale-110"
                  }`}
                  style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
                >
                  <div
                    className={`relative flex items-center justify-center w-8 h-8 rounded-full border shadow-lg ${
                      isSelected
                        ? "bg-blue-600 text-white border-white ring-4 ring-blue-500/40"
                        : flight?.flightType === "Arrival"
                        ? "bg-emerald-600 text-white border-emerald-300"
                        : "bg-indigo-600 text-white border-indigo-300"
                    }`}
                  >
                    <Plane className="w-4 h-4 transform -rotate-45" />
                  </div>

                  {/* Callsign Badge */}
                  <div
                    className={`absolute left-1/2 -bottom-5 -translate-x-1/2 whitespace-nowrap px-1.5 py-0.5 rounded text-[9px] font-mono font-bold shadow-md ${
                      isSelected ? "bg-blue-600 text-white" : "bg-slate-900/90 text-slate-200 border border-slate-700"
                    }`}
                  >
                    {flight ? flight.flightNumber : fId}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Aircraft Digital Twin Sidebar (1/4 width) */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4 shadow-sm flex flex-col justify-between">
          {selectedFlight ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-slate-400 font-mono">Selected Aircraft</span>
                  <h3 className="text-lg font-bold text-slate-100">{selectedFlight.flightNumber}</h3>
                  <p className="text-xs text-slate-400">{selectedFlight.airline} • {selectedFlight.aircraftType}</p>
                </div>
                <span className="px-2.5 py-1 rounded text-xs font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  {selectedFlight.status}
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Route:</span>
                  <span className="font-mono font-bold text-slate-200">{selectedFlight.origin} → {selectedFlight.destination}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Wake Category:</span>
                  <span className="font-semibold text-indigo-400">{selectedFlight.wakeCategory}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Assigned Runway:</span>
                  <span className="font-mono text-slate-200">{selectedFlight.runwayId}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Assigned Gate:</span>
                  <span className="font-mono text-slate-200">{selectedFlight.gateId}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Passengers:</span>
                  <span className="font-bold text-slate-200">{selectedFlight.passengerCount} Pax</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Current Delay:</span>
                  <span className={`font-bold ${selectedFlight.delayMinutes > 0 ? "text-amber-400" : "text-emerald-400"}`}>
                    +{selectedFlight.delayMinutes} mins
                  </span>
                </div>
              </div>

              {/* Surface Movement Path Metrics */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-3 space-y-2">
                <div className="flex items-center space-x-1.5 text-xs text-slate-300 font-bold">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>A* Surface Taxi Path</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Path: Rapid Exit A1 → Taxiway Bravo → Apron T2 → Gate 201
                </p>
                <div className="flex justify-between text-[11px] text-slate-300 pt-1">
                  <span>Distance: <strong>1,250m</strong></span>
                  <span>Est Taxi: <strong>4.8 mins</strong></span>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500 text-xs">
              Select an aircraft on the map to inspect live telemetry and taxi path.
            </div>
          )}

          <div className="pt-3 border-t border-slate-800">
            <button
              onClick={() => selectedFlight && onSelectFlight(selectedFlight.id)}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold py-2 rounded-lg transition-colors"
            >
              Open Flight Turnaround DAG
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
