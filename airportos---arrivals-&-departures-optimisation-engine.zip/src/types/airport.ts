export type AircraftClass =
  | "regional_jet"
  | "narrow_body"
  | "wide_body"
  | "turboprop"
  | "freighter"
  | "business_aviation"
  | "charter"
  | "future_concept";

export type WakeCategory = "Super" | "Heavy" | "Medium" | "Light";

export type FlightStatus =
  | "Scheduled"
  | "Boarding"
  | "Ready"
  | "Pushback"
  | "Taxiing"
  | "Departed"
  | "Airborne"
  | "Approaching"
  | "Landed"
  | "Taxi-to-gate"
  | "At-gate"
  | "Delayed"
  | "Cancelled"
  | "Diverted";

export type FlightType = "Arrival" | "Departure" | "Turnaround";

export interface Aircraft {
  id: string;
  flightNumber: string;
  airline: string;
  aircraftType: string; // e.g. "A350-1000", "B787-9", "A320neo", "ATR-72", "B777F"
  registration: string;
  class: AircraftClass;
  origin: string; // IATA code
  destination: string;
  scheduledArrival: string; // ISO string
  estimatedArrival: string;
  scheduledDeparture: string;
  estimatedDeparture: string;
  turnaroundTimeMinutes: number;
  passengerCapacity: number;
  cargoCapacityKg: number;
  fuelRequirementKg: number;
  gateCompatibility: string[]; // compatible gate types
  standCompatibility: string[];
  runwayCompatibilityMinLengthM: number;
  wakeCategory: WakeCategory;
  noiseCategory: "QC1" | "QC2" | "QC4" | "QC8";
  operationalStatus: "In-Flight" | "On-Ground" | "Maintenance" | "Decommissioned";
}

export interface ConnectingPassengerGroup {
  id: string;
  inboundFlightId: string;
  outboundFlightId: string;
  passengerCount: number;
  baggageCount: number;
  minimumConnectionTimeMinutes: number;
  transferType: "International-International" | "International-Domestic" | "Domestic-Domestic";
  riskLevel: "Low" | "Medium" | "High" | "Critical";
  estimatedTransferTimeMinutes: number;
}

export interface Flight {
  id: string;
  aircraftId: string;
  flightNumber: string;
  airline: string;
  aircraftType: string;
  wakeCategory: WakeCategory;
  origin: string;
  destination: string;
  flightType: FlightType;
  arrivalTime: string;
  departureTime: string;
  gateId: string;
  standId: string;
  terminalId: string;
  runwayId: string;
  passengerCount: number;
  cargoWeightKg: number;
  priorityScore: number; // 1-100 based on pax, connections, VIP, economic value
  delayMinutes: number;
  connectionRiskCount: number;
  status: FlightStatus;
  rotationSequence?: string[]; // list of flight numbers in rotation e.g. ["BA101", "BA102", "BA103"]
  targetOffBlockTime?: string;
  targetLandingTime?: string;
}

export interface Runway {
  id: string; // e.g. "09L/27R"
  name: string;
  lengthM: number;
  widthM: number;
  surface: "Asphalt" | "Concrete";
  directionDegrees: number;
  configuration: "Single" | "Parallel" | "Intersecting";
  mode: "Arrivals Only" | "Departures Only" | "Mixed Mode";
  arrivalCapacityPerHour: number;
  departureCapacityPerHour: number;
  currentStatus: "Active" | "Maintenance" | "Closed" | "Weather Restricted";
  occupancyTimeSeconds: number; // Average runway occupancy
  currentMovementsPerHour: number;
  weatherLimitations: string[];
}

export interface GateStand {
  id: string;
  name: string; // e.g. "Gate 22" or "Stand 401"
  terminalId: string;
  isRemoteStand: boolean;
  hasPassengerBridge: boolean;
  maxAircraftClass: AircraftClass;
  isInternational: boolean;
  isSchengen: boolean;
  hasCustoms: boolean;
  currentOccupantFlightId?: string;
  nextAvailableTime: string;
  towingRequired: boolean;
  status: "Available" | "Occupied" | "Maintenance" | "Conflict";
}

export interface TurnaroundTask {
  id: string;
  taskName:
    | "Deplane Passengers"
    | "Unload Baggage"
    | "Cabin Cleaning"
    | "Catering Replenishment"
    | "Refuelling"
    | "Water Servicing"
    | "Lavatory Servicing"
    | "Cargo Loading"
    | "Passenger Boarding"
    | "Doors Closure & Checks"
    | "Tug Attachment & Pushback";
  durationMinutes: number;
  dependencies: string[]; // Task IDs that must finish before this starts
  status: "Pending" | "In-Progress" | "Completed" | "Delayed";
  assignedCrewId?: string;
  progressPercent: number;
  criticalPath: boolean;
  startedAt?: string;
  completedAt?: string;
}

export interface TurnaroundProcess {
  flightId: string;
  scheduledDurationMinutes: number;
  predictedDurationMinutes: number;
  actualDurationMinutes: number;
  minimumFeasibleMinutes: number;
  riskLevel: "Low" | "Medium" | "High" | "Critical";
  criticalConstraint: string;
  tasks: TurnaroundTask[];
  predictedDepartureDelayMinutes: number;
}

export interface GroundResource {
  id: string;
  type:
    | "Baggage Crew"
    | "Ramp Crew"
    | "Pushback Tractor"
    | "Catering Truck"
    | "Cleaning Crew"
    | "Fuel Hydrant Truck"
    | "Water Truck"
    | "Lavatory Truck"
    | "Cargo Loader"
    | "De-icing Rig";
  status: "Available" | "Assigned" | "In-Transit" | "Maintenance";
  assignedFlightId?: string;
  locationNodeId: string;
}

export interface ResourceConflict {
  id: string;
  resourceType: string;
  flightAId: string;
  flightBId: string;
  requestedTimeA: string;
  requestedTimeB: string;
  recommendedResolution: string;
}

export interface StandConflict {
  id: string;
  standId: string;
  flightAId: string;
  flightBId: string;
  overlapStart: string;
  overlapEnd: string;
  alternativeStandId: string;
  towingRequired: boolean;
}

export interface TaxiNode {
  id: string;
  name: string;
  type: "Runway_Exit" | "Taxiway_Intersection" | "Apron_Entry" | "Stand" | "Holding_Point";
  x: number; // percentage coordinate on digital twin map (0-100)
  y: number;
}

export interface TaxiEdge {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  name: string; // e.g. "Taxiway Alpha"
  distanceMeters: number;
  speedLimitKts: number;
  currentCongestionLevel: "Clear" | "Moderate" | "Heavy" | "Blocked";
  isRunwayCrossing: boolean;
}

export interface SurfaceMovementState {
  aircraftId: string;
  flightNumber: string;
  currentNodeId: string;
  targetNodeId: string;
  currentEdgeId?: string;
  progressOnEdgePercent: number;
  routeNodeIds: string[];
  estimatedTaxiTimeSeconds: number;
  speedKts: number;
  isHolding: boolean;
  holdingReason?: string;
}

export interface BaggageSystemState {
  totalInboundBags: number;
  totalOutboundBags: number;
  transferBagsCount: number;
  sorterConveyorUtilisationPercent: number;
  screeningLanesActive: number;
  screeningThroughputBagsPerHour: number;
  predictedBottleneckArea?: string;
}

export interface SecurityCapacityState {
  openLanes: number;
  totalLanes: number;
  staffOnDuty: number;
  passengersPerHourThroughput: number;
  currentQueueCount: number;
  averageWaitTimeMinutes: number;
  forecastQueue30m: number;
}

export interface ImmigrationCapacityState {
  passportDesksOpen: number;
  eGatesActive: number;
  currentQueueCount: number;
  processingRatePaxPerMin: number;
  averageWaitTimeMinutes: number;
}

export interface WeatherScenario {
  condition: "Clear" | "Light Rain" | "Heavy Thunderstorm" | "Low Visibility / Fog" | "High Crosswind" | "Snow / Ice";
  windSpeedKts: number;
  windDirectionDegrees: number;
  visibilityKm: number;
  temperatureC: number;
  runwayCapacityReductionPercent: number;
  deIcingRequired: boolean;
}

export interface DisruptionEvent {
  id: string;
  type: "Runway_Closure" | "Gate_Failure" | "Ground_Crew_Shortage" | "Severe_Weather" | "Baggage_System_Fault" | "Aircraft_Technical";
  title: string;
  description: string;
  impactedResourceIds: string[];
  startTime: string;
  estimatedEndTime: string;
  severity: "Minor" | "Moderate" | "Major" | "Critical";
  status: "Active" | "Mitigated" | "Resolved";
}

export interface DisruptionRecoveryPlan {
  id: string;
  disruptionId: string;
  createdAt: string;
  newArrivalSequences: { flightId: string; originalEta: string; newEta: string; delayMinutes: number }[];
  newDepartureSequences: { flightId: string; originalEtd: string; newEtd: string; delayMinutes: number }[];
  reassignedGates: { flightId: string; oldGateId: string; newGateId: string }[];
  connectionHoldRecommendations: { flightId: string; holdMinutes: number; savedPassengers: number; costTradeoffBenefit: number }[];
  totalSavedDelayMinutes: number;
  totalPreventedMissedConnections: number;
  netEconomicBenefitPounds: number;
}

export interface CapacityInvestmentProject {
  id: string;
  title: string; // e.g. "New Rapid-Exit Taxiway Echo", "Terminal 3 Gate Pier Extension"
  type: "Runway" | "Taxiway" | "Terminal" | "Stand" | "Baggage" | "Security";
  capexPounds: number;
  annualOpexPounds: number;
  capacityGainMovementsPerHour: number;
  capacityGainPaxPerHour: number;
  annualAdditionalRevenuePounds: number;
  npvPounds: number;
  irrPercent: number;
  paybackYears: number;
  valuePerPoundInvested: number; // IRR/CAPEX ratio ranking
}

export interface HeatmapHorizon {
  timeOffsetLabel: "NOW" | "+15m" | "+30m" | "+1h" | "+3h" | "+12h" | "+24h";
  runwayUtilisationPercent: number;
  taxiwayCongestionPercent: number;
  gateUtilisationPercent: number;
  standUtilisationPercent: number;
  securityQueueUtilisationPercent: number;
  baggageConveyorUtilisationPercent: number;
  immigrationUtilisationPercent: number;
}

export interface ControlTowerMetrics {
  arrivalsNext60m: number;
  departuresNext60m: number;
  runwayUtilisationPercent: number;
  gateUtilisationPercent: number;
  standUtilisationPercent: number;
  averageDelayMinutes: number;
  aircraftAtRiskCount: number;
  missedConnectionRiskPaxCount: number;
  turnaroundCriticalRiskCount: number;
  activeDisruptionsCount: number;
  onTimeDepartureRatePercent: number;
}
