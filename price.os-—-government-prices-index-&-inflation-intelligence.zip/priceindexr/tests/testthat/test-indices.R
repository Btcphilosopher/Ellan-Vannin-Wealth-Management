test_that("Elementary indices match mathematical definitions", {
  current <- c(1.20, 2.40, 4.80)
  base <- c(1.00, 2.00, 4.00)
  
  # Each ratio is 1.20
  expect_equal(round(jevons_index(current, base), 2), 120.00)
  expect_equal(round(dutot_index(current, base), 2), 120.00)
  expect_equal(round(carli_index(current, base), 2), 120.00)
})

test_that("Carli index exhibits known upward arithmetic bias", {
  current <- c(2.00, 0.50)
  base <- c(1.00, 1.00)
  # Ratios: 2.0 and 0.5
  # Jevons = sqrt(2 * 0.5) = 1.0 -> 100
  # Carli = mean(2, 0.5) = 1.25 -> 125
  expect_equal(jevons_index(current, base), 100.0)
  expect_equal(carli_index(current, base), 125.0)
})

test_that("Laspeyres aggregate index weights correctly", {
  indices <- c(110, 120)
  weights <- c(500, 500)
  expect_equal(laspeyres_index(indices, weights), 115.0)
})

test_that("Quantity quality adjustment handles shrinkflation", {
  # 500g -> 400g at same £2.00 price
  adj <- adjust_quality(2.00, 0.500, 0.400)
  expect_equal(adj, 2.50)
})
