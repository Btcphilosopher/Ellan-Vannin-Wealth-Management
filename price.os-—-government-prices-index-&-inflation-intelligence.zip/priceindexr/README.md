# priceindexr: Transparent and Defensible Government Price Index Engine

`priceindexr` is a dedicated R statistical package for calculating consumer price indices, producer price indices, and business cost inflation metrics under internationally harmonised methodologies (ILO/IMF/OECD CPI Manual, Eurostat HICP, and UK ONS guidelines).

## Core Capabilities
- **Elementary Price Indices**: `jevons_index()`, `dutot_index()`, `carli_index()`
- **Higher-Level Aggregations**: `laspeyres_index()`, `paasche_index()`, `fisher_index()`, `lowe_index()`, `tornqvist_index()`
- **Inflation Metrics**: `calculate_mom_inflation()`, `calculate_yoy_inflation()`, `calculate_annual_average()`
- **Decomposition**: `calculate_contributions()` for additive percentage-point impact
- **Chain Linking & Rebasing**: `chain_link_index()`, `rebase_index()`, `update_weights()`
- **Micro-Data Validation & Outliers**: `validate_price_data()`, `detect_price_outliers()`, `impute_missing_prices()`
- **Quality & Quantity Adjustments**: `adjust_quality()`, `fit_hedonic_model()`
- **Forecasting & Sensitivity**: `forecast_price_index()`, `analyse_index_sensitivity()`

## Quick Example
```r
library(priceindexr)

# Elementary index calculation
curr <- c(1.35, 2.10, 4.45)
base <- c(1.25, 2.00, 4.20)
j_idx <- jevons_index(curr, base)
print(j_idx)

# Higher level Laspeyres aggregation
div_indices <- c(108.4, 104.2, 112.1)
exp_weights <- c(118, 42, 56)
headline <- laspeyres_index(div_indices, exp_weights)
print(headline)
```

Maintained by PRICE.OS Office of the Chief Statistician.
