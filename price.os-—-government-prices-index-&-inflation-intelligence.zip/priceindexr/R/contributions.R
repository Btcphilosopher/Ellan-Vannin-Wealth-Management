#' Calculate Percentage-Point Contributions to Headline Inflation
#'
#' @description
#' Decomposes the 12-month change in the aggregate index into the additive
#' contributions of its constituent COICOP categories (ONS / Eurostat standard formula).
#'
#' \deqn{\text{Contribution}_{c,t} = w_{c,t-12} \frac{I_{c,t} - I_{c,t-12}}{I_{\text{headline}, t-12}}}
#'
#' @param category_indices Matrix or data.frame with columns as categories and rows as time periods.
#' @param headline_series Numeric vector of aggregate headline index points.
#' @param weights Vector of normalised category weights summing to 1.
#' @param period_index Target row index for contribution evaluation.
#'
#' @return A data.frame of category codes, category weights, category YoY, and percentage-point contributions.
#' @export
calculate_contributions <- function(category_indices, headline_series, weights, period_index) {
  if (period_index <= 12) {
    stop("period_index must be greater than 12 for annual contribution analysis.")
  }
  
  headline_base <- headline_series[period_index - 12]
  k <- ncol(category_indices)
  
  contributions <- numeric(k)
  for (j in 1:k) {
    cat_curr <- category_indices[period_index, j]
    cat_base <- category_indices[period_index - 12, j]
    w_norm <- weights[j] / sum(weights)
    contributions[j] <- (w_norm * (cat_curr - cat_base) / headline_base) * 100
  }
  
  data.frame(
    category = colnames(category_indices),
    weight = weights,
    contribution_ppt = round(contributions, 2)
  )
}
