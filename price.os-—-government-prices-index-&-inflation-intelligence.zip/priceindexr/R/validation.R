#' Validate Price Dataset Observations
#'
#' @description
#' Performs automated data validation checks on micro-level price records.
#' Identifies negative prices, zero prices, duplicate quotes, and extreme movements.
#'
#' @param df data.frame containing columns 'price', 'product_id', 'outlet_id', 'date'
#' @export
validate_price_data <- function(df) {
  errors <- list()
  
  if (any(df$price <= 0, na.rm = TRUE)) {
    errors$non_positive <- which(df$price <= 0)
  }
  
  dups <- duplicated(df[, c("product_id", "outlet_id", "date")])
  if (any(dups)) {
    errors$duplicates <- which(dups)
  }
  
  list(
    total_observations = nrow(df),
    valid_count = nrow(df) - length(unique(unlist(errors))),
    errors = errors,
    is_valid = (length(errors) == 0)
  )
}

#' Detect Extreme Price Outliers
#'
#' @param prices Current prices vector.
#' @param base_prices Corresponding base period prices.
#' @param k Multiplier for interquartile range (default 1.5).
#' @export
detect_price_outliers <- function(prices, base_prices, k = 1.5) {
  ratios <- log(prices / base_prices)
  q1 <- stats::quantile(ratios, 0.25, na.rm = TRUE)
  q3 <- stats::quantile(ratios, 0.75, na.rm = TRUE)
  iqr <- q3 - q1
  
  lower_bound <- q1 - k * iqr
  upper_bound <- q3 + k * iqr
  
  outliers <- which(ratios < lower_bound | ratios > upper_bound)
  outliers
}

#' Impute Missing Prices
#'
#' @description
#' Imputes temporarily missing item quotes using class-mean or carry-forward procedures.
#' @param prices Vector of prices with NAs.
#' @param method Character: "class_mean" or "carry_forward".
#' @export
impute_missing_prices <- function(prices, method = "class_mean") {
  if (method == "class_mean") {
    m <- mean(prices, na.rm = TRUE)
    prices[is.na(prices)] <- m
  } else if (method == "carry_forward") {
    for (i in 2:length(prices)) {
      if (is.na(prices[i])) prices[i] <- prices[i - 1]
    }
  }
  prices
}

#' Quality Adjustment for Price Changes
#'
#' @description
#' Adjusts observed price for changes in quantity/specification (e.g., shrinkflation).
#'
#' \deqn{p^* = p_{\text{obs}} \cdot \left(\frac{q_{\text{base}}}{q_{\text{current}}}\right)}
#'
#' @param observed_price Observed shelf price.
#' @param base_quantity Standard base package quantity.
#' @param current_quantity Current package quantity.
#' @export
adjust_quality <- function(observed_price, base_quantity, current_quantity) {
  if (current_quantity <= 0) stop("current_quantity must be positive.")
  observed_price * (base_quantity / current_quantity)
}

#' Fit Hedonic Price Regression
#'
#' @param formula Model formula, e.g. log(price) ~ screen_size + ram + storage
#' @param data Data frame of product specifications and prices.
#' @export
fit_hedonic_model <- function(formula, data) {
  stats::lm(formula, data = data)
}

#' Forecast Price Index Series
#'
#' @param index_series Numeric historical series.
#' @param h Horizon months ahead.
#' @export
forecast_price_index <- function(index_series, h = 6) {
  n <- length(index_series)
  recent_diff <- diff(index_series[(n - 6):n])
  drift <- mean(recent_diff)
  
  future <- numeric(h)
  last_val <- index_series[n]
  for (i in 1:h) {
    last_val <- last_val + drift
    future[i] <- round(last_val, 2)
  }
  
  future
}

#' Sensitivity Analysis for Basket Weights
#'
#' @param elementary_indices Vector of sub-indices.
#' @param weights Vector of base weights.
#' @param perturb_sd Relative perturbation standard deviation.
#' @export
analyse_index_sensitivity <- function(elementary_indices, weights, perturb_sd = 0.05) {
  baseline <- sum(elementary_indices * (weights / sum(weights)))
  simulations <- replicate(200, {
    noisy_w <- weights * stats::rnorm(length(weights), mean = 1, sd = perturb_sd)
    noisy_w[noisy_w < 0] <- 0
    sum(elementary_indices * (noisy_w / sum(noisy_w)))
  })
  
  list(
    baseline = baseline,
    sim_mean = mean(simulations),
    sim_sd = stats::sd(simulations),
    ci_95 = stats::quantile(simulations, c(0.025, 0.975))
  )
}
