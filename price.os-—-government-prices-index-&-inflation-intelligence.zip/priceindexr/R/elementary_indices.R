#' Calculate Jevons Elementary Price Index
#'
#' @description
#' Computes the unweighted geometric mean of price ratios for matched elementary items.
#' Satisfies the time reversal and transitivity axioms. Standard formula for European HICP
#' and UK CPI elementary aggregates.
#'
#' \deqn{I_{0,t}^J = 100 \left(\prod_{i=1}^n \frac{p_{i,t}}{p_{i,0}}\right)^{1/n}}
#'
#' @param current_prices Numeric vector of current period prices (\eqn{p_{i,t}}).
#' @param base_prices Numeric vector of base period prices (\eqn{p_{i,0}}).
#' @param na.rm Logical, whether to remove missing observations. Default TRUE.
#'
#' @return A single numeric index value scaled to 100 in base period.
#' @references ILO, IMF, OECD, UNECE, Eurostat, World Bank (2020), Consumer Price Index Manual: Concepts and Methods.
#' @export
#' @examples
#' jevons_index(c(1.10, 2.30, 4.50), c(1.00, 2.00, 4.00))
jevons_index <- function(current_prices, base_prices, na.rm = TRUE) {
  if (length(current_prices) != length(base_prices)) {
    stop("current_prices and base_prices must have identical length.")
  }
  valid <- !is.na(current_prices) & !is.na(base_prices) & base_prices > 0 & current_prices > 0
  if (!any(valid)) return(NA_real_)
  
  ratios <- current_prices[valid] / base_prices[valid]
  # Geometric mean using log-scale to prevent numerical overflow
  100 * exp(mean(log(ratios)))
}

#' Calculate Dutot Elementary Price Index
#'
#' @description
#' Computes the ratio of arithmetic mean prices for strictly homogeneous items
#' with common units of measurement.
#'
#' \deqn{I_{0,t}^D = 100 \frac{\sum_{i=1}^n p_{i,t}}{\sum_{i=1}^n p_{i,0}}}
#'
#' @param current_prices Numeric vector of current prices.
#' @param base_prices Numeric vector of base prices.
#' @param na.rm Logical, default TRUE.
#'
#' @return A single numeric index value scaled to 100.
#' @export
#' @examples
#' dutot_index(c(1.40, 1.45, 1.50), c(1.30, 1.35, 1.40))
dutot_index <- function(current_prices, base_prices, na.rm = TRUE) {
  if (length(current_prices) != length(base_prices)) {
    stop("current_prices and base_prices must have identical length.")
  }
  valid <- !is.na(current_prices) & !is.na(base_prices) & base_prices > 0 & current_prices >= 0
  if (!any(valid)) return(NA_real_)
  
  100 * (sum(current_prices[valid]) / sum(base_prices[valid]))
}

#' Calculate Carli Elementary Price Index
#'
#' @description
#' Computes the arithmetic mean of price relatives. Known to have an upward bias
#' and fails the time-reversal test. Historically used in the UK Retail Prices Index (RPI).
#'
#' \deqn{I_{0,t}^C = \frac{100}{n} \sum_{i=1}^n \frac{p_{i,t}}{p_{i,0}}}
#'
#' @param current_prices Numeric vector of current prices.
#' @param base_prices Numeric vector of base prices.
#' @param na.rm Logical, default TRUE.
#'
#' @return A single numeric index value scaled to 100.
#' @export
#' @examples
#' carli_index(c(1.10, 2.30, 4.50), c(1.00, 2.00, 4.00))
carli_index <- function(current_prices, base_prices, na.rm = TRUE) {
  if (length(current_prices) != length(base_prices)) {
    stop("current_prices and base_prices must have identical length.")
  }
  valid <- !is.na(current_prices) & !is.na(base_prices) & base_prices > 0 & current_prices >= 0
  if (!any(valid)) return(NA_real_)
  
  ratios <- current_prices[valid] / base_prices[valid]
  100 * mean(ratios)
}
