#' Calculate Month-on-Month Inflation Rate
#'
#' @description
#' Computes the percentage change in the index between month t and month t-1.
#'
#' \deqn{\pi_{1,t} = 100 \left( \frac{I_t}{I_{t-1}} - 1 \right)}
#'
#' @param index_series Numeric vector of monthly index values ordered chronologically.
#' @return Numeric vector of percentage rates with first element NA.
#' @export
calculate_mom_inflation <- function(index_series) {
  if (length(index_series) < 2) return(rep(NA_real_, length(index_series)))
  lagged <- c(NA_real_, index_series[-length(index_series)])
  100 * ((index_series / lagged) - 1)
}

#' Calculate Year-on-Year Inflation Rate
#'
#' @description
#' Computes the 12-month percentage change in the price index series.
#'
#' \deqn{\pi_{12,t} = 100 \left( \frac{I_t}{I_{t-12}} - 1 \right)}
#'
#' @param index_series Numeric vector of monthly index values.
#' @return Numeric vector of annual inflation rates (first 12 elements NA).
#' @export
calculate_yoy_inflation <- function(index_series) {
  n <- length(index_series)
  if (n <= 12) return(rep(NA_real_, n))
  lagged12 <- c(rep(NA_real_, 12), index_series[1:(n - 12)])
  100 * ((index_series / lagged12) - 1)
}

#' Calculate 12-Month Moving Average Inflation
#'
#' @description
#' Annual average index rate comparing average of past 12 months with preceding 12 months.
#' @param index_series Numeric vector of index points.
#' @export
calculate_annual_average <- function(index_series) {
  n <- length(index_series)
  if (n < 24) return(rep(NA_real_, n))
  res <- rep(NA_real_, n)
  for (i in 24:n) {
    curr_12 <- mean(index_series[(i - 11):i])
    prev_12 <- mean(index_series[(i - 23):(i - 12)])
    res[i] <- 100 * ((curr_12 / prev_12) - 1)
  }
  res
}

#' Chain Link Index Series
#'
#' @description
#' Multiplies overlapping series at the link month to produce a continuous historical series.
#' @param new_series Numeric vector of indices on new base.
#' @param old_series Numeric vector of indices on old base.
#' @param link_index Numeric index of overlapping period.
#' @export
chain_link_index <- function(new_series, old_series, link_index) {
  link_factor <- old_series[link_index] / new_series[link_index]
  c(old_series[1:(link_index - 1)], new_series[link_index:length(new_series)] * link_factor)
}

#' Rebase Index Series to New Reference Year
#'
#' @param index_series Numeric vector of index values.
#' @param new_base_mean Value or mean of target reference period (e.g. 2024=100).
#' @export
rebase_index <- function(index_series, new_base_mean) {
  if (new_base_mean <= 0) stop("new_base_mean must be strictly positive.")
  (index_series / new_base_mean) * 100
}

#' Update Expenditure Weights
#'
#' @param raw_weights Numeric vector of category weights.
#' @param target_total Target sum (default 1000 for per-mille).
#' @export
update_weights <- function(raw_weights, target_total = 1000) {
  if (any(raw_weights < 0)) stop("Weights must be non-negative.")
  (raw_weights / sum(raw_weights)) * target_total
}
