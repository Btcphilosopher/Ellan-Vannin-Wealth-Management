#' Calculate Laspeyres Aggregate Price Index
#'
#' @description
#' Evaluates price movements using fixed base-period quantities or expenditure shares.
#'
#' \deqn{I_L = 100 \frac{\sum_i p_{i,t} q_{i,0}}{\sum_i p_{i,0} q_{i,0}} = \sum_i w_{i,0} \left(\frac{p_{i,t}}{p_{i,0}}\right)}
#'
#' @param elementary_indices Numeric vector of elementary price indices (e.g. base = 100).
#' @param weights Numeric vector of expenditure weights corresponding to elementary indices.
#' @param normalise_weights Logical, whether to scale weights to sum to 1. Default TRUE.
#'
#' @return Aggregate index numeric value.
#' @export
laspeyres_index <- function(elementary_indices, weights, normalise_weights = TRUE) {
  if (length(elementary_indices) != length(weights)) {
    stop("Indices and weights vectors must have the same length.")
  }
  if (normalise_weights) {
    w <- weights / sum(weights)
  } else {
    w <- weights
  }
  sum(elementary_indices * w)
}

#' Calculate Paasche Price Index
#'
#' @description
#' Evaluates price changes weighted by current-period consumption quantities.
#'
#' \deqn{I_P = 100 \frac{\sum_i p_{i,t} q_{i,t}}{\sum_i p_{i,0} q_{i,t}}}
#'
#' @param current_prices Numeric vector of period t prices.
#' @param base_prices Numeric vector of period 0 prices.
#' @param current_quantities Numeric vector of period t quantities.
#' @export
paasche_index <- function(current_prices, base_prices, current_quantities) {
  num <- sum(current_prices * current_quantities)
  denom <- sum(base_prices * current_quantities)
  if (denom == 0) return(NA_real_)
  100 * (num / denom)
}

#' Calculate Fisher Ideal Price Index
#'
#' @description
#' Geometric mean of Laspeyres and Paasche price indices. A superlative index
#' that satisfies both the time reversal and factor reversal axioms.
#'
#' \deqn{I_F = \sqrt{I_L \cdot I_P}}
#'
#' @param laspeyres Numeric Laspeyres index value.
#' @param paasche Numeric Paasche index value.
#' @export
fisher_index <- function(laspeyres, paasche) {
  sqrt(laspeyres * paasche)
}

#' Calculate Törnqvist Superlative Price Index
#'
#' @description
#' Weighted geometric average of price ratios with weights equal to the arithmetic
#' average of expenditure shares in base and current periods.
#'
#' @param price_relatives Numeric vector of price ratios (p_{i,t} / p_{i,0}).
#' @param base_shares Numeric vector of period 0 expenditure shares (sum to 1).
#' @param current_shares Numeric vector of period t expenditure shares (sum to 1).
#' @export
tornqvist_index <- function(price_relatives, base_shares, current_shares) {
  avg_weights <- (base_shares + current_shares) / 2
  100 * exp(sum(avg_weights * log(price_relatives)))
}

#' Calculate Lowe Price Index
#'
#' @description
#' Fixed-basket index where the quantity vector corresponds to an earlier reference period b.
#' @param current_prices Vector of current prices.
#' @param base_prices Vector of price reference prices.
#' @param basket_quantities Vector of reference basket quantities.
#' @export
lowe_index <- function(current_prices, base_prices, basket_quantities) {
  100 * (sum(current_prices * basket_quantities) / sum(base_prices * basket_quantities))
}
