/**
 * PRICE.OS — Types and Data Models
 * Government Statistics • Inflation Measurement • Business Price Intelligence
 */

export type IndexFormula = 'jevons' | 'dutot' | 'carli';
export type AggregationFormula = 'laspeyres' | 'paasche' | 'fisher' | 'lowe' | 'young' | 'tornqvist';
export type PriceType = 'shelf' | 'transaction' | 'online_scrape' | 'scanner' | 'admin' | 'business_quote';
export type ValidationStatus = 'valid' | 'warning' | 'flagged' | 'rejected' | 'imputed' | 'adjusted';
export type Role = 'chief_statistician' | 'price_collector' | 'methodology_reviewer' | 'economic_analyst' | 'auditor';

export interface PriceObservation {
  observationId: string;
  productId: string;
  productName: string;
  coicopCode: string; // e.g. "01.1.1"
  divisionCode: string; // e.g. "01"
  divisionName: string;
  outletId: string;
  retailerName: string;
  regionCode: string;
  regionName: string;
  collectionDate: string; // YYYY-MM-DD
  observedPrice: number;
  basePrice?: number;
  currency: string;
  quantity: number;
  unitCode: string; // kg, litre, unit, pack
  priceType: PriceType;
  dataSource: string;
  qualityFlag?: string;
  status: ValidationStatus;
  notes?: string;
  isPromotional?: boolean;
  shrinkflationFlag?: boolean;
}

export interface CoicopDivision {
  code: string;
  name: string;
  description: string;
  defaultWeight: number; // in parts per 1000 (per mille)
  icon: string;
  isCoreItem: boolean; // Food and energy excluded from core
  isGoods: boolean;
}

export interface BasketItem {
  id: string;
  coicopCode: string;
  divisionCode: string;
  name: string;
  specification: string;
  weight: number; // per mille (sum to 1000)
  unit: string;
  samplingFrequency: 'monthly' | 'quarterly';
  elementaryFormula: IndexFormula;
}

export interface WeightSet {
  id: string;
  name: string;
  year: number;
  methodology: string;
  totalWeights: number; // 1000
  weightsByDivision: Record<string, number>;
  source: string;
  status: 'active' | 'draft' | 'archived';
  approvedBy?: string;
  updatedAt: string;
}

export interface MonthlyIndexPoint {
  period: string; // YYYY-MM
  indexValue: number; // 2024 = 100
  momInflation: number; // %
  yoyInflation: number; // %
  threeMonthChange?: number; // %
  annualAverage?: number; // %
}

export interface CategoryContribution {
  divisionCode: string;
  divisionName: string;
  weight: number;
  categoryIndex: number;
  categoryMom: number;
  categoryYoy: number;
  percentagePointContribution: number; // ppt to headline YoY
}

export interface ElementaryIndexResult {
  coicopCode: string;
  divisionCode: string;
  period: string;
  formula: IndexFormula;
  observationCount: number;
  indexValue: number;
  geometricMeanRatio?: number;
  arithmeticMeanRatio?: number;
}

export interface AggregateIndexRun {
  runId: string;
  timestamp: string;
  methodologyVersion: string;
  basePeriod: string;
  elementaryFormula: IndexFormula;
  aggregateFormula: AggregationFormula;
  weightSetId: string;
  configHash: string;
  calculatedBy: string;
  series: {
    headline: MonthlyIndexPoint[];
    core: MonthlyIndexPoint[];
    food: MonthlyIndexPoint[];
    energy: MonthlyIndexPoint[];
    goods: MonthlyIndexPoint[];
    services: MonthlyIndexPoint[];
    rpiStyle: MonthlyIndexPoint[];
    hicpStyle: MonthlyIndexPoint[];
    cpihStyle: MonthlyIndexPoint[];
  };
  contributions: Record<string, CategoryContribution[]>; // period -> contributions
  divisionsSeries: Record<string, MonthlyIndexPoint[]>;
  warnings: string[];
  reproducibilitySeed: number;
}

export interface ValidationRuleResult {
  id: string;
  observationId: string;
  ruleName: string;
  severity: 'warning' | 'error';
  message: string;
  currentValue: number | string;
  expectedRange?: string;
  resolved: boolean;
}

export interface BusinessCostBasket {
  id: string;
  name: string;
  industry: string;
  components: {
    name: string;
    weight: number; // percentage (0-100)
    category: 'energy' | 'freight' | 'raw_materials' | 'labor' | 'tech' | 'packaging';
    baseIndex: number;
    currentIndex: number;
    trend: number;
  }[];
  notes: string;
}

export interface StatisticalRelease {
  id: string;
  title: string;
  referencePeriod: string; // e.g. "October 2026"
  headlineYoy: number;
  headlineMom: number;
  coreYoy: number;
  stage: 'cutoff' | 'validation' | 'processing' | 'methodological_review' | 'qa' | 'approval' | 'release_prep' | 'published' | 'revised';
  embargoDate: string;
  isEmbargoed: boolean;
  publishedDate?: string;
  publishedBy?: string;
  bulletinSummary: string;
  approvedBy?: string;
  dataVintage: string;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  user: string;
  role: Role;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
  configHash?: string;
}

export interface ForecastPoint {
  period: string;
  pointForecast: number;
  lower80: number;
  upper80: number;
  lower95: number;
  upper95: number;
  yoyForecast: number;
}
