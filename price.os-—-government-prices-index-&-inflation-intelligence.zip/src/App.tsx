/**
 * PRICE.OS — Government Prices Index & Inflation Intelligence Operating System
 * National Statistics • Econometric R Engine • Business Price Intelligence
 */

import React, { useState, useEffect } from 'react';
import {
  PriceObservation,
  AggregateIndexRun,
  ValidationRuleResult,
  IndexFormula,
  AggregationFormula,
} from './types/priceIndex';
import { generateSyntheticObservations } from './services/syntheticData';
import { StatisticalEngine } from './services/statisticalEngine';
import { COICOP_DIVISIONS } from './services/coicopData';

// Workstations
import { NationalDashboard } from './components/workstations/NationalDashboard';
import { PriceCollectionCentre } from './components/workstations/PriceCollectionCentre';
import { ProductRegistry } from './components/workstations/ProductRegistry';
import { PriceValidationLab } from './components/workstations/PriceValidationLab';
import { IndexCalculationStudio } from './components/workstations/IndexCalculationStudio';
import { InflationAnalysis } from './components/workstations/InflationAnalysis';
import { BusinessPriceIntelligence } from './components/workstations/BusinessPriceIntelligence';
import { ProducerPrices, RevisionAuditCentre } from './components/workstations/ProducerPrices';
import { RegionalObservatory, BasketWeightsManager } from './components/workstations/RegionalObservatory';
import { QualityAdjustmentLab, TimeSeriesWorkbench } from './components/workstations/QualityAdjustmentLab';
import { ForecastingStudio } from './components/workstations/ForecastingStudio';
import { StatisticalPublications } from './components/workstations/StatisticalPublications';
import { DataExplorer } from './components/workstations/DataExplorer';
import { RStatisticalConsole } from './components/workstations/RStatisticalConsole';
import { EnterpriseAdmin } from './components/workstations/EnterpriseAdmin';

import {
  BarChart3,
  Database,
  Sliders,
  TrendingUp,
  Briefcase,
  Terminal,
  FileText,
  Search,
  ShieldCheck,
  Building,
  RotateCcw,
  CheckCircle2,
} from 'lucide-react';

export type WorkstationId =
  | 'national-dashboard'
  | 'collection-centre'
  | 'product-registry'
  | 'validation-lab'
  | 'calculation-studio'
  | 'inflation-analysis'
  | 'business-intelligence'
  | 'producer-prices'
  | 'regional-observatory'
  | 'basket-weights'
  | 'quality-adjustment'
  | 'timeseries-workbench'
  | 'forecasting-studio'
  | 'publications'
  | 'data-explorer'
  | 'r-console'
  | 'revision-audit'
  | 'enterprise-admin';

export default function App() {
  const [observations, setObservations] = useState<PriceObservation[]>(() => {
    return generateSyntheticObservations();
  });

  const [weightsByDivision, setWeightsByDivision] = useState<Record<string, number>>(() => {
    const wMap: Record<string, number> = {};
    COICOP_DIVISIONS.forEach(d => {
      wMap[d.code] = d.defaultWeight;
    });
    return wMap;
  });

  const [currentRun, setCurrentRun] = useState<AggregateIndexRun>(() => {
    const initialObs = generateSyntheticObservations();
    const wMap: Record<string, number> = {};
    COICOP_DIVISIONS.forEach(d => { wMap[d.code] = d.defaultWeight; });
    return StatisticalEngine.runIndexCalculation(initialObs, wMap, 'jevons', 'laspeyres', 2024);
  });

  const [validationResults, setValidationResults] = useState<ValidationRuleResult[]>(() => {
    return StatisticalEngine.validateDataset(observations);
  });

  const [activeWorkstation, setActiveWorkstation] = useState<WorkstationId>('national-dashboard');
  const [isCalculating, setIsCalculating] = useState<boolean>(false);

  // Recalculate index when triggered
  const handleRunCalculation = (
    elementaryFormula: IndexFormula = currentRun.elementaryFormula,
    aggregateFormula: AggregationFormula = currentRun.aggregateFormula,
    baseYear: number = 2024
  ) => {
    setIsCalculating(true);
    setTimeout(() => {
      const newRun = StatisticalEngine.runIndexCalculation(
        observations,
        weightsByDivision,
        elementaryFormula,
        aggregateFormula,
        baseYear
      );
      setCurrentRun(newRun);
      setIsCalculating(false);
    }, 120);
  };

  // Add observation
  const handleAddObservation = (newObs: PriceObservation) => {
    const updated = [newObs, ...observations];
    setObservations(updated);
    // update calculations
    const newRun = StatisticalEngine.runIndexCalculation(
      updated,
      weightsByDivision,
      currentRun.elementaryFormula,
      currentRun.aggregateFormula
    );
    setCurrentRun(newRun);
    setValidationResults(StatisticalEngine.validateDataset(updated));
  };

  // Resolve validation issue
  const handleResolveValidation = (
    issueId: string,
    action: 'accept' | 'reject' | 'adjust' | 'impute',
    note?: string
  ) => {
    const issue = validationResults.find(i => i.id === issueId);
    if (!issue) return;

    const updatedObs = observations.map(o => {
      if (o.observationId === issue.observationId) {
        if (action === 'accept') {
          return { ...o, status: 'valid' as const, notes: note };
        } else if (action === 'reject') {
          return { ...o, status: 'rejected' as const, notes: note };
        } else if (action === 'adjust') {
          // normalize shrinkflation or decimal typo
          const correctedPrice = o.observedPrice > 100 ? 1.80 : o.observedPrice * (0.80 / (o.quantity || 0.70));
          return { ...o, observedPrice: Number(correctedPrice.toFixed(2)), status: 'adjusted' as const, notes: note };
        } else if (action === 'impute') {
          return { ...o, observedPrice: 1.25, status: 'imputed' as const, notes: note };
        }
      }
      return o;
    });

    setObservations(updatedObs);
    setValidationResults(
      validationResults.map(i => (i.id === issueId ? { ...i, resolved: true } : i))
    );

    // Refresh calculation run
    const newRun = StatisticalEngine.runIndexCalculation(
      updatedObs,
      weightsByDivision,
      currentRun.elementaryFormula,
      currentRun.aggregateFormula
    );
    setCurrentRun(newRun);
  };

  // Update weights
  const handleUpdateWeights = (newWeights: Record<string, number>) => {
    setWeightsByDivision(newWeights);
    const newRun = StatisticalEngine.runIndexCalculation(
      observations,
      newWeights,
      currentRun.elementaryFormula,
      currentRun.aggregateFormula
    );
    setCurrentRun(newRun);
  };

  const handleExportFullReport = () => {
    const csvContent = "data:text/csv;charset=utf-8," +
      "Period,HeadlineCPI,CoreCPI,FoodCPI,EnergyCPI,GoodsCPI,ServicesCPI,YoYInflation,MoMInflation\n" +
      currentRun.series.headline.map(h => {
        const core = currentRun.series.core.find(c => c.period === h.period)?.indexValue || 100;
        const food = currentRun.series.food.find(f => f.period === h.period)?.indexValue || 100;
        const energy = currentRun.series.energy.find(e => e.period === h.period)?.indexValue || 100;
        const goods = currentRun.series.goods.find(g => g.period === h.period)?.indexValue || 100;
        const services = currentRun.series.services.find(s => s.period === h.period)?.indexValue || 100;
        return `${h.period},${h.indexValue.toFixed(2)},${core.toFixed(2)},${food.toFixed(2)},${energy.toFixed(2)},${goods.toFixed(2)},${services.toFixed(2)},${h.yoyInflation.toFixed(2)}%,${h.momInflation.toFixed(2)}%`;
      }).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `PRICE_OS_Index_Report_${currentRun.runId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900 selection:bg-blue-900 selection:text-white">
      {/* 
        TOP BAR CONTRACT:
        Zone 1: Single text element wordmark
        Zone 2: 4-5 concise single-line nav links with hover underlines
        Zone 3: 1 primary action button
      */}
      <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-slate-900 text-white border-b border-slate-800 shrink-0">
        {/* Zone 1: Brand wordmark */}
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded bg-blue-600 flex items-center justify-center font-bold text-white text-xs tracking-wider shadow-xs">
            OS
          </div>
          <span className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0">
            PRICE.OS
          </span>
          <span className="hidden sm:inline-block text-[11px] text-slate-400 font-mono border-l border-slate-700 pl-2.5">
            GOVERNMENT PRICES INDEX
          </span>
        </div>

        {/* Zone 2: 4-5 clean single-line text links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-300">
          <button
            onClick={() => setActiveWorkstation('national-dashboard')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${activeWorkstation === 'national-dashboard' ? 'text-white border-b-2 border-blue-500 pb-0.5' : ''}`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveWorkstation('validation-lab')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${activeWorkstation === 'validation-lab' ? 'text-white border-b-2 border-blue-500 pb-0.5' : ''}`}
          >
            Validation Lab
          </button>
          <button
            onClick={() => setActiveWorkstation('calculation-studio')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${activeWorkstation === 'calculation-studio' ? 'text-white border-b-2 border-blue-500 pb-0.5' : ''}`}
          >
            Calculation Studio
          </button>
          <button
            onClick={() => setActiveWorkstation('business-intelligence')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${activeWorkstation === 'business-intelligence' ? 'text-white border-b-2 border-blue-500 pb-0.5' : ''}`}
          >
            Business Prices
          </button>
          <button
            onClick={() => setActiveWorkstation('r-console')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${activeWorkstation === 'r-console' ? 'text-white border-b-2 border-blue-500 pb-0.5' : ''}`}
          >
            R Console
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => handleRunCalculation()}
            disabled={isCalculating}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors whitespace-nowrap shrink-0 shadow-xs flex items-center gap-1.5"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isCalculating ? 'animate-spin' : ''}`} />
            {isCalculating ? 'Calculating...' : 'Recalculate Series'}
          </button>
        </div>
      </header>

      {/* Sub-Header Toolbar: Full 18 Government Workstations Navigation Strip */}
      <div className="bg-white border-b border-slate-200 px-6 py-2 overflow-x-auto">
        <div className="flex items-center gap-1.5 min-w-max text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-2 shrink-0">
            Workstations:
          </span>

          {/* Group 1: Macro & Dashboards */}
          <button
            onClick={() => setActiveWorkstation('national-dashboard')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'national-dashboard'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            1. National Dashboard
          </button>

          <button
            onClick={() => setActiveWorkstation('collection-centre')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'collection-centre'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            2. Collection Centre
          </button>

          <button
            onClick={() => setActiveWorkstation('product-registry')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'product-registry'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            3. Product Registry
          </button>

          <button
            onClick={() => setActiveWorkstation('validation-lab')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'validation-lab'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            4. Validation Lab
          </button>

          <button
            onClick={() => setActiveWorkstation('calculation-studio')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'calculation-studio'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            5. Calculation Studio
          </button>

          <button
            onClick={() => setActiveWorkstation('inflation-analysis')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'inflation-analysis'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            6. Inflation Analysis
          </button>

          <button
            onClick={() => setActiveWorkstation('business-intelligence')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'business-intelligence'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            7. Business Prices
          </button>

          <button
            onClick={() => setActiveWorkstation('producer-prices')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'producer-prices'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            8. Producer Prices
          </button>

          <button
            onClick={() => setActiveWorkstation('regional-observatory')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'regional-observatory'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            9. Regional Observatory
          </button>

          <button
            onClick={() => setActiveWorkstation('basket-weights')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'basket-weights'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            10. Basket & Weights
          </button>

          <button
            onClick={() => setActiveWorkstation('quality-adjustment')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'quality-adjustment'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            11. Quality Lab
          </button>

          <button
            onClick={() => setActiveWorkstation('timeseries-workbench')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'timeseries-workbench'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            12. Time-Series
          </button>

          <button
            onClick={() => setActiveWorkstation('forecasting-studio')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'forecasting-studio'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            13. Forecasting
          </button>

          <button
            onClick={() => setActiveWorkstation('publications')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'publications'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            14. Publications
          </button>

          <button
            onClick={() => setActiveWorkstation('data-explorer')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'data-explorer'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            15. Data Explorer
          </button>

          <button
            onClick={() => setActiveWorkstation('r-console')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'r-console'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            16. R Console
          </button>

          <button
            onClick={() => setActiveWorkstation('revision-audit')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'revision-audit'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            17. Revision & Audit
          </button>

          <button
            onClick={() => setActiveWorkstation('enterprise-admin')}
            className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              activeWorkstation === 'enterprise-admin'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            18. Administration
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6">
        {activeWorkstation === 'national-dashboard' && (
          <NationalDashboard
            currentRun={currentRun}
            onNavigateToWorkstation={(id) => setActiveWorkstation(id as WorkstationId)}
            onExportReport={handleExportFullReport}
          />
        )}

        {activeWorkstation === 'collection-centre' && (
          <PriceCollectionCentre
            onAddObservation={handleAddObservation}
            observationsCount={observations.length}
          />
        )}

        {activeWorkstation === 'product-registry' && (
          <ProductRegistry />
        )}

        {activeWorkstation === 'validation-lab' && (
          <PriceValidationLab
            observations={observations}
            validationResults={validationResults}
            onResolveIssue={handleResolveValidation}
            onRevalidate={() => setValidationResults(StatisticalEngine.validateDataset(observations))}
          />
        )}

        {activeWorkstation === 'calculation-studio' && (
          <IndexCalculationStudio
            currentRun={currentRun}
            onRunCalculation={handleRunCalculation}
            isCalculating={isCalculating}
          />
        )}

        {activeWorkstation === 'inflation-analysis' && (
          <InflationAnalysis currentRun={currentRun} />
        )}

        {activeWorkstation === 'business-intelligence' && (
          <BusinessPriceIntelligence />
        )}

        {activeWorkstation === 'producer-prices' && (
          <ProducerPrices currentRun={currentRun} />
        )}

        {activeWorkstation === 'regional-observatory' && (
          <RegionalObservatory />
        )}

        {activeWorkstation === 'basket-weights' && (
          <BasketWeightsManager
            weights={weightsByDivision}
            onUpdateWeights={handleUpdateWeights}
          />
        )}

        {activeWorkstation === 'quality-adjustment' && (
          <QualityAdjustmentLab />
        )}

        {activeWorkstation === 'timeseries-workbench' && (
          <TimeSeriesWorkbench currentRun={currentRun} />
        )}

        {activeWorkstation === 'forecasting-studio' && (
          <ForecastingStudio currentRun={currentRun} />
        )}

        {activeWorkstation === 'publications' && (
          <StatisticalPublications currentRun={currentRun} />
        )}

        {activeWorkstation === 'data-explorer' && (
          <DataExplorer observations={observations} />
        )}

        {activeWorkstation === 'r-console' && (
          <RStatisticalConsole currentRun={currentRun} />
        )}

        {activeWorkstation === 'revision-audit' && (
          <RevisionAuditCentre currentRun={currentRun} />
        )}

        {activeWorkstation === 'enterprise-admin' && (
          <EnterpriseAdmin
            currentRun={currentRun}
            observationsCount={observations.length}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 px-6 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-700">PRICE.OS</span>
          <span aria-hidden="true">·</span>
          <span>Government Prices Index & Inflation Intelligence</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono text-[11px]">R package: priceindexr v1.0.0</span>
        </div>
        <div className="flex items-center gap-4 text-slate-400 font-mono text-[11px]">
          <span>Hash: {currentRun.configHash.slice(0, 16)}</span>
          <span aria-hidden="true">·</span>
          <span>Seed: {currentRun.reproducibilitySeed}</span>
        </div>
      </footer>
    </div>
  );
}
