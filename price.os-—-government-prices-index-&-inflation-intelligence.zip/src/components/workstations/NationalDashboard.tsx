import React, { useState } from 'react';
import { AggregateIndexRun } from '../../types/priceIndex';
import { MultiLineChart, WaterfallContributionChart } from '../common/Charts';
import { ArrowUpRight, ArrowDownRight, ShieldCheck, Download, AlertTriangle, FileText, CheckCircle2 } from 'lucide-react';

export function NationalDashboard({
  currentRun,
  onNavigateToWorkstation,
  onExportReport,
}: {
  currentRun: AggregateIndexRun;
  onNavigateToWorkstation: (id: string) => void;
  onExportReport: () => void;
}) {
  const [selectedOverlay, setSelectedOverlay] = useState<'standard' | 'variants' | 'subcomponents'>('standard');

  const headline = currentRun.series.headline;
  const latestIdx = headline.length - 1;
  const latestHeadline = headline[latestIdx];
  const priorMonthHeadline = headline[latestIdx - 1];

  const latestCore = currentRun.series.core[latestIdx];
  const latestFood = currentRun.series.food[latestIdx];
  const latestEnergy = currentRun.series.energy[latestIdx];
  const latestGoods = currentRun.series.goods[latestIdx];
  const latestServices = currentRun.series.services[latestIdx];

  const contributions = currentRun.contributions[latestHeadline.period] || [];

  // Chart series configuration
  const chartSeries = selectedOverlay === 'standard' ? [
    { name: 'Headline CPI', color: '#1e3a8a', data: headline.map(h => ({ period: h.period, value: h.yoyInflation })) },
    { name: 'Core CPI (ex Food/Energy)', color: '#0d9488', data: currentRun.series.core.map(h => ({ period: h.period, value: h.yoyInflation })) },
    { name: 'Goods Inflation', color: '#64748b', data: currentRun.series.goods.map(h => ({ period: h.period, value: h.yoyInflation })) },
    { name: 'Services Inflation', color: '#d97706', data: currentRun.series.services.map(h => ({ period: h.period, value: h.yoyInflation })) },
  ] : selectedOverlay === 'variants' ? [
    { name: 'CPI (Headline Jevons)', color: '#1e3a8a', data: headline.map(h => ({ period: h.period, value: h.yoyInflation })) },
    { name: 'CPIH (Owner-Occupiers)', color: '#0d9488', data: currentRun.series.cpihStyle.map(h => ({ period: h.period, value: h.yoyInflation })) },
    { name: 'RPI-Style (Carli Element)', color: '#dc2626', data: currentRun.series.rpiStyle.map(h => ({ period: h.period, value: h.yoyInflation })) },
    { name: 'HICP Aligned', color: '#6366f1', data: currentRun.series.hicpStyle.map(h => ({ period: h.period, value: h.yoyInflation })) },
  ] : [
    { name: 'Food & Non-Alcoholic', color: '#16a34a', data: currentRun.series.food.map(h => ({ period: h.period, value: h.yoyInflation })) },
    { name: 'Housing & Energy', color: '#ea580c', data: currentRun.series.energy.map(h => ({ period: h.period, value: h.yoyInflation })) },
    { name: 'Headline CPI', color: '#1e3a8a', data: headline.map(h => ({ period: h.period, value: h.yoyInflation })) },
  ];

  const sortedContribs = [...contributions]
    .sort((a, b) => Math.abs(b.percentagePointContribution) - Math.abs(a.percentagePointContribution))
    .slice(0, 8)
    .map(c => ({ name: c.divisionName, ppt: c.percentagePointContribution }));

  return (
    <div className="space-y-6">
      {/* Top Banner / Official Status */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span>OFFICIAL NATIONAL STATISTICS</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">{latestHeadline.period} VINTAGE</span>
            <span aria-hidden="true">·</span>
            <span>BASE: {currentRun.basePeriod}</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-700 flex items-center gap-1 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" /> CODE OF PRACTICE COMPLIANT
            </span>
          </div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 mt-1">
            Consumer Price Index & Inflation Intelligence
          </h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Calculation Run <span className="font-mono font-semibold">{currentRun.runId}</span> · Method: {currentRun.elementaryFormula.toUpperCase()} Elementary / {currentRun.aggregateFormula.toUpperCase()} Aggregate
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => onNavigateToWorkstation('publications')}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5"
          >
            <FileText className="w-3.5 h-3.5" /> Statistical Bulletin
          </button>
          <button
            onClick={onExportReport}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 rounded-md transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Download className="w-3.5 h-3.5" /> Export Data & R Script
          </button>
        </div>
      </div>

      {/* Primary KPI Metric Strip */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Headline CPI YoY */}
        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
            Headline CPI YoY
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {latestHeadline.yoyInflation.toFixed(2)}%
            </span>
            <span className={`text-xs font-mono tabular-nums flex items-center ${latestHeadline.yoyInflation >= priorMonthHeadline.yoyInflation ? 'text-amber-600' : 'text-emerald-600'}`}>
              {latestHeadline.yoyInflation >= priorMonthHeadline.yoyInflation ? (
                <ArrowUpRight className="w-3.5 h-3.5" />
              ) : (
                <ArrowDownRight className="w-3.5 h-3.5" />
              )}
              {Math.abs(latestHeadline.yoyInflation - priorMonthHeadline.yoyInflation).toFixed(2)}
            </span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Index: {latestHeadline.indexValue.toFixed(2)}
          </div>
        </div>

        {/* Headline CPI MoM */}
        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
            Monthly Change (MoM)
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {latestHeadline.momInflation > 0 ? `+${latestHeadline.momInflation.toFixed(2)}%` : `${latestHeadline.momInflation.toFixed(2)}%`}
            </span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Prior month: {priorMonthHeadline.momInflation > 0 ? `+${priorMonthHeadline.momInflation.toFixed(2)}%` : `${priorMonthHeadline.momInflation.toFixed(2)}%`}
          </div>
        </div>

        {/* Core CPI */}
        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
            Core CPI (Ex Food/Energy)
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-teal-800">
              {latestCore.yoyInflation.toFixed(2)}%
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Sticky services anchor
          </div>
        </div>

        {/* Food & Beverages */}
        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
            Food & Non-Alcoholic
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {latestFood.yoyInflation.toFixed(2)}%
            </span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Div 01 (11.8% weight)
          </div>
        </div>

        {/* Goods vs Services Spread */}
        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
            Services vs Goods
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {latestServices.yoyInflation.toFixed(1)}% / {latestGoods.yoyInflation.toFixed(1)}%
            </span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Spread: +{(latestServices.yoyInflation - latestGoods.yoyInflation).toFixed(1)}%
          </div>
        </div>

        {/* Alternative RPI / CPIH */}
        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
            CPIH / RPI Benchmark
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {currentRun.series.cpihStyle[latestIdx].yoyInflation.toFixed(1)}%
            </span>
            <span className="text-xs text-slate-400 font-mono">
              / {currentRun.series.rpiStyle[latestIdx].yoyInflation.toFixed(1)}%
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Housing included / Legacy RPI
          </div>
        </div>
      </div>

      {/* Main Analysis Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Time-Series Chart */}
        <div className="lg:col-span-2 p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Inflation Time Series & Methodology Comparators
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Annual Year-on-Year percentage change (%) across 34 monthly collection vintages
              </p>
            </div>

            {/* Segmented series switcher */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start sm:self-auto">
              <button
                onClick={() => setSelectedOverlay('standard')}
                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                  selectedOverlay === 'standard' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Core vs Goods/Services
              </button>
              <button
                onClick={() => setSelectedOverlay('variants')}
                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                  selectedOverlay === 'variants' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                CPI vs CPIH vs RPI
              </button>
              <button
                onClick={() => setSelectedOverlay('subcomponents')}
                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                  selectedOverlay === 'subcomponents' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Food & Energy
              </button>
            </div>
          </div>

          <MultiLineChart series={chartSeries} height={300} yUnit="%" zeroLine={true} />

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Formula: Jevons geometric mean at elementary level; Laspeyres chained aggregation.</span>
            <button
              onClick={() => onNavigateToWorkstation('calculation-studio')}
              className="text-blue-700 hover:underline font-semibold"
            >
              Open Index Calculation Studio →
            </button>
          </div>
        </div>

        {/* Right Col: Category Contributions Decomposition */}
        <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Annual Inflation Contributions
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Additive percentage-point impact on headline {latestHeadline.yoyInflation.toFixed(2)}%
              </p>
            </div>
            <button
              onClick={() => onNavigateToWorkstation('inflation-analysis')}
              className="text-xs text-blue-700 font-semibold hover:underline"
            >
              Full Analysis
            </button>
          </div>

          <WaterfallContributionChart
            contributions={sortedContribs}
            headlineYoy={latestHeadline.yoyInflation}
          />

          <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500 leading-relaxed">
            Decomposed using the official Eurostat/ONS formula:
            <span className="font-mono block text-slate-700 mt-1 bg-slate-50 p-1.5 rounded text-[10px]">
              Contr_c = w_c × (I_{'{c,t}'} - I_{'{c,t-12}'}) / I_{'{headline, t-12}'}
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Section: Data Quality, Audit Status & Quick Navigation */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-lg flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <div className="text-xs font-bold text-slate-900">Data Integrity & Validation</div>
            <p className="text-xs text-slate-600 mt-1">
              99.2% of micro-price observations passed automated validation checks. Outliers flagged for review in the Validation Lab.
            </p>
            <button
              onClick={() => onNavigateToWorkstation('validation-lab')}
              className="text-xs text-blue-700 font-semibold hover:underline mt-2 inline-block"
            >
              Review Validation Lab (4 flags) →
            </button>
          </div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <div className="text-xs font-bold text-slate-900">Business Price Intelligence</div>
            <p className="text-xs text-slate-600 mt-1">
              Commercial inputs and energy tariffs showing diverging dynamics vs consumer indices. Input PPI tracking +3.8% YoY.
            </p>
            <button
              onClick={() => onNavigateToWorkstation('business-intelligence')}
              className="text-xs text-blue-700 font-semibold hover:underline mt-2 inline-block"
            >
              Open Business Cost Intelligence →
            </button>
          </div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg flex items-start gap-3">
          <FileText className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
          <div>
            <div className="text-xs font-bold text-slate-900">R Statistical Engine (priceindexr)</div>
            <p className="text-xs text-slate-600 mt-1">
              All calculations verified by the integrated R package. Reproducible scripts generated with golden test verification.
            </p>
            <button
              onClick={() => onNavigateToWorkstation('r-console')}
              className="text-xs text-blue-700 font-semibold hover:underline mt-2 inline-block"
            >
              Inspect R Console & Package →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
