import React, { useState } from 'react';
import { PriceObservation } from '../../types/priceIndex';
import { COICOP_DIVISIONS, REGIONS } from '../../services/coicopData';
import { Upload, Plus, FileSpreadsheet, Server, Check, ArrowRight } from 'lucide-react';

export function PriceCollectionCentre({
  onAddObservation,
  observationsCount,
}: {
  onAddObservation: (obs: PriceObservation) => void;
  observationsCount: number;
}) {
  const [productName, setProductName] = useState('');
  const [divisionCode, setDivisionCode] = useState('01');
  const [coicopCode, setCoicopCode] = useState('01.1.1');
  const [observedPrice, setObservedPrice] = useState('2.45');
  const [retailerName, setRetailerName] = useState('Tesco Superstores');
  const [regionCode, setRegionCode] = useState('UK-LON');
  const [quantity, setQuantity] = useState('1.0');
  const [unitCode, setUnitCode] = useState('kg');
  const [priceType, setPriceType] = useState<'shelf' | 'transaction' | 'scanner' | 'admin'>('shelf');
  const [successMsg, setSuccessMsg] = useState(false);

  const [csvPasteText, setCsvPasteText] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);

  const handleSubmitManual = (e: React.FormEvent) => {
    e.preventDefault();
    const div = COICOP_DIVISIONS.find(d => d.code === divisionCode);
    const reg = REGIONS.find(r => r.code === regionCode);

    const newObs: PriceObservation = {
      observationId: `OBS-MANUAL-${Date.now().toString(36).toUpperCase()}`,
      productId: `PRD-USER-${Math.floor(Math.random() * 1000)}`,
      productName: productName.trim() || 'Custom Sample Product',
      coicopCode,
      divisionCode,
      divisionName: div ? div.name : 'Food & Non-Alcoholic',
      outletId: `OUT-MANUAL-${Math.floor(Math.random() * 50)}`,
      retailerName,
      regionCode,
      regionName: reg ? reg.name : 'London',
      collectionDate: new Date().toISOString().slice(0, 10),
      observedPrice: parseFloat(observedPrice) || 1.0,
      basePrice: parseFloat(observedPrice) * 0.95,
      currency: 'GBP',
      quantity: parseFloat(quantity) || 1.0,
      unitCode,
      priceType,
      dataSource: 'MANUAL_OFFICER_INPUT',
      status: 'valid',
    };

    onAddObservation(newObs);
    setSuccessMsg(true);
    setTimeout(() => setSuccessMsg(false), 3000);
    setProductName('');
  };

  const handleImportCsv = () => {
    if (!csvPasteText.trim()) return;
    const lines = csvPasteText.trim().split('\n');
    let importedCount = 0;

    lines.forEach((line, idx) => {
      // skip header if present
      if (idx === 0 && line.toLowerCase().includes('price')) return;
      const parts = line.split(',');
      if (parts.length >= 3) {
        const name = parts[0]?.trim() || `Imported Item ${idx}`;
        const p = parseFloat(parts[1]?.trim());
        const div = parts[2]?.trim() || '01';
        if (!isNaN(p) && p > 0) {
          const divObj = COICOP_DIVISIONS.find(d => d.code === div) || COICOP_DIVISIONS[0];
          onAddObservation({
            observationId: `OBS-CSV-${Date.now().toString(36)}-${idx}`,
            productId: `PRD-CSV-${idx}`,
            productName: name,
            coicopCode: `${divObj.code}.1.1`,
            divisionCode: divObj.code,
            divisionName: divObj.name,
            outletId: 'OUT-IMPORT-01',
            retailerName: parts[3]?.trim() || 'Direct Data Feed',
            regionCode: 'UK-LON',
            regionName: 'London',
            collectionDate: new Date().toISOString().slice(0, 10),
            observedPrice: p,
            basePrice: p * 0.96,
            currency: 'GBP',
            quantity: 1.0,
            unitCode: 'unit',
            priceType: 'transaction',
            dataSource: 'BATCH_CSV_INGEST',
            status: 'valid',
          });
          importedCount++;
        }
      }
    });

    setImportStatus(`Successfully ingested ${importedCount} price observations into the active database.`);
    setCsvPasteText('');
    setTimeout(() => setImportStatus(null), 5000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">FIELD OPERATIONS · PRICE INGESTION PIPELINES</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Price Collection Centre</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Ingest retail feeds, field enumerator tablet logs, scanner data, administrative tariffs, and manual survey quotes.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-semibold text-slate-700 bg-slate-100 px-3 py-1.5 rounded">
            Total Ingested: {observationsCount.toLocaleString()} Quotes
          </span>
        </div>
      </div>

      {/* Automated Data Feeds Status */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">EPOS Scanner Ingest</span>
            <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-mono font-semibold">ACTIVE</span>
          </div>
          <div className="text-xs text-slate-500 mt-2">Supermarket point-of-sale scanner transaction data stream</div>
          <div className="text-[11px] font-mono text-slate-700 mt-2">1,240 quotes/mo · Weekly sync</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">Field Tablet Surveys</span>
            <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-mono font-semibold">ACTIVE</span>
          </div>
          <div className="text-xs text-slate-500 mt-2">Local price collection across 12 UK regions on Collection Tuesday</div>
          <div className="text-[11px] font-mono text-slate-700 mt-2">850 quotes/mo · Field audited</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">Administrative Tariffs</span>
            <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-mono font-semibold">ACTIVE</span>
          </div>
          <div className="text-xs text-slate-500 mt-2">Ofgem domestic energy price caps, rail fares, water authority tariffs</div>
          <div className="text-[11px] font-mono text-slate-700 mt-2">Direct statutory feed</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">Web Scraping Pipeline</span>
            <span className="text-[10px] text-blue-800 bg-blue-50 px-2 py-0.5 rounded font-mono font-semibold">SCHEDULED</span>
          </div>
          <div className="text-xs text-slate-500 mt-2">Lawful collection of public online catalogue listings for consumer tech</div>
          <div className="text-[11px] font-mono text-slate-700 mt-2">Daily crawler bots</div>
        </div>
      </div>

      {/* Input Operations: Manual Entry Form & CSV Bulk Ingest */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Manual Quote Entry */}
        <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-blue-900" /> Single Price Quote Entry
            </h2>
            <span className="text-xs text-slate-500 font-mono">Field Survey</span>
          </div>

          {successMsg && (
            <div className="p-2.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-xs flex items-center gap-2">
              <Check className="w-4 h-4" /> Observation logged and added to current index dataset!
            </div>
          )}

          <form onSubmit={handleSubmitManual} className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Product Description</label>
              <input
                type="text"
                required
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="e.g. White Sliced Loaf 800g"
                className="w-full p-2 border border-slate-300 rounded"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">COICOP Division</label>
                <select
                  value={divisionCode}
                  onChange={(e) => {
                    setDivisionCode(e.target.value);
                    setCoicopCode(`${e.target.value}.1.1`);
                  }}
                  className="w-full p-2 border border-slate-300 rounded"
                >
                  {COICOP_DIVISIONS.map(d => (
                    <option key={d.code} value={d.code}>
                      Div {d.code}: {d.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Observed Price (£)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={observedPrice}
                  onChange={(e) => setObservedPrice(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded font-mono tabular-nums"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Retailer / Supplier</label>
                <input
                  type="text"
                  value={retailerName}
                  onChange={(e) => setRetailerName(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Region</label>
                <select
                  value={regionCode}
                  onChange={(e) => setRegionCode(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded"
                >
                  {REGIONS.map(r => (
                    <option key={r.code} value={r.code}>
                      {r.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Quantity</label>
                <input
                  type="number"
                  step="0.01"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded font-mono"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Unit</label>
                <input
                  type="text"
                  value={unitCode}
                  onChange={(e) => setUnitCode(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded font-mono"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Price Type</label>
                <select
                  value={priceType}
                  onChange={(e) => setPriceType(e.target.value as any)}
                  className="w-full p-2 border border-slate-300 rounded"
                >
                  <option value="shelf">Shelf Price</option>
                  <option value="transaction">Transaction</option>
                  <option value="scanner">Scanner</option>
                  <option value="admin">Admin Feed</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 px-3 text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 rounded transition-colors"
            >
              Submit & Ingest Observation
            </button>
          </form>
        </div>

        {/* Bulk CSV / Batch Ingest */}
        <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <FileSpreadsheet className="w-4 h-4 text-emerald-800" /> Batch CSV Ingestion
            </h2>
            <span className="text-xs text-slate-500 font-mono">Bulk Ingest</span>
          </div>

          <p className="text-xs text-slate-600">
            Paste comma-separated rows: <code className="bg-slate-100 px-1 py-0.5 rounded text-[11px] font-mono">ProductName, Price, DivisionCode, Retailer</code>
          </p>

          <textarea
            value={csvPasteText}
            onChange={(e) => setCsvPasteText(e.target.value)}
            rows={7}
            placeholder={`Organic Butter 250g, 2.80, 01, Sainsbury's\nWireless Mouse, 19.99, 08, Currys Tech\nRoast Coffee Beans 1kg, 14.50, 01, Waitrose`}
            className="w-full p-2.5 border border-slate-300 rounded font-mono text-xs focus:ring-1 focus:ring-blue-900"
          />

          {importStatus && (
            <div className="p-2.5 bg-blue-50 text-blue-900 border border-blue-200 rounded text-xs">
              {importStatus}
            </div>
          )}

          <button
            onClick={handleImportCsv}
            disabled={!csvPasteText.trim()}
            className="w-full py-2 px-3 text-xs font-semibold text-white bg-emerald-800 hover:bg-emerald-700 disabled:opacity-50 rounded transition-colors flex items-center justify-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5" /> Parse & Ingest Batch Observations
          </button>
        </div>
      </div>
    </div>
  );
}
