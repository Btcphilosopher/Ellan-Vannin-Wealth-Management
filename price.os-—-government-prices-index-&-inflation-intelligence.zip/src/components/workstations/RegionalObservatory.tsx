import React, { useState } from 'react';
import { REGIONS } from '../../services/coicopData';
import { MapPin, Globe, Compass, ShieldAlert } from 'lucide-react';

export function RegionalObservatory() {
  // Spatial price index (London = 100 benchmark) and regional annual inflation
  const regionalData = [
    { code: 'UK-LON', name: 'London', spatialPriceLevel: 108.4, inflationYoY: 3.1, sampleQuotes: 384, coverage: 'Comprehensive' },
    { code: 'UK-SE', name: 'South East', spatialPriceLevel: 104.2, inflationYoY: 2.8, sampleQuotes: 320, coverage: 'Comprehensive' },
    { code: 'UK-EE', name: 'East of England', spatialPriceLevel: 101.5, inflationYoY: 2.6, sampleQuotes: 210, coverage: 'Good' },
    { code: 'UK-SW', name: 'South West', spatialPriceLevel: 99.8, inflationYoY: 2.5, sampleQuotes: 195, coverage: 'Good' },
    { code: 'UK-WM', name: 'West Midlands', spatialPriceLevel: 97.4, inflationYoY: 2.9, sampleQuotes: 205, coverage: 'Good' },
    { code: 'UK-NW', name: 'North West', spatialPriceLevel: 96.8, inflationYoY: 2.7, sampleQuotes: 245, coverage: 'Comprehensive' },
    { code: 'UK-EM', name: 'East Midlands', spatialPriceLevel: 96.2, inflationYoY: 2.4, sampleQuotes: 170, coverage: 'Adequate' },
    { code: 'UK-YH', name: 'Yorkshire & The Humber', spatialPriceLevel: 95.5, inflationYoY: 2.6, sampleQuotes: 185, coverage: 'Good' },
    { code: 'UK-SCT', name: 'Scotland', spatialPriceLevel: 96.0, inflationYoY: 2.5, sampleQuotes: 190, coverage: 'Good' },
    { code: 'UK-WLS', name: 'Wales', spatialPriceLevel: 94.8, inflationYoY: 2.3, sampleQuotes: 110, coverage: 'Adequate' },
    { code: 'UK-NE', name: 'North East', spatialPriceLevel: 93.6, inflationYoY: 2.4, sampleQuotes: 95, coverage: 'Adequate' },
    { code: 'UK-NIR', name: 'Northern Ireland', spatialPriceLevel: 94.2, inflationYoY: 2.6, sampleQuotes: 80, coverage: 'Adequate' },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">GEOGRAPHICAL VARIATION · SPATIAL COMPARISON</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Regional Price Observatory</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Compare spatial consumer price levels and regional annual inflation across the 12 UK statistical regions.
          </p>
        </div>

        <div className="text-xs text-slate-500 font-mono bg-slate-100 px-3 py-1.5 rounded">
          Spatial Base: UK National Average = 100.0
        </div>
      </div>

      {/* Critical Methodological Advisory Note (prompt requirement: "Do not equate regional inflation rates with regional price levels") */}
      <div className="p-4 bg-amber-50/50 border border-amber-200 rounded-lg flex items-start gap-3 text-xs">
        <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <div className="font-bold text-amber-900">Chief Statistician Methodological Rule:</div>
          <p className="text-amber-800 mt-0.5 leading-normal">
            Do not equate regional inflation rates with regional price levels. A region with a lower inflation rate (e.g. London at 3.1% vs West Midlands at 2.9%) can still have a significantly higher absolute price level (London index 108.4 vs West Midlands 97.4) due to structural housing costs and transport differentials.
          </p>
        </div>
      </div>

      {/* Regional Comparison Table */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900">
          Regional Price Level Index vs Annual Inflation
        </h2>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Statistical Region</th>
                <th className="py-2.5 px-3">Region Code</th>
                <th className="py-2.5 px-3 text-right">Spatial Price Level (UK=100)</th>
                <th className="py-2.5 px-3 text-right">Regional Inflation (YoY)</th>
                <th className="py-2.5 px-3 text-right">Monthly Sample Quotes</th>
                <th className="py-2.5 px-3">Sampling Coverage Quality</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
              {regionalData.map(r => (
                <tr key={r.code} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-sans font-bold text-slate-900">{r.name}</td>
                  <td className="py-2.5 px-3 text-blue-900 font-semibold">{r.code}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-900">{r.spatialPriceLevel.toFixed(1)}</td>
                  <td className="py-2.5 px-3 text-right font-semibold text-blue-900">+{r.inflationYoY.toFixed(1)}%</td>
                  <td className="py-2.5 px-3 text-right text-slate-600">{r.sampleQuotes}</td>
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-sans font-semibold uppercase ${
                      r.coverage === 'Comprehensive'
                        ? 'bg-emerald-50 text-emerald-800'
                        : r.coverage === 'Good'
                        ? 'bg-blue-50 text-blue-800'
                        : 'bg-slate-100 text-slate-700'
                    }`}>
                      {r.coverage}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function BasketWeightsManager({
  weights,
  onUpdateWeights,
}: {
  weights: Record<string, number>;
  onUpdateWeights: (newWeights: Record<string, number>) => void;
}) {
  const [localWeights, setLocalWeights] = useState<Record<string, number>>({ ...weights });
  const [saveMsg, setSaveMsg] = useState(false);

  const totalSum: number = Object.values(localWeights).reduce((a: number, b: number) => a + b, 0);

  const handleNormalize = () => {
    const factor = 1000 / totalSum;
    const normalized: Record<string, number> = {};
    let running = 0;
    const keys = Object.keys(localWeights);
    keys.forEach((k, idx) => {
      if (idx === keys.length - 1) {
        normalized[k] = 1000 - running;
      } else {
        const val = Math.round(localWeights[k] * factor);
        normalized[k] = val;
        running += val;
      }
    });
    setLocalWeights(normalized);
  };

  const handleSave = () => {
    onUpdateWeights(localWeights);
    setSaveMsg(true);
    setTimeout(() => setSaveMsg(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">BASKET MANAGEMENT · EXPENDITURE SHARES</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Basket & Weights Manager</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Manage Household Final Consumption Expenditure (HFCE) weights per mille (sum to 1000‰).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleNormalize}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
          >
            Auto-Normalize to 1000‰
          </button>
          <button
            onClick={handleSave}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 rounded-md transition-colors shadow-xs"
          >
            Save & Update Weights Set
          </button>
        </div>
      </div>

      {saveMsg && (
        <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-xs">
          Expenditure weights successfully updated. Index calculations will apply this updated weighting scheme.
        </div>
      )}

      {/* Weights Table */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <h2 className="text-sm font-bold text-slate-900">
            COICOP Division Weights (Per Mille ‰)
          </h2>
          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
            totalSum === 1000 ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'
          }`}>
            Total Sum: {totalSum}‰ ({totalSum === 1000 ? 'Balanced' : 'Requires Normalization'})
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {Object.keys(localWeights).map(code => (
            <div key={code} className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded">
              <span className="font-semibold text-slate-800">Division {code}</span>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="0"
                  max="1000"
                  value={localWeights[code]}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10) || 0;
                    setLocalWeights({ ...localWeights, [code]: val });
                  }}
                  className="w-20 p-1 border border-slate-300 rounded font-mono text-right font-bold"
                />
                <span className="text-slate-500 font-mono text-[11px]">‰</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
