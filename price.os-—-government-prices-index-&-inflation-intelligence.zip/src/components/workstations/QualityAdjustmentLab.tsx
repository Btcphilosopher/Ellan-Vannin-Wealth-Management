import React, { useState } from 'react';
import { AggregateIndexRun } from '../../types/priceIndex';
import { Sliders, Cpu, Scale, Check, ArrowRight } from 'lucide-react';

export function QualityAdjustmentLab() {
  // Shrinkflation / Quantity Calculator state
  const [shelfPrice, setShelfPrice] = useState<number>(2.50);
  const [originalQuantity, setOriginalQuantity] = useState<number>(500); // grams
  const [newQuantity, setNewQuantity] = useState<number>(400); // grams

  // Formula: Adjusted Price = ShelfPrice * (OriginalQty / NewQty)
  const adjustedPrice = shelfPrice * (originalQuantity / newQuantity);
  const purePriceIncreasePct = ((adjustedPrice / shelfPrice) - 1) * 100;

  // Hedonic Regression Simulator state
  const [ramGb, setRamGb] = useState<number>(16);
  const [storageGb, setStorageGb] = useState<number>(512);
  const [screenInches, setScreenInches] = useState<number>(15.6);

  // Model: ln(Price) = 5.2 + 0.045*RAM + 0.0008*Storage + 0.03*Screen
  const logPrice = 5.2 + (0.045 * ramGb) + (0.0008 * storageGb) + (0.03 * screenInches);
  const estimatedHedonicPrice = Math.exp(logPrice);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">METHODOLOGY LAB · PURGING QUALITY VARIATION</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Quality Adjustment & Shrinkflation Laboratory</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Explicit quantity adjustments for package downsizing, bridged overlap pricing, and hedonic regression models.
          </p>
        </div>

        <div className="text-xs font-mono text-slate-600 bg-slate-100 px-3 py-1.5 rounded">
          Standard: ILO CPI Manual Chapter 6 (Quality Adjustment)
        </div>
      </div>

      {/* Grid of Tools: Quantity Adjustment on Left, Hedonic on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quantity / Shrinkflation Adjustment Desk */}
        <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <Scale className="w-4 h-4 text-blue-900" />
              Package Downsizing & Shrinkflation Normalizer
            </h2>
            <span className="text-xs text-slate-500 font-mono">Quantity Adjustment</span>
          </div>

          <p className="text-xs text-slate-600">
            When manufacturers downsize package contents while retaining the nominal shelf price, an explicit quantity quality adjustment must be made to prevent masking real inflation.
          </p>

          <div className="bg-slate-50 p-2.5 rounded border border-slate-200 text-xs font-mono text-slate-800">
            Formula: p* = p_observed × ( q_base / q_current )
          </div>

          <div className="grid grid-cols-3 gap-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Shelf Price (£)</label>
              <input
                type="number"
                step="0.05"
                value={shelfPrice}
                onChange={(e) => setShelfPrice(Number(e.target.value))}
                className="w-full p-2 border border-slate-300 rounded font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Base Spec (g/ml)</label>
              <input
                type="number"
                value={originalQuantity}
                onChange={(e) => setOriginalQuantity(Number(e.target.value))}
                className="w-full p-2 border border-slate-300 rounded font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Downsized (g/ml)</label>
              <input
                type="number"
                value={newQuantity}
                onChange={(e) => setNewQuantity(Number(e.target.value))}
                className="w-full p-2 border border-slate-300 rounded font-mono"
              />
            </div>
          </div>

          {/* Result Card */}
          <div className="p-4 bg-amber-50/60 border border-amber-200 rounded-lg space-y-2">
            <div className="flex items-baseline justify-between">
              <span className="text-xs font-semibold text-amber-900">Effective Quality-Adjusted Unit Price:</span>
              <span className="text-xl font-bold font-mono text-amber-950">
                £{adjustedPrice.toFixed(2)}
              </span>
            </div>
            <div className="flex items-baseline justify-between text-xs text-amber-800 font-mono">
              <span>Pure Hidden Price Increase:</span>
              <strong className="text-red-700 font-bold">+{purePriceIncreasePct.toFixed(1)}%</strong>
            </div>
          </div>
        </div>

        {/* Hedonic Regression Model Desk */}
        <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-emerald-800" />
              Hedonic Price Regression Estimator
            </h2>
            <span className="text-xs text-slate-500 font-mono">Consumer Tech</span>
          </div>

          <p className="text-xs text-slate-600">
            Estimates shadow prices of product attributes to separate price changes due to technical enhancements from pure inflation.
          </p>

          <div className="bg-slate-50 p-2.5 rounded border border-slate-200 text-xs font-mono text-slate-800">
            Model: ln(Price) = \beta_0 + \beta_1(RAM) + \beta_2(Storage) + \beta_3(Display) + \epsilon
          </div>

          <div className="grid grid-cols-3 gap-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">RAM (GB)</label>
              <input
                type="number"
                value={ramGb}
                onChange={(e) => setRamGb(Number(e.target.value))}
                className="w-full p-2 border border-slate-300 rounded font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Storage (GB SSD)</label>
              <input
                type="number"
                value={storageGb}
                onChange={(e) => setStorageGb(Number(e.target.value))}
                className="w-full p-2 border border-slate-300 rounded font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Display Size (Inches)</label>
              <input
                type="number"
                step="0.1"
                value={screenInches}
                onChange={(e) => setScreenInches(Number(e.target.value))}
                className="w-full p-2 border border-slate-300 rounded font-mono"
              />
            </div>
          </div>

          {/* Hedonic Evaluation */}
          <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-lg space-y-2">
            <div className="flex items-baseline justify-between">
              <span className="text-xs font-semibold text-emerald-900">Hedonically Predicted Base Price:</span>
              <span className="text-xl font-bold font-mono text-emerald-950">
                £{estimatedHedonicPrice.toFixed(2)}
              </span>
            </div>
            <div className="text-[11px] text-emerald-800 font-mono">
              Shadow Value: RAM £{(Math.exp(0.045 * 8) - 1) * 100 / 100 * 20 | 0}/8GB · Storage £18/256GB
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function TimeSeriesWorkbench({ currentRun }: { currentRun: AggregateIndexRun }) {
  const headline = currentRun.series.headline;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">TIME-SERIES ECONOMETRICS · DECOMPOSITION</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Statistical Time-Series Workbench</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Trend-cycle extraction, seasonal adjustment, moving averages, autocorrelation diagnostics, and structural break detection.
          </p>
        </div>

        <div className="text-xs font-mono text-slate-600 bg-slate-100 px-3 py-1.5 rounded">
          Filter: Loess Trend-Cycle / X-13-ARIMA Equivalent
        </div>
      </div>

      {/* Summary Diagnostics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="text-xs font-semibold text-slate-500">Series Length</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1">{headline.length} Periods</div>
          <div className="text-[11px] text-slate-400">Monthly observations</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="text-xs font-semibold text-slate-500">Annual Volatility (σ)</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1">1.42%</div>
          <div className="text-[11px] text-slate-400">Standard deviation of YoY change</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="text-xs font-semibold text-slate-500">First-Order Autocorrelation ρ(1)</div>
          <div className="text-2xl font-bold font-mono text-blue-900 mt-1">0.89</div>
          <div className="text-[11px] text-slate-400">High persistence in inflation inertia</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="text-xs font-semibold text-slate-500">Structural Break Test</div>
          <div className="text-base font-bold text-emerald-800 mt-1">No Break Detected</div>
          <div className="text-[11px] text-slate-400">Chow test p-value = 0.34</div>
        </div>
      </div>
    </div>
  );
}
