import React, { useState } from 'react';
import { PriceObservation, ValidationRuleResult } from '../../types/priceIndex';
import { AlertTriangle, CheckCircle, XCircle, Sliders, RefreshCw, Check, ArrowRight } from 'lucide-react';

export function PriceValidationLab({
  observations,
  validationResults,
  onResolveIssue,
  onRevalidate,
}: {
  observations: PriceObservation[];
  validationResults: ValidationRuleResult[];
  onResolveIssue: (issueId: string, action: 'accept' | 'reject' | 'adjust' | 'impute', note?: string) => void;
  onRevalidate: () => void;
}) {
  const [filterSeverity, setFilterSeverity] = useState<'all' | 'error' | 'warning'>('all');
  const [selectedIssue, setSelectedIssue] = useState<ValidationRuleResult | null>(validationResults[0] || null);
  const [reviewerNote, setReviewerNote] = useState<string>('');

  const filteredIssues = validationResults.filter(issue => {
    if (filterSeverity === 'all') return true;
    return issue.severity === filterSeverity;
  });

  const errorCount = validationResults.filter(i => i.severity === 'error' && !i.resolved).length;
  const warningCount = validationResults.filter(i => i.severity === 'warning' && !i.resolved).length;
  const resolvedCount = validationResults.filter(i => i.resolved).length;

  const currentObs = selectedIssue
    ? observations.find(o => o.observationId === selectedIssue.observationId)
    : null;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">QUALITY ASSURANCE · DATA AUDITING</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Price Validation Laboratory</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Automated outlier screening, extreme movement flags, shrinkflation detection, and reviewer sign-off.
          </p>
        </div>

        <button
          onClick={onRevalidate}
          className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Re-scan Entire Dataset
        </button>
      </div>

      {/* Triage Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="text-xs font-semibold text-slate-500">Total Observations Scanned</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {observations.length.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">34 collection vintages</div>
        </div>

        <div className="p-4 bg-white border border-red-200 bg-red-50/20 rounded-lg">
          <div className="text-xs font-semibold text-red-700 flex items-center gap-1.5">
            <XCircle className="w-4 h-4" /> Critical Errors (Blocks Calc)
          </div>
          <div className="text-2xl font-bold font-mono text-red-700 mt-1 tabular-nums">
            {errorCount}
          </div>
          <div className="text-[11px] text-red-600 mt-0.5">Zero prices, duplicates, unit errors</div>
        </div>

        <div className="p-4 bg-white border border-amber-200 bg-amber-50/20 rounded-lg">
          <div className="text-xs font-semibold text-amber-700 flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4" /> Quality Warnings
          </div>
          <div className="text-2xl font-bold font-mono text-amber-700 mt-1 tabular-nums">
            {warningCount}
          </div>
          <div className="text-[11px] text-amber-600 mt-0.5">Extreme spikes & shrinkflation</div>
        </div>

        <div className="p-4 bg-white border border-emerald-200 bg-emerald-50/20 rounded-lg">
          <div className="text-xs font-semibold text-emerald-700 flex items-center gap-1.5">
            <CheckCircle className="w-4 h-4" /> Reviewer Resolved
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-700 mt-1 tabular-nums">
            {resolvedCount}
          </div>
          <div className="text-[11px] text-emerald-600 mt-0.5">Approved or adjusted by analyst</div>
        </div>
      </div>

      {/* Main Split: Issue List on Left, Resolution Panel on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Triage List */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-lg shadow-xs p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Flagged Micro-Price Records ({filteredIssues.length})
            </h2>

            <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded">
              <button
                onClick={() => setFilterSeverity('all')}
                className={`px-2.5 py-1 text-xs font-semibold rounded ${
                  filterSeverity === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilterSeverity('error')}
                className={`px-2.5 py-1 text-xs font-semibold rounded ${
                  filterSeverity === 'error' ? 'bg-white text-red-700 shadow-xs' : 'text-slate-600'
                }`}
              >
                Errors
              </button>
              <button
                onClick={() => setFilterSeverity('warning')}
                className={`px-2.5 py-1 text-xs font-semibold rounded ${
                  filterSeverity === 'warning' ? 'bg-white text-amber-700 shadow-xs' : 'text-slate-600'
                }`}
              >
                Warnings
              </button>
            </div>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredIssues.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No unresolved validation issues in current filter view.
              </div>
            ) : (
              filteredIssues.map((issue) => {
                const isSelected = selectedIssue?.id === issue.id;
                const obs = observations.find(o => o.observationId === issue.observationId);
                return (
                  <div
                    key={issue.id}
                    onClick={() => {
                      setSelectedIssue(issue);
                      setReviewerNote('');
                    }}
                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      isSelected
                        ? 'border-blue-800 bg-blue-50/40'
                        : issue.resolved
                        ? 'border-slate-200 bg-slate-50/50 opacity-60'
                        : issue.severity === 'error'
                        ? 'border-red-200 bg-red-50/10 hover:border-red-300'
                        : 'border-amber-200 bg-amber-50/10 hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {issue.severity === 'error' ? (
                          <XCircle className="w-4 h-4 text-red-600 shrink-0" />
                        ) : (
                          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                        )}
                        <span className="text-xs font-bold text-slate-900 font-mono">
                          {issue.observationId}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {obs?.collectionDate}
                        </span>
                      </div>
                      <span className={`text-[10px] font-mono font-semibold uppercase px-2 py-0.5 rounded ${
                        issue.resolved
                          ? 'bg-emerald-100 text-emerald-800'
                          : issue.severity === 'error'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {issue.resolved ? 'RESOLVED' : issue.ruleName.replace('_RULE', '')}
                      </span>
                    </div>

                    <div className="text-xs text-slate-800 font-medium mt-1.5">
                      {obs?.productName || 'Unknown Product'} · {obs?.retailerName}
                    </div>

                    <p className="text-xs text-slate-600 mt-1 leading-normal">
                      {issue.message}
                    </p>

                    <div className="flex items-center gap-3 mt-2 text-[11px] font-mono text-slate-500">
                      <span>Observed: <strong className="text-slate-800">£{obs?.observedPrice.toFixed(2)}</strong></span>
                      {obs?.basePrice && (
                        <span>Base: £{obs.basePrice.toFixed(2)}</span>
                      )}
                      <span>Region: {obs?.regionName}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Reviewer Action Desk */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-lg shadow-xs p-5 space-y-4">
          <div className="border-b border-slate-100 pb-2">
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Statistical Reviewer Action Panel
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Defensible treatment with recorded justification under National Statistics audit rules
            </p>
          </div>

          {selectedIssue && currentObs ? (
            <div className="space-y-4">
              {/* Observation Detail Card */}
              <div className="bg-slate-50 p-3.5 rounded border border-slate-200 text-xs space-y-2">
                <div className="font-bold text-slate-900 flex items-center justify-between">
                  <span>{currentObs.productName}</span>
                  <span className="font-mono text-slate-500">{currentObs.coicopCode}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-slate-600 text-[11px]">
                  <div>Retailer: <strong className="text-slate-800">{currentObs.retailerName}</strong></div>
                  <div>Outlet: <strong className="text-slate-800">{currentObs.outletId}</strong></div>
                  <div>Region: <strong className="text-slate-800">{currentObs.regionName}</strong></div>
                  <div>Date: <strong className="text-slate-800">{currentObs.collectionDate}</strong></div>
                  <div>Quantity: <strong className="text-slate-800">{currentObs.quantity} {currentObs.unitCode}</strong></div>
                  <div>Source: <strong className="text-slate-800">{currentObs.dataSource}</strong></div>
                </div>

                <div className="pt-2 border-t border-slate-200 flex items-baseline justify-between">
                  <span className="text-slate-600">Observed Price:</span>
                  <span className="text-base font-bold font-mono text-slate-900">
                    £{currentObs.observedPrice.toFixed(2)} {currentObs.currency}
                  </span>
                </div>
              </div>

              {/* Reviewer Note */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Methodological Audit Justification (Required for approval):
                </label>
                <textarea
                  value={reviewerNote}
                  onChange={(e) => setReviewerNote(e.target.value)}
                  placeholder="e.g. Field enumerator confirms typographical error; adjusted to standard £1.80 based on receipt image."
                  rows={3}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-900 focus:border-blue-900"
                />
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                {selectedIssue.ruleName === 'SHRINKFLATION_QUANTITY_RULE' ? (
                  <button
                    onClick={() => onResolveIssue(selectedIssue.id, 'adjust', reviewerNote || 'Adjusted shelf price for pack downsize.')}
                    className="w-full py-2 px-3 text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 rounded-md transition-colors flex items-center justify-center gap-2"
                  >
                    <Sliders className="w-3.5 h-3.5" /> Apply Quantity Quality Adjustment (Normalize Unit Price)
                  </button>
                ) : selectedIssue.ruleName === 'NON_POSITIVE_PRICE_RULE' ? (
                  <button
                    onClick={() => onResolveIssue(selectedIssue.id, 'impute', reviewerNote || 'Imputed via class mean due to missing quote.')}
                    className="w-full py-2 px-3 text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 rounded-md transition-colors flex items-center justify-center gap-2"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Impute Price via COICOP Class Mean (£1.25)
                  </button>
                ) : (
                  <button
                    onClick={() => onResolveIssue(selectedIssue.id, 'adjust', reviewerNote || 'Corrected data entry error.')}
                    className="w-full py-2 px-3 text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 rounded-md transition-colors flex items-center justify-center gap-2"
                  >
                    <Sliders className="w-3.5 h-3.5" /> Correct Decimal Entry to £1.80
                  </button>
                )}

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => onResolveIssue(selectedIssue.id, 'accept', reviewerNote || 'Verified as legitimate commercial price spike.')}
                    className="py-1.5 px-3 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" /> Accept Genuine
                  </button>
                  <button
                    onClick={() => onResolveIssue(selectedIssue.id, 'reject', reviewerNote || 'Inadmissible error, excluded from calculation.')}
                    className="py-1.5 px-3 text-xs font-semibold text-red-800 bg-red-50 hover:bg-red-100 border border-red-200 rounded-md transition-colors flex items-center justify-center gap-1.5"
                  >
                    <XCircle className="w-3.5 h-3.5" /> Reject & Exclude
                  </button>
                </div>
              </div>

              <div className="text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                Action will be permanently recorded in the immutable revision audit trail with timestamp and user ID.
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-xs text-slate-400">
              Select an observation from the triage list to review and resolve.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
