import React from 'react';
import { AggregateIndexRun } from '../../types/priceIndex';
import { Factory, TrendingUp, AlertTriangle } from 'lucide-react';

export function ProducerPrices({ currentRun }: { currentRun: AggregateIndexRun }) {
  const ppiData = [
    { code: 'PPI-IN-01', name: 'Materials & Fuels Purchased (Total Inputs)', type: 'input', indexVal: 122.4, yoy: 3.8, mom: 0.4 },
    { code: 'PPI-IN-02', name: 'Crude Petroleum & Natural Gas Inputs', type: 'input', indexVal: 131.8, yoy: 5.2, mom: -0.8 },
    { code: 'PPI-IN-03', name: 'Imported Food & Agricultural Commodities', type: 'input', indexVal: 119.5, yoy: 3.1, mom: 0.2 },
    { code: 'PPI-OUT-01', name: 'Manufactured Goods Factory Gate (Total Output)', type: 'output', indexVal: 116.8, yoy: 2.4, mom: 0.1 },
    { code: 'PPI-OUT-02', name: 'Domestic Food Product Manufacturing Output', type: 'output', indexVal: 118.2, yoy: 2.9, mom: 0.3 },
    { code: 'PPI-OUT-03', name: 'Chemical & Pharmaceutical Factory Gate Output', type: 'output', indexVal: 114.1, yoy: 1.8, mom: 0.0 },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">BUSINESS STATISTICS · WHOLESALE & INDUSTRY</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Producer Price Indices (PPI) & Factory Gate Prices</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Monitor upstream cost pressures across input materials, industrial fuels, and manufactured factory gate outputs.
          </p>
        </div>

        <div className="text-xs font-mono text-slate-600 bg-slate-100 px-3 py-1.5 rounded">
          Base: 2024 = 100.0 · Net Sector Output
        </div>
      </div>

      {/* PPI Pipeline Spread Card */}
      <div className="p-4 bg-blue-50/50 border border-blue-200 rounded-lg flex items-center justify-between text-xs">
        <div>
          <span className="font-bold text-blue-900">Pipeline Pricing Pressure Spread:</span>
          <p className="text-blue-800 mt-0.5">
            Input PPI (+3.8% YoY) is running 1.4 percentage points higher than Factory Gate Output PPI (+2.4% YoY), indicating ongoing gross margin compression among domestic manufacturers.
          </p>
        </div>
        <div className="text-right shrink-0">
          <div className="text-base font-bold font-mono text-blue-950">+1.4 ppt Spread</div>
        </div>
      </div>

      {/* PPI Table */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900">
          Producer Price Index Series Breakdown
        </h2>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Series Code</th>
                <th className="py-2.5 px-3">Index Description</th>
                <th className="py-2.5 px-3">Classification</th>
                <th className="py-2.5 px-3 text-right">Current Index Level</th>
                <th className="py-2.5 px-3 text-right">1-Month Change (MoM)</th>
                <th className="py-2.5 px-3 text-right">12-Month Change (YoY)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
              {ppiData.map(p => (
                <tr key={p.code} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-semibold text-blue-900">{p.code}</td>
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-900">{p.name}</td>
                  <td className="py-2.5 px-3 font-sans capitalize text-slate-600">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      p.type === 'input' ? 'bg-amber-50 text-amber-800' : 'bg-emerald-50 text-emerald-800'
                    }`}>
                      {p.type === 'input' ? 'Materials & Fuel Input' : 'Factory Gate Output'}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-900">{p.indexVal.toFixed(1)}</td>
                  <td className="py-2.5 px-3 text-right text-slate-600">{p.mom > 0 ? `+${p.mom.toFixed(1)}%` : `${p.mom.toFixed(1)}%`}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-blue-900">+{p.yoy.toFixed(1)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function RevisionAuditCentre({ currentRun }: { currentRun: AggregateIndexRun }) {
  const auditLogs = [
    {
      id: 'AUD-9021',
      timestamp: '2026-11-06 08:14:22 UTC',
      user: 'chief_statistician',
      action: 'CALCULATION_RUN_EXECUTION',
      details: `Executed calculation run ${currentRun.runId} with ${currentRun.elementaryFormula} elementary / ${currentRun.aggregateFormula} aggregate.`,
      hash: currentRun.configHash,
    },
    {
      id: 'AUD-9020',
      timestamp: '2026-11-06 07:45:10 UTC',
      user: 'price_analyst_04',
      action: 'VALIDATION_ISSUE_RESOLVED',
      details: 'Quality adjusted bread observation for package downsizing (800g to 700g).',
      hash: 'sha256-4b9d81f2...',
    },
    {
      id: 'AUD-9019',
      timestamp: '2026-11-05 18:30:00 UTC',
      user: 'methodology_reviewer',
      action: 'ANNUAL_WEIGHTS_RATIFIED',
      details: 'Approved 2026 HFCE expenditure weights update (1000 per mille).',
      hash: 'sha256-e918402c...',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">GOVERNANCE · IMMUTABLE AUDIT TRAIL</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Revision & Audit Centre</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Cryptographic configuration hashes, data vintage comparison, and methodological change tracking.
          </p>
        </div>

        <div className="text-xs font-mono text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded font-semibold">
          Ledger: Tamper-Evident SHA-256
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900">
          Chronological Audit Events
        </h2>

        <div className="space-y-3 font-mono text-xs">
          {auditLogs.map(log => (
            <div key={log.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">{log.id} · {log.action}</span>
                <span className="text-[11px] text-slate-500">{log.timestamp}</span>
              </div>
              <p className="font-sans text-slate-700 text-xs">{log.details}</p>
              <div className="flex items-center justify-between pt-1 border-t border-slate-200 text-[10px] text-slate-500">
                <span>Authorized User: <strong className="text-slate-700">{log.user}</strong></span>
                <span>Config Hash: {log.hash}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
