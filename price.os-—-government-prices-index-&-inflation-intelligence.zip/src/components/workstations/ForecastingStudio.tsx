import React, { useState } from 'react';
import { AggregateIndexRun } from '../../types/priceIndex';
import { StatisticalEngine } from '../../services/statisticalEngine';
import { FanForecastChart } from '../common/Charts';
import { Sparkles, Sliders, AlertCircle, ArrowUpRight } from 'lucide-react';

export function ForecastingStudio({ currentRun }: { currentRun: AggregateIndexRun }) {
  const [horizon, setHorizon] = useState<number>(6);
  const [scenarioShock, setScenarioShock] = useState<'baseline' | 'energy_spike' | 'food_stabilization'>('baseline');

  const history = currentRun.series.headline.map(h => ({
    period: h.period,
    value: h.indexValue,
  }));

  let forecasts = StatisticalEngine.generateForecasts(currentRun.series.headline, horizon);

  // Apply scenario shocks if selected
  if (scenarioShock === 'energy_spike') {
    forecasts = forecasts.map(f => ({
      ...f,
      pointForecast: Number((f.pointForecast * 1.018).toFixed(2)),
      upper80: Number((f.upper80 * 1.022).toFixed(2)),
      upper95: Number((f.upper95 * 1.030).toFixed(2)),
      yoyForecast: Number((f.yoyForecast + 1.2).toFixed(2)),
    }));
  } else if (scenarioShock === 'food_stabilization') {
    forecasts = forecasts.map(f => ({
      ...f,
      pointForecast: Number((f.pointForecast * 0.992).toFixed(2)),
      lower80: Number((f.lower80 * 0.988).toFixed(2)),
      lower95: Number((f.lower95 * 0.982).toFixed(2)),
      yoyForecast: Number((f.yoyForecast - 0.7).toFixed(2)),
    }));
  }

  const latestHistory = currentRun.series.headline[currentRun.series.headline.length - 1];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">ECONOMETRIC PROJECTIONS · UNCERTAINTY MODELING</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Inflation Forecasting Studio</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Holt-Winters state-space and ARIMA projection models with 80% and 95% fan chart prediction intervals.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-1 rounded">
            Model: ARIMA(1,1,0) Drift + Additive Seasonal
          </span>
        </div>
      </div>

      {/* Control Strip */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">
            Projection Horizon: <span className="text-blue-900 font-bold">{horizon} Months</span>
          </label>
          <div className="flex items-center gap-2">
            {[3, 6, 9, 12].map(h => (
              <button
                key={h}
                onClick={() => setHorizon(h)}
                className={`px-3 py-1 text-xs font-semibold rounded-md border transition-colors ${
                  horizon === h
                    ? 'bg-blue-900 text-white border-blue-900'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {h} Months Ahead
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">
            Scenario Stress Testing:
          </label>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setScenarioShock('baseline')}
              className={`px-3 py-1 text-xs font-semibold rounded-md border transition-colors ${
                scenarioShock === 'baseline'
                  ? 'bg-blue-900 text-white border-blue-900'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Central Baseline
            </button>
            <button
              onClick={() => setScenarioShock('energy_spike')}
              className={`px-3 py-1 text-xs font-semibold rounded-md border transition-colors ${
                scenarioShock === 'energy_spike'
                  ? 'bg-amber-700 text-white border-amber-700'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              +20% Geopolitical Energy Shock
            </button>
            <button
              onClick={() => setScenarioShock('food_stabilization')}
              className={`px-3 py-1 text-xs font-semibold rounded-md border transition-colors ${
                scenarioShock === 'food_stabilization'
                  ? 'bg-emerald-700 text-white border-emerald-700'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              Agricultural Crop Harvest Relief
            </button>
          </div>
        </div>
      </div>

      {/* Fan Chart Viewport */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              Headline Price Index Forecast Fan Chart (Reference Base: {currentRun.basePeriod})
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Historical series in black; central projection dotted in blue; shaded regions denote 80% and 95% confidence bands.
            </p>
          </div>
          <span className="text-xs font-mono font-semibold text-slate-700">
            Current: {latestHistory.indexValue.toFixed(2)} ({latestHistory.period})
          </span>
        </div>

        <FanForecastChart history={history} forecasts={forecasts} />
      </div>

      {/* Tabular Forecast Breakdown */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-3">
        <h2 className="text-sm font-bold text-slate-900">
          Point Estimates & Prediction Intervals
        </h2>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Forecast Period</th>
                <th className="py-2.5 px-3 text-right">Central Point Index</th>
                <th className="py-2.5 px-3 text-right">80% Interval</th>
                <th className="py-2.5 px-3 text-right">95% Interval</th>
                <th className="py-2.5 px-3 text-right">Projected YoY Inflation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
              {forecasts.map(f => (
                <tr key={f.period} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-sans font-bold text-slate-800">{f.period}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-blue-900">{f.pointForecast.toFixed(2)}</td>
                  <td className="py-2.5 px-3 text-right text-slate-600">
                    [{f.lower80.toFixed(2)} – {f.upper80.toFixed(2)}]
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-500">
                    [{f.lower95.toFixed(2)} – {f.upper95.toFixed(2)}]
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                    {f.yoyForecast.toFixed(2)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
