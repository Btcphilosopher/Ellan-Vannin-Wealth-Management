import React, { useState } from 'react';
import { AggregateIndexRun } from '../../types/priceIndex';
import { MultiLineChart } from '../common/Charts';
import { TrendingUp, ArrowUpRight, ArrowDownRight, Layers } from 'lucide-react';

export function InflationAnalysis({ currentRun }: { currentRun: AggregateIndexRun }) {
  const headline = currentRun.series.headline;
  const latestIdx = headline.length - 1;
  const latest = headline[latestIdx];
  const prior = headline[latestIdx - 1];

  const [selectedPeriod, setSelectedPeriod] = useState<string>(latest.period);
  const activePeriodContributions = currentRun.contributions[selectedPeriod] || currentRun.contributions[latest.period] || [];

  const headlineSelectedPt = headline.find(h => h.period === selectedPeriod) || latest;

  const chartSeries = [
    { name: 'Headline YoY (%)', color: '#1e3a8a', data: headline.map(h => ({ period: h.period, value: h.yoyInflation })) },
    { name: 'Monthly MoM (%)', color: '#64748b', data: headline.map(h => ({ period: h.period, value: h.momInflation })) },
    { name: 'Core CPI YoY (%)', color: '#0d9488', data: currentRun.series.core.map(h => ({ period: h.period, value: h.yoyInflation })) },
    { name: '3-Month Annualized (%)', color: '#d97706', data: headline.map(h => ({ period: h.period, value: h.threeMonthChange ? h.threeMonthChange * 4 : 0 })) },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">MACROECONOMIC ANALYSIS · PRICE DYNAMICS</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Inflation Dynamics & Contributions Decomposition</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Examine multi-horizon inflation rates (MoM, YoY, 3M, 6M, 12M moving average) and additive percentage point contributions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-600 font-medium">Decomposition Period:</label>
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="text-xs py-1 px-2.5 border border-slate-300 rounded font-mono font-semibold text-slate-800"
          >
            {headline.slice(-18).reverse().map(h => (
              <option key={h.period} value={h.period}>
                {h.period} (YoY: {h.yoyInflation.toFixed(2)}%)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Metric Cards Across Horizons */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">12-Month Rate (YoY)</div>
          <div className="text-2xl font-bold font-mono text-blue-900 mt-1 tabular-nums">
            {headlineSelectedPt.yoyInflation.toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Annual change</div>
        </div>

        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">1-Month Rate (MoM)</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {headlineSelectedPt.momInflation > 0 ? `+${headlineSelectedPt.momInflation.toFixed(2)}%` : `${headlineSelectedPt.momInflation.toFixed(2)}%`}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Monthly momentum</div>
        </div>

        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">3-Month Change</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {headlineSelectedPt.threeMonthChange ? `${headlineSelectedPt.threeMonthChange.toFixed(2)}%` : 'N/A'}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Quarterly velocity</div>
        </div>

        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Core Inflation</div>
          <div className="text-2xl font-bold font-mono text-teal-800 mt-1 tabular-nums">
            {currentRun.series.core[latestIdx].yoyInflation.toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Ex food & energy</div>
        </div>

        <div className="p-3.5 bg-white border border-slate-200 rounded-lg">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">12M Moving Average</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {headlineSelectedPt.annualAverage ? headlineSelectedPt.annualAverage.toFixed(2) : '101.40'}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Smoothed index level</div>
        </div>
      </div>

      {/* Multi-Horizon Chart */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900">
          Historical Inflation Rates by Measurement Horizon
        </h2>
        <MultiLineChart series={chartSeries} height={280} yUnit="%" zeroLine={true} />
      </div>

      {/* Exact Category Contributions Table */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              COICOP Category Contributions to Headline Annual Inflation ({selectedPeriod})
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Additive percentage point decomposition summing exactly to headline YoY rate ({headlineSelectedPt.yoyInflation.toFixed(2)}%)
            </p>
          </div>
          <span className="text-xs font-mono font-semibold text-slate-700 bg-slate-100 px-2.5 py-1 rounded">
            Formula: ONS / Eurostat Standard
          </span>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Division</th>
                <th className="py-2.5 px-3">COICOP Category Name</th>
                <th className="py-2.5 px-3 text-right">Basket Weight (‰)</th>
                <th className="py-2.5 px-3 text-right">Category Index Level</th>
                <th className="py-2.5 px-3 text-right">Category YoY (%)</th>
                <th className="py-2.5 px-3 text-right">Contribution (ppt)</th>
                <th className="py-2.5 px-3 text-right">% of Total Inflation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
              {activePeriodContributions.map(c => {
                const isPositive = c.percentagePointContribution >= 0;
                const shareOfTotal = headlineSelectedPt.yoyInflation !== 0
                  ? (c.percentagePointContribution / headlineSelectedPt.yoyInflation) * 100
                  : 0;

                return (
                  <tr key={c.divisionCode} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-bold text-blue-900">Div {c.divisionCode}</td>
                    <td className="py-2 px-3 font-sans font-medium text-slate-900">{c.divisionName}</td>
                    <td className="py-2 px-3 text-right text-slate-600">{c.weight}‰</td>
                    <td className="py-2 px-3 text-right">{c.categoryIndex.toFixed(2)}</td>
                    <td className="py-2 px-3 text-right font-semibold text-slate-800">
                      {c.categoryYoy > 0 ? `+${c.categoryYoy.toFixed(2)}%` : `${c.categoryYoy.toFixed(2)}%`}
                    </td>
                    <td className={`py-2 px-3 text-right font-bold ${isPositive ? 'text-blue-900' : 'text-amber-700'}`}>
                      {isPositive ? `+${c.percentagePointContribution.toFixed(2)}` : c.percentagePointContribution.toFixed(2)} ppt
                    </td>
                    <td className="py-2 px-3 text-right text-slate-500">
                      {shareOfTotal.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
