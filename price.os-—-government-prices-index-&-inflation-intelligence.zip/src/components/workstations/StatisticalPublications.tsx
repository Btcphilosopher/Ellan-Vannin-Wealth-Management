import React, { useState } from 'react';
import { AggregateIndexRun } from '../../types/priceIndex';
import { CheckCircle2, Clock, Lock, ShieldCheck, Printer, Download, Eye, FileText } from 'lucide-react';

const RELEASE_STAGES = [
  { id: 'cutoff', label: '1. Cutoff', desc: 'Price survey freeze' },
  { id: 'validation', label: '2. Validation', desc: 'Outlier & error clearance' },
  { id: 'processing', label: '3. Processing', desc: 'R elementary index calculation' },
  { id: 'review', label: '4. Method Review', desc: 'Axiomatic & formula check' },
  { id: 'qa', label: '5. Quality Assurance', desc: 'Cross-division consistency' },
  { id: 'approval', label: '6. Chief Approval', desc: 'Chief Statistician sign-off' },
  { id: 'prep', label: '7. Release Prep', desc: 'Embargo lock & bulletin draft' },
  { id: 'published', label: '8. Published', desc: 'Public National Statistics' },
  { id: 'revision', label: '9. Revision Log', desc: 'Historical vintage tracking' },
];

export function StatisticalPublications({ currentRun }: { currentRun: AggregateIndexRun }) {
  const [currentStageIdx, setCurrentStageIdx] = useState<number>(7); // Stage 8: Published
  const [isEmbargoed, setIsEmbargoed] = useState<boolean>(false);
  const [chiefSigned, setChiefSigned] = useState<boolean>(true);

  const headline = currentRun.series.headline[currentRun.series.headline.length - 1];
  const priorMonth = currentRun.series.headline[currentRun.series.headline.length - 2];
  const core = currentRun.series.core[currentRun.series.core.length - 1];
  const food = currentRun.series.food[currentRun.series.food.length - 1];
  const energy = currentRun.series.energy[currentRun.series.energy.length - 1];

  const handlePrintBulletin = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">OFFICIAL DISCLOSURE · GOVERNANCE PIPELINE</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Statistical Publications & Release Governance</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Strict 9-stage government statistical publication protocol with embargo lock and Chief Statistician approval.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrintBulletin}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5" /> Print / PDF Bulletin
          </button>
        </div>
      </div>

      {/* 9-Stage Release Pipeline Stepper */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
            Official 9-Stage National Statistics Release Protocol
          </h2>
          <span className="text-xs font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-semibold">
            Status: STAGE {currentStageIdx + 1} OF 9
          </span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-9 gap-2">
          {RELEASE_STAGES.map((stg, idx) => {
            const isCompleted = idx <= currentStageIdx;
            const isCurrent = idx === currentStageIdx;
            return (
              <div
                key={stg.id}
                onClick={() => setCurrentStageIdx(idx)}
                className={`p-2.5 rounded-lg border text-left cursor-pointer transition-all ${
                  isCurrent
                    ? 'border-blue-900 bg-blue-50/70 ring-1 ring-blue-900'
                    : isCompleted
                    ? 'border-emerald-200 bg-emerald-50/30'
                    : 'border-slate-200 bg-slate-50 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between text-[11px] font-bold">
                  <span className={isCurrent ? 'text-blue-900' : isCompleted ? 'text-emerald-800' : 'text-slate-500'}>
                    {stg.label}
                  </span>
                  {isCompleted && <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />}
                </div>
                <div className="text-[10px] text-slate-500 mt-1 truncate" title={stg.desc}>
                  {stg.desc}
                </div>
              </div>
            );
          })}
        </div>

        {/* Embargo & Sign-Off Controls */}
        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-700">
              <input
                type="checkbox"
                checked={isEmbargoed}
                onChange={(e) => setIsEmbargoed(e.target.checked)}
                className="rounded border-slate-300 text-blue-900 focus:ring-blue-900"
              />
              <Lock className="w-3.5 h-3.5 text-amber-600" />
              <span>Strict 07:00 GMT Pre-Release Embargo</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-700">
              <input
                type="checkbox"
                checked={chiefSigned}
                onChange={(e) => setChiefSigned(e.target.checked)}
                className="rounded border-slate-300 text-blue-900 focus:ring-blue-900"
              />
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Chief Statistician Signature Enforced</span>
            </label>
          </div>

          <div className="text-slate-500 font-mono text-[11px]">
            Data Vintage: <strong className="text-slate-800">{headline.period}-FINAL</strong> · Published: 2026-11-06
          </div>
        </div>
      </div>

      {/* Official Statistical Bulletin Document Preview */}
      <div className="p-8 bg-white border border-slate-300 rounded-lg shadow-sm space-y-6 max-w-4xl mx-auto font-sans print:border-none print:shadow-none print:p-0">
        {/* Bulletin Letterhead */}
        <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
          <div>
            <div className="text-xs uppercase font-extrabold tracking-widest text-slate-600">
              NATIONAL STATISTICAL SERVICE · ECONOMIC STATISTICS RELEASE
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 mt-1">
              Consumer Price Inflation, UK & Harmonised Index: {headline.period}
            </h2>
            <p className="text-xs text-slate-600 mt-1">
              Coverage: National · Frequency: Monthly · Next Release: December 2026 (07:00 GMT)
            </p>
          </div>
          <div className="text-right text-xs font-mono">
            <span className="font-bold text-emerald-800 bg-emerald-50 px-2 py-1 rounded inline-block">
              OFFICIAL STATISTICS
            </span>
            <div className="text-slate-500 mt-1 text-[11px]">Ref: {currentRun.runId}</div>
          </div>
        </div>

        {/* Executive Summary Paragraphs */}
        <div className="space-y-3 text-xs leading-relaxed text-slate-800">
          <p className="font-semibold text-sm text-slate-900">
            Headline Findings:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-slate-700">
            <li>
              The Consumer Prices Index (CPI) rose by <strong>{headline.yoyInflation.toFixed(1)}%</strong> in the 12 months to {headline.period}, down from {priorMonth.yoyInflation.toFixed(1)}% in the previous month.
            </li>
            <li>
              On a monthly basis, CPI rose by <strong>{headline.momInflation > 0 ? `+${headline.momInflation.toFixed(1)}%` : `${headline.momInflation.toFixed(1)}%`}</strong> in {headline.period}.
            </li>
            <li>
              Core CPI (excluding energy, food, alcohol and tobacco) rose by <strong>{core.yoyInflation.toFixed(1)}%</strong> in the 12 months to {headline.period}, reflecting persistent price dynamics in consumer services.
            </li>
            <li>
              Food and non-alcoholic beverages inflation was recorded at <strong>{food.yoyInflation.toFixed(1)}%</strong>, with deceleration observed in fresh dairy and produce.
            </li>
            <li>
              The alternative Retail Prices Index (RPI) benchmark was recorded at <strong>{currentRun.series.rpiStyle[currentRun.series.rpiStyle.length - 1].yoyInflation.toFixed(1)}%</strong>, reflecting its arithmetic Carli formula formulation.
            </li>
          </ul>
        </div>

        {/* Summary Table */}
        <div>
          <div className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-2">
            Table 1: Key Price Index Aggregates ({headline.period})
          </div>
          <table className="w-full text-xs text-left border border-slate-200">
            <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2 px-3">Index Series</th>
                <th className="py-2 px-3 text-right">Index Level (2024=100)</th>
                <th className="py-2 px-3 text-right">1-Month % Change</th>
                <th className="py-2 px-3 text-right">12-Month % Change</th>
                <th className="py-2 px-3">Methodology Basis</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
              <tr>
                <td className="py-2 px-3 font-sans font-bold text-slate-900">CPI (Headline)</td>
                <td className="py-2 px-3 text-right">{headline.indexValue.toFixed(2)}</td>
                <td className="py-2 px-3 text-right">{headline.momInflation.toFixed(2)}%</td>
                <td className="py-2 px-3 text-right font-bold text-slate-900">{headline.yoyInflation.toFixed(2)}%</td>
                <td className="py-2 px-3 font-sans text-slate-600">Jevons Elementary / Laspeyres Aggregation</td>
              </tr>
              <tr>
                <td className="py-2 px-3 font-sans font-medium text-slate-800">Core CPI</td>
                <td className="py-2 px-3 text-right">{core.indexValue.toFixed(2)}</td>
                <td className="py-2 px-3 text-right">{core.momInflation.toFixed(2)}%</td>
                <td className="py-2 px-3 text-right font-semibold text-slate-800">{core.yoyInflation.toFixed(2)}%</td>
                <td className="py-2 px-3 font-sans text-slate-600">Excludes Food (Div 01) & Energy (Div 04)</td>
              </tr>
              <tr>
                <td className="py-2 px-3 font-sans font-medium text-slate-800">CPIH</td>
                <td className="py-2 px-3 text-right">{currentRun.series.cpihStyle[currentRun.series.cpihStyle.length - 1].indexValue.toFixed(2)}</td>
                <td className="py-2 px-3 text-right">{currentRun.series.cpihStyle[currentRun.series.cpihStyle.length - 1].momInflation.toFixed(2)}%</td>
                <td className="py-2 px-3 text-right">{currentRun.series.cpihStyle[currentRun.series.cpihStyle.length - 1].yoyInflation.toFixed(2)}%</td>
                <td className="py-2 px-3 font-sans text-slate-600">Includes Owner Occupiers’ Housing Costs</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Quality and Methodology Sign-off Box */}
        <div className="bg-slate-50 border border-slate-200 p-4 rounded text-xs space-y-2">
          <div className="font-bold text-slate-900">Methodological Compliance Certification</div>
          <p className="text-slate-600 leading-normal">
            This statistical release was compiled in accordance with the Code of Practice for Statistics. Elementary aggregates are calculated using the unweighted geometric mean (Jevons formula), with higher-level expenditure weights derived from the Household Final Consumption Expenditure (HFCE) accounts.
          </p>
          <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-slate-500 font-mono text-[11px]">
            <span>Signatory: Dr. E. Vance, Chief Government Statistician</span>
            <span>Integrity Checksum: {currentRun.configHash.slice(0, 20)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
