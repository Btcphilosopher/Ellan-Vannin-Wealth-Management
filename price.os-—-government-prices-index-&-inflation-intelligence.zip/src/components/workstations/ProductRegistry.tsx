import React, { useState } from 'react';
import { COICOP_DIVISIONS, DEFAULT_BASKET_ITEMS } from '../../services/coicopData';
import { FolderTree, Tag, Info, Layers, Check } from 'lucide-react';

export function ProductRegistry() {
  const [selectedDivisionCode, setSelectedDivisionCode] = useState<string>('01');
  const activeDivision = COICOP_DIVISIONS.find(d => d.code === selectedDivisionCode) || COICOP_DIVISIONS[0];
  const itemsInDivision = DEFAULT_BASKET_ITEMS.filter(item => item.divisionCode === selectedDivisionCode);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">STATISTICAL CLASSIFICATION · COICOP HIERARCHY</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Product & Service Classification Registry</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Classification of Individual Consumption According to Purpose (COICOP) with versioned mappings and representative basket items.
          </p>
        </div>

        <div className="text-xs font-mono text-slate-600 bg-slate-100 px-3 py-1.5 rounded">
          Standard: UN COICOP 2018 / Eurostat HICP Aligned
        </div>
      </div>

      {/* Main Split: Division Selector on Left, Specification Details on Right */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Column: 12 Divisions */}
        <div className="md:col-span-5 bg-white border border-slate-200 rounded-lg shadow-xs p-4 space-y-2">
          <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wide pb-2 border-b border-slate-100">
            COICOP Major Divisions (12)
          </h2>

          <div className="space-y-1.5 max-h-[560px] overflow-y-auto pr-1">
            {COICOP_DIVISIONS.map(div => {
              const isSelected = selectedDivisionCode === div.code;
              return (
                <button
                  key={div.code}
                  onClick={() => setSelectedDivisionCode(div.code)}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    isSelected
                      ? 'border-blue-900 bg-blue-50/50 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-blue-900">
                      Division {div.code}
                    </span>
                    <span className="text-xs font-mono font-semibold text-slate-700">
                      {div.defaultWeight}‰ ({((div.defaultWeight / 1000) * 100).toFixed(1)}%)
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-slate-900 mt-1">
                    {div.name}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
                    <span>{div.isGoods ? 'Goods' : 'Services'}</span>
                    <span aria-hidden="true">·</span>
                    <span>{div.isCoreItem ? 'Core Basket' : 'Excluded from Core'}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Active Division Specifications & Items */}
        <div className="md:col-span-7 bg-white border border-slate-200 rounded-lg shadow-xs p-5 space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-bold text-blue-900 uppercase">
                COICOP Division {activeDivision.code}
              </span>
              <span className={`text-[10px] uppercase font-semibold px-2 py-0.5 rounded ${
                activeDivision.isCoreItem ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'
              }`}>
                {activeDivision.isCoreItem ? 'Core Component' : 'Non-Core Component'}
              </span>
            </div>
            <h2 className="text-base font-bold text-slate-900 mt-1">
              {activeDivision.name}
            </h2>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              {activeDivision.description}
            </p>
          </div>

          {/* Division Parameters Card */}
          <div className="grid grid-cols-3 gap-3 bg-slate-50 p-3.5 rounded border border-slate-200 text-xs">
            <div>
              <span className="text-slate-500 text-[11px] block">National Weight:</span>
              <strong className="text-slate-900 font-mono text-sm">{activeDivision.defaultWeight} per mille</strong>
            </div>
            <div>
              <span className="text-slate-500 text-[11px] block">Economic Classification:</span>
              <strong className="text-slate-900 text-sm">{activeDivision.isGoods ? 'Physical Goods' : 'Consumer Services'}</strong>
            </div>
            <div>
              <span className="text-slate-500 text-[11px] block">Elementary Formula:</span>
              <strong className="text-blue-900 font-mono text-sm">
                {activeDivision.code === '04' ? 'Dutot / Jevons' : 'Jevons (Geometric)'}
              </strong>
            </div>
          </div>

          {/* Representative Basket Items in Division */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Representative Basket Items Sampled ({itemsInDivision.length})
            </h3>

            {itemsInDivision.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400 bg-slate-50 rounded">
                Additional items in this division sampled via secondary retailer web scrapers and field catalogs.
              </div>
            ) : (
              <div className="space-y-2">
                {itemsInDivision.map(item => (
                  <div key={item.id} className="p-3 bg-slate-50/70 border border-slate-200 rounded-lg text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">{item.name}</span>
                      <span className="font-mono text-blue-900 font-semibold">{item.coicopCode}</span>
                    </div>
                    <p className="text-slate-600 text-[11px]">{item.specification}</p>
                    <div className="flex items-center gap-4 text-[11px] font-mono text-slate-500 pt-1">
                      <span>Unit: <strong className="text-slate-700">{item.unit}</strong></span>
                      <span>Weight: <strong className="text-slate-700">{item.weight}‰</strong></span>
                      <span>Cadence: <strong className="text-slate-700 capitalize">{item.samplingFrequency}</strong></span>
                      <span>Formula: <strong className="text-slate-700 uppercase">{item.elementaryFormula}</strong></span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
