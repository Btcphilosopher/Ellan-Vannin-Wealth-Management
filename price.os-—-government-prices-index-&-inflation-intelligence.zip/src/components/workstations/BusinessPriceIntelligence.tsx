import React, { useState } from 'react';
import { BusinessCostBasket } from '../../types/priceIndex';
import { Calculator, TrendingUp, AlertTriangle, Briefcase, Plus, RefreshCw, FileSpreadsheet } from 'lucide-react';

const INITIAL_BUSINESS_BASKETS: BusinessCostBasket[] = [
  {
    id: 'BASKET-MFG-01',
    name: 'Advanced Manufacturing & Assembly',
    industry: 'Automotive & Precision Engineering',
    notes: 'Heavy exposure to industrial power tariffs, imported stainless steel, and European freight.',
    components: [
      { name: 'Industrial Electricity (MWh)', weight: 30, category: 'energy', baseIndex: 100, currentIndex: 124.5, trend: 4.2 },
      { name: 'Commercial Freight & Haulage', weight: 25, category: 'freight', baseIndex: 100, currentIndex: 116.8, trend: 1.8 },
      { name: 'Raw Stainless Steel & Aluminium', weight: 25, category: 'raw_materials', baseIndex: 100, currentIndex: 108.4, trend: -0.6 },
      { name: 'Technical Skilled Labor', weight: 20, category: 'labor', baseIndex: 100, currentIndex: 114.2, trend: 5.1 },
    ],
  },
  {
    id: 'BASKET-FOOD-02',
    name: 'Food & Beverage Processing',
    industry: 'Consumer Packaged Goods',
    notes: 'High sensitivity to wholesale dairy, agricultural commodities, and corrugated packaging.',
    components: [
      { name: 'Agricultural Dairy & Wheat Inputs', weight: 45, category: 'raw_materials', baseIndex: 100, currentIndex: 118.2, trend: 3.4 },
      { name: 'Industrial Natural Gas Process Heat', weight: 20, category: 'energy', baseIndex: 100, currentIndex: 129.0, trend: 6.5 },
      { name: 'Cardboard & Polymer Packaging', weight: 15, category: 'packaging', baseIndex: 100, currentIndex: 106.5, trend: 0.8 },
      { name: 'Cold-Chain Refrigerated Logistics', weight: 20, category: 'freight', baseIndex: 100, currentIndex: 115.0, trend: 2.2 },
    ],
  },
];

export function BusinessPriceIntelligence() {
  const [baskets, setBaskets] = useState<BusinessCostBasket[]>(INITIAL_BUSINESS_BASKETS);
  const [activeBasketId, setActiveBasketId] = useState<string>(baskets[0].id);

  // Contract escalation calculator state
  const [contractValue, setContractValue] = useState<number>(250000);
  const [fixedPortion, setFixedPortion] = useState<number>(20); // 20%
  const [laborWeight, setLaborWeight] = useState<number>(50); // 50%
  const [materialWeight, setMaterialWeight] = useState<number>(30); // 30%
  const [laborIndexChange, setLaborIndexChange] = useState<number>(5.2); // %
  const [materialIndexChange, setMaterialIndexChange] = useState<number>(3.8); // %

  const activeBasket = baskets.find(b => b.id === activeBasketId) || baskets[0];

  // Calculate Weighted Business Cost Index
  const totalWeight = activeBasket.components.reduce((s, c) => s + c.weight, 0);
  const compositeIndex = activeBasket.components.reduce(
    (sum, c) => sum + (c.currentIndex * (c.weight / totalWeight)),
    0
  );
  const weightedCostInflation = activeBasket.components.reduce(
    (sum, c) => sum + (c.trend * (c.weight / totalWeight)),
    0
  );

  // Contract escalation formula:
  // Escalated = Base * [ (Fixed) + (LaborW * (1 + laborChange)) + (MaterialW * (1 + matChange)) ]
  const escalationFactor = (fixedPortion / 100) +
    ((laborWeight / 100) * (1 + laborIndexChange / 100)) +
    ((materialWeight / 100) * (1 + materialIndexChange / 100));
  const escalatedContractValue = contractValue * escalationFactor;
  const escalationImpact = escalatedContractValue - contractValue;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">BUSINESS PRICE INTELLIGENCE · PROCUREMENT ANALYTICS</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Enterprise Input Cost & Contract Escalation</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Monitor supplier variance, industry input inflation, budget exposure, and legally defensible contract escalation clauses.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] bg-slate-100 text-slate-700 px-2.5 py-1 rounded font-medium">
            Confidential B2B Data Vault
          </span>
        </div>
      </div>

      {/* Basket Selector Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        {baskets.map(b => (
          <button
            key={b.id}
            onClick={() => setActiveBasketId(b.id)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeBasketId === b.id
                ? 'bg-blue-900 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {b.name}
          </button>
        ))}
      </div>

      {/* Summary KPI Strip for Active Basket */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Composite Input Cost Index
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {compositeIndex.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">Base 2024 = 100.00</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Annual Input Cost Inflation
          </div>
          <div className="text-2xl font-bold font-mono text-amber-700 mt-1 tabular-nums">
            +{weightedCostInflation.toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Weighted supplier basket</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Margin Compression Indicator
          </div>
          <div className="text-2xl font-bold font-mono text-red-700 mt-1 tabular-nums">
            -1.85 ppt
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Input inflation exceeds sales CPI</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Primary Cost Driver
          </div>
          <div className="text-base font-bold text-slate-900 mt-1 truncate">
            {activeBasket.components.reduce((max, c) => (c.trend > max.trend ? c : max)).name}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Highest annualized inflation rate</div>
        </div>
      </div>

      {/* Component Breakdown Table */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              Input Component Weights & Price Ratios ({activeBasket.industry})
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">{activeBasket.notes}</p>
          </div>
          <span className="text-xs text-slate-500 font-mono">Total Weight: {totalWeight}%</span>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Input Component</th>
                <th className="py-2.5 px-3">Cost Category</th>
                <th className="py-2.5 px-3 text-right">Exposure Weight</th>
                <th className="py-2.5 px-3 text-right">Current Cost Index</th>
                <th className="py-2.5 px-3 text-right">Annual Trend (YoY)</th>
                <th className="py-2.5 px-3 text-right">Weighted Budget Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
              {activeBasket.components.map(c => {
                const weightedImpact = (c.trend * (c.weight / totalWeight));
                return (
                  <tr key={c.name} className="hover:bg-slate-50/50">
                    <td className="py-2.5 px-3 font-sans font-medium text-slate-900">{c.name}</td>
                    <td className="py-2.5 px-3 font-sans capitalize text-slate-600">{c.category.replace('_', ' ')}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-800">{c.weight}%</td>
                    <td className="py-2.5 px-3 text-right">{c.currentIndex.toFixed(1)}</td>
                    <td className={`py-2.5 px-3 text-right font-semibold ${c.trend > 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                      {c.trend > 0 ? `+${c.trend.toFixed(1)}%` : `${c.trend.toFixed(1)}%`}
                    </td>
                    <td className="py-2.5 px-3 text-right font-semibold text-slate-900">
                      +{weightedImpact.toFixed(2)} ppt
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Contract Escalation Formula Studio */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <div>
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Calculator className="w-4 h-4 text-blue-900" />
            Statutory Contract Price Escalation Calculator
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Evaluate price revision formulas used in public procurement and long-term commercial contracts.
          </p>
        </div>

        <div className="bg-slate-50 p-3 rounded border border-slate-200 text-xs font-mono text-slate-700">
          Standard Contract Clause: P_t = P_0 × [ a + b × (L_t / L_0) + c × (M_t / M_0) ]
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Base Contract Value (£)</label>
            <input
              type="number"
              value={contractValue}
              onChange={(e) => setContractValue(Number(e.target.value))}
              className="w-full p-2 border border-slate-300 rounded font-mono tabular-nums"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Fixed Non-Adjustable (%)</label>
            <input
              type="number"
              value={fixedPortion}
              onChange={(e) => setFixedPortion(Number(e.target.value))}
              className="w-full p-2 border border-slate-300 rounded font-mono tabular-nums"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Labor Share (L_0) & Wage Index %</label>
            <div className="flex gap-2">
              <input
                type="number"
                value={laborWeight}
                onChange={(e) => setLaborWeight(Number(e.target.value))}
                placeholder="Weight %"
                className="w-1/2 p-2 border border-slate-300 rounded font-mono tabular-nums"
              />
              <input
                type="number"
                step="0.1"
                value={laborIndexChange}
                onChange={(e) => setLaborIndexChange(Number(e.target.value))}
                placeholder="Change %"
                className="w-1/2 p-2 border border-slate-300 rounded font-mono tabular-nums"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Materials Share (M_0) & PPI %</label>
            <div className="flex gap-2">
              <input
                type="number"
                value={materialWeight}
                onChange={(e) => setMaterialWeight(Number(e.target.value))}
                placeholder="Weight %"
                className="w-1/2 p-2 border border-slate-300 rounded font-mono tabular-nums"
              />
              <input
                type="number"
                step="0.1"
                value={materialIndexChange}
                onChange={(e) => setMaterialIndexChange(Number(e.target.value))}
                placeholder="Change %"
                className="w-1/2 p-2 border border-slate-300 rounded font-mono tabular-nums"
              />
            </div>
          </div>
        </div>

        {/* Output Strip */}
        <div className="p-4 bg-blue-50/50 border border-blue-200 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs text-blue-900 font-semibold">Calculated Escalation Multiplier</div>
            <div className="text-xl font-bold font-mono text-blue-950 tabular-nums">
              {escalationFactor.toFixed(4)}x (+{((escalationFactor - 1) * 100).toFixed(2)}%)
            </div>
          </div>

          <div className="sm:text-right">
            <div className="text-xs text-blue-900 font-semibold">Escalated Contract Total & Settlement Adjustment</div>
            <div className="text-xl font-bold font-mono text-blue-950 tabular-nums">
              £{Math.round(escalatedContractValue).toLocaleString()} (+£{Math.round(escalationImpact).toLocaleString()})
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
