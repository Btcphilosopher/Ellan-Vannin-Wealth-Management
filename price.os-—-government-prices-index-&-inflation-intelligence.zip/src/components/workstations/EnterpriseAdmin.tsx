import React, { useState } from 'react';
import { AggregateIndexRun } from '../../types/priceIndex';
import { Shield, Users, Server, Database, CheckCircle, RefreshCw } from 'lucide-react';

export function EnterpriseAdmin({
  currentRun,
  observationsCount,
}: {
  currentRun: AggregateIndexRun;
  observationsCount: number;
}) {
  const [activeRole, setActiveRole] = useState<string>('chief_statistician');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const roles = [
    { id: 'chief_statistician', name: 'Chief Statistician', access: 'Full Administrative & Release Sign-Off Authority' },
    { id: 'methodology_reviewer', name: 'Methodology Reviewer', access: 'Formula & Weight Set Configuration, Axiomatic Clearance' },
    { id: 'price_analyst', name: 'Price Analyst / QA', access: 'Validation Lab Clearance, Outlier Treatment & Imputation' },
    { id: 'price_collector', name: 'Field Enumerator / Collector', access: 'Price Quote Entry and Scanner Batch Upload' },
    { id: 'auditor', name: 'External Statistical Auditor', access: 'Read-Only Audit Trail & Reproducibility Verification' },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">SYSTEM CONFIGURATION · ROLE-BASED ACCESS</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Enterprise Administration & Methodology Settings</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Manage statistical roles, default methodology parameters, database persistence, and system diagnostics.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded font-semibold flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> System Healthy
          </span>
        </div>
      </div>

      {/* Diagnostics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
            <span>R Statistical Worker</span>
            <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-mono">ONLINE</span>
          </div>
          <div className="text-base font-bold text-slate-900 mt-2 font-mono">priceindexr v1.0.0</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Isolated process worker</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
            <span>Micro-Price Database</span>
            <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-mono">PERSISTED</span>
          </div>
          <div className="text-base font-bold text-slate-900 mt-2 font-mono">{observationsCount.toLocaleString()} Quotes</div>
          <div className="text-[11px] text-slate-400 mt-0.5">34 collection vintages</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
            <span>Axiomatic Engine</span>
            <span className="text-[10px] text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-mono">VERIFIED</span>
          </div>
          <div className="text-base font-bold text-slate-900 mt-2 font-mono">Jevons Standard</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Time-reversal compliant</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-lg">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
            <span>Code of Practice</span>
            <span className="text-[10px] text-blue-800 bg-blue-50 px-2 py-0.5 rounded font-mono">RATIFIED</span>
          </div>
          <div className="text-base font-bold text-slate-900 mt-2 font-mono">UN / HICP Aligned</div>
          <div className="text-[11px] text-slate-400 mt-0.5">National accounts compliance</div>
        </div>
      </div>

      {/* Role-Based Permissions Desk */}
      <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Users className="w-4 h-4 text-blue-900" />
          Role-Based Access Governance (RBAC)
        </h2>

        <div className="space-y-2">
          {roles.map(r => (
            <div
              key={r.id}
              onClick={() => setActiveRole(r.id)}
              className={`p-3 rounded-lg border cursor-pointer flex items-center justify-between transition-colors ${
                activeRole === r.id
                  ? 'border-blue-900 bg-blue-50/50'
                  : 'border-slate-200 hover:bg-slate-50'
              }`}
            >
              <div>
                <div className="text-xs font-bold text-slate-900">{r.name}</div>
                <div className="text-[11px] text-slate-500 mt-0.5">{r.access}</div>
              </div>
              <span className={`text-[10px] font-mono font-semibold uppercase px-2.5 py-1 rounded ${
                activeRole === r.id ? 'bg-blue-900 text-white' : 'bg-slate-100 text-slate-600'
              }`}>
                {activeRole === r.id ? 'ACTIVE ROLE' : 'SWITCH'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
