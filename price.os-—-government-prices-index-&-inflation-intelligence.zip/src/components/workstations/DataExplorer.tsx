import React, { useState } from 'react';
import { PriceObservation } from '../../types/priceIndex';
import { COICOP_DIVISIONS, REGIONS } from '../../services/coicopData';
import { Search, Download, Filter, ArrowUpDown } from 'lucide-react';

export function DataExplorer({ observations }: { observations: PriceObservation[] }) {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedDivision, setSelectedDivision] = useState<string>('all');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [page, setPage] = useState<number>(1);
  const pageSize = 25;

  const filtered = observations.filter(obs => {
    if (selectedDivision !== 'all' && obs.divisionCode !== selectedDivision) return false;
    if (selectedRegion !== 'all' && obs.regionCode !== selectedRegion) return false;
    if (selectedStatus !== 'all' && obs.status !== selectedStatus) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const match =
        obs.productName.toLowerCase().includes(q) ||
        obs.retailerName.toLowerCase().includes(q) ||
        obs.observationId.toLowerCase().includes(q) ||
        obs.coicopCode.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const totalPages = Math.ceil(filtered.length / pageSize) || 1;
  const pageObs = filtered.slice((page - 1) * pageSize, page * pageSize);

  const handleExportCSV = () => {
    const headers = [
      'ObservationID', 'Date', 'COICOP', 'Division', 'ProductName',
      'ObservedPrice', 'Currency', 'Quantity', 'Unit', 'Retailer', 'Region', 'PriceType', 'Status'
    ];
    const rows = filtered.map(o => [
      o.observationId,
      o.collectionDate,
      o.coicopCode,
      `"${o.divisionName}"`,
      `"${o.productName}"`,
      o.observedPrice.toFixed(2),
      o.currency,
      o.quantity,
      o.unitCode,
      `"${o.retailerName}"`,
      `"${o.regionName}"`,
      o.priceType,
      o.status
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `price_os_observations_export_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white border border-slate-200 rounded-lg shadow-xs">
        <div>
          <div className="text-xs text-slate-500 font-medium">MICRO-DATA EXPLORATION · RECORD INSPECTION</div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Price Observations Data Explorer</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Query individual quote-level records across retailers, geographical regions, and collection methods.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 rounded-md transition-colors flex items-center gap-1.5 shadow-xs self-start sm:self-auto"
        >
          <Download className="w-3.5 h-3.5" /> Export Filtered CSV ({filtered.length.toLocaleString()})
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* Search box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => { setSearchTerm(e.target.value); setPage(1); }}
              placeholder="Search product, retailer, ID..."
              className="w-full pl-8 pr-3 py-1.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-900 focus:border-blue-900"
            />
          </div>

          {/* Division Filter */}
          <select
            value={selectedDivision}
            onChange={(e) => { setSelectedDivision(e.target.value); setPage(1); }}
            className="w-full py-1.5 px-2.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-900"
          >
            <option value="all">All COICOP Divisions (12)</option>
            {COICOP_DIVISIONS.map(d => (
              <option key={d.code} value={d.code}>
                Div {d.code}: {d.name}
              </option>
            ))}
          </select>

          {/* Region Filter */}
          <select
            value={selectedRegion}
            onChange={(e) => { setSelectedRegion(e.target.value); setPage(1); }}
            className="w-full py-1.5 px-2.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-900"
          >
            <option value="all">All Regions (UK-Wide)</option>
            {REGIONS.map(r => (
              <option key={r.code} value={r.code}>
                {r.name}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => { setSelectedStatus(e.target.value); setPage(1); }}
            className="w-full py-1.5 px-2.5 border border-slate-300 rounded-md focus:ring-1 focus:ring-blue-900"
          >
            <option value="all">All Validation Statuses</option>
            <option value="valid">Valid (Passed)</option>
            <option value="flagged">Flagged Outlier</option>
            <option value="adjusted">Quality Adjusted</option>
            <option value="rejected">Rejected / Inadmissible</option>
          </select>
        </div>
      </div>

      {/* High-Density Data Grid */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Observation ID</th>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">COICOP</th>
                <th className="py-2.5 px-3">Product Description</th>
                <th className="py-2.5 px-3 text-right">Price</th>
                <th className="py-2.5 px-3">Quantity / Unit</th>
                <th className="py-2.5 px-3">Retailer / Supplier</th>
                <th className="py-2.5 px-3">Region</th>
                <th className="py-2.5 px-3">Source</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
              {pageObs.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400 font-sans">
                    No matching price observations found for criteria.
                  </td>
                </tr>
              ) : (
                pageObs.map(obs => (
                  <tr key={obs.observationId} className="hover:bg-slate-50/60">
                    <td className="py-2 px-3 font-semibold text-slate-800">{obs.observationId}</td>
                    <td className="py-2 px-3 text-slate-500">{obs.collectionDate}</td>
                    <td className="py-2 px-3 text-blue-900 font-bold">{obs.coicopCode}</td>
                    <td className="py-2 px-3 font-sans text-slate-900 truncate max-w-[200px]" title={obs.productName}>
                      {obs.productName}
                    </td>
                    <td className="py-2 px-3 text-right font-bold text-slate-900">
                      £{obs.observedPrice.toFixed(2)}
                    </td>
                    <td className="py-2 px-3 text-slate-600">
                      {obs.quantity} {obs.unitCode}
                    </td>
                    <td className="py-2 px-3 font-sans text-slate-700 truncate max-w-[140px]" title={obs.retailerName}>
                      {obs.retailerName}
                    </td>
                    <td className="py-2 px-3 font-sans text-slate-600">{obs.regionName}</td>
                    <td className="py-2 px-3 text-[10px] text-slate-500">{obs.priceType}</td>
                    <td className="py-2 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-sans font-semibold uppercase ${
                        obs.status === 'valid'
                          ? 'bg-emerald-50 text-emerald-800'
                          : obs.status === 'flagged'
                          ? 'bg-amber-50 text-amber-800'
                          : obs.status === 'adjusted'
                          ? 'bg-blue-50 text-blue-800'
                          : 'bg-red-50 text-red-800'
                      }`}>
                        {obs.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="flex items-center justify-between p-3 border-t border-slate-100 text-xs text-slate-600">
          <div>
            Showing <strong className="font-mono">{((page - 1) * pageSize) + 1}</strong> to <strong className="font-mono">{Math.min(page * pageSize, filtered.length)}</strong> of <strong className="font-mono">{filtered.length.toLocaleString()}</strong> records
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-2.5 py-1 border border-slate-200 rounded disabled:opacity-40 hover:bg-slate-50"
            >
              Previous
            </button>
            <span className="font-mono font-medium">Page {page} of {totalPages}</span>
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="px-2.5 py-1 border border-slate-200 rounded disabled:opacity-40 hover:bg-slate-50"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
