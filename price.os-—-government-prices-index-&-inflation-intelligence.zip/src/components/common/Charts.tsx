import React, { useState } from 'react';

interface LinePoint {
  period: string;
  value: number;
}

interface MultiLineSeries {
  name: string;
  color: string;
  data: LinePoint[];
}

export function MultiLineChart({
  series,
  height = 280,
  yUnit = '%',
  zeroLine = true,
}: {
  series: MultiLineSeries[];
  height?: number;
  yUnit?: string;
  zeroLine?: boolean;
}) {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  if (series.length === 0 || series[0].data.length === 0) {
    return <div className="h-64 flex items-center justify-center text-xs text-slate-400">No time-series data available</div>;
  }

  const periods = series[0].data.map(d => d.period);
  const allValues = series.flatMap(s => s.data.map(d => d.value)).filter(v => !isNaN(v) && isFinite(v));
  
  const minVal = Math.min(...allValues, zeroLine ? 0 : 0);
  const maxVal = Math.max(...allValues, zeroLine ? 0 : 5);
  const yPadding = (maxVal - minVal) * 0.1 || 1;
  const yMin = minVal - yPadding;
  const yMax = maxVal + yPadding;

  const width = 800;
  const paddingLeft = 55;
  const paddingRight = 20;
  const paddingTop = 25;
  const paddingBottom = 40;

  const chartW = width - paddingLeft - paddingRight;
  const chartH = height - paddingTop - paddingBottom;

  const getX = (idx: number) => paddingLeft + (idx / (periods.length - 1)) * chartW;
  const getY = (val: number) => paddingTop + chartH - ((val - yMin) / (yMax - yMin)) * chartH;

  // Y-axis ticks
  const tickCount = 5;
  const ticks = Array.from({ length: tickCount }, (_, i) => {
    const v = yMin + (i / (tickCount - 1)) * (yMax - yMin);
    return Number(v.toFixed(1));
  });

  return (
    <div className="relative w-full overflow-hidden">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto select-none"
        onMouseLeave={() => setHoverIndex(null)}
      >
        {/* Horizontal grid lines & labels */}
        {ticks.map((t, idx) => {
          const y = getY(t);
          return (
            <g key={idx}>
              <line
                x1={paddingLeft}
                y1={y}
                x2={width - paddingRight}
                y2={y}
                stroke="#e2e8f0"
                strokeDasharray={t === 0 ? 'none' : '3 3'}
                strokeWidth={t === 0 ? 1.5 : 1}
              />
              <text
                x={paddingLeft - 8}
                y={y + 4}
                textAnchor="end"
                className="text-[10px] fill-slate-400 font-mono tabular-nums"
              >
                {t}
                {yUnit}
              </text>
            </g>
          );
        })}

        {/* X-axis labels (render every 3-4 months to prevent collision) */}
        {periods.map((p, idx) => {
          if (idx % 3 !== 0 && idx !== periods.length - 1) return null;
          const x = getX(idx);
          return (
            <text
              key={p}
              x={x}
              y={height - 12}
              textAnchor="middle"
              className="text-[10px] fill-slate-500 font-mono"
            >
              {p.slice(2)}
            </text>
          );
        })}

        {/* Lines */}
        {series.map(s => {
          const points = s.data.map((d, i) => `${getX(i)},${getY(d.value)}`).join(' ');
          return (
            <g key={s.name}>
              <polyline
                fill="none"
                stroke={s.color}
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
                points={points}
              />
              {s.data.map((d, i) => (
                <circle
                  key={i}
                  cx={getX(i)}
                  cy={getY(d.value)}
                  r={hoverIndex === i ? 4.5 : 2}
                  fill={s.color}
                  stroke="#ffffff"
                  strokeWidth={1.5}
                />
              ))}
            </g>
          );
        })}

        {/* Vertical hover indicator */}
        {hoverIndex !== null && (
          <line
            x1={getX(hoverIndex)}
            y1={paddingTop}
            x2={getX(hoverIndex)}
            y2={height - paddingBottom}
            stroke="#94a3b8"
            strokeWidth={1}
            strokeDasharray="4 4"
          />
        )}

        {/* Invisible mouse capture columns */}
        {periods.map((_, i) => {
          const x1 = i === 0 ? paddingLeft : (getX(i - 1) + getX(i)) / 2;
          const x2 = i === periods.length - 1 ? width - paddingRight : (getX(i) + getX(i + 1)) / 2;
          return (
            <rect
              key={i}
              x={x1}
              y={paddingTop}
              width={x2 - x1}
              height={chartH}
              fill="transparent"
              className="cursor-crosshair"
              onMouseEnter={() => setHoverIndex(i)}
            />
          );
        })}
      </svg>

      {/* Tooltip */}
      {hoverIndex !== null && (
        <div
          className="absolute pointer-events-none bg-slate-900 text-white rounded p-2 text-xs shadow-lg z-20 border border-slate-700"
          style={{
            left: `${(getX(hoverIndex) / width) * 100}%`,
            top: '25px',
            transform: 'translateX(-50%)',
          }}
        >
          <div className="font-semibold text-slate-300 font-mono mb-1">{periods[hoverIndex]}</div>
          <div className="space-y-0.5">
            {series.map(s => (
              <div key={s.name} className="flex items-center justify-between gap-4">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: s.color }} />
                  {s.name}:
                </span>
                <span className="font-mono tabular-nums font-medium">
                  {s.data[hoverIndex]?.value !== undefined ? `${s.data[hoverIndex].value.toFixed(2)}${yUnit}` : 'N/A'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap items-center justify-center gap-5 mt-2 text-xs">
        {series.map(s => (
          <div key={s.name} className="flex items-center gap-1.5 text-slate-600">
            <span className="w-3 h-0.5 inline-block" style={{ backgroundColor: s.color }} />
            <span>{s.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function WaterfallContributionChart({
  contributions,
  headlineYoy,
}: {
  contributions: { name: string; ppt: number; color?: string }[];
  headlineYoy: number;
}) {
  const maxPpt = Math.max(...contributions.map(c => Math.abs(c.ppt)), 1.5);

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center text-xs text-slate-500 pb-1 border-b border-slate-200">
        <span>COICOP Division</span>
        <span>Contribution to Headline YoY ({headlineYoy.toFixed(2)}%)</span>
      </div>
      <div className="space-y-2 pt-1">
        {contributions.map((c) => {
          const isPos = c.ppt >= 0;
          const barWidthPercent = (Math.abs(c.ppt) / maxPpt) * 100;
          return (
            <div key={c.name} className="flex items-center gap-3 text-xs">
              <div className="w-44 truncate text-slate-700 font-medium shrink-0" title={c.name}>
                {c.name}
              </div>
              <div className="flex-1 flex items-center h-5 bg-slate-100 rounded px-1 relative">
                {/* Zero center line */}
                <div className="absolute left-1/2 top-0 bottom-0 w-px bg-slate-300" />
                {isPos ? (
                  <div
                    className="h-3.5 bg-blue-600 rounded-r transition-all"
                    style={{
                      marginLeft: '50%',
                      width: `${Math.min(50, barWidthPercent / 2)}%`,
                    }}
                  />
                ) : (
                  <div
                    className="h-3.5 bg-amber-600 rounded-l transition-all"
                    style={{
                      marginLeft: `${Math.max(0, 50 - barWidthPercent / 2)}%`,
                      width: `${Math.min(50, barWidthPercent / 2)}%`,
                    }}
                  />
                )}
              </div>
              <div className={`w-14 text-right font-mono tabular-nums font-semibold shrink-0 ${isPos ? 'text-blue-700' : 'text-amber-700'}`}>
                {isPos ? `+${c.ppt.toFixed(2)}` : c.ppt.toFixed(2)} ppt
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function FanForecastChart({
  history,
  forecasts,
}: {
  history: { period: string; value: number }[];
  forecasts: { period: string; pointForecast: number; lower80: number; upper80: number; lower95: number; upper95: number }[];
}) {
  const combined = [
    ...history.slice(-12).map(h => ({ period: h.period, val: h.value, isHist: true })),
    ...forecasts.map(f => ({ period: f.period, val: f.pointForecast, isHist: false, lower80: f.lower80, upper80: f.upper80, lower95: f.lower95, upper95: f.upper95 })),
  ];

  const minVal = Math.min(...combined.map(c => c.val || 100), ...forecasts.map(f => f.lower95 || 100)) - 1;
  const maxVal = Math.max(...combined.map(c => c.val || 100), ...forecasts.map(f => f.upper95 || 100)) + 1;

  const width = 760;
  const height = 260;
  const padL = 50;
  const padR = 25;
  const padT = 20;
  const padB = 35;
  const chartW = width - padL - padR;
  const chartH = height - padT - padB;

  const getX = (idx: number) => padL + (idx / (combined.length - 1)) * chartW;
  const getY = (v: number) => padT + chartH - ((v - minVal) / (maxVal - minVal)) * chartH;

  const histLen = 12;
  const histPoints = combined.slice(0, histLen).map((c, i) => `${getX(i)},${getY(c.val)}`).join(' ');
  const forePoints = combined.slice(histLen - 1).map((c, i) => `${getX(histLen - 1 + i)},${getY(c.val)}`).join(' ');

  // 95% fan polygon
  const fan95Points = [
    `${getX(histLen - 1)},${getY(combined[histLen - 1].val)}`,
    ...forecasts.map((f, i) => `${getX(histLen + i)},${getY(f.upper95)}`),
    ...forecasts.slice().reverse().map((f, i) => `${getX(histLen + forecasts.length - 1 - i)},${getY(f.lower95)}`),
    `${getX(histLen - 1)},${getY(combined[histLen - 1].val)}`,
  ].join(' ');

  // 80% fan polygon
  const fan80Points = [
    `${getX(histLen - 1)},${getY(combined[histLen - 1].val)}`,
    ...forecasts.map((f, i) => `${getX(histLen + i)},${getY(f.upper80)}`),
    ...forecasts.slice().reverse().map((f, i) => `${getX(histLen + forecasts.length - 1 - i)},${getY(f.lower80)}`),
    `${getX(histLen - 1)},${getY(combined[histLen - 1].val)}`,
  ].join(' ');

  return (
    <div className="w-full">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
        {/* Background Grid */}
        {[0, 0.25, 0.5, 0.75, 1].map((pct, i) => {
          const v = minVal + pct * (maxVal - minVal);
          const y = getY(v);
          return (
            <g key={i}>
              <line x1={padL} y1={y} x2={width - padR} y2={y} stroke="#e2e8f0" strokeDasharray="3 3" />
              <text x={padL - 6} y={y + 4} textAnchor="end" className="text-[10px] fill-slate-400 font-mono">
                {v.toFixed(1)}
              </text>
            </g>
          );
        })}

        {/* Fan 95% interval */}
        <polygon points={fan95Points} fill="#bfdbfe" fillOpacity={0.4} />
        {/* Fan 80% interval */}
        <polygon points={fan80Points} fill="#93c5fd" fillOpacity={0.6} />

        {/* Historical line */}
        <polyline points={histPoints} fill="none" stroke="#0f172a" strokeWidth={2.2} />
        {/* Forecast point line */}
        <polyline points={forePoints} fill="none" stroke="#2563eb" strokeWidth={2.2} strokeDasharray="4 3" />

        {/* Transition delimiter */}
        <line
          x1={getX(histLen - 1)}
          y1={padT}
          x2={getX(histLen - 1)}
          y2={height - padB}
          stroke="#94a3b8"
          strokeWidth={1}
          strokeDasharray="2 2"
        />
        <text
          x={getX(histLen - 1)}
          y={padT + 12}
          textAnchor="middle"
          className="text-[9px] fill-slate-500 font-sans font-semibold uppercase tracking-wider"
        >
          Forecast Horizon
        </text>

        {/* X labels */}
        {combined.map((c, i) => {
          if (i % 2 !== 0 && i !== combined.length - 1) return null;
          return (
            <text key={i} x={getX(i)} y={height - 10} textAnchor="middle" className="text-[10px] fill-slate-500 font-mono">
              {c.period.slice(2)}
            </text>
          );
        })}
      </svg>
      <div className="flex items-center justify-center gap-6 mt-2 text-xs text-slate-600">
        <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-slate-900 inline-block" /> Historical Index</span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-blue-600 border-b border-dashed inline-block" /> Central Projection</span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-2 bg-blue-300 opacity-60 inline-block rounded-xs" /> 80% Confidence Band</span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-2 bg-blue-200 opacity-40 inline-block rounded-xs" /> 95% Confidence Band</span>
      </div>
    </div>
  );
}
