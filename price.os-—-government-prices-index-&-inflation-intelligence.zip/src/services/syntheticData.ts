import { PriceObservation } from '../types/priceIndex';
import { COICOP_DIVISIONS, REGIONS } from './coicopData';

export const SAMPLE_PRODUCTS = [
  // Division 01 Food
  { id: 'PRD-0101', name: 'White Sliced Loaf 800g', coicop: '01.1.1', division: '01', basePrice: 1.25, unit: 'pack', qty: 0.8, type: 'shelf' as const },
  { id: 'PRD-0102', name: 'Whole Milk 2 Pints 1.13L', coicop: '01.1.2', division: '01', basePrice: 1.30, unit: 'bottle', qty: 1.13, type: 'shelf' as const },
  { id: 'PRD-0103', name: 'Free Range Eggs 6-pack', coicop: '01.1.3', division: '01', basePrice: 1.95, unit: 'pack', qty: 6, type: 'shelf' as const },
  { id: 'PRD-0104', name: 'Chicken Breast Fillets 1kg', coicop: '01.1.4', division: '01', basePrice: 6.20, unit: 'kg', qty: 1.0, type: 'shelf' as const },
  { id: 'PRD-0105', name: 'Bananas Loose 1kg', coicop: '01.1.5', division: '01', basePrice: 0.95, unit: 'kg', qty: 1.0, type: 'shelf' as const },
  { id: 'PRD-0106', name: 'Cheddar Cheese Mature 400g', coicop: '01.1.6', division: '01', basePrice: 3.40, unit: 'pack', qty: 0.4, type: 'shelf' as const },
  { id: 'PRD-0107', name: 'Potatoes Maris Piper 2.5kg', coicop: '01.1.7', division: '01', basePrice: 2.10, unit: 'bag', qty: 2.5, type: 'shelf' as const },
  
  // Division 02 Alcohol & Tobacco
  { id: 'PRD-0201', name: 'Lager Cans 4x440ml', coicop: '02.1.1', division: '02', basePrice: 4.80, unit: 'pack', qty: 1.76, type: 'shelf' as const },
  { id: 'PRD-0202', name: 'Sauvignon Blanc 75cl', coicop: '02.1.2', division: '02', basePrice: 7.50, unit: 'bottle', qty: 0.75, type: 'shelf' as const },
  
  // Division 03 Clothing
  { id: 'PRD-0301', name: 'Men Cotton Crew T-Shirt', coicop: '03.1.1', division: '03', basePrice: 12.00, unit: 'unit', qty: 1.0, type: 'shelf' as const },
  { id: 'PRD-0302', name: 'Women Slim Denim Jeans', coicop: '03.1.2', division: '03', basePrice: 34.00, unit: 'unit', qty: 1.0, type: 'shelf' as const },
  { id: 'PRD-0303', name: 'Children Leather School Shoes', coicop: '03.2.1', division: '03', basePrice: 38.00, unit: 'pair', qty: 1.0, type: 'shelf' as const },

  // Division 04 Housing & Energy
  { id: 'PRD-0401', name: 'Domestic Electricity Unit Rate (kWh)', coicop: '04.1.1', division: '04', basePrice: 0.28, unit: 'kWh', qty: 1.0, type: 'admin' as const },
  { id: 'PRD-0402', name: 'Domestic Gas Unit Rate (kWh)', coicop: '04.1.2', division: '04', basePrice: 0.07, unit: 'kWh', qty: 1.0, type: 'admin' as const },
  { id: 'PRD-0403', name: 'Private Rental 2-Bed Flat (Monthly)', coicop: '04.2.1', division: '04', basePrice: 1150.00, unit: 'month', qty: 1.0, type: 'transaction' as const },

  // Division 05 Furnishings
  { id: 'PRD-0501', name: 'Washing Machine 8kg 1400rpm', coicop: '05.3.1', division: '05', basePrice: 380.00, unit: 'unit', qty: 1.0, type: 'shelf' as const },

  // Division 06 Health
  { id: 'PRD-0601', name: 'Paracetamol 500mg 16 Tablets', coicop: '06.1.1', division: '06', basePrice: 0.55, unit: 'pack', qty: 16, type: 'shelf' as const },

  // Division 07 Transport
  { id: 'PRD-0701', name: 'Unleaded Petrol Standard 95 (Litre)', coicop: '07.1.1', division: '07', basePrice: 1.42, unit: 'litre', qty: 1.0, type: 'scanner' as const },
  { id: 'PRD-0702', name: 'Standard Single Train Fare 50mi', coicop: '07.2.1', division: '07', basePrice: 24.50, unit: 'ticket', qty: 1.0, type: 'transaction' as const },

  // Division 08 Communication
  { id: 'PRD-0801', name: 'Mobile SIM Contract 50GB 5G', coicop: '08.1.1', division: '08', basePrice: 14.00, unit: 'month', qty: 1.0, type: 'transaction' as const },

  // Division 09 Recreation & Culture
  { id: 'PRD-0901', name: 'Adult Cinema Ticket 2D', coicop: '09.1.1', division: '09', basePrice: 11.50, unit: 'ticket', qty: 1.0, type: 'transaction' as const },

  // Division 10 Education
  { id: 'PRD-1001', name: 'Private Music Tuition (1 hr)', coicop: '10.1.1', division: '10', basePrice: 35.00, unit: 'hour', qty: 1.0, type: 'shelf' as const },

  // Division 11 Restaurants & Hotels
  { id: 'PRD-1101', name: 'Pub Fish & Chips with Ale', coicop: '11.1.1', division: '11', basePrice: 14.50, unit: 'meal', qty: 1.0, type: 'transaction' as const },
  { id: 'PRD-1102', name: 'Barista Regular Cappuccino 12oz', coicop: '11.1.2', division: '11', basePrice: 3.40, unit: 'cup', qty: 1.0, type: 'shelf' as const },

  // Division 12 Miscellaneous
  { id: 'PRD-1201', name: 'Men Standard Dry Haircut', coicop: '12.1.1', division: '12', basePrice: 18.00, unit: 'service', qty: 1.0, type: 'shelf' as const },
];

export const RETAILERS = [
  'Tesco Superstores', 'Sainsbury’s Local', 'Asda Hypermarket', 'Waitrose & Partners',
  'Shell Petrol Station', 'BP Express', 'British Gas Domestic', 'Octopus Energy',
  'Currys Tech Retail', 'National Rail Network', 'EE Telecom', 'O2 Mobile',
  'JD Wetherspoon', 'Costa Coffee UK', 'Boots Pharmacy', 'Independent Retailer'
];

// Generate synthetic monthly observations across 2024-01 to 2026-10 (34 months)
export function generateSyntheticObservations(): PriceObservation[] {
  const observations: PriceObservation[] = [];
  const startYear = 2024;
  const endYear = 2026;
  const endMonth = 10; // Current time is Nov 2026, so through Oct 2026

  let obsCounter = 10000;

  for (let y = startYear; y <= endYear; y++) {
    const maxM = (y === endYear) ? endMonth : 12;
    for (let m = 1; m <= maxM; m++) {
      const monthStr = m < 10 ? `0${m}` : `${m}`;
      const period = `${y}-${monthStr}`;
      const collectionDate = `${y}-${monthStr}-14`; // ONS second Tuesday collection date convention
      const monthIndex = (y - 2024) * 12 + (m - 1); // 0 to 33

      // Historical trend multipliers reflecting realistic UK/global inflation path:
      // 2024 started higher, eased through late 2024/2025, slight energy uptick in winter, services sticky
      const foodTrend = 1.0 + Math.pow(monthIndex, 0.75) * 0.016 + Math.sin(m * 0.5) * 0.008;
      const energyTrend = 1.0 + (monthIndex < 10 ? -monthIndex * 0.015 : monthIndex < 22 ? -0.15 + (monthIndex - 10) * 0.01 : -0.03 + (monthIndex - 22) * 0.008);
      const servicesTrend = 1.0 + monthIndex * 0.0042; // sticky ~5% per annum
      const goodsTrend = 1.0 + monthIndex * 0.0021; // slower ~2.5% per annum

      // For each product, generate 2-3 regional quotes
      SAMPLE_PRODUCTS.forEach((prd) => {
        const divisionObj = COICOP_DIVISIONS.find(d => d.code === prd.division);
        let categoryTrend = goodsTrend;
        if (prd.division === '01') categoryTrend = foodTrend;
        else if (prd.division === '04') categoryTrend = (prd.coicop === '04.2.1' ? servicesTrend : energyTrend);
        else if (prd.division === '07' && prd.coicop === '07.1.1') categoryTrend = energyTrend * 0.95 + goodsTrend * 0.05;
        else if (!divisionObj?.isGoods) categoryTrend = servicesTrend;

        // Sample across 3 representative regions per product per month
        const selectedRegions = [
          REGIONS[obsCounter % REGIONS.length],
          REGIONS[(obsCounter + 3) % REGIONS.length],
          REGIONS[(obsCounter + 7) % REGIONS.length],
        ];

        selectedRegions.forEach((region, rIdx) => {
          obsCounter++;
          const regionalWeightFactor = 1.0 + (region.code === 'UK-LON' ? 0.09 : region.code === 'UK-SE' ? 0.04 : -0.03);
          const noise = ((obsCounter % 17) - 8) * 0.003; // small deterministic realistic noise
          const observed = Number((prd.basePrice * categoryTrend * regionalWeightFactor * (1 + noise)).toFixed(2));
          const retailer = RETAILERS[(obsCounter + rIdx) % RETAILERS.length];

          observations.push({
            observationId: `OBS-${obsCounter}`,
            productId: prd.id,
            productName: prd.name,
            coicopCode: prd.coicop,
            divisionCode: prd.division,
            divisionName: divisionObj ? divisionObj.name : 'Unknown Division',
            outletId: `OUT-${100 + (obsCounter % 50)}`,
            retailerName: retailer,
            regionCode: region.code,
            regionName: region.name,
            collectionDate,
            observedPrice: observed,
            basePrice: prd.basePrice,
            currency: 'GBP',
            quantity: prd.qty,
            unitCode: prd.unit,
            priceType: prd.type,
            dataSource: prd.type === 'admin' ? 'OFGEM_ADMIN_FEED' : prd.type === 'scanner' ? 'EPOS_SCANNER_API' : 'FIELD_TABLET_SURVEY',
            status: 'valid',
            isPromotional: (obsCounter % 23 === 0),
          });
        });
      });
    }
  }

  // Inject intentional realistic anomalies in the most recent periods for the Price Validation Laboratory to demonstrate real detection:
  // 1. Extreme Price Spike (decimal slip £180.00 instead of £1.80)
  const milkSpikeIdx = observations.findIndex(o => o.productId === 'PRD-0102' && o.collectionDate.startsWith('2026-10'));
  if (milkSpikeIdx >= 0) {
    observations[milkSpikeIdx].observedPrice = 180.00;
    observations[milkSpikeIdx].status = 'flagged';
    observations[milkSpikeIdx].qualityFlag = 'EXTREME_OUTLIER_SPIKE';
    observations[milkSpikeIdx].notes = 'Suspected decimal entry error (180.00 vs 1.80)';
  }

  // 2. Unit Inconsistency / Zero Price
  const zeroPriceIdx = observations.findIndex(o => o.productId === 'PRD-0105' && o.collectionDate.startsWith('2026-10'));
  if (zeroPriceIdx >= 0) {
    observations[zeroPriceIdx].observedPrice = 0.00;
    observations[zeroPriceIdx].status = 'rejected';
    observations[zeroPriceIdx].qualityFlag = 'ZERO_PRICE_ERROR';
    observations[zeroPriceIdx].notes = 'Zero price detected. Inadmissible under elementary index formulas.';
  }

  // 3. Shrinkflation / Downsizing Example
  const breadShrinkIdx = observations.findIndex(o => o.productId === 'PRD-0101' && o.collectionDate.startsWith('2026-09'));
  if (breadShrinkIdx >= 0) {
    observations[breadShrinkIdx].quantity = 0.70; // 700g down from 800g
    observations[breadShrinkIdx].shrinkflationFlag = true;
    observations[breadShrinkIdx].qualityFlag = 'PACKAGE_DOWNSIZING_DETECTED';
    observations[breadShrinkIdx].notes = 'Pack size reduced from 800g to 700g at shelf price £1.45. Requires quantity quality adjustment.';
  }

  return observations;
}
