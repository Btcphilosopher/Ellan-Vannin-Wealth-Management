import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { simulationEngine } from './src/services/simulationEngine';

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Initialize Gemini SDK with telemetry header as specified in skill
const aiKey = process.env.GEMINI_API_KEY || '';
let aiClient: GoogleGenAI | null = null;
if (aiKey && aiKey !== 'MY_GEMINI_API_KEY') {
  aiClient = new GoogleGenAI({
    apiKey: aiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// REST API Routes
app.get('/api/v1/state', (_req, res) => {
  res.json({ success: true, data: simulationEngine.getStoreState() });
});

app.post('/api/v1/vem/mint', (req, res) => {
  try {
    const { amountEur } = req.body;
    if (!amountEur || amountEur <= 0) {
      return res.status(400).json({ success: false, error: 'Invalid amount for VEM minting.' });
    }
    const result = simulationEngine.mintVem(Number(amountEur));
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Minting failed' });
  }
});

app.post('/api/v1/vem/redeem', (req, res) => {
  try {
    const { amountVem } = req.body;
    if (!amountVem || amountVem <= 0) {
      return res.status(400).json({ success: false, error: 'Invalid amount for VEM redemption.' });
    }
    const result = simulationEngine.redeemVem(Number(amountVem));
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Redemption failed' });
  }
});

app.post('/api/v1/transfer', (req, res) => {
  try {
    const { fromCurrency, recipientName, recipientIban, amount, reference, rail } = req.body;
    const result = simulationEngine.executeTransfer({
      fromCurrency,
      recipientName: recipientName || 'Counterparty',
      recipientIban: recipientIban || 'DE00000000000000000000',
      amount: Number(amount),
      reference: reference || 'Transfer',
      rail: rail || 'SEPA_INSTANT',
    });
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Transfer failed' });
  }
});

app.post('/api/v1/demo/berlin', (_req, res) => {
  try {
    const result = simulationEngine.runBerlinDemoScenario();
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/v1/euro-pos/scenario', (req, res) => {
  try {
    const { scenario } = req.body;
    const posState = simulationEngine.triggerEuroPosScenario(scenario);
    res.json({ success: true, data: posState });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

app.post('/api/v1/ai/query', async (req, res) => {
  try {
    const { userQuery } = req.body;
    if (!userQuery) {
      return res.status(400).json({ success: false, error: 'userQuery is required' });
    }

    const currentState = simulationEngine.getStoreState();
    const stateSummary = `
CURRENT SYSTEM STATE (BANCO DE VESUVIUS):
Client Name: ${currentState.client.name}
Total Wealth: €${currentState.client.totalWealthEur.toLocaleString()}
EUR Current Account Balance: €${currentState.accounts[0].balance.toLocaleString()}
Digital Euro Balance: €${currentState.accounts[1].balance.toLocaleString()} (Limit: €3,000)
Vesuvius Mark (VEM) Balance: ${currentState.accounts[2].balance.toLocaleString()} VEM (€1.0000/VEM)
VEM Circulating Supply: €${(currentState.vemMonetary.circulatingSupply / 1e9).toFixed(2)} Billion
VEM Reserves Total: €${(currentState.vemMonetary.reservesTotal / 1e9).toFixed(2)} Billion (Coverage: ${currentState.vemMonetary.reserveCoverage}%)
Reserve Assets: German Bunds (€840M), EUR Cash (€620M), French OAT (€510M), Dutch Bonds (€290M), Other Liquid Sovereign (€600M).
Euro PoS Network: ${currentState.euroPos.status} with ${currentState.euroPos.activeValidators}/${currentState.euroPos.totalValidators} Validators, Finality ${currentState.euroPos.finalitySec}s, Epoch ${currentState.euroPos.currentEpoch}.
Portfolio Investments: €${currentState.portfolio.investmentsEur.toLocaleString()} | YTD Return: +${currentState.portfolio.ytdReturnPercent}% | Sharpe: ${currentState.portfolio.sharpeRatio} | Volatility: ${currentState.portfolio.volatilityPercent}%.
Lombard Credit Facility: €${currentState.portfolio.lombardCreditEur.toLocaleString()}.
    `;

    const systemPrompt = `
You are Vesuvius Intelligence, the private banking AI assistant for Banco de Vesuvius in Berlin.
You have direct real-time access to the client's simulated banking ledger, VEM reserves, Euro PoS consensus state, and wealth portfolio.

MANDATORY RESPONSE STYLE:
1. Always tag financial claims and insights explicitly with one of these tags:
   - [OBSERVED] for actual recorded account balances and holdings.
   - [CALCULATED] for computed metrics like Sharpe ratio, reserve coverage, or YTD return.
   - [SIMULATED] for Euro PoS validator latency, finality, or offline wallet status.
   - [SCENARIO] for stress test model outputs or sensitivity projections.
   - [ASSUMPTION] for market yield or macro forecasts.
2. Be professional, concise, authoritative, and sophisticated in European private banking tone.
3. Distinguish Vesuvius Mark (VEM) as a private/synthetic euro stablecoin, and Digital Euro as the public Eurosystem retail CBDC integration layer.
`;

    if (!aiClient) {
      // Return authoritative rule-based fallback response grounded in state
      const fallbackText = `
[OBSERVED] According to your Banco de Vesuvius ledger, your liquid accounts hold €${currentState.accounts[0].balance.toLocaleString()} in EUR commercial bank money, ${currentState.accounts[2].balance.toLocaleString()} VEM in Vesuvius Mark stablecoins, and €${currentState.accounts[1].balance.toLocaleString()} in Digital Euro.

[CALCULATED] Your total wealth stands at €${currentState.client.totalWealthEur.toLocaleString()} with an investment portfolio of €${currentState.portfolio.investmentsEur.toLocaleString()} (YTD Return: +${currentState.portfolio.ytdReturnPercent}%, Sharpe Ratio: ${currentState.portfolio.sharpeRatio}).

[SIMULATED] The Vesuvius Euro Mark (VEM) is backed 1:1 with €${(currentState.vemMonetary.reservesTotal / 1e9).toFixed(2)}bn in high-quality liquid European reserves (${currentState.vemMonetary.reserveCoverage}% reserve coverage). Euro PoS consensus network is ${currentState.euroPos.status} with ${currentState.euroPos.activeValidators} active European validator nodes achieving ${currentState.euroPos.finalitySec}s finality.

[SCENARIO] Your portfolio has a -6.8% maximum drawdown limit and 9.8% annualized volatility. In a +100bps rate shock scenario, your fixed income duration (2.8 yrs) implies a manageable -2.4% price sensitivity offset by yield reinvestment.
      `.trim();
      return res.json({ success: true, text: fallbackText, model: 'state-grounded-fallback' });
    }

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: stateSummary + '\n\nUSER QUESTION: ' + userQuery,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    res.json({ success: true, text: response.text });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'AI Intelligence query failed' });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = await vite.transformIndexHtml(url, `
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Banco de Vesuvius — European Private Bank & Digital Euro OS</title>
    <meta name="description" content="European private banking, digital euro operating system, Vesuvius Mark stablecoin, Euro PoS consensus network, institutional treasury, and wealth management platform." />
    <meta property="og:title" content="Banco de Vesuvius — European Private Bank & Digital Euro OS" />
    <meta property="og:description" content="European private banking, digital euro operating system, Vesuvius Mark stablecoin, Euro PoS consensus network, institutional treasury, and wealth management platform." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
  </head>
  <body class="bg-[#0f1115] text-[#e2e8f0] antialiased">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
        `);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[BANCO DE VESUVIUS] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
