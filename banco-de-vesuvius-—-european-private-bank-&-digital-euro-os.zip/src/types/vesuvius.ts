export type MoneyType = 'EUR' | 'DIGITAL_EURO' | 'VEM' | 'USD' | 'CHF' | 'GBP';

export type AccountType = 'CURRENT' | 'DIGITAL_EURO_WALLET' | 'VEM_WALLET' | 'TREASURY' | 'RESERVE_CUSTODY';

export interface BankAccount {
  id: string;
  accountNumber: string;
  iban: string;
  bic: string;
  accountType: AccountType;
  currency: MoneyType;
  balance: number;
  availableBalance: number;
  holdingLimit?: number; // e.g. €3,000 for Digital Euro
  status: 'ACTIVE' | 'FROZEN' | 'RESTRICTED';
}

export interface BankTransaction {
  id: string;
  timestamp: string;
  counterparty: string;
  counterpartyIban?: string;
  reference: string;
  amount: number; // positive = credit, negative = debit
  currency: MoneyType;
  status: 'COMPLETED' | 'PENDING' | 'REJECTED';
  paymentRail: 'SEPA_INSTANT' | 'SEPA' | 'DIGITAL_EURO_RAIL' | 'VEM_POS_SETTLEMENT' | 'INTERNAL_VESUVIUS';
  riskStatus: 'LOW' | 'MEDIUM' | 'HIGH_SENSITIVITY';
  auditHash: string;
}

export interface VemReserveAsset {
  id: string;
  name: string;
  type: 'EUR_CASH' | 'GERMAN_BUNDS' | 'FRENCH_OAT' | 'DUTCH_BONDS' | 'LIQUID_SOVEREIGN';
  amountMillions: number;
  percentage: number;
  yieldPercent: number;
  rating: string;
  custodian: string;
}

export interface VemMonetaryState {
  ticker: 'VEM';
  name: 'Vesuvius Euro Mark';
  priceEur: number; // 1.0000
  circulatingSupply: number; // e.g., 2,840,000,000
  reservesTotal: number; // e.g., 2,860,000,000
  reserveCoverage: number; // e.g., 100.7%
  dailyVolumeEur: number;
  activeWallets: number;
  validatorCount: number;
  reserves: VemReserveAsset[];
}

export interface ValidatorNode {
  id: string;
  name: string;
  city: string;
  country: string;
  jurisdiction: string;
  latitude: number;
  longitude: number;
  stakeEur: number;
  votingPowerPercent: number;
  uptimePercent: number;
  latencyMs: number;
  status: 'ACTIVE' | 'DEGRADED' | 'SLASHED' | 'OFFLINE';
  lastAttestedEpoch: number;
  attestationCount: number;
  hardware: string;
}

export interface EuroPosNetworkState {
  status: 'HEALTHY' | 'DEGRADED' | 'RECOVERING' | 'SIMULATED_STRESS';
  totalValidators: number;
  activeValidators: number;
  finalitySec: number;
  networkLatencyMs: number;
  totalStakeEur: number;
  attestationRatePercent: number;
  currentEpoch: number;
  currentStateRoot: string;
  proposerNodeId: string;
  validators: ValidatorNode[];
}

export interface PortfolioPosition {
  id: string;
  ticker: string;
  name: string;
  assetClass: 'EQUITY' | 'FIXED_INCOME' | 'FUNDS_UCITS' | 'PRIVATE_MARKETS' | 'ALTERNATIVES';
  geography: 'GERMANY' | 'FRANCE' | 'ITALY' | 'SWITZERLAND' | 'NETHERLANDS' | 'GLOBAL' | 'US' | string;
  currency: MoneyType;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
  valueEur: number;
  weightPercent: number;
  ytdReturnPercent: number;
}

export interface PortfolioState {
  totalWealthEur: number;
  liquidAssetsEur: number;
  investmentsEur: number;
  propertyEur: number;
  lombardCreditEur: number;
  ytdReturnPercent: number;
  todayChangeEur: number;
  volatilityPercent: number;
  sharpeRatio: number;
  maxDrawdownPercent: number;
  positions: PortfolioPosition[];
}

export interface FxQuote {
  pair: string;
  bid: number;
  ask: number;
  change24hPercent: number;
  volume24h: number;
  high24h: number;
  low24h: number;
}

export interface MacroCountryData {
  code: string;
  name: string;
  gdpBnEur: number;
  gdpGrowthPercent: number;
  cpiInflationPercent: number;
  unemploymentPercent: number;
  govDebtGdpPercent: number;
  creditGrowthPercent: number;
  latitude: number;
  longitude: number;
}

export interface SystemEvent {
  id: string;
  timestamp: string;
  type: 'PAYMENT_ACCEPTED' | 'SETTLEMENT_CONFIRMED' | 'VEM_TRANSFER' | 'EURO_POS_ATTESTATION' | 'RESERVE_STATE_UPDATED' | 'MINT_COMPLETED' | 'REDEMPTION_COMPLETED';
  description: string;
  amountEur?: number;
  actor: string;
  auditHash: string;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  action: string;
  entity: string;
  actor: string;
  details: string;
  hash: string;
}

export interface ClientProfile {
  id: string;
  name: string;
  residence: string;
  taxResidence: string;
  riskProfile: 'Conservative' | 'Balanced Growth' | 'Capital Preservation' | 'Opportunistic';
  relationshipManager: string;
  totalWealthEur: number;
  familyOfficeActive: boolean;
  corporateTreasuryActive: boolean;
}
