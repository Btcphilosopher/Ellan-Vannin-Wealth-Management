import { vesuviusStore } from './store';
import { BankTransaction, SystemEvent, AuditLogItem } from '../types/vesuvius';

function generateHash() {
  return '0x' + Math.random().toString(16).substring(2, 10) + Math.random().toString(16).substring(2, 8);
}

function getFormattedTime() {
  const d = new Date();
  return d.toTimeString().split(' ')[0];
}

function getFormattedDateTime() {
  const d = new Date();
  return d.toISOString().replace('T', ' ').substring(0, 19);
}

export const simulationEngine = {
  getStoreState() {
    return vesuviusStore;
  },

  mintVem(amountEur: number) {
    const eurAcc = vesuviusStore.accounts.find((a) => a.currency === 'EUR');
    const vemAcc = vesuviusStore.accounts.find((a) => a.currency === 'VEM');

    if (!eurAcc || eurAcc.balance < amountEur) {
      throw new Error(`Insufficient EUR balance for VEM minting. Available: €${eurAcc?.balance.toLocaleString()}`);
    }

    // 1. Debit EUR Account
    eurAcc.balance -= amountEur;
    eurAcc.availableBalance -= amountEur;

    // 2. Credit VEM Wallet
    if (vemAcc) {
      vemAcc.balance += amountEur;
      vemAcc.availableBalance += amountEur;
    }

    // 3. Update VEM Monetary State
    vesuviusStore.vemMonetary.circulatingSupply += amountEur;
    vesuviusStore.vemMonetary.reservesTotal += amountEur;
    vesuviusStore.vemMonetary.reserveCoverage = Number(
      ((vesuviusStore.vemMonetary.reservesTotal / vesuviusStore.vemMonetary.circulatingSupply) * 100).toFixed(2)
    );

    // 4. Update Cash Reserve in Assets
    const cashRes = vesuviusStore.vemMonetary.reserves.find((r) => r.type === 'EUR_CASH');
    if (cashRes) {
      cashRes.amountMillions += amountEur / 1_000_000;
    }

    // 5. Create Transaction Record
    const txId = 'TX-MINT-' + Math.floor(100000 + Math.random() * 900000);
    const hash = generateHash();
    const newTx: BankTransaction = {
      id: txId,
      timestamp: getFormattedDateTime(),
      counterparty: 'Vesuvius Euro Mark Reserve Engine',
      counterpartyIban: 'VEM-RESERVE-DE-01',
      reference: `VEM Minting Issue (€${amountEur.toLocaleString()})`,
      amount: -amountEur,
      currency: 'EUR',
      status: 'COMPLETED',
      paymentRail: 'VEM_POS_SETTLEMENT',
      riskStatus: 'LOW',
      auditHash: hash,
    };
    vesuviusStore.transactions.unshift(newTx);

    // 6. Record System Events
    const epoch = ++vesuviusStore.euroPos.currentEpoch;
    vesuviusStore.euroPos.currentStateRoot = generateHash();

    const ev1: SystemEvent = {
      id: 'EVT-' + Math.floor(1000 + Math.random() * 9000),
      timestamp: getFormattedTime(),
      type: 'MINT_COMPLETED',
      description: `Minted ${amountEur.toLocaleString()} VEM backed 1:1 by Bundesbank EUR Cash`,
      amountEur,
      actor: 'VESUVIUS_MINT_ENGINE',
      auditHash: hash,
    };
    const ev2: SystemEvent = {
      id: 'EVT-' + Math.floor(1000 + Math.random() * 9000),
      timestamp: getFormattedTime(),
      type: 'EURO_POS_ATTESTATION',
      description: `Euro PoS Epoch ${epoch.toLocaleString()} attested finality in 2.8s`,
      actor: 'VSV-BER-001',
      auditHash: hash,
    };

    vesuviusStore.systemEvents.unshift(ev1, ev2);

    // 7. Audit Log
    const audit: AuditLogItem = {
      id: 'AUD-' + Math.floor(1000 + Math.random() * 9000),
      timestamp: getFormattedDateTime(),
      action: 'VEM_MINT_ISSUANCE',
      entity: 'VEM_MONETARY_LAYER',
      actor: vesuviusStore.client.name,
      details: `Minted ${amountEur.toLocaleString()} VEM. Reserves updated to €${(vesuviusStore.vemMonetary.reservesTotal / 1e9).toFixed(3)}bn (${vesuviusStore.vemMonetary.reserveCoverage}% coverage).`,
      hash,
    };
    vesuviusStore.auditLogs.unshift(audit);

    return {
      success: true,
      amountEur,
      newVemBalance: vemAcc?.balance,
      newEurBalance: eurAcc.balance,
      reserveCoverage: vesuviusStore.vemMonetary.reserveCoverage,
      epoch,
      auditHash: hash,
    };
  },

  redeemVem(amountVem: number) {
    const vemAcc = vesuviusStore.accounts.find((a) => a.currency === 'VEM');
    const eurAcc = vesuviusStore.accounts.find((a) => a.currency === 'EUR');

    if (!vemAcc || vemAcc.balance < amountVem) {
      throw new Error(`Insufficient VEM balance for redemption. Available: ${vemAcc?.balance.toLocaleString()} VEM`);
    }

    // 1. Debit VEM Wallet
    vemAcc.balance -= amountVem;
    vemAcc.availableBalance -= amountVem;

    // 2. Credit EUR Account
    if (eurAcc) {
      eurAcc.balance += amountVem;
      eurAcc.availableBalance += amountVem;
    }

    // 3. Burn VEM and reduce reserves
    vesuviusStore.vemMonetary.circulatingSupply -= amountVem;
    vesuviusStore.vemMonetary.reservesTotal -= amountVem;
    vesuviusStore.vemMonetary.reserveCoverage = Number(
      ((vesuviusStore.vemMonetary.reservesTotal / vesuviusStore.vemMonetary.circulatingSupply) * 100).toFixed(2)
    );

    const cashRes = vesuviusStore.vemMonetary.reserves.find((r) => r.type === 'EUR_CASH');
    if (cashRes) {
      cashRes.amountMillions = Math.max(0, cashRes.amountMillions - amountVem / 1_000_000);
    }

    const txId = 'TX-BURN-' + Math.floor(100000 + Math.random() * 900000);
    const hash = generateHash();

    const newTx: BankTransaction = {
      id: txId,
      timestamp: getFormattedDateTime(),
      counterparty: 'Vesuvius Euro Mark Redemption Engine',
      counterpartyIban: 'VEM-BURN-GATEWAY-01',
      reference: `VEM Burn & EUR Release (€${amountVem.toLocaleString()})`,
      amount: amountVem,
      currency: 'EUR',
      status: 'COMPLETED',
      paymentRail: 'VEM_POS_SETTLEMENT',
      riskStatus: 'LOW',
      auditHash: hash,
    };
    vesuviusStore.transactions.unshift(newTx);

    const epoch = ++vesuviusStore.euroPos.currentEpoch;
    vesuviusStore.euroPos.currentStateRoot = generateHash();

    const ev: SystemEvent = {
      id: 'EVT-' + Math.floor(1000 + Math.random() * 9000),
      timestamp: getFormattedTime(),
      type: 'REDEMPTION_COMPLETED',
      description: `Redeemed ${amountVem.toLocaleString()} VEM for €${amountVem.toLocaleString()} EUR cash release`,
      amountEur: amountVem,
      actor: 'VESUVIUS_REDEMPTION_ENGINE',
      auditHash: hash,
    };
    vesuviusStore.systemEvents.unshift(ev);

    const audit: AuditLogItem = {
      id: 'AUD-' + Math.floor(1000 + Math.random() * 9000),
      timestamp: getFormattedDateTime(),
      action: 'VEM_REDEMPTION_BURN',
      entity: 'VEM_MONETARY_LAYER',
      actor: vesuviusStore.client.name,
      details: `Burned ${amountVem.toLocaleString()} VEM. Released €${amountVem.toLocaleString()} EUR to account ${eurAcc?.iban}`,
      hash,
    };
    vesuviusStore.auditLogs.unshift(audit);

    return {
      success: true,
      amountVem,
      newVemBalance: vemAcc.balance,
      newEurBalance: eurAcc?.balance,
      reserveCoverage: vesuviusStore.vemMonetary.reserveCoverage,
      epoch,
      auditHash: hash,
    };
  },

  executeTransfer(params: {
    fromCurrency: 'EUR' | 'DIGITAL_EURO' | 'VEM';
    recipientName: string;
    recipientIban: string;
    amount: number;
    reference: string;
    rail: 'SEPA_INSTANT' | 'SEPA' | 'DIGITAL_EURO_RAIL' | 'VEM_POS_SETTLEMENT' | 'INTERNAL_VESUVIUS';
  }) {
    const acc = vesuviusStore.accounts.find((a) => a.currency === params.fromCurrency);
    if (!acc || acc.balance < params.amount) {
      throw new Error(`Insufficient funds in ${params.fromCurrency} account.`);
    }

    acc.balance -= params.amount;
    acc.availableBalance -= params.amount;

    const hash = generateHash();
    const tx: BankTransaction = {
      id: 'TX-' + Math.floor(100000 + Math.random() * 900000),
      timestamp: getFormattedDateTime(),
      counterparty: params.recipientName,
      counterpartyIban: params.recipientIban,
      reference: params.reference,
      amount: -params.amount,
      currency: params.fromCurrency,
      status: 'COMPLETED',
      paymentRail: params.rail,
      riskStatus: params.amount > 50000 ? 'MEDIUM' : 'LOW',
      auditHash: hash,
    };

    vesuviusStore.transactions.unshift(tx);

    const ev: SystemEvent = {
      id: 'EVT-' + Math.floor(1000 + Math.random() * 9000),
      timestamp: getFormattedTime(),
      type: 'PAYMENT_ACCEPTED',
      description: `Transfer of ${params.amount.toLocaleString()} ${params.fromCurrency} to ${params.recipientName}`,
      amountEur: params.amount,
      actor: 'SETTLEMENT_ROUTER',
      auditHash: hash,
    };
    vesuviusStore.systemEvents.unshift(ev);

    return { success: true, transaction: tx };
  },

  runBerlinDemoScenario() {
    const logs: string[] = [];
    logs.push('>>> INITIATING BANCO DE VESUVIUS FLAGSHIP BERLIN DEMO <<<');
    logs.push('Client: Friedrich von Vesuvius-Halle (Berlin Private Client)');
    
    // Step 1: Initial state check
    const eurAcc = vesuviusStore.accounts.find((a) => a.currency === 'EUR');
    const vemAcc = vesuviusStore.accounts.find((a) => a.currency === 'VEM');
    logs.push(`Initial Holdings: EUR €${eurAcc?.balance.toLocaleString()} | VEM ${vemAcc?.balance.toLocaleString()} VEM`);

    // Step 2: Mint €10,000 into VEM
    logs.push('\n[STEP 1] Transferring €10,000 EUR into Vesuvius Mark (VEM)...');
    logs.push(' -> Compliance & KYC/AML Risk Check: PASSED (Risk Score: 0.02 LOW)');
    logs.push(' -> Bundesbank Reserve Collateral Allocation: €10,000 EUR Cash assigned');
    const mintRes = this.mintVem(10000);
    logs.push(` -> VEM Mint Request Approved. Issuance Hash: ${mintRes.auditHash}`);
    logs.push(` -> Euro PoS Epoch ${mintRes.epoch} Verified by 128 Validators in 2.8s`);
    logs.push(` -> Reserve Coverage updated to ${mintRes.reserveCoverage}%`);

    // Step 3: Transfer 5,000 VEM to another client
    logs.push('\n[STEP 2] Executing P2P VEM Transfer: 5,000 VEM to Baroness E. von Metternich (Vienna)...');
    if (vemAcc) {
      vemAcc.balance -= 5000;
      vemAcc.availableBalance -= 5000;
    }
    const transferHash = generateHash();
    logs.push(` -> Settlement Router: Cleared over Euro PoS Network (Hash: ${transferHash})`);
    logs.push(` -> Recipient Balance updated (+5,000 VEM) | Attestation Rate: 99.98%`);

    // Step 4: Redeem 2,000 VEM -> EUR
    logs.push('\n[STEP 3] Redeeming 2,000 VEM back to EUR account...');
    const redeemRes = this.redeemVem(2000);
    logs.push(` -> VEM Burn Executed. EUR Release Hash: ${redeemRes.auditHash}`);
    logs.push(` -> Bundesbank EUR Cash Released: +€2,000 EUR`);

    logs.push('\n>>> DEMO COMPLETED SUCCESSFULLY <<<');
    logs.push(`Final Client Holdings: EUR €${eurAcc?.balance.toLocaleString()} | VEM ${vemAcc?.balance.toLocaleString()} VEM`);

    return {
      success: true,
      logs,
      finalEurBalance: eurAcc?.balance,
      finalVemBalance: vemAcc?.balance,
    };
  },

  triggerEuroPosScenario(scenario: 'VALIDATOR_FAILURE' | 'LIQUIDITY_SHOCK' | 'FX_SHOCK' | 'RECOVERY') {
    if (scenario === 'VALIDATOR_FAILURE') {
      vesuviusStore.euroPos.status = 'DEGRADED';
      vesuviusStore.euroPos.activeValidators = 115;
      vesuviusStore.euroPos.networkLatencyMs = 85;
      vesuviusStore.euroPos.finalitySec = 5.4;
      vesuviusStore.euroPos.attestationRatePercent = 89.84;
      vesuviusStore.euroPos.validators[0].status = 'DEGRADED';
      vesuviusStore.euroPos.validators[1].status = 'OFFLINE';

      vesuviusStore.systemEvents.unshift({
        id: 'EVT-STRESS-' + Math.floor(1000 + Math.random() * 9000),
        timestamp: getFormattedTime(),
        type: 'EURO_POS_ATTESTATION',
        description: 'SCENARIO LAB: 13 Validator nodes offline simulated. Quorum maintained.',
        actor: 'EURO_POS_SCENARIO_ENGINE',
        auditHash: generateHash(),
      });
    } else if (scenario === 'LIQUIDITY_SHOCK') {
      vesuviusStore.vemMonetary.circulatingSupply -= 500_000_000;
      vesuviusStore.vemMonetary.reservesTotal -= 500_000_000;
      vesuviusStore.vemMonetary.reserveCoverage = 100.3;

      vesuviusStore.systemEvents.unshift({
        id: 'EVT-STRESS-' + Math.floor(1000 + Math.random() * 9000),
        timestamp: getFormattedTime(),
        type: 'RESERVE_STATE_UPDATED',
        description: 'SCENARIO LAB: €500M VEM redemption stress test absorbed. Coverage 100.3%.',
        actor: 'VESUVIUS_STRESS_ENGINE',
        auditHash: generateHash(),
      });
    } else if (scenario === 'FX_SHOCK') {
      const eurUsd = vesuviusStore.fxQuotes.find((q) => q.pair === 'EUR/USD');
      if (eurUsd) {
        eurUsd.bid = 0.9758;
        eurUsd.ask = 0.9762;
        eurUsd.change24hPercent = -10.0;
      }
      vesuviusStore.systemEvents.unshift({
        id: 'EVT-STRESS-' + Math.floor(1000 + Math.random() * 9000),
        timestamp: getFormattedTime(),
        type: 'RESERVE_STATE_UPDATED',
        description: 'SCENARIO LAB: Macro FX shock applied (EUR/USD -10.0%). Portfolio hedges active.',
        actor: 'RISK_ENGINE',
        auditHash: generateHash(),
      });
    } else if (scenario === 'RECOVERY') {
      vesuviusStore.euroPos.status = 'HEALTHY';
      vesuviusStore.euroPos.activeValidators = 127;
      vesuviusStore.euroPos.networkLatencyMs = 41;
      vesuviusStore.euroPos.finalitySec = 2.8;
      vesuviusStore.euroPos.attestationRatePercent = 99.98;
      vesuviusStore.euroPos.validators.forEach((v) => (v.status = 'ACTIVE'));

      const eurUsd = vesuviusStore.fxQuotes.find((q) => q.pair === 'EUR/USD');
      if (eurUsd) {
        eurUsd.bid = 1.0842;
        eurUsd.ask = 1.0845;
        eurUsd.change24hPercent = 0.18;
      }

      vesuviusStore.systemEvents.unshift({
        id: 'EVT-RECOVER-' + Math.floor(1000 + Math.random() * 9000),
        timestamp: getFormattedTime(),
        type: 'EURO_POS_ATTESTATION',
        description: 'Network restored to optimal state (128 Validators / 2.8s finality).',
        actor: 'VESUVIUS_CONTROL',
        auditHash: generateHash(),
      });
    }

    return vesuviusStore.euroPos;
  },
};
