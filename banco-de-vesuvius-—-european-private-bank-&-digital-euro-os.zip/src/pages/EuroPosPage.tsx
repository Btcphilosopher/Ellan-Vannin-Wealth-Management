import React, { useState } from 'react';
import { EuroPosNetworkState, ValidatorNode } from '../types/vesuvius';
import { Cpu, ShieldCheck, Activity, Globe, Zap, AlertTriangle, RefreshCw, CheckCircle2 } from 'lucide-react';

interface EuroPosPageProps {
  euroPos: EuroPosNetworkState;
  onRunScenario: (scenario: 'VALIDATOR_FAILURE' | 'LIQUIDITY_SHOCK' | 'FX_SHOCK' | 'RECOVERY') => void;
}

export const EuroPosPage: React.FC<EuroPosPageProps> = ({ euroPos, onRunScenario }) => {
  const [selectedValidator, setSelectedValidator] = useState<ValidatorNode | null>(euroPos.validators[0]);
  const [activeTab, setActiveTab] = useState<'VALIDATORS' | 'MAP' | 'SCENARIO_LAB'>('VALIDATORS');

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg">
        <div>
          <span className="text-xs font-mono text-emerald-400 uppercase tracking-widest">
            BANCO DE VESUVIUS PRIVATE DISTRIBUTED VALIDATION LAYER
          </span>
          <h1 className="text-xl font-mono text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            EURO PoS CONSENSUS TERMINAL
          </h1>
        </div>

        <div className="flex items-center gap-1 bg-[#0c0e12] p-1 rounded-lg border border-[#222830] text-xs font-mono">
          <button
            onClick={() => setActiveTab('VALIDATORS')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'VALIDATORS' ? 'bg-[#1f2634] text-emerald-300 font-bold' : 'text-slate-400'
            }`}
          >
            VALIDATOR SET
          </button>
          <button
            onClick={() => setActiveTab('MAP')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'MAP' ? 'bg-[#1f2634] text-emerald-300 font-bold' : 'text-slate-400'
            }`}
          >
            EUROPEAN MAP
          </button>
          <button
            onClick={() => setActiveTab('SCENARIO_LAB')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'SCENARIO_LAB' ? 'bg-[#1f2634] text-amber-300 font-bold' : 'text-slate-400'
            }`}
          >
            SCENARIO STRESS LAB
          </button>
        </div>
      </div>

      {/* Euro PoS Key Performance Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 font-mono">
        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <div className="text-[10px] text-slate-400 uppercase">NETWORK HEALTH</div>
          <div className="text-xl font-bold text-emerald-400 mt-1 flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>{euroPos.status}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Quorum Verified</div>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <div className="text-[10px] text-slate-400 uppercase">VALIDATORS ACTIVE</div>
          <div className="text-xl font-bold text-slate-100 mt-1">
            {euroPos.activeValidators} / {euroPos.totalValidators}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">12 European Hubs</div>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <div className="text-[10px] text-slate-400 uppercase">FINALITY LATENCY</div>
          <div className="text-xl font-bold text-sky-300 mt-1">{euroPos.finalitySec} sec</div>
          <div className="text-[11px] text-slate-400 mt-1">{euroPos.networkLatencyMs}ms Roundtrip</div>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <div className="text-[10px] text-slate-400 uppercase">TOTAL STAKED CAP</div>
          <div className="text-xl font-bold text-slate-100 mt-1">€{(euroPos.totalStakeEur / 1e6).toFixed(0)}m</div>
          <div className="text-[11px] text-emerald-400 mt-1">Bonded Collateral</div>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <div className="text-[10px] text-slate-400 uppercase">ATTESTATION RATE</div>
          <div className="text-xl font-bold text-emerald-300 mt-1">{euroPos.attestationRatePercent}%</div>
          <div className="text-[11px] text-slate-400 mt-1">0 Slashing Events</div>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <div className="text-[10px] text-slate-400 uppercase">CURRENT EPOCH</div>
          <div className="text-xl font-bold text-amber-200 mt-1">#{euroPos.currentEpoch}</div>
          <div className="text-[11px] text-slate-400 mt-1 truncate">{euroPos.currentStateRoot.substring(0, 10)}</div>
        </div>
      </div>

      {activeTab === 'VALIDATORS' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Validator Set Table */}
          <div className="lg:col-span-2 bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl font-mono text-xs">
            <h2 className="text-sm text-slate-200 font-semibold tracking-wider uppercase border-b border-[#202634] pb-3">
              PRIMARY EUROPEAN VALIDATOR NODES
            </h2>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[#202634] text-slate-400 uppercase text-[10px]">
                    <th className="py-2.5 px-2">NODE ID & LOCATION</th>
                    <th className="py-2.5 px-2">STAKE (€)</th>
                    <th className="py-2.5 px-2">POWER</th>
                    <th className="py-2.5 px-2">UPTIME</th>
                    <th className="py-2.5 px-2">LATENCY</th>
                    <th className="py-2.5 px-2">STATUS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1b212d]">
                  {euroPos.validators.map((val) => (
                    <tr
                      key={val.id}
                      onClick={() => setSelectedValidator(val)}
                      className={`cursor-pointer transition-colors ${
                        selectedValidator?.id === val.id ? 'bg-[#1a212f] text-slate-100' : 'hover:bg-[#161b26] text-slate-300'
                      }`}
                    >
                      <td className="py-3 px-2 font-semibold">
                        <div>{val.id} · {val.city}</div>
                        <div className="text-[10px] text-slate-400">{val.name}</div>
                      </td>
                      <td className="py-3 px-2 text-slate-200">
                        €{(val.stakeEur / 1e6).toFixed(0)}m
                      </td>
                      <td className="py-3 px-2 text-amber-300">{val.votingPowerPercent}%</td>
                      <td className="py-3 px-2 text-emerald-400">{val.uptimePercent}%</td>
                      <td className="py-3 px-2 text-sky-300">{val.latencyMs}ms</td>
                      <td className="py-3 px-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] ${
                            val.status === 'ACTIVE'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {val.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Selected Node Details Card */}
          {selectedValidator && (
            <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl font-mono text-xs">
              <div className="border-b border-[#202634] pb-3">
                <span className="text-emerald-400 text-[10px] uppercase tracking-widest">
                  VALIDATOR INSPECTION
                </span>
                <h3 className="text-base font-semibold text-slate-100 uppercase mt-0.5">
                  {selectedValidator.id} ({selectedValidator.city}, {selectedValidator.country})
                </h3>
              </div>

              <div className="space-y-3 text-slate-300">
                <div className="bg-[#161a24] p-3 rounded border border-[#232a3b]">
                  <span className="text-slate-400 text-[10px] block">HARDWARE SPECIFICATION:</span>
                  <span className="text-slate-100 font-semibold">{selectedValidator.hardware}</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-[#161a24] p-3 rounded border border-[#232a3b]">
                    <span className="text-slate-400 text-[10px] block">BONDED STAKE:</span>
                    <span className="text-amber-300 font-bold">€{(selectedValidator.stakeEur / 1e6).toFixed(1)}m</span>
                  </div>

                  <div className="bg-[#161a24] p-3 rounded border border-[#232a3b]">
                    <span className="text-slate-400 text-[10px] block">UPTIME RECORD:</span>
                    <span className="text-emerald-400 font-bold">{selectedValidator.uptimePercent}%</span>
                  </div>
                </div>

                <div className="bg-[#161a24] p-3 rounded border border-[#232a3b]">
                  <span className="text-slate-400 text-[10px] block">LAST ATTESTED EPOCH:</span>
                  <span className="text-sky-300 font-bold">#{selectedValidator.lastAttestedEpoch}</span>
                </div>

                <div className="bg-[#161a24] p-3 rounded border border-[#232a3b]">
                  <span className="text-slate-400 text-[10px] block">ATTESTATIONS PROCESSED:</span>
                  <span className="text-slate-100">{selectedValidator.attestationCount.toLocaleString()} Blocks</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'MAP' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl font-mono text-xs">
          <div className="border-b border-[#202634] pb-3 flex justify-between items-center">
            <div>
              <span className="text-emerald-400 text-[10px] uppercase tracking-widest">
                GEOGRAPHIC NETWORK DISTRIBUTION
              </span>
              <h2 className="text-base font-semibold text-slate-100 uppercase mt-0.5">
                EUROPEAN VALIDATOR INFRASTRUCTURE MAP
              </h2>
            </div>
            <span className="text-slate-400">12 EUROPEAN FINANCIAL CENTRES</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {euroPos.validators.map((node) => (
              <div
                key={node.id}
                onClick={() => setSelectedValidator(node)}
                className="bg-[#161a24] border border-[#242b3c] p-4 rounded-lg space-y-2 hover:border-emerald-400 transition-colors cursor-pointer"
              >
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-100">{node.city}</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                </div>
                <div className="text-[11px] text-slate-400">{node.id}</div>
                <div className="text-amber-300 font-semibold">€{(node.stakeEur / 1e6).toFixed(0)}M Stake</div>
                <div className="text-sky-300 text-[10px]">{node.latencyMs}ms Latency</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'SCENARIO_LAB' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl font-mono text-xs">
          <div className="border-b border-[#202634] pb-3">
            <span className="text-amber-400 text-[10px] uppercase tracking-widest">NETWORK STRESS & RESILIENCE SIMULATOR</span>
            <h2 className="text-base font-semibold text-slate-100 uppercase mt-0.5">
              EURO PoS FAILURE & SHOCK SCENARIO LAB
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <button
              onClick={() => onRunScenario('VALIDATOR_FAILURE')}
              className="p-4 bg-[#1e1a22] border border-amber-800/80 hover:bg-rose-950/60 text-amber-200 rounded-lg text-left transition-colors space-y-2"
            >
              <div className="font-bold flex items-center gap-1.5 text-rose-300">
                <AlertTriangle className="w-4 h-4" />
                <span>SIMULATE 10% NODE FAILURE</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Takes 13 validator nodes offline. Evaluates quorum retention and latency spikes.
              </p>
            </button>

            <button
              onClick={() => onRunScenario('LIQUIDITY_SHOCK')}
              className="p-4 bg-[#1e1a22] border border-amber-800/80 hover:bg-amber-950/60 text-amber-200 rounded-lg text-left transition-colors space-y-2"
            >
              <div className="font-bold flex items-center gap-1.5 text-amber-300">
                <Activity className="w-4 h-4" />
                <span>€500M VEM LIQUIDITY SHOCK</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Simulates massive simultaneous VEM redemption shock against Bundesbank reserves.
              </p>
            </button>

            <button
              onClick={() => onRunScenario('FX_SHOCK')}
              className="p-4 bg-[#1e1a22] border border-amber-800/80 hover:bg-sky-950/60 text-sky-200 rounded-lg text-left transition-colors space-y-2"
            >
              <div className="font-bold flex items-center gap-1.5 text-sky-300">
                <Zap className="w-4 h-4" />
                <span>EUR/USD -10.0% MACRO SHOCK</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Applies sudden European currency depreciation and tests hedging response.
              </p>
            </button>

            <button
              onClick={() => onRunScenario('RECOVERY')}
              className="p-4 bg-[#14201a] border border-emerald-800/80 hover:bg-emerald-900/60 text-emerald-200 rounded-lg text-left transition-colors space-y-2"
            >
              <div className="font-bold flex items-center gap-1.5 text-emerald-300">
                <RefreshCw className="w-4 h-4" />
                <span>RESTORE NETWORK HEALTH</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Restores all 128 nodes, optimal 2.8s finality, and normal FX market quotes.
              </p>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
