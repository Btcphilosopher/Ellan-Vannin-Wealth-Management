import React, { useState } from 'react';
import { BankAccount, BankTransaction, MoneyType } from '../types/vesuvius';
import { Landmark, Send, Download, Search, CheckCircle2, AlertTriangle, ArrowDownLeft, ArrowUpRight } from 'lucide-react';

interface BankingPageProps {
  accounts: BankAccount[];
  transactions: BankTransaction[];
  onTransfer: (params: {
    fromCurrency: MoneyType;
    recipientName: string;
    recipientIban: string;
    amount: number;
    reference: string;
    rail: 'SEPA_INSTANT' | 'SEPA' | 'DIGITAL_EURO_RAIL' | 'VEM_POS_SETTLEMENT' | 'INTERNAL_VESUVIUS';
  }) => void;
}

export const BankingPage: React.FC<BankingPageProps> = ({ accounts, transactions, onTransfer }) => {
  const [selectedAcc, setSelectedAcc] = useState<MoneyType>('EUR');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Payment Form state
  const [recipientName, setRecipientName] = useState('');
  const [recipientIban, setRecipientIban] = useState('');
  const [amount, setAmount] = useState('');
  const [reference, setReference] = useState('');
  const [paymentRail, setPaymentRail] = useState<'SEPA_INSTANT' | 'SEPA' | 'DIGITAL_EURO_RAIL' | 'VEM_POS_SETTLEMENT'>('SEPA_INSTANT');
  const [transferMsg, setTransferMsg] = useState<string | null>(null);

  const activeAccount = accounts.find((a) => a.currency === selectedAcc) || accounts[0];

  const handleExecutePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || Number(amount) <= 0) return;

    try {
      onTransfer({
        fromCurrency: selectedAcc,
        recipientName: recipientName || 'Siemens Energy AG',
        recipientIban: recipientIban || 'DE89100100109988776655',
        amount: Number(amount),
        reference: reference || 'Invoice Settlement',
        rail: paymentRail,
      });

      setTransferMsg(`Payment of €${Number(amount).toLocaleString()} executed successfully via ${paymentRail}.`);
      setAmount('');
      setRecipientName('');
      setRecipientIban('');
      setReference('');
      setTimeout(() => setTransferMsg(null), 5000);
    } catch (err: any) {
      alert(err.message || 'Payment execution failed.');
    }
  };

  const filteredTx = transactions.filter((tx) =>
    tx.counterparty.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const generateStatementDownload = () => {
    const header = "DATE,TIME,COUNTERPARTY,REFERENCE,AMOUNT,CURRENCY,RAIL,STATUS,AUDIT_HASH\n";
    const rows = transactions.map((t) => 
      `"${t.timestamp}","${t.counterparty}","${t.reference}",${t.amount},"${t.currency}","${t.paymentRail}","${t.status}","${t.auditHash}"`
    ).join("\n");

    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Banco_de_Vesuvius_Statement_${selectedAcc}_2026.csv`;
    a.click();
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg">
        <div>
          <span className="text-xs font-mono text-amber-400 uppercase tracking-widest">
            EUROPEAN COMMERCIAL & DIGITAL BANKING
          </span>
          <h1 className="text-xl font-mono text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            ACCOUNTS & SEPA PAYMENTS
          </h1>
        </div>

        <button
          onClick={generateStatementDownload}
          className="flex items-center gap-2 px-4 py-2 text-xs font-mono text-slate-200 bg-[#1a202c] border border-[#2d3648] hover:border-amber-400 rounded-md transition-colors"
        >
          <Download className="w-3.5 h-3.5 text-amber-400" />
          <span>DOWNLOAD AUDITED STATEMENT (.CSV)</span>
        </button>
      </div>

      {/* Account Selector Tabs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {accounts.map((acc) => {
          const isSelected = selectedAcc === acc.currency;
          return (
            <button
              key={acc.id}
              onClick={() => setSelectedAcc(acc.currency)}
              className={`p-5 rounded-xl border text-left transition-all font-mono space-y-3 ${
                isSelected
                  ? 'bg-[#181f2c] border-[#d4af37] shadow-lg ring-1 ring-[#d4af37]/30'
                  : 'bg-[#11141c] border-[#202634] hover:border-slate-500'
              }`}
            >
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 uppercase">{acc.accountType}</span>
                <span className={`px-2 py-0.5 rounded text-[10px] ${
                  acc.currency === 'EUR' ? 'bg-emerald-950 text-emerald-300' :
                  acc.currency === 'VEM' ? 'bg-amber-950 text-amber-300' : 'bg-sky-950 text-sky-300'
                }`}>
                  {acc.currency}
                </span>
              </div>
              <div className="text-2xl font-bold text-slate-100">
                {acc.currency === 'VEM' ? '' : '€'}
                {acc.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                {acc.currency === 'VEM' ? ' VEM' : ''}
              </div>
              <div className="text-[11px] text-slate-400 truncate">
                IBAN: {acc.iban}
              </div>
            </button>
          );
        })}
      </div>

      {/* Payment Initiation Form */}
      <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-5 shadow-xl">
        <div className="flex items-center justify-between border-b border-[#202634] pb-3">
          <h2 className="text-sm font-mono text-slate-200 font-semibold tracking-wider uppercase flex items-center gap-2">
            <Send className="w-4 h-4 text-amber-400" />
            <span>EXECUTE PAYMENT ({selectedAcc} RAIL)</span>
          </h2>
          <span className="text-xs font-mono text-slate-400">TARGET2 / SEPA INSTANT READY</span>
        </div>

        {transferMsg && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-700 text-emerald-300 rounded-lg text-xs font-mono flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{transferMsg}</span>
          </div>
        )}

        <form onSubmit={handleExecutePayment} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
          <div>
            <label className="block text-slate-400 mb-1">RECIPIENT NAME</label>
            <input
              type="text"
              placeholder="e.g. Siemens Energy AG Berlin"
              value={recipientName}
              onChange={(e) => setRecipientName(e.target.value)}
              className="w-full bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-amber-400"
              required
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">RECIPIENT IBAN / ACCOUNT</label>
            <input
              type="text"
              placeholder="DE89100100109988776655"
              value={recipientIban}
              onChange={(e) => setRecipientIban(e.target.value)}
              className="w-full bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-amber-400"
              required
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">AMOUNT ({selectedAcc})</label>
            <input
              type="number"
              placeholder="10000"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-amber-400"
              required
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">PAYMENT RAIL</label>
            <select
              value={paymentRail}
              onChange={(e: any) => setPaymentRail(e.target.value)}
              className="w-full bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-amber-400"
            >
              <option value="SEPA_INSTANT">SEPA Instant (10 sec)</option>
              <option value="SEPA">SEPA Standard Clearing</option>
              <option value="DIGITAL_EURO_RAIL">Digital Euro Intermediary Rail</option>
              <option value="VEM_POS_SETTLEMENT">Vesuvius Mark Euro PoS</option>
            </select>
          </div>

          <div className="md:col-span-3">
            <label className="block text-slate-400 mb-1">PAYMENT REFERENCE</label>
            <input
              type="text"
              placeholder="e.g. Q3 Commercial Supply Invoice Ref #88492"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              className="w-full bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-amber-400"
              required
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-[#d4af37] hover:bg-amber-400 text-black font-semibold rounded transition-colors"
            >
              AUTHORIZE & SUBMIT
            </button>
          </div>
        </form>
      </div>

      {/* Transaction History Table */}
      <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#202634] pb-4">
          <h2 className="text-sm font-mono text-slate-200 font-semibold tracking-wider uppercase">
            AUDITED TRANSACTION JOURNAL ({selectedAcc})
          </h2>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search counterparty or ref..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#181d28] border border-[#2a3344] rounded pl-9 pr-3 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse font-mono text-xs">
            <thead>
              <tr className="border-b border-[#202634] text-slate-400 uppercase text-[10px]">
                <th className="py-3 px-2">DATE & TIME</th>
                <th className="py-3 px-2">COUNTERPARTY & IBAN</th>
                <th className="py-3 px-2">REFERENCE</th>
                <th className="py-3 px-2">RAIL</th>
                <th className="py-3 px-2">RISK</th>
                <th className="py-3 px-2 text-right">AMOUNT</th>
                <th className="py-3 px-2 text-right">AUDIT HASH</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b212d]">
              {filteredTx.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500 italic">
                    No transactions matching search criteria.
                  </td>
                </tr>
              ) : (
                filteredTx.map((tx) => (
                  <tr key={tx.id} className="hover:bg-[#161b26] transition-colors">
                    <td className="py-3.5 px-2 text-slate-300 whitespace-nowrap">{tx.timestamp}</td>
                    <td className="py-3.5 px-2 font-medium text-slate-100">
                      <div>{tx.counterparty}</div>
                      <div className="text-[10px] text-slate-400">{tx.counterpartyIban}</div>
                    </td>
                    <td className="py-3.5 px-2 text-slate-300 max-w-xs truncate">{tx.reference}</td>
                    <td className="py-3.5 px-2">
                      <span className="px-2 py-0.5 text-[10px] bg-[#1a212e] text-sky-300 rounded border border-[#2c374d]">
                        {tx.paymentRail}
                      </span>
                    </td>
                    <td className="py-3.5 px-2">
                      <span className="text-emerald-400 flex items-center gap-1 text-[11px]">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>{tx.riskStatus}</span>
                      </span>
                    </td>
                    <td className={`py-3.5 px-2 text-right font-bold ${tx.amount >= 0 ? 'text-emerald-400' : 'text-slate-200'}`}>
                      {tx.amount >= 0 ? '+' : ''}€{Math.abs(tx.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-2 text-right text-slate-400 text-[10px]">
                      {tx.auditHash.substring(0, 10)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
