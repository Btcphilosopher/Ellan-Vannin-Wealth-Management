import React, { useState } from 'react';
import { ClientProfile, PortfolioState, BankAccount } from '../types/vesuvius';
import { Bot, Send, UserCheck, ShieldCheck, RefreshCw, MessageSquare } from 'lucide-react';

interface PrivateBankingPageProps {
  client: ClientProfile;
  portfolio: PortfolioState;
  accounts: BankAccount[];
}

interface ChatMessage {
  sender: 'USER' | 'AI';
  text: string;
  time: string;
}

export const PrivateBankingPage: React.FC<PrivateBankingPageProps> = ({
  client,
  portfolio,
  accounts,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'AI',
      text: `Good morning, ${client.name}. I am Vesuvius Intelligence, your private banking AI assistant grounded in Banco de Vesuvius live ledger and risk state. How may I assist your treasury or portfolio today?`,
      time: '09:00',
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const presets = [
    'How much of my portfolio is exposed to the euro?',
    'What happens to my portfolio if European rates rise 100bp?',
    'Show me my liquidity over the next twelve months.',
    'How much Vesuvius Mark do I hold?',
    "Explain today's portfolio movement.",
  ];

  const handleSendQuery = async (queryText?: string) => {
    const query = queryText || inputQuery;
    if (!query.trim()) return;

    const userMsg: ChatMessage = {
      sender: 'USER',
      text: query,
      time: new Date().toTimeString().split(' ')[0].substring(0, 5),
    };
    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/v1/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userQuery: query }),
      });
      const data = await res.json();

      const aiMsg: ChatMessage = {
        sender: 'AI',
        text: data.text || 'Unable to query Vesuvius Intelligence.',
        time: new Date().toTimeString().split(' ')[0].substring(0, 5),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      const aiErrorMsg: ChatMessage = {
        sender: 'AI',
        text: `[OBSERVED] System Query Error: ${err.message || 'Server connection issue'}.`,
        time: new Date().toTimeString().split(' ')[0].substring(0, 5),
      };
      setMessages((prev) => [...prev, aiErrorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8 font-mono text-xs">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg">
        <div>
          <span className="text-xs text-amber-400 uppercase tracking-widest">
            BERLIN PRIVATE BANKING DESK
          </span>
          <h1 className="text-xl text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            RELATIONSHIP MANAGEMENT & VESUVIUS INTELLIGENCE
          </h1>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-[#1a212e] border border-[#2d394e] rounded text-slate-200">
          <UserCheck className="w-4 h-4 text-amber-400" />
          <span>RM: {client.relationshipManager}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Client Profile & Credit Facilities Card */}
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-5 shadow-xl">
          <h2 className="text-sm text-slate-200 font-semibold uppercase border-b border-[#202634] pb-2">
            PRIVATE CLIENT DOSSIER
          </h2>

          <div className="space-y-3 text-slate-300">
            <div className="bg-[#161a24] p-3 rounded border border-[#232a3b]">
              <span className="text-slate-400 text-[10px] block">CLIENT IDENTITY:</span>
              <span className="text-slate-100 font-bold">{client.name} ({client.id})</span>
            </div>

            <div className="bg-[#161a24] p-3 rounded border border-[#232a3b]">
              <span className="text-slate-400 text-[10px] block">TAX RESIDENCE:</span>
              <span className="text-slate-100">{client.taxResidence}</span>
            </div>

            <div className="bg-[#161a24] p-3 rounded border border-[#232a3b]">
              <span className="text-slate-400 text-[10px] block">RISK SUITABILITY PROFILE:</span>
              <span className="text-amber-300 font-semibold">{client.riskProfile}</span>
            </div>

            <div className="bg-[#161a24] p-3 rounded border border-[#232a3b]">
              <span className="text-slate-400 text-[10px] block">APPROVED LOMBARD CREDIT FACILITY:</span>
              <span className="text-emerald-400 font-bold">€{portfolio.lombardCreditEur.toLocaleString()} (50% LTV)</span>
            </div>
          </div>
        </div>

        {/* AI Private Banker Chat Window */}
        <div className="lg:col-span-2 bg-[#11141c] border border-[#222838] p-6 rounded-xl flex flex-col justify-between space-y-4 shadow-xl min-h-[500px]">
          <div className="flex items-center justify-between border-b border-[#202634] pb-3">
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-amber-400" />
              <div>
                <h3 className="text-sm font-semibold text-slate-100 uppercase">
                  VESUVIUS INTELLIGENCE
                </h3>
                <p className="text-[10px] text-slate-400">
                  Grounded in live ledger, Euro PoS consensus & risk metrics
                </p>
              </div>
            </div>
            <span className="px-2 py-0.5 text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
              STATE GROUNDED
            </span>
          </div>

          {/* Chat Messages Log */}
          <div className="flex-1 bg-[#0a0c10] border border-[#1d222e] rounded-lg p-4 space-y-4 overflow-y-auto max-h-[380px] scrollbar-thin">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`flex flex-col ${m.sender === 'USER' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`p-3.5 rounded-lg max-w-[85%] font-mono leading-relaxed text-xs ${
                    m.sender === 'USER'
                      ? 'bg-[#1e2738] text-amber-200 border border-[#2f3d57]'
                      : 'bg-[#141822] text-slate-200 border border-[#222a3b]'
                  }`}
                >
                  <div className="text-[10px] font-bold text-slate-400 mb-1 flex items-center justify-between gap-4">
                    <span>{m.sender === 'USER' ? 'YOU' : 'VESUVIUS INTELLIGENCE'}</span>
                    <span>{m.time}</span>
                  </div>
                  <div className="whitespace-pre-wrap">{m.text}</div>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="text-amber-400 italic font-mono text-xs animate-pulse">
                Consulting live Vesuvius ledger & market risk models...
              </div>
            )}
          </div>

          {/* Query Presets */}
          <div className="flex items-center gap-2 overflow-x-auto py-1 text-[11px]">
            <span className="text-slate-400 shrink-0">PRESETS:</span>
            {presets.map((p, idx) => (
              <button
                key={idx}
                onClick={() => handleSendQuery(p)}
                className="px-2.5 py-1 bg-[#181e2b] hover:bg-[#232c3f] text-slate-300 border border-[#2a354c] rounded whitespace-nowrap transition-colors shrink-0"
              >
                {p}
              </button>
            ))}
          </div>

          {/* Input Field */}
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Ask Vesuvius Intelligence about your holdings, EUR risk, or VEM reserves..."
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendQuery()}
              className="flex-1 bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-amber-400"
            />
            <button
              onClick={() => handleSendQuery()}
              className="px-4 py-2.5 bg-[#d4af37] hover:bg-amber-400 text-black font-bold rounded transition-colors flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>QUERY</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
