import React, { useState } from 'react';
import { VemMonetaryState, BankAccount } from '../types/vesuvius';
import { Coins, ShieldCheck, Flame, RefreshCw, Layers, ArrowUpRight, ArrowDownRight, AlertTriangle } from 'lucide-react';

interface VesuviusMarkPageProps {
  vemState: VemMonetaryState;
  accounts: BankAccount[];
  onMint: (amountEur: number) => void;
  onRedeem: (amountVem: number) => void;
}

export const VesuviusMarkPage: React.FC<VesuviusMarkPageProps> = ({
  vemState,
  accounts,
  onMint,
  onRedeem,
}) => {
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'MINT' | 'REDEEM' | 'STRESS'>('DASHBOARD');

  // Minting form state
  const [mintAmount, setMintAmount] = useState('10000');
  const [mintPurpose, setMintPurpose] = useState('Treasury Settlement Allocation');
  const [isMinting, setIsMinting] = useState(false);

  // Redemption form state
  const [redeemAmount, setRedeemAmount] = useState('5000');
  const [isRedeeming, setIsRedeeming] = useState(false);

  // Stress lab state
  const [stressShock, setStressShock] = useState('500');
  const [stressResult, setStressResult] = useState<any>(null);

  const eurAcc = accounts.find((a) => a.currency === 'EUR');
  const vemAcc = accounts.find((a) => a.currency === 'VEM');

  const handleExecuteMint = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(mintAmount);
    if (!amt || amt <= 0) return;

    setIsMinting(true);
    setTimeout(() => {
      try {
        onMint(amt);
        setIsMinting(false);
        alert(`Successfully minted ${amt.toLocaleString()} VEM! Euro PoS Attestation confirmed.`);
      } catch (err: any) {
        setIsMinting(false);
        alert(err.message || 'Minting failed.');
      }
    }, 800);
  };

  const handleExecuteRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(redeemAmount);
    if (!amt || amt <= 0) return;

    setIsRedeeming(true);
    setTimeout(() => {
      try {
        onRedeem(amt);
        setIsRedeeming(false);
        alert(`Successfully burned ${amt.toLocaleString()} VEM and released €${amt.toLocaleString()} EUR Cash!`);
      } catch (err: any) {
        setIsRedeeming(false);
        alert(err.message || 'Redemption failed.');
      }
    }, 800);
  };

  const handleRunStressTest = () => {
    const shockMillions = Number(stressShock);
    const newSupply = Math.max(1, vemState.circulatingSupply - shockMillions * 1e6);
    const newReserves = Math.max(1, vemState.reservesTotal - shockMillions * 1e6);
    const newCoverage = Number(((newReserves / newSupply) * 100).toFixed(2));

    setStressResult({
      shockMillions,
      remainingSupplyBn: (newSupply / 1e9).toFixed(3),
      remainingReservesBn: (newReserves / 1e9).toFixed(3),
      newCoverage,
      timeToLiquidateHours: 2.8,
      expectedPriceDeviationPercent: 0.04,
      liquidityStatus: 'OPTIMAL (High Quality Liquid Asset Buffer Unimpaired)',
    });
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg">
        <div>
          <span className="text-xs font-mono text-amber-400 uppercase tracking-widest">
            PRIVATE EURO-DENOMINATED SETTLEMENT STABLECOIN
          </span>
          <h1 className="text-xl font-mono text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            VESUVIUS MARK (VEM) MONETARY SYSTEM
          </h1>
        </div>

        <div className="flex items-center gap-1 bg-[#0c0e12] p-1 rounded-lg border border-[#222830] text-xs font-mono">
          <button
            onClick={() => setActiveTab('DASHBOARD')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'DASHBOARD' ? 'bg-[#1f2634] text-amber-300 font-bold' : 'text-slate-400'
            }`}
          >
            MONETARY DASHBOARD
          </button>
          <button
            onClick={() => setActiveTab('MINT')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'MINT' ? 'bg-[#1f2634] text-amber-300 font-bold' : 'text-slate-400'
            }`}
          >
            MINTING ENGINE
          </button>
          <button
            onClick={() => setActiveTab('REDEEM')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'REDEEM' ? 'bg-[#1f2634] text-amber-300 font-bold' : 'text-slate-400'
            }`}
          >
            REDEMPTION ENGINE
          </button>
          <button
            onClick={() => setActiveTab('STRESS')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'STRESS' ? 'bg-[#1f2634] text-amber-300 font-bold' : 'text-slate-400'
            }`}
          >
            STRESS LAB
          </button>
        </div>
      </div>

      {/* Primary Key Monetary Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono">
        <div className="bg-[#121620] border border-[#222836] p-5 rounded-xl shadow-md">
          <div className="text-[10px] text-slate-400 uppercase">PEG PRICE</div>
          <div className="text-2xl font-bold text-slate-100 mt-1">€{vemState.priceEur.toFixed(4)}</div>
          <div className="text-[11px] text-emerald-400 mt-1">Target: 1 VEM = €1.0000</div>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-5 rounded-xl shadow-md">
          <div className="text-[10px] text-amber-400 uppercase">CIRCULATING SUPPLY</div>
          <div className="text-2xl font-bold text-amber-200 mt-1">
            €{(vemState.circulatingSupply / 1e9).toFixed(3)}bn
          </div>
          <div className="text-[11px] text-slate-400 mt-1">{vemState.activeWallets.toLocaleString()} Active Wallets</div>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-5 rounded-xl shadow-md">
          <div className="text-[10px] text-emerald-400 uppercase">TOTAL RESERVES</div>
          <div className="text-2xl font-bold text-emerald-300 mt-1">
            €{(vemState.reservesTotal / 1e9).toFixed(3)}bn
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">Coverage: {vemState.reserveCoverage}%</div>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-5 rounded-xl shadow-md">
          <div className="text-[10px] text-slate-400 uppercase">SETTLEMENT NETWORK</div>
          <div className="text-2xl font-bold text-sky-300 mt-1">{vemState.validatorCount} Nodes</div>
          <div className="text-[11px] text-slate-400 mt-1">Euro PoS Consensus</div>
        </div>
      </div>

      {activeTab === 'DASHBOARD' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Reserve Composition Breakdown */}
          <div className="lg:col-span-2 bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl font-mono">
            <div className="flex justify-between items-center border-b border-[#202634] pb-3">
              <h2 className="text-sm text-slate-200 font-semibold tracking-wider uppercase flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>VESUVIUS MARK RESERVE COMPOSITION (AUDITED 1:1 BACKING)</span>
              </h2>
              <span className="text-xs text-emerald-400">BUNDESBANK & CLEARSTREAM CUSTODY</span>
            </div>

            <div className="space-y-4">
              {vemState.reserves.map((res) => (
                <div key={res.id} className="bg-[#161a24] border border-[#232a3b] p-4 rounded-lg space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-100 font-semibold">{res.name}</span>
                    <span className="text-amber-300 font-bold">
                      €{res.amountMillions}M ({res.percentage}%)
                    </span>
                  </div>
                  <div className="w-full bg-[#10131a] h-2 rounded-full overflow-hidden">
                    <div className="bg-amber-400 h-full" style={{ width: `${res.percentage}%` }} />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400 pt-1">
                    <span>Yield: {res.yieldPercent}% · Rating: {res.rating}</span>
                    <span>Custodian: {res.custodian}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* User Holdings & Quick Mint */}
          <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-5 font-mono text-xs shadow-xl">
            <h3 className="text-sm font-semibold text-amber-300 uppercase tracking-wider border-b border-[#202634] pb-2">
              YOUR VESUVIUS MARK WALLET
            </h3>

            <div className="bg-[#181e2a] border border-[#283246] p-4 rounded-lg space-y-2">
              <div className="text-slate-400 text-[10px]">CURRENT WALLET BALANCE</div>
              <div className="text-2xl font-bold text-amber-200">
                {vemAcc?.balance.toLocaleString()} VEM
              </div>
              <div className="text-slate-400 text-[11px]">Equivalent Value: €{vemAcc?.balance.toLocaleString()} EUR</div>
            </div>

            <div className="space-y-2 pt-2 border-t border-[#202634]">
              <div className="text-slate-300 font-medium">QUICK ISSUANCE & REDEMPTION</div>
              <p className="text-slate-400 leading-relaxed text-[11px]">
                Convert EUR cash into VEM or burn VEM for instant EUR cash release over the Euro PoS settlement network.
              </p>
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => setActiveTab('MINT')}
                  className="py-2.5 px-3 bg-[#d4af37] text-black font-semibold rounded hover:bg-amber-400 transition-colors text-center"
                >
                  MINT VEM
                </button>
                <button
                  onClick={() => setActiveTab('REDEEM')}
                  className="py-2.5 px-3 bg-[#1e2636] text-slate-200 font-semibold rounded hover:bg-[#283348] border border-[#2e3b52] transition-colors text-center"
                >
                  REDEEM VEM
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'MINT' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl max-w-2xl mx-auto font-mono text-xs">
          <div className="border-b border-[#202634] pb-3">
            <span className="text-amber-400 text-[10px] uppercase tracking-widest">MONETARY ISSUANCE CONSOLE</span>
            <h2 className="text-base font-semibold text-slate-100 uppercase mt-0.5">
              MINT VESUVIUS MARK (VEM)
            </h2>
          </div>

          <form onSubmit={handleExecuteMint} className="space-y-4">
            <div>
              <label className="block text-slate-400 mb-1">ISSUANCE AMOUNT IN EUR (€)</label>
              <input
                type="number"
                value={mintAmount}
                onChange={(e) => setMintAmount(e.target.value)}
                className="w-full bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-amber-400 text-sm"
                required
              />
              <div className="text-[11px] text-slate-400 mt-1">
                Available EUR Balance: €{(eurAcc?.balance || 0).toLocaleString()}
              </div>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">RESERVE SOURCE / PURPOSE</label>
              <input
                type="text"
                value={mintPurpose}
                onChange={(e) => setMintPurpose(e.target.value)}
                className="w-full bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <div className="bg-[#161b26] p-4 rounded-lg border border-[#232c3d] space-y-2 text-[11px] text-slate-300">
              <div className="text-amber-300 font-semibold">ISSUANCE PIPELINE PIPELINE STEPS:</div>
              <div className="flex items-center gap-2">✓ 1. EUR Reserve Check & Collateral Lock</div>
              <div className="flex items-center gap-2">✓ 2. Automated Compliance & Risk Assessment</div>
              <div className="flex items-center gap-2">✓ 3. VEM Token Minting & Ledger Entry</div>
              <div className="flex items-center gap-2">✓ 4. Euro PoS Consensus Network Attestation</div>
            </div>

            <button
              type="submit"
              disabled={isMinting}
              className="w-full py-3 bg-[#d4af37] hover:bg-amber-400 text-black font-bold rounded transition-colors text-sm"
            >
              {isMinting ? 'EXECUTING ISSUANCE PIPELINE...' : 'EXECUTE MINT & ATTEST ON EURO PoS'}
            </button>
          </form>
        </div>
      )}

      {activeTab === 'REDEEM' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl max-w-2xl mx-auto font-mono text-xs">
          <div className="border-b border-[#202634] pb-3">
            <span className="text-amber-400 text-[10px] uppercase tracking-widest">REDEMPTION & BURN CONSOLE</span>
            <h2 className="text-base font-semibold text-slate-100 uppercase mt-0.5">
              REDEEM VESUVIUS MARK FOR EUR CASH
            </h2>
          </div>

          <form onSubmit={handleExecuteRedeem} className="space-y-4">
            <div>
              <label className="block text-slate-400 mb-1">REDEMPTION AMOUNT (VEM)</label>
              <input
                type="number"
                value={redeemAmount}
                onChange={(e) => setRedeemAmount(e.target.value)}
                className="w-full bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-amber-400 text-sm"
                required
              />
              <div className="text-[11px] text-slate-400 mt-1">
                Available VEM Balance: {(vemAcc?.balance || 0).toLocaleString()} VEM
              </div>
            </div>

            <div className="bg-[#161b26] p-4 rounded-lg border border-[#232c3d] space-y-2 text-[11px] text-slate-300">
              <div className="text-amber-300 font-semibold">REDEMPTION PIPELINE STEPS:</div>
              <div className="flex items-center gap-2">✓ 1. VEM Balance Verification</div>
              <div className="flex items-center gap-2">✓ 2. Cryptographic VEM Token Burn</div>
              <div className="flex items-center gap-2">✓ 3. Bundesbank EUR Cash Release to Account</div>
              <div className="flex items-center gap-2">✓ 4. Reserve Reconciliation & Coverage Audit</div>
            </div>

            <button
              type="submit"
              disabled={isRedeeming}
              className="w-full py-3 bg-[#d4af37] hover:bg-amber-400 text-black font-bold rounded transition-colors text-sm"
            >
              {isRedeeming ? 'BURNING VEM & RELEASING EUR...' : 'BURN VEM & RELEASE EUR CASH'}
            </button>
          </form>
        </div>
      )}

      {activeTab === 'STRESS' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl font-mono text-xs">
          <div className="border-b border-[#202634] pb-3">
            <span className="text-amber-400 text-[10px] uppercase tracking-widest">STRESS TESTING & SIMULATION LAB</span>
            <h2 className="text-base font-semibold text-slate-100 uppercase mt-0.5">
              VEM MONETARY SHOCK & REDEMPTION SIMULATOR
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="block text-slate-400">SIMULATED REDEMPTION SHOCK (€ MILLIONS)</label>
              <input
                type="number"
                value={stressShock}
                onChange={(e) => setStressShock(e.target.value)}
                className="w-full bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>
            <div className="flex items-end">
              <button
                onClick={handleRunStressTest}
                className="w-full py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded transition-colors"
              >
                RUN REDEMPTION STRESS TEST
              </button>
            </div>
          </div>

          {stressResult && (
            <div className="bg-[#161a24] border border-[#232a3b] p-5 rounded-lg space-y-3">
              <h3 className="text-amber-300 font-semibold uppercase">
                STRESS TEST RESULTS (€{stressResult.shockMillions}M REDEMPTION SHOCK)
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-slate-300 pt-2 border-t border-[#222a3a]">
                <div>
                  <span className="text-slate-400 text-[10px] block">NEW CIRCULATING SUPPLY</span>
                  <span className="text-sm font-bold text-slate-100">€{stressResult.remainingSupplyBn}bn</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">NEW RESERVES TOTAL</span>
                  <span className="text-sm font-bold text-slate-100">€{stressResult.remainingReservesBn}bn</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">NEW COVERAGE RATIO</span>
                  <span className="text-sm font-bold text-emerald-400">{stressResult.newCoverage}%</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">TIME TO LIQUIDATE</span>
                  <span className="text-sm font-bold text-sky-300">{stressResult.timeToLiquidateHours} Hours</span>
                </div>
              </div>
              <div className="pt-2 text-[11px] text-slate-400">
                Status: <span className="text-emerald-400 font-semibold">{stressResult.liquidityStatus}</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
