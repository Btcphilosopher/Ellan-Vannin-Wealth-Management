import React, { useState } from 'react';
import {
  BankAccount,
  PortfolioState,
  VemMonetaryState,
  EuroPosNetworkState,
  ClientProfile,
  SystemEvent,
} from '../types/vesuvius';
import {
  TrendingUp,
  ShieldCheck,
  ArrowUpRight,
  ArrowDownRight,
  Coins,
  Cpu,
  RefreshCw,
  Building2,
  ChevronRight,
  Play,
} from 'lucide-react';

interface OverviewPageProps {
  client: ClientProfile;
  accounts: BankAccount[];
  portfolio: PortfolioState;
  vemState: VemMonetaryState;
  euroPos: EuroPosNetworkState;
  events: SystemEvent[];
  onRunDemo: () => void;
  isDemoRunning: boolean;
  demoLogs: string[];
  setActiveTab: (tab: string) => void;
}

export const OverviewPage: React.FC<OverviewPageProps> = ({
  client,
  accounts,
  portfolio,
  vemState,
  euroPos,
  events,
  onRunDemo,
  isDemoRunning,
  demoLogs,
  setActiveTab,
}) => {
  const [viewScope, setViewScope] = useState<'CLIENT' | 'INSTITUTIONAL'>('CLIENT');

  const eurAcc = accounts.find((a) => a.currency === 'EUR');
  const deuroAcc = accounts.find((a) => a.currency === 'DIGITAL_EURO');
  const vemAcc = accounts.find((a) => a.currency === 'VEM');

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8">
      {/* Scope Switcher Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#12161f] border border-[#222836] p-4 rounded-xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[#1a202c] border border-[#2a3244] flex items-center justify-center text-[#d4af37]">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-mono tracking-wider text-slate-200 uppercase">
              BANCO DE VESUVIUS · BERLIN HEADQUARTERS
            </h1>
            <p className="text-xs text-slate-400">
              European Private Bank & Digital Euro Operating System
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-[#0c0e12] p-1 rounded-lg border border-[#1e232d] text-xs font-mono">
          <button
            onClick={() => setViewScope('CLIENT')}
            className={`px-4 py-2 rounded-md font-medium transition-colors ${
              viewScope === 'CLIENT'
                ? 'bg-[#1e2533] text-amber-300 border border-[#2f384c]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            PRIVATE CLIENT WEALTH
          </button>
          <button
            onClick={() => setViewScope('INSTITUTIONAL')}
            className={`px-4 py-2 rounded-md font-medium transition-colors ${
              viewScope === 'INSTITUTIONAL'
                ? 'bg-[#1e2533] text-sky-300 border border-[#2f384c]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            VESUVIUS CONTROL (INSTITUTIONAL)
          </button>
        </div>
      </div>

      {viewScope === 'CLIENT' ? (
        <>
          {/* PRIVATE CLIENT WEALTH DASHBOARD */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Wealth Overview Card */}
            <div className="lg:col-span-2 bg-[#11141b] border border-[#202632] rounded-xl p-6 relative overflow-hidden shadow-xl">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <div className="text-xs font-mono text-slate-400 uppercase tracking-widest">
                    GOOD MORNING
                  </div>
                  <h2 className="text-xl font-medium text-slate-100 tracking-tight mt-0.5">
                    {client.name}
                  </h2>
                  <div className="text-xs text-amber-400/90 font-mono mt-1 flex items-center gap-2">
                    <span>{client.residence}</span>
                    <span>·</span>
                    <span>Risk: {client.riskProfile}</span>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <div className="text-xs text-slate-400 uppercase">TOTAL WEALTH</div>
                  <div className="text-3xl font-bold text-slate-100 tracking-tight mt-0.5">
                    €{client.totalWealthEur.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                  <div className="text-xs text-emerald-400 flex items-center justify-end gap-1 mt-1 font-semibold">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>+{portfolio.todayChangeEur.toLocaleString()} EUR (+{portfolio.ytdReturnPercent}% YTD)</span>
                  </div>
                </div>
              </div>

              {/* Wealth Breakdown Metrics */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-[#1e232e]">
                <div className="bg-[#161a23] p-4 rounded-lg border border-[#232936]">
                  <div className="text-[11px] font-mono text-slate-400 uppercase">LIQUID ASSETS</div>
                  <div className="text-xl font-bold text-slate-100 mt-1 font-mono">
                    €{client.totalWealthEur > 4800000 ? (eurAcc?.balance || 842190).toLocaleString() : '842,190.00'}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">EUR + VEM + Digital Euro</div>
                </div>

                <div className="bg-[#161a23] p-4 rounded-lg border border-[#232936]">
                  <div className="text-[11px] font-mono text-slate-400 uppercase">INVESTMENTS</div>
                  <div className="text-xl font-bold text-slate-100 mt-1 font-mono">
                    €{portfolio.investmentsEur.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                  <div className="text-[11px] text-emerald-400 mt-1 font-mono">Sharpe: {portfolio.sharpeRatio}</div>
                </div>

                <div className="bg-[#161a23] p-4 rounded-lg border border-[#232936]">
                  <div className="text-[11px] font-mono text-slate-400 uppercase">PROPERTY & REAL ASSETS</div>
                  <div className="text-xl font-bold text-slate-100 mt-1 font-mono">
                    €{portfolio.propertyEur.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">Berlin & Zurich Commercial</div>
                </div>
              </div>
            </div>

            {/* Berlin Office Architectural Showcase */}
            <div className="bg-[#11141b] border border-[#202632] rounded-xl overflow-hidden flex flex-col shadow-xl">
              <div className="relative h-44 overflow-hidden">
                <img
                  src="/src/assets/images/potsdamer_platz_office_1790514583447.jpg"
                  alt="Banco de Vesuvius Berlin HQ"
                  className="w-full h-full object-cover brightness-90 hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#11141b] via-[#11141b]/40 to-transparent" />
                <div className="absolute bottom-3 left-4 right-4 flex justify-between items-end">
                  <div>
                    <span className="text-[10px] font-mono text-amber-300 uppercase tracking-widest bg-black/60 px-2 py-0.5 rounded border border-amber-500/30">
                      POTSDAMER PLATZ BERLIN
                    </span>
                    <h3 className="text-sm font-semibold text-slate-100 mt-1">
                      Vesuvius Private Desk
                    </h3>
                  </div>
                </div>
              </div>
              <div className="p-4 flex-1 flex flex-col justify-between text-xs font-mono text-slate-300 bg-[#0e1016]">
                <p className="text-slate-400 leading-relaxed">
                  Headquartered in Potsdamer Platz, operating private banking, Eurosystem Digital Euro services, and Vesuvius Mark settlement infrastructure across 12 European financial hubs.
                </p>
                <div className="pt-3 border-t border-[#1e232e] flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">RELATIONSHIP MANAGER:</span>
                  <span className="text-amber-200 font-semibold">{client.relationshipManager}</span>
                </div>
              </div>
            </div>
          </div>

          {/* LIQUIDITY & MULTI-MONEY BREAKDOWN */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-mono tracking-wider text-slate-200 uppercase flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-400" />
                <span>LIQUIDITY & MULTI-MONEY POSITIONS</span>
              </h3>
              <button
                onClick={() => setActiveTab('ACCOUNTS')}
                className="text-xs text-amber-400 hover:text-amber-300 font-mono flex items-center gap-1"
              >
                <span>Manage Accounts</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {/* EUR Account */}
              <div className="bg-[#121620] border border-[#222836] p-5 rounded-xl space-y-4 hover:border-slate-600 transition-all shadow-md">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">
                      COMMERCIAL BANK MONEY
                    </span>
                    <h4 className="text-base font-semibold text-slate-100 mt-0.5">EUR Current Account</h4>
                  </div>
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
                    SEPA INSTANT
                  </span>
                </div>
                <div>
                  <div className="text-2xl font-bold font-mono text-slate-100">
                    €{eurAcc?.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                  <div className="text-xs font-mono text-slate-400 mt-1 truncate">
                    IBAN: {eurAcc?.iban}
                  </div>
                </div>
                <div className="pt-3 border-t border-[#1d2330] flex justify-between text-xs font-mono">
                  <span className="text-slate-400">Status:</span>
                  <span className="text-emerald-400 font-medium">ACTIVE / TARGET2</span>
                </div>
              </div>

              {/* Vesuvius Mark VEM */}
              <div className="bg-[#121620] border border-[#222836] p-5 rounded-xl space-y-4 hover:border-amber-500/50 transition-all shadow-md">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono text-amber-400 uppercase tracking-widest">
                      PRIVATE EURO STABLECOIN
                    </span>
                    <h4 className="text-base font-semibold text-slate-100 mt-0.5">Vesuvius Mark (VEM)</h4>
                  </div>
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-amber-950 text-amber-300 border border-amber-800 rounded">
                    1 VEM = €1.00
                  </span>
                </div>
                <div>
                  <div className="text-2xl font-bold font-mono text-amber-200">
                    {vemAcc?.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })} VEM
                  </div>
                  <div className="text-xs font-mono text-slate-400 mt-1">
                    100.7% Bundesbank Cash/Bund Reserve Backing
                  </div>
                </div>
                <div className="pt-3 border-t border-[#1d2330] flex justify-between text-xs font-mono">
                  <span className="text-slate-400">Settlement Rail:</span>
                  <span className="text-amber-300 font-medium">EURO PoS (128 NODES)</span>
                </div>
              </div>

              {/* Digital Euro */}
              <div className="bg-[#121620] border border-[#222836] p-5 rounded-xl space-y-4 hover:border-sky-500/50 transition-all shadow-md">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono text-sky-400 uppercase tracking-widest">
                      PUBLIC EUROSYSTEM CBDC
                    </span>
                    <h4 className="text-base font-semibold text-slate-100 mt-0.5">Digital Euro Wallet</h4>
                  </div>
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-sky-950 text-sky-300 border border-sky-800 rounded">
                    LIMIT €3,000
                  </span>
                </div>
                <div>
                  <div className="text-2xl font-bold font-mono text-sky-200">
                    €{deuroAcc?.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                  <div className="text-xs font-mono text-slate-400 mt-1">
                    Linked to Commercial EUR Account
                  </div>
                </div>
                <div className="pt-3 border-t border-[#1d2330] flex justify-between text-xs font-mono">
                  <span className="text-slate-400">Offline Subsystem:</span>
                  <span className="text-sky-300 font-medium">READY (€180.00 OFFLINE)</span>
                </div>
              </div>
            </div>
          </div>

          {/* FLAGSHIP DEMO EXECUTION PANEL & RECENT MOVEMENTS */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Flagship End-to-End Berlin Simulation */}
            <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono text-amber-400 uppercase tracking-widest">
                    FLAGSHIP DEMO SIMULATOR
                  </span>
                  <h3 className="text-base font-semibold text-slate-100 mt-0.5">
                    End-to-End Berlin Transaction Flow
                  </h3>
                </div>
                <button
                  onClick={onRunDemo}
                  disabled={isDemoRunning}
                  className="flex items-center gap-2 px-4 py-2 text-xs font-mono font-semibold text-black bg-[#d4af37] hover:bg-amber-400 rounded-md transition-all focus:outline-none shadow-md disabled:opacity-50"
                >
                  <Play className={`w-3.5 h-3.5 ${isDemoRunning ? 'animate-spin' : ''}`} />
                  <span>{isDemoRunning ? 'EXECUTING...' : 'RUN DEMO FLOW'}</span>
                </button>
              </div>

              <p className="text-xs text-slate-400 font-mono leading-relaxed">
                Simulates real-time client transaction: Transfer €10,000 EUR → Mint VEM → Attest on 128 Euro PoS Nodes → P2P Transfer 5,000 VEM → Redeem 2,000 VEM for EUR cash release with Bundesbank reserve adjustments.
              </p>

              <div className="bg-[#090b0f] border border-[#1d222e] rounded-lg p-4 font-mono text-xs text-slate-300 max-h-56 overflow-y-auto space-y-1.5 scrollbar-thin">
                {demoLogs.length === 0 ? (
                  <div className="text-slate-400 italic">
                    Click "RUN DEMO FLOW" above to execute genuine end-to-end multi-money settlement simulation...
                  </div>
                ) : (
                  demoLogs.map((log, idx) => (
                    <div
                      key={idx}
                      className={
                        log.startsWith('>>>')
                          ? 'text-amber-300 font-bold'
                          : log.startsWith('[STEP')
                          ? 'text-sky-300 font-semibold mt-2'
                          : log.startsWith(' ->')
                          ? 'text-slate-300 pl-3'
                          : 'text-slate-400'
                      }
                    >
                      {log}
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Today's Transactions & Ledger Activity */}
            <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-[#1d222e] pb-3">
                <h3 className="text-sm font-mono tracking-wider text-slate-200 uppercase">
                  TODAY'S LEDGER ACTIVITY
                </h3>
                <span className="text-xs font-mono text-slate-400">REAL-TIME AUDIT HASHED</span>
              </div>

              <div className="space-y-3">
                {events.slice(0, 4).map((evt) => (
                  <div
                    key={evt.id}
                    className="flex items-center justify-between p-3 bg-[#151924] border border-[#232a3b] rounded-lg text-xs font-mono"
                  >
                    <div className="space-y-0.5">
                      <div className="text-slate-200 font-medium">{evt.description}</div>
                      <div className="text-slate-400 text-[11px] flex items-center gap-2">
                        <span>{evt.timestamp}</span>
                        <span>·</span>
                        <span className="text-sky-300">{evt.actor}</span>
                      </div>
                    </div>
                    {evt.amountEur && (
                      <div className="text-emerald-400 font-semibold text-right">
                        +€{evt.amountEur.toLocaleString()}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      ) : (
        <>
          {/* INSTITUTIONAL VESUVIUS CONTROL DASHBOARD */}
          <div className="space-y-6">
            <div className="border-b border-[#222836] pb-4">
              <h2 className="text-xl font-mono text-slate-100 font-semibold tracking-wider uppercase">
                VESUVIUS CONTROL · MASTER INSTITUTIONAL TERMINAL
              </h2>
              <p className="text-xs font-mono text-slate-400 mt-1">
                Real-time European financial network operating metrics across 128 consensus nodes & Bundesbank reserves.
              </p>
            </div>

            {/* Master Metrics Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
                <div className="text-[10px] font-mono text-slate-400 uppercase">TOTAL CLIENT ASSETS</div>
                <div className="text-2xl font-bold font-mono text-slate-100 mt-1">€84.2bn</div>
                <div className="text-[11px] text-emerald-400 mt-1 font-mono">+4.2% YoY</div>
              </div>

              <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
                <div className="text-[10px] font-mono text-slate-400 uppercase">EUR LIQUIDITY BUFFER</div>
                <div className="text-2xl font-bold font-mono text-slate-100 mt-1">€18.4bn</div>
                <div className="text-[11px] text-sky-400 mt-1 font-mono">Target2 Eligible</div>
              </div>

              <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
                <div className="text-[10px] font-mono text-amber-400 uppercase">VEM CIRCULATING SUPPLY</div>
                <div className="text-2xl font-bold font-mono text-amber-200 mt-1">
                  €{(vemState.circulatingSupply / 1e9).toFixed(2)}bn
                </div>
                <div className="text-[11px] text-amber-300 mt-1 font-mono">24h Vol: €184.2m</div>
              </div>

              <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
                <div className="text-[10px] font-mono text-emerald-400 uppercase">VEM COVERAGE RATIO</div>
                <div className="text-2xl font-bold font-mono text-emerald-300 mt-1">
                  {vemState.reserveCoverage}%
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">Reserves: €{(vemState.reservesTotal / 1e9).toFixed(2)}bn</div>
              </div>

              <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
                <div className="text-[10px] font-mono text-slate-400 uppercase">EURO PoS VALIDATORS</div>
                <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
                  {euroPos.activeValidators} / {euroPos.totalValidators}
                </div>
                <div className="text-[11px] text-emerald-400 mt-1 font-mono">Status: {euroPos.status}</div>
              </div>

              <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
                <div className="text-[10px] font-mono text-slate-400 uppercase">NETWORK FINALITY</div>
                <div className="text-2xl font-bold font-mono text-sky-300 mt-1">
                  {euroPos.finalitySec} sec
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">Latency: {euroPos.networkLatencyMs}ms</div>
              </div>

              <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
                <div className="text-[10px] font-mono text-slate-400 uppercase">PAYMENTS TODAY</div>
                <div className="text-2xl font-bold font-mono text-slate-100 mt-1">€8.42bn</div>
                <div className="text-[11px] text-slate-400 mt-1 font-mono">184,920 Transactions</div>
              </div>

              <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
                <div className="text-[10px] font-mono text-slate-400 uppercase">PORTFOLIO ASSETS UNDER MGMT</div>
                <div className="text-2xl font-bold font-mono text-slate-100 mt-1">€71.8bn</div>
                <div className="text-[11px] text-emerald-400 mt-1 font-mono">UCITS & Sovereign Bonds</div>
              </div>
            </div>

            {/* VEM Reserve Composition Panel */}
            <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
              <h3 className="text-sm font-mono tracking-wider text-slate-200 uppercase">
                VESUVIUS MARK (VEM) RESERVE ASSET ALLOCATION
              </h3>
              <div className="space-y-3">
                {vemState.reserves.map((res) => (
                  <div key={res.id} className="space-y-1 font-mono text-xs">
                    <div className="flex justify-between text-slate-300">
                      <span>{res.name} ({res.rating})</span>
                      <span className="text-amber-300 font-semibold">
                        €{res.amountMillions}m ({res.percentage}%)
                      </span>
                    </div>
                    <div className="w-full bg-[#1e2533] h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-amber-400 h-full transition-all"
                        style={{ width: `${res.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
