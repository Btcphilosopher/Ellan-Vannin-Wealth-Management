import React, { useState } from 'react';
import { PortfolioState } from '../types/vesuvius';
import { TrendingUp, ArrowUpRight, ShieldCheck, Building2, PieChart, Layers, DollarSign } from 'lucide-react';

interface WealthPageProps {
  portfolio: PortfolioState;
  entityMode: 'PRIVATE' | 'FAMILY_OFFICE' | 'CORPORATE';
}

export const WealthPage: React.FC<WealthPageProps> = ({ portfolio, entityMode }) => {
  const [assetFilter, setAssetFilter] = useState<'ALL' | 'EQUITY' | 'FIXED_INCOME' | 'FUNDS_UCITS' | 'PRIVATE_MARKETS'>('ALL');

  const filteredPositions = portfolio.positions.filter((p) => {
    if (assetFilter === 'ALL') return true;
    return p.assetClass === assetFilter;
  });

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8 font-mono">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg">
        <div>
          <span className="text-xs text-amber-400 uppercase tracking-widest">
            {entityMode === 'PRIVATE'
              ? 'VESUVIUS PRIVATE WEALTH MANAGEMENT'
              : entityMode === 'FAMILY_OFFICE'
              ? 'VESUVIUS FAMILY OFFICE CONSOLIDATED PORTFOLIO'
              : 'CORPORATE TREASURY ASSET MANAGEMENT'}
          </span>
          <h1 className="text-xl text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            EUROPEAN INSTITUTIONAL PORTFOLIO
          </h1>
        </div>

        <div className="text-right">
          <div className="text-xs text-slate-400 uppercase">INVESTMENT PORTFOLIO VALUE</div>
          <div className="text-2xl font-bold text-slate-100 mt-0.5">
            €{portfolio.investmentsEur.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
        </div>
      </div>

      {/* Portfolio Risk & Performance Ratios */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 text-xs">
        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">YTD PERFORMANCE</span>
          <div className="text-xl font-bold text-emerald-400 mt-1 flex items-center gap-1">
            <ArrowUpRight className="w-4 h-4" />
            <span>+{portfolio.ytdReturnPercent}%</span>
          </div>
          <span className="text-[10px] text-slate-400">Benchmark: MSCI Europe +4.2%</span>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">SHARPE RATIO</span>
          <div className="text-xl font-bold text-slate-100 mt-1">{portfolio.sharpeRatio}</div>
          <span className="text-[10px] text-emerald-400">Top-decile Risk-Adjusted</span>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">ANNUALIZED VOLATILITY</span>
          <div className="text-xl font-bold text-sky-300 mt-1">{portfolio.volatilityPercent}%</div>
          <span className="text-[10px] text-slate-400">Controlled Tail Risk</span>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">MAX DRAWDOWN</span>
          <div className="text-xl font-bold text-amber-300 mt-1">{portfolio.maxDrawdownPercent}%</div>
          <span className="text-[10px] text-slate-400">Peak-to-Trough Limit</span>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">LOMBARD CREDIT LINE</span>
          <div className="text-xl font-bold text-amber-200 mt-1">
            €{(portfolio.lombardCreditEur / 1e3).toFixed(0)}k
          </div>
          <span className="text-[10px] text-slate-400">Securities Backed (50% LTV)</span>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">REAL ASSETS & PROPERTY</span>
          <div className="text-xl font-bold text-slate-100 mt-1">
            €{(portfolio.propertyEur / 1e3).toFixed(0)}k
          </div>
          <span className="text-[10px] text-slate-400">Berlin Commercial Real Estate</span>
        </div>
      </div>

      {/* Asset Allocation Filter & Holdings Table */}
      <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl text-xs">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-[#202634] pb-4">
          <h2 className="text-sm text-slate-200 font-semibold tracking-wider uppercase">
            PORTFOLIO HOLDINGS & ASSET ALLOCATION
          </h2>

          <div className="flex items-center gap-1 bg-[#0c0e12] p-1 rounded-lg border border-[#202634]">
            {(['ALL', 'EQUITY', 'FIXED_INCOME', 'FUNDS_UCITS', 'PRIVATE_MARKETS'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setAssetFilter(filter)}
                className={`px-3 py-1.5 rounded transition-colors text-[11px] ${
                  assetFilter === filter ? 'bg-[#1e2534] text-amber-300 font-bold' : 'text-slate-400'
                }`}
              >
                {filter.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#202634] text-slate-400 uppercase text-[10px]">
                <th className="py-3 px-2">ASSET / TICKER</th>
                <th className="py-3 px-2">ASSET CLASS</th>
                <th className="py-3 px-2">GEOGRAPHY</th>
                <th className="py-3 px-2 text-right">QUANTITY</th>
                <th className="py-3 px-2 text-right">MARKET PRICE</th>
                <th className="py-3 px-2 text-right">VALUE (€)</th>
                <th className="py-3 px-2 text-right">WEIGHT</th>
                <th className="py-3 px-2 text-right">YTD RETURN</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b212d]">
              {filteredPositions.map((pos) => (
                <tr key={pos.id} className="hover:bg-[#161b26] transition-colors">
                  <td className="py-3.5 px-2 font-semibold text-slate-100">
                    <div>{pos.name}</div>
                    <div className="text-[10px] text-slate-400">{pos.ticker}</div>
                  </td>
                  <td className="py-3.5 px-2">
                    <span className="px-2 py-0.5 text-[10px] bg-[#1a212e] text-sky-300 rounded border border-[#2c374d]">
                      {pos.assetClass}
                    </span>
                  </td>
                  <td className="py-3.5 px-2 text-slate-300">{pos.geography}</td>
                  <td className="py-3.5 px-2 text-right text-slate-300">{pos.quantity.toLocaleString()}</td>
                  <td className="py-3.5 px-2 text-right text-slate-200">€{pos.currentPrice.toLocaleString()}</td>
                  <td className="py-3.5 px-2 text-right font-bold text-slate-100">
                    €{pos.valueEur.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-3.5 px-2 text-right text-amber-300 font-semibold">{pos.weightPercent}%</td>
                  <td className="py-3.5 px-2 text-right text-emerald-400 font-bold">+{pos.ytdReturnPercent}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
