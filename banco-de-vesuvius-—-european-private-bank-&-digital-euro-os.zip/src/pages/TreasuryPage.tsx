import React from 'react';
import { Vault, ShieldCheck, Layers, DollarSign, Activity } from 'lucide-react';

export const TreasuryPage: React.FC = () => {
  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8 font-mono">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg">
        <div>
          <span className="text-xs text-amber-400 uppercase tracking-widest">
            INSTITUTIONAL LIQUIDITY & RESERVE CONTROL
          </span>
          <h1 className="text-xl text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            TREASURY CONTROL CENTRE
          </h1>
        </div>

        <div className="text-right">
          <div className="text-xs text-slate-400 uppercase">TOTAL LIQUIDITY BUFFER</div>
          <div className="text-2xl font-bold text-slate-100 mt-0.5">€18,400,000,000</div>
        </div>
      </div>

      {/* Currency Breakdown Grid */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-xs">
        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">EUR LIQUIDITY</span>
          <div className="text-xl font-bold text-slate-100 mt-1">€12.2bn</div>
          <span className="text-[10px] text-emerald-400">66.3% Share</span>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">USD RESERVES</span>
          <div className="text-xl font-bold text-sky-300 mt-1">$2.8bn</div>
          <span className="text-[10px] text-slate-400">15.2% Share</span>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">CHF RESERVES</span>
          <div className="text-xl font-bold text-amber-200 mt-1">CHF 1.1bn</div>
          <span className="text-[10px] text-slate-400">6.0% Share</span>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">GBP RESERVES</span>
          <div className="text-xl font-bold text-slate-200 mt-1">£1.4bn</div>
          <span className="text-[10px] text-slate-400">7.6% Share</span>
        </div>

        <div className="bg-[#121620] border border-[#222836] p-4 rounded-xl">
          <span className="text-slate-400 text-[10px] uppercase">OTHER LIQUID</span>
          <div className="text-xl font-bold text-slate-300 mt-1">€0.9bn</div>
          <span className="text-[10px] text-slate-400">4.9% Share</span>
        </div>
      </div>

      {/* Maturity Ladder & HQLA Buffer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
          <h2 className="text-sm text-slate-200 font-semibold uppercase border-b border-[#202634] pb-3">
            HQLA MATURITY LADDER
          </h2>
          <div className="space-y-3 text-slate-300">
            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>Overnight / Target2 Cash</span>
              <span className="font-bold text-emerald-400">€6.2bn (33.7%)</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>7-Day Sovereign Bills</span>
              <span className="font-bold text-sky-300">€4.8bn (26.1%)</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>30-Day German Bunds</span>
              <span className="font-bold text-amber-300">€4.1bn (22.3%)</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>90-Day Supranational Papers</span>
              <span className="font-bold text-slate-100">€3.3bn (17.9%)</span>
            </div>
          </div>
        </div>

        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
          <h2 className="text-sm text-slate-200 font-semibold uppercase border-b border-[#202634] pb-3">
            REGULATORY CAPITAL & LCR RATIOS
          </h2>
          <div className="space-y-3 text-slate-300">
            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>Liquidity Coverage Ratio (LCR)</span>
              <span className="font-bold text-emerald-400">248.5% (Req: 100%)</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>Net Stable Funding Ratio (NSFR)</span>
              <span className="font-bold text-emerald-400">142.1% (Req: 100%)</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>CET1 Capital Ratio</span>
              <span className="font-bold text-amber-300">18.4% (Tier-1)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
