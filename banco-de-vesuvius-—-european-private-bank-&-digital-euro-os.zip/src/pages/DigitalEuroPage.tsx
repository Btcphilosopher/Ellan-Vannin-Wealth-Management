import React, { useState } from 'react';
import { BankAccount } from '../types/vesuvius';
import { Wallet, ShieldCheck, Wifi, WifiOff, RefreshCw, Smartphone, CheckCircle2, ArrowDownLeft, ArrowUpRight } from 'lucide-react';

interface DigitalEuroPageProps {
  accounts: BankAccount[];
  onTransfer: (params: any) => void;
}

export const DigitalEuroPage: React.FC<DigitalEuroPageProps> = ({ accounts, onTransfer }) => {
  const deuroAcc = accounts.find((a) => a.currency === 'DIGITAL_EURO');
  const eurAcc = accounts.find((a) => a.currency === 'EUR');

  const balance = deuroAcc?.balance || 2150.0;
  const limit = deuroAcc?.holdingLimit || 3000.0;
  const holdingPercentage = Math.min(100, Number(((balance / limit) * 100).toFixed(1)));

  // Offline payment simulation state
  const [offlineBalance, setOfflineBalance] = useState(180.0);
  const [offlineAmount, setOfflineAmount] = useState('25');
  const [offlineRecipient, setOfflineRecipient] = useState('P2P-NFC-BERLIN-MERCHANT-88');
  const [offlineLog, setOfflineLog] = useState<string[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);

  // Fund / Defund state
  const [fundAmount, setFundAmount] = useState('');

  const handleFundWallet = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Number(fundAmount);
    if (!amt || amt <= 0) return;

    if (balance + amt > limit) {
      alert(`Fund request exceeds Eurosystem legislative holding limit of €${limit.toLocaleString()}. Waterfall mechanism active.`);
      return;
    }

    try {
      onTransfer({
        fromCurrency: 'EUR',
        recipientName: 'ECB Digital Euro Service Layer',
        recipientIban: 'DE999999DEURO00000000',
        amount: amt,
        reference: 'Wallet Top-Up via Intermediary Rail',
        rail: 'DIGITAL_EURO_RAIL',
      });
      setFundAmount('');
      alert(`Successfully added €${amt} to Digital Euro Wallet.`);
    } catch (err: any) {
      alert(err.message || 'Funding failed');
    }
  };

  const handleExecuteOfflinePayment = () => {
    const amt = Number(offlineAmount);
    if (!amt || amt <= 0) return;
    if (offlineBalance < amt) {
      alert('Insufficient funds in Secure Element for offline transaction.');
      return;
    }

    setOfflineBalance((prev) => prev - amt);
    const time = new Date().toTimeString().split(' ')[0];
    const newLog = `[${time}] OFFLINE SECURE ELEMENT: Sent €${amt.toFixed(2)} to ${offlineRecipient} (Local Counter: #${offlineLog.length + 101}, Hash: 0xSE${Math.random().toString(16).substring(2, 8)})`;
    setOfflineLog([newLog, ...offlineLog]);
  };

  const handleSyncOfflineVault = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      alert('Secure Element cryptograms synchronized with Bundesbank Digital Euro Settlement Router.');
    }, 1500);
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg">
        <div>
          <span className="text-xs font-mono text-sky-400 uppercase tracking-widest">
            EUROSYSTEM CBDC INTEGRATION LAYER
          </span>
          <h1 className="text-xl font-mono text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            DIGITAL EURO OPERATING SYSTEM
          </h1>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-sky-950/60 border border-sky-800/80 rounded-md text-xs font-mono text-sky-300">
          <ShieldCheck className="w-4 h-4 text-sky-400" />
          <span>SUPERVISED INTERMEDIARY ARCHITECTURE</span>
        </div>
      </div>

      {/* Main Digital Euro Balance & Holding Limit Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#121620] border border-[#222836] p-6 rounded-xl space-y-6 shadow-xl">
          <div className="flex justify-between items-start border-b border-[#202634] pb-4">
            <div>
              <span className="text-xs font-mono text-slate-400 uppercase">ONLINE WALLET BALANCE</span>
              <div className="text-3xl font-bold font-mono text-slate-100 mt-1">
                €{balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-xs font-mono text-slate-400 mt-1">
                Linked Account Balance: €{(eurAcc?.balance || 842190).toLocaleString()}
              </div>
            </div>

            <div className="text-right font-mono">
              <span className="text-xs text-amber-400 uppercase">HOLDING LIMIT</span>
              <div className="text-xl font-bold text-slate-200 mt-1">
                €{limit.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Non-Remunerated Retail Limit</div>
            </div>
          </div>

          {/* Holding Limit Visual Progress */}
          <div className="space-y-2 font-mono text-xs">
            <div className="flex justify-between text-slate-300">
              <span>Holding Capacity Used: {holdingPercentage}%</span>
              <span>Available Capacity: €{(limit - balance).toLocaleString()}</span>
            </div>
            <div className="w-full bg-[#1b212e] h-3 rounded-full overflow-hidden border border-[#2b3447]">
              <div
                className={`h-full transition-all ${
                  holdingPercentage > 85 ? 'bg-amber-400' : 'bg-sky-400'
                }`}
                style={{ width: `${holdingPercentage}%` }}
              />
            </div>
            <p className="text-[11px] text-slate-400 italic">
              * Waterfall mechanism active: any incoming transfers exceeding the €3,000 limit are automatically swept into your commercial EUR account.
            </p>
          </div>

          {/* Fund / Defund Form */}
          <form onSubmit={handleFundWallet} className="pt-4 border-t border-[#202634] grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
            <div className="md:col-span-2">
              <label className="block text-slate-400 mb-1">FUND DIGITAL EURO FROM COMMERCIAL ACC</label>
              <input
                type="number"
                placeholder="Amount in EUR (e.g. 500)"
                value={fundAmount}
                onChange={(e) => setFundAmount(e.target.value)}
                className="w-full bg-[#181d28] border border-[#2a3344] rounded p-2.5 text-slate-100 focus:outline-none focus:border-sky-400"
              />
            </div>
            <div className="flex items-end">
              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-500 text-white font-semibold rounded transition-colors"
              >
                TOP UP WALLET
              </button>
            </div>
          </form>
        </div>

        {/* Architecture Matrix Card */}
        <div className="bg-[#121620] border border-[#222836] p-6 rounded-xl space-y-4 font-mono text-xs shadow-xl">
          <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider text-sky-400 border-b border-[#202634] pb-2">
            ECB DESIGN PRINCIPLES
          </h3>
          <div className="space-y-3 text-slate-300">
            <div>
              <span className="text-slate-400 block text-[10px]">ISSUER & BACKING:</span>
              <span>Eurosystem (Public Central Bank Money)</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">INTERMEDIARY ROLE:</span>
              <span>Banco de Vesuvius (KYC / AML & Wallet Mgmt)</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">HOLDING LIMIT & REMUNERATION:</span>
              <span>€3,000 Cap · 0.00% Remuneration Rate</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">PRIVACY MODEL:</span>
              <span>Pseudonymised Online · Full Privacy Offline</span>
            </div>
          </div>
        </div>
      </div>

      {/* OFFLINE PAYMENT SUBSYSTEM */}
      <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-[#202634] pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
              <WifiOff className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-mono text-emerald-400 uppercase tracking-widest">
                OFFLINE HARDWARE SECURE ELEMENT
              </span>
              <h2 className="text-base font-mono text-slate-100 font-semibold tracking-wide uppercase">
                OFFLINE DIGITAL EURO SUBSYSTEM
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-3 font-mono text-xs">
            <div className="text-right">
              <div className="text-slate-400 text-[10px]">SECURE DEVICE BALANCE</div>
              <div className="text-lg font-bold text-emerald-300">
                €{offlineBalance.toFixed(2)}
              </div>
            </div>
            <button
              onClick={handleSyncOfflineVault}
              disabled={isSyncing}
              className="flex items-center gap-1.5 px-3 py-2 bg-[#1b2230] hover:bg-[#252f42] text-slate-200 border border-[#2f3a52] rounded transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'SYNCING...' : 'RECONCILE VAULT'}</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Offline Payment Execution */}
          <div className="bg-[#161a24] border border-[#232a3b] p-5 rounded-lg space-y-4 font-mono text-xs">
            <h3 className="text-slate-200 font-semibold uppercase flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span>SIMULATE P2P OFFLINE NFC PAYMENT</span>
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">RECIPIENT DEVICE / MERCHANT ID</label>
                <input
                  type="text"
                  value={offlineRecipient}
                  onChange={(e) => setOfflineRecipient(e.target.value)}
                  className="w-full bg-[#1c2230] border border-[#2d374d] rounded p-2 text-slate-100 focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">AMOUNT IN EUR (€)</label>
                <input
                  type="number"
                  value={offlineAmount}
                  onChange={(e) => setOfflineAmount(e.target.value)}
                  className="w-full bg-[#1c2230] border border-[#2d374d] rounded p-2 text-slate-100 focus:outline-none focus:border-emerald-400"
                />
              </div>

              <button
                onClick={handleExecuteOfflinePayment}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded transition-colors"
              >
                EXECUTE OFFLINE P2P TRANSFER
              </button>
            </div>
          </div>

          {/* Offline Hardware Cryptogram Log */}
          <div className="bg-[#161a24] border border-[#232a3b] p-5 rounded-lg space-y-3 font-mono text-xs">
            <h3 className="text-slate-200 font-semibold uppercase flex items-center justify-between">
              <span>LOCAL HARDWARE CRYPTOGRAM JOURNAL</span>
              <span className="text-[10px] text-emerald-400">HARDWARE ENCLAVE ACTIVE</span>
            </h3>

            <div className="bg-[#0b0e14] border border-[#1e2534] rounded p-3 text-[11px] text-slate-300 space-y-2 h-44 overflow-y-auto scrollbar-thin">
              {offlineLog.length === 0 ? (
                <div className="text-slate-500 italic">
                  No local offline transactions executed yet. Execute an offline P2P transfer above to observe secure element cryptogram generation...
                </div>
              ) : (
                offlineLog.map((log, i) => (
                  <div key={i} className="text-emerald-300 font-mono border-b border-[#18202e] pb-1">
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
