import React, { useState } from 'react';
import { MacroCountryData } from '../types/vesuvius';
import { Globe2, Sliders, TrendingUp, Cpu, Activity, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface ResearchPageProps {
  macroCountries: MacroCountryData[];
}

export const ResearchPage: React.FC<ResearchPageProps> = ({ macroCountries }) => {
  const [activeSubTab, setActiveSubTab] = useState<'MACRO' | 'SIMULATOR' | 'QUANT'>('MACRO');

  // Monetary Policy Simulator Sliders
  const [policyRate, setPolicyRate] = useState(3.25);
  const [energyPriceIndex, setEnergyPriceIndex] = useState(100);
  const [fiscalSpendingGdp, setFiscalSpendingGdp] = useState(48.5);

  // Computed causal impacts
  const moneyMarketRate = (policyRate + 0.02).toFixed(2);
  const creditGrowthImpact = (4.5 - policyRate * 0.6).toFixed(1);
  const gdpGrowthImpact = (1.8 - policyRate * 0.25 + (fiscalSpendingGdp - 48.5) * 0.1).toFixed(2);
  const cpiInflationImpact = (2.2 - (policyRate - 3.25) * 0.35 + (energyPriceIndex - 100) * 0.04).toFixed(2);
  const eurUsdImpact = (1.0842 + (policyRate - 3.25) * 0.025).toFixed(4);

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8 font-mono text-xs">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg">
        <div>
          <span className="text-xs text-amber-400 uppercase tracking-widest">
            VESUVIUS RESEARCH & QUANTITATIVE ECONOMICS
          </span>
          <h1 className="text-xl text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            EUROPEAN MACRO & MONETARY POLICY SIMULATOR
          </h1>
        </div>

        <div className="flex items-center gap-1 bg-[#0c0e12] p-1 rounded-lg border border-[#222830]">
          <button
            onClick={() => setActiveSubTab('MACRO')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'MACRO' ? 'bg-[#1f2634] text-amber-300 font-bold' : 'text-slate-400'
            }`}
          >
            MACRO MAP & DATA
          </button>
          <button
            onClick={() => setActiveSubTab('SIMULATOR')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'SIMULATOR' ? 'bg-[#1f2634] text-sky-300 font-bold' : 'text-slate-400'
            }`}
          >
            MONETARY POLICY SIMULATOR
          </button>
          <button
            onClick={() => setActiveSubTab('QUANT')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'QUANT' ? 'bg-[#1f2634] text-emerald-300 font-bold' : 'text-slate-400'
            }`}
          >
            R & PYTHON QUANT ENGINE
          </button>
        </div>
      </div>

      {activeSubTab === 'MACRO' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
          <h2 className="text-sm text-slate-200 font-semibold uppercase border-b border-[#202634] pb-3">
            EUROPEAN UNION MACROECONOMIC INDICATORS (20 ECONOMIES)
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#202634] text-slate-400 uppercase text-[10px]">
                  <th className="py-2.5 px-2">COUNTRY</th>
                  <th className="py-2.5 px-2 text-right">GDP (€ BN)</th>
                  <th className="py-2.5 px-2 text-right">GDP GROWTH</th>
                  <th className="py-2.5 px-2 text-right">CPI INFLATION</th>
                  <th className="py-2.5 px-2 text-right">UNEMPLOYMENT</th>
                  <th className="py-2.5 px-2 text-right">GOVT DEBT/GDP</th>
                  <th className="py-2.5 px-2 text-right">CREDIT GROWTH</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b212d]">
                {macroCountries.map((m) => (
                  <tr key={m.code} className="hover:bg-[#161b26] transition-colors">
                    <td className="py-3 px-2 font-semibold text-slate-100">{m.name} ({m.code})</td>
                    <td className="py-3 px-2 text-right font-bold text-slate-200">€{m.gdpBnEur.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right text-emerald-400">+{m.gdpGrowthPercent}%</td>
                    <td className="py-3 px-2 text-right text-amber-300">{m.cpiInflationPercent}%</td>
                    <td className="py-3 px-2 text-right text-slate-300">{m.unemploymentPercent}%</td>
                    <td className="py-3 px-2 text-right text-slate-300">{m.govDebtGdpPercent}%</td>
                    <td className="py-3 px-2 text-right text-sky-300">+{m.creditGrowthPercent}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeSubTab === 'SIMULATOR' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl">
          <div className="border-b border-[#202634] pb-3">
            <span className="text-sky-400 text-[10px] uppercase">RESEARCH SANDBOX</span>
            <h2 className="text-base font-semibold text-slate-100 uppercase mt-0.5">
              CAUSAL MONETARY POLICY PROPAGATION ENGINE
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Input Controls */}
            <div className="space-y-4 bg-[#161a24] p-4 rounded-lg border border-[#232a3b]">
              <h3 className="text-amber-300 font-semibold uppercase border-b border-[#222a3a] pb-2">
                POLICY INPUT CONTROLS
              </h3>

              <div className="space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span>ECB Policy Rate:</span>
                  <span className="font-bold text-amber-300">{policyRate.toFixed(2)}%</span>
                </div>
                <input
                  type="range"
                  min="0.0"
                  max="7.0"
                  step="0.25"
                  value={policyRate}
                  onChange={(e) => setPolicyRate(Number(e.target.value))}
                  className="w-full accent-amber-400"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span>Energy Price Index:</span>
                  <span className="font-bold text-amber-300">{energyPriceIndex}</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="200"
                  step="5"
                  value={energyPriceIndex}
                  onChange={(e) => setEnergyPriceIndex(Number(e.target.value))}
                  className="w-full accent-amber-400"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span>Fiscal Spending / GDP:</span>
                  <span className="font-bold text-amber-300">{fiscalSpendingGdp.toFixed(1)}%</span>
                </div>
                <input
                  type="range"
                  min="40.0"
                  max="60.0"
                  step="0.5"
                  value={fiscalSpendingGdp}
                  onChange={(e) => setFiscalSpendingGdp(Number(e.target.value))}
                  className="w-full accent-amber-400"
                />
              </div>
            </div>

            {/* Causal Chain Output */}
            <div className="md:col-span-2 space-y-4 bg-[#161a24] p-4 rounded-lg border border-[#232a3b]">
              <h3 className="text-sky-300 font-semibold uppercase border-b border-[#222a3a] pb-2">
                DOWNSTREAM MODEL PROPAGATION OUTPUTS
              </h3>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-slate-300">
                <div className="bg-[#10131a] p-3 rounded border border-[#1e2534]">
                  <span className="text-slate-400 text-[10px] block">MONEY MARKET RATE</span>
                  <span className="text-base font-bold text-slate-100">{moneyMarketRate}%</span>
                </div>

                <div className="bg-[#10131a] p-3 rounded border border-[#1e2534]">
                  <span className="text-slate-400 text-[10px] block">PROJECTED CREDIT GROWTH</span>
                  <span className="text-base font-bold text-sky-300">+{creditGrowthImpact}%</span>
                </div>

                <div className="bg-[#10131a] p-3 rounded border border-[#1e2534]">
                  <span className="text-slate-400 text-[10px] block">PROJECTED GDP GROWTH</span>
                  <span className="text-base font-bold text-emerald-400">+{gdpGrowthImpact}%</span>
                </div>

                <div className="bg-[#10131a] p-3 rounded border border-[#1e2534]">
                  <span className="text-slate-400 text-[10px] block">PROJECTED CPI INFLATION</span>
                  <span className="text-base font-bold text-amber-300">{cpiInflationImpact}%</span>
                </div>

                <div className="bg-[#10131a] p-3 rounded border border-[#1e2534]">
                  <span className="text-slate-400 text-[10px] block">PROJECTED EUR/USD EXCHANGE</span>
                  <span className="text-base font-bold text-slate-100">{eurUsdImpact}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'QUANT' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl">
          <div className="border-b border-[#202634] pb-3">
            <span className="text-emerald-400 text-[10px] uppercase">R & PYTHON QUANTITATIVE ANALYTICS</span>
            <h2 className="text-base font-semibold text-slate-100 uppercase mt-0.5">
              VAR MODELS, PCA FACTOR LOADINGS & MONTE CARLO SIMULATION
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-[#161a24] p-4 rounded-lg border border-[#232a3b] space-y-3">
              <h3 className="text-amber-300 font-semibold uppercase">
                R VAR(4) MODEL IMPULSE RESPONSE FUNCTIONS
              </h3>
              <p className="text-slate-400 leading-relaxed">
                Reproduction of 1,000 Monte Carlo draws. 95% confidence bounds confirm price stability of VEM collateral under 200bps interest rate shocks.
              </p>
              <div className="bg-[#0b0e14] p-3 rounded text-[11px] font-mono text-emerald-400">
                eigenvalues: [0.942, 0.881, 0.764, 0.412] · Granger Causality p-val: 0.0012
              </div>
            </div>

            <div className="bg-[#161a24] p-4 rounded-lg border border-[#232a3b] space-y-3">
              <h3 className="text-sky-300 font-semibold uppercase">
                PYTHON PCA FACTOR ANALYSIS ON EUROPEAN YIELDS
              </h3>
              <p className="text-slate-400 leading-relaxed">
                Factor 1 (Level): 84.2% variance explained · Factor 2 (Slope): 11.4% variance explained · Factor 3 (Curvature): 3.1% variance explained.
              </p>
              <div className="bg-[#0b0e14] p-3 rounded text-[11px] font-mono text-sky-300">
                explained_variance_ratio_: [0.842, 0.114, 0.031]
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
