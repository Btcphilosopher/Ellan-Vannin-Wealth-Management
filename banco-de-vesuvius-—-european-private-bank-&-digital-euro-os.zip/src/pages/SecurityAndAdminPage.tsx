import React, { useState } from 'react';
import { AuditLogItem } from '../types/vesuvius';
import { ShieldCheck, Lock, FileCheck2, AlertOctagon, Key, Fingerprint } from 'lucide-react';

interface SecurityAndAdminPageProps {
  auditLogs: AuditLogItem[];
}

export const SecurityAndAdminPage: React.FC<SecurityAndAdminPageProps> = ({ auditLogs }) => {
  const [activeTab, setActiveTab] = useState<'SECURITY' | 'PRIVACY' | 'AUDIT' | 'GOVERNANCE'>('SECURITY');
  const [isAccountFrozen, setIsAccountFrozen] = useState(false);

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8 font-mono text-xs">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg">
        <div>
          <span className="text-xs text-sky-400 uppercase tracking-widest">
            EUROPEAN SECURITY & COMPLIANCE INFRASTRUCTURE
          </span>
          <h1 className="text-xl text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            SECURITY, PRIVACY & MODEL GOVERNANCE
          </h1>
        </div>

        <div className="flex items-center gap-1 bg-[#0c0e12] p-1 rounded-lg border border-[#222830]">
          <button
            onClick={() => setActiveTab('SECURITY')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'SECURITY' ? 'bg-[#1f2634] text-sky-300 font-bold' : 'text-slate-400'
            }`}
          >
            SECURITY & PASSKEYS
          </button>
          <button
            onClick={() => setActiveTab('PRIVACY')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'PRIVACY' ? 'bg-[#1f2634] text-emerald-300 font-bold' : 'text-slate-400'
            }`}
          >
            EUROPEAN PRIVACY CENTRE
          </button>
          <button
            onClick={() => setActiveTab('AUDIT')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'AUDIT' ? 'bg-[#1f2634] text-amber-300 font-bold' : 'text-slate-400'
            }`}
          >
            IMMUTABLE AUDIT LOG
          </button>
          <button
            onClick={() => setActiveTab('GOVERNANCE')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'GOVERNANCE' ? 'bg-[#1f2634] text-slate-200 font-bold' : 'text-slate-400'
            }`}
          >
            MODEL GOVERNANCE
          </button>
        </div>
      </div>

      {activeTab === 'SECURITY' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
            <h2 className="text-sm text-slate-200 font-semibold uppercase border-b border-[#202634] pb-3 flex items-center gap-2">
              <Key className="w-4 h-4 text-sky-400" />
              <span>AUTHENTICATION & PASSKEYS</span>
            </h2>

            <div className="space-y-3 text-slate-300">
              <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
                <span>Biometric Hardware Passkey</span>
                <span className="text-emerald-400 font-bold">ACTIVE (WebAuthn / YubiKey)</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
                <span>Hardware Enclave Signing</span>
                <span className="text-emerald-400 font-bold">ACTIVE (SECP256R1)</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
                <span>Transaction Confirmation Threshold</span>
                <span className="text-amber-300 font-bold">€50,000 Dual-Sign</span>
              </div>
            </div>
          </div>

          <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
            <h2 className="text-sm text-slate-200 font-semibold uppercase border-b border-[#202634] pb-3 flex items-center gap-2">
              <AlertOctagon className="w-4 h-4 text-rose-400" />
              <span>EMERGENCY ACCOUNT CONTROLS</span>
            </h2>

            <div className="p-4 bg-[#1a151b] border border-rose-900/60 rounded-lg space-y-3">
              <div className="text-slate-200 font-semibold">GLOBAL ACCOUNT FREEZE TOGGLE</div>
              <p className="text-slate-400 leading-relaxed text-[11px]">
                Immediately restricts outgoing transfers across EUR, VEM, and Digital Euro rails in event of security compromise.
              </p>

              <button
                onClick={() => setIsAccountFrozen(!isAccountFrozen)}
                className={`w-full py-2.5 px-4 font-bold rounded transition-colors ${
                  isAccountFrozen
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-rose-700 hover:bg-rose-600 text-white'
                }`}
              >
                {isAccountFrozen ? 'UNFREEZE ACCOUNT' : 'ACTIVATE EMERGENCY ACCOUNT FREEZE'}
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'PRIVACY' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
          <h2 className="text-sm text-slate-200 font-semibold uppercase border-b border-[#202634] pb-3">
            EUROPEAN DATA PROTECTION & GDPR CONTROL CENTRE
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-slate-300">
            <div className="p-3 bg-[#161a24] rounded border border-[#232a3b] space-y-1">
              <span className="text-slate-400 text-[10px] block">PAYMENT DATA PRIVACY:</span>
              <span className="text-emerald-400 font-bold">Pseudonymised Online · Full Privacy Offline</span>
            </div>
            <div className="p-3 bg-[#161a24] rounded border border-[#232a3b] space-y-1">
              <span className="text-slate-400 text-[10px] block">COMMERCIAL DATA PROFILES:</span>
              <span className="text-emerald-400 font-bold">STRICTLY DISABLED (Zero Monitization)</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'AUDIT' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
          <h2 className="text-sm text-slate-200 font-semibold uppercase border-b border-[#202634] pb-3">
            IMMUTABLE CRYPTOGRAPHIC AUDIT JOURNAL
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#202634] text-slate-400 uppercase text-[10px]">
                  <th className="py-2.5 px-2">TIMESTAMP</th>
                  <th className="py-2.5 px-2">ACTION</th>
                  <th className="py-2.5 px-2">ENTITY</th>
                  <th className="py-2.5 px-2">ACTOR</th>
                  <th className="py-2.5 px-2">DETAILS</th>
                  <th className="py-2.5 px-2 text-right">HASH</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b212d]">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-[#161b26] transition-colors">
                    <td className="py-3 px-2 text-slate-300">{log.timestamp}</td>
                    <td className="py-3 px-2 font-semibold text-amber-300">{log.action}</td>
                    <td className="py-3 px-2 text-sky-300">{log.entity}</td>
                    <td className="py-3 px-2 text-slate-300">{log.actor}</td>
                    <td className="py-3 px-2 text-slate-300 max-w-sm truncate">{log.details}</td>
                    <td className="py-3 px-2 text-right font-mono text-emerald-400 text-[10px]">{log.hash}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'GOVERNANCE' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl">
          <h2 className="text-sm text-slate-200 font-semibold uppercase border-b border-[#202634] pb-3">
            MODEL GOVERNANCE & QUANT REGISTER
          </h2>

          <div className="space-y-3 text-slate-300">
            <div className="p-3 bg-[#161a24] rounded border border-[#232a3b] space-y-1">
              <span className="text-amber-300 font-bold block">MODEL ID: MOD-VESU-VAR-2026</span>
              <p className="text-slate-400">
                Vector Autoregression Macro-Reserve Model. Validated against 2008-2025 sovereign bond crisis scenarios.
              </p>
            </div>
            <div className="p-3 bg-[#161a24] rounded border border-[#232a3b] space-y-1">
              <span className="text-sky-300 font-bold block">MODEL ID: MOD-VESU-POS-CONSENSUS-V3</span>
              <p className="text-slate-400">
                Euro PoS Validator Quorum & Finality Engine. Formally verifiedSGX enclave state transitions.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
