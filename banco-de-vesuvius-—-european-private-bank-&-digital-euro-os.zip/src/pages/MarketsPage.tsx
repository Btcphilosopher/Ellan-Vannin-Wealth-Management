import React, { useState } from 'react';
import { FxQuote } from '../types/vesuvius';
import { LineChart, ArrowUpRight, ArrowDownRight, RefreshCw, Layers } from 'lucide-react';

interface MarketsPageProps {
  fxQuotes: FxQuote[];
}

export const MarketsPage: React.FC<MarketsPageProps> = ({ fxQuotes }) => {
  const [selectedPair, setSelectedPair] = useState<FxQuote>(fxQuotes[0]);
  const [activeTab, setActiveTab] = useState<'FX' | 'RATES'>('FX');

  // Simulated Order Book
  const bids = [
    { price: (selectedPair.bid - 0.0001).toFixed(4), amount: '12,500,000' },
    { price: (selectedPair.bid - 0.0002).toFixed(4), amount: '28,000,000' },
    { price: (selectedPair.bid - 0.0004).toFixed(4), amount: '45,200,000' },
  ];
  const asks = [
    { price: (selectedPair.ask + 0.0001).toFixed(4), amount: '15,000,000' },
    { price: (selectedPair.ask + 0.0003).toFixed(4), amount: '32,100,000' },
    { price: (selectedPair.ask + 0.0005).toFixed(4), amount: '50,000,000' },
  ];

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8 font-mono">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg">
        <div>
          <span className="text-xs text-amber-400 uppercase tracking-widest">
            EUROPEAN INSTITUTIONAL MARKETS TERMINAL
          </span>
          <h1 className="text-xl text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            FX DESK & ECB MONEY MARKET
          </h1>
        </div>

        <div className="flex items-center gap-1 bg-[#0c0e12] p-1 rounded-lg border border-[#222830] text-xs">
          <button
            onClick={() => setActiveTab('FX')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'FX' ? 'bg-[#1f2634] text-amber-300 font-bold' : 'text-slate-400'
            }`}
          >
            EUROPEAN FX DESK
          </button>
          <button
            onClick={() => setActiveTab('RATES')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'RATES' ? 'bg-[#1f2634] text-amber-300 font-bold' : 'text-slate-400'
            }`}
          >
            ECB MONEY MARKET & CURVES
          </button>
        </div>
      </div>

      {activeTab === 'FX' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* FX Pairs Ticker */}
          <div className="bg-[#11141c] border border-[#222838] p-5 rounded-xl space-y-3 shadow-xl text-xs">
            <h2 className="text-sm text-slate-200 font-semibold uppercase border-b border-[#202634] pb-2">
              EURO CROSSES (LIVE QUOTES)
            </h2>

            <div className="space-y-2">
              {fxQuotes.map((q) => {
                const isSelected = selectedPair.pair === q.pair;
                return (
                  <div
                    key={q.pair}
                    onClick={() => setSelectedPair(q)}
                    className={`p-3.5 rounded-lg border cursor-pointer transition-all flex justify-between items-center ${
                      isSelected
                        ? 'bg-[#1a2230] border-[#d4af37] text-slate-100'
                        : 'bg-[#161a24] border-[#232a3b] text-slate-300 hover:border-slate-500'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-sm text-slate-100">{q.pair}</div>
                      <div className="text-[10px] text-slate-400">Vol: €{(q.volume24h / 1e6).toFixed(0)}m</div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold text-sm">
                        {q.bid} / {q.ask}
                      </div>
                      <div className={`text-[10px] flex items-center justify-end gap-0.5 ${q.change24hPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {q.change24hPercent >= 0 ? '+' : ''}{q.change24hPercent}%
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected FX Pair Terminal & Order Book */}
          <div className="lg:col-span-2 bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl text-xs">
            <div className="flex justify-between items-center border-b border-[#202634] pb-3">
              <div>
                <span className="text-[10px] text-slate-400 uppercase">SELECTED PAIR</span>
                <h3 className="text-xl font-bold text-amber-300">{selectedPair.pair} SPOT DESK</h3>
              </div>
              <div className="text-right">
                <span className="text-slate-400 text-[10px]">24H RANGE:</span>
                <div className="text-slate-200 font-semibold">{selectedPair.low24h} - {selectedPair.high24h}</div>
              </div>
            </div>

            {/* Simulated Depth & Order Book */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#161a24] border border-[#232a3b] p-4 rounded-lg space-y-2">
                <h4 className="text-emerald-400 font-semibold uppercase text-[11px] border-b border-[#222838] pb-1">
                  BID DEPTH (BUYING EUR)
                </h4>
                {bids.map((b, i) => (
                  <div key={i} className="flex justify-between text-slate-300">
                    <span className="text-emerald-400 font-bold">{b.price}</span>
                    <span className="text-slate-400">{b.amount} EUR</span>
                  </div>
                ))}
              </div>

              <div className="bg-[#161a24] border border-[#232a3b] p-4 rounded-lg space-y-2">
                <h4 className="text-rose-400 font-semibold uppercase text-[11px] border-b border-[#222838] pb-1">
                  ASK DEPTH (SELLING EUR)
                </h4>
                {asks.map((a, i) => (
                  <div key={i} className="flex justify-between text-slate-300">
                    <span className="text-rose-400 font-bold">{a.price}</span>
                    <span className="text-slate-400">{a.amount} EUR</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'RATES' && (
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-6 shadow-xl text-xs">
          <div className="border-b border-[#202634] pb-3">
            <span className="text-amber-400 text-[10px] uppercase">ECB POLICY & BENCHMARK RATES</span>
            <h2 className="text-base font-semibold text-slate-100 uppercase mt-0.5">
              EURO MONEY MARKET & SOVEREIGN YIELD CURVES
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-[#161a24] border border-[#232a3b] p-4 rounded-lg">
              <span className="text-slate-400 text-[10px] uppercase">ECB DEPOSIT FACILITY</span>
              <div className="text-2xl font-bold text-slate-100 mt-1">3.25%</div>
              <span className="text-[10px] text-emerald-400">Target Benchmark</span>
            </div>

            <div className="bg-[#161a24] border border-[#232a3b] p-4 rounded-lg">
              <span className="text-slate-400 text-[10px] uppercase">ESTR OVERNIGHT RATE</span>
              <div className="text-2xl font-bold text-sky-300 mt-1">3.248%</div>
              <span className="text-[10px] text-slate-400">Euro Short-Term Rate</span>
            </div>

            <div className="bg-[#161a24] border border-[#232a3b] p-4 rounded-lg">
              <span className="text-slate-400 text-[10px] uppercase">GERMAN 10Y BUND YIELD</span>
              <div className="text-2xl font-bold text-amber-300 mt-1">2.42%</div>
              <span className="text-[10px] text-slate-400">AAA Sovereign Anchor</span>
            </div>

            <div className="bg-[#161a24] border border-[#232a3b] p-4 rounded-lg">
              <span className="text-slate-400 text-[10px] uppercase">FRENCH 10Y OAT SPREAD</span>
              <div className="text-2xl font-bold text-slate-100 mt-1">+72 bps</div>
              <span className="text-[10px] text-slate-400">vs Bunds Baseline</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
