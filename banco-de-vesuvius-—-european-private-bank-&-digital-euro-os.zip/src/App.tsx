import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { EventStreamTicker } from './components/EventStreamTicker';
import { OverviewPage } from './pages/OverviewPage';
import { BankingPage } from './pages/BankingPage';
import { CardPreview } from './components/CardPreview';
import { DigitalEuroPage } from './pages/DigitalEuroPage';
import { VesuviusMarkPage } from './pages/VesuviusMarkPage';
import { WealthPage } from './pages/WealthPage';
import { MarketsPage } from './pages/MarketsPage';
import { TreasuryPage } from './pages/TreasuryPage';
import { EuroPosPage } from './pages/EuroPosPage';
import { ResearchPage } from './pages/ResearchPage';
import { PrivateBankingPage } from './pages/PrivateBankingPage';
import { SecurityAndAdminPage } from './pages/SecurityAndAdminPage';
import { simulationEngine } from './services/simulationEngine';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('OVERVIEW');
  const [entityMode, setEntityMode] = useState<'PRIVATE' | 'FAMILY_OFFICE' | 'CORPORATE'>('PRIVATE');

  const [storeState, setStoreState] = useState(simulationEngine.getStoreState());
  const [isDemoRunning, setIsDemoRunning] = useState(false);
  const [demoLogs, setDemoLogs] = useState<string[]>([]);

  // Function to refresh state from backend/engine
  const refreshState = () => {
    setStoreState({ ...simulationEngine.getStoreState() });
  };

  const handleRunBerlinDemo = () => {
    setIsDemoRunning(true);
    setDemoLogs([]);
    setTimeout(() => {
      const res = simulationEngine.runBerlinDemoScenario();
      setDemoLogs(res.logs);
      setIsDemoRunning(false);
      refreshState();
    }, 1000);
  };

  const handleMintVem = (amountEur: number) => {
    simulationEngine.mintVem(amountEur);
    refreshState();
  };

  const handleRedeemVem = (amountVem: number) => {
    simulationEngine.redeemVem(amountVem);
    refreshState();
  };

  const handleTransfer = (params: any) => {
    simulationEngine.executeTransfer(params);
    refreshState();
  };

  const handleRunEuroPosScenario = (scenario: 'VALIDATOR_FAILURE' | 'LIQUIDITY_SHOCK' | 'FX_SHOCK' | 'RECOVERY') => {
    simulationEngine.triggerEuroPosScenario(scenario);
    refreshState();
  };

  return (
    <div className="min-h-screen bg-[#0a0c0f] text-[#e2e8f0] font-sans flex flex-col selection:bg-[#d4af37]/30 selection:text-white">
      {/* Top Bar Contract Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        entityMode={entityMode}
        setEntityMode={setEntityMode}
        onRunDemo={handleRunBerlinDemo}
        isDemoRunning={isDemoRunning}
      />

      {/* Live System Event Ticker */}
      <EventStreamTicker events={storeState.systemEvents} />

      {/* Main Body Layout with Sidebar + Content */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        <main className="flex-1 overflow-y-auto bg-[#0d0f14]">
          {activeTab === 'OVERVIEW' && (
            <OverviewPage
              client={storeState.client}
              accounts={storeState.accounts}
              portfolio={storeState.portfolio}
              vemState={storeState.vemMonetary}
              euroPos={storeState.euroPos}
              events={storeState.systemEvents}
              onRunDemo={handleRunBerlinDemo}
              isDemoRunning={isDemoRunning}
              demoLogs={demoLogs}
              setActiveTab={setActiveTab}
            />
          )}

          {(activeTab === 'ACCOUNTS' || activeTab === 'PAYMENTS') && (
            <BankingPage
              accounts={storeState.accounts}
              transactions={storeState.transactions}
              onTransfer={handleTransfer}
            />
          )}

          {activeTab === 'CARDS' && <CardPreview />}

          {activeTab === 'DIGITAL_EURO' && (
            <DigitalEuroPage
              accounts={storeState.accounts}
              onTransfer={handleTransfer}
            />
          )}

          {activeTab === 'VESUVIUS_MARK' && (
            <VesuviusMarkPage
              vemState={storeState.vemMonetary}
              accounts={storeState.accounts}
              onMint={handleMintVem}
              onRedeem={handleRedeemVem}
            />
          )}

          {activeTab === 'PORTFOLIO' && (
            <WealthPage
              portfolio={storeState.portfolio}
              entityMode={entityMode}
            />
          )}

          {activeTab === 'MARKETS' && (
            <MarketsPage fxQuotes={storeState.fxQuotes} />
          )}

          {activeTab === 'TREASURY' && <TreasuryPage />}

          {activeTab === 'EURO_POS' && (
            <EuroPosPage
              euroPos={storeState.euroPos}
              onRunScenario={handleRunEuroPosScenario}
            />
          )}

          {(activeTab === 'MACRO' || activeTab === 'QUANT') && (
            <ResearchPage macroCountries={storeState.macroCountries} />
          )}

          {(activeTab === 'RELATIONSHIP' || activeTab === 'AI_BANKER') && (
            <PrivateBankingPage
              client={storeState.client}
              portfolio={storeState.portfolio}
              accounts={storeState.accounts}
            />
          )}

          {(activeTab === 'SECURITY' || activeTab === 'AUDIT') && (
            <SecurityAndAdminPage auditLogs={storeState.auditLogs} />
          )}
        </main>
      </div>
    </div>
  );
}
