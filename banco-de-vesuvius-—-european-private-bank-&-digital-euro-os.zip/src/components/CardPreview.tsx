import React from 'react';
import { ShieldCheck, CreditCard, Wifi, Lock } from 'lucide-react';

export const CardPreview: React.FC = () => {
  return (
    <div className="p-6 max-w-[1200px] mx-auto space-y-8 font-mono text-xs">
      <div className="bg-[#11141c] border border-[#222838] p-5 rounded-xl shadow-lg flex justify-between items-center">
        <div>
          <span className="text-xs text-amber-400 uppercase tracking-widest">
            PHYSICAL PRIVATE BANKING INSTRUMENT
          </span>
          <h1 className="text-xl text-slate-100 font-semibold tracking-wide uppercase mt-0.5">
            BANCO DE VESUVIUS PRIVATE CARD
          </h1>
        </div>
        <span className="px-3 py-1 bg-amber-950 text-amber-300 border border-amber-800 rounded font-mono">
          MATTE GRAPHITE TITANIUM
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        {/* Card Graphic */}
        <div className="bg-[#121620] border border-[#222836] p-6 rounded-xl shadow-2xl relative overflow-hidden flex flex-col items-center">
          <img
            src="/src/assets/images/banco_vesuvius_card_1790514595835.jpg"
            alt="Banco de Vesuvius Private Metal Card"
            className="w-full max-w-sm rounded-xl shadow-2xl border border-slate-700/50 hover:scale-105 transition-transform duration-500"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Card Capabilities Specification */}
        <div className="bg-[#11141c] border border-[#222838] p-6 rounded-xl space-y-4 shadow-xl text-slate-300">
          <h2 className="text-sm text-slate-100 font-semibold uppercase border-b border-[#202634] pb-2">
            CARD CAPABILITIES & MULTI-RAIL COMPATIBILITY
          </h2>

          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>COMMERCIAL EUR ACCOUNT LINK</span>
              <span className="text-emerald-400 font-bold">ACTIVE (SEPA INSTANT)</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>VESUVIUS MARK (VEM) PAYMENTS</span>
              <span className="text-amber-300 font-bold">1:1 INSTANT CLEARING</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>DIGITAL EURO COMPATIBILITY</span>
              <span className="text-sky-300 font-bold">SECURE ELEMENT SYNC</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-[#161a24] rounded border border-[#232a3b]">
              <span>DYNAMIC SECURITY CODE</span>
              <span className="text-slate-100 font-bold">E-INK CVV REFRESH (60s)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
