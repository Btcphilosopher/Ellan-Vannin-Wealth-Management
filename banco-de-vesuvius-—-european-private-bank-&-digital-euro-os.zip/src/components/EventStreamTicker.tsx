import React from 'react';
import { SystemEvent } from '../types/vesuvius';
import { Activity, Cpu, CheckCircle2, RefreshCw } from 'lucide-react';

interface EventStreamTickerProps {
  events: SystemEvent[];
}

export const EventStreamTicker: React.FC<EventStreamTickerProps> = ({ events }) => {
  return (
    <div className="bg-[#0b0d11] border-b border-[#1c212b] px-4 py-2 flex items-center gap-3 overflow-x-auto text-xs font-mono shrink-0">
      <div className="flex items-center gap-1.5 text-amber-400 font-semibold shrink-0 uppercase tracking-widest text-[11px] border-r border-[#222834] pr-3">
        <Activity className="w-3.5 h-3.5 animate-pulse" />
        <span>LIVE EVENT STREAM</span>
      </div>

      <div className="flex items-center gap-6 overflow-x-auto whitespace-nowrap scrollbar-none py-0.5">
        {events.slice(0, 5).map((evt) => (
          <div key={evt.id} className="flex items-center gap-2 shrink-0 text-slate-300">
            <span className="text-slate-400 text-[11px]">{evt.timestamp}</span>
            <span className="px-1.5 py-0.5 text-[10px] bg-[#1a202c] text-sky-300 rounded border border-[#2a3242]">
              {evt.type}
            </span>
            <span className="text-slate-200">{evt.description}</span>
            <span className="text-[10px] text-slate-400 font-mono">[{evt.actor}]</span>
            <span className="text-slate-400 font-mono text-[10px] text-amber-300/80">
              {evt.auditHash.substring(0, 10)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
