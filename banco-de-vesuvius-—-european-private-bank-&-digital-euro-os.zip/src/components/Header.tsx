import React from 'react';
import { ShieldCheck, Building2, Globe, Cpu, RefreshCw } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  entityMode: 'PRIVATE' | 'FAMILY_OFFICE' | 'CORPORATE';
  setEntityMode: (mode: 'PRIVATE' | 'FAMILY_OFFICE' | 'CORPORATE') => void;
  onRunDemo: () => void;
  isDemoRunning: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  entityMode,
  setEntityMode,
  onRunDemo,
  isDemoRunning,
}) => {
  return (
    <header className="sticky top-0 z-50 bg-[#0c0e12]/95 backdrop-blur-md border-b border-[#222730] px-4 md:px-8 py-3.5">
      <div className="flex items-center justify-between gap-4 max-w-[1600px] mx-auto">
        {/* Zone 1: Single text element wordmark with V logo */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('OVERVIEW')}
            className="flex items-center gap-2.5 group text-left focus:outline-none"
          >
            <div className="w-8 h-8 rounded bg-[#1e232d] border border-[#333a48] flex items-center justify-center text-[#d4af37] font-semibold text-lg tracking-tighter group-hover:border-[#d4af37] transition-colors">
              V
            </div>
            <div>
              <span className="text-base font-semibold tracking-wider text-slate-100 uppercase font-sans">
                BANCO DE VESUVIUS
              </span>
              <div className="text-[10px] text-slate-400 font-mono tracking-widest flex items-center gap-1.5">
                <span>BERLIN</span>
                <span>·</span>
                <span>PRIVATE BANKING</span>
                <span>·</span>
                <span className="text-[#38bdf8]">EURO OS</span>
              </div>
            </div>
          </button>
        </div>

        {/* Zone 2: Entity Mode Switcher & Key Navigation Links */}
        <div className="hidden lg:flex items-center gap-1 bg-[#141820] p-1 rounded-lg border border-[#222730] text-xs">
          <button
            onClick={() => setEntityMode('PRIVATE')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              entityMode === 'PRIVATE'
                ? 'bg-[#222834] text-slate-100 shadow-sm border border-[#333c4d]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Private Client
          </button>
          <button
            onClick={() => setEntityMode('FAMILY_OFFICE')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              entityMode === 'FAMILY_OFFICE'
                ? 'bg-[#222834] text-amber-200 shadow-sm border border-[#333c4d]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Family Office
          </button>
          <button
            onClick={() => setEntityMode('CORPORATE')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              entityMode === 'CORPORATE'
                ? 'bg-[#222834] text-sky-200 shadow-sm border border-[#333c4d]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Corporate Treasury
          </button>
        </div>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onRunDemo}
            disabled={isDemoRunning}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-mono font-medium text-amber-300 bg-[#252014] border border-[#4a3b1d] rounded-md hover:bg-[#332b1a] transition-all shadow-sm focus:outline-none disabled:opacity-50"
            title="Execute full end-to-end Berlin private client transaction flow"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isDemoRunning ? 'animate-spin' : ''}`} />
            <span className="whitespace-nowrap">
              {isDemoRunning ? 'SIMULATING...' : 'RUN BERLIN DEMO'}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('EURO_POS')}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono text-slate-300 bg-[#161a22] border border-[#262c38] rounded-md hover:border-[#38bdf8] transition-colors"
          >
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span>EURO PoS: 128 NODES</span>
          </button>

          <button
            onClick={() => setActiveTab('SECURITY')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-300 bg-[#14171f] border border-[#222732] rounded-md hover:text-slate-100 transition-colors"
            title="System Security & Privacy"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden md:inline font-mono">SECP256R1</span>
          </button>
        </div>
      </div>
    </header>
  );
};
