import React from 'react';
import {
  LayoutDashboard,
  Landmark,
  Wallet,
  Coins,
  Cpu,
  TrendingUp,
  LineChart,
  Vault,
  Globe2,
  Sliders,
  UserCheck,
  Bot,
  Shield,
  FileCheck2,
  CreditCard,
  Send,
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const navSections = [
    {
      group: 'OVERVIEW',
      items: [{ id: 'OVERVIEW', label: 'Master Control', icon: LayoutDashboard }],
    },
    {
      group: 'BANKING',
      items: [
        { id: 'ACCOUNTS', label: 'Accounts & SEPA', icon: Landmark },
        { id: 'PAYMENTS', label: 'Payments & Transfers', icon: Send },
        { id: 'CARDS', label: 'Physical Bank Cards', icon: CreditCard },
        { id: 'DIGITAL_EURO', label: 'Digital Euro (ECB)', icon: Wallet },
        { id: 'VESUVIUS_MARK', label: 'Vesuvius Mark (VEM)', icon: Coins },
      ],
    },
    {
      group: 'WEALTH & INVESTMENTS',
      items: [
        { id: 'PORTFOLIO', label: 'HNW Portfolio Engine', icon: TrendingUp },
        { id: 'MARKETS', label: 'European FX & Rates', icon: LineChart },
      ],
    },
    {
      group: 'EURO INFRASTRUCTURE',
      items: [
        { id: 'EURO_POS', label: 'Euro PoS Consensus', icon: Cpu },
        { id: 'TREASURY', label: 'Institutional Treasury', icon: Vault },
      ],
    },
    {
      group: 'RESEARCH & MACRO',
      items: [
        { id: 'MACRO', label: 'European Macro & Policy', icon: Globe2 },
        { id: 'QUANT', label: 'R & Python Analytics', icon: Sliders },
      ],
    },
    {
      group: 'PRIVATE BANKING & AI',
      items: [
        { id: 'RELATIONSHIP', label: 'Relationship Manager', icon: UserCheck },
        { id: 'AI_BANKER', label: 'Vesuvius Intelligence', icon: Bot },
      ],
    },
    {
      group: 'SECURITY & GOVERNANCE',
      items: [
        { id: 'SECURITY', label: 'Privacy & Security', icon: Shield },
        { id: 'AUDIT', label: 'Compliance & Audit Log', icon: FileCheck2 },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-[#0c0e12] border-r border-[#1e232d] flex flex-col shrink-0 min-h-[calc(100vh-57px)]">
      <div className="p-4 border-b border-[#1b2029]">
        <div className="text-[11px] font-mono text-slate-400 tracking-wider uppercase mb-1">
          OPERATING SYSTEM
        </div>
        <div className="text-xs font-medium text-slate-200 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>BERLIN NODE ACTIVE</span>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-3 space-y-5">
        {navSections.map((sec) => (
          <div key={sec.group}>
            <div className="px-2 text-[10px] font-mono font-semibold text-slate-400 tracking-widest uppercase mb-1.5">
              {sec.group}
            </div>
            <div className="space-y-0.5">
              {sec.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-md text-xs font-medium transition-all text-left focus:outline-none ${
                      isActive
                        ? 'bg-[#1a202c] text-slate-100 border-l-2 border-[#d4af37] pl-2 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-[#141820]'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#d4af37]' : 'text-slate-400'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="p-3 border-t border-[#1b2029] bg-[#0a0c0f]">
        <div className="text-[10px] font-mono text-slate-400">BUILD: v3.6.8-BERLIN-PROD</div>
        <div className="text-[10px] text-slate-400 mt-0.5">ESTR: 3.25% · ECB DEPOSIT: 3.25%</div>
      </div>
    </aside>
  );
};
