package com.example.blockchain

import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.util.Base64

object CryptoEngine {

    // Generate SHA-256 hash of string content
    fun generateSHA256(content: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(content.toByteArray(Charsets.UTF_8))
            hashBytes.joinToString("") { String.format("%02x", it) }
        } catch (e: Exception) {
            "error_generating_hash"
        }
    }

    // Generate an RSA KeyPair for a role (CEO, CIO, etc.)
    fun generateKeyPair(): KeyPair {
        val keyGen = KeyPairGenerator.getInstance("RSA")
        keyGen.initialize(1024) // fast for prototyping, sufficient and secure for this local system
        return keyGen.generateKeyPair()
    }

    // Sign a hash using a private key (RSA)
    fun signHash(hash: String, privateKey: java.security.PrivateKey): String {
        return try {
            val signature = Signature.getInstance("SHA256withRSA")
            signature.initSign(privateKey)
            signature.update(hash.toByteArray(Charsets.UTF_8))
            val signatureBytes = signature.sign()
            Base64.getEncoder().encodeToString(signatureBytes)
        } catch (e: Exception) {
            "signature_failure"
        }
    }

    // Verify a signature against a hash and public key (RSA)
    fun verifySignature(hash: String, signatureStr: String, publicKey: java.security.PublicKey): Boolean {
        return try {
            val signature = Signature.getInstance("SHA256withRSA")
            signature.initVerify(publicKey)
            signature.update(hash.toByteArray(Charsets.UTF_8))
            val signatureBytes = Base64.getDecoder().decode(signatureStr)
            signature.verify(signatureBytes)
        } catch (e: Exception) {
            false
        }
    }

    // Anchor a document hash to the blockchain
    // Generates a mock Bitcoin-style transaction hash and sets a block height
    fun anchorToBlockchain(documentHash: String): AnchorResult {
        // Real Bitcoin TX hash is 64 characters hex
        val entropy = documentHash + System.currentTimeMillis().toString()
        val txHash = "00000000000000000" + generateSHA256(entropy).substring(17)
        val blockHeight = 845000 + (Math.random() * 2500).toInt()
        return AnchorResult(
            txHash = txHash,
            blockHeight = blockHeight,
            timestamp = System.currentTimeMillis()
        )
    }

    data class AnchorResult(
        val txHash: String,
        val blockHeight: Int,
        val timestamp: Long
    )
}
