package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SovereignAccentNavy
import com.example.ui.theme.SovereignGold
import com.example.ui.theme.SovereignNavyDark
import com.example.ui.screens.*
import com.example.viewmodel.EOSViewModel
import com.example.data.InfrastructureProject
import com.example.ui.components.IsleOfManInvestmentMap

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val eosViewModel: EOSViewModel = viewModel()
                    val isLoggedIn by eosViewModel.isLoggedIn.collectAsState()

                    if (!isLoggedIn) {
                        LoginScreen(viewModel = eosViewModel)
                    } else {
                        EosMasterLayout(viewModel = eosViewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun EosMasterLayout(viewModel: EOSViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val activeRole by viewModel.activeUserRole.collectAsState()

    // Determine tablet vs phone responsive layout using BoxWithConstraints
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        val isTablet = maxWidth >= 720.dp

        if (isTablet) {
            // Tablet layout: Side Navigation Rail + Rich Main View (multi-pane ready)
            Row(modifier = Modifier.fillMaxSize()) {
                EosNavigationRail(
                    currentScreen = currentScreen,
                    onScreenSelected = { viewModel.currentScreen.value = it },
                    activeRole = activeRole,
                    onLogout = { viewModel.logout() }
                )

                VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                Column(modifier = Modifier.weight(1f)) {
                    EosTopHeader(viewModel = viewModel, activeRole = activeRole)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    Box(modifier = Modifier.weight(1f)) {
                        RenderScreen(screen = currentScreen, viewModel = viewModel, isTablet = true)
                    }
                }
            }
        } else {
            // Phone layout: Top Header + Main View + Bottom Navigation
            Column(modifier = Modifier.fillMaxSize()) {
                EosTopHeader(viewModel = viewModel, activeRole = activeRole)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                Box(modifier = Modifier.weight(1f)) {
                    RenderScreen(screen = currentScreen, viewModel = viewModel, isTablet = false)
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                EosBottomNavigation(
                    currentScreen = currentScreen,
                    onScreenSelected = { viewModel.currentScreen.value = it }
                )
            }
        }
    }
}

@Composable
fun EosTopHeader(viewModel: EOSViewModel, activeRole: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = "EOS Crest",
                tint = SovereignAccentNavy,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = "ELLAN VANNIN EOS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Role Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(SovereignAccentNavy.copy(alpha = 0.15f))
                    .border(1.dp, SovereignAccentNavy.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = activeRole.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = SovereignAccentNavy,
                    fontSize = 10.sp
                )
            }

            // Quick system audit icon
            Icon(
                imageVector = Icons.Default.Circle,
                contentDescription = "System Nominal",
                tint = Color(0xFF10B981),
                modifier = Modifier.size(8.dp)
            )

            // Logout quick tap
            IconButton(
                onClick = { viewModel.logout() },
                modifier = Modifier.size(24.dp).testTag("logout_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Logout,
                    contentDescription = "Logout session",
                    tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun EosNavigationRail(
    currentScreen: EOSViewModel.Screen,
    onScreenSelected: (EOSViewModel.Screen) -> Unit,
    activeRole: String,
    onLogout: () -> Unit
) {
    NavigationRail(
        containerColor = MaterialTheme.colorScheme.background,
        header = {
            Icon(
                imageVector = Icons.Default.AccountBalance,
                contentDescription = "Crest",
                tint = SovereignAccentNavy,
                modifier = Modifier
                    .size(32.dp)
                    .padding(bottom = 8.dp)
            )
        }
    ) {
        Column(
            modifier = Modifier.fillMaxHeight(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                RailItem(EOSViewModel.Screen.Dashboard, Icons.Default.Dashboard, "Dash", currentScreen, onScreenSelected)
                RailItem(EOSViewModel.Screen.Portfolio, Icons.Default.PieChart, "Port", currentScreen, onScreenSelected)
                RailItem(EOSViewModel.Screen.Infrastructure, Icons.Default.Business, "Infr", currentScreen, onScreenSelected)
                RailItem(EOSViewModel.Screen.Treasury, Icons.Default.AccountBalance, "Treas", currentScreen, onScreenSelected)
                RailItem(EOSViewModel.Screen.BitcoinTreasury, Icons.Default.MonetizationOn, "BTC", currentScreen, onScreenSelected)
                RailItem(EOSViewModel.Screen.Governance, Icons.Default.Gavel, "Gov", currentScreen, onScreenSelected)
                RailItem(EOSViewModel.Screen.Map, Icons.Default.Map, "Map", currentScreen, onScreenSelected)
                RailItem(EOSViewModel.Screen.Reports, Icons.Default.Description, "Rep", currentScreen, onScreenSelected)
                RailItem(EOSViewModel.Screen.AIAssistant, Icons.Default.Terminal, "AI", currentScreen, onScreenSelected)
                RailItem(EOSViewModel.Screen.Settings, Icons.Default.Settings, "Set", currentScreen, onScreenSelected)
            }

            // Bottom session kill
            IconButton(onClick = onLogout, modifier = Modifier.padding(bottom = 16.dp)) {
                Icon(Icons.Default.Logout, "Exit session", tint = Color.Red.copy(alpha = 0.7f))
            }
        }
    }
}

@Composable
fun RailItem(
    screen: EOSViewModel.Screen,
    icon: ImageVector,
    label: String,
    currentScreen: EOSViewModel.Screen,
    onScreenSelected: (EOSViewModel.Screen) -> Unit
) {
    NavigationRailItem(
        selected = currentScreen == screen,
        onClick = { onScreenSelected(screen) },
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label, fontSize = 9.sp) },
        colors = NavigationRailItemDefaults.colors(
            selectedIconColor = SovereignAccentNavy,
            selectedTextColor = SovereignAccentNavy,
            unselectedIconColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            unselectedTextColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
        )
    )
}

@Composable
fun EosBottomNavigation(
    currentScreen: EOSViewModel.Screen,
    onScreenSelected: (EOSViewModel.Screen) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.background,
        tonalElevation = 8.dp
    ) {
        BottomNavItem(EOSViewModel.Screen.Dashboard, Icons.Default.Dashboard, "Dash", currentScreen, onScreenSelected)
        BottomNavItem(EOSViewModel.Screen.Portfolio, Icons.Default.PieChart, "Port", currentScreen, onScreenSelected)
        BottomNavItem(EOSViewModel.Screen.Infrastructure, Icons.Default.Business, "Infr", currentScreen, onScreenSelected)
        BottomNavItem(EOSViewModel.Screen.Governance, Icons.Default.Gavel, "Gov", currentScreen, onScreenSelected)
        BottomNavItem(EOSViewModel.Screen.Map, Icons.Default.Map, "Map", currentScreen, onScreenSelected)
        BottomNavItem(EOSViewModel.Screen.AIAssistant, Icons.Default.Terminal, "AI Shell", currentScreen, onScreenSelected)
        BottomNavItem(EOSViewModel.Screen.Reports, Icons.Default.Description, "Reports", currentScreen, onScreenSelected)
    }
}

@Composable
fun RowScope.BottomNavItem(
    screen: EOSViewModel.Screen,
    icon: ImageVector,
    label: String,
    currentScreen: EOSViewModel.Screen,
    onScreenSelected: (EOSViewModel.Screen) -> Unit
) {
    NavigationBarItem(
        selected = currentScreen == screen,
        onClick = { onScreenSelected(screen) },
        icon = { Icon(icon, contentDescription = label, modifier = Modifier.size(20.dp)) },
        label = { Text(label, fontSize = 9.sp) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = SovereignAccentNavy,
            selectedTextColor = SovereignAccentNavy,
            unselectedIconColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            unselectedTextColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
        )
    )
}

@Composable
fun RenderScreen(screen: EOSViewModel.Screen, viewModel: EOSViewModel, isTablet: Boolean) {
    when (screen) {
        EOSViewModel.Screen.Dashboard -> DashboardScreen(viewModel = viewModel)
        EOSViewModel.Screen.Portfolio -> PortfolioScreen(viewModel = viewModel)
        EOSViewModel.Screen.Infrastructure -> InfrastructureScreen(viewModel = viewModel)
        EOSViewModel.Screen.Treasury -> TreasuryScreen(viewModel = viewModel)
        EOSViewModel.Screen.BitcoinTreasury -> BitcoinTreasuryScreen(viewModel = viewModel)
        EOSViewModel.Screen.Governance -> GovernanceScreen(viewModel = viewModel)
        EOSViewModel.Screen.Map -> {
            val projects by viewModel.infrastructureProjects.collectAsState()
            val selectedProject by viewModel.selectedProjectOnMap.collectAsState()

            if (isTablet) {
                // Two-pane: Left Map, Right detail
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(modifier = Modifier.weight(1.2f).padding(16.dp)) {
                        IsleOfManInvestmentMap(
                            projects = projects,
                            selectedProject = selectedProject,
                            onProjectSelected = { viewModel.selectedProjectOnMap.value = it },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    Box(modifier = Modifier.weight(0.8f).padding(16.dp)) {
                        if (selectedProject != null) {
                            MapDetailPane(project = selectedProject!!, viewModel = viewModel)
                        } else {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Select an asset pin on the sovereign map to view full logs.", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f), fontSize = 12.sp)
                            }
                        }
                    }
                }
            } else {
                // Single column scrollable
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IsleOfManInvestmentMap(
                        projects = projects,
                        selectedProject = selectedProject,
                        onProjectSelected = { viewModel.selectedProjectOnMap.value = it },
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (selectedProject != null) {
                        MapDetailPane(project = selectedProject!!, viewModel = viewModel)
                    }
                }
            }
        }
        EOSViewModel.Screen.Reports -> ReportsScreen(viewModel = viewModel)
        EOSViewModel.Screen.AIAssistant -> AIScreen(viewModel = viewModel)
        EOSViewModel.Screen.Settings -> SettingsScreen(viewModel = viewModel)
    }
}

@Composable
fun MapDetailPane(project: InfrastructureProject, viewModel: EOSViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(project.name.uppercase(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Audited Location Coordinates: ${project.latitude}°N, ${project.longitude}°W", style = MaterialTheme.typography.bodySmall, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, color = SovereignAccentNavy)

            Divider(color = MaterialTheme.colorScheme.outlineVariant)

            DetailRow("Capital Investment", viewModel.formatCurrency(project.capitalInvested))
            DetailRow("Current Valuation", viewModel.formatCurrency(project.currentValuation))
            DetailRow("Project Yield (IRR)", "${String.format("%.1f", project.expectedIrr * 100)}%")
            DetailRow("Annual Cash Flow", viewModel.formatCurrency(project.cashFlow))
            DetailRow("Employment Impact", "${project.employmentCount} Jobs Created")
            DetailRow("Timeline Schedule", project.timeline)
            DetailRow("Gearing (Debt Ratio)", "${String.format("%.1f", (project.debt / project.capitalInvested) * 100)}%")

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.03f), RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    "Sovereign Note: Geolocation status confirmed via satellite orbital audits. Core cash flow channels are locked to the Isle of Man Treasury Gilt index.",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}
