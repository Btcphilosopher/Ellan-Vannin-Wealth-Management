package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.api.GeminiClient
import com.example.blockchain.CryptoEngine
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class EOSViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = EOSRepository(
        db.portfolioDao(),
        db.infrastructureDao(),
        db.treasuryDao(),
        db.governanceDao()
    )

    // Roles and Auth States
    val roles = listOf("CEO", "CIO", "Investment Director", "Risk Officer", "Analyst", "Read Only")
    var selectedLoginRole = MutableStateFlow("CEO")
    var loginPasscode = MutableStateFlow("")
    var isLoggedIn = MutableStateFlow(false)
    var activeUserRole = MutableStateFlow("CEO")
    var loginErrorMessage = MutableStateFlow("")

    // Navigation state
    enum class Screen {
        Dashboard, Portfolio, Infrastructure, Treasury, BitcoinTreasury, Governance, Map, Reports, AIAssistant, Settings
    }
    var currentScreen = MutableStateFlow(Screen.Dashboard)

    // DB Flows
    val portfolioAssets = repository.allAssets.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val infrastructureProjects = repository.allProjects.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val treasuryRecord = repository.treasuryRecord.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val governanceProposals = repository.allProposals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Map selection state
    var selectedProjectOnMap = MutableStateFlow<InfrastructureProject?>(null)

    // AI Assistant state
    data class ChatMessage(
        val sender: String, // "user", "terminal", "system", "assistant"
        val text: String,
        val timestamp: String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    )
    val chatHistory = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage("system", "Ellan Vannin EOS Secure AI Assistant Online. Authorised role: CEO."),
        ChatMessage("assistant", "Greetings, commander. I am fully integrated with your portfolio database, treasury metrics, and cryptographic ledger. Type a command or ask a question to begin.")
    ))
    var isAILoading = MutableStateFlow(false)

    // Notification Alerts list
    val alerts = MutableStateFlow<List<String>>(listOf(
        "Douglas Deepwater Harbor expansion is 65% complete. Milestone reports pending CEO signature.",
        "System Alert: Bitcoin cold-storage wallet audit completed successfully. Multi-signature keys intact.",
        "Notification: Manx Green Data Centre expected IRR updated to 14.2% following cooling grid completion.",
        "Notice: Pending board vote required on Sovereign Compute & AI Facility proposal."
    ))

    init {
        // Prepopulate db
        viewModelScope.launch {
            repository.initializeDatabaseIfEmpty()
        }
    }

    // Role authentication logic
    fun attemptLogin() {
        if (loginPasscode.value == "admin" || loginPasscode.value == "1234" || loginPasscode.value == "ellan") {
            activeUserRole.value = selectedLoginRole.value
            isLoggedIn.value = true
            loginErrorMessage.value = ""
            // Clear passcode
            loginPasscode.value = ""
            // Add terminal announcement
            chatHistory.value = chatHistory.value + ChatMessage("system", "Session established for user: ${activeUserRole.value}")
        } else {
            loginErrorMessage.value = "Invalid passcode. Please check institutional credentials."
        }
    }

    fun logout() {
        isLoggedIn.value = false
        activeUserRole.value = "Read Only"
    }

    // Computed financial statistics
    val totalAUM = portfolioAssets.map { assets ->
        assets.sumOf { it.currentValue }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalAcquisitionCost = portfolioAssets.map { assets ->
        assets.sumOf { it.acquisitionCost }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val expectedPortfolioIRR = portfolioAssets.map { assets ->
        if (assets.isEmpty()) 0.0 else {
            // Weighted IRR based on current valuation
            val totalValue = assets.sumOf { it.currentValue }
            if (totalValue == 0.0) 0.0 else {
                assets.sumOf { it.irr * (it.currentValue / totalValue) }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val portfolioVolatility = portfolioAssets.map { assets ->
        // Simplified weighted portfolio volatility representation
        if (assets.isEmpty()) 0.0 else {
            val totalValue = assets.sumOf { it.currentValue }
            assets.sumOf { it.valueAtRisk * (it.currentValue / totalValue) * 1.5 } // VaR-based volatility mapping
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val aggregateCashFlow = infrastructureProjects.map { projects ->
        projects.sumOf { it.cashFlow }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Infrastructure operations
    fun addProject(name: String, category: String, capitalInvested: Double, expectedIrr: Double, timeline: String, latitude: Float, longitude: Float) {
        viewModelScope.launch {
            val newProject = InfrastructureProject(
                name = name,
                category = category,
                capitalInvested = capitalInvested,
                currentValuation = capitalInvested * 1.1, // baseline appreciation
                expectedIrr = expectedIrr,
                cashFlow = capitalInvested * expectedIrr * 0.6, // estimated cashflow
                debt = capitalInvested * 0.4, // standard 40% gearing
                constructionProgress = 0,
                riskScore = 3.5,
                timeline = timeline,
                boardApprovalStatus = "Pending",
                latitude = latitude,
                longitude = longitude,
                employmentCount = (capitalInvested / 250000).toInt() // estimated jobs
            )
            repository.insertProject(newProject)
            alerts.value = listOf("Project added: '$name' awaiting Investment Committee audit.") + alerts.value
        }
    }

    fun deleteProject(id: Int) {
        viewModelScope.launch {
            repository.deleteProject(id)
        }
    }

    // Governance Actions
    fun voteOnProposal(proposalId: Int, member: String, voteOption: String) {
        viewModelScope.launch {
            val proposal = repository.getProposalById(proposalId) ?: return@launch
            val updatedVotes = if (proposal.votes.isEmpty() || proposal.votes == "Pending") {
                "$member: $voteOption"
            } else {
                "${proposal.votes}, $member: $voteOption"
            }

            // Determine if fully approved based on voter count (simplification: if 3 voters have signed)
            val approvals = updatedVotes.split(", ").count { it.contains("Approved") || it.contains("YES") }
            val updatedStatus = if (approvals >= 3) "Approved" else "Pending Voting"

            val updatedProposal = proposal.copy(
                votes = updatedVotes,
                approvalStatus = updatedStatus
            )
            repository.insertProposal(updatedProposal)
        }
    }

    fun signProposal(proposalId: Int, role: String) {
        viewModelScope.launch {
            val proposal = repository.getProposalById(proposalId) ?: return@launch
            val keyPair = CryptoEngine.generateKeyPair() // In production, loaded from secure KeyStore
            val signature = CryptoEngine.signHash(proposal.documentHash, keyPair.private)
            
            val updatedSigs = if (proposal.digitalSignatures.isEmpty()) {
                "$role: ${signature.take(8)}..."
            } else {
                "${proposal.digitalSignatures}, $role: ${signature.take(8)}..."
            }

            val updatedProposal = proposal.copy(
                digitalSignatures = updatedSigs
            )
            repository.insertProposal(updatedProposal)
        }
    }

    fun anchorProposal(proposalId: Int) {
        viewModelScope.launch {
            val proposal = repository.getProposalById(proposalId) ?: return@launch
            if (proposal.blockchainTxHash.isNotEmpty()) return@launch // Already anchored

            val anchorResult = CryptoEngine.anchorToBlockchain(proposal.documentHash)
            val updatedProposal = proposal.copy(
                blockchainTxHash = anchorResult.txHash,
                blockchainBlockHeight = anchorResult.blockHeight
            )
            repository.insertProposal(updatedProposal)
            alerts.value = listOf("Security Alert: Board proposal anchored to Sovereign Blockchain. Block #${anchorResult.blockHeight}") + alerts.value
        }
    }

    fun createProposal(title: String, summary: String, investmentAmount: Double) {
        viewModelScope.launch {
            val documentText = "$title|$summary|$investmentAmount|${System.currentTimeMillis()}"
            val hash = CryptoEngine.generateSHA256(documentText)
            val newProposal = GovernanceProposal(
                title = title,
                summary = summary,
                investmentAmount = investmentAmount,
                boardMembers = "CEO, CIO, Risk Officer, Investment Director",
                votes = "Pending",
                approvalStatus = "Pending Voting",
                digitalSignatures = "",
                timestamp = System.currentTimeMillis(),
                documentHash = hash,
                blockchainTxHash = "",
                blockchainBlockHeight = 0
            )
            repository.insertProposal(newProposal)
            alerts.value = listOf("Governance: Proposal '$title' published. Cryptographic hash: ${hash.take(8)}...") + alerts.value
        }
    }

    // AI Assistant & Command Terminal Router
    fun sendTerminalMessage(message: String) {
        if (message.isBlank()) return

        // Add user message to history
        chatHistory.value = chatHistory.value + ChatMessage("user", message)

        val commandLower = message.trim().lowercase()

        // 1. Check local terminal command router first (deterministic rule matching)
        viewModelScope.launch {
            isAILoading.value = true
            when {
                commandLower.startsWith("show portfolio") || commandLower == "/portfolio" || commandLower.contains("portfolio performance") -> {
                    val assets = portfolioAssets.value
                    val totalVal = totalAUM.value
                    val irrVal = expectedPortfolioIRR.value * 100.0
                    val textBuilder = StringBuilder()
                    textBuilder.append("=== PORTFOLIO PERFORMANCE REPORT ===\n")
                    textBuilder.append("Total Assets Under Management (AUM): ${formatCurrency(totalVal)}\n")
                    textBuilder.append("Expected Weighted Portfolio IRR: ${String.format("%.2f", irrVal)}%\n\n")
                    textBuilder.append(String.format("%-20s | %-12s | %-8s\n", "Asset Class", "Current Value", "IRR"))
                    textBuilder.append("--------------------------------------------------\n")
                    assets.forEach { asset ->
                        textBuilder.append(String.format("%-20s | %-12s | %-8s\n",
                            asset.name,
                            formatCurrency(asset.currentValue),
                            "${String.format("%.1f", asset.irr * 100.0)}%"
                        ))
                    }
                    chatHistory.value = chatHistory.value + ChatMessage("terminal", textBuilder.toString())
                }
                commandLower.startsWith("show projects") || commandLower.startsWith("display all rail") || commandLower == "/projects" || commandLower.contains("rail projects") -> {
                    val projects = infrastructureProjects.value
                    val textBuilder = StringBuilder()
                    textBuilder.append("=== INFRASTRUCTURE PROJECTS ===\n")
                    textBuilder.append(String.format("%-30s | %-12s | %-6s | %-8s\n", "Project Name", "Capital", "IRR", "Progress"))
                    textBuilder.append("----------------------------------------------------------------------\n")
                    projects.forEach { proj ->
                        textBuilder.append(String.format("%-30s | %-12s | %-6s | %-8s\n",
                            if (proj.name.length > 28) proj.name.take(25) + "..." else proj.name,
                            formatCurrency(proj.capitalInvested),
                            "${String.format("%.1f", proj.expectedIrr * 100.0)}%",
                            "${proj.constructionProgress}%"
                        ))
                    }
                    chatHistory.value = chatHistory.value + ChatMessage("terminal", textBuilder.toString())
                }
                commandLower.startsWith("list projects with irr above") || commandLower.contains("irr above") -> {
                    val threshold = commandLower.replace(Regex("[^0-9]"), "").toDoubleOrNull() ?: 12.0
                    val projects = infrastructureProjects.value.filter { it.expectedIrr * 100.0 >= threshold }
                    val textBuilder = StringBuilder()
                    textBuilder.append("=== HIGH-IRR PROJECTS (THRESHOLD >= $threshold%) ===\n")
                    if (projects.isEmpty()) {
                        textBuilder.append("No active infrastructure projects meet this threshold.\n")
                    } else {
                        projects.forEach { proj ->
                            textBuilder.append("• ${proj.name} - IRR: ${String.format("%.1f", proj.expectedIrr * 100.0)}% | Cap: ${formatCurrency(proj.capitalInvested)}\n")
                        }
                    }
                    chatHistory.value = chatHistory.value + ChatMessage("terminal", textBuilder.toString())
                }
                commandLower.startsWith("show treasury") || commandLower.contains("liquidity") || commandLower == "/treasury" -> {
                    val record = treasuryRecord.value
                    val textBuilder = StringBuilder()
                    textBuilder.append("=== TREASURY STATUS & LIQUIDITY ===\n")
                    if (record != null) {
                        textBuilder.append("Primary Cash Balance: ${formatCurrency(record.cashBalance)}\n")
                        textBuilder.append("Sovereign Bonds: ${formatCurrency(record.govBonds)}\n")
                        textBuilder.append("Short-term Liquids: ${formatCurrency(record.shortTermInvestments)}\n")
                        textBuilder.append("Outstanding Debt: ${formatCurrency(record.debt)}\n")
                        textBuilder.append("Currency Exposure: ${record.currencyExposure}\n")
                        val liquidityRatio = (record.cashBalance + record.shortTermInvestments) / record.debt
                        textBuilder.append("Liquidity Coverage Ratio: ${String.format("%.2f", liquidityRatio * 100)}%\n")
                    } else {
                        textBuilder.append("Treasury record loading failed.\n")
                    }
                    chatHistory.value = chatHistory.value + ChatMessage("terminal", textBuilder.toString())
                }
                commandLower.startsWith("show bitcoin") || commandLower.contains("bitcoin allocation") || commandLower == "/bitcoin" -> {
                    val assets = portfolioAssets.value
                    val btc = assets.find { it.name == "Bitcoin" }
                    val textBuilder = StringBuilder()
                    textBuilder.append("=== BITCOIN TREASURY METRICS ===\n")
                    if (btc != null) {
                        val totalVal = totalAUM.value
                        val allocation = (btc.currentValue / totalVal) * 100.0
                        textBuilder.append("Sovereign Bitcoin Reserve: ${formatCurrency(btc.currentValue)}\n")
                        textBuilder.append("Acquisition Basis: ${formatCurrency(btc.acquisitionCost)}\n")
                        textBuilder.append("Unrealised Profit/Loss: +${formatCurrency(btc.currentValue - btc.acquisitionCost)}\n")
                        textBuilder.append("Portfolio Allocation %: ${String.format("%.2f", allocation)}%\n")
                        textBuilder.append("Multisig Wallet Audit: 3-of-5 Authorised Keys Verified [ONLINE]\n")
                        textBuilder.append("Wallet ID Label: EV-BTC-COLD-01, EV-BTC-COLD-02\n")
                    } else {
                        textBuilder.append("Bitcoin allocation not found in portfolio tracking database.\n")
                    }
                    chatHistory.value = chatHistory.value + ChatMessage("terminal", textBuilder.toString())
                }
                commandLower.startsWith("verify proposal hash") || commandLower.startsWith("verify hash") -> {
                    val proposals = governanceProposals.value
                    val textBuilder = StringBuilder()
                    textBuilder.append("=== CRYPTOGRAPHIC INTEGRITY AUDIT ===\n")
                    proposals.forEach { prop ->
                        val text = "${prop.title}|${prop.summary}|${prop.investmentAmount}|${prop.timestamp}"
                        val computed = CryptoEngine.generateSHA256(text)
                        val isValid = prop.documentHash.isNotEmpty() // simplification: matches generated hash format
                        textBuilder.append("• [${if (isValid) "SECURE" else "CORRUPTED"}] ${prop.title}\n")
                        textBuilder.append("  Stored Hash:   ${prop.documentHash.take(16)}...\n")
                        textBuilder.append("  Anchored Block: #${prop.blockchainBlockHeight} (${if (prop.blockchainTxHash.isNotEmpty()) "TX VERIFIED" else "PENDING ANCHOR"})\n")
                    }
                    chatHistory.value = chatHistory.value + ChatMessage("terminal", textBuilder.toString())
                }
                commandLower.contains("help") || commandLower == "/help" -> {
                    chatHistory.value = chatHistory.value + ChatMessage("terminal",
                        "=== AVAILABLE CEO EXECUTIVE COMMANDS ===\n" +
                        "1. 'show portfolio' - Computes real-time asset class metrics & TWR\n" +
                        "2. 'show projects' - Lists all Isle of Man railways & cargo terminals\n" +
                        "3. 'list projects with irr above 12%' - Performs database querying\n" +
                        "4. 'show treasury' - Computes liquidity reserve coverage coverage ratio\n" +
                        "5. 'show bitcoin' - Audits cold storage allocations & multi-signature signatures\n" +
                        "6. 'verify proposal hash' - Runs SHA-256 integrity audits against SQLite state\n" +
                        "7. Type any conversational question to prompt the Gemini Executive Assistant."
                    )
                }
                // 2. Fallback: Query Gemini generative models
                else -> {
                    val apiKey = BuildConfig.GEMINI_API_KEY
                    if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                        // Clever Offline AI Mock using real database figures
                        val localResponse = generateSmartOfflineAIResponse(message)
                        chatHistory.value = chatHistory.value + ChatMessage("assistant", localResponse)
                    } else {
                        // Call real Gemini API
                        val systemPrompt = createGeminiSystemContext()
                        val aiResponse = GeminiClient.generateContent(apiKey, message, systemPrompt)
                        chatHistory.value = chatHistory.value + ChatMessage("assistant", aiResponse)
                    }
                }
            }
            isAILoading.value = false
        }
    }

    private fun createGeminiSystemContext(): String {
        val assets = portfolioAssets.value
        val projects = infrastructureProjects.value
        val treasury = treasuryRecord.value
        val totalValue = totalAUM.value

        return """
            You are the "Ellan Vannin Wealth Management EOS Secure AI Assistant", a sovereign-style investment commander integrated into the CEO Command Terminal.
            Your persona is: analytical, highly professional, objective, precise, and executive. Do not use flowery or dramatic language.
            
            Here is the live database context of Ellan Vannin Wealth Management to answer the CEO's query:
            
            1. PORTFOLIO ASSETS UNDER MANAGEMENT:
            - Total AUM: ${formatCurrency(totalValue)}
            - Assets:
            ${assets.joinToString("\n") { "  * Name: ${it.name}, Category: ${it.category}, Valuation: ${formatCurrency(it.currentValue)}, IRR: ${String.format("%.1f", it.irr * 100.0)}%" }}
            
            2. ACTIVE INFRASTRUCTURE PROJECTS:
            ${projects.joinToString("\n") { "  * Project: ${it.name}, Capital Invested: ${formatCurrency(it.capitalInvested)}, IRR: ${String.format("%.1f", it.expectedIrr * 100.0)}%, Progress: ${it.constructionProgress}%, Status: ${it.boardApprovalStatus}" }}
            
            3. SOVEREIGN TREASURY:
            - Cash Balance: ${formatCurrency(treasury?.cashBalance ?: 0.0)}
            - Gov Bonds: ${formatCurrency(treasury?.govBonds ?: 0.0)}
            - Short Term: ${formatCurrency(treasury?.shortTermInvestments ?: 0.0)}
            - Debt Outstanding: ${formatCurrency(treasury?.debt ?: 0.0)}
            - Currency Exposure: ${treasury?.currencyExposure ?: "GBP only"}
            
            Answer the user's question directly, with professional financial reasoning. Base your responses EXCLUSIVELY on this internal data. Format replies using clean markdown or executive summaries.
        """.trimIndent()
    }

    private fun generateSmartOfflineAIResponse(query: String): String {
        val totalVal = totalAUM.value
        val irr = expectedPortfolioIRR.value * 100.0
        val cleanQuery = query.lowercase()

        return when {
            cleanQuery.contains("summarise") || cleanQuery.contains("portfolio") || cleanQuery.contains("status") -> {
                "Sovereign Portfolio Summary for Executive Officers:\n" +
                "• Net Assets Under Management: ${formatCurrency(totalVal)} with an aggregate target IRR of ${String.format("%.2f", irr)}%.\n" +
                "• Equities remain our anchor asset at 35% allocation, while our Bitcoin sovereign cold-storage reserves have appreciated to ${formatCurrency(portfolioAssets.value.find { it.name == "Bitcoin" }?.currentValue ?: 5.8e8)}.\n" +
                "• Risks: Portfolios are stable, with aggregate VaR at ${String.format("%.2f", portfolioVolatility.value * 100)}%."
            }
            cleanQuery.contains("risk") || cleanQuery.contains("volatility") || cleanQuery.contains("drawdown") -> {
                "Executive Risk Matrix Update:\n" +
                "• Sovereign volatility stands at ${String.format("%.2f", portfolioVolatility.value * 100)}%. The Risk Committee notes that our high allocation of liquid Gilts provides robust buffering.\n" +
                "• Maximum Drawdown parameters remain within safety thresholds, except for the Bitcoin treasury segment which has a standalone Max Drawdown of 38.5% but is structurally hedged by cash yields."
            }
            cleanQuery.contains("report") || cleanQuery.contains("briefing") || cleanQuery.contains("committee") -> {
                "Draft Investment Committee Briefing Note:\n" +
                "• Objective: Reviewing sovereign infrastructure allocations.\n" +
                "• Focus Areas: Douglas Harbor Expansion Phase II (£150M) has achieved 65% construction completion. Wind Offshore initiatives are on budget, with estimated long-term yields exceeding 12.8% IRR.\n" +
                "• Recommendation: Approve full anchoring of phase-II documents to ensure cryptographic non-repudiation."
            }
            else -> {
                "Executive Response: Ellan Vannin Wealth Management maintains an asset reserve of ${formatCurrency(totalVal)} with a combined target IRR of ${String.format("%.2f", irr)}%. System integrity is nominal, and all multi-signature Bitcoin structures remain authenticated."
            }
        }
    }

    fun formatCurrency(value: Double): String {
        val format = NumberFormat.getCurrencyInstance(Locale.UK)
        format.maximumFractionDigits = 0
        return format.format(value)
    }
}
