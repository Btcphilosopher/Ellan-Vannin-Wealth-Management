@file:OptIn(ExperimentalLayoutApi::class)
package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.InfrastructureProject
import com.example.data.PortfolioAsset
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalTextApi::class)
@Composable
fun AssetAllocationChart(
    assets: List<PortfolioAsset>,
    totalAUM: Double,
    modifier: Modifier = Modifier,
    onAssetSelected: (PortfolioAsset) -> Unit = {}
) {
    if (assets.isEmpty() || totalAUM == 0.0) return

    val colors = listOf(
        Color(0xFF38BDF8), // Equities - cyan
        Color(0xFF34D399), // Bonds - emerald
        Color(0xFFFBBF24), // Property - amber
        Color(0xFF818CF8), // Infrastructure - indigo
        Color(0xFFF87171), // Private Equity - red
        Color(0xFFFB7185), // Gold - rose
        Color(0xFFF59E0B), // Bitcoin - gold
        Color(0xFF94A3B8)  // Cash - slate
    )

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "SOVEREIGN CAPITAL ALLOCATION",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .size(180.dp)
                    .align(Alignment.CenterHorizontally),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    var startAngle = -90f
                    assets.forEachIndexed { index, asset ->
                        val sweepAngle = ((asset.currentValue / totalAUM) * 360f).toFloat()
                        val color = colors.getOrElse(index) { Color.Gray }

                        drawArc(
                            color = color,
                            startAngle = startAngle,
                            sweepAngle = sweepAngle,
                            useCenter = false,
                            style = Stroke(width = 24.dp.toPx(), cap = StrokeCap.Round),
                            size = Size(size.width - 24.dp.toPx(), size.height - 24.dp.toPx()),
                            topLeft = Offset(12.dp.toPx(), 12.dp.toPx())
                        )
                        startAngle += sweepAngle
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "TOTAL AUM",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                    Text(
                        text = formatCompactCurrency(totalAUM),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Custom Flow Grid for Chart Keys
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                maxItemsInEachRow = 3,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                assets.forEachIndexed { index, asset ->
                    val color = colors.getOrElse(index) { Color.Gray }
                    val percent = (asset.currentValue / totalAUM) * 100.0

                    Row(
                        modifier = Modifier
                            .padding(vertical = 4.dp)
                            .clickable { onAssetSelected(asset) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(color, RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${asset.name} (${String.format("%.1f", percent)}%)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IsleOfManInvestmentMap(
    projects: List<InfrastructureProject>,
    selectedProject: InfrastructureProject?,
    onProjectSelected: (InfrastructureProject) -> Unit,
    modifier: Modifier = Modifier
) {
    // Isle of Man geographic boundaries
    val minLat = 54.04f
    val maxLat = 54.44f
    val minLong = -4.85f
    val maxLong = -4.30f

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "SOVEREIGN INFRASTRUCTURE GEOLOCATION MAP",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Tap on coordinates to audit project pipelines directly",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(projects) {
                            detectTapGestures { offset ->
                                // Find closest project pin matching tap radius
                                projects.forEach { proj ->
                                    // Scale coordinates
                                    val x = ((proj.longitude - minLong) / (maxLong - minLong)) * size.width
                                    val y = (1f - (proj.latitude - minLat) / (maxLat - minLat)) * size.height
                                    val pinDistance = Offset(x, y).minus(offset).getDistance()
                                    if (pinDistance < 24.dp.toPx()) {
                                        onProjectSelected(proj)
                                    }
                                }
                            }
                        }
                ) {
                    val width = size.width
                    val height = size.height

                    // Draw the Isle of Man stylized island path (diamond shape northeast-southwest)
                    val islandPath = Path().apply {
                        moveTo(width * 0.70f, height * 0.15f) // Point of Ayre (North)
                        quadraticTo(width * 0.85f, height * 0.35f, width * 0.78f, height * 0.45f) // Ramsey bay
                        quadraticTo(width * 0.68f, height * 0.70f, width * 0.60f, height * 0.78f) // Douglas harbor
                        lineTo(width * 0.42f, height * 0.88f) // Castletown
                        lineTo(width * 0.30f, height * 0.90f) // Calf of Man (Southwest)
                        lineTo(width * 0.32f, height * 0.80f) // Port Erin
                        quadraticTo(width * 0.34f, height * 0.60f, width * 0.45f, height * 0.50f) // Peel
                        close()
                    }

                    // Fill Island with high-contrast sovereign gradient
                    drawPath(
                        path = islandPath,
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF1E293B), Color(0xFF334155)),
                            center = Offset(width / 2, height / 2),
                            radius = width / 2
                        )
                    )

                    // Draw contour border line
                    drawPath(
                        path = islandPath,
                        color = Color(0xFF475569),
                        style = Stroke(width = 2.dp.toPx())
                    )

                    // Overlay Map Grid lines for that Palantir / Command Centre look
                    for (i in 1..4) {
                        val xVal = width * (i / 5f)
                        drawLine(
                            color = Color(0xFF1E293B).copy(alpha = 0.4f),
                            start = Offset(xVal, 0f),
                            end = Offset(xVal, height),
                            strokeWidth = 1f
                        )
                        val yVal = height * (i / 5f)
                        drawLine(
                            color = Color(0xFF1E293B).copy(alpha = 0.4f),
                            start = Offset(0f, yVal),
                            end = Offset(width, yVal),
                            strokeWidth = 1f
                        )
                    }

                    // Plot and render Project Pins
                    projects.forEach { proj ->
                        val x = ((proj.longitude - minLong) / (maxLong - minLong)) * width
                        val y = (1f - (proj.latitude - minLat) / (maxLat - minLat)) * height

                        val isSelected = proj.id == selectedProject?.id
                        val pinColor = when (proj.category) {
                            "railways" -> Color(0xFF38BDF8)   // sky
                            "ports" -> Color(0xFF10B981)      // emerald
                            "airports" -> Color(0xFFF59E0B)   // gold
                            "data centres" -> Color(0xFFEC4899) // pink
                            "energy" -> Color(0xFFA855F7)     // purple
                            else -> Color(0xFF94A3B8)
                        }

                        // Glow circle
                        drawCircle(
                            color = pinColor.copy(alpha = if (isSelected) 0.5f else 0.25f),
                            radius = if (isSelected) 14.dp.toPx() else 8.dp.toPx(),
                            center = Offset(x, y)
                        )

                        // Center pin dot
                        drawCircle(
                            color = pinColor,
                            radius = 4.dp.toPx(),
                            center = Offset(x, y)
                        )

                        // Outline ring for selected pins
                        if (isSelected) {
                            drawCircle(
                                color = Color.White,
                                radius = 14.dp.toPx(),
                                center = Offset(x, y),
                                style = Stroke(width = 1.5.dp.toPx())
                            )
                        }
                    }
                }

                // Map Legend overlay
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .background(Color(0xFF0F172A).copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                        .padding(6.dp)
                ) {
                    Text("PINS Legend", style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(2.dp))
                    LegendItem("Railways", Color(0xFF38BDF8))
                    LegendItem("Douglas Port", Color(0xFF10B981))
                    LegendItem("Airports", Color(0xFFF59E0B))
                    LegendItem("Data / Energy", Color(0xFFEC4899))
                }
            }
        }
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 1.dp)) {
        Box(modifier = Modifier.size(6.dp).background(color, RoundedCornerShape(1.dp)))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.bodySmall, fontSize = 9.sp, color = Color.White.copy(alpha = 0.8f))
    }
}

@Composable
fun LiquidityForecastChart(
    modifier: Modifier = Modifier
) {
    // Forecast data mapping: Months 1 to 6
    val months = listOf("Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val baseScenario = listOf(1.42e9, 1.45e9, 1.48e9, 1.55e9, 1.52e9, 1.60e9)
    val stressScenario = listOf(1.42e9, 1.35e9, 1.30e9, 1.25e9, 1.28e9, 1.31e9)

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "TREASURY LIQUIDITY PREDICTIVE FORECAST",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "6-Month projection: Sovereign base case vs historical stress-test scenario",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height

                    val maxVal = 1.70e9
                    val minVal = 1.10e9

                    // Draw vertical and horizontal grid lines
                    for (i in 0..5) {
                        val x = width * (i / 5f)
                        drawLine(
                            color = Color.LightGray.copy(alpha = 0.2f),
                            start = Offset(x, 0f),
                            end = Offset(x, height),
                            strokeWidth = 1f
                        )
                    }
                    for (i in 0..3) {
                        val y = height * (i / 3f)
                        drawLine(
                            color = Color.LightGray.copy(alpha = 0.2f),
                            start = Offset(0f, y),
                            end = Offset(width, y),
                            strokeWidth = 1f
                        )
                    }

                    // Plot Base Case line (Emerald Green)
                    val basePath = Path().apply {
                        baseScenario.forEachIndexed { index, value ->
                            val x = width * (index / 5f)
                            val y = height - ((value - minVal) / (maxVal - minVal) * height).toFloat()
                            if (index == 0) moveTo(x, y) else lineTo(x, y)
                        }
                    }
                    drawPath(
                        path = basePath,
                        color = Color(0xFF10B981),
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Draw dots for base case
                    baseScenario.forEachIndexed { index, value ->
                        val x = width * (index / 5f)
                        val y = height - ((value - minVal) / (maxVal - minVal) * height).toFloat()
                        drawCircle(color = Color(0xFF10B981), radius = 4.dp.toPx(), center = Offset(x, y))
                    }

                    // Plot Stress Case line (Crimson Red)
                    val stressPath = Path().apply {
                        stressScenario.forEachIndexed { index, value ->
                            val x = width * (index / 5f)
                            val y = height - ((value - minVal) / (maxVal - minVal) * height).toFloat()
                            if (index == 0) moveTo(x, y) else lineTo(x, y)
                        }
                    }
                    drawPath(
                        path = stressPath,
                        color = Color(0xFFF87171),
                        style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                    )

                    // Draw dots for stress case
                    stressScenario.forEachIndexed { index, value ->
                        val x = width * (index / 5f)
                        val y = height - ((value - minVal) / (maxVal - minVal) * height).toFloat()
                        drawCircle(color = Color(0xFFF87171), radius = 3.dp.toPx(), center = Offset(x, y))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                months.forEach { m ->
                    Text(m, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(12.dp, 3.dp).background(Color(0xFF10B981)))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Baseline Forecast", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(12.dp, 3.dp).background(Color(0xFFF87171)))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Gilt Stress Scenario (-15%)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

private fun formatCompactCurrency(value: Double): String {
    return when {
        value >= 1.0e9 -> "£${String.format("%.2f", value / 1.0e9)}B"
        value >= 1.0e6 -> "£${String.format("%.1f", value / 1.0e6)}M"
        else -> "£${value.toInt()}"
    }
}
