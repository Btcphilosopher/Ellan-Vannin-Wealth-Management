package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sovereign Wealth Theme Color Palette
val SovereignNavyDark = Color(0xFF0B1220)
val SovereignNavyLight = Color(0xFF0F172A)
val SovereignNavyPrimary = Color(0xFF1E293B)
val SovereignAccentNavy = Color(0xFF38BDF8) // cyan highlight

val SovereignForestGreen = Color(0xFF10B981) // success/gain
val SovereignMutedGreen = Color(0xFF047857)

val SovereignSlateGrey = Color(0xFF64748B) // text/borders
val SovereignMutedSlate = Color(0xFF334155)

val SovereignGold = Color(0xFFF59E0B) // warning/premium
val SovereignCream = Color(0xFFF8FAFC) // light background
val SovereignCardDark = Color(0xFF1E293B)
val SovereignCardLight = Color(0xFFF1F5F9)
val SovereignTerminalGreen = Color(0xFF10B981)
val SovereignTerminalText = Color(0xFF38BDF8)

