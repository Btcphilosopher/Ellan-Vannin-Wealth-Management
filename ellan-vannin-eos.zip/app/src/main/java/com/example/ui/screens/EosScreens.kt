@file:OptIn(ExperimentalLayoutApi::class)
package com.example.ui.screens

import androidx.compose.ui.geometry.Offset
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.blockchain.CryptoEngine
import com.example.data.*
import com.example.ui.components.*
import com.example.viewmodel.EOSViewModel
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

// --- 1. LOGIN SCREEN ---
@Composable
fun LoginScreen(viewModel: EOSViewModel) {
    val selectedRole by viewModel.selectedLoginRole.collectAsState()
    val passcode by viewModel.loginPasscode.collectAsState()
    val errorMessage by viewModel.loginErrorMessage.collectAsState()

    var showPassword by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F172A), Color(0xFF020617))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Bloomberg style command background noise/mesh lines
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            for (i in 1..8) {
                drawLine(
                    color = Color(0xFF1E293B).copy(alpha = 0.3f),
                    start = Offset(0f, height * (i / 9f)),
                    end = Offset(width, height * (i / 9f)),
                    strokeWidth = 1f
                )
            }
        }

        Card(
            modifier = Modifier
                .widthIn(max = 440.dp)
                .fillMaxWidth()
                .padding(24.dp)
                .testTag("login_card"),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B).copy(alpha = 0.9f)),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color(0xFF334155))
        ) {
            Column(
                modifier = Modifier
                    .padding(32.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Crest / Icon
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Sovereign Crest",
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(56.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "ELLAN VANNIN WEALTH",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "EXECUTIVE OPERATING SYSTEM (EOS)",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF38BDF8),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Role selector
                Text(
                    text = "SELECT AUDIT IDENTITY",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.align(Alignment.Start)
                )

                var expanded by remember { mutableStateOf(false) }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    OutlinedButton(
                        onClick = { expanded = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("role_selector_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFF334155))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(selectedRole, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                        }
                    }

                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF334155))
                    ) {
                        viewModel.roles.forEach { role ->
                            DropdownMenuItem(
                                text = { Text(role, color = Color.White) },
                                onClick = {
                                    viewModel.selectedLoginRole.value = role
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Passcode field
                Text(
                    text = "ENTER SECURE PASSCODE",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.align(Alignment.Start)
                )

                OutlinedTextField(
                    value = passcode,
                    onValueChange = { viewModel.loginPasscode.value = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .testTag("passcode_input"),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF0F172A).copy(alpha = 0.5f),
                        unfocusedContainerColor = Color(0xFF0F172A).copy(alpha = 0.5f)
                    ),
                    trailingIcon = {
                        IconButton(onClick = { viewModel.loginPasscode.value = "ellan" }) {
                            Icon(Icons.Default.VpnKey, "Autofill test key", tint = Color(0xFF64748B))
                        }
                    },
                    placeholder = { Text("Passcode (e.g., 'ellan')", color = Color(0xFF64748B)) }
                )

                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Red,
                        modifier = Modifier
                            .padding(vertical = 8.dp)
                            .fillMaxWidth(),
                        textAlign = TextAlign.Start
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { viewModel.attemptLogin() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("login_submit_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        "ESTABLISH ENCRYPTED SESSION",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0B1220),
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Sovereign cryptographic session tracking active. Non-repudiation audit trails committed on-chain.",
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 10.sp,
                    color = Color(0xFF64748B),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}


// --- 2. EXECUTIVE DASHBOARD SCREEN ---
@Composable
fun DashboardScreen(viewModel: EOSViewModel) {
    val totalAUMVal by viewModel.totalAUM.collectAsState()
    val expectedIRR by viewModel.expectedPortfolioIRR.collectAsState()
    val portfolioVol by viewModel.portfolioVolatility.collectAsState()
    val cashFlowVal by viewModel.aggregateCashFlow.collectAsState()
    val projects by viewModel.infrastructureProjects.collectAsState()
    val treasury by viewModel.treasuryRecord.collectAsState()
    val assets by viewModel.portfolioAssets.collectAsState()
    val alertList by viewModel.alerts.collectAsState()

    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Sovereign Banner Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "COMMAND CENTRE FEED - ACTIVE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f),
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Sovereign Fund Terminal: Ellan Vannin",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(Color(0xFF10B981), RoundedCornerShape(4.dp))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "SECURE BLOCKCHAIN LINK",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                }
            }
        }

        // Ticker Tape Rate indicators
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    TickerItem("FTSE 100", "8,124.50", "+0.45%", isGreen = true)
                    TickerItem("UK 10Y Gilt", "4.120%", "-0.015%", isGreen = true)
                    TickerItem("US 10Y Treasury", "4.242%", "+0.008%", isGreen = false)
                    TickerItem("Sovereign BTC Index", "£85,412.00", "+3.45%", isGreen = true)
                    TickerItem("Gold Strategic", "£1,842.50/oz", "+0.12%", isGreen = true)
                    TickerItem("Manx Inflation (CPI)", "2.80%", "0.00%", isGreen = true)
                }
            }
        }

        // High Density KPI Grid - 10 Core Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "EXECUTIVE CORE METRICS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )

                // Grid layout with 2 items per row
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KpiCard(
                        title = "Assets Under Management",
                        value = viewModel.formatCurrency(totalAUMVal),
                        change = "+12.4% YoY",
                        icon = Icons.Default.AccountBalance,
                        color = Color(0xFF38BDF8),
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Net Asset Value (NAV)",
                        value = viewModel.formatCurrency(totalAUMVal - (treasury?.debt ?: 0.0)),
                        change = "+9.2% YoY",
                        icon = Icons.Default.TrendingUp,
                        color = Color(0xFF10B981),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KpiCard(
                        title = "Primary Cash Reserves",
                        value = viewModel.formatCurrency(treasury?.cashBalance ?: 3.1e8),
                        change = "Target: £300M Min",
                        icon = Icons.Default.Money,
                        color = Color(0xFF34D399),
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Infrastructure Assets",
                        value = viewModel.formatCurrency(projects.sumOf { it.currentValuation }),
                        change = "${projects.size} Active Pipes",
                        icon = Icons.Default.Business,
                        color = Color(0xFF818CF8),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KpiCard(
                        title = "Sovereign Bitcoin Reserve",
                        value = viewModel.formatCurrency(assets.find { it.name == "Bitcoin" }?.currentValue ?: 5.8e8),
                        change = "HODL Multisig Active",
                        icon = Icons.Default.CurrencyBitcoin,
                        color = Color(0xFFF59E0B),
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Weighted Portfolio IRR",
                        value = "${String.format("%.2f", expectedIRR * 100)}%",
                        change = "Target: 8.5%",
                        icon = Icons.Default.Percent,
                        color = Color(0xFF10B981),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KpiCard(
                        title = "Sovereign Volatility",
                        value = "${String.format("%.2f", portfolioVol * 100)}%",
                        change = "Conservative Margin",
                        icon = Icons.Default.QueryStats,
                        color = Color(0xFFF87171),
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Annual Infrastructure Cashflow",
                        value = viewModel.formatCurrency(cashFlowVal),
                        change = "Aggregate Yield",
                        icon = Icons.Default.Waves,
                        color = Color(0xFFEC4899),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KpiCard(
                        title = "Liquidity Coverage Ratio",
                        value = "${String.format("%.1f", ((treasury?.cashBalance ?: 3.10e8) / (treasury?.debt ?: 3.85e8)) * 100.0)}%",
                        change = "Basel III Compliant",
                        icon = Icons.Default.Speed,
                        color = Color(0xFFFB7185),
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "EOS System Risk Index",
                        value = "2.1 Low",
                        change = "No Breaches",
                        icon = Icons.Default.Security,
                        color = Color(0xFF38BDF8),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Dual-Panel Layout: Donut Chart and Core Live Alerts list
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "PORTFOLIO ALLOCATION & ALERTS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )

                AssetAllocationChart(
                    assets = assets,
                    totalAUM = totalAUMVal,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.NotificationsActive, "Alerts", tint = Color(0xFFF59E0B))
                            Text("SOVEREIGN LIVE NOTIFICATION LOG", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            alertList.take(4).forEach { alert ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.03f),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .background(Color(0xFFF59E0B), RoundedCornerShape(3.dp))
                                            .align(Alignment.CenterVertically)
                                    )
                                    Text(
                                        text = alert,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TickerItem(name: String, price: String, change: String, isGreen: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
        Text("$name: ", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Text("$price ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
        Text(
            text = change,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = if (isGreen) Color(0xFF10B981) else Color(0xFFF87171)
        )
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    change: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Icon(icon, contentDescription = title, tint = color, modifier = Modifier.size(16.dp))
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = change,
                style = MaterialTheme.typography.bodySmall,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = if (change.contains("+") || change.contains("Approved") || change.contains("Verified")) Color(0xFF10B981) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}


// --- 3. PORTFOLIO SCREEN ---
@Composable
fun PortfolioScreen(viewModel: EOSViewModel) {
    val assets by viewModel.portfolioAssets.collectAsState()
    val totalAUMVal by viewModel.totalAUM.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "PORTFOLIO TRACKING & FINANCIAL LEDGER",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }

        items(assets) { asset ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(
                                        when (asset.category) {
                                            "Equities" -> Color(0xFF38BDF8)
                                            "Bonds" -> Color(0xFF34D399)
                                            "Bitcoin" -> Color(0xFFF59E0B)
                                            else -> Color(0xFF818CF8)
                                        },
                                        RoundedCornerShape(4.dp)
                                    )
                            )
                            Text(
                                text = asset.name.uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Text(
                            text = viewModel.formatCurrency(asset.currentValue),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("ACQUISITION COST", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text(viewModel.formatCurrency(asset.acquisitionCost), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                        }
                        Column {
                            Text("NET UNREALISED P/L", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            val pl = asset.currentValue - asset.acquisitionCost
                            Text(
                                text = (if (pl >= 0) "+" else "") + viewModel.formatCurrency(pl),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = if (pl >= 0) Color(0xFF10B981) else Color(0xFFF87171)
                            )
                        }
                        Column {
                            Text("ALLOCATION %", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            val percent = if (totalAUMVal > 0.0) (asset.currentValue / totalAUMVal) * 100.0 else 0.0
                            Text("${String.format("%.2f", percent)}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    // Audit risk numbers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("TARGET IRR", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text("${String.format("%.1f", asset.irr * 100.0)}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("SHARPE RATIO", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text(String.format("%.2f", asset.sharpeRatio), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                        }
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("SORTINO RATIO", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text(String.format("%.2f", asset.sortinoRatio), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                        }
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("MAX DRAWDOWN", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text("-${String.format("%.1f", asset.maxDrawdown * 100.0)}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, color = Color(0xFFF87171))
                        }
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("VAR (95%)", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text("${String.format("%.1f", asset.valueAtRisk * 100.0)}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}


// --- 4. INFRASTRUCTURE SCREEN ---
@Composable
fun InfrastructureScreen(viewModel: EOSViewModel) {
    val projects by viewModel.infrastructureProjects.collectAsState()
    val activeRole by viewModel.activeUserRole.collectAsState()

    var showCreateForm by remember { mutableStateOf(false) }

    // Propose project state parameters
    var projName by remember { mutableStateOf("") }
    var projCategory by remember { mutableStateOf("Energy") }
    var projCapital by remember { mutableStateOf("") }
    var projIrr by remember { mutableStateOf("") }
    var projTimeline by remember { mutableStateOf("2026 - 2030") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "INFRASTRUCTURE AUDITING LEDGER",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                    Text(
                        text = "Real railways, harbors and utility investments",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                    )
                }

                // CEO/CIO and other core roles can create infrastructure project proposals
                if (activeRole != "Read Only" && activeRole != "Analyst") {
                    Button(
                        onClick = { showCreateForm = !showCreateForm },
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(if (showCreateForm) Icons.Default.Close else Icons.Default.Add, "Action")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showCreateForm) "Cancel" else "Propose Project")
                    }
                }
            }
        }

        // Show Project Proposing Form
        if (showCreateForm) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("PROPOSE SOVEREIGN INFRASTRUCTURE CAPITAL ALLOCATION", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                        OutlinedTextField(
                            value = projName,
                            onValueChange = { projName = it },
                            label = { Text("Project Title") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = projCapital,
                                onValueChange = { projCapital = it },
                                label = { Text("Capital Invested (£)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = projIrr,
                                onValueChange = { projIrr = it },
                                label = { Text("Target IRR %") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = projTimeline,
                                onValueChange = { projTimeline = it },
                                label = { Text("Timeline") },
                                modifier = Modifier.weight(1.2f)
                            )

                            var catExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(0.8f).padding(top = 8.dp)) {
                                OutlinedButton(
                                    onClick = { catExpanded = true },
                                    modifier = Modifier.fillMaxWidth().height(52.dp)
                                ) {
                                    Text(projCategory)
                                }
                                DropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                                    listOf("railways", "ports", "airports", "data centres", "energy", "housing").forEach { cat ->
                                        DropdownMenuItem(
                                            text = { Text(cat) },
                                            onClick = {
                                                projCategory = cat
                                                catExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = {
                                val cap = projCapital.toDoubleOrNull() ?: 1.0e7
                                val irr = (projIrr.toDoubleOrNull() ?: 10.0) / 100.0
                                viewModel.addProject(projName, projCategory, cap, irr, projTimeline, 54.2f, -4.5f)
                                showCreateForm = false
                                projName = ""
                                projCapital = ""
                                projIrr = ""
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("PUBLISH CAPITAL ALLOCATION PIPELINE", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        items(projects) { project ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = project.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "CATEGORY: ${project.category.uppercase()} | TIMELINE: ${project.timeline}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    if (project.boardApprovalStatus == "Approved") Color(0xFF10B981).copy(alpha = 0.15f)
                                    else Color(0xFFF59E0B).copy(alpha = 0.15f)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = project.boardApprovalStatus.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (project.boardApprovalStatus == "Approved") Color(0xFF10B981) else Color(0xFFF59E0B)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Progress indicators
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "CONSTRUCTION PROGRESS:",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                        LinearProgressIndicator(
                            progress = project.constructionProgress / 100f,
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = Color(0xFF10B981),
                            trackColor = MaterialTheme.colorScheme.outlineVariant
                        )
                        Text(
                            "${project.constructionProgress}%",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CAPITAL INVESTED", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text(viewModel.formatCurrency(project.capitalInvested), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("CURRENT VALUATION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text(viewModel.formatCurrency(project.currentValuation), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("EXPECTED IRR", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text("${String.format("%.1f", project.expectedIrr * 100.0)}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("EMPLOYEES", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            Text(project.employmentCount.toString(), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text(
                                "Debt/Gearing: ${viewModel.formatCurrency(project.debt)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Text(
                                "Risk Score: ${project.riskScore}/10",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (project.riskScore > 4.0) Color(0xFFF87171) else Color(0xFF10B981)
                            )
                        }

                        // Remove button for admins
                        if (activeRole == "CEO" || activeRole == "CIO") {
                            TextButton(
                                onClick = { viewModel.deleteProject(project.id) },
                                colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
                            ) {
                                Icon(Icons.Default.Delete, "Delete")
                                Text("Retire Pipeline")
                            }
                        }
                    }
                }
            }
        }
    }
}


// --- 5. TREASURY SCREEN ---
@Composable
fun TreasuryScreen(viewModel: EOSViewModel) {
    val treasury by viewModel.treasuryRecord.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "LIQUIDITY TREASURY MONITOR",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "PRIMARY LIQUID RESERVES STATUS",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("TREASURY CASH BALANCE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text(viewModel.formatCurrency(treasury?.cashBalance ?: 3.1e8), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("SHORT-TERM LIQUIDS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text(viewModel.formatCurrency(treasury?.shortTermInvestments ?: 4.5e8), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("GOVERNMENT BONDS (GILTS)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text(viewModel.formatCurrency(treasury?.govBonds ?: 1.42e9), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("OUTSTANDING DEBT", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text(viewModel.formatCurrency(treasury?.debt ?: 3.85e8), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    Column {
                        Text("Sovereign Currency Hedging:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = treasury?.currencyExposure ?: "GBP: 55%, USD: 30%, EUR: 15%",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                    }
                }
            }
        }

        // Liquidity predictive line chart
        item {
            LiquidityForecastChart(modifier = Modifier.fillMaxWidth())
        }
    }
}


// --- 6. BITCOIN TREASURY SCREEN ---
@Composable
fun BitcoinTreasuryScreen(viewModel: EOSViewModel) {
    val assets by viewModel.portfolioAssets.collectAsState()
    val totalAUMVal by viewModel.totalAUM.collectAsState()

    val btc = assets.find { it.name == "Bitcoin" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SOVEREIGN BITCOIN TREASURY RESERVES",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.CurrencyBitcoin, "Bitcoin Symbol", tint = Color(0xFFF59E0B), modifier = Modifier.size(28.dp))
                            Text("Sovereign HODL Allocation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }

                        val percent = if (totalAUMVal > 0.0 && btc != null) (btc.currentValue / totalAUMVal) * 100.0 else 0.0
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFF59E0B).copy(alpha = 0.15f))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                "ALLOCATION: ${String.format("%.2f", percent)}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF59E0B)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("RESERVE VALUE (GBP)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text(viewModel.formatCurrency(btc?.currentValue ?: 5.8e8), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        }
                        Column {
                            Text("AVERAGE COST BASIS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text(viewModel.formatCurrency(btc?.acquisitionCost ?: 3.2e8), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    // Audit labels and Cold storage wallet tags
                    Text("SECURE WALLETS AUDITING (READ ONLY):", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    WalletAuditRow("EV-BTC-COLD-01", "3-of-5 Multisignature Keys Verified", "[SECURE]")
                    Spacer(modifier = Modifier.height(6.dp))
                    WalletAuditRow("EV-BTC-COLD-02", "Deep Storage Vault Isle of Man node #4", "[SECURE]")

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("HISTORICAL SOVEREIGN ACQUISITIONS:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    BtcTxRow("2024-11-12", "Acquired 3,120 BTC", "Avg Price: £52,400", "Tx: 3a1f8b...ef02")
                    BtcTxRow("2025-03-05", "Acquired 1,840 BTC", "Avg Price: £61,120", "Tx: d4e190...82bc")
                }
            }
        }
    }
}

@Composable
fun WalletAuditRow(id: String, desc: String, status: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF1E293B))
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(id, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.White)
            Text(desc, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = Color.White.copy(alpha = 0.6f))
        }
        Text(status, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
    }
}

@Composable
fun BtcTxRow(date: String, amount: String, price: String, tx: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(amount, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            Text(tx, style = MaterialTheme.typography.bodySmall, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(price, style = MaterialTheme.typography.bodySmall)
            Text(date, style = MaterialTheme.typography.bodySmall, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }
    }
}


// --- 7. GOVERNANCE SCREEN ---
@Composable
fun GovernanceScreen(viewModel: EOSViewModel) {
    val proposals by viewModel.governanceProposals.collectAsState()
    val activeRole by viewModel.activeUserRole.collectAsState()

    var showProposalForm by remember { mutableStateOf(false) }

    // Propose proposal fields
    var propTitle by remember { mutableStateOf("") }
    var propSummary by remember { mutableStateOf("") }
    var propAmount by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SOVEREIGN GOVERNANCE & BLOCKCHAIN REGISTRY",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                    Text(
                        text = "Anchoring document integrity hashes and board decisions on-chain",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                    )
                }

                if (activeRole == "CEO" || activeRole == "CIO") {
                    Button(
                        onClick = { showProposalForm = !showProposalForm },
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(if (showProposalForm) Icons.Default.Close else Icons.Default.Publish, "Action")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showProposalForm) "Cancel" else "Draft Proposal")
                    }
                }
            }
        }

        // Proposal Draft Form
        if (showProposalForm) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("DRAFT BOARD INVESTMENT PROPOSAL", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                        OutlinedTextField(
                            value = propTitle,
                            onValueChange = { propTitle = it },
                            label = { Text("Proposal Title") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = propSummary,
                            onValueChange = { propSummary = it },
                            label = { Text("Brief Proposal Summary & Directives") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )

                        OutlinedTextField(
                            value = propAmount,
                            onValueChange = { propAmount = it },
                            label = { Text("Investment Amount Required (£)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                val amt = propAmount.toDoubleOrNull() ?: 1.0e6
                                viewModel.createProposal(propTitle, propSummary, amt)
                                showProposalForm = false
                                propTitle = ""
                                propSummary = ""
                                propAmount = ""
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("PUBLISH & GENERATE DOCUMENT HASH", fontWeight = FontWeight.Bold, color = Color(0xFF0B1220))
                        }
                    }
                }
            }
        }

        items(proposals) { proposal ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = proposal.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(0.7f)
                        )

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    when (proposal.approvalStatus) {
                                        "Approved" -> Color(0xFF10B981).copy(alpha = 0.15f)
                                        "Pending Voting" -> Color(0xFFF59E0B).copy(alpha = 0.15f)
                                        else -> Color(0xFFF87171).copy(alpha = 0.15f)
                                    }
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = proposal.approvalStatus.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = when (proposal.approvalStatus) {
                                    "Approved" -> Color(0xFF10B981)
                                    "Pending Voting" -> Color(0xFFF59E0B)
                                    else -> Color(0xFFF87171)
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = proposal.summary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "CAPITAL BUDGET REQUIRED: ${viewModel.formatCurrency(proposal.investmentAmount)}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    // Crypto verification hashes
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.03f), RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Fingerprint, "SHA", tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                "SHA-256 DOCUMENT HASH: ${proposal.documentHash}",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }

                        if (proposal.blockchainTxHash.isNotEmpty()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Link, "Anchor", tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "BLOCKCHAIN ANCHOR: TX ${proposal.blockchainTxHash.take(24)}... (Block #${proposal.blockchainBlockHeight})",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF10B981)
                                )
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CloudQueue, "Pending", tint = Color(0xFFF59E0B), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "BLOCKCHAIN ANCHOR: LOCAL REPO ONLY (Unanchored)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFFF59E0B)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "BOARD VOTING RECORD: ${proposal.votes}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    if (proposal.digitalSignatures.isNotEmpty()) {
                        Text(
                            text = "CRYPTOGRAPHIC SIGNATURES: ${proposal.digitalSignatures}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            fontSize = 10.sp,
                            color = Color(0xFF10B981)
                        )
                    }

                    // Interactive Sign and Anchor Actions
                    if (activeRole != "Read Only") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.signProposal(proposal.id, activeRole) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(4.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(Icons.Default.Draw, "Sign", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Sign Document")
                            }

                            if (proposal.approvalStatus == "Approved" && proposal.blockchainTxHash.isEmpty()) {
                                Button(
                                    onClick = { viewModel.anchorProposal(proposal.id) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(4.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                ) {
                                    Icon(Icons.Default.CloudUpload, "Anchor", modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Anchor Blockchain")
                                }
                            } else if (proposal.approvalStatus != "Approved") {
                                Button(
                                    onClick = { viewModel.voteOnProposal(proposal.id, activeRole, "Approved") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(4.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B))
                                ) {
                                    Icon(Icons.Default.HowToVote, "Vote", modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Approve Vote")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// --- 8. AI ASSISTANT AND TERMINAL ---
@Composable
fun AIScreen(viewModel: EOSViewModel) {
    val chat by viewModel.chatHistory.collectAsState()
    val isAILoading by viewModel.isAILoading.collectAsState()

    var inputQuery by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    // Scroll to bottom on updates
    LaunchedEffect(chat.size) {
        scrollState.animateScrollTo(scrollState.maxValue)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "SOVEREIGN COMMAND SHELL & AI TERMINAL",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )

        // Split shell window
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = BorderStroke(1.dp, Color(0xFF334155)),
            shape = RoundedCornerShape(6.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                // Ticker / Info header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ELLAN VANNIN EOS SECURITIES AI v3.5", style = MaterialTheme.typography.labelSmall, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.size(8.dp).background(Color(0xFF10B981), RoundedCornerShape(4.dp)))
                }

                Divider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFF1E293B))

                // Chat logs scroll area
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(scrollState),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    chat.forEach { msg ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "[${msg.timestamp}] ",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF64748B)
                                )
                                Text(
                                    text = when (msg.sender) {
                                        "user" -> "COMMANDER"
                                        "terminal" -> "SHELL_EXEC"
                                        "system" -> "SECURITY_DAEMON"
                                        else -> "EOS_AI_AGENT"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = when (msg.sender) {
                                        "user" -> Color(0xFF38BDF8)
                                        "terminal" -> Color(0xFFF59E0B)
                                        "system" -> Color(0xFFEF4444)
                                        else -> Color(0xFF10B981)
                                    }
                                )
                                Text(" >", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, color = Color(0xFF64748B))
                            }

                            Text(
                                text = msg.text,
                                style = MaterialTheme.typography.bodyMedium,
                                fontFamily = if (msg.sender == "terminal") FontFamily.Monospace else FontFamily.Default,
                                color = if (msg.sender == "terminal") Color(0xFFE2E8F0) else Color.White,
                                modifier = Modifier.padding(start = 12.dp, top = 2.dp)
                            )
                        }
                    }

                    if (isAILoading) {
                        Text(
                            "Processing cryptographic parsing & generative query...",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFF59E0B),
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    }
                }
            }
        }

        // Input prompt bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputQuery,
                onValueChange = { inputQuery = it },
                placeholder = { Text("Ask secure AI or type '/performance'...", color = Color(0xFF64748B)) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_input_field"),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color(0xFF38BDF8),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedContainerColor = Color(0xFF1E293B),
                    unfocusedContainerColor = Color(0xFF0F172A)
                )
            )

            Button(
                onClick = {
                    viewModel.sendTerminalMessage(inputQuery)
                    inputQuery = ""
                },
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                modifier = Modifier.height(52.dp)
            ) {
                Text("RUN", color = Color(0xFF0B1220), fontWeight = FontWeight.Bold)
            }
        }
    }
}


// --- 9. REPORTS AND VAULT ---
@Composable
fun ReportsScreen(viewModel: EOSViewModel) {
    val proposals by viewModel.governanceProposals.collectAsState()
    val activeRole by viewModel.activeUserRole.collectAsState()

    var activeReportTab by remember { mutableStateOf(0) } // 0: PDF Report, 1: Vault Audit
    var documentIntegrityResult by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        TabRow(
            selectedTabIndex = activeReportTab,
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(selected = activeReportTab == 0, onClick = { activeReportTab = 0 }, text = { Text("Sovereign Briefing PDF") })
            Tab(selected = activeReportTab == 1, onClick = { activeReportTab = 1 }, text = { Text("Secure Document Vault") })
        }

        if (activeReportTab == 0) {
            // PDF Preview Simulation
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(2.dp, Color(0xFF0B1220))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Ellan Vannin Crest Placeholder
                    Icon(Icons.Default.Security, "Seal", tint = Color(0xFF0B1220), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "ELLAN VANNIN WEALTH MANAGEMENT",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0B1220),
                        fontSize = 16.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        "SOVEREIGN INVESTMENT COMMITTEE STRATEGY BRIEFING",
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF0B1220),
                        fontSize = 11.sp,
                        letterSpacing = 0.5.sp
                    )

                    Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFF0B1220), thickness = 2.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("DATE: JULY 2026", fontSize = 10.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        Text("CLASSIFICATION: HIGHLY CONFIDENTIAL", fontSize = 10.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                        Text("AUDITOR: CEO OFFICE", fontSize = 10.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "1. EXECUTIVE BRIEFING SUMMARY",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFF0B1220),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Ellan Vannin Sovereign wealth parameters remain exceptionally robust. Primary capital exposure aggregates exceed target margins. High focus centers on deep-berth cargo terminals in Douglas and green data computing loops. Portfolios continue structurally hedging inflation risk using institutional digital cold-storage assets.",
                        fontSize = 11.sp,
                        color = Color.DarkGray,
                        textAlign = TextAlign.Justify,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "2. CAPITAL AUDITING STATS",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFF0B1220),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Simplified PDF report table
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF1F5F9))
                            .padding(6.dp)
                    ) {
                        Text("Asset Classification", modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold, fontSize = 10.sp, color = Color.Black)
                        Text("Target IRR", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 10.sp, color = Color.Black)
                        Text("Risk Tier", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 10.sp, color = Color.Black)
                    }
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Text("Sovereign Bitcoin", modifier = Modifier.weight(1.5f), fontSize = 10.sp, color = Color.Black)
                        Text("45.2%", modifier = Modifier.weight(1f), fontSize = 10.sp, color = Color.Black)
                        Text("High", modifier = Modifier.weight(1f), fontSize = 10.sp, color = Color.Black)
                    }
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Text("Manx Green Data", modifier = Modifier.weight(1.5f), fontSize = 10.sp, color = Color.Black)
                        Text("14.2%", modifier = Modifier.weight(1f), fontSize = 10.sp, color = Color.Black)
                        Text("Low", modifier = Modifier.weight(1f), fontSize = 10.sp, color = Color.Black)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Simulated stamp
                    Box(
                        modifier = Modifier
                            .border(2.dp, Color(0xFF10B981), RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text("SOVEREIGN LEDGER MATCHED & ANCHORED", color = Color(0xFF10B981), fontWeight = FontWeight.Black, fontSize = 11.sp)
                    }
                }
            }
        } else {
            // Vault Audit & Integrity checker
            LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Text("VAULTED ASSET SECURITIES & SHA-256 MATCHING", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                }

                items(proposals) { prop ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(prop.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                Button(
                                    onClick = {
                                        // Run SHA-256 matching on text
                                        val text = "${prop.title}|${prop.summary}|${prop.investmentAmount}|${prop.timestamp}"
                                        val computed = CryptoEngine.generateSHA256(text)
                                        documentIntegrityResult = if (computed == prop.documentHash) {
                                            "SECURE MATCH: Document matches on-chain hash '${prop.documentHash.take(16)}...'"
                                        } else {
                                            "ALERT: Hash mismatch detected!"
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text("Verify Hash", fontSize = 10.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Stored SHA-256 Hash: ${prop.documentHash}", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                if (documentIntegrityResult.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = if (documentIntegrityResult.contains("SECURE")) Color(0xFF10B981).copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f))
                        ) {
                            Text(
                                text = documentIntegrityResult,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (documentIntegrityResult.contains("SECURE")) Color(0xFF10B981) else Color.Red,
                                modifier = Modifier.padding(16.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}


// --- 10. SETTINGS / ROLES PANEL ---
@Composable
fun SettingsScreen(viewModel: EOSViewModel) {
    val activeRole by viewModel.activeUserRole.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SYSTEM SETTINGS & PRIVILEGES",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("ACTIVE EXECUTIVE ROLE STATUS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Text(
                        text = "Current privileges: $activeRole",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8)
                    )

                    Text(
                        text = "To alternate or mock roles during sovereign testing, swap active states below:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )

                    // Role swap grid
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        maxItemsInEachRow = 3,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        viewModel.roles.forEach { r ->
                            Button(
                                onClick = { viewModel.activeUserRole.value = r },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (activeRole == r) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                ),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Text(r, fontSize = 10.sp)
                            }
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    Button(
                        onClick = { viewModel.logout() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("TERMINATE SECURE SESSION (LOGOUT)", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}
