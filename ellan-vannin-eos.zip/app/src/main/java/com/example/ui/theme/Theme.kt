package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = SovereignAccentNavy,
    secondary = SovereignForestGreen,
    tertiary = SovereignGold,
    background = SovereignNavyDark,
    surface = SovereignCardDark,
    onPrimary = SovereignNavyDark,
    onSecondary = SovereignCream,
    onTertiary = SovereignNavyDark,
    onBackground = SovereignCream,
    onSurface = SovereignCream
  )

private val LightColorScheme =
  lightColorScheme(
    primary = SovereignNavyLight,
    secondary = SovereignMutedGreen,
    tertiary = SovereignGold,
    background = SovereignCream,
    surface = SovereignCardLight,
    onPrimary = SovereignCream,
    onSecondary = SovereignCream,
    onTertiary = SovereignNavyDark,
    onBackground = SovereignNavyLight,
    onSurface = SovereignNavyLight
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disable dynamic color to preserve our custom Bloomberg Terminal branding
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
