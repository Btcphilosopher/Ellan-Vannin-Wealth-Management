package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PortfolioDao {
    @Query("SELECT * FROM portfolio_assets")
    fun getAllAssets(): Flow<List<PortfolioAsset>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAsset(asset: PortfolioAsset)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssets(assets: List<PortfolioAsset>)

    @Query("DELETE FROM portfolio_assets")
    suspend fun clearAssets()
}

@Dao
interface InfrastructureDao {
    @Query("SELECT * FROM infrastructure_projects")
    fun getAllProjects(): Flow<List<InfrastructureProject>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: InfrastructureProject)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProjects(projects: List<InfrastructureProject>)

    @Query("DELETE FROM infrastructure_projects WHERE id = :id")
    suspend fun deleteProjectById(id: Int)
}

@Dao
interface TreasuryDao {
    @Query("SELECT * FROM treasury_records LIMIT 1")
    fun getTreasuryRecord(): Flow<TreasuryRecord?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTreasuryRecord(record: TreasuryRecord)
}

@Dao
interface GovernanceDao {
    @Query("SELECT * FROM governance_proposals ORDER BY timestamp DESC")
    fun getAllProposals(): Flow<List<GovernanceProposal>>

    @Query("SELECT * FROM governance_proposals WHERE id = :id")
    suspend fun getProposalById(id: Int): GovernanceProposal?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProposal(proposal: GovernanceProposal): Long

    @Query("DELETE FROM governance_proposals WHERE id = :id")
    suspend fun deleteProposal(id: Int)
}
