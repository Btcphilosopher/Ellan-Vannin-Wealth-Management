package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "portfolio_assets")
data class PortfolioAsset(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String,
    val currentValue: Double,
    val acquisitionCost: Double,
    val irr: Double,
    val sharpeRatio: Double,
    val sortinoRatio: Double,
    val maxDrawdown: Double,
    val valueAtRisk: Double
) {
    val gainLoss: Double get() = currentValue - acquisitionCost
    val timeWeightedReturn: Double get() = (currentValue / acquisitionCost - 1.0) * 100.0
    val moneyWeightedReturn: Double get() = irr * 100.0 // Simplified representation for display
}

@Entity(tableName = "infrastructure_projects")
data class InfrastructureProject(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String,
    val capitalInvested: Double,
    val currentValuation: Double,
    val expectedIrr: Double,
    val cashFlow: Double,
    val debt: Double,
    val constructionProgress: Int, // 0 to 100
    val riskScore: Double, // 1.0 to 10.0
    val timeline: String,
    val boardApprovalStatus: String, // "Approved", "Pending", "Review"
    val latitude: Float,
    val longitude: Float,
    val employmentCount: Int
)

@Entity(tableName = "treasury_records")
data class TreasuryRecord(
    @PrimaryKey val id: Int = 1,
    val cashBalance: Double,
    val govBonds: Double,
    val shortTermInvestments: Double,
    val debt: Double,
    val currencyExposure: String // e.g., "GBP: 55%, USD: 30%, EUR: 15%"
)

@Entity(tableName = "governance_proposals")
data class GovernanceProposal(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val summary: String,
    val investmentAmount: Double,
    val boardMembers: String, // Comma separated list of names
    val votes: String, // Comma separated list of votes (e.g. "CEO: YES, CIO: YES")
    val approvalStatus: String, // "Approved", "Pending Voting", "Rejected"
    val digitalSignatures: String, // Comma separated list of crypto signatures
    val timestamp: Long,
    val documentHash: String, // SHA-256 representation
    val blockchainTxHash: String, // Bitcoin timestamp anchor TX
    val blockchainBlockHeight: Int
)
