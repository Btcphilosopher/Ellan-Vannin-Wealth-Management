package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers

class EOSRepository(
    private val portfolioDao: PortfolioDao,
    private val infrastructureDao: InfrastructureDao,
    private val treasuryDao: TreasuryDao,
    private val governanceDao: GovernanceDao
) {
    val allAssets: Flow<List<PortfolioAsset>> = portfolioDao.getAllAssets()
    val allProjects: Flow<List<InfrastructureProject>> = infrastructureDao.getAllProjects()
    val treasuryRecord: Flow<TreasuryRecord?> = treasuryDao.getTreasuryRecord()
    val allProposals: Flow<List<GovernanceProposal>> = governanceDao.getAllProposals()

    suspend fun initializeDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        val existingAssets = allAssets.firstOrNull()
        if (existingAssets.isNullOrEmpty()) {
            // Pre-populate Portfolio Assets
            val initialAssets = listOf(
                PortfolioAsset(name = "Equities", category = "Equities", currentValue = 2.15e9, acquisitionCost = 1.80e9, irr = 0.124, sharpeRatio = 1.45, sortinoRatio = 1.62, maxDrawdown = 0.145, valueAtRisk = 0.032),
                PortfolioAsset(name = "Bonds", category = "Bonds", currentValue = 1.42e9, acquisitionCost = 1.38e9, irr = 0.048, sharpeRatio = 2.10, sortinoRatio = 2.45, maxDrawdown = 0.052, valueAtRisk = 0.011),
                PortfolioAsset(name = "Property", category = "Property", currentValue = 8.50e8, acquisitionCost = 7.20e8, irr = 0.085, sharpeRatio = 1.12, sortinoRatio = 1.30, maxDrawdown = 0.088, valueAtRisk = 0.021),
                PortfolioAsset(name = "Infrastructure", category = "Infrastructure", currentValue = 1.20e9, acquisitionCost = 9.80e8, irr = 0.112, sharpeRatio = 1.25, sortinoRatio = 1.40, maxDrawdown = 0.075, valueAtRisk = 0.018),
                PortfolioAsset(name = "Private Equity", category = "Private Equity", currentValue = 9.20e8, acquisitionCost = 6.80e8, irr = 0.186, sharpeRatio = 1.65, sortinoRatio = 1.88, maxDrawdown = 0.224, valueAtRisk = 0.058),
                PortfolioAsset(name = "Gold & Commodities", category = "Gold", currentValue = 4.50e8, acquisitionCost = 3.80e8, irr = 0.092, sharpeRatio = 0.98, sortinoRatio = 1.10, maxDrawdown = 0.120, valueAtRisk = 0.025),
                PortfolioAsset(name = "Bitcoin", category = "Bitcoin", currentValue = 5.80e8, acquisitionCost = 3.20e8, irr = 0.452, sharpeRatio = 2.40, sortinoRatio = 3.10, maxDrawdown = 0.385, valueAtRisk = 0.082),
                PortfolioAsset(name = "Cash & Equivalents", category = "Cash", currentValue = 3.10e8, acquisitionCost = 3.10e8, irr = 0.032, sharpeRatio = 0.0, sortinoRatio = 0.0, maxDrawdown = 0.0, valueAtRisk = 0.0)
            )
            portfolioDao.insertAssets(initialAssets)

            // Pre-populate Infrastructure Projects
            val initialProjects = listOf(
                InfrastructureProject(
                    name = "Isle of Man Electric Railway Grid", category = "railways",
                    capitalInvested = 1.20e8, currentValuation = 1.45e8, expectedIrr = 0.088,
                    cashFlow = 8.2e6, debt = 4.0e7, constructionProgress = 82, riskScore = 2.5,
                    timeline = "2023 - 2026", boardApprovalStatus = "Approved",
                    latitude = 54.2009f, longitude = -4.4326f, employmentCount = 340
                ),
                InfrastructureProject(
                    name = "Douglas Deepwater Harbor", category = "ports",
                    capitalInvested = 2.80e8, currentValuation = 3.10e8, expectedIrr = 0.115,
                    cashFlow = 1.85e7, debt = 9.0e7, constructionProgress = 65, riskScore = 3.8,
                    timeline = "2022 - 2027", boardApprovalStatus = "Approved",
                    latitude = 54.1485f, longitude = -4.4725f, employmentCount = 520
                ),
                InfrastructureProject(
                    name = "Ronaldsway Cargo Hub", category = "airports",
                    capitalInvested = 1.40e8, currentValuation = 1.55e8, expectedIrr = 0.094,
                    cashFlow = 1.01e7, debt = 4.5e7, constructionProgress = 45, riskScore = 4.2,
                    timeline = "2024 - 2028", boardApprovalStatus = "Approved",
                    latitude = 54.0858f, longitude = -4.6239f, employmentCount = 210
                ),
                InfrastructureProject(
                    name = "Manx Green Data Centre", category = "data centres",
                    capitalInvested = 2.10e8, currentValuation = 2.45e8, expectedIrr = 0.142,
                    cashFlow = 2.40e7, debt = 7.0e7, constructionProgress = 90, riskScore = 2.1,
                    timeline = "2023 - 2025", boardApprovalStatus = "Approved",
                    latitude = 54.3216f, longitude = -4.3845f, employmentCount = 180
                ),
                InfrastructureProject(
                    name = "Ramsey Offshore Wind Utility", category = "energy",
                    capitalInvested = 3.20e8, currentValuation = 3.60e8, expectedIrr = 0.128,
                    cashFlow = 2.85e7, debt = 1.1e8, constructionProgress = 40, riskScore = 4.8,
                    timeline = "2024 - 2029", boardApprovalStatus = "Approved",
                    latitude = 54.3228f, longitude = -4.3852f, employmentCount = 450
                ),
                InfrastructureProject(
                    name = "Sovereign Housing Initiative", category = "housing",
                    capitalInvested = 9.5e7, currentValuation = 1.05e8, expectedIrr = 0.065,
                    cashFlow = 4.2e6, debt = 3.0e7, constructionProgress = 95, riskScore = 1.5,
                    timeline = "2022 - 2025", boardApprovalStatus = "Approved",
                    latitude = 54.1550f, longitude = -4.4820f, employmentCount = 610
                )
            )
            infrastructureDao.insertProjects(initialProjects)

            // Pre-populate Treasury Record
            val initialTreasury = TreasuryRecord(
                cashBalance = 3.10e8,
                govBonds = 1.42e9,
                shortTermInvestments = 4.50e8,
                debt = 3.85e8,
                currencyExposure = "GBP: 55%, USD: 30%, EUR: 15%"
            )
            treasuryDao.insertTreasuryRecord(initialTreasury)

            // Pre-populate Governance Proposals
            val p1 = GovernanceProposal(
                title = "Douglas Deepwater Harbor Expansion - Phase II",
                summary = "Expansion of deepwater berths to support heavy freight and container vessel docking, improving sovereign import/export capability.",
                investmentAmount = 1.50e8,
                boardMembers = "CEO, CIO, Risk Officer, Investment Director",
                votes = "CEO: Approved, CIO: Approved, Risk Officer: Approved, Investment Director: Approved",
                approvalStatus = "Approved",
                digitalSignatures = "CEO_sig_3a8b4f, CIO_sig_e48c12, Risk_sig_bc1982, Director_sig_ff3928",
                timestamp = System.currentTimeMillis() - 86400000L * 5,
                documentHash = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                blockchainTxHash = "00000000000000000005a7df42e5b8d277d54e4bc9df29cfba29a28bcff82a93",
                blockchainBlockHeight = 845621
            )
            val p2 = GovernanceProposal(
                title = "Sovereign Compute & AI Facility",
                summary = "Establishment of a local cryptographic AI and High-Performance Compute facility powered by the Ramsey Wind Utility to host secure private LLMs and verify transaction states.",
                investmentAmount = 7.5e7,
                boardMembers = "CEO, CIO, Risk Officer",
                votes = "CEO: Pending, CIO: Approved, Risk Officer: Pending",
                approvalStatus = "Pending Voting",
                digitalSignatures = "CIO_sig_e48c12",
                timestamp = System.currentTimeMillis() - 86400000L * 2,
                documentHash = "fcde83a79f32389104fa28cd76da4172a1e389e7102e3a893e1152a197b102ef",
                blockchainTxHash = "",
                blockchainBlockHeight = 0
            )
            governanceDao.insertProposal(p1)
            governanceDao.insertProposal(p2)
        }
    }

    suspend fun insertProject(project: InfrastructureProject) = withContext(Dispatchers.IO) {
        infrastructureDao.insertProject(project)
    }

    suspend fun deleteProject(id: Int) = withContext(Dispatchers.IO) {
        infrastructureDao.deleteProjectById(id)
    }

    suspend fun updateTreasury(record: TreasuryRecord) = withContext(Dispatchers.IO) {
        treasuryDao.insertTreasuryRecord(record)
    }

    suspend fun insertProposal(proposal: GovernanceProposal): Long = withContext(Dispatchers.IO) {
        governanceDao.insertProposal(proposal)
    }

    suspend fun getProposalById(id: Int): GovernanceProposal? = withContext(Dispatchers.IO) {
        governanceDao.getProposalById(id)
    }
}
