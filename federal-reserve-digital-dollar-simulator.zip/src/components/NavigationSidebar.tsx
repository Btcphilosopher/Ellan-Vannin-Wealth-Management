import React from 'react';
import { useSimulator, NavigationModule } from '../store/simulatorStore';
import {
  LayoutDashboard,
  Coins,
  BookOpen,
  Wallet as WalletIcon,
  Building2,
  Network,
  Cpu,
  Zap,
  TrendingUp,
  Users,
  ShieldAlert,
  EyeOff,
  WifiOff,
  Code2,
  Receipt,
  Landmark,
  Globe2,
  ShieldCheck,
  FileCheck,
  LineChart,
  Server,
  FlaskConical,
  Scale,
  ChevronRight
} from 'lucide-react';

interface NavGroup {
  groupName: string;
  items: {
    id: NavigationModule;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }[];
}

export const NavigationSidebar: React.FC = () => {
  const { activeModule, setActiveModule, securityIncidents, dvpContracts, offlineQueue } = useSimulator();

  const activeIncidentsCount = securityIncidents.filter(i => i.status === 'UNDER_INVESTIGATION').length;
  const pendingDvpCount = dvpContracts.filter(d => d.atomicFinality === 'PENDING').length;
  const pendingOfflineCount = offlineQueue.filter(o => o.status === 'STORED_ON_CHIP').length;

  const navGroups: NavGroup[] = [
    {
      groupName: 'COMMAND & OVERVIEW',
      items: [
        { id: 'COMMAND_CENTER', label: 'Command Center', icon: LayoutDashboard, badge: 'CORE' },
        { id: 'PAYMENTS_TOPOLOGY', label: 'Network Topology', icon: Network },
      ],
    },
    {
      groupName: 'CENTRAL BANK CORE',
      items: [
        { id: 'ISSUANCE', label: 'Issuance & Redemption', icon: Coins },
        { id: 'LEDGER', label: 'Digital Dollar Ledger', icon: BookOpen },
        { id: 'TREASURY', label: 'Treasury Operations', icon: Landmark },
        { id: 'MONETARY_POLICY', label: 'Monetary Policy Engine', icon: TrendingUp },
        { id: 'FOMC', label: 'FOMC Control Room', icon: Users },
      ],
    },
    {
      groupName: 'INTERMEDIATED SYSTEM',
      items: [
        { id: 'BANKS', label: 'Commercial Banks', icon: Building2 },
        { id: 'WALLETS', label: 'Wallet System', icon: WalletIcon },
        { id: 'SETTLEMENT_RAILS', label: 'Payment Rails Simulator', icon: Cpu },
        { id: 'FEDNOW', label: 'FedNow Interoperability', icon: Zap },
      ],
    },
    {
      groupName: 'ADVANCED ARCHITECTURES',
      items: [
        { id: 'FINANCIAL_STABILITY', label: 'Financial Stability', icon: ShieldAlert },
        { id: 'PRIVACY', label: 'Privacy & Identity', icon: EyeOff },
        { id: 'OFFLINE', label: 'Offline Payments Lab', icon: WifiOff, badge: pendingOfflineCount ? `${pendingOfflineCount}` : undefined },
        { id: 'PROGRAMMABLE', label: 'Programmable Money', icon: Code2 },
        { id: 'TOKENIZATION_DVP', label: 'Tokenized DvP Settlement', icon: Receipt, badge: pendingDvpCount ? `${pendingDvpCount}` : undefined },
        { id: 'CROSS_BORDER', label: 'Cross-Border (mCBDC)', icon: Globe2 },
      ],
    },
    {
      groupName: 'OPERATIONS & RESEARCH',
      items: [
        { id: 'TRANSACTION_SIMULATOR', label: 'Transaction Simulator', icon: FlaskConical },
        { id: 'CYBERSECURITY', label: 'Security Operations (SOC)', icon: ShieldCheck, badge: activeIncidentsCount ? `${activeIncidentsCount}` : undefined },
        { id: 'AUDIT', label: 'Audit & Traceability', icon: FileCheck },
        { id: 'DATA_LAB', label: 'Economic Data Lab', icon: LineChart },
        { id: 'INFRASTRUCTURE', label: 'System Infrastructure', icon: Server },
        { id: 'LEGAL', label: 'Legal & Statutory Explorer', icon: Scale },
      ],
    },
  ];

  return (
    <aside className="w-64 shrink-0 bg-[#081120] border-r border-slate-800 flex flex-col h-[calc(100vh-85px)] select-none">
      <div className="p-3 border-b border-slate-800/80 bg-[#060d1a]">
        <div className="text-[10px] font-mono uppercase tracking-widest text-slate-400 font-semibold mb-1">
          OPERATING WORKSTATION
        </div>
        <div className="text-xs font-semibold text-slate-200 flex items-center justify-between">
          <span>FRB-DUSD MONETARY LAB</span>
          <span className="text-[10px] font-mono px-1.5 py-0.2 bg-blue-900/50 text-blue-300 border border-blue-700/50 rounded-xs">
            v3.8-FED
          </span>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-2 space-y-4 text-xs font-['Public_Sans',sans-serif]">
        {navGroups.map((group, idx) => (
          <div key={idx} className="space-y-1">
            <div className="px-2 py-1 text-[10px] font-mono font-bold tracking-wider text-slate-400 uppercase">
              {group.groupName}
            </div>
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeModule === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveModule(item.id)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xs transition-colors text-left group ${
                    isActive
                      ? 'bg-blue-950/80 text-white font-semibold border-l-2 border-blue-500 shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <Icon
                      className={`w-4 h-4 shrink-0 transition-colors ${
                        isActive ? 'text-blue-400' : 'text-slate-400 group-hover:text-slate-200'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 ml-1">
                    {item.badge && (
                      <span
                        className={`text-[9px] font-mono px-1.5 py-0.2 rounded-xs font-semibold ${
                          item.badge === 'CORE'
                            ? 'bg-blue-900/60 text-blue-300 border border-blue-700/40'
                            : 'bg-amber-900/60 text-amber-200 border border-amber-700/40'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                    {isActive && <ChevronRight className="w-3.5 h-3.5 text-blue-400" />}
                  </div>
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Persistent institutional workstation tag */}
      <div className="p-3 border-t border-slate-800 bg-[#060c18] text-[10px] font-mono text-slate-400">
        <div className="flex items-center justify-between">
          <span>CLASSIFICATION:</span>
          <span className="text-slate-200 font-semibold">PUBLIC RESEARCH</span>
        </div>
        <div className="flex items-center justify-between mt-1">
          <span>MODEL ID:</span>
          <span className="text-blue-400">DUSD-SYNTH-2026</span>
        </div>
      </div>
    </aside>
  );
};
