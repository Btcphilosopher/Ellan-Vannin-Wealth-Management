import React from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  StepForward, 
  ShieldCheck, 
  AlertTriangle,
  Activity,
  Layers,
  Database,
  Lock,
  Cpu,
  Download
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    isRunning,
    timeScale,
    simulationClock,
    blockHeight,
    transactionsPerSec,
    fedBalanceSheet,
    monetaryPolicy,
    accountingStatus,
    toggleSimulation,
    setTimeScale,
    stepSimulationTick,
    resetSimulation,
    exportSimulationState,
  } = useSimulator();

  return (
    <header className="border-b border-slate-800 bg-[#070e1b] text-slate-200 select-none sticky top-0 z-30 shadow-md">
      {/* Disclaimer Top Alert Stripe */}
      <div className="bg-[#0b172a] border-b border-slate-800/80 px-3 py-1 flex items-center justify-between text-[11px] font-mono tracking-wider text-slate-300">
        <div className="flex items-center gap-3 overflow-x-auto whitespace-nowrap scrollbar-none">
          <span className="flex items-center gap-1.5 text-amber-400 font-semibold bg-amber-950/40 px-2 py-0.5 border border-amber-800/60 rounded-xs">
            <AlertTriangle className="w-3 h-3" />
            SIMULATION ENVIRONMENT
          </span>
          <span className="text-slate-400">SYNTHETIC DATA</span>
          <span className="text-slate-600">•</span>
          <span className="text-slate-400">HYPOTHETICAL DIGITAL DOLLAR ARCHITECTURE</span>
          <span className="text-slate-600">•</span>
          <span className="text-rose-400 font-semibold bg-rose-950/40 px-2 py-0.5 border border-rose-800/60 rounded-xs">
            NOT A LIVE FEDERAL RESERVE SYSTEM
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => exportSimulationState('json')}
            className="flex items-center gap-1 text-[10px] bg-slate-800/80 hover:bg-slate-700 text-slate-300 px-2 py-0.5 border border-slate-700 rounded-xs transition-colors"
            title="Export JSON snapshot"
          >
            <Download className="w-2.5 h-2.5" />
            JSON
          </button>
          <button
            onClick={() => exportSimulationState('csv')}
            className="flex items-center gap-1 text-[10px] bg-slate-800/80 hover:bg-slate-700 text-slate-300 px-2 py-0.5 border border-slate-700 rounded-xs transition-colors"
            title="Export CSV transactions"
          >
            <Download className="w-2.5 h-2.5" />
            CSV
          </button>
        </div>
      </div>

      {/* Main Title & Simulation Engine Controls */}
      <div className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          {/* Institutional Crest / Seal Icon */}
          <div className="w-10 h-10 rounded-xs bg-gradient-to-br from-[#0f274a] to-[#0a182d] border border-blue-600/40 flex items-center justify-center text-blue-400 shadow-inner">
            <Layers className="w-5 h-5 text-blue-300" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-base font-bold tracking-tight text-white font-['Public_Sans',sans-serif]">
                FEDERAL RESERVE DIGITAL DOLLAR
              </h1>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 bg-blue-950/80 text-blue-300 border border-blue-700/60 rounded-xs font-semibold">
                DUSD Research
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono tracking-wide">
              U.S. CBDC RESEARCH &amp; MONETARY INFRASTRUCTURE SIMULATOR
            </p>
          </div>
        </div>

        {/* Engine Time & Execution Controls */}
        <div className="flex items-center gap-3 bg-[#0a1424] border border-slate-800 px-2.5 py-1.5 rounded-xs">
          <div className="flex items-center gap-1">
            <button
              onClick={toggleSimulation}
              className={`p-1.5 rounded-xs font-mono text-xs flex items-center gap-1.5 transition-colors ${
                isRunning 
                  ? 'bg-amber-950/60 text-amber-300 border border-amber-700/60 hover:bg-amber-900/60' 
                  : 'bg-emerald-950/60 text-emerald-300 border border-emerald-700/60 hover:bg-emerald-900/60'
              }`}
              title={isRunning ? 'Pause Simulation' : 'Run Simulation'}
            >
              {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span className="text-[11px] font-semibold">{isRunning ? 'PAUSE' : 'RUN'}</span>
            </button>

            <button
              onClick={stepSimulationTick}
              disabled={isRunning}
              className="p-1.5 bg-slate-800 text-slate-300 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed border border-slate-700 rounded-xs text-[11px]"
              title="Single step tick (+60s)"
            >
              <StepForward className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={resetSimulation}
              className="p-1.5 bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 rounded-xs text-[11px]"
              title="Reset to Initial Baseline"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-4 w-px bg-slate-800" />

          {/* Time Scale Multipliers */}
          <div className="flex items-center gap-1 text-[11px] font-mono">
            <span className="text-slate-500 text-[10px] mr-1">SPEED:</span>
            {[1, 10, 100, 1000].map(s => (
              <button
                key={s}
                onClick={() => setTimeScale(s)}
                className={`px-1.5 py-0.5 rounded-xs font-semibold transition-colors ${
                  timeScale === s 
                    ? 'bg-blue-600 text-white shadow-xs' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {s}×
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Terminal Telemetry Metric Bar */}
      <div className="bg-[#050b15] border-t border-slate-800 px-4 py-1.5 flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-300 gap-y-1">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-slate-400">SYSTEM STATUS:</span>
            <span className="text-emerald-400 font-bold">OPERATIONAL</span>
          </div>

          <div className="flex items-center gap-1.5">
            <Database className="w-3 h-3 text-blue-400" />
            <span className="text-slate-400">LEDGER:</span>
            <span className="text-white font-semibold">SYNCHRONIZED (BLK #{blockHeight.toLocaleString()})</span>
          </div>

          <div className="flex items-center gap-1.5">
            <Activity className="w-3 h-3 text-cyan-400" />
            <span className="text-slate-400">THROUGHPUT:</span>
            <span className="text-cyan-300 font-semibold tabular-nums">{transactionsPerSec.toLocaleString()} TPS</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">SETTLEMENT:</span>
            <span className="text-emerald-400 font-semibold">NORMAL (0.42s)</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">LIQUIDITY:</span>
            <span className="text-blue-400 font-semibold">STABLE</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">POLICY RATE:</span>
            <span className="text-amber-300 font-bold tabular-nums">{monetaryPolicy.policyRate.toFixed(2)}%</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">DUSD SUPPLY:</span>
            <span className="text-emerald-300 font-bold tabular-nums">
              {formatCurrency(fedBalanceSheet.liabilities.digitalDollarInCirculation, { compact: true })}
            </span>
          </div>
        </div>

        {/* Double-Entry Invariant Status Badge */}
        <div className="flex items-center gap-2">
          <div 
            className={`flex items-center gap-1.5 px-2 py-0.5 rounded-xs border text-[10px] font-semibold font-mono ${
              accountingStatus.valid
                ? 'bg-emerald-950/50 border-emerald-700/60 text-emerald-300'
                : 'bg-rose-950/80 border-rose-600 text-rose-200 animate-pulse'
            }`}
          >
            {accountingStatus.valid ? (
              <>
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span>DOUBLE-ENTRY INVARIANT: BALANCED (Δ $0.00)</span>
              </>
            ) : (
              <>
                <AlertTriangle className="w-3 h-3 text-rose-400" />
                <span>INVARIANT VIOLATION: Δ ${accountingStatus.discrepancy.toLocaleString()}</span>
              </>
            )}
          </div>

          <div className="text-slate-400 text-[10px] tabular-nums pl-1 border-l border-slate-800">
            {simulationClock}
          </div>
        </div>
      </div>
    </header>
  );
};
