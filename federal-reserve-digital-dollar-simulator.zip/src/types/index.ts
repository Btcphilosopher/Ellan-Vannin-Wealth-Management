/**
 * Federal Reserve Digital Dollar (DUSD) Research & Monetary Infrastructure Simulator
 * Domain Model Definitions
 * 
 * DISCLAIMER: FICTIONAL RESEARCH SIMULATION — SYNTHETIC DATA — HYPOTHETICAL ARCHITECTURE
 */

export type AssetType = 
  | 'DUSD'                        // Hypothetical Federal Reserve Digital Dollar (direct central-bank liability)
  | 'FEDERAL_RESERVE_NOTES'      // Physical currency in circulation
  | 'BANK_RESERVES'              // Master account reserves at Federal Reserve
  | 'COMMERCIAL_DEPOSIT'         // Commercial bank liability (demand deposit)
  | 'TREASURY_BALANCE'           // Treasury General Account (TGA) balance
  | 'TOKENIZED_DEPOSIT'          // Commercial bank tokenized liability
  | 'PRIVATE_STABLECOIN'         // Non-bank private tokenized fiat
  | 'TREASURY_SECURITY'          // U.S. Treasury Bills, Notes, Bonds
  | 'TOKENIZED_SECURITY'         // Tokenized Treasury / Corporate Bond (DvP eligible)
  | 'AGENCY_MBS'                 // Mortgage-backed securities held on Fed SOMA
  | 'FOREIGN_RESERVE';           // Central bank FX swap / SDR balances

export type SettlementRail = 
  | 'DUSD_CORE_LEDGER'           // Central bank real-time gross settlement for DUSD
  | 'FEDWIRE_FUNDS'              // Fedwire wholesale high-value payment system
  | 'FEDNOW_SERVICE'             // Federal Reserve instant retail payment service
  | 'ACH_NETWORK'                // Automated Clearing House batch settlement
  | 'CARD_NETWORK_ADAPTER'       // Commercial card network gateway
  | 'TREASURY_DIRECT_RAIL'       // U.S. Fiscal Service disbursement rail
  | 'CROSS_BORDER_MCBDC';        // Multi-CBDC bilateral FX corridor

export type PrivacyLevel = 
  | 'TIER_1_ANONYMOUS'           // Micro-transactions (<$200) zero identity disclosure
  | 'TIER_2_INTERMEDIATED'       // Routine retail (<$10,000) bank visible, Fed sees hashed pseudonym
  | 'TIER_3_REGISTERED'          // Institutional / High-value (> $10,000) fully KYC/AML registered
  | 'TIER_4_CONFIDENTIAL_COMPLIANCE'; // Zero-knowledge proof verified with encrypted audit key

export type TransactionStatus = 
  | 'INITIATED'
  | 'AUTHENTICATED'
  | 'VALIDATED'
  | 'COMPLIANCE_CHECK'
  | 'LIQUIDITY_CHECK'
  | 'ROUTED'
  | 'SETTLED'
  | 'RECONCILED'
  | 'FAILED'
  | 'ROLLED_BACK';

export interface LedgerTransaction {
  id: string;
  timestamp: string;
  blockHeight: number;
  originator: string;
  originatorName: string;
  intermediaryId: string;
  intermediaryName: string;
  beneficiary: string;
  beneficiaryName: string;
  amount: number;
  assetType: AssetType;
  settlementRail: SettlementRail;
  privacyClass: PrivacyLevel;
  status: TransactionStatus;
  latencyMs: number;
  auditHash: string;
  signature: string;
  isOfflineSync?: boolean;
  memo?: string;
  complianceFlag?: 'CLEARED' | 'SUSPICIOUS_VELOCITY' | 'SANCTION_SCREEN_PASS' | 'FLAGGED_CTR';
}

export interface FedBalanceSheet {
  timestamp: string;
  assets: {
    treasurySecurities: number;    // SOMA holdings of Treasuries
    agencySecurities: number;      // Agency debt & MBS
    loansToDepositoryInstitutions: number; // Discount window
    repoAgreements: number;        // Overnight repo
    foreignCurrencyReserves: number;// FX holdings
    totalAssets: number;
  };
  liabilities: {
    digitalDollarInCirculation: number; // DUSD outstanding liability ($2.84T baseline)
    bankReserveBalances: number;        // Depository institution reserves ($3.91T baseline)
    federalReserveNotes: number;        // Physical paper currency
    treasuryGeneralAccount: number;     // TGA cash balance
    reverseRepoObligations: number;     // Overnight reverse repo facility (ON RRP)
    otherLiabilities: number;
    totalLiabilities: number;
  };
  capital: {
    surplusCapital: number;             // Reserve Bank paid-in capital & retained earnings
    totalCapital: number;
  };
  invariantCheck: {
    balanced: boolean;
    discrepancy: number; // Must be 0 in double-entry accounting
  };
}

export interface CommercialBank {
  id: string;
  name: string;
  routingNumber: string;
  assets: {
    centralBankReserves: number;
    dusdOperatingBalance: number;
    commercialLoans: number;
    consumerMortgages: number;
    treasurySecurities: number;
    cashInVault: number;
    totalAssets: number;
  };
  liabilities: {
    retailDeposits: number;
    commercialDeposits: number;
    wholesaleFunding: number;
    dusdConversionFacility: number;
    fedDiscountBorrowings: number;
    totalLiabilities: number;
  };
  equity: {
    tier1CommonCapital: number;
    totalEquity: number;
  };
  metrics: {
    cet1Ratio: number;              // Common Equity Tier 1 (%)
    liquidityCoverageRatio: number; // LCR (%)
    dusdDepositOutflowRate: number; // % of deposits migrated to DUSD
    reserveRatio: number;
    loanToDepositRatio: number;
    netInterestMargin: number;      // NIM (%)
    dailySettlementVolume: number;
  };
  status: 'OPTIMAL' | 'MODERATE_STRESS' | 'LIQUIDITY_WATCH' | 'CRITICAL';
}

export type WalletCategory = 
  | 'CONSUMER'
  | 'MERCHANT'
  | 'BUSINESS'
  | 'INSTITUTIONAL'
  | 'GOVERNMENT'
  | 'FINANCIAL_INSTITUTION';

export interface Wallet {
  id: string;
  ownerName: string;
  category: WalletCategory;
  intermediaryId: string;
  intermediaryName: string;
  dusdBalance: number;
  offlineAllowance: number;
  offlineAvailable: number;
  dailyTransferLimit: number;
  dailyTransferredToday: number;
  identityStatus: 'VERIFIED' | 'TIER_1_PSEUDONYM' | 'PENDING_DOCUMENTATION' | 'ENHANCED_DILIGENCE';
  privacyTier: PrivacyLevel;
  securityStatus: 'HARDWARE_ENCLAVE_ACTIVE' | 'SECURE_ELEMENT_VALID' | 'SOFTWARE_CONTAINER' | 'FLAGGED';
  programmableRulesCount: number;
  createdAt: string;
  lastActive: string;
}

export interface MonetaryPolicyState {
  federalFundsTargetRangeMin: number; // e.g., 4.25%
  federalFundsTargetRangeMax: number; // e.g., 4.50%
  policyRate: number;                 // Effective FFR e.g., 4.33%
  interestOnReserveBalances: number;  // IORB e.g., 4.40%
  overnightReverseRepoRate: number;   // ON RRP rate e.g., 4.30%
  dusdRemunerationRate: number;       // CBDC interest rate (0% for cash-like, or tiered)
  holdingLimitIndividual: number;     // e.g. $10,000 cap per retail wallet
  openMarketOperationsPace: number;   // $B per month change in balance sheet
  discountWindowPrimaryRate: number;  // e.g., 4.75%
  
  macroIndicators: {
    headlineInflationCPI: number;     // % e.g., 2.4%
    corePCEInflation: number;         // % e.g., 2.3%
    realGdpGrowth: number;            // % e.g., 2.1%
    unemploymentRate: number;         // % e.g., 3.9%
    paymentVelocity: number;          // V = GDP / Money Stock e.g., 1.48
    financialConditionsIndex: number; // Goldman/Chicago Fed scale e.g., -0.22 (loose/tight)
    cbdcSubstitutionElasticity: number; // sensitivity of bank deposits to DUSD
    systemLiquidityStressScore: number;// 0 - 100
  };
  
  scenarioName: 'BASELINE' | 'EASING' | 'TIGHTENING' | 'BANKING_STRESS' | 'CBDC_RUN_SCENARIO' | 'HIGH_ADOPTION' | 'LOW_ADOPTION';
}

export type ScenarioType = MonetaryPolicyState['scenarioName'];

export interface FOMCMemberOpinion {
  memberId: string;
  role: string;
  title: string;
  stance: 'HAWKISH' | 'NEUTRAL' | 'DOVISH' | 'FINANCIAL_STABILITY_FOCUSED';
  recommendation: string;
  vote: 'HIKE_25' | 'HOLD' | 'CUT_25' | 'PAUSE_CBDC_LIMITS';
  rationale: string;
}

export interface PaymentRailAdapter {
  id: string;
  name: string;
  description: string;
  avgLatencyMs: number;
  tpsThroughput: number;
  peakCapacityTps: number;
  settlementFinality: 'IMMEDIATE_ATOMIC' | 'INTRA_DAY_GROSS' | 'NEXT_DAY_NET' | 'BATCH_MULTILATERAL';
  activeQueueDepth: number;
  failureRatePercent: number;
  liquidityRequirement: 'CENTRAL_BANK_PRE_FUNDED' | 'COLLATERALIZED' | 'COMMERCIAL_CREDIT';
  status: 'ONLINE' | 'THROTTLED' | 'MAINTENANCE' | 'TEST_MODE';
}

export interface OfflinePaymentSimulation {
  id: string;
  sourceDeviceId: string;
  targetDeviceId: string;
  amount: number;
  offlineCounter: number;
  hardwareSignature: string;
  timestamp: string;
  status: 'STORED_ON_CHIP' | 'SYNCHRONIZING' | 'RECONCILED' | 'DOUBLE_SPEND_DETECTED';
  reconciliationBlock?: number;
}

export interface ProgrammablePaymentContract {
  id: string;
  title: string;
  payerName: string;
  payeeName: string;
  principalAmount: number;
  paymentType: 'SUPPLIER_ESCROW' | 'GOVERNMENT_STIMULUS' | 'CORPORATE_PAYROLL_LOCK' | 'TAX_WITHHOLDING' | 'IOT_MACHINE_SETTLEMENT';
  conditionDescription: string;
  state: 'LOCKED' | 'CONDITION_VERIFIED' | 'SETTLED' | 'EXPIRED' | 'CANCELLED';
  createdDate: string;
  expiryDate: string;
  verificationSource: string;
  executionLogs: string[];
}

export interface TokenizedDvPContract {
  id: string;
  securityTitle: string;
  cusip: string;
  securityType: 'TOKENIZED_TREASURY_BILL' | 'TOKENIZED_CORP_BOND' | 'TOKENIZED_COMMERCIAL_PAPER' | 'TOKENIZED_MUNICIPAL';
  parValue: number;
  yieldPercent: number;
  settlementDusdAmount: number;
  buyerInstitution: string;
  sellerInstitution: string;
  assetLegStatus: 'ESCROWED' | 'MATCHED' | 'TRANSFERRED' | 'FAILED';
  paymentLegStatus: 'ESCROWED' | 'MATCHED' | 'TRANSFERRED' | 'FAILED';
  atomicFinality: 'PENDING' | 'EXECUTED_ATOMIC' | 'ROLLED_BACK';
  timestamp: string;
}

export interface TreasuryOperationsState {
  tgaBalance: number;
  dailyReceipts: number;
  dailyDisbursements: number;
  upcomingAuctionVolume: number;
  debtServiceDaily: number;
  socialSecurityDirectDisbursementPace: number;
  disbursementRailShare: {
    dusdDirect: number;     // % disbursed directly to DUSD citizen wallets
    fedwireToBank: number;  // % traditional bank deposit via Fedwire
    achBatch: number;       // % traditional ACH
  };
}

export interface CrossBorderCorridor {
  id: string;
  partnerCurrency: 'EUR' | 'JPY' | 'GBP' | 'CAD';
  partnerCbdcName: string;
  foreignCentralBank: string;
  exchangeRate: number; // 1 DUSD = X foreign currency
  dailyCorridorVolumeDusd: number;
  settlementProtocol: 'PVP_SYNCHRONIZED_ATOMIC' | 'NOSTRO_VOSTRO_INTERMEDIATED';
  liquidityPoolDusd: number;
  liquidityPoolForeign: number;
  averageLatencySec: number;
  status: 'ACTIVE_HEALTHY' | 'SURCHARGE_RISK' | 'VOLATILITY_GUARD';
}

export interface SecurityIncident {
  id: string;
  timestamp: string;
  title: string;
  type: 'ABNORMAL_TRANSACTION_VELOCITY' | 'UNUSUAL_GEO_CONCENTRATION' | 'KEY_CEREMONY_ROTATION' | 'DDOS_ATTEMPT_ABSORBED' | 'SUSPICIOUS_ORPHANED_OFFLINE_SYNC';
  severity: 'INFO' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'MONITORING' | 'UNDER_INVESTIGATION' | 'CONTAINED' | 'RESOLVED';
  affectedIntermediariesCount: number;
  monitoredExposureDusd: number;
  description: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  operatorId: string;
  actionCategory: 'ISSUANCE' | 'REDEMPTION' | 'POLICY_ADJUSTMENT' | 'SETTLEMENT_OVERRIDE' | 'KEY_ROTATION' | 'STRESS_INJECTION' | 'LEDGER_CHECKPOINT';
  description: string;
  previousStateSnippet: string;
  newStateSnippet: string;
  cryptographicReference: string;
  authorizationCertificate: string;
}

export interface InfrastructureNode {
  id: string;
  region: 'NEW_YORK' | 'CHICAGO' | 'DALLAS' | 'ATLANTA' | 'SAN_FRANCISCO' | 'WASHINGTON_DC';
  role: 'PRIMARY_VALIDATOR' | 'CONSENSUS_ORDERER' | 'SETTLEMENT_CORE' | 'API_GATEWAY' | 'ARCHIVAL_AUDIT';
  status: 'HEALTHY' | 'DEGRADED' | 'FAILOVER_STANDBY' | 'SYNCING';
  cpuUtilizationPercent: number;
  memoryUtilizationPercent: number;
  networkThroughputGbps: number;
  activePeerCount: number;
  latencyToCoreMs: number;
}
