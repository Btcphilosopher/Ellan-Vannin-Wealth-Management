import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  FlaskConical,
  Play,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Search,
  Lock,
  Layers
} from 'lucide-react';
import { SettlementRail, PrivacyLevel } from '../types';

export const TransactionLabView: React.FC = () => {
  const { wallets, banks, executeCustomTransaction } = useSimulator();

  const [originatorId, setOriginatorId] = useState<string>(wallets[0]?.id || 'WLT-JC-7419');
  const [beneficiaryId, setBeneficiaryId] = useState<string>(wallets[1]?.id || 'WLT-MERCHANT-WHOLEFOODS');
  const [amount, setAmount] = useState<number>(1250);
  const [rail, setRail] = useState<SettlementRail>('DUSD_CORE_LEDGER');
  const [privacy, setPrivacy] = useState<PrivacyLevel>('TIER_2_INTERMEDIATED');
  const [priority, setPriority] = useState<string>('NORMAL');
  const [purposeCode, setPurposeCode] = useState<string>('SUPP'); // ISO 20022 Supplier Payment
  const [memo, setMemo] = useState<string>('Commercial Invoice #98421 settlement');

  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [executionStep, setExecutionStep] = useState<number>(0);
  const [completedTxId, setCompletedTxId] = useState<string | null>(null);

  const originator = wallets.find(w => w.id === originatorId) || wallets[0];
  const beneficiary = wallets.find(w => w.id === beneficiaryId) || wallets[1];

  const executionSteps = [
    { step: 1, label: 'Transaction initiated', detail: 'Payload constructed and encrypted via Client App SDK' },
    { step: 2, label: 'Originator authenticated', detail: 'FIDO2 WebAuthn & Hardware Enclave key signature verified' },
    { step: 3, label: 'Intermediary validation', detail: 'Commercial bank confirms account standing & identity tier' },
    { step: 4, label: 'Compliance screening', detail: 'Real-time FinCEN / OFAC SDN list screening passed' },
    { step: 5, label: 'Liquidity verification', detail: 'Originator DUSD balance and bank reserve backing verified' },
    { step: 6, label: 'Routed to Federal Reserve core', detail: 'ISO 20022 pacs.008 message routed to Central Ledger' },
    { step: 7, label: 'Core ledger settlement', detail: 'Atomic balance reassignment executed across PBFT validators' },
    { step: 8, label: 'Intermediary accounts reconciled', detail: 'Originating and receiving banks updated on sub-ledger' },
    { step: 9, label: 'Settlement finalized', detail: 'Cryptographic receipt issued; irrevocable legal finality achieved' },
  ];

  const handleRunSimulation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!originator || !beneficiary || originator.id === beneficiary.id) {
      alert('Originator and Beneficiary must be valid and distinct wallets.');
      return;
    }

    setIsExecuting(true);
    setExecutionStep(1);
    setCompletedTxId(null);

    // Animate the 9-step progression cleanly
    let current = 1;
    const interval = setInterval(async () => {
      current++;
      setExecutionStep(current);
      if (current >= 9) {
        clearInterval(interval);
        try {
          const tx = await executeCustomTransaction({
            originator: originator.id,
            beneficiary: beneficiary.id,
            intermediaryId: originator.intermediaryId,
            amount: amount,
            assetType: 'DUSD',
            settlementRail: rail,
            privacyLevel: privacy,
            priority: priority as any,
            memo: `${purposeCode}: ${memo}`,
          });
          setCompletedTxId(tx.id);
        } catch (err: any) {
          alert(`Transaction failed: ${err.message}`);
        } finally {
          setIsExecuting(false);
        }
      }
    }, 280);
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-blue-400" />
              INTERACTIVE TRANSACTION SANDBOX &amp; 9-STAGE LIFECYCLE
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              ISO 20022 PAC.008 PROTOCOL
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Construct Synthetic Payment Envelopes • Step-by-Step Ledger Execution • Real-Time Settlement Tracing
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono text-xs">
        {/* Transaction Constructor Form (5 cols) */}
        <div className="lg:col-span-5 bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-bold text-white uppercase tracking-wider">
              CONFIGURE PAYMENT ENVELOPE
            </h3>
            <span className="text-[10px] text-slate-400">STAGE BUILDER</span>
          </div>

          <form onSubmit={handleRunSimulation} className="space-y-3">
            <div>
              <label className="text-slate-400 text-[11px] block mb-1">ORIGINATOR (DEBIT)</label>
              <select
                value={originatorId}
                onChange={(e) => setOriginatorId(e.target.value)}
                className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
              >
                {wallets.map(w => (
                  <option key={w.id} value={w.id}>
                    {w.ownerName} (DUSD: {formatCurrency(w.dusdBalance, { compact: true })})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">BENEFICIARY (CREDIT)</label>
              <select
                value={beneficiaryId}
                onChange={(e) => setBeneficiaryId(e.target.value)}
                className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
              >
                {wallets.filter(w => w.id !== originatorId).map(w => (
                  <option key={w.id} value={w.id}>
                    {w.ownerName} ({w.category})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">AMOUNT (DUSD)</label>
                <input
                  type="number"
                  min="0.01"
                  step="10"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">PRIORITY</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
                >
                  <option value="NORMAL">Normal (RTGS)</option>
                  <option value="HIGH">High (Wholesale)</option>
                  <option value="EMERGENCY">Emergency (Sovereign)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">SETTLEMENT RAIL</label>
                <select
                  value={rail}
                  onChange={(e) => setRail(e.target.value as any)}
                  className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
                >
                  <option value="DUSD_CORE_LEDGER">DUSD Core</option>
                  <option value="FEDNOW_SERVICE">FedNow</option>
                  <option value="FEDWIRE_FUNDS">Fedwire</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">PRIVACY CLASS</label>
                <select
                  value={privacy}
                  onChange={(e) => setPrivacy(e.target.value as any)}
                  className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
                >
                  <option value="TIER_1_ANONYMOUS">Tier 1 (&lt;$200)</option>
                  <option value="TIER_2_INTERMEDIATED">Tier 2 Intermediated</option>
                  <option value="TIER_3_REGISTERED">Tier 3 Full BSA/AML</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">ISO 20022 PURPOSE CODE</label>
              <select
                value={purposeCode}
                onChange={(e) => setPurposeCode(e.target.value)}
                className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
              >
                <option value="SUPP">SUPP - Supplier Payment</option>
                <option value="SALA">SALA - Salary Payment</option>
                <option value="TAXS">TAXS - Tax Payment</option>
                <option value="TREA">TREA - Treasury Operations</option>
                <option value="COMC">COMC - Commercial E-Commerce</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={isExecuting}
              className="w-full py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold rounded-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Play className="w-4 h-4" />
              {isExecuting ? 'EXECUTING 9-STEP PIPELINE...' : 'DISPATCH SIMULATION TO FED CORE'}
            </button>
          </form>
        </div>

        {/* 9-Step Lifecycle Execution Trace (7 cols) */}
        <div className="lg:col-span-7 bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-cyan-400" />
              STEP-BY-STEP SETTLEMENT EXECUTION TRACE
            </h3>
            {completedTxId && (
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 border border-emerald-800 rounded-xs">
                CONFIRMED: {completedTxId}
              </span>
            )}
          </div>

          <div className="space-y-1.5">
            {executionSteps.map(s => {
              const isPast = executionStep > s.step;
              const isCurrent = executionStep === s.step;
              return (
                <div
                  key={s.step}
                  className={`p-2.5 rounded-xs border transition-all flex items-center justify-between text-xs ${
                    isCurrent
                      ? 'bg-blue-950/60 border-blue-500 text-white shadow-xs'
                      : isPast
                      ? 'bg-[#060c18] border-slate-800 text-slate-300'
                      : 'bg-[#050a14] border-slate-800/40 text-slate-600'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className={`w-5 h-5 rounded-xs flex items-center justify-center text-[10px] font-bold ${
                      isPast
                        ? 'bg-emerald-600 text-white'
                        : isCurrent
                        ? 'bg-blue-600 text-white animate-pulse'
                        : 'bg-slate-800 text-slate-500'
                    }`}>
                      {isPast ? '✓' : s.step}
                    </span>
                    <div>
                      <div className="font-bold">{s.label}</div>
                      <div className="text-[10px] text-slate-400">{s.detail}</div>
                    </div>
                  </div>

                  <span className={`text-[10px] font-semibold ${
                    isPast ? 'text-emerald-400' : isCurrent ? 'text-blue-400' : 'text-slate-600'
                  }`}>
                    {isPast ? 'CLEARED' : isCurrent ? 'PROCESSING...' : 'QUEUED'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
