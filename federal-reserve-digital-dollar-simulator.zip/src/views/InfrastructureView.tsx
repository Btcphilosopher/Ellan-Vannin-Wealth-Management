import React from 'react';
import { useSimulator } from '../store/simulatorStore';
import {
  Server,
  Cpu,
  HardDrive,
  Activity,
  CheckCircle2,
  ShieldCheck,
  RefreshCw,
  Clock,
  Layers,
  Network
} from 'lucide-react';
import { InfrastructureNode } from '../types';

export const InfrastructureView: React.FC = () => {
  const { infrastructureNodes, blockHeight, transactionsPerSec } = useSimulator();

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Server className="w-5 h-5 text-blue-400" />
              FEDERAL RESERVE CORE INFRASTRUCTURE &amp; VALIDATOR NODES
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              GEO-DISTRIBUTED BFT CLUSTER
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            6 Federal Reserve District Data Centers • Hardware Security Modules • 99.999% High Availability
          </p>
        </div>
      </div>

      {/* Cluster Metrics Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
        <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">LEDGER BLOCK HEIGHT</span>
          <span className="text-xl font-bold text-white">#{blockHeight.toLocaleString()}</span>
          <span className="text-slate-400 text-[10px]">Deterministic state commits</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">CLUSTER THROUGHPUT (TPS)</span>
          <span className="text-xl font-bold text-emerald-400">{transactionsPerSec.toLocaleString()}</span>
          <span className="text-slate-400 text-[10px]">Peak test capacity 125,000 TPS</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">CONSENSUS FINALITY</span>
          <span className="text-xl font-bold text-cyan-400">&lt; 400 ms</span>
          <span className="text-slate-400 text-[10px]">Byzantine Fault Tolerant</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">DISASTER RECOVERY RPO/RTO</span>
          <span className="text-xl font-bold text-indigo-400">RPO 0s / RTO &lt;1s</span>
          <span className="text-slate-400 text-[10px]">Zero data loss synchronous mirror</span>
        </div>
      </div>

      {/* 6 Federal Reserve Validator District Nodes Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 font-mono text-xs">
        {infrastructureNodes.map((node: InfrastructureNode) => (
          <div key={node.id} className="bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div>
                <span className="font-bold text-white text-xs block">{node.region.replace(/_/g, ' ')} DISTRICT</span>
                <span className="text-[10px] text-slate-500">{node.id} • {node.role.replace(/_/g, ' ')}</span>
              </div>
              <span className={`text-[9px] px-2 py-0.5 rounded-xs font-bold ${
                node.status === 'HEALTHY' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
              }`}>
                {node.status}
              </span>
            </div>

            <div className="space-y-2 text-[11px]">
              {/* CPU */}
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span className="flex items-center gap-1">
                    <Cpu className="w-3 h-3 text-blue-400" /> CPU Load
                  </span>
                  <span className="text-white font-semibold">{node.cpuUtilizationPercent}%</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-500 h-full rounded-full"
                    style={{ width: `${node.cpuUtilizationPercent}%` }}
                  />
                </div>
              </div>

              {/* Memory */}
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span className="flex items-center gap-1">
                    <Layers className="w-3 h-3 text-cyan-400" /> RAM Utilization
                  </span>
                  <span className="text-white font-semibold">{node.memoryUtilizationPercent}%</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-cyan-500 h-full rounded-full"
                    style={{ width: `${node.memoryUtilizationPercent}%` }}
                  />
                </div>
              </div>

              {/* Network Throughput */}
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span className="flex items-center gap-1">
                    <Network className="w-3 h-3 text-emerald-400" /> Bandwidth
                  </span>
                  <span className="text-white font-semibold">{node.networkThroughputGbps} Gbps</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full"
                    style={{ width: `${Math.min(100, (node.networkThroughputGbps / 40) * 100)}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
              <span>Peer Latency: <strong className="text-emerald-400">{node.latencyToCoreMs} ms</strong></span>
              <span>Active Peers: <strong className="text-slate-200">{node.activePeerCount}</strong></span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
