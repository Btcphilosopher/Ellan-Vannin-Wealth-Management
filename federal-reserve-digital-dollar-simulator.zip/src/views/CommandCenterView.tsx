import React from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  AreaChart,
  Area,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import {
  HISTORICAL_SUPPLY_DATA,
  INTRADAY_SETTLEMENT_DATA
} from '../data/initialData';
import {
  TrendingUp,
  Activity,
  Layers,
  ArrowUpRight,
  ShieldCheck,
  Zap,
  Building,
  Users,
  Clock,
  WifiOff,
  Scale,
  DollarSign
} from 'lucide-react';

export const CommandCenterView: React.FC = () => {
  const {
    fedBalanceSheet,
    banks,
    wallets,
    transactions,
    monetaryPolicy,
    setActiveModule,
    accountingStatus
  } = useSimulator();

  const metrics = [
    {
      title: 'DIGITAL DOLLAR SUPPLY',
      value: '$2.84T',
      exact: formatCurrency(fedBalanceSheet.liabilities.digitalDollarInCirculation),
      subtext: '+3.8% over past 30 days',
      trend: 'positive',
      icon: DollarSign,
      targetView: 'ISSUANCE',
    },
    {
      title: 'ACTIVE WALLETS',
      value: '184.7M',
      exact: '184,721,904 Verified Accounts',
      subtext: '68% of adult US population',
      trend: 'positive',
      icon: Users,
      targetView: 'WALLETS',
    },
    {
      title: 'INTERMEDIARIES',
      value: '412',
      exact: 'Commercial Banks & Credit Unions',
      subtext: '100% FedNow/DUSD interoperable',
      trend: 'neutral',
      icon: Building,
      targetView: 'BANKS',
    },
    {
      title: 'TRANSACTIONS / DAY',
      value: '86.4M',
      exact: '54,200 avg TPS peak 180k',
      subtext: 'Retail, B2B & Wholesale RTGS',
      trend: 'positive',
      icon: Activity,
      targetView: 'LEDGER',
    },
    {
      title: 'SETTLEMENT VALUE',
      value: '$7.82T',
      exact: 'Daily Gross Volume',
      subtext: 'Zero-counterparty risk RTGS',
      trend: 'positive',
      icon: TrendingUp,
      targetView: 'SETTLEMENT_RAILS',
    },
    {
      title: 'RESERVE BALANCE',
      value: '$3.91T',
      exact: formatCurrency(fedBalanceSheet.liabilities.bankReserveBalances),
      subtext: 'Master accounts at 12 Reserve Banks',
      trend: 'neutral',
      icon: Layers,
      targetView: 'ISSUANCE',
    },
    {
      title: 'AVG SETTLEMENT LATENCY',
      value: '0.42 sec',
      exact: '420ms core ledger finality',
      subtext: 'Sub-second atomic finality',
      trend: 'positive',
      icon: Clock,
      targetView: 'SETTLEMENT_RAILS',
    },
    {
      title: 'OFFLINE BALANCE',
      value: '$31.4B',
      exact: '$750 default limit per citizen',
      subtext: 'Stored in secure hardware enclaves',
      trend: 'neutral',
      icon: WifiOff,
      targetView: 'OFFLINE',
    },
  ];

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Workstation Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white">
              FEDERAL RESERVE DIGITAL MONEY COMMAND CENTER
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-900/60 border border-blue-600/60 text-blue-300 rounded-xs font-semibold">
              LIVE SYSTEM STATE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Hypothetical U.S. CBDC monetary conditions, balance sheet absorption, and real-time ledger settlement
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-[#0c1626] border border-slate-700/80 px-3 py-1.5 rounded-xs flex items-center gap-3 text-xs font-mono">
            <div>
              <span className="text-slate-400 text-[10px] block">EFFECTIVE FFR</span>
              <span className="text-white font-bold">{monetaryPolicy.policyRate.toFixed(2)}%</span>
            </div>
            <div className="h-6 w-px bg-slate-700" />
            <div>
              <span className="text-slate-400 text-[10px] block">IORB RATE</span>
              <span className="text-cyan-400 font-bold">{monetaryPolicy.interestOnReserveBalances.toFixed(2)}%</span>
            </div>
            <div className="h-6 w-px bg-slate-700" />
            <div>
              <span className="text-slate-400 text-[10px] block">ON RRP RATE</span>
              <span className="text-amber-400 font-bold">{monetaryPolicy.overnightReverseRepoRate.toFixed(2)}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* 8 Main Primary Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        {metrics.map((m, idx) => {
          const Icon = m.icon;
          return (
            <div
              key={idx}
              onClick={() => setActiveModule(m.targetView as any)}
              className="bg-[#0b1629] border border-slate-800/90 hover:border-blue-600/70 p-3 rounded-xs transition-all cursor-pointer group shadow-xs relative overflow-hidden"
            >
              <div className="flex items-center justify-between text-slate-400 mb-1">
                <span className="text-[10px] font-mono font-bold tracking-wider uppercase text-slate-400">
                  {m.title}
                </span>
                <Icon className="w-3.5 h-3.5 text-slate-500 group-hover:text-blue-400 transition-colors" />
              </div>
              <div className="text-2xl font-bold font-mono text-white tabular-nums tracking-tight">
                {m.value}
              </div>
              <div className="text-[11px] text-slate-400 font-mono truncate mt-0.5" title={m.exact}>
                {m.exact}
              </div>
              <div className="text-[10px] text-emerald-400 font-mono mt-1 flex items-center justify-between">
                <span>{m.subtext}</span>
                <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 text-blue-400 transition-opacity" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Primary Financial Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {/* Chart 1: Supply & Bank Reserve Migration */}
        <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider">
                DIGITAL DOLLAR ABSORPTION &amp; BANK RESERVES ($ TRILLIONS)
              </h3>
              <p className="text-[11px] text-slate-400 font-mono">
                Historical 6-month DUSD expansion vs bank reserve substitution
              </p>
            </div>
            <span className="text-[10px] font-mono text-blue-400 border border-blue-800/60 bg-blue-950/40 px-2 py-0.5 rounded-xs">
              M0 SUBSTITUTION
            </span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={HISTORICAL_SUPPLY_DATA}>
                <defs>
                  <linearGradient id="colorDusd" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0}/>
                  </linearGradient>
                  <linearGradient id="colorReserves" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#059669" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="month" stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} domain={[0, 5]} unit="T" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#070f1e', borderColor: '#334155', fontSize: '11px', fontFamily: 'monospace' }}
                  itemStyle={{ color: '#e2e8f0' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Area type="monotone" dataKey="dusdSupply" name="Digital Dollar (DUSD)" stroke="#3b82f6" fillOpacity={1} fill="url(#colorDusd)" />
                <Area type="monotone" dataKey="bankReserves" name="Bank Reserves at Fed" stroke="#10b981" fillOpacity={1} fill="url(#colorReserves)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Intraday Settlement Volume & Latency */}
        <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider">
                INTRADAY SETTLEMENT DISTRIBUTION BY RAIL ($ BILLIONS)
              </h3>
              <p className="text-[11px] text-slate-400 font-mono">
                Hourly throughput comparison: DUSD RTGS vs Fedwire vs FedNow
              </p>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 border border-emerald-800/60 bg-emerald-950/40 px-2 py-0.5 rounded-xs">
              FINALITY: 420ms
            </span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={INTRADAY_SETTLEMENT_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} unit="B" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#070f1e', borderColor: '#334155', fontSize: '11px', fontFamily: 'monospace' }}
                  itemStyle={{ color: '#e2e8f0' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="dusdVolume" name="DUSD Core RTGS" fill="#3b82f6" />
                <Bar dataKey="fedwireVolume" name="Fedwire Wholesale" fill="#6366f1" />
                <Bar dataKey="fednowVolume" name="FedNow Retail" fill="#14b8a6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Lower Multi-Panel: Live Intermediary Banks & Real-Time Ledger Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        {/* Intermediary Bank Health Snapshot (1 col) */}
        <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider flex items-center gap-1.5">
              <Building className="w-3.5 h-3.5 text-blue-400" />
              COMMERCIAL BANK LIQUIDITY RATIOS
            </h3>
            <button
              onClick={() => setActiveModule('BANKS')}
              className="text-[11px] font-mono text-blue-400 hover:text-blue-300"
            >
              View 8 Banks &rarr;
            </button>
          </div>

          <div className="space-y-2">
            {banks.slice(0, 4).map((bank) => (
              <div key={bank.id} className="p-2 bg-[#0d1a2f] border border-slate-800 rounded-xs text-xs space-y-1">
                <div className="flex items-center justify-between font-semibold">
                  <span className="text-slate-200">{bank.name}</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-xs ${
                    bank.status === 'OPTIMAL' ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800' : 'bg-amber-950/60 text-amber-300 border border-amber-800'
                  }`}>
                    {bank.status}
                  </span>
                </div>
                <div className="grid grid-cols-3 text-[11px] font-mono text-slate-400 pt-0.5">
                  <div>
                    <span className="text-slate-500 text-[9px] block">CET1 RATIO</span>
                    <span className="text-slate-300 font-semibold">{bank.metrics.cet1Ratio}%</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[9px] block">LCR RATIO</span>
                    <span className="text-slate-300 font-semibold">{bank.metrics.liquidityCoverageRatio}%</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[9px] block">DUSD MIGRATION</span>
                    <span className="text-amber-300 font-semibold">{bank.metrics.dusdDepositOutflowRate}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Real-time Ledger Stream (2 cols) */}
        <div className="lg:col-span-2 bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-cyan-400" />
                CENTRAL DIGITAL DOLLAR LEDGER STREAM
              </h3>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            </div>
            <button
              onClick={() => setActiveModule('LEDGER')}
              className="text-[11px] font-mono text-blue-400 hover:text-blue-300"
            >
              Full Ledger Inspector &rarr;
            </button>
          </div>

          <div className="overflow-x-auto border border-slate-800 rounded-xs">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#060c18] border-b border-slate-800 text-[10px] text-slate-400 uppercase">
                <tr>
                  <th className="py-1.5 px-2.5">TX ID</th>
                  <th className="py-1.5 px-2.5">TIME</th>
                  <th className="py-1.5 px-2.5">ORIGINATOR</th>
                  <th className="py-1.5 px-2.5">BENEFICIARY</th>
                  <th className="py-1.5 px-2.5 text-right">AMOUNT (DUSD)</th>
                  <th className="py-1.5 px-2.5">RAIL</th>
                  <th className="py-1.5 px-2.5 text-right">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[11px]">
                {transactions.slice(0, 6).map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-1.5 px-2.5 text-blue-400 font-semibold">{tx.id}</td>
                    <td className="py-1.5 px-2.5 text-slate-400">{tx.timestamp.slice(11, 19)}</td>
                    <td className="py-1.5 px-2.5 text-slate-200 truncate max-w-[140px]" title={tx.originatorName}>
                      {tx.originatorName}
                    </td>
                    <td className="py-1.5 px-2.5 text-slate-200 truncate max-w-[140px]" title={tx.beneficiaryName}>
                      {tx.beneficiaryName}
                    </td>
                    <td className="py-1.5 px-2.5 text-right font-bold text-white tabular-nums">
                      {formatCurrency(tx.amount)}
                    </td>
                    <td className="py-1.5 px-2.5">
                      <span className="text-[9px] px-1.5 py-0.2 bg-slate-800 text-slate-300 rounded-xs border border-slate-700">
                        {tx.settlementRail.replace('_SERVICE', '').replace('_NETWORK', '')}
                      </span>
                    </td>
                    <td className="py-1.5 px-2.5 text-right">
                      <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-950/40 px-1.5 py-0.2 rounded-xs border border-emerald-800/60">
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1">
            <span>High-throughput validator consensus: PBFT-Optimized Centralized Engine</span>
            <span>Finality Latency: <strong className="text-emerald-400">0.38 - 0.44 sec</strong></span>
          </div>
        </div>
      </div>
    </div>
  );
};
