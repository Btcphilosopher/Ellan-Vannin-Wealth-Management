import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  WifiOff,
  Wifi,
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  ArrowRight,
  Cpu,
  Lock
} from 'lucide-react';
import { OfflinePaymentSimulation } from '../types';

export const OfflineView: React.FC = () => {
  const { offlineQueue, queueOfflinePayment, reconcileOfflineQueue, wallets } = useSimulator();

  const [paymentAmount, setPaymentAmount] = useState<number>(45.50);
  const [payerId, setPayerId] = useState<string>(wallets[0]?.id || 'WLT-JC-7419');
  const [payeeId, setPayeeId] = useState<string>(wallets[1]?.id || 'WLT-MERCHANT-WHOLEFOODS');
  const [feedback, setFeedback] = useState<string | null>(null);

  const payer = wallets.find(w => w.id === payerId) || wallets[0];
  const payee = wallets.find(w => w.id === payeeId) || wallets[1];

  const handleSimulateOfflineNfc = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      queueOfflinePayment(
        `DEVICE-SE-${payer.id.slice(-4)}`,
        `POS-TERMINAL-${payee.id.slice(-4)}`,
        paymentAmount
      );
      setFeedback(`Offline NFC transfer completed: ${formatCurrency(paymentAmount)} signed inside Secure Element. Hardware Monotonic Counter incremented. Stored on local device chip, ready for synchronization.`);
      setTimeout(() => setFeedback(null), 5000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleReconcileWithFed = () => {
    try {
      reconcileOfflineQueue();
      setFeedback(`Successfully reconciled offline payments with Central Ledger. Double-spend checks passed (0 anomalies).`);
      setTimeout(() => setFeedback(null), 5000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <WifiOff className="w-5 h-5 text-amber-400" />
              CONSECUTIVE OFFLINE PAYMENT &amp; HARDWARE ENCLAVE SIMULATOR
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-amber-950/80 border border-amber-700/60 text-amber-300 rounded-xs font-semibold">
              SECURE ELEMENT PROTOCOL
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Zero-Connectivity Device-to-Device Mesh • Anti-Double-Spend Monotonic Counters • Staged Central Ledger Sync
          </p>
        </div>

        <button
          onClick={handleReconcileWithFed}
          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-mono text-xs font-bold rounded-xs flex items-center gap-1.5 shadow-xs transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          RECONCILE QUEUED PAYMENTS WITH FED
        </button>
      </div>

      {feedback && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-600/70 text-emerald-200 text-xs font-mono rounded-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Protocol Architecture Banner */}
      <div className="bg-[#091322] border border-slate-800 p-4 rounded-xs font-mono text-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <Cpu className="w-4 h-4 text-amber-400" />
          OFFLINE PROTOCOL ARCHITECTURE (CONSECUTIVE TRANSACTIONS)
        </h3>
        <p className="text-slate-400 text-xs">
          Offline Digital Dollar transfers utilize hardware-isolated Secure Elements (SE) and Embedded UICCs. Monotonic hardware counters increment deterministically upon cryptographic sign-off. Counterfeiting and double-spending are physically prevented at the silicon layer, even without cellular or internet connectivity.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
          <div className="p-2.5 bg-[#060c18] border border-slate-800 rounded-xs">
            <span className="text-slate-500 text-[10px] block">STORED-VALUE ALLOWANCE</span>
            <span className="text-sm font-bold text-white">$500.00 / device</span>
            <span className="text-slate-400 text-[10px] block mt-0.5">Statutory emergency cap</span>
          </div>

          <div className="p-2.5 bg-[#060c18] border border-slate-800 rounded-xs">
            <span className="text-slate-500 text-[10px] block">CONSECUTIVE OFFLINE LIMIT</span>
            <span className="text-sm font-bold text-amber-400">Up to 25 Transactions</span>
            <span className="text-slate-400 text-[10px] block mt-0.5">Mandates sync before reset</span>
          </div>

          <div className="p-2.5 bg-[#060c18] border border-slate-800 rounded-xs">
            <span className="text-slate-500 text-[10px] block">HARDWARE CRYPTO PRIMITIVE</span>
            <span className="text-sm font-bold text-emerald-400">Ed25519 &bull; BIP-32</span>
            <span className="text-slate-400 text-[10px] block mt-0.5">Tamper-resistant enclave</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Device-to-Device NFC Simulator (5 cols) */}
        <div className="lg:col-span-5 bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-4">
          <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-800 pb-2">
            <Smartphone className="w-4 h-4 text-amber-400" />
            SIMULATE AIR-GAPPED NFC INTERCHANGE
          </h3>

          <form onSubmit={handleSimulateOfflineNfc} className="space-y-3 font-mono text-xs">
            <div>
              <label className="text-slate-400 text-[11px] block mb-1">ORIGINATOR SECURE WALLET</label>
              <select
                value={payerId}
                onChange={(e) => setPayerId(e.target.value)}
                className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
              >
                {wallets.map(w => (
                  <option key={w.id} value={w.id}>
                    {w.ownerName} (Offline Avail: {formatCurrency(w.offlineAvailable)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">RECIPIENT POS / DEVICE</label>
              <select
                value={payeeId}
                onChange={(e) => setPayeeId(e.target.value)}
                className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
              >
                {wallets.map(w => (
                  <option key={w.id} value={w.id}>
                    {w.ownerName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">PAYMENT AMOUNT (DUSD)</label>
              <input
                type="number"
                step="0.01"
                min="0.50"
                max="500.00"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(Number(e.target.value))}
                className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white font-bold"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Maximum offline cap: $500.00</span>
            </div>

            <div className="p-3 bg-[#050b16] border border-slate-800 rounded-xs space-y-1.5 text-[11px]">
              <div className="flex justify-between text-slate-300">
                <span>Silicon Counter:</span>
                <span className="text-white font-bold">#15 of 25</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Secure Element State:</span>
                <span className="text-emerald-400 font-bold">TAMPER_SEAL_VALID</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>NFC Radio Status:</span>
                <span className="text-amber-400 font-bold">PROXIMITY_PAIRING_OK</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
            >
              <ArrowRight className="w-4 h-4" />
              DISPATCH OFFLINE HARDWARE PAYMENT
            </button>
          </form>
        </div>

        {/* Queued Offline Vouchers Waiting For Central Reconciliation (7 cols) */}
        <div className="lg:col-span-7 bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider">
                QUEUED OFFLINE TRANSACTIONS ({offlineQueue.length})
              </h3>
              <span className="text-[11px] font-mono text-slate-400">
                Staged vouchers awaiting central ledger synchronization
              </span>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 bg-amber-950/60 text-amber-300 border border-amber-800 rounded-xs">
              PENDING RECONCILIATION
            </span>
          </div>

          <div className="space-y-2 max-h-[380px] overflow-y-auto">
            {offlineQueue.map((item: OfflinePaymentSimulation) => (
              <div key={item.id} className="p-3 bg-[#060c18] border border-slate-800 rounded-xs font-mono text-xs space-y-1.5">
                <div className="flex items-center justify-between font-bold">
                  <span className="text-white">{item.sourceDeviceId} &rarr; {item.targetDeviceId}</span>
                  <span className="text-amber-300 tabular-nums">{formatCurrency(item.amount)}</span>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px] text-slate-400 pt-1">
                  <div>
                    <span className="text-slate-500 block">HARDWARE COUNTER</span>
                    <span className="text-slate-200">#{item.offlineCounter}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">STATUS</span>
                    <span className={`font-semibold ${item.status === 'RECONCILED' ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {item.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">DOUBLE-SPEND CHECK</span>
                    <span className="text-emerald-400">ZERO_COLLISION</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">ENCLAVE ATTESTATION</span>
                    <span className="text-blue-300">PASS (CERT-OK)</span>
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 truncate pt-1 border-t border-slate-800/80">
                  Signature: <span className="text-slate-400">{item.hardwareSignature}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
