import React, { useState } from 'react';
import {
  Scale,
  BookOpen,
  Building,
  FileText,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Lock
} from 'lucide-react';

export const LegalView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'STATUTES' | 'CONGRESSIONAL_SCENARIOS' | 'GOVERNANCE'>('STATUTES');

  const statutes = [
    {
      citation: 'Federal Reserve Act § 16 (12 U.S.C. § 411)',
      title: 'Issuance of Federal Reserve Notes & Legal Tender Status',
      summary: 'Authorizes Federal Reserve notes for the purpose of making advances. Whether a digital central bank liability constitutes a "note" under § 16 remains a foundational statutory debate.',
      status: 'AMENDMENT REQUIRED FOR RETAIL',
      impact: 'Wholesale digital balances already exist in Master Accounts under § 13; retail general-purpose tokens would require explicit statutory modernization.'
    },
    {
      citation: 'Federal Reserve Act § 13(2) (12 U.S.C. § 342)',
      title: 'Deposits and Interbank Clearings',
      summary: 'Restricts direct Federal Reserve depository accounts strictly to depository institutions, U.S. Treasury, and designated financial market utilities.',
      status: 'INTERMEDIATED MANDATE',
      impact: 'Precludes the Federal Reserve from offering direct consumer checking accounts, legally necessitating the 2-Tier Intermediated Architecture.'
    },
    {
      citation: 'Right to Financial Privacy Act (RFPA) (12 U.S.C. § 3401 et seq.)',
      title: 'Customer Financial Record Protections Against Federal Access',
      summary: 'Prohibits federal government agencies from accessing individual customer financial records held by financial institutions without a warrant, subpoena, or statutory exception.',
      status: 'ACTIVE BINDING RESTRAINT',
      impact: 'Ensures the central bank cannot build a centralized surveillance database of citizen purchases without violating constitutional and statutory safeguards.'
    },
    {
      citation: 'Bank Secrecy Act (31 U.S.C. § 5311 et seq.) & USA PATRIOT Act',
      title: 'Anti-Money Laundering & Counter-Terrorist Financing (AML/CFT)',
      summary: 'Mandates customer identification (CIP/KYC), Currency Transaction Reporting (CTR) above $10,000, and Suspicious Activity Reports (SAR).',
      status: 'INTERMEDIARY ENFORCEMENT',
      impact: 'Commercial banks and wallet providers bear legal compliance liability, shielding the central core from retail compliance processing.'
    }
  ];

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Scale className="w-5 h-5 text-amber-400" />
              LEGAL, STATUTORY &amp; CONGRESSIONAL GOVERNANCE EXPLORER
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-amber-950/80 border border-amber-700/60 text-amber-300 rounded-xs font-semibold">
              FEDERAL RESERVE ACT JURISDICTION
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Statutory Authority Analysis • 12 U.S.C. Provisions • Congressional Authorization Scenarios
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 bg-[#0b1626] p-1 border border-slate-800 rounded-xs text-xs font-mono">
          <button
            onClick={() => setActiveTab('STATUTES')}
            className={`px-3 py-1 rounded-xs transition-colors font-semibold ${
              activeTab === 'STATUTES' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            STATUTORY MATRIX
          </button>
          <button
            onClick={() => setActiveTab('CONGRESSIONAL_SCENARIOS')}
            className={`px-3 py-1 rounded-xs transition-colors font-semibold ${
              activeTab === 'CONGRESSIONAL_SCENARIOS' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            CONGRESSIONAL SCENARIOS
          </button>
          <button
            onClick={() => setActiveTab('GOVERNANCE')}
            className={`px-3 py-1 rounded-xs transition-colors font-semibold ${
              activeTab === 'GOVERNANCE' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            GOVERNANCE CHARTERS
          </button>
        </div>
      </div>

      {activeTab === 'STATUTES' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-xs">
          {statutes.map((s, idx) => (
            <div key={idx} className="bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-2">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-amber-400 text-xs">{s.citation}</span>
                <span className="text-[9px] px-1.5 py-0.5 rounded-xs font-bold bg-amber-950 text-amber-300 border border-amber-800">
                  {s.status}
                </span>
              </div>
              <h3 className="font-bold text-white text-xs">{s.title}</h3>
              <p className="text-slate-300 text-[11px]">{s.summary}</p>
              <div className="pt-2 border-t border-slate-800/80 text-[10px] text-slate-400">
                Architectural Impact: <strong className="text-slate-200">{s.impact}</strong>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'CONGRESSIONAL_SCENARIOS' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-xs">
          <div className="bg-[#091322] border border-emerald-900/60 p-4 rounded-xs space-y-2">
            <div className="flex items-center justify-between text-emerald-400 font-bold">
              <span>SCENARIO A: EXPLICIT MANDATE</span>
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <h3 className="text-white font-bold text-xs">"Federal Reserve Digital Dollar Act"</h3>
            <p className="text-slate-300 text-[11px]">
              Congress passes statutory authorization explicitly granting the Board of Governors authority to issue digital legal tender through regulated financial intermediaries, with statutory consumer privacy covenants.
            </p>
            <div className="text-[10px] text-emerald-300 font-semibold pt-2 border-t border-slate-800">
              LEGAL FOUNDATION: ROBUST &amp; UNCONTESTED
            </div>
          </div>

          <div className="bg-[#091322] border border-blue-900/60 p-4 rounded-xs space-y-2">
            <div className="flex items-center justify-between text-cyan-400 font-bold">
              <span>SCENARIO B: WHOLESALE ONLY</span>
              <Building className="w-4 h-4" />
            </div>
            <h3 className="text-white font-bold text-xs">Existing Federal Reserve Act Powers</h3>
            <p className="text-slate-300 text-[11px]">
              The Fed implements wholesale tokenized settlement strictly between Master Account holding member banks under existing § 13 and § 16 authority without expanding into general retail circulation.
            </p>
            <div className="text-[10px] text-cyan-300 font-semibold pt-2 border-t border-slate-800">
              LEGAL FOUNDATION: SOUND ADMINISTRATIVE POWER
            </div>
          </div>

          <div className="bg-[#091322] border border-rose-900/60 p-4 rounded-xs space-y-2">
            <div className="flex items-center justify-between text-rose-400 font-bold">
              <span>SCENARIO C: PROHIBITORY BAN</span>
              <AlertTriangle className="w-4 h-4" />
            </div>
            <h3 className="text-white font-bold text-xs">Anti-CBDC Surveillance Statutes</h3>
            <p className="text-slate-300 text-[11px]">
              Legislation explicitly barring the Federal Reserve from testing, piloting, or deploying any retail CBDC. Private sector stablecoins and tokenized bank deposits fill payment modernization demand instead.
            </p>
            <div className="text-[10px] text-rose-300 font-semibold pt-2 border-t border-slate-800">
              LEGAL FOUNDATION: STATUTORILY PRECLUDED
            </div>
          </div>
        </div>
      )}

      {activeTab === 'GOVERNANCE' && (
        <div className="bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3 font-mono text-xs">
          <h3 className="font-bold text-white uppercase tracking-wider text-xs">
            FEDERAL RESERVE SYSTEM GOVERNANCE &amp; OVERSIGHT COMMITTTEE CHARTER
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 bg-[#060c18] border border-slate-800 rounded-xs space-y-1">
              <span className="font-bold text-white block">Board of Governors</span>
              <p className="text-slate-400 text-[11px]">Supervises systemic design rules, privacy policies, and Master Account eligibility criteria.</p>
            </div>
            <div className="p-3 bg-[#060c18] border border-slate-800 rounded-xs space-y-1">
              <span className="font-bold text-white block">Federal Open Market Committee (FOMC)</span>
              <p className="text-slate-400 text-[11px]">Sets remuneration rates (if authorized), balance sheet caps, and systemic liquidity injection parameters.</p>
            </div>
            <div className="p-3 bg-[#060c18] border border-slate-800 rounded-xs space-y-1">
              <span className="font-bold text-white block">Interagency Surveillance Council (FSOC)</span>
              <p className="text-slate-400 text-[11px]">Coordinates with OCC, FDIC, SEC, CFTC, and Treasury on bank deposit migration and run containment.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
