import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  TrendingUp,
  Sliders,
  Play,
  RotateCcw,
  Scale,
  Percent,
  CheckCircle2,
  AlertTriangle,
  Layers,
  ArrowRight
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';

export const MonetaryPolicyView: React.FC = () => {
  const { monetaryPolicy, updateMonetaryPolicy, applyScenario } = useSimulator();

  const [rate, setRate] = useState<number>(monetaryPolicy.policyRate);
  const [remunerationRate, setRemunerationRate] = useState<number>(monetaryPolicy.dusdRemunerationRate);
  const [holdingCap, setHoldingCap] = useState<number>(monetaryPolicy.holdingLimitIndividual);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleApplyPolicy = (e: React.FormEvent) => {
    e.preventDefault();
    updateMonetaryPolicy({
      policyRate: rate,
      interestOnReserveBalances: Number((rate + 0.15).toFixed(2)),
      overnightReverseRepoRate: Number((rate - 0.05).toFixed(2)),
      dusdRemunerationRate: remunerationRate,
      holdingLimitIndividual: holdingCap,
    });
    setFeedback(`Monetary Policy updated: Target FFR set to ${rate.toFixed(2)}%, DUSD Remuneration at ${remunerationRate.toFixed(2)}%, Individual Holding Limit set to ${formatCurrency(holdingCap)}.`);
    setTimeout(() => setFeedback(null), 5000);
  };

  // Sensitivity curve data: Remuneration Rate vs Bank Disintermediation Outflow
  const sensitivityData = [
    { dusdRate: '0.0%', outflowPct: 1.2, bankMargin: 3.10 },
    { dusdRate: '0.5%', outflowPct: 2.8, bankMargin: 2.95 },
    { dusdRate: '1.0%', outflowPct: 4.9, bankMargin: 2.80 },
    { dusdRate: '1.5%', outflowPct: 8.4, bankMargin: 2.55 },
    { dusdRate: '2.0%', outflowPct: 14.1, bankMargin: 2.20 },
    { dusdRate: '2.5%', outflowPct: 22.5, bankMargin: 1.85 },
    { dusdRate: '3.0%', outflowPct: 35.0, bankMargin: 1.40 },
  ];

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-400" />
              MONETARY POLICY SIMULATION ENGINE
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              MACRO TRANSMISSION
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Federal Funds Rate Corridors • Interest on DUSD • Bank Deposit Disintermediation Modeling
          </p>
        </div>
      </div>

      {feedback && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-600/70 text-emerald-200 text-xs font-mono rounded-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Primary Policy Corridors Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 font-mono text-xs">
        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs">
          <span className="text-slate-500 text-[10px] block">POLICY TARGET RATE</span>
          <span className="text-2xl font-bold text-white tabular-nums">{monetaryPolicy.policyRate.toFixed(2)}%</span>
          <span className="text-slate-400 text-[10px] block mt-0.5">Target Range: 4.25% - 4.50%</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs">
          <span className="text-slate-500 text-[10px] block">IORB RATE (RESERVES)</span>
          <span className="text-2xl font-bold text-cyan-400 tabular-nums">{monetaryPolicy.interestOnReserveBalances.toFixed(2)}%</span>
          <span className="text-slate-400 text-[10px] block mt-0.5">Interest on Reserve Balances</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs">
          <span className="text-slate-500 text-[10px] block">ON RRP RATE (FLOOR)</span>
          <span className="text-2xl font-bold text-amber-400 tabular-nums">{monetaryPolicy.overnightReverseRepoRate.toFixed(2)}%</span>
          <span className="text-slate-400 text-[10px] block mt-0.5">Overnight Reverse Repo</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs">
          <span className="text-slate-500 text-[10px] block">DUSD REMUNERATION</span>
          <span className="text-2xl font-bold text-emerald-400 tabular-nums">{monetaryPolicy.dusdRemunerationRate.toFixed(2)}%</span>
          <span className="text-slate-400 text-[10px] block mt-0.5">Zero-Yield Baseline Policy</span>
        </div>
      </div>

      {/* Main Interactive Controls & Transmission Curve */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Controls Form (5 cols) */}
        <div className="lg:col-span-5 bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-blue-400" />
              POLICY RATE &amp; DUSD ARCHITECTURE SLIDERS
            </h3>
          </div>

          <form onSubmit={handleApplyPolicy} className="space-y-4 font-mono text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Federal Funds Rate (Target)</span>
                <span className="font-bold text-white">{rate.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="8"
                step="0.25"
                value={rate}
                onChange={(e) => setRate(Number(e.target.value))}
                className="w-full accent-blue-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>DUSD Remuneration (CBDC Yield)</span>
                <span className="font-bold text-emerald-400">{remunerationRate.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="5"
                step="0.1"
                value={remunerationRate}
                onChange={(e) => setRemunerationRate(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Note: Interest-bearing CBDC significantly increases risk of commercial deposit disintermediation.
              </p>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Individual Holding Limit (Cap)</span>
                <span className="font-bold text-amber-300">{formatCurrency(holdingCap)}</span>
              </div>
              <input
                type="range"
                min="2500"
                max="100000"
                step="2500"
                value={holdingCap}
                onChange={(e) => setHoldingCap(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Holding caps prevent rapid flight from bank deposits during crisis episodes.
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Play className="w-4 h-4" />
              TRANSMIT MONETARY POLICY
            </button>
          </form>

          {/* Quick Scenario Buttons */}
          <div className="pt-2 border-t border-slate-800 space-y-2">
            <span className="text-slate-400 text-[10px] font-mono uppercase font-bold block">
              MACROECONOMIC STRESS SCENARIO PRESETS:
            </span>
            <div className="grid grid-cols-2 gap-1.5 font-mono text-[10px]">
              <button
                type="button"
                onClick={() => applyScenario('CBDC_RUN_SCENARIO')}
                className="p-2 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800 text-rose-200 rounded-xs text-left"
              >
                <strong>BANK RUN SCENARIO:</strong> 15% deposit flight to DUSD
              </button>
              <button
                type="button"
                onClick={() => applyScenario('BANKING_STRESS')}
                className="p-2 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-800 text-amber-200 rounded-xs text-left"
              >
                <strong>LIQUIDITY SHOCK:</strong> Interbank repo spread spike
              </button>
              <button
                type="button"
                onClick={() => applyScenario('HIGH_ADOPTION')}
                className="p-2 bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-800 text-cyan-200 rounded-xs text-left"
              >
                <strong>HIGH ADOPTION:</strong> $50B foreign DUSD demand
              </button>
              <button
                type="button"
                onClick={() => applyScenario('BASELINE')}
                className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-xs text-left"
              >
                <strong>RESET BASELINE:</strong> Normal economic conditions
              </button>
            </div>
          </div>
        </div>

        {/* Disintermediation Sensitivity Curve Chart (7 cols) */}
        <div className="lg:col-span-7 bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider">
                DEPOSIT DISINTERMEDIATION SENSITIVITY CURVE
              </h3>
              <p className="text-[11px] text-slate-400 font-mono">
                Projected retail deposit runoff vs. DUSD remuneration interest rate
              </p>
            </div>
            <span className="text-[10px] font-mono text-amber-400 border border-amber-800 bg-amber-950/40 px-2 py-0.5 rounded-xs">
              TAYLOR SENSITIVITY
            </span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sensitivityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="dusdRate" stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} label={{ value: 'DUSD Yield', position: 'insideBottomRight', offset: -5, fontSize: 10, fill: '#64748b' }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} unit="%" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#070f1e', borderColor: '#334155', fontSize: '11px', fontFamily: 'monospace' }}
                  itemStyle={{ color: '#e2e8f0' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Line type="monotone" dataKey="outflowPct" name="Commercial Deposit Outflow %" stroke="#f43f5e" strokeWidth={2} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="bankMargin" name="Bank Net Interest Margin (NIM %)" stroke="#38bdf8" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-[#050b16] p-3 border border-slate-800 rounded-xs text-xs font-mono text-slate-300 space-y-1">
            <div className="font-bold text-white uppercase text-[10px]">MONETARY TRANSMISSION FINDINGS:</div>
            <p className="text-[11px] text-slate-400">
              When DUSD pays 0.00% (non-interest-bearing), deposit migration remains strictly bounded to transactional liquidity demand (&lt;2%). However, offering even a 1.5% yield on central bank money would accelerate bank deposit outflows to 8.4%, compressing private bank lending capacity by ~12%.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
