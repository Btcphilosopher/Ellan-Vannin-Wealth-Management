import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  Users,
  Vote,
  FileText,
  Sliders,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  Scale
} from 'lucide-react';

interface FomcMember {
  id: string;
  role: string;
  stance: 'HAWKISH' | 'DOVISH' | 'NEUTRAL' | 'TECH_FOCUSED';
  recommendation: string;
  vote: 'APPROVE' | 'DISSENT' | 'ABSTAIN';
  statement: string;
}

export const FomcView: React.FC = () => {
  const { monetaryPolicy, updateMonetaryPolicy } = useSimulator();

  const [selectedHoldingCap, setSelectedHoldingCap] = useState<number>(monetaryPolicy.holdingLimitIndividual);
  const [selectedYield, setSelectedYield] = useState<number>(monetaryPolicy.dusdRemunerationRate);
  const [voteSubmitted, setVoteSubmitted] = useState<boolean>(false);

  const members: FomcMember[] = [
    {
      id: 'MEMBER_01',
      role: 'Board of Governors Member 01',
      stance: 'DOVISH',
      recommendation: 'Non-remunerated DUSD with $10,000 Cap',
      vote: 'APPROVE',
      statement: 'A zero-interest Digital Dollar preserves commercial bank lending while delivering high-speed inclusive payment access.',
    },
    {
      id: 'MEMBER_02',
      role: 'Reserve Bank President 02',
      stance: 'HAWKISH',
      recommendation: 'Strict $2,500 Cap to prevent deposit runs',
      vote: selectedHoldingCap <= 5000 ? 'APPROVE' : 'DISSENT',
      statement: 'Regional banks face severe balance-sheet contraction if retail depositors treat DUSD as a substitute for checking deposits.',
    },
    {
      id: 'MEMBER_03',
      role: 'Board of Governors Member 03',
      stance: 'TECH_FOCUSED',
      recommendation: 'Flexible $25,000 Tiered Threshold',
      vote: 'APPROVE',
      statement: 'Smart-contract programmability and instant settlement offer immense productivity gains for corporate supply chains.',
    },
    {
      id: 'STAFF_ECONOMIST',
      role: 'Division of Research & Statistics',
      stance: 'NEUTRAL',
      recommendation: 'Target zero yield; preserve monetary neutrality',
      vote: selectedYield === 0 ? 'APPROVE' : 'DISSENT',
      statement: 'Staff models estimate an elasticity of 0.85 between commercial deposits and CBDC yield differentials.',
    },
    {
      id: 'MARKETS_DESK',
      role: 'Open Market Desk (FRBNY)',
      stance: 'NEUTRAL',
      recommendation: 'Ensure ON RRP & IORB remain operational arbitrage anchors',
      vote: 'APPROVE',
      statement: 'Trading desks report seamless liquidity absorption under current SOMA operational framework.',
    },
    {
      id: 'FINANCIAL_STABILITY',
      role: 'Division of Financial Stability',
      stance: 'HAWKISH',
      recommendation: 'Tier-2 remuneration penalty on excess balances',
      vote: 'APPROVE',
      statement: 'Holding limits remain an indispensable macroprudential firewall during stress periods.',
    },
  ];

  const approvals = members.filter(m => m.vote === 'APPROVE').length;
  const dissents = members.filter(m => m.vote === 'DISSENT').length;

  const handleSimulateVote = () => {
    updateMonetaryPolicy({
      holdingLimitIndividual: selectedHoldingCap,
      dusdRemunerationRate: selectedYield,
    });
    setVoteSubmitted(true);
    setTimeout(() => setVoteSubmitted(false), 5000);
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-400" />
              FEDERAL OPEN MARKET COMMITTEE (FOMC) POLICY CONTROL ROOM
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              SIMULATED POLICY DELIBERATION
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Institutional CBDC Design Ballots • Quantitative Impact Projections • Macroprudential Consensus
          </p>
        </div>
      </div>

      {voteSubmitted && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-600/70 text-emerald-200 text-xs font-mono rounded-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>FOMC Policy Resolution adopted by {approvals}-{dissents} majority. SOMA Desk instructions dispatched.</span>
        </div>
      )}

      {/* Policy Proposal Dials */}
      <div className="bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-2 gap-2">
          <h3 className="text-xs font-bold font-mono text-white uppercase tracking-wider flex items-center gap-1.5">
            <Sliders className="w-4 h-4 text-blue-400" />
            PROPOSED DUSD MONETARY POLICY DIRECTIVE
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Current Outcome: <strong className="text-emerald-400">{approvals} AYES</strong> / <strong className="text-rose-400">{dissents} NOES</strong>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          <div>
            <label className="text-slate-400 text-[11px] block mb-1">INDIVIDUAL HOLDING CAP</label>
            <select
              value={selectedHoldingCap}
              onChange={(e) => setSelectedHoldingCap(Number(e.target.value))}
              className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white font-bold"
            >
              <option value="2500">$2,500 (Strict Run Prevention)</option>
              <option value="5000">$5,000 (Conservative Retail)</option>
              <option value="10000">$10,000 (Baseline Recommendation)</option>
              <option value="25000">$25,000 (Expanded Liquidity)</option>
              <option value="100000">$100,000 (Unconstrained Wholesale)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 text-[11px] block mb-1">REMUNERATION POLICY (YIELD)</label>
            <select
              value={selectedYield}
              onChange={(e) => setSelectedYield(Number(e.target.value))}
              className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white font-bold"
            >
              <option value="0">0.00% (Non-Remunerated Cash Equivalent)</option>
              <option value="1.0">1.00% (Sub-Policy Rate Pass-Through)</option>
              <option value="2.5">2.50% (Active Competition with Deposits)</option>
              <option value="4.33">4.33% (Full Fed Funds Rate Parity)</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleSimulateVote}
              className="w-full py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Vote className="w-3.5 h-3.5" />
              SIMULATE FOMC ROLL-CALL VOTE
            </button>
          </div>
        </div>
      </div>

      {/* FOMC Committee Member Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 font-mono text-xs">
        {members.map(member => (
          <div key={member.id} className="bg-[#0b1628] border border-slate-800 p-3.5 rounded-xs space-y-2">
            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
              <span className="font-bold text-white text-xs">{member.role}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-xs font-bold ${
                member.vote === 'APPROVE' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'
              }`}>
                {member.vote}
              </span>
            </div>

            <div className="text-[11px] text-blue-300 font-semibold">
              Policy Stance: {member.stance}
            </div>

            <div className="text-[11px] text-slate-300 italic bg-[#060c18] p-2 border border-slate-800 rounded-xs">
              "{member.statement}"
            </div>

            <div className="text-[10px] text-slate-500 pt-1">
              Preferred Target: <span className="text-slate-300">{member.recommendation}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
