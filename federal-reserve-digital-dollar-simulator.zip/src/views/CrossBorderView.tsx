import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  Globe2,
  ArrowRightLeft,
  CheckCircle2,
  AlertTriangle,
  Play,
  ShieldCheck,
  Building,
  RefreshCw,
  Scale
} from 'lucide-react';
import { CrossBorderCorridor } from '../types';

export const CrossBorderView: React.FC = () => {
  const { crossBorderCorridors, wallets, executeCustomTransaction } = useSimulator();

  const [selectedCorridorId, setSelectedCorridorId] = useState<string>(crossBorderCorridors[0]?.id || 'CORRIDOR-USD-JPY');
  const [usdTransferAmount, setUsdTransferAmount] = useState<number>(10000000); // $10M USD default -> ~1.55B JPY
  const [importerWalletId, setImporterWalletId] = useState<string>(wallets[0]?.id || 'WLT-JC-7419');
  const [foreignSupplierName, setForeignSupplierName] = useState<string>('Tokyo Industrial Electronics Corp.');
  const [feedback, setFeedback] = useState<string | null>(null);

  const activeCorridor = crossBorderCorridors.find(c => c.id === selectedCorridorId) || crossBorderCorridors[0];
  const convertedForeignAmount = activeCorridor ? usdTransferAmount * activeCorridor.exchangeRate : 0;

  const handleExecuteAtomicPvp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCorridor) return;
    try {
      await executeCustomTransaction({
        originator: importerWalletId,
        beneficiary: `SWIFT-${activeCorridor.foreignCentralBank.slice(0, 8)}`,
        intermediaryId: 'BNK-JPMC-01',
        amount: usdTransferAmount,
        assetType: 'DUSD',
        settlementRail: 'CROSS_BORDER_MCBDC',
        privacyLevel: 'TIER_3_REGISTERED',
        priority: 'HIGH',
        memo: `PvP Atomic Settlement: ${activeCorridor.partnerCbdcName} for ${foreignSupplierName}`
      });
      setFeedback(`Atomic PvP Settlement Finalized: ${formatCurrency(usdTransferAmount)} DUSD converted to ${convertedForeignAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })} ${activeCorridor.partnerCurrency} via ${activeCorridor.foreignCentralBank}. Herstatt settlement risk eliminated.`);
      setTimeout(() => setFeedback(null), 6000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Globe2 className="w-5 h-5 text-blue-400" />
              CROSS-BORDER MULTI-CBDC (mCBDC) ATOMIC PVP CORRIDOR
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              HERSTATT RISK ELIMINATION
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Interlinked Sovereign Central Bank Corridors • Synchronized Payment-versus-Payment • Real-Time FX Liquidity
          </p>
        </div>
      </div>

      {feedback && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-600/70 text-emerald-200 text-xs font-mono rounded-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Grid of Active FX Corridors */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 font-mono text-xs">
        {crossBorderCorridors.map(c => {
          const isSelected = c.id === activeCorridor?.id;
          return (
            <div
              key={c.id}
              onClick={() => setSelectedCorridorId(c.id)}
              className={`p-3 rounded-xs border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#0f223f] border-blue-500 shadow-md ring-1 ring-blue-500/50'
                  : 'bg-[#091322] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-xs">USD / {c.partnerCurrency}</span>
                <span className="text-[9px] px-1.5 py-0.2 bg-slate-800 rounded-xs text-emerald-400">
                  {c.status.replace(/_/g, ' ')}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 mt-1 font-semibold">
                1 USD = {c.exchangeRate.toFixed(4)} {c.partnerCurrency}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5 truncate" title={c.foreignCentralBank}>
                {c.foreignCentralBank}
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Interactive Atomic PvP Execution Lab */}
      {activeCorridor && (
        <div className="bg-[#0b1628] border border-slate-800 p-4 rounded-xs space-y-4 font-mono text-xs">
          <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>Bilateral Corridor: USD / {activeCorridor.partnerCurrency}</span>
                <span className="text-xs text-cyan-400 bg-cyan-950 px-2 py-0.5 border border-cyan-800 rounded-xs">
                  {activeCorridor.foreignCentralBank}
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Available Corridor Liquidity Pool: <strong className="text-white">{formatCurrency(activeCorridor.liquidityPoolDusd)}</strong>
              </p>
            </div>
          </div>

          {/* Execution Form & Two-Leg Visualization */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Form (5 cols) */}
            <form onSubmit={handleExecuteAtomicPvp} className="lg:col-span-5 space-y-3">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">ORIGINATING U.S. IMPORTER WALLET</label>
                <select
                  value={importerWalletId}
                  onChange={(e) => setImporterWalletId(e.target.value)}
                  className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
                >
                  {wallets.map(w => (
                    <option key={w.id} value={w.id}>
                      {w.ownerName} (DUSD: {formatCurrency(w.dusdBalance, { compact: true })})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">RECIPIENT FOREIGN SUPPLIER</label>
                <input
                  type="text"
                  value={foreignSupplierName}
                  onChange={(e) => setForeignSupplierName(e.target.value)}
                  className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">SETTLEMENT AMOUNT (USD)</label>
                <input
                  type="number"
                  min="10000"
                  step="100000"
                  value={usdTransferAmount}
                  onChange={(e) => setUsdTransferAmount(Number(e.target.value))}
                  className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white font-bold"
                />
              </div>

              <div className="p-2.5 bg-[#050c18] border border-slate-800 rounded-xs space-y-1 text-[11px]">
                <div className="text-slate-400 font-semibold uppercase text-[10px]">PvP Conversion Calculation:</div>
                <div className="flex justify-between text-slate-300">
                  <span>Debit U.S. DUSD:</span>
                  <span className="text-rose-400 font-bold">-{formatCurrency(usdTransferAmount)}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Credit {activeCorridor.partnerCurrency}:</span>
                  <span className="text-emerald-400 font-bold">
                    +{convertedForeignAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })} {activeCorridor.partnerCurrency}
                  </span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Play className="w-4 h-4" />
                DISPATCH SYNCHRONIZED ATOMIC PVP SETTLEMENT
              </button>
            </form>

            {/* Atomic Diagram & Herstatt Risk Proof (7 cols) */}
            <div className="lg:col-span-7 bg-[#060c18] border border-slate-800 p-3.5 rounded-xs space-y-3">
              <div className="text-[10px] font-bold text-slate-400 uppercase">
                SYNCHRONIZED CENTRAL-BANK HASH-TIME-LOCKED (HTLC) INTERLINK:
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-2.5 bg-[#091424] border border-blue-900/60 rounded-xs">
                  <span className="text-[10px] text-blue-400 block font-bold">LEG 1: FEDERAL RESERVE DUSD</span>
                  <span className="text-sm font-bold text-white">{formatCurrency(usdTransferAmount)}</span>
                  <span className="text-[10px] text-slate-400 block mt-1">U.S. Core RTGS Debit</span>
                </div>

                <div className="p-2.5 bg-[#091424] border border-emerald-900/60 rounded-xs">
                  <span className="text-[10px] text-emerald-400 block font-bold">LEG 2: {activeCorridor.foreignCentralBank}</span>
                  <span className="text-sm font-bold text-white">
                    {convertedForeignAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })} {activeCorridor.partnerCurrency}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-1">Foreign RTGS Simultaneous Credit</span>
                </div>
              </div>

              <div className="p-3 bg-[#050b16] border border-slate-800 rounded-xs text-[11px] text-slate-300 space-y-1">
                <div className="text-emerald-400 font-bold uppercase text-[10px] flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  HERSTATT SETTLEMENT RISK ELIMINATED
                </div>
                <p className="text-slate-400">
                  In legacy correspondent banking, time-zone differences force one leg to settle hours before the other, exposing institutions to default risk. Under this synchronized mCBDC protocol, both central-bank ledgers commit atomically. If either leg fails, the entire transaction reverts.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
