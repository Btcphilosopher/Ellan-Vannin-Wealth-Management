import React, { useState } from 'react';
import {
  Zap,
  Building,
  Wallet,
  ArrowRight,
  CheckCircle2,
  Scale,
  ShieldCheck,
  DollarSign,
  Clock,
  Layers
} from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

export const FedNowView: React.FC = () => {
  const [testAmount, setTestAmount] = useState<number>(100);
  const [activeStep, setActiveStep] = useState<number>(3); // 3: Complete

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              FEDNOW &amp; DIGITAL DOLLAR INTEROPERABILITY LAB
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              COMPLEMENTARY INFRASTRUCTURE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Interbank Deposit Movement vs. Direct Sovereign Central-Bank Digital Currency Settlement
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400 text-[11px]">SCENARIO AMOUNT:</span>
          <div className="flex items-center gap-1">
            {[25, 100, 500, 2500].map(amt => (
              <button
                key={amt}
                onClick={() => setTestAmount(amt)}
                className={`px-2 py-0.5 rounded-xs font-bold ${
                  testAmount === amt ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                ${amt}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Side-by-Side Institutional Comparison Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Flow 1: FedNow Instant Payment Service */}
        <div className="bg-[#091322] border border-amber-900/40 p-4 rounded-xs space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <span className="text-[10px] font-mono text-amber-400 font-bold tracking-wider uppercase block">
                FLOW 1: COMMERCIAL BANK RAIL
              </span>
              <h3 className="text-sm font-bold text-white font-mono">
                FedNow Service (Interbank Deposit Settlement)
              </h3>
            </div>
            <span className="text-[10px] font-mono bg-amber-950/60 text-amber-300 border border-amber-800 px-2 py-0.5 rounded-xs">
              COMMERCIAL LIABILITIES
            </span>
          </div>

          {/* Graphical Step Flow */}
          <div className="bg-[#060c18] p-3 rounded-xs border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Building className="w-4 h-4 text-slate-400" />
                <span className="text-slate-200">Bank A Customer Account</span>
              </div>
              <span className="text-rose-400 font-bold">-{formatCurrency(testAmount)}</span>
            </div>

            <div className="flex items-center justify-center text-slate-500 gap-1 text-[11px]">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span>FedNow Message Routing &amp; Reserve Debit</span>
              <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
            </div>

            <div className="flex items-center justify-between bg-slate-900/60 p-2 rounded-xs border border-slate-800">
              <span className="text-slate-400">Fed Reserve Master Accounts</span>
              <span className="text-amber-300 font-semibold">Bank A Reserve ↓ / Bank B Reserve ↑</span>
            </div>

            <div className="flex items-center justify-center text-slate-500 gap-1 text-[11px]">
              <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
              <span>Credit Confirmation Callback</span>
              <span className="w-2 h-2 rounded-full bg-amber-400" />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Building className="w-4 h-4 text-slate-400" />
                <span className="text-slate-200">Bank B Merchant Account</span>
              </div>
              <span className="text-emerald-400 font-bold">+{formatCurrency(testAmount)}</span>
            </div>
          </div>

          {/* Specs */}
          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between py-1 border-b border-slate-800 text-slate-300">
              <span className="text-slate-500">SETTLEMENT ASSET:</span>
              <span className="font-semibold text-white">Commercial Bank Deposit Claim</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800 text-slate-300">
              <span className="text-slate-500">SETTLEMENT TIME:</span>
              <span className="font-semibold text-amber-300">1.8 - 3.2 seconds</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800 text-slate-300">
              <span className="text-slate-500">TRANSACTION FEE:</span>
              <span className="font-semibold text-slate-200">$0.045 per transfer to bank</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800 text-slate-300">
              <span className="text-slate-500">OPERATING MODEL:</span>
              <span className="font-semibold text-slate-200">Interbank Clearing Rail</span>
            </div>
            <div className="flex justify-between py-1 text-slate-300">
              <span className="text-slate-500">COUNTERPARTY RISK:</span>
              <span className="font-semibold text-slate-200">Commercial Bank Solvency (FDIC $250k)</span>
            </div>
          </div>
        </div>

        {/* Flow 2: Federal Reserve Digital Dollar Core */}
        <div className="bg-[#091322] border border-blue-900/40 p-4 rounded-xs space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <span className="text-[10px] font-mono text-blue-400 font-bold tracking-wider uppercase block">
                FLOW 2: CENTRAL BANK SOVEREIGN RAIL
              </span>
              <h3 className="text-sm font-bold text-white font-mono">
                Federal Reserve Digital Dollar Core (DUSD)
              </h3>
            </div>
            <span className="text-[10px] font-mono bg-blue-950/60 text-blue-300 border border-blue-800 px-2 py-0.5 rounded-xs">
              CENTRAL BANK LIABILITIES
            </span>
          </div>

          {/* Graphical Step Flow */}
          <div className="bg-[#060c18] p-3 rounded-xs border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-blue-400" />
                <span className="text-slate-200">Customer DUSD Wallet</span>
              </div>
              <span className="text-rose-400 font-bold">-{formatCurrency(testAmount)}</span>
            </div>

            <div className="flex items-center justify-center text-slate-500 gap-1 text-[11px]">
              <span className="w-2 h-2 rounded-full bg-blue-400" />
              <span>Direct PBFT Core Ledger Transfer</span>
              <ArrowRight className="w-3.5 h-3.5 text-blue-400" />
            </div>

            <div className="flex items-center justify-between bg-blue-950/30 p-2 rounded-xs border border-blue-800/60">
              <span className="text-blue-300">Fed DUSD Central Ledger</span>
              <span className="text-emerald-400 font-semibold">Atomic Direct Liability Reassignment</span>
            </div>

            <div className="flex items-center justify-center text-slate-500 gap-1 text-[11px]">
              <ArrowRight className="w-3.5 h-3.5 text-blue-400" />
              <span>Cryptographic Receipt Finality</span>
              <span className="w-2 h-2 rounded-full bg-blue-400" />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-emerald-400" />
                <span className="text-slate-200">Merchant DUSD Wallet</span>
              </div>
              <span className="text-emerald-400 font-bold">+{formatCurrency(testAmount)}</span>
            </div>
          </div>

          {/* Specs */}
          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between py-1 border-b border-slate-800 text-slate-300">
              <span className="text-slate-500">SETTLEMENT ASSET:</span>
              <span className="font-semibold text-emerald-400">Direct Federal Reserve Liability</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800 text-slate-300">
              <span className="text-slate-500">SETTLEMENT TIME:</span>
              <span className="font-semibold text-emerald-400">0.42 seconds (Atomic)</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800 text-slate-300">
              <span className="text-slate-500">TRANSACTION FEE:</span>
              <span className="font-semibold text-slate-200">$0.0001 (Zero Interchange)</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-800 text-slate-300">
              <span className="text-slate-500">OPERATING MODEL:</span>
              <span className="font-semibold text-slate-200">Sovereign Central Bank Money</span>
            </div>
            <div className="flex justify-between py-1 text-slate-300">
              <span className="text-slate-500">COUNTERPARTY RISK:</span>
              <span className="font-semibold text-emerald-400">Zero (Full Faith &amp; Credit of the U.S.)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Institutional Synthesis: Why Both Coexist */}
      <div className="bg-[#091322] border border-slate-800 p-4 rounded-xs text-xs font-mono space-y-2 text-slate-300">
        <h4 className="font-bold text-white uppercase flex items-center gap-2 text-sm">
          <Scale className="w-4 h-4 text-blue-400" />
          COEXISTENCE SYNERGY: THE U.S. PAYMENTS MOSAIC
        </h4>
        <p>
          FedNow operates as an advanced interbank gross settlement service for <strong>commercial bank deposits</strong>, ensuring that private banks can offer instant 24/7 retail payments while retaining customer credit relationships and fractional-reserve deposit bases.
        </p>
        <p>
          A hypothetical Digital Dollar acts as a <strong>third form of sovereign legal tender</strong> (complementing cash and reserves). It provides universal programmability, offline capability, zero-counterparty settlement, and international interoperability without crowding out the competitive commercial banking sector.
        </p>
      </div>
    </div>
  );
};
