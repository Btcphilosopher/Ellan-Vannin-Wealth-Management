import React, { useState, useMemo } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency, formatShortHash } from '../utils/formatters';
import {
  BookOpen,
  Filter,
  Search,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Shield,
  Layers,
  Database,
  Hash,
  Download,
  Info
} from 'lucide-react';
import { LedgerTransaction, SettlementRail, PrivacyLevel, TransactionStatus } from '../types';

export const LedgerView: React.FC = () => {
  const {
    transactions,
    blockHeight,
    transactionsPerSec,
    exportSimulationState,
  } = useSimulator();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterRail, setFilterRail] = useState<string>('ALL');
  const [filterPrivacy, setFilterPrivacy] = useState<string>('ALL');
  const [selectedTx, setSelectedTx] = useState<LedgerTransaction | null>(null);
  const [rollbackSuccessId, setRollbackSuccessId] = useState<string | null>(null);

  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => {
      const matchesSearch = 
        tx.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.originatorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.beneficiaryName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.intermediaryName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.auditHash.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesRail = filterRail === 'ALL' || tx.settlementRail === filterRail;
      const matchesPrivacy = filterPrivacy === 'ALL' || tx.privacyClass === filterPrivacy;

      return matchesSearch && matchesRail && matchesPrivacy;
    });
  }, [transactions, searchQuery, filterRail, filterPrivacy]);

  const handleSimulateRollback = (tx: LedgerTransaction) => {
    setRollbackSuccessId(tx.id);
    setTimeout(() => setRollbackSuccessId(null), 4000);
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-400" />
              FEDERAL RESERVE CENTRAL DIGITAL DOLLAR LEDGER
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              RTGS CORE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Enterprise Settlement Infrastructure • High-Throughput Central Bank Ledger • Transaction Finality Engine
          </p>
        </div>

        <button
          onClick={() => exportSimulationState('csv')}
          className="flex items-center gap-1.5 text-xs font-mono bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 border border-slate-700 rounded-xs transition-colors"
        >
          <Download className="w-3.5 h-3.5" />
          EXPORT LEDGER CSV
        </button>
      </div>

      {/* Required Telemetry Status Bar: LEDGER HEIGHT, TPS, FINALITY LATENCY, VALIDATION QUEUE, FAILED TXS, RECONCILIATION */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-xs font-mono">
        <div className="bg-[#091322] border border-slate-800 p-2.5 rounded-xs">
          <span className="text-slate-400 text-[10px] block">LEDGER HEIGHT</span>
          <span className="text-white font-bold text-base tabular-nums">#{blockHeight.toLocaleString()}</span>
        </div>
        <div className="bg-[#091322] border border-slate-800 p-2.5 rounded-xs">
          <span className="text-slate-400 text-[10px] block">TRANSACTIONS / SEC</span>
          <span className="text-cyan-400 font-bold text-base tabular-nums">{transactionsPerSec.toLocaleString()}</span>
        </div>
        <div className="bg-[#091322] border border-slate-800 p-2.5 rounded-xs">
          <span className="text-slate-400 text-[10px] block">FINALITY LATENCY</span>
          <span className="text-emerald-400 font-bold text-base">0.42 sec</span>
        </div>
        <div className="bg-[#091322] border border-slate-800 p-2.5 rounded-xs">
          <span className="text-slate-400 text-[10px] block">VALIDATION QUEUE</span>
          <span className="text-amber-400 font-bold text-base">1,420 TXs</span>
        </div>
        <div className="bg-[#091322] border border-slate-800 p-2.5 rounded-xs">
          <span className="text-slate-400 text-[10px] block">FAILED TRANSACTIONS</span>
          <span className="text-slate-300 font-bold text-base">0.0004%</span>
        </div>
        <div className="bg-[#091322] border border-slate-800 p-2.5 rounded-xs">
          <span className="text-slate-400 text-[10px] block">RECONCILIATION</span>
          <span className="text-emerald-400 font-bold text-base">100% VERIFIED</span>
        </div>
      </div>

      {rollbackSuccessId && (
        <div className="p-3 bg-amber-950/60 border border-amber-600/70 text-amber-200 text-xs font-mono rounded-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Simulated Compensating Reversal Voucher generated for {rollbackSuccessId}. Symmetrical double-entry reversal confirmed on Block #{blockHeight + 1}.</span>
        </div>
      )}

      {/* Filter and Search Controls */}
      <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
        <div className="flex-1 min-w-[240px] relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-2.5 top-2.5" />
          <input
            type="text"
            placeholder="Search by Tx ID, Originator, Beneficiary, Intermediary, or Hash..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#050b16] border border-slate-700 pl-8 pr-3 py-1.5 text-slate-200 rounded-xs focus:outline-hidden focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-400 text-[11px] flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            RAIL:
          </span>
          <select
            value={filterRail}
            onChange={(e) => setFilterRail(e.target.value)}
            className="bg-[#050b16] border border-slate-700 text-slate-300 px-2 py-1 rounded-xs"
          >
            <option value="ALL">All Rails</option>
            <option value="DUSD_CORE_LEDGER">DUSD Core</option>
            <option value="FEDWIRE_FUNDS">Fedwire</option>
            <option value="FEDNOW_SERVICE">FedNow</option>
            <option value="TREASURY_DIRECT_RAIL">Treasury Direct</option>
            <option value="CROSS_BORDER_MCBDC">Cross-Border</option>
          </select>

          <span className="text-slate-400 text-[11px] ml-2">PRIVACY:</span>
          <select
            value={filterPrivacy}
            onChange={(e) => setFilterPrivacy(e.target.value)}
            className="bg-[#050b16] border border-slate-700 text-slate-300 px-2 py-1 rounded-xs"
          >
            <option value="ALL">All Tiers</option>
            <option value="TIER_1_ANONYMOUS">Tier 1 Anonymous (&lt;$200)</option>
            <option value="TIER_2_INTERMEDIATED">Tier 2 Intermediated</option>
            <option value="TIER_3_REGISTERED">Tier 3 Registered</option>
          </select>
        </div>
      </div>

      {/* Main Ledger Table */}
      <div className="bg-[#091322] border border-slate-800 rounded-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#060c18] border-b border-slate-800 text-[10px] text-slate-400 uppercase tracking-wider">
              <tr>
                <th className="py-2 px-2.5">TX ID</th>
                <th className="py-2 px-2.5">TIMESTAMP</th>
                <th className="py-2 px-2.5">ORIGINATOR</th>
                <th className="py-2 px-2.5">INTERMEDIARY</th>
                <th className="py-2 px-2.5">BENEFICIARY</th>
                <th className="py-2 px-2.5 text-right">AMOUNT (DUSD)</th>
                <th className="py-2 px-2.5">ASSET TYPE</th>
                <th className="py-2 px-2.5">RAIL</th>
                <th className="py-2 px-2.5">PRIVACY</th>
                <th className="py-2 px-2.5">COMPLIANCE</th>
                <th className="py-2 px-2.5">BATCH/BLOCK</th>
                <th className="py-2 px-2.5 text-center">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {filteredTransactions.map((tx) => (
                <tr 
                  key={tx.id} 
                  className={`hover:bg-slate-800/50 transition-colors cursor-pointer ${
                    selectedTx?.id === tx.id ? 'bg-blue-950/40 border-l-2 border-blue-500' : ''
                  }`}
                  onClick={() => setSelectedTx(tx)}
                >
                  <td className="py-2 px-2.5 text-blue-400 font-bold whitespace-nowrap">{tx.id}</td>
                  <td className="py-2 px-2.5 text-slate-400 whitespace-nowrap">{tx.timestamp.slice(11, 19)}</td>
                  <td className="py-2 px-2.5 text-slate-200 font-medium truncate max-w-[130px]" title={tx.originatorName}>
                    {tx.originatorName}
                  </td>
                  <td className="py-2 px-2.5 text-slate-300 truncate max-w-[120px]" title={tx.intermediaryName}>
                    {tx.intermediaryName}
                  </td>
                  <td className="py-2 px-2.5 text-slate-200 font-medium truncate max-w-[130px]" title={tx.beneficiaryName}>
                    {tx.beneficiaryName}
                  </td>
                  <td className="py-2 px-2.5 text-right font-bold text-white tabular-nums whitespace-nowrap">
                    {formatCurrency(tx.amount)}
                  </td>
                  <td className="py-2 px-2.5 whitespace-nowrap">
                    <span className="text-[10px] text-slate-400">{tx.assetType}</span>
                  </td>
                  <td className="py-2 px-2.5 whitespace-nowrap">
                    <span className="text-[9px] px-1.5 py-0.2 bg-slate-800 border border-slate-700 text-slate-300 rounded-xs">
                      {tx.settlementRail.replace('_SERVICE', '').replace('_NETWORK', '')}
                    </span>
                  </td>
                  <td className="py-2 px-2.5 whitespace-nowrap">
                    <span className="text-[9px] px-1.5 py-0.2 bg-blue-950/50 border border-blue-800/60 text-blue-300 rounded-xs">
                      {tx.privacyClass.replace('TIER_', 'T')}
                    </span>
                  </td>
                  <td className="py-2 px-2.5 whitespace-nowrap">
                    <span className="text-[9px] px-1.5 py-0.2 bg-emerald-950/60 border border-emerald-800 text-emerald-300 rounded-xs">
                      {tx.complianceFlag || 'CLEARED'}
                    </span>
                  </td>
                  <td className="py-2 px-2.5 text-slate-400 whitespace-nowrap">#{tx.blockHeight}</td>
                  <td className="py-2 px-2.5 text-center whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => handleSimulateRollback(tx)}
                      className="px-2 py-0.5 bg-amber-950/50 hover:bg-amber-900/60 text-amber-300 border border-amber-700/60 rounded-xs text-[10px] flex items-center gap-1 mx-auto"
                      title="Simulate compensatory reversal"
                    >
                      <RotateCcw className="w-2.5 h-2.5" />
                      REVERSAL
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drill-down Transaction Detail Modal / Drawer */}
      {selectedTx && (
        <div className="bg-[#060c18] border border-blue-900/60 p-4 rounded-xs text-xs font-mono space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <Hash className="w-4 h-4 text-blue-400" />
              <span className="text-white font-bold">TRANSACTION DEEP AUDIT RECORD: {selectedTx.id}</span>
            </div>
            <button
              onClick={() => setSelectedTx(null)}
              className="text-slate-400 hover:text-white px-2 py-0.5 bg-slate-800 rounded-xs"
            >
              CLOSE
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <span className="text-slate-500 text-[10px] block">ORIGINATOR ID</span>
              <span className="text-slate-200">{selectedTx.originator}</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block">BENEFICIARY ID</span>
              <span className="text-slate-200">{selectedTx.beneficiary}</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block">SETTLEMENT LATENCY</span>
              <span className="text-emerald-400">{selectedTx.latencyMs} ms</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block">FINALITY STATUS</span>
              <span className="text-emerald-400 font-bold">{selectedTx.status} (IMMEDIATE)</span>
            </div>
            <div className="md:col-span-2">
              <span className="text-slate-500 text-[10px] block">CRYPTOGRAPHIC AUDIT HASH</span>
              <span className="text-blue-300 font-mono text-[11px] break-all">{selectedTx.auditHash}</span>
            </div>
            <div className="md:col-span-2">
              <span className="text-slate-500 text-[10px] block">ED25519 INTERMEDIARY SIGNATURE</span>
              <span className="text-slate-300 font-mono text-[11px] break-all">{selectedTx.signature}</span>
            </div>
            {selectedTx.memo && (
              <div className="md:col-span-4 bg-[#0a1424] p-2 border border-slate-800 rounded-xs">
                <span className="text-slate-500 text-[10px] block">PAYMENT MEMO / ISO 20022 REMITTANCE DATA</span>
                <span className="text-slate-200">{selectedTx.memo}</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
