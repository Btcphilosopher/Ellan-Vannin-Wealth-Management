import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  Cpu,
  Zap,
  Clock,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Activity,
  Layers,
  ShieldCheck,
  Play
} from 'lucide-react';
import { SettlementRail } from '../types';

interface RailSpec {
  rail: SettlementRail;
  name: string;
  type: string;
  latency: string;
  finality: string;
  cost: string;
  availability: string;
  counterpartyRisk: string;
  liquidityReq: string;
  failureRate: string;
  settlementMechanism: string;
  interoperability: string;
}

export const SettlementRailsView: React.FC = () => {
  const { executeCustomTransaction, wallets } = useSimulator();

  const [selectedRail, setSelectedRail] = useState<SettlementRail>('DUSD_CORE_LEDGER');
  const [testAmount, setTestAmount] = useState<number>(1000);
  const [simStatus, setSimStatus] = useState<string | null>(null);

  const rails: RailSpec[] = [
    {
      rail: 'DUSD_CORE_LEDGER',
      name: 'Digital Dollar Core RTGS',
      type: 'Central Bank Digital Currency',
      latency: '0.42 seconds',
      finality: 'Immediate Atomic Finality',
      cost: '$0.0001 (Zero Interchange)',
      availability: '24/7/365 Continuous',
      counterpartyRisk: 'None (Direct Central Bank Liability)',
      liquidityReq: '100% Pre-funded Central Bank Money',
      failureRate: '0.0004%',
      settlementMechanism: 'Direct PBFT Central Ledger Transfer',
      interoperability: 'Native ISO 20022 Multi-Rail Bridge',
    },
    {
      rail: 'FEDNOW_SERVICE',
      name: 'FedNow Instant Payment Service',
      type: 'Instant Commercial Bank Rail',
      latency: '2.8 seconds',
      finality: 'Immediate Gross Settlement',
      cost: '$0.045 per transfer',
      availability: '24/7/365 Continuous',
      counterpartyRisk: 'Commercial Bank Reserve Settlement',
      liquidityReq: 'Pre-funded Master Account Sub-account',
      failureRate: '0.012%',
      settlementMechanism: 'Interbank Reserve Movement at Fed',
      interoperability: 'Full ISO 20022 Intermediated',
    },
    {
      rail: 'FEDWIRE_FUNDS',
      name: 'Fedwire Funds Service',
      type: 'Wholesale High-Value RTGS',
      latency: '15 - 45 seconds',
      finality: 'Irrevocable Real-Time Gross',
      cost: '$0.82 tiered fee',
      availability: 'Mon-Fri 21.5 hrs/day (Operating Window)',
      counterpartyRisk: 'None (Fed Master Account)',
      liquidityReq: 'High Intraday Credit / Reserves',
      failureRate: '0.002%',
      settlementMechanism: 'Gross Debit/Credit Reserve Accounts',
      interoperability: 'ISO 20022 Fedwire Format',
    },
    {
      rail: 'ACH_NETWORK',
      name: 'Automated Clearing House (ACH)',
      type: 'Batch Net Settlement',
      latency: '1 - 3 Business Days (Same-Day ACH 4h)',
      finality: 'Deferred Net Settlement (Revocable up to 60d)',
      cost: '$0.25 - $0.50',
      availability: 'Banking Days, Batch Windows',
      counterpartyRisk: 'High (Float & Settlement Failure)',
      liquidityReq: 'Net Settling Position Collateral',
      failureRate: '1.45% (NSF / Returns)',
      settlementMechanism: 'Multilateral Netting at Clearing House',
      interoperability: 'NACHA Standard',
    },
    {
      rail: 'CARD_NETWORK_ADAPTER',
      name: 'Legacy Card Networks (Visa/Mastercard)',
      type: 'Four-Party Retail Credit/Debit',
      latency: 'Authorization 1.5s / Settlement 2-3 Days',
      finality: 'Provisional (Chargebacks up to 120d)',
      cost: '1.5% - 3.2% + $0.10 Interchange',
      availability: '24/7 Gateway / Batch Settlement',
      counterpartyRisk: 'Acquiring / Issuing Bank Credit Risk',
      liquidityReq: 'Interchange Settlement Accounts',
      failureRate: '2.1% (Declines / Fraud)',
      settlementMechanism: 'Bilateral Netting via Sponsor Banks',
      interoperability: 'ISO 8583 Proprietary Network',
    },
  ];

  const currentRail = rails.find(r => r.rail === selectedRail) || rails[0];

  const handleRunRailTest = async () => {
    setSimStatus(`Initiating test transaction on ${currentRail.name}...`);
    try {
      await executeCustomTransaction({
        originator: wallets[0]?.id || 'WLT-JC-7419',
        beneficiary: wallets[1]?.id || 'WLT-MERCHANT-WHOLEFOODS',
        intermediaryId: wallets[0]?.intermediaryId || 'BANK-LNB',
        amount: testAmount,
        assetType: 'DUSD',
        settlementRail: currentRail.rail,
        privacyLevel: 'TIER_2_INTERMEDIATED',
        priority: 'NORMAL',
        memo: `Synthetic Benchmark Test across ${currentRail.name}`,
      });
      setSimStatus(`Settled ${formatCurrency(testAmount)} via ${currentRail.name} with ${currentRail.latency} latency and finality: ${currentRail.finality}.`);
      setTimeout(() => setSimStatus(null), 5000);
    } catch (err: any) {
      setSimStatus(`Error: ${err.message}`);
    }
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Cpu className="w-5 h-5 text-blue-400" />
              PAYMENT RAILS &amp; SETTLEMENT SYSTEM SIMULATOR
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              MULTI-RAIL BENCHMARK
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Compare Settlement Latency, Finality Windows, Counterparty Exposure, and Interchange Costs
          </p>
        </div>
      </div>

      {simStatus && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-600/70 text-emerald-200 text-xs font-mono rounded-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{simStatus}</span>
        </div>
      )}

      {/* 5 Rails Comparative Selector Bar */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2 font-mono text-xs">
        {rails.map(r => {
          const isSelected = r.rail === selectedRail;
          return (
            <div
              key={r.rail}
              onClick={() => setSelectedRail(r.rail)}
              className={`p-3 rounded-xs border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#0f223f] border-blue-500 shadow-md ring-1 ring-blue-500/50'
                  : 'bg-[#091322] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="font-bold text-white text-xs truncate">{r.name}</div>
              <div className="text-[10px] text-slate-400 mt-0.5 truncate">{r.type}</div>
              <div className="mt-2 text-[11px] flex items-center justify-between">
                <span className="text-slate-500 text-[10px]">LATENCY:</span>
                <span className={`font-bold ${r.rail === 'DUSD_CORE_LEDGER' ? 'text-emerald-400' : 'text-slate-300'}`}>
                  {r.latency}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Detailed Side-by-Side Comparison Matrix */}
      <div className="bg-[#0b1628] border border-slate-800 p-4 rounded-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
          <div>
            <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
              <span>{currentRail.name}</span>
              <span className="text-xs text-blue-400 bg-blue-950 px-2 py-0.5 border border-blue-800 rounded-xs">
                {currentRail.type}
              </span>
            </h3>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Settlement Mechanism: <span className="text-slate-200">{currentRail.settlementMechanism}</span>
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-slate-400 text-[11px]">BENCHMARK AMOUNT:</span>
            <input
              type="number"
              value={testAmount}
              onChange={(e) => setTestAmount(Number(e.target.value))}
              className="bg-[#050b16] border border-slate-700 px-2 py-1 text-white rounded-xs w-28 font-bold"
            />
            <button
              onClick={handleRunRailTest}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xs flex items-center gap-1 shadow-xs"
            >
              <Play className="w-3.5 h-3.5" />
              DISPATCH TEST
            </button>
          </div>
        </div>

        {/* Matrix Specifications Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-xs">
          <div className="bg-[#060c18] border border-slate-800 p-3 rounded-xs space-y-1">
            <span className="text-slate-500 text-[10px] block">SETTLEMENT LATENCY</span>
            <span className="text-lg font-bold text-emerald-400 block">{currentRail.latency}</span>
            <span className="text-slate-400 text-[11px]">From initiation to recipient ledger credit</span>
          </div>

          <div className="bg-[#060c18] border border-slate-800 p-3 rounded-xs space-y-1">
            <span className="text-slate-500 text-[10px] block">LEGAL FINALITY</span>
            <span className="text-sm font-bold text-white block">{currentRail.finality}</span>
            <span className="text-slate-400 text-[11px]">Irrevocability point under UCC / Fed Regulations</span>
          </div>

          <div className="bg-[#060c18] border border-slate-800 p-3 rounded-xs space-y-1">
            <span className="text-slate-500 text-[10px] block">TRANSACTION COST / INTERCHANGE</span>
            <span className="text-base font-bold text-amber-300 block">{currentRail.cost}</span>
            <span className="text-slate-400 text-[11px]">Network fees and interchange take-rates</span>
          </div>

          <div className="bg-[#060c18] border border-slate-800 p-3 rounded-xs space-y-1">
            <span className="text-slate-500 text-[10px] block">OPERATING WINDOW</span>
            <span className="text-white font-semibold block">{currentRail.availability}</span>
            <span className="text-slate-400 text-[11px]">Hours of clearing and settlement</span>
          </div>

          <div className="bg-[#060c18] border border-slate-800 p-3 rounded-xs space-y-1">
            <span className="text-slate-500 text-[10px] block">COUNTERPARTY CREDIT RISK</span>
            <span className="text-white font-semibold block">{currentRail.counterpartyRisk}</span>
            <span className="text-slate-400 text-[11px]">Exposure during clearing float</span>
          </div>

          <div className="bg-[#060c18] border border-slate-800 p-3 rounded-xs space-y-1">
            <span className="text-slate-500 text-[10px] block">FAILURE / DISPUTE RATE</span>
            <span className="text-white font-semibold block">{currentRail.failureRate}</span>
            <span className="text-slate-400 text-[11px]">NSF, chargeback, or technical routing errors</span>
          </div>
        </div>
      </div>
    </div>
  );
};
