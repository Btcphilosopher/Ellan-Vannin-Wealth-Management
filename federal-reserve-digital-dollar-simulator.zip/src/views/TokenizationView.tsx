import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  Receipt,
  Play,
  CheckCircle2,
  AlertTriangle,
  ArrowRightLeft,
  ShieldCheck,
  Landmark,
  Scale,
  Layers,
  ArrowRight
} from 'lucide-react';
import { TokenizedDvPContract } from '../types';

export const TokenizationView: React.FC = () => {
  const { dvpContracts, executeDvPAtomicSettlement } = useSimulator();
  const [selectedDvpId, setSelectedDvpId] = useState<string>(dvpContracts[0]?.id || 'DVP-TBILL-2026-09');
  const [feedback, setFeedback] = useState<string | null>(null);

  const selectedDvp = dvpContracts.find(d => d.id === selectedDvpId) || dvpContracts[0];

  const handleExecuteAtomicDvp = (dvpId: string) => {
    try {
      executeDvPAtomicSettlement(dvpId);
      setFeedback(`Atomic DvP Settlement Executed: Cash leg and Asset leg transferred simultaneously. Principal settlement fail risk: 0.00%.`);
      setTimeout(() => setFeedback(null), 5000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Receipt className="w-5 h-5 text-blue-400" />
              TOKENIZATION &amp; ATOMIC DELIVERY-VERSUS-PAYMENT (DvP)
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              WHOLESALE FINANCIAL MARKET INFRASTRUCTURE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Tokenized U.S. Treasuries &bull; Corporate Commercial Paper &bull; Simultaneous Atomic Settlement &bull; Elimination of T+1 Float
          </p>
        </div>
      </div>

      {feedback && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-600/70 text-emerald-200 text-xs font-mono rounded-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Grid of DvP Contracts Available */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-xs">
        {dvpContracts.map((contract: TokenizedDvPContract) => {
          const isSelected = contract.id === selectedDvp?.id;
          return (
            <div
              key={contract.id}
              onClick={() => setSelectedDvpId(contract.id)}
              className={`p-3.5 rounded-xs border transition-all cursor-pointer space-y-2 flex flex-col justify-between ${
                isSelected
                  ? 'bg-[#0f223f] border-blue-500 shadow-md ring-1 ring-blue-500/50'
                  : 'bg-[#091322] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs">{contract.securityTitle}</span>
                  <span className={`text-[9px] px-1.5 py-0.2 rounded-xs font-bold ${
                    contract.atomicFinality === 'EXECUTED_ATOMIC' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                    'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}>
                    {contract.atomicFinality.replace(/_/g, ' ')}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  Cash Leg: <strong className="text-white">{formatCurrency(contract.settlementDusdAmount)}</strong> DUSD
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  Par Value: <span className="text-slate-300 font-bold">{formatCurrency(contract.parValue)}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
                <span className="text-blue-400">{contract.id}</span>
                <span className="text-slate-400">{contract.buyerInstitution}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Deep Atomic Execution Workbench */}
      {selectedDvp && (
        <div className="bg-[#0b1628] border border-slate-800 p-4 rounded-xs space-y-4 font-mono text-xs">
          <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>{selectedDvp.securityTitle}</span>
                <span className="text-xs text-blue-400 bg-blue-950 px-2 py-0.5 border border-blue-800 rounded-xs">
                  CUSIP: {selectedDvp.cusip}
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Buyer: <span className="text-white font-semibold">{selectedDvp.buyerInstitution}</span> &harr; Seller: <span className="text-white font-semibold">{selectedDvp.sellerInstitution}</span>
              </p>
            </div>

            {selectedDvp.atomicFinality === 'PENDING' && (
              <button
                onClick={() => handleExecuteAtomicDvp(selectedDvp.id)}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xs flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <Play className="w-3.5 h-3.5" />
                EXECUTE ATOMIC DVP SETTLEMENT
              </button>
            )}
          </div>

          {/* Simultaneous Two-Leg Visual Diagram */}
          <div className="bg-[#060c18] border border-slate-800 p-4 rounded-xs space-y-3">
            <div className="text-[10px] font-bold text-slate-400 uppercase">
              SIMULTANEOUS TWO-LEG ATOMIC SETTLEMENT SPECIFICATION:
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Cash Leg */}
              <div className="p-3 bg-[#091424] border border-blue-900/60 rounded-xs space-y-2">
                <div className="flex items-center justify-between text-blue-400 font-bold border-b border-slate-800 pb-1">
                  <span>CASH LEG (DUSD)</span>
                  <span>{formatCurrency(selectedDvp.settlementDusdAmount)}</span>
                </div>
                <div className="text-[11px] text-slate-300 space-y-1">
                  <div>From: <strong className="text-white">{selectedDvp.buyerInstitution}</strong></div>
                  <div>To: <strong className="text-white">{selectedDvp.sellerInstitution}</strong></div>
                  <div>Rail: <span className="text-cyan-400">Federal Reserve DUSD Core RTGS</span></div>
                  <div>Finality: <span className="text-emerald-400">Immediate &amp; Irrevocable</span></div>
                </div>
              </div>

              {/* Asset Leg */}
              <div className="p-3 bg-[#091424] border border-purple-900/60 rounded-xs space-y-2">
                <div className="flex items-center justify-between text-purple-400 font-bold border-b border-slate-800 pb-1">
                  <span>ASSET LEG ({selectedDvp.securityType.replace(/_/g, ' ')})</span>
                  <span>Par: {formatCurrency(selectedDvp.parValue)}</span>
                </div>
                <div className="text-[11px] text-slate-300 space-y-1">
                  <div>From: <strong className="text-white">{selectedDvp.sellerInstitution}</strong></div>
                  <div>To: <strong className="text-white">{selectedDvp.buyerInstitution}</strong></div>
                  <div>Depository: <span className="text-purple-300">Fedwire Securities / DTCC Smart Custody</span></div>
                  <div>Title Transfer: <span className="text-emerald-400">Simultaneous with Cash Leg</span></div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px] text-slate-400">
              <span>Cryptographic Commit Phase: <strong>2-Phase Atomic Hash Commitment</strong></span>
              <span>Principal Settlement Failure Risk: <strong className="text-emerald-400">0.00% (Mathematically Bound)</strong></span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
