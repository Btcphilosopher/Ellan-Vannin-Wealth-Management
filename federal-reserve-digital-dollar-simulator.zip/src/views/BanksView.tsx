import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  Building2,
  TrendingDown,
  ShieldCheck,
  AlertTriangle,
  ArrowRightLeft,
  Percent,
  Activity,
  Layers
} from 'lucide-react';
import { CommercialBank } from '../types';

export const BanksView: React.FC = () => {
  const {
    banks,
    convertDepositToDusd,
    wallets,
  } = useSimulator();

  const [selectedBankId, setSelectedBankId] = useState<string>('BANK-LNB');
  const [migrationAmount, setMigrationAmount] = useState<number>(1000000000); // $1B default stress migration
  const [migrationMsg, setMigrationMsg] = useState<string | null>(null);

  const selectedBank = banks.find(b => b.id === selectedBankId) || banks[0];
  const targetWallet = wallets[0];

  const handleSimulateDepositMigration = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      convertDepositToDusd(migrationAmount, selectedBank.id, targetWallet.id);
      setMigrationMsg(`Simulated ${formatCurrency(migrationAmount)} commercial deposit migration into DUSD. Bank balance sheet contracted symmetrically.`);
      setTimeout(() => setMigrationMsg(null), 5000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-400" />
              COMMERCIAL BANKING SYSTEM SIMULATOR
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              8 TIER-1 INSTITUTIONS
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Intermediated Reserve Balancing • Deposit Disintermediation Sensitivity • Basel III CET1 &amp; LCR Surveillance
          </p>
        </div>
      </div>

      {migrationMsg && (
        <div className="p-3 bg-amber-950/60 border border-amber-600/70 text-amber-200 text-xs font-mono rounded-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{migrationMsg}</span>
        </div>
      )}

      {/* Grid of 8 Commercial Banks Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        {banks.map(bank => {
          const isSelected = bank.id === selectedBank.id;
          return (
            <div
              key={bank.id}
              onClick={() => setSelectedBankId(bank.id)}
              className={`p-3 rounded-xs border transition-all cursor-pointer text-xs font-mono ${
                isSelected
                  ? 'bg-[#0f223f] border-blue-500 shadow-md'
                  : 'bg-[#091322] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-white font-bold truncate max-w-[140px]">{bank.name}</span>
                <span className={`text-[9px] px-1.5 py-0.2 rounded-xs font-semibold ${
                  bank.status === 'OPTIMAL' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                }`}>
                  {bank.status}
                </span>
              </div>

              <div className="mt-2 space-y-1 text-[11px]">
                <div className="flex justify-between text-slate-400">
                  <span>TOTAL ASSETS:</span>
                  <span className="text-white font-semibold">{formatCurrency(bank.assets.totalAssets, { compact: true })}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>CET1 CAPITAL:</span>
                  <span className="text-emerald-400 font-semibold">{bank.metrics.cet1Ratio}%</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>LCR RATIO:</span>
                  <span className="text-cyan-400 font-semibold">{bank.metrics.liquidityCoverageRatio}%</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>DUSD MIGRATION:</span>
                  <span className="text-amber-400 font-semibold">{bank.metrics.dusdDepositOutflowRate}%</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Deep Bank Balance Sheet & Stress Testing */}
      <div className="bg-[#0b1628] border border-slate-800 p-4 rounded-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white font-mono">
                {selectedBank.name}
              </h3>
              <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded-xs">
                ROUTING #{selectedBank.routingNumber}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Net Interest Margin (NIM): <strong className="text-slate-200">{selectedBank.metrics.netInterestMargin}%</strong> • Loan-to-Deposit Ratio: <strong className="text-slate-200">{selectedBank.metrics.loanToDepositRatio}%</strong>
            </p>
          </div>

          {/* Deposit Migration Injection */}
          <form onSubmit={handleSimulateDepositMigration} className="flex items-center gap-2 text-xs font-mono">
            <span className="text-slate-400 text-[11px]">MIGRATE DEPOSITS TO DUSD:</span>
            <input
              type="number"
              min="100000000"
              step="500000000"
              value={migrationAmount}
              onChange={(e) => setMigrationAmount(Number(e.target.value))}
              className="bg-[#050b16] border border-slate-700 px-2 py-1 text-white rounded-xs w-36 font-bold"
            />
            <button
              type="submit"
              className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xs flex items-center gap-1 shadow-xs"
            >
              <TrendingDown className="w-3.5 h-3.5" />
              SIMULATE MIGRATION
            </button>
          </form>
        </div>

        {/* Detailed Full Double-Entry Commercial Bank Balance Sheet */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          {/* Assets */}
          <div className="border border-slate-800 bg-[#060c18] rounded-xs p-3 space-y-2">
            <div className="flex justify-between border-b border-slate-700 pb-1.5 font-bold text-slate-200">
              <span>ASSETS</span>
              <span>AMOUNT (USD)</span>
            </div>
            <div className="space-y-1.5 divide-y divide-slate-800/60">
              <div className="flex justify-between pt-1 text-slate-300">
                <span>Central Bank Reserves (at Fed)</span>
                <span className="font-semibold text-white">{formatCurrency(selectedBank.assets.centralBankReserves)}</span>
              </div>
              <div className="flex justify-between pt-1 text-blue-300 font-semibold bg-blue-950/20 px-1 rounded-xs">
                <span>DUSD Operating Vault Balance</span>
                <span className="font-bold text-blue-400">{formatCurrency(selectedBank.assets.dusdOperatingBalance)}</span>
              </div>
              <div className="flex justify-between pt-1 text-slate-300">
                <span>Commercial &amp; Industrial Loans</span>
                <span className="font-semibold text-white">{formatCurrency(selectedBank.assets.commercialLoans)}</span>
              </div>
              <div className="flex justify-between pt-1 text-slate-300">
                <span>Residential &amp; Commercial Mortgages</span>
                <span className="font-semibold text-white">{formatCurrency(selectedBank.assets.consumerMortgages)}</span>
              </div>
              <div className="flex justify-between pt-1 text-slate-300">
                <span>U.S. Treasury &amp; Agency Debt</span>
                <span className="font-semibold text-white">{formatCurrency(selectedBank.assets.treasurySecurities)}</span>
              </div>
              <div className="flex justify-between pt-1 text-slate-300">
                <span>Cash in Vault &amp; ATM Floats</span>
                <span className="font-semibold text-white">{formatCurrency(selectedBank.assets.cashInVault)}</span>
              </div>
            </div>
            <div className="flex justify-between border-t-2 border-slate-700 pt-2 font-bold text-sm text-emerald-400">
              <span>TOTAL BANK ASSETS</span>
              <span>{formatCurrency(selectedBank.assets.totalAssets)}</span>
            </div>
          </div>

          {/* Liabilities & Equity */}
          <div className="border border-slate-800 bg-[#060c18] rounded-xs p-3 space-y-2">
            <div className="flex justify-between border-b border-slate-700 pb-1.5 font-bold text-slate-200">
              <span>LIABILITIES &amp; CAPITAL</span>
              <span>AMOUNT (USD)</span>
            </div>
            <div className="space-y-1.5 divide-y divide-slate-800/60">
              <div className="flex justify-between pt-1 text-slate-300">
                <span>Retail Checking &amp; Savings Deposits</span>
                <span className="font-semibold text-white">{formatCurrency(selectedBank.liabilities.retailDeposits)}</span>
              </div>
              <div className="flex justify-between pt-1 text-slate-300">
                <span>Commercial &amp; Corporate Deposits</span>
                <span className="font-semibold text-white">{formatCurrency(selectedBank.liabilities.commercialDeposits)}</span>
              </div>
              <div className="flex justify-between pt-1 text-slate-300">
                <span>Wholesale &amp; Federal Funds Funding</span>
                <span className="font-semibold text-white">{formatCurrency(selectedBank.liabilities.wholesaleFunding)}</span>
              </div>
              <div className="flex justify-between pt-1 text-slate-300">
                <span>DUSD Conversion Facility Commitments</span>
                <span className="font-semibold text-white">{formatCurrency(selectedBank.liabilities.dusdConversionFacility)}</span>
              </div>
              <div className="flex justify-between pt-1 text-slate-300">
                <span>Discount Window Borrowings (Fed)</span>
                <span className="font-semibold text-white">{formatCurrency(selectedBank.liabilities.fedDiscountBorrowings)}</span>
              </div>
              <div className="flex justify-between pt-1 text-slate-400 italic">
                <span>Tier-1 Common Equity Capital</span>
                <span className="font-semibold text-slate-300">{formatCurrency(selectedBank.equity.tier1CommonCapital)}</span>
              </div>
            </div>
            <div className="flex justify-between border-t-2 border-slate-700 pt-2 font-bold text-sm text-emerald-400">
              <span>TOTAL LIABILITIES &amp; EQUITY</span>
              <span>{formatCurrency(selectedBank.liabilities.totalLiabilities + selectedBank.equity.totalEquity)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
