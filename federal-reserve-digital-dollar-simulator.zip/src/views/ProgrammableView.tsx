import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  Code2,
  Play,
  Lock,
  Unlock,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Receipt,
  Truck,
  Building
} from 'lucide-react';
import { ProgrammablePaymentContract } from '../types';

export const ProgrammableView: React.FC = () => {
  const { programmableContracts, fulfillProgrammablePayment } = useSimulator();
  const [selectedContractId, setSelectedContractId] = useState<string>(programmableContracts[0]?.id || 'PRG-ESCROW-001');
  const [feedback, setFeedback] = useState<string | null>(null);

  const selectedContract = programmableContracts.find(c => c.id === selectedContractId) || programmableContracts[0];

  const handleExecuteTrigger = (contractId: string) => {
    try {
      fulfillProgrammablePayment(contractId);
      setFeedback(`Execution condition verified. Escrowed DUSD released with immediate atomic finality.`);
      setTimeout(() => setFeedback(null), 5000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Code2 className="w-5 h-5 text-blue-400" />
              PROGRAMMABLE MONEY &amp; CONDITIONAL ESCROW LOGIC
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              SMART DISBURSEMENT ENGINE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Automated Supply-Chain Escrows • Milestone Releases • Dynamic Tax Withholding • Policy-Constrained Stimulus
          </p>
        </div>
      </div>

      {feedback && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-600/70 text-emerald-200 text-xs font-mono rounded-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Contract Template Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-xs">
        {programmableContracts.map((contract: ProgrammablePaymentContract) => {
          const isSelected = contract.id === selectedContract?.id;
          return (
            <div
              key={contract.id}
              onClick={() => setSelectedContractId(contract.id)}
              className={`p-3.5 rounded-xs border transition-all cursor-pointer space-y-2 flex flex-col justify-between ${
                isSelected
                  ? 'bg-[#0f223f] border-blue-500 shadow-md ring-1 ring-blue-500/50'
                  : 'bg-[#091322] border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs">{contract.title}</span>
                  <span className={`text-[9px] px-1.5 py-0.2 rounded-xs font-bold ${
                    contract.state === 'SETTLED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                    contract.state === 'LOCKED' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                    'bg-slate-800 text-slate-300'
                  }`}>
                    {contract.state.replace(/_/g, ' ')}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  Amount: <strong className="text-white">{formatCurrency(contract.principalAmount)}</strong> DUSD
                </div>
                <div className="text-[10px] text-slate-500 mt-1">
                  Trigger: <span className="text-slate-300">{contract.conditionDescription}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
                <span className="text-blue-400">{contract.id}</span>
                <span className="text-slate-400">{contract.paymentType.replace(/_/g, ' ')}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Deep Contract Inspector & Flow Visualizer */}
      {selectedContract && (
        <div className="bg-[#0b1628] border border-slate-800 p-4 rounded-xs space-y-4 font-mono text-xs">
          <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>{selectedContract.title}</span>
                <span className="text-xs text-blue-400 bg-blue-950 px-2 py-0.5 border border-blue-800 rounded-xs">
                  ESCROW CONTRACT #{selectedContract.id}
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Parties: <span className="text-slate-200 font-semibold">{selectedContract.payerName}</span> &rarr; <span className="text-slate-200 font-semibold">{selectedContract.payeeName}</span>
              </p>
            </div>

            {selectedContract.state !== 'SETTLED' && (
              <button
                onClick={() => handleExecuteTrigger(selectedContract.id)}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xs flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <Play className="w-3.5 h-3.5" />
                SIMULATE ORACLE TRIGGER &amp; RELEASE
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-3 bg-[#060c18] border border-slate-800 rounded-xs space-y-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase">1. ESCROW LOCK STATE</span>
              <div className="text-lg font-bold text-amber-400">
                {formatCurrency(selectedContract.principalAmount)}
              </div>
              <p className="text-[11px] text-slate-400">
                Central-bank liability locked under programmable script. Payer funds are sequestered; recipient receives verifiable claim.
              </p>
            </div>

            <div className="p-3 bg-[#060c18] border border-slate-800 rounded-xs space-y-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase">2. VERIFICATION SOURCE</span>
              <div className="text-xs font-bold text-white">
                {selectedContract.verificationSource}
              </div>
              <p className="text-[11px] text-slate-400">
                Authorized external oracle or cryptographically signed delivery receipt required to transition state.
              </p>
            </div>

            <div className="p-3 bg-[#060c18] border border-slate-800 rounded-xs space-y-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase">3. FINAL SETTLEMENT</span>
              <div className={`text-xs font-bold ${selectedContract.state === 'SETTLED' ? 'text-emerald-400' : 'text-slate-400'}`}>
                {selectedContract.state === 'SETTLED' ? 'SETTLED (FINAL GROSS RTGS)' : 'AWAITING ATOMIC TRIGGER'}
              </div>
              <p className="text-[11px] text-slate-400">
                Upon oracle trigger, central bank ledger atomically transfers DUSD from escrow container to payee account.
              </p>
            </div>
          </div>

          {/* Execution Logs */}
          <div className="bg-[#050a14] p-3 border border-slate-800 rounded-xs space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase block">AUDIT TRAIL &amp; EXECUTION LOGS</span>
            <div className="text-[11px] text-slate-300 space-y-0.5">
              {selectedContract.executionLogs.map((log, idx) => (
                <div key={idx} className="flex gap-2">
                  <span className="text-slate-600">&gt;</span>
                  <span>{log}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
