import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import {
  LineChart as LineChartIcon,
  Download,
  Sliders,
  FileSpreadsheet,
  TrendingUp,
  Percent,
  Activity,
  Layers
} from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

export const DataLabView: React.FC = () => {
  const { exportSimulationState } = useSimulator();

  const [inclusionTarget, setInclusionTarget] = useState<number>(94.5); // % of US adults
  const [costReductionEstimate, setCostReductionEstimate] = useState<number>(82.4); // % payment fee savings

  // Empirical synthetic economic research series
  const velocityData = [
    { period: '2024 Q1', m1Velocity: 1.12, m2Velocity: 1.25, dusdVelocity: 4.85 },
    { period: '2024 Q2', m1Velocity: 1.14, m2Velocity: 1.26, dusdVelocity: 5.12 },
    { period: '2024 Q3', m1Velocity: 1.13, m2Velocity: 1.24, dusdVelocity: 5.45 },
    { period: '2024 Q4', m1Velocity: 1.15, m2Velocity: 1.27, dusdVelocity: 5.92 },
    { period: '2025 Q1', m1Velocity: 1.16, m2Velocity: 1.28, dusdVelocity: 6.34 },
    { period: '2025 Q2', m1Velocity: 1.15, m2Velocity: 1.26, dusdVelocity: 6.80 },
  ];

  const crossBorderSavingsData = [
    { corridor: 'USD / MXN', legacyCostPct: 5.8, dusdCostPct: 0.25 },
    { corridor: 'USD / EUR', legacyCostPct: 2.9, dusdCostPct: 0.10 },
    { corridor: 'USD / JPY', legacyCostPct: 3.4, dusdCostPct: 0.12 },
    { corridor: 'USD / GBP', legacyCostPct: 2.7, dusdCostPct: 0.08 },
    { corridor: 'USD / PHP', legacyCostPct: 6.2, dusdCostPct: 0.30 },
  ];

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <LineChartIcon className="w-5 h-5 text-blue-400" />
              ECONOMIC &amp; FINANCIAL QUANTITATIVE DATA LAB
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              QUANTITATIVE RESEARCH WORKSTATION
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Macroeconomic Transmission Modeling • Monetary Velocity Comparison • Cross-Border Frictions Reduction
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => exportSimulationState('csv')}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 border border-slate-700 rounded-xs transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            EXPORT CSV RESEARCH DATASET
          </button>
          <button
            onClick={() => exportSimulationState('json')}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 border border-slate-700 rounded-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            EXPORT JSON
          </button>
        </div>
      </div>

      {/* Key Research Highlights Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 font-mono text-xs">
        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">MONEY VELOCITY MULTIPLIER</span>
          <span className="text-xl font-bold text-cyan-400">5.4x vs M1</span>
          <span className="text-slate-400 text-[10px]">Instant 24/7 continuous circulation</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">RETAIL PAYMENT COST SAVINGS</span>
          <span className="text-xl font-bold text-emerald-400">-$64.2B / Year</span>
          <span className="text-slate-400 text-[10px]">Interchange fee reduction for US merchants</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">FINANCIAL INCLUSION EXPANSION</span>
          <span className="text-xl font-bold text-amber-400">+7.4M Unbanked</span>
          <span className="text-slate-400 text-[10px]">Direct low-friction fee-free digital accounts</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">INTRADAY LIQUIDITY BUFFER</span>
          <span className="text-xl font-bold text-indigo-400">-38% Reserve Lockup</span>
          <span className="text-slate-400 text-[10px]">Synchronized continuous gross settlement</span>
        </div>
      </div>

      {/* Two Macro Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Chart 1: Velocity Comparison */}
        <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white uppercase tracking-wider">
              VELOCITY OF MONEY: DUSD CORE VS. M1 &amp; M2 MONETARY AGGREGATES
            </h3>
            <span className="text-[10px] text-blue-400 bg-blue-950 px-2 py-0.5 rounded-xs border border-blue-800">
              FRED SERIES EQUIVALENT
            </span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={velocityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="period" stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} domain={[0, 8]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#070f1e', borderColor: '#334155', fontSize: '11px', fontFamily: 'monospace' }}
                  itemStyle={{ color: '#e2e8f0' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Line type="monotone" dataKey="dusdVelocity" name="Digital Dollar (DUSD) Turnover" stroke="#38bdf8" strokeWidth={2} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="m1Velocity" name="M1 Velocity (Checking/Cash)" stroke="#94a3b8" strokeWidth={1.5} />
                <Line type="monotone" dataKey="m2Velocity" name="M2 Velocity (Broad Money)" stroke="#64748b" strokeWidth={1.5} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Cross-Border Cost Reductions */}
        <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white uppercase tracking-wider">
              CROSS-BORDER TRANSACTION FRICTION REDUCTION (% TOTAL TRANSFER)
            </h3>
            <span className="text-[10px] text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-xs border border-emerald-800">
              G20 ROADMAP TARGETS
            </span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={crossBorderSavingsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="corridor" stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11, fill: '#94a3b8' }} unit="%" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#070f1e', borderColor: '#334155', fontSize: '11px', fontFamily: 'monospace' }}
                  itemStyle={{ color: '#e2e8f0' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="legacyCostPct" name="Legacy Correspondent Banking Fee %" fill="#ef4444" />
                <Bar dataKey="dusdCostPct" name="mCBDC Atomic PvP Fee %" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
