import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency, formatLargeExactNumber } from '../utils/formatters';
import { 
  Coins, 
  ArrowDownCircle, 
  ArrowUpCircle, 
  ShieldCheck, 
  AlertTriangle,
  Building,
  RefreshCw,
  Sliders,
  Scale,
  CheckCircle2
} from 'lucide-react';

export const IssuanceView: React.FC = () => {
  const {
    fedBalanceSheet,
    banks,
    issueDusd,
    redeemDusd,
    accountingStatus
  } = useSimulator();

  const [issueAmount, setIssueAmount] = useState<number>(500000000); // $500M default
  const [selectedBankId, setSelectedBankId] = useState<string>('BANK-LNB');
  const [redeemAmount, setRedeemAmount] = useState<number>(250000000); // $250M default
  const [activeTab, setActiveTab] = useState<'ISSUANCE_REDEMPTION' | 'BALANCE_SHEET'>('ISSUANCE_REDEMPTION');
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  const selectedBank = banks.find(b => b.id === selectedBankId) || banks[0];

  const handleIssue = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      issueDusd(issueAmount, selectedBankId);
      setActionSuccessMsg(`Successfully issued ${formatCurrency(issueAmount)} DUSD to ${selectedBank.name} against Federal Reserve Master Account Reserve debit.`);
      setTimeout(() => setActionSuccessMsg(null), 5000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      redeemDusd(redeemAmount, selectedBankId);
      setActionSuccessMsg(`Successfully redeemed ${formatCurrency(redeemAmount)} DUSD from ${selectedBank.name} into Bank Reserve Account.`);
      setTimeout(() => setActionSuccessMsg(null), 5000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const dusdLiability = fedBalanceSheet.liabilities.digitalDollarInCirculation;
  const issuanceToday = 14250000000;
  const redemptionsToday = 8900000000;
  const netIssuance = issuanceToday - redemptionsToday;

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Coins className="w-5 h-5 text-blue-400" />
              FEDERAL RESERVE ISSUANCE &amp; REDEMPTION ENGINE
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 rounded-xs font-semibold">
              DOUBLE-ENTRY CERTIFIED
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Direct Central-Bank Liability Management • Reserve Swaps • Institutional SOMA Backing
          </p>
        </div>

        <div className="flex items-center gap-1.5 bg-[#0b1626] p-1 border border-slate-800 rounded-xs text-xs font-mono">
          <button
            onClick={() => setActiveTab('ISSUANCE_REDEMPTION')}
            className={`px-3 py-1 rounded-xs transition-colors font-semibold ${
              activeTab === 'ISSUANCE_REDEMPTION' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            ISSUANCE &amp; REDEMPTION
          </button>
          <button
            onClick={() => setActiveTab('BALANCE_SHEET')}
            className={`px-3 py-1 rounded-xs transition-colors font-semibold ${
              activeTab === 'BALANCE_SHEET' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            FED BALANCE SHEET (SOMA)
          </button>
        </div>
      </div>

      {actionSuccessMsg && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-600/70 text-emerald-200 text-xs font-mono rounded-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* Main Liability Readout Display */}
      <div className="bg-[#0b1629] border border-blue-900/40 p-4 rounded-xs shadow-md space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
          <span className="text-xs font-mono font-bold tracking-wider text-slate-400 uppercase">
            FEDERAL RESERVE DIGITAL DOLLAR CENTRAL LIABILITY
          </span>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-800 px-2 py-0.5 rounded-xs">
            LEGAL TENDER CENTRAL-BANK MONEY
          </span>
        </div>

        <div className="flex flex-wrap items-baseline justify-between gap-4">
          <div>
            <div className="text-3xl lg:text-4xl font-extrabold font-mono text-white tabular-nums tracking-tight">
              {formatCurrency(dusdLiability)}
            </div>
            <div className="text-xs font-mono text-slate-400 mt-1">
              Exact Outstanding: <strong className="text-blue-400">${formatLargeExactNumber(dusdLiability)}</strong> DUSD
            </div>
          </div>

          <div className="flex items-center gap-6 text-xs font-mono">
            <div>
              <span className="text-slate-500 text-[10px] block">ISSUANCE TODAY</span>
              <span className="text-emerald-400 font-bold tabular-nums">+{formatCurrency(issuanceToday, { compact: true })}</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block">REDEMPTIONS TODAY</span>
              <span className="text-rose-400 font-bold tabular-nums">-{formatCurrency(redemptionsToday, { compact: true })}</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block">NET ISSUANCE</span>
              <span className="text-white font-bold tabular-nums">+{formatCurrency(netIssuance, { compact: true })}</span>
            </div>
          </div>
        </div>

        {/* Breakdown of balances */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 pt-2 border-t border-slate-800/70 text-[11px] font-mono">
          <div className="bg-[#07101f] p-2 border border-slate-800/80 rounded-xs">
            <span className="text-slate-500 text-[10px] block">CIRCULATING SUPPLY</span>
            <span className="text-white font-bold">$2.68T (94.3%)</span>
          </div>
          <div className="bg-[#07101f] p-2 border border-slate-800/80 rounded-xs">
            <span className="text-slate-500 text-[10px] block">INSTITUTIONAL POOL</span>
            <span className="text-cyan-300 font-bold">$98.2B (3.5%)</span>
          </div>
          <div className="bg-[#07101f] p-2 border border-slate-800/80 rounded-xs">
            <span className="text-slate-500 text-[10px] block">OFFLINE BALANCES</span>
            <span className="text-amber-300 font-bold">$31.4B (1.1%)</span>
          </div>
          <div className="bg-[#07101f] p-2 border border-slate-800/80 rounded-xs">
            <span className="text-slate-500 text-[10px] block">ESCROW BALANCES</span>
            <span className="text-indigo-300 font-bold">$21.8B (0.8%)</span>
          </div>
          <div className="bg-[#07101f] p-2 border border-slate-800/80 rounded-xs">
            <span className="text-slate-500 text-[10px] block">INACTIVE / COLD</span>
            <span className="text-slate-400 font-bold">$8.7B (0.3%)</span>
          </div>
        </div>
      </div>

      {activeTab === 'ISSUANCE_REDEMPTION' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Issue DUSD Form */}
          <div className="bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-xs font-bold font-mono text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <ArrowDownCircle className="w-4 h-4" />
                ISSUE DIGITAL DOLLARS (RESERVE CONVERSION)
              </h3>
              <span className="text-[10px] font-mono text-slate-400">CREDIT: DUSD / DEBIT: RESERVES</span>
            </div>

            <p className="text-xs text-slate-400">
              Commercial banks purchase DUSD by debiting their Reserve Master Account at the Federal Reserve. Fed balance sheet size is unchanged; reserve liability shifts into Digital Dollar liability.
            </p>

            <form onSubmit={handleIssue} className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">RECIPIENT INTERMEDIARY BANK</label>
                <select
                  value={selectedBankId}
                  onChange={(e) => setSelectedBankId(e.target.value)}
                  className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-slate-200 focus:outline-hidden focus:border-blue-500"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.name} (Reserves: {formatCurrency(b.assets.centralBankReserves, { compact: true })})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">ISSUANCE AMOUNT (DUSD)</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1000000"
                    step="10000000"
                    value={issueAmount}
                    onChange={(e) => setIssueAmount(Number(e.target.value))}
                    className="flex-1 bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white font-bold focus:outline-hidden focus:border-blue-500"
                  />
                  <div className="flex gap-1">
                    {[100e6, 500e6, 1e9].map(amt => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setIssueAmount(amt)}
                        className="px-2 py-1 bg-slate-800 text-slate-300 hover:bg-slate-700 rounded-xs text-[10px]"
                      >
                        {formatCurrency(amt, { compact: true })}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-2.5 bg-[#050c18] border border-slate-800 rounded-xs space-y-1 text-[11px]">
                <div className="text-slate-400 font-semibold uppercase text-[10px]">Double-Entry Journal Voucher:</div>
                <div className="flex justify-between text-slate-300">
                  <span>Dr. Fed Reserve Liabilities (Bank Reserves):</span>
                  <span className="text-rose-400 font-bold">-${formatLargeExactNumber(issueAmount)}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Cr. Fed DUSD Liabilities (In Circulation):</span>
                  <span className="text-emerald-400 font-bold">+${formatLargeExactNumber(issueAmount)}</span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Coins className="w-4 h-4" />
                EXECUTE FED DUSD ISSUANCE
              </button>
            </form>
          </div>

          {/* Redeem DUSD Form */}
          <div className="bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-xs font-bold font-mono text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                <ArrowUpCircle className="w-4 h-4" />
                REDEEM DIGITAL DOLLARS (RETURN TO RESERVES)
              </h3>
              <span className="text-[10px] font-mono text-slate-400">DEBIT: DUSD / CREDIT: RESERVES</span>
            </div>

            <p className="text-xs text-slate-400">
              Commercial bank surrenders excess DUSD liquidity back to the Federal Reserve in exchange for Central Bank Master Account Reserve credits.
            </p>

            <form onSubmit={handleRedeem} className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">ORIGINATING INTERMEDIARY BANK</label>
                <select
                  value={selectedBankId}
                  onChange={(e) => setSelectedBankId(e.target.value)}
                  className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-slate-200 focus:outline-hidden focus:border-blue-500"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.name} (DUSD Operating: {formatCurrency(b.assets.dusdOperatingBalance, { compact: true })})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">REDEMPTION AMOUNT (DUSD)</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1000000"
                    step="10000000"
                    value={redeemAmount}
                    onChange={(e) => setRedeemAmount(Number(e.target.value))}
                    className="flex-1 bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white font-bold focus:outline-hidden focus:border-blue-500"
                  />
                  <div className="flex gap-1">
                    {[100e6, 250e6, 500e6].map(amt => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setRedeemAmount(amt)}
                        className="px-2 py-1 bg-slate-800 text-slate-300 hover:bg-slate-700 rounded-xs text-[10px]"
                      >
                        {formatCurrency(amt, { compact: true })}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-2.5 bg-[#050c18] border border-slate-800 rounded-xs space-y-1 text-[11px]">
                <div className="text-slate-400 font-semibold uppercase text-[10px]">Double-Entry Journal Voucher:</div>
                <div className="flex justify-between text-slate-300">
                  <span>Dr. Fed DUSD Liabilities (Circulation Burn):</span>
                  <span className="text-rose-400 font-bold">-${formatLargeExactNumber(redeemAmount)}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Cr. Fed Reserve Liabilities (Bank Reserve Credit):</span>
                  <span className="text-emerald-400 font-bold">+${formatLargeExactNumber(redeemAmount)}</span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Coins className="w-4 h-4" />
                EXECUTE FED DUSD REDEMPTION
              </button>
            </form>
          </div>
        </div>
      ) : (
        /* Full Federal Reserve SOMA Balance Sheet Table */
        <div className="bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2">
                <Scale className="w-4 h-4 text-blue-400" />
                FEDERAL RESERVE SYSTEM OF RECORD (H.4.1 SIMULATED BALANCE SHEET)
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                System Open Market Account (SOMA) Assets vs. Central Bank Monetary Liabilities
              </p>
            </div>
            <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 bg-emerald-950/40 px-2.5 py-1 border border-emerald-800 rounded-xs">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>INVARIANT: ASSETS = LIABILITIES + CAPITAL</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            {/* Assets Column */}
            <div className="border border-slate-800 bg-[#060c18] rounded-xs p-3 space-y-2">
              <div className="flex justify-between border-b border-slate-700 pb-1.5 font-bold text-slate-200">
                <span>ASSETS (SOMA HOLDINGS)</span>
                <span>AMOUNT (USD)</span>
              </div>
              <div className="space-y-1.5 divide-y divide-slate-800/60">
                <div className="flex justify-between pt-1 text-slate-300">
                  <span>U.S. Treasury Securities</span>
                  <span className="font-semibold text-white">{formatCurrency(fedBalanceSheet.assets.treasurySecurities)}</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-300">
                  <span>Federal Agency Debt &amp; MBS</span>
                  <span className="font-semibold text-white">{formatCurrency(fedBalanceSheet.assets.agencySecurities)}</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-300">
                  <span>Discount Window Loans</span>
                  <span className="font-semibold text-white">{formatCurrency(fedBalanceSheet.assets.loansToDepositoryInstitutions)}</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-300">
                  <span>Repurchase Agreements (Repo)</span>
                  <span className="font-semibold text-white">{formatCurrency(fedBalanceSheet.assets.repoAgreements)}</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-300">
                  <span>Foreign Currency &amp; Swap Lines</span>
                  <span className="font-semibold text-white">{formatCurrency(fedBalanceSheet.assets.foreignCurrencyReserves)}</span>
                </div>
              </div>
              <div className="flex justify-between border-t-2 border-slate-700 pt-2 font-bold text-sm text-emerald-400">
                <span>TOTAL FED ASSETS</span>
                <span>{formatCurrency(fedBalanceSheet.assets.totalAssets)}</span>
              </div>
            </div>

            {/* Liabilities & Equity Column */}
            <div className="border border-slate-800 bg-[#060c18] rounded-xs p-3 space-y-2">
              <div className="flex justify-between border-b border-slate-700 pb-1.5 font-bold text-slate-200">
                <span>LIABILITIES &amp; CAPITAL</span>
                <span>AMOUNT (USD)</span>
              </div>
              <div className="space-y-1.5 divide-y divide-slate-800/60">
                <div className="flex justify-between pt-1 text-blue-300 font-semibold bg-blue-950/30 px-1 rounded-xs">
                  <span>Digital Dollar (DUSD in Circulation)</span>
                  <span className="font-bold text-blue-400">{formatCurrency(fedBalanceSheet.liabilities.digitalDollarInCirculation)}</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-300">
                  <span>Depository Institution Reserves</span>
                  <span className="font-semibold text-white">{formatCurrency(fedBalanceSheet.liabilities.bankReserveBalances)}</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-300">
                  <span>Federal Reserve Notes (Physical)</span>
                  <span className="font-semibold text-white">{formatCurrency(fedBalanceSheet.liabilities.federalReserveNotes)}</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-300">
                  <span>Treasury General Account (TGA)</span>
                  <span className="font-semibold text-white">{formatCurrency(fedBalanceSheet.liabilities.treasuryGeneralAccount)}</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-300">
                  <span>Overnight Reverse Repo (ON RRP)</span>
                  <span className="font-semibold text-white">{formatCurrency(fedBalanceSheet.liabilities.reverseRepoObligations)}</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-300">
                  <span>Other Federal Reserve Liabilities</span>
                  <span className="font-semibold text-white">{formatCurrency(fedBalanceSheet.liabilities.otherLiabilities)}</span>
                </div>
                <div className="flex justify-between pt-1 text-slate-400 italic">
                  <span>Reserve Bank Surplus Capital (Equity)</span>
                  <span className="font-semibold text-slate-300">{formatCurrency(fedBalanceSheet.capital.totalCapital)}</span>
                </div>
              </div>
              <div className="flex justify-between border-t-2 border-slate-700 pt-2 font-bold text-sm text-emerald-400">
                <span>TOTAL LIABILITIES &amp; EQUITY</span>
                <span>{formatCurrency(fedBalanceSheet.liabilities.totalLiabilities + fedBalanceSheet.capital.totalCapital)}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
