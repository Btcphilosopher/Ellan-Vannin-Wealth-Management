import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency, formatLargeExactNumber } from '../utils/formatters';
import {
  Landmark,
  Play,
  CheckCircle2,
  AlertTriangle,
  ArrowDownRight,
  TrendingDown,
  Users,
  ShieldCheck,
  RotateCcw,
  FileCheck
} from 'lucide-react';

export const TreasuryView: React.FC = () => {
  const { fedBalanceSheet, disburseTreasuryPayment, wallets, treasuryState } = useSimulator();

  const [disbursementAmount, setDisbursementAmount] = useState<number>(12500000000); // $12.5B
  const [recipientCount, setRecipientCount] = useState<number>(8200000); // 8.2M citizens
  const [disbursementType, setDisbursementType] = useState<string>('SOCIAL_SECURITY');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [lastDisbursementResult, setLastDisbursementResult] = useState<any>(null);

  const tgaBalance = fedBalanceSheet.liabilities.treasuryGeneralAccount;

  const handleSimulateDisbursement = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      try {
        const recipient = wallets[0]?.id || 'WLT-JC-7419';
        disburseTreasuryPayment(disbursementAmount, recipient, `${disbursementType} Monthly Federal Benefit Distribution`);
        setLastDisbursementResult({
          amount: disbursementAmount,
          recipient,
          recipients: recipientCount,
          avgLatency: '1.24s total batch time',
          failures: '0 (100% atomic execution)',
        });
      } catch (err: any) {
        alert(err.message);
      } finally {
        setIsProcessing(false);
      }
    }, 800);
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Landmark className="w-5 h-5 text-amber-400" />
              U.S. TREASURY GENERAL ACCOUNT &amp; FISCAL FLOWS
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-amber-950/80 border border-amber-700/60 text-amber-300 rounded-xs font-semibold">
              BUREAU OF THE FISCAL SERVICE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Direct Sovereign Disbursements • Social Security Injection • Treasury Auction Liquidity Settlement
          </p>
        </div>
      </div>

      {/* TGA Balance Hero Metric */}
      <div className="bg-[#0b1629] border border-amber-900/50 p-4 rounded-xs shadow-md space-y-3 font-mono">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
          <span className="text-xs font-bold tracking-wider text-slate-400 uppercase">
            TREASURY GENERAL ACCOUNT (TGA) CASH BALANCE AT FEDERAL RESERVE
          </span>
          <span className="text-[11px] text-amber-400 bg-amber-950/40 border border-amber-800 px-2 py-0.5 rounded-xs">
            DEPOSITORY LIQUIDITY
          </span>
        </div>

        <div className="flex flex-wrap items-baseline justify-between gap-4">
          <div>
            <div className="text-3xl lg:text-4xl font-extrabold text-white tabular-nums tracking-tight">
              {formatCurrency(tgaBalance)}
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Exact TGA Ledger Balance: <strong className="text-amber-400">${formatLargeExactNumber(tgaBalance)}</strong> USD
            </div>
          </div>

          <div className="flex items-center gap-6 text-xs">
            <div>
              <span className="text-slate-500 text-[10px] block">TODAY'S TAX RECEIPTS</span>
              <span className="text-emerald-400 font-bold tabular-nums">+$4.85B</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block">FEDERAL EXPENDITURES</span>
              <span className="text-rose-400 font-bold tabular-nums">-$16.20B</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block">DEBT ISSUANCE FLOWS</span>
              <span className="text-blue-400 font-bold tabular-nums">+$22.00B</span>
            </div>
          </div>
        </div>
      </div>

      {/* Fiscal Disbursement Simulator Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Form (5 cols) */}
        <div className="lg:col-span-5 bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <ArrowDownRight className="w-4 h-4 text-amber-400" />
              DISBURSE FISCAL BENEFIT BATCH
            </h3>
            <span className="text-[10px] text-slate-400">INSTANT DIRECT CREDIT</span>
          </div>

          <form onSubmit={handleSimulateDisbursement} className="space-y-3">
            <div>
              <label className="text-slate-400 text-[11px] block mb-1">PROGRAM TYPE</label>
              <select
                value={disbursementType}
                onChange={(e) => setDisbursementType(e.target.value)}
                className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white font-semibold"
              >
                <option value="SOCIAL_SECURITY">Social Security Administration (OASDI)</option>
                <option value="VETERANS_AFFAIRS">Veterans Affairs Benefits</option>
                <option value="EMERGENCY_DISASTER">FEMA Emergency Relief</option>
                <option value="TAX_REFUND">IRS Federal Tax Refunds</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">TOTAL DISBURSEMENT AMOUNT (USD)</label>
              <input
                type="number"
                value={disbursementAmount}
                onChange={(e) => setDisbursementAmount(Number(e.target.value))}
                className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white font-bold"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-1">RECIPIENT WALLET POOL</label>
              <input
                type="number"
                value={recipientCount}
                onChange={(e) => setRecipientCount(Number(e.target.value))}
                className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2.5 py-1.5 text-white"
              />
            </div>

            <div className="p-2.5 bg-[#050c18] border border-slate-800 rounded-xs space-y-1 text-[11px]">
              <div className="text-slate-400 font-semibold uppercase text-[10px]">Fiscal Journal Voucher:</div>
              <div className="flex justify-between text-slate-300">
                <span>Dr. Fed TGA Liabilities:</span>
                <span className="text-rose-400 font-bold">-${formatLargeExactNumber(disbursementAmount)}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Cr. Fed DUSD Liabilities (Citizens):</span>
                <span className="text-emerald-400 font-bold">+${formatLargeExactNumber(disbursementAmount)}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isProcessing}
              className="w-full py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-bold rounded-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Play className="w-4 h-4" />
              {isProcessing ? 'DISPATCHING FISCAL BATCH...' : 'EXECUTE DIRECT FISCAL DISBURSEMENT'}
            </button>
          </form>
        </div>

        {/* Results & Audit Trail Log (7 cols) */}
        <div className="lg:col-span-7 bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <FileCheck className="w-4 h-4 text-emerald-400" />
              TREASURY DISBURSEMENT AUDIT TELEMETRY
            </h3>
            <span className="text-[10px] text-emerald-400 bg-emerald-950 px-2 py-0.5 border border-emerald-800 rounded-xs">
              100% RECONCILED
            </span>
          </div>

          {lastDisbursementResult ? (
            <div className="space-y-3 animate-fadeIn">
              <div className="p-3 bg-[#060c18] border border-emerald-900/60 rounded-xs space-y-2">
                <div className="flex items-center justify-between font-bold text-emerald-300">
                  <span>DISBURSEMENT COMPLETED SUCCESSFULLY</span>
                  <span>{formatCurrency(lastDisbursementResult.amount)}</span>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px] text-slate-300 pt-1">
                  <div>
                    <span className="text-slate-500 block text-[10px]">BENEFICIARIES</span>
                    <span>{lastDisbursementResult.recipients.toLocaleString()} Wallets</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">TOTAL BATCH LATENCY</span>
                    <span>{lastDisbursementResult.avgLatency}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">FAILED SETTLEMENTS</span>
                    <span className="text-emerald-400 font-bold">{lastDisbursementResult.failures}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">LEDGER BATCH</span>
                    <span>#{lastDisbursementResult.blockHeight}</span>
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 bg-[#050b16] p-3 border border-slate-800 rounded-xs space-y-1">
                <div className="text-slate-300 font-bold uppercase text-[10px]">Treasury Operational Advantages:</div>
                <p>
                  Zero float delay. Eliminates paper checks, postal theft, prepaid debit card predatory fees, and ACH 2-day delays. Funds arrive instantly in citizen digital wallets and are spendable immediately.
                </p>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-slate-500">
              No recent fiscal disbursement batch executed in this session. Configure and execute a disbursement above.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
