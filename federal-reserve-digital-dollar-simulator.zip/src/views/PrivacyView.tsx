import React, { useState } from 'react';
import {
  EyeOff,
  Eye,
  ShieldCheck,
  Lock,
  FileCheck,
  Scale,
  Users,
  Building,
  Key
} from 'lucide-react';

type PrivacyModelId = 'MODEL_TRANSPARENT' | 'MODEL_INTERMEDIATED' | 'MODEL_ZKP' | 'MODEL_TIERED';

export const PrivacyView: React.FC = () => {
  const [selectedModel, setSelectedModel] = useState<PrivacyModelId>('MODEL_TIERED');

  const models = [
    {
      id: 'MODEL_TIERED',
      name: 'Tiered Regulatory Privacy Model (Recommended Research Model)',
      desc: 'Cash-like anonymity for micropayments (<$200); bank-isolated privacy for retail (<$10k); full BSA/AML for wholesale.',
    },
    {
      id: 'MODEL_INTERMEDIATED',
      name: 'Bank-Intermediated Commercial Privacy',
      desc: 'Commercial banks hold identity mappings; Federal Reserve central core sees only pseudonymized ledger tokens.',
    },
    {
      id: 'MODEL_ZKP',
      name: 'Cryptographic Zero-Knowledge Privacy',
      desc: 'Amounts and identities blinded by zk-SNARKs with auditable cryptographic viewing keys for certified court orders.',
    },
    {
      id: 'MODEL_TRANSPARENT',
      name: 'Fully Transparent Public Ledger (Cryptocurrency Benchmark)',
      desc: 'All wallet addresses, transaction amounts, and balances publicly visible across network nodes.',
    },
  ];

  // Viewer vs Data Field visibility for current selected model
  const matrixData: {
    viewer: string;
    role: string;
    consumerId: string;
    merchantId: string;
    amount: string;
    timestamp: string;
    history: string;
  }[] = selectedModel === 'MODEL_TIERED' ? [
    { viewer: 'Public', role: 'External Observer', consumerId: 'Hidden', merchantId: 'Hidden', amount: 'Hidden', timestamp: 'Public', history: 'Hidden' },
    { viewer: 'Commercial Intermediary', role: 'Customer Onboarder', consumerId: 'Visible (KYC)', merchantId: 'Visible', amount: 'Visible', timestamp: 'Visible', history: 'Customer Only' },
    { viewer: 'Federal Reserve Core', role: 'Central Bank Ledger', consumerId: 'Blinded Hash', merchantId: 'Blinded Hash', amount: 'Aggregated / Obfuscated', timestamp: 'Visible', history: 'Token Graph Only' },
    { viewer: 'FinCEN / Regulator', role: 'BSA / AML Compliance', consumerId: 'Visible if >$10k', merchantId: 'Visible if >$10k', amount: 'Visible', timestamp: 'Visible', history: 'Suspicious Filter' },
    { viewer: 'Law Enforcement', role: 'Judicial Process', consumerId: 'Warrant Required', merchantId: 'Warrant Required', amount: 'Warrant Required', timestamp: 'Visible', history: 'Subpoena Bound' },
    { viewer: 'Independent Auditor', role: 'Inspector General / GAO', consumerId: 'Synthetic Sample', merchantId: 'Synthetic Sample', amount: 'Cryptographic Proof', timestamp: 'Visible', history: 'Audit Trails' },
  ] : selectedModel === 'MODEL_ZKP' ? [
    { viewer: 'Public', role: 'External Observer', consumerId: 'Hidden', merchantId: 'Hidden', amount: 'Hidden', timestamp: 'Public', history: 'Hidden' },
    { viewer: 'Commercial Intermediary', role: 'Customer Onboarder', consumerId: 'Visible (KYC)', merchantId: 'Visible', amount: 'Zk-Proof Verified', timestamp: 'Visible', history: 'Hidden' },
    { viewer: 'Federal Reserve Core', role: 'Central Bank Ledger', consumerId: 'Hidden (zk)', merchantId: 'Hidden (zk)', amount: 'Hidden (zk)', timestamp: 'Visible', history: 'Hidden' },
    { viewer: 'FinCEN / Regulator', role: 'BSA / AML Compliance', consumerId: 'Viewing Key Only', merchantId: 'Viewing Key Only', amount: 'Viewing Key Only', timestamp: 'Visible', history: 'Viewing Key' },
    { viewer: 'Law Enforcement', role: 'Judicial Process', consumerId: 'Viewing Key (Warrant)', merchantId: 'Viewing Key (Warrant)', amount: 'Viewing Key (Warrant)', timestamp: 'Visible', history: 'Viewing Key' },
    { viewer: 'Independent Auditor', role: 'Inspector General / GAO', consumerId: 'Hidden', merchantId: 'Hidden', amount: 'Zk Mathematical Proof', timestamp: 'Visible', history: 'Zk Math' },
  ] : selectedModel === 'MODEL_INTERMEDIATED' ? [
    { viewer: 'Public', role: 'External Observer', consumerId: 'Hidden', merchantId: 'Hidden', amount: 'Hidden', timestamp: 'Public', history: 'Hidden' },
    { viewer: 'Commercial Intermediary', role: 'Customer Onboarder', consumerId: 'Visible', merchantId: 'Visible', amount: 'Visible', timestamp: 'Visible', history: 'Full Bank Record' },
    { viewer: 'Federal Reserve Core', role: 'Central Bank Ledger', consumerId: 'Pseudonymous ID', merchantId: 'Pseudonymous ID', amount: 'Visible', timestamp: 'Visible', history: 'Pseudonymous Graph' },
    { viewer: 'FinCEN / Regulator', role: 'BSA / AML Compliance', consumerId: 'Bank SAR Filing', merchantId: 'Bank SAR Filing', amount: 'Visible', timestamp: 'Visible', history: 'SAR Reports' },
    { viewer: 'Law Enforcement', role: 'Judicial Process', consumerId: 'Subpoena to Bank', merchantId: 'Subpoena to Bank', amount: 'Subpoena to Bank', timestamp: 'Visible', history: 'Bank Records' },
    { viewer: 'Independent Auditor', role: 'Inspector General / GAO', consumerId: 'Sample Audit', merchantId: 'Sample Audit', amount: 'Visible', timestamp: 'Visible', history: 'Sample Audit' },
  ] : [
    { viewer: 'Public', role: 'External Observer', consumerId: 'Pseudonymous ID', merchantId: 'Pseudonymous ID', amount: 'Visible', timestamp: 'Visible', history: 'Complete Trace' },
    { viewer: 'Commercial Intermediary', role: 'Customer Onboarder', consumerId: 'Visible', merchantId: 'Visible', amount: 'Visible', timestamp: 'Visible', history: 'Complete Trace' },
    { viewer: 'Federal Reserve Core', role: 'Central Bank Ledger', consumerId: 'Visible', merchantId: 'Visible', amount: 'Visible', timestamp: 'Visible', history: 'Complete Trace' },
    { viewer: 'FinCEN / Regulator', role: 'BSA / AML Compliance', consumerId: 'Visible', merchantId: 'Visible', amount: 'Visible', timestamp: 'Visible', history: 'Complete Trace' },
    { viewer: 'Law Enforcement', role: 'Judicial Process', consumerId: 'Visible', merchantId: 'Visible', amount: 'Visible', timestamp: 'Visible', history: 'Complete Trace' },
    { viewer: 'Independent Auditor', role: 'Inspector General / GAO', consumerId: 'Visible', merchantId: 'Visible', amount: 'Visible', timestamp: 'Visible', history: 'Complete Trace' },
  ];

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <EyeOff className="w-5 h-5 text-blue-400" />
              PRIVACY &amp; IDENTITY MATRIX LAB
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              BSA/AML &amp; 4TH AMENDMENT SURVEILLANCE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Model Privacy Preserving Cryptography vs. Bank Secrecy Act &amp; Financial Crimes Compliance
          </p>
        </div>

        {/* Model Tabs */}
        <div className="flex flex-wrap items-center gap-1 bg-[#0b1626] p-1 border border-slate-800 rounded-xs text-xs font-mono">
          {models.map(m => (
            <button
              key={m.id}
              onClick={() => setSelectedModel(m.id as any)}
              className={`px-2.5 py-1 rounded-xs transition-colors font-semibold text-[11px] ${
                selectedModel === m.id ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              {m.name.split(' ')[0]} {m.name.split(' ')[1]}
            </button>
          ))}
        </div>
      </div>

      {/* Model Description */}
      <div className="p-3 bg-[#0a1526] border border-blue-900/60 rounded-xs text-xs font-mono text-slate-300 flex items-center justify-between">
        <div>
          <span className="text-white font-bold block">{models.find(m => m.id === selectedModel)?.name}</span>
          <span className="text-slate-400 text-[11px]">{models.find(m => m.id === selectedModel)?.desc}</span>
        </div>
        <span className="text-blue-400 font-mono text-[10px] bg-blue-950 border border-blue-800 px-2 py-0.5 rounded-xs shrink-0 ml-3">
          4TH AMENDMENT COMPLIANT
        </span>
      </div>

      {/* Full Surveillance & Visibility Matrix Table */}
      <div className="bg-[#091322] border border-slate-800 rounded-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#060c18] border-b border-slate-800 text-[10px] text-slate-400 uppercase tracking-wider">
              <tr>
                <th className="py-2 px-3">STAKEHOLDER / VIEWER</th>
                <th className="py-2 px-3">INSTITUTIONAL ROLE</th>
                <th className="py-2 px-3">CONSUMER IDENTITY</th>
                <th className="py-2 px-3">MERCHANT IDENTITY</th>
                <th className="py-2 px-3">TRANSACTION AMOUNT</th>
                <th className="py-2 px-3">TIMESTAMP</th>
                <th className="py-2 px-3">TRANSACTION GRAPH</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {matrixData.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-white flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-blue-400" />
                    {row.viewer}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400">{row.role}</td>
                  <td className="py-2.5 px-3">
                    <span className={`px-1.5 py-0.5 rounded-xs font-semibold ${
                      row.consumerId.includes('Hidden') ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800' :
                      row.consumerId.includes('Warrant') ? 'bg-amber-950/60 text-amber-300 border border-amber-800' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {row.consumerId}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className={`px-1.5 py-0.5 rounded-xs font-semibold ${
                      row.merchantId.includes('Hidden') ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800' :
                      row.merchantId.includes('Warrant') ? 'bg-amber-950/60 text-amber-300 border border-amber-800' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {row.merchantId}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-slate-200">{row.amount}</td>
                  <td className="py-2.5 px-3 text-slate-400">{row.timestamp}</td>
                  <td className="py-2.5 px-3 text-slate-300">{row.history}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3-Tier Threshold Policy Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-xs">
        <div className="bg-[#0b1628] border border-slate-800 p-3 rounded-xs space-y-1">
          <div className="flex items-center justify-between text-emerald-400 font-bold">
            <span>TIER 1: MICROPAYMENTS</span>
            <span>&lt; $200.00</span>
          </div>
          <p className="text-slate-300 text-[11px]">
            Cash-equivalent anonymity. No personal identity recorded on ledger or shared with merchant. Zero-knowledge cryptographic tokens.
          </p>
        </div>

        <div className="bg-[#0b1628] border border-slate-800 p-3 rounded-xs space-y-1">
          <div className="flex items-center justify-between text-blue-400 font-bold">
            <span>TIER 2: RETAIL COMMERCE</span>
            <span>$200 - $10,000</span>
          </div>
          <p className="text-slate-300 text-[11px]">
            Commercial bank KYC/AML onboarding. Bank holds identity record; Federal Reserve core processes pseudonymized transactions.
          </p>
        </div>

        <div className="bg-[#0b1628] border border-slate-800 p-3 rounded-xs space-y-1">
          <div className="flex items-center justify-between text-amber-400 font-bold">
            <span>TIER 3: WHOLESALE &amp; LARGE</span>
            <span>&gt; $10,000.00</span>
          </div>
          <p className="text-slate-300 text-[11px]">
            Full Bank Secrecy Act (BSA), Currency Transaction Reporting (CTR), and Suspicious Activity Monitoring (SAR) compliance.
          </p>
        </div>
      </div>
    </div>
  );
};
