import React, { useState } from 'react';
import {
  Network,
  Building,
  Landmark,
  Wallet,
  Store,
  Layers,
  Globe2,
  WifiOff,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Info
} from 'lucide-react';

type ArchitectureMode = 'TWO_TIER' | 'DIRECT' | 'HYBRID' | 'CROSS_BORDER' | 'OFFLINE_EDGE';

export const TopologyView: React.FC = () => {
  const [activeModel, setActiveModel] = useState<ArchitectureMode>('TWO_TIER');
  const [selectedNode, setSelectedNode] = useState<string | null>('FED_CORE');

  const models: { id: ArchitectureMode; label: string; desc: string }[] = [
    { id: 'TWO_TIER', label: 'Two-Tier Intermediated (Fed Baseline)', desc: 'Commercial banks handle KYC/AML and onboarding; Fed maintains non-custodial root liabilities.' },
    { id: 'DIRECT', label: 'Direct Model (Theoretical)', desc: 'Federal Reserve maintains accounts directly for 330M citizens (studied as theoretical benchmark).' },
    { id: 'HYBRID', label: 'Hybrid Model', desc: 'Intermediaries process retail payments, backed by pooled or segregated central bank reserve claims.' },
    { id: 'CROSS_BORDER', label: 'Cross-Border mCBDC', desc: 'Interlinked wholesale corridor connecting Federal Reserve DUSD with ECB (EUR), BOJ (JPY), and BOE (GBP).' },
    { id: 'OFFLINE_EDGE', label: 'Offline-Enabled Edge Model', desc: 'Device-to-device peer transfer over secure hardware enclaves with cryptographic tamper-resistance.' },
  ];

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <Network className="w-5 h-5 text-blue-400" />
              PAYMENTS TOPOLOGY &amp; ARCHITECTURAL FLOW ENGINE
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              STRUCTURAL DESIGN LAB
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Compare Central Bank Liabilities, Intermediary Routing, and Payment Flow Models
          </p>
        </div>

        {/* Model Selector Tabs */}
        <div className="flex flex-wrap items-center gap-1 bg-[#0b1626] p-1 border border-slate-800 rounded-xs text-xs font-mono">
          {models.map(m => (
            <button
              key={m.id}
              onClick={() => setActiveModel(m.id)}
              className={`px-2.5 py-1 rounded-xs transition-colors font-semibold text-[11px] ${
                activeModel === m.id ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* Model Description Banner */}
      <div className="p-3 bg-[#0a1526] border border-blue-900/60 rounded-xs text-xs font-mono flex items-center justify-between text-slate-300">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-blue-400 shrink-0" />
          <span>{models.find(m => m.id === activeModel)?.desc}</span>
        </div>
        <span className="text-emerald-400 text-[10px] bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded-xs">
          ACTIVE ARCHITECTURE
        </span>
      </div>

      {/* Interactive Topology Diagram Canvas */}
      <div className="bg-[#070e1a] border border-slate-800 rounded-xs p-6 relative overflow-hidden min-h-[460px] flex flex-col justify-between">
        {/* Animated flow background grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b10_1px,transparent_1px),linear-gradient(to_bottom,#1e293b10_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

        {/* Top Tier: Central Bank & Treasury */}
        <div className="flex justify-center items-center gap-12 relative z-10">
          <div
            onClick={() => setSelectedNode('TREASURY')}
            className={`cursor-pointer p-3.5 bg-[#0e1d35] border rounded-xs transition-all w-64 text-center font-mono text-xs ${
              selectedNode === 'TREASURY' ? 'border-amber-400 shadow-lg shadow-amber-950/40' : 'border-slate-700 hover:border-slate-500'
            }`}
          >
            <Landmark className="w-5 h-5 text-amber-400 mx-auto mb-1" />
            <div className="font-bold text-white uppercase">U.S. TREASURY (TGA)</div>
            <div className="text-[10px] text-slate-400">Fiscal Disbursements &amp; Debt Ops</div>
          </div>

          <div
            onClick={() => setSelectedNode('FED_CORE')}
            className={`cursor-pointer p-4 bg-[#0e1f3c] border-2 rounded-xs transition-all w-80 text-center font-mono text-xs ${
              selectedNode === 'FED_CORE' ? 'border-blue-400 shadow-xl shadow-blue-950/60 ring-2 ring-blue-500/20' : 'border-blue-700 hover:border-blue-400'
            }`}
          >
            <div className="w-3 h-3 rounded-full bg-emerald-400 mx-auto mb-1 animate-ping" />
            <div className="font-extrabold text-white uppercase text-sm">FEDERAL RESERVE CORE LEDGER</div>
            <div className="text-[11px] text-blue-300">Central Bank Direct Liabilities ($2.84T)</div>
            <div className="text-[9px] text-slate-400 mt-0.5">PBFT High-Throughput RTGS • 0.42s Finality</div>
          </div>

          {activeModel === 'CROSS_BORDER' && (
            <div
              onClick={() => setSelectedNode('MCBDC_HUB')}
              className="cursor-pointer p-3.5 bg-[#0e1d35] border border-cyan-500 rounded-xs w-64 text-center font-mono text-xs shadow-lg shadow-cyan-950/40"
            >
              <Globe2 className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
              <div className="font-bold text-white uppercase">mCBDC SETTLEMENT CORRIDOR</div>
              <div className="text-[10px] text-cyan-300">Atomic PvP vs. EUR, JPY, GBP</div>
            </div>
          )}
        </div>

        {/* Dynamic Connectors / Vectors */}
        <div className="my-6 flex justify-around items-center text-[10px] font-mono text-slate-500 relative z-10 px-8">
          <div className="flex flex-col items-center">
            <span className="text-blue-400">ISO 20022 Financial Messages</span>
            <div className="h-8 w-0.5 bg-gradient-to-b from-blue-500 to-blue-800 animate-pulse" />
          </div>
          <div className="flex flex-col items-center">
            <span className="text-emerald-400">Direct RTGS Liquidity Flow</span>
            <div className="h-8 w-0.5 bg-gradient-to-b from-emerald-500 to-emerald-800 animate-pulse" />
          </div>
          <div className="flex flex-col items-center">
            <span className="text-amber-400">Reserve Balance Debits/Credits</span>
            <div className="h-8 w-0.5 bg-gradient-to-b from-amber-500 to-amber-800 animate-pulse" />
          </div>
        </div>

        {/* Middle Tier: Intermediary Depository Institutions & Clearing Rails */}
        <div className="flex justify-around items-center gap-4 relative z-10">
          {activeModel === 'DIRECT' ? (
            <div className="p-3 bg-amber-950/40 border border-amber-800 text-amber-200 text-xs font-mono rounded-xs text-center w-full max-w-xl mx-auto">
              DIRECT MODEL BYPASS: Commercial banks are bypassed; Federal Reserve directly interfaces with consumer &amp; merchant wallets.
            </div>
          ) : (
            <>
              <div
                onClick={() => setSelectedNode('COMMERCIAL_BANKS')}
                className={`cursor-pointer p-3 bg-[#0a1729] border rounded-xs transition-all w-72 text-center font-mono text-xs ${
                  selectedNode === 'COMMERCIAL_BANKS' ? 'border-blue-400 shadow-md' : 'border-slate-800 hover:border-slate-600'
                }`}
              >
                <Building className="w-5 h-5 text-blue-400 mx-auto mb-1" />
                <div className="font-bold text-white uppercase">COMMERCIAL BANKS</div>
                <div className="text-[10px] text-slate-400">KYC/AML • Customer Support • Reserve Accounts</div>
              </div>

              <div
                onClick={() => setSelectedNode('PAYMENT_PSPS')}
                className={`cursor-pointer p-3 bg-[#0a1729] border rounded-xs transition-all w-72 text-center font-mono text-xs ${
                  selectedNode === 'PAYMENT_PSPS' ? 'border-blue-400 shadow-md' : 'border-slate-800 hover:border-slate-600'
                }`}
              >
                <Layers className="w-5 h-5 text-indigo-400 mx-auto mb-1" />
                <div className="font-bold text-white uppercase">AUTHORIZED PSPS &amp; RAILS</div>
                <div className="text-[10px] text-slate-400">FedNow • Fedwire • Card Gateway Interop</div>
              </div>
            </>
          )}
        </div>

        {/* Dynamic Connectors */}
        <div className="my-6 flex justify-around items-center text-[10px] font-mono text-slate-500 relative z-10 px-12">
          <div className="flex flex-col items-center">
            <span className="text-slate-400">Tokenized Wallet Sync</span>
            <div className="h-8 w-0.5 bg-slate-700" />
          </div>
          <div className="flex flex-col items-center">
            <span className="text-slate-400">Merchant Point-of-Sale Finality</span>
            <div className="h-8 w-0.5 bg-slate-700" />
          </div>
        </div>

        {/* Bottom Tier: End Users, Merchants & Offline Enclaves */}
        <div className="flex justify-around items-center gap-4 relative z-10">
          <div
            onClick={() => setSelectedNode('CONSUMER_WALLETS')}
            className={`cursor-pointer p-3 bg-[#091322] border rounded-xs transition-all w-64 text-center font-mono text-xs ${
              selectedNode === 'CONSUMER_WALLETS' ? 'border-blue-400 shadow-md' : 'border-slate-800 hover:border-slate-600'
            }`}
          >
            <Wallet className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
            <div className="font-bold text-white uppercase">CONSUMER WALLETS (184.7M)</div>
            <div className="text-[10px] text-slate-400">James Carter &amp; Retail Users</div>
          </div>

          <div
            onClick={() => setSelectedNode('MERCHANTS')}
            className={`cursor-pointer p-3 bg-[#091322] border rounded-xs transition-all w-64 text-center font-mono text-xs ${
              selectedNode === 'MERCHANTS' ? 'border-blue-400 shadow-md' : 'border-slate-800 hover:border-slate-600'
            }`}
          >
            <Store className="w-5 h-5 text-purple-400 mx-auto mb-1" />
            <div className="font-bold text-white uppercase">MERCHANTS &amp; ENTERPRISE</div>
            <div className="text-[10px] text-slate-400">Instant Finality • Zero Interchange</div>
          </div>

          {activeModel === 'OFFLINE_EDGE' && (
            <div
              onClick={() => setSelectedNode('OFFLINE_ENCLAVE')}
              className="cursor-pointer p-3 bg-[#131b2b] border border-amber-500 rounded-xs w-64 text-center font-mono text-xs shadow-md shadow-amber-950/30"
            >
              <WifiOff className="w-5 h-5 text-amber-400 mx-auto mb-1" />
              <div className="font-bold text-white uppercase">OFFLINE HARDWARE ENCLAVE</div>
              <div className="text-[10px] text-amber-300">P2P Device NFC ($750 Cap)</div>
            </div>
          )}
        </div>
      </div>

      {/* Node Inspector Box */}
      <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs font-mono text-xs space-y-2">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <span className="font-bold text-white uppercase flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-blue-400" />
            NODE INSPECTOR: {selectedNode}
          </span>
          <span className="text-[10px] text-emerald-400">STATUS: HEALTHY • CONCURRENCY: OPTIMAL</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-slate-300 text-[11px]">
          <div>
            <span className="text-slate-500 block text-[10px]">LEGAL OBLIGATION:</span>
            <span>Direct sovereign liability of the U.S. Federal Reserve. Free of commercial bank default risk.</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">CLEARING PROTOCOL:</span>
            <span>ISO 20022 messaging schema with instant cryptographic finality confirmation.</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">INTERMEDIATION ROLE:</span>
            <span>Two-tier model ensures private banking preserves customer relationship and underwriting.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
