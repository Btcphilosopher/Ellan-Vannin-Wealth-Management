import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  Wallet as WalletIcon,
  ShieldCheck,
  Send,
  Building,
  WifiOff,
  Sliders,
  CheckCircle2,
  Lock,
  History,
  CreditCard,
  UserCheck
} from 'lucide-react';
import { Wallet, WalletCategory } from '../types';

export const WalletsView: React.FC = () => {
  const {
    wallets,
    transferWalletDusd,
    convertDepositToDusd,
    banks,
    transactions,
  } = useSimulator();

  const [selectedWalletId, setSelectedWalletId] = useState<string>('WLT-JC-7419'); // Default: James Carter
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [transferAmount, setTransferAmount] = useState<number>(250);
  const [recipientWalletId, setRecipientWalletId] = useState<string>('WLT-ELENA-RODRIGUEZ');
  const [transferMemo, setTransferMemo] = useState<string>('Peer-to-Peer DUSD transfer');
  const [transferFeedback, setTransferFeedback] = useState<string | null>(null);

  const selectedWallet = wallets.find(w => w.id === selectedWalletId) || wallets[0];
  const recipientWallet = wallets.find(w => w.id === recipientWalletId) || wallets[1];

  const filteredWallets = wallets.filter(w => {
    if (activeCategory === 'ALL') return true;
    return w.category === activeCategory;
  });

  const walletTransactions = transactions.filter(
    t => t.originator === selectedWallet.id || t.beneficiary === selectedWallet.id
  );

  const handleSendDusd = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedWallet.id === recipientWalletId) {
      alert('Sender and recipient wallet cannot be the same.');
      return;
    }
    try {
      transferWalletDusd(transferAmount, selectedWallet.id, recipientWalletId, transferMemo);
      setTransferFeedback(`Transferred ${formatCurrency(transferAmount)} DUSD to ${recipientWallet.ownerName} with immediate atomic finality.`);
      setTimeout(() => setTransferFeedback(null), 5000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleQuickConvert = () => {
    try {
      convertDepositToDusd(500, selectedWallet.intermediaryId, selectedWallet.id);
      setTransferFeedback(`Converted $500.00 Commercial Bank Deposit into ${selectedWallet.ownerName}'s DUSD Wallet via ${selectedWallet.intermediaryName}.`);
      setTimeout(() => setTransferFeedback(null), 5000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <WalletIcon className="w-5 h-5 text-blue-400" />
              INTERMEDIATED DIGITAL DOLLAR WALLET MANAGEMENT
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950/80 border border-blue-700/60 text-blue-300 rounded-xs font-semibold">
              TWO-TIER ARCHITECTURE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Customer Onboarding via Regulated Commercial Intermediaries • Non-Custodial Core Liabilities • Hardware Enclave Custody
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1 bg-[#0b1626] p-1 border border-slate-800 rounded-xs text-xs font-mono">
          {['ALL', 'CONSUMER', 'MERCHANT', 'BUSINESS', 'INSTITUTIONAL', 'GOVERNMENT'].map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-2 py-1 rounded-xs transition-colors font-semibold text-[10px] ${
                activeCategory === cat ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {transferFeedback && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-600/70 text-emerald-200 text-xs font-mono rounded-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{transferFeedback}</span>
        </div>
      )}

      {/* Main Grid: Wallet Selector (Left) & Detailed Realistic Screen (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Wallet List (5 cols) */}
        <div className="lg:col-span-5 space-y-2">
          <div className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider px-1">
            VERIFIED WALLET REGISTRY ({filteredWallets.length})
          </div>
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {filteredWallets.map(w => {
              const isSelected = w.id === selectedWallet.id;
              return (
                <div
                  key={w.id}
                  onClick={() => setSelectedWalletId(w.id)}
                  className={`p-3 rounded-xs border transition-all cursor-pointer text-xs font-mono ${
                    isSelected
                      ? 'bg-[#0f223f] border-blue-500 shadow-md'
                      : 'bg-[#091322] border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span className="text-white truncate max-w-[180px]">{w.ownerName}</span>
                    <span className="text-emerald-400 tabular-nums">{formatCurrency(w.dusdBalance)}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
                    <span className="truncate">{w.intermediaryName}</span>
                    <span className="text-[10px] px-1.5 py-0.2 bg-slate-800 rounded-xs text-slate-300">
                      {w.category}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Detailed Wallet Workstation Screen (7 cols) - Emphasizes Prompt's James Carter example */}
        <div className="lg:col-span-7 space-y-3">
          {/* Institutional Electronic Wallet Card */}
          <div className="bg-[#0c1a30] border border-blue-900/60 p-4 rounded-xs shadow-md space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xs bg-blue-600/30 border border-blue-500 flex items-center justify-center text-blue-300 font-bold">
                  {selectedWallet.ownerName.charAt(0)}
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-mono tracking-tight">
                    {selectedWallet.ownerName}
                  </h3>
                  <div className="text-[11px] text-slate-400 font-mono">
                    Digital Dollar Wallet ID: <span className="text-slate-300 font-semibold">{selectedWallet.id}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono font-semibold px-2 py-0.5 bg-emerald-950/70 border border-emerald-700/60 text-emerald-300 rounded-xs flex items-center gap-1">
                  <UserCheck className="w-3 h-3" />
                  {selectedWallet.identityStatus}
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 bg-blue-950 border border-blue-800 text-blue-300 rounded-xs">
                  {selectedWallet.category}
                </span>
              </div>
            </div>

            {/* Balances & Allowances */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 font-mono text-xs">
              <div className="bg-[#07101f] p-2.5 border border-slate-800 rounded-xs">
                <span className="text-slate-500 text-[10px] block">AVAILABLE DUSD</span>
                <span className="text-xl font-bold text-white tabular-nums">
                  {formatCurrency(selectedWallet.dusdBalance)}
                </span>
              </div>
              <div className="bg-[#07101f] p-2.5 border border-slate-800 rounded-xs">
                <span className="text-slate-500 text-[10px] block">OFFLINE ALLOWANCE</span>
                <span className="text-lg font-bold text-amber-300 tabular-nums">
                  {formatCurrency(selectedWallet.offlineAllowance)}
                </span>
                <span className="text-[9px] text-slate-500 block">Available: {formatCurrency(selectedWallet.offlineAvailable)}</span>
              </div>
              <div className="bg-[#07101f] p-2.5 border border-slate-800 rounded-xs">
                <span className="text-slate-500 text-[10px] block">DAILY TRANSFER LIMIT</span>
                <span className="text-lg font-bold text-slate-200 tabular-nums">
                  {formatCurrency(selectedWallet.dailyTransferLimit)}
                </span>
                <span className="text-[9px] text-slate-500 block">Used: {formatCurrency(selectedWallet.dailyTransferredToday)}</span>
              </div>
              <div className="bg-[#07101f] p-2.5 border border-slate-800 rounded-xs">
                <span className="text-slate-500 text-[10px] block">INTERMEDIARY</span>
                <span className="text-xs font-bold text-blue-400 block truncate" title={selectedWallet.intermediaryName}>
                  {selectedWallet.intermediaryName}
                </span>
                <span className="text-[9px] text-slate-500 block">Regulated Agent</span>
              </div>
            </div>

            {/* Hardware Enclave & Security Status */}
            <div className="bg-[#07101f] p-3 border border-slate-800 rounded-xs grid grid-cols-3 gap-2 text-[11px] font-mono">
              <div>
                <span className="text-slate-500 text-[10px] block">SECURITY ENCLAVE</span>
                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  {selectedWallet.securityStatus.replace(/_/g, ' ')}
                </span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">PRIVACY CLASS</span>
                <span className="text-blue-300 font-semibold">
                  {selectedWallet.privacyTier.replace(/_/g, ' ')}
                </span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] block">PROGRAMMABLE RULES</span>
                <span className="text-white font-semibold">{selectedWallet.programmableRulesCount} Active Policies</span>
              </div>
            </div>

            {/* Quick Actions: Transfer & Deposit Conversion */}
            <div className="pt-2 border-t border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs font-mono font-bold text-slate-300">
                <span>INSTANT DIRECT DUSD TRANSFER</span>
                <button
                  type="button"
                  onClick={handleQuickConvert}
                  className="text-blue-400 hover:text-blue-300 underline font-normal text-[11px]"
                >
                  + Convert $500 Deposit to DUSD
                </button>
              </div>

              <form onSubmit={handleSendDusd} className="grid grid-cols-1 md:grid-cols-3 gap-2 font-mono text-xs">
                <div>
                  <label className="text-slate-500 text-[10px] block mb-1">RECIPIENT WALLET</label>
                  <select
                    value={recipientWalletId}
                    onChange={(e) => setRecipientWalletId(e.target.value)}
                    className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2 py-1.5 text-slate-200"
                  >
                    {wallets.filter(w => w.id !== selectedWallet.id).map(w => (
                      <option key={w.id} value={w.id}>
                        {w.ownerName} ({w.category})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-500 text-[10px] block mb-1">AMOUNT (DUSD)</label>
                  <input
                    type="number"
                    min="1"
                    step="10"
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(Number(e.target.value))}
                    className="w-full bg-[#050b16] border border-slate-700 rounded-xs px-2 py-1.5 text-white font-bold"
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <Send className="w-3.5 h-3.5" />
                    DISPATCH DUSD
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Wallet Transaction History */}
          <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs space-y-2">
            <h4 className="text-xs font-mono font-bold text-slate-300 uppercase flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-slate-400" />
              WALLET SETTLEMENT HISTORY ({walletTransactions.length})
            </h4>

            <div className="space-y-1.5">
              {walletTransactions.length === 0 ? (
                <div className="text-xs font-mono text-slate-500 py-3 text-center">
                  No direct transactions recorded for this wallet in current session snapshot.
                </div>
              ) : (
                walletTransactions.slice(0, 4).map(tx => (
                  <div key={tx.id} className="p-2 bg-[#060c18] border border-slate-800 rounded-xs flex items-center justify-between text-xs font-mono">
                    <div>
                      <div className="text-slate-200 font-semibold">{tx.memo || 'Digital Dollar Settlement'}</div>
                      <div className="text-[10px] text-slate-500">
                        {tx.timestamp.slice(11, 19)} • Rail: {tx.settlementRail.replace('_SERVICE', '')} • Ref: {tx.id}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`font-bold tabular-nums ${
                        tx.beneficiary === selectedWallet.id ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {tx.beneficiary === selectedWallet.id ? '+' : '-'}{formatCurrency(tx.amount)}
                      </div>
                      <span className="text-[9px] text-emerald-400">{tx.status}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
