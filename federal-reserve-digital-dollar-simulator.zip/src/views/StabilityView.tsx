import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import { formatCurrency } from '../utils/formatters';
import {
  ShieldAlert,
  AlertTriangle,
  Play,
  RotateCcw,
  Activity,
  Zap,
  Building,
  CheckCircle2,
  Lock,
  Layers,
  Flame
} from 'lucide-react';
import { ScenarioType } from '../types';

export const StabilityView: React.FC = () => {
  const { applyScenario, monetaryPolicy, banks } = useSimulator();
  const activeScenario = monetaryPolicy.scenarioName;
  const [circuitBreakerActive, setCircuitBreakerActive] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleTriggerScenario = (sc: ScenarioType, label: string) => {
    applyScenario(sc);
    setStatusMessage(`STRESS PROTOCOL ACTIVATED: ${label}. Fed Discount Window & Standing Repo Facility primed.`);
    setTimeout(() => setStatusMessage(null), 6000);
  };

  const toggleCircuitBreaker = () => {
    setCircuitBreakerActive(!circuitBreakerActive);
    setStatusMessage(
      !circuitBreakerActive 
        ? 'CIRCUIT BREAKER ENGAGED: Hourly DUSD conversion capped at $1,000/wallet to halt deposit run.' 
        : 'CIRCUIT BREAKER RELEASED: Normal conversion limits restored.'
    );
    setTimeout(() => setStatusMessage(null), 5000);
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-400" />
              FINANCIAL STABILITY &amp; SYSTEMIC STRESS TESTING
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-rose-950/80 border border-rose-700/60 text-rose-300 rounded-xs font-semibold">
              CRISIS SIMULATION LAB
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Evaluate Contagion Dynamics, Liquidity Freezes, Cyber Intermediation Outages &amp; Emergency Backstops
          </p>
        </div>

        <button
          onClick={toggleCircuitBreaker}
          className={`px-3 py-1.5 rounded-xs font-mono text-xs font-bold flex items-center gap-1.5 transition-colors ${
            circuitBreakerActive
              ? 'bg-rose-600 text-white animate-pulse'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          {circuitBreakerActive ? 'CIRCUIT BREAKER: ACTIVE' : 'ENGAGE CIRCUIT BREAKER'}
        </button>
      </div>

      {statusMessage && (
        <div className="p-3 bg-rose-950/60 border border-rose-600 text-rose-200 text-xs font-mono rounded-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* 5 Prominent Stress Scenarios */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 font-mono text-xs">
        {/* Scenario A */}
        <div className="bg-[#091322] border border-rose-900/50 p-3.5 rounded-xs space-y-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-rose-400 mb-1">
              <span className="text-[10px] font-bold uppercase">SCENARIO A: LIQUIDITY RUN</span>
              <Flame className="w-4 h-4 text-rose-500" />
            </div>
            <h3 className="font-bold text-white text-xs">Sudden 400% Bank Deposit Flight</h3>
            <p className="text-[11px] text-slate-400 mt-1">
              Retail depositors rapidly convert $45B in commercial checking balances to DUSD within 48 hours.
            </p>
          </div>
          <button
            onClick={() => handleTriggerScenario('CBDC_RUN_SCENARIO', '400% Bank Deposit Run into DUSD')}
            className="w-full py-1.5 bg-rose-950/60 hover:bg-rose-900/80 border border-rose-800 text-rose-200 font-bold rounded-xs flex items-center justify-center gap-1 mt-2"
          >
            <Play className="w-3 h-3" />
            SIMULATE DEPOSIT RUN
          </button>
        </div>

        {/* Scenario B */}
        <div className="bg-[#091322] border border-amber-900/50 p-3.5 rounded-xs space-y-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-amber-400 mb-1">
              <span className="text-[10px] font-bold uppercase">SCENARIO B: INTERBANK FREEZE</span>
              <AlertTriangle className="w-4 h-4 text-amber-500" />
            </div>
            <h3 className="font-bold text-white text-xs">Overnight Repo Collateral Gridlock</h3>
            <p className="text-[11px] text-slate-400 mt-1">
              Unsecured interbank lending spreads spike 180 bps; Fed Standing Repo Facility (SRF) activates.
            </p>
          </div>
          <button
            onClick={() => handleTriggerScenario('BANKING_STRESS', 'Interbank Repo Liquidity Freeze')}
            className="w-full py-1.5 bg-amber-950/60 hover:bg-amber-900/80 border border-amber-800 text-amber-200 font-bold rounded-xs flex items-center justify-center gap-1 mt-2"
          >
            <Play className="w-3 h-3" />
            TRIGGER LIQUIDITY SHOCK
          </button>
        </div>

        {/* Scenario C */}
        <div className="bg-[#091322] border border-blue-900/50 p-3.5 rounded-xs space-y-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-cyan-400 mb-1">
              <span className="text-[10px] font-bold uppercase">SCENARIO C: CYBER OUTAGE</span>
              <Activity className="w-4 h-4 text-cyan-500" />
            </div>
            <h3 className="font-bold text-white text-xs">Major Intermediary Bank Isolated</h3>
            <p className="text-[11px] text-slate-400 mt-1">
              One Tier-1 intermediary network is severed; Fed automated bypass rails reroute customer DUSD balances.
            </p>
          </div>
          <button
            onClick={() => handleTriggerScenario('BANKING_STRESS', 'Cyber Isolation at Major Intermediary Bank')}
            className="w-full py-1.5 bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-800 text-cyan-200 font-bold rounded-xs flex items-center justify-center gap-1 mt-2"
          >
            <Play className="w-3 h-3" />
            ISOLATE INTERMEDIARY
          </button>
        </div>

        {/* Scenario D */}
        <div className="bg-[#091322] border border-blue-900/50 p-3.5 rounded-xs space-y-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-indigo-400 mb-1">
              <span className="text-[10px] font-bold uppercase">SCENARIO D: CROSS-BORDER SURGE</span>
              <Layers className="w-4 h-4 text-indigo-500" />
            </div>
            <h3 className="font-bold text-white text-xs">Foreign Capital Flight into DUSD</h3>
            <p className="text-[11px] text-slate-400 mt-1">
              Emerging market distress causes $50B flight to quality; Fed central bank swap lines expand.
            </p>
          </div>
          <button
            onClick={() => handleTriggerScenario('HIGH_ADOPTION', 'Cross-Border DUSD Flight')}
            className="w-full py-1.5 bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-800 text-indigo-200 font-bold rounded-xs flex items-center justify-center gap-1 mt-2"
          >
            <Play className="w-3 h-3" />
            SIMULATE CAPITAL FLIGHT
          </button>
        </div>

        {/* Reset */}
        <div className="bg-[#091322] border border-slate-800 p-3.5 rounded-xs space-y-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="text-[10px] font-bold uppercase">BENCHMARK RESTORATION</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            </div>
            <h3 className="font-bold text-white text-xs">Restore Normal Steady-State</h3>
            <p className="text-[11px] text-slate-400 mt-1">
              Reset liquidity parameters, clear emergency credit lines, and normalize payment rail latency.
            </p>
          </div>
          <button
            onClick={() => handleTriggerScenario('BASELINE', 'Baseline System State')}
            className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold rounded-xs flex items-center justify-center gap-1 mt-2"
          >
            <RotateCcw className="w-3 h-3" />
            RESET TO BASELINE
          </button>
        </div>
      </div>

      {/* Real-time Emergency Facility Telemetry */}
      <div className="bg-[#060c18] border border-slate-800 p-4 rounded-xs font-mono text-xs space-y-3">
        <h3 className="text-white font-bold uppercase tracking-wider text-xs flex items-center gap-2">
          <Activity className="w-4 h-4 text-blue-400" />
          FEDERAL RESERVE EMERGENCY LIQUIDITY BACKSTOP SURVEILLANCE
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="bg-[#091322] p-2.5 border border-slate-800 rounded-xs">
            <span className="text-slate-500 text-[10px] block">DISCOUNT WINDOW (PRIMARY CREDIT)</span>
            <span className="text-lg font-bold text-white tabular-nums">$42.8B</span>
            <span className="text-[10px] text-emerald-400 block">Collateralized at 102%</span>
          </div>

          <div className="bg-[#091322] p-2.5 border border-slate-800 rounded-xs">
            <span className="text-slate-500 text-[10px] block">STANDING REPO FACILITY (SRF)</span>
            <span className="text-lg font-bold text-cyan-400 tabular-nums">$18.5B</span>
            <span className="text-[10px] text-slate-400 block">Treasury / Agency collateral</span>
          </div>

          <div className="bg-[#091322] p-2.5 border border-slate-800 rounded-xs">
            <span className="text-slate-500 text-[10px] block">CENTRAL BANK LIQUIDITY SWAPS</span>
            <span className="text-lg font-bold text-indigo-400 tabular-nums">$12.0B</span>
            <span className="text-[10px] text-slate-400 block">ECB &amp; BOJ Bilateral Lines</span>
          </div>

          <div className="bg-[#091322] p-2.5 border border-slate-800 rounded-xs">
            <span className="text-slate-500 text-[10px] block">ACTIVE CRISIS STATUS</span>
            <span className={`text-sm font-bold block ${activeScenario === 'BASELINE' ? 'text-emerald-400' : 'text-rose-400'}`}>
              {activeScenario}
            </span>
            <span className="text-[10px] text-slate-400 block">Surveillance: Continuous</span>
          </div>
        </div>
      </div>
    </div>
  );
};
