import React, { useState } from 'react';
import { useSimulator } from '../store/simulatorStore';
import {
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  Lock,
  Cpu,
  Radio,
  CheckCircle2,
  Terminal,
  Activity,
  KeyRound
} from 'lucide-react';
import { SecurityIncident } from '../types';

export const CybersecurityView: React.FC = () => {
  const { securityIncidents, resolveSecurityIncident } = useSimulator();
  const [selectedIncidentId, setSelectedIncidentId] = useState<string>(securityIncidents[0].id);
  const [socFeedback, setSocFeedback] = useState<string | null>(null);

  const selectedIncident = securityIncidents.find(i => i.id === selectedIncidentId) || securityIncidents[0];

  const handleMitigate = (incidentId: string) => {
    resolveSecurityIncident(incidentId);
    setSocFeedback(`Security incident ${incidentId} mitigated: Rate limiting enforced on bridge, cryptographic ledger hashes verified clean.`);
    setTimeout(() => setSocFeedback(null), 5000);
  };

  return (
    <div className="space-y-4 font-['Public_Sans',sans-serif]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              CENTRAL BANK CYBERSECURITY OPERATIONS CENTER (SOC)
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 rounded-xs font-semibold">
              FIPS 140-3 LEVEL 4 ACTIVE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Post-Quantum Cryptography Readiness • Hardware Security Module (HSM) Fleet • Real-Time Anomaly Surveillance
          </p>
        </div>
      </div>

      {socFeedback && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-600/70 text-emerald-200 text-xs font-mono rounded-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{socFeedback}</span>
        </div>
      )}

      {/* Cyber Readiness & HSM Fleet Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 font-mono text-xs">
        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">POST-QUANTUM READINESS</span>
          <span className="text-base font-bold text-emerald-400 flex items-center gap-1.5">
            <Lock className="w-4 h-4" />
            ML-KEM / ML-DSA READY
          </span>
          <span className="text-slate-400 text-[10px]">NIST FIPS 203/204 Hybrid Signing</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">ROOT HSM STATUS</span>
          <span className="text-base font-bold text-white flex items-center gap-1.5">
            <Cpu className="w-4 h-4 text-blue-400" />
            36/36 NODES ONLINE
          </span>
          <span className="text-slate-400 text-[10px]">Zeroized Enclaves • Tamper Resilient</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">ANOMALY DETECTOR (AI-SOC)</span>
          <span className="text-base font-bold text-cyan-400 flex items-center gap-1.5">
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
            SURVEILLANCE ACTIVE
          </span>
          <span className="text-slate-400 text-[10px]">Velocity &amp; Smurfing Pattern Analysis</span>
        </div>

        <div className="bg-[#091322] border border-slate-800 p-3 rounded-xs space-y-1">
          <span className="text-slate-500 text-[10px] block">DDOS MITIGATION POOL</span>
          <span className="text-base font-bold text-emerald-400">12.8 Tbps CAPACITY</span>
          <span className="text-slate-400 text-[10px]">Scrubbing Centers: 100% Clear</span>
        </div>
      </div>

      {/* Incident Management Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 font-mono text-xs">
        {/* Incident List (5 cols) */}
        <div className="lg:col-span-5 bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              THREAT INTELLIGENCE INCIDENTS ({securityIncidents.length})
            </h3>
          </div>

          <div className="space-y-2">
            {securityIncidents.map(inc => {
              const isSelected = inc.id === selectedIncident.id;
              return (
                <div
                  key={inc.id}
                  onClick={() => setSelectedIncidentId(inc.id)}
                  className={`p-3 rounded-xs border transition-all cursor-pointer space-y-1 ${
                    isSelected
                      ? 'bg-[#0f223f] border-blue-500 shadow-md'
                      : 'bg-[#060c18] border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-xs">{inc.type.replace(/_/g, ' ')}</span>
                    <span className={`text-[9px] px-1.5 py-0.2 rounded-xs font-bold ${
                      inc.severity === 'HIGH' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                      inc.severity === 'MEDIUM' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {inc.severity}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-300 truncate">{inc.description}</div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
                    <span>{inc.timestamp.slice(11, 19)}</span>
                    <span className={inc.status === 'RESOLVED' ? 'text-emerald-400' : 'text-amber-400'}>
                      {inc.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Incident Response Workflow Detail (7 cols) */}
        <div className="lg:col-span-7 bg-[#091322] border border-slate-800 p-4 rounded-xs space-y-4">
          <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-2 gap-2">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>{selectedIncident.type.replace(/_/g, ' ')}</span>
                <span className="text-xs text-amber-400 bg-amber-950 px-2 py-0.5 border border-amber-800 rounded-xs">
                  {selectedIncident.id}
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Affected Intermediaries: <span className="text-white font-semibold">{selectedIncident.affectedIntermediariesCount} Institutions</span>
              </p>
            </div>

            {selectedIncident.status !== 'RESOLVED' && (
              <button
                onClick={() => handleMitigate(selectedIncident.id)}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xs flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <Lock className="w-3.5 h-3.5" />
                EXECUTE EMERGENCY MITIGATION
              </button>
            )}
          </div>

          <div className="bg-[#060c18] p-3 border border-slate-800 rounded-xs space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase block">INCIDENT TELEMETRY &amp; REMEDIATION PLAN</span>
            <p className="text-slate-300 text-xs">{selectedIncident.description}</p>
            <div className="p-2 bg-[#040812] border border-slate-800 rounded-xs text-[11px] text-cyan-300 space-y-1">
              <div>&gt; Automated Rule Trigger: ISOLATE_BRIDGE_INTERFACE</div>
              <div>&gt; Rate Limit Rule: Max 50 TPS per Intermediary IP subnet</div>
              <div>&gt; Ledger State Verification: PBFT Merkle Root Match 100% Certified</div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-[11px]">
            <div className="bg-[#060c18] p-2 border border-slate-800 rounded-xs">
              <span className="text-slate-500 text-[10px] block">SEVERITY</span>
              <span className="text-white font-bold">{selectedIncident.severity}</span>
            </div>
            <div className="bg-[#060c18] p-2 border border-slate-800 rounded-xs">
              <span className="text-slate-500 text-[10px] block">LEDGER INTEGRITY</span>
              <span className="text-emerald-400 font-bold">UNCOMPROMISED</span>
            </div>
            <div className="bg-[#060c18] p-2 border border-slate-800 rounded-xs">
              <span className="text-slate-500 text-[10px] block">DISRUPTED HONEST TXS</span>
              <span className="text-white font-bold">0.00%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
