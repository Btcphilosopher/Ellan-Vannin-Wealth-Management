/**
 * Federal Reserve Digital Dollar Double-Entry Accounting Engine
 * Enforces rigorous double-entry balance sheet consistency across:
 * 1. Federal Reserve SOMA / Balance Sheet
 * 2. Commercial Depository Banks
 * 3. Citizen / Merchant / Institutional Wallets
 * 4. U.S. Treasury General Account (TGA)
 * 
 * Verifies Invariant: TOTAL ASSETS === TOTAL LIABILITIES + EQUITY
 */

import { FedBalanceSheet, CommercialBank, Wallet, LedgerTransaction, TreasuryOperationsState } from '../types';
import { generateDeterministicHash, formatTimestamp } from '../utils/formatters';

export interface AccountingValidationResult {
  valid: boolean;
  discrepancy: number;
  fedAssets: number;
  fedLiabilitiesAndCapital: number;
  error?: string;
}

export class AccountingEngine {
  /**
   * Verify the Federal Reserve balance sheet invariant:
   * Total Assets == Total Liabilities + Surplus Capital
   */
  static validateFedBalanceSheet(fed: FedBalanceSheet): AccountingValidationResult {
    const totalAssets = 
      fed.assets.treasurySecurities +
      fed.assets.agencySecurities +
      fed.assets.loansToDepositoryInstitutions +
      fed.assets.repoAgreements +
      fed.assets.foreignCurrencyReserves;

    const totalLiabilities = 
      fed.liabilities.digitalDollarInCirculation +
      fed.liabilities.bankReserveBalances +
      fed.liabilities.federalReserveNotes +
      fed.liabilities.treasuryGeneralAccount +
      fed.liabilities.reverseRepoObligations +
      fed.liabilities.otherLiabilities;

    const totalEquity = fed.capital.totalCapital;
    const liabilitiesAndCapital = totalLiabilities + totalEquity;
    const discrepancy = Math.abs(totalAssets - liabilitiesAndCapital);

    // Allow less than 1 dollar rounding error in multi-trillion aggregate
    const isValid = discrepancy < 1.0;

    return {
      valid: isValid,
      discrepancy,
      fedAssets: totalAssets,
      fedLiabilitiesAndCapital: liabilitiesAndCapital,
      error: isValid ? undefined : `SYSTEM ACCOUNTING INVARIANT VIOLATION: Fed Assets ($${totalAssets.toLocaleString()}) != Liabilities + Capital ($${liabilitiesAndCapital.toLocaleString()}) | Discrepancy: $${discrepancy.toLocaleString()}`
    };
  }

  /**
   * Verify a commercial bank's balance sheet:
   * Total Assets == Total Liabilities + Tier 1 Common Capital
   */
  static validateCommercialBank(bank: CommercialBank): { valid: boolean; discrepancy: number; error?: string } {
    const assets = 
      bank.assets.centralBankReserves +
      bank.assets.dusdOperatingBalance +
      bank.assets.commercialLoans +
      bank.assets.consumerMortgages +
      bank.assets.treasurySecurities +
      bank.assets.cashInVault;

    const liabilities = 
      bank.liabilities.retailDeposits +
      bank.liabilities.commercialDeposits +
      bank.liabilities.wholesaleFunding +
      bank.liabilities.dusdConversionFacility +
      bank.liabilities.fedDiscountBorrowings;

    const equity = bank.equity.totalEquity;
    const discrepancy = Math.abs(assets - (liabilities + equity));
    const isValid = discrepancy < 1.0;

    return {
      valid: isValid,
      discrepancy,
      error: isValid ? undefined : `BANK ACCOUNTING INVARIANT VIOLATION [${bank.name}]: Assets ($${assets.toLocaleString()}) != Liabilities+Equity ($${(liabilities + equity).toLocaleString()})`
    };
  }

  /**
   * Issue new Digital Dollars into the monetary system:
   * Mechanism: Commercial Bank purchases DUSD by debiting its Reserve Account at the Federal Reserve.
   * Double Entry:
   * - Fed Liabilities: Bank Reserves DECREASE by amount; Digital Dollar In Circulation INCREASES by amount.
   *   (Total Fed liabilities unchanged! Net asset composition invariant preserved.)
   * - Bank Assets: Central Bank Reserves DECREASE by amount; DUSD Operating Balance INCREASES by amount.
   *   (Total Bank assets unchanged!)
   */
  static issueDusdAgainstReserves(
    amount: number,
    bankId: string,
    fed: FedBalanceSheet,
    banks: CommercialBank[]
  ): { updatedFed: FedBalanceSheet; updatedBanks: CommercialBank[]; transaction: LedgerTransaction } {
    const targetBank = banks.find(b => b.id === bankId);
    if (!targetBank) throw new Error(`Bank ${bankId} not found`);
    if (targetBank.assets.centralBankReserves < amount) {
      throw new Error(`Insufficient central bank reserves at ${targetBank.name}`);
    }

    // 1. Mutate Fed Liabilities
    const updatedFed: FedBalanceSheet = {
      ...fed,
      timestamp: formatTimestamp(),
      liabilities: {
        ...fed.liabilities,
        digitalDollarInCirculation: fed.liabilities.digitalDollarInCirculation + amount,
        bankReserveBalances: fed.liabilities.bankReserveBalances - amount,
      }
    };
    updatedFed.liabilities.totalLiabilities = 
      updatedFed.liabilities.digitalDollarInCirculation +
      updatedFed.liabilities.bankReserveBalances +
      updatedFed.liabilities.federalReserveNotes +
      updatedFed.liabilities.treasuryGeneralAccount +
      updatedFed.liabilities.reverseRepoObligations +
      updatedFed.liabilities.otherLiabilities;

    // 2. Mutate Bank Assets
    const updatedBanks = banks.map(b => {
      if (b.id !== bankId) return b;
      return {
        ...b,
        assets: {
          ...b.assets,
          centralBankReserves: b.assets.centralBankReserves - amount,
          dusdOperatingBalance: b.assets.dusdOperatingBalance + amount,
        }
      };
    });

    const txId = `TX-ISSUE-${Date.now()}`;
    const transaction: LedgerTransaction = {
      id: txId,
      timestamp: formatTimestamp(),
      blockHeight: 849205 + Math.floor(Math.random() * 50),
      originator: 'FEDERAL_RESERVE_ISSUANCE_DESK',
      originatorName: 'Federal Reserve Monetary Facility',
      intermediaryId: targetBank.id,
      intermediaryName: targetBank.name,
      beneficiary: targetBank.id,
      beneficiaryName: `${targetBank.name} DUSD Vault`,
      amount,
      assetType: 'DUSD',
      settlementRail: 'DUSD_CORE_LEDGER',
      privacyClass: 'TIER_3_REGISTERED',
      status: 'SETTLED',
      latencyMs: 340,
      auditHash: generateDeterministicHash(txId),
      signature: generateDeterministicHash(`SIG-FED-${amount}`),
      memo: `Fed DUSD Issuance against reserve debit (${targetBank.name})`,
      complianceFlag: 'SANCTION_SCREEN_PASS',
    };

    return { updatedFed, updatedBanks, transaction };
  }

  /**
   * Redeem Digital Dollars back into Bank Reserves:
   * Mechanism: Commercial Bank surrenders DUSD to the Federal Reserve to replenish Reserve Account.
   * Double Entry:
   * - Fed Liabilities: Digital Dollar In Circulation DECREASES by amount; Bank Reserves INCREASE by amount.
   * - Bank Assets: DUSD Operating Balance DECREASES by amount; Central Bank Reserves INCREASE by amount.
   */
  static redeemDusdToReserves(
    amount: number,
    bankId: string,
    fed: FedBalanceSheet,
    banks: CommercialBank[]
  ): { updatedFed: FedBalanceSheet; updatedBanks: CommercialBank[]; transaction: LedgerTransaction } {
    const targetBank = banks.find(b => b.id === bankId);
    if (!targetBank) throw new Error(`Bank ${bankId} not found`);
    if (targetBank.assets.dusdOperatingBalance < amount) {
      throw new Error(`Insufficient DUSD operating balance at ${targetBank.name}`);
    }

    const updatedFed: FedBalanceSheet = {
      ...fed,
      timestamp: formatTimestamp(),
      liabilities: {
        ...fed.liabilities,
        digitalDollarInCirculation: fed.liabilities.digitalDollarInCirculation - amount,
        bankReserveBalances: fed.liabilities.bankReserveBalances + amount,
      }
    };
    updatedFed.liabilities.totalLiabilities = 
      updatedFed.liabilities.digitalDollarInCirculation +
      updatedFed.liabilities.bankReserveBalances +
      updatedFed.liabilities.federalReserveNotes +
      updatedFed.liabilities.treasuryGeneralAccount +
      updatedFed.liabilities.reverseRepoObligations +
      updatedFed.liabilities.otherLiabilities;

    const updatedBanks = banks.map(b => {
      if (b.id !== bankId) return b;
      return {
        ...b,
        assets: {
          ...b.assets,
          centralBankReserves: b.assets.centralBankReserves + amount,
          dusdOperatingBalance: b.assets.dusdOperatingBalance - amount,
        }
      };
    });

    const txId = `TX-REDEEM-${Date.now()}`;
    const transaction: LedgerTransaction = {
      id: txId,
      timestamp: formatTimestamp(),
      blockHeight: 849206 + Math.floor(Math.random() * 50),
      originator: targetBank.id,
      originatorName: `${targetBank.name} DUSD Vault`,
      intermediaryId: targetBank.id,
      intermediaryName: targetBank.name,
      beneficiary: 'FEDERAL_RESERVE_REDEMPTION_DESK',
      beneficiaryName: 'Federal Reserve Master Account Reserves',
      amount,
      assetType: 'BANK_RESERVES',
      settlementRail: 'DUSD_CORE_LEDGER',
      privacyClass: 'TIER_3_REGISTERED',
      status: 'SETTLED',
      latencyMs: 380,
      auditHash: generateDeterministicHash(txId),
      signature: generateDeterministicHash(`SIG-REDEEM-${amount}`),
      memo: `Commercial Bank DUSD Redemption to Central Bank Reserves`,
      complianceFlag: 'SANCTION_SCREEN_PASS',
    };

    return { updatedFed, updatedBanks, transaction };
  }

  /**
   * Consumer/Commercial Deposit to DUSD Conversion (CBDC disintermediation flow):
   * Consumer converts $X of Commercial Bank Deposit into DUSD in their wallet.
   * Double Entry:
   * - Commercial Bank:
   *   Liabilities: Retail Deposits DECREASE by amount.
   *   Assets: Bank's DUSD Operating Balance DECREASE by amount (transferred to user's wallet).
   *   Total assets and liabilities decrease symmetrically; equity unchanged!
   * - User Wallet:
   *   DUSD balance INCREASES by amount.
   */
  static convertBankDepositToDusd(
    amount: number,
    bankId: string,
    walletId: string,
    banks: CommercialBank[],
    wallets: Wallet[]
  ): { updatedBanks: CommercialBank[]; updatedWallets: Wallet[]; transaction: LedgerTransaction } {
    const bank = banks.find(b => b.id === bankId);
    const wallet = wallets.find(w => w.id === walletId);
    if (!bank || !wallet) throw new Error('Bank or wallet not found');

    if (bank.assets.dusdOperatingBalance < amount) {
      throw new Error(`${bank.name} has insufficient DUSD operating liquidity for this conversion request`);
    }

    const updatedBanks = banks.map(b => {
      if (b.id !== bankId) return b;
      return {
        ...b,
        assets: {
          ...b.assets,
          dusdOperatingBalance: b.assets.dusdOperatingBalance - amount,
          totalAssets: b.assets.totalAssets - amount,
        },
        liabilities: {
          ...b.liabilities,
          retailDeposits: b.liabilities.retailDeposits - amount,
          totalLiabilities: b.liabilities.totalLiabilities - amount,
        },
        metrics: {
          ...b.metrics,
          dusdDepositOutflowRate: Number((b.metrics.dusdDepositOutflowRate + 0.05).toFixed(2)),
        }
      };
    });

    const updatedWallets = wallets.map(w => {
      if (w.id !== walletId) return w;
      return {
        ...w,
        dusdBalance: w.dusdBalance + amount,
        lastActive: 'Just now',
      };
    });

    const txId = `TX-CONV-${Date.now()}`;
    const transaction: LedgerTransaction = {
      id: txId,
      timestamp: formatTimestamp(),
      blockHeight: 849207 + Math.floor(Math.random() * 50),
      originator: bank.name,
      originatorName: `${bank.name} Deposit Account`,
      intermediaryId: bank.id,
      intermediaryName: bank.name,
      beneficiary: wallet.id,
      beneficiaryName: wallet.ownerName,
      amount,
      assetType: 'DUSD',
      settlementRail: 'FEDNOW_SERVICE',
      privacyClass: wallet.privacyTier,
      status: 'SETTLED',
      latencyMs: 410,
      auditHash: generateDeterministicHash(txId),
      signature: generateDeterministicHash(`SIG-CONV-${amount}`),
      memo: `Commercial Bank Deposit -> DUSD Wallet Conversion`,
      complianceFlag: 'CLEARED',
    };

    return { updatedBanks, updatedWallets, transaction };
  }

  /**
   * Wallet-to-Wallet Direct DUSD Settlement:
   * Instant gross settlement on DUSD Core Ledger.
   */
  static executeWalletTransfer(
    amount: number,
    senderWalletId: string,
    recipientWalletId: string,
    wallets: Wallet[],
    memo: string = 'Digital Dollar Direct Transfer'
  ): { updatedWallets: Wallet[]; transaction: LedgerTransaction } {
    const sender = wallets.find(w => w.id === senderWalletId);
    const recipient = wallets.find(w => w.id === recipientWalletId);
    if (!sender || !recipient) throw new Error('Sender or recipient wallet not found');
    if (sender.dusdBalance < amount) {
      throw new Error(`Insufficient DUSD balance in ${sender.ownerName}'s wallet ($${sender.dusdBalance.toFixed(2)})`);
    }

    const updatedWallets = wallets.map(w => {
      if (w.id === senderWalletId) {
        return {
          ...w,
          dusdBalance: w.dusdBalance - amount,
          dailyTransferredToday: w.dailyTransferredToday + amount,
          lastActive: 'Just now',
        };
      }
      if (w.id === recipientWalletId) {
        return {
          ...w,
          dusdBalance: w.dusdBalance + amount,
          lastActive: 'Just now',
        };
      }
      return w;
    });

    const txId = `TX-DUSD-${Date.now()}`;
    const transaction: LedgerTransaction = {
      id: txId,
      timestamp: formatTimestamp(),
      blockHeight: 849208 + Math.floor(Math.random() * 50),
      originator: sender.id,
      originatorName: sender.ownerName,
      intermediaryId: sender.intermediaryId,
      intermediaryName: sender.intermediaryName,
      beneficiary: recipient.id,
      beneficiaryName: recipient.ownerName,
      amount,
      assetType: 'DUSD',
      settlementRail: 'DUSD_CORE_LEDGER',
      privacyClass: sender.privacyTier,
      status: 'SETTLED',
      latencyMs: 390 + Math.floor(Math.random() * 80),
      auditHash: generateDeterministicHash(txId),
      signature: generateDeterministicHash(`SIG-TX-${sender.id}-${amount}`),
      memo,
      complianceFlag: amount > 10000 ? 'FLAGGED_CTR' : 'CLEARED',
    };

    return { updatedWallets, transaction };
  }

  /**
   * Treasury General Account (TGA) Direct Disbursement:
   * Fed Liabilities: Treasury General Account DECREASES by amount; Digital Dollar in Circulation INCREASES.
   * Recipient Wallet: DUSD balance INCREASES by amount.
   */
  static executeTreasuryDisbursement(
    amount: number,
    recipientWalletId: string,
    fed: FedBalanceSheet,
    wallets: Wallet[],
    treasury: TreasuryOperationsState,
    memo: string = 'Direct Federal Disbursement via TreasuryDirect'
  ): { updatedFed: FedBalanceSheet; updatedWallets: Wallet[]; updatedTreasury: TreasuryOperationsState; transaction: LedgerTransaction } {
    const recipient = wallets.find(w => w.id === recipientWalletId);
    if (!recipient) throw new Error('Recipient wallet not found');
    if (fed.liabilities.treasuryGeneralAccount < amount) {
      throw new Error('Treasury General Account has insufficient funds');
    }

    const updatedFed: FedBalanceSheet = {
      ...fed,
      timestamp: formatTimestamp(),
      liabilities: {
        ...fed.liabilities,
        treasuryGeneralAccount: fed.liabilities.treasuryGeneralAccount - amount,
        digitalDollarInCirculation: fed.liabilities.digitalDollarInCirculation + amount,
      }
    };
    updatedFed.liabilities.totalLiabilities = 
      updatedFed.liabilities.digitalDollarInCirculation +
      updatedFed.liabilities.bankReserveBalances +
      updatedFed.liabilities.federalReserveNotes +
      updatedFed.liabilities.treasuryGeneralAccount +
      updatedFed.liabilities.reverseRepoObligations +
      updatedFed.liabilities.otherLiabilities;

    const updatedWallets = wallets.map(w => {
      if (w.id !== recipientWalletId) return w;
      return {
        ...w,
        dusdBalance: w.dusdBalance + amount,
        lastActive: 'Just now',
      };
    });

    const updatedTreasury: TreasuryOperationsState = {
      ...treasury,
      tgaBalance: treasury.tgaBalance - amount,
      dailyDisbursements: treasury.dailyDisbursements + amount,
    };

    const txId = `TX-TREAS-${Date.now()}`;
    const transaction: LedgerTransaction = {
      id: txId,
      timestamp: formatTimestamp(),
      blockHeight: 849209 + Math.floor(Math.random() * 50),
      originator: 'U.S._TREASURY_GENERAL_ACCOUNT',
      originatorName: 'U.S. Department of the Treasury (Fiscal Service)',
      intermediaryId: 'BANK-LNB',
      intermediaryName: 'Liberty National Bank (Fiscal Agent)',
      beneficiary: recipient.id,
      beneficiaryName: recipient.ownerName,
      amount,
      assetType: 'DUSD',
      settlementRail: 'TREASURY_DIRECT_RAIL',
      privacyClass: 'TIER_3_REGISTERED',
      status: 'SETTLED',
      latencyMs: 310,
      auditHash: generateDeterministicHash(txId),
      signature: generateDeterministicHash(`SIG-TGA-${amount}`),
      memo,
      complianceFlag: 'CLEARED',
    };

    return { updatedFed, updatedWallets, updatedTreasury, transaction };
  }
}
