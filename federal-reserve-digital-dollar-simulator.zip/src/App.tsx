import React from 'react';
import { SimulatorProvider, useSimulator } from './store/simulatorStore';
import { Header } from './components/Header';
import { NavigationSidebar } from './components/NavigationSidebar';

// All 23 Specialized Views
import { CommandCenterView } from './views/CommandCenterView';
import { IssuanceView } from './views/IssuanceView';
import { LedgerView } from './views/LedgerView';
import { WalletsView } from './views/WalletsView';
import { BanksView } from './views/BanksView';
import { TopologyView } from './views/TopologyView';
import { SettlementRailsView } from './views/SettlementRailsView';
import { FedNowView } from './views/FedNowView';
import { MonetaryPolicyView } from './views/MonetaryPolicyView';
import { FomcView } from './views/FomcView';
import { StabilityView } from './views/StabilityView';
import { PrivacyView } from './views/PrivacyView';
import { OfflineView } from './views/OfflineView';
import { ProgrammableView } from './views/ProgrammableView';
import { TokenizationView } from './views/TokenizationView';
import { TreasuryView } from './views/TreasuryView';
import { CrossBorderView } from './views/CrossBorderView';
import { CybersecurityView } from './views/CybersecurityView';
import { AuditView } from './views/AuditView';
import { DataLabView } from './views/DataLabView';
import { InfrastructureView } from './views/InfrastructureView';
import { TransactionLabView } from './views/TransactionLabView';
import { LegalView } from './views/LegalView';

const MainViewContent: React.FC = () => {
  const { activeModule } = useSimulator();

  const renderActiveView = () => {
    switch (activeModule) {
      case 'COMMAND_CENTER':
        return <CommandCenterView />;
      case 'ISSUANCE':
        return <IssuanceView />;
      case 'LEDGER':
        return <LedgerView />;
      case 'WALLETS':
        return <WalletsView />;
      case 'BANKS':
        return <BanksView />;
      case 'PAYMENTS_TOPOLOGY':
        return <TopologyView />;
      case 'SETTLEMENT_RAILS':
        return <SettlementRailsView />;
      case 'FEDNOW':
        return <FedNowView />;
      case 'MONETARY_POLICY':
        return <MonetaryPolicyView />;
      case 'FOMC':
        return <FomcView />;
      case 'FINANCIAL_STABILITY':
        return <StabilityView />;
      case 'PRIVACY':
        return <PrivacyView />;
      case 'OFFLINE':
        return <OfflineView />;
      case 'PROGRAMMABLE':
        return <ProgrammableView />;
      case 'TOKENIZATION_DVP':
        return <TokenizationView />;
      case 'TREASURY':
        return <TreasuryView />;
      case 'CROSS_BORDER':
        return <CrossBorderView />;
      case 'CYBERSECURITY':
        return <CybersecurityView />;
      case 'AUDIT':
        return <AuditView />;
      case 'DATA_LAB':
        return <DataLabView />;
      case 'INFRASTRUCTURE':
        return <InfrastructureView />;
      case 'TRANSACTION_SIMULATOR':
        return <TransactionLabView />;
      case 'LEGAL':
        return <LegalView />;
      default:
        return <CommandCenterView />;
    }
  };

  return (
    <main className="flex-1 overflow-y-auto p-4 lg:p-5 bg-[#070d18] text-slate-100">
      <div className="max-w-[1700px] mx-auto space-y-4">
        {renderActiveView()}
      </div>

      {/* Institutional Legal Disclaimer Footer */}
      <footer className="mt-8 pt-4 border-t border-slate-800/80 text-center text-[11px] font-mono text-slate-500 space-y-1">
        <p className="font-semibold text-slate-400">
          UNITED STATES FEDERAL RESERVE SYSTEM RESEARCH BENCHMARK SIMULATOR &bull; EXPERIMENTAL ARCHITECTURAL STUDY
        </p>
        <p>
          SIMULATION ENVIRONMENT &bull; SYNTHETIC DATA &bull; HYPOTHETICAL DIGITAL DOLLAR ARCHITECTURE &bull; NOT A LIVE FEDERAL RESERVE SYSTEM
        </p>
        <p className="text-[10px] text-slate-600">
          Designed in accordance with Federal Reserve Board CBDC Research Whitepapers &bull; Project Hamilton &bull; BIS Innovation Hub Multi-CBDC Models
        </p>
      </footer>
    </main>
  );
};

export default function App() {
  return (
    <SimulatorProvider>
      <div className="min-h-screen flex flex-col bg-[#070d18] text-slate-100 selection:bg-blue-600 selection:text-white font-['Public_Sans',sans-serif]">
        <Header />
        <div className="flex-1 flex overflow-hidden">
          <NavigationSidebar />
          <MainViewContent />
        </div>
      </div>
    </SimulatorProvider>
  );
}
