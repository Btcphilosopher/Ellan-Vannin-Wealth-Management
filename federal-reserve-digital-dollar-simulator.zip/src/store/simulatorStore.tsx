/**
 * Core Simulator State & Controller
 * Implements real-time financial system loop, double-entry validation, and state propagation
 */

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  FedBalanceSheet,
  CommercialBank,
  Wallet,
  LedgerTransaction,
  MonetaryPolicyState,
  PaymentRailAdapter,
  ProgrammablePaymentContract,
  TokenizedDvPContract,
  TreasuryOperationsState,
  CrossBorderCorridor,
  SecurityIncident,
  AuditEvent,
  InfrastructureNode,
  FOMCMemberOpinion,
  OfflinePaymentSimulation
} from '../types';
import {
  INITIAL_FED_BALANCE_SHEET,
  INITIAL_COMMERCIAL_BANKS,
  INITIAL_WALLETS,
  INITIAL_PAYMENT_RAILS,
  INITIAL_MONETARY_POLICY,
  INITIAL_FOMC_OPINIONS,
  INITIAL_PROGRAMMABLE_CONTRACTS,
  INITIAL_DVP_CONTRACTS,
  INITIAL_TREASURY_STATE,
  INITIAL_CROSS_BORDER_CORRIDORS,
  INITIAL_SECURITY_INCIDENTS,
  INITIAL_INFRASTRUCTURE_NODES,
  INITIAL_AUDIT_LOGS,
  INITIAL_TRANSACTIONS
} from '../data/initialData';
import { AccountingEngine } from '../services/accountingEngine';
import { formatTimestamp, generateDeterministicHash } from '../utils/formatters';

export type NavigationModule = 
  | 'COMMAND_CENTER'
  | 'LEDGER'
  | 'ISSUANCE'
  | 'WALLETS'
  | 'BANKS'
  | 'PAYMENTS_TOPOLOGY'
  | 'SETTLEMENT_RAILS'
  | 'FEDNOW'
  | 'MONETARY_POLICY'
  | 'FOMC'
  | 'FINANCIAL_STABILITY'
  | 'PRIVACY'
  | 'OFFLINE'
  | 'PROGRAMMABLE'
  | 'TOKENIZATION_DVP'
  | 'TREASURY'
  | 'CROSS_BORDER'
  | 'CYBERSECURITY'
  | 'AUDIT'
  | 'DATA_LAB'
  | 'INFRASTRUCTURE'
  | 'TRANSACTION_SIMULATOR'
  | 'LEGAL';

interface SimulatorContextType {
  // State
  activeModule: NavigationModule;
  setActiveModule: (m: NavigationModule) => void;
  isRunning: boolean;
  timeScale: number; // 1, 10, 100, 1000
  simulationClock: string;
  blockHeight: number;
  transactionsPerSec: number;
  
  fedBalanceSheet: FedBalanceSheet;
  banks: CommercialBank[];
  wallets: Wallet[];
  transactions: LedgerTransaction[];
  paymentRails: PaymentRailAdapter[];
  monetaryPolicy: MonetaryPolicyState;
  fomcOpinions: FOMCMemberOpinion[];
  programmableContracts: ProgrammablePaymentContract[];
  dvpContracts: TokenizedDvPContract[];
  treasuryState: TreasuryOperationsState;
  crossBorderCorridors: CrossBorderCorridor[];
  securityIncidents: SecurityIncident[];
  infrastructureNodes: InfrastructureNode[];
  auditLogs: AuditEvent[];
  offlineQueue: OfflinePaymentSimulation[];
  
  // Invariant verification
  accountingStatus: {
    valid: boolean;
    discrepancy: number;
    error?: string;
  };

  // Actions
  toggleSimulation: () => void;
  setTimeScale: (scale: number) => void;
  stepSimulationTick: () => void;
  resetSimulation: () => void;

  issueDusd: (amount: number, bankId: string) => void;
  redeemDusd: (amount: number, bankId: string) => void;
  convertDepositToDusd: (amount: number, bankId: string, walletId: string) => void;
  transferWalletDusd: (amount: number, senderId: string, recipientId: string, memo?: string) => void;
  disburseTreasuryPayment: (amount: number, recipientId: string, memo?: string) => void;
  
  executeDvPAtomicSettlement: (contractId: string) => void;
  fulfillProgrammablePayment: (contractId: string) => void;
  queueOfflinePayment: (sourceDeviceId: string, targetDeviceId: string, amount: number) => void;
  reconcileOfflineQueue: () => void;
  
  applyScenario: (scenario: MonetaryPolicyState['scenarioName']) => void;
  updatePolicyRates: (ffrMin: number, ffrMax: number, iorb: number, onRrp: number, dusdRate: number) => void;
  updateMonetaryPolicy: (params: Partial<MonetaryPolicyState>) => void;
  resolveSecurityIncident: (incidentId: string) => void;
  injectStressEvent: (stressType: 'BANK_FAILURE' | 'LIQUIDITY_SHOCK' | 'NETWORK_OUTAGE' | 'CYBER_ATTACK' | 'RAPID_ADOPTION_SPIKE') => void;
  executeCustomTransaction: (params: {
    originator: string;
    beneficiary: string;
    intermediaryId: string;
    amount: number;
    assetType: any;
    settlementRail: any;
    privacyLevel: any;
    priority: string;
    memo?: string;
  }) => Promise<LedgerTransaction>;
  
  exportSimulationState: (format: 'json' | 'csv') => void;
}

const SimulatorContext = createContext<SimulatorContextType | null>(null);

export const SimulatorProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeModule, setActiveModule] = useState<NavigationModule>('COMMAND_CENTER');
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [timeScale, setTimeScale] = useState<number>(1);
  const [clockDate, setClockDate] = useState<Date>(new Date(2026, 8, 19, 7, 20, 0));
  const [blockHeight, setBlockHeight] = useState<number>(849204);
  const [transactionsPerSec, setTransactionsPerSec] = useState<number>(54200);

  // Entities
  const [fedBalanceSheet, setFedBalanceSheet] = useState<FedBalanceSheet>(INITIAL_FED_BALANCE_SHEET);
  const [banks, setBanks] = useState<CommercialBank[]>(INITIAL_COMMERCIAL_BANKS);
  const [wallets, setWallets] = useState<Wallet[]>(INITIAL_WALLETS);
  const [transactions, setTransactions] = useState<LedgerTransaction[]>(INITIAL_TRANSACTIONS);
  const [paymentRails, setPaymentRails] = useState<PaymentRailAdapter[]>(INITIAL_PAYMENT_RAILS);
  const [monetaryPolicy, setMonetaryPolicy] = useState<MonetaryPolicyState>(INITIAL_MONETARY_POLICY);
  const [fomcOpinions] = useState<FOMCMemberOpinion[]>(INITIAL_FOMC_OPINIONS);
  const [programmableContracts, setProgrammableContracts] = useState<ProgrammablePaymentContract[]>(INITIAL_PROGRAMMABLE_CONTRACTS);
  const [dvpContracts, setDvpContracts] = useState<TokenizedDvPContract[]>(INITIAL_DVP_CONTRACTS);
  const [treasuryState, setTreasuryState] = useState<TreasuryOperationsState>(INITIAL_TREASURY_STATE);
  const [crossBorderCorridors, setCrossBorderCorridors] = useState<CrossBorderCorridor[]>(INITIAL_CROSS_BORDER_CORRIDORS);
  const [securityIncidents, setSecurityIncidents] = useState<SecurityIncident[]>(INITIAL_SECURITY_INCIDENTS);
  const [infrastructureNodes, setInfrastructureNodes] = useState<InfrastructureNode[]>(INITIAL_INFRASTRUCTURE_NODES);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>(INITIAL_AUDIT_LOGS);
  const [offlineQueue, setOfflineQueue] = useState<OfflinePaymentSimulation[]>([
    {
      id: 'OFF-TX-0091',
      sourceDeviceId: 'DEVICE-HARDWARE-ENCLAVE-JC74',
      targetDeviceId: 'POS-TERMINAL-METRO-09',
      amount: 45.80,
      offlineCounter: 14,
      hardwareSignature: 'SIG-SE-ED25519-094A',
      timestamp: '2026-09-19 07:15:20 UTC',
      status: 'STORED_ON_CHIP',
    }
  ]);

  // Real-time double-entry validation
  const accountingStatus = useMemo(() => {
    return AccountingEngine.validateFedBalanceSheet(fedBalanceSheet);
  }, [fedBalanceSheet]);

  // Simulation Clock Tick (runs background simulated transactions and updates TPS)
  useEffect(() => {
    if (!isRunning) return;

    const intervalMs = Math.max(100, Math.floor(1000 / (timeScale > 100 ? 10 : 1)));
    const timer = setInterval(() => {
      // Advance clock
      setClockDate(prev => new Date(prev.getTime() + 1000 * timeScale));

      // Advance block height periodically
      setBlockHeight(prev => prev + 1);

      // Random jitter in TPS around realistic 50k-85k
      setTransactionsPerSec(prev => {
        const jitter = (Math.random() - 0.48) * 800 * (timeScale > 10 ? 3 : 1);
        return Math.floor(Math.max(42000, Math.min(92000, prev + jitter)));
      });

      // Synthetic background micro-transactions flow (inter-wallet activity)
      if (Math.random() < 0.35) {
        const randomAmount = Number((Math.random() * 85 + 5).toFixed(2));
        const syntheticTx: LedgerTransaction = {
          id: `TX-DUSD-${Date.now().toString().slice(-6)}`,
          timestamp: formatTimestamp(),
          blockHeight: blockHeight,
          originator: 'WLT-METRO-RET-01',
          originatorName: 'Midwest Supermarket Network Inc.',
          intermediaryId: 'BANK-CTB',
          intermediaryName: 'Continental Bank',
          beneficiary: 'WLT-CORP-LOG-88',
          beneficiaryName: 'Trans-American Logistics LLC',
          amount: randomAmount,
          assetType: 'DUSD',
          settlementRail: 'DUSD_CORE_LEDGER',
          privacyClass: 'TIER_2_INTERMEDIATED',
          status: 'SETTLED',
          latencyMs: 380 + Math.floor(Math.random() * 60),
          auditHash: generateDeterministicHash(`SYN-${Date.now()}`),
          signature: generateDeterministicHash(`SIG-${randomAmount}`),
          memo: 'Automated Merchant Clearing Batch Split',
          complianceFlag: 'CLEARED',
        };
        setTransactions(prev => [syntheticTx, ...prev.slice(0, 75)]);
      }
    }, intervalMs);

    return () => clearInterval(timer);
  }, [isRunning, timeScale, blockHeight]);

  const toggleSimulation = () => setIsRunning(prev => !prev);

  const stepSimulationTick = () => {
    setClockDate(prev => new Date(prev.getTime() + 60000));
    setBlockHeight(prev => prev + 1);
  };

  const resetSimulation = () => {
    setFedBalanceSheet(INITIAL_FED_BALANCE_SHEET);
    setBanks(INITIAL_COMMERCIAL_BANKS);
    setWallets(INITIAL_WALLETS);
    setTransactions(INITIAL_TRANSACTIONS);
    setPaymentRails(INITIAL_PAYMENT_RAILS);
    setMonetaryPolicy(INITIAL_MONETARY_POLICY);
    setProgrammableContracts(INITIAL_PROGRAMMABLE_CONTRACTS);
    setDvpContracts(INITIAL_DVP_CONTRACTS);
    setTreasuryState(INITIAL_TREASURY_STATE);
    setCrossBorderCorridors(INITIAL_CROSS_BORDER_CORRIDORS);
    setSecurityIncidents(INITIAL_SECURITY_INCIDENTS);
    setInfrastructureNodes(INITIAL_INFRASTRUCTURE_NODES);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setBlockHeight(849204);
  };

  const recordAuditEvent = (actionCategory: AuditEvent['actionCategory'], description: string, prevSnap: string, newSnap: string) => {
    const event: AuditEvent = {
      id: `AUDIT-${Date.now().toString().slice(-6)}`,
      timestamp: formatTimestamp(),
      operatorId: 'SIM_CHIEF_ENGINEER_CONSOLE',
      actionCategory,
      description,
      previousStateSnippet: prevSnap,
      newStateSnippet: newSnap,
      cryptographicReference: generateDeterministicHash(`AUDIT-${Date.now()}`),
      authorizationCertificate: 'FED-SEC-TOKEN-SIM-PROT',
    };
    setAuditLogs(prev => [event, ...prev]);
  };

  // Actions
  const issueDusd = useCallback((amount: number, bankId: string) => {
    const prevLiab = fedBalanceSheet.liabilities.digitalDollarInCirculation;
    const { updatedFed, updatedBanks, transaction } = AccountingEngine.issueDusdAgainstReserves(
      amount,
      bankId,
      fedBalanceSheet,
      banks
    );

    setFedBalanceSheet(updatedFed);
    setBanks(updatedBanks);
    setTransactions(prev => [transaction, ...prev]);
    recordAuditEvent(
      'ISSUANCE',
      `Issued $${amount.toLocaleString()} DUSD to ${updatedBanks.find(b => b.id === bankId)?.name} against Reserve Account debit`,
      `DUSD: $${prevLiab.toLocaleString()}`,
      `DUSD: $${updatedFed.liabilities.digitalDollarInCirculation.toLocaleString()}`
    );
  }, [fedBalanceSheet, banks]);

  const redeemDusd = useCallback((amount: number, bankId: string) => {
    const prevLiab = fedBalanceSheet.liabilities.digitalDollarInCirculation;
    const { updatedFed, updatedBanks, transaction } = AccountingEngine.redeemDusdToReserves(
      amount,
      bankId,
      fedBalanceSheet,
      banks
    );

    setFedBalanceSheet(updatedFed);
    setBanks(updatedBanks);
    setTransactions(prev => [transaction, ...prev]);
    recordAuditEvent(
      'REDEMPTION',
      `Redeemed $${amount.toLocaleString()} DUSD from ${updatedBanks.find(b => b.id === bankId)?.name} into Reserve Account`,
      `DUSD: $${prevLiab.toLocaleString()}`,
      `DUSD: $${updatedFed.liabilities.digitalDollarInCirculation.toLocaleString()}`
    );
  }, [fedBalanceSheet, banks]);

  const convertDepositToDusd = useCallback((amount: number, bankId: string, walletId: string) => {
    const { updatedBanks, updatedWallets, transaction } = AccountingEngine.convertBankDepositToDusd(
      amount,
      bankId,
      walletId,
      banks,
      wallets
    );
    setBanks(updatedBanks);
    setWallets(updatedWallets);
    setTransactions(prev => [transaction, ...prev]);
  }, [banks, wallets]);

  const transferWalletDusd = useCallback((amount: number, senderId: string, recipientId: string, memo?: string) => {
    const { updatedWallets, transaction } = AccountingEngine.executeWalletTransfer(
      amount,
      senderId,
      recipientId,
      wallets,
      memo
    );
    setWallets(updatedWallets);
    setTransactions(prev => [transaction, ...prev]);
  }, [wallets]);

  const disburseTreasuryPayment = useCallback((amount: number, recipientId: string, memo?: string) => {
    const { updatedFed, updatedWallets, updatedTreasury, transaction } = AccountingEngine.executeTreasuryDisbursement(
      amount,
      recipientId,
      fedBalanceSheet,
      wallets,
      treasuryState,
      memo
    );
    setFedBalanceSheet(updatedFed);
    setWallets(updatedWallets);
    setTreasuryState(updatedTreasury);
    setTransactions(prev => [transaction, ...prev]);
    recordAuditEvent(
      'SETTLEMENT_OVERRIDE',
      `Treasury Direct TGA disbursement: $${amount.toLocaleString()} DUSD credited to recipient ${recipientId}`,
      `TGA: $${treasuryState.tgaBalance.toLocaleString()}`,
      `TGA: $${updatedTreasury.tgaBalance.toLocaleString()}`
    );
  }, [fedBalanceSheet, wallets, treasuryState]);

  const executeDvPAtomicSettlement = useCallback((contractId: string) => {
    const contract = dvpContracts.find(c => c.id === contractId);
    if (!contract || contract.atomicFinality === 'EXECUTED_ATOMIC') return;

    // Mutate contract to executed
    setDvpContracts(prev => prev.map(c => {
      if (c.id !== contractId) return c;
      return {
        ...c,
        assetLegStatus: 'TRANSFERRED',
        paymentLegStatus: 'TRANSFERRED',
        atomicFinality: 'EXECUTED_ATOMIC',
        timestamp: formatTimestamp(),
      };
    }));

    const tx: LedgerTransaction = {
      id: `TX-DVP-${Date.now().toString().slice(-6)}`,
      timestamp: formatTimestamp(),
      blockHeight: blockHeight,
      originator: contract.buyerInstitution,
      originatorName: `${contract.buyerInstitution} (DUSD Leg)`,
      intermediaryId: 'BANK-LNB',
      intermediaryName: 'Central DvP Depository Facility',
      beneficiary: contract.sellerInstitution,
      beneficiaryName: `${contract.sellerInstitution} (Asset Leg: ${contract.cusip})`,
      amount: contract.settlementDusdAmount,
      assetType: 'TOKENIZED_SECURITY',
      settlementRail: 'DUSD_CORE_LEDGER',
      privacyClass: 'TIER_3_REGISTERED',
      status: 'SETTLED',
      latencyMs: 320,
      auditHash: generateDeterministicHash(`DVP-${contract.id}`),
      signature: generateDeterministicHash(`SIG-DVP-ATOMIC-${contract.id}`),
      memo: `Atomic Delivery-versus-Payment Finality for CUSIP ${contract.cusip}`,
      complianceFlag: 'SANCTION_SCREEN_PASS',
    };

    setTransactions(prev => [tx, ...prev]);
    recordAuditEvent(
      'SETTLEMENT_OVERRIDE',
      `Atomic DvP Executed for ${contract.securityTitle} ($${contract.settlementDusdAmount.toLocaleString()} DUSD)`,
      `Finality: PENDING`,
      `Finality: EXECUTED_ATOMIC`
    );
  }, [dvpContracts, blockHeight]);

  const fulfillProgrammablePayment = useCallback((contractId: string) => {
    const contract = programmableContracts.find(c => c.id === contractId);
    if (!contract || contract.state === 'SETTLED') return;

    setProgrammableContracts(prev => prev.map(c => {
      if (c.id !== contractId) return c;
      return {
        ...c,
        state: 'SETTLED',
        executionLogs: [
          ...c.executionLogs,
          `${formatTimestamp()}: Condition verified by oracle payload. $${c.principalAmount.toLocaleString()} DUSD settled atomically.`,
        ]
      };
    }));

    const tx: LedgerTransaction = {
      id: `TX-PRG-${Date.now().toString().slice(-6)}`,
      timestamp: formatTimestamp(),
      blockHeight: blockHeight,
      originator: contract.payerName,
      originatorName: contract.payerName,
      intermediaryId: 'BANK-CTB',
      intermediaryName: 'Continental Bank',
      beneficiary: contract.payeeName,
      beneficiaryName: contract.payeeName,
      amount: contract.principalAmount,
      assetType: 'DUSD',
      settlementRail: 'DUSD_CORE_LEDGER',
      privacyClass: 'TIER_2_INTERMEDIATED',
      status: 'SETTLED',
      latencyMs: 360,
      auditHash: generateDeterministicHash(`PRG-${contract.id}`),
      signature: generateDeterministicHash(`SIG-PRG-${contract.id}`),
      memo: `Programmable Contract Fulfilled: ${contract.title}`,
      complianceFlag: 'CLEARED',
    };
    setTransactions(prev => [tx, ...prev]);
  }, [programmableContracts, blockHeight]);

  const queueOfflinePayment = useCallback((sourceDeviceId: string, targetDeviceId: string, amount: number) => {
    const offlineTx: OfflinePaymentSimulation = {
      id: `OFF-TX-${Date.now().toString().slice(-6)}`,
      sourceDeviceId,
      targetDeviceId,
      amount,
      offlineCounter: 15,
      hardwareSignature: generateDeterministicHash(`OFFLINE-SE-${amount}`),
      timestamp: formatTimestamp(),
      status: 'STORED_ON_CHIP',
    };
    setOfflineQueue(prev => [offlineTx, ...prev]);
  }, []);

  const reconcileOfflineQueue = useCallback(() => {
    setOfflineQueue(prev => prev.map(item => ({
      ...item,
      status: 'RECONCILED',
      reconciliationBlock: blockHeight,
    })));

    recordAuditEvent(
      'SETTLEMENT_OVERRIDE',
      `Synchronized & verified ${offlineQueue.length} offline device-to-device payments with central ledger`,
      `State: STORED_ON_CHIP`,
      `State: RECONCILED (Block #${blockHeight})`
    );
  }, [offlineQueue, blockHeight]);

  const applyScenario = useCallback((scenario: MonetaryPolicyState['scenarioName']) => {
    let newFfrMin = 4.25;
    let newFfrMax = 4.50;
    let newPolicyRate = 4.33;
    let newIorb = 4.40;
    let newOnRrp = 4.30;
    let newDusdRate = 0.00;
    let newOmoPace = -25.0;
    let newInflation = 2.38;
    let newGdp = 2.14;
    let newUnemployment = 3.92;
    let newVelocity = 1.48;
    let newStress = 12.4;

    switch (scenario) {
      case 'EASING':
        newFfrMin = 3.25;
        newFfrMax = 3.50;
        newPolicyRate = 3.33;
        newIorb = 3.40;
        newOnRrp = 3.30;
        newOmoPace = 40.0;
        newGdp = 2.75;
        newInflation = 2.85;
        newUnemployment = 3.65;
        newVelocity = 1.62;
        newStress = 8.5;
        break;
      case 'TIGHTENING':
        newFfrMin = 5.25;
        newFfrMax = 5.50;
        newPolicyRate = 5.33;
        newIorb = 5.40;
        newOnRrp = 5.30;
        newOmoPace = -60.0;
        newGdp = 1.45;
        newInflation = 2.05;
        newUnemployment = 4.35;
        newVelocity = 1.34;
        newStress = 24.0;
        break;
      case 'BANKING_STRESS':
        newFfrMin = 4.00;
        newFfrMax = 4.25;
        newPolicyRate = 4.10;
        newStress = 72.5;
        newVelocity = 1.15;
        break;
      case 'CBDC_RUN_SCENARIO':
        newDusdRate = 0.00;
        newStress = 88.0;
        break;
      case 'HIGH_ADOPTION':
        newVelocity = 1.85;
        newStress = 16.0;
        break;
      case 'LOW_ADOPTION':
        newVelocity = 1.25;
        newStress = 9.0;
        break;
      case 'BASELINE':
      default:
        break;
    }

    setMonetaryPolicy(prev => ({
      ...prev,
      federalFundsTargetRangeMin: newFfrMin,
      federalFundsTargetRangeMax: newFfrMax,
      policyRate: newPolicyRate,
      interestOnReserveBalances: newIorb,
      overnightReverseRepoRate: newOnRrp,
      dusdRemunerationRate: newDusdRate,
      openMarketOperationsPace: newOmoPace,
      discountWindowPrimaryRate: newFfrMax + 0.25,
      holdingLimitIndividual: prev.holdingLimitIndividual,
      macroIndicators: {
        headlineInflationCPI: newInflation,
        corePCEInflation: newInflation - 0.09,
        realGdpGrowth: newGdp,
        unemploymentRate: newUnemployment,
        paymentVelocity: newVelocity,
        financialConditionsIndex: scenario === 'TIGHTENING' ? 0.65 : (scenario === 'EASING' ? -0.58 : -0.21),
        cbdcSubstitutionElasticity: scenario === 'CBDC_RUN_SCENARIO' ? 0.58 : 0.14,
        systemLiquidityStressScore: newStress,
      },
      scenarioName: scenario,
    }));

    recordAuditEvent(
      'POLICY_ADJUSTMENT',
      `Applied macroeconomic simulation scenario: ${scenario}`,
      `Previous Scenario: ${monetaryPolicy.scenarioName}`,
      `New Scenario: ${scenario} (Policy Rate: ${newPolicyRate}%)`
    );
  }, [monetaryPolicy.scenarioName]);

  const updatePolicyRates = useCallback((ffrMin: number, ffrMax: number, iorb: number, onRrp: number, dusdRate: number) => {
    setMonetaryPolicy(prev => ({
      ...prev,
      federalFundsTargetRangeMin: ffrMin,
      federalFundsTargetRangeMax: ffrMax,
      policyRate: Number(((ffrMin + ffrMax) / 2 + 0.08).toFixed(2)),
      interestOnReserveBalances: iorb,
      overnightReverseRepoRate: onRrp,
      dusdRemunerationRate: dusdRate,
    }));

    recordAuditEvent(
      'POLICY_ADJUSTMENT',
      `Updated Federal Funds Target Range to ${ffrMin.toFixed(2)}% - ${ffrMax.toFixed(2)}% (IORB: ${iorb.toFixed(2)}%)`,
      `FFR: ${monetaryPolicy.federalFundsTargetRangeMin}% - ${monetaryPolicy.federalFundsTargetRangeMax}%`,
      `FFR: ${ffrMin}% - ${ffrMax}%`
    );
  }, [monetaryPolicy]);

  const updateMonetaryPolicy = useCallback((params: Partial<MonetaryPolicyState>) => {
    setMonetaryPolicy(prev => ({
      ...prev,
      ...params,
    }));
    recordAuditEvent(
      'POLICY_ADJUSTMENT',
      `Updated monetary policy parameters: ${Object.keys(params).join(', ')}`,
      JSON.stringify(params),
      'UPDATED'
    );
  }, []);

  const resolveSecurityIncident = useCallback((incidentId: string) => {
    setSecurityIncidents(prev => prev.map(inc =>
      inc.id === incidentId ? { ...inc, status: 'RESOLVED' as const } : inc
    ));
    recordAuditEvent(
      'STRESS_INJECTION',
      `Security Incident ${incidentId} mitigated and resolved by operator`,
      `Incident ${incidentId} Active`,
      `Incident ${incidentId} Status: RESOLVED`
    );
  }, []);

  const injectStressEvent = useCallback((stressType: 'BANK_FAILURE' | 'LIQUIDITY_SHOCK' | 'NETWORK_OUTAGE' | 'CYBER_ATTACK' | 'RAPID_ADOPTION_SPIKE') => {
    let incidentTitle = '';
    let incidentDesc = '';

    if (stressType === 'BANK_FAILURE') {
      incidentTitle = 'Simulated Regional Bank Resolvability Test (Metropolitan Commercial Bank)';
      incidentDesc = 'Injecting 25% accelerated deposit flight into DUSD wallet safe-havens to test Fed discount window automatic collateralization bridge.';
      setBanks(prev => prev.map(b => b.id === 'BANK-MCB' ? { ...b, status: 'CRITICAL', metrics: { ...b.metrics, dusdDepositOutflowRate: 24.5, liquidityCoverageRatio: 88.2 } } : b));
    } else if (stressType === 'LIQUIDITY_SHOCK') {
      incidentTitle = 'Intraday Money Market Liquidity Freeze';
      incidentDesc = 'Tripping overnight repo facility spread divergence to test DUSD wholesale backstop.';
      setMonetaryPolicy(prev => ({ ...prev, macroIndicators: { ...prev.macroIndicators, systemLiquidityStressScore: 78.4 } }));
    } else if (stressType === 'NETWORK_OUTAGE') {
      incidentTitle = 'Simulated Trans-Atlantic Cable Severance (New York Fed Node Failover)';
      incidentDesc = 'Diverting consensus traffic to Chicago and Dallas backup validator clusters.';
      setInfrastructureNodes(prev => prev.map(n => n.region === 'NEW_YORK' ? { ...n, status: 'FAILOVER_STANDBY' } : n));
    } else if (stressType === 'CYBER_ATTACK') {
      incidentTitle = 'Coordinated DDoS Burst on Intermediary API Endpoints';
      incidentDesc = 'Rate limiting activated across 8 bank intermediary gateways; DUSD core ledger remains 100% operational.';
    } else {
      incidentTitle = 'Rapid DUSD Retail Adoption Wave (+$250B / 24h)';
      incidentDesc = 'Simulating rapid migration from demand deposits into non-remunerated DUSD; evaluating macro bank lending resilience.';
    }

    const newIncident: SecurityIncident = {
      id: `INC-${Date.now().toString().slice(-5)}`,
      timestamp: formatTimestamp(),
      title: incidentTitle,
      type: 'ABNORMAL_TRANSACTION_VELOCITY',
      severity: 'HIGH',
      status: 'UNDER_INVESTIGATION',
      affectedIntermediariesCount: 4,
      monitoredExposureDusd: 25000000000.00,
      description: incidentDesc,
    };
    setSecurityIncidents(prev => [newIncident, ...prev]);

    recordAuditEvent('STRESS_INJECTION', incidentTitle, 'Baseline Conditions', `Stress Event Injected: ${stressType}`);
  }, []);

  const executeCustomTransaction = useCallback(async (params: {
    originator: string;
    beneficiary: string;
    intermediaryId: string;
    amount: number;
    assetType: any;
    settlementRail: any;
    privacyLevel: any;
    priority: string;
    memo?: string;
  }): Promise<LedgerTransaction> => {
    const txId = `TX-LAB-${Date.now().toString().slice(-6)}`;
    const tx: LedgerTransaction = {
      id: txId,
      timestamp: formatTimestamp(),
      blockHeight: blockHeight,
      originator: params.originator,
      originatorName: params.originator,
      intermediaryId: params.intermediaryId,
      intermediaryName: banks.find(b => b.id === params.intermediaryId)?.name || 'Liberty National Bank',
      beneficiary: params.beneficiary,
      beneficiaryName: params.beneficiary,
      amount: params.amount,
      assetType: params.assetType,
      settlementRail: params.settlementRail,
      privacyClass: params.privacyLevel,
      status: 'SETTLED',
      latencyMs: params.settlementRail === 'DUSD_CORE_LEDGER' ? 380 : (params.settlementRail === 'FEDNOW_SERVICE' ? 620 : 1200),
      auditHash: generateDeterministicHash(txId),
      signature: generateDeterministicHash(`SIG-${params.originator}-${params.amount}`),
      memo: params.memo || 'Custom Transaction Simulator Request',
      complianceFlag: params.amount > 10000 ? 'FLAGGED_CTR' : 'CLEARED',
    };

    setTransactions(prev => [tx, ...prev]);
    return tx;
  }, [blockHeight, banks]);

  const exportSimulationState = useCallback((format: 'json' | 'csv') => {
    let content = '';
    let filename = '';
    let mimeType = '';

    if (format === 'json') {
      const data = {
        metadata: {
          system: 'FEDERAL RESERVE DIGITAL DOLLAR SIMULATOR',
          disclaimer: 'FICTIONAL RESEARCH SIMULATION — NOT LIVE FEDERAL RESERVE SYSTEM',
          exportedAt: formatTimestamp(),
          blockHeight,
        },
        fedBalanceSheet,
        monetaryPolicy,
        banks,
        wallets,
        recentTransactions: transactions.slice(0, 50),
        accountingInvariant: accountingStatus,
      };
      content = JSON.stringify(data, null, 2);
      filename = `dusd_simulation_snapshot_${Date.now()}.json`;
      mimeType = 'application/json';
    } else {
      // CSV format for transactions
      const headers = ['TransactionID', 'Timestamp', 'Originator', 'Intermediary', 'Beneficiary', 'Amount', 'AssetType', 'Rail', 'Status', 'AuditHash'];
      const rows = transactions.map(t => [
        t.id,
        t.timestamp,
        `"${t.originatorName}"`,
        `"${t.intermediaryName}"`,
        `"${t.beneficiaryName}"`,
        t.amount,
        t.assetType,
        t.settlementRail,
        t.status,
        t.auditHash,
      ].join(','));
      content = [headers.join(','), ...rows].join('\n');
      filename = `dusd_ledger_transactions_${Date.now()}.csv`;
      mimeType = 'text/csv';
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [blockHeight, fedBalanceSheet, monetaryPolicy, banks, wallets, transactions, accountingStatus]);

  return (
    <SimulatorContext.Provider
      value={{
        activeModule,
        setActiveModule,
        isRunning,
        timeScale,
        simulationClock: clockDate.toUTCString().replace('GMT', 'UTC'),
        blockHeight,
        transactionsPerSec,
        fedBalanceSheet,
        banks,
        wallets,
        transactions,
        paymentRails,
        monetaryPolicy,
        fomcOpinions,
        programmableContracts,
        dvpContracts,
        treasuryState,
        crossBorderCorridors,
        securityIncidents,
        infrastructureNodes,
        auditLogs,
        offlineQueue,
        accountingStatus,
        toggleSimulation,
        setTimeScale,
        stepSimulationTick,
        resetSimulation,
        issueDusd,
        redeemDusd,
        convertDepositToDusd,
        transferWalletDusd,
        disburseTreasuryPayment,
        executeDvPAtomicSettlement,
        fulfillProgrammablePayment,
        queueOfflinePayment,
        reconcileOfflineQueue,
        applyScenario,
        updatePolicyRates,
        updateMonetaryPolicy,
        resolveSecurityIncident,
        injectStressEvent,
        executeCustomTransaction,
        exportSimulationState,
      }}
    >
      {children}
    </SimulatorContext.Provider>
  );
};

export const useSimulator = () => {
  const context = useContext(SimulatorContext);
  if (!context) {
    throw new Error('useSimulator must be used within a SimulatorProvider');
  }
  return context;
};
