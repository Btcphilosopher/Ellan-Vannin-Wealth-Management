/**
 * Financial formatters and cryptographic signature helpers
 * Ensures strict monetary notation & monospaced alignment
 */

export function formatCurrency(val: number, options: { compact?: boolean; precision?: number } = {}): string {
  const { compact = false, precision = 2 } = options;
  
  if (compact) {
    const absVal = Math.abs(val);
    if (absVal >= 1e12) {
      return `$${(val / 1e12).toFixed(precision)}T`;
    }
    if (absVal >= 1e9) {
      return `$${(val / 1e9).toFixed(precision)}B`;
    }
    if (absVal >= 1e6) {
      return `$${(val / 1e6).toFixed(precision)}M`;
    }
    if (absVal >= 1e3) {
      return `$${(val / 1e3).toFixed(precision)}K`;
    }
  }

  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: precision,
    maximumFractionDigits: precision,
  }).format(val);
}

export function formatLargeExactNumber(val: number): string {
  return new Intl.NumberFormat('en-US', {
    maximumFractionDigits: 0,
  }).format(val);
}

export function formatPercent(val: number, precision: number = 2): string {
  return `${val >= 0 ? '+' : ''}${val.toFixed(precision)}%`;
}

export function formatPercentPlain(val: number, precision: number = 2): string {
  return `${val.toFixed(precision)}%`;
}

export function formatShortHash(hash: string): string {
  if (!hash || hash.length < 12) return hash;
  return `${hash.slice(0, 6)}...${hash.slice(-6)}`;
}

export function generateDeterministicHash(seed: string): string {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    const char = seed.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  const tail = Math.abs((hash ^ 0x5a5a5a5a) * 31).toString(16).padStart(8, '0');
  const ext1 = Math.abs((hash * 67) ^ 0x3c3c3c3c).toString(16).padStart(8, '0');
  const ext2 = Math.abs((hash * 131) ^ 0x96969696).toString(16).padStart(8, '0');
  return `0x${hex}${tail}${ext1}${ext2}`.toUpperCase();
}

export function formatTimestamp(date: Date = new Date()): string {
  return date.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
}
