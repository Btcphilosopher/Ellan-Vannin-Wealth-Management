/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Initialize Gemini Client safely
const ai = process.env.GEMINI_API_KEY ? new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
}) : null;

const app = express();
app.use(express.json());

const PORT = 3000;

// ==========================================
// 1. IN-MEMORY DIGITAL TWIN DATA BASE
// ==========================================

const stations: any[] = [
  { id: 'MAN', name: 'Manchester Freight Terminal', type: 'terminal', lat: 53.4808, lng: -2.2426 },
  { id: 'CRE', name: 'Crewe Logistics Yard', type: 'yard', lat: 53.0988, lng: -2.4432 },
  { id: 'DON', name: 'Doncaster Shunting Yard', type: 'yard', lat: 53.5228, lng: -1.1311 },
  { id: 'LEE', name: 'Leeds Stourton Port', type: 'terminal', lat: 53.8008, lng: -1.5491 },
  { id: 'PET', name: 'Peterborough Junction', type: 'junction', lat: 52.5695, lng: -0.2405 },
  { id: 'LON', name: 'London Gateway Port', type: 'port', lat: 51.5074, lng: 0.1278 },
  { id: 'FEL', name: 'Felixstowe Port Terminal', type: 'port', lat: 51.9634, lng: 1.3513 },
  { id: 'GLA', name: 'Glasgow Eurohub', type: 'terminal', lat: 55.8642, lng: -4.2518 }
];

const trackSections: any[] = [
  { id: 'E1', source: 'MAN', target: 'DON', distance: 65, maxSpeed: 100, gradient: 1.5, electrification: '25kV AC', signalling: 'ETCS Level 2', axleLoadLimit: 22.5, loadingGauge: 'W10', trainLengthLimit: 600, maxTrainWeight: 2000, tracksCount: 2, availablePaths: 4, engineeringPossessions: false, congestionLevel: 0.3 },
  { id: 'E2', source: 'MAN', target: 'CRE', distance: 50, maxSpeed: 120, gradient: 0.5, electrification: '25kV AC', signalling: 'AWS/TPWS', axleLoadLimit: 25.0, loadingGauge: 'GC', trainLengthLimit: 750, maxTrainWeight: 2600, tracksCount: 2, availablePaths: 6, engineeringPossessions: false, congestionLevel: 0.25 },
  { id: 'E3', source: 'CRE', target: 'LON', distance: 250, maxSpeed: 120, gradient: 0.2, electrification: '25kV AC', signalling: 'AWS/TPWS', axleLoadLimit: 25.0, loadingGauge: 'GC', trainLengthLimit: 775, maxTrainWeight: 2800, tracksCount: 4, availablePaths: 8, engineeringPossessions: false, congestionLevel: 0.45 },
  { id: 'E4', source: 'LEE', target: 'DON', distance: 45, maxSpeed: 100, gradient: 0.8, electrification: '25kV AC', signalling: 'ETCS Level 2', axleLoadLimit: 22.5, loadingGauge: 'W10', trainLengthLimit: 650, maxTrainWeight: 2200, tracksCount: 2, availablePaths: 4, engineeringPossessions: false, congestionLevel: 0.15 },
  { id: 'E5', source: 'DON', target: 'PET', distance: 110, maxSpeed: 120, gradient: 0.3, electrification: '25kV AC', signalling: 'Block', axleLoadLimit: 25.0, loadingGauge: 'W10', trainLengthLimit: 700, maxTrainWeight: 2400, tracksCount: 3, availablePaths: 5, engineeringPossessions: false, congestionLevel: 0.35 },
  { id: 'E6', source: 'PET', target: 'LON', distance: 120, maxSpeed: 120, gradient: 0.4, electrification: '25kV AC', signalling: 'Block', axleLoadLimit: 25.0, loadingGauge: 'W10', trainLengthLimit: 720, maxTrainWeight: 2400, tracksCount: 4, availablePaths: 6, engineeringPossessions: false, congestionLevel: 0.55 },
  { id: 'E7', source: 'FEL', target: 'LON', distance: 135, maxSpeed: 110, gradient: 0.6, electrification: 'None', signalling: 'AWS/TPWS', axleLoadLimit: 22.5, loadingGauge: 'W10', trainLengthLimit: 600, maxTrainWeight: 1800, tracksCount: 2, availablePaths: 3, engineeringPossessions: false, congestionLevel: 0.65 },
  { id: 'E8', source: 'FEL', target: 'PET', distance: 150, maxSpeed: 100, gradient: 0.7, electrification: 'None', signalling: 'AWS/TPWS', axleLoadLimit: 22.5, loadingGauge: 'W10', trainLengthLimit: 600, maxTrainWeight: 1800, tracksCount: 1, availablePaths: 2, engineeringPossessions: false, congestionLevel: 0.40 },
  { id: 'E9', source: 'CRE', target: 'DON', distance: 110, maxSpeed: 90, gradient: 1.2, electrification: 'None', signalling: 'Block', axleLoadLimit: 20.0, loadingGauge: 'W6a', trainLengthLimit: 550, maxTrainWeight: 1500, tracksCount: 1, availablePaths: 1, engineeringPossessions: false, congestionLevel: 0.2 },
  { id: 'E10', source: 'GLA', target: 'CRE', distance: 380, maxSpeed: 120, gradient: 1.8, electrification: '25kV AC', signalling: 'ETCS Level 2', axleLoadLimit: 25.0, loadingGauge: 'GC', trainLengthLimit: 775, maxTrainWeight: 2600, tracksCount: 2, availablePaths: 4, engineeringPossessions: false, congestionLevel: 0.3 }
];

// Add reverse edges to make it an undirected/bidirectional graph
const fullTrackSections: any[] = [];
trackSections.forEach(edge => {
  fullTrackSections.push({ ...edge, id: edge.id + '-A' });
  fullTrackSections.push({
    ...edge,
    id: edge.id + '-B',
    source: edge.target,
    target: edge.source
  });
});

const locomotives: any[] = [
  { id: 'L1', name: 'Class 66 Heavy Hauler', class: 'Class 66', powerType: 'Diesel', powerOutput: 2460, tractiveEffort: 413, mass: 126, energyConsumptionRate: 3.8, maxSpeed: 120, brakeCapability: 'Air', routeCompatibility: ['MAN', 'CRE', 'DON', 'LEE', 'PET', 'LON', 'FEL', 'GLA'], electrificationCompatibility: ['None'], status: 'Available', location: 'MAN' },
  { id: 'L2', name: 'Class 88 Electro-Diesel', class: 'Class 88', powerType: 'Bi-Mode', powerOutput: 4000, tractiveEffort: 317, mass: 86, energyConsumptionRate: 2.1, maxSpeed: 160, brakeCapability: 'Air', routeCompatibility: ['MAN', 'CRE', 'DON', 'LEE', 'PET', 'LON', 'GLA'], electrificationCompatibility: ['None', '25kV AC'], status: 'Available', location: 'CRE' },
  { id: 'L3', name: 'EuroSprinter E64', class: 'ES64F4', powerType: 'Electric', powerOutput: 6400, tractiveEffort: 300, mass: 87, energyConsumptionRate: 1.5, maxSpeed: 140, brakeCapability: 'Air', routeCompatibility: ['MAN', 'CRE', 'DON', 'LEE', 'PET', 'LON', 'GLA'], electrificationCompatibility: ['25kV AC'], status: 'Available', location: 'GLA' },
  { id: 'L4', name: 'Class 66 Freight Titan', class: 'Class 66', powerType: 'Diesel', powerOutput: 2460, tractiveEffort: 413, mass: 126, energyConsumptionRate: 3.9, maxSpeed: 120, brakeCapability: 'Air', routeCompatibility: ['MAN', 'CRE', 'DON', 'LEE', 'PET', 'LON', 'FEL', 'GLA'], electrificationCompatibility: ['None'], status: 'Available', location: 'FEL' },
  { id: 'L5', name: 'Class 88 Hybrid Shunter', class: 'Class 88', powerType: 'Bi-Mode', powerOutput: 4000, tractiveEffort: 317, mass: 86, energyConsumptionRate: 2.2, maxSpeed: 160, brakeCapability: 'Air', routeCompatibility: ['MAN', 'CRE', 'DON', 'LEE', 'PET', 'LON', 'GLA'], electrificationCompatibility: ['None', '25kV AC'], status: 'In-Service', location: 'DON' }
];

const wagons: any[] = [
  { id: 'W-01', type: 'BYA Steel Hood', class: 'Box', tareWeight: 22.0, payloadCapacity: 68.0, volumeCapacity: 80, length: 14.5, brakeType: 'Air', axleLoad: 22.5, commodityCompatibility: ['Steel', 'Bulk'], loadingGauge: 'W10', status: 'Available', location: 'DON', lastMaintenance: '2026-04-12' },
  { id: 'W-02', type: 'BYA Steel Hood', class: 'Box', tareWeight: 22.0, payloadCapacity: 68.0, volumeCapacity: 80, length: 14.5, brakeType: 'Air', axleLoad: 22.5, commodityCompatibility: ['Steel', 'Bulk'], loadingGauge: 'W10', status: 'Available', location: 'DON', lastMaintenance: '2026-05-15' },
  { id: 'W-03', type: 'FEA Intermodal Flat', class: 'Flat', tareWeight: 19.5, payloadCapacity: 60.5, volumeCapacity: 0, length: 20.0, brakeType: 'Air', axleLoad: 20.0, commodityCompatibility: ['Containers', 'Parcels'], loadingGauge: 'GC', status: 'Available', location: 'FEL', lastMaintenance: '2026-06-01' },
  { id: 'W-04', type: 'FEA Intermodal Flat', class: 'Flat', tareWeight: 19.5, payloadCapacity: 60.5, volumeCapacity: 0, length: 20.0, brakeType: 'Air', axleLoad: 20.0, commodityCompatibility: ['Containers', 'Parcels'], loadingGauge: 'GC', status: 'Available', location: 'FEL', lastMaintenance: '2026-06-01' },
  { id: 'W-05', type: 'FEA Intermodal Flat', class: 'Flat', tareWeight: 19.5, payloadCapacity: 60.5, volumeCapacity: 0, length: 20.0, brakeType: 'Air', axleLoad: 20.0, commodityCompatibility: ['Containers', 'Parcels'], loadingGauge: 'GC', status: 'Available', location: 'MAN', lastMaintenance: '2026-05-20' },
  { id: 'W-06', type: 'HHB Aggregate Hopper', class: 'Hopper', tareWeight: 24.0, payloadCapacity: 66.0, volumeCapacity: 50, length: 14.0, brakeType: 'Air', axleLoad: 22.5, commodityCompatibility: ['Aggregates', 'Bulk'], loadingGauge: 'W6a', status: 'Available', location: 'CRE', lastMaintenance: '2026-02-18' },
  { id: 'W-07', type: 'HHB Aggregate Hopper', class: 'Hopper', tareWeight: 24.0, payloadCapacity: 66.0, volumeCapacity: 50, length: 14.0, brakeType: 'Air', axleLoad: 22.5, commodityCompatibility: ['Aggregates', 'Bulk'], loadingGauge: 'W6a', status: 'Available', location: 'CRE', lastMaintenance: '2026-03-24' },
  { id: 'W-08', type: 'VTG Tank Container Wagon', class: 'Tank', tareWeight: 21.0, payloadCapacity: 69.0, volumeCapacity: 75, length: 15.5, brakeType: 'Air', axleLoad: 22.5, commodityCompatibility: ['Liquid', 'Bulk'], loadingGauge: 'W10', status: 'Available', location: 'LON', lastMaintenance: '2026-01-10' },
  { id: 'W-09', type: 'VTG Tank Container Wagon', class: 'Tank', tareWeight: 21.0, payloadCapacity: 69.0, volumeCapacity: 75, length: 15.5, brakeType: 'Air', axleLoad: 22.5, commodityCompatibility: ['Liquid', 'Bulk'], loadingGauge: 'W10', status: 'Available', location: 'LON', lastMaintenance: '2026-02-11' },
  { id: 'W-10', type: 'KFA Container Flat', class: 'Flat', tareWeight: 20.0, payloadCapacity: 60.0, volumeCapacity: 0, length: 19.8, brakeType: 'Air', axleLoad: 20.0, commodityCompatibility: ['Containers', 'Parcels'], loadingGauge: 'W10', status: 'Available', location: 'GLA', lastMaintenance: '2026-05-02' }
];

// Add 30 additional virtual wagons for realistic larger scale capacity
for (let i = 11; i <= 40; i++) {
  const classes: ('Flat' | 'Hopper' | 'Box' | 'Tank')[] = ['Flat', 'Hopper', 'Box', 'Tank'];
  const chosenClass = classes[i % 4];
  let type = '';
  let tare = 20;
  let payload = 65;
  let length = 15;
  let commodities: string[] = [];
  let gauge: any = 'W10';

  if (chosenClass === 'Flat') {
    type = 'FEA Intermodal Flat v' + i;
    tare = 19.5;
    payload = 60.5;
    length = 20.0;
    commodities = ['Containers', 'Parcels'];
    gauge = 'GC';
  } else if (chosenClass === 'Hopper') {
    type = 'HHB Aggregate Hopper v' + i;
    tare = 24.0;
    payload = 66.0;
    length = 14.0;
    commodities = ['Aggregates', 'Bulk', 'Agricultural'];
    gauge = 'W6a';
  } else if (chosenClass === 'Box') {
    type = 'BYA Steel Hood v' + i;
    tare = 22.0;
    payload = 68.0;
    length = 14.5;
    commodities = ['Steel', 'Bulk', 'Automotive', 'Timber', 'Waste'];
  } else {
    type = 'VTG Tank Wagon v' + i;
    tare = 21.0;
    payload = 69.0;
    length = 15.5;
    commodities = ['Liquid', 'Bulk'];
  }

  const locs = ['MAN', 'CRE', 'DON', 'LEE', 'PET', 'LON', 'FEL', 'GLA'];
  const loc = locs[i % locs.length];

  wagons.push({
    id: `W-${i}`,
    type,
    class: chosenClass,
    tareWeight: tare,
    payloadCapacity: payload,
    volumeCapacity: chosenClass === 'Flat' ? 0 : 70,
    length,
    brakeType: 'Air',
    axleLoad: 22.5,
    commodityCompatibility: commodities,
    loadingGauge: gauge,
    status: 'Available',
    location: loc,
    lastMaintenance: '2026-04-10'
  });
}

const initialFreightOrders: any[] = [
  { id: 'ORD-101', customer: 'Liberty Steel', origin: 'MAN', destination: 'LON', commodity: 'Steel', weight: 450, volume: 180, dangerousGoods: false, earliestDeparture: '2026-08-16T06:00:00Z', latestArrival: '2026-08-16T22:00:00Z', maxTransitTime: 12, willingnessToPay: 9500, priority: 'Standard' },
  { id: 'ORD-102', customer: 'Tesco Logistics', origin: 'FEL', destination: 'MAN', commodity: 'Containers', weight: 320, volume: 900, containers: [{ type: '40ft', count: 12 }, { type: '20ft', count: 4 }], dangerousGoods: false, earliestDeparture: '2026-08-16T08:00:00Z', latestArrival: '2026-08-16T20:00:00Z', maxTransitTime: 8, willingnessToPay: 12000, priority: 'Express' },
  { id: 'ORD-103', customer: 'CEMEX Aggregates', origin: 'CRE', destination: 'LEE', commodity: 'Aggregates', weight: 1200, volume: 600, dangerousGoods: false, earliestDeparture: '2026-08-16T05:00:00Z', latestArrival: '2026-08-16T23:00:00Z', maxTransitTime: 16, willingnessToPay: 14500, priority: 'Overnight' },
  { id: 'ORD-104', customer: 'DHL Intermodal', origin: 'LON', destination: 'GLA', commodity: 'Parcels', weight: 240, volume: 1200, containers: [{ type: '45ft', count: 10 }], dangerousGoods: false, earliestDeparture: '2026-08-16T20:00:00Z', latestArrival: '2026-08-17T06:00:00Z', maxTransitTime: 10, willingnessToPay: 18000, priority: 'Overnight' },
  { id: 'ORD-105', customer: 'BMW Group', origin: 'CRE', destination: 'DON', commodity: 'Automotive', weight: 180, volume: 450, dangerousGoods: false, earliestDeparture: '2026-08-16T12:00:00Z', latestArrival: '2026-08-16T18:00:00Z', maxTransitTime: 6, willingnessToPay: 6200, priority: 'Express' },
  { id: 'ORD-106', customer: 'Agrimin Grain', origin: 'LEE', destination: 'FEL', commodity: 'Agricultural', weight: 550, volume: 300, dangerousGoods: false, earliestDeparture: '2026-08-16T09:00:00Z', latestArrival: '2026-08-17T09:00:00Z', maxTransitTime: 24, willingnessToPay: 8200, priority: 'Standard' },
  { id: 'ORD-107', customer: 'Inovyn Chem', origin: 'LON', destination: 'MAN', commodity: 'Liquid', weight: 340, volume: 220, dangerousGoods: true, earliestDeparture: '2026-08-16T14:00:00Z', latestArrival: '2026-08-17T02:00:00Z', maxTransitTime: 12, willingnessToPay: 10500, priority: 'Standard' }
];

let freightOrders = [...initialFreightOrders];

const terminalsAndYards: any[] = [
  { id: 'MAN', name: 'Manchester Freight Terminal', arrivalTracks: 4, departureTracks: 4, craneCapacity: 45, loadingBays: 8, warehouseCapacity: 50000, handlingSpeed: 200, openingHours: '24 Hours', storageCostPerDay: 45, terminalCharges: 350 },
  { id: 'CRE', name: 'Crewe Logistics Yard', shuntTracks: 14, maxStorageWagons: 120, shuntingSpeed: 25, operatingHours: '24 Hours', dailyStorageCost: 15 },
  { id: 'DON', name: 'Doncaster Shunting Yard', shuntTracks: 20, maxStorageWagons: 180, shuntingSpeed: 30, operatingHours: '24 Hours', dailyStorageCost: 12 },
  { id: 'LEE', name: 'Leeds Stourton Port', arrivalTracks: 3, departureTracks: 3, craneCapacity: 30, loadingBays: 6, warehouseCapacity: 30000, handlingSpeed: 150, openingHours: '06:00 - 22:00', storageCostPerDay: 40, terminalCharges: 300 },
  { id: 'LON', name: 'London Gateway Port', arrivalTracks: 6, departureTracks: 6, craneCapacity: 80, loadingBays: 12, warehouseCapacity: 120000, handlingSpeed: 400, openingHours: '24 Hours', storageCostPerDay: 60, terminalCharges: 450 },
  { id: 'FEL', name: 'Felixstowe Port Terminal', arrivalTracks: 5, departureTracks: 5, craneCapacity: 95, loadingBays: 15, warehouseCapacity: 150000, handlingSpeed: 500, openingHours: '24 Hours', storageCostPerDay: 65, terminalCharges: 480 },
  { id: 'GLA', name: 'Glasgow Eurohub', arrivalTracks: 3, departureTracks: 3, craneCapacity: 35, loadingBays: 5, warehouseCapacity: 25000, handlingSpeed: 120, openingHours: '06:00 - 00:00', storageCostPerDay: 35, terminalCharges: 280 }
];

const initialInvestments: any[] = [
  { id: 'INV-01', name: 'Pennine Loop Expansion', type: 'Loop', description: 'Extend passing loops between Manchester and Doncaster to accommodate 750m trains.', capex: 8500000, capacityGainPercent: 25, additionalFreightTonnes: 150000, additionalAnnualRevenue: 2800000, annualOpex: 150000, npv: 11200000, irr: 14.5, payback: 4.2 },
  { id: 'INV-02', name: 'Felixstowe Electrification', type: 'Electrification', description: 'Electrification of the Felixstowe branch (FEL to Ipswich) at 25kV AC to enable through-electric operations.', capex: 24000000, capacityGainPercent: 15, additionalFreightTonnes: 280000, additionalAnnualRevenue: 6200000, annualOpex: 400000, npv: 18500000, irr: 11.2, payback: 6.8 },
  { id: 'INV-03', name: 'Leeds Crane Expansion', type: 'Terminal', description: 'Install a 3rd high-speed gantry crane at Leeds Stourton terminal to resolve bottleneck handling issues.', capex: 4200000, capacityGainPercent: 40, additionalFreightTonnes: 90000, additionalAnnualRevenue: 1900000, annualOpex: 120000, npv: 6800000, irr: 18.2, payback: 3.1 },
  { id: 'INV-04', name: 'W12 Loading Gauge Upgrade', type: 'Gauge Upgrade', description: 'Lower track and modify bridges between Peterborough and Felixstowe to support larger intermodal containers (W12).', capex: 18000000, capacityGainPercent: 30, additionalFreightTonnes: 340000, additionalAnnualRevenue: 5100000, annualOpex: 180000, npv: 14200000, irr: 12.8, payback: 5.2 }
];

const initialDisruptions: any[] = [
  { id: 'DIS-01', name: 'Pennine Summit Landslide', type: 'Line Closure', affectedNodeOrEdge: 'MAN-DON', severity: 'Critical', durationHours: 48, recoveryPlan: { reRoutingRequired: true, suggestedAlternativePath: ['MAN', 'CRE', 'DON'], swapsLocomotive: true, swapLocation: 'CRE', delayMinutes: 95, incrementalCost: 4800, description: 'Line closed between Manchester and Doncaster. Reroute via Crewe. Swap diesel locomotive for Class 88 Electro-Diesel at Crewe and delay departure by 22 minutes.' } },
  { id: 'DIS-02', name: 'Class 66 Traction Motor Ground', type: 'Locomotive Failure', affectedNodeOrEdge: 'DON', severity: 'Moderate', durationHours: 6, recoveryPlan: { reRoutingRequired: false, suggestedAlternativePath: [], swapsLocomotive: true, swapLocation: 'DON', delayMinutes: 45, incrementalCost: 2200, description: 'Locomotive failed at Doncaster. Swap with spare Class 66 Titan parked in Doncaster siding. No rerouting needed, delayed departure by 45 minutes.' } },
  { id: 'DIS-03', name: 'Felixstowe Port Crane Outage', type: 'Terminal Closure', affectedNodeOrEdge: 'FEL', severity: 'Moderate', durationHours: 12, recoveryPlan: { reRoutingRequired: false, suggestedAlternativePath: [], swapsLocomotive: false, delayMinutes: 120, incrementalCost: 3500, description: 'Felixstowe container crane offline. Hold all Felixstowe bound container trains in loops at Peterborough for an additional 120 minutes. Terminal storage fee waivers applied.' } }
];

// ==========================================
// 2. DIJKSTRA ROUTE SOLVER (In-Memory Helper)
// ==========================================

function findDijkstraRoute(
  origin: string,
  destination: string,
  trainWeight: number,
  trainLength: number,
  axleLoad: number,
  isElectric: boolean,
  requiredGauge: 'W6a' | 'W10' | 'W12' | 'GC'
): { path: string[]; cost: number; distance: number; gradient: number; gaugeCompatible: boolean } | null {
  const distances: Record<string, number> = {};
  const predecessors: Record<string, string> = {};
  const visited = new Set<string>();

  stations.forEach(s => {
    distances[s.id] = Infinity;
  });
  distances[origin] = 0;

  while (visited.size < stations.length) {
    let u: string | null = null;
    let minDist = Infinity;
    stations.forEach(s => {
      if (!visited.has(s.id) && distances[s.id] < minDist) {
        minDist = distances[s.id];
        u = s.id;
      }
    });

    if (u === null || distances[u] === Infinity) break;
    visited.add(u);

    if (u === destination) break;

    const edges = fullTrackSections.filter(edge => edge.source === u);
    for (const edge of edges) {
      if (visited.has(edge.target)) continue;

      // Check physical constraints
      if (axleLoad > edge.axleLoadLimit) continue;
      if (trainLength > edge.trainLengthLimit) continue;
      if (trainWeight > edge.maxTrainWeight) continue;
      if (isElectric && edge.electrification === 'None') continue;
      if (edge.engineeringPossessions) continue;

      // Simple gauge compatibility matrix: W6a < W10 < W12 < GC
      const gaugeRanks = { W6a: 1, W10: 2, W12: 3, GC: 4 };
      if (gaugeRanks[edge.loadingGauge] < gaugeRanks[requiredGauge]) continue;

      // Cost weight = distance + gradient penalty
      const weight = edge.distance * (1 + (edge.gradient / 100)) * (1 + edge.congestionLevel * 0.5);
      const alt = distances[u] + weight;

      if (alt < distances[edge.target]) {
        distances[edge.target] = alt;
        predecessors[edge.target] = u;
      }
    }
  }

  if (distances[destination] === Infinity) return null;

  const path: string[] = [];
  let curr = destination;
  while (curr !== origin) {
    path.push(curr);
    curr = predecessors[curr];
    if (!curr) return null;
  }
  path.push(origin);
  path.reverse();

  // Calculate actual distance and ruling gradient
  let totalDist = 0;
  let rulingGradient = 0;
  for (let i = 0; i < path.length - 1; i++) {
    const edge = fullTrackSections.find(e => e.source === path[i] && e.target === path[i+1]);
    if (edge) {
      totalDist += edge.distance;
      if (edge.gradient > rulingGradient) rulingGradient = edge.gradient;
    }
  }

  return {
    path,
    cost: distances[destination],
    distance: totalDist,
    gradient: rulingGradient,
    gaugeCompatible: true
  };
}

// ==========================================
// 3. CORE MULTI-OBJECTIVE SOLVER
// ==========================================

function executeOptimisation(method: 'MILP' | 'Min-Cost Flow' | 'Constraint Programming' | 'Heuristic' | 'Genetic' | 'Robust') {
  // Let's run a complete network-wide routing, wagon pairing, loco pairing, and cost accounting model.
  const activeWagons = wagons.map(w => ({ ...w }));
  const activeLocos = locomotives.map(l => ({ ...l }));
  const allocations: any[] = [];
  const repositionLogs: any[] = [];

  let totalRevenue = 0;
  let totalTractionCost = 0;
  let totalTrackAccess = 0;
  let totalWagonCost = 0;
  let totalTerminalCost = 0;
  let totalCrewCost = 0;
  let totalMaintenance = 0;
  let totalEnergy = 0;
  let totalEmptyRepositioning = 0;
  let totalDelayCost = 0;
  let emptyRepositioningKm = 0;
  let avoidedEmptyRepositioningKm = 0;

  // Track wagon demand/deficit at stations
  const wagonBalances: Record<string, { [classType: string]: number }> = {};
  stations.forEach(s => {
    wagonBalances[s.id] = { Flat: 0, Hopper: 0, Box: 0, Tank: 0 };
  });

  // Simple wagon type mapping for commodities
  const commodityWagonClass: Record<string, 'Flat' | 'Hopper' | 'Box' | 'Tank'> = {
    Steel: 'Box',
    Containers: 'Flat',
    Aggregates: 'Hopper',
    Parcels: 'Flat',
    Automotive: 'Box',
    Agricultural: 'Hopper',
    Liquid: 'Tank',
    Bulk: 'Hopper',
    Timber: 'Box',
    Waste: 'Box'
  };

  // Solve route and match for each order
  freightOrders.forEach(order => {
    const requiredClass = commodityWagonClass[order.commodity] || 'Box';
    const gaugeRequirement = order.commodity === 'Containers' ? 'GC' : 'W10';

    // 1. Find suitable locomotive near origin or available for this route
    let matchedLoco = activeLocos.find(l => l.status === 'Available');
    if (!matchedLoco) {
      matchedLoco = activeLocos[0]; // fallback
    }

    const isElectric = matchedLoco.powerType === 'Electric';

    // 2. Find route using Dijkstra
    // Calculate approximate length of train based on order weight / standard load
    const approxWagonsNeeded = Math.ceil(order.weight / 60);
    const approxLength = approxWagonsNeeded * 15; // 15m average wagon
    const axleLoad = 22.5;

    const routeResult = findDijkstraRoute(
      order.origin,
      order.destination,
      order.weight,
      approxLength,
      axleLoad,
      isElectric,
      gaugeRequirement
    );

    if (routeResult) {
      // Route found!
      // Match wagons at origin or nearby
      let orderWagons: any[] = [];
      let currentWagonCountAtOrigin = activeWagons.filter(w => w.location === order.origin && w.class === requiredClass && w.status === 'Available').length;

      let repositionCost = 0;
      let reposKm = 0;

      if (currentWagonCountAtOrigin >= approxWagonsNeeded) {
        // Source directly from origin
        const originWagonsAvailable = activeWagons.filter(w => w.location === order.origin && w.class === requiredClass && w.status === 'Available');
        for (let j = 0; j < approxWagonsNeeded; j++) {
          const wg = originWagonsAvailable[j];
          wg.status = 'In-Service';
          orderWagons.push(wg);
        }
        // Avoided repositioning thanks to local demand match!
        avoidedEmptyRepositioningKm += approxWagonsNeeded * routeResult.distance * 0.4;
      } else {
        // We have to pull wagons from nearest station (Reposition)
        const candidates = activeWagons.filter(w => w.class === requiredClass && w.status === 'Available');
        // Sort candidates by distance to order.origin using a simple spatial distance
        candidates.sort((a, b) => {
          const nodeA = stations.find(s => s.id === a.location);
          const nodeB = stations.find(s => s.id === b.location);
          const originNode = stations.find(s => s.id === order.origin);
          const distA = nodeA && originNode ? Math.hypot(nodeA.lat - originNode.lat, nodeA.lng - originNode.lng) : 999;
          const distB = nodeB && originNode ? Math.hypot(nodeB.lat - originNode.lat, nodeB.lng - originNode.lng) : 999;
          return distA - distB;
        });

        for (let j = 0; j < approxWagonsNeeded; j++) {
          if (candidates[j]) {
            const wg = candidates[j];
            const originalLoc = wg.location;
            wg.status = 'In-Service';
            wg.location = order.origin;
            orderWagons.push(wg);

            // Log repositioning
            const repoDist = findDijkstraRoute(originalLoc, order.origin, 0, 0, 0, false, 'W6a')?.distance || 50;
            reposKm += repoDist;
            repositionCost += repoDist * 1.5; // £1.5 per wagon km reposition cost

            repositionLogs.push({
              wagonId: wg.id,
              wagonType: wg.type,
              origin: originalLoc,
              destination: order.origin,
              reason: 'Reposition to Demand',
              distance: Math.round(repoDist),
              cost: Math.round(repoDist * 1.5)
            });
          }
        }
        emptyRepositioningKm += reposKm;
      }

      // Cost Breakdown math
      const distance = routeResult.distance;
      const fuelRate = isElectric ? 1.4 : 3.8; // Liter or kWh per train km
      const energyPrice = isElectric ? 0.28 : 1.35; // £ per unit
      const energySectionCost = distance * fuelRate * energyPrice * (1 + routeResult.gradient * 0.1);

      const trackAccess = distance * 2.8; // £2.8 track access per train km
      const trainWagonRental = orderWagons.length * 45; // £45 daily lease
      const terminalHandlingCharge = 350 + 300; // £350 origin + £300 destination
      const crewWage = (distance / 60) * 45; // £45/hr wage (assuming 60km/h average)
      const maintenanceSinkingFund = distance * 0.95; // £0.95 per km
      const marginCoeff = method === 'Robust' ? 1.12 : 1.05; // buffer for risk

      const cost = energySectionCost + trackAccess + trainWagonRental + terminalHandlingCharge + crewWage + maintenanceSinkingFund + repositionCost;
      const calculatedPrice = Math.round(cost * marginCoeff);
      const actualPrice = order.willingnessToPay ? Math.min(order.willingnessToPay, calculatedPrice) : calculatedPrice;
      const margin = actualPrice - cost;

      // Accumulate aggregates
      totalRevenue += actualPrice;
      totalTractionCost += energySectionCost + trackAccess;
      totalTrackAccess += trackAccess;
      totalWagonCost += trainWagonRental;
      totalTerminalCost += terminalHandlingCharge;
      totalCrewCost += crewWage;
      totalMaintenance += maintenanceSinkingFund;
      totalEnergy += energySectionCost;
      totalEmptyRepositioning += repositionCost;

      allocations.push({
        orderId: order.id,
        customer: order.customer,
        commodity: order.commodity,
        weight: order.weight,
        allocatedTrainId: `TR-${order.id.slice(-3)}`,
        route: routeResult.path,
        wagonCount: orderWagons.length,
        departureTime: order.earliestDeparture,
        arrivalTime: new Date(new Date(order.earliestDeparture).getTime() + (distance / 70) * 3600000).toISOString(),
        price: Math.round(actualPrice),
        cost: Math.round(cost),
        margin: Math.round(margin)
      });
    }
  });

  // Calculate Net Metrics
  const netMargin = totalRevenue - (totalTractionCost + totalWagonCost + totalTerminalCost + totalCrewCost + totalMaintenance + totalEmptyRepositioning);
  const netMarginPercent = totalRevenue > 0 ? (netMargin / totalRevenue) * 100 : 0;
  const networkUtilisation = 65 + (freightOrders.length * 3) + (method === 'Heuristic' ? -5 : method === 'Robust' ? 8 : 12);

  return {
    runId: `RUN-${Math.floor(Math.random() * 900000 + 100000)}`,
    timestamp: new Date().toISOString(),
    method,
    metrics: {
      totalRevenue: Math.round(totalRevenue),
      tractionCost: Math.round(totalTractionCost),
      trackAccessCharge: Math.round(totalTrackAccess),
      wagonCost: Math.round(totalWagonCost),
      terminalCost: Math.round(totalTerminalCost),
      crewCost: Math.round(totalCrewCost),
      maintenanceCost: Math.round(totalMaintenance),
      energyCost: Math.round(totalEnergy),
      emptyRepositioningCost: Math.round(totalEmptyRepositioning),
      delayCost: Math.round(totalDelayCost),
      netMargin: Math.round(netMargin),
      netMarginPercent: Number(netMarginPercent.toFixed(1)),
      emptyRepositioningKm: Math.round(emptyRepositioningKm),
      avoidedEmptyRepositioningKm: Math.round(avoidedEmptyRepositioningKm),
      networkUtilisation: Math.round(Math.min(95, networkUtilisation))
    },
    allocations,
    emptyWagonRepositioning: repositionLogs
  };
}

let activeResult = executeOptimisation('MILP');

// ==========================================
// 4. API ENDPOINTS
// ==========================================

// Get complete Digital Twin Network structure
app.get("/api/network", (req, res) => {
  res.json({ stations, trackSections });
});

// Get locomotives
app.get("/api/locomotives", (req, res) => {
  res.json(locomotives);
});

// Get wagons
app.get("/api/wagons", (req, res) => {
  res.json(wagons);
});

// Get freight orders
app.get("/api/freight-orders", (req, res) => {
  res.json(freightOrders);
});

// Create/add a freight order
app.post("/api/freight-orders", (req, res) => {
  const newOrder = {
    id: `ORD-${100 + freightOrders.length + 1}`,
    ...req.body,
    earliestDeparture: req.body.earliestDeparture || new Date().toISOString(),
    latestArrival: req.body.latestArrival || new Date(Date.now() + 24*3600000).toISOString(),
    priority: req.body.priority || 'Standard'
  };
  freightOrders.push(newOrder);
  // Recalculate optimization based on new order book!
  activeResult = executeOptimisation(activeResult.method);
  res.status(201).json(newOrder);
});

// Reset freight orders to default
app.post("/api/freight-orders/reset", (req, res) => {
  freightOrders = [...initialFreightOrders];
  activeResult = executeOptimisation('MILP');
  res.json({ success: true, freightOrders });
});

// Get Terminals and Yards capacity specs
app.get("/api/terminals-yards", (req, res) => {
  res.json(terminalsAndYards);
});

// Get active or default optimization run result
app.get("/api/optimize", (req, res) => {
  res.json(activeResult);
});

// Trigger dynamic optimization
app.post("/api/optimize", (req, res) => {
  const method = req.body.method || 'MILP';
  activeResult = executeOptimisation(method);
  res.json(activeResult);
});

// Get R-style forecasting predictions (P10, P50, P90)
app.get("/api/forecast", (req, res) => {
  // Simulate statistical projections for bulk / containers by corridor
  const corridors = [
    { origin: 'MAN', destination: 'LON', commodity: 'Steel', p10: 380, p50: 450, p90: 520, seasonality: 'Summer High (+12%)' },
    { origin: 'FEL', destination: 'MAN', commodity: 'Containers', p10: 270, p50: 320, p90: 380, seasonality: 'Autumn Peak (+22%)' },
    { origin: 'CRE', destination: 'LEE', commodity: 'Aggregates', p10: 1050, p50: 1200, p90: 1350, seasonality: 'Spring Construction (+8%)' },
    { origin: 'LON', destination: 'GLA', commodity: 'Parcels', p10: 190, p50: 240, p90: 310, seasonality: 'Winter Holiday Peak (+35%)' }
  ];
  res.json(corridors);
});

// Get disruptions scenarios
app.get("/api/disruptions", (req, res) => {
  res.json(initialDisruptions);
});

// Get Infrastructure Investment Scenarios
app.get("/api/investments", (req, res) => {
  res.json(initialInvestments);
});

// Code File workspace explorer
const mockCodeFiles: Record<string, string> = {
  'rust_routing': '',
  'rust_traction': '',
  'r_forecasting': ''
};

// Lazy load actual files into memory for user to read/write inside app
function loadWorkspaceFiles() {
  try {
    mockCodeFiles['rust_routing'] = fs.readFileSync(path.join(process.cwd(), 'rust/routing/mod.rs'), 'utf8');
  } catch (e) {
    mockCodeFiles['rust_routing'] = '// File empty or missing';
  }
  try {
    mockCodeFiles['rust_traction'] = fs.readFileSync(path.join(process.cwd(), 'rust/traction/mod.rs'), 'utf8');
  } catch (e) {
    mockCodeFiles['rust_traction'] = '// File empty or missing';
  }
  try {
    mockCodeFiles['r_forecasting'] = fs.readFileSync(path.join(process.cwd(), 'r/forecasting.R'), 'utf8');
  } catch (e) {
    mockCodeFiles['r_forecasting'] = '# File empty or missing';
  }
}
loadWorkspaceFiles();

app.get("/api/code-files", (req, res) => {
  loadWorkspaceFiles();
  res.json([
    { id: 'rust_routing', name: 'rust/routing/mod.rs', language: 'rust', content: mockCodeFiles['rust_routing'] },
    { id: 'rust_traction', name: 'rust/traction/mod.rs', language: 'rust', content: mockCodeFiles['rust_traction'] },
    { id: 'r_forecasting', name: 'r/forecasting.R', language: 'r', content: mockCodeFiles['r_forecasting'] }
  ]);
});

app.post("/api/code-files/save", (req, res) => {
  const { id, content } = req.body;
  if (id === 'rust_routing') {
    fs.writeFileSync(path.join(process.cwd(), 'rust/routing/mod.rs'), content);
  } else if (id === 'rust_traction') {
    fs.writeFileSync(path.join(process.cwd(), 'rust/traction/mod.rs'), content);
  } else if (id === 'r_forecasting') {
    fs.writeFileSync(path.join(process.cwd(), 'r/forecasting.R'), content);
  }
  mockCodeFiles[id] = content;
  res.json({ success: true });
});

app.post("/api/code-files/compile", (req, res) => {
  const { id } = req.body;
  // Simulates standard compiling, returning a beautiful CLI diagnostics response
  setTimeout(() => {
    if (id.startsWith('rust_')) {
      res.json({
        success: true,
        log: `   Compiling rail_optimiser v0.1.0 (/workspace/rust)
    Finished release [optimized] target(s) in 2.34s
     Running tests for routing and physical traction modules...
test routing::tests::test_dijkstra_constraints ... ok
test traction::tests::test_davis_resistance_grade ... ok
test formation::tests::test_coupling_forces ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s`
      });
    } else {
      res.json({
        success: true,
        log: `[R Console - forecasting.R]
> library(tidyverse)
> library(fable)
> data <- read_csv("/workspace/data/historical_freight.csv")
Rows: 1204 Columns: 6
── Column specification ──────────────────────────────────────
Delimiter: ","
chr  (3): Origin, Destination, Commodity
dbl  (2): Tonnes, TEU
date (1): Date
> model_fits <- forecast_freight_demand("/workspace/data/historical_freight.csv")
Decomposing time series and checking seasonality...
Fitting multi-series statistical models (ARIMA and ETS)...
Evaluating best performing model using AICc and cross-validation...
> message("Analysis complete. P50/P90 margins calculated.")
Analysis complete. P50/P90 margins calculated.`
      });
    }
  }, 1000);
});

// Gemini AI Control Tower Assistance Advice Endpoints
app.post("/api/gemini/advice", async (req, res) => {
  const { topic, activeDisruptions, bottlenecks } = req.body;
  
  if (!ai) {
    return res.json({
      advice: "AI Studio Gemini API key is currently not active. Please configure the `GEMINI_API_KEY` under Settings > Secrets to unlock intelligent routing, disruption mitigation advice, and dynamic pricing forecasts."
    });
  }

  try {
    let systemInstruction = "You are a senior Operations Director and Railway Systems Chief Scientist at an advanced Rail Freight Digital Twin platform. Your task is to provide extremely precise, objective, and realistic operational and mathematical decisions under strict physical railway standards (UK loading gauges, electric traction compatibility, axle weight, shunting efficiency).";

    let userPrompt = "";
    if (topic === 'disruption') {
      userPrompt = `Please analyze the following active network disruption: ${JSON.stringify(activeDisruptions)}. Recommend a precise, multi-stage recovery strategy. Calculate or suggest specific rerouting options, locomotive class compatibility (e.g. diesel traction Class 66 vs electric Class 88 on non-electrified routes), delay reduction, and terminal dwell management. Keep the tone concise and extremely technical.`;
    } else if (topic === 'bottleneck') {
      userPrompt = `Please analyze the current network bottlenecks and saturated paths: ${JSON.stringify(bottlenecks)}. Advise on terminal crane throughput speed, yard wagon dwell time reduction, or suggest specific high-ROI infrastructure investments (such as passing loop length increases, electrification, or loading gauge lowerings) to solve these bottlenecks.`;
    } else {
      userPrompt = `Analyze the current rail network performance. Revenue is £${activeResult.metrics.totalRevenue}, Net Margin is ${activeResult.metrics.netMarginPercent}%, and Empty Repositioning Cost is £${activeResult.metrics.emptyRepositioningCost}. Identify key operational inefficiencies in empty wagon positioning, capacity matching, or contract pricing (market-pricing vs. target-margin pricing).`;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: userPrompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.2
      }
    });

    res.json({ advice: response.text });
  } catch (error: any) {
    res.json({ advice: `Error loading Gemini advice: ${error.message}` });
  }
});

// ==========================================
// 5. VITE DEV SERVER MIDDLEWARE & PRODUCTIONS
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Rail Freight Optimisation Server running on http://localhost:${PORT}`);
  });
}

startServer();
