# Rail Freight Demand Forecasting and Capacity Elasticity Model
# 
# Uses tidyverse, fable, and forecast to model historical freight volumes 
# and predict future requirements across different corridors and commodity classes.

library(tidyverse)
library(lubridate)
library(fable)
library(tsibble)
library(feasts)
library(urca)

# Function to generate P10/P50/P90 forecasts for rail corridors
forecast_freight_demand <- function(historical_data_path, forecast_horizon_months = 12) {
  message("Reading historical rail transport records...")
  
  # Load historical demand metrics (Origin-Destination pairs)
  # Expected columns: Date, Origin, Destination, Commodity, Tonnes, TEU
  df <- read_csv(historical_data_path) %>%
    mutate(Date = yearmonth(Date)) %>%
    as_tsibble(index = Date, key = c(Origin, Destination, Commodity))
  
  message("Decomposing time series and checking seasonality...")
  # Seasonal decomposition of rail freight volumes
  df_decomp <- df %>%
    model(STL(Tonnes ~ trend(window = 12) + season(window = "periodic"))) %>%
    components()
  
  message("Fitting multi-series statistical models (ARIMA and ETS)...")
  # Fit ETS (Exponential Smoothing) and ARIMA models
  fit <- df %>%
    model(
      ets_model = ETS(Tonnes),
      arima_model = ARIMA(Tonnes ~ pdq() + PDQ())
    )
  
  message("Evaluating best performing model using AICc and cross-validation...")
  # Choose best model (combination) to forecast P10/P50/P90 margins
  fc <- fit %>%
    forecast(h = paste(forecast_horizon_months, "months"))
  
  # Extract prediction intervals (P10, P50, P90)
  forecasts_with_quantiles <- fc %>%
    hilo(level = c(80, 95)) %>%
    mutate(
      P50_tonnes = mean(Tonnes),
      P10_tonnes = quantile(Tonnes, 0.10),
      P90_tonnes = quantile(Tonnes, 0.90)
    ) %>%
    as_tibble() %>%
    select(Date, Origin, Destination, Commodity, .model, P10_tonnes, P50_tonnes, P90_tonnes)
  
  return(forecasts_with_quantiles)
}

# Monte Carlo simulation for network-wide disruption impact on revenue
simulate_disruption_impact <- function(routes_df, scenarios_df, iterations = 5000) {
  # Estimate economic risk of freight delay using probability distributions
  results <- tibble(
    iteration = 1:iterations,
    total_revenue_loss = 0,
    network_delay_minutes = 0
  )
  
  for (i in 1:iterations) {
    # Randomly draw disruptions based on historical probability density
    drawn_disruptions <- scenarios_df %>%
      mutate(
        active = rbinom(n(), 1, probability_of_occurrence),
        actual_duration = if_else(active == 1, rlnorm(n(), log(mean_duration_hours), 0.5), 0)
      ) %>%
      filter(active == 1)
    
    # Calculate penalty costs and repositioning delays
    revenue_loss <- sum(drawn_disruptions$actual_duration * drawn_disruptions$penalty_cost_per_hour)
    delay_min <- sum(drawn_disruptions$actual_duration * 60)
    
    results$total_revenue_loss[i] <- revenue_loss
    results$network_delay_minutes[i] <- delay_min
  }
  
  # Calculate risk metrics
  p50_loss <- median(results$total_revenue_loss)
  p90_loss <- quantile(results$total_revenue_loss, 0.90)
  
  message(sprintf("Monte Carlo Risk Summary: P50 economic exposure is £%s, P90 exposure is £%s", 
                  round(p50_loss, 2), round(p90_loss, 2)))
  
  return(results)
}
