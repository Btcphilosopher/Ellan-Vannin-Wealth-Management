/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Core types for the Rail Freight Optimisation Platform

export interface StationNode {
  id: string;
  name: string;
  type: 'station' | 'terminal' | 'yard' | 'port' | 'junction' | 'depot';
  lat: number;
  lng: number;
}

export interface TrackSectionEdge {
  id: string;
  source: string;
  target: string;
  distance: number; // km
  maxSpeed: number; // km/h
  gradient: number; // average % (ruling gradient)
  electrification: 'None' | '25kV AC' | '750V DC' | 'Multi';
  signalling: 'ETCS Level 2' | 'AWS/TPWS' | 'CBTC' | 'Block';
  axleLoadLimit: number; // tonnes
  loadingGauge: 'W6a' | 'W10' | 'W12' | 'GC'; // GC is largest European, W6a/W10 UK standard
  trainLengthLimit: number; // meters
  maxTrainWeight: number; // tonnes
  tracksCount: number;
  availablePaths: number; // paths per hour
  engineeringPossessions: boolean;
  congestionLevel: number; // 0 (empty) to 1 (saturated)
}

export interface FreightOrder {
  id: string;
  customer: string;
  origin: string;
  destination: string;
  commodity: 'Bulk' | 'Containers' | 'Automotive' | 'Steel' | 'Aggregates' | 'Timber' | 'Agricultural' | 'Parcels' | 'Waste' | 'Liquid';
  weight: number; // tonnes
  volume: number; // m3
  pallets?: number;
  containers?: {
    type: '20ft' | '40ft' | '45ft' | 'Semi-Trailer' | 'Tank' | 'Reefer';
    count: number;
  }[];
  dangerousGoods: boolean;
  tempRequirement?: string;
  earliestDeparture: string; // ISO string
  latestArrival: string; // ISO string
  maxTransitTime: number; // hours
  willingnessToPay: number; // £
  priority: 'Low' | 'Standard' | 'Express' | 'Overnight';
}

export interface Wagon {
  id: string;
  type: string; // e.g., 'BYA Steel Hood', 'FEA Intermodal Flat', 'HHB Hopper'
  class: 'Flat' | 'Hopper' | 'Box' | 'Tank' | 'CarCarrier';
  tareWeight: number; // tonnes
  payloadCapacity: number; // tonnes
  volumeCapacity: number; // m3
  length: number; // meters
  brakeType: 'Air' | 'Vacuum' | 'Dual';
  axleLoad: number; // tonnes
  commodityCompatibility: string[];
  loadingGauge: 'W6a' | 'W10' | 'W12' | 'GC';
  status: 'Available' | 'In-Service' | 'Maintenance' | 'Staged_Empty';
  location: string; // Node ID
  lastMaintenance: string;
}

export interface Locomotive {
  id: string;
  name: string;
  class: string; // e.g., 'Class 66', 'Class 88', 'EuroSprinter'
  powerType: 'Diesel' | 'Electric' | 'Bi-Mode';
  powerOutput: number; // kW
  tractiveEffort: number; // kN
  mass: number; // tonnes
  energyConsumptionRate: number; // litres/km or kWh/km
  maxSpeed: number; // km/h
  brakeCapability: string;
  routeCompatibility: string[];
  electrificationCompatibility: ('None' | '25kV AC' | '750V DC')[];
  status: 'Available' | 'In-Service' | 'Maintenance';
  location: string;
}

export interface TrainPath {
  id: string;
  origin: string;
  destination: string;
  departureTime: string;
  arrivalTime: string;
  intermediateStops: { nodeId: string; passingTime: string }[];
  priority: 'High' | 'Medium' | 'Low';
  allocatedWagons: string[];
  allocatedLocomotives: string[];
  bookedPayloadWeight: number;
  bookedWagonSlots: number; // Count of containers/wagons
  maxPayloadCapacity: number;
  maxWagonSlots: number;
}

export interface Terminal {
  id: string;
  name: string;
  arrivalTracks: number;
  departureTracks: number;
  craneCapacity: number; // TEU/hr
  loadingBays: number;
  warehouseCapacity: number; // m3
  handlingSpeed: number; // tonnes/hr
  openingHours: string;
  storageCostPerDay: number; // £/TEU
  terminalCharges: number; // £/handling
}

export interface Yard {
  id: string;
  name: string;
  shuntTracks: number;
  maxStorageWagons: number;
  shuntingSpeed: number; // wagons/hr
  operatingHours: string;
  dailyStorageCost: number; // £/wagon
}

export interface OptimisationResult {
  runId: string;
  timestamp: string;
  method: 'MILP' | 'Min-Cost Flow' | 'Constraint Programming' | 'Heuristic' | 'Genetic' | 'Robust';
  metrics: {
    totalRevenue: number;
    tractionCost: number;
    trackAccessCharge: number;
    wagonCost: number;
    terminalCost: number;
    crewCost: number;
    maintenanceCost: number;
    energyCost: number;
    emptyRepositioningCost: number;
    delayCost: number;
    netMargin: number;
    netMarginPercent: number;
    emptyRepositioningKm: number;
    avoidedEmptyRepositioningKm: number;
    networkUtilisation: number;
  };
  allocations: {
    orderId: string;
    customer: string;
    commodity: string;
    weight: number;
    allocatedTrainId: string;
    route: string[];
    wagonId: string;
    departureTime: string;
    arrivalTime: string;
    price: number;
    cost: number;
    margin: number;
  }[];
  emptyWagonRepositioning: {
    wagonId: string;
    wagonType: string;
    origin: string;
    destination: string;
    reason: 'Reposition to Demand' | 'Storage' | 'Maintenance' | 'Lease';
    distance: number;
    cost: number;
  }[];
}

export interface InfrastructureInvestment {
  id: string;
  name: string;
  type: 'Loop' | 'Terminal' | 'Electrification' | 'Double Track' | 'Gauge Upgrade' | 'Signalling' | 'Siding' | 'Fleet';
  description: string;
  capex: number; // £
  capacityGainPercent: number;
  additionalFreightTonnes: number;
  additionalAnnualRevenue: number;
  annualOpex: number;
  npv: number;
  irr: number;
  payback: number; // years
}

export interface DisruptionScenario {
  id: string;
  name: string;
  type: 'Locomotive Failure' | 'Wagon Defect' | 'Signalling Outage' | 'Line Closure' | 'Engineering Works' | 'Terminal Closure' | 'Weather Severe';
  affectedNodeOrEdge: string; // ID of station or section
  severity: 'Minor' | 'Moderate' | 'Critical';
  durationHours: number;
  recoveryPlan: {
    reRoutingRequired: boolean;
    suggestedAlternativePath: string[];
    swapsLocomotive: boolean;
    swapLocation?: string;
    delayMinutes: number;
    incrementalCost: number;
    description: string;
  };
}
