/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  MapPin, 
  TrendingUp, 
  AlertTriangle, 
  Code, 
  Layers, 
  TrendingDown, 
  DollarSign, 
  RefreshCw, 
  Play, 
  Plus, 
  Check, 
  Terminal, 
  Wrench, 
  Sparkles,
  ArrowRight,
  ShieldAlert,
  Sliders,
  HelpCircle,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  StationNode, 
  TrackSectionEdge, 
  FreightOrder, 
  Wagon, 
  Locomotive, 
  OptimisationResult, 
  InfrastructureInvestment, 
  DisruptionScenario 
} from './types';

export default function App() {
  // Navigation & Control State
  const [activeTab, setActiveTab] = useState<'control-tower' | 'network' | 'orders' | 'reposition' | 'disruption' | 'investments' | 'workspace'>('control-tower');
  const [optMethod, setOptMethod] = useState<'MILP' | 'Min-Cost Flow' | 'Constraint Programming' | 'Heuristic' | 'Genetic' | 'Robust'>('MILP');
  const [scenario, setScenario] = useState<string>('Current Network');

  // Simulation Data State
  const [network, setNetwork] = useState<{ stations: StationNode[]; trackSections: TrackSectionEdge[] }>({ stations: [], trackSections: [] });
  const [locomotives, setLocomotives] = useState<Locomotive[]>([]);
  const [wagons, setWagons] = useState<Wagon[]>([]);
  const [orders, setOrders] = useState<FreightOrder[]>([]);
  const [terminalsYards, setTerminalsYards] = useState<any[]>([]);
  const [optResult, setOptResult] = useState<OptimisationResult | null>(null);
  const [disruptions, setDisruptions] = useState<DisruptionScenario[]>([]);
  const [investments, setInvestments] = useState<InfrastructureInvestment[]>([]);
  const [forecasts, setForecasts] = useState<any[]>([]);

  // Workspace Code Editor State
  const [codeFiles, setCodeFiles] = useState<any[]>([]);
  const [selectedCodeId, setSelectedCodeId] = useState<string>('rust_routing');
  const [editorContent, setEditorContent] = useState<string>('');
  const [consoleLog, setConsoleLog] = useState<string>('Select a script file and click "Compile & Test" to execute simulation runs.');
  const [isCompiling, setIsCompiling] = useState<boolean>(false);

  // AI Assistant Chat State
  const [aiQuery, setAiQuery] = useState<string>('');
  const [aiResponse, setAiResponse] = useState<string>('');
  const [aiLoading, setAiLoading] = useState<boolean>(false);

  // New Freight Order Form State
  const [showOrderForm, setShowOrderForm] = useState<boolean>(false);
  const [newOrder, setNewOrder] = useState({
    customer: '',
    origin: 'MAN',
    destination: 'LON',
    commodity: 'Containers' as any,
    weight: 400,
    volume: 800,
    priority: 'Standard' as any,
    willingnessToPay: 11000,
    dangerousGoods: false,
    useContainerSpec: true,
    containersType: '40ft' as any,
    containersCount: 10
  });

  // UI Interactive States
  const [selectedStation, setSelectedStation] = useState<StationNode | null>(null);
  const [selectedEdge, setSelectedEdge] = useState<TrackSectionEdge | null>(null);
  const [activeDisruptionId, setActiveDisruptionId] = useState<string | null>(null);
  const [optimizing, setOptimizing] = useState<boolean>(false);

  // Load initial data
  useEffect(() => {
    fetchNetworkData();
    fetchLocomotives();
    fetchWagons();
    fetchOrders();
    fetchTerminalsYards();
    fetchOptimisation();
    fetchDisruptions();
    fetchInvestments();
    fetchForecasts();
    fetchCodeFiles();
  }, []);

  const fetchNetworkData = () => {
    fetch('/api/network').then(r => r.json()).then(setNetwork);
  };
  const fetchLocomotives = () => {
    fetch('/api/locomotives').then(r => r.json()).then(setLocomotives);
  };
  const fetchWagons = () => {
    fetch('/api/wagons').then(r => r.json()).then(setWagons);
  };
  const fetchOrders = () => {
    fetch('/api/freight-orders').then(r => r.json()).then(setOrders);
  };
  const fetchTerminalsYards = () => {
    fetch('/api/terminals-yards').then(r => r.json()).then(setTerminalsYards);
  };
  const fetchOptimisation = (methodOverride?: string) => {
    setOptimizing(true);
    const methodToUse = methodOverride || optMethod;
    fetch('/api/optimize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ method: methodToUse })
    })
      .then(r => r.json())
      .then(data => {
        setOptResult(data);
        setOptimizing(false);
      });
  };
  const fetchDisruptions = () => {
    fetch('/api/disruptions').then(r => r.json()).then(setDisruptions);
  };
  const fetchInvestments = () => {
    fetch('/api/investments').then(r => r.json()).then(setInvestments);
  };
  const fetchForecasts = () => {
    fetch('/api/forecast').then(r => r.json()).then(setForecasts);
  };
  const fetchCodeFiles = () => {
    fetch('/api/code-files')
      .then(r => r.json())
      .then(files => {
        setCodeFiles(files);
        const active = files.find((f: any) => f.id === selectedCodeId);
        if (active) setEditorContent(active.content);
      });
  };

  const handleSaveCode = () => {
    fetch('/api/code-files/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: selectedCodeId, content: editorContent })
    })
      .then(r => r.json())
      .then(() => {
        setConsoleLog(prev => prev + `\n[System] Successfully saved ${codeFiles.find(f => f.id === selectedCodeId)?.name} to workspace.`);
      });
  };

  const handleCompileCode = () => {
    setIsCompiling(true);
    fetch('/api/code-files/compile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: selectedCodeId })
    })
      .then(r => r.json())
      .then(data => {
        setConsoleLog(data.log);
        setIsCompiling(false);
      });
  };

  const handleAddOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const orderData = {
      customer: newOrder.customer || 'Commercial Client',
      origin: newOrder.origin,
      destination: newOrder.destination,
      commodity: newOrder.commodity,
      weight: Number(newOrder.weight),
      volume: Number(newOrder.volume),
      priority: newOrder.priority,
      willingnessToPay: Number(newOrder.willingnessToPay),
      dangerousGoods: newOrder.dangerousGoods,
      containers: newOrder.commodity === 'Containers' ? [{ type: newOrder.containersType, count: Number(newOrder.containersCount) }] : undefined
    };

    fetch('/api/freight-orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData)
    })
      .then(r => r.json())
      .then(() => {
        fetchOrders();
        fetchOptimisation();
        setShowOrderForm(false);
        // Reset form
        setNewOrder({
          customer: '',
          origin: 'MAN',
          destination: 'LON',
          commodity: 'Containers',
          weight: 400,
          volume: 800,
          priority: 'Standard',
          willingnessToPay: 11000,
          dangerousGoods: false,
          useContainerSpec: true,
          containersType: '40ft',
          containersCount: 10
        });
      });
  };

  const handleResetOrders = () => {
    fetch('/api/freight-orders/reset', { method: 'POST' })
      .then(r => r.json())
      .then(() => {
        fetchOrders();
        fetchOptimisation();
      });
  };

  const askGemini = (topic: 'disruption' | 'bottleneck' | 'general') => {
    setAiLoading(true);
    setAiResponse('');
    
    let activeDisruptions = disruptions;
    if (topic === 'disruption' && activeDisruptionId) {
      activeDisruptions = disruptions.filter(d => d.id === activeDisruptionId);
    }

    const bottlenecks = network.trackSections.filter(edge => edge.congestionLevel > 0.45);

    fetch('/api/gemini/advice', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        topic,
        activeDisruptions,
        bottlenecks
      })
    })
      .then(r => r.json())
      .then(data => {
        setAiResponse(data.advice);
        setAiLoading(false);
      });
  };

  // Helper formatting values
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP', maximumFractionDigits: 0 }).format(val);
  };

  // Simulation scenario parameters tweaking
  const handleScenarioChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const nextScenario = e.target.value;
    setScenario(nextScenario);

    // Apply scenario changes to mock state local values instantly for real-time digital twin feedback!
    const updatedSections = [...network.trackSections].map(sec => {
      let edge = { ...sec };
      if (nextScenario === 'Electrified Network') {
        edge.electrification = '25kV AC';
      } else if (nextScenario === 'Longer Trains') {
        edge.trainLengthLimit = 900;
      }
      return edge;
    });

    let updatedOrders = [...orders];
    if (nextScenario === '+25% Freight Demand') {
      // Duplicate some high value orders
      const currentLen = orders.length;
      for (let i = 0; i < 3; i++) {
        if (orders[i]) {
          updatedOrders.push({
            ...orders[i],
            id: `ORD-EXT-${i+1}`,
            customer: `${orders[i].customer} (Extended)`,
            earliestDeparture: new Date(Date.now() + 2*3600000).toISOString()
          });
        }
      }
    }

    setNetwork(prev => ({ ...prev, trackSections: updatedSections }));
    setOrders(updatedOrders);
    fetchOptimisation();
  };

  return (
    <div className="min-h-screen bg-[#0A0B10] text-slate-300 flex flex-col font-sans" id="app-root">
      
      {/* HEADER / BRAND BAR */}
      <header className="bg-[#0F111A] text-white py-4 px-6 border-b border-slate-800 flex flex-wrap justify-between items-center gap-4 z-10" id="global-header">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500 rounded-none text-slate-950 shadow-inner">
            <Activity className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-semibold tracking-tight text-white uppercase">RAIL FREIGHT <span className="text-amber-500 italic font-serif">CONTROL TOWER</span></h1>
            <p className="text-[10px] text-slate-500 font-bold tracking-wider uppercase font-mono">System Engine: RUST_CORE // R_ANALYTICS ACTIVE</p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-3 flex-wrap">
          
          <div className="flex items-center gap-2 bg-[#0E0F16] px-3 py-1.5 rounded-none border border-slate-800">
            <Sliders className="w-4 h-4 text-amber-500" />
            <span className="text-xs text-slate-400 font-medium font-mono">Scenario:</span>
            <select 
              value={scenario}
              onChange={handleScenarioChange}
              className="bg-transparent text-xs text-white border-none outline-none font-semibold font-mono cursor-pointer focus:ring-0"
              id="scenario-select"
            >
              <option value="Current Network" className="bg-[#0E0F16] text-white">Current Network (Default)</option>
              <option value="+25% Freight Demand" className="bg-[#0E0F16] text-white">+25% Demand Spike</option>
              <option value="Electrified Network" className="bg-[#0E0F16] text-white">100% Electrified Corridor</option>
              <option value="Longer Trains" className="bg-[#0E0F16] text-white">900m Siding Capacity Upgrade</option>
            </select>
          </div>

          <div className="flex items-center gap-2 bg-[#0E0F16] px-3 py-1.5 rounded-none border border-slate-800">
            <TrendingUp className="w-4 h-4 text-amber-500" />
            <span className="text-xs text-slate-400 font-medium font-mono">Solver:</span>
            <select 
              value={optMethod}
              onChange={(e) => {
                setOptMethod(e.target.value as any);
                fetchOptimisation(e.target.value);
              }}
              className="bg-transparent text-xs text-white border-none outline-none font-semibold font-mono cursor-pointer focus:ring-0"
              id="solver-method-select"
            >
              <option value="MILP" className="bg-[#0E0F16] text-white">Mixed-Integer Linear (MILP)</option>
              <option value="Min-Cost Flow" className="bg-[#0E0F16] text-white">Min-Cost Network Flow Heuristics</option>
              <option value="Constraint Programming" className="bg-[#0E0F16] text-white">Constraint Timetabler</option>
              <option value="Heuristic" className="bg-[#0E0F16] text-white">Greedy Heuristic (Fast)</option>
              <option value="Genetic" className="bg-[#0E0F16] text-white">Genetic Train Formation Heuristics</option>
              <option value="Robust" className="bg-[#0E0F16] text-white">Robust Disruption-Buffered Optimizer</option>
            </select>
          </div>

          <button 
            onClick={() => fetchOptimisation()}
            disabled={optimizing}
            className="flex items-center gap-2 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 disabled:bg-slate-800 text-slate-950 font-bold px-4 py-1.5 rounded-none text-xs transition duration-150 shadow font-mono tracking-wider uppercase"
            id="re-optimize-btn"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${optimizing ? 'animate-spin' : ''}`} />
            {optimizing ? 'SOLVING...' : 'RUN SOLVER'}
          </button>
        </div>
      </header>

      {/* VIEW SELECTION SUB-BAR */}
      <nav className="bg-[#0F111A] border-b border-slate-800 px-6 flex overflow-x-auto gap-1 scrollbar-none" id="main-tabs">
        <button 
          onClick={() => setActiveTab('control-tower')}
          className={`py-3 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-all duration-200 ${activeTab === 'control-tower' ? 'border-amber-500 text-amber-500 bg-[#0E0F16] font-serif italic' : 'border-transparent text-slate-400 hover:text-white'}`}
          id="tab-control-tower"
        >
          <Activity className="w-4 h-4 inline-block mr-1.5 align-text-bottom" />
          Control Tower
        </button>
        <button 
          onClick={() => setActiveTab('network')}
          className={`py-3 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-all duration-200 ${activeTab === 'network' ? 'border-amber-500 text-amber-500 bg-[#0E0F16] font-serif italic' : 'border-transparent text-slate-400 hover:text-white'}`}
          id="tab-network"
        >
          <Layers className="w-4 h-4 inline-block mr-1.5 align-text-bottom" />
          Digital Twin Network
        </button>
        <button 
          onClick={() => setActiveTab('orders')}
          className={`py-3 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-all duration-200 ${activeTab === 'orders' ? 'border-amber-500 text-amber-500 bg-[#0E0F16] font-serif italic' : 'border-transparent text-slate-400 hover:text-white'}`}
          id="tab-orders"
        >
          <Database className="w-4 h-4 inline-block mr-1.5 align-text-bottom" />
          Order Book & Capacity Market
        </button>
        <button 
          onClick={() => setActiveTab('reposition')}
          className={`py-3 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-all duration-200 ${activeTab === 'reposition' ? 'border-amber-500 text-amber-500 bg-[#0E0F16] font-serif italic' : 'border-transparent text-slate-400 hover:text-white'}`}
          id="tab-reposition"
        >
          <TrendingUp className="w-4 h-4 inline-block mr-1.5 align-text-bottom" />
          Repositioning & Backhaul
        </button>
        <button 
          onClick={() => setActiveTab('disruption')}
          className={`py-3 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-all duration-200 ${activeTab === 'disruption' ? 'border-amber-500 text-amber-500 bg-[#0E0F16] font-serif italic' : 'border-transparent text-slate-400 hover:text-white'}`}
          id="tab-disruption"
        >
          <AlertTriangle className="w-4 h-4 inline-block mr-1.5 align-text-bottom" />
          Disruption Engine
        </button>
        <button 
          onClick={() => setActiveTab('investments')}
          className={`py-3 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-all duration-200 ${activeTab === 'investments' ? 'border-amber-500 text-amber-500 bg-[#0E0F16] font-serif italic' : 'border-transparent text-slate-400 hover:text-white'}`}
          id="tab-investments"
        >
          <TrendingDown className="w-4 h-4 inline-block mr-1.5 align-text-bottom" />
          Investment & Analytics
        </button>
        <button 
          onClick={() => setActiveTab('workspace')}
          className={`py-3 px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-all duration-200 ${activeTab === 'workspace' ? 'border-amber-500 text-amber-500 bg-[#0E0F16] font-serif italic' : 'border-transparent text-slate-400 hover:text-white'}`}
          id="tab-workspace"
        >
          <Code className="w-4 h-4 inline-block mr-1.5 align-text-bottom" />
          Rust & R Workspace
        </button>
      </nav>

      {/* CORE FRAMEWORK WORKSPACE CONTAINER */}
      <main className="flex-1 p-6 overflow-y-auto" id="main-content">
        <AnimatePresence mode="wait">
          
          {/* TAB 1: CONTROL TOWER */}
          {activeTab === 'control-tower' && (
            <motion.div 
              key="control-tower-view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="space-y-6"
              id="control-tower-pane"
            >
              {/* TOP LEVEL METRIC CARDS */}
              {optResult && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="kpi-grid">
                  <div className="bg-[#0E0F16] p-5 rounded-none border border-slate-800 shadow-none relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-amber-500"></div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1 font-mono">Financial Yield</span>
                    <div className="text-2xl font-bold text-white font-serif italic">{formatCurrency(optResult.metrics.totalRevenue)}</div>
                    <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1 mt-1 font-mono">
                      <DollarSign className="w-3 h-3" /> Net: {formatCurrency(optResult.metrics.netMargin)} ({optResult.metrics.netMarginPercent}%)
                    </span>
                  </div>

                  <div className="bg-[#0E0F16] p-5 rounded-none border border-slate-800 shadow-none relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-amber-500"></div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1 font-mono">Network Dwell / Utilisation</span>
                    <div className="text-2xl font-bold text-white font-serif italic">{optResult.metrics.networkUtilisation}%</div>
                    <div className="w-full bg-slate-900 rounded-none h-1.5 mt-2 overflow-hidden border border-slate-800">
                      <div className="bg-amber-500 h-1.5" style={{ width: `${optResult.metrics.networkUtilisation}%` }}></div>
                    </div>
                  </div>

                  <div className="bg-[#0E0F16] p-5 rounded-none border border-slate-800 shadow-none relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-amber-500"></div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1 font-mono">Empty Wagon Burden</span>
                    <div className="text-2xl font-bold text-white font-serif italic">{optResult.metrics.emptyRepositioningKm.toLocaleString()} km</div>
                    <span className="text-xs text-rose-400 font-semibold flex items-center gap-1 mt-1 font-mono">
                      Cost: {formatCurrency(optResult.metrics.emptyRepositioningCost)}
                    </span>
                  </div>

                  <div className="bg-[#0E0F16] p-5 rounded-none border border-slate-800 shadow-none relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-amber-500"></div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1 font-mono">Repositioning Avoided</span>
                    <div className="text-2xl font-bold text-emerald-400 font-serif italic">{optResult.metrics.avoidedEmptyRepositioningKm.toLocaleString()} km</div>
                    <span className="text-xs text-slate-400 mt-1 block font-mono">Backhaul demand matched matches</span>
                  </div>
                </div>
              )}

              {/* CORE ACTIVE TRAIN TIMETABLE VIEW */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="dashboard-sections">
                
                {/* Active Trains Table */}
                <div className="lg:col-span-2 bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4">
                  <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                    <div>
                      <h2 className="text-base font-semibold text-white font-serif italic">Optimal Train Allocations & Margin Plans</h2>
                      <p className="text-xs text-slate-400 font-mono">Heuristics matches cargo requirements to wagon classes & track axle limits</p>
                    </div>
                    <span className="px-2 py-1 bg-slate-900 text-slate-300 text-[10px] font-mono border border-slate-800">
                      ALLOCATIONS: {optResult?.allocations.length || 0}
                    </span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-500 uppercase font-bold tracking-wider text-[10px] font-mono">
                          <th className="pb-3">Train / Flow</th>
                          <th className="pb-3">Route Corridor</th>
                          <th className="pb-3 text-right">Weight</th>
                          <th className="pb-3 text-center">Wagons</th>
                          <th className="pb-3 text-right">Revenue</th>
                          <th className="pb-3 text-right">Margin</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900 font-medium font-mono">
                        {optResult?.allocations.map((alloc) => (
                          <tr key={alloc.orderId} className="hover:bg-slate-900/30 transition">
                            <td className="py-3">
                              <div className="font-bold text-white">{alloc.allocatedTrainId}</div>
                              <div className="text-[10px] text-slate-500">{alloc.customer} ({alloc.commodity})</div>
                            </td>
                            <td className="py-3">
                              <div className="flex items-center gap-1">
                                <span className="font-bold text-slate-300">{alloc.route[0]}</span>
                                <ArrowRight className="w-3 h-3 text-slate-500" />
                                <span className="font-bold text-slate-300">{alloc.route[alloc.route.length - 1]}</span>
                              </div>
                              <div className="text-[10px] text-slate-500">{alloc.route.join(' → ')}</div>
                            </td>
                            <td className="py-3 text-right text-slate-300">{alloc.weight} t</td>
                            <td className="py-3 text-center text-slate-300">{alloc.wagonCount}</td>
                            <td className="py-3 text-right font-bold text-white">{formatCurrency(alloc.price)}</td>
                            <td className="py-3 text-right">
                              <span className={`px-2 py-0.5 rounded-none font-bold text-[11px] ${alloc.margin > 0 ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-900/40' : 'bg-rose-950/40 text-rose-400 border border-rose-900/40'}`}>
                                {formatCurrency(alloc.margin)}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* AI DECISION ADVISORY COOP */}
                <div className="bg-[#0E0F16] text-white rounded-none border border-slate-800 p-6 space-y-4 flex flex-col justify-between relative">
                  <div className="absolute top-0 right-0 bg-amber-500 text-black font-mono text-[9px] font-bold px-2 py-0.5 tracking-wider uppercase">
                    GEMINI ENGINE
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-amber-500">
                      <Sparkles className="w-5 h-5 animate-pulse" />
                      <h3 className="font-semibold text-sm tracking-wide uppercase font-serif italic">AI Control Tower Advisor</h3>
                    </div>
                    
                    <p className="text-xs text-slate-400 leading-relaxed font-mono">
                      Leverage Gemini 2.5-Flash to analyze network parameters, route gradient economics, empty wagon bottlenecks, or disruption mitigation schedules.
                    </p>

                    <div className="bg-[#0A0B10] rounded-none p-4 border border-slate-800 text-xs text-slate-300 font-mono space-y-2 h-[220px] overflow-y-auto scrollbar-thin">
                      {aiLoading ? (
                        <div className="flex items-center justify-center h-full gap-2 text-slate-400">
                          <RefreshCw className="w-4 h-4 animate-spin text-amber-500" />
                          <span>Gemini is generating strategy...</span>
                        </div>
                      ) : aiResponse ? (
                        <p className="whitespace-pre-wrap leading-relaxed">{aiResponse}</p>
                      ) : (
                        <div className="text-slate-500 italic h-full flex items-center justify-center text-center px-4">
                          Select an analysis perspective below to prompt structural recommendations.
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">Select Perspective:</span>
                    <div className="grid grid-cols-3 gap-2">
                      <button 
                        onClick={() => askGemini('general')}
                        className="py-2 px-1 bg-[#0A0B10] hover:bg-slate-900 active:bg-slate-900 text-[10px] font-mono font-bold rounded-none border border-slate-800 text-slate-300 transition"
                      >
                        Wagon Economics
                      </button>
                      <button 
                        onClick={() => askGemini('bottleneck')}
                        className="py-2 px-1 bg-[#0A0B10] hover:bg-slate-900 active:bg-slate-900 text-[10px] font-mono font-bold rounded-none border border-slate-800 text-slate-300 transition"
                      >
                        Bottlenecks
                      </button>
                      <button 
                        onClick={() => askGemini('disruption')}
                        className="py-2 px-1 bg-[#0A0B10] hover:bg-slate-900 active:bg-slate-900 text-[10px] font-mono font-bold rounded-none border border-slate-800 text-slate-300 transition"
                      >
                        Incidents Plan
                      </button>
                    </div>
                  </div>
                </div>

              </div>
            </motion.div>
          )}

          {/* TAB 2: DIGITAL TWIN NETWORK */}
          {activeTab === 'network' && (
            <motion.div 
              key="network-twin"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in"
              id="digital-twin-pane"
            >
              {/* Interactive SVG Network Graph Map */}
              <div className="lg:col-span-2 bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4">
                <div>
                  <h2 className="text-base font-semibold text-white font-serif italic">Rail Network Digital Twin Topology</h2>
                  <p className="text-xs text-slate-400 font-mono">Interactive SVG. Hover nodes to view terminals & yards. Hover lines to see track sections.</p>
                </div>

                <div className="relative bg-[#0A0B10] rounded-none p-2 h-[450px] overflow-hidden flex items-center justify-center border border-slate-800" id="network-map-container">
                  
                  {/* SVG Canvas Map */}
                  <svg viewBox="0 0 800 600" className="w-full h-full max-h-[420px]" id="network-svg">
                    
                    {/* Drawing Track Edges (Underlay lines) */}
                    {network.trackSections && network.trackSections.map((edge) => {
                      const srcNode = network.stations.find(s => s.id === edge.source);
                      const tgtNode = network.stations.find(s => s.id === edge.target);
                      if (!srcNode || !tgtNode) return null;

                      // Map Lat Lng to SVG X Y coordinate space
                      const x1 = (srcNode.lng + 5) * 80 + 350;
                      const y1 = (60 - srcNode.lat) * 70 + 120;
                      const x2 = (tgtNode.lng + 5) * 80 + 350;
                      const y2 = (60 - tgtNode.lat) * 70 + 120;

                      // Determine color by congestion level
                      const isCongested = edge.congestionLevel > 0.5;
                      const edgeColor = edge.engineeringPossessions ? '#f43f5e' : (isCongested ? '#f59e0b' : '#10b981');

                      return (
                        <g 
                          key={edge.id}
                          className="cursor-pointer group"
                          onMouseEnter={() => setSelectedEdge(edge)}
                        >
                          {/* Hover path buffer */}
                          <line 
                             x1={x1} y1={y1} x2={x2} y2={y2} 
                             stroke="transparent" 
                             strokeWidth="12" 
                          />
                          {/* Actual track section */}
                          <line 
                            x1={x1} y1={y1} x2={x2} y2={y2} 
                            stroke={edgeColor} 
                            strokeWidth={selectedEdge?.id === edge.id ? "4" : "2"} 
                            strokeDasharray={edge.electrification === 'None' ? "5,3" : "none"}
                            className="transition-all duration-200"
                          />
                          {/* Core flow directional glow */}
                          <circle r="4" fill={edgeColor}>
                            <animateMotion 
                              path={`M ${x1} ${y1} L ${x2} ${y2}`} 
                              dur="6s" 
                              repeatCount="indefinite" 
                            />
                          </circle>
                        </g>
                      );
                    })}

                    {/* Drawing Station Nodes */}
                    {network.stations && network.stations.map((node) => {
                      const x = (node.lng + 5) * 80 + 350;
                      const y = (60 - node.lat) * 70 + 120;

                      let nodeColor = '#3b82f6'; // junction / station
                      if (node.type === 'terminal') nodeColor = '#10b981';
                      if (node.type === 'yard') nodeColor = '#8b5cf6';
                      if (node.type === 'port') nodeColor = '#f59e0b';

                      return (
                        <g 
                          key={node.id} 
                          className="cursor-pointer group"
                          transform={`translate(${x}, ${y})`}
                          onMouseEnter={() => setSelectedStation(node)}
                        >
                          <circle 
                            r={selectedStation?.id === node.id ? "10" : "7"} 
                            fill={nodeColor}
                            className="transition-all duration-150 shadow"
                            stroke="#0A0B10"
                            strokeWidth="2"
                          />
                          <text 
                            y="-14" 
                            textAnchor="middle" 
                            fill="#f8fafc" 
                            fontSize="10" 
                            fontWeight="bold"
                            className="bg-slate-950 font-mono px-1 rounded-none filter drop-shadow"
                          >
                            {node.id}
                          </text>
                        </g>
                      );
                    })}
                  </svg>

                  {/* Micro Map Legend Overlay */}
                  <div className="absolute bottom-3 left-3 bg-slate-950/90 backdrop-blur border border-slate-800 p-2.5 rounded-none text-[10px] space-y-1 text-slate-300 font-mono">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]"></span>
                      <span>Terminal / Port</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#8b5cf6]"></span>
                      <span>Shunting Yard</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#3b82f6]"></span>
                      <span>Junction / Depot</span>
                    </div>
                    <div className="flex items-center gap-1.5 pt-1 border-t border-slate-800">
                      <span className="w-4 h-0.5 border-t border-dashed border-slate-400"></span>
                      <span>Non-Electrified Track</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Selected Element Specs Card */}
              <div className="space-y-6" id="digital-twin-details">
                {/* Track Details */}
                <div className="bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-800 font-mono">
                    <Activity className="w-4 h-4 text-amber-500" />
                    Section Telemetry Inspector
                  </h3>

                  {selectedEdge ? (
                    <div className="space-y-3 font-medium text-xs text-slate-400 font-mono" id="selected-edge-info">
                      <div className="flex justify-between">
                        <span>Section ID:</span>
                        <span className="font-bold text-white">{selectedEdge.id}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Connection Path:</span>
                        <span className="font-bold text-white">{selectedEdge.source} ↔ {selectedEdge.target}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Track Distance:</span>
                        <span className="font-bold text-white">{selectedEdge.distance} km</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Steepest Ruling Gradient:</span>
                        <span className="font-bold text-white">{selectedEdge.gradient}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Electrified Tension:</span>
                        <span className="font-bold text-white">{selectedEdge.electrification}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Loading Gauge Standard:</span>
                        <span className="font-bold text-amber-500">{selectedEdge.loadingGauge} compatible</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Max Axle Load Limit:</span>
                        <span className="font-bold text-white">{selectedEdge.axleLoadLimit} tonnes</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Active Siding Max Length:</span>
                        <span className="font-bold text-white">{selectedEdge.trainLengthLimit} meters</span>
                      </div>
                      <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                        <span>Sect. Traffic Congestion:</span>
                        <span className={`px-2 py-0.5 rounded-none font-bold ${selectedEdge.congestionLevel > 0.5 ? 'bg-orange-950/40 text-orange-400 border border-orange-900/40' : 'bg-emerald-950/40 text-emerald-400 border border-emerald-900/40'}`}>
                          {(selectedEdge.congestionLevel * 100).toFixed(0)}% Saturated
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="text-slate-500 italic text-center py-6 font-mono">
                      Hover over any edge line on the Digital Twin topology to inspect track section parameters.
                    </div>
                  )}
                </div>

                {/* Station Terminal/Yard Details */}
                <div className="bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-800 font-mono">
                    <MapPin className="w-4 h-4 text-amber-500" />
                    Terminal & Yard Hub Analyzer
                  </h3>

                  {selectedStation ? (
                    <div className="space-y-3 font-medium text-xs text-slate-400 font-mono" id="selected-station-info">
                      <div className="flex justify-between">
                        <span>Station Name:</span>
                        <span className="font-bold text-white">{selectedStation.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Type Category:</span>
                        <span className="font-bold uppercase text-amber-500 text-[10px]">{selectedStation.type}</span>
                      </div>

                      {/* Display Terminal/Yard capacity specs merged from DB list */}
                      {(() => {
                        const spec = terminalsYards.find(t => t.id === selectedStation.id);
                        if (!spec) return null;
                        if (selectedStation.type === 'yard') {
                          return (
                            <>
                              <div className="flex justify-between">
                                <span>Shunting Tracks:</span>
                                <span className="font-bold text-white">{spec.shuntTracks}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Max Wagon Storage:</span>
                                <span className="font-bold text-white">{spec.maxStorageWagons} wagons</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Shunting Sorting Speed:</span>
                                <span className="font-bold text-white">{spec.shuntingSpeed} wagons/hr</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Daily Wagon Dwell Cost:</span>
                                <span className="font-bold text-white">£{spec.dailyStorageCost}/wagon</span>
                              </div>
                            </>
                          );
                        } else {
                          return (
                            <>
                              <div className="flex justify-between">
                                <span>Crane Handling Cap:</span>
                                <span className="font-bold text-white">{spec.craneCapacity} TEU/hr</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Bimodal Loading Bays:</span>
                                <span className="font-bold text-white">{spec.loadingBays} bays</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Warehouse Storage:</span>
                                <span className="font-bold text-white">{spec.warehouseCapacity.toLocaleString()} m³</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Standard Handling Charge:</span>
                                <span className="font-bold text-white">£{spec.terminalCharges} / train</span>
                              </div>
                            </>
                          );
                        }
                      })()}
                    </div>
                  ) : (
                    <div className="text-slate-500 italic text-center py-6 font-mono">
                      Hover over any station dot on the Digital Twin topology to inspect capacity parameters.
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 3: ORDER BOOK & CAPACITY MARKET */}
          {activeTab === 'orders' && (
            <motion.div 
              key="orders-market"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="space-y-6"
              id="order-book-pane"
            >
              {/* Order form toggle trigger and action bar */}
              <div className="flex justify-between items-center gap-4">
                <div>
                  <h2 className="text-lg font-bold text-white font-serif italic">Freight Ledger & Capacity Broker</h2>
                  <p className="text-xs text-slate-400 font-mono">Examine current commercial demand contracts, or submit custom spot loads to match available locomotive payload capacity.</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setShowOrderForm(!showOrderForm)}
                    className="flex items-center gap-1 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-bold px-4 py-2 rounded-none text-xs transition duration-150 shadow font-mono"
                    id="add-order-toggle-btn"
                  >
                    <Plus className="w-4 h-4" />
                    SUBMIT FREIGHT DEMAND
                  </button>
                  <button 
                    onClick={handleResetOrders}
                    className="bg-slate-900 hover:bg-slate-850 active:bg-slate-800 text-slate-300 border border-slate-800 font-bold px-3 py-2 rounded-none text-xs transition duration-150 font-mono"
                    id="reset-ledger-btn"
                  >
                    Reset Ledger
                  </button>
                </div>
              </div>

              {/* MODAL / COLLAPSED ORDER FORM */}
              {showOrderForm && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="bg-[#0E0F16] rounded-none border border-slate-800 p-6 shadow-none space-y-4"
                  id="add-order-form-block"
                >
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-2 border-b border-slate-800 font-serif italic">Submit New Commercial Contract</h3>
                  <form onSubmit={handleAddOrder} className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-semibold">
                    <div>
                      <label className="block text-slate-400 mb-1 font-mono">Customer / Client:</label>
                      <input 
                        type="text" 
                        required
                        value={newOrder.customer}
                        onChange={(e) => setNewOrder({...newOrder, customer: e.target.value})}
                        className="w-full bg-[#0A0B10] border border-slate-800 rounded-none p-2 text-white focus:border-amber-500 outline-none font-mono font-normal"
                        placeholder="Liberty Steel, BMW, etc."
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1 font-mono">Origin Terminal:</label>
                      <select 
                        value={newOrder.origin}
                        onChange={(e) => setNewOrder({...newOrder, origin: e.target.value})}
                        className="w-full bg-[#0A0B10] border border-slate-800 rounded-none p-2 text-white focus:border-amber-500 outline-none font-mono font-normal"
                      >
                        {network.stations.map(s => <option key={s.id} value={s.id} className="bg-[#0E0F16]">{s.name} ({s.id})</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1 font-mono">Destination Terminal:</label>
                      <select 
                        value={newOrder.destination}
                        onChange={(e) => setNewOrder({...newOrder, destination: e.target.value})}
                        className="w-full bg-[#0A0B10] border border-slate-800 rounded-none p-2 text-white focus:border-amber-500 outline-none font-mono font-normal"
                      >
                        {network.stations.map(s => <option key={s.id} value={s.id} className="bg-[#0E0F16]">{s.name} ({s.id})</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1 font-mono">Commodity Type:</label>
                      <select 
                        value={newOrder.commodity}
                        onChange={(e) => setNewOrder({...newOrder, commodity: e.target.value as any})}
                        className="w-full bg-[#0A0B10] border border-slate-800 rounded-none p-2 text-white focus:border-amber-500 outline-none font-mono font-normal"
                      >
                        <option value="Containers" className="bg-[#0E0F16]">Containers / Intermodal</option>
                        <option value="Steel" className="bg-[#0E0F16]">Steel Cargo</option>
                        <option value="Aggregates" className="bg-[#0E0F16]">Aggregates / Construction</option>
                        <option value="Bulk" className="bg-[#0E0F16]">Bulk Freight</option>
                        <option value="Automotive" className="bg-[#0E0F16]">Automotive Carrier</option>
                        <option value="Liquid" className="bg-[#0E0F16]">Chemicals / Liquid</option>
                        <option value="Parcels" className="bg-[#0E0F16]">Parcels / Parcels Express</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1 font-mono">Cargo Weight (Tonnes):</label>
                      <input 
                        type="number" 
                        required
                        value={newOrder.weight}
                        onChange={(e) => setNewOrder({...newOrder, weight: Number(e.target.value)})}
                        className="w-full bg-[#0A0B10] border border-slate-800 rounded-none p-2 text-white focus:border-amber-500 outline-none font-mono font-normal"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1 font-mono">Willingness To Pay Price Limit (£):</label>
                      <input 
                        type="number" 
                        required
                        value={newOrder.willingnessToPay}
                        onChange={(e) => setNewOrder({...newOrder, willingnessToPay: Number(e.target.value)})}
                        className="w-full bg-[#0A0B10] border border-slate-800 rounded-none p-2 text-white focus:border-amber-500 outline-none font-mono font-normal"
                      />
                    </div>

                    {newOrder.commodity === 'Containers' && (
                      <>
                        <div>
                          <label className="block text-slate-400 mb-1 font-mono">Container Standard:</label>
                          <select 
                            value={newOrder.containersType}
                            onChange={(e) => setNewOrder({...newOrder, containersType: e.target.value as any})}
                            className="w-full bg-[#0A0B10] border border-slate-800 rounded-none p-2 text-white focus:border-amber-500 outline-none font-mono font-normal"
                          >
                            <option value="20ft" className="bg-[#0E0F16]">20ft Dry Van</option>
                            <option value="40ft" className="bg-[#0E0F16]">40ft Dry Van</option>
                            <option value="45ft" className="bg-[#0E0F16]">45ft High-Cube</option>
                            <option value="Tank" className="bg-[#0E0F16]">Tank Container</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-slate-400 mb-1 font-mono">Containers Count:</label>
                          <input 
                            type="number" 
                            required
                            value={newOrder.containersCount}
                            onChange={(e) => setNewOrder({...newOrder, containersCount: Number(e.target.value)})}
                            className="w-full bg-[#0A0B10] border border-slate-800 rounded-none p-2 text-white focus:border-amber-500 outline-none font-mono font-normal"
                          />
                        </div>
                      </>
                    )}

                    <div className="flex items-center gap-2 pt-6">
                      <input 
                        type="checkbox" 
                        id="dangerous" 
                        checked={newOrder.dangerousGoods}
                        onChange={(e) => setNewOrder({...newOrder, dangerousGoods: e.target.checked})}
                        className="w-4 h-4 rounded-none bg-[#0A0B10] border-slate-800 text-amber-500"
                      />
                      <label htmlFor="dangerous" className="text-slate-400 text-xs font-mono font-normal">Dangerous Goods (ADR Compatible)</label>
                    </div>

                    <div className="md:col-span-3 flex justify-end gap-2 pt-4">
                      <button 
                        type="button" 
                        onClick={() => setShowOrderForm(false)}
                        className="px-4 py-2 text-slate-400 border border-slate-800 rounded-none hover:bg-slate-900 transition font-mono"
                      >
                        Cancel
                      </button>
                      <button 
                        type="submit" 
                        className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-none font-bold transition shadow font-mono"
                        id="submit-order-form-btn"
                      >
                        Add Contract
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}

              {/* DEMAND LOGS CARDS GRID */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="ledger-cards-grid">
                {orders.map((order) => (
                  <div key={order.id} className="bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-5 space-y-3 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-slate-800"></div>
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="px-2 py-0.5 bg-slate-900 text-slate-300 text-[10px] font-mono border border-slate-800 font-bold uppercase">{order.id}</span>
                        <h4 className="text-sm font-bold text-white font-serif italic mt-1.5">{order.customer}</h4>
                      </div>
                      <span className={`px-2 py-0.5 border text-[10px] font-mono font-bold ${order.priority === 'Express' ? 'bg-orange-950/40 text-orange-400 border-orange-900/40' : 'bg-slate-900 text-slate-400 border-slate-800'}`}>
                        {order.priority.toUpperCase()}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs font-medium text-slate-400 pt-3 border-t border-slate-900 font-mono">
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase">Corridor:</span>
                        <div className="font-bold text-white text-sm mt-0.5 flex items-center gap-1.5">
                          {order.origin} <ArrowRight className="w-3.5 h-3.5 text-amber-500" /> {order.destination}
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase">Commodity / Weight:</span>
                        <div className="font-bold text-white text-sm mt-0.5">{order.commodity} ({order.weight}t)</div>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase">Max Transit Deadline:</span>
                        <div className="font-bold text-slate-300 mt-0.5">{order.maxTransitTime} hours</div>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase">Budget Price Yield:</span>
                        <div className="font-bold text-amber-400 text-sm mt-0.5 font-mono">{formatCurrency(order.willingnessToPay)}</div>
                      </div>
                    </div>

                    {order.dangerousGoods && (
                      <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-rose-950/20 text-rose-400 border border-rose-900/30 text-[10px] font-bold font-mono">
                        <ShieldAlert className="w-3.5 h-3.5" />
                        Dangerous Goods: requires specialized container flats & route validation
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* TAB 4: REPOSITIONING & BACKHAUL */}
          {activeTab === 'reposition' && (
            <motion.div 
              key="reposition-backhaul"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-6"
              id="repositioning-pane"
            >
              {/* Left Column: Empty Wagon Balances & Reposition Costs */}
              <div className="lg:col-span-2 bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4">
                <div>
                  <h2 className="text-base font-semibold text-white font-serif italic">Network Empty Wagon Repositioning Schedule</h2>
                  <p className="text-xs text-slate-400 font-mono">Heuristics solves empty repositioning to match subsequent corridor departures, minimizing empty wagon-kilometers.</p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-500 uppercase font-bold tracking-wider text-[10px]">
                        <th className="pb-3 font-mono">Wagon ID</th>
                        <th className="pb-3 font-mono">Wagon Class Type</th>
                        <th className="pb-3 font-mono">Origin Location</th>
                        <th className="pb-3 font-mono">Deficit Destination</th>
                        <th className="pb-3 text-right font-mono">Reposition Distance</th>
                        <th className="pb-3 text-right font-mono">Manning Cost</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-900 font-medium text-slate-300">
                      {optResult?.emptyWagonRepositioning && optResult.emptyWagonRepositioning.length > 0 ? (
                        optResult.emptyWagonRepositioning.map((repo, idx) => (
                          <tr key={idx} className="hover:bg-slate-950 transition">
                            <td className="py-3 font-mono font-bold text-white">{repo.wagonId}</td>
                            <td className="py-3 text-slate-400">{repo.wagonType}</td>
                            <td className="py-3 font-bold text-slate-300">{repo.origin}</td>
                            <td className="py-3 font-bold text-purple-400">{repo.destination}</td>
                            <td className="py-3 text-right font-mono text-slate-400">{repo.distance} km</td>
                            <td className="py-3 text-right font-bold text-amber-500 font-mono">{formatCurrency(repo.cost)}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-slate-500 italic font-mono">
                            No empty wagon repositioning schedules needed. Balance matches current demand profiles exactly.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Right Column: Backhaul Corridor Match Analysis */}
              <div className="bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-2 border-b border-slate-800 font-serif italic">Backhaul Route Synergies</h3>
                    <p className="text-xs text-slate-400 font-mono mt-1">Saves hundreds of deadhead-miles by pairing opposite directional flows onto identical block train runs.</p>
                  </div>

                  {/* Visual Corridor matches */}
                  <div className="space-y-3">
                    <div className="bg-slate-950/60 p-4 rounded-none border border-slate-800 flex justify-between items-center text-xs font-mono">
                      <div className="space-y-1">
                        <span className="font-bold text-white font-serif italic">Manchester ↔ London (Aggregates/Steel)</span>
                        <div className="text-[10px] text-emerald-400 font-bold">Yield Synergy: £14,200 repositioning saved</div>
                      </div>
                      <span className="px-2 py-1 bg-emerald-950/40 text-emerald-400 text-[10px] font-bold rounded-none border border-emerald-900/40">Matched</span>
                    </div>

                    <div className="bg-slate-950/60 p-4 rounded-none border border-slate-800 flex justify-between items-center text-xs font-mono">
                      <div className="space-y-1">
                        <span className="font-bold text-white font-serif italic">Felixstowe ↔ Leeds (Containers/Agri)</span>
                        <div className="text-[10px] text-emerald-400 font-bold">Yield Synergy: £9,800 repositioning saved</div>
                      </div>
                      <span className="px-2 py-1 bg-emerald-950/40 text-emerald-400 text-[10px] font-bold rounded-none border border-emerald-900/40">Matched</span>
                    </div>

                    <div className="bg-slate-950/60 p-4 rounded-none border border-slate-800 flex justify-between items-center text-xs font-mono">
                      <div className="space-y-1">
                        <span className="font-bold text-white font-serif italic">Glasgow ↔ Crewe (Parcels/Aggregates)</span>
                        <div className="text-[10px] text-slate-500">Potential flow matching available</div>
                      </div>
                      <span className="px-2 py-1 bg-slate-900 text-slate-400 text-[10px] font-bold rounded-none border border-slate-800">Analysing</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-950/40 p-4 rounded-none border border-slate-800 text-xs text-slate-300 space-y-1 font-medium mt-4 font-mono">
                  <div className="font-bold text-slate-400">Avoided Repositioning Kilometers:</div>
                  <p className="text-sm font-extrabold font-mono text-amber-500">{optResult ? optResult.metrics.avoidedEmptyRepositioningKm.toLocaleString() : '12,500'} km</p>
                  <p className="text-[10px] text-slate-500">Calculates to an estimated carbon saving of approx 4.2 tCO2e.</p>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 5: DISRUPTION ENGINE */}
          {activeTab === 'disruption' && (
            <motion.div 
              key="disruptions"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in"
              id="disruption-pane"
            >
              {/* Left Column: Active Incidents List */}
              <div className="lg:col-span-2 bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4">
                <div>
                  <h2 className="text-base font-semibold text-white font-serif italic">Rail Network Active Disruption Scenarios</h2>
                  <p className="text-xs text-slate-400 font-mono">Inject incidents below to verify real-time digital twin recovery pathing calculations.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {disruptions.map((dis) => (
                    <div 
                      key={dis.id} 
                      onClick={() => setActiveDisruptionId(dis.id)}
                      className={`cursor-pointer border p-5 rounded-none transition duration-150 relative overflow-hidden flex flex-col justify-between ${activeDisruptionId === dis.id ? 'border-amber-500 bg-amber-950/20' : 'border-slate-800 bg-[#0A0B10] hover:bg-slate-900'}`}
                    >
                      {/* Top ribbon */}
                      <div className="flex justify-between items-start gap-2 mb-3">
                        <div>
                          <span className="px-2 py-0.5 bg-red-950/50 text-red-400 border border-red-900/40 text-[9px] font-bold rounded-none uppercase font-mono">{dis.severity} Severity</span>
                          <h4 className="text-sm font-bold text-white font-serif italic mt-1.5">{dis.name}</h4>
                        </div>
                        <AlertTriangle className={`w-5 h-5 ${dis.severity === 'Critical' ? 'text-red-500 animate-pulse' : 'text-amber-500'}`} />
                      </div>

                      <div className="text-xs text-slate-400 font-medium space-y-2 mt-2 pt-2 border-t border-slate-900 font-mono">
                        <div className="flex justify-between">
                          <span>Incident Location:</span>
                          <span className="font-bold text-white">{dis.affectedNodeOrEdge}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Est. Duration:</span>
                          <span className="font-bold text-white">{dis.durationHours} hours</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Column: Calculated Recovery Plan details */}
              <div className="bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4 flex flex-col justify-between" id="recovery-plan-inspector">
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-2 border-b border-slate-800 font-mono flex items-center gap-2">
                    <Activity className="w-4 h-4 text-amber-500" />
                    Digital Twin Recovery Dispatcher
                  </h3>
                  
                  {activeDisruptionId ? (() => {
                    const activeDis = disruptions.find(d => d.id === activeDisruptionId);
                    if (!activeDis) return null;
                    return (
                      <div className="space-y-4 text-xs font-medium text-slate-400 font-mono" id="active-disruption-details">
                        <div className="bg-[#0A0B10] p-4 rounded-none border border-slate-800 space-y-2">
                          <span className="text-[10px] uppercase font-bold text-slate-500">Incident Overview:</span>
                          <p className="text-white leading-relaxed font-bold font-serif italic">{activeDis.recoveryPlan.description}</p>
                        </div>

                        <div className="space-y-2.5">
                          <div className="flex justify-between">
                            <span>Alternative Detour Path:</span>
                            <span className="font-bold text-amber-500">{activeDis.recoveryPlan.reRoutingRequired ? activeDis.recoveryPlan.suggestedAlternativePath.join(' ➔ ') : 'Not needed'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Train Delay Impact:</span>
                            <span className="font-bold text-white font-mono">+{activeDis.recoveryPlan.delayMinutes} minutes</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Incremental Operations Cost:</span>
                            <span className="font-bold text-red-400 font-mono">{formatCurrency(activeDis.recoveryPlan.incrementalCost)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Locomotive Swap Required:</span>
                            <span className="font-bold text-slate-300">{activeDis.recoveryPlan.swapsLocomotive ? `Yes, swap at ${activeDis.recoveryPlan.swapLocation}` : 'No'}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })() : (
                    <div className="text-slate-500 italic text-center py-12 font-mono">
                      Select an active network disruption on the left to inspect the digital twin’s simulated recovery, detour routes, and cost offsets.
                    </div>
                  )}
                </div>

                {activeDisruptionId && (
                  <button 
                    onClick={() => askGemini('disruption')}
                    className="w-full mt-6 py-2 px-4 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-bold rounded-none text-xs transition duration-150 flex items-center justify-center gap-2 font-mono"
                  >
                    <Sparkles className="w-4 h-4 text-slate-950" />
                    Query Gemini Recovery Strategy
                  </button>
                )}
              </div>
            </motion.div>
          )}

          {/* TAB 6: INVESTMENT & R FORECASTING */}
          {activeTab === 'investments' && (
            <motion.div 
              key="investments-pane"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="space-y-6"
              id="analytics-pane"
            >
              {/* Top Row: R forecasting line-area chart */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4">
                  <div>
                    <h2 className="text-base font-semibold text-white font-serif italic">R Forecast Engine: Cargo Demand Outlook (P10/P50/P90)</h2>
                    <p className="text-xs text-slate-400 font-mono">Uses time series models in fable to model growth, seasonality, and uncertainty curves.</p>
                  </div>

                  {/* Beautiful custom styled SVG forecasting chart */}
                  <div className="relative bg-[#0A0B10] border border-slate-800 p-4 rounded-none h-[240px]">
                    <svg className="w-full h-full" viewBox="0 0 600 200">
                      {/* Grid Lines */}
                      <line x1="40" y1="20" x2="560" y2="20" stroke="#1b1e2e" strokeWidth="1" />
                      <line x1="40" y1="60" x2="560" y2="60" stroke="#1b1e2e" strokeWidth="1" />
                      <line x1="40" y1="100" x2="560" y2="100" stroke="#1b1e2e" strokeWidth="1" />
                      <line x1="40" y1="140" x2="560" y2="140" stroke="#1b1e2e" strokeWidth="1" />
                      <line x1="40" y1="180" x2="560" y2="180" stroke="#334155" strokeWidth="1" />

                      {/* Y Axis Labels */}
                      <text x="15" y="24" fill="#64748b" fontSize="8" fontWeight="bold" className="font-mono">1,500t</text>
                      <text x="15" y="64" fill="#64748b" fontSize="8" fontWeight="bold" className="font-mono">1,000t</text>
                      <text x="15" y="104" fill="#64748b" fontSize="8" fontWeight="bold" className="font-mono">500t</text>
                      <text x="15" y="144" fill="#64748b" fontSize="8" fontWeight="bold" className="font-mono">200t</text>
                      <text x="15" y="184" fill="#64748b" fontSize="8" fontWeight="bold" className="font-mono">0t</text>

                      {/* X Axis Labels */}
                      <text x="40" y="195" fill="#64748b" fontSize="8" fontWeight="bold" className="font-mono">JAN</text>
                      <text x="144" y="195" fill="#64748b" fontSize="8" fontWeight="bold" className="font-mono">APR</text>
                      <text x="248" y="195" fill="#64748b" fontSize="8" fontWeight="bold" className="font-mono">JUL</text>
                      <text x="352" y="195" fill="#e2e8f0" fontSize="8" fontWeight="bold" className="font-mono">OCT (Today)</text>
                      <text x="456" y="195" fill="#64748b" fontSize="8" fontWeight="bold" className="font-mono">DEC (F50)</text>
                      <text x="560" y="195" fill="#64748b" fontSize="8" fontWeight="bold" className="font-mono">MAR (F90)</text>

                      {/* Drawing P90 confidence area shaded (Washed Blue) */}
                      <polygon 
                        points="40,110 144,100 248,80 352,90 456,60 560,30 560,170 456,150 352,140 248,130 144,120 40,130" 
                        fill="#3b82f6" 
                        fillOpacity="0.12" 
                      />
                      {/* Drawing P50 median forecast band */}
                      <polygon 
                        points="40,115 144,105 248,90 352,100 456,80 560,60 560,150 456,130 352,120 248,115 144,110 40,120" 
                        fill="#10b981" 
                        fillOpacity="0.18" 
                      />

                      {/* Historical Solid Line (Actual volumes up to OCT) */}
                      <path 
                        d="M 40,120 L 144,112 L 248,105 L 352,110" 
                        fill="none" 
                        stroke="#f1f5f9" 
                        strokeWidth="3" 
                        strokeLinecap="round" 
                      />

                      {/* Forecast Median Line P50 */}
                      <path 
                        d="M 352,110 L 456,105 L 560,100" 
                        fill="none" 
                        stroke="#10b981" 
                        strokeWidth="2.5" 
                        strokeDasharray="4" 
                      />

                      {/* Forecast High Line P90 */}
                      <path 
                        d="M 352,110 L 456,60 L 560,30" 
                        fill="none" 
                        stroke="#3b82f6" 
                        strokeWidth="1.5" 
                        strokeDasharray="4" 
                      />

                      {/* Forecast Low Line P10 */}
                      <path 
                        d="M 352,110 L 456,150 L 560,170" 
                        fill="none" 
                        stroke="#f43f5e" 
                        strokeWidth="1.5" 
                        strokeDasharray="4" 
                      />
                    </svg>

                    <div className="absolute top-3 right-3 flex items-center gap-3 text-[9px] font-bold font-mono">
                      <div className="flex items-center gap-1">
                        <span className="w-2.5 h-0.5 bg-[#f1f5f9]"></span>
                        <span className="text-slate-300">Historical Actuals</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-2.5 h-0.5 bg-[#10b981] border-t border-dashed"></span>
                        <span className="text-emerald-400">P50 Median</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-2.5 h-0.5 bg-[#3b82f6] border-t border-dashed"></span>
                        <span className="text-blue-400">P90 (High)</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="w-2.5 h-0.5 bg-[#f43f5e] border-t border-dashed"></span>
                        <span className="text-red-400">P10 (Low)</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Corridor-by-corridor demand predictions list */}
                <div className="bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-2 border-b border-slate-800 font-serif italic">Regional Forecast Outlook</h3>
                  
                  <div className="space-y-3">
                    {forecasts.map((f, i) => (
                      <div key={i} className="text-xs p-3.5 bg-slate-950/40 rounded-none border border-slate-850/60 space-y-1 font-mono">
                        <div className="flex justify-between font-bold">
                          <span className="text-white font-serif italic">{f.origin} ➔ {f.destination}</span>
                          <span className="text-slate-400 font-mono text-[10px]">{f.commodity}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-1 font-mono text-[10px] text-slate-400 pt-1.5 border-t border-slate-900">
                          <div>P10: <span className="font-bold text-red-400">{f.p10}t</span></div>
                          <div>P50: <span className="font-bold text-emerald-400">{f.p50}t</span></div>
                          <div>P90: <span className="font-bold text-blue-400">{f.p90}t</span></div>
                        </div>
                        <div className="text-[10px] text-amber-500 font-semibold italic">{f.seasonality}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom Row: Rail Freight Investment Decision Curve */}
              <div className="bg-[#0E0F16] rounded-none border border-slate-800 shadow-none p-6 space-y-4">
                <div>
                  <h2 className="text-base font-semibold text-white font-serif italic">Incremental Return Curve (Where Should We Build Next?)</h2>
                  <p className="text-xs text-slate-400 font-mono">Ranks proposed capital infrastructure additions by their calculated IRR and payback offsets against multi-customer network demand.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4" id="investments-cards">
                  {investments.map((inv) => (
                    <div key={inv.id} className="border border-slate-800 bg-[#0A0B10] rounded-none p-5 flex flex-col justify-between space-y-4 font-mono">
                      <div className="space-y-1">
                        <span className="px-2 py-0.5 bg-emerald-950/40 text-emerald-400 border border-emerald-900/40 text-[9px] font-bold rounded-none uppercase">{inv.type} Option</span>
                        <h4 className="text-sm font-bold text-white font-serif italic mt-1.5">{inv.name}</h4>
                        <p className="text-[11px] text-slate-400 leading-normal font-medium">{inv.description}</p>
                      </div>

                      <div className="space-y-2 pt-2 border-t border-slate-900 text-xs font-semibold text-slate-400">
                        <div className="flex justify-between">
                          <span>Est. CAPEX cost:</span>
                          <span className="font-bold text-white font-mono">{formatCurrency(inv.capex)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Internal Rate of Return:</span>
                          <span className="font-bold text-amber-500 font-mono">{inv.irr}% IRR</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Payback Period:</span>
                          <span className="font-bold text-white font-mono">{inv.payback} Years</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 7: INTEGRATED WORKSPACE */}
          {activeTab === 'workspace' && (
            <motion.div 
              key="workspace-ide"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[520px]"
              id="workspace-pane"
            >
              {/* Sidebar file tree explorer */}
              <div className="bg-[#0E0F16] text-slate-300 rounded-none border border-slate-800 p-4 space-y-4 flex flex-col justify-between shadow-none">
                <div className="space-y-4 font-mono">
                  <div className="flex items-center gap-2 text-white border-b border-slate-800 pb-2">
                    <Database className="w-4 h-4 text-amber-500" />
                    <span className="text-xs font-bold tracking-wider uppercase">Source Explorer</span>
                  </div>

                  <div className="space-y-1.5 text-xs font-semibold" id="ide-file-tree">
                    <div className="text-slate-500 text-[10px] uppercase font-bold tracking-wider pl-1 pb-1">Rust Operational Engine</div>
                    <button 
                      onClick={() => { setSelectedCodeId('rust_routing'); setEditorContent(codeFiles.find(f => f.id === 'rust_routing')?.content || ''); }}
                      className={`w-full text-left py-1.5 px-3 rounded-none flex items-center gap-2 transition-all ${selectedCodeId === 'rust_routing' ? 'bg-amber-950/20 text-amber-500 border-l border-amber-500' : 'text-slate-400 hover:bg-slate-900'}`}
                    >
                      <Code className="w-3.5 h-3.5 text-amber-500" />
                      routing/mod.rs
                    </button>
                    <button 
                      onClick={() => { setSelectedCodeId('rust_traction'); setEditorContent(codeFiles.find(f => f.id === 'rust_traction')?.content || ''); }}
                      className={`w-full text-left py-1.5 px-3 rounded-none flex items-center gap-2 transition-all ${selectedCodeId === 'rust_traction' ? 'bg-amber-950/20 text-amber-500 border-l border-amber-500' : 'text-slate-400 hover:bg-slate-900'}`}
                    >
                      <Code className="w-3.5 h-3.5 text-amber-500" />
                      traction/mod.rs
                    </button>

                    <div className="text-slate-500 text-[10px] uppercase font-bold tracking-wider pl-1 pt-3 pb-1">R Statistical Engine</div>
                    <button 
                      onClick={() => { setSelectedCodeId('r_forecasting'); setEditorContent(codeFiles.find(f => f.id === 'r_forecasting')?.content || ''); }}
                      className={`w-full text-left py-1.5 px-3 rounded-none flex items-center gap-2 transition-all ${selectedCodeId === 'r_forecasting' ? 'bg-amber-950/20 text-amber-500 border-l border-amber-500' : 'text-slate-400 hover:bg-slate-900'}`}
                    >
                      <Wrench className="w-3.5 h-3.5 text-emerald-500" />
                      forecasting.R
                    </button>
                  </div>
                </div>

                <div className="bg-[#0A0B10] p-3 rounded-none border border-slate-800 text-[10px] font-mono text-slate-400 leading-normal">
                  <div className="font-bold text-white mb-1 flex items-center gap-1.5">
                    <Terminal className="w-3 h-3 text-amber-500" />
                    COMPILER LINK
                  </div>
                  System synchronizes client edits directly to backend files, allowing real-time testing.
                </div>
              </div>

              {/* Center panel code editor */}
              <div className="lg:col-span-3 flex flex-col bg-[#0E0F16] rounded-none border border-slate-800 overflow-hidden shadow-none font-mono">
                <div className="bg-[#0A0B10] border-b border-slate-800 px-4 py-2 flex justify-between items-center gap-4">
                  <span className="text-xs font-mono text-white font-bold">
                    {codeFiles.find(f => f.id === selectedCodeId)?.name || 'Editor'}
                  </span>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={handleSaveCode}
                      className="py-1 px-3 bg-slate-900 hover:bg-slate-850 active:bg-slate-800 border border-slate-800 text-slate-300 text-[10px] font-bold rounded-none font-mono transition"
                      id="save-code-btn"
                    >
                      SAVE SCRIPT
                    </button>
                    <button 
                      onClick={handleCompileCode}
                      disabled={isCompiling}
                      className="py-1 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 text-[10px] font-bold rounded-none font-mono flex items-center gap-1.5 transition"
                      id="compile-code-btn"
                    >
                      <Play className="w-3 h-3 fill-slate-950" />
                      {isCompiling ? 'RUNNING...' : 'COMPILE & TEST'}
                    </button>
                  </div>
                </div>

                {/* Editor Content Box */}
                <div className="flex-1 p-2 font-mono text-xs flex">
                  <textarea 
                    value={editorContent}
                    onChange={(e) => setEditorContent(e.target.value)}
                    className="w-full h-[260px] bg-transparent text-slate-200 border-none outline-none resize-none overflow-y-auto leading-relaxed focus:ring-0 p-3 select-text"
                    id="ide-textarea"
                    spellCheck="false"
                  />
                </div>

                {/* Simulated Console Bash / R output logs */}
                <div className="h-[140px] border-t border-slate-800 bg-[#0A0B10] p-4 font-mono text-[10px] text-slate-300 overflow-y-auto" id="ide-console">
                  <div className="text-slate-500 border-b border-slate-900 pb-1.5 mb-1.5 flex justify-between items-center">
                    <span>BUILD TERMINAL & TEST SUITE OUT:</span>
                    <span className="text-emerald-500 font-bold">● SYSTEM READY</span>
                  </div>
                  <pre className="whitespace-pre-wrap">{consoleLog}</pre>
                </div>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* FOOTER */}
      <footer className="bg-[#0A0B10] border-t border-slate-800 py-3.5 px-6 flex flex-wrap justify-between items-center text-[11px] font-medium text-slate-400 font-mono" id="global-footer">
        <span>© 2026 Rail Freight Optimisation and Capacity Broker Network</span>
        <div className="flex gap-4">
          <span>Standards: EN 15273 / UK Group Standards</span>
          <span className="text-amber-500 font-bold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 inline-block animate-pulse"></span>
            Operations Synced
          </span>
        </div>
      </footer>
    </div>
  );
}
