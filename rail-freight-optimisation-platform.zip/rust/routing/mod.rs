//! Multi-criteria railway routing engine.
//!
//! Solves the shortest path problem on the directed rail graph under physical constraints:
//! - Axle load limits (tonnes)
//! - Loading gauge (e.g., W6a, W10, GC)
//! - Electrification compatibility
//! - Train length and gross weight limits

use std::collections::{BinaryHeap, HashMap};
use std::cmp::Ordering;

#[derive(Debug, Clone)]
pub struct TrackSection {
    pub id: String,
    pub source: String,
    pub target: String,
    pub distance_km: f64,
    pub max_speed_kmh: f64,
    pub gradient_permille: f64, // in permille (mm/m)
    pub electrified: bool,
    pub max_axle_load_tonnes: f64,
    pub loading_gauge: String, // "W6a", "W10", "W12", "GC"
    pub max_train_length_meters: f64,
    pub max_train_weight_tonnes: f64,
    pub cost_multiplier: f64,
}

#[derive(Debug, Clone, PartialEq)]
pub struct NodeState {
    pub node_id: String,
    pub cost: f64,
    pub elapsed_time_hours: f64,
}

impl Eq for NodeState {}

impl Ord for NodeState {
    fn cmp(&self, other: &Self) -> Ordering {
        // Reverse for min-heap
        other.cost.partial_cmp(&self.cost).unwrap_or(Ordering::Equal)
    }
}

impl PartialOrd for NodeState {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

pub struct RoutingEngine {
    pub graph: HashMap<String, Vec<TrackSection>>,
}

impl RoutingEngine {
    pub fn new() -> Self {
        Self {
            graph: HashMap::new(),
        }
    }

    pub fn add_section(&mut self, section: TrackSection) {
        self.graph.entry(section.source.clone())
            .or_insert_with(Vec::new)
            .push(section);
    }

    /// Finds the optimal constrained route between origin and destination.
    ///
    /// Considers locomotive capabilities, wagon load requirements, and physical railway constraints.
    pub fn find_route(
        &self,
        origin: &str,
        destination: &str,
        train_weight_tonnes: f64,
        train_length_meters: f64,
        axle_load_tonnes: f64,
        is_electric: bool,
        required_gauge: &str,
    ) -> Option<(Vec<String>, f64, f64)> {
        let mut distances = HashMap::new();
        let mut predecessors = HashMap::new();
        let mut pq = BinaryHeap::new();

        distances.insert(origin.to_string(), 0.0);
        pq.push(NodeState {
            node_id: origin.to_string(),
            cost: 0.0,
            elapsed_time_hours: 0.0,
        });

        while let Some(NodeState { node_id, cost, elapsed_time_hours }) = pq.pop() {
            if &node_id == destination {
                // Reconstruct route
                let mut path = Vec::new();
                let mut curr = destination.to_string();
                while curr != origin {
                    path.push(curr.clone());
                    if let Some(pred) = predecessors.get(&curr) {
                        curr = pred.clone();
                    } else {
                        break;
                    }
                }
                path.push(origin.to_string());
                path.reverse();
                return Some((path, cost, elapsed_time_hours));
            }

            if let Some(current_dist) = distances.get(&node_id) {
                if cost > *current_dist {
                    continue;
                }
            }

            if let Some(edges) = self.graph.get(&node_id) {
                for edge in edges {
                    // Check physical constraints
                    if axle_load_tonnes > edge.max_axle_load_tonnes {
                        continue; // Train too heavy for track structure
                    }
                    if train_length_meters > edge.max_train_length_meters {
                        continue; // Train exceeds passing loop or siding capacities
                    }
                    if train_weight_tonnes > edge.max_train_weight_tonnes {
                        continue; // Exceeds drawbar force or section capacity
                    }
                    if is_electric && !edge.electrified {
                        continue; // Electric loco cannot use non-electrified routes
                    }
                    if !self.gauge_compatible(&edge.loading_gauge, required_gauge) {
                        continue; // Cargo is too tall/wide for bridges or tunnels on this section
                    }

                    // Calculate travel time and economic weight (cost-plus and access charge)
                    let travel_time = edge.distance_km / edge.max_speed_kmh;
                    let edge_cost = edge.distance_km * edge.cost_multiplier 
                        + (edge.gradient_permille.max(0.0) * 0.05 * train_weight_tonnes); // Gradient energy cost

                    let next_cost = cost + edge_cost;
                    let next_time = elapsed_time_hours + travel_time;

                    let entry = distances.entry(edge.target.clone()).or_insert(f64::INFINITY);
                    if next_cost < *entry {
                        *entry = next_cost;
                        predecessors.insert(edge.target.clone(), node_id.clone());
                        pq.push(NodeState {
                            node_id: edge.target.clone(),
                            cost: next_cost,
                            elapsed_time_hours: next_time,
                        });
                    }
                }
            }
        }

        None // No viable route matching constraints
    }

    fn gauge_compatible(&self, track_gauge: &str, cargo_gauge: &str) -> bool {
        // Gauges in hierarchy: W6a < W10 < W12 < GC
        let ranking = |g: &str| match g {
            "W6a" => 1,
            "W10" => 2,
            "W12" => 3,
            "GC" => 4,
            _ => 0,
        };
        ranking(track_gauge) >= ranking(cargo_gauge)
    }
}
