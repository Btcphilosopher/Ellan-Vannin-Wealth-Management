//! Locomotive traction physics, power matching, and energy consumption estimation.
//!
//! Models Davis resistance formula, grade resistance, acceleration force, 
//! energy draw, and regenerative braking recovery.

pub struct TractionForces {
    pub davis_a: f64, // Constant journal resistance (N)
    pub davis_b: f64, // Flange and mechanical resistance (N/(km/h))
    pub davis_c: f64, // Aerodynamic drag coefficient (N/(km/h)^2)
}

pub struct LocomotiveSpecs {
    pub mass_tonnes: f64,
    pub max_power_kw: f64,
    pub starting_tractive_effort_kn: f64,
    pub fuel_consumption_idle_lh: f64, // litres per hour (diesel)
    pub efficiency: f64,               // efficiency factor (e.g., 0.85)
    pub regenerative_efficiency: f64,  // braking energy recovery factor
}

impl TractionForces {
    /// Estimates Davis resistance coefficients for general freight trains.
    ///
    /// Formula: R = A + B*v + C*v^2
    pub fn for_train(total_weight_tonnes: f64, number_of_axles: u32, is_intermodal: bool) -> Self {
        // Davis coefficients adapted for standard European freight
        let a = 6.4 * total_weight_tonnes + 130.0 * (number_of_axles as f64);
        let b = 0.18 * total_weight_tonnes;
        let c = if is_intermodal { 0.045 } else { 0.03 }; // higher drag for intermodal containers due to gap turbulence

        Self {
            davis_a: a,
            davis_b: b,
            davis_c: c,
        }
    }
}

pub struct TractionOptimiser;

impl TractionOptimiser {
    /// Calculates energy consumption (kWh or litres) for a route section.
    pub fn calculate_section_consumption(
        loco: &LocomotiveSpecs,
        forces: &TractionForces,
        train_weight_tonnes: f64,
        distance_km: f64,
        gradient_permille: f64, // Positive is uphill, negative is downhill
        speed_kmh: f64,
        acceleration_ms2: f64,
        is_electric: bool,
    ) -> (f64, f64) { // (energy_consumed, cost_coefficient)
        let speed_ms = speed_kmh / 3.6;
        let gravity = 9.81;

        // 1. Davis Mechanical Resistance (N)
        let r_davis = forces.davis_a 
            + forces.davis_b * speed_kmh 
            + forces.davis_c * speed_kmh.powi(2);

        // 2. Grade Resistance (N)
        // F_g = m * g * sin(theta) ~ m * g * gradient_permille / 1000
        let r_grade = train_weight_tonnes * 1000.0 * gravity * (gradient_permille / 1000.0);

        // 3. Acceleration Force (N)
        // F_a = m * a
        let r_acceleration = train_weight_tonnes * 1000.0 * acceleration_ms2;

        // Total tractive effort required at the rail (N)
        let total_force_n = r_davis + r_grade + r_acceleration;

        // Convert distance to meters
        let distance_meters = distance_km * 1000.0;

        // Work done (Joules = N * m)
        let work_done_joules = total_force_n * distance_meters;

        // Convert Joules to kWh (1 kWh = 3.6e6 Joules)
        let mechanical_energy_kwh = work_done_joules / 3.6e6;

        let mut energy_consumed_kwh = 0.0;
        let mut diesel_litres_consumed = 0.0;

        if mechanical_energy_kwh > 0.0 {
            // Traction energy drawn
            let electrical_energy_required = mechanical_energy_kwh / loco.efficiency;
            
            if is_electric {
                energy_consumed_kwh = electrical_energy_required;
            } else {
                // For diesel, 1 litre of diesel yields roughly 10 kWh of thermal energy.
                // At ~35% engine efficiency, 1 litre = 3.5 kWh mechanical.
                diesel_litres_consumed = mechanical_energy_kwh / (3.5 * loco.efficiency);
            }
        } else if mechanical_energy_kwh < 0.0 && is_electric {
            // Uphill potential or deceleration translated into regenerative braking
            // Recovery energy = Work * regenerative_efficiency
            let recovery_kwh = mechanical_energy_kwh.abs() * loco.regenerative_efficiency;
            energy_consumed_kwh = -recovery_kwh; // Negative consumption indicates grid feedback
        }

        if !is_electric {
            // Add idle consumption for duration of travel
            let travel_time_hours = distance_km / speed_kmh;
            diesel_litres_consumed += loco.fuel_consumption_idle_lh * travel_time_hours;
        }

        // Return (calculated metric, unit_factor)
        if is_electric {
            (energy_consumed_kwh, 1.0) // kWh
        } else {
            (diesel_litres_consumed, 0.0) // Litres
        }
    }
}
