/**
 * Albion Audio Synthesizer & Audiophile Web Audio Engine
 * Provides rich, realistic, real-time synthesized musical soundscapes
 * for catalog tracks, with real-time FFT frequency analysis.
 */

class AudioEngine {
  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private gainNode: GainNode | null = null;
  private isPlaying: boolean = false;
  private currentSynthInterval: number | null = null;
  private vinylNoiseNode: AudioBufferSourceNode | null = null;
  private eqFilters: BiquadFilterNode[] = [];
  
  // Track parameters
  private currentBpm: number = 120;
  private currentSynthType: string = 'ambient';

  constructor() {
    // Lazy init on first user interaction
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 128;
      this.analyser.smoothingTimeConstant = 0.85;

      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.value = 0.8;

      // Create 10-band EQ
      const frequencies = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
      let lastNode: AudioNode = this.gainNode;

      this.eqFilters = frequencies.map((freq, idx) => {
        if (!this.ctx) throw new Error("No context");
        const filter = this.ctx.createBiquadFilter();
        if (idx === 0) filter.type = 'lowshelf';
        else if (idx === frequencies.length - 1) filter.type = 'highshelf';
        else filter.type = 'peaking';
        filter.frequency.value = freq;
        filter.gain.value = 0; // Flat default
        
        lastNode.connect(filter);
        lastNode = filter;
        return filter;
      });

      lastNode.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(val: number) {
    if (this.gainNode && this.ctx) {
      this.gainNode.gain.setValueAtTime(Math.max(0, Math.min(1, val)), this.ctx.currentTime);
    }
  }

  public setEQBand(index: number, gainDb: number) {
    if (this.eqFilters[index] && this.ctx) {
      this.eqFilters[index].gain.setValueAtTime(gainDb, this.ctx.currentTime);
    }
  }

  public setEQPreset(bands: number[]) {
    bands.forEach((gain, i) => this.setEQBand(i, gain));
  }

  public start(synthType: string = 'ambient', bpm: number = 100) {
    this.initCtx();
    if (!this.ctx) return;

    this.stop();
    this.isPlaying = true;
    this.currentSynthType = synthType;
    this.currentBpm = bpm;

    this.startVinylNoise();
    this.startMusicalPattern();
  }

  public stop() {
    this.isPlaying = false;
    if (this.currentSynthInterval !== null) {
      window.clearInterval(this.currentSynthInterval);
      this.currentSynthInterval = null;
    }
    if (this.vinylNoiseNode) {
      try {
        this.vinylNoiseNode.stop();
      } catch {
        // ignore
      }
      this.vinylNoiseNode = null;
    }
  }

  public pause() {
    this.stop();
  }

  public resume() {
    if (!this.isPlaying) {
      this.start(this.currentSynthType, this.currentBpm);
    }
  }

  public getFrequencyData(array: Uint8Array): void {
    if (this.analyser && this.isPlaying) {
      this.analyser.getByteFrequencyData(array);
    } else {
      array.fill(0);
    }
  }

  private startVinylNoise() {
    if (!this.ctx || !this.gainNode) return;
    const bufferSize = this.ctx.sampleRate * 2;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      // Warm pink/crackle noise simulation
      data[i] = (Math.random() * 2 - 1) * 0.008;
      if (Math.random() < 0.0008) {
        data[i] += (Math.random() > 0.5 ? 1 : -1) * 0.08; // subtle vinyl pop
      }
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'lowpass';
    noiseFilter.frequency.value = 1800;

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.value = 0.15;

    noise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.gainNode);

    noise.start();
    this.vinylNoiseNode = noise;
  }

  private startMusicalPattern() {
    if (!this.ctx || !this.gainNode) return;

    // Musical note frequencies in Hz
    const scales: Record<string, number[]> = {
      ambient: [130.81, 164.81, 196.00, 246.94, 293.66, 329.63, 392.00, 493.88], // C maj9
      jazz: [146.83, 174.61, 220.00, 261.63, 329.63, 392.00, 440.00, 523.25], // Dm9
      orchestral: [110.00, 130.81, 164.81, 220.00, 261.63, 329.63, 440.00], // A minor orchestral
      postpunk: [82.41, 110.00, 123.47, 146.83, 164.81, 220.00], // E minor bass drive
      synthwave: [130.81, 155.56, 196.00, 233.08, 261.63, 311.13, 392.00], // C minor synth
      piano: [130.81, 146.83, 164.81, 174.61, 196.00, 220.00, 246.94, 261.63, 293.66, 329.63],
      folk: [146.83, 164.81, 185.00, 220.00, 246.94, 293.66, 329.63]
    };

    const notes = scales[this.currentSynthType] || scales.ambient;
    const beatInterval = (60 / Math.max(60, this.currentBpm)) * 500; // Step speed

    let step = 0;
    this.currentSynthInterval = window.setInterval(() => {
      if (!this.ctx || !this.isPlaying || !this.gainNode) return;

      const now = this.ctx.currentTime;
      const freq1 = notes[step % notes.length];
      const freq2 = notes[(step + 3) % notes.length];

      // Primary tone oscillator
      const osc = this.ctx.createOscillator();
      const oscGain = this.ctx.createGain();

      if (this.currentSynthType === 'piano' || this.currentSynthType === 'folk') {
        osc.type = 'triangle';
        oscGain.gain.setValueAtTime(0.25, now);
        oscGain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);
      } else if (this.currentSynthType === 'postpunk' || this.currentSynthType === 'synthwave') {
        osc.type = 'sawtooth';
        oscGain.gain.setValueAtTime(0.2, now);
        oscGain.gain.exponentialRampToValueAtTime(0.005, now + 0.4);
      } else {
        osc.type = 'sine';
        oscGain.gain.setValueAtTime(0.18, now);
        oscGain.gain.linearRampToValueAtTime(0.12, now + 0.5);
        oscGain.gain.exponentialRampToValueAtTime(0.001, now + 2.5);
      }

      osc.frequency.setValueAtTime(freq1, now);

      // Stereo panner for spatial depth
      const panner = this.ctx.createStereoPanner();
      panner.pan.value = (Math.sin(step * 0.7) * 0.6);

      osc.connect(oscGain);
      oscGain.connect(panner);
      panner.connect(this.gainNode);

      osc.start(now);
      osc.stop(now + 2.5);

      // Subtle background harmony chord every 4 steps
      if (step % 4 === 0) {
        const chordOsc = this.ctx.createOscillator();
        const chordGain = this.ctx.createGain();
        chordOsc.type = 'sine';
        chordOsc.frequency.setValueAtTime(freq2 * 0.5, now); // Sub octave
        chordGain.gain.setValueAtTime(0.12, now);
        chordGain.gain.exponentialRampToValueAtTime(0.001, now + 3.0);

        chordOsc.connect(chordGain);
        chordGain.connect(this.gainNode);
        chordOsc.start(now);
        chordOsc.stop(now + 3.0);
      }

      step++;
    }, beatInterval);
  }
}

export const audioEngine = new AudioEngine();
