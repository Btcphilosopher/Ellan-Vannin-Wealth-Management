export type AudioQuality = '16-bit / 44.1kHz (CD)' | '24-bit / 96kHz (Lossless)' | '24-bit / 192kHz (Master Studio)';

export interface LyricLine {
  time: number; // in seconds
  text: string;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  album: string;
  albumId: string;
  coverUrl: string;
  duration: number; // in seconds
  releaseYear: number;
  genre: string;
  bpm?: number;
  key?: string;
  audioQuality: AudioQuality;
  composer?: string;
  producer?: string;
  studio?: string;
  synthsType?: 'piano' | 'ambient' | 'synthwave' | 'jazz' | 'orchestral' | 'postpunk' | 'folk';
  lyrics?: LyricLine[];
  essay?: string;
}

export interface Album {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  coverUrl: string;
  releaseYear: number;
  genre: string;
  trackCount: number;
  totalDuration: number; // seconds
  essay: string;
  credits: {
    producer: string;
    engineer: string;
    studio: string;
    label: string;
  };
  dominantColor: string; // Hex for aesthetic backgrounds
  tracks: Track[];
}

export interface Artist {
  id: string;
  name: string;
  avatarUrl: string;
  heroUrl: string;
  genre: string;
  origin: string; // e.g. "Bristol, England"
  formedYear: number;
  bio: string;
  monthlyListeners: number;
  tourDates?: {
    date: string;
    venue: string;
    city: string;
    ticketUrl?: string;
  }[];
  albums: Album[];
  topTracks: Track[];
}

export interface ListeningJourney {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  coverUrl: string;
  theme: string; // e.g., "Misty Rain", "Late Night South London", "Highland Chill"
  curator: string;
  readTime: string;
  tracks: Track[];
}

export interface EditorialFeature {
  id: string;
  category: 'ARCHIVE' | 'ESSAY' | 'SHOWCASE' | 'INTERVIEW';
  title: string;
  subtitle: string;
  author: string;
  date: string;
  readTime: string;
  heroUrl: string;
  summary: string;
  content: string[];
  featuredAlbumId?: string;
}

export type ActiveView = 
  | { type: 'DISCOVER' }
  | { type: 'LIBRARY'; filter?: 'albums' | 'artists' | 'genres' | 'playlists' | 'history' | 'pinned' }
  | { type: 'EDITORIAL' }
  | { type: 'JOURNEYS' }
  | { type: 'ALBUM'; albumId: string }
  | { type: 'ARTIST'; artistId: string }
  | { type: 'PLAYLIST'; playlistId: string }
  | { type: 'SETTINGS' };

export interface AudioDevice {
  id: string;
  name: string;
  brand: string;
  type: 'Speaker' | 'Headphones' | 'Streamer' | 'DAC';
  connection: 'AirPlay 2' | 'Wi-Fi Hi-Res' | 'USB-DAC' | 'RCA Line Out';
  status: 'Connected' | 'Available';
  maxResolution: string;
}

export interface EqualizerPreset {
  id: string;
  name: string;
  description: string;
  bands: number[]; // 10 bands: 32Hz, 64Hz, 125Hz, 250Hz, 500Hz, 1kHz, 2kHz, 4kHz, 8kHz, 16kHz
}

export interface Playlist {
  id: string;
  title: string;
  description: string;
  coverUrl: string;
  tracks: Track[];
  createdAt: string;
  isPinned?: boolean;
}
