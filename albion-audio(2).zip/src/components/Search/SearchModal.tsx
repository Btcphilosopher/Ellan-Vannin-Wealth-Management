import React, { useEffect, useState } from 'react';
import { Search, X, Play, Disc, User, Music, ArrowRight } from 'lucide-react';
import { Album, Artist, Track } from '../../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  tracks: Track[];
  albums: Album[];
  artists: Artist[];
  onPlayTrack: (track: Track) => void;
  onSelectAlbum: (albumId: string) => void;
  onSelectArtist: (artistId: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  tracks,
  albums,
  artists,
  onPlayTrack,
  onSelectAlbum,
  onSelectArtist
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredTracks = query.trim() 
    ? tracks.filter(t => t.title.toLowerCase().includes(query.toLowerCase()) || t.artist.toLowerCase().includes(query.toLowerCase()) || t.album.toLowerCase().includes(query.toLowerCase()))
    : tracks.slice(0, 4);

  const filteredAlbums = query.trim()
    ? albums.filter(a => a.title.toLowerCase().includes(query.toLowerCase()) || a.artist.toLowerCase().includes(query.toLowerCase()))
    : albums.slice(0, 3);

  const filteredArtists = query.trim()
    ? artists.filter(a => a.name.toLowerCase().includes(query.toLowerCase()) || a.genre.toLowerCase().includes(query.toLowerCase()))
    : artists.slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-start justify-center pt-20 p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl glass-panel rounded-2xl border border-white/10 overflow-hidden shadow-2xl space-y-4 p-4">
        {/* Input Bar */}
        <div className="flex items-center space-x-3 bg-[#181B20] border border-white/10 rounded-xl px-4 py-3">
          <Search className="w-5 h-5 text-[#C5A059]" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search catalog by track, artist, album, genre or location..."
            className="w-full bg-transparent text-sm text-white placeholder-[#8E96A3] outline-none font-sans"
            autoFocus
          />
          <kbd className="text-[10px] font-mono-tech text-[#8E96A3] px-2 py-0.5 rounded bg-[#20242B]">ESC</kbd>
        </div>

        {/* Live Search Results Area */}
        <div className="max-h-[60vh] overflow-y-auto space-y-6 pr-2">
          {/* Tracks Section */}
          {filteredTracks.length > 0 && (
            <div>
              <span className="text-[10px] font-mono-tech text-[#C5A059] uppercase tracking-widest block mb-2 px-2">
                Master Tracks
              </span>
              <div className="space-y-1">
                {filteredTracks.map((track) => (
                  <div
                    key={track.id}
                    onClick={() => {
                      onPlayTrack(track);
                      onClose();
                    }}
                    className="p-2.5 rounded-xl hover:bg-white/5 flex items-center justify-between cursor-pointer group transition-all"
                  >
                    <div className="flex items-center space-x-3 truncate">
                      <img src={track.coverUrl} alt={track.title} className="w-10 h-10 rounded-lg object-cover" />
                      <div className="truncate">
                        <h4 className="text-xs font-semibold text-white group-hover:text-[#C5A059] transition-colors truncate">
                          {track.title}
                        </h4>
                        <p className="text-[11px] text-[#8E96A3] truncate">{track.artist} · {track.album}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] font-mono-tech text-[#C5A059]">{track.audioQuality.split(' ')[0]}</span>
                      <Play className="w-4 h-4 text-[#C5A059] opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Albums Section */}
          {filteredAlbums.length > 0 && (
            <div>
              <span className="text-[10px] font-mono-tech text-[#C5A059] uppercase tracking-widest block mb-2 px-2">
                Master Albums
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {filteredAlbums.map((album) => (
                  <div
                    key={album.id}
                    onClick={() => {
                      onSelectAlbum(album.id);
                      onClose();
                    }}
                    className="p-3 rounded-xl bg-[#181B20] hover:border-[#C5A059]/40 border border-white/5 cursor-pointer group transition-all"
                  >
                    <img src={album.coverUrl} alt={album.title} className="w-full aspect-square rounded-lg object-cover mb-2" />
                    <h5 className="text-xs font-semibold text-white truncate group-hover:text-[#C5A059]">{album.title}</h5>
                    <p className="text-[10px] text-[#8E96A3] truncate">{album.artist}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Artists Section */}
          {filteredArtists.length > 0 && (
            <div>
              <span className="text-[10px] font-mono-tech text-[#C5A059] uppercase tracking-widest block mb-2 px-2">
                Pioneering British Artists
              </span>
              <div className="space-y-1">
                {filteredArtists.map((artist) => (
                  <div
                    key={artist.id}
                    onClick={() => {
                      onSelectArtist(artist.id);
                      onClose();
                    }}
                    className="p-2.5 rounded-xl hover:bg-white/5 flex items-center space-x-3 cursor-pointer group transition-all"
                  >
                    <img src={artist.avatarUrl} alt={artist.name} className="w-10 h-10 rounded-full object-cover" />
                    <div>
                      <h5 className="text-xs font-semibold text-white group-hover:text-[#C5A059]">{artist.name}</h5>
                      <p className="text-[11px] text-[#8E96A3]">{artist.genre} · {artist.origin}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
