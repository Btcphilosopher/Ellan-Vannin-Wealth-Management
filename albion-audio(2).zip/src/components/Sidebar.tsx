import React from 'react';
import { 
  Compass, 
  BookOpen, 
  Sparkles, 
  Library, 
  Disc, 
  User, 
  FolderHeart, 
  SlidersHorizontal, 
  Pin,
  Clock,
  Music2
} from 'lucide-react';
import { ActiveView, Playlist } from '../types';

interface SidebarProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  playlists: Playlist[];
  openSettings: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  setActiveView,
  playlists,
  openSettings
}) => {
  const isSelected = (viewType: string, filter?: string) => {
    if (activeView.type !== viewType) return false;
    if (viewType === 'LIBRARY' && filter) {
      return (activeView as { type: 'LIBRARY'; filter?: string }).filter === filter;
    }
    return true;
  };

  return (
    <aside className="w-64 h-[calc(100vh-4rem)] bg-[#0D0D0D] border-r border-[#1F1F1F] flex flex-col justify-between p-6 shrink-0 overflow-y-auto gap-8">
      {/* Top Navigation Sections */}
      <div className="space-y-8">
        {/* Essentials Section */}
        <div className="space-y-3">
          <p className="text-[10px] uppercase tracking-[0.2em] text-[#666666] font-semibold px-2">
            Essentials
          </p>
          <nav className="space-y-1">
            <button
              onClick={() => setActiveView({ type: 'DISCOVER' })}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm transition-all ${
                isSelected('DISCOVER')
                  ? 'text-[#E0E0E0] font-medium bg-[#141414]'
                  : 'text-[#888888] hover:text-white hover:bg-[#141414]/50'
              }`}
            >
              {isSelected('DISCOVER') ? (
                <span className="w-1.5 h-1.5 bg-[#C5A059] rounded-full shrink-0"></span>
              ) : (
                <Compass className="w-4 h-4 text-[#666666] shrink-0" />
              )}
              <span>Curated Discover</span>
            </button>

            <button
              onClick={() => setActiveView({ type: 'EDITORIAL' })}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm transition-all ${
                isSelected('EDITORIAL')
                  ? 'text-[#E0E0E0] font-medium bg-[#141414]'
                  : 'text-[#888888] hover:text-white hover:bg-[#141414]/50'
              }`}
            >
              {isSelected('EDITORIAL') ? (
                <span className="w-1.5 h-1.5 bg-[#C5A059] rounded-full shrink-0"></span>
              ) : (
                <BookOpen className="w-4 h-4 text-[#666666] shrink-0" />
              )}
              <span>Monocle Essays</span>
            </button>

            <button
              onClick={() => setActiveView({ type: 'JOURNEYS' })}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm transition-all ${
                isSelected('JOURNEYS')
                  ? 'text-[#E0E0E0] font-medium bg-[#141414]'
                  : 'text-[#888888] hover:text-white hover:bg-[#141414]/50'
              }`}
            >
              {isSelected('JOURNEYS') ? (
                <span className="w-1.5 h-1.5 bg-[#C5A059] rounded-full shrink-0"></span>
              ) : (
                <Sparkles className="w-4 h-4 text-[#666666] shrink-0" />
              )}
              <span>Atmospheric Journeys</span>
            </button>
          </nav>
        </div>

        {/* Collections Section */}
        <div className="space-y-3">
          <p className="text-[10px] uppercase tracking-[0.2em] text-[#666666] font-semibold px-2">
            Collections
          </p>
          <nav className="space-y-1">
            <button
              onClick={() => setActiveView({ type: 'LIBRARY' })}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm transition-all ${
                isSelected('LIBRARY', undefined)
                  ? 'text-[#E0E0E0] font-medium bg-[#141414]'
                  : 'text-[#888888] hover:text-white hover:bg-[#141414]/50'
              }`}
            >
              {isSelected('LIBRARY', undefined) ? (
                <span className="w-1.5 h-1.5 bg-[#C5A059] rounded-full shrink-0"></span>
              ) : (
                <Library className="w-4 h-4 text-[#666666] shrink-0" />
              )}
              <span>Full Library</span>
            </button>

            <button
              onClick={() => setActiveView({ type: 'LIBRARY', filter: 'albums' })}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm transition-all ${
                isSelected('LIBRARY', 'albums')
                  ? 'text-[#E0E0E0] font-medium bg-[#141414]'
                  : 'text-[#888888] hover:text-white hover:bg-[#141414]/50'
              }`}
            >
              {isSelected('LIBRARY', 'albums') ? (
                <span className="w-1.5 h-1.5 bg-[#C5A059] rounded-full shrink-0"></span>
              ) : (
                <Disc className="w-4 h-4 text-[#666666] shrink-0" />
              )}
              <span>Oxford Classics</span>
            </button>

            <button
              onClick={() => setActiveView({ type: 'LIBRARY', filter: 'artists' })}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm transition-all ${
                isSelected('LIBRARY', 'artists')
                  ? 'text-[#E0E0E0] font-medium bg-[#141414]'
                  : 'text-[#888888] hover:text-white hover:bg-[#141414]/50'
              }`}
            >
              {isSelected('LIBRARY', 'artists') ? (
                <span className="w-1.5 h-1.5 bg-[#C5A059] rounded-full shrink-0"></span>
              ) : (
                <User className="w-4 h-4 text-[#666666] shrink-0" />
              )}
              <span>Mist & Slate Artists</span>
            </button>

            <button
              onClick={() => setActiveView({ type: 'LIBRARY', filter: 'history' })}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm transition-all ${
                isSelected('LIBRARY', 'history')
                  ? 'text-[#E0E0E0] font-medium bg-[#141414]'
                  : 'text-[#888888] hover:text-white hover:bg-[#141414]/50'
              }`}
            >
              {isSelected('LIBRARY', 'history') ? (
                <span className="w-1.5 h-1.5 bg-[#C5A059] rounded-full shrink-0"></span>
              ) : (
                <Clock className="w-4 h-4 text-[#666666] shrink-0" />
              )}
              <span>Listening Archives</span>
            </button>
          </nav>
        </div>

        {/* Pinned Archives */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-2">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#666666] font-semibold">
              London Sessions
            </span>
            <FolderHeart className="w-3.5 h-3.5 text-[#666666]" />
          </div>
          <div className="space-y-1">
            {playlists.map((pl) => (
              <button
                key={pl.id}
                onClick={() => setActiveView({ type: 'PLAYLIST', playlistId: pl.id })}
                className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition-all ${
                  activeView.type === 'PLAYLIST' && (activeView as { playlistId: string }).playlistId === pl.id
                    ? 'text-[#E0E0E0] bg-[#141414] font-medium'
                    : 'text-[#888888] hover:text-white hover:bg-[#141414]/50'
                }`}
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <Music2 className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                  <span className="truncate">{pl.title}</span>
                </div>
                {pl.isPinned && <Pin className="w-3 h-3 text-[#C5A059] shrink-0 opacity-70" />}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Footer Widget */}
      <div className="p-4 bg-[#141414] rounded-lg border border-[#1F1F1F] space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-[10px] text-[#C5A059] uppercase tracking-widest font-semibold">Premium</p>
          <button 
            onClick={openSettings}
            className="text-[#666666] hover:text-[#C5A059] transition-colors"
            title="Equalizer Settings"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
          </button>
        </div>
        <p className="text-xs text-[#888888] leading-relaxed">
          High-fidelity 24-bit studio streaming enabled.
        </p>
      </div>
    </aside>
  );
};
