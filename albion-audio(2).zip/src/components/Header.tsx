import React from 'react';
import { Search, SlidersHorizontal, Radio, ShieldCheck, Sparkles, Disc } from 'lucide-react';
import { ActiveView, AudioDevice, AudioQuality } from '../types';

interface HeaderProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  openSearch: () => void;
  openSettings: () => void;
  openDeviceModal: () => void;
  currentDevice: AudioDevice;
  audioQuality: AudioQuality;
  isPlaying: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  setActiveView,
  openSearch,
  openSettings,
  openDeviceModal,
  currentDevice,
  audioQuality,
  isPlaying
}) => {
  return (
    <header className="sticky top-0 z-30 h-16 w-full bg-[#0D0D0D]/90 backdrop-blur-xl border-b border-[#1F1F1F] px-6 flex items-center justify-between transition-all">
      {/* Brand Badge & Origin */}
      <div className="flex items-center space-x-6">
        <button
          onClick={() => setActiveView({ type: 'DISCOVER' })}
          className="flex items-center space-x-3 text-left group focus:outline-none"
        >
          <div className="w-8 h-8 rounded-sm bg-[#C5A059] flex items-center justify-center text-[#0A0A0A] font-bold text-xs shadow-sm">
            A
          </div>
          <div>
            <div className="font-serif italic text-lg tracking-tight text-[#F5F5F0] flex items-center gap-2">
              Albion Audio
            </div>
            <div className="text-[9px] text-[#666666] tracking-[0.2em] uppercase font-mono-tech">
              London · Est. 2026
            </div>
          </div>
        </button>

        {/* Status Pills */}
        <div className="hidden lg:flex items-center space-x-3 text-xs border-l border-[#1F1F1F] pl-6">
          <button
            onClick={openDeviceModal}
            className="flex items-center space-x-2 px-3 py-1 rounded-full bg-[#141414] border border-[#1F1F1F] hover:border-[#C5A059]/50 text-[#888888] hover:text-[#E0E0E0] transition-all"
          >
            <Radio className="w-3.5 h-3.5 text-[#C5A059]" />
            <span className="font-medium text-[11px]">{currentDevice.name}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          </button>

          <div className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-[#C5A059]/10 border border-[#C5A059]/30 text-[#C5A059] text-[11px] font-mono-tech">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{audioQuality.split(' ')[0]}</span>
          </div>
        </div>
      </div>

      {/* Center Search Bar Trigger */}
      <button
        onClick={openSearch}
        className="w-full max-w-md mx-4 px-4 py-2 rounded-lg bg-[#141414] border border-[#1F1F1F] hover:border-[#333333] text-[#888888] text-xs flex items-center justify-between group transition-all"
      >
        <div className="flex items-center space-x-2.5">
          <Search className="w-3.5 h-3.5 text-[#666666] group-hover:text-[#E0E0E0] transition-colors" />
          <span className="text-[#888888] group-hover:text-[#E0E0E0] text-xs font-light">Search archives, artists, albums...</span>
        </div>
        <kbd className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-mono-tech bg-[#1A1A1A] border border-[#333333] text-[#888888] rounded">
          ⌘K
        </kbd>
      </button>

      {/* Right Controls */}
      <div className="flex items-center space-x-3">
        <button
          onClick={() => setActiveView({ type: 'JOURNEYS' })}
          className="hidden md:flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full bg-[#1A1A1A] hover:bg-[#222222] text-xs text-[#E0E0E0] border border-[#333333] transition-all font-medium"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>Curate Journey</span>
        </button>

        <button
          onClick={openSettings}
          className="p-2 rounded-lg bg-[#141414] hover:bg-[#1A1A1A] border border-[#1F1F1F] hover:border-[#C5A059]/40 text-[#888888] hover:text-[#E0E0E0] transition-colors"
          title="Audiophile Settings & Equalizer"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>

        {/* Profile Avatar */}
        <div className="w-8 h-8 rounded-full bg-[#1A1A1A] border border-[#333333] p-0.5">
          <div className="w-full h-full rounded-full bg-[#0A0A0A] flex items-center justify-center text-[10px] text-[#C5A059] font-bold">
            UK
          </div>
        </div>
      </div>
    </header>
  );
};
