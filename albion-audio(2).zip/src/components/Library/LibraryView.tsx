import React, { useState } from 'react';
import { Disc, User, Music, Clock, Pin, FolderPlus, Play, Plus, Heart, Filter } from 'lucide-react';
import { Album, Artist, Playlist, Track } from '../../types';

interface LibraryViewProps {
  filter?: 'albums' | 'artists' | 'genres' | 'playlists' | 'history' | 'pinned';
  albums: Album[];
  artists: Artist[];
  tracks: Track[];
  playlists: Playlist[];
  history: Track[];
  onPlayTrack: (track: Track) => void;
  onPlayAlbum: (album: Album) => void;
  onSelectAlbum: (albumId: string) => void;
  onSelectArtist: (artistId: string) => void;
  onCreatePlaylist: (title: string, description: string) => void;
}

export const LibraryView: React.FC<LibraryViewProps> = ({
  filter = 'albums',
  albums,
  artists,
  tracks,
  playlists,
  history,
  onPlayTrack,
  onPlayAlbum,
  onSelectAlbum,
  onSelectArtist,
  onCreatePlaylist
}) => {
  const [activeTab, setActiveTab] = useState<'albums' | 'artists' | 'playlists' | 'history'>(
    filter === 'pinned' ? 'playlists' : (filter as 'albums' | 'artists' | 'playlists' | 'history') || 'albums'
  );
  const [showNewPlaylistModal, setShowNewPlaylistModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onCreatePlaylist(newTitle, newDesc);
    setNewTitle('');
    setNewDesc('');
    setShowNewPlaylistModal(false);
  };

  return (
    <div className="space-y-8 pb-24">
      {/* Header & Category Tabs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <span className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest block mb-1">
            Personal Collection
          </span>
          <h1 className="text-3xl md:text-4xl font-serif font-bold text-[#F7F5F0]">
            Library Archives
          </h1>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowNewPlaylistModal(true)}
            className="px-4 py-2 rounded-xl bg-[#C5A059] hover:bg-[#D4AF66] text-[#111317] text-xs font-semibold flex items-center space-x-2 transition-all shadow-lg"
          >
            <Plus className="w-4 h-4" />
            <span>New Custom Playlist</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 border-b border-white/5 pb-3">
        <button
          onClick={() => setActiveTab('albums')}
          className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
            activeTab === 'albums' ? 'bg-[#C5A059]/20 border border-[#C5A059] text-[#C5A059]' : 'text-[#8E96A3] hover:text-white'
          }`}
        >
          Master Albums ({albums.length})
        </button>
        <button
          onClick={() => setActiveTab('artists')}
          className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
            activeTab === 'artists' ? 'bg-[#C5A059]/20 border border-[#C5A059] text-[#C5A059]' : 'text-[#8E96A3] hover:text-white'
          }`}
        >
          Artists ({artists.length})
        </button>
        <button
          onClick={() => setActiveTab('playlists')}
          className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
            activeTab === 'playlists' ? 'bg-[#C5A059]/20 border border-[#C5A059] text-[#C5A059]' : 'text-[#8E96A3] hover:text-white'
          }`}
        >
          Playlists ({playlists.length})
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
            activeTab === 'history' ? 'bg-[#C5A059]/20 border border-[#C5A059] text-[#C5A059]' : 'text-[#8E96A3] hover:text-white'
          }`}
        >
          Listening History
        </button>
      </div>

      {/* Content depending on active tab */}
      {activeTab === 'albums' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {albums.map((album) => (
            <div 
              key={album.id}
              className="glass-panel p-4 rounded-2xl border border-white/5 hover:border-[#C5A059]/40 transition-all group cursor-pointer"
              onClick={() => onSelectAlbum(album.id)}
            >
              <div className="relative aspect-square rounded-xl overflow-hidden mb-3">
                <img 
                  src={album.coverUrl} 
                  alt={album.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onPlayAlbum(album);
                  }}
                  className="absolute bottom-3 right-3 w-10 h-10 rounded-full bg-[#C5A059] text-[#111317] flex items-center justify-center opacity-0 group-hover:opacity-100 shadow-xl transition-all"
                >
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                </button>
              </div>
              <h3 className="text-sm font-semibold text-[#F7F5F0] truncate group-hover:text-[#C5A059] transition-colors">
                {album.title}
              </h3>
              <p className="text-xs text-[#8E96A3] truncate">{album.artist}</p>
              <p className="text-[10px] font-mono-tech text-[#C5A059] mt-2">{album.releaseYear} · {album.genre}</p>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'artists' && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {artists.map((artist) => (
            <div 
              key={artist.id}
              onClick={() => onSelectArtist(artist.id)}
              className="glass-panel p-5 rounded-2xl border border-white/5 hover:border-[#C5A059]/40 transition-all group cursor-pointer flex items-center space-x-4"
            >
              <img 
                src={artist.avatarUrl} 
                alt={artist.name}
                referrerPolicy="no-referrer"
                className="w-16 h-16 rounded-full object-cover border border-[#C5A059]/30 group-hover:scale-105 transition-transform"
              />
              <div className="truncate">
                <h3 className="text-sm font-semibold text-[#F7F5F0] group-hover:text-[#C5A059] transition-colors truncate">
                  {artist.name}
                </h3>
                <p className="text-xs text-[#8E96A3] truncate">{artist.origin}</p>
                <p className="text-[10px] font-mono-tech text-[#C5A059] mt-1">{artist.genre}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'playlists' && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {playlists.map((pl) => (
            <div 
              key={pl.id}
              className="glass-panel p-5 rounded-2xl border border-white/5 hover:border-[#C5A059]/40 transition-all space-y-3 group cursor-pointer"
            >
              <div className="relative aspect-video rounded-xl overflow-hidden">
                <img src={pl.coverUrl} alt={pl.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-[#F7F5F0] group-hover:text-[#C5A059] transition-colors">{pl.title}</h3>
                <p className="text-xs text-[#8E96A3] line-clamp-2 mt-1">{pl.description}</p>
                <span className="text-[10px] font-mono-tech text-[#C5A059] mt-2 block">{pl.tracks.length} Tracks</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'history' && (
        <div className="glass-panel p-6 rounded-2xl border border-white/5 space-y-3">
          <h3 className="text-sm font-semibold text-[#F7F5F0] mb-4">Recently Listened Sessions</h3>
          {history.length > 0 ? (
            history.map((track, idx) => (
              <div 
                key={track.id + idx}
                onClick={() => onPlayTrack(track)}
                className="p-3 rounded-xl bg-[#181B20] hover:bg-[#20242B] border border-white/5 flex items-center justify-between text-xs cursor-pointer group transition-all"
              >
                <div className="flex items-center space-x-3">
                  <Play className="w-4 h-4 text-[#C5A059]" />
                  <div>
                    <h4 className="font-semibold text-white group-hover:text-[#C5A059] transition-colors">{track.title}</h4>
                    <p className="text-[11px] text-[#8E96A3]">{track.artist} · {track.album}</p>
                  </div>
                </div>
                <span className="text-[10px] font-mono-tech text-[#C5A059]">{track.audioQuality.split(' ')[0]}</span>
              </div>
            ))
          ) : (
            <p className="text-xs text-[#8E96A3] italic">No listening history recorded yet in this session.</p>
          )}
        </div>
      )}

      {/* New Playlist Modal */}
      {showNewPlaylistModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <form onSubmit={handleCreate} className="w-full max-w-md glass-panel p-6 rounded-2xl border border-white/10 space-y-4">
            <h3 className="text-lg font-serif font-bold text-white">Create Custom Playlist</h3>
            <div>
              <label className="block text-xs text-[#8E96A3] mb-1 font-mono-tech">Playlist Title</label>
              <input 
                type="text" 
                value={newTitle} 
                onChange={(e) => setNewTitle(e.target.value)} 
                placeholder="e.g. Abbey Road Late Night Session" 
                className="w-full bg-[#181B20] border border-white/10 rounded-xl p-3 text-xs text-white focus:border-[#C5A059] outline-none" 
                required 
              />
            </div>
            <div>
              <label className="block text-xs text-[#8E96A3] mb-1 font-mono-tech">Description</label>
              <textarea 
                value={newDesc} 
                onChange={(e) => setNewDesc(e.target.value)} 
                placeholder="Notes on acoustic selection..." 
                className="w-full bg-[#181B20] border border-white/10 rounded-xl p-3 text-xs text-white focus:border-[#C5A059] outline-none h-24" 
              />
            </div>
            <div className="flex justify-end space-x-3 pt-2">
              <button 
                type="button" 
                onClick={() => setShowNewPlaylistModal(false)} 
                className="px-4 py-2 rounded-xl text-xs text-[#8E96A3] hover:text-white"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="px-4 py-2 rounded-xl bg-[#C5A059] text-[#111317] text-xs font-semibold hover:bg-[#D4AF66]"
              >
                Create
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
