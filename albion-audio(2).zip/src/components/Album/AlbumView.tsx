import React, { useState } from 'react';
import { Play, ArrowLeft, Disc, ShieldCheck, Sparkles, RefreshCw, Clock, User, Building } from 'lucide-react';
import { Album, Track } from '../../types';

interface AlbumViewProps {
  album: Album;
  onBack: () => void;
  onPlayTrack: (track: Track) => void;
  onPlayAlbum: (album: Album) => void;
  onSelectArtist: (artistId: string) => void;
}

export const AlbumView: React.FC<AlbumViewProps> = ({
  album,
  onBack,
  onPlayTrack,
  onPlayAlbum,
  onSelectArtist
}) => {
  const [essayText, setEssayText] = useState(album.essay);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateEssay = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/editorial/essay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: album.title,
          artist: album.artist,
          genre: album.genre,
          releaseYear: album.releaseYear
        })
      });
      const data = await res.json();
      if (data.essay) {
        setEssayText(data.essay);
      }
    } catch (err) {
      console.error('Failed to generate essay:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = Math.floor(secs % 60);
    return `${mins}:${remaining < 10 ? '0' : ''}${remaining}`;
  };

  return (
    <div className="space-y-10 pb-24 animate-in fade-in duration-300">
      {/* Back Button */}
      <button onClick={onBack} className="flex items-center space-x-2 text-xs text-[#C5A059] hover:underline">
        <ArrowLeft className="w-4 h-4" />
        <span>Back</span>
      </button>

      {/* Album Hero Header */}
      <div className="glass-panel p-8 md:p-12 rounded-3xl border border-white/10 flex flex-col md:flex-row items-center md:items-end space-y-6 md:space-y-0 md:space-x-10">
        <div className="relative group shrink-0 w-48 h-48 md:w-64 md:h-64 rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
          <img 
            src={album.coverUrl} 
            alt={album.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute top-3 left-3 px-2.5 py-1 rounded bg-black/60 backdrop-blur-md text-[10px] font-mono-tech text-[#C5A059] border border-white/10">
            24-BIT MASTER
          </div>
        </div>

        <div className="space-y-4 flex-1 text-center md:text-left">
          <span className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest block">
            {album.genre} · {album.releaseYear}
          </span>
          <h1 className="text-3xl md:text-5xl font-serif font-bold text-white leading-tight">
            {album.title}
          </h1>
          <p 
            onClick={() => onSelectArtist(album.artistId)}
            className="text-lg text-[#8E96A3] font-medium hover:text-[#C5A059] hover:underline cursor-pointer"
          >
            {album.artist}
          </p>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 pt-2">
            <button
              onClick={() => onPlayAlbum(album)}
              className="px-6 py-3 rounded-xl bg-[#C5A059] hover:bg-[#D4AF66] text-[#111317] text-xs font-semibold uppercase tracking-wider flex items-center space-x-2 shadow-xl hover:scale-105 transition-all"
            >
              <Play className="w-4 h-4 fill-current ml-0.5" />
              <span>Play Master Album</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tracklist */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <h2 className="text-xl font-serif font-bold text-white">Album Tracklist</h2>
          <span className="text-xs font-mono-tech text-[#8E96A3]">{album.tracks.length} Master Tracks</span>
        </div>

        <div className="space-y-2">
          {album.tracks.map((track, idx) => (
            <div
              key={track.id + idx}
              onClick={() => onPlayTrack(track)}
              className="p-4 rounded-2xl bg-[#181B20] hover:bg-[#20242B] border border-white/5 flex items-center justify-between text-xs cursor-pointer group transition-all"
            >
              <div className="flex items-center space-x-4">
                <span className="w-6 font-mono-tech text-[#8E96A3] text-center">{idx + 1}</span>
                <div>
                  <h4 className="font-semibold text-white group-hover:text-[#C5A059] transition-colors text-sm">{track.title}</h4>
                  <p className="text-[11px] text-[#8E96A3]">{track.composer ? `Composer: ${track.composer}` : track.artist}</p>
                </div>
              </div>

              <div className="flex items-center space-x-6">
                <span className="text-[10px] font-mono-tech text-[#C5A059] bg-[#C5A059]/10 px-2 py-0.5 rounded border border-[#C5A059]/30">
                  {track.audioQuality.split(' ')[0]}
                </span>
                <span className="font-mono-tech text-[#8E96A3]">{formatDuration(track.duration)}</span>
                <Play className="w-4 h-4 text-[#C5A059] group-hover:scale-110 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Monocle Liner Notes Essay */}
      <div className="glass-panel p-8 rounded-3xl border border-white/10 space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center space-x-2 text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest">
            <Sparkles className="w-4 h-4" />
            <span>Monocle Editorial Liner Note</span>
          </div>

          <button
            onClick={handleGenerateEssay}
            disabled={isGenerating}
            className="px-3 py-1.5 rounded-lg bg-[#20242B] border border-white/10 hover:border-[#C5A059] text-xs text-[#8E96A3] hover:text-white flex items-center space-x-2 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#C5A059] ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{isGenerating ? 'Generating...' : 'Regenerate via Gemini'}</span>
          </button>
        </div>

        <div className="prose prose-invert prose-sm text-[#F7F5F0]/90 font-serif leading-relaxed text-base space-y-3">
          {essayText.split('\n\n').map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
      </div>

      {/* Studio Credits */}
      <div className="glass-panel p-8 rounded-3xl border border-white/5 space-y-4">
        <h3 className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest">
          Studio Recording Credentials
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-xs text-[#8E96A3]">
          <div>
            <span className="block font-mono-tech text-[10px] uppercase text-[#8E96A3]">Producer</span>
            <span className="text-white font-medium">{album.credits.producer}</span>
          </div>
          <div>
            <span className="block font-mono-tech text-[10px] uppercase text-[#8E96A3]">Audio Engineer</span>
            <span className="text-white font-medium">{album.credits.engineer}</span>
          </div>
          <div>
            <span className="block font-mono-tech text-[10px] uppercase text-[#8E96A3]">Recording Studio</span>
            <span className="text-white font-medium">{album.credits.studio}</span>
          </div>
          <div>
            <span className="block font-mono-tech text-[10px] uppercase text-[#8E96A3]">Record Label</span>
            <span className="text-white font-medium">{album.credits.label}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
