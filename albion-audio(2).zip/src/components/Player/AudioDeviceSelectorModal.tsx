import React from 'react';
import { X, Radio, Check, Volume2, ShieldCheck, Sparkles } from 'lucide-react';
import { AudioDevice } from '../../types';

interface AudioDeviceSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  devices: AudioDevice[];
  currentDevice: AudioDevice;
  onSelectDevice: (device: AudioDevice) => void;
}

export const AudioDeviceSelectorModal: React.FC<AudioDeviceSelectorModalProps> = ({
  isOpen,
  onClose,
  devices,
  currentDevice,
  onSelectDevice
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-xl glass-panel rounded-2xl border border-white/10 p-6 space-y-6 shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-[#C5A059]/15 border border-[#C5A059]/30 flex items-center justify-center text-[#C5A059]">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-serif font-bold text-[#F7F5F0]">Audiophile Output Routing</h3>
              <p className="text-xs text-[#8E96A3]">Bit-perfect transmission to British audio hardware</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-[#8E96A3] hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Device List */}
        <div className="space-y-3">
          {devices.map((device) => {
            const isSelected = device.id === currentDevice.id;
            return (
              <div
                key={device.id}
                onClick={() => {
                  onSelectDevice(device);
                  onClose();
                }}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                  isSelected 
                    ? 'bg-[#C5A059]/15 border-[#C5A059] shadow-lg' 
                    : 'bg-[#181B20] border-white/5 hover:border-white/20'
                }`}
              >
                <div className="flex items-center space-x-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
                    isSelected ? 'bg-[#C5A059] text-[#111317] border-[#C5A059]' : 'bg-[#20242B] text-[#8E96A3] border-white/10'
                  }`}>
                    <Volume2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-[#F7F5F0]">{device.name}</h4>
                    <p className="text-xs text-[#8E96A3]">{device.brand} · {device.type}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className="text-[10px] font-mono-tech text-[#C5A059] bg-[#C5A059]/10 px-2 py-0.5 rounded border border-[#C5A059]/20">
                        {device.connection}
                      </span>
                      <span className="text-[10px] text-[#8E96A3] font-mono-tech">
                        Max {device.maxResolution}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  {isSelected ? (
                    <div className="flex items-center space-x-1 text-xs text-[#C5A059] font-semibold bg-[#C5A059]/10 px-3 py-1 rounded-full border border-[#C5A059]/30">
                      <Check className="w-4 h-4" />
                      <span>Active Output</span>
                    </div>
                  ) : (
                    <span className="text-xs text-[#8E96A3] hover:text-white">Route Here</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Tech Footer */}
        <div className="p-3.5 rounded-xl bg-[#181B20] border border-white/5 text-xs text-[#8E96A3] flex items-center space-x-3">
          <ShieldCheck className="w-5 h-5 text-[#C5A059] shrink-0" />
          <p>
            Albion Audio supports bit-exact WASAPI / ALSA / AirPlay 2 output bypass, eliminating OS kernel resampling.
          </p>
        </div>
      </div>
    </div>
  );
};
