import React, { useEffect, useRef, useState } from 'react';
import { 
  X, 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX, 
  ListMusic, 
  AlignLeft, 
  Radio, 
  ShieldCheck, 
  Heart, 
  Sparkles,
  Info,
  Disc,
  SlidersHorizontal
} from 'lucide-react';
import { AudioDevice, Track } from '../../types';
import { audioEngine } from '../../lib/audioEngine';

interface FullScreenPlayerProps {
  currentTrack: Track;
  isPlaying: boolean;
  togglePlay: () => void;
  nextTrack: () => void;
  prevTrack: () => void;
  currentTime: number;
  duration: number;
  onSeek: (time: number) => void;
  volume: number;
  setVolume: (vol: number) => void;
  closeFullScreen: () => void;
  currentDevice: AudioDevice;
  openDeviceModal: () => void;
  openSettings: () => void;
  queue: Track[];
  playTrackFromQueue: (track: Track) => void;
}

export const FullScreenPlayer: React.FC<FullScreenPlayerProps> = ({
  currentTrack,
  isPlaying,
  togglePlay,
  nextTrack,
  prevTrack,
  currentTime,
  duration,
  onSeek,
  volume,
  setVolume,
  closeFullScreen,
  currentDevice,
  openDeviceModal,
  openSettings,
  queue,
  playTrackFromQueue
}) => {
  const [activeTab, setActiveTab] = useState<'VISUALIZER' | 'LYRICS' | 'ESSAY' | 'QUEUE'>('VISUALIZER');
  const [isLiked, setIsLiked] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Animated Waveform Canvas Visualizer using Web Audio API frequency data
  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const frequencyData = new Uint8Array(64);

    const render = () => {
      audioEngine.getFrequencyData(frequencyData);

      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;

      const width = canvas.width;
      const height = canvas.height;

      ctx.clearRect(0, 0, width, height);

      const barWidth = (width / frequencyData.length) * 1.5;
      let x = 0;

      // Draw subtle bronze audio spectrum
      for (let i = 0; i < frequencyData.length; i++) {
        const barHeight = (frequencyData[i] / 255) * (height * 0.7);

        const gradient = ctx.createLinearGradient(0, height, 0, height - barHeight);
        gradient.addColorStop(0, 'rgba(197, 160, 89, 0.05)');
        gradient.addColorStop(0.5, 'rgba(197, 160, 89, 0.4)');
        gradient.addColorStop(1, 'rgba(212, 175, 102, 0.8)');

        ctx.fillStyle = gradient;
        ctx.fillRect(x, height - barHeight, barWidth - 2, barHeight);

        x += barWidth;
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying]);

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = Math.floor(secs % 60);
    return `${mins}:${remainder < 10 ? '0' : ''}${remainder}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0E1013] text-[#F7F5F0] flex flex-col justify-between p-6 md:p-12 overflow-hidden backdrop-blur-3xl animate-in fade-in duration-300">
      {/* Dynamic Background Backlight */}
      <div 
        className="absolute inset-0 opacity-20 pointer-events-none filter blur-[120px] scale-125 transition-all duration-1000"
        style={{
          backgroundImage: `url(${currentTrack.coverUrl})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />

      {/* Top Bar */}
      <div className="relative z-10 flex items-center justify-between border-b border-white/10 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-[#181B20] border border-[#C5A059]/40 flex items-center justify-center text-[#C5A059]">
            <Disc className={`w-4 h-4 ${isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '4s' }} />
          </div>
          <div>
            <div className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest">
              Immersive Audiophile Mode
            </div>
            <div className="text-sm font-semibold text-[#F7F5F0]">
              {currentTrack.audioQuality}
            </div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center space-x-2 bg-[#181B20]/80 p-1 rounded-xl border border-white/10">
          <button
            onClick={() => setActiveTab('VISUALIZER')}
            className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'VISUALIZER' ? 'bg-[#C5A059] text-[#111317]' : 'text-[#8E96A3] hover:text-white'
            }`}
          >
            Visualizer
          </button>
          <button
            onClick={() => setActiveTab('LYRICS')}
            className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'LYRICS' ? 'bg-[#C5A059] text-[#111317]' : 'text-[#8E96A3] hover:text-white'
            }`}
          >
            Lyrics
          </button>
          <button
            onClick={() => setActiveTab('ESSAY')}
            className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'ESSAY' ? 'bg-[#C5A059] text-[#111317]' : 'text-[#8E96A3] hover:text-white'
            }`}
          >
            Liner Notes
          </button>
          <button
            onClick={() => setActiveTab('QUEUE')}
            className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'QUEUE' ? 'bg-[#C5A059] text-[#111317]' : 'text-[#8E96A3] hover:text-white'
            }`}
          >
            Queue ({queue.length})
          </button>
        </div>

        {/* Exit Button */}
        <button
          onClick={closeFullScreen}
          className="p-2.5 rounded-full bg-[#181B20] border border-white/10 hover:border-[#C5A059] text-[#8E96A3] hover:text-white transition-all"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Center Area */}
      <div className="relative z-10 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center my-8">
        {/* Left: Album Cover Art & Signal Path */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center space-y-6">
          <div className="relative group max-w-sm w-full">
            <img 
              src={currentTrack.coverUrl} 
              alt={currentTrack.title}
              referrerPolicy="no-referrer"
              className="w-full aspect-square rounded-2xl object-cover border border-white/10 shadow-2xl group-hover:scale-102 transition-transform duration-500"
            />
            <div className="absolute -bottom-4 right-4 bg-[#181B20]/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-[#C5A059]/40 text-[11px] font-mono-tech text-[#C5A059] flex items-center space-x-2 shadow-xl">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>24-bit / 192kHz Master</span>
            </div>
          </div>

          {/* Audio Signal Path Badge */}
          <div className="w-full max-w-sm bg-[#181B20]/60 border border-white/5 p-4 rounded-2xl space-y-2 text-xs">
            <div className="flex items-center justify-between text-[#8E96A3]">
              <span className="font-mono-tech uppercase text-[10px] tracking-wider">Output Signal Route</span>
              <button onClick={openDeviceModal} className="text-[#C5A059] hover:underline flex items-center gap-1">
                <Radio className="w-3 h-3" />
                Change
              </button>
            </div>
            <div className="flex items-center justify-between font-semibold text-[#F7F5F0]">
              <span>{currentDevice.name}</span>
              <span className="text-[10px] font-mono-tech text-emerald-400">{currentDevice.connection}</span>
            </div>
          </div>
        </div>

        {/* Right: Tab Content (Visualizer / Lyrics / Liner Notes / Queue) */}
        <div className="lg:col-span-7 h-full max-h-[460px] flex flex-col justify-center overflow-hidden">
          {activeTab === 'VISUALIZER' && (
            <div className="flex flex-col h-full justify-between space-y-6 py-4">
              <div>
                <span className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest mb-2 block">
                  {currentTrack.genre}
                </span>
                <h1 className="text-3xl md:text-5xl font-serif font-bold text-[#F7F5F0] leading-tight mb-2">
                  {currentTrack.title}
                </h1>
                <p className="text-lg text-[#8E96A3] font-medium">
                  {currentTrack.artist} — <span className="italic font-serif">{currentTrack.album}</span>
                </p>
              </div>

              {/* FFT Spectrum Canvas */}
              <div className="relative w-full h-40 bg-[#181B20]/40 rounded-2xl border border-white/5 overflow-hidden p-4">
                <canvas ref={canvasRef} className="w-full h-full block" />
              </div>

              {/* Technical Credits */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs text-[#8E96A3] pt-2 border-t border-white/10">
                <div>
                  <span className="block text-[10px] font-mono-tech uppercase">Composer</span>
                  <span className="text-white">{currentTrack.composer || 'N/A'}</span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono-tech uppercase">Producer</span>
                  <span className="text-white">{currentTrack.producer || 'N/A'}</span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono-tech uppercase">Studio</span>
                  <span className="text-white">{currentTrack.studio || 'N/A'}</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'LYRICS' && (
            <div className="h-full overflow-y-auto space-y-6 pr-4 scrollbar-thin">
              <h3 className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest">
                Synchronized Lyrics
              </h3>
              {currentTrack.lyrics && currentTrack.lyrics.length > 0 ? (
                <div className="space-y-4">
                  {currentTrack.lyrics.map((line, idx) => {
                    const isCurrent = currentTime >= line.time && (idx === currentTrack.lyrics!.length - 1 || currentTime < currentTrack.lyrics![idx + 1].time);
                    return (
                      <p 
                        key={idx}
                        className={`text-xl md:text-2xl font-serif transition-all duration-300 ${
                          isCurrent ? 'text-[#C5A059] font-bold scale-102 pl-2 border-l-2 border-[#C5A059]' : 'text-[#8E96A3] opacity-60'
                        }`}
                      >
                        {line.text}
                      </p>
                    );
                  })}
                </div>
              ) : (
                <p className="text-[#8E96A3] italic font-serif">Instrumental performance. No lyrics registered.</p>
              )}
            </div>
          )}

          {activeTab === 'ESSAY' && (
            <div className="h-full overflow-y-auto space-y-4 pr-4 text-sm leading-relaxed text-[#8E96A3]">
              <div className="flex items-center space-x-2 text-[#C5A059] text-xs font-mono-tech uppercase tracking-widest">
                <Sparkles className="w-4 h-4" />
                <span>Monocle Editorial Liner Note</span>
              </div>
              <p className="text-lg font-serif italic text-white leading-relaxed">
                "{currentTrack.essay || 'An exquisite masterwork of British recording history.'}"
              </p>
            </div>
          )}

          {activeTab === 'QUEUE' && (
            <div className="h-full overflow-y-auto space-y-2 pr-4">
              <h3 className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest mb-3">
                Up Next In Listening Queue
              </h3>
              {queue.map((track, idx) => (
                <div 
                  key={track.id + idx}
                  onClick={() => playTrackFromQueue(track)}
                  className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                    track.id === currentTrack.id 
                      ? 'bg-[#C5A059]/15 border-[#C5A059]/40 text-[#C5A059]' 
                      : 'bg-[#181B20]/50 border-white/5 hover:border-white/20 text-[#8E96A3] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <img src={track.coverUrl} alt={track.title} className="w-10 h-10 rounded-lg object-cover" />
                    <div>
                      <h5 className="text-xs font-semibold text-white truncate">{track.title}</h5>
                      <p className="text-[11px] text-[#8E96A3]">{track.artist}</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono-tech text-[#8E96A3]">{track.audioQuality.split(' ')[0]}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Timeline & Controls */}
      <div className="relative z-10 space-y-4 max-w-4xl mx-auto w-full pt-4 border-t border-white/10">
        {/* Seekbar */}
        <div className="flex items-center space-x-3 text-xs font-mono-tech text-[#8E96A3]">
          <span>{formatTime(currentTime)}</span>
          <input
            type="range"
            min={0}
            max={duration || 100}
            value={currentTime}
            onChange={(e) => onSeek(Number(e.target.value))}
            className="w-full h-1.5 bg-[#20242B] rounded-lg appearance-none cursor-pointer accent-[#C5A059]"
          />
          <span>{formatTime(duration)}</span>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-between">
          <button 
            onClick={() => setIsLiked(!isLiked)}
            className={`p-2 rounded-full border border-white/10 ${isLiked ? 'text-rose-500 bg-rose-500/10' : 'text-[#8E96A3] hover:text-white'}`}
          >
            <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
          </button>

          <div className="flex items-center space-x-6">
            <button onClick={prevTrack} className="text-[#8E96A3] hover:text-white transition-colors">
              <SkipBack className="w-6 h-6" />
            </button>
            <button
              onClick={togglePlay}
              className="w-14 h-14 rounded-full bg-[#C5A059] hover:bg-[#D4AF66] text-[#111317] flex items-center justify-center shadow-2xl scale-105 active:scale-95 transition-all"
            >
              {isPlaying ? <Pause className="w-7 h-7 fill-current" /> : <Play className="w-7 h-7 fill-current ml-1" />}
            </button>
            <button onClick={nextTrack} className="text-[#8E96A3] hover:text-white transition-colors">
              <SkipForward className="w-6 h-6" />
            </button>
          </div>

          <button onClick={openSettings} className="p-2 text-[#8E96A3] hover:text-white transition-colors">
            <SlidersHorizontal className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
