import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  AlignLeft, 
  ListMusic, 
  Radio, 
  Heart,
  SlidersHorizontal,
  Disc
} from 'lucide-react';
import { AudioDevice, Track } from '../../types';

interface FloatingPlayerProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  togglePlay: () => void;
  nextTrack: () => void;
  prevTrack: () => void;
  currentTime: number;
  duration: number;
  onSeek: (time: number) => void;
  volume: number;
  setVolume: (vol: number) => void;
  openFullScreen: () => void;
  toggleQueue: () => void;
  showQueue: boolean;
  toggleLyrics: () => void;
  showLyrics: boolean;
  openDeviceModal: () => void;
  currentDevice: AudioDevice;
  openSettings: () => void;
}

export const FloatingPlayer: React.FC<FloatingPlayerProps> = ({
  currentTrack,
  isPlaying,
  togglePlay,
  nextTrack,
  prevTrack,
  currentTime,
  duration,
  onSeek,
  volume,
  setVolume,
  openFullScreen,
  toggleQueue,
  showQueue,
  toggleLyrics,
  showLyrics,
  openDeviceModal,
  currentDevice,
  openSettings
}) => {
  const [isLiked, setIsLiked] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [prevVol, setPrevVol] = useState(0.8);

  if (!currentTrack) return null;

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainderSecs = Math.floor(secs % 60);
    return `${mins}:${remainderSecs < 10 ? '0' : ''}${remainderSecs}`;
  };

  const handleMuteToggle = () => {
    if (isMuted) {
      setVolume(prevVol);
      setIsMuted(false);
    } else {
      setPrevVol(volume);
      setVolume(0);
      setIsMuted(true);
    }
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#0D0D0D]/95 backdrop-blur-xl border-t border-[#1F1F1F] p-3 px-6 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-6">
        {/* Track Info */}
        <div className="flex items-center space-x-4 min-w-[220px] max-w-[280px]">
          <div className="relative group shrink-0 cursor-pointer" onClick={openFullScreen}>
            <img 
              src={currentTrack.coverUrl} 
              alt={currentTrack.title}
              referrerPolicy="no-referrer"
              className="w-12 h-12 rounded-lg object-cover border border-[#1F1F1F] shadow-lg group-hover:scale-105 transition-transform"
            />
            <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
              <Maximize2 className="w-4 h-4 text-white" />
            </div>
          </div>

          <div className="truncate">
            <h4 
              onClick={openFullScreen}
              className="text-xs font-semibold text-[#E0E0E0] truncate hover:text-[#C5A059] cursor-pointer transition-colors"
            >
              {currentTrack.title}
            </h4>
            <p className="text-[11px] text-[#888888] truncate">
              {currentTrack.artist}
            </p>
            <div className="flex items-center space-x-1.5 mt-0.5">
              <span className="text-[9px] font-mono-tech text-[#C5A059] uppercase bg-[#C5A059]/10 px-1.5 py-0.2 rounded border border-[#C5A059]/30">
                {currentTrack.audioQuality.split(' ')[0]}
              </span>
              <span className="text-[10px] text-[#666666] truncate">{currentTrack.album}</span>
            </div>
          </div>

          <button 
            onClick={() => setIsLiked(!isLiked)}
            className={`p-1.5 rounded-lg transition-colors ${
              isLiked ? 'text-rose-500' : 'text-[#666666] hover:text-white'
            }`}
          >
            <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Center Controls & Timeline */}
        <div className="flex-1 max-w-xl flex flex-col items-center space-y-1.5">
          {/* Main Buttons */}
          <div className="flex items-center space-x-6">
            <button 
              onClick={prevTrack}
              className="p-1.5 text-[#888888] hover:text-[#E0E0E0] transition-colors"
              title="Previous Track"
            >
              <SkipBack className="w-4 h-4" />
            </button>

            <button
              onClick={togglePlay}
              className="w-10 h-10 rounded-full bg-[#E0E0E0] hover:bg-white text-[#0A0A0A] flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-all"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? (
                <Pause className="w-5 h-5 fill-current" />
              ) : (
                <Play className="w-5 h-5 fill-current ml-0.5" />
              )}
            </button>

            <button 
              onClick={nextTrack}
              className="p-1.5 text-[#888888] hover:text-[#E0E0E0] transition-colors"
              title="Next Track"
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>

          {/* Timeline bar */}
          <div className="w-full flex items-center space-x-3 text-[10px] font-mono-tech text-[#666666]">
            <span className="w-8 text-right">{formatTime(currentTime)}</span>
            <div className="relative flex-1 group py-1 cursor-pointer">
              <input
                type="range"
                min={0}
                max={duration || 100}
                value={currentTime}
                onChange={(e) => onSeek(Number(e.target.value))}
                className="w-full h-1 bg-[#1A1A1A] rounded-lg appearance-none cursor-pointer accent-[#C5A059]"
              />
              <div 
                className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-[#C5A059] rounded-lg pointer-events-none"
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
            <span className="w-8">{formatTime(duration)}</span>
          </div>
        </div>

        {/* Right Tools & Volume */}
        <div className="flex items-center space-x-3 shrink-0">
          {/* Device output button */}
          <button
            onClick={openDeviceModal}
            className="hidden lg:flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-[#141414] border border-[#1F1F1F] hover:border-[#333333] text-xs text-[#888888] hover:text-[#E0E0E0] transition-all"
            title="Audio Output Device"
          >
            <Radio className="w-3.5 h-3.5 text-[#C5A059]" />
            <span className="text-[11px] truncate max-w-[90px]">{currentDevice.name}</span>
          </button>

          {/* Lyrics toggle */}
          <button
            onClick={toggleLyrics}
            className={`p-2 rounded-lg transition-colors ${
              showLyrics ? 'bg-[#C5A059]/20 text-[#C5A059]' : 'text-[#888888] hover:text-[#E0E0E0]'
            }`}
            title="Lyrics Mode"
          >
            <AlignLeft className="w-4 h-4" />
          </button>

          {/* Queue toggle */}
          <button
            onClick={toggleQueue}
            className={`p-2 rounded-lg transition-colors ${
              showQueue ? 'bg-[#C5A059]/20 text-[#C5A059]' : 'text-[#888888] hover:text-[#E0E0E0]'
            }`}
            title="Queue Panel"
          >
            <ListMusic className="w-4 h-4" />
          </button>

          {/* Settings / Equalizer */}
          <button
            onClick={openSettings}
            className="p-2 text-[#888888] hover:text-[#E0E0E0] transition-colors"
            title="Equalizer"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>

          {/* Volume Slider */}
          <div className="hidden sm:flex items-center space-x-1.5 group">
            <button onClick={handleMuteToggle} className="text-[#888888] hover:text-[#E0E0E0]">
              {volume === 0 || isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={isMuted ? 0 : volume}
              onChange={(e) => {
                setVolume(Number(e.target.value));
                if (isMuted) setIsMuted(false);
              }}
              className="w-16 h-1 bg-[#1A1A1A] rounded-lg appearance-none cursor-pointer accent-[#C5A059]"
            />
          </div>

          {/* Expand Full-Screen */}
          <button
            onClick={openFullScreen}
            className="p-2 rounded-lg text-[#C5A059] hover:bg-[#C5A059]/10 transition-colors"
            title="Full-Screen Immersive Player"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
