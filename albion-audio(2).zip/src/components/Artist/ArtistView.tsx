import React from 'react';
import { Play, ArrowLeft, Disc, Calendar, MapPin, Heart, Ticket, Users } from 'lucide-react';
import { Artist, Album, Track } from '../../types';

interface ArtistViewProps {
  artist: Artist;
  onBack: () => void;
  onPlayTrack: (track: Track) => void;
  onPlayAlbum: (album: Album) => void;
  onSelectAlbum: (albumId: string) => void;
}

export const ArtistView: React.FC<ArtistViewProps> = ({
  artist,
  onBack,
  onPlayTrack,
  onPlayAlbum,
  onSelectAlbum
}) => {
  return (
    <div className="space-y-10 pb-24 animate-in fade-in duration-300">
      {/* Back Button */}
      <button onClick={onBack} className="flex items-center space-x-2 text-xs text-[#C5A059] hover:underline">
        <ArrowLeft className="w-4 h-4" />
        <span>Back</span>
      </button>

      {/* Hero Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-white/10 glass-panel min-h-[360px] flex items-end p-8 md:p-12">
        <img 
          src={artist.heroUrl} 
          alt={artist.name}
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover filter brightness-75"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#111317] via-[#111317]/60 to-transparent" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between w-full gap-6">
          <div className="flex items-center space-x-6">
            <img 
              src={artist.avatarUrl} 
              alt={artist.name}
              referrerPolicy="no-referrer"
              className="w-24 h-24 md:w-32 md:h-32 rounded-full object-cover border-2 border-[#C5A059] shadow-2xl"
            />
            <div>
              <span className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest block mb-1">
                {artist.genre} · {artist.origin}
              </span>
              <h1 className="text-4xl md:text-6xl font-serif font-bold text-white mb-2">
                {artist.name}
              </h1>
              <p className="text-xs text-[#8E96A3] font-mono-tech">
                Formed {artist.formedYear} · {(artist.monthlyListeners / 1000000).toFixed(1)}M Monthly Listeners
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            {artist.topTracks[0] && (
              <button
                onClick={() => onPlayTrack(artist.topTracks[0])}
                className="px-6 py-3 rounded-xl bg-[#C5A059] hover:bg-[#D4AF66] text-[#111317] text-xs font-semibold uppercase tracking-wider flex items-center space-x-2 shadow-xl hover:scale-105 transition-all"
              >
                <Play className="w-4 h-4 fill-current ml-0.5" />
                <span>Play Top Track</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Biography Essay */}
      <div className="glass-panel p-8 rounded-3xl border border-white/5 space-y-3">
        <h3 className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest">
          Monocle Artist Biography
        </h3>
        <p className="text-lg font-serif italic text-[#F7F5F0] leading-relaxed">
          "{artist.bio}"
        </p>
      </div>

      {/* Top Master Tracks */}
      <div className="space-y-4">
        <h2 className="text-2xl font-serif font-bold text-white border-b border-white/10 pb-3">
          Flagship Master Tracks
        </h2>
        <div className="space-y-2">
          {artist.topTracks.map((track, idx) => (
            <div 
              key={track.id + idx}
              onClick={() => onPlayTrack(track)}
              className="p-3.5 rounded-2xl bg-[#181B20] hover:bg-[#20242B] border border-white/5 flex items-center justify-between text-xs cursor-pointer group transition-all"
            >
              <div className="flex items-center space-x-4">
                <span className="w-6 font-mono-tech text-[#8E96A3] text-center">{idx + 1}</span>
                <img src={track.coverUrl} alt={track.title} className="w-10 h-10 rounded-xl object-cover" />
                <div>
                  <h4 className="font-semibold text-white group-hover:text-[#C5A059] transition-colors">{track.title}</h4>
                  <p className="text-[11px] text-[#8E96A3]">{track.album}</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <span className="text-[10px] font-mono-tech text-[#C5A059] bg-[#C5A059]/10 px-2 py-0.5 rounded border border-[#C5A059]/30">
                  {track.audioQuality.split(' ')[0]}
                </span>
                <Play className="w-4 h-4 text-[#C5A059] group-hover:scale-110 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Discography Master Albums */}
      <div className="space-y-4">
        <h2 className="text-2xl font-serif font-bold text-white border-b border-white/10 pb-3">
          Master Discography
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {artist.albums.map((album) => (
            <div 
              key={album.id}
              onClick={() => onSelectAlbum(album.id)}
              className="glass-panel p-4 rounded-2xl border border-white/5 hover:border-[#C5A059]/40 transition-all cursor-pointer group"
            >
              <img src={album.coverUrl} alt={album.title} className="w-full aspect-square rounded-xl object-cover mb-3" />
              <h3 className="text-sm font-semibold text-white group-hover:text-[#C5A059] truncate">{album.title}</h3>
              <p className="text-xs text-[#8E96A3]">{album.releaseYear} · {album.genre}</p>
            </div>
          ))}
        </div>
      </div>

      {/* UK Venue Tour Dates */}
      {artist.tourDates && artist.tourDates.length > 0 && (
        <div className="glass-panel p-8 rounded-3xl border border-white/5 space-y-4">
          <div className="flex items-center space-x-2 text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest">
            <Ticket className="w-4 h-4" />
            <span>UK Venue Concert Appearances</span>
          </div>

          <div className="space-y-3">
            {artist.tourDates.map((tour, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-[#181B20] border border-white/5 flex items-center justify-between text-xs">
                <div>
                  <span className="font-mono-tech text-[#C5A059] text-[11px] font-bold block">{tour.date}</span>
                  <span className="font-semibold text-white text-sm">{tour.venue}</span>
                  <span className="text-[#8E96A3] block">{tour.city}, United Kingdom</span>
                </div>
                <button className="px-4 py-2 rounded-xl bg-[#20242B] border border-white/10 hover:border-[#C5A059] text-xs font-semibold text-white transition-all">
                  Box Office
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
