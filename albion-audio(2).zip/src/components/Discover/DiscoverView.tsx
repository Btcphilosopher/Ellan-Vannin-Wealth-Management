import React, { useState } from 'react';
import { Play, Sparkles, BookOpen, Compass, ArrowRight, Disc, ShieldCheck, Heart, Plus } from 'lucide-react';
import { Album, Artist, EditorialFeature, ListeningJourney, Track } from '../../types';

interface DiscoverViewProps {
  onPlayTrack: (track: Track) => void;
  onPlayAlbum: (album: Album) => void;
  onSelectAlbum: (albumId: string) => void;
  onSelectArtist: (artistId: string) => void;
  onSelectEditorial: (feature: EditorialFeature) => void;
  albums: Album[];
  artists: Artist[];
  editorialFeatures: EditorialFeature[];
  listeningJourneys: ListeningJourney[];
}

export const DiscoverView: React.FC<DiscoverViewProps> = ({
  onPlayTrack,
  onPlayAlbum,
  onSelectAlbum,
  onSelectArtist,
  onSelectEditorial,
  albums,
  artists,
  editorialFeatures,
  listeningJourneys
}) => {
  const [selectedRegion, setSelectedRegion] = useState<string>('ALL');

  const featuredEditorial = editorialFeatures[0];

  return (
    <div className="space-y-12 pb-24">
      {/* Editorial Monocle Hero Banner */}
      {featuredEditorial && (
        <section className="relative rounded-2xl overflow-hidden border border-[#1F1F1F] bg-[#0D0D0D] shadow-2xl group">
          <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[420px]">
            {/* Left Content */}
            <div className="lg:col-span-7 p-8 lg:p-12 flex flex-col justify-between space-y-6 z-10 bg-gradient-to-r from-[#0D0D0D] via-[#0D0D0D]/95 to-transparent">
              <div className="space-y-3">
                <div className="flex items-center space-x-3 text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest">
                  <span className="px-2.5 py-1 rounded bg-[#C5A059]/10 border border-[#C5A059]/30 font-semibold">
                    {featuredEditorial.category}
                  </span>
                  <span>{featuredEditorial.date}</span>
                  <span>·</span>
                  <span>{featuredEditorial.readTime}</span>
                </div>

                <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-[#F5F5F0] leading-tight">
                  {featuredEditorial.title}
                </h1>

                <p className="text-sm sm:text-base text-[#888888] font-sans leading-relaxed max-w-xl">
                  {featuredEditorial.summary}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => onSelectEditorial(featuredEditorial)}
                  className="px-6 py-3 rounded-full bg-[#E0E0E0] hover:bg-white text-[#0A0A0A] text-xs font-bold uppercase tracking-wider flex items-center space-x-2 shadow-lg hover:scale-105 transition-all"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Read Editorial Essay</span>
                </button>

                {featuredEditorial.featuredAlbumId && (
                  <button
                    onClick={() => onSelectAlbum(featuredEditorial.featuredAlbumId!)}
                    className="px-6 py-3 rounded-full bg-[#1A1A1A] hover:bg-[#222222] text-xs font-semibold text-[#E0E0E0] border border-[#333333] flex items-center space-x-2 transition-all"
                  >
                    <Disc className="w-4 h-4 text-[#C5A059]" />
                    <span>View Featured Master Album</span>
                  </button>
                )}
              </div>
            </div>

            {/* Right Hero Image */}
            <div className="lg:col-span-5 relative h-64 lg:h-auto overflow-hidden">
              <img 
                src={featuredEditorial.heroUrl} 
                alt={featuredEditorial.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 filter brightness-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-transparent to-transparent lg:hidden" />
            </div>
          </div>
        </section>
      )}

      {/* Regional British Sound Showcases Filter */}
      <section className="space-y-6">
        <div className="flex items-center justify-between border-b border-[#1F1F1F] pb-4">
          <div>
            <span className="text-[10px] font-mono-tech text-[#C5A059] uppercase tracking-widest block mb-1">
              Geographic Archive
            </span>
            <h2 className="text-2xl font-serif font-bold text-[#F5F5F0]">
              Regional Music Heritage
            </h2>
          </div>

          <div className="flex items-center space-x-2 text-xs">
            {['ALL', 'BRISTOL', 'SOUTH LONDON', 'MANCHESTER', 'HIGHLANDS'].map((reg) => (
              <button
                key={reg}
                onClick={() => setSelectedRegion(reg)}
                className={`px-3 py-1.5 rounded-lg border transition-all text-xs ${
                  selectedRegion === reg
                    ? 'bg-[#C5A059]/20 border-[#C5A059] text-[#C5A059] font-medium'
                    : 'bg-[#141414] border-[#1F1F1F] text-[#888888] hover:text-white'
                }`}
              >
                {reg}
              </button>
            ))}
          </div>
        </div>

        {/* Master Albums Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {albums.map((album) => (
            <div 
              key={album.id}
              className="group bg-[#141414] rounded-xl p-4 border border-[#1F1F1F] hover:border-[#333333] transition-all hover:-translate-y-1 shadow-lg flex flex-col justify-between"
            >
              <div className="relative aspect-square rounded-lg overflow-hidden mb-3 cursor-pointer" onClick={() => onSelectAlbum(album.id)}>
                <img 
                  src={album.coverUrl} 
                  alt={album.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onPlayAlbum(album);
                  }}
                  className="absolute bottom-3 right-3 w-11 h-11 rounded-full bg-[#E0E0E0] text-[#0A0A0A] flex items-center justify-center opacity-0 group-hover:opacity-100 shadow-xl hover:scale-110 transition-all"
                  title="Play Master Album"
                >
                  <Play className="w-5 h-5 fill-current ml-0.5" />
                </button>
                <div className="absolute top-3 left-3 px-2 py-0.5 rounded bg-black/70 backdrop-blur-md border border-[#1F1F1F] text-[10px] font-mono-tech text-[#C5A059]">
                  {album.genre}
                </div>
              </div>

              <div>
                <h3 
                  onClick={() => onSelectAlbum(album.id)}
                  className="text-sm font-semibold text-[#E0E0E0] truncate hover:text-[#C5A059] cursor-pointer transition-colors"
                >
                  {album.title}
                </h3>
                <p 
                  onClick={() => onSelectArtist(album.artistId)}
                  className="text-xs text-[#888888] truncate hover:underline cursor-pointer"
                >
                  {album.artist}
                </p>
                <div className="flex items-center justify-between text-[11px] text-[#666666] mt-3 pt-3 border-t border-[#1F1F1F]">
                  <span>{album.releaseYear}</span>
                  <span className="font-mono-tech text-[10px] text-[#C5A059]">24-BIT LOSSLESS</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Curated Listening Journeys */}
      <section className="space-y-6">
        <div className="flex items-center justify-between border-b border-[#1F1F1F] pb-4">
          <div>
            <span className="text-[10px] font-mono-tech text-[#C5A059] uppercase tracking-widest block mb-1">
              Atmospheric Journeys
            </span>
            <h2 className="text-2xl font-serif font-bold text-[#F5F5F0]">
              Curated Listening Journeys
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {listeningJourneys.map((journey) => (
            <div 
              key={journey.id}
              className="bg-[#141414] rounded-xl p-5 border border-[#1F1F1F] hover:border-[#333333] transition-all space-y-4 group cursor-pointer"
              onClick={() => {
                if (journey.tracks[0]) onPlayTrack(journey.tracks[0]);
              }}
            >
              <div className="relative aspect-video rounded-lg overflow-hidden">
                <img 
                  src={journey.coverUrl} 
                  alt={journey.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-transparent to-transparent opacity-80" />
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                  <span className="text-[10px] font-mono-tech text-[#C5A059] uppercase bg-black/70 px-2 py-0.5 rounded border border-[#1F1F1F]">
                    {journey.readTime}
                  </span>
                  <button className="w-9 h-9 rounded-full bg-[#E0E0E0] text-[#0A0A0A] flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                    <Play className="w-4 h-4 fill-current ml-0.5" />
                  </button>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-serif font-bold text-[#F5F5F0] group-hover:text-[#C5A059] transition-colors">
                  {journey.title}
                </h3>
                <p className="text-xs text-[#C5A059] font-medium mb-1">{journey.subtitle}</p>
                <p className="text-xs text-[#888888] line-clamp-2 leading-relaxed">{journey.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Artists Showcase */}
      <section className="space-y-6">
        <div className="flex items-center justify-between border-b border-[#1F1F1F] pb-4">
          <div>
            <span className="text-[10px] font-mono-tech text-[#C5A059] uppercase tracking-widest block mb-1">
              Iconic Figures
            </span>
            <h2 className="text-2xl font-serif font-bold text-[#F5F5F0]">
              Pioneering British Artists
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {artists.map((artist) => (
            <div 
              key={artist.id}
              onClick={() => onSelectArtist(artist.id)}
              className="bg-[#141414] p-5 rounded-xl border border-[#1F1F1F] hover:border-[#333333] transition-all group cursor-pointer flex items-center space-x-4"
            >
              <img 
                src={artist.avatarUrl} 
                alt={artist.name}
                referrerPolicy="no-referrer"
                className="w-16 h-16 rounded-full object-cover border border-[#C5A059]/30 group-hover:scale-105 transition-transform"
              />
              <div className="truncate">
                <h3 className="text-sm font-semibold text-[#E0E0E0] group-hover:text-[#C5A059] transition-colors truncate">
                  {artist.name}
                </h3>
                <p className="text-xs text-[#888888] truncate">{artist.origin}</p>
                <p className="text-[10px] font-mono-tech text-[#C5A059] mt-1">
                  {(artist.monthlyListeners / 1000000).toFixed(1)}M Monthly Listeners
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
