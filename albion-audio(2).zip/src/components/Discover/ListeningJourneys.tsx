import React, { useState } from 'react';
import { Sparkles, Play, CloudRain, Sun, Moon, Wind, Compass, RefreshCw } from 'lucide-react';
import { ListeningJourney, Track } from '../../types';

interface ListeningJourneysProps {
  journeys: ListeningJourney[];
  onPlayTrack: (track: Track) => void;
}

export const ListeningJourneys: React.FC<ListeningJourneysProps> = ({
  journeys,
  onPlayTrack
}) => {
  const [userMood, setUserMood] = useState('Reflective');
  const [userWeather, setUserWeather] = useState('Misty Rain');
  const [userLocation, setUserLocation] = useState('London');
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiCustomJourney, setAiCustomJourney] = useState<{
    title: string;
    subtitle: string;
    description: string;
    curatorNote: string;
  } | null>(null);

  const handleGenerateCustomJourney = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/editorial/curate-journey', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mood: userMood,
          weather: userWeather,
          location: userLocation
        })
      });
      const data = await res.json();
      setAiCustomJourney(data);
    } catch (err) {
      console.error('Failed to generate journey:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-10 pb-24">
      {/* Header */}
      <div className="border-b border-white/10 pb-6">
        <span className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest block mb-1">
          Algorithmic & Human Curation
        </span>
        <h1 className="text-3xl md:text-4xl font-serif font-bold text-[#F7F5F0]">
          Curated British Listening Journeys
        </h1>
        <p className="text-sm text-[#8E96A3] max-w-2xl mt-2">
          Designed for specific weather conditions, geographic atmospheres, and temporal moods.
        </p>
      </div>

      {/* AI Journey Generator Box */}
      <div className="glass-panel p-6 rounded-3xl border border-[#C5A059]/30 space-y-6">
        <div className="flex items-center space-x-3 text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest">
          <Sparkles className="w-4 h-4" />
          <span>Gemini AI Atmospheric Curator Engine</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs text-[#8E96A3] mb-1.5 font-mono-tech">Desired Mood</label>
            <select
              value={userMood}
              onChange={(e) => setUserMood(e.target.value)}
              className="w-full bg-[#181B20] border border-white/10 text-xs text-white rounded-xl p-2.5 focus:border-[#C5A059] outline-none"
            >
              <option value="Reflective">Reflective & Solitary</option>
              <option value="Nocturnal Energy">Nocturnal City Energy</option>
              <option value="Peaceful Solitude">Peaceful Highland Solitude</option>
              <option value="Warm Nostalgia">Warm Vinyl Nostalgia</option>
            </select>
          </div>

          <div>
            <label className="block text-xs text-[#8E96A3] mb-1.5 font-mono-tech">Weather Condition</label>
            <select
              value={userWeather}
              onChange={(e) => setUserWeather(e.target.value)}
              className="w-full bg-[#181B20] border border-white/10 text-xs text-white rounded-xl p-2.5 focus:border-[#C5A059] outline-none"
            >
              <option value="Misty Rain">Misty Rain & Fog</option>
              <option value="Overcast Grey">Overcast Autumn Sky</option>
              <option value="Clear Midnight">Clear Midnight Frost</option>
              <option value="Golden Hour">Golden Sussex Hour</option>
            </select>
          </div>

          <div>
            <label className="block text-xs text-[#8E96A3] mb-1.5 font-mono-tech">Location Setting</label>
            <input
              type="text"
              value={userLocation}
              onChange={(e) => setUserLocation(e.target.value)}
              placeholder="e.g. Edinburgh, Bristol, Manchester"
              className="w-full bg-[#181B20] border border-white/10 text-xs text-white rounded-xl p-2.5 focus:border-[#C5A059] outline-none"
            />
          </div>
        </div>

        <button
          onClick={handleGenerateCustomJourney}
          disabled={isGenerating}
          className="px-6 py-3 rounded-xl bg-[#C5A059] hover:bg-[#D4AF66] text-[#111317] text-xs font-semibold uppercase tracking-wider flex items-center space-x-2 transition-all disabled:opacity-50"
        >
          {isGenerating ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4" />
          )}
          <span>{isGenerating ? 'Curating Acoustic Palette...' : 'Curate Custom Journey'}</span>
        </button>

        {/* Custom AI Journey Result */}
        {aiCustomJourney && (
          <div className="p-6 rounded-2xl bg-[#181B20] border border-[#C5A059]/40 space-y-3 animate-in fade-in duration-300">
            <span className="text-[10px] font-mono-tech text-[#C5A059] uppercase">Custom Journey Generated</span>
            <h3 className="text-xl font-serif font-bold text-white">{aiCustomJourney.title}</h3>
            <p className="text-xs text-[#C5A059] font-medium">{aiCustomJourney.subtitle}</p>
            <p className="text-xs text-[#8E96A3] leading-relaxed">{aiCustomJourney.description}</p>
            <p className="text-xs italic font-serif text-[#C5A059]/90 border-l-2 border-[#C5A059] pl-3 py-1">
              "{aiCustomJourney.curatorNote}"
            </p>
          </div>
        )}
      </div>

      {/* Flagship Curated Journeys List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {journeys.map((j) => (
          <div 
            key={j.id}
            className="glass-panel p-6 rounded-3xl border border-white/5 hover:border-[#C5A059]/40 transition-all space-y-5 group"
          >
            <div className="relative aspect-video rounded-2xl overflow-hidden">
              <img 
                src={j.coverUrl} 
                alt={j.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-90"
              />
              <div className="absolute top-3 left-3 px-2.5 py-1 rounded bg-black/60 backdrop-blur-md text-[10px] font-mono-tech text-[#C5A059] border border-white/10">
                {j.theme}
              </div>
            </div>

            <div>
              <span className="text-[10px] font-mono-tech text-[#8E96A3] uppercase">{j.readTime} · Curator: {j.curator}</span>
              <h2 className="text-2xl font-serif font-bold text-[#F7F5F0] group-hover:text-[#C5A059] transition-colors mt-1">
                {j.title}
              </h2>
              <p className="text-xs text-[#C5A059] font-medium mb-2">{j.subtitle}</p>
              <p className="text-xs text-[#8E96A3] leading-relaxed">{j.description}</p>
            </div>

            {/* Tracks List preview */}
            <div className="space-y-2 pt-4 border-t border-white/5">
              <span className="text-[10px] font-mono-tech text-[#8E96A3] uppercase">Included Master Tracks</span>
              {j.tracks.map((track, idx) => (
                <div 
                  key={track.id + idx}
                  onClick={() => onPlayTrack(track)}
                  className="p-2.5 rounded-xl bg-[#181B20] hover:bg-[#20242B] border border-white/5 flex items-center justify-between text-xs cursor-pointer group/track transition-all"
                >
                  <div className="flex items-center space-x-3 truncate">
                    <Play className="w-3.5 h-3.5 text-[#C5A059] shrink-0 opacity-80 group-hover/track:scale-110" />
                    <span className="font-semibold text-white truncate">{track.title}</span>
                    <span className="text-[#8E96A3] text-[11px] truncate">{track.artist}</span>
                  </div>
                  <span className="text-[10px] font-mono-tech text-[#C5A059]">{track.audioQuality.split(' ')[0]}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
