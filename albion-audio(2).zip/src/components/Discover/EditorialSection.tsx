import React, { useState } from 'react';
import { BookOpen, Sparkles, Disc, ArrowLeft, Clock, User, Share2 } from 'lucide-react';
import { EditorialFeature } from '../../types';

interface EditorialSectionProps {
  features: EditorialFeature[];
  onSelectAlbum: (albumId: string) => void;
  selectedFeature?: EditorialFeature;
  onClearSelectedFeature?: () => void;
}

export const EditorialSection: React.FC<EditorialSectionProps> = ({
  features,
  onSelectAlbum,
  selectedFeature,
  onClearSelectedFeature
}) => {
  const [activeArticle, setActiveArticle] = useState<EditorialFeature | null>(selectedFeature || null);

  const articleToRender = activeArticle || selectedFeature;

  if (articleToRender) {
    return (
      <div className="max-w-4xl mx-auto space-y-8 pb-24 animate-in fade-in duration-300">
        <button
          onClick={() => {
            setActiveArticle(null);
            if (onClearSelectedFeature) onClearSelectedFeature();
          }}
          className="flex items-center space-x-2 text-xs text-[#C5A059] hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Monocle Archives</span>
        </button>

        {/* Article Header */}
        <div className="space-y-4">
          <div className="flex items-center space-x-3 text-xs font-mono-tech text-[#C5A059]">
            <span className="px-2.5 py-1 rounded bg-[#C5A059]/10 border border-[#C5A059]/30 uppercase">
              {articleToRender.category}
            </span>
            <span>{articleToRender.date}</span>
            <span>·</span>
            <span>{articleToRender.readTime}</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-serif font-bold text-[#F7F5F0] leading-tight">
            {articleToRender.title}
          </h1>

          <p className="text-xl font-serif italic text-[#C5A059]">
            "{articleToRender.subtitle}"
          </p>

          <div className="flex items-center justify-between pt-4 border-t border-b border-white/10 text-xs text-[#8E96A3]">
            <div className="flex items-center space-x-2">
              <User className="w-4 h-4 text-[#C5A059]" />
              <span>{articleToRender.author}</span>
            </div>
            <button className="flex items-center space-x-1 hover:text-white">
              <Share2 className="w-4 h-4" />
              <span>Share Article</span>
            </button>
          </div>
        </div>

        {/* Hero Image */}
        <div className="relative rounded-2xl overflow-hidden aspect-video border border-white/10">
          <img 
            src={articleToRender.heroUrl} 
            alt={articleToRender.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Article Body */}
        <div className="prose prose-invert prose-lg max-w-none space-y-6 text-[#F7F5F0]/90 font-serif leading-relaxed text-lg">
          {articleToRender.content.map((paragraph, idx) => (
            <p key={idx} className="first-letter:text-5xl first-letter:font-bold first-letter:text-[#C5A059] first-letter:mr-2 first-letter:float-left">
              {paragraph}
            </p>
          ))}
        </div>

        {/* Featured Album Footer Link */}
        {articleToRender.featuredAlbumId && (
          <div className="p-6 rounded-2xl bg-[#181B20] border border-[#C5A059]/30 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Disc className="w-8 h-8 text-[#C5A059]" />
              <div>
                <h4 className="text-sm font-semibold text-[#F7F5F0]">Listen to Master Album Reference</h4>
                <p className="text-xs text-[#8E96A3]">Audition the album discussed in this essay in 24-bit Lossless</p>
              </div>
            </div>
            <button
              onClick={() => onSelectAlbum(articleToRender.featuredAlbumId!)}
              className="px-4 py-2 rounded-xl bg-[#C5A059] text-[#111317] text-xs font-semibold hover:bg-[#D4AF66] transition-all"
            >
              Open Album
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-24">
      {/* Header */}
      <div className="border-b border-white/10 pb-6">
        <span className="text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest block mb-1">
          Monocle & London Design Museum Archive
        </span>
        <h1 className="text-3xl md:text-4xl font-serif font-bold text-[#F7F5F0]">
          British Music Essays & Cultural Critiques
        </h1>
        <p className="text-sm text-[#8E96A3] max-w-2xl mt-2">
          In-depth architectural analysis of iconic British soundscapes, studio acoustics, and cultural movements.
        </p>
      </div>

      {/* Grid of Articles */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {features.map((feature) => (
          <div 
            key={feature.id}
            onClick={() => setActiveArticle(feature)}
            className="glass-panel rounded-2xl overflow-hidden border border-white/5 hover:border-[#C5A059]/40 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="relative aspect-video overflow-hidden">
              <img 
                src={feature.heroUrl} 
                alt={feature.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-90"
              />
              <div className="absolute top-3 left-3 px-2.5 py-1 rounded bg-black/60 backdrop-blur-md text-[10px] font-mono-tech text-[#C5A059] uppercase border border-white/10">
                {feature.category}
              </div>
            </div>

            <div className="p-6 space-y-3 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono-tech text-[#8E96A3]">{feature.date} · {feature.readTime}</span>
                <h2 className="text-xl font-serif font-bold text-[#F7F5F0] group-hover:text-[#C5A059] transition-colors mt-1">
                  {feature.title}
                </h2>
                <p className="text-xs text-[#8E96A3] line-clamp-3 mt-2 leading-relaxed">
                  {feature.summary}
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs text-[#C5A059] font-semibold">
                <span>Read Full Essay</span>
                <BookOpen className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
