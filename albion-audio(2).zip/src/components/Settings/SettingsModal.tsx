import React, { useState } from 'react';
import { X, SlidersHorizontal, ShieldCheck, Radio, Check, RefreshCw } from 'lucide-react';
import { AudioQuality, EqualizerPreset } from '../../types';
import { EQUALIZER_PRESETS } from '../../data/mockCatalog';
import { audioEngine } from '../../lib/audioEngine';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  audioQuality: AudioQuality;
  setAudioQuality: (quality: AudioQuality) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  audioQuality,
  setAudioQuality
}) => {
  const [selectedPresetId, setSelectedPresetId] = useState('abbey-road');
  const [eqBands, setEqBands] = useState<number[]>([2.5, 1.8, 1.0, 0.5, 1.2, 2.0, 1.5, 1.0, 0.5, -0.5]);

  if (!isOpen) return null;

  const bandFrequencies = ['32Hz', '64Hz', '125Hz', '250Hz', '500Hz', '1kHz', '2kHz', '4kHz', '8kHz', '16kHz'];

  const handleSelectPreset = (preset: EqualizerPreset) => {
    setSelectedPresetId(preset.id);
    setEqBands([...preset.bands]);
    audioEngine.setEQPreset(preset.bands);
  };

  const handleBandChange = (index: number, val: number) => {
    const updated = [...eqBands];
    updated[index] = val;
    setEqBands(updated);
    audioEngine.setEQBand(index, val);
    setSelectedPresetId('custom');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl glass-panel rounded-3xl border border-white/10 p-6 md:p-8 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-[#C5A059]/15 border border-[#C5A059]/30 flex items-center justify-center text-[#C5A059]">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-serif font-bold text-[#F7F5F0]">Audiophile Engine & Equalizer</h3>
              <p className="text-xs text-[#8E96A3]">DSP Signal Processing & British Sound Curves</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-[#8E96A3] hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Master Resolution Selector */}
        <div className="space-y-3">
          <label className="block text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest">
            Stream Master Audio Quality
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              '16-bit / 44.1kHz (CD)',
              '24-bit / 96kHz (Lossless)',
              '24-bit / 192kHz (Master Studio)'
            ].map((qual) => {
              const isSelected = audioQuality === qual;
              return (
                <button
                  key={qual}
                  onClick={() => setAudioQuality(qual as AudioQuality)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    isSelected 
                      ? 'bg-[#C5A059]/20 border-[#C5A059] text-white' 
                      : 'bg-[#181B20] border-white/5 text-[#8E96A3] hover:text-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold">{qual.split(' ')[0]}</span>
                    {isSelected && <Check className="w-4 h-4 text-[#C5A059]" />}
                  </div>
                  <span className="text-[10px] font-mono-tech text-[#8E96A3] block mt-1">{qual}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* EQ Presets */}
        <div className="space-y-3">
          <label className="block text-xs font-mono-tech text-[#C5A059] uppercase tracking-widest">
            Equalizer Acoustic Curves
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {EQUALIZER_PRESETS.map((preset) => {
              const isSelected = selectedPresetId === preset.id;
              return (
                <button
                  key={preset.id}
                  onClick={() => handleSelectPreset(preset)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    isSelected 
                      ? 'bg-[#C5A059]/20 border-[#C5A059] text-white' 
                      : 'bg-[#181B20] border-white/5 text-[#8E96A3] hover:text-white'
                  }`}
                >
                  <span className="text-xs font-semibold block">{preset.name}</span>
                  <span className="text-[10px] text-[#8E96A3] line-clamp-1">{preset.description}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 10-Band EQ Sliders */}
        <div className="space-y-3 p-4 rounded-2xl bg-[#181B20] border border-white/5">
          <div className="flex items-center justify-between text-xs font-mono-tech text-[#8E96A3]">
            <span>10-Band Graphic DSP Equalizer</span>
            <span>-12dB to +12dB</span>
          </div>

          <div className="grid grid-cols-10 gap-2 pt-2">
            {bandFrequencies.map((freq, idx) => (
              <div key={freq} className="flex flex-col items-center space-y-2">
                <span className="text-[9px] font-mono-tech text-[#C5A059]">
                  {eqBands[idx] > 0 ? `+${eqBands[idx]}` : eqBands[idx]}
                </span>
                <input
                  type="range"
                  min={-12}
                  max={12}
                  step={0.5}
                  value={eqBands[idx] || 0}
                  onChange={(e) => handleBandChange(idx, Number(e.target.value))}
                  className="w-full h-24 bg-[#20242B] rounded-lg appearance-none cursor-pointer accent-[#C5A059] [writing-mode:vertical-lr] [direction:rtl]"
                />
                <span className="text-[9px] font-mono-tech text-[#8E96A3]">{freq}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-[#181B20] border border-white/5 text-xs text-[#8E96A3] flex items-center justify-between">
          <span>Equalizer settings are persisted in Web Audio API engine.</span>
          <button 
            onClick={() => handleSelectPreset(EQUALIZER_PRESETS[0])}
            className="text-[#C5A059] hover:underline text-xs flex items-center space-x-1"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset EQ</span>
          </button>
        </div>
      </div>
    </div>
  );
};
