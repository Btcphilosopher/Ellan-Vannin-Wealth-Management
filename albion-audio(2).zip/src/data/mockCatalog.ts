import { Album, Artist, EditorialFeature, EqualizerPreset, ListeningJourney, Playlist, Track } from '../types';

export const EQUALIZER_PRESETS: EqualizerPreset[] = [
  {
    id: 'flat',
    name: 'Flat Reference',
    description: 'Pure, uncolored audio for studio monitor transparency.',
    bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  },
  {
    id: 'abbey-road',
    name: 'Abbey Road Studio 2',
    description: 'Warm tube saturation, rich midrange, and silky highs inspired by REDD desks.',
    bands: [2.5, 1.8, 1.0, 0.5, 1.2, 2.0, 1.5, 1.0, 0.5, -0.5]
  },
  {
    id: 'bbc-broadcast',
    name: 'BBC Broadcast Master',
    description: 'Optimized for speech legibility, warm orchestral depth, and acoustic air.',
    bands: [1.0, 0.5, 0, -0.5, 0, 1.5, 2.2, 1.8, 1.0, 0]
  },
  {
    id: 'warm-analog',
    name: 'Warm Analog Tape',
    description: 'Smooth low-end roll-off with rich second-order harmonic warmth.',
    bands: [3.0, 2.5, 1.8, 1.0, 0.5, 0, -0.5, -1.0, -1.5, -2.5]
  },
  {
    id: 'bristol-bass',
    name: 'Bristol Sub-Acoustic',
    description: 'Deep 32Hz sub-frequency amplification for UK garage, trip-hop, and dubstep.',
    bands: [5.0, 4.0, 2.5, 1.0, 0, 0, 0.5, 1.0, 1.5, 1.0]
  }
];

export const MOCK_TRACKS: Track[] = [
  {
    id: 'tr-01',
    title: 'Fog Over the Avon Gorge',
    artist: 'Portishead Sound Collective',
    artistId: 'art-01',
    album: 'DUMMY: REVISITED (2030 RE-MASTER)',
    albumId: 'alb-01',
    coverUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    duration: 312,
    releaseYear: 1994,
    genre: 'Trip-Hop / Bristol Sound',
    bpm: 78,
    key: 'C Minor',
    audioQuality: '24-bit / 192kHz (Master Studio)',
    composer: 'Geoff Barrow, Beth Gibbons',
    producer: 'Portishead & Adrian Utley',
    studio: 'State of the Art Studio, Bristol',
    synthsType: 'ambient',
    essay: 'Recorded in a subterranean Bristol warehouse using vintage tape reels and Rhodes organ, this track defined the melancholic atmosphere of mid-90s Britain.',
    lyrics: [
      { time: 0, text: '[Instrumental Intro — Vinyl crackle & Fender Rhodes]' },
      { time: 14, text: 'The fog settles on the suspension bridge...' },
      { time: 28, text: 'No words remain in the quiet morning light' },
      { time: 42, text: 'Shadows drift across the limestone cliffs' },
      { time: 58, text: 'And the river carries everything down to the sea' },
      { time: 75, text: '[Turntable scratching & muted brass solo]' },
      { time: 110, text: 'Give me a reason to hold on to the night' },
      { time: 140, text: 'When the rain falls cold on St Nicholas Street' }
    ]
  },
  {
    id: 'tr-02',
    title: 'Archangel (South London Nights)',
    artist: 'Burial',
    artistId: 'art-02',
    album: 'UNTRUE (AUDIOPHILE EDITION)',
    albumId: 'alb-02',
    coverUrl: 'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?q=80&w=800&auto=format&fit=crop',
    duration: 238,
    releaseYear: 2007,
    genre: 'UK Garage / Ambient Dubstep',
    bpm: 134,
    key: 'F# Minor',
    audioQuality: '24-bit / 192kHz (Master Studio)',
    composer: 'William Bevan',
    producer: 'Burial',
    studio: 'Hyperdub Underground, South London',
    synthsType: 'synthwave',
    essay: 'Constructed entirely in Sound Forge without a sequencer grid, Burial captured the solitary beauty of night buses, rain-slicked tarmac, and distant London club echo.',
    lyrics: [
      { time: 0, text: '[Rain noise & distant tube train rumble]' },
      { time: 12, text: 'Holding you... loving you...' },
      { time: 25, text: 'I can’t take my eyes off you' },
      { time: 40, text: '[Shuffling vinyl percussion & pitch-shifted vocal]' },
      { time: 70, text: 'In the dark night, on the last 368 bus' },
      { time: 95, text: 'You was always there for me' }
    ]
  },
  {
    id: 'tr-03',
    title: 'Spitfire Overture (Op. 42)',
    artist: 'Royal Philharmonic Orchestra & Max Richter',
    artistId: 'art-03',
    album: 'ALBION SYMPHONIC SKIES',
    albumId: 'alb-03',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=800&auto=format&fit=crop',
    duration: 485,
    releaseYear: 2024,
    genre: 'Modern Classical',
    bpm: 92,
    key: 'D Major',
    audioQuality: '24-bit / 192kHz (Master Studio)',
    composer: 'Max Richter',
    producer: 'Max Richter & BBC Sound Labs',
    studio: 'Abbey Road Studio 1, London',
    synthsType: 'orchestral',
    essay: 'Recorded with a 90-piece orchestra at Abbey Road, combining analog Moog sub-oscillators with soaring 18th-century violin sections.',
    lyrics: [
      { time: 0, text: '[Movement I: Quiet strings & analog sub-bass entry]' },
      { time: 45, text: '[Movement II: Full brass fanfare over Sussex downs theme]' },
      { time: 180, text: '[Movement III: Piano solo with tape delay resonance]' }
    ]
  },
  {
    id: 'tr-04',
    title: 'Rumble in Bermondsey',
    artist: 'Ezra Collective',
    artistId: 'art-04',
    album: 'WHERE I’M MEANT TO BE (FLAC MASTER)',
    albumId: 'alb-04',
    coverUrl: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629?q=80&w=800&auto=format&fit=crop',
    duration: 295,
    releaseYear: 2023,
    genre: 'UK Jazz / Afrobeat',
    bpm: 118,
    key: 'G Minor',
    audioQuality: '24-bit / 96kHz (Lossless)',
    composer: 'Femi Koleoso, Joe Armon-Jones',
    producer: 'Femi Koleoso',
    studio: 'Chalk Farm Recording Rooms, London',
    synthsType: 'jazz',
    essay: 'Mercury Prize winning South London jazz ensemble merging West African rhythm, dub basslines, and virtuosic horn counterpoint.',
    lyrics: [
      { time: 0, text: '[Afrobeat drum break & upright bass groove]' },
      { time: 20, text: '[Tenor sax and trumpet unison riff]' },
      { time: 60, text: 'London city pulse... feel the energy' },
      { time: 120, text: '[Piano solo by Joe Armon-Jones]' }
    ]
  },
  {
    id: 'tr-05',
    title: 'Hebden Bridge Acoustic',
    artist: 'Laura Marling',
    artistId: 'art-05',
    album: 'SONG FOR OUR DAUGHTER (LIVE AT TRADES CLUB)',
    albumId: 'alb-05',
    coverUrl: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?q=80&w=800&auto=format&fit=crop',
    duration: 264,
    releaseYear: 2020,
    genre: 'British Folk / Acoustic',
    bpm: 104,
    key: 'A Major',
    audioQuality: '24-bit / 192kHz (Master Studio)',
    composer: 'Laura Marling',
    producer: 'Ethan Johns & Laura Marling',
    studio: 'Trades Club, Hebden Bridge, West Yorkshire',
    synthsType: 'folk',
    essay: 'Captured live in a historic Pennine mill town club, featuring pristine microphoning on Martin D-28 acoustic guitars and ribbon mic vocals.',
    lyrics: [
      { time: 0, text: '[Acoustic guitar fingerpicking & room ambient warmth]' },
      { time: 12, text: 'Lately I’ve been thinking about the hills' },
      { time: 28, text: 'How the canal winds down through the stone mill town' },
      { time: 45, text: 'Save your courage for the morning tide' },
      { time: 68, text: 'No one walks these moorland tracks alone' }
    ]
  },
  {
    id: 'tr-06',
    title: 'Neon Piccadilly',
    artist: 'Bicep',
    artistId: 'art-06',
    album: 'ISLES (DELUXE EXTENDED)',
    albumId: 'alb-06',
    coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=800&auto=format&fit=crop',
    duration: 382,
    releaseYear: 2021,
    genre: 'UK Electronic / Breakbeat',
    bpm: 126,
    key: 'Bb Minor',
    audioQuality: '24-bit / 96kHz (Lossless)',
    composer: 'Matt McBriar, Andy Ferguson',
    producer: 'Bicep',
    studio: 'Feel My Bicep HQ, Belfast & London',
    synthsType: 'synthwave',
    essay: 'A masterclass in analog synthesizer layering, featuring Prophet 6 pads, vocal chops, and emotive Northern Irish rave nostalgia.',
    lyrics: [
      { time: 0, text: '[Chopped vocal synth intro & analogue pulse]' },
      { time: 30, text: '[Syncopated breakbeat entry]' },
      { time: 90, text: '[Sub-bass swell & ethereal breakdown]' }
    ]
  },
  {
    id: 'tr-07',
    title: 'Hounds of Love (Orchestral Cut)',
    artist: 'Kate Bush',
    artistId: 'art-07',
    album: 'HOUNDS OF LOVE (STUDIO MASTER 2026)',
    albumId: 'alb-07',
    coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=800&auto=format&fit=crop',
    duration: 302,
    releaseYear: 1985,
    genre: 'Art Pop / Progressive',
    bpm: 138,
    key: 'G Major',
    audioQuality: '24-bit / 192kHz (Master Studio)',
    composer: 'Kate Bush',
    producer: 'Kate Bush',
    studio: 'Wickham Farm Studio, Kent',
    synthsType: 'piano',
    essay: 'Recorded on a Fairlight CMI digital synthesizer in a private Kent barn studio, defying 80s pop conventions with literary romanticism.',
    lyrics: [
      { time: 0, text: '"It’s in the trees, it’s coming!"' },
      { time: 10, text: 'It’s in the trees, it’s coming...' },
      { time: 24, text: 'When I was a child, running in the night' },
      { time: 42, text: 'Afraid of what was hiding in the dark' },
      { time: 60, text: 'Take my shoes off, and throw them in the lake!' }
    ]
  },
  {
    id: 'tr-08',
    title: 'Transmission (Live at Factory)',
    artist: 'Joy Division',
    artistId: 'art-08',
    album: 'UNKNOWN PLEASURES (45TH ANNIVERSARY)',
    albumId: 'alb-08',
    coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=800&auto=format&fit=crop',
    duration: 216,
    releaseYear: 1979,
    genre: 'Post-Punk / Manchester Industrial',
    bpm: 158,
    key: 'D Minor',
    audioQuality: '24-bit / 192kHz (Master Studio)',
    composer: 'Ian Curtis, Peter Hook, Bernard Sumner, Stephen Morris',
    producer: 'Martin Hannett',
    studio: 'Strawberry Studios, Stockport',
    synthsType: 'postpunk',
    essay: 'Martin Hannett used AMS digital delays and toilet echo chambers at 3 AM in Stockport to craft the razor-sharp sonic archetype of post-punk.',
    lyrics: [
      { time: 0, text: '[Peter Hook driving bassline & Stephen Morris snare]' },
      { time: 20, text: 'Listen to the silence, let it ring on...' },
      { time: 40, text: 'Eyes, cold eyes, looking at me...' },
      { time: 80, text: 'Dance, dance, dance, dance, dance to the radio!' }
    ]
  }
];

export const MOCK_ALBUMS: Album[] = [
  {
    id: 'alb-01',
    title: 'DUMMY: REVISITED (2030 RE-MASTER)',
    artist: 'Portishead Sound Collective',
    artistId: 'art-01',
    coverUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    releaseYear: 1994,
    genre: 'Trip-Hop / Bristol Sound',
    trackCount: 11,
    totalDuration: 2940,
    dominantColor: '#1A242B',
    essay: 'Dummy stands as one of the most singular achievements in British music history. Blending film noir cinematic grandeur, hip-hop turntablism, and heartbreaking vocal delivery, it created an entire genre out of West Country rain and vintage record sampling.',
    credits: {
      producer: 'Adrian Utley & Geoff Barrow',
      engineer: 'Dave McDonald',
      studio: 'State of the Art, Bristol & Moles Studio, Bath',
      label: 'Go! Beat / Albion Master'
    },
    tracks: [MOCK_TRACKS[0]]
  },
  {
    id: 'alb-02',
    title: 'UNTRUE (AUDIOPHILE EDITION)',
    artist: 'Burial',
    artistId: 'art-02',
    coverUrl: 'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?q=80&w=800&auto=format&fit=crop',
    releaseYear: 2007,
    genre: 'UK Garage / Ambient Dubstep',
    trackCount: 13,
    totalDuration: 3012,
    dominantColor: '#12161E',
    essay: 'Untrue captured the ghost of rave culture wandering through late-night London McDonald’s and nocturnal bus stops. It remains a watershed monument of 21st-century British electronic soundscapes.',
    credits: {
      producer: 'William Bevan (Burial)',
      engineer: 'Kode9 (Mastering)',
      studio: 'Hyperdub HQ, South London',
      label: 'Hyperdub / Albion Master Edition'
    },
    tracks: [MOCK_TRACKS[1]]
  },
  {
    id: 'alb-03',
    title: 'ALBION SYMPHONIC SKIES',
    artist: 'Royal Philharmonic Orchestra & Max Richter',
    artistId: 'art-03',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=800&auto=format&fit=crop',
    releaseYear: 2024,
    genre: 'Modern Classical',
    trackCount: 8,
    totalDuration: 3200,
    dominantColor: '#24201B',
    essay: 'A majestic meditation on British landscapes from the Scottish Highlands to the Sussex downs, blending 90-piece orchestral acoustic resonance with sub-harmonic electronic textures.',
    credits: {
      producer: 'Max Richter & Yulia Mahr',
      engineer: 'Geoff Foster',
      studio: 'Abbey Road Studio 1, London',
      label: 'Deutsche Grammophon / Albion'
    },
    tracks: [MOCK_TRACKS[2]]
  },
  {
    id: 'alb-04',
    title: 'WHERE I’M MEANT TO BE',
    artist: 'Ezra Collective',
    artistId: 'art-04',
    coverUrl: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629?q=80&w=800&auto=format&fit=crop',
    releaseYear: 2023,
    genre: 'UK Jazz / Afrobeat',
    trackCount: 14,
    totalDuration: 3420,
    dominantColor: '#2A1F18',
    essay: 'Winner of the 2023 Mercury Prize, this record embodies the joyous, multicultural, community-driven spirit of contemporary London jazz culture.',
    credits: {
      producer: 'Femi Koleoso',
      engineer: 'Dilip Harris',
      studio: 'Chalk Farm Rooms, London',
      label: 'Partisan Records'
    },
    tracks: [MOCK_TRACKS[3]]
  }
];

export const MOCK_ARTISTS: Artist[] = [
  {
    id: 'art-01',
    name: 'Portishead Sound Collective',
    avatarUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=400&auto=format&fit=crop',
    heroUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=1600&auto=format&fit=crop',
    genre: 'Trip-Hop / Bristol Sound',
    origin: 'Bristol, England',
    formedYear: 1991,
    monthlyListeners: 3420000,
    bio: 'Formed in Portishead near Bristol, Geoff Barrow and Beth Gibbons pioneered a dark, cinematic sound fusing hip-hop turntable techniques with orchestral film arrangements.',
    tourDates: [
      { date: '14 SEP 2026', venue: 'Royal Albert Hall', city: 'London', ticketUrl: '#' },
      { date: '18 SEP 2026', venue: 'Victoria Warehouse', city: 'Manchester', ticketUrl: '#' },
      { date: '22 SEP 2026', venue: 'Barrowland Ballroom', city: 'Glasgow', ticketUrl: '#' }
    ],
    albums: [MOCK_ALBUMS[0]],
    topTracks: [MOCK_TRACKS[0]]
  },
  {
    id: 'art-02',
    name: 'Burial',
    avatarUrl: 'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?q=80&w=400&auto=format&fit=crop',
    heroUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=1600&auto=format&fit=crop',
    genre: 'UK Garage / Ambient Dubstep',
    origin: 'South London, England',
    formedYear: 2005,
    monthlyListeners: 1850000,
    bio: 'Anonymously producing nocturnal sonic masterpieces from South London, William Bevan redefined electronic music in the late 2000s.',
    tourDates: [],
    albums: [MOCK_ALBUMS[1]],
    topTracks: [MOCK_TRACKS[1]]
  },
  {
    id: 'art-03',
    name: 'Royal Philharmonic & Max Richter',
    avatarUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=400&auto=format&fit=crop',
    heroUrl: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?q=80&w=1600&auto=format&fit=crop',
    genre: 'Modern Classical',
    origin: 'London, England',
    formedYear: 1946,
    monthlyListeners: 4200000,
    bio: 'One of the world’s most prestigious orchestral institutions, paired with post-minimalist composer Max Richter.',
    tourDates: [
      { date: '04 OCT 2026', venue: 'Barbican Centre', city: 'London', ticketUrl: '#' },
      { date: '10 OCT 2026', venue: 'Symphony Hall', city: 'Birmingham', ticketUrl: '#' }
    ],
    albums: [MOCK_ALBUMS[2]],
    topTracks: [MOCK_TRACKS[2]]
  }
];

export const EDITORIAL_FEATURES: EditorialFeature[] = [
  {
    id: 'ed-01',
    category: 'ARCHIVE',
    title: 'The Bristol Sound: From St Nicholas Market to Global Reverberation',
    subtitle: 'How a damp West Country port city birthed trip-hop, massive basslines and cinematic melancholy.',
    author: 'Edward Thornton · Senior Music Editor',
    date: 'AUGUST 2026',
    readTime: '8 MIN READ',
    heroUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1200&auto=format&fit=crop',
    summary: 'In the damp basement studios of Clifton and Montpelier during the early 1990s, artists discarded fast tempo dance formulas in favour of slowed-down breakbeats, reggae dub basslines, and 1960s film noir strings.',
    content: [
      'Bristol in 1991 was defined by its industrial maritime heritage and its vibrant counterculture. Sound systems like The Wild Bunch (who later became Massive Attack) brought dub, reggae, funk, and early hip-hop together at underground hall dances.',
      'When Geoff Barrow met Beth Gibbons while waiting for job interviews at a community centre, the foundation for Portishead was laid. Instead of using pristine digital synthesizers, they cut bespoke vinyl records, dragged them across dusty carpets, and recorded them back onto vintage tape reels.',
      'The result was Dummy — a masterpiece that sounded like it had been exhumed from a 1960s British film vault, yet felt acutely tuned to the isolation of the late 20th century.'
    ],
    featuredAlbumId: 'alb-01'
  },
  {
    id: 'ed-02',
    category: 'ESSAY',
    title: 'Nocturnal Geography: Burial and the Architecture of London at 3 AM',
    subtitle: 'Mapping William Bevan’s haunting soundscapes against night buses and rain-slicked asphalt.',
    author: 'Helena Vance · Architecture & Sound Critic',
    date: 'JULY 2026',
    readTime: '6 MIN READ',
    heroUrl: 'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?q=80&w=1200&auto=format&fit=crop',
    summary: 'Listen closely to Untrue and you hear the sonic ecology of South London: rain falling on tarmac, tube train brakes squealing in underground tunnels, lighter clicks, and distant laughter filtered through brick walls.',
    content: [
      'Unlike the pristine studio environments favoured by modern electronic producers, Burial constructed his audio montages in Sound Forge without grid-snapping. Beats shuffle with human imperfection, like someone tapping a wet boot against a kerbstone.',
      'His music is an archivist’s portrait of a city in transit — where lonely commuters find solace in glowing smartphone screens and distant bass frequencies drifting out of basement clubs.'
    ],
    featuredAlbumId: 'alb-02'
  }
];

export const LISTENING_JOURNEYS: ListeningJourney[] = [
  {
    id: 'jrn-01',
    title: 'Misty Rain over Dartmoor',
    subtitle: 'Acoustic Folk, Ambient Strings & Warm Tape Delays',
    description: 'Designed for quiet morning walks, wet granite tors, and slow coffee brewing.',
    coverUrl: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?q=80&w=800&auto=format&fit=crop',
    theme: 'Warm Oak & Slate',
    curator: 'Albion Editorial Desk',
    readTime: '45 MIN PLAYTIME',
    tracks: [MOCK_TRACKS[4], MOCK_TRACKS[0], MOCK_TRACKS[2]]
  },
  {
    id: 'jrn-02',
    title: 'Late Night South London Jazz',
    subtitle: 'Improvised Brass, Upright Bass & Warm Rhodes Organ',
    description: 'Evoking the warm, smoky acoustics of Bermondsey vaults and Peckham rooftop sessions.',
    coverUrl: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629?q=80&w=800&auto=format&fit=crop',
    theme: 'Oxford Blue & Bronze',
    curator: 'Femi Koleoso',
    readTime: '62 MIN PLAYTIME',
    tracks: [MOCK_TRACKS[3], MOCK_TRACKS[1], MOCK_TRACKS[5]]
  },
  {
    id: 'jrn-03',
    title: 'Industrial Echoes & Post-Punk Reverb',
    subtitle: 'Manchester Analog Bass, Cold Synthlines & Studio Echo',
    description: 'From Stockport Strawberry Studios to Sheffield steel mill practice rooms.',
    coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=800&auto=format&fit=crop',
    theme: 'Deep Graphite',
    curator: 'Peter Hook Archive',
    readTime: '50 MIN PLAYTIME',
    tracks: [MOCK_TRACKS[7], MOCK_TRACKS[6], MOCK_TRACKS[1]]
  }
];

export const USER_PLAYLISTS: Playlist[] = [
  {
    id: 'pl-01',
    title: 'Audiophile Master Reference',
    description: 'Pristine 24-bit 192kHz recordings for testing speaker imaging and dynamic range.',
    coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=800&auto=format&fit=crop',
    tracks: [MOCK_TRACKS[2], MOCK_TRACKS[0], MOCK_TRACKS[4]],
    createdAt: '2026-08-01',
    isPinned: true
  },
  {
    id: 'pl-02',
    title: 'British Electronic Essentials',
    description: 'Sub-bass warmth, trip-hop breakbeats, and synth nostalgia.',
    coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=800&auto=format&fit=crop',
    tracks: [MOCK_TRACKS[1], MOCK_TRACKS[5], MOCK_TRACKS[0]],
    createdAt: '2026-08-05',
    isPinned: true
  }
];
