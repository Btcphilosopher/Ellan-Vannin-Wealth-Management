/**
 * Albion Audio — Britain's Premier Music Streaming Platform
 */

import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { FloatingPlayer } from './components/Player/FloatingPlayer';
import { FullScreenPlayer } from './components/Player/FullScreenPlayer';
import { AudioDeviceSelectorModal } from './components/Player/AudioDeviceSelectorModal';
import { DiscoverView } from './components/Discover/DiscoverView';
import { EditorialSection } from './components/Discover/EditorialSection';
import { ListeningJourneys } from './components/Discover/ListeningJourneys';
import { LibraryView } from './components/Library/LibraryView';
import { SearchModal } from './components/Search/SearchModal';
import { ArtistView } from './components/Artist/ArtistView';
import { AlbumView } from './components/Album/AlbumView';
import { SettingsModal } from './components/Settings/SettingsModal';

import { 
  MOCK_ALBUMS, 
  MOCK_ARTISTS, 
  MOCK_TRACKS, 
  EDITORIAL_FEATURES, 
  LISTENING_JOURNEYS, 
  USER_PLAYLISTS 
} from './data/mockCatalog';
import { 
  ActiveView, 
  Album, 
  Artist, 
  AudioDevice, 
  AudioQuality, 
  EditorialFeature, 
  Playlist, 
  Track 
} from './types';
import { audioEngine } from './lib/audioEngine';

const AUDIO_DEVICES: AudioDevice[] = [
  {
    id: 'dev-1',
    name: 'Naim Mu-so 2 Special Edition',
    brand: 'Naim Audio (Salisbury)',
    type: 'Speaker',
    connection: 'Wi-Fi Hi-Res',
    status: 'Connected',
    maxResolution: '24-bit / 192kHz'
  },
  {
    id: 'dev-2',
    name: 'Bang & Olufsen Beolab 90',
    brand: 'Bang & Olufsen',
    type: 'Speaker',
    connection: 'Wi-Fi Hi-Res',
    status: 'Available',
    maxResolution: '24-bit / 192kHz'
  },
  {
    id: 'dev-3',
    name: 'Bowers & Wilkins Nautilus',
    brand: 'Bowers & Wilkins (Worthing)',
    type: 'Speaker',
    connection: 'USB-DAC',
    status: 'Available',
    maxResolution: '24-bit / 192kHz'
  },
  {
    id: 'dev-4',
    name: 'Linn Klimax DSM Network Player',
    brand: 'Linn (Glasgow)',
    type: 'Streamer',
    connection: 'RCA Line Out',
    status: 'Available',
    maxResolution: '24-bit / 192kHz'
  }
];

export default function App() {
  const [activeView, setActiveView] = useState<ActiveView>({ type: 'DISCOVER' });
  const [currentTrack, setCurrentTrack] = useState<Track | null>(MOCK_TRACKS[0]);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(MOCK_TRACKS[0].duration);
  const [volume, setVolume] = useState<number>(0.8);
  const [audioQuality, setAudioQuality] = useState<AudioQuality>('24-bit / 192kHz (Master Studio)');
  const [currentDevice, setCurrentDevice] = useState<AudioDevice>(AUDIO_DEVICES[0]);

  // Queue & History state
  const [queue, setQueue] = useState<Track[]>(MOCK_TRACKS);
  const [history, setHistory] = useState<Track[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>(USER_PLAYLISTS);

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isDeviceModalOpen, setIsDeviceModalOpen] = useState(false);
  const [isFullScreenPlayerOpen, setIsFullScreenPlayerOpen] = useState(false);
  const [showQueue, setShowQueue] = useState(false);
  const [showLyrics, setShowLyrics] = useState(false);
  const [selectedEditorial, setSelectedEditorial] = useState<EditorialFeature | undefined>(undefined);

  // Timer reference for current time playback progress
  const timerRef = useRef<number | null>(null);

  // Sync Audio Engine Volume
  useEffect(() => {
    audioEngine.setVolume(volume);
  }, [volume]);

  // Playback Timer
  useEffect(() => {
    if (isPlaying && currentTrack) {
      audioEngine.start(currentTrack.synthsType || 'ambient', currentTrack.bpm || 100);

      timerRef.current = window.setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= duration) {
            handleNextTrack();
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    } else {
      audioEngine.pause();
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isPlaying, currentTrack]);

  const handlePlayTrack = (track: Track) => {
    setCurrentTrack(track);
    setCurrentTime(0);
    setDuration(track.duration);
    setIsPlaying(true);
    setHistory((prev) => [track, ...prev.filter(t => t.id !== track.id)]);
  };

  const handlePlayAlbum = (album: Album) => {
    if (album.tracks.length > 0) {
      setQueue(album.tracks);
      handlePlayTrack(album.tracks[0]);
    }
  };

  const togglePlay = () => {
    if (!currentTrack && MOCK_TRACKS[0]) {
      handlePlayTrack(MOCK_TRACKS[0]);
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  const handleNextTrack = () => {
    if (!currentTrack) return;
    const currentIndex = queue.findIndex(t => t.id === currentTrack.id);
    if (currentIndex >= 0 && currentIndex < queue.length - 1) {
      handlePlayTrack(queue[currentIndex + 1]);
    } else if (queue.length > 0) {
      handlePlayTrack(queue[0]);
    }
  };

  const handlePrevTrack = () => {
    if (!currentTrack) return;
    const currentIndex = queue.findIndex(t => t.id === currentTrack.id);
    if (currentIndex > 0) {
      handlePlayTrack(queue[currentIndex - 1]);
    } else if (queue.length > 0) {
      handlePlayTrack(queue[queue.length - 1]);
    }
  };

  const handleSeek = (time: number) => {
    setCurrentTime(time);
  };

  const handleCreatePlaylist = (title: string, description: string) => {
    const newPl: Playlist = {
      id: `pl-${Date.now()}`,
      title,
      description,
      coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=800&auto=format&fit=crop',
      tracks: currentTrack ? [currentTrack] : [],
      createdAt: new Date().toISOString().split('T')[0],
      isPinned: true
    };
    setPlaylists([newPl, ...playlists]);
  };

  const selectedAlbum = activeView.type === 'ALBUM' 
    ? MOCK_ALBUMS.find(a => a.id === (activeView as { albumId: string }).albumId) || MOCK_ALBUMS[0] 
    : null;

  const selectedArtist = activeView.type === 'ARTIST' 
    ? MOCK_ARTISTS.find(a => a.id === (activeView as { artistId: string }).artistId) || MOCK_ARTISTS[0] 
    : null;

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#E0E0E0] flex flex-col font-sans selection:bg-[#C5A059] selection:text-[#0A0A0A]">
      {/* Top Header */}
      <Header
        activeView={activeView}
        setActiveView={setActiveView}
        openSearch={() => setIsSearchOpen(true)}
        openSettings={() => setIsSettingsOpen(true)}
        openDeviceModal={() => setIsDeviceModalOpen(true)}
        currentDevice={currentDevice}
        audioQuality={audioQuality}
        isPlaying={isPlaying}
      />

      {/* Main Body Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          activeView={activeView}
          setActiveView={setActiveView}
          playlists={playlists}
          openSettings={() => setIsSettingsOpen(true)}
        />

        {/* Main Workspace View */}
        <main className="flex-1 h-[calc(100vh-4rem)] overflow-y-auto p-6 lg:p-10 scrollbar-thin">
          <div className="max-w-7xl mx-auto">
            {activeView.type === 'DISCOVER' && (
              <DiscoverView
                onPlayTrack={handlePlayTrack}
                onPlayAlbum={handlePlayAlbum}
                onSelectAlbum={(id) => setActiveView({ type: 'ALBUM', albumId: id })}
                onSelectArtist={(id) => setActiveView({ type: 'ARTIST', artistId: id })}
                onSelectEditorial={(feature) => {
                  setSelectedEditorial(feature);
                  setActiveView({ type: 'EDITORIAL' });
                }}
                albums={MOCK_ALBUMS}
                artists={MOCK_ARTISTS}
                editorialFeatures={EDITORIAL_FEATURES}
                listeningJourneys={LISTENING_JOURNEYS}
              />
            )}

            {activeView.type === 'EDITORIAL' && (
              <EditorialSection
                features={EDITORIAL_FEATURES}
                onSelectAlbum={(id) => setActiveView({ type: 'ALBUM', albumId: id })}
                selectedFeature={selectedEditorial}
                onClearSelectedFeature={() => setSelectedEditorial(undefined)}
              />
            )}

            {activeView.type === 'JOURNEYS' && (
              <ListeningJourneys
                journeys={LISTENING_JOURNEYS}
                onPlayTrack={handlePlayTrack}
              />
            )}

            {activeView.type === 'LIBRARY' && (
              <LibraryView
                filter={(activeView as { filter?: 'albums' | 'artists' | 'genres' | 'playlists' | 'history' | 'pinned' }).filter}
                albums={MOCK_ALBUMS}
                artists={MOCK_ARTISTS}
                tracks={MOCK_TRACKS}
                playlists={playlists}
                history={history}
                onPlayTrack={handlePlayTrack}
                onPlayAlbum={handlePlayAlbum}
                onSelectAlbum={(id) => setActiveView({ type: 'ALBUM', albumId: id })}
                onSelectArtist={(id) => setActiveView({ type: 'ARTIST', artistId: id })}
                onCreatePlaylist={handleCreatePlaylist}
              />
            )}

            {activeView.type === 'ALBUM' && selectedAlbum && (
              <AlbumView
                album={selectedAlbum}
                onBack={() => setActiveView({ type: 'DISCOVER' })}
                onPlayTrack={handlePlayTrack}
                onPlayAlbum={handlePlayAlbum}
                onSelectArtist={(id) => setActiveView({ type: 'ARTIST', artistId: id })}
              />
            )}

            {activeView.type === 'ARTIST' && selectedArtist && (
              <ArtistView
                artist={selectedArtist}
                onBack={() => setActiveView({ type: 'DISCOVER' })}
                onPlayTrack={handlePlayTrack}
                onPlayAlbum={handlePlayAlbum}
                onSelectAlbum={(id) => setActiveView({ type: 'ALBUM', albumId: id })}
              />
            )}

            {activeView.type === 'PLAYLIST' && (
              <LibraryView
                filter="playlists"
                albums={MOCK_ALBUMS}
                artists={MOCK_ARTISTS}
                tracks={MOCK_TRACKS}
                playlists={playlists}
                history={history}
                onPlayTrack={handlePlayTrack}
                onPlayAlbum={handlePlayAlbum}
                onSelectAlbum={(id) => setActiveView({ type: 'ALBUM', albumId: id })}
                onSelectArtist={(id) => setActiveView({ type: 'ARTIST', artistId: id })}
                onCreatePlaylist={handleCreatePlaylist}
              />
            )}
          </div>
        </main>
      </div>

      {/* Floating Bottom Music Player Bar */}
      <FloatingPlayer
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        togglePlay={togglePlay}
        nextTrack={handleNextTrack}
        prevTrack={handlePrevTrack}
        currentTime={currentTime}
        duration={duration}
        onSeek={handleSeek}
        volume={volume}
        setVolume={setVolume}
        openFullScreen={() => setIsFullScreenPlayerOpen(true)}
        toggleQueue={() => setShowQueue(!showQueue)}
        showQueue={showQueue}
        toggleLyrics={() => setShowLyrics(!showLyrics)}
        showLyrics={showLyrics}
        openDeviceModal={() => setIsDeviceModalOpen(true)}
        currentDevice={currentDevice}
        openSettings={() => setIsSettingsOpen(true)}
      />

      {/* Full Screen Immersive Player Overlay */}
      {isFullScreenPlayerOpen && currentTrack && (
        <FullScreenPlayer
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          togglePlay={togglePlay}
          nextTrack={handleNextTrack}
          prevTrack={handlePrevTrack}
          currentTime={currentTime}
          duration={duration}
          onSeek={handleSeek}
          volume={volume}
          setVolume={setVolume}
          closeFullScreen={() => setIsFullScreenPlayerOpen(false)}
          currentDevice={currentDevice}
          openDeviceModal={() => setIsDeviceModalOpen(true)}
          openSettings={() => setIsSettingsOpen(true)}
          queue={queue}
          playTrackFromQueue={handlePlayTrack}
        />
      )}

      {/* Audiophile Output Routing Modal */}
      <AudioDeviceSelectorModal
        isOpen={isDeviceModalOpen}
        onClose={() => setIsDeviceModalOpen(false)}
        devices={AUDIO_DEVICES}
        currentDevice={currentDevice}
        onSelectDevice={setCurrentDevice}
      />

      {/* Command-K Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        tracks={MOCK_TRACKS}
        albums={MOCK_ALBUMS}
        artists={MOCK_ARTISTS}
        onPlayTrack={handlePlayTrack}
        onSelectAlbum={(id) => setActiveView({ type: 'ALBUM', albumId: id })}
        onSelectArtist={(id) => setActiveView({ type: 'ARTIST', artistId: id })}
      />

      {/* Settings & DSP Equalizer Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        audioQuality={audioQuality}
        setAudioQuality={setAudioQuality}
      />
    </div>
  );
}
