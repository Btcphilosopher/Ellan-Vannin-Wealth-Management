import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Google GenAI on server side
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY || '',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', platform: 'Albion Audio Engine' });
  });

  // Gemini API route: Generate Monocle / British Design Museum style Album Essays & Liner Notes
  app.post('/api/editorial/essay', async (req, res) => {
    try {
      const { title, artist, genre, releaseYear } = req.body;

      if (!process.env.GEMINI_API_KEY) {
        return res.json({
          essay: `Album Essay for "${title}" by ${artist} (${releaseYear}).\n\nRecorded with spatial acoustic depth, this record stands as an iconic pillar of British ${genre} sound heritage. Fusing vintage analog studio warmth with forward-thinking compositional craftsmanship.`,
        });
      }

      const prompt = `You are a senior music critic for Monocle Magazine and the London Design Museum. Write a cultured, elegant, and evocative 3-paragraph liner note essay for the album "${title}" by "${artist}" released in ${releaseYear} (${genre}). Focus on British design craftsmanship, studio acoustics (tape saturation, room acoustics, analog gear), architectural atmosphere, and cultural impact. Keep it sophisticated, understated, and luxurious.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
      });

      res.json({
        essay: response.text || 'Essay generated successfully.',
      });
    } catch (err) {
      console.error('Error generating essay:', err);
      res.status(500).json({ error: 'Failed to generate album essay' });
    }
  });

  // Gemini API route: Curate custom British Listening Journey based on user prompt / mood
  app.post('/api/editorial/curate-journey', async (req, res) => {
    try {
      const { mood, weather, location } = req.body;

      if (!process.env.GEMINI_API_KEY) {
        return res.json({
          title: `Nocturnal ${location || 'London'} Atmosphere`,
          subtitle: `Curated for ${weather || 'Mist'} & ${mood || 'Reflective'} moods`,
          description: `A custom soundscape journey blending British post-punk sub-bass, warm rhodes piano, and acoustic folk resonances.`,
          curatorNote: `Hand-selected by Albion Audio Editorial Desk for optimal listening on high-fidelity British audio systems.`
        });
      }

      const prompt = `You are the lead audio curator for Albion Audio, Britain's premier music platform. Create a custom listening journey title, subtitle, 2-sentence description, and curator's note for someone experiencing "${mood}" mood during "${weather}" weather in "${location || 'London'}". Return in plain JSON format with keys: "title", "subtitle", "description", "curatorNote".`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
      });

      let parsed = {};
      try {
        const text = response.text?.replace(/```json/g, '').replace(/```/g, '').trim() || '{}';
        parsed = JSON.parse(text);
      } catch {
        parsed = {
          title: `${mood || 'Serene'} Journey`,
          subtitle: `Acoustics for ${weather || 'overcast'} conditions`,
          description: response.text,
          curatorNote: 'Curated by Albion AI Engine'
        };
      }

      res.json(parsed);
    } catch (err) {
      console.error('Error curating journey:', err);
      res.status(500).json({ error: 'Failed to curate journey' });
    }
  });

  // Vite middleware in development vs static serving in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Albion Audio platform server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
