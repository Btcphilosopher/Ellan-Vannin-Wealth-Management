import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import crypto from 'node:crypto';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// ==========================================
// ELLAN VANNIN CBDC SERVER-SIDE MONETARY ENGINE
// ==========================================

interface CentralBankState {
  jurisdictionCode: string;
  currencyCode: string;
  currencySymbol: string;
  centralBankName: string;
  ledgerHeight: number;
  totalIssued: number;
  totalRedeemed: number;
  totalOutstanding: number;
  offlineValue: number;
  isLedgerPaused: boolean;
  isIssuanceSuspended: boolean;
  isRedemptionSuspended: boolean;
}

const centralBankState: CentralBankState = {
  jurisdictionCode: 'EVP',
  currencyCode: 'EVP',
  currencySymbol: '£EVP ',
  centralBankName: 'Isle of Man Financial Services Authority & Central Monetary Authority',
  ledgerHeight: 10482,
  totalIssued: 1250000000,
  totalRedeemed: 150000000,
  totalOutstanding: 1100000000,
  offlineValue: 12450000,
  isLedgerPaused: false,
  isIssuanceSuspended: false,
  isRedemptionSuspended: false,
};

// Initial Mock Data Stores
const issuanceRequestsStore = [
  {
    requestId: 'ISS-2026-0901',
    authorizedInstitution: 'Central Monetary Authority',
    authorizedOfficer: 'Governor M. Quayle',
    currency: 'EVP',
    amount: 50000000,
    reason: 'Intermediary Liquidity Provision for Q3 Banking Reserve',
    targetIntermediaryId: 'INT-BANK-IOM-01',
    targetIntermediaryName: 'Isle of Man Bank & Trust',
    status: 'EXECUTED',
    approvals: [
      { officerId: 'GOV-01', officerName: 'Gov. M. Quayle', timestamp: '2026-09-01T09:15:00Z', signature: '0x8f2a...1e4b' },
      { officerId: 'TREAS-02', officerName: 'Treasury Controller S. Callow', timestamp: '2026-09-01T09:18:20Z', signature: '0x3c91...7a0d' }
    ],
    requiredApprovals: 2,
    timestamp: '2026-09-01T09:15:00Z',
    proofHash: '0xe4b82c19a0f3d61081971f114c023d8392019a128e45f'
  },
  {
    requestId: 'ISS-2026-0911',
    authorizedInstitution: 'Central Monetary Authority',
    authorizedOfficer: 'Deputy Gov. R. Teare',
    currency: 'EVP',
    amount: 25000000,
    reason: 'Wholesale DvP Liquidity Pool Expansion',
    targetIntermediaryId: 'INT-BANK-MANX-02',
    targetIntermediaryName: 'Conister Bank CBDC Gateway',
    status: 'PENDING_APPROVAL',
    approvals: [
      { officerId: 'DEP-GOV-02', officerName: 'Deputy Gov. R. Teare', timestamp: '2026-09-11T07:30:00Z', signature: '0x991f...4c22' }
    ],
    requiredApprovals: 2,
    timestamp: '2026-09-11T07:30:00Z',
    proofHash: '0x12a94f83b09204cd2e8174112c8a129031d234a981'
  }
];

const walletsStore = [
  {
    walletId: 'WAL-CIT-001',
    ownerReference: 'PERSON-EVP-88219',
    ownerName: 'Ewan Cannell (Citizen)',
    walletType: 'PERSONAL',
    currency: 'EVP',
    balance: 14250.50,
    unconfirmedBalance: 0,
    limits: { maxBalance: 20000, dailyPaymentLimit: 5000, offlineLimit: 500, usedToday: 240.00 },
    status: 'ACTIVE',
    publicKey: 'ed25519:7a419c8f0012b1928371fe992381',
    devices: [{ deviceId: 'DEV-IPHONE-15', deviceName: 'iPhone 15 Pro (Secure Enclave)', isHardwareSecured: true }],
    riskProfile: 'LOW'
  },
  {
    walletId: 'WAL-MER-002',
    ownerReference: 'ORG-EVP-44012',
    ownerName: 'Douglas Harbour Groceries & Goods',
    walletType: 'MERCHANT',
    currency: 'EVP',
    balance: 184920.00,
    unconfirmedBalance: 0,
    limits: { maxBalance: 1000000, dailyPaymentLimit: 250000, offlineLimit: 5000, usedToday: 12400.00 },
    status: 'ACTIVE',
    publicKey: 'ed25519:3b19284fa91028301140029193f2',
    devices: [{ deviceId: 'DEV-POS-TERMINAL-01', deviceName: 'Pax A920 POS Terminal', isHardwareSecured: true }],
    riskProfile: 'LOW'
  },
  {
    walletId: 'WAL-WHOLESALE-BANK1',
    ownerReference: 'INST-IOM-BANK-01',
    ownerName: 'Isle of Man Bank Wholesale Treasury',
    walletType: 'WHOLESALE',
    currency: 'EVP',
    balance: 450000000.00,
    unconfirmedBalance: 0,
    limits: { maxBalance: 2000000000, dailyPaymentLimit: 500000000, offlineLimit: 0, usedToday: 15000000.00 },
    status: 'ACTIVE',
    publicKey: 'ed25519:9f8e7d6c5b4a3f2e1d0c9b8a7f6e',
    devices: [{ deviceId: 'DEV-HSM-BANK1-01', deviceName: 'Thales Luna HSM Cluster', isHardwareSecured: true }],
    riskProfile: 'LOW'
  }
];

const transactionsStore = [
  {
    transactionId: 'TX-2026-90412',
    payerWalletId: 'WAL-CIT-001',
    payerAlias: 'Ewan Cannell',
    payeeWalletId: 'WAL-MER-002',
    payeeAlias: 'Douglas Harbour Groceries',
    amount: 84.50,
    currency: 'EVP',
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
    nonce: 1042,
    settlementStatus: 'FINAL',
    finalityStatus: 'INSTANT',
    signature: '0x9e12...f4a1',
    proofHash: '0x7a2f1b402c9183491028340129034812390148123049182',
    paymentMethod: 'NFC',
    privacyTier: 'TIER_1_MINIMAL',
    purpose: 'Merchant Retail Purchase',
    complianceScore: 98,
    riskAction: 'ALLOW',
    blockHeight: 10481
  },
  {
    transactionId: 'TX-2026-90411',
    payerWalletId: 'WAL-WHOLESALE-BANK1',
    payerAlias: 'Isle of Man Bank Treasury',
    payeeWalletId: 'WAL-MER-002',
    payeeAlias: 'Douglas Harbour Groceries',
    amount: 12500.00,
    currency: 'EVP',
    timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    nonce: 8891,
    settlementStatus: 'FINAL',
    finalityStatus: 'SETTLED_IN_BLOCK',
    signature: '0x3f41...89c2',
    proofHash: '0x1823901824091823901823901823901283901283012',
    paymentMethod: 'WHOLESALE_WIRE',
    privacyTier: 'TIER_3_HIGH_VALUE',
    purpose: 'Daily Merchant Settlement Payout',
    complianceScore: 99,
    riskAction: 'ALLOW',
    blockHeight: 10480
  }
];

// ==========================================
// REST API ENDPOINTS
// ==========================================

// 1. Status & Metrics
app.get('/api/cbdc/v1/status', (req, res) => {
  res.json({
    success: true,
    data: {
      ...centralBankState,
      timestamp: new Date().toISOString(),
      consensusStatus: 'HEALTHY_BFT',
      validatorsActive: 5,
      activeWalletsTotal: walletsStore.length,
      averageFinalityLatencyMs: 240,
      m0ReserveRatio: 1.00
    }
  });
});

// 2. Issuance Routes
app.get('/api/cbdc/v1/issuance', (req, res) => {
  res.json({ success: true, data: issuanceRequestsStore });
});

app.post('/api/cbdc/v1/issuance', (req, res) => {
  const { amount, reason, targetIntermediaryId, targetIntermediaryName, officerName } = req.body;
  if (!amount || amount <= 0) {
    res.status(400).json({ success: false, error: 'Invalid issuance amount' });
    return;
  }

  const newRequest = {
    requestId: `ISS-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    authorizedInstitution: centralBankState.centralBankName,
    authorizedOfficer: officerName || 'Central Bank Administrator',
    currency: centralBankState.currencyCode,
    amount: Number(amount),
    reason: reason || 'Monetary policy distribution',
    targetIntermediaryId: targetIntermediaryId || 'INT-BANK-IOM-01',
    targetIntermediaryName: targetIntermediaryName || 'Isle of Man Bank & Trust',
    status: 'PENDING_APPROVAL',
    approvals: [
      {
        officerId: 'OFFICER-01',
        officerName: officerName || 'Primary Initiator',
        timestamp: new Date().toISOString(),
        signature: `0x${crypto.randomBytes(8).toString('hex')}`
      }
    ],
    requiredApprovals: 2,
    timestamp: new Date().toISOString(),
    proofHash: `0x${crypto.randomBytes(20).toString('hex')}`
  };

  issuanceRequestsStore.unshift(newRequest);
  res.json({ success: true, data: newRequest });
});

app.post('/api/cbdc/v1/issuance/approve', (req, res) => {
  const { requestId, officerName } = req.body;
  const reqItem = issuanceRequestsStore.find(i => i.requestId === requestId);
  if (!reqItem) {
    res.status(404).json({ success: false, error: 'Issuance request not found' });
    return;
  }

  reqItem.approvals.push({
    officerId: 'OFFICER-02',
    officerName: officerName || 'Governor Approver',
    timestamp: new Date().toISOString(),
    signature: `0x${crypto.randomBytes(8).toString('hex')}`
  });

  if (reqItem.approvals.length >= reqItem.requiredApprovals) {
    reqItem.status = 'EXECUTED';
    centralBankState.totalIssued += reqItem.amount;
    centralBankState.totalOutstanding += reqItem.amount;
    centralBankState.ledgerHeight += 1;
  }

  res.json({ success: true, data: reqItem });
});

// 3. Wallets
app.get('/api/cbdc/v1/wallets', (req, res) => {
  res.json({ success: true, data: walletsStore });
});

app.get('/api/cbdc/v1/wallets/:id', (req, res) => {
  const wallet = walletsStore.find(w => w.walletId === req.params.id);
  if (!wallet) {
    res.status(404).json({ success: false, error: 'Wallet not found' });
    return;
  }
  res.json({ success: true, data: wallet });
});

// 4. Payments
app.get('/api/cbdc/v1/payments', (req, res) => {
  res.json({ success: true, data: transactionsStore });
});

app.post('/api/cbdc/v1/payments', (req, res) => {
  const { payerWalletId, payeeWalletId, amount, purpose, paymentMethod, privacyTier } = req.body;
  
  if (centralBankState.isLedgerPaused) {
    res.status(503).json({ success: false, error: 'CBDC Ledger is currently under emergency pause' });
    return;
  }

  const payer = walletsStore.find(w => w.walletId === payerWalletId);
  const payee = walletsStore.find(w => w.walletId === payeeWalletId);

  if (!payer || !payee) {
    res.status(404).json({ success: false, error: 'Payer or Payee wallet not found' });
    return;
  }

  if (payer.balance < amount) {
    res.status(400).json({ success: false, error: 'Insufficient funds in payer wallet' });
    return;
  }

  // Deduct/Credit
  payer.balance -= amount;
  payee.balance += amount;
  payer.limits.usedToday += amount;

  centralBankState.ledgerHeight += 1;

  const newTx = {
    transactionId: `TX-2026-${Math.floor(10000 + Math.random() * 90000)}`,
    payerWalletId,
    payerAlias: payer.ownerName,
    payeeWalletId,
    payeeAlias: payee.ownerName,
    amount: Number(amount),
    currency: centralBankState.currencyCode,
    timestamp: new Date().toISOString(),
    nonce: Math.floor(Math.random() * 10000),
    settlementStatus: 'FINAL',
    finalityStatus: 'INSTANT',
    signature: `0x${crypto.randomBytes(16).toString('hex')}`,
    proofHash: `0x${crypto.randomBytes(32).toString('hex')}`,
    paymentMethod: paymentMethod || 'NFC',
    privacyTier: privacyTier || 'TIER_1_MINIMAL',
    purpose: purpose || 'Retail Transfer',
    complianceScore: 99,
    riskAction: 'ALLOW',
    blockHeight: centralBankState.ledgerHeight
  };

  transactionsStore.unshift(newTx);
  res.json({ success: true, data: newTx });
});

// 5. Emergency Controls
app.post('/api/cbdc/v1/emergency/toggle', (req, res) => {
  const { action, reason } = req.body;
  if (action === 'PAUSE_LEDGER') {
    centralBankState.isLedgerPaused = !centralBankState.isLedgerPaused;
  } else if (action === 'SUSPEND_ISSUANCE') {
    centralBankState.isIssuanceSuspended = !centralBankState.isIssuanceSuspended;
  }
  res.json({ success: true, data: { ...centralBankState, reason: reason || 'Administrative action' } });
});

// Static assets & Angular SSR catch-all
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 3000;
  app.listen(port, () => {
    console.log(`Ellan Vannin CBDC Express server listening on http://0.0.0.0:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
