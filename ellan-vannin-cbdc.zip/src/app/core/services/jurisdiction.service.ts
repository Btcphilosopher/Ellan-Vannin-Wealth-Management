import { Injectable, signal, computed } from '@angular/core';
import { JurisdictionCode, JurisdictionConfig } from '../models/cbdc.types';

@Injectable({
  providedIn: 'root',
})
export class JurisdictionService {
  readonly JURISDICTIONS: Record<JurisdictionCode, JurisdictionConfig> = {
    EVP: {
      code: 'EVP',
      centralBankName: 'Isle of Man Financial Services Authority & Central Monetary Authority',
      currencyCode: 'EVP',
      currencySymbol: '£EVP ',
      jurisdictionName: 'Isle of Man (Ellan Vannin)',
      legalFramework: 'Isle of Man Currency & Central Bank Digital Money Act 2026',
      monetaryModel: 'HYBRID',
      holdingLimitRetail: 20000,
      dailyTransactionLimitRetail: 5000,
      offlineWalletLimit: 500,
      privacyTier1Threshold: 250,
      privacyTier2Threshold: 2500,
      remunerationRate: 0.00,
    },
    GBP: {
      code: 'GBP',
      centralBankName: 'Bank of England',
      currencyCode: 'GBP',
      currencySymbol: '£',
      jurisdictionName: 'United Kingdom',
      legalFramework: 'UK Digital Pound Monetary Framework & Banking Act',
      monetaryModel: 'HYBRID',
      holdingLimitRetail: 10000,
      dailyTransactionLimitRetail: 3000,
      offlineWalletLimit: 300,
      privacyTier1Threshold: 100,
      privacyTier2Threshold: 2000,
      remunerationRate: 0.00,
    },
    EUR: {
      code: 'EUR',
      centralBankName: 'European Central Bank (ECB)',
      currencyCode: 'EUR',
      currencySymbol: '€',
      jurisdictionName: 'Eurozone (European Union)',
      legalFramework: 'EU Digital Euro Regulation & Single Euro Payment Area',
      monetaryModel: 'ACCOUNT',
      holdingLimitRetail: 3000,
      dailyTransactionLimitRetail: 1000,
      offlineWalletLimit: 200,
      privacyTier1Threshold: 150,
      privacyTier2Threshold: 1000,
      remunerationRate: 0.00,
    },
    USD: {
      code: 'USD',
      centralBankName: 'Federal Reserve System',
      currencyCode: 'USD',
      currencySymbol: '$',
      jurisdictionName: 'United States of America',
      legalFramework: 'Federal Reserve Act & US Digital Dollar Governance Standard',
      monetaryModel: 'HYBRID',
      holdingLimitRetail: 25000,
      dailyTransactionLimitRetail: 10000,
      offlineWalletLimit: 1000,
      privacyTier1Threshold: 500,
      privacyTier2Threshold: 5000,
      remunerationRate: 0.015,
    },
    SGD: {
      code: 'SGD',
      centralBankName: 'Monetary Authority of Singapore (MAS)',
      currencyCode: 'SGD',
      currencySymbol: 'S$',
      jurisdictionName: 'Singapore',
      legalFramework: 'MAS Purpose Bound Money & Orchard Retail CBDC Infrastructure',
      monetaryModel: 'TOKEN',
      holdingLimitRetail: 15000,
      dailyTransactionLimitRetail: 4000,
      offlineWalletLimit: 400,
      privacyTier1Threshold: 200,
      privacyTier2Threshold: 2000,
      remunerationRate: 0.01,
    },
  };

  readonly currentCode = signal<JurisdictionCode>('EVP');
  readonly activeJurisdiction = computed(() => this.currentCode());

  readonly activeConfig = computed(() => {
    const config = this.JURISDICTIONS[this.currentCode()];
    return {
      ...config,
      name: config.jurisdictionName,
    };
  });

  setJurisdiction(code: JurisdictionCode) {
    this.currentCode.set(code);
  }
}
