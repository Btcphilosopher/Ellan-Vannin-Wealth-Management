import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  Block,
  Validator,
  IssuanceRequest,
  RedemptionRequest,
  Wallet,
  Transaction,
  Intermediary,
  DvPInstruction,
  CrossBorderTransfer,
  ProgrammableCondition,
  RiskAlert,
  OfflineDeviceWallet,
  ReconciliationRecord,
  EmergencyControlState,
  MonetarySupplyMetrics,
  PaymentMethod,
  PrivacyTier,
} from '../models/cbdc.types';
import { JurisdictionService } from './jurisdiction.service';

export type UserPersona =
  | 'CENTRAL_BANK'
  | 'INTERMEDIARY'
  | 'CITIZEN'
  | 'MERCHANT'
  | 'AUDITOR';

@Injectable({
  providedIn: 'root',
})
export class CBDCService {
  private http = inject(HttpClient);
  private jurisdictionService = inject(JurisdictionService);

  // Active Role / Persona
  readonly activePersona = signal<UserPersona>('CENTRAL_BANK');

  // Monetary Supply Metrics
  readonly supplyMetrics = signal<MonetarySupplyMetrics>({
    totalIssued: 1250000000,
    totalRedeemed: 150000000,
    totalOutstanding: 1100000000,
    activeWallets: 148200,
    activeIntermediaries: 12,
    transactionVolume24h: 384910,
    transactionValue24h: 84290000,
    settlementValue24h: 72000000,
    offlineValue: 12450000,
    m0ReserveRatio: 1.0,
  });

  // Emergency Control State
  readonly emergencyState = signal<EmergencyControlState>({
    isLedgerPaused: false,
    isIssuanceSuspended: false,
    isRedemptionSuspended: false,
    activeIsolationLevel: 'NORMAL',
    reason: 'All systems operating within standard monetary policy baseline.',
    initiatedBy: 'System Security Protocol',
    initiatedAt: new Date().toISOString(),
  });

  // Ledger Height & Consensus
  readonly ledgerHeight = signal<number>(10482);

  // Validators Topology
  readonly validators = signal<Validator[]>([
    {
      validatorId: 'VAL-CMA-01',
      institutionId: 'CMA-IOM',
      institutionName: 'Central Monetary Authority Primary Node',
      publicKey: 'ed25519:7b1e428c9f0012',
      certificate: 'X.509 CA Issuer Certified (Grade 5 HSM)',
      status: 'ACTIVE',
      jurisdiction: 'Isle of Man',
      permissions: ['BLOCK_PROPOSAL', 'MINT_VALIDATION', 'CROSS_BORDER_VOTE'],
      blocksProposed: 2104,
      votingWeight: 30,
      latencyMs: 12,
    },
    {
      validatorId: 'VAL-BANK-IOM-02',
      institutionId: 'INT-BANK-IOM-01',
      institutionName: 'Isle of Man Bank Consensus Node',
      publicKey: 'ed25519:3a9d182e008129',
      certificate: 'X.509 Intermediary Certified',
      status: 'ACTIVE',
      jurisdiction: 'Isle of Man',
      permissions: ['BLOCK_PROPOSAL', 'TRANSACTION_VALIDATION'],
      blocksProposed: 1980,
      votingWeight: 20,
      latencyMs: 18,
    },
    {
      validatorId: 'VAL-CONISTER-03',
      institutionId: 'INT-BANK-MANX-02',
      institutionName: 'Conister Bank Settlement Node',
      publicKey: 'ed25519:8c12a4f0012b91',
      certificate: 'X.509 Intermediary Certified',
      status: 'ACTIVE',
      jurisdiction: 'Isle of Man',
      permissions: ['TRANSACTION_VALIDATION'],
      blocksProposed: 1840,
      votingWeight: 20,
      latencyMs: 22,
    },
    {
      validatorId: 'VAL-BOE-LINK-04',
      institutionId: 'BOE-UK-GATEWAY',
      institutionName: 'Bank of England Gateway Observer Node',
      publicKey: 'ed25519:12f49c00823a10',
      certificate: 'X.509 Central Bank Interop Certified',
      status: 'ACTIVE',
      jurisdiction: 'United Kingdom',
      permissions: ['CROSS_BORDER_VOTE', 'READ_AUDIT'],
      blocksProposed: 1200,
      votingWeight: 15,
      latencyMs: 35,
    },
    {
      validatorId: 'VAL-AUDIT-IOM-05',
      institutionId: 'GOV-AUDITOR-GENERAL',
      institutionName: 'Government Auditor General Supervisory Node',
      publicKey: 'ed25519:90182c1e400291',
      certificate: 'X.509 Regulatory Supervisor Certified',
      status: 'ACTIVE',
      jurisdiction: 'Isle of Man',
      permissions: ['READ_AUDIT', 'SUPERVISORY_DECRYPTION'],
      blocksProposed: 0,
      votingWeight: 15,
      latencyMs: 15,
    },
  ]);

  // Intermediaries
  readonly intermediaries = signal<Intermediary[]>([
    {
      intermediaryId: 'INT-BANK-IOM-01',
      name: 'Isle of Man Bank & Trust',
      type: 'COMMERCIAL_BANK',
      reserveBalance: 450000000,
      cbdcAllocated: 380000000,
      status: 'ACTIVE',
      jurisdiction: 'Isle of Man',
      activeWalletsCount: 82400,
    },
    {
      intermediaryId: 'INT-BANK-MANX-02',
      name: 'Conister Bank Commercial Gateway',
      type: 'COMMERCIAL_BANK',
      reserveBalance: 210000000,
      cbdcAllocated: 185000000,
      status: 'ACTIVE',
      jurisdiction: 'Isle of Man',
      activeWalletsCount: 41200,
    },
    {
      intermediaryId: 'INT-PAYMENT-PEEL-03',
      name: 'Manx Telecom Financial Services',
      type: 'PAYMENT_INSTITUTION',
      reserveBalance: 85000000,
      cbdcAllocated: 72000000,
      status: 'ACTIVE',
      jurisdiction: 'Isle of Man',
      activeWalletsCount: 24600,
    },
  ]);

  // Issuance Requests
  readonly issuanceRequests = signal<IssuanceRequest[]>([
    {
      requestId: 'ISS-2026-0901',
      authorizedInstitution: 'Isle of Man Financial Services Authority',
      authorizedOfficer: 'Governor M. Quayle',
      currency: 'EVP',
      amount: 50000000,
      reason: 'Intermediary Liquidity Provision for Q3 Banking Reserve',
      targetIntermediaryId: 'INT-BANK-IOM-01',
      targetIntermediaryName: 'Isle of Man Bank & Trust',
      status: 'EXECUTED',
      approvals: [
        { officerId: 'GOV-01', officerName: 'Gov. M. Quayle', timestamp: '2026-09-01T09:15:00Z', signature: '0x8f2a...1e4b' },
        { officerId: 'TREAS-02', officerName: 'Treasury Controller S. Callow', timestamp: '2026-09-01T09:18:20Z', signature: '0x3c91...7a0d' },
      ],
      requiredApprovals: 2,
      timestamp: '2026-09-01T09:15:00Z',
      proofHash: '0xe4b82c19a0f3d61081971f114c023d8392019a128e45f',
    },
    {
      requestId: 'ISS-2026-0911',
      authorizedInstitution: 'Isle of Man Financial Services Authority',
      authorizedOfficer: 'Deputy Gov. R. Teare',
      currency: 'EVP',
      amount: 25000000,
      reason: 'Wholesale DvP Liquidity Pool Expansion',
      targetIntermediaryId: 'INT-BANK-MANX-02',
      targetIntermediaryName: 'Conister Bank CBDC Gateway',
      status: 'PENDING_APPROVAL',
      approvals: [
        { officerId: 'DEP-GOV-02', officerName: 'Deputy Gov. R. Teare', timestamp: '2026-09-11T07:30:00Z', signature: '0x991f...4c22' },
      ],
      requiredApprovals: 2,
      timestamp: '2026-09-11T07:30:00Z',
      proofHash: '0x12a94f83b09204cd2e8174112c8a129031d234a981',
    },
  ]);

  // Redemption Requests
  readonly redemptionRequests = signal<RedemptionRequest[]>([
    {
      requestId: 'RED-2026-0410',
      intermediaryId: 'INT-BANK-IOM-01',
      intermediaryName: 'Isle of Man Bank & Trust',
      amount: 15000000,
      burnReference: 'BURN-CBDC-EVP-88102',
      settlementBankAccount: 'BOE-RTGS-ACC-0029102',
      status: 'COMPLETED',
      timestamp: '2026-09-08T14:22:00Z',
    },
  ]);

  // Wallets
  readonly wallets = signal<Wallet[]>([
    {
      walletId: 'WAL-CIT-001',
      ownerReference: 'PERSON-EVP-88219',
      ownerName: 'Ewan Cannell (Citizen)',
      walletType: 'PERSONAL',
      currency: 'EVP',
      balance: 14250.50,
      unconfirmedBalance: 0,
      limits: { maxBalance: 20000, dailyPaymentLimit: 5000, offlineLimit: 500, usedToday: 240.00 },
      status: 'ACTIVE',
      publicKey: 'ed25519:7a419c8f0012b1928371fe992381',
      devices: [{ deviceId: 'DEV-IPHONE-15', deviceName: 'iPhone 15 Pro (Secure Enclave)', isHardwareSecured: true }],
      riskProfile: 'LOW',
    },
    {
      walletId: 'WAL-MER-002',
      ownerReference: 'ORG-EVP-44012',
      ownerName: 'Douglas Harbour Groceries & Goods',
      walletType: 'MERCHANT',
      currency: 'EVP',
      balance: 184920.00,
      unconfirmedBalance: 0,
      limits: { maxBalance: 1000000, dailyPaymentLimit: 250000, offlineLimit: 5000, usedToday: 12400.00 },
      status: 'ACTIVE',
      publicKey: 'ed25519:3b19284fa91028301140029193f2',
      devices: [{ deviceId: 'DEV-POS-TERMINAL-01', deviceName: 'Pax A920 POS Terminal', isHardwareSecured: true }],
      riskProfile: 'LOW',
    },
    {
      walletId: 'WAL-GOV-003',
      ownerReference: 'GOV-TREASURY-01',
      ownerName: 'Isle of Man Government Treasury Disbursement',
      walletType: 'GOVERNMENT',
      currency: 'EVP',
      balance: 45000000.00,
      unconfirmedBalance: 0,
      limits: { maxBalance: 500000000, dailyPaymentLimit: 50000000, offlineLimit: 0, usedToday: 1500000.00 },
      status: 'ACTIVE',
      publicKey: 'ed25519:12893a019284019284019284',
      devices: [{ deviceId: 'DEV-GOV-HSM-01', deviceName: 'Treasury Enterprise HSM Cluster', isHardwareSecured: true }],
      riskProfile: 'LOW',
    },
    {
      walletId: 'WAL-WHOLESALE-BANK1',
      ownerReference: 'INST-IOM-BANK-01',
      ownerName: 'Isle of Man Bank Wholesale Treasury',
      walletType: 'WHOLESALE',
      currency: 'EVP',
      balance: 450000000.00,
      unconfirmedBalance: 0,
      limits: { maxBalance: 2000000000, dailyPaymentLimit: 500000000, offlineLimit: 0, usedToday: 15000000.00 },
      status: 'ACTIVE',
      publicKey: 'ed25519:9f8e7d6c5b4a3f2e1d0c9b8a7f6e',
      devices: [{ deviceId: 'DEV-HSM-BANK1-01', deviceName: 'Thales Luna HSM Cluster', isHardwareSecured: true }],
      riskProfile: 'LOW',
    },
  ]);

  // Transactions
  readonly transactions = signal<Transaction[]>([
    {
      transactionId: 'TX-2026-90412',
      payerWalletId: 'WAL-CIT-001',
      payerAlias: 'Ewan Cannell',
      payeeWalletId: 'WAL-MER-002',
      payeeAlias: 'Douglas Harbour Groceries',
      amount: 84.50,
      currency: 'EVP',
      timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
      nonce: 1042,
      settlementStatus: 'FINAL',
      finalityStatus: 'INSTANT',
      signature: '0x9e12f4a189c10284',
      proofHash: '0x7a2f1b402c9183491028340129034812390148123049182',
      paymentMethod: 'NFC',
      privacyTier: 'TIER_1_MINIMAL',
      purpose: 'Merchant Retail Purchase',
      complianceScore: 98,
      riskAction: 'ALLOW',
      blockHeight: 10481,
    },
    {
      transactionId: 'TX-2026-90411',
      payerWalletId: 'WAL-GOV-003',
      payerAlias: 'Isle of Man Government Treasury',
      payeeWalletId: 'WAL-CIT-001',
      payeeAlias: 'Ewan Cannell',
      amount: 1250.00,
      currency: 'EVP',
      timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
      nonce: 4892,
      settlementStatus: 'FINAL',
      finalityStatus: 'INSTANT',
      signature: '0x4c91029419283f12',
      proofHash: '0x992e10293f102930129301293012930129301293012',
      paymentMethod: 'API',
      privacyTier: 'TIER_2_STANDARD',
      purpose: 'Government Solar Energy Rebate Grant',
      complianceScore: 100,
      riskAction: 'ALLOW',
      blockHeight: 10480,
    },
    {
      transactionId: 'TX-2026-90410',
      payerWalletId: 'WAL-WHOLESALE-BANK1',
      payerAlias: 'Isle of Man Bank Wholesale Treasury',
      payeeWalletId: 'WAL-MER-002',
      payeeAlias: 'Douglas Harbour Groceries',
      amount: 12500.00,
      currency: 'EVP',
      timestamp: new Date(Date.now() - 1000 * 60 * 360).toISOString(),
      nonce: 8891,
      settlementStatus: 'FINAL',
      finalityStatus: 'SETTLED_IN_BLOCK',
      signature: '0x3f4189c2019283f2',
      proofHash: '0x1823901824091823901823901823901283901283012',
      paymentMethod: 'WHOLESALE_WIRE',
      privacyTier: 'TIER_3_HIGH_VALUE',
      purpose: 'Daily Merchant Settlement Payout',
      complianceScore: 99,
      riskAction: 'ALLOW',
      blockHeight: 10479,
    },
  ]);

  // Ledger Blocks
  readonly blocks = signal<Block[]>([
    {
      height: 10481,
      blockHash: '0x0000a8912f41029481203918239018239018239018239',
      previousHash: '0x000049f102948120938120391823901823901823901',
      stateRoot: '0x77f12e8910239102938120938102938120391823',
      transactions: [this.transactions()[0]],
      proposerValidatorId: 'VAL-CMA-01',
      proposerName: 'Central Monetary Authority Primary Node',
      timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
      signature: '0x992f10294812039182',
    },
    {
      height: 10480,
      blockHash: '0x000049f102948120938120391823901823901823901',
      previousHash: '0x0000102948120938120391823901823901823901001',
      stateRoot: '0x3310293810293810293810293810293810293810',
      transactions: [this.transactions()[1]],
      proposerValidatorId: 'VAL-BANK-IOM-02',
      proposerName: 'Isle of Man Bank Consensus Node',
      timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
      signature: '0x12a938102938102938',
    },
  ]);

  // Wholesale DvP
  readonly dvpInstructions = signal<DvPInstruction[]>([
    {
      dvpId: 'DVP-2026-081',
      securityIsin: 'GB00B1234567',
      securityName: 'Isle of Man 3.25% Sovereign Treasury Bond 2030',
      units: 10000,
      pricePerUnit: 98.50,
      totalValue: 985000.00,
      buyerWalletId: 'WAL-WHOLESALE-BANK1',
      sellerWalletId: 'WAL-GOV-003',
      settlementStatus: 'ATOMICALLY_SETTLED',
      escrowTxId: 'TX-2026-90410',
      timestamp: '2026-09-10T11:45:00Z',
    },
    {
      dvpId: 'DVP-2026-082',
      securityIsin: 'GB00B8901234',
      securityName: 'Manx Green Transition Note Series A',
      units: 5000,
      pricePerUnit: 100.00,
      totalValue: 500000.00,
      buyerWalletId: 'WAL-WHOLESALE-BANK1',
      sellerWalletId: 'WAL-GOV-003',
      settlementStatus: 'PENDING',
      escrowTxId: 'TX-ESCROW-PENDING-02',
      timestamp: '2026-09-11T08:00:00Z',
    },
  ]);

  // Cross-Border Transfers
  readonly crossBorderTransfers = signal<CrossBorderTransfer[]>([
    {
      transferId: 'CB-2026-0041',
      sourceCbdc: 'GBP',
      targetCbdc: 'EVP',
      sourceAmount: 100000.00,
      fxRate: 1.00, // Parity GBP/EVP
      convertedAmount: 100000.00,
      gatewayId: 'GATEWAY-BOE-IOM-01',
      recipientWalletId: 'WAL-WHOLESALE-BANK1',
      status: 'COMPLETED',
      timestamp: '2026-09-10T16:10:00Z',
    },
  ]);

  // Programmable Monetary Conditions
  readonly programmableConditions = signal<ProgrammableCondition[]>([
    {
      programId: 'PROG-SOLAR-2026',
      title: 'Isle of Man Green Housing Energy Grant',
      purpose: 'Restricted-purpose subsidy for certified solar panel installation',
      issuer: 'Department of Environment, Food & Agriculture',
      conditions: {
        expirationDate: '2026-12-31',
        restrictedCategories: ['SOLAR_HARDWARE', 'GREEN_ENERGY_CONTRACTORS'],
        maxClaimAmount: 2500,
        requireDualSign: false,
      },
      totalBudget: 5000000,
      disbursedAmount: 1850000,
      activeBeneficiariesCount: 1480,
      status: 'ACTIVE',
    },
    {
      programId: 'PROG-HERITAGE-PASS',
      title: 'Manx National Heritage Cultural Pass',
      purpose: 'Citizen tourism & local cultural venue subsidy',
      issuer: 'Department of Enterprise',
      conditions: {
        expirationDate: '2026-10-31',
        restrictedCategories: ['MUSEUMS', 'TRANSPORT', 'LOCAL_CRAFTS'],
        maxClaimAmount: 150,
        requireDualSign: false,
      },
      totalBudget: 1000000,
      disbursedAmount: 420000,
      activeBeneficiariesCount: 2800,
      status: 'ACTIVE',
    },
  ]);

  // Risk & Compliance Alerts
  readonly riskAlerts = signal<RiskAlert[]>([
    {
      alertId: 'ALT-2026-441',
      transactionId: 'TX-SUSPICIOUS-TEST-881',
      walletId: 'WAL-SUSPECT-991',
      riskScore: 84,
      triggers: ['Rapid velocity anomaly (>10 txs in 30s)', 'Unregistered IP geolocation transition'],
      recommendedAction: 'STEP_UP',
      status: 'OPEN',
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    },
  ]);

  // Offline Devices
  readonly offlineDevices = signal<OfflineDeviceWallet[]>([
    {
      deviceId: 'DEV-IPHONE-15',
      walletId: 'WAL-CIT-001',
      ownerName: 'Ewan Cannell',
      hardwareSecureElementId: 'SE-APPLE-A17-991028',
      offlineBalance: 260.00,
      offlineCounter: 14,
      maxOfflineLimit: 500.00,
      lastSyncedAt: new Date(Date.now() - 1000 * 3600 * 8).toISOString(),
      syncDeadlineHours: 24,
      pendingOfflineTxs: 2,
      status: 'SYNCED',
    },
    {
      deviceId: 'DEV-KEYCARD-SEC-02',
      walletId: 'WAL-OFFLINE-RURAL-88',
      ownerName: 'Ramsey Agricultural Co-op',
      hardwareSecureElementId: 'SE-INFINEON-SLE78-8812',
      offlineBalance: 480.00,
      offlineCounter: 42,
      maxOfflineLimit: 500.00,
      lastSyncedAt: new Date(Date.now() - 1000 * 3600 * 22).toISOString(),
      syncDeadlineHours: 24,
      pendingOfflineTxs: 5,
      status: 'PENDING_SYNC',
    },
  ]);

  // Reconciliation Records
  readonly reconciliationRecords = signal<ReconciliationRecord[]>([
    {
      reconciliationId: 'REC-2026-0911',
      timestamp: new Date().toISOString(),
      ledgerTotalIssuance: 1250000000,
      ledgerTotalRedemption: 150000000,
      calculatedOutstanding: 1100000000,
      actualWalletBalancesSum: 1100000000,
      discrepancyAmount: 0.00,
      status: 'BALANCED',
      reconciliationOfficer: 'Automated Audit Daemon & Auditor General',
    },
  ]);

  // Active Citizen Wallet helper
  readonly activeCitizenWallet = computed(() =>
    this.wallets().find((w) => w.walletId === 'WAL-CIT-001') || this.wallets()[0]
  );

  // Active Merchant Wallet helper
  readonly activeMerchantWallet = computed(() =>
    this.wallets().find((w) => w.walletId === 'WAL-MER-002') || this.wallets()[1]
  );

  // Actions

  setPersona(persona: UserPersona) {
    this.activePersona.set(persona);
  }

  // Issuance Submission
  submitIssuance(amount: number, reason: string, targetIntermediaryId: string, officerName: string) {
    const targetInt = this.intermediaries().find((i) => i.intermediaryId === targetIntermediaryId);
    const newReq: IssuanceRequest = {
      requestId: `ISS-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      authorizedInstitution: this.jurisdictionService.activeConfig().centralBankName,
      authorizedOfficer: officerName,
      currency: this.jurisdictionService.activeConfig().currencyCode,
      amount,
      reason,
      targetIntermediaryId,
      targetIntermediaryName: targetInt?.name || 'Authorized Bank',
      status: 'PENDING_APPROVAL',
      approvals: [
        {
          officerId: 'OFFICER-01',
          officerName,
          timestamp: new Date().toISOString(),
          signature: `0x${Math.random().toString(16).substring(2, 10)}`,
        },
      ],
      requiredApprovals: 2,
      timestamp: new Date().toISOString(),
      proofHash: `0x${Math.random().toString(16).substring(2, 34)}`,
    };

    this.issuanceRequests.update((list) => [newReq, ...list]);

    // Also call backend API asynchronously
    this.http.post('/api/cbdc/v1/issuance', { amount, reason, targetIntermediaryId, officerName }).subscribe();
  }

  // Issuance Approval
  approveIssuance(requestId: string, approverName: string) {
    this.issuanceRequests.update((list) =>
      list.map((req) => {
        if (req.requestId === requestId) {
          const updatedApprovals = [
            ...req.approvals,
            {
              officerId: 'GOVERNOR-02',
              officerName: approverName,
              timestamp: new Date().toISOString(),
              signature: `0x${Math.random().toString(16).substring(2, 10)}`,
            },
          ];

          const isFullyApproved = updatedApprovals.length >= req.requiredApprovals;
          if (isFullyApproved) {
            // Update Monetary Metrics
            this.supplyMetrics.update((m) => ({
              ...m,
              totalIssued: m.totalIssued + req.amount,
              totalOutstanding: m.totalOutstanding + req.amount,
            }));
            this.ledgerHeight.update((h) => h + 1);
          }

          return {
            ...req,
            approvals: updatedApprovals,
            status: isFullyApproved ? ('EXECUTED' as const) : ('PENDING_APPROVAL' as const),
          };
        }
        return req;
      })
    );

    this.http.post('/api/cbdc/v1/issuance/approve', { requestId, officerName: approverName }).subscribe();
  }

  // Payment Execution
  executePayment(
    payerWalletId: string,
    payeeWalletId: string,
    amount: number,
    purpose: string,
    paymentMethod: PaymentMethod = 'NFC',
    privacyTier: PrivacyTier = 'TIER_1_MINIMAL'
  ): { success: boolean; error?: string } {
    if (this.emergencyState().isLedgerPaused) {
      return { success: false, error: 'CBDC Ledger is under emergency pause.' };
    }

    const payer = this.wallets().find((w) => w.walletId === payerWalletId);
    const payee = this.wallets().find((w) => w.walletId === payeeWalletId);

    if (!payer || !payee) {
      return { success: false, error: 'Invalid wallet credentials.' };
    }

    if (payer.balance < amount) {
      return { success: false, error: 'Insufficient CBDC balance.' };
    }

    // Update Local Wallet Balances
    this.wallets.update((list) =>
      list.map((w) => {
        if (w.walletId === payerWalletId) {
          return {
            ...w,
            balance: w.balance - amount,
            limits: { ...w.limits, usedToday: w.limits.usedToday + amount },
          };
        }
        if (w.walletId === payeeWalletId) {
          return { ...w, balance: w.balance + amount };
        }
        return w;
      })
    );

    const newHeight = this.ledgerHeight() + 1;
    this.ledgerHeight.set(newHeight);

    const newTx: Transaction = {
      transactionId: `TX-2026-${Math.floor(10000 + Math.random() * 90000)}`,
      payerWalletId,
      payerAlias: payer.ownerName,
      payeeWalletId,
      payeeAlias: payee.ownerName,
      amount,
      currency: this.jurisdictionService.activeConfig().currencyCode,
      timestamp: new Date().toISOString(),
      nonce: Math.floor(Math.random() * 10000),
      settlementStatus: 'FINAL',
      finalityStatus: 'INSTANT',
      signature: `0x${Math.random().toString(16).substring(2, 18)}`,
      proofHash: `0x${Math.random().toString(16).substring(2, 42)}`,
      paymentMethod,
      privacyTier,
      purpose,
      complianceScore: 99,
      riskAction: 'ALLOW',
      blockHeight: newHeight,
    };

    this.transactions.update((txs) => [newTx, ...txs]);

    // Create a new block
    const newBlock: Block = {
      height: newHeight,
      blockHash: `0x0000${Math.random().toString(16).substring(2, 38)}`,
      previousHash: this.blocks()[0]?.blockHash || '0x0000000000',
      stateRoot: `0x${Math.random().toString(16).substring(2, 38)}`,
      transactions: [newTx],
      proposerValidatorId: 'VAL-CMA-01',
      proposerName: 'Central Monetary Authority Primary Node',
      timestamp: new Date().toISOString(),
      signature: `0x${Math.random().toString(16).substring(2, 18)}`,
    };

    this.blocks.update((b) => [newBlock, ...b]);

    // Call REST server
    this.http
      .post('/api/cbdc/v1/payments', {
        payerWalletId,
        payeeWalletId,
        amount,
        purpose,
        paymentMethod,
        privacyTier,
      })
      .subscribe();

    return { success: true };
  }

  // Atomic DvP Settlement
  executeDvP(dvpId: string) {
    this.dvpInstructions.update((list) =>
      list.map((d) => {
        if (d.dvpId === dvpId) {
          return {
            ...d,
            settlementStatus: 'ATOMICALLY_SETTLED',
            escrowTxId: `TX-DVP-SETTLED-${Math.floor(1000 + Math.random() * 9000)}`,
          };
        }
        return d;
      })
    );
  }

  // Offline Device Sync
  syncOfflineDevice(deviceId: string) {
    this.offlineDevices.update((list) =>
      list.map((dev) => {
        if (dev.deviceId === deviceId) {
          return {
            ...dev,
            lastSyncedAt: new Date().toISOString(),
            pendingOfflineTxs: 0,
            status: 'SYNCED',
          };
        }
        return dev;
      })
    );
  }

  // Emergency Controls
  toggleLedgerPause(reason: string) {
    this.emergencyState.update((state) => {
      const nextState = !state.isLedgerPaused;
      return {
        ...state,
        isLedgerPaused: nextState,
        activeIsolationLevel: nextState ? 'EMERGENCY_HALT' : 'NORMAL',
        reason: nextState ? reason : 'Ledger resumed normal operations.',
        initiatedAt: new Date().toISOString(),
      };
    });

    this.http
      .post('/api/cbdc/v1/emergency/toggle', { action: 'PAUSE_LEDGER', reason })
      .subscribe();
  }

  // Continuous Reconciliation Run
  runReconciliation() {
    const totalIss = this.supplyMetrics().totalIssued;
    const totalRed = this.supplyMetrics().totalRedeemed;
    const calcOut = totalIss - totalRed;

    const newRecord: ReconciliationRecord = {
      reconciliationId: `REC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString(),
      ledgerTotalIssuance: totalIss,
      ledgerTotalRedemption: totalRed,
      calculatedOutstanding: calcOut,
      actualWalletBalancesSum: calcOut,
      discrepancyAmount: 0.0,
      status: 'BALANCED',
      reconciliationOfficer: 'Auditor General Continuous Verification Engine',
    };

    this.reconciliationRecords.update((r) => [newRecord, ...r]);
  }
}
