export type MonetaryModel = 'ACCOUNT' | 'TOKEN' | 'HYBRID';

export type JurisdictionCode = 'EVP' | 'GBP' | 'EUR' | 'USD' | 'SGD';

export interface JurisdictionConfig {
  code: JurisdictionCode;
  centralBankName: string;
  currencyCode: string;
  currencySymbol: string;
  jurisdictionName: string;
  legalFramework: string;
  monetaryModel: MonetaryModel;
  holdingLimitRetail: number;
  dailyTransactionLimitRetail: number;
  offlineWalletLimit: number;
  privacyTier1Threshold: number;
  privacyTier2Threshold: number;
  remunerationRate: number; // e.g., 0.035 for 3.5%
}

export type UnitStatus = 'ACTIVE' | 'LOCKED' | 'REDEEMED' | 'SUSPENDED';

export interface CBDCUnit {
  unitId: string;
  currency: string;
  issuer: string;
  denomination: number;
  status: UnitStatus;
  issuanceReference: string;
  currentOwnerReference: string;
  createdAt: string;
  updatedAt: string;
  ledgerStateHash: string;
}

export type TransactionStatus =
  | 'PENDING'
  | 'AUTHORIZED'
  | 'SETTLED'
  | 'FINAL'
  | 'REJECTED'
  | 'REVERSED';

export type PaymentMethod =
  | 'QR'
  | 'NFC'
  | 'API'
  | 'ONLINE'
  | 'DEVICE_TO_DEVICE'
  | 'WHOLESALE_WIRE'
  | 'INTERBANK_SETTLEMENT';

export type PrivacyTier = 'TIER_1_MINIMAL' | 'TIER_2_STANDARD' | 'TIER_3_HIGH_VALUE';

export interface Transaction {
  transactionId: string;
  payerWalletId: string;
  payerAlias: string;
  payeeWalletId: string;
  payeeAlias: string;
  amount: number;
  currency: string;
  timestamp: string;
  nonce: number;
  settlementStatus: TransactionStatus;
  finalityStatus: 'INSTANT' | 'PROBABILISTIC' | 'SETTLED_IN_BLOCK';
  signature: string;
  proofHash: string;
  paymentMethod: PaymentMethod;
  privacyTier: PrivacyTier;
  purpose: string;
  complianceScore: number;
  riskAction: 'ALLOW' | 'STEP_UP' | 'DELAY' | 'REVIEW' | 'SUSPEND' | 'REJECT';
  blockHeight?: number;
}

export interface Block {
  height: number;
  blockHash: string;
  previousHash: string;
  stateRoot: string;
  transactions: Transaction[];
  proposerValidatorId: string;
  proposerName: string;
  timestamp: string;
  signature: string;
}

export interface Validator {
  validatorId: string;
  institutionId: string;
  institutionName: string;
  publicKey: string;
  certificate: string;
  status: 'ACTIVE' | 'STANDBY' | 'SUSPENDED' | 'MAINTENANCE';
  jurisdiction: string;
  permissions: string[];
  blocksProposed: number;
  votingWeight: number;
  latencyMs: number;
}

export type IssuanceStatus = 'PENDING_APPROVAL' | 'APPROVED' | 'EXECUTED' | 'REJECTED';

export interface IssuanceRequest {
  requestId: string;
  authorizedInstitution: string;
  authorizedOfficer: string;
  currency: string;
  amount: number;
  reason: string;
  targetIntermediaryId: string;
  targetIntermediaryName: string;
  status: IssuanceStatus;
  approvals: { officerId: string; officerName: string; timestamp: string; signature: string }[];
  requiredApprovals: number;
  timestamp: string;
  proofHash: string;
}

export interface RedemptionRequest {
  requestId: string;
  intermediaryId: string;
  intermediaryName: string;
  amount: number;
  burnReference: string;
  settlementBankAccount: string;
  status: 'PENDING' | 'COMPLETED' | 'CANCELLED';
  timestamp: string;
}

export type WalletType =
  | 'PERSONAL'
  | 'BUSINESS'
  | 'MERCHANT'
  | 'INSTITUTIONAL'
  | 'GOVERNMENT'
  | 'WHOLESALE'
  | 'OFFLINE';

export interface Wallet {
  walletId: string;
  ownerReference: string;
  ownerName: string;
  walletType: WalletType;
  currency: string;
  balance: number;
  unconfirmedBalance: number;
  limits: {
    maxBalance: number;
    dailyPaymentLimit: number;
    offlineLimit: number;
    usedToday: number;
  };
  status: 'ACTIVE' | 'SUSPENDED' | 'FROZEN_COMPLIANCE' | 'RECOVERY_REQUIRED';
  publicKey: string;
  devices: { deviceId: string; deviceName: string; isHardwareSecured: boolean }[];
  riskProfile: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface Intermediary {
  intermediaryId: string;
  name: string;
  type: 'COMMERCIAL_BANK' | 'PAYMENT_INSTITUTION' | 'LICENSED_WALLET_PROVIDER';
  reserveBalance: number;
  cbdcAllocated: number;
  status: 'ACTIVE' | 'RESTRICTED' | 'UNDER_AUDIT';
  jurisdiction: string;
  activeWalletsCount: number;
}

export interface DvPInstruction {
  dvpId: string;
  securityIsin: string;
  securityName: string;
  units: number;
  pricePerUnit: number;
  totalValue: number;
  buyerWalletId: string;
  sellerWalletId: string;
  settlementStatus: 'PENDING' | 'LEG1_COMMITTED' | 'ATOMICALLY_SETTLED' | 'REJECTED';
  escrowTxId: string;
  timestamp: string;
}

export interface CrossBorderTransfer {
  transferId: string;
  sourceCbdc: string;
  targetCbdc: string;
  sourceAmount: number;
  fxRate: number;
  convertedAmount: number;
  gatewayId: string;
  recipientWalletId: string;
  status: 'INITIATED' | 'FX_LOCKED' | 'GATEWAY_SETTLED' | 'COMPLETED' | 'FAILED';
  timestamp: string;
}

export interface ProgrammableCondition {
  programId: string;
  title: string;
  purpose: string;
  issuer: string;
  conditions: {
    expirationDate: string;
    restrictedCategories: string[];
    maxClaimAmount: number;
    requireDualSign: boolean;
  };
  totalBudget: number;
  disbursedAmount: number;
  activeBeneficiariesCount: number;
  status: 'ACTIVE' | 'EXPIRED' | 'PAUSED';
}

export interface RiskAlert {
  alertId: string;
  transactionId?: string;
  walletId: string;
  riskScore: number;
  triggers: string[];
  recommendedAction: 'ALLOW' | 'STEP_UP' | 'DELAY' | 'REVIEW' | 'SUSPEND' | 'REJECT';
  status: 'OPEN' | 'INVESTIGATING' | 'RESOLVED' | 'DISMISSED';
  timestamp: string;
}

export interface OfflineDeviceWallet {
  deviceId: string;
  walletId: string;
  ownerName: string;
  hardwareSecureElementId: string;
  offlineBalance: number;
  offlineCounter: number;
  maxOfflineLimit: number;
  lastSyncedAt: string;
  syncDeadlineHours: number;
  pendingOfflineTxs: number;
  status: 'SYNCED' | 'PENDING_SYNC' | 'EXCEEDED_DEADLINE' | 'SUSPECTED_TAMPER';
}

export interface ReconciliationRecord {
  reconciliationId: string;
  timestamp: string;
  ledgerTotalIssuance: number;
  ledgerTotalRedemption: number;
  calculatedOutstanding: number;
  actualWalletBalancesSum: number;
  discrepancyAmount: number;
  status: 'BALANCED' | 'BREAK_DETECTED' | 'RESOLVED';
  reconciliationOfficer: string;
}

export interface EmergencyControlState {
  isLedgerPaused: boolean;
  isIssuanceSuspended: boolean;
  isRedemptionSuspended: boolean;
  activeIsolationLevel: 'NORMAL' | 'ELEVATED' | 'LOCKDOWN' | 'EMERGENCY_HALT';
  reason: string;
  initiatedBy: string;
  initiatedAt: string;
}

export interface MonetarySupplyMetrics {
  totalIssued: number;
  totalRedeemed: number;
  totalOutstanding: number;
  activeWallets: number;
  activeIntermediaries: number;
  transactionVolume24h: number;
  transactionValue24h: number;
  settlementValue24h: number;
  offlineValue: number;
  m0ReserveRatio: number;
}
