import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HeaderComponent } from './components/header/header';
import { CommandCenterComponent } from './components/command-center/command-center';
import { CitizenWalletComponent } from './components/citizen-wallet/citizen-wallet';
import { MerchantTerminalComponent } from './components/merchant-terminal/merchant-terminal';
import { ApiExplorerComponent } from './components/api-explorer/api-explorer';
import { DocumentationComponent } from './components/documentation/documentation';
import { CBDCService } from './core/services/cbdc.service';

export type MainView = 'COMMAND' | 'WALLET' | 'MERCHANT' | 'API' | 'DOCS';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    CommandCenterComponent,
    CitizenWalletComponent,
    MerchantTerminalComponent,
    ApiExplorerComponent,
    DocumentationComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  cbdcService = inject(CBDCService);

  currentView = signal<MainView>('COMMAND');

  setView(view: MainView) {
    this.currentView.set(view);
    if (view === 'COMMAND') this.cbdcService.setPersona('CENTRAL_BANK');
    if (view === 'WALLET') this.cbdcService.setPersona('CITIZEN');
    if (view === 'MERCHANT') this.cbdcService.setPersona('MERCHANT');
  }
}
