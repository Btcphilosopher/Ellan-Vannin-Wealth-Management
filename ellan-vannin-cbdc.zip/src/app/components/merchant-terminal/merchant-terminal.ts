import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CBDCService } from '../../core/services/cbdc.service';
import { JurisdictionService } from '../../core/services/jurisdiction.service';

@Component({
  selector: 'app-merchant-terminal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-stone-950 text-stone-100 py-8 px-4 sm:px-6 lg:px-8 font-mono">
      <div class="max-w-xl mx-auto space-y-6">

        <!-- Merchant Header -->
        <div class="bg-stone-900 border border-stone-800 rounded-2xl p-5 flex items-center justify-between">
          <div>
            <span class="text-xs text-stone-400 uppercase">Licensed Merchant POS Terminal</span>
            <h1 class="text-lg font-bold text-stone-100 flex items-center gap-2 mt-0.5">
              <mat-icon class="text-amber-500">storefront</mat-icon>
              Douglas Harbour Groceries & Goods
            </h1>
          </div>
          <div class="text-right text-xs text-stone-400">
            <div>Terminal: <span class="text-amber-400 font-bold">POS-A920-01</span></div>
            <div>Status: <span class="text-emerald-400">ONLINE</span></div>
          </div>
        </div>

        <!-- POS Screen Display -->
        <div class="bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl text-center space-y-6">
          
          <div class="bg-stone-950 p-6 rounded-2xl border border-stone-800 shadow-inner">
            <span class="text-xs text-stone-400 uppercase tracking-widest block mb-1">CHARGE AMOUNT</span>
            <div class="text-5xl font-extrabold text-amber-400">
              {{ jurisdiction.activeConfig().currencySymbol }}{{ displayAmount() }}
            </div>
          </div>

          <!-- Dynamic States: KEYPAD vs READY_FOR_PAYMENT vs PAID -->
          @if (terminalState() === 'KEYPAD') {
            <!-- Keypad -->
            <div class="grid grid-cols-3 gap-3">
              @for (num of keypadNumbers; track num) {
                <button (click)="pressNum(num)" class="py-4 bg-stone-800 hover:bg-stone-700 font-bold text-lg rounded-xl transition-all">
                  {{ num }}
                </button>
              }
              <button (click)="pressClear()" class="py-4 bg-stone-800 hover:bg-rose-950/50 text-rose-400 font-bold text-sm rounded-xl">
                CLEAR
              </button>
              <button (click)="pressNum(0)" class="py-4 bg-stone-800 hover:bg-stone-700 font-bold text-lg rounded-xl">
                0
              </button>
              <button (click)="pressDot()" class="py-4 bg-stone-800 hover:bg-stone-700 font-bold text-lg rounded-xl">
                .
              </button>
            </div>

            <button
              (click)="generatePaymentQR()"
              [disabled]="amountNum() <= 0"
              class="w-full py-4 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-stone-950 font-bold text-sm rounded-xl transition-all flex items-center justify-center gap-2"
            >
              <mat-icon>qr_code_2</mat-icon>
              GENERATE PAYMENT QR & LISTENER
            </button>
          }

          @if (terminalState() === 'WAITING') {
            <div class="space-y-4 py-4">
              <div class="p-6 bg-white rounded-2xl inline-block shadow-inner mx-auto">
                <mat-icon class="text-7xl text-stone-950 animate-pulse">qr_code_2</mat-icon>
              </div>

              <div class="text-xs text-amber-400 font-bold animate-pulse flex items-center justify-center gap-2">
                <mat-icon class="text-sm">nfc</mat-icon>
                TAP NFC DEVICE OR SCAN QR TO PAY
              </div>

              <div class="flex justify-center space-x-3 pt-2">
                <button (click)="pressClear()" class="px-4 py-2 bg-stone-800 text-stone-300 text-xs rounded-xl">
                  CANCEL
                </button>
                <button (click)="simulateCustomerPay()" class="px-4 py-2 bg-emerald-600 text-stone-950 font-bold text-xs rounded-xl">
                  SIMULATE CUSTOMER TAP
                </button>
              </div>
            </div>
          }

          @if (terminalState() === 'SUCCESS') {
            <div class="space-y-4 py-4 bg-emerald-950/40 border border-emerald-800/50 rounded-2xl p-6">
              <div class="w-16 h-16 bg-emerald-500 text-stone-950 rounded-full flex items-center justify-center mx-auto shadow-lg">
                <mat-icon class="text-3xl font-bold">check</mat-icon>
              </div>

              <h2 class="text-xl font-bold text-emerald-400">SETTLEMENT FINALIZED</h2>
              <p class="text-xs text-stone-300">
                Payment of {{ jurisdiction.activeConfig().currencySymbol }}{{ displayAmount() }} received with instant finality.
              </p>

              <div class="text-[10px] text-stone-400 break-all bg-stone-950 p-2.5 rounded-lg border border-stone-800 text-left space-y-1">
                <div>Proof Hash: <span class="text-stone-200">0x7a2f1b402c91834910283401290348</span></div>
                <div>Block Height: <span class="text-amber-400">#{{ cbdcService.ledgerHeight() }}</span></div>
              </div>

              <button (click)="pressClear()" class="w-full py-3 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs rounded-xl">
                NEW POS TRANSACTION
              </button>
            </div>
          }

        </div>

        <!-- End of Day Batch Settlement -->
        <div class="bg-stone-900 border border-stone-800 rounded-2xl p-5 flex items-center justify-between text-xs">
          <div>
            <div class="font-bold text-stone-200">END-OF-DAY BATCH SETTLEMENT</div>
            <p class="text-stone-400 mt-0.5">Sweep merchant CBDC balance to Commercial Bank Reserve account.</p>
          </div>
          <button (click)="cbdcService.runReconciliation()" class="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-amber-400 font-bold rounded-xl border border-stone-700">
            SWEEP BALANCE
          </button>
        </div>

      </div>
    </div>
  `,
})
export class MerchantTerminalComponent {
  cbdcService = inject(CBDCService);
  jurisdiction = inject(JurisdictionService);

  readonly keypadNumbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];

  displayAmount = signal<string>('0.00');
  amountNum = signal<number>(0);
  terminalState = signal<'KEYPAD' | 'WAITING' | 'SUCCESS'>('KEYPAD');

  pressNum(num: number) {
    let curr = this.displayAmount();
    if (curr === '0.00' || curr === '0') {
      curr = num.toString();
    } else {
      curr += num.toString();
    }
    this.displayAmount.set(curr);
    this.amountNum.set(parseFloat(curr) || 0);
  }

  pressDot() {
    let curr = this.displayAmount();
    if (!curr.includes('.')) {
      curr += '.';
      this.displayAmount.set(curr);
    }
  }

  pressClear() {
    this.displayAmount.set('0.00');
    this.amountNum.set(0);
    this.terminalState.set('KEYPAD');
  }

  generatePaymentQR() {
    this.terminalState.set('WAITING');
  }

  simulateCustomerPay() {
    const amount = this.amountNum();
    const result = this.cbdcService.executePayment(
      'WAL-CIT-001',
      'WAL-MER-002',
      amount,
      'Douglas Groceries POS Purchase',
      'NFC',
      'TIER_1_MINIMAL'
    );

    if (result.success) {
      this.terminalState.set('SUCCESS');
    }
  }
}
