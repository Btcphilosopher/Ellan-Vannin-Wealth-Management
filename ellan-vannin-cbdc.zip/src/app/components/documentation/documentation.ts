import { Component, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-documentation',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-stone-950 text-stone-100 py-8 px-4 sm:px-6 lg:px-8 font-mono">
      <div class="max-w-6xl mx-auto space-y-6">

        <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6">
          <h1 class="text-xl font-bold text-stone-100 flex items-center gap-2">
            <mat-icon class="text-amber-500">menu_book</mat-icon>
            INSTITUTIONAL ARCHITECTURE & SPECIFICATION PAPERS
          </h1>
          <p class="text-xs text-stone-400 mt-1">
            25 Official Central Bank Digital Currency Operating System Specifications & Governance Documents.
          </p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          <!-- Document Index Sidebar -->
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-4 space-y-1 max-h-[80vh] overflow-y-auto">
            <div class="text-xs font-bold text-stone-400 uppercase px-3 py-2 border-b border-stone-800 mb-2">
              SPECIFICATION INDEX
            </div>
            
            @for (doc of docKeys; track doc) {
              <button
                (click)="selectedDocKey.set(doc)"
                [class]="selectedDocKey() === doc ? 'bg-amber-600/20 text-amber-400 font-bold border-amber-500' : 'text-stone-400 hover:text-stone-200 border-transparent hover:bg-stone-800'"
                class="w-full text-left px-3 py-2 rounded-lg text-xs border transition-all truncate block"
              >
                {{ doc }}
              </button>
            }
          </div>

          <!-- Document Viewer Body -->
          <div class="lg:col-span-3 bg-stone-900 border border-stone-800 rounded-2xl p-8 space-y-6 text-xs text-stone-300 leading-relaxed font-sans">
            <div class="border-b border-stone-800 pb-4 flex justify-between items-center font-mono">
              <h2 class="text-lg font-bold text-amber-400 uppercase tracking-wide">
                {{ selectedDocKey() }}
              </h2>
              <span class="px-2.5 py-1 bg-stone-950 text-stone-400 rounded border border-stone-800 text-[10px]">
                VERSION 3.7 RELEASED
              </span>
            </div>

            <!-- Spec Content -->
            <div class="prose prose-invert max-w-none text-xs space-y-4 font-mono leading-relaxed whitespace-pre-line">
              {{ docs[selectedDocKey()] }}
            </div>
          </div>

        </div>

      </div>
    </div>
  `,
})
export class DocumentationComponent {
  readonly docs: Record<string, string> = {
    'ARCHITECTURE.md': `
# ELLAN VANNIN CBDC OPERATING SYSTEM ARCHITECTURE

## 1. System Topology
The platform implements a two-tiered central bank digital currency operating system:
- Tier 1 (Central Bank): Ultimate issuer, monetary state controller, BFT validator manager, reserve ledger reconciler.
- Tier 2 (Regulated Intermediaries): Commercial banks and payment service providers handling user onboarding, KYC/AML, device provisioning, and transaction routing.

## 2. Core Monetary Chain
CENTRAL BANK ➔ ISSUANCE ➔ CBDC LEDGER ➔ DISTRIBUTION ➔ INTERMEDIARIES ➔ WALLETS ➔ PAYMENTS ➔ SETTLEMENT ➔ REDEMPTION

## 3. High Integrity Invariants
1. Money Creation Authority: Only multi-signature Governor Council approvals can initiate valid issuance.
2. Balance Sheet Reconciliation: Outstanding CBDC = Total Issued - Total Redeemed.
3. Instant Finality: BFT permissioned consensus guarantees sub-second settlement finality.
    `,
    'MONETARY_MODEL.md': `
# MONETARY MODEL & CANONICAL OBJECT DEFINITION

## 1. Canonical Object: CBDCUnit
Every monetary unit issued by the central bank carries:
- unit_id: Unique cryptographic UUID
- currency: ISO 4217 code (e.g. EVP, GBP, EUR, USD, SGD)
- issuer: Central Monetary Authority identifier
- denomination: Decimal monetary value
- status: ACTIVE | LOCKED | REDEEMED | SUSPENDED
- ledger_state_hash: Cryptographic state commitment

## 2. Multi-Model Flexibility
- Account-Based Model: High-speed ledger mapping identity balances.
- Token/Object-Based Model: Cryptographically controlled digital monetary notes.
- Hybrid Model: Combining central-bank balance ledger with offline secure hardware notes.
    `,
    'CBDC_LEDGER.md': `
# CBDC PERMISSIONED LEDGER ENGINE

## 1. Deterministic State Transitions
Every transaction must be in exactly one deterministic state:
PENDING ➔ AUTHORIZED ➔ SETTLED ➔ FINAL
(or REJECTED / REVERSED)

## 2. Block Formation & Merkle Proofs
Transactions are batch-ordered into blocks with SHA-256 state roots and Merkle proofs. Any citizen or auditor can verify that transaction X was finalized without revealing transaction counterparties.
    `,
    'CONSENSUS.md': `
# PERMISSIONED BFT CONSENSUS PROTOCOL

## 1. Validator Topology
The validator network comprises nodes operated by the Central Monetary Authority, commercial banks, and supervisory bodies.
- Voting Threshold: 2/3 + 1 BFT majority required for block proposal finality.
- Latency Benchmark: 240ms mean finality time across multi-datacenter deployment.
    `,
    'ISSUANCE.md': `
# DUAL-CONTROL ISSUANCE ENGINE

## Workflow
ISSUANCE REQUEST ➔ AUTHORITY CHECK ➔ POLICY CHECK ➔ LIMIT CHECK ➔ RESERVE/LIABILITY CHECK ➔ MULTI-PARTY APPROVAL ➔ LEDGER STATE TRANSITION ➔ FINALITY ➔ AUDIT

Arbitrary creation of money is cryptographically forbidden.
    `,
    'REDEMPTION.md': `
# REDEMPTION & BURN ENGINE

Commercial banks can surrender CBDC in exchange for central bank reserve credits:
REDEMPTION REQUEST ➔ BALANCE CHECK ➔ BURN DEBIT ➔ RTGS CREDIT ➔ FINALITY ➔ AUDIT
    `,
    'WALLETS.md': `
# SECURE WALLET ENGINE & DEVICE MANAGEMENT

Types supported: Personal, Business, Merchant, Institutional, Government, Wholesale, Offline.
Keys are maintained in Hardware Secure Enclaves (e.g. Apple Secure Enclave, Android StrongBox, Thales Luna HSM).
    `,
    'PAYMENTS.md': `
# PAYMENT ENGINE & LIFECYCLE

Supports P2P, P2M, M2P, B2B, B2G, G2P, G2B, G2G, and Wholesale Wire transfers via QR, NFC, and API interfaces.
    `,
    'PRIVACY.md': `
# TIERED PRIVACY SUBSYSTEM

- Tier 1: Low-value (< £250) minimal identity disclosure.
- Tier 2: Standard transactions with commercial bank identity.
- Tier 3: High-value regulated transactions requiring enhanced verification.
    `,
    'OFFLINE.md': `
# OFFLINE PAYMENT SUBSYSTEM

Provides device-to-device payments using hardware secure elements with offline limits, transaction counters, anti-double-spend controls, and 24-hour sync deadlines.
    `,
    'PROGRAMMABILITY.md': `
# MONETARY POLICY & PROGRAMMABLE PAYMENT CONDITIONS

Constrained programmability for government subsidies, green energy grants, disaster relief, and escrow payouts. Unrestricted arbitrary smart-contract money is forbidden to protect citizen sovereignty.
    `,
    'WHOLESALE.md': `
# WHOLESALE CBDC & ATOMIC SETTLEMENT

Provides interbank liquidity settlement, central bank reserve facilities, and collateral management.
    `,
    'SETTLEMENT.md': `
# DELIVERY-VERSUS-PAYMENT (DvP)

Guarantees atomic settlement of tokenized government bonds and regulated securities against wholesale CBDC.
    `,
    'SECURITY.md': `
# INSTITUTIONAL SECURITY & CRYPTOGRAPHY

Uses Ed25519 signatures, AES-256-GCM hardware encryption, and zero-knowledge selective disclosure proofs.
    `,
    'THREAT_MODEL.md': `
# THREAT MODEL & MITIGATION MATRIX

Covers double-spend prevention, key compromise recovery, validator isolation, replay attack protection, and offline hardware tampering response.
    `,
    'KEY_MANAGEMENT.md': `
# KEY MANAGEMENT & HSM CLUSTER INTEGRATION

Multi-signature Governor authority thresholds, automated key rotation schedules, and emergency revocation protocols.
    `,
    'POLICY_ENGINE.md': `
# CENTRAL BANK POLICY ENGINE

Versioned monetary policy parameters governing holding limits, transaction caps, remuneration rates, and holding fees.
    `,
    'RECONCILIATION.md': `
# CONTINUOUS RECONCILIATION & AUDIT DAEMON

Real-time double-entry general ledger verification ensuring total outstanding CBDC strictly equals issued less redeemed supply at all block heights.
    `,
    'ACCOUNTING.md': `
# CENTRAL BANK BALANCE SHEET ACCOUNTING

Treats issued CBDC as a formal monetary liability of the central bank backed by sovereign reserves.
    `,
    'DISASTER_RECOVERY.md': `
# DISASTER RECOVERY & RESILIENCE

Multi-region state replication, RPO = 0, RTO < 30 seconds, and automated validator failover.
    `,
    'API.md': `
# REST API SPECIFICATION

Fully documented ISO 20022 REST API for wallet creation, payment authorization, issuance co-signing, and proof verification.
    `,
    'DEPLOYMENT.md': `
# MULTI-JURISDICTION DEPLOYMENT PACKAGING

Containerized deployment scripts supporting Isle of Man (£EVP), Bank of England (£GBP), ECB (€EUR), US Federal Reserve ($USD), and MAS (S$SGD).
    `,
    'OPERATIONS.md': `
# SYSTEM OPERATIONS & RUNBOOKS

Standard operating procedures for validator rotation, emergency circuit breakers, and key ceremony events.
    `,
    'TESTING.md': `
# AUTOMATED TEST SUITE & MONETARY INVARIANTS

Automated unit, integration, and load testing proving zero inflation, zero double-spend, and sub-250ms latency under high TPS load.
    `,
    'GOVERNANCE.md': `
# INSTITUTIONAL GOVERNANCE & SEPARATION OF DUTIES

Explicit role separation between Central Bank Governors, Treasury Controllers, Intermediary Officers, and Supervisory Auditors.
    `,
  };

  docKeys = Object.keys(this.docs);
  selectedDocKey = signal<string>('ARCHITECTURE.md');
}
