import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { JurisdictionService } from '../../core/services/jurisdiction.service';
import { CBDCService } from '../../core/services/cbdc.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-stone-900 border-b border-stone-800 py-3.5 px-4 sm:px-6 lg:px-8 shadow-lg">
      <div class="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">

        <!-- Sovereign Brand Identity -->
        <div class="flex items-center space-x-3">
          <div class="w-10 h-10 rounded-xl bg-amber-600 text-stone-950 flex items-center justify-center font-bold text-lg font-mono shadow-md">
            EV
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h1 class="text-base font-extrabold font-mono text-stone-100 tracking-tight">
                ELLAN VANNIN CBDC
              </h1>
              <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-950 text-amber-400 border border-amber-800/80">
                SOVEREIGN OS
              </span>
            </div>
            <p class="text-[11px] font-mono text-stone-400">
              Central Bank Digital Currency Infrastructure • {{ jurisdictionService.activeConfig().name }}
            </p>
          </div>
        </div>

        <!-- Controls: Jurisdiction Switcher & Persona Selector -->
        <div class="flex flex-wrap items-center gap-3 text-xs font-mono">

          <!-- Jurisdiction Switcher -->
          <div class="flex items-center space-x-2 bg-stone-950 p-1.5 rounded-xl border border-stone-800">
            <mat-icon class="text-amber-500 text-sm ml-1">public</mat-icon>
            <label for="jurisdiction-select" class="sr-only">Select Jurisdiction Framework</label>
            <select
              id="jurisdiction-select"
              [ngModel]="jurisdictionService.activeJurisdiction()"
              (ngModelChange)="jurisdictionService.setJurisdiction($event)"
              class="bg-transparent text-stone-200 text-xs font-mono focus:outline-none pr-2 cursor-pointer"
            >
              <option value="IOM">Isle of Man (£EVP)</option>
              <option value="BOE">Bank of England (£GBP)</option>
              <option value="ECB">ECB Eurosystem (€EUR)</option>
              <option value="FED">US Federal Reserve ($USD)</option>
              <option value="MAS">MAS Singapore (S$SGD)</option>
            </select>
          </div>

          <!-- Active Persona Switcher -->
          <div class="flex items-center space-x-1 bg-stone-950 p-1 rounded-xl border border-stone-800">
            @for (p of personas; track p.id) {
              <button
                (click)="cbdcService.setPersona(p.id)"
                [class]="cbdcService.activePersona() === p.id 
                  ? 'bg-amber-600 text-stone-950 font-bold' 
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'"
                class="px-2.5 py-1 rounded-lg text-[11px] transition-all flex items-center gap-1"
              >
                <mat-icon class="text-xs">{{ p.icon }}</mat-icon>
                <span>{{ p.label }}</span>
              </button>
            }
          </div>

        </div>

      </div>
    </header>
  `,
})
export class HeaderComponent {
  jurisdictionService = inject(JurisdictionService);
  cbdcService = inject(CBDCService);

  readonly personas = [
    { id: 'CENTRAL_BANK' as const, label: 'Central Bank', icon: 'account_balance' },
    { id: 'INTERMEDIARY' as const, label: 'Bank', icon: 'domain' },
    { id: 'CITIZEN' as const, label: 'Citizen', icon: 'person' },
    { id: 'MERCHANT' as const, label: 'Merchant', icon: 'storefront' },
    { id: 'AUDITOR' as const, label: 'Auditor', icon: 'verified' },
  ];
}
