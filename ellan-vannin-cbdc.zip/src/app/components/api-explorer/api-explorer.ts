import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-api-explorer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-stone-950 text-stone-100 py-8 px-4 sm:px-6 lg:px-8 font-mono">
      <div class="max-w-5xl mx-auto space-y-6">

        <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6">
          <h1 class="text-xl font-bold text-stone-100 flex items-center gap-2">
            <mat-icon class="text-amber-500">api</mat-icon>
            INSTITUTIONAL CBDC DEVELOPER REST API PORTAL
          </h1>
          <p class="text-xs text-stone-400 mt-1">
            Open standard ISO 20022 compliant REST API for central bank monitoring, wallet management, and payment execution.
          </p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          <!-- Endpoint List -->
          <div class="space-y-2">
            @for (ep of endpoints; track ep.path) {
              <button
                type="button"
                (click)="selectEndpoint(ep)"
                [class]="selectedEp().path === ep.path ? 'border-amber-500 bg-amber-950/20 text-amber-300' : 'border-stone-800 bg-stone-900 text-stone-300 hover:border-stone-700'"
                class="w-full text-left p-3.5 rounded-xl border text-xs cursor-pointer transition-all space-y-1 block"
              >
                <div class="flex items-center justify-between">
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-stone-950 text-amber-400 border border-stone-800">
                    {{ ep.method }}
                  </span>
                  <span class="text-[10px] text-stone-500">v1.0</span>
                </div>
                <div class="font-bold text-stone-100">{{ ep.path }}</div>
                <p class="text-[11px] text-stone-400">{{ ep.description }}</p>
              </button>
            }
          </div>

          <!-- Runner Panel -->
          <div class="lg:col-span-2 bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4 text-xs">
            <div class="flex items-center justify-between border-b border-stone-800 pb-3">
              <div class="flex items-center gap-2 font-bold text-stone-200">
                <span class="px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800 text-[10px]">
                  {{ selectedEp().method }}
                </span>
                <span>{{ selectedEp().path }}</span>
              </div>

              <button
                (click)="executeApiCall()"
                class="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold rounded-xl transition-all flex items-center gap-1.5"
              >
                <mat-icon class="text-sm">play_arrow</mat-icon>
                EXECUTE REQUEST
              </button>
            </div>

            <!-- Request Headers & Auth -->
            <div class="bg-stone-950 p-3 rounded-xl border border-stone-800 text-[11px] space-y-1 text-stone-400">
              <div>Authorization: <span class="text-emerald-400">Bearer cma_live_token_88910248</span></div>
              <div>Content-Type: <span class="text-stone-200">application/json</span></div>
            </div>

            <!-- JSON Output Window -->
            <div class="space-y-1">
              <span class="text-stone-400 text-[11px] font-bold">RESPONSE DATA (HTTP 200 OK)</span>
              <pre class="bg-stone-950 p-4 rounded-xl border border-stone-800 text-emerald-400 overflow-x-auto text-[11px] max-h-96">
{{ apiResponse() }}
              </pre>
            </div>
          </div>

        </div>

      </div>
    </div>
  `,
})
export class ApiExplorerComponent {
  private http = inject(HttpClient);

  readonly endpoints = [
    { method: 'GET', path: '/api/cbdc/v1/status', description: 'Real-time monetary supply, consensus status, and ledger height' },
    { method: 'GET', path: '/api/cbdc/v1/issuance', description: 'Retrieve issuance requests and multi-party signature logs' },
    { method: 'GET', path: '/api/cbdc/v1/wallets', description: 'Query active institutional, merchant, and retail CBDC wallets' },
    { method: 'GET', path: '/api/cbdc/v1/payments', description: 'Query payment transaction audit trail and proof hashes' },
  ];

  selectedEp = signal(this.endpoints[0]);
  apiResponse = signal<string>('Click EXECUTE REQUEST to run live REST API query...');

  selectEndpoint(ep: typeof this.endpoints[0]) {
    this.selectedEp.set(ep);
    this.executeApiCall();
  }

  executeApiCall() {
    this.apiResponse.set('Loading response from CBDC Express backend...');
    this.http.get(this.selectedEp().path).subscribe({
      next: (res) => {
        this.apiResponse.set(JSON.stringify(res, null, 2));
      },
      error: (err) => {
        this.apiResponse.set(JSON.stringify(err, null, 2));
      },
    });
  }
}
