import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { CBDCService } from '../../core/services/cbdc.service';
import { JurisdictionService } from '../../core/services/jurisdiction.service';

export type CentralBankTab =
  | 'OVERVIEW'
  | 'ISSUANCE'
  | 'LEDGER'
  | 'VALIDATORS'
  | 'INTERMEDIARIES'
  | 'PROGRAMMABLE'
  | 'WHOLESALE'
  | 'OFFLINE'
  | 'RECONCILIATION'
  | 'EMERGENCY';

@Component({
  selector: 'app-command-center',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-stone-950 text-stone-100 py-6 px-4 sm:px-6 lg:px-8 font-mono">
      <div class="max-w-7xl mx-auto space-y-6">

        <!-- Top Navigation Bar for Central Bank Engine -->
        <div class="bg-stone-900 border border-stone-800 p-2 rounded-2xl flex flex-wrap gap-1 text-xs">
          @for (tab of tabs; track tab.id) {
            <button
              (click)="activeTab.set(tab.id)"
              [class]="activeTab() === tab.id 
                ? 'bg-amber-600 text-stone-950 font-bold shadow-md' 
                : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'"
              class="px-3 py-2 rounded-xl transition-all flex items-center gap-1.5"
            >
              <mat-icon class="text-sm">{{ tab.icon }}</mat-icon>
              <span>{{ tab.label }}</span>
            </button>
          }
        </div>

        <!-- TAB 1: OVERVIEW & MONETARY METRICS -->
        @if (activeTab() === 'OVERVIEW') {
          <div class="space-y-6">
            
            <!-- Key Monetary Supply KPI Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              <div class="bg-stone-900 border border-stone-800 p-5 rounded-2xl space-y-2 relative overflow-hidden">
                <span class="text-xs text-stone-400 uppercase tracking-wider block">TOTAL ISSUED SUPPLY</span>
                <div class="text-2xl font-extrabold text-amber-400">
                  {{ jurisdiction.activeConfig().currencySymbol }}{{ cbdcService.supplyMetrics().totalIssued | number }}
                </div>
                <div class="text-[11px] text-stone-400 flex items-center justify-between pt-1">
                  <span>M0 Reserve Ratio:</span>
                  <span class="text-emerald-400 font-bold">100% Backed</span>
                </div>
              </div>

              <div class="bg-stone-900 border border-stone-800 p-5 rounded-2xl space-y-2">
                <span class="text-xs text-stone-400 uppercase tracking-wider block">NET OUTSTANDING</span>
                <div class="text-2xl font-extrabold text-stone-100">
                  {{ jurisdiction.activeConfig().currencySymbol }}{{ cbdcService.supplyMetrics().totalOutstanding | number }}
                </div>
                <div class="text-[11px] text-stone-400 flex items-center justify-between pt-1">
                  <span>Redeemed (Burned):</span>
                  <span class="text-rose-400 font-bold">{{ jurisdiction.activeConfig().currencySymbol }}{{ cbdcService.supplyMetrics().totalRedeemed | number }}</span>
                </div>
              </div>

              <div class="bg-stone-900 border border-stone-800 p-5 rounded-2xl space-y-2">
                <span class="text-xs text-stone-400 uppercase tracking-wider block">ACTIVE WALLETS & BANKS</span>
                <div class="text-2xl font-extrabold text-amber-400">
                  {{ cbdcService.supplyMetrics().activeWallets | number }}
                </div>
                <div class="text-[11px] text-stone-400 flex items-center justify-between pt-1">
                  <span>Intermediary Banks:</span>
                  <span class="text-stone-200 font-bold">{{ cbdcService.supplyMetrics().activeIntermediaries }} Tier-2 Institutions</span>
                </div>
              </div>

              <div class="bg-stone-900 border border-stone-800 p-5 rounded-2xl space-y-2">
                <span class="text-xs text-stone-400 uppercase tracking-wider block">24H VOLUME & TPS</span>
                <div class="text-2xl font-extrabold text-emerald-400">
                  {{ jurisdiction.activeConfig().currencySymbol }}{{ cbdcService.supplyMetrics().transactionValue24h | number }}
                </div>
                <div class="text-[11px] text-stone-400 flex items-center justify-between pt-1">
                  <span>24h Transactions:</span>
                  <span class="text-stone-200 font-bold">{{ cbdcService.supplyMetrics().transactionVolume24h | number }} Txs</span>
                </div>
              </div>

            </div>

            <!-- Ledger Status & Topology Snapshot -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              <!-- Ledger Height & BFT Consensus -->
              <div class="lg:col-span-2 bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4">
                <div class="flex items-center justify-between border-b border-stone-800 pb-3">
                  <h2 class="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2">
                    <mat-icon class="text-amber-500">grid_view</mat-icon>
                    BFT CONSENSUS & LEDGER STATE MACHINE
                  </h2>
                  <span class="px-2.5 py-1 bg-emerald-950 text-emerald-400 text-[11px] font-bold rounded-lg border border-emerald-800">
                    BFT FINALITY ACTIVE (240ms)
                  </span>
                </div>

                <div class="grid grid-cols-3 gap-4 text-xs">
                  <div class="p-3 bg-stone-950 rounded-xl border border-stone-800">
                    <span class="text-stone-400">Current Block Height:</span>
                    <div class="text-lg font-bold text-amber-400 mt-1">#{{ cbdcService.ledgerHeight() }}</div>
                  </div>
                  <div class="p-3 bg-stone-950 rounded-xl border border-stone-800">
                    <span class="text-stone-400">Validator Nodes:</span>
                    <div class="text-lg font-bold text-stone-100 mt-1">{{ cbdcService.validators().length }} Active Nodes</div>
                  </div>
                  <div class="p-3 bg-stone-950 rounded-xl border border-stone-800">
                    <span class="text-stone-400">Consensus Engine:</span>
                    <div class="text-lg font-bold text-emerald-400 mt-1">PBFT 2/3+1</div>
                  </div>
                </div>

                <!-- Latest Blocks -->
                <div class="space-y-2 pt-2">
                  <span class="text-xs text-stone-400 font-bold uppercase block">LATEST FINALIZED BLOCKS</span>
                  @for (block of cbdcService.blocks(); track block.height) {
                    <div class="p-3 bg-stone-950 rounded-xl border border-stone-800 flex items-center justify-between text-xs">
                      <div>
                        <div class="font-bold text-amber-400">Block #{{ block.height }}</div>
                        <div class="text-[11px] text-stone-400 truncate max-w-md">Proposer: {{ block.proposerName }}</div>
                      </div>
                      <div class="text-right text-[11px]">
                        <div class="text-stone-300">{{ block.transactions.length }} Tx(s)</div>
                        <div class="text-stone-500">{{ block.timestamp | date:'shortTime' }}</div>
                      </div>
                    </div>
                  }
                </div>
              </div>

              <!-- Quick Operations Panel -->
              <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4">
                <h2 class="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2 border-b border-stone-800 pb-3">
                  <mat-icon class="text-amber-500">flash_on</mat-icon>
                  EXECUTIVE GOVERNANCE ACTIONS
                </h2>

                <div class="space-y-3">
                  <button
                    (click)="activeTab.set('ISSUANCE')"
                    class="w-full py-3 px-4 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs rounded-xl transition-all text-left flex items-center justify-between"
                  >
                    <span>INITIATE MONETARY ISSUANCE</span>
                    <mat-icon>arrow_forward</mat-icon>
                  </button>

                  <button
                    (click)="cbdcService.runReconciliation()"
                    class="w-full py-3 px-4 bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs rounded-xl transition-all text-left flex items-center justify-between border border-stone-700"
                  >
                    <span>RUN AUDIT RECONCILIATION</span>
                    <mat-icon class="text-amber-500">fact_check</mat-icon>
                  </button>

                  <button
                    (click)="activeTab.set('EMERGENCY')"
                    class="w-full py-3 px-4 bg-rose-950/60 hover:bg-rose-900 text-rose-300 font-bold text-xs rounded-xl transition-all text-left flex items-center justify-between border border-rose-800"
                  >
                    <span>EMERGENCY PAUSE CIRCUIT BREAKER</span>
                    <mat-icon class="text-rose-400">warning</mat-icon>
                  </button>
                </div>
              </div>

            </div>

          </div>
        }

        <!-- TAB 2: ISSUANCE ENGINE -->
        @if (activeTab() === 'ISSUANCE') {
          <div class="space-y-6">
            
            <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4">
              <div class="flex items-center justify-between border-b border-stone-800 pb-3">
                <div>
                  <h2 class="text-base font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2">
                    <mat-icon class="text-amber-500">add_card</mat-icon>
                    DUAL-CONTROL MONETARY ISSUANCE ENGINE
                  </h2>
                  <p class="text-xs text-stone-400 mt-0.5">
                    Requires 2-of-2 Central Bank Governor cryptographic co-signatures. Arbitrary money printing is mathematically impossible.
                  </p>
                </div>
                <button
                  (click)="showCreateIssuanceModal.set(true)"
                  class="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5"
                >
                  <mat-icon>add</mat-icon>
                  NEW ISSUANCE REQUEST
                </button>
              </div>

              <div class="space-y-3">
                @for (req of cbdcService.issuanceRequests(); track req.requestId) {
                  <div class="bg-stone-950 border border-stone-800 rounded-xl p-4 text-xs space-y-3">
                    <div class="flex items-center justify-between">
                      <div class="flex items-center gap-2">
                        <span class="font-bold text-amber-400">{{ req.requestId }}</span>
                        <span class="text-stone-400">• {{ req.targetIntermediaryName }}</span>
                      </div>
                      <span [class]="req.status === 'EXECUTED' ? 'bg-emerald-950 text-emerald-400 border-emerald-800' : 'bg-amber-950 text-amber-400 border-amber-800'" class="px-2.5 py-0.5 rounded text-[10px] font-bold border">
                        {{ req.status }}
                      </span>
                    </div>

                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-stone-300">
                      <div>
                        <span class="text-stone-500 block">Amount:</span>
                        <span class="font-bold text-stone-100 text-sm">{{ jurisdiction.activeConfig().currencySymbol }}{{ req.amount | number }}</span>
                      </div>
                      <div>
                        <span class="text-stone-500 block">Initiating Officer:</span>
                        <span>{{ req.authorizedOfficer }}</span>
                      </div>
                      <div>
                        <span class="text-stone-500 block">Signatures Progress:</span>
                        <span class="text-amber-400 font-bold">{{ req.approvals.length }} / {{ req.requiredApprovals }} Co-signs</span>
                      </div>
                      <div>
                        <span class="text-stone-500 block">Proof Hash:</span>
                        <span class="text-stone-400 text-[10px] truncate block">{{ req.proofHash }}</span>
                      </div>
                    </div>

                    <div class="text-stone-400 text-[11px] bg-stone-900 p-2 rounded border border-stone-800">
                      <span class="font-bold text-stone-300">Monetary Justification:</span> {{ req.reason }}
                    </div>

                    @if (req.status === 'PENDING_APPROVAL') {
                      <div class="flex justify-end pt-2 border-t border-stone-900">
                        <button
                          (click)="approveIssuance(req.requestId)"
                          class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-stone-950 font-bold rounded-lg transition-all text-xs"
                        >
                          CO-SIGN AS SECOND GOVERNOR
                        </button>
                      </div>
                    }
                  </div>
                }
              </div>
            </div>

          </div>
        }

        <!-- TAB 3: LEDGER EXPLORER -->
        @if (activeTab() === 'LEDGER') {
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4">
            <h2 class="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2 border-b border-stone-800 pb-3">
              <mat-icon class="text-amber-500">manage_search</mat-icon>
              IMMUTABLE PERMISSIONED CBDC LEDGER AUDIT TRAIL
            </h2>

            <div class="space-y-3 font-mono text-xs">
              @for (tx of cbdcService.transactions(); track tx.transactionId) {
                <div class="bg-stone-950 border border-stone-800 rounded-xl p-4 space-y-2">
                  <div class="flex items-center justify-between">
                    <div class="flex items-center gap-2">
                      <span class="font-bold text-amber-400">{{ tx.transactionId }}</span>
                      <span class="text-stone-400 text-[11px]">Block #{{ tx.blockHeight }}</span>
                    </div>
                    <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] border border-emerald-800 font-bold">
                      INSTANT SETTLED
                    </span>
                  </div>

                  <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-stone-300">
                    <div>
                      <span class="text-stone-500 block">Payer:</span>
                      <span class="font-bold text-stone-200">{{ tx.payerAlias }}</span>
                    </div>
                    <div>
                      <span class="text-stone-500 block">Payee:</span>
                      <span class="font-bold text-stone-200">{{ tx.payeeAlias }}</span>
                    </div>
                    <div>
                      <span class="text-stone-500 block">Amount:</span>
                      <span class="font-bold text-amber-400 text-sm">{{ jurisdiction.activeConfig().currencySymbol }}{{ tx.amount | number:'1.2-2' }}</span>
                    </div>
                    <div>
                      <span class="text-stone-500 block">Privacy Tier:</span>
                      <span class="text-stone-300">{{ tx.privacyTier }}</span>
                    </div>
                  </div>

                  <div class="text-[10px] text-stone-500 bg-stone-900 p-2 rounded border border-stone-800 break-all">
                    <span>Cryptographic Proof: {{ tx.proofHash }}</span>
                  </div>
                </div>
              }
            </div>
          </div>
        }

        <!-- TAB 4: VALIDATORS -->
        @if (activeTab() === 'VALIDATORS') {
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4 text-xs font-mono">
            <h2 class="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2 border-b border-stone-800 pb-3">
              <mat-icon class="text-amber-500">security</mat-icon>
              PERMISSIONED BFT VALIDATOR NODES TOPOLOGY
            </h2>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              @for (val of cbdcService.validators(); track val.validatorId) {
                <div class="bg-stone-950 border border-stone-800 rounded-xl p-4 space-y-2">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-amber-400">{{ val.institutionName }}</span>
                    <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] border border-emerald-800">
                      {{ val.status }}
                    </span>
                  </div>

                  <div class="text-stone-400 space-y-1">
                    <div>Jurisdiction: <span class="text-stone-200">{{ val.jurisdiction }}</span></div>
                    <div>Voting Weight: <span class="text-amber-400 font-bold">{{ val.votingWeight }}%</span></div>
                    <div>Latency: <span class="text-emerald-400 font-bold">{{ val.latencyMs }}ms</span></div>
                    <div>Certificate: <span class="text-stone-300 text-[11px]">{{ val.certificate }}</span></div>
                  </div>
                </div>
              }
            </div>
          </div>
        }

        <!-- TAB 5: INTERMEDIARIES -->
        @if (activeTab() === 'INTERMEDIARIES') {
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4 text-xs font-mono">
            <h2 class="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2 border-b border-stone-800 pb-3">
              <mat-icon class="text-amber-500">domain</mat-icon>
              TIER-2 REGULATED FINANCIAL INTERMEDIARIES
            </h2>

            <div class="space-y-3">
              @for (bank of cbdcService.intermediaries(); track bank.intermediaryId) {
                <div class="bg-stone-950 border border-stone-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div class="font-bold text-stone-100 text-sm">{{ bank.name }}</div>
                    <div class="text-stone-400 text-[11px]">ID: {{ bank.intermediaryId }} • {{ bank.type }}</div>
                  </div>

                  <div class="flex items-center space-x-6">
                    <div>
                      <span class="text-stone-500 block text-[10px]">Central Bank Reserve:</span>
                      <span class="font-bold text-amber-400">{{ jurisdiction.activeConfig().currencySymbol }}{{ bank.reserveBalance | number }}</span>
                    </div>
                    <div>
                      <span class="text-stone-500 block text-[10px]">CBDC Distributed:</span>
                      <span class="font-bold text-emerald-400">{{ jurisdiction.activeConfig().currencySymbol }}{{ bank.cbdcAllocated | number }}</span>
                    </div>
                    <div>
                      <span class="text-stone-500 block text-[10px]">Wallets Onboarded:</span>
                      <span class="font-bold text-stone-200">{{ bank.activeWalletsCount | number }}</span>
                    </div>
                  </div>
                </div>
              }
            </div>
          </div>
        }

        <!-- TAB 6: PROGRAMMABLE -->
        @if (activeTab() === 'PROGRAMMABLE') {
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4 text-xs font-mono">
            <h2 class="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2 border-b border-stone-800 pb-3">
              <mat-icon class="text-amber-500">code</mat-icon>
              CONSTRAINED PROGRAMMABLE PAYMENTS & SUBSIDIES
            </h2>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              @for (prog of cbdcService.programmableConditions(); track prog.programId) {
                <div class="bg-stone-950 border border-stone-800 rounded-xl p-4 space-y-3">
                  <div class="flex justify-between items-start">
                    <div>
                      <div class="font-bold text-amber-400">{{ prog.title }}</div>
                      <div class="text-[11px] text-stone-400">{{ prog.issuer }}</div>
                    </div>
                    <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] border border-emerald-800">
                      {{ prog.status }}
                    </span>
                  </div>

                  <p class="text-stone-300 text-[11px]">{{ prog.purpose }}</p>

                  <div class="grid grid-cols-2 gap-2 text-[11px] text-stone-400 bg-stone-900 p-2.5 rounded-lg border border-stone-800">
                    <div>Budget: <span class="text-stone-100 font-bold">{{ jurisdiction.activeConfig().currencySymbol }}{{ prog.totalBudget | number }}</span></div>
                    <div>Disbursed: <span class="text-emerald-400 font-bold">{{ jurisdiction.activeConfig().currencySymbol }}{{ prog.disbursedAmount | number }}</span></div>
                    <div>Max Claim: <span class="text-amber-400 font-bold">{{ jurisdiction.activeConfig().currencySymbol }}{{ prog.conditions.maxClaimAmount }}</span></div>
                    <div>Beneficiaries: <span class="text-stone-100 font-bold">{{ prog.activeBeneficiariesCount | number }}</span></div>
                  </div>
                </div>
              }
            </div>
          </div>
        }

        <!-- TAB 7: WHOLESALE & DvP -->
        @if (activeTab() === 'WHOLESALE') {
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4 text-xs font-mono">
            <h2 class="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2 border-b border-stone-800 pb-3">
              <mat-icon class="text-amber-500">swap_horiz</mat-icon>
              WHOLESALE CBDC & ATOMIC DELIVERY-VERSUS-PAYMENT (DvP)
            </h2>

            <div class="space-y-3">
              @for (dvp of cbdcService.dvpInstructions(); track dvp.dvpId) {
                <div class="bg-stone-950 border border-stone-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div class="font-bold text-amber-400">{{ dvp.securityName }}</div>
                    <div class="text-stone-400 text-[11px]">ISIN: {{ dvp.securityIsin }} • Units: {{ dvp.units | number }} @ {{ jurisdiction.activeConfig().currencySymbol }}{{ dvp.pricePerUnit }}</div>
                  </div>

                  <div class="flex items-center space-x-4">
                    <div class="text-right">
                      <div class="font-bold text-emerald-400 text-sm">{{ jurisdiction.activeConfig().currencySymbol }}{{ dvp.totalValue | number:'1.2-2' }}</div>
                      <span class="text-[10px] text-stone-400">{{ dvp.settlementStatus }}</span>
                    </div>

                    @if (dvp.settlementStatus === 'PENDING') {
                      <button
                        (click)="cbdcService.executeDvP(dvp.dvpId)"
                        class="px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold rounded-lg text-xs"
                      >
                        SETTLE ATOMICALLY
                      </button>
                    }
                  </div>
                </div>
              }
            </div>
          </div>
        }

        <!-- TAB 8: OFFLINE DEVICES -->
        @if (activeTab() === 'OFFLINE') {
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4 text-xs font-mono">
            <h2 class="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2 border-b border-stone-800 pb-3">
              <mat-icon class="text-amber-500">wifi_off</mat-icon>
              OFFLINE SECURE HARDWARE ELEMENT REGISTRY
            </h2>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              @for (dev of cbdcService.offlineDevices(); track dev.deviceId) {
                <div class="bg-stone-950 border border-stone-800 rounded-xl p-4 space-y-2">
                  <div class="flex justify-between items-center">
                    <span class="font-bold text-stone-100">{{ dev.ownerName }}</span>
                    <span [class]="dev.status === 'SYNCED' ? 'bg-emerald-950 text-emerald-400 border-emerald-800' : 'bg-amber-950 text-amber-400 border-amber-800'" class="px-2 py-0.5 rounded text-[10px] border font-bold">
                      {{ dev.status }}
                    </span>
                  </div>

                  <div class="text-stone-400 space-y-1 text-[11px]">
                    <div>Hardware SE ID: <span class="text-stone-200">{{ dev.hardwareSecureElementId }}</span></div>
                    <div>Offline Balance: <span class="text-amber-400 font-bold">{{ jurisdiction.activeConfig().currencySymbol }}{{ dev.offlineBalance | number:'1.2-2' }}</span></div>
                    <div>Pending Offline Txs: <span class="text-stone-200 font-bold">{{ dev.pendingOfflineTxs }}</span></div>
                  </div>

                  <button
                    (click)="cbdcService.syncOfflineDevice(dev.deviceId)"
                    class="w-full mt-2 py-2 bg-stone-800 hover:bg-stone-700 text-amber-400 font-bold rounded-lg border border-stone-700 text-xs"
                  >
                    TRIGGER DEVICE RE-SYNC
                  </button>
                </div>
              }
            </div>
          </div>
        }

        <!-- TAB 9: RECONCILIATION -->
        @if (activeTab() === 'RECONCILIATION') {
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 space-y-4 text-xs font-mono">
            <div class="flex justify-between items-center border-b border-stone-800 pb-3">
              <h2 class="text-sm font-bold text-stone-100 uppercase tracking-wider flex items-center gap-2">
                <mat-icon class="text-amber-500">fact_check</mat-icon>
                REAL-TIME DOUBLE-ENTRY GENERAL LEDGER RECONCILIATION
              </h2>

              <button
                (click)="cbdcService.runReconciliation()"
                class="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold rounded-xl text-xs"
              >
                TRIGGER AUDIT RECONCILIATION
              </button>
            </div>

            <div class="space-y-3">
              @for (rec of cbdcService.reconciliationRecords(); track rec.reconciliationId) {
                <div class="bg-stone-950 border border-stone-800 rounded-xl p-4 space-y-2">
                  <div class="flex justify-between items-center">
                    <span class="font-bold text-amber-400">{{ rec.reconciliationId }}</span>
                    <span class="px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold text-[10px]">
                      {{ rec.status }}
                    </span>
                  </div>

                  <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-stone-300 text-[11px]">
                    <div>Total Issuance: <span class="text-stone-100 font-bold block">{{ jurisdiction.activeConfig().currencySymbol }}{{ rec.ledgerTotalIssuance | number }}</span></div>
                    <div>Total Redeemed: <span class="text-stone-100 font-bold block">{{ jurisdiction.activeConfig().currencySymbol }}{{ rec.ledgerTotalRedemption | number }}</span></div>
                    <div>Net Outstanding: <span class="text-amber-400 font-bold block">{{ jurisdiction.activeConfig().currencySymbol }}{{ rec.calculatedOutstanding | number }}</span></div>
                    <div>Discrepancy: <span class="text-emerald-400 font-bold block">{{ jurisdiction.activeConfig().currencySymbol }}{{ rec.discrepancyAmount | number:'1.2-2' }}</span></div>
                  </div>
                </div>
              }
            </div>
          </div>
        }

        <!-- TAB 10: EMERGENCY CONTROLS -->
        @if (activeTab() === 'EMERGENCY') {
          <div class="bg-stone-900 border border-rose-900/60 rounded-2xl p-6 space-y-4 text-xs font-mono">
            <h2 class="text-sm font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2 border-b border-rose-900/60 pb-3">
              <mat-icon class="text-rose-500">warning</mat-icon>
              MONETARY SYSTEM EMERGENCY CIRCUIT BREAKER CONTROLS
            </h2>

            <div class="p-4 bg-rose-950/40 border border-rose-900 rounded-xl space-y-3">
              <div class="flex justify-between items-center">
                <div>
                  <div class="font-bold text-stone-100 text-sm">LEDGER STATE MACHINE PAUSE</div>
                  <p class="text-rose-300 text-[11px] mt-0.5">Halts all block transitions and payment settlements across the jurisdiction.</p>
                </div>

                <button
                  (click)="cbdcService.toggleLedgerPause('Governor Council Security Isolation Event')"
                  [class]="cbdcService.emergencyState().isLedgerPaused ? 'bg-emerald-600 text-stone-950' : 'bg-rose-600 text-stone-950'"
                  class="px-5 py-2.5 font-bold rounded-xl text-xs transition-all"
                >
                  {{ cbdcService.emergencyState().isLedgerPaused ? 'RESUME LEDGER' : 'EMERGENCY PAUSE' }}
                </button>
              </div>

              <div class="text-[11px] text-stone-400 border-t border-rose-900/60 pt-3">
                Status: <span [class]="cbdcService.emergencyState().isLedgerPaused ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'">
                  {{ cbdcService.emergencyState().isLedgerPaused ? 'EMERGENCY HALTED' : 'OPERATIONAL' }}
                </span>
                • Reason: <span class="text-stone-300">{{ cbdcService.emergencyState().reason }}</span>
              </div>
            </div>
          </div>
        }

      </div>

      <!-- Create Issuance Request Modal -->
      @if (showCreateIssuanceModal()) {
        <div class="fixed inset-0 bg-stone-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 max-w-md w-full space-y-4 font-mono text-xs">
            <div class="flex justify-between items-center border-b border-stone-800 pb-3">
              <h3 class="font-bold text-stone-100 text-sm flex items-center gap-2">
                <mat-icon class="text-amber-500">add_card</mat-icon>
                INITIATE CENTRAL BANK ISSUANCE
              </h3>
              <button (click)="showCreateIssuanceModal.set(false)" class="text-stone-400 hover:text-stone-200">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <div>
              <label for="target-bank-select" class="block text-stone-400 mb-1">Target Intermediary Bank</label>
              <select
                id="target-bank-select"
                [(ngModel)]="newIssuanceTargetBank"
                class="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 focus:outline-none focus:border-amber-500"
              >
                @for (bank of cbdcService.intermediaries(); track bank.intermediaryId) {
                  <option [value]="bank.intermediaryId">{{ bank.name }}</option>
                }
              </select>
            </div>

            <div>
              <label for="issuance-amount-input" class="block text-stone-400 mb-1">Issuance Amount ({{ jurisdiction.activeConfig().currencySymbol }})</label>
              <input
                id="issuance-amount-input"
                type="number"
                [(ngModel)]="newIssuanceAmount"
                class="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 text-lg font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label for="issuance-reason-input" class="block text-stone-400 mb-1">Monetary Policy Justification</label>
              <input
                id="issuance-reason-input"
                type="text"
                [(ngModel)]="newIssuanceReason"
                class="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label for="issuance-officer-input" class="block text-stone-400 mb-1">Initiating Central Bank Officer Name</label>
              <input
                id="issuance-officer-input"
                type="text"
                [(ngModel)]="newIssuanceOfficer"
                class="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div class="flex justify-end space-x-2 pt-2">
              <button
                (click)="showCreateIssuanceModal.set(false)"
                class="px-4 py-2 bg-stone-800 text-stone-300 rounded-lg"
              >
                CANCEL
              </button>
              <button
                (click)="submitIssuanceForm()"
                class="px-4 py-2 bg-amber-600 text-stone-950 font-bold rounded-lg hover:bg-amber-500"
              >
                SUBMIT CO-SIGN REQUEST
              </button>
            </div>
          </div>
        </div>
      }

    </div>
  `,
})
export class CommandCenterComponent {
  cbdcService = inject(CBDCService);
  jurisdiction = inject(JurisdictionService);

  activeTab = signal<CentralBankTab>('OVERVIEW');
  showCreateIssuanceModal = signal<boolean>(false);

  newIssuanceAmount = 10000000;
  newIssuanceReason = 'Quarterly Commercial Intermediary Liquidity Window';
  newIssuanceTargetBank = 'INT-BANK-IOM-01';
  newIssuanceOfficer = 'Governor M. Quayle';

  readonly tabs = [
    { id: 'OVERVIEW' as const, label: 'Overview', icon: 'dashboard' },
    { id: 'ISSUANCE' as const, label: 'Dual Issuance', icon: 'add_card' },
    { id: 'LEDGER' as const, label: 'Ledger Audit', icon: 'manage_search' },
    { id: 'VALIDATORS' as const, label: 'BFT Validators', icon: 'security' },
    { id: 'INTERMEDIARIES' as const, label: 'Tier-2 Banks', icon: 'domain' },
    { id: 'PROGRAMMABLE' as const, label: 'Subsidies', icon: 'code' },
    { id: 'WHOLESALE' as const, label: 'Wholesale DvP', icon: 'swap_horiz' },
    { id: 'OFFLINE' as const, label: 'Offline SE', icon: 'wifi_off' },
    { id: 'RECONCILIATION' as const, label: 'Reconciliation', icon: 'fact_check' },
    { id: 'EMERGENCY' as const, label: 'Circuit Breaker', icon: 'warning' },
  ];

  submitIssuanceForm() {
    this.cbdcService.submitIssuance(
      this.newIssuanceAmount,
      this.newIssuanceReason,
      this.newIssuanceTargetBank,
      this.newIssuanceOfficer
    );
    this.showCreateIssuanceModal.set(false);
  }

  approveIssuance(requestId: string) {
    this.cbdcService.approveIssuance(requestId, 'Deputy Gov. R. Teare');
  }
}
