import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { CBDCService } from '../../core/services/cbdc.service';
import { JurisdictionService } from '../../core/services/jurisdiction.service';
import { PrivacyTier } from '../../core/models/cbdc.types';

@Component({
  selector: 'app-citizen-wallet',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-stone-950 text-stone-100 py-8 px-4 sm:px-6 lg:px-8">
      <div class="max-w-2xl mx-auto space-y-6">

        <!-- Header / Wallet Badge -->
        <div class="flex items-center justify-between border-b border-stone-800 pb-4">
          <div>
            <span class="text-xs font-mono text-stone-400 uppercase tracking-widest">Sovereign Retail CBDC Wallet</span>
            <h1 class="text-xl font-bold font-mono text-stone-100 flex items-center gap-2">
              <mat-icon class="text-amber-500">account_balance_wallet</mat-icon>
              {{ wallet().ownerName }}
            </h1>
          </div>
          <span class="px-3 py-1 bg-emerald-950 text-emerald-400 rounded-full text-xs font-mono border border-emerald-800/60 flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            ACTIVE & VERIFIED
          </span>
        </div>

        <!-- Main Balance Display Card -->
        <div class="bg-gradient-to-br from-stone-900 via-stone-900 to-stone-950 border border-stone-800 rounded-3xl p-6 shadow-xl relative overflow-hidden">
          <div class="absolute -right-10 -bottom-10 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div class="flex justify-between items-start">
            <span class="text-xs font-mono text-stone-400 uppercase">Available Balance</span>
            <span class="text-xs font-mono px-2.5 py-1 bg-stone-800 text-amber-400 rounded-lg border border-stone-700">
              {{ jurisdiction.activeConfig().currencyCode }}
            </span>
          </div>

          <div class="mt-4 flex items-baseline space-x-2">
            <span class="text-4xl font-extrabold font-mono text-stone-100 tracking-tight">
              {{ jurisdiction.activeConfig().currencySymbol }}{{ wallet().balance | number:'1.2-2' }}
            </span>
          </div>

          <div class="mt-6 pt-4 border-t border-stone-800/80 flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-stone-400">
            <div>
              <span>Holding Limit:</span>
              <span class="text-stone-200 font-bold ml-1">
                {{ jurisdiction.activeConfig().currencySymbol }}{{ wallet().limits.maxBalance | number }}
              </span>
            </div>
            <div>
              <span>Daily Limit Used:</span>
              <span class="text-amber-400 font-bold ml-1">
                {{ jurisdiction.activeConfig().currencySymbol }}{{ wallet().limits.usedToday | number:'1.2-2' }} / {{ jurisdiction.activeConfig().currencySymbol }}{{ wallet().limits.dailyPaymentLimit | number }}
              </span>
            </div>
          </div>
        </div>

        <!-- Quick Actions: Send / Receive / NFC Tap -->
        <div class="grid grid-cols-3 gap-3">
          
          <button
            (click)="showSendModal.set(true)"
            class="py-3.5 px-4 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold font-mono rounded-2xl transition-all shadow-md flex flex-col items-center justify-center gap-1 text-xs"
          >
            <mat-icon>send</mat-icon>
            SEND PAYMENT
          </button>

          <button
            (click)="showReceiveModal.set(true)"
            class="py-3.5 px-4 bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-800 font-bold font-mono rounded-2xl transition-all flex flex-col items-center justify-center gap-1 text-xs"
          >
            <mat-icon class="text-amber-500">qr_code_2</mat-icon>
            RECEIVE / QR
          </button>

          <button
            (click)="simulateNfcTap()"
            class="py-3.5 px-4 bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-800 font-bold font-mono rounded-2xl transition-all flex flex-col items-center justify-center gap-1 text-xs"
          >
            <mat-icon class="text-emerald-400">nfc</mat-icon>
            NFC TAP-TO-PAY
          </button>

        </div>

        <!-- Offline Hardware Wallet Card -->
        <div class="bg-stone-900 border border-stone-800 rounded-2xl p-5 space-y-3 font-mono text-xs">
          <div class="flex justify-between items-center border-b border-stone-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon [class]="isOffline() ? 'text-amber-500' : 'text-stone-500'">wifi_off</mat-icon>
              <span class="font-bold text-stone-200">OFFLINE HARDWARE SECURE ELEMENT</span>
            </div>

            <button
              (click)="toggleOfflineMode()"
              [class]="isOffline() ? 'bg-amber-600 text-stone-950 font-bold' : 'bg-stone-800 text-stone-300'"
              class="px-3 py-1 rounded-lg transition-all"
            >
              {{ isOffline() ? 'OFFLINE ACTIVE' : 'ENABLE OFFLINE' }}
            </button>
          </div>

          <div class="grid grid-cols-2 gap-4 text-[11px] text-stone-400">
            <div>
              <span>Offline Balance:</span>
              <div class="text-stone-100 font-bold text-sm">
                {{ jurisdiction.activeConfig().currencySymbol }}260.00
              </div>
            </div>
            <div>
              <span>Sync Deadline:</span>
              <div class="text-emerald-400 font-bold text-sm">
                16h Remaining
              </div>
            </div>
          </div>
        </div>

        <!-- Transaction History with Privacy Badges -->
        <div class="bg-stone-900 border border-stone-800 rounded-2xl p-5 space-y-4 font-mono text-xs">
          <div class="flex justify-between items-center border-b border-stone-800 pb-3">
            <h3 class="font-bold text-stone-200 flex items-center gap-2">
              <mat-icon class="text-amber-500">history</mat-icon>
              PAYMENT TRANSACTION HISTORY
            </h3>
            <span class="text-[11px] text-stone-400">Cryptographically Signed</span>
          </div>

          <div class="space-y-3">
            @for (tx of citizenTransactions(); track tx.transactionId) {
              <div class="p-3.5 bg-stone-950 rounded-xl border border-stone-800 flex items-center justify-between gap-3">
                <div>
                  <div class="font-bold text-stone-200">{{ tx.purpose }}</div>
                  <div class="text-[11px] text-stone-400 mt-0.5">
                    {{ tx.payerWalletId === wallet().walletId ? 'To: ' + tx.payeeAlias : 'From: ' + tx.payerAlias }}
                    • {{ tx.timestamp | date:'shortTime' }}
                  </div>
                </div>

                <div class="text-right">
                  <div [class]="tx.payerWalletId === wallet().walletId ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'">
                    {{ tx.payerWalletId === wallet().walletId ? '-' : '+' }}{{ jurisdiction.activeConfig().currencySymbol }}{{ tx.amount | number:'1.2-2' }}
                  </div>
                  <div class="mt-1 flex justify-end">
                    <span class="px-2 py-0.5 rounded text-[9px] bg-stone-800 text-stone-300 border border-stone-700">
                      {{ tx.privacyTier === 'TIER_1_MINIMAL' ? 'Tier 1 (Minimal ID)' : 'Tier 2 (Standard)' }}
                    </span>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

      </div>

      <!-- Send Payment Modal -->
      @if (showSendModal()) {
        <div class="fixed inset-0 bg-stone-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 max-w-md w-full space-y-4 font-mono text-xs">
            <div class="flex justify-between items-center border-b border-stone-800 pb-3">
              <h3 class="font-bold text-stone-100 text-sm flex items-center gap-2">
                <mat-icon class="text-amber-500">send</mat-icon>
                SEND {{ jurisdiction.activeConfig().currencyCode }} CBDC
              </h3>
              <button (click)="showSendModal.set(false)" class="text-stone-400 hover:text-stone-200">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <div>
              <label for="send-payee-select" class="block text-stone-400 mb-1">Payee Merchant / Citizen</label>
              <select
                id="send-payee-select"
                [(ngModel)]="sendPayeeId"
                class="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 focus:outline-none focus:border-amber-500"
              >
                <option value="WAL-MER-002">Douglas Harbour Groceries & Goods (Merchant)</option>
                <option value="WAL-WHOLESALE-BANK1">Isle of Man Bank Wholesale Vault</option>
              </select>
            </div>

            <div>
              <label for="send-amount-input" class="block text-stone-400 mb-1">Amount ({{ jurisdiction.activeConfig().currencySymbol }})</label>
              <input
                id="send-amount-input"
                type="number"
                [(ngModel)]="sendAmount"
                class="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 text-lg font-bold focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label for="send-purpose-input" class="block text-stone-400 mb-1">Payment Purpose</label>
              <input
                id="send-purpose-input"
                type="text"
                [(ngModel)]="sendPurpose"
                class="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label for="send-privacy-tier" class="block text-stone-400 mb-1">Privacy Tier</label>
              <select
                id="send-privacy-tier"
                [(ngModel)]="sendPrivacyTier"
                class="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 focus:outline-none focus:border-amber-500"
              >
                <option value="TIER_1_MINIMAL">Tier 1: Minimal Identity Disclosure (&lt; {{ jurisdiction.activeConfig().currencySymbol }}{{ jurisdiction.activeConfig().privacyTier1Threshold }})</option>
                <option value="TIER_2_STANDARD">Tier 2: Standard Intermediary Verification</option>
              </select>
            </div>

            @if (sendError()) {
              <div class="p-2.5 bg-rose-950 border border-rose-800 rounded-lg text-rose-300 text-[11px]">
                {{ sendError() }}
              </div>
            }

            <div class="flex justify-end space-x-2 pt-2">
              <button
                (click)="showSendModal.set(false)"
                class="px-4 py-2 bg-stone-800 text-stone-300 rounded-lg"
              >
                CANCEL
              </button>
              <button
                (click)="confirmSendPayment()"
                class="px-4 py-2 bg-amber-600 text-stone-950 font-bold rounded-lg hover:bg-amber-500"
              >
                AUTHORIZE & SIGN
              </button>
            </div>
          </div>
        </div>
      }

      <!-- Receive / QR Modal -->
      @if (showReceiveModal()) {
        <div class="fixed inset-0 bg-stone-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div class="bg-stone-900 border border-stone-800 rounded-2xl p-6 max-w-sm w-full space-y-4 font-mono text-xs text-center">
            <div class="flex justify-between items-center border-b border-stone-800 pb-3">
              <h3 class="font-bold text-stone-100 text-sm">RECEIVE CBDC</h3>
              <button (click)="showReceiveModal.set(false)" class="text-stone-400">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <div class="p-4 bg-white rounded-2xl inline-block shadow-inner mx-auto">
              <mat-icon class="text-7xl text-stone-950">qr_code_2</mat-icon>
            </div>

            <div class="text-[11px] text-stone-400 break-all bg-stone-950 p-2.5 rounded-lg border border-stone-800">
              {{ wallet().publicKey }}
            </div>

            <p class="text-stone-400 text-[11px]">
              Scan to initiate instant finality peer-to-peer payment.
            </p>
          </div>
        </div>
      }

    </div>
  `,
})
export class CitizenWalletComponent {
  cbdcService = inject(CBDCService);
  jurisdiction = inject(JurisdictionService);

  showSendModal = signal<boolean>(false);
  showReceiveModal = signal<boolean>(false);
  isOffline = signal<boolean>(false);

  sendPayeeId = 'WAL-MER-002';
  sendAmount = 45.00;
  sendPurpose = 'Local Peels Bakery & Cafe';
  sendPrivacyTier: PrivacyTier = 'TIER_1_MINIMAL';
  sendError = signal<string | null>(null);

  wallet = this.cbdcService.activeCitizenWallet;

  citizenTransactions = signal(this.cbdcService.transactions());

  confirmSendPayment() {
    this.sendError.set(null);
    const result = this.cbdcService.executePayment(
      this.wallet().walletId,
      this.sendPayeeId,
      this.sendAmount,
      this.sendPurpose,
      'NFC',
      this.sendPrivacyTier
    );

    if (result.success) {
      this.showSendModal.set(false);
      this.citizenTransactions.set(this.cbdcService.transactions());
    } else {
      this.sendError.set(result.error || 'Payment execution failed');
    }
  }

  simulateNfcTap() {
    this.sendAmount = 18.50;
    this.sendPurpose = 'Douglas Tramway Tap-to-Pay';
    this.confirmSendPayment();
  }

  toggleOfflineMode() {
    this.isOffline.update((v) => !v);
  }
}
