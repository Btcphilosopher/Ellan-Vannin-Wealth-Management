/**
 * ELLAN VANNIN GOVERNMENT OS
 * Universal Institutional Workflow Engine
 * 
 * Manages formal statutory state machines:
 * INITIATE -> IN_REVIEW -> POLICY_VERIFICATION -> MANDATE_AUTHORIZATION -> COMMIT_TO_LEDGER
 */

import { WorkflowInstance } from '../types/canonical-types';
import { SovereignLedger } from '../ledger/sovereign-ledger';
import { PolicyEngine } from '../policy/policy-engine';
import { AuthorityEngine } from '../authority/authority-engine';
import { CryptoEngine } from '../crypto/crypto-engine';

export class WorkflowEngine {
  private workflows = new Map<string, WorkflowInstance>();

  constructor(
    private ledger: SovereignLedger,
    private policyEngine: PolicyEngine,
    private authorityEngine: AuthorityEngine
  ) {
    this.seedDefaultWorkflows();
  }

  private seedDefaultWorkflows() {
    const initialWorkflows: WorkflowInstance[] = [
      {
        id: 'WF-INC-2026-089',
        workflowType: 'BUSINESS_INCORPORATION',
        title: 'Incorporation of Ellan Vannin Sovereign AI Dynamics Ltd',
        initiatorId: 'did:ellan:gov:per:77102',
        initiatorName: 'Dr. Catherine Callister (Chartered Advocate)',
        currentStep: 'AUTHORITY_APPROVAL',
        status: 'AUTHORIZED',
        assignedAuthority: 'ROLE-CHIEF-REGISTRAR-COMPANIES',
        createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
        updatedAt: new Date().toISOString(),
        deadline: new Date(Date.now() + 3600000 * 48).toISOString(),
        steps: [
          { name: 'Articles of Association Submission', status: 'COMPLETED', completedBy: 'Dr. Catherine Callister', completedAt: '2026-09-09T10:00:00Z' },
          { name: 'Beneficial Ownership Anti-Money Laundering Check', status: 'COMPLETED', completedBy: 'FSA AML Screening Engine', completedAt: '2026-09-09T11:15:00Z' },
          { name: 'Statutory Policy Validation (POL-TAX-CORP-2026)', status: 'COMPLETED', completedBy: 'Policy Engine v2.4.1', completedAt: '2026-09-09T11:16:00Z' },
          { name: 'Registrar of Companies Warrant Signature', status: 'COMPLETED', completedBy: 'ROLE-CHIEF-REGISTRAR-COMPANIES', completedAt: '2026-09-10T14:30:00Z' },
          { name: 'Ledger State Commitment & Seal', status: 'COMPLETED', completedBy: 'VAL-TREASURY-01', completedAt: '2026-09-10T14:30:05Z' },
        ],
        dataPayload: {
          companyName: 'Ellan Vannin Sovereign AI Dynamics Ltd',
          companyType: 'LIMITED_COMPANY',
          registeredOffice: 'St. George’s Tower, Hope Street, Douglas, Isle of Man',
          directors: [{ name: 'Dr. Catherine Callister', nationalId: 'EVN-9912-A8' }],
          shareCapital: 100000,
        },
        ledgerTxId: 'TX-INC-CORP-9912',
      },
      {
        id: 'WF-PLAN-2026-042',
        workflowType: 'PLANNING_PERMIT',
        title: 'Planning Application: Sovereign Subsea Cable Landing Station & Data Resiliency Hub',
        initiatorId: 'did:ellan:gov:org:manx-telecom-sovereign',
        initiatorName: 'Manx Telecom Infrastructure Ltd',
        currentStep: 'POLICY_VERIFICATION',
        status: 'IN_REVIEW',
        assignedAuthority: 'ROLE-CHIEF-PLANNING-OFFICER',
        createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
        updatedAt: new Date().toISOString(),
        deadline: new Date(Date.now() + 3600000 * 120).toISOString(),
        steps: [
          { name: 'Environmental Impact Study Submission', status: 'COMPLETED', completedBy: 'DEFA Marine Ecology Unit', completedAt: '2026-09-08T09:00:00Z' },
          { name: 'Cadastral Parcel Title Verification', status: 'COMPLETED', completedBy: 'General Registry Titles Node', completedAt: '2026-09-08T14:00:00Z' },
          { name: 'Statutory Height & Coastal Zone Policy Check', status: 'PENDING', notes: 'Evaluating against POL-PLANNING-CONSENT-2026' },
          { name: 'Planning Committee Adjudication', status: 'PENDING' },
          { name: 'Final Warrant of Development', status: 'PENDING' },
        ],
        dataPayload: {
          cadastralParcel: 'PARCEL-PEEL-COASTAL-881',
          proposedHeightMetres: 11.5,
          environmentalScore: 92,
          hasTitleOrConsent: true,
          estimatedCost: 14500000,
        },
      },
      {
        id: 'WF-PROC-2026-015',
        workflowType: 'TENDER_AWARD',
        title: 'Procurement: National Digital Health Core Sovereign Electronic Patient Record Integration',
        initiatorId: 'ROLE-PROCUREMENT-CHAIR',
        initiatorName: 'Cabinet Office Central Procurement',
        currentStep: 'TREASURY_COMMITMENT',
        status: 'AUTHORIZED',
        assignedAuthority: 'ROLE-MINISTER-TREASURY',
        createdAt: new Date(Date.now() - 3600000 * 72).toISOString(),
        updatedAt: new Date().toISOString(),
        deadline: new Date(Date.now() + 3600000 * 24).toISOString(),
        steps: [
          { name: 'Statutory Need & Health Mandate Ratification', status: 'COMPLETED', completedBy: 'Minister for Health & Social Care', completedAt: '2026-09-06T10:00:00Z' },
          { name: 'Tender Publication & Sealed Bids Submission', status: 'COMPLETED', completedBy: 'Procurement Board Node', completedAt: '2026-09-07T12:00:00Z' },
          { name: 'Algorithmic Anomaly Detection & Scoring', status: 'COMPLETED', completedBy: 'AI Governance Inspector', completedAt: '2026-09-08T15:00:00Z' },
          { name: 'Procurement Board Award Ratification', status: 'COMPLETED', completedBy: 'ROLE-PROCUREMENT-CHAIR', completedAt: '2026-09-09T16:00:00Z' },
          { name: 'Treasury Expenditure Sanction (£8.4M)', status: 'COMPLETED', completedBy: 'ROLE-MINISTER-TREASURY', completedAt: '2026-09-10T11:00:00Z' },
          { name: 'Ledger State Transition & Public Award Seal', status: 'COMPLETED', completedBy: 'VAL-CABINET-OFFICE-03', completedAt: '2026-09-10T11:00:08Z' },
        ],
        dataPayload: {
          tenderRef: 'TDR-EVN-HEALTH-2026-004',
          awardedSupplier: 'Manx MedTech Sovereign Systems Ltd',
          awardedAmount: 8400000,
          budgetCap: 9000000,
        },
        ledgerTxId: 'TX-PROC-HEALTH-8400',
      },
    ];

    for (const wf of initialWorkflows) {
      this.workflows.set(wf.id, wf);
    }
  }

  public getAllWorkflows(): WorkflowInstance[] {
    return Array.from(this.workflows.values()).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  public getWorkflow(id: string): WorkflowInstance | undefined {
    return this.workflows.get(id);
  }

  /**
   * Transitions a workflow through statutory evaluation and commits to ledger when authorized.
   */
  public executeTransition(
    workflowId: string,
    action: 'EVALUATE_POLICY' | 'AUTHORIZE_STEP' | 'REJECT' | 'COMMIT_LEDGER',
    officerRoleId: string,
    officerName: string,
    notes?: string
  ): { success: boolean; message: string; workflow: WorkflowInstance | null; txId?: string } {
    const wf = this.workflows.get(workflowId);
    if (!wf) {
      return { success: false, message: 'Workflow not found', workflow: null };
    }

    if (action === 'REJECT') {
      wf.status = 'REJECTED';
      wf.updatedAt = new Date().toISOString();
      return { success: true, message: 'Workflow rejected by authority', workflow: wf };
    }

    if (action === 'EVALUATE_POLICY') {
      // Find matching policy based on workflow type
      let policyCode = 'POL-TAX-CORP-2026';
      if (wf.workflowType === 'PLANNING_PERMIT') policyCode = 'POL-PLANNING-CONSENT-2026';
      if (wf.workflowType === 'TENDER_AWARD') policyCode = 'POL-PROCUREMENT-AWARD-2026';
      if (wf.workflowType === 'BENEFIT_APPLICATION') policyCode = 'POL-BENEFITS-UNIVERSAL-2026';

      const evalResult = this.policyEngine.evaluate(policyCode, wf.dataPayload, officerName);
      if (evalResult.decision === 'APPROVED') {
        wf.status = 'AUTHORIZED';
        const pendingStep = wf.steps.find(s => s.status === 'PENDING');
        if (pendingStep) {
          pendingStep.status = 'COMPLETED';
          pendingStep.completedBy = officerName;
          pendingStep.completedAt = new Date().toISOString();
          pendingStep.notes = `Policy ${policyCode} passed. Evidence: ${evalResult.evidenceHash.slice(0, 12)}...`;
        }
        wf.updatedAt = new Date().toISOString();
        return { success: true, message: `Policy Evaluation Approved: ${evalResult.reasons.join('; ')}`, workflow: wf };
      } else {
        return { success: false, message: `Policy Evaluation Failed: ${evalResult.reasons.join('; ')}`, workflow: wf };
      }
    }

    if (action === 'COMMIT_LEDGER' || action === 'AUTHORIZE_STEP') {
      // For general workflow transitions, we check that officer has role
      const role = this.authorityEngine.getRole(officerRoleId);
      if (!role) {
        return { success: false, message: `Officer role '${officerRoleId}' not found in Authority Registry`, workflow: wf };
      }

      // Mark all remaining pending steps as completed
      for (const step of wf.steps) {
        if (step.status === 'PENDING') {
          step.status = 'COMPLETED';
          step.completedBy = `${officerName} (${role.title})`;
          step.completedAt = new Date().toISOString();
          step.notes = notes || 'Authorized under statutory mandate';
        }
      }

      // Commit to permissioned ledger
      const payloadHash = CryptoEngine.sha256(wf.dataPayload);
      const prevStateHash = CryptoEngine.sha256({ id: wf.id, status: wf.status });
      const newStateHash = CryptoEngine.sha256({ id: wf.id, status: 'COMMITTED_TO_LEDGER', data: wf.dataPayload });

      const tx = this.ledger.submitTransaction({
        jurisdiction_id: 'JUR-ISLE-OF-MAN',
        tenant_id: 'TENANT-GOV-CENTRAL',
        actor_id: officerRoleId,
        actor_name: `${officerName} (${role.title})`,
        authority_id: role.mandate,
        transaction_type: `WORKFLOW_STATE_COMMIT_${wf.workflowType}`,
        object_type: 'WORKFLOW_RECORD',
        object_id: wf.id,
        payload_hash: payloadHash,
        payload_summary: `Final statutory execution and seal for: ${wf.title}`,
        policy_version: 'POL-SOVEREIGN-WORKFLOW-v2.0',
        authorization_context: `${role.office} - Approved under ${role.mandate}`,
        timestamp: new Date().toISOString(),
        previous_state_hash: prevStateHash,
        new_state_hash: newStateHash,
      });

      wf.status = 'COMMITTED_TO_LEDGER';
      wf.ledgerTxId = tx.transaction_id;
      wf.updatedAt = new Date().toISOString();

      return {
        success: true,
        message: `Workflow state finalized and sealed into Ledger Block at transaction ID ${tx.transaction_id}`,
        workflow: wf,
        txId: tx.transaction_id,
      };
    }

    return { success: false, message: 'Invalid action requested', workflow: wf };
  }

  public createWorkflow(data: Omit<WorkflowInstance, 'id' | 'createdAt' | 'updatedAt' | 'status'>): WorkflowInstance {
    const id = `WF-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    const newWf: WorkflowInstance = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: 'IN_REVIEW',
    };
    this.workflows.set(id, newWf);
    return newWf;
  }
}
