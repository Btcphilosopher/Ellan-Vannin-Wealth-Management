/**
 * ELLAN VANNIN GOVERNMENT OS
 * Canonical Domain Types and Schemas
 * 
 * Strict separation of sovereign concerns:
 * Identity, Authority, Ledger, Registries, Policies, Workflows, Finance, Audit.
 */

export type SubjectType =
  | 'PERSON'
  | 'CITIZEN'
  | 'RESIDENT'
  | 'BUSINESS'
  | 'ORGANIZATION'
  | 'OFFICIAL'
  | 'EMPLOYEE'
  | 'CONTRACTOR'
  | 'DEVICE'
  | 'APPLICATION'
  | 'PUBLIC_AUTHORITY';

export type AssuranceLevel = 'AL1_LOW' | 'AL2_SUBSTANTIAL' | 'AL3_HIGH' | 'AL4_SOVEREIGN';

export interface DigitalIdentity {
  id: string; // DID format: did:ellan:gov:<unique_hash>
  subjectType: SubjectType;
  fullName: string;
  nationalIdentifier: string; // e.g. EVN-8921-X9
  jurisdictionId: string;
  assuranceLevel: AssuranceLevel;
  status: 'ACTIVE' | 'SUSPENDED' | 'REVOKED';
  publicKey: string;
  createdAt: string;
  updatedAt: string;
  metadata: Record<string, string | number | boolean>;
  credentials: VerifiableCredential[];
  delegations: DelegatedAuthority[];
}

export interface VerifiableCredential {
  id: string;
  type: 'CITIZENSHIP' | 'DRIVING_LICENCE' | 'BUSINESS_DIRECTOR' | 'LEGAL_PRACTICE' | 'MINISTERIAL_APPOINTMENT' | 'PROPERTY_TITLE' | 'TAX_CLEARANCE';
  issuerId: string; // e.g. did:ellan:gov:authority:registry
  issuerTitle: string;
  issuanceDate: string;
  expiryDate?: string;
  claimsHash: string;
  signature: string;
  status: 'VALID' | 'REVOKED' | 'EXPIRED';
  claims: Record<string, string | number | boolean>;
}

export interface DelegatedAuthority {
  id: string;
  delegatorId: string;
  delegateeId: string;
  scope: string[];
  maxMonetaryLimit?: number;
  validFrom: string;
  validUntil: string;
  status: 'ACTIVE' | 'REVOKED';
}

export interface GovernmentRole {
  id: string;
  title: string;
  department: string;
  office: string;
  mandate: string;
  maxMonetaryLimit: number;
  permissions: string[];
  clearanceLevel: 'UNCLASSIFIED' | 'OFFICIAL' | 'SECRET' | 'TOP_SECRET_SOVEREIGN';
}

export interface LedgerTransaction {
  transaction_id: string;
  jurisdiction_id: string;
  tenant_id: string;
  actor_id: string;
  actor_name: string;
  authority_id: string;
  transaction_type: string;
  object_type: string;
  object_id: string;
  payload_hash: string;
  payload_summary: string;
  policy_version: string;
  authorization_context: string;
  timestamp: string;
  nonce: number;
  previous_state_hash: string;
  new_state_hash: string;
  signature: string;
  status: 'FINALIZED' | 'PENDING' | 'REJECTED';
}

export interface LedgerBlock {
  block_height: number;
  block_hash: string;
  previous_block_hash: string;
  state_root: string;
  timestamp: string;
  validator_id: string;
  validator_name: string;
  validator_signature: string;
  transactions: LedgerTransaction[];
  tx_count: number;
  checkpoint?: boolean;
}

export interface ValidatorNode {
  id: string;
  name: string;
  institution: string;
  jurisdiction: string;
  publicKey: string;
  certificateHash: string;
  status: 'ACTIVE' | 'REGISTERED' | 'SUSPENDED' | 'REVOKED';
  blocksProposed: number;
  lastActive: string;
  votingWeight: number;
}

export interface AuditEvent {
  id: string;
  eventType:
    | 'IDENTITY_CREATED'
    | 'IDENTITY_UPDATED'
    | 'CREDENTIAL_ISSUED'
    | 'AUTHENTICATION'
    | 'AUTHORIZATION'
    | 'POLICY_EVALUATED'
    | 'TAX_ASSESSED'
    | 'PAYMENT_RECEIVED'
    | 'LICENCE_ISSUED'
    | 'PROPERTY_TRANSFERRED'
    | 'CONTRACT_SIGNED'
    | 'PROCUREMENT_AWARDED'
    | 'BENEFIT_APPROVED'
    | 'ELECTION_EVENT'
    | 'DOCUMENT_SIGNED'
    | 'ADMIN_ACTION'
    | 'SECURITY_EVENT';
  actorId: string;
  actorName: string;
  institution: string;
  authorityId: string;
  action: string;
  objectId: string;
  timestamp: string;
  requestId: string;
  correlationId: string;
  policyVersion: string;
  previousStateHash: string;
  newStateHash: string;
  securityClassification: 'PUBLIC' | 'INTERNAL' | 'RESTRICTED' | 'SECRET';
}

export interface DeclarativePolicy {
  id: string;
  code: string; // e.g. POL-TAX-CORP-2026
  title: string;
  jurisdictionId: string;
  version: string;
  category: 'TAX' | 'LICENSING' | 'PROCUREMENT' | 'PLANNING' | 'BENEFITS' | 'IDENTITY';
  effectiveDate: string;
  status: 'ACTIVE' | 'SUPERSEDED' | 'DRAFT';
  rules: {
    conditionDescription: string;
    field: string;
    operator: 'GTE' | 'LTE' | 'EQ' | 'NEQ' | 'IN' | 'CONTAINS';
    value: string | number | boolean | string[];
    result: 'ALLOW' | 'DENY' | 'REQUIRE_MANUAL_REVIEW' | 'APPLY_RATE';
    rateValue?: number;
    notes?: string;
  }[];
}

export interface PolicyEvaluationResult {
  policyId: string;
  policyCode: string;
  policyVersion: string;
  decision: 'APPROVED' | 'REJECTED' | 'FLAGGED_FOR_REVIEW';
  reasons: string[];
  appliedCalculations?: Record<string, number | string>;
  inputsSnapshot: Record<string, unknown>;
  timestamp: string;
  evaluatedByAuthority: string;
  evidenceHash: string;
}

export interface WorkflowInstance {
  id: string;
  workflowType: 'BUSINESS_INCORPORATION' | 'PROPERTY_CONVEYANCE' | 'TENDER_AWARD' | 'BENEFIT_APPLICATION' | 'PLANNING_PERMIT' | 'PASSPORT_RENEWAL';
  title: string;
  initiatorId: string;
  initiatorName: string;
  currentStep: string;
  status: 'DRAFT' | 'IN_REVIEW' | 'POLICY_VERIFICATION' | 'AUTHORIZED' | 'COMMITTED_TO_LEDGER' | 'REJECTED';
  assignedAuthority: string;
  createdAt: string;
  updatedAt: string;
  deadline: string;
  steps: {
    name: string;
    status: 'COMPLETED' | 'PENDING' | 'FAILED' | 'SKIPPED';
    completedBy?: string;
    completedAt?: string;
    notes?: string;
  }[];
  dataPayload: Record<string, unknown>;
  ledgerTxId?: string;
}

export interface SovereignBalanceSheet {
  currency: string;
  fiscalYear: number;
  lastUpdated: string;
  assets: {
    cashAndTreasuryReserves: number;
    sovereignInvestmentFund: number;
    publicInfrastructureAndLand: number;
    taxReceivables: number;
  };
  liabilities: {
    nationalSovereignBonds: number;
    pensionLiabilities: number;
    procurementPayables: number;
    contingentGuarantees: number;
  };
  revenueYTD: {
    corporateTax: number;
    personalIncomeTax: number;
    customsAndExcise: number;
    registryAndLicensingFees: number;
  };
  expenditureYTD: {
    infrastructureAndWorks: number;
    publicHealthAndServices: number;
    educationAndResearch: number;
    civilServiceAdministration: number;
  };
}

export interface JurisdictionProfile {
  id: string;
  name: string;
  legalEntity: string;
  sovereignType: 'ISLAND_NATION' | 'CROWN_DEPENDENCY' | 'MUNICIPALITY' | 'REGIONAL_STATE' | 'DIGITAL_JURISDICTION';
  flagEmblem: string;
  motto: string;
  currencySymbol: string;
  currencyCode: string;
  primaryLanguage: string;
  legislativeBody: string;
  activeModules: string[];
}

export interface RegistryCompany {
  id: string;
  registrationNumber: string;
  legalName: string;
  jurisdictionId: string;
  incorporationDate: string;
  type: 'LIMITED_COMPANY' | 'LLC' | 'PUBLIC_PLC' | 'STATUTORY_BOARD';
  status: 'GOOD_STANDING' | 'UNDER_LIQUIDATION' | 'STRUCK_OFF';
  registeredOffice: string;
  directors: { name: string; nationalId: string; appointedDate: string }[];
  beneficialOwners: { name: string; percentage: number; nationality: string }[];
  shareCapital: number;
  currency: string;
  lastFilingDate: string;
}

export interface RegistryProperty {
  id: string;
  titleNumber: string;
  parcelId: string;
  cadastralZone: string;
  address: string;
  registeredOwnerId: string;
  registeredOwnerName: string;
  tenure: 'FREEHOLD' | 'LEASEHOLD_999' | 'CROWN_GRANT';
  rateableValue: number;
  mortgages: { lender: string; amount: number; registeredDate: string }[];
  easements: string[];
  lastTransferDate: string;
  planningPermissions: { refNumber: string; proposal: string; approvedDate: string; status: 'APPROVED' | 'EXPIRED' }[];
}

export interface RegistryLicence {
  id: string;
  licenceNumber: string;
  category: 'DRIVING' | 'COMMERCIAL_AVIATION' | 'FINANCIAL_SERVICES' | 'MEDICAL_PRACTICE' | 'CONSTRUCTION' | 'BROADCASTING';
  holderId: string;
  holderName: string;
  issuingAuthority: string;
  issuedDate: string;
  validUntil: string;
  status: 'ACTIVE' | 'SUSPENDED' | 'EXPIRED' | 'REVOKED';
  conditions: string[];
  qrProofCode: string;
}

export interface ProcurementTender {
  id: string;
  referenceNumber: string;
  title: string;
  procuringDepartment: string;
  budgetAllocated: number;
  currency: string;
  publicationDate: string;
  closingDate: string;
  status: 'PUBLISHED' | 'EVALUATION' | 'AWARDED' | 'CLOSED';
  selectedSupplier?: string;
  awardedContractValue?: number;
  bidsReceived: {
    bidderName: string;
    amount: number;
    submissionTime: string;
    evaluatedScore?: number;
    status: 'QUALIFIED' | 'DISQUALIFIED' | 'AWARDED';
  }[];
  transparencyUrl: string;
}

export interface PublicVerificationResult {
  isValid: boolean;
  itemType: 'DOCUMENT' | 'TRANSACTION' | 'BLOCK' | 'CREDENTIAL' | 'LICENCE' | 'PROPERTY_TITLE';
  identifier: string;
  issuingAuthority: string;
  timestamp: string;
  stateRootConfirmed: boolean;
  blockHeight: number;
  cryptographicSignature: string;
  auditHash: string;
  classification: 'PUBLIC' | 'PUBLIC_WITH_REDACTION';
  details: Record<string, unknown>;
}
