/**
 * ELLAN VANNIN GOVERNMENT OS
 * Declarative Policy Engine
 * 
 * Deterministic, versioned, executable government policy rules.
 * No black-box AI decisions: every decision produces an attributable reason trace
 * with explicit rule inputs, versioned statutory references, and evidence hashes.
 */

import { DeclarativePolicy, PolicyEvaluationResult } from '../types/canonical-types';
import { CryptoEngine } from '../crypto/crypto-engine';

export class PolicyEngine {
  private policies = new Map<string, DeclarativePolicy>();

  constructor() {
    this.initializeDefaultPolicies();
  }

  private initializeDefaultPolicies() {
    const defaultPolicies: DeclarativePolicy[] = [
      {
        id: 'POL-TAX-CORP-2026',
        code: 'POL-TAX-CORP-2026',
        title: 'Corporate Income Tax Assessment Policy',
        jurisdictionId: 'JUR-ISLE-OF-MAN',
        version: 'v2.4.1',
        category: 'TAX',
        effectiveDate: '2026-04-06',
        status: 'ACTIVE',
        rules: [
          {
            conditionDescription: 'Standard Trading Companies qualify for 0% standard headline rate',
            field: 'businessCategory',
            operator: 'EQ',
            value: 'GENERAL_TRADING',
            result: 'APPLY_RATE',
            rateValue: 0.0,
            notes: 'Zero-Ten Tax Regime under Section 11 of Income Tax Act.',
          },
          {
            conditionDescription: 'Banking & Financial Institutions licensed with FSA subject to 10% rate',
            field: 'businessCategory',
            operator: 'EQ',
            value: 'BANKING_FINANCIAL',
            result: 'APPLY_RATE',
            rateValue: 10.0,
            notes: 'Deposit taking and financial services rate.',
          },
          {
            conditionDescription: 'Commercial property and land developments subject to 20% land development rate',
            field: 'businessCategory',
            operator: 'EQ',
            value: 'PROPERTY_DEVELOPMENT',
            result: 'APPLY_RATE',
            rateValue: 20.0,
            notes: 'Land extraction and commercial development tax band.',
          },
        ],
      },
      {
        id: 'POL-PLANNING-CONSENT-2026',
        code: 'POL-PLANNING-CONSENT-2026',
        title: 'Statutory Planning & Development Assessment',
        jurisdictionId: 'JUR-ISLE-OF-MAN',
        version: 'v1.8.0',
        category: 'PLANNING',
        effectiveDate: '2026-01-01',
        status: 'ACTIVE',
        rules: [
          {
            conditionDescription: 'Applicant must have verified property title or leasehold consent',
            field: 'hasTitleOrConsent',
            operator: 'EQ',
            value: true,
            result: 'ALLOW',
          },
          {
            conditionDescription: 'Environmental Sustainability Score must meet or exceed 75/100',
            field: 'environmentalScore',
            operator: 'GTE',
            value: 75,
            result: 'ALLOW',
          },
          {
            conditionDescription: 'Height restriction in Coastal Conservation Zone capped at 14 metres',
            field: 'proposedHeightMetres',
            operator: 'LTE',
            value: 14,
            result: 'ALLOW',
          },
        ],
      },
      {
        id: 'POL-PROCUREMENT-AWARD-2026',
        code: 'POL-PROCUREMENT-AWARD-2026',
        title: 'Institutional Public Procurement Evaluation Protocol',
        jurisdictionId: 'JUR-ISLE-OF-MAN',
        version: 'v3.2.0',
        category: 'PROCUREMENT',
        effectiveDate: '2026-02-15',
        status: 'ACTIVE',
        rules: [
          {
            conditionDescription: 'Supplier must hold active ISO 27001 or National Cyber Essentials Plus',
            field: 'cyberSecurityCertified',
            operator: 'EQ',
            value: true,
            result: 'ALLOW',
          },
          {
            conditionDescription: 'Supplier must have clean tax clearance status with Treasury',
            field: 'taxClearanceStatus',
            operator: 'EQ',
            value: 'VALID',
            result: 'ALLOW',
          },
          {
            conditionDescription: 'Bid value must not exceed 115% of pre-tender Treasury benchmark estimate',
            field: 'bidRatioToBenchmark',
            operator: 'LTE',
            value: 1.15,
            result: 'ALLOW',
          },
        ],
      },
      {
        id: 'POL-BENEFITS-UNIVERSAL-2026',
        code: 'POL-BENEFITS-UNIVERSAL-2026',
        title: 'Social Security & Income Support Entitlement',
        jurisdictionId: 'JUR-ISLE-OF-MAN',
        version: 'v2.1.0',
        category: 'BENEFITS',
        effectiveDate: '2026-01-01',
        status: 'ACTIVE',
        rules: [
          {
            conditionDescription: 'Claimant must have at least 5 years continuous residency status',
            field: 'residencyYears',
            operator: 'GTE',
            value: 5,
            result: 'ALLOW',
          },
          {
            conditionDescription: 'Total household liquid savings must be under £16,000 threshold',
            field: 'householdSavings',
            operator: 'LTE',
            value: 16000,
            result: 'ALLOW',
          },
        ],
      },
      {
        id: 'POL-IDENTITY-ASSURANCE-2026',
        code: 'POL-IDENTITY-ASSURANCE-2026',
        title: 'National Digital Identity & Biometric Trust Framework',
        jurisdictionId: 'JUR-ISLE-OF-MAN',
        version: 'v4.0.0',
        category: 'IDENTITY',
        effectiveDate: '2026-01-01',
        status: 'ACTIVE',
        rules: [
          {
            conditionDescription: 'Citizen must possess verified birth registry or naturalisation certificate',
            field: 'verifiedCivilRecord',
            operator: 'EQ',
            value: true,
            result: 'ALLOW',
          },
        ],
      },
    ];

    for (const p of defaultPolicies) {
      this.policies.set(p.code, p);
    }
  }

  public getPolicy(code: string): DeclarativePolicy | undefined {
    return this.policies.get(code);
  }

  public getAllPolicies(): DeclarativePolicy[] {
    return Array.from(this.policies.values());
  }

  /**
   * Deterministically evaluates input data against the specified versioned policy.
   */
  public evaluate(policyCode: string, inputs: Record<string, unknown>, authority = 'AUTOMATED_STATUTORY_EVALUATOR'): PolicyEvaluationResult {
    const policy = this.policies.get(policyCode);
    if (!policy) {
      return {
        policyId: 'UNKNOWN',
        policyCode,
        policyVersion: 'N/A',
        decision: 'REJECTED',
        reasons: [`Policy with code '${policyCode}' is not registered.`],
        inputsSnapshot: inputs,
        timestamp: new Date().toISOString(),
        evaluatedByAuthority: authority,
        evidenceHash: CryptoEngine.sha256({ inputs, error: 'POLICY_NOT_FOUND' }),
      };
    }

    const reasons: string[] = [];
    const appliedCalculations: Record<string, number | string> = {};
    let passedAll = true;

    for (const rule of policy.rules) {
      const actualValue = inputs[rule.field];
      let rulePassed = false;

      if (actualValue === undefined) {
        passedAll = false;
        reasons.push(`❌ Missing required field '${rule.field}' for condition: ${rule.conditionDescription}`);
        continue;
      }

      switch (rule.operator) {
        case 'EQ':
          rulePassed = actualValue === rule.value;
          break;
        case 'NEQ':
          rulePassed = actualValue !== rule.value;
          break;
        case 'GTE':
          rulePassed = Number(actualValue) >= Number(rule.value);
          break;
        case 'LTE':
          rulePassed = Number(actualValue) <= Number(rule.value);
          break;
        case 'IN':
          rulePassed = Array.isArray(rule.value) && (rule.value as unknown[]).includes(actualValue);
          break;
        case 'CONTAINS':
          rulePassed = String(actualValue).toLowerCase().includes(String(rule.value).toLowerCase());
          break;
      }

      if (rulePassed) {
        if (rule.result === 'APPLY_RATE' && rule.rateValue !== undefined) {
          appliedCalculations['effectiveTaxRatePercent'] = rule.rateValue;
          reasons.push(`✓ Rate rule matched: ${rule.conditionDescription} -> Rate ${rule.rateValue}%`);
        } else {
          reasons.push(`✓ Passed condition: ${rule.conditionDescription} (actual: ${actualValue})`);
        }
      } else {
        passedAll = false;
        reasons.push(`❌ Failed condition: ${rule.conditionDescription} (expected ${rule.operator} ${rule.value}, got ${actualValue})`);
      }
    }

    const decision: PolicyEvaluationResult['decision'] = passedAll ? 'APPROVED' : 'REJECTED';
    const evidenceHash = CryptoEngine.sha256({
      policyCode: policy.code,
      policyVersion: policy.version,
      inputs,
      reasons,
      decision,
    });

    return {
      policyId: policy.id,
      policyCode: policy.code,
      policyVersion: policy.version,
      decision,
      reasons,
      appliedCalculations,
      inputsSnapshot: inputs,
      timestamp: new Date().toISOString(),
      evaluatedByAuthority: authority,
      evidenceHash,
    };
  }

  public registerPolicy(policy: DeclarativePolicy) {
    this.policies.set(policy.code, policy);
  }
}
