/**
 * ELLAN VANNIN GOVERNMENT OS
 * Universal Sovereign Registry Engine
 * 
 * Manages institutional registries across People, Business, Property/Land,
 * Licences, Procurement, Tax, and Sovereign Assets.
 */

import {
  DigitalIdentity,
  RegistryCompany,
  RegistryProperty,
  RegistryLicence,
  ProcurementTender,
  SovereignBalanceSheet,
} from '../types/canonical-types';
import { CryptoEngine } from '../crypto/crypto-engine';
import { SovereignLedger } from '../ledger/sovereign-ledger';

export class RegistryEngine {
  private identities = new Map<string, DigitalIdentity>();
  private companies = new Map<string, RegistryCompany>();
  private properties = new Map<string, RegistryProperty>();
  private licences = new Map<string, RegistryLicence>();
  private procurementTenders = new Map<string, ProcurementTender>();
  private balanceSheet: SovereignBalanceSheet;

  constructor(private ledger: SovereignLedger) {
    this.balanceSheet = {
      currency: 'GBP (£ Manx)',
      fiscalYear: 2026,
      lastUpdated: new Date().toISOString(),
      assets: {
        cashAndTreasuryReserves: 485000000,
        sovereignInvestmentFund: 1850000000,
        publicInfrastructureAndLand: 3420000000,
        taxReceivables: 68400000,
      },
      liabilities: {
        nationalSovereignBonds: 400000000,
        pensionLiabilities: 1200000000,
        procurementPayables: 31200000,
        contingentGuarantees: 150000000,
      },
      revenueYTD: {
        corporateTax: 194500000,
        personalIncomeTax: 312800000,
        customsAndExcise: 410200000,
        registryAndLicensingFees: 48600000,
      },
      expenditureYTD: {
        infrastructureAndWorks: 215000000,
        publicHealthAndServices: 340000000,
        educationAndResearch: 185000000,
        civilServiceAdministration: 95000000,
      },
    };

    this.seedRegistries();
  }

  private seedRegistries() {
    // 1. Digital Identities
    const seedIdentities: DigitalIdentity[] = [
      {
        id: 'did:ellan:gov:cit:88210',
        subjectType: 'CITIZEN',
        fullName: 'Ewan Christian MHK',
        nationalIdentifier: 'EVN-8821-C1',
        jurisdictionId: 'JUR-ISLE-OF-MAN',
        assuranceLevel: 'AL4_SOVEREIGN',
        status: 'ACTIVE',
        publicKey: 'PUB_KEY_ED25519_EWAN_CHRISTIAN_8821',
        createdAt: '2024-03-15T08:00:00Z',
        updatedAt: '2026-09-01T12:00:00Z',
        metadata: {
          residenceParish: 'Braddan',
          electoralDistrict: 'Douglas South',
          taxReferenceNumber: 'NINO-MN-88210-K',
          digitalMailboxAddress: 'ewan.christian@gov.im.box',
        },
        credentials: [
          {
            id: 'CRED-NAT-ID-88210',
            type: 'CITIZENSHIP',
            issuerId: 'did:ellan:gov:authority:registry',
            issuerTitle: 'General Registry of the Isle of Man',
            issuanceDate: '2024-03-15',
            claimsHash: CryptoEngine.sha256('Ewan Christian::EVN-8821-C1::CITIZEN'),
            signature: 'SIG_ED25519_GOV_GEN_REG_001',
            status: 'VALID',
            claims: { status: 'Full Sovereign Manx Citizen', rights: 'Right of Abode and Tynwald Electorship' },
          },
          {
            id: 'CRED-DL-88210',
            type: 'DRIVING_LICENCE',
            issuerId: 'did:ellan:gov:authority:licensing',
            issuerTitle: 'Highways & Vehicle Licensing Division',
            issuanceDate: '2025-06-10',
            expiryDate: '2035-06-10',
            claimsHash: CryptoEngine.sha256('DL::Ewan Christian::A_B_C1_E'),
            signature: 'SIG_ED25519_LIC_DIV_992',
            status: 'VALID',
            claims: { categories: 'A, B, BE, C1', endorsements: 'None - Clean Record' },
          },
        ],
        delegations: [],
      },
      {
        id: 'did:ellan:gov:cit:91044',
        subjectType: 'CITIZEN',
        fullName: 'Siobhán Quayle',
        nationalIdentifier: 'EVN-9104-Q9',
        jurisdictionId: 'JUR-ISLE-OF-MAN',
        assuranceLevel: 'AL3_HIGH',
        status: 'ACTIVE',
        publicKey: 'PUB_KEY_ED25519_SIOBHAN_QUAYLE_9104',
        createdAt: '2025-01-20T10:00:00Z',
        updatedAt: '2026-08-15T09:30:00Z',
        metadata: {
          residenceParish: 'Ramsey',
          electoralDistrict: 'Ayre & Michael',
          taxReferenceNumber: 'NINO-MN-91044-B',
          digitalMailboxAddress: 'siobhan.quayle@gov.im.box',
        },
        credentials: [
          {
            id: 'CRED-NAT-ID-91044',
            type: 'CITIZENSHIP',
            issuerId: 'did:ellan:gov:authority:registry',
            issuerTitle: 'General Registry of the Isle of Man',
            issuanceDate: '2025-01-20',
            claimsHash: CryptoEngine.sha256('Siobhan Quayle::EVN-9104-Q9::CITIZEN'),
            signature: 'SIG_ED25519_GOV_GEN_REG_002',
            status: 'VALID',
            claims: { status: 'Full Sovereign Manx Citizen' },
          },
          {
            id: 'CRED-DIR-91044',
            type: 'BUSINESS_DIRECTOR',
            issuerId: 'did:ellan:gov:authority:companies',
            issuerTitle: 'Companies Registry',
            issuanceDate: '2025-04-12',
            claimsHash: CryptoEngine.sha256('Director::Siobhan Quayle::Manx Maritime Tech'),
            signature: 'SIG_ED25519_COMPANIES_DIR_08',
            status: 'VALID',
            claims: { corporateEntity: 'CO-138902-C', fiduciaryStatus: 'Qualified Director' },
          },
        ],
        delegations: [],
      },
    ];

    for (const id of seedIdentities) {
      this.identities.set(id.id, id);
    }

    // 2. Companies Registry
    const seedCompanies: RegistryCompany[] = [
      {
        id: 'CO-138902-C',
        registrationNumber: '138902C',
        legalName: 'Manx Maritime Clean Propulsion Ltd',
        jurisdictionId: 'JUR-ISLE-OF-MAN',
        incorporationDate: '2021-05-18',
        type: 'LIMITED_COMPANY',
        status: 'GOOD_STANDING',
        registeredOffice: 'Viking Maritime House, Peel Marina, Isle of Man IM5 1TB',
        directors: [
          { name: 'Siobhán Quayle', nationalId: 'EVN-9104-Q9', appointedDate: '2021-05-18' },
          { name: 'Capt. Thomas Teare', nationalId: 'EVN-7201-T4', appointedDate: '2023-01-15' },
        ],
        beneficialOwners: [
          { name: 'Siobhán Quayle', percentage: 65, nationality: 'Manx / British' },
          { name: 'Celtic Green Energy Syndicate', percentage: 35, nationality: 'Irish' },
        ],
        shareCapital: 500000,
        currency: 'GBP',
        lastFilingDate: '2026-05-01',
      },
      {
        id: 'CO-099411-V',
        registrationNumber: '099411V',
        legalName: 'Ellan Vannin Digital Space Telemetry plc',
        jurisdictionId: 'JUR-ISLE-OF-MAN',
        incorporationDate: '2019-11-04',
        type: 'PUBLIC_PLC',
        status: 'GOOD_STANDING',
        registeredOffice: 'Tynwald Science Park, Foxdale, Isle of Man IM4 3EU',
        directors: [
          { name: 'Prof. Alistair Kermode', nationalId: 'EVN-5510-K2', appointedDate: '2019-11-04' },
          { name: 'Dr. Catherine Callister', nationalId: 'EVN-9912-A8', appointedDate: '2022-09-01' },
        ],
        beneficialOwners: [
          { name: 'Isle of Man Sovereign Technology Fund', percentage: 40, nationality: 'Manx Sovereign' },
          { name: 'Public Free Float (AIM / Tynwald Exchange)', percentage: 60, nationality: 'International' },
        ],
        shareCapital: 25000000,
        currency: 'GBP',
        lastFilingDate: '2026-06-30',
      },
      {
        id: 'CO-142088-C',
        registrationNumber: '142088C',
        legalName: 'Douglas Sovereign Trust & Fiduciary Services LLC',
        jurisdictionId: 'JUR-ISLE-OF-MAN',
        incorporationDate: '2023-08-11',
        type: 'LLC',
        status: 'GOOD_STANDING',
        registeredOffice: 'Finch Road Financial Quarter, Douglas, Isle of Man IM1 2PX',
        directors: [
          { name: 'Finian Clucas TEP', nationalId: 'EVN-6310-C7', appointedDate: '2023-08-11' },
        ],
        beneficialOwners: [
          { name: 'Clucas Sovereign Holdings Ltd', percentage: 100, nationality: 'Manx' },
        ],
        shareCapital: 2000000,
        currency: 'GBP',
        lastFilingDate: '2026-07-15',
      },
    ];

    for (const co of seedCompanies) {
      this.companies.set(co.id, co);
    }

    // 3. Property & Land Cadastre
    const seedProperties: RegistryProperty[] = [
      {
        id: 'PROP-DGL-0982',
        titleNumber: 'IOM-TITLE-0982-DOUGLAS',
        parcelId: 'CAD-DGL-CENTRAL-4401',
        cadastralZone: 'Douglas Central Maritime',
        address: '14 Athol Street, Douglas, Isle of Man IM1 1JA',
        registeredOwnerId: 'CO-142088-C',
        registeredOwnerName: 'Douglas Sovereign Trust & Fiduciary Services LLC',
        tenure: 'FREEHOLD',
        rateableValue: 84000,
        mortgages: [
          { lender: 'Isle of Man Bank plc (NatWest Group)', amount: 1200000, registeredDate: '2023-08-15' },
        ],
        easements: ['Right of way for public subterranean optical fibre conduit (Manx Telecom)'],
        lastTransferDate: '2023-08-11',
        planningPermissions: [
          { refNumber: 'PA-24-00912-B', proposal: 'Solar PV rooftop installation and facade conservation', approvedDate: '2024-11-20', status: 'APPROVED' },
        ],
      },
      {
        id: 'PROP-PEL-4410',
        titleNumber: 'IOM-TITLE-4410-PEEL',
        parcelId: 'CAD-PEL-HARBOUR-102',
        cadastralZone: 'Peel Historic Fishery & Marina',
        address: 'Quay West Coastal Pavilion, Peel, Isle of Man IM5 1AW',
        registeredOwnerId: 'did:ellan:gov:cit:88210',
        registeredOwnerName: 'Ewan Christian MHK',
        tenure: 'FREEHOLD',
        rateableValue: 42000,
        mortgages: [],
        easements: ['Harbour Authority tidal wall maintenance servitude'],
        lastTransferDate: '2020-04-18',
        planningPermissions: [
          { refNumber: 'PA-25-00114-A', proposal: 'Low-carbon heat pump conversion and glazed terrace', approvedDate: '2025-03-02', status: 'APPROVED' },
        ],
      },
    ];

    for (const prop of seedProperties) {
      this.properties.set(prop.id, prop);
    }

    // 4. Licences
    const seedLicences: RegistryLicence[] = [
      {
        id: 'LIC-FSA-CLS-01',
        licenceNumber: 'FSA-CLASS-2-INV-8891',
        category: 'FINANCIAL_SERVICES',
        holderId: 'CO-142088-C',
        holderName: 'Douglas Sovereign Trust & Fiduciary Services LLC',
        issuingAuthority: 'Isle of Man Financial Services Authority',
        issuedDate: '2023-09-01',
        validUntil: '2028-09-01',
        status: 'ACTIVE',
        conditions: ['Maintain minimum Tier 1 capital adequacy of £1.5M', 'Annual independent AML audit filing'],
        qrProofCode: 'PROV-FSA-8891-VERIFIABLE-STATE-PROOF',
      },
      {
        id: 'LIC-AV-SPACE-09',
        licenceNumber: 'IOM-SPACE-GROUND-04',
        category: 'COMMERCIAL_AVIATION',
        holderId: 'CO-099411-V',
        holderName: 'Ellan Vannin Digital Space Telemetry plc',
        issuingAuthority: 'Isle of Man Civil Aviation Administration',
        issuedDate: '2022-04-10',
        validUntil: '2032-04-10',
        status: 'ACTIVE',
        conditions: ['Compliance with ITU orbital frequency coordination', 'Dual encrypted backup telemetry'],
        qrProofCode: 'PROV-SPACE-004-VERIFIABLE-STATE-PROOF',
      },
    ];

    for (const lic of seedLicences) {
      this.licences.set(lic.id, lic);
    }

    // 5. Procurement Tenders
    const seedTenders: ProcurementTender[] = [
      {
        id: 'TDR-EVN-HEALTH-2026-004',
        referenceNumber: 'EVN-PROC-2026-004',
        title: 'National Digital Health Core: Sovereign Electronic Health Record Integration',
        procuringDepartment: 'Department of Health and Social Care (Manx Care)',
        budgetAllocated: 9000000,
        currency: 'GBP',
        publicationDate: '2026-08-01',
        closingDate: '2026-09-05',
        status: 'AWARDED',
        selectedSupplier: 'Manx MedTech Sovereign Systems Ltd',
        awardedContractValue: 8400000,
        bidsReceived: [
          { bidderName: 'Manx MedTech Sovereign Systems Ltd', amount: 8400000, submissionTime: '2026-09-04T16:20:00Z', evaluatedScore: 94.5, status: 'AWARDED' },
          { bidderName: 'Global Health Cloud Corp Europe', amount: 8950000, submissionTime: '2026-09-05T11:00:00Z', evaluatedScore: 82.0, status: 'QUALIFIED' },
          { bidderName: 'Celtic Clinical Data Consortium', amount: 9200000, submissionTime: '2026-09-05T15:45:00Z', evaluatedScore: 78.5, status: 'QUALIFIED' },
        ],
        transparencyUrl: 'https://gov.im/transparency/procurement/EVN-PROC-2026-004',
      },
      {
        id: 'TDR-EVN-ENERGY-2026-009',
        referenceNumber: 'EVN-PROC-2026-009',
        title: 'Sovereign Offshore Wind & Tidal Microgrid Balancing Storage (40MWh)',
        procuringDepartment: 'Manx Utilities Authority',
        budgetAllocated: 24000000,
        currency: 'GBP',
        publicationDate: '2026-08-20',
        closingDate: '2026-10-15',
        status: 'PUBLISHED',
        bidsReceived: [
          { bidderName: 'Celtic Marine Energy Ltd', amount: 22800000, submissionTime: '2026-09-08T09:12:00Z', status: 'QUALIFIED' },
          { bidderName: 'Orkney & Isle Storage Systems', amount: 23400000, submissionTime: '2026-09-10T14:30:00Z', status: 'QUALIFIED' },
        ],
        transparencyUrl: 'https://gov.im/transparency/procurement/EVN-PROC-2026-009',
      },
    ];

    for (const tdr of seedTenders) {
      this.procurementTenders.set(tdr.id, tdr);
    }
  }

  // Registry Getters & Mutators
  public getAllIdentities(): DigitalIdentity[] {
    return Array.from(this.identities.values());
  }

  public getIdentity(id: string): DigitalIdentity | undefined {
    return this.identities.get(id);
  }

  public createIdentity(data: Omit<DigitalIdentity, 'id' | 'createdAt' | 'updatedAt' | 'credentials' | 'delegations'>): DigitalIdentity {
    const id = `did:ellan:gov:${data.subjectType.toLowerCase()}:${Math.floor(10000 + Math.random() * 90000)}`;
    const newIdentity: DigitalIdentity = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      credentials: [
        {
          id: `CRED-NAT-ID-${id.split(':').pop()}`,
          type: 'CITIZENSHIP',
          issuerId: 'did:ellan:gov:authority:registry',
          issuerTitle: 'General Registry',
          issuanceDate: new Date().toISOString().split('T')[0],
          claimsHash: CryptoEngine.sha256(data),
          signature: CryptoEngine.signPayload(CryptoEngine.sha256(data), 'GOV_REG_ROOT', 1),
          status: 'VALID',
          claims: { ...data.metadata, verified: true },
        },
      ],
      delegations: [],
    };

    this.identities.set(id, newIdentity);

    // Commit to ledger
    this.ledger.submitTransaction({
      jurisdiction_id: 'JUR-ISLE-OF-MAN',
      tenant_id: 'TENANT-GOV-IDENTITY',
      actor_id: 'OFFICIAL-REGISTRAR-GEN',
      actor_name: 'General Registry Registrar',
      authority_id: 'National Identity Trust Framework Act',
      transaction_type: 'IDENTITY_ENROLMENT',
      object_type: 'DIGITAL_IDENTITY',
      object_id: id,
      payload_hash: CryptoEngine.sha256(newIdentity),
      payload_summary: `Sovereign digital identity registered for ${data.fullName} (${data.subjectType})`,
      policy_version: 'POL-IDENTITY-ASSURANCE-2026',
      authorization_context: 'Civil Registration Division',
      timestamp: new Date().toISOString(),
      previous_state_hash: '0000000000000000000000000000000000000000000000000000000000000000',
      new_state_hash: CryptoEngine.sha256(newIdentity),
    });

    return newIdentity;
  }

  public getAllCompanies(): RegistryCompany[] {
    return Array.from(this.companies.values());
  }

  public getCompany(id: string): RegistryCompany | undefined {
    return this.companies.get(id);
  }

  public incorporateCompany(data: Omit<RegistryCompany, 'id' | 'registrationNumber' | 'incorporationDate' | 'status' | 'lastFilingDate'>): RegistryCompany {
    const regNum = `${Math.floor(100000 + Math.random() * 900000)}C`;
    const id = `CO-${regNum}`;
    const newCompany: RegistryCompany = {
      ...data,
      id,
      registrationNumber: regNum,
      incorporationDate: new Date().toISOString().split('T')[0],
      status: 'GOOD_STANDING',
      lastFilingDate: new Date().toISOString().split('T')[0],
    };

    this.companies.set(id, newCompany);

    this.ledger.submitTransaction({
      jurisdiction_id: 'JUR-ISLE-OF-MAN',
      tenant_id: 'TENANT-GOV-COMPANIES',
      actor_id: 'ROLE-CHIEF-REGISTRAR-COMPANIES',
      actor_name: 'Registrar of Companies',
      authority_id: 'Companies Act 2006 (Act of Tynwald)',
      transaction_type: 'COMPANY_INCORPORATION',
      object_type: 'COMPANY_RECORD',
      object_id: id,
      payload_hash: CryptoEngine.sha256(newCompany),
      payload_summary: `Company incorporated: ${newCompany.legalName} (${regNum})`,
      policy_version: 'POL-TAX-CORP-2026',
      authorization_context: 'Companies Registry Statutory Seal',
      timestamp: new Date().toISOString(),
      previous_state_hash: '0000000000000000000000000000000000000000000000000000000000000000',
      new_state_hash: CryptoEngine.sha256(newCompany),
    });

    return newCompany;
  }

  public getAllProperties(): RegistryProperty[] {
    return Array.from(this.properties.values());
  }

  public getProperty(id: string): RegistryProperty | undefined {
    return this.properties.get(id);
  }

  public transferPropertyTitle(propertyId: string, newOwnerId: string, newOwnerName: string, considerationValue: number): RegistryProperty {
    const prop = this.properties.get(propertyId);
    if (!prop) throw new Error('Property parcel not found');

    const prevStateHash = CryptoEngine.sha256(prop);
    const prevOwner = prop.registeredOwnerName;

    prop.registeredOwnerId = newOwnerId;
    prop.registeredOwnerName = newOwnerName;
    prop.lastTransferDate = new Date().toISOString().split('T')[0];

    const newStateHash = CryptoEngine.sha256(prop);

    this.ledger.submitTransaction({
      jurisdiction_id: 'JUR-ISLE-OF-MAN',
      tenant_id: 'TENANT-GOV-LAND-REGISTRY',
      actor_id: 'ROLE-CHIEF-REGISTRAR-COMPANIES',
      actor_name: 'Deeds & Land Title Registry',
      authority_id: 'Land Registration Act 1982',
      transaction_type: 'PROPERTY_TITLE_CONVEYANCE',
      object_type: 'PROPERTY_CADASTRE_RECORD',
      object_id: propertyId,
      payload_hash: CryptoEngine.sha256({ propertyId, prevOwner, newOwnerName, considerationValue }),
      payload_summary: `Title conveyed: ${prop.address} from ${prevOwner} to ${newOwnerName} (£${considerationValue.toLocaleString()})`,
      policy_version: 'POL-PLANNING-CONSENT-2026',
      authorization_context: 'General Registry Conveyance Warrant',
      timestamp: new Date().toISOString(),
      previous_state_hash: prevStateHash,
      new_state_hash: newStateHash,
    });

    return prop;
  }

  public getAllLicences(): RegistryLicence[] {
    return Array.from(this.licences.values());
  }

  public getAllProcurementTenders(): ProcurementTender[] {
    return Array.from(this.procurementTenders.values());
  }

  public submitBid(tenderId: string, bidderName: string, amount: number): ProcurementTender {
    const tdr = this.procurementTenders.get(tenderId);
    if (!tdr) throw new Error('Tender not found');

    tdr.bidsReceived.push({
      bidderName,
      amount,
      submissionTime: new Date().toISOString(),
      status: 'QUALIFIED',
    });

    this.ledger.submitTransaction({
      jurisdiction_id: 'JUR-ISLE-OF-MAN',
      tenant_id: 'TENANT-GOV-PROCUREMENT',
      actor_id: 'SYSTEM-PROCUREMENT-PORTAL',
      actor_name: 'Procurement Sealed Bid Box',
      authority_id: 'Financial Regulations Procurement Code 2026',
      transaction_type: 'PROCUREMENT_BID_SUBMISSION',
      object_type: 'PROCUREMENT_TENDER',
      object_id: tenderId,
      payload_hash: CryptoEngine.sha256({ tenderId, bidderName, amount }),
      payload_summary: `Sealed tender bid received for ${tdr.referenceNumber} from ${bidderName}`,
      policy_version: 'POL-PROCUREMENT-AWARD-2026',
      authorization_context: 'Cryptographic Bid Envelope Timestamped',
      timestamp: new Date().toISOString(),
      previous_state_hash: CryptoEngine.sha256(tdr.bidsReceived.slice(0, -1)),
      new_state_hash: CryptoEngine.sha256(tdr.bidsReceived),
    });

    return tdr;
  }

  public getBalanceSheet(): SovereignBalanceSheet {
    return { ...this.balanceSheet };
  }

  public recordTaxPayment(taxPayerName: string, amount: number, taxType: string) {
    this.balanceSheet.revenueYTD.personalIncomeTax += amount;
    this.balanceSheet.assets.cashAndTreasuryReserves += amount;
    this.balanceSheet.lastUpdated = new Date().toISOString();

    this.ledger.submitTransaction({
      jurisdiction_id: 'JUR-ISLE-OF-MAN',
      tenant_id: 'TENANT-GOV-TREASURY',
      actor_id: 'ROLE-DIRECTOR-INCOME-TAX',
      actor_name: 'Treasury Cashier Node',
      authority_id: 'Income Tax Act 1970',
      transaction_type: 'TAX_SETTLEMENT_RECEIPT',
      object_type: 'TREASURY_ACCOUNT',
      object_id: `TAX-PMT-${Date.now()}`,
      payload_hash: CryptoEngine.sha256({ taxPayerName, amount, taxType }),
      payload_summary: `Tax payment settled: £${amount.toLocaleString()} (${taxType}) from ${taxPayerName}`,
      policy_version: 'POL-TAX-CORP-2026',
      authorization_context: 'Income Tax Division Clearing',
      timestamp: new Date().toISOString(),
      previous_state_hash: CryptoEngine.sha256(this.balanceSheet),
      new_state_hash: CryptoEngine.sha256({ ...this.balanceSheet, updated: true }),
    });
  }
}
