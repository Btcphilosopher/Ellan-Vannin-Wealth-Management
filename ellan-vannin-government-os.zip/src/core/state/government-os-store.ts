/**
 * ELLAN VANNIN GOVERNMENT OS
 * Sovereign Platform State Orchestrator & Multi-Jurisdiction Engine
 */

import { SovereignLedger } from '../ledger/sovereign-ledger';
import { AuthorityEngine } from '../authority/authority-engine';
import { PolicyEngine } from '../policy/policy-engine';
import { WorkflowEngine } from '../workflow/workflow-engine';
import { RegistryEngine } from '../registries/registry-engine';
import { JurisdictionProfile, PublicVerificationResult } from '../types/canonical-types';
import { CryptoEngine } from '../crypto/crypto-engine';

export class GovernmentOSStore {
  private static instance: GovernmentOSStore;

  public ledger: SovereignLedger;
  public authorityEngine: AuthorityEngine;
  public policyEngine: PolicyEngine;
  public workflowEngine: WorkflowEngine;
  public registryEngine: RegistryEngine;

  public availableJurisdictions: JurisdictionProfile[] = [
    {
      id: 'JUR-ISLE-OF-MAN',
      name: 'Ellan Vannin (Isle of Man)',
      legalEntity: 'Government of the Isle of Man (Reiltys Ellan Vannin)',
      sovereignType: 'ISLAND_NATION',
      flagEmblem: '🇮🇲',
      motto: 'Quocunque Jeceris Stabit (Whithersoever you throw it, it will stand)',
      currencySymbol: '£',
      currencyCode: 'GBP',
      primaryLanguage: 'English / Manx Gaelic (Gaelg)',
      legislativeBody: 'High Court of Tynwald (Parliament of the Isle of Man)',
      activeModules: [
        'Sovereign Ledger',
        'Digital Identity & Trust Framework',
        'Universal Registries',
        'Zero-Ten Tax Engine',
        'Sovereign Balance Sheet',
        'Procurement & Tenders',
        'Land & Property Cadastre',
        'Universal Licences',
        'Social Benefits',
        'Public Transparency Gazette',
        'AI Provenance Navigator',
      ],
    },
    {
      id: 'JUR-DOUGLAS-MUNICIPALITY',
      name: 'City of Douglas (Doolish)',
      legalEntity: 'Douglas Borough Council & Municipal Corporation',
      sovereignType: 'MUNICIPALITY',
      flagEmblem: '🏛️',
      motto: 'Kione Heidys ny h-Ellan (Capital of the Island)',
      currencySymbol: '£',
      currencyCode: 'GBP',
      primaryLanguage: 'English',
      legislativeBody: 'Municipal Council Chambers',
      activeModules: [
        'Municipal Byelaw Ledger',
        'Citizen Services Portal',
        'Local Planning & Rates',
        'Waste & Civil Works Licensing',
        'Civic Registry',
      ],
    },
    {
      id: 'JUR-CELTIC-DIGITAL-FEDERATION',
      name: 'Celtic Digital Trade Federation',
      legalEntity: 'Cross-Jurisdictional Inter-Island Sovereign Entity',
      sovereignType: 'DIGITAL_JURISDICTION',
      flagEmblem: '🌐',
      motto: 'Sovereignty Through Interoperability',
      currencySymbol: '€',
      currencyCode: 'EUR',
      primaryLanguage: 'English / Multilingual',
      legislativeBody: 'Intergovernmental Digital Council',
      activeModules: [
        'Cross-Border Digital Identity',
        'Inter-Island Digital Contracts',
        'Mutual Tax Transparency',
        'Federated Validator Consensus',
      ],
    },
  ];

  public activeJurisdiction: JurisdictionProfile;

  private constructor() {
    this.activeJurisdiction = this.availableJurisdictions[0];
    this.ledger = new SovereignLedger(this.activeJurisdiction.id);
    this.authorityEngine = new AuthorityEngine();
    this.policyEngine = new PolicyEngine();
    this.registryEngine = new RegistryEngine(this.ledger);
    this.workflowEngine = new WorkflowEngine(this.ledger, this.policyEngine, this.authorityEngine);
  }

  public static getInstance(): GovernmentOSStore {
    if (!GovernmentOSStore.instance) {
      GovernmentOSStore.instance = new GovernmentOSStore();
    }
    return GovernmentOSStore.instance;
  }

  public switchJurisdiction(jurisdictionId: string) {
    const found = this.availableJurisdictions.find(j => j.id === jurisdictionId);
    if (found) {
      this.activeJurisdiction = found;
    }
  }

  /**
   * Public Zero-Knowledge Verification Tool.
   * Enables any citizen or auditor to verify a document, transaction, licence, or block.
   */
  public verifyPublicRecord(query: string): PublicVerificationResult {
    const trimmed = query.trim();

    // Check transaction ID
    const tx = this.ledger.getTransactionById(trimmed);
    if (tx) {
      const block = this.ledger.getBlocks().find(b => b.transactions.some(t => t.transaction_id === tx.transaction_id));
      return {
        isValid: true,
        itemType: 'TRANSACTION',
        identifier: tx.transaction_id,
        issuingAuthority: tx.authority_id,
        timestamp: tx.timestamp,
        stateRootConfirmed: true,
        blockHeight: block?.block_height ?? 1,
        cryptographicSignature: tx.signature,
        auditHash: tx.payload_hash,
        classification: 'PUBLIC',
        details: {
          transactionType: tx.transaction_type,
          actor: tx.actor_name,
          summary: tx.payload_summary,
          policyVersion: tx.policy_version,
          previousStateHash: tx.previous_state_hash,
          newStateHash: tx.new_state_hash,
        },
      };
    }

    // Check Block Hash or Height
    const block = !isNaN(Number(trimmed))
      ? this.ledger.getBlockByHeight(Number(trimmed))
      : this.ledger.getBlocks().find(b => b.block_hash === trimmed);

    if (block) {
      return {
        isValid: true,
        itemType: 'BLOCK',
        identifier: block.block_hash,
        issuingAuthority: block.validator_name,
        timestamp: block.timestamp,
        stateRootConfirmed: true,
        blockHeight: block.block_height,
        cryptographicSignature: block.validator_signature,
        auditHash: block.state_root,
        classification: 'PUBLIC',
        details: {
          transactionsCount: block.tx_count,
          previousBlockHash: block.previous_block_hash,
          isCheckpoint: block.checkpoint || false,
        },
      };
    }

    // Check Licence Number
    const licence = this.registryEngine.getAllLicences().find(l => l.licenceNumber === trimmed || l.id === trimmed);
    if (licence) {
      return {
        isValid: licence.status === 'ACTIVE',
        itemType: 'LICENCE',
        identifier: licence.licenceNumber,
        issuingAuthority: licence.issuingAuthority,
        timestamp: licence.issuedDate,
        stateRootConfirmed: true,
        blockHeight: 1,
        cryptographicSignature: CryptoEngine.signPayload(licence.qrProofCode, 'GOV_LIC_AUTHORITY', 1),
        auditHash: CryptoEngine.sha256(licence),
        classification: 'PUBLIC',
        details: {
          category: licence.category,
          holderName: licence.holderName,
          validUntil: licence.validUntil,
          conditions: licence.conditions,
          status: licence.status,
        },
      };
    }

    // Check Company Number
    const company = this.registryEngine.getAllCompanies().find(c => c.registrationNumber === trimmed || c.id === trimmed);
    if (company) {
      return {
        isValid: company.status === 'GOOD_STANDING',
        itemType: 'DOCUMENT',
        identifier: company.registrationNumber,
        issuingAuthority: 'Companies Registry (General Registry of the Isle of Man)',
        timestamp: company.incorporationDate,
        stateRootConfirmed: true,
        blockHeight: 1,
        cryptographicSignature: CryptoEngine.signPayload(CryptoEngine.sha256(company), 'COMPANIES_REG_OFFICIAL', 1),
        auditHash: CryptoEngine.sha256(company),
        classification: 'PUBLIC',
        details: {
          companyName: company.legalName,
          companyType: company.type,
          status: company.status,
          shareCapital: `£${company.shareCapital.toLocaleString()}`,
          registeredOffice: company.registeredOffice,
        },
      };
    }

    // Check Property Title
    const property = this.registryEngine.getAllProperties().find(p => p.titleNumber === trimmed || p.id === trimmed);
    if (property) {
      return {
        isValid: true,
        itemType: 'PROPERTY_TITLE',
        identifier: property.titleNumber,
        issuingAuthority: 'Land Registry of the Isle of Man',
        timestamp: property.lastTransferDate,
        stateRootConfirmed: true,
        blockHeight: 1,
        cryptographicSignature: CryptoEngine.signPayload(CryptoEngine.sha256(property), 'LAND_REG_OFFICIAL', 1),
        auditHash: CryptoEngine.sha256(property),
        classification: 'PUBLIC_WITH_REDACTION',
        details: {
          parcelId: property.parcelId,
          cadastralZone: property.cadastralZone,
          address: property.address,
          tenure: property.tenure,
          registeredOwner: property.registeredOwnerName,
          easements: property.easements,
        },
      };
    }

    // Generic Hash / Document check
    return {
      isValid: false,
      itemType: 'DOCUMENT',
      identifier: trimmed,
      issuingAuthority: 'Ellan Vannin Sovereign Verification Gateway',
      timestamp: new Date().toISOString(),
      stateRootConfirmed: false,
      blockHeight: 0,
      cryptographicSignature: 'NONE',
      auditHash: CryptoEngine.sha256(trimmed),
      classification: 'PUBLIC',
      details: {
        error: 'No active state commitment or signature found for the queried hash/identifier.',
        suggestedAction: 'Verify the statutory identifier format (e.g. TX-..., IOM-TITLE-..., FSA-..., CO-... or Block Hash)',
      },
    };
  }
}
