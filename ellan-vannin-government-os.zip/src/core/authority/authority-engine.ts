/**
 * ELLAN VANNIN GOVERNMENT OS
 * Sovereign Authority & Mandate Engine
 * 
 * Model: PERSON -> ROLE -> OFFICE -> MANDATE -> AUTHORITY -> PERMISSION -> ACTION
 * Enforces:
 * - Explicit statutory authority
 * - Time-bound mandates
 * - Scope-bound monetary expenditure limits
 * - Non-repudiation and delegation audit
 */

import { GovernmentRole, DelegatedAuthority } from '../types/canonical-types';

export class AuthorityEngine {
  private roles = new Map<string, GovernmentRole>();
  private delegations = new Map<string, DelegatedAuthority>();

  constructor() {
    this.initializeDefaultRoles();
  }

  private initializeDefaultRoles() {
    const defaultRoles: GovernmentRole[] = [
      {
        id: 'ROLE-MINISTER-TREASURY',
        title: 'Minister for the Treasury',
        department: 'Department of the Treasury (Rheynn Tashtee)',
        office: 'Ministerial Office of the Treasury',
        mandate: 'Financial Administration & Sovereign Reserve Management Act',
        maxMonetaryLimit: 50000000, // £50,000,000
        permissions: [
          'TREASURY_PAYMENT_APPROVAL',
          'SOVEREIGN_BOND_ISSUANCE',
          'TAX_RATE_ASSESSMENT_OVERRIDE',
          'PROCUREMENT_MAJOR_AWARD_SIGN',
          'VALIDATOR_KEY_AUTHORIZATION',
        ],
        clearanceLevel: 'TOP_SECRET_SOVEREIGN',
      },
      {
        id: 'ROLE-DIRECTOR-INCOME-TAX',
        title: 'Assessor of Income Tax',
        department: 'Income Tax Division',
        office: 'Statutory Tax Assessment Office',
        mandate: 'Income Tax Act 1970 (as amended 2026)',
        maxMonetaryLimit: 5000000,
        permissions: [
          'TAX_ASSESSMENT_CREATE',
          'TAX_PENALTY_WAIVE',
          'TAX_REFUND_AUTHORIZE',
          'COMPANY_TAX_CLEARANCE_ISSUE',
        ],
        clearanceLevel: 'SECRET',
      },
      {
        id: 'ROLE-CHIEF-REGISTRAR-COMPANIES',
        title: 'Registrar of Companies & Deeds',
        department: 'General Registry',
        office: 'Companies & Intellectual Property Office',
        mandate: 'Companies Act 2006 & Beneficial Ownership Act 2017',
        maxMonetaryLimit: 1000000,
        permissions: [
          'COMPANY_INCORPORATE',
          'COMPANY_STRIKE_OFF',
          'DIRECTOR_APPOINTMENT_RATIFY',
          'BENEFICIAL_OWNERSHIP_REGISTER',
        ],
        clearanceLevel: 'OFFICIAL',
      },
      {
        id: 'ROLE-CHIEF-PLANNING-OFFICER',
        title: 'Director of Planning & Building Control',
        department: 'Department of Environment, Food and Agriculture',
        office: 'Planning Directorate',
        mandate: 'Town and Country Planning Act 1999',
        maxMonetaryLimit: 2000000,
        permissions: [
          'PLANNING_PERMIT_GRANT',
          'BUILDING_REGULATION_CERTIFY',
          'LAND_PARCEL_BOUNDARY_ADJUDICATE',
          'ENVIRONMENTAL_LICENCE_ISSUE',
        ],
        clearanceLevel: 'OFFICIAL',
      },
      {
        id: 'ROLE-PROCUREMENT-CHAIR',
        title: 'Head of Government Procurement',
        department: 'Cabinet Office Procurement Board',
        office: 'Central Procurement Directorate',
        mandate: 'Financial Regulations Procurement Code 2026',
        maxMonetaryLimit: 10000000,
        permissions: [
          'TENDER_PUBLISH',
          'BID_EVALUATION_RATIFY',
          'CONTRACT_AWARD_EXECUTE',
          'SUPPLIER_DISQUALIFY',
        ],
        clearanceLevel: 'SECRET',
      },
      {
        id: 'ROLE-CHIEF-ELECTORAL-OFFICER',
        title: 'Electoral Returning Officer',
        department: 'Clerk of Tynwald’s Office',
        office: 'Electoral Commission',
        mandate: 'Elections (Keys and Local Authorities) Act 2020',
        maxMonetaryLimit: 500000,
        permissions: [
          'ELECTORAL_REGISTER_CERTIFY',
          'CANDIDATE_NOMINATION_APPROVE',
          'POLL_RESULT_SEAL_LEDGER',
        ],
        clearanceLevel: 'SECRET',
      },
    ];

    for (const r of defaultRoles) {
      this.roles.set(r.id, r);
    }
  }

  public getRole(roleId: string): GovernmentRole | undefined {
    return this.roles.get(roleId);
  }

  public getAllRoles(): GovernmentRole[] {
    return Array.from(this.roles.values());
  }

  /**
   * Verifies if an actor holding a role (or valid delegated mandate) has authority
   * for an action and monetary amount.
   */
  public verifyAuthority(
    roleId: string,
    permissionRequired: string,
    monetaryAmount?: number
  ): {
    authorized: boolean;
    reason: string;
    office?: string;
    mandate?: string;
  } {
    const role = this.roles.get(roleId);
    if (!role) {
      return { authorized: false, reason: `Role identifier '${roleId}' is not registered in Sovereign Authority Registry.` };
    }

    if (!role.permissions.includes(permissionRequired)) {
      return {
        authorized: false,
        reason: `Role '${role.title}' does not possess explicit permission '${permissionRequired}'.`,
      };
    }

    if (monetaryAmount !== undefined && monetaryAmount > role.maxMonetaryLimit) {
      return {
        authorized: false,
        reason: `Requested transaction value (£${monetaryAmount.toLocaleString()}) exceeds statutory expenditure limit of £${role.maxMonetaryLimit.toLocaleString()} for '${role.title}'. Ministerial or Tynwald sanction required.`,
      };
    }

    return {
      authorized: true,
      reason: `Authorized under statutory mandate: ${role.mandate}`,
      office: role.office,
      mandate: role.mandate,
    };
  }

  public registerDelegation(delegation: DelegatedAuthority) {
    this.delegations.set(delegation.id, delegation);
  }

  public getDelegations(): DelegatedAuthority[] {
    return Array.from(this.delegations.values());
  }
}
