import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { GovernmentOSStore } from './core/state/government-os-store';
import { AIProvenanceEngine } from './core/ai/ai-provenance';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

const govStore = GovernmentOSStore.getInstance();

// ==========================================
// ELLAN VANNIN GOVERNMENT OS REST API ROUTES
// ==========================================

// 1. Status & Jurisdiction
app.get('/api/status', (req, res) => {
  const integrity = govStore.ledger.verifyLedgerIntegrity();
  res.json({
    status: 'OPERATIONAL',
    systemName: 'Ellan Vannin Government OS',
    version: '2026.3.8-SOVEREIGN',
    jurisdiction: govStore.activeJurisdiction,
    ledgerHeight: integrity.totalBlocks - 1,
    totalTransactions: integrity.totalTransactions,
    activeValidatorsCount: govStore.ledger.getValidators().filter(v => v.status === 'ACTIVE').length,
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/jurisdiction', (req, res) => {
  res.json({
    current: govStore.activeJurisdiction,
    available: govStore.availableJurisdictions,
  });
});

app.post('/api/jurisdiction/switch', (req, res) => {
  const { jurisdictionId } = req.body;
  if (!jurisdictionId) {
    res.status(400).json({ error: 'jurisdictionId is required' });
    return;
  }
  govStore.switchJurisdiction(jurisdictionId);
  res.json({ success: true, activeJurisdiction: govStore.activeJurisdiction });
});

// 2. Sovereign Ledger & Consensus
app.get('/api/ledger/blocks', (req, res) => {
  res.json({ blocks: govStore.ledger.getBlocks() });
});

app.get('/api/ledger/transactions', (req, res) => {
  const allTxs = govStore.ledger.getBlocks().flatMap(b => b.transactions);
  res.json({ transactions: allTxs });
});

app.get('/api/ledger/integrity', (req, res) => {
  const integrity = govStore.ledger.verifyLedgerIntegrity();
  res.json(integrity);
});

app.get('/api/validators', (req, res) => {
  res.json({ validators: govStore.ledger.getValidators() });
});

app.post('/api/validators/rotate', (req, res) => {
  const { validatorId, status } = req.body;
  govStore.ledger.rotateValidatorStatus(validatorId, status);
  res.json({ success: true, validators: govStore.ledger.getValidators() });
});

// 3. Registries
app.get('/api/identities', (req, res) => {
  res.json({ identities: govStore.registryEngine.getAllIdentities() });
});

app.post('/api/identities', (req, res) => {
  try {
    const newIdentity = govStore.registryEngine.createIdentity(req.body);
    res.status(201).json({ success: true, identity: newIdentity });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.get('/api/companies', (req, res) => {
  res.json({ companies: govStore.registryEngine.getAllCompanies() });
});

app.post('/api/companies/incorporate', (req, res) => {
  try {
    const company = govStore.registryEngine.incorporateCompany(req.body);
    res.status(201).json({ success: true, company });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.get('/api/properties', (req, res) => {
  res.json({ properties: govStore.registryEngine.getAllProperties() });
});

app.post('/api/properties/transfer', (req, res) => {
  try {
    const { propertyId, newOwnerId, newOwnerName, considerationValue } = req.body;
    const property = govStore.registryEngine.transferPropertyTitle(propertyId, newOwnerId, newOwnerName, Number(considerationValue));
    res.json({ success: true, property });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.get('/api/licences', (req, res) => {
  res.json({ licences: govStore.registryEngine.getAllLicences() });
});

app.get('/api/procurement/tenders', (req, res) => {
  res.json({ tenders: govStore.registryEngine.getAllProcurementTenders() });
});

app.post('/api/procurement/bids', (req, res) => {
  try {
    const { tenderId, bidderName, amount } = req.body;
    const tender = govStore.registryEngine.submitBid(tenderId, bidderName, Number(amount));
    res.json({ success: true, tender });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// 4. Treasury & Sovereign Balance Sheet
app.get('/api/treasury/balance-sheet', (req, res) => {
  res.json({ balanceSheet: govStore.registryEngine.getBalanceSheet() });
});

app.post('/api/treasury/tax-payment', (req, res) => {
  try {
    const { taxPayerName, amount, taxType } = req.body;
    govStore.registryEngine.recordTaxPayment(taxPayerName, Number(amount), taxType);
    res.json({ success: true, balanceSheet: govStore.registryEngine.getBalanceSheet() });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// 5. Policies & Authority
app.get('/api/policies', (req, res) => {
  res.json({ policies: govStore.policyEngine.getAllPolicies() });
});

app.post('/api/policies/evaluate', (req, res) => {
  const { policyCode, inputs, authority } = req.body;
  const result = govStore.policyEngine.evaluate(policyCode, inputs, authority);
  res.json({ result });
});

app.get('/api/authorities', (req, res) => {
  res.json({
    roles: govStore.authorityEngine.getAllRoles(),
    delegations: govStore.authorityEngine.getDelegations(),
  });
});

// 6. Workflows
app.get('/api/workflows', (req, res) => {
  res.json({ workflows: govStore.workflowEngine.getAllWorkflows() });
});

app.post('/api/workflows', (req, res) => {
  try {
    const workflow = govStore.workflowEngine.createWorkflow(req.body);
    res.status(201).json({ success: true, workflow });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.post('/api/workflows/transition', (req, res) => {
  try {
    const { workflowId, action, officerRoleId, officerName, notes } = req.body;
    const outcome = govStore.workflowEngine.executeTransition(workflowId, action, officerRoleId, officerName, notes);
    res.json(outcome);
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// 7. Audit Log
app.get('/api/audit', (req, res) => {
  res.json({ auditLog: govStore.ledger.getAuditLog() });
});

// 8. Public Verification Gateway
app.post('/api/public/verify', (req, res) => {
  const { query } = req.body;
  const verification = govStore.verifyPublicRecord(query || '');
  res.json(verification);
});

// 9. AI Institutional Assistant with Provenance
app.post('/api/ai/screen-bids', (req, res) => {
  const { tenderTitle, budgetCap, bids } = req.body;
  const provenance = AIProvenanceEngine.screenProcurementBids(tenderTitle, Number(budgetCap), bids || []);
  res.json(provenance);
});

app.post('/api/ai/analyze-policy', (req, res) => {
  const { policyCode, scenario } = req.body;
  const provenance = AIProvenanceEngine.analyzePolicyCompliance(policyCode, scenario);
  res.json(provenance);
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

