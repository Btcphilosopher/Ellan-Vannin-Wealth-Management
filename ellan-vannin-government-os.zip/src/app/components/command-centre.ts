/**
 * ELLAN VANNIN GOVERNMENT OS
 * Institutional Command Centre Component
 */

import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SovereignOSService } from '../services/sovereign-os.service';
import { WorkflowInstance } from '../../core/types/canonical-types';

@Component({
  selector: 'app-command-centre',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Top Institutional Banner / Quick KPI Matrix -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 relative overflow-hidden">
          <div class="flex items-center justify-between">
            <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Sovereign Ledger Height</span>
            <div class="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <mat-icon class="text-base">account_balance</mat-icon>
            </div>
          </div>
          <div class="mt-3 flex items-baseline gap-2">
            <span class="text-3xl font-bold font-mono text-slate-100">#{{ os.totalBlocksCount() - 1 }}</span>
            <span class="text-xs text-emerald-400 font-medium">Immutable Chain Sealed</span>
          </div>
          <div class="mt-2 text-xs text-slate-400 truncate">
            State Root: <span class="font-mono text-slate-300">{{ os.latestBlock()?.state_root?.slice(0, 16) }}...</span>
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5">
          <div class="flex items-center justify-between">
            <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Consensus Validators</span>
            <div class="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <mat-icon class="text-base">verified_user</mat-icon>
            </div>
          </div>
          <div class="mt-3 flex items-baseline gap-2">
            <span class="text-3xl font-bold font-mono text-slate-100">{{ os.activeValidatorsCount() }}/{{ os.validators().length }}</span>
            <span class="text-xs text-indigo-400 font-medium">Deterministic BFT</span>
          </div>
          <div class="mt-2 text-xs text-slate-400">
            Cabinet, Treasury, High Court, FSA Nodes
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5">
          <div class="flex items-center justify-between">
            <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Treasury Reserves (Cash)</span>
            <div class="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <mat-icon class="text-base">payments</mat-icon>
            </div>
          </div>
          <div class="mt-3 flex items-baseline gap-2">
            <span class="text-3xl font-bold font-mono text-slate-100">£{{ (os.balanceSheet().assets.cashAndTreasuryReserves / 1000000).toFixed(1) }}M</span>
            <span class="text-xs text-amber-400 font-medium">+£{{ (os.balanceSheet().revenueYTD.personalIncomeTax / 1000000).toFixed(1) }}M Tax YTD</span>
          </div>
          <div class="mt-2 text-xs text-slate-400">
            Sovereign Fund: £{{ (os.balanceSheet().assets.sovereignInvestmentFund / 1000000000).toFixed(2) }}B
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5">
          <div class="flex items-center justify-between">
            <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Statutory Approvals Queue</span>
            <div class="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <mat-icon class="text-base">pending_actions</mat-icon>
            </div>
          </div>
          <div class="mt-3 flex items-baseline gap-2">
            <span class="text-3xl font-bold font-mono text-slate-100">{{ os.pendingWorkflowsCount() }}</span>
            <span class="text-xs text-cyan-400 font-medium">Awaiting Mandate</span>
          </div>
          <div class="mt-2 text-xs text-slate-400">
            Total Entities: {{ os.identities().length }} Citizens, {{ os.companies().length }} Companies
          </div>
        </div>
      </div>

      <!-- Main Dual Grid: Workflows & Sovereign Balance Sheet -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Left Column: Statutory Workflow Execution Queue -->
        <div class="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-xl p-6">
          <div class="flex items-center justify-between mb-4">
            <div>
              <h2 class="text-lg font-bold text-slate-100 flex items-center gap-2">
                <mat-icon class="text-amber-400">gavel</mat-icon>
                Statutory State Transition & Approval Queue
              </h2>
              <p class="text-xs text-slate-400">Formal legal transitions requiring ministerial or officer mandate sign-off</p>
            </div>
            <button
              (click)="showNewWorkflowModal.set(true)"
              class="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
            >
              <mat-icon class="text-sm">add_circle</mat-icon>
              Initiate Application
            </button>
          </div>

          <div class="space-y-4">
            @for (wf of os.workflows(); track wf.id) {
              <div class="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 transition-all hover:border-slate-700">
                <div class="flex items-start justify-between gap-3">
                  <div>
                    <div class="flex items-center gap-2">
                      <span class="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">{{ wf.id }}</span>
                      <span
                        [class]="
                          wf.status === 'COMMITTED_TO_LEDGER'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            : wf.status === 'AUTHORIZED'
                            ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                            : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                        "
                        class="text-[11px] font-semibold px-2 py-0.5 rounded border uppercase tracking-wider"
                      >
                        {{ wf.status.replace('_', ' ') }}
                      </span>
                      <span class="text-xs text-slate-400">• {{ wf.workflowType.replace('_', ' ') }}</span>
                    </div>
                    <h3 class="text-sm font-semibold text-slate-200 mt-1.5">{{ wf.title }}</h3>
                    <div class="text-xs text-slate-400 mt-1 flex items-center gap-2">
                      <span>Initiator: <strong class="text-slate-300">{{ wf.initiatorName }}</strong></span>
                      <span>•</span>
                      <span>Assigned: <strong class="text-slate-300">{{ wf.assignedAuthority }}</strong></span>
                    </div>
                  </div>

                  <!-- Quick Action Buttons based on status -->
                  <div class="flex flex-col gap-1.5 items-end">
                    @if (wf.status === 'IN_REVIEW') {
                      <button
                        (click)="evaluatePolicy(wf)"
                        class="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium flex items-center gap-1 shadow-sm"
                      >
                        <mat-icon class="text-xs">rule</mat-icon>
                        Evaluate Policy
                      </button>
                    } @else if (wf.status === 'AUTHORIZED') {
                      <button
                        (click)="commitToLedger(wf)"
                        class="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium flex items-center gap-1 shadow-sm"
                      >
                        <mat-icon class="text-xs">verified</mat-icon>
                        Commit to Ledger
                      </button>
                    } @else if (wf.status === 'COMMITTED_TO_LEDGER') {
                      <span class="text-xs font-mono text-emerald-400 flex items-center gap-1">
                        <mat-icon class="text-xs">lock</mat-icon>
                        {{ wf.ledgerTxId }}
                      </span>
                    }
                  </div>
                </div>

                <!-- Step Checklist -->
                <div class="mt-3 pt-3 border-t border-slate-900 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  @for (step of wf.steps; track step.name) {
                    <div class="flex items-center gap-1.5">
                      <mat-icon
                        [class]="step.status === 'COMPLETED' ? 'text-emerald-400' : 'text-slate-600'"
                        class="text-sm"
                      >
                        {{ step.status === 'COMPLETED' ? 'check_circle' : 'radio_button_unchecked' }}
                      </mat-icon>
                      <span [class]="step.status === 'COMPLETED' ? 'text-slate-300' : 'text-slate-400'" class="truncate">
                        {{ step.name }}
                      </span>
                    </div>
                  }
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Right Column: Sovereign Balance Sheet & Treasury Orchestration -->
        <div class="lg:col-span-5 space-y-6">
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
            <div class="flex items-center justify-between mb-4">
              <div>
                <h2 class="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <mat-icon class="text-emerald-400">account_balance_wallet</mat-icon>
                  Sovereign Balance Sheet
                </h2>
                <p class="text-xs text-slate-400">Fiscal Year {{ os.balanceSheet().fiscalYear }} ({{ os.balanceSheet().currency }})</p>
              </div>
              <button
                (click)="showTaxPaymentModal.set(true)"
                class="px-2.5 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors"
              >
                <mat-icon class="text-sm">add</mat-icon>
                Record Tax Settlement
              </button>
            </div>

            <!-- Assets vs Liabilities Breakdown -->
            <div class="space-y-4">
              <div>
                <div class="flex justify-between text-xs text-slate-400 mb-1">
                  <span class="font-semibold text-emerald-400 uppercase tracking-wider">Sovereign Assets</span>
                  <span class="font-mono text-slate-200 font-bold">
                    £{{ ((os.balanceSheet().assets.cashAndTreasuryReserves + os.balanceSheet().assets.sovereignInvestmentFund + os.balanceSheet().assets.publicInfrastructureAndLand + os.balanceSheet().assets.taxReceivables) / 1000000000).toFixed(3) }}B
                  </span>
                </div>
                <div class="bg-slate-950/80 rounded-lg p-3 space-y-1.5 text-xs">
                  <div class="flex justify-between text-slate-300">
                    <span>Cash & Treasury Reserves</span>
                    <span class="font-mono font-medium">£{{ (os.balanceSheet().assets.cashAndTreasuryReserves / 1000000).toFixed(1) }}M</span>
                  </div>
                  <div class="flex justify-between text-slate-300">
                    <span>Sovereign Investment Fund</span>
                    <span class="font-mono font-medium">£{{ (os.balanceSheet().assets.sovereignInvestmentFund / 1000000).toFixed(1) }}M</span>
                  </div>
                  <div class="flex justify-between text-slate-300">
                    <span>Infrastructure, Crown & Public Land</span>
                    <span class="font-mono font-medium">£{{ (os.balanceSheet().assets.publicInfrastructureAndLand / 1000000).toFixed(1) }}M</span>
                  </div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-xs text-slate-400 mb-1">
                  <span class="font-semibold text-rose-400 uppercase tracking-wider">Sovereign Liabilities</span>
                  <span class="font-mono text-slate-200 font-bold">
                    £{{ ((os.balanceSheet().liabilities.nationalSovereignBonds + os.balanceSheet().liabilities.pensionLiabilities + os.balanceSheet().liabilities.procurementPayables + os.balanceSheet().liabilities.contingentGuarantees) / 1000000000).toFixed(3) }}B
                  </span>
                </div>
                <div class="bg-slate-950/80 rounded-lg p-3 space-y-1.5 text-xs">
                  <div class="flex justify-between text-slate-300">
                    <span>National Sovereign Bonds</span>
                    <span class="font-mono font-medium">£{{ (os.balanceSheet().liabilities.nationalSovereignBonds / 1000000).toFixed(1) }}M</span>
                  </div>
                  <div class="flex justify-between text-slate-300">
                    <span>Civil Service Pension Liabilities</span>
                    <span class="font-mono font-medium">£{{ (os.balanceSheet().liabilities.pensionLiabilities / 1000000).toFixed(1) }}M</span>
                  </div>
                  <div class="flex justify-between text-slate-300">
                    <span>Procurement Payables</span>
                    <span class="font-mono font-medium">£{{ (os.balanceSheet().liabilities.procurementPayables / 1000000).toFixed(1) }}M</span>
                  </div>
                </div>
              </div>

              <!-- Revenue vs Expenditure YTD -->
              <div class="pt-2 border-t border-slate-800 grid grid-cols-2 gap-3 text-xs">
                <div class="bg-emerald-950/30 border border-emerald-800/40 rounded-lg p-2.5">
                  <span class="text-emerald-400 font-semibold block text-[11px]">Revenue YTD</span>
                  <span class="text-base font-bold font-mono text-slate-100 mt-1 block">
                    £{{ ((os.balanceSheet().revenueYTD.personalIncomeTax + os.balanceSheet().revenueYTD.corporateTax + os.balanceSheet().revenueYTD.customsAndExcise + os.balanceSheet().revenueYTD.registryAndLicensingFees) / 1000000).toFixed(1) }}M
                  </span>
                  <span class="text-[10px] text-slate-400">0/10 Corporate + Income Tax</span>
                </div>
                <div class="bg-cyan-950/30 border border-cyan-800/40 rounded-lg p-2.5">
                  <span class="text-cyan-400 font-semibold block text-[11px]">Expenditure YTD</span>
                  <span class="text-base font-bold font-mono text-slate-100 mt-1 block">
                    £{{ ((os.balanceSheet().expenditureYTD.infrastructureAndWorks + os.balanceSheet().expenditureYTD.publicHealthAndServices + os.balanceSheet().expenditureYTD.educationAndResearch + os.balanceSheet().expenditureYTD.civilServiceAdministration) / 1000000).toFixed(1) }}M
                  </span>
                  <span class="text-[10px] text-slate-400">Health, Works, Education</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Live Tamper-Evident Audit Feed -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
            <div class="flex items-center justify-between mb-3">
              <h3 class="text-sm font-bold text-slate-200 flex items-center gap-1.5">
                <mat-icon class="text-slate-400 text-base">history_edu</mat-icon>
                Institutional Audit Stream
              </h3>
              <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                TAMPER-EVIDENT
              </span>
            </div>
            <div class="space-y-2 max-h-64 overflow-y-auto pr-1">
              @for (audit of os.auditLog().slice(0, 8); track audit.id) {
                <div class="bg-slate-950/60 border border-slate-800/60 rounded p-2 text-xs">
                  <div class="flex items-center justify-between text-[11px]">
                    <span class="font-mono font-bold text-amber-400">{{ audit.eventType }}</span>
                    <span class="text-slate-400 font-mono">{{ audit.timestamp.slice(11, 19) }}</span>
                  </div>
                  <div class="text-slate-300 mt-0.5 truncate">{{ audit.action }}</div>
                  <div class="text-[10px] text-slate-400 flex items-center justify-between mt-1">
                    <span>Actor: {{ audit.actorName }}</span>
                    <span class="font-mono text-slate-400">{{ audit.correlationId.slice(0, 14) }}...</span>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal: Record Tax Settlement -->
    @if (showTaxPaymentModal()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
        <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-emerald-400">payments</mat-icon>
              Record Statutory Tax Settlement
            </h3>
            <button (click)="showTaxPaymentModal.set(false)" class="text-slate-400 hover:text-slate-200">
              <mat-icon>close</mat-icon>
            </button>
          </div>
          <div class="space-y-3 text-xs">
            <div>
              <label for="taxPayerInput" class="block text-slate-400 mb-1 font-medium">Taxpayer Entity / Citizen</label>
              <input
                id="taxPayerInput"
                type="text"
                [(ngModel)]="taxPayerName"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label for="taxTypeSelect" class="block text-slate-400 mb-1 font-medium">Tax Regime / Schedule</label>
              <select
                id="taxTypeSelect"
                [(ngModel)]="taxType"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              >
                <option value="Personal Income Tax">Personal Income Tax (Standard Rate 10% / Higher 22%)</option>
                <option value="Corporate Tax (Banking/Retail)">Corporate Tax (10% FSA / 20% Property)</option>
                <option value="Customs & Excise Duty">Customs & Excise Tariff</option>
              </select>
            </div>
            <div>
              <label for="taxAmountInput" class="block text-slate-400 mb-1 font-medium">Settlement Amount (£ GBP)</label>
              <input
                id="taxAmountInput"
                type="number"
                [(ngModel)]="taxAmount"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>
          <div class="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              (click)="showTaxPaymentModal.set(false)"
              class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium"
            >
              Cancel
            </button>
            <button
              (click)="submitTaxPayment()"
              class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-md"
            >
              <mat-icon class="text-sm">receipt</mat-icon>
              Record & Commit to Ledger
            </button>
          </div>
        </div>
      </div>
    }

    <!-- Modal: Initiate New Application / Workflow -->
    @if (showNewWorkflowModal()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
        <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400">post_add</mat-icon>
              Initiate Statutory Workflow Application
            </h3>
            <button (click)="showNewWorkflowModal.set(false)" class="text-slate-400 hover:text-slate-200">
              <mat-icon>close</mat-icon>
            </button>
          </div>
          <div class="space-y-3 text-xs">
            <div>
              <label for="newWfTypeSelect" class="block text-slate-400 mb-1 font-medium">Workflow Category</label>
              <select
                id="newWfTypeSelect"
                [(ngModel)]="newWfType"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              >
                <option value="PLANNING_PERMIT">Statutory Planning & Development Permit</option>
                <option value="BUSINESS_INCORPORATION">Company Incorporation & Registry Seal</option>
                <option value="BENEFIT_APPLICATION">Universal Benefit & Income Support</option>
              </select>
            </div>
            <div>
              <label for="newWfTitleInput" class="block text-slate-400 mb-1 font-medium">Subject / Title</label>
              <input
                id="newWfTitleInput"
                type="text"
                [(ngModel)]="newWfTitle"
                placeholder="e.g. Planning Permission for Solar Array at Peel Harbour"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label for="newWfInitiatorInput" class="block text-slate-400 mb-1 font-medium">Applicant / Initiator Name</label>
              <input
                id="newWfInitiatorInput"
                type="text"
                [(ngModel)]="newWfInitiator"
                placeholder="e.g. Ewan Christian MHK"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>
          <div class="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              (click)="showNewWorkflowModal.set(false)"
              class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium"
            >
              Cancel
            </button>
            <button
              (click)="createWorkflow()"
              class="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-md"
            >
              <mat-icon class="text-sm">send</mat-icon>
              Submit Application
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class CommandCentreComponent {
  public os = inject(SovereignOSService);

  public showTaxPaymentModal = signal<boolean>(false);
  public showNewWorkflowModal = signal<boolean>(false);

  public taxPayerName = 'Manx Maritime Clean Propulsion Ltd';
  public taxType = 'Corporate Tax (Banking/Retail)';
  public taxAmount = 250000;

  public newWfType: WorkflowInstance['workflowType'] = 'PLANNING_PERMIT';
  public newWfTitle = 'Statutory Planning Permission for Peel Subsea Telemetry Substation';
  public newWfInitiator = 'Ewan Christian MHK';

  public evaluatePolicy(wf: WorkflowInstance) {
    this.os.transitionWorkflow(
      wf.id,
      'EVALUATE_POLICY',
      'ROLE-CHIEF-PLANNING-OFFICER',
      'Director of Planning & Building Control',
      'Automated statutory policy verification'
    );
  }

  public commitToLedger(wf: WorkflowInstance) {
    this.os.transitionWorkflow(
      wf.id,
      'COMMIT_LEDGER',
      'ROLE-MINISTER-TREASURY',
      'Minister for the Treasury',
      'Final constitutional ministerial warrant seal'
    );
  }

  public submitTaxPayment() {
    if (this.taxAmount > 0) {
      this.os.payTax(this.taxPayerName, this.taxAmount, this.taxType);
      this.showTaxPaymentModal.set(false);
    }
  }

  public createWorkflow() {
    if (!this.newWfTitle) return;

    this.os.createWorkflow({
      workflowType: this.newWfType,
      title: this.newWfTitle,
      initiatorId: 'did:ellan:gov:per:officer_session',
      initiatorName: this.newWfInitiator,
      assignedAuthority: 'ROLE-CHIEF-REGISTRAR-COMPANIES',
      deadline: new Date(Date.now() + 86400000 * 7).toISOString(),
      dataPayload: { title: this.newWfTitle, applicant: this.newWfInitiator }
    });
    this.os.refreshAllState();
    this.showNewWorkflowModal.set(false);
  }
}
