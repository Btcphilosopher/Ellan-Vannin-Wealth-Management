/**
 * ELLAN VANNIN GOVERNMENT OS
 * Sovereign Business Operating Portal Component
 */

import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SovereignOSService } from '../services/sovereign-os.service';
import { RegistryCompany, ProcurementTender } from '../../core/types/canonical-types';

@Component({
  selector: 'app-business-portal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Top Corporate Header & Selector -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="flex items-center gap-4">
          <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-cyan-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-institutional font-bold text-2xl shadow-inner">
            {{ activeCompany()?.legalName?.slice(0, 1) || 'B' }}
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xl font-bold text-slate-100">{{ activeCompany()?.legalName }}</h2>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold">
                {{ activeCompany()?.status?.replace('_', ' ') }}
              </span>
            </div>
            <div class="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-3">
              <span class="font-mono text-slate-300">Reg: {{ activeCompany()?.registrationNumber }}</span>
              <span>•</span>
              <span>Type: <strong class="text-slate-200">{{ activeCompany()?.type }}</strong></span>
              <span>•</span>
              <span>Share Capital: <strong class="text-slate-200">£{{ activeCompany()?.shareCapital?.toLocaleString() }}</strong></span>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <select
            [ngModel]="activeCompany()?.id"
            (ngModelChange)="os.selectCompany($event)"
            class="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
          >
            @for (co of os.companies(); track co.id) {
              <option [value]="co.id">{{ co.legalName }} ({{ co.registrationNumber }})</option>
            }
          </select>

          <button
            (click)="showIncorporateModal.set(true)"
            class="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-md transition-colors whitespace-nowrap"
          >
            <mat-icon class="text-sm">domain_add</mat-icon>
            Incorporate Company
          </button>
        </div>
      </div>

      <!-- Main Business OS Subsystems -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Left: Governance, Directors & Beneficial Ownership -->
        <div class="lg:col-span-6 space-y-6">
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2 mb-4">
              <mat-icon class="text-indigo-400">badge</mat-icon>
              Corporate Governance & Fiduciary Officers
            </h3>

            <div class="space-y-3">
              <div class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Registered Directors</div>
              @for (dir of activeCompany()?.directors; track dir.nationalId) {
                <div class="bg-slate-950/80 border border-slate-800 rounded-lg p-3 text-xs flex items-center justify-between">
                  <div>
                    <span class="font-bold text-slate-200">{{ dir.name }}</span>
                    <div class="text-slate-400 font-mono text-[11px]">National ID: {{ dir.nationalId }}</div>
                  </div>
                  <span class="text-slate-400 text-[11px]">Appointed: {{ dir.appointedDate }}</span>
                </div>
              }

              <div class="text-xs font-semibold text-slate-400 uppercase tracking-wider pt-2">Beneficial Ownership Register (AML 2017)</div>
              @for (bo of activeCompany()?.beneficialOwners; track bo.name) {
                <div class="bg-slate-950/80 border border-slate-800 rounded-lg p-3 text-xs flex items-center justify-between">
                  <div>
                    <span class="font-bold text-slate-200">{{ bo.name }}</span>
                    <div class="text-slate-400 text-[11px]">Nationality: {{ bo.nationality }}</div>
                  </div>
                  <span class="font-mono font-bold text-amber-400 text-xs">{{ bo.percentage }}% Holding</span>
                </div>
              }
            </div>

            <div class="mt-4 p-3 bg-indigo-950/30 border border-indigo-800/40 rounded-lg text-xs text-indigo-200">
              <span class="font-semibold block mb-0.5">Registered Office Address</span>
              {{ activeCompany()?.registeredOffice }}
            </div>
          </div>

          <!-- Property Title Conveyance Tool -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2 mb-2">
              <mat-icon class="text-emerald-400">swap_horiz</mat-icon>
              Cadastral Property Title Conveyance
            </h3>
            <p class="text-xs text-slate-400 mb-4">
              Execute a formal state transition conveying registered land parcels under the Land Registration Act 1982.
            </p>

            <div class="space-y-3 text-xs">
              <div>
                <label for="selectTransferPropSelect" class="block text-slate-400 mb-1 font-medium">Select Property Parcel</label>
                <select
                  id="selectTransferPropSelect"
                  [(ngModel)]="selectedTransferPropId"
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                >
                  @for (prop of os.properties(); track prop.id) {
                    <option [value]="prop.id">{{ prop.titleNumber }} — {{ prop.address }} (Owner: {{ prop.registeredOwnerName }})</option>
                  }
                </select>
              </div>

              <div>
                <label for="transferNewOwnerNameInput" class="block text-slate-400 mb-1 font-medium">Transferee (New Owner Legal Name)</label>
                <input
                  id="transferNewOwnerNameInput"
                  type="text"
                  [(ngModel)]="transferNewOwnerName"
                  placeholder="e.g. Ellan Vannin Digital Space Telemetry plc"
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label for="transferValueInput" class="block text-slate-400 mb-1 font-medium">Consideration Value (£ GBP)</label>
                <input
                  id="transferValueInput"
                  type="number"
                  [(ngModel)]="transferValue"
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div class="pt-2 flex justify-end">
                <button
                  (click)="executeConveyance()"
                  class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-xs flex items-center gap-1.5 shadow"
                >
                  <mat-icon class="text-sm">gavel</mat-icon>
                  Execute Conveyance State Transition
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Right: Institutional Procurement Tenders & Sealed Bid Portal -->
        <div class="lg:col-span-6 space-y-6">
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
            <div class="flex items-center justify-between mb-4">
              <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
                <mat-icon class="text-amber-400">gavel</mat-icon>
                Government Procurement & Sealed Tenders
              </h3>
              <span class="text-xs text-slate-400 font-mono">Financial Regulations 2026</span>
            </div>

            <div class="space-y-4">
              @for (tdr of os.tenders(); track tdr.id) {
                <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-3 text-xs">
                  <div class="flex items-start justify-between gap-3">
                    <div>
                      <div class="flex items-center gap-2">
                        <span class="text-[10px] font-mono font-bold text-amber-400">{{ tdr.referenceNumber }}</span>
                        <span
                          [class]="tdr.status === 'AWARDED' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'"
                          class="text-[10px] font-bold px-2 py-0.5 rounded border"
                        >
                          {{ tdr.status }}
                        </span>
                      </div>
                      <h4 class="text-sm font-bold text-slate-200 mt-1">{{ tdr.title }}</h4>
                      <p class="text-slate-400 mt-0.5">{{ tdr.procuringDepartment }} • Budget Cap: £{{ tdr.budgetAllocated.toLocaleString() }}</p>
                    </div>

                    @if (tdr.status === 'PUBLISHED') {
                      <button
                        (click)="openBidModal(tdr)"
                        class="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow whitespace-nowrap"
                      >
                        <mat-icon class="text-xs">upload_file</mat-icon>
                        Submit Sealed Bid
                      </button>
                    }
                  </div>

                  <!-- Bid List & AI Anomaly Screen -->
                  <div class="bg-slate-900/80 rounded-lg p-2.5 space-y-1.5">
                    <div class="flex justify-between items-center text-[11px] text-slate-400">
                      <span>Received Bids: {{ tdr.bidsReceived.length }} Envelopes</span>
                      <button
                        (click)="screenBidsWithAI(tdr)"
                        class="text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
                      >
                        <mat-icon class="text-xs">psychology</mat-icon> AI Anomaly Screen
                      </button>
                    </div>
                    @for (bid of tdr.bidsReceived; track bid.bidderName) {
                      <div class="flex justify-between text-slate-300 text-[11px] pt-1 border-t border-slate-800">
                        <span>{{ bid.bidderName }} @if (bid.evaluatedScore) { (Score: {{ bid.evaluatedScore }}) }</span>
                        <span class="font-mono font-bold">£{{ bid.amount.toLocaleString() }}</span>
                      </div>
                    }
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- AI Provenance Results Preview if any -->
          @if (os.aiAnalysis()) {
            <div class="bg-indigo-950/30 border border-indigo-800/50 rounded-xl p-5 space-y-3 text-xs">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                  <mat-icon class="text-indigo-400 text-sm">auto_awesome</mat-icon>
                  AI Statutory Provenance Record
                </span>
                <span class="text-[10px] font-mono text-indigo-400">{{ os.aiAnalysis()?.analysisId }}</span>
              </div>
              <div class="space-y-1 text-slate-300">
                @for (finding of os.aiAnalysis()?.findings; track finding) {
                  <div>{{ finding }}</div>
                }
              </div>
              <div class="pt-2 border-t border-indigo-900/50 text-[10px] text-amber-300/80 italic">
                {{ os.aiAnalysis()?.statutoryWarning }}
              </div>
            </div>
          }
        </div>
      </div>
    </div>

    <!-- Modal: Incorporate Company -->
    @if (showIncorporateModal()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
        <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-indigo-400">domain_add</mat-icon>
              Statutory Company Incorporation
            </h3>
            <button (click)="showIncorporateModal.set(false)" class="text-slate-400 hover:text-slate-200">
              <mat-icon>close</mat-icon>
            </button>
          </div>
          <div class="space-y-3 text-xs">
            <div>
              <label for="newCoNameInput" class="block text-slate-400 mb-1 font-medium">Proposed Legal Name</label>
              <input
                id="newCoNameInput"
                type="text"
                [(ngModel)]="newCoName"
                placeholder="e.g. Celtic Quantum Subsea Ltd"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-indigo-500 focus:outline-none"
              />
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label for="newCoTypeSelect" class="block text-slate-400 mb-1 font-medium">Company Structure</label>
                <select
                  id="newCoTypeSelect"
                  [(ngModel)]="newCoType"
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-indigo-500 focus:outline-none"
                >
                  <option value="LIMITED_COMPANY">Limited Company (1931/2006 Act)</option>
                  <option value="LLC">LLC (Limited Liability Company)</option>
                  <option value="PUBLIC_PLC">Public plc</option>
                </select>
              </div>
              <div>
                <label for="newCoCapitalInput" class="block text-slate-400 mb-1 font-medium">Authorised Share Capital (£)</label>
                <input
                  id="newCoCapitalInput"
                  type="number"
                  [(ngModel)]="newCoCapital"
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>
            <div>
              <label for="newCoOfficeInput" class="block text-slate-400 mb-1 font-medium">Registered Office in Isle of Man</label>
              <input
                id="newCoOfficeInput"
                type="text"
                [(ngModel)]="newCoOffice"
                placeholder="e.g. St. George’s Chambers, Athol Street, Douglas, IM1 1JA"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-indigo-500 focus:outline-none"
              />
            </div>
          </div>
          <div class="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              (click)="showIncorporateModal.set(false)"
              class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium"
            >
              Cancel
            </button>
            <button
              (click)="incorporate()"
              class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-md"
            >
              <mat-icon class="text-sm">verified</mat-icon>
              Incorporate & Seal in Ledger
            </button>
          </div>
        </div>
      </div>
    }

    <!-- Modal: Submit Tender Bid -->
    @if (showBidModal()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
        <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400">upload_file</mat-icon>
              Submit Cryptographic Tender Bid
            </h3>
            <button (click)="showBidModal.set(false)" class="text-slate-400 hover:text-slate-200">
              <mat-icon>close</mat-icon>
            </button>
          </div>
          <div class="space-y-3 text-xs">
            <div>
              <label for="bidTenderRefInput" class="block text-slate-400 mb-1 font-medium">Tender Reference</label>
              <input
                id="bidTenderRefInput"
                type="text"
                disabled
                [value]="activeTenderForBid?.referenceNumber"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-400 text-xs"
              />
            </div>
            <div>
              <label for="bidderNameInput" class="block text-slate-400 mb-1 font-medium">Bidding Company</label>
              <input
                id="bidderNameInput"
                type="text"
                [(ngModel)]="bidderName"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label for="bidAmountInput" class="block text-slate-400 mb-1 font-medium">Total Commercial Bid Amount (£ GBP)</label>
              <input
                id="bidAmountInput"
                type="number"
                [(ngModel)]="bidAmount"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>
          <div class="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              (click)="showBidModal.set(false)"
              class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium"
            >
              Cancel
            </button>
            <button
              (click)="submitBid()"
              class="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-md"
            >
              <mat-icon class="text-sm">lock</mat-icon>
              Seal Bid in Blockchain Envelope
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class BusinessPortalComponent {
  public os = inject(SovereignOSService);

  public showIncorporateModal = signal<boolean>(false);
  public showBidModal = signal<boolean>(false);

  public activeCompany = computed(() => this.os.currentCompany() || this.os.companies()[0]);

  // Incorporation fields
  public newCoName = 'Celtic Quantum Subsea Telemetry Ltd';
  public newCoType: RegistryCompany['type'] = 'LIMITED_COMPANY';
  public newCoCapital = 1000000;
  public newCoOffice = 'St. George’s Chambers, Athol Street, Douglas, IM1 1JA';

  // Conveyance fields
  public selectedTransferPropId = 'PROP-PEL-4410';
  public transferNewOwnerName = 'Manx Maritime Clean Propulsion Ltd';
  public transferValue = 485000;

  // Tender bid fields
  public activeTenderForBid: ProcurementTender | null = null;
  public bidderName = 'Douglas Sovereign Trust & Fiduciary Services LLC';
  public bidAmount = 21900000;

  public incorporate() {
    if (!this.newCoName) return;
    this.os.incorporateCompany({
      legalName: this.newCoName,
      jurisdictionId: 'JUR-ISLE-OF-MAN',
      type: this.newCoType,
      registeredOffice: this.newCoOffice,
      directors: [{ name: 'Siobhán Quayle', nationalId: 'EVN-9104-Q9', appointedDate: new Date().toISOString().split('T')[0] }],
      beneficialOwners: [{ name: 'Siobhán Quayle', percentage: 100, nationality: 'Manx' }],
      shareCapital: this.newCoCapital,
      currency: 'GBP',
    });
    this.showIncorporateModal.set(false);
  }

  public executeConveyance() {
    if (!this.selectedTransferPropId || !this.transferNewOwnerName) return;
    this.os.transferProperty(this.selectedTransferPropId, 'CO-138902-C', this.transferNewOwnerName, this.transferValue);
  }

  public openBidModal(tender: ProcurementTender) {
    this.activeTenderForBid = tender;
    this.bidAmount = tender.budgetAllocated * 0.95;
    this.showBidModal.set(true);
  }

  public submitBid() {
    if (!this.activeTenderForBid) return;
    this.os.submitTenderBid(this.activeTenderForBid.id, this.bidderName, this.bidAmount);
    this.showBidModal.set(false);
  }

  public screenBidsWithAI(tender: ProcurementTender) {
    this.os.screenTenderBids(tender);
  }
}
