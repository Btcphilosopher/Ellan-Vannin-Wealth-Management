/**
 * ELLAN VANNIN GOVERNMENT OS
 * Permissioned Sovereign Ledger Explorer Component
 */

import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SovereignOSService } from '../services/sovereign-os.service';
import { LedgerBlock, ValidatorNode } from '../../core/types/canonical-types';

@Component({
  selector: 'app-ledger-explorer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Top Ledger Metric & Chain Integrity Banner -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xl font-bold text-slate-100 flex items-center gap-2">
                <mat-icon class="text-emerald-400">lock</mat-icon>
                Sovereign Permissioned Ledger Explorer
              </h2>
              <span class="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                PROVENANCE SECURED
              </span>
            </div>
            <p class="text-xs text-slate-400 mt-1">
              Deterministic BFT Consensus • Round-Robin State Machine Replication • Dual SHA-256 Merkle Roots
            </p>
          </div>

          <div class="flex items-center gap-3">
            <button
              (click)="runFullAudit()"
              class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow transition-colors"
            >
              <mat-icon class="text-sm">verified_user</mat-icon>
              Run 10-Point Formal Invariants Audit
            </button>
          </div>
        </div>

        <!-- Audit Result Output (if triggered) -->
        @if (auditResult()) {
          <div class="mt-4 p-4 rounded-xl border bg-slate-950/90 border-emerald-500/40 space-y-2 text-xs font-mono">
            <div class="flex items-center justify-between text-emerald-400 font-bold">
              <span class="flex items-center gap-1.5">
                <mat-icon class="text-base">check_circle</mat-icon>
                {{ auditResult()?.isFullyValid ? 'Ledger Chain Verified & Untampered' : 'Ledger Invariant Violation Detected' }}
              </span>
              <span>Total Transactions: {{ auditResult()?.totalTransactions }}</span>
            </div>
            <div class="text-slate-400 text-[11px] grid grid-cols-1 md:grid-cols-3 gap-2 pt-1 border-t border-slate-800">
              <div>Blocks Verified: {{ auditResult()?.totalBlocks }}</div>
              <div>Status: {{ auditResult()?.isFullyValid ? 'PASSED' : 'FAILED' }}</div>
              <div>Verified At: {{ auditResult()?.verifiedAt?.slice(11, 19) }}</div>
            </div>
          </div>
        }
      </div>

      <!-- Main Ledger Visualizer: Block Chain & Transaction Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Left: Blocks Stream -->
        <div class="lg:col-span-5 space-y-4">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-slate-200 uppercase tracking-wider">Sealed Ledger Blocks</h3>
            <span class="text-xs font-mono text-slate-400">Total: {{ os.totalBlocksCount() }}</span>
          </div>

          <div class="space-y-3">
            @for (blk of os.blocks(); track blk.block_hash) {
              <button
                type="button"
                (click)="selectedBlock.set(blk)"
                [class]="
                  selectedBlock()?.block_hash === blk.block_hash
                    ? 'border-amber-500/70 bg-slate-900'
                    : 'border-slate-800/80 bg-slate-950/70 hover:border-slate-700'
                "
                class="w-full text-left border rounded-xl p-4 cursor-pointer transition-all relative overflow-hidden focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-amber-400">
                      Block #{{ blk.block_height }}
                    </span>
                    <span class="text-[10px] text-slate-400 font-mono">{{ blk.timestamp.slice(11, 19) }}</span>
                  </div>
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/30">
                    {{ blk.tx_count }} TXs
                  </span>
                </div>

                <div class="mt-2 text-xs text-slate-300 font-medium">
                  Validator: <strong class="text-slate-100">{{ blk.validator_name }}</strong>
                </div>

                <div class="mt-1 text-[11px] font-mono text-slate-400 truncate">
                  Hash: {{ blk.block_hash }}
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Right: Block & Transaction Deep Inspector -->
        <div class="lg:col-span-7 space-y-6">
          @if (selectedBlock(); as blk) {
            <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-4">
              <div class="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <div class="flex items-center gap-2">
                    <h3 class="text-lg font-bold text-slate-100 font-mono">Block #{{ blk.block_height }}</h3>
                    <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold">
                      FINALIZED
                    </span>
                  </div>
                  <p class="text-xs text-slate-400 mt-0.5">Sealed by {{ blk.validator_name }} ({{ blk.validator_id }})</p>
                </div>
                <div class="text-xs font-mono text-slate-400 text-right">
                  <div>{{ blk.timestamp }}</div>
                  <div>Jurisdiction: {{ os.activeJurisdiction().id }}</div>
                </div>
              </div>

              <!-- Cryptographic State Parameters -->
              <div class="bg-slate-950/90 rounded-xl p-4 border border-slate-800 space-y-2 text-xs font-mono">
                <div>
                  <span class="text-slate-500 block text-[11px]">Block Hash:</span>
                  <span class="text-amber-300 break-all">{{ blk.block_hash }}</span>
                </div>
                <div>
                  <span class="text-slate-500 block text-[11px]">Previous Block Hash:</span>
                  <span class="text-slate-400 break-all">{{ blk.previous_block_hash }}</span>
                </div>
                <div>
                  <span class="text-slate-500 block text-[11px]">State Commitment Root:</span>
                  <span class="text-emerald-300 break-all">{{ blk.state_root }}</span>
                </div>
                <div>
                  <span class="text-slate-500 block text-[11px]">Validator Ed25519 Signature:</span>
                  <span class="text-slate-400 break-all">{{ blk.validator_signature }}</span>
                </div>
              </div>

              <!-- Transactions in this Block -->
              <div>
                <h4 class="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Transactions In Block ({{ blk.transactions.length }})
                </h4>
                <div class="space-y-3">
                  @for (tx of blk.transactions; track tx.transaction_id) {
                    <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-2 text-xs">
                      <div class="flex items-start justify-between">
                        <div>
                          <div class="flex items-center gap-2">
                            <span class="font-mono font-bold text-amber-400">{{ tx.transaction_id }}</span>
                            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                              {{ tx.transaction_type }}
                            </span>
                          </div>
                          <p class="text-slate-200 font-semibold mt-1">{{ tx.payload_summary }}</p>
                        </div>
                        <span class="text-[10px] font-mono text-slate-400">{{ tx.timestamp.slice(11, 19) }}</span>
                      </div>

                      <div class="grid grid-cols-2 gap-2 text-[11px] text-slate-400 bg-slate-900/60 p-2.5 rounded-lg font-mono">
                        <div>Actor: <span class="text-slate-200">{{ tx.actor_name }}</span></div>
                        <div>Authority: <span class="text-slate-200">{{ tx.authority_id }}</span></div>
                        <div>Policy: <span class="text-slate-200">{{ tx.policy_version }}</span></div>
                        <div>Status: <span class="text-emerald-400">{{ tx.status }}</span></div>
                        <div class="col-span-2 text-[10px] text-slate-500 truncate">
                          Sig: {{ tx.signature }}
                        </div>
                      </div>
                    </div>
                  }
                </div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Consensus Validator Network -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-4">
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-indigo-400">dns</mat-icon>
              Constitutional Validator Network
            </h3>
            <p class="text-xs text-slate-400">Independent institutional nodes executing round-robin Byzantine consensus</p>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          @for (val of os.validators(); track val.id) {
            <div class="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2 text-xs">
              <div class="flex items-start justify-between">
                <div>
                  <h4 class="font-bold text-slate-200">{{ val.name }}</h4>
                  <div class="text-[11px] text-slate-400 font-mono">{{ val.id }}</div>
                </div>
                <span
                  [class]="val.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-rose-500/10 text-rose-400 border-rose-500/30'"
                  class="text-[10px] font-bold px-2 py-0.5 rounded border"
                >
                  {{ val.status }}
                </span>
              </div>

              <div class="space-y-1 font-mono text-[11px] text-slate-400 pt-1">
                <div class="truncate">Institution: {{ val.institution }}</div>
                <div class="truncate">Key: {{ val.publicKey }}</div>
                <div>Blocks Proposed: <strong class="text-slate-200">{{ val.blocksProposed }}</strong></div>
              </div>

              <div class="pt-2 border-t border-slate-800 flex justify-end">
                <button
                  (click)="toggleValidator(val.id, val.status)"
                  class="text-[10px] font-semibold text-indigo-400 hover:text-indigo-300"
                >
                  Rotate Status ({{ val.status === 'ACTIVE' ? 'Suspend' : 'Activate' }})
                </button>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class LedgerExplorerComponent {
  public os = inject(SovereignOSService);

  public selectedBlock = signal<LedgerBlock | null>(null);
  public auditResult = signal<ReturnType<SovereignOSService['ledgerIntegrity']> | null>(null);

  constructor() {
    if (this.os.blocks().length > 0) {
      this.selectedBlock.set(this.os.blocks()[0]);
    }
  }

  public runFullAudit() {
    const res = this.os.ledgerIntegrity();
    this.auditResult.set(res);
  }

  public toggleValidator(id: string, currentStatus: string) {
    const nextStatus: ValidatorNode['status'] = currentStatus === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
    this.os.rotateValidator(id, nextStatus);
  }
}
