/**
 * ELLAN VANNIN GOVERNMENT OS
 * Policy Engine, Authority & AI Provenance Component
 */

import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SovereignOSService } from '../services/sovereign-os.service';
import { PolicyEvaluationResult } from '../../core/types/canonical-types';

@Component({
  selector: 'app-policy-authority',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Top Governance Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
        <div class="flex items-center justify-between">
          <div>
            <h2 class="text-xl font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-indigo-400">rule</mat-icon>
              Declarative Policy Engine & Constitutional Mandates
            </h2>
            <p class="text-xs text-slate-400 mt-1">
              Versioned statutory rules • Deterministic policy evaluation • Multi-tier expenditure limits
            </p>
          </div>
          <span class="text-xs font-mono px-2.5 py-1 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 font-bold">
            ZERO BLACK-BOX GUARANTEE
          </span>
        </div>
      </div>

      <!-- Main Dual Column: Live Policy Simulator & Authority Mandates -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Left Column: Declarative Policy Simulator -->
        <div class="lg:col-span-7 space-y-6">
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-4">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400">tune</mat-icon>
              Interactive Statutory Policy Simulator
            </h3>

            <div class="space-y-3 text-xs">
              <div>
                <label for="selectPolicyCode" class="block text-slate-400 mb-1 font-medium">Select Statutory Policy</label>
                <select
                  id="selectPolicyCode"
                  [(ngModel)]="selectedPolicyCode"
                  (ngModelChange)="onPolicyChange()"
                  class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-amber-500"
                >
                  @for (pol of os.policies(); track pol.code) {
                    <option [value]="pol.code">{{ pol.code }}: {{ pol.title }} (v{{ pol.version }})</option>
                  }
                </select>
              </div>

              <!-- Dynamic Simulated Inputs based on policy -->
              @if (selectedPolicyCode === 'POL-PLANNING-001') {
                <div class="grid grid-cols-2 gap-3 bg-slate-950/70 p-4 rounded-xl border border-slate-800">
                  <div>
                    <label for="simPlanningConservationSelect" class="block text-slate-400 mb-1">Conservation Zone Area?</label>
                    <select id="simPlanningConservationSelect" [(ngModel)]="simPlanningConservation" class="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200">
                      <option [value]="false">No (Standard Zone)</option>
                      <option [value]="true">Yes (Conservation Area)</option>
                    </select>
                  </div>
                  <div>
                    <label for="simPlanningCategorySelect" class="block text-slate-400 mb-1">Parish Rate Category</label>
                    <select id="simPlanningCategorySelect" [(ngModel)]="simPlanningCategory" class="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200">
                      <option value="COMMERCIAL">Commercial Infrastructure</option>
                      <option value="RESIDENTIAL">Residential Property</option>
                    </select>
                  </div>
                </div>
              } @else if (selectedPolicyCode === 'POL-TAX-ZEROTEN') {
                <div class="grid grid-cols-2 gap-3 bg-slate-950/70 p-4 rounded-xl border border-slate-800">
                  <div>
                    <label for="simTaxSectorSelect" class="block text-slate-400 mb-1">Corporate Business Sector</label>
                    <select id="simTaxSectorSelect" [(ngModel)]="simTaxSector" class="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200">
                      <option value="GENERAL_COMMERCIAL">General Commercial / Tech / Digital</option>
                      <option value="BANKING_DEPOSIT_TAKERS">Banking & Deposit Taking (FSA)</option>
                      <option value="LAND_PROPERTY_DEVELOPMENT">Land & Real Estate Development</option>
                    </select>
                  </div>
                  <div>
                    <label for="simTaxProfitInput" class="block text-slate-400 mb-1">Taxable Corporate Profit (£)</label>
                    <input id="simTaxProfitInput" type="number" [(ngModel)]="simTaxProfit" class="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200" />
                  </div>
                </div>
              } @else if (selectedPolicyCode === 'POL-PROCURE-THRESHOLD') {
                <div class="grid grid-cols-2 gap-3 bg-slate-950/70 p-4 rounded-xl border border-slate-800">
                  <div>
                    <label for="simProcureAmountInput" class="block text-slate-400 mb-1">Tender Proposed Value (£)</label>
                    <input id="simProcureAmountInput" type="number" [(ngModel)]="simProcureAmount" class="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200" />
                  </div>
                  <div>
                    <label for="simProcureRoleSelect" class="block text-slate-400 mb-1">Signing Authority Role</label>
                    <select id="simProcureRoleSelect" [(ngModel)]="simProcureRole" class="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200">
                      <option value="ROLE-MINISTER-TREASURY">Minister for the Treasury (£50M Limit)</option>
                      <option value="ROLE-PROCUREMENT-CHAIR">Procurement Board Chair (£10M Limit)</option>
                      <option value="ROLE-CHIEF-PLANNING-OFFICER">Chief Planning Officer (£250k Limit)</option>
                    </select>
                  </div>
                </div>
              }

              <div class="flex justify-end pt-2">
                <button
                  (click)="runSimulator()"
                  class="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-semibold rounded-lg text-xs flex items-center gap-1.5 shadow"
                >
                  <mat-icon class="text-sm">play_arrow</mat-icon>
                  Execute Deterministic Policy Evaluation
                </button>
              </div>
            </div>

            <!-- Simulation Outcome Card -->
            @if (simResult(); as res) {
              <div
                [class]="res.decision === 'APPROVED' ? 'border-emerald-500/50 bg-emerald-950/20' : 'border-rose-500/50 bg-rose-950/20'"
                class="border rounded-xl p-4 space-y-2 text-xs font-mono"
              >
                <div class="flex items-center justify-between">
                  <span class="font-bold flex items-center gap-1.5 text-sm" [class]="res.decision === 'APPROVED' ? 'text-emerald-400' : 'text-rose-400'">
                    <mat-icon class="text-base">{{ res.decision === 'APPROVED' ? 'check_circle' : 'cancel' }}</mat-icon>
                    {{ res.decision }}
                  </span>
                  <span class="text-slate-400">Policy: {{ res.policyCode }}</span>
                </div>

                <div class="space-y-1 text-slate-300 font-sans">
                  @for (reason of res.reasons; track reason) {
                    <div>• {{ reason }}</div>
                  }
                </div>

                <div class="pt-2 border-t border-slate-800 text-[10px] text-slate-400 break-all">
                  Evidence Hash: <span class="text-amber-300">{{ res.evidenceHash }}</span>
                </div>
              </div>
            }
          </div>

          <!-- AI Provenance Institutional Assistant -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-4">
            <div class="flex items-center justify-between">
              <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
                <mat-icon class="text-indigo-400">psychology</mat-icon>
                AI Legal Synthesis & Provenance Trail
              </h3>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/30">
                HUMAN-IN-THE-LOOP MANDATORY
              </span>
            </div>

            <p class="text-xs text-slate-400">
              Test an institutional policy query using Gemini Sovereign Governance Model with mandatory provenance and legal disclaimer.
            </p>

            <div class="space-y-3 text-xs">
              <textarea
                [(ngModel)]="aiScenarioPrompt"
                rows="3"
                placeholder="Describe factual scenario for statutory synthesis..."
                class="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-slate-100 text-xs focus:outline-none focus:border-indigo-500 font-sans"
              ></textarea>

              <div class="flex justify-end">
                <button
                  (click)="runAIAnalysis()"
                  class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-xs flex items-center gap-1.5 shadow"
                >
                  <mat-icon class="text-sm">auto_awesome</mat-icon>
                  Synthesize Statutory Compliance
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Right Column: Statutory Roles & Authority Limits -->
        <div class="lg:col-span-5 space-y-6">
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-4">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-emerald-400">shield</mat-icon>
              Constitutional Roles & Expenditure Mandates
            </h3>

            <div class="space-y-3 text-xs">
              <div class="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-1">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-slate-100">Minister for the Treasury</span>
                  <span class="font-mono text-emerald-400 font-bold">Limit: £50,000,000</span>
                </div>
                <div class="text-slate-400 text-[11px]">Primary fiscal sanction, national bond issuance, sovereign fund allocation.</div>
              </div>

              <div class="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-1">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-slate-100">Procurement Board Chair</span>
                  <span class="font-mono text-emerald-400 font-bold">Limit: £10,000,000</span>
                </div>
                <div class="text-slate-400 text-[11px]">Commercial works evaluation, tender award ratification, supplier compliance.</div>
              </div>

              <div class="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-1">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-slate-100">Financial Services Commissioner</span>
                  <span class="font-mono text-emerald-400 font-bold">Limit: £5,000,000</span>
                </div>
                <div class="text-slate-400 text-[11px]">Banking licences, investment management, fiduciary supervision.</div>
              </div>

              <div class="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-1">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-slate-100">Chief Planning Officer</span>
                  <span class="font-mono text-emerald-400 font-bold">Limit: £250,000</span>
                </div>
                <div class="text-slate-400 text-[11px]">Development permits, cadastral zoning, building regulations endorsement.</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PolicyAuthorityComponent {
  public os = inject(SovereignOSService);

  public selectedPolicyCode = 'POL-PLANNING-001';

  // Simulator inputs
  public simPlanningConservation = false;
  public simPlanningCategory = 'COMMERCIAL';

  public simTaxSector = 'GENERAL_COMMERCIAL';
  public simTaxProfit = 500000;

  public simProcureAmount = 4500000;
  public simProcureRole = 'ROLE-PROCUREMENT-CHAIR';

  public simResult = signal<PolicyEvaluationResult | null>(null);

  public aiScenarioPrompt = 'Assess whether a subsea telemetry landing station in Peel requires environmental impact assessment under Town and Country Planning Act 1999.';

  public onPolicyChange() {
    this.simResult.set(null);
  }

  public runSimulator() {
    let inputs: Record<string, unknown> = {};
    if (this.selectedPolicyCode === 'POL-PLANNING-001') {
      inputs = {
        inConservationArea: String(this.simPlanningConservation) === 'true',
        proposalCategory: this.simPlanningCategory,
      };
    } else if (this.selectedPolicyCode === 'POL-TAX-ZEROTEN') {
      inputs = {
        sector: this.simTaxSector,
        taxableProfit: this.simTaxProfit,
      };
    } else if (this.selectedPolicyCode === 'POL-PROCURE-THRESHOLD') {
      inputs = {
        expenditureAmount: this.simProcureAmount,
      };
    }

    const res = this.os.evaluatePolicy(this.selectedPolicyCode, inputs, this.simProcureRole);
    this.simResult.set(res);
  }

  public runAIAnalysis() {
    this.os.analyzePolicyWithAI(this.selectedPolicyCode, this.aiScenarioPrompt);
  }
}
