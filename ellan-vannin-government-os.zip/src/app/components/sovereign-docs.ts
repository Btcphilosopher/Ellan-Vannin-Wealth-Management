/**
 * ELLAN VANNIN GOVERNMENT OS
 * Sovereign Technical Documentation Suite Component
 */

import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

type DocSection =
  | 'ARCHITECTURE'
  | 'SECURITY'
  | 'LEDGER'
  | 'PRIVACY'
  | 'DISASTER_RECOVERY'
  | 'FORMAL_INVARIANTS'
  | 'API_REFERENCE';

@Component({
  selector: 'app-sovereign-docs',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Top Documentation Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
        <div class="flex items-center justify-between">
          <div>
            <h2 class="text-xl font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400">menu_book</mat-icon>
              Sovereign Technical Specification & Constitutional Blueprints
            </h2>
            <p class="text-xs text-slate-400 mt-1">
              Ellan Vannin Government OS • Official System Architecture, Threat Models & Invariants
            </p>
          </div>
          <span class="text-xs font-mono px-2.5 py-1 rounded bg-slate-800 text-slate-300 border border-slate-700 font-bold">
            SPECIFICATION v2026.3.8
          </span>
        </div>
      </div>

      <!-- Navigation Tabs & Content Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Sidebar Navigation Tabs -->
        <div class="lg:col-span-3 space-y-1">
          <button
            (click)="activeSection.set('ARCHITECTURE')"
            [class]="activeSection() === 'ARCHITECTURE' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'"
            class="w-full text-left px-4 py-3 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all"
          >
            <mat-icon class="text-base">account_tree</mat-icon>
            1. System Architecture
          </button>

          <button
            (click)="activeSection() === 'FORMAL_INVARIANTS' ? null : activeSection.set('FORMAL_INVARIANTS')"
            [class]="activeSection() === 'FORMAL_INVARIANTS' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'"
            class="w-full text-left px-4 py-3 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all"
          >
            <mat-icon class="text-base">verified</mat-icon>
            2. Formal Invariants (10 Rules)
          </button>

          <button
            (click)="activeSection.set('SECURITY')"
            [class]="activeSection() === 'SECURITY' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'"
            class="w-full text-left px-4 py-3 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all"
          >
            <mat-icon class="text-base">security</mat-icon>
            3. Security & Threat Model
          </button>

          <button
            (click)="activeSection.set('LEDGER')"
            [class]="activeSection() === 'LEDGER' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'"
            class="w-full text-left px-4 py-3 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all"
          >
            <mat-icon class="text-base">lock</mat-icon>
            4. Ledger & Consensus Model
          </button>

          <button
            (click)="activeSection.set('PRIVACY')"
            [class]="activeSection() === 'PRIVACY' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'"
            class="w-full text-left px-4 py-3 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all"
          >
            <mat-icon class="text-base">visibility_off</mat-icon>
            5. Privacy & Data Sovereignty
          </button>

          <button
            (click)="activeSection.set('DISASTER_RECOVERY')"
            [class]="activeSection() === 'DISASTER_RECOVERY' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'"
            class="w-full text-left px-4 py-3 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all"
          >
            <mat-icon class="text-base">cloud_sync</mat-icon>
            6. Air-Gap & Disaster Recovery
          </button>

          <button
            (click)="activeSection.set('API_REFERENCE')"
            [class]="activeSection() === 'API_REFERENCE' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'"
            class="w-full text-left px-4 py-3 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all"
          >
            <mat-icon class="text-base">code</mat-icon>
            7. REST API Endpoints
          </button>
        </div>

        <!-- Documentation Content Panel -->
        <div class="lg:col-span-9 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 lg:p-8 text-slate-300 space-y-6 text-sm">
          @switch (activeSection()) {
            @case ('ARCHITECTURE') {
              <div>
                <h3 class="text-xl font-bold text-slate-100 font-institutional">1. Sovereign Architecture Overview</h3>
                <p class="mt-2 text-slate-400 text-xs">
                  Ellan Vannin Government OS is structured as a layered, modular, sovereign operating environment.
                  State transitions must be validated across independent layers before committing to permanent storage.
                </p>

                <div class="mt-4 space-y-4">
                  <div class="bg-slate-950/80 rounded-xl p-4 border border-slate-800 space-y-1">
                    <span class="font-bold text-amber-400 text-xs uppercase tracking-wider">Layer 1: Deterministic Sovereign Ledger</span>
                    <p class="text-xs text-slate-300">
                      An append-only, permissioned cryptographic chain with deterministic Byzantine Fault Tolerant (BFT) consensus across constitutional nodes (Cabinet Office, Treasury, High Court, Financial Services Authority). Maintains Merkle state roots.
                    </p>
                  </div>

                  <div class="bg-slate-950/80 rounded-xl p-4 border border-slate-800 space-y-1">
                    <span class="font-bold text-emerald-400 text-xs uppercase tracking-wider">Layer 2: Canonical Registries Engine</span>
                    <p class="text-xs text-slate-300">
                      Standardized data stores for People (Identity & DIDs), Legal Entities (Companies 1931/2006 Acts), Cadastral Land & Property, Universal Statutory Licences, and Double-Entry Sovereign Balance Sheet.
                    </p>
                  </div>

                  <div class="bg-slate-950/80 rounded-xl p-4 border border-slate-800 space-y-1">
                    <span class="font-bold text-indigo-400 text-xs uppercase tracking-wider">Layer 3: Declarative Policy & Authority Machinery</span>
                    <p class="text-xs text-slate-300">
                      Versioned, statutory logic executed deterministically. Every state transition evaluates statutory rules, statutory spending thresholds, and mandates with full evidence hashes.
                    </p>
                  </div>

                  <div class="bg-slate-950/80 rounded-xl p-4 border border-slate-800 space-y-1">
                    <span class="font-bold text-cyan-400 text-xs uppercase tracking-wider">Layer 4: AI Institutional Provenance</span>
                    <p class="text-xs text-slate-300">
                      Advisory AI assistance for anomaly detection and legal summarization. Governed by zero black-box guarantees and mandatory human-in-the-loop ministerial review.
                    </p>
                  </div>
                </div>
              </div>
            }

            @case ('FORMAL_INVARIANTS') {
              <div>
                <h3 class="text-xl font-bold text-slate-100 font-institutional">2. The 10 Formal Sovereign Invariants</h3>
                <p class="mt-2 text-slate-400 text-xs">
                  Every transaction and block in Ellan Vannin Government OS mathematically adheres to these 10 invariants:
                </p>

                <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
                    <strong class="text-amber-400 block mb-1">1. Append-Only State</strong>
                    Past blocks and historical state hashes can never be altered, mutated, or removed.
                  </div>
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
                    <strong class="text-amber-400 block mb-1">2. No Unsigned Transitions</strong>
                    Every transaction must carry valid cryptographic Ed25519 signatures from authorized actors.
                  </div>
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
                    <strong class="text-amber-400 block mb-1">3. Deterministic Policy Verification</strong>
                    Policy evaluations must produce identical evidence hashes given identical state inputs.
                  </div>
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
                    <strong class="text-amber-400 block mb-1">4. Double-Entry Balance Conservation</strong>
                    In the Sovereign Balance Sheet, sum of Debits must strictly equal Credits (Conservation of Public Value).
                  </div>
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
                    <strong class="text-amber-400 block mb-1">5. Cadastral Uniqueness</strong>
                    No land parcel or title number may be registered to multiple owners concurrently without joint tenancy.
                  </div>
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
                    <strong class="text-amber-400 block mb-1">6. Spending Threshold Enforcement</strong>
                    No authority may approve expenditure exceeding statutory mandate limits without superior countersignatures.
                  </div>
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
                    <strong class="text-amber-400 block mb-1">7. AI Accountability (No Black Box)</strong>
                    AI may advise, but consequential public rights must be sealed by human statutory officers.
                  </div>
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
                    <strong class="text-amber-400 block mb-1">8. Sovereign Multi-Party Consensus</strong>
                    Blocks are proposed round-robin and verified by constitutional nodes before finalization.
                  </div>
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
                    <strong class="text-amber-400 block mb-1">9. Public Verifiability</strong>
                    Any citizen or auditor can verify authenticity of state records without disclosing private attributes.
                  </div>
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
                    <strong class="text-amber-400 block mb-1">10. Complete Audit Traceability</strong>
                    Every operational state change records an immutable audit log entry linked to the transaction root.
                  </div>
                </div>
              </div>
            }

            @case ('SECURITY') {
              <div>
                <h3 class="text-xl font-bold text-slate-100 font-institutional">3. Security Architecture & Threat Model</h3>
                <div class="mt-4 space-y-3 text-xs">
                  <div class="bg-slate-950/80 rounded-xl p-4 border border-slate-800">
                    <strong class="text-slate-200 block text-sm mb-1">Threat: Malicious Validator Collusion</strong>
                    <p class="text-slate-400">
                      Mitigated via 4-way constitutional node distribution (Executive, Treasury, Judiciary, Regulator). Corrupting a single branch cannot produce a valid block state transition without consensus violation detection.
                    </p>
                  </div>
                  <div class="bg-slate-950/80 rounded-xl p-4 border border-slate-800">
                    <strong class="text-slate-200 block text-sm mb-1">Threat: Cryptographic Key Compromise</strong>
                    <p class="text-slate-400">
                      Validator and officer keys undergo automated rotational status management. Revoked keys immediately invalidate future state transition proposals while preserving historic audit validity.
                    </p>
                  </div>
                </div>
              </div>
            }

            @case ('LEDGER') {
              <div>
                <h3 class="text-xl font-bold text-slate-100 font-institutional">4. Sovereign Ledger & Consensus Model</h3>
                <div class="mt-4 space-y-3 text-xs">
                  <p class="text-slate-300">
                    The ledger employs a deterministic Round-Robin Byzantine Fault Tolerant state machine.
                    Each block bundles state transactions, calculates their transactional Merkle tree root, and computes a cumulative state root representing the unified canonical state of all registries.
                  </p>
                  <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-[11px] text-amber-300">
                    <div>BlockHeader &#123;</div>
                    <div class="pl-4">block_height: uint64,</div>
                    <div class="pl-4">previous_block_hash: sha256_hex,</div>
                    <div class="pl-4">tx_merkle_root: sha256_hex,</div>
                    <div class="pl-4">state_root: sha256_hex,</div>
                    <div class="pl-4">validator_signature: ed25519_sig</div>
                    <div>&#125;</div>
                  </div>
                </div>
              </div>
            }

            @case ('PRIVACY') {
              <div>
                <h3 class="text-xl font-bold text-slate-100 font-institutional">5. Privacy & Data Protection Compliance</h3>
                <div class="mt-4 space-y-3 text-xs">
                  <p class="text-slate-300">
                    Adheres strictly to the Isle of Man Data Protection Act 2018 and GDPR standards.
                    PII is held in encrypted, access-controlled canonical registries.
                    Only non-reversible cryptographic hashes and Zero-Knowledge proofs are committed to the public ledger stream.
                  </p>
                </div>
              </div>
            }

            @case ('DISASTER_RECOVERY') {
              <div>
                <h3 class="text-xl font-bold text-slate-100 font-institutional">6. Air-Gap & Disaster Recovery</h3>
                <div class="mt-4 space-y-3 text-xs">
                  <p class="text-slate-300">
                    Periodic state checkpoints are sealed with all active validator signatures.
                    Snapshot tarballs can be restored to cold, air-gapped sovereign environments within 60 seconds with 100% mathematical integrity verification.
                  </p>
                </div>
              </div>
            }

            @case ('API_REFERENCE') {
              <div>
                <h3 class="text-xl font-bold text-slate-100 font-institutional">7. REST API Endpoints Specification</h3>
                <div class="mt-4 space-y-2 text-xs font-mono">
                  <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <span><strong class="text-emerald-400">GET</strong> /api/status</span>
                    <span class="text-slate-400">System health & ledger height</span>
                  </div>
                  <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <span><strong class="text-emerald-400">GET</strong> /api/ledger/blocks</span>
                    <span class="text-slate-400">Query immutable block chain</span>
                  </div>
                  <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <span><strong class="text-indigo-400">POST</strong> /api/public/verify</span>
                    <span class="text-slate-400">Verify document, licence or transaction</span>
                  </div>
                  <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <span><strong class="text-indigo-400">POST</strong> /api/ai/screen-bids</span>
                    <span class="text-slate-400">Screen procurement bids for anomalies</span>
                  </div>
                </div>
              </div>
            }
          }
        </div>
      </div>
    </div>
  `,
})
export class SovereignDocsComponent {
  public activeSection = signal<DocSection>('ARCHITECTURE');
}
