/**
 * ELLAN VANNIN GOVERNMENT OS
 * Sovereign Citizen Portal (MyGov) Component
 */

import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SovereignOSService } from '../services/sovereign-os.service';

@Component({
  selector: 'app-citizen-portal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Top Citizen Profile Bar & Selector -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div class="flex items-center gap-4">
          <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500/20 to-indigo-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 font-institutional font-bold text-2xl shadow-inner">
            {{ activeCitizen()?.fullName?.slice(0, 1) || 'C' }}
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xl font-bold text-slate-100">{{ activeCitizen()?.fullName }}</h2>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold">
                {{ activeCitizen()?.assuranceLevel?.replace('_', ' ') }}
              </span>
            </div>
            <div class="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-3">
              <span class="font-mono text-slate-300">DID: {{ activeCitizen()?.id }}</span>
              <span>•</span>
              <span>National ID: <strong class="text-slate-200">{{ activeCitizen()?.nationalIdentifier }}</strong></span>
              <span>•</span>
              <span>Parish: <strong class="text-slate-200">{{ activeCitizen()?.metadata?.['residenceParish'] }}</strong></span>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <select
            [ngModel]="activeCitizen()?.id"
            (ngModelChange)="os.selectCitizen($event)"
            class="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
          >
            @for (cit of os.identities(); track cit.id) {
              <option [value]="cit.id">{{ cit.fullName }} ({{ cit.nationalIdentifier }})</option>
            }
          </select>

          <button
            (click)="showEnrolModal.set(true)"
            class="px-3 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-md transition-colors whitespace-nowrap"
          >
            <mat-icon class="text-sm">badge</mat-icon>
            Enrol Identity
          </button>
        </div>
      </div>

      <!-- Navigation Grid for Citizen Services -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Left: Verifiable Credentials & Digital Identity Wallet -->
        <div class="lg:col-span-6 space-y-6">
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
            <div class="flex items-center justify-between mb-4">
              <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
                <mat-icon class="text-amber-400">verified</mat-icon>
                Sovereign Digital Credentials Wallet
              </h3>
              <span class="text-xs text-slate-400">Cryptographically verifiable offline</span>
            </div>

            <div class="space-y-4">
              @for (cred of activeCitizen()?.credentials; track cred.id) {
                <div class="bg-gradient-to-r from-slate-950 to-slate-900 border border-slate-800 rounded-xl p-4 relative overflow-hidden group hover:border-amber-500/40 transition-all">
                  <div class="flex items-start justify-between">
                    <div>
                      <span class="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400/90">{{ cred.type.replace('_', ' ') }}</span>
                      <h4 class="text-sm font-bold text-slate-200 mt-0.5">{{ cred.issuerTitle }}</h4>
                      <p class="text-xs text-slate-400 mt-1">Issued: {{ cred.issuanceDate }} @if (cred.expiryDate) { • Exp: {{ cred.expiryDate }} }</p>
                    </div>
                    <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-semibold">
                      {{ cred.status }}
                    </span>
                  </div>

                  <div class="mt-3 bg-slate-950/80 rounded-lg p-2.5 text-xs text-slate-300 font-mono space-y-1">
                    <div class="text-[11px] text-slate-400 truncate">Claims Hash: {{ cred.claimsHash }}</div>
                    <div class="text-[11px] text-slate-400 truncate">Sig: {{ cred.signature }}</div>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Digital Mailbox & Official Notices -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2 mb-4">
              <mat-icon class="text-cyan-400">mark_email_read</mat-icon>
              Sovereign Digital Mailbox (Gov.im)
            </h3>
            <div class="space-y-3 text-xs">
              <div class="bg-slate-950/70 border border-slate-800 rounded-lg p-3">
                <div class="flex items-center justify-between text-slate-400 text-[11px]">
                  <span class="font-semibold text-slate-300">Income Tax Division</span>
                  <span>10 Sept 2026</span>
                </div>
                <div class="text-slate-200 font-medium mt-1">Statutory Notice of Tax Assessment 2025/26 Available</div>
                <div class="text-slate-400 mt-0.5">Your annual personal allowance and statutory calculation have been sealed into the ledger.</div>
              </div>

              <div class="bg-slate-950/70 border border-slate-800 rounded-lg p-3">
                <div class="flex items-center justify-between text-slate-400 text-[11px]">
                  <span class="font-semibold text-slate-300">General Registry (Land Deeds)</span>
                  <span>02 Aug 2026</span>
                </div>
                <div class="text-slate-200 font-medium mt-1">Cadastral Title Register Update: Peel Harbour Pavilion</div>
                <div class="text-slate-400 mt-0.5">Planning consent PA-25-00114-A has been endorsed onto the public title register.</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Right: Registered Properties & Direct Services -->
        <div class="lg:col-span-6 space-y-6">
          <!-- Land & Property Registered to Citizen -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
            <div class="flex items-center justify-between mb-4">
              <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
                <mat-icon class="text-emerald-400">home_work</mat-icon>
                Registered Property & Land Titles
              </h3>
              <span class="text-xs text-slate-400 font-mono">HM Land Registry IM</span>
            </div>

            @if (citizenProperties().length === 0) {
              <div class="bg-slate-950/50 border border-slate-800 rounded-xl p-4 text-center text-xs text-slate-400">
                No freehold or leasehold properties currently registered to this citizen DID.
              </div>
            } @else {
              <div class="space-y-4">
                @for (prop of citizenProperties(); track prop.id) {
                  <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-2 text-xs">
                    <div class="flex items-start justify-between">
                      <div>
                        <span class="text-[10px] font-mono text-amber-400 font-bold">{{ prop.titleNumber }}</span>
                        <h4 class="text-sm font-bold text-slate-100 mt-0.5">{{ prop.address }}</h4>
                        <div class="text-slate-400 mt-0.5">Zone: {{ prop.cadastralZone }} • Tenure: {{ prop.tenure }}</div>
                      </div>
                      <span class="text-xs font-mono font-bold text-slate-200">Rateable: £{{ prop.rateableValue.toLocaleString() }}</span>
                    </div>

                    @if (prop.planningPermissions.length > 0) {
                      <div class="bg-slate-900/80 rounded-lg p-2.5 mt-2">
                        <div class="text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
                          <mat-icon class="text-xs">architecture</mat-icon>
                          Active Planning Permission: {{ prop.planningPermissions[0].refNumber }}
                        </div>
                        <div class="text-slate-300 text-[11px] mt-0.5">{{ prop.planningPermissions[0].proposal }}</div>
                      </div>
                    }
                  </div>
                }
              </div>
            }
          </div>

          <!-- Direct Tax Settlement Widget for Citizen -->
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2 mb-3">
              <mat-icon class="text-amber-400">receipt_long</mat-icon>
              Income Tax Division Self-Assessment
            </h3>
            <p class="text-xs text-slate-400 mb-4">
              Isle of Man Individual Tax Rate: 10% standard rate (first £6,500 over £14,500 allowance) and 22% higher rate.
            </p>

            <div class="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3 text-xs">
              <div class="flex justify-between items-center text-slate-300">
                <span>Personal Tax Allowance (2026/27):</span>
                <span class="font-mono font-bold text-slate-100">£14,500.00</span>
              </div>
              <div class="flex justify-between items-center text-slate-300">
                <span>Current Estimated Assessment:</span>
                <span class="font-mono font-bold text-slate-100">£4,200.00</span>
              </div>
              <div class="flex justify-between items-center text-slate-300">
                <span>Payment Status:</span>
                <span class="text-emerald-400 font-semibold flex items-center gap-1">
                  <mat-icon class="text-xs">check_circle</mat-icon> Up to date
                </span>
              </div>

              <div class="pt-2 border-t border-slate-800 flex justify-end">
                <button
                  (click)="payCitizenTax()"
                  class="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-semibold rounded-lg text-xs flex items-center gap-1.5 shadow"
                >
                  <mat-icon class="text-sm">payments</mat-icon>
                  Make Voluntary Interim Tax Payment (£500)
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal: Enrol New Identity -->
    @if (showEnrolModal()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
        <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400">person_add</mat-icon>
              Enrol Sovereign Citizen Identity
            </h3>
            <button (click)="showEnrolModal.set(false)" class="text-slate-400 hover:text-slate-200">
              <mat-icon>close</mat-icon>
            </button>
          </div>
          <div class="space-y-3 text-xs">
            <div>
              <label for="newCitizenNameInput" class="block text-slate-400 mb-1 font-medium">Full Legal Name</label>
              <input
                id="newCitizenNameInput"
                type="text"
                [(ngModel)]="newName"
                placeholder="e.g. Aalin Shimmin"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label for="newNatIdInput" class="block text-slate-400 mb-1 font-medium">National Identifier</label>
              <input
                id="newNatIdInput"
                type="text"
                [(ngModel)]="newNatId"
                placeholder="e.g. EVN-9820-S3"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label for="newParishSelect" class="block text-slate-400 mb-1 font-medium">Parish of Residence</label>
              <select
                id="newParishSelect"
                [(ngModel)]="newParish"
                class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-xs focus:border-amber-500 focus:outline-none"
              >
                <option value="Douglas">Douglas (Doolish)</option>
                <option value="Peel">Peel (Purt ny h-Inshey)</option>
                <option value="Ramsey">Ramsey (Rhumsaa)</option>
                <option value="Castletown">Castletown (Balley Chashtal)</option>
                <option value="Braddan">Braddan</option>
                <option value="Onchan">Onchan</option>
              </select>
            </div>
          </div>
          <div class="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              (click)="showEnrolModal.set(false)"
              class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium"
            >
              Cancel
            </button>
            <button
              (click)="enrolIdentity()"
              class="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 shadow-md"
            >
              <mat-icon class="text-sm">verified</mat-icon>
              Enrol & Issue AL4 Credential
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class CitizenPortalComponent {
  public os = inject(SovereignOSService);

  public showEnrolModal = signal<boolean>(false);

  public newName = 'Aalin Shimmin';
  public newNatId = 'EVN-9820-S3';
  public newParish = 'Castletown';

  public activeCitizen = computed(() => this.os.currentCitizen() || this.os.identities()[0]);

  public citizenProperties = computed(() => {
    const cit = this.activeCitizen();
    if (!cit) return [];
    return this.os.properties().filter(p => p.registeredOwnerId === cit.id || p.registeredOwnerName === cit.fullName);
  });

  public payCitizenTax() {
    const cit = this.activeCitizen();
    if (!cit) return;
    this.os.payTax(cit.fullName, 500, 'Personal Income Tax (Interim)');
  }

  public enrolIdentity() {
    if (!this.newName) return;
    this.os.createIdentity({
      subjectType: 'CITIZEN',
      fullName: this.newName,
      nationalIdentifier: this.newNatId,
      jurisdictionId: 'JUR-ISLE-OF-MAN',
      assuranceLevel: 'AL4_SOVEREIGN',
      status: 'ACTIVE',
      publicKey: `PUB_KEY_ED25519_${this.newName.toUpperCase().replace(/\s+/g, '_')}_${Math.floor(1000 + Math.random() * 9000)}`,
      metadata: {
        residenceParish: this.newParish,
        digitalMailboxAddress: `${this.newName.toLowerCase().replace(/\s+/g, '.')}@gov.im.box`,
      },
    });
    this.showEnrolModal.set(false);
  }
}
