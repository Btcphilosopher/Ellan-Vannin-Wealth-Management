/**
 * ELLAN VANNIN GOVERNMENT OS
 * Public Transparency & Cryptographic Verification Gazette Component
 */

import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SovereignOSService } from '../services/sovereign-os.service';

@Component({
  selector: 'app-public-verification',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Public Verification Hero Search -->
      <div class="bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 rounded-2xl p-8 relative overflow-hidden">
        <div class="max-w-3xl">
          <div class="flex items-center gap-2 mb-2">
            <span class="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              OPEN CITIZEN & AUDITOR GATEWAY
            </span>
            <span class="text-xs text-slate-400">• Zero-Knowledge Proof & Merkle State Engine</span>
          </div>
          <h2 class="text-2xl lg:text-3xl font-bold text-slate-100 font-institutional tracking-wide">
            Sovereign Document & Transaction Verifier
          </h2>
          <p class="text-sm text-slate-300 mt-2">
            Verify any statutory document, land title, corporate status, digital licence, or ledger transaction.
            Every valid record is anchored to the Ellan Vannin Sovereign Ledger state root.
          </p>

          <!-- Search Input Box -->
          <div class="mt-6 flex flex-col sm:flex-row gap-2">
            <div class="relative flex-1">
              <mat-icon class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">search</mat-icon>
              <input
                type="text"
                [(ngModel)]="searchQuery"
                (keyup.enter)="verify()"
                placeholder="Enter Transaction ID, Title Number, Company No, Licence ID, or Block Hash..."
                class="w-full bg-slate-950/90 border border-slate-700/80 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all font-mono"
              />
            </div>
            <button
              (click)="verify()"
              [disabled]="os.isVerifying()"
              class="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 transition-colors shadow-lg disabled:opacity-50"
            >
              <mat-icon class="text-base">verified</mat-icon>
              <span>{{ os.isVerifying() ? 'Verifying...' : 'Verify Cryptographically' }}</span>
            </button>
          </div>

          <!-- Sample Quick Query Chips -->
          <div class="mt-4 flex flex-wrap items-center gap-2 text-xs">
            <span class="text-slate-400 font-medium">Quick Verify Samples:</span>
            <button
              (click)="quickVerify('IOM-TITLE-DGL-8821')"
              class="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-lg font-mono border border-slate-700 transition-colors"
            >
              Land Title: IOM-TITLE-DGL-8821
            </button>
            <button
              (click)="quickVerify('CO-138902-C')"
              class="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-lg font-mono border border-slate-700 transition-colors"
            >
              Company: CO-138902-C
            </button>
            <button
              (click)="quickVerify('FSA-INV-2026-004')"
              class="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-lg font-mono border border-slate-700 transition-colors"
            >
              FSA Licence: FSA-INV-2026-004
            </button>
            <button
              (click)="quickVerify('TX-GENESIS-001')"
              class="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-lg font-mono border border-slate-700 transition-colors"
            >
              Genesis Tx: TX-GENESIS-001
            </button>
          </div>
        </div>
      </div>

      <!-- Verification Result Card (if any) -->
      @if (os.lastVerification(); as res) {
        <div
          [class]="
            res.isValid
              ? 'bg-slate-900/95 border-emerald-500/50 shadow-emerald-950/20'
              : 'bg-slate-900/95 border-rose-500/50 shadow-rose-950/20'
          "
          class="border rounded-2xl p-6 shadow-2xl space-y-4"
        >
          <div class="flex items-start justify-between">
            <div class="flex items-center gap-3">
              <div
                [class]="res.isValid ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-rose-500/10 text-rose-400 border-rose-500/30'"
                class="w-12 h-12 rounded-xl border flex items-center justify-center"
              >
                <mat-icon class="text-2xl">{{ res.isValid ? 'verified' : 'gpp_bad' }}</mat-icon>
              </div>
              <div>
                <div class="flex items-center gap-2">
                  <span class="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">{{ res.itemType }}</span>
                  <span
                    [class]="res.isValid ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-rose-500/10 text-rose-400 border-rose-500/30'"
                    class="text-[10px] font-bold px-2 py-0.5 rounded border"
                  >
                    {{ res.isValid ? 'VALID • STATE ROOT CONFIRMED' : 'UNVERIFIED RECORD' }}
                  </span>
                </div>
                <h3 class="text-lg font-bold text-slate-100 mt-0.5 font-mono">{{ res.identifier }}</h3>
              </div>
            </div>

            <div class="text-right text-xs text-slate-400 font-mono">
              <div>Block Height: #{{ res.blockHeight }}</div>
              <div>{{ res.timestamp }}</div>
            </div>
          </div>

          <!-- Cryptographic Details Matrix -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono bg-slate-950/80 rounded-xl p-4 border border-slate-800">
            <div>
              <span class="text-slate-500 text-[11px] block">Issuing Constitutional Authority:</span>
              <span class="text-slate-200 font-medium font-sans">{{ res.issuingAuthority }}</span>
            </div>
            <div>
              <span class="text-slate-500 text-[11px] block">Security Classification:</span>
              <span class="text-emerald-400 font-semibold">{{ res.classification }}</span>
            </div>
            <div class="col-span-1 md:col-span-2">
              <span class="text-slate-500 text-[11px] block">Audit Payload SHA-256 Hash:</span>
              <span class="text-amber-300 break-all">{{ res.auditHash }}</span>
            </div>
            <div class="col-span-1 md:col-span-2">
              <span class="text-slate-500 text-[11px] block">Institutional Cryptographic Signature:</span>
              <span class="text-indigo-300 break-all">{{ res.cryptographicSignature }}</span>
            </div>
          </div>

          <!-- Payload Dynamic Metadata -->
          <div class="pt-2">
            <span class="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 block">Statutory Record Metadata</span>
            <div class="bg-slate-950/60 rounded-xl p-4 text-xs space-y-1.5 font-sans">
              @for (entry of getEntries(res.details); track entry[0]) {
                <div class="flex justify-between border-b border-slate-800/60 pb-1 text-slate-300">
                  <span class="text-slate-400 capitalize">{{ entry[0].replace(/([A-Z])/g, ' $1') }}:</span>
                  <span class="font-medium text-slate-100 text-right">{{ entry[1] }}</span>
                </div>
              }
            </div>
          </div>
        </div>
      }

      <!-- Public Gazette Stream -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-4">
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-base font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400">newspaper</mat-icon>
              Official Government Gazette & Public Contracts
            </h3>
            <p class="text-xs text-slate-400">Statutory public notices, enacted primary legislation, and approved procurement awards</p>
          </div>
          <span class="text-xs font-mono text-emerald-400 flex items-center gap-1">
            <mat-icon class="text-sm">rss_feed</mat-icon> Live Gazette Feed
          </span>
        </div>

        <div class="space-y-3 text-xs">
          <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-4">
            <div class="flex items-center justify-between text-[11px] text-slate-400">
              <span class="font-bold text-amber-400">STATUTORY INSTRUMENT • TYNWALD ACT</span>
              <span class="font-mono">10 Sept 2026</span>
            </div>
            <h4 class="text-sm font-bold text-slate-200 mt-1">Sovereign Artificial Intelligence Governance & Provenance Order 2026</h4>
            <p class="text-slate-400 mt-1">
              Enacted by the Queen's Most Excellent Majesty, by and with the advice and consent of the Council and Keys in Tynwald assembled.
              Establishes mandatory cryptographic audit trails for AI institutional advisory agents.
            </p>
            <div class="mt-2 text-[10px] font-mono text-slate-500">
              State Root Proof: <span class="text-slate-400">0x7f44a991c49b0123...</span>
            </div>
          </div>

          <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-4">
            <div class="flex items-center justify-between text-[11px] text-slate-400">
              <span class="font-bold text-emerald-400">PROCUREMENT AWARD NOTICE</span>
              <span class="font-mono">08 Sept 2026</span>
            </div>
            <h4 class="text-sm font-bold text-slate-200 mt-1">Contract Award: Peel Harbour Deepwater Berth & Subsea Power Feeder</h4>
            <p class="text-slate-400 mt-1">
              Procuring Department: Department of Infrastructure. Contractor: Celtic Subsea Works Ltd.
              Total Committed Value: £21,900,000.00. Evaluated under the Financial Regulations Procurement Code 2026.
            </p>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PublicVerificationComponent {
  public os = inject(SovereignOSService);

  public searchQuery = 'IOM-TITLE-DGL-8821';

  public verify() {
    if (!this.searchQuery) return;
    this.os.verifyPublicQuery(this.searchQuery);
  }

  public quickVerify(query: string) {
    this.searchQuery = query;
    this.verify();
  }

  public getEntries(obj: Record<string, unknown> | null | undefined): [string, unknown][] {
    if (!obj) return [];
    return Object.entries(obj);
  }
}
