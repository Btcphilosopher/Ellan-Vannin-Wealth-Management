/**
 * ELLAN VANNIN GOVERNMENT OS
 * Sovereign Client Service
 * 
 * Manages institutional application state using Angular Signals.
 * Connects UI seamlessly to Sovereign Ledger, Registries, Policy, and Workflow engines.
 */

import { Injectable, signal, computed } from '@angular/core';
import {
  DigitalIdentity,
  RegistryCompany,
  RegistryProperty,
  RegistryLicence,
  ProcurementTender,
  SovereignBalanceSheet,
  LedgerBlock,
  ValidatorNode,
  AuditEvent,
  DeclarativePolicy,
  PolicyEvaluationResult,
  WorkflowInstance,
  JurisdictionProfile,
  PublicVerificationResult,
} from '../../core/types/canonical-types';
import { GovernmentOSStore } from '../../core/state/government-os-store';
import { AIProvenanceEngine, AIProvenanceRecord } from '../../core/ai/ai-provenance';

export type ActivePortalView =
  | 'COMMAND_CENTRE'
  | 'CITIZEN_PORTAL'
  | 'BUSINESS_PORTAL'
  | 'PUBLIC_VERIFICATION'
  | 'LEDGER_EXPLORER'
  | 'POLICY_AUTHORITY'
  | 'SOVEREIGN_DOCS';

@Injectable({
  providedIn: 'root',
})
export class SovereignOSService {
  private store = GovernmentOSStore.getInstance();

  // Active portal tab
  public activePortal = signal<ActivePortalView>('COMMAND_CENTRE');

  // Core signals
  public activeJurisdiction = signal<JurisdictionProfile>(this.store.activeJurisdiction);
  public availableJurisdictions = signal<JurisdictionProfile[]>(this.store.availableJurisdictions);

  public blocks = signal<LedgerBlock[]>(this.store.ledger.getBlocks());
  public validators = signal<ValidatorNode[]>(this.store.ledger.getValidators());
  public auditLog = signal<AuditEvent[]>(this.store.ledger.getAuditLog());
  public balanceSheet = signal<SovereignBalanceSheet>(this.store.registryEngine.getBalanceSheet());

  public identities = signal<DigitalIdentity[]>(this.store.registryEngine.getAllIdentities());
  public companies = signal<RegistryCompany[]>(this.store.registryEngine.getAllCompanies());
  public properties = signal<RegistryProperty[]>(this.store.registryEngine.getAllProperties());
  public licences = signal<RegistryLicence[]>(this.store.registryEngine.getAllLicences());
  public tenders = signal<ProcurementTender[]>(this.store.registryEngine.getAllProcurementTenders());
  public workflows = signal<WorkflowInstance[]>(this.store.workflowEngine.getAllWorkflows());
  public policies = signal<DeclarativePolicy[]>(this.store.policyEngine.getAllPolicies());

  // Active selected identity for Citizen Portal (defaults to Ewan Christian MHK)
  public currentCitizen = signal<DigitalIdentity | null>(null);

  // Active selected company for Business Portal
  public currentCompany = signal<RegistryCompany | null>(null);

  // System status metrics
  public ledgerIntegrity = computed(() => this.store.ledger.verifyLedgerIntegrity());
  public totalBlocksCount = computed(() => this.blocks().length);
  public latestBlock = computed(() => this.blocks()[0]);
  public activeValidatorsCount = computed(() => this.validators().filter(v => v.status === 'ACTIVE').length);
  public pendingWorkflowsCount = computed(() => this.workflows().filter(w => w.status !== 'COMMITTED_TO_LEDGER' && w.status !== 'REJECTED').length);

  // Verification results
  public lastVerification = signal<PublicVerificationResult | null>(null);
  public isVerifying = signal<boolean>(false);

  // AI Provenance results
  public aiAnalysis = signal<AIProvenanceRecord | null>(null);

  constructor() {
    this.refreshAllState();
    if (this.identities().length > 0) {
      this.currentCitizen.set(this.identities()[0]);
    }
    if (this.companies().length > 0) {
      this.currentCompany.set(this.companies()[0]);
    }
  }

  public refreshAllState() {
    this.activeJurisdiction.set(this.store.activeJurisdiction);
    this.blocks.set(this.store.ledger.getBlocks());
    this.validators.set(this.store.ledger.getValidators());
    this.auditLog.set(this.store.ledger.getAuditLog());
    this.balanceSheet.set(this.store.registryEngine.getBalanceSheet());
    this.identities.set(this.store.registryEngine.getAllIdentities());
    this.companies.set(this.store.registryEngine.getAllCompanies());
    this.properties.set(this.store.registryEngine.getAllProperties());
    this.licences.set(this.store.registryEngine.getAllLicences());
    this.tenders.set(this.store.registryEngine.getAllProcurementTenders());
    this.workflows.set(this.store.workflowEngine.getAllWorkflows());
    this.policies.set(this.store.policyEngine.getAllPolicies());
  }

  public setPortal(portal: ActivePortalView) {
    this.activePortal.set(portal);
  }

  public switchJurisdiction(jurisdictionId: string) {
    this.store.switchJurisdiction(jurisdictionId);
    this.refreshAllState();
  }

  public selectCitizen(id: string) {
    const found = this.identities().find(i => i.id === id);
    if (found) this.currentCitizen.set(found);
  }

  public selectCompany(id: string) {
    const found = this.companies().find(c => c.id === id);
    if (found) this.currentCompany.set(found);
  }

  // Workflows
  public transitionWorkflow(
    workflowId: string,
    action: 'EVALUATE_POLICY' | 'AUTHORIZE_STEP' | 'REJECT' | 'COMMIT_LEDGER',
    officerRoleId: string,
    officerName: string,
    notes?: string
  ) {
    const res = this.store.workflowEngine.executeTransition(workflowId, action, officerRoleId, officerName, notes);
    this.refreshAllState();
    return res;
  }

  public createWorkflow(data: { workflowType: WorkflowInstance['workflowType']; title: string; initiatorId: string; initiatorName: string; assignedAuthority: string; deadline?: string; dataPayload?: Record<string, unknown> }) {
    const defaultSteps = [
      { name: 'Initial Application Submission', status: 'COMPLETED' as const, completedBy: data.initiatorName, completedAt: new Date().toISOString() },
      { name: 'Statutory Verification', status: 'PENDING' as const },
      { name: 'Authority Approval', status: 'PENDING' as const },
    ];
    const created = this.store.workflowEngine.createWorkflow({
      currentStep: 'Initial Application Submission',
      steps: defaultSteps,
      deadline: data.deadline || new Date(Date.now() + 86400000 * 7).toISOString(),
      dataPayload: data.dataPayload || {},
      ...data,
    });
    this.refreshAllState();
    return created;
  }

  // Registries Actions
  public createIdentity(data: Omit<DigitalIdentity, 'id' | 'createdAt' | 'updatedAt' | 'credentials' | 'delegations'>) {
    const created = this.store.registryEngine.createIdentity(data);
    this.refreshAllState();
    return created;
  }

  public incorporateCompany(data: Omit<RegistryCompany, 'id' | 'registrationNumber' | 'incorporationDate' | 'status' | 'lastFilingDate'>) {
    const created = this.store.registryEngine.incorporateCompany(data);
    this.refreshAllState();
    return created;
  }

  public transferProperty(propertyId: string, newOwnerId: string, newOwnerName: string, considerationValue: number) {
    const updated = this.store.registryEngine.transferPropertyTitle(propertyId, newOwnerId, newOwnerName, considerationValue);
    this.refreshAllState();
    return updated;
  }

  public submitTenderBid(tenderId: string, bidderName: string, amount: number) {
    const updated = this.store.registryEngine.submitBid(tenderId, bidderName, amount);
    this.refreshAllState();
    return updated;
  }

  public payTax(taxPayerName: string, amount: number, taxType: string) {
    this.store.registryEngine.recordTaxPayment(taxPayerName, amount, taxType);
    this.refreshAllState();
  }

  // Policy Evaluation
  public evaluatePolicy(policyCode: string, inputs: Record<string, unknown>, authority?: string): PolicyEvaluationResult {
    return this.store.policyEngine.evaluate(policyCode, inputs, authority);
  }

  // Public Verification
  public verifyPublicQuery(query: string) {
    this.isVerifying.set(true);
    setTimeout(() => {
      const res = this.store.verifyPublicRecord(query);
      this.lastVerification.set(res);
      this.isVerifying.set(false);
    }, 200);
  }

  // AI Institutional Assistants
  public screenTenderBids(tender: ProcurementTender) {
    const res = AIProvenanceEngine.screenProcurementBids(tender.title, tender.budgetAllocated, tender.bidsReceived);
    this.aiAnalysis.set(res);
    return res;
  }

  public analyzePolicyWithAI(policyCode: string, scenario: string) {
    const res = AIProvenanceEngine.analyzePolicyCompliance(policyCode, scenario);
    this.aiAnalysis.set(res);
    return res;
  }

  // Validator rotation
  public rotateValidator(validatorId: string, status: ValidatorNode['status']) {
    this.store.ledger.rotateValidatorStatus(validatorId, status);
    this.refreshAllState();
  }
}
