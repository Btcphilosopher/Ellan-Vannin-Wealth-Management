import { ChangeDetectionStrategy, Component, inject, signal, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SovereignOSService, ActivePortalView } from './services/sovereign-os.service';
import { CommandCentreComponent } from './components/command-centre';
import { CitizenPortalComponent } from './components/citizen-portal';
import { BusinessPortalComponent } from './components/business-portal';
import { PublicVerificationComponent } from './components/public-verification';
import { LedgerExplorerComponent } from './components/ledger-explorer';
import { PolicyAuthorityComponent } from './components/policy-authority';
import { SovereignDocsComponent } from './components/sovereign-docs';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    FormsModule,
    MatIconModule,
    CommandCentreComponent,
    CitizenPortalComponent,
    BusinessPortalComponent,
    PublicVerificationComponent,
    LedgerExplorerComponent,
    PolicyAuthorityComponent,
    SovereignDocsComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, OnDestroy {
  public os = inject(SovereignOSService);
  public institutionalTime = signal<string>('');
  private timerId: ReturnType<typeof setInterval> | null = null;

  ngOnInit() {
    this.updateClock();
    this.timerId = setInterval(() => this.updateClock(), 1000);
  }

  ngOnDestroy() {
    if (this.timerId) clearInterval(this.timerId);
  }

  private updateClock() {
    const now = new Date();
    this.institutionalTime.set(
      now.toLocaleTimeString('en-GB', {
        timeZone: 'UTC',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      }) + ' UTC'
    );
  }

  public setTab(tab: ActivePortalView) {
    this.os.setPortal(tab);
  }
}

