package com.example.domain.model

enum class ContainerStatus {
    BOOKED,
    EMPTY,
    GATED_IN,
    YARD,
    LOADED,
    ON_VESSEL,
    DISCHARGING,
    TRANSHIPMENT,
    RAIL,
    TRUCK,
    WAREHOUSE,
    CUSTOMS_HOLD,
    DELIVERED,
    RETURNED,
    DAMAGED,
    EXCEPTION
}

enum class CargoHazard {
    NORMAL,
    CONTROLLED,
    HAZARDOUS,
    SPECIAL_HANDLING
}

enum class CraneType {
    QUAY_CRANE,
    RTG,
    RMG
}

enum class CraneStatus {
    IDLE,
    MOVING,
    PICKING,
    LIFTING,
    TRAVELLING,
    LOWERING,
    PLACING,
    FAULT,
    MAINTENANCE
}

enum class TruckStatus {
    AVAILABLE,
    ASSIGNED,
    DRIVING_EMPTY,
    APPROACHING,
    LOADED,
    DELIVERING,
    CHARGING,
    FAULT
}

enum class TrainStatus {
    LOADING,
    READY,
    EN_ROUTE,
    DELAYED,
    ARRIVED
}

enum class VesselStatus {
    BERTHED,
    DISCHARGING,
    LOADING,
    ANCHORED,
    DEPARTED
}

enum class EventSeverity {
    INFO,
    WARNING,
    ALARM,
    CRITICAL
}

enum class WorkOrderStatus {
    CREATED,
    ASSIGNED,
    IN_PROGRESS,
    WAITING_PARTS,
    COMPLETED,
    VERIFIED,
    CLOSED
}

enum class ScenarioType {
    NORMAL_TERMINAL,
    VESSEL_ARRIVAL,
    PORT_CONGESTION,
    CRANE_FAILURE,
    RAIL_DELAY,
    TRUCK_SURGE,
    REEFER_FAILURE,
    YARD_SATURATION,
    STORM,
    WAREHOUSE_BOTTLENECK
}

data class Container(
    val id: String,
    val isoType: String = "45R1",
    val sizeFeet: Int = 40,
    val weightTonnes: Double = 22.4,
    val cargoType: String = "Pharma Cold Chain",
    val origin: String = "NINGBO",
    val destination: String = "ROTTERDAM",
    val currentLocation: String = "YARD BLOCK B14",
    val nextLocation: String = "RAIL TERMINAL",
    val status: ContainerStatus = ContainerStatus.YARD,
    val owner: String = "MAERSK",
    val operator: String = "SYN-LOGISTICS",
    val bookingRef: String = "BK-992140",
    val voyage: String = "VY-8842",
    val railService: String = "TR204",
    val truckAssignment: String = "ATV-042",
    val temperatureC: Double = 4.2,
    val setpointC: Double = 4.0,
    val isReefer: Boolean = true,
    val humidityPct: Int = 61,
    val doorStatus: String = "SEALED",
    val shockG: Double = 0.12,
    val tiltDeg: Double = 1.4,
    val batteryPct: Int = 82,
    val sealStatus: String = "VERIFIED #SL-992",
    val customsStatus: String = "CLEARED",
    val hazardStatus: CargoHazard = CargoHazard.NORMAL,
    val lastScan: String = "10:23:14",
    val dwellHours: Int = 18,
    val block: String = "B14",
    val bay: Int = 7,
    val stack: Int = 3,
    val tier: Int = 2
)

data class Crane(
    val id: String,
    val name: String,
    val type: CraneType,
    val status: CraneStatus = CraneStatus.IDLE,
    val positionPct: Float = 0.45f,
    val trolleyPct: Float = 0.60f,
    val boomState: String = "DOWN",
    val loadTonnes: Double = 0.0,
    val energyMw: Double = 1.4,
    val currentContainerId: String? = null,
    val cycleTimeSec: Int = 42,
    val cyclesTotal: Int = 182492,
    val remainingUsefulLifeHrs: Int = 126,
    val motorTempC: Double = 68.5,
    val vibrationG: Double = 0.18,
    val faultMessage: String? = null
)

data class TerminalTruck(
    val id: String,
    val name: String,
    val status: TruckStatus = TruckStatus.AVAILABLE,
    val mission: String = "QC07 -> BLOCK B14",
    val containerId: String? = "CXRU-482193-7",
    val batteryPct: Int = 74,
    val speedKmh: Int = 18,
    val etaMins: Double = 4.5,
    val posX: Float = 0.35f,
    val posY: Float = 0.55f
)

data class Wagon(
    val id: Int,
    val wagonType: String = "Sgnss",
    val containerId: String? = null,
    val weightTonnes: Double = 0.0,
    val isSecured: Boolean = true
)

data class Train(
    val id: String,
    val route: String = "ROTTERDAM -> DUISBURG",
    val wagonsCount: Int = 42,
    val containersLoaded: Int = 30,
    val loadingPct: Int = 71,
    val departureTime: String = "14:35",
    val eta: String = "18:20",
    val status: TrainStatus = TrainStatus.LOADING,
    val wagons: List<Wagon> = emptyList()
)

data class VesselStowageSlot(
    val bay: Int,
    val row: Int,
    val tier: Int,
    val containerId: String? = null,
    val weightTonnes: Double = 0.0,
    val destination: String = "ROTTERDAM",
    val hazardStatus: CargoHazard = CargoHazard.NORMAL,
    val isReefer: Boolean = false,
    val conflictWarning: String? = null
)

data class Vessel(
    val id: String,
    val name: String = "MV NORTH STAR",
    val imo: String = "SYN-48291",
    val lengthM: Int = 366,
    val teuCapacity: Int = 14000,
    val currentBerth: String = "BERTH 04",
    val status: VesselStatus = VesselStatus.DISCHARGING,
    val baysLoadedPct: Int = 64,
    val eta: String = "08:00"
)

data class YardSlot(
    val block: String,
    val bay: Int,
    val stack: Int,
    val tier: Int,
    val containerId: String? = null,
    val dwellHours: Int = 0,
    val optimizationScore: Double = 82.4,
    val recommendedAction: String = "READY FOR RAIL"
)

data class AMR(
    val id: String,
    val mission: String = "PICKUP DOCK-03",
    val location: String = "RACK A-14",
    val destination: String = "DOCK-03",
    val batteryPct: Int = 61,
    val status: String = "EXECUTING"
)

data class WarehouseData(
    val id: String = "WH-OS-01",
    val name: String = "NORTH INTERMODAL WAREHOUSE",
    val receivingCount: Int = 142,
    val storageCount: Int = 890,
    val pickingCount: Int = 64,
    val loadingDocksCount: Int = 12,
    val occupancyPct: Double = 68.5,
    val amrs: List<AMR> = emptyList()
)

data class TelemetryPoint(
    val timeLabel: String,
    val tempC: Double,
    val humidityPct: Int,
    val shockG: Double,
    val batteryPct: Int
)

data class IndustrialEvent(
    val id: String,
    val timestamp: String,
    val assetId: String,
    val eventType: String,
    val severity: EventSeverity,
    val summary: String,
    val details: String,
    val acknowledged: Boolean = false
)

data class WorkOrder(
    val id: String,
    val assetId: String,
    val type: String = "PREDICTIVE MAINTENANCE",
    val priority: String = "HIGH",
    val assignedEngineer: String = "ENGINEER 17",
    val status: WorkOrderStatus = WorkOrderStatus.IN_PROGRESS,
    val notes: String = "Motor vibration exceeding 0.15g threshold",
    val timestamp: String = "12:00:00"
)

data class OpcUaNode(
    val nodeId: String,
    val path: String,
    val dataType: String,
    val value: String,
    val quality: String = "GOOD (0x00)",
    val lastUpdated: String
)

data class MqttMessage(
    val topic: String,
    val payload: String,
    val timestamp: String
)

data class WhatIfResult(
    val scenarioName: String,
    val craneCount: Int,
    val truckCount: Int,
    val yardCapacityPct: Double,
    val throughputTeuHr: Int,
    val avgDwellHours: Double,
    val craneUtilizationPct: Double,
    val truckWaitMins: Int,
    val energyLoadMw: Double,
    val bottleneckArea: String
)

data class IntermodalRoutingOption(
    val name: String,
    val dominantMode: String,
    val transitHours: Int,
    val handlingCount: Int,
    val estimatedCostUsd: Double,
    val emissionsLevel: String,
    val reliabilityPct: Int,
    val pathSegments: List<String>
)
