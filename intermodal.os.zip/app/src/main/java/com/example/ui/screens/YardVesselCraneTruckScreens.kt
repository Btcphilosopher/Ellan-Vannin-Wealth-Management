package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.components.visualizers.VesselStowageCanvas
import com.example.ui.components.visualizers.YardStackCanvas
import com.example.ui.theme.*

// 1. YARD MANAGEMENT SCREEN
@Composable
fun YardManagementScreen(
    yardSlots: List<YardSlot>,
    containers: List<Container>,
    onMoveContainer: (String, String, Int, Int) -> Unit,
    onSelectContainer: (String) -> Unit
) {
    var selectedSlot by remember { mutableStateOf<YardSlot?>(yardSlots.firstOrNull()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        IndustrialSectionHeader("CONTAINER YARD STACK DIGITAL TWIN (TOP-DOWN VIEW)")

        YardStackCanvas(
            yardSlots = yardSlots,
            selectedSlot = selectedSlot,
            onSlotClick = { selectedSlot = it },
            modifier = Modifier.testTag("yard_stack_canvas")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // YARD POSITION SCORE & SLOT INSPECTOR CARD
        selectedSlot?.let { slot ->
            Card(
                colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, IndustrialBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SLOT ADDRESS: ${slot.block}-${String.format("%02d", slot.bay)}-${String.format("%02d", slot.stack)}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = IndustrialOrange
                        )
                        Box(
                            modifier = Modifier
                                .background(IndustrialBlue.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                                .border(1.dp, IndustrialBlue)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "POSITION SCORE: ${slot.optimizationScore}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = IndustrialBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (slot.containerId != null) {
                        Text(text = "CONTAINER: ${slot.containerId}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(text = "DWELL TIME: ${slot.dwellHours}h 42m · STATUS: ${slot.recommendedAction}", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = IndustrialSteel)

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onSelectContainer(slot.containerId) },
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = IndustrialOrange),
                                modifier = Modifier.testTag("btn_inspect_container")
                            ) {
                                Text("INSPECT CONTAINER TWIN", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = Color.Black)
                            }

                            OutlinedButton(
                                onClick = { onMoveContainer(slot.containerId, "B18", 2, 1) },
                                shape = RoundedCornerShape(2.dp),
                                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(IndustrialBlue))
                            ) {
                                Text("AUTO-RELOCATE (RTG)", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialBlue)
                            }
                        }
                    } else {
                        Text(text = "SLOT STATE: EMPTY AVAILABLE FOR ASSIGNMENT", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = IndustrialGreen)
                    }
                }
            }
        }
    }
}

// 2. VESSELS SCREEN & STOWAGE PLANNER
@Composable
fun VesselsScreen(
    vessels: List<Vessel>,
    stowageGrid: List<VesselStowageSlot>,
    onSelectContainer: (String) -> Unit
) {
    val vessel = vessels.firstOrNull() ?: Vessel(id = "VSL-01")
    var selectedStowageSlot by remember { mutableStateOf<VesselStowageSlot?>(stowageGrid.firstOrNull { it.containerId != null }) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        IndustrialSectionHeader("VESSEL DIGITAL TWIN & STOWAGE PLANNER (${vessel.name})")

        Card(
            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, IndustrialBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = vessel.name, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                    StatusBadge(status = vessel.status.name)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "IMO: ${vessel.imo} · LENGTH: ${vessel.lengthM}m · TEU CAPACITY: ${vessel.teuCapacity}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialSteel)
                Text(text = "BERTH: ${vessel.currentBerth} · DISCHARGE PROGRESS: ${vessel.baysLoadedPct}%", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialBlue)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        IndustrialSectionHeader("BAY 18 STOWAGE GRID (BAY x ROW x TIER)")

        VesselStowageCanvas(
            stowageGrid = stowageGrid,
            onSlotClick = { selectedStowageSlot = it },
            modifier = Modifier.testTag("vessel_stowage_canvas")
        )

        Spacer(modifier = Modifier.height(8.dp))

        selectedStowageSlot?.let { slot ->
            Card(
                colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, IndustrialBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "BAY ${slot.bay} / ROW ${String.format("%02d", slot.row)} / TIER ${String.format("%02d", slot.tier)}",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = IndustrialOrange,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    if (slot.containerId != null) {
                        Text(text = "CONTAINER: ${slot.containerId}", fontFamily = FontFamily.Monospace, color = Color.White)
                        Text(text = "WEIGHT: ${slot.weightTonnes}t · DEST: ${slot.destination} · HAZARD: ${slot.hazardStatus.name}", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = IndustrialSteel)

                        if (slot.hazardStatus == CargoHazard.HAZARDOUS) {
                            Text(text = "STOWAGE WARNING: HAZARDOUS ISOLATION ZONE REQUIRED", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialRed)
                        }
                    } else {
                        Text(text = "SLOT STATE: VACANT", fontFamily = FontFamily.Monospace, color = IndustrialGreen)
                    }
                }
            }
        }
    }
}

// 3. CRANES SCREEN
@Composable
fun CranesScreen(
    cranes: List<Crane>,
    onCreateWorkOrder: (String, String, String, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            IndustrialSectionHeader("QUAY & YARD CRANE DIGITAL TWINS (${cranes.size})")
        }

        items(cranes) { crane ->
            Card(
                colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, if (crane.status == CraneStatus.FAULT) IndustrialRed else IndustrialBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = crane.id, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = crane.name, fontFamily = FontFamily.SansSerif, fontSize = 12.sp, color = IndustrialSteel)
                        }
                        StatusBadge(status = crane.status.name)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "MOTOR TEMP: ${String.format("%.1f", crane.motorTempC)}°C", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = if (crane.motorTempC > 85) IndustrialRed else IndustrialSteel)
                        Text(text = "VIBRATION: ${crane.vibrationG}g", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialSteel)
                        Text(text = "RUL: ${crane.remainingUsefulLifeHrs}h", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialOrange)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "TOTAL CYCLES: ${crane.cyclesTotal} · LOAD: ${crane.loadTonnes}t · CONTAINER: ${crane.currentContainerId ?: "NONE"}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = IndustrialSteelLight
                    )

                    if (crane.faultMessage != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = crane.faultMessage, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialRed, fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = { onCreateWorkOrder(crane.id, "EMERGENCY INSPECTION", "HIGH", "Trolley motor thermal trip investigation.") },
                            colors = ButtonDefaults.buttonColors(containerColor = IndustrialRed),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text("DISPATCH FIELD ENGINEER WORK ORDER", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

// 4. TRUCKS SCREEN
@Composable
fun TrucksScreen(
    trucks: List<TerminalTruck>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            IndustrialSectionHeader("AUTONOMOUS TERMINAL TRUCKS (ATV FLEET)")
        }

        items(trucks) { truck ->
            Card(
                colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, IndustrialBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = truck.id, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = IndustrialOrange)
                        StatusBadge(status = truck.status.name)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(text = "MISSION: ${truck.mission}", fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                    Text(text = "CONTAINER: ${truck.containerId ?: "EMPTY"} · BATTERY: ${truck.batteryPct}% · SPEED: ${truck.speedKmh} km/h · ETA: ${String.format("%.1f", truck.etaMins)}m", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialSteel)
                }
            }
        }
    }
}
