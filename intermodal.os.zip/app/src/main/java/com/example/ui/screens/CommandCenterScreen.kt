package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.components.visualizers.LiveIntermodalMapCanvas
import com.example.ui.theme.*

@Composable
fun CommandCenterScreen(
    activeContainersCount: Int,
    inTransitCount: Int,
    yardOccupancyPct: Double,
    openIncidentsCount: Int,
    cranes: List<Crane>,
    trucks: List<TerminalTruck>,
    containers: List<Container>,
    recentEvents: List<IndustrialEvent>,
    onSelectAsset: (String, String) -> Unit,
    onNavigateDestination: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // TOP OPERATIONAL STATS GRID
        item {
            Column {
                IndustrialSectionHeader("COMMAND CENTER · REAL-TIME NETWORK OVERVIEW")

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IndustrialStatCard(
                        title = "ACTIVE CONTAINERS",
                        value = "18,492",
                        subtitle = "7,238 IN TRANSIT",
                        icon = Icons.Default.Inventory2,
                        modifier = Modifier.weight(1f).testTag("card_active_containers"),
                        onClick = { onNavigateDestination("CONTAINERS") }
                    )

                    IndustrialStatCard(
                        title = "YARD OCCUPANCY",
                        value = "${String.format("%.1f", yardOccupancyPct)}%",
                        subtitle = if (yardOccupancyPct > 85) "HIGH CONGESTION" else "OPTIMAL STACK",
                        icon = Icons.Default.GridOn,
                        accentColor = if (yardOccupancyPct > 85) IndustrialRed else IndustrialBlue,
                        modifier = Modifier.weight(1f).testTag("card_yard_occupancy"),
                        onClick = { onNavigateDestination("YARD") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IndustrialStatCard(
                        title = "VESSELS / BERTHS",
                        value = "8 / 4",
                        subtitle = "MV NORTH STAR BERTH 04",
                        icon = Icons.Default.DirectionsBoat,
                        accentColor = IndustrialBlue,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateDestination("VESSELS") }
                    )

                    IndustrialStatCard(
                        title = "CRANES ACTIVE",
                        value = "${cranes.count { it.status != CraneStatus.FAULT }}/${cranes.size}",
                        subtitle = "QC07 LIFTING · 24.8t",
                        icon = Icons.Default.Engineering,
                        accentColor = IndustrialOrange,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateDestination("CRANES") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IndustrialStatCard(
                        title = "TRUCKS / TRAINS",
                        value = "184 / 12",
                        subtitle = "TR204 LOADING 71%",
                        icon = Icons.Default.LocalShipping,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateDestination("TRUCKS") }
                    )

                    IndustrialStatCard(
                        title = "OPEN INCIDENTS",
                        value = "$openIncidentsCount",
                        subtitle = if (openIncidentsCount > 0) "ACTION REQUIRED" else "ALL CLEAR",
                        icon = Icons.Default.Warning,
                        accentColor = if (openIncidentsCount > 0) IndustrialRed else IndustrialGreen,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateDestination("MAINTENANCE") }
                    )
                }
            }
        }

        // LIVE INTERMODAL MAP CANVAS
        item {
            Column {
                IndustrialSectionHeader("LIVE INTERMODAL DIGITAL TWIN MAP (TAP OBJECT TO INSPECT)")
                LiveIntermodalMapCanvas(
                    cranes = cranes,
                    trucks = trucks,
                    containers = containers,
                    onSelectAsset = onSelectAsset,
                    modifier = Modifier.testTag("live_intermodal_map")
                )
            }
        }

        // LIVE EVENT LOG FEED
        item {
            IndustrialSectionHeader("LIVE UNIFIED EVENT STREAM (OPC UA / MQTT)")
        }

        items(recentEvents.take(5)) { ev ->
            Card(
                colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                    .clickable { onSelectAsset("EVENT", ev.id) }
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SeverityBadge(severity = ev.severity)
                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = ev.timestamp,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = IndustrialSteel,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = ev.summary,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = IndustrialText
                        )
                        Text(
                            text = "Asset: ${ev.assetId} · ${ev.details}",
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 10.sp,
                            color = IndustrialSteel
                        )
                    }
                }
            }
        }
    }
}
