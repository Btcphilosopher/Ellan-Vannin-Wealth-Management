package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

// 1. DIGITAL TWIN (UNIFIED NAMESPACE & OPC UA / MQTT)
@Composable
fun DigitalTwinScreen(
    opcUaNodes: List<OpcUaNode>,
    mqttMessages: List<MqttMessage>
) {
    var selectedTab by remember { mutableStateOf("UNIFIED_NAMESPACE") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        IndustrialSectionHeader("DIGITAL TWIN ARCHITECTURE & INDUSTRIAL DATA SPACE")

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("UNIFIED_NAMESPACE", "OPC_UA_NODES", "MQTT_EVENT_BUS").forEach { tab ->
                val isSelected = selectedTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (isSelected) IndustrialOrange else IndustrialSurfaceVariant)
                        .border(1.dp, if (isSelected) IndustrialOrange else IndustrialBorder)
                        .clickable { selectedTab = tab }
                        .padding(vertical = 6.dp)
                        .testTag("dt_tab_$tab"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab.replace("_", " "),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.Black else IndustrialText
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (selectedTab) {
                "UNIFIED_NAMESPACE" -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, IndustrialBorder)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("UNIFIED INDUSTRIAL NAMESPACE HIERARCHY", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialOrange, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = """
PORT/
  TERMINAL-01/
    BERTH-04/
      VESSEL/ [MV NORTH STAR]
      QUAY_CRANE/ [QC07]
    YARD/
      BLOCK-B14/
        STACK-07/
          SLOT-03/ [CONTAINER CXRU-482193-7]
    GATE/
      KIOSK-02/ [TRUCK HH-TR-9920]
    RAIL/
      TERMINAL/ [TRAIN TR204 / WAGON 27]
    WAREHOUSE/
      WH-OS-01/ [AMR-019]
                                    """.trimIndent(),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = IndustrialBlue
                                )
                            }
                        }
                    }
                }

                "OPC_UA_NODES" -> {
                    items(opcUaNodes) { node ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, IndustrialBorder)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(text = node.path, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                Text(text = "NodeID: ${node.nodeId} · Type: ${node.dataType}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialSteel)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(text = "VALUE: ${node.value}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialOrange, fontWeight = FontWeight.Bold)
                                    Text(text = "QUALITY: ${node.quality}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialGreen)
                                }
                            }
                        }
                    }
                }

                "MQTT_EVENT_BUS" -> {
                    items(mqttMessages) { msg ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, IndustrialBorder)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(text = "${msg.timestamp} · TOPIC: ${msg.topic}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = IndustrialBlue)
                                Text(text = "PAYLOAD: ${msg.payload}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialText)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 2. SUPPLY CHAIN CONTROL TOWER & INTERMODAL ROUTING
@Composable
fun ControlTowerScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        IndustrialSectionHeader("INTERMODAL FREIGHT ROUTING ENGINE & CONTROL TOWER")

        Card(
            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, IndustrialBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(text = "ROUTE SCENARIO COMPARISON (PORT NINGBO ➔ DUISBURG WAREHOUSE)", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialOrange, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(10.dp))

                // Option A
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(IndustrialSurfaceVariant)
                        .border(1.dp, IndustrialBlue)
                        .padding(10.dp)
                ) {
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "OPTION A: RAIL DOMINANT (RECOMMENDED)", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialBlue, fontSize = 12.sp)
                            StatusBadge(status = "LOW EMISSIONS")
                        }
                        Text(text = "TRANSIT: 31h · HANDLINGS: 4 · EST COST: $1,840 · RELIABILITY: 94%", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.White)
                        Text(text = "PATH: NINGBO ➔ OCEAN VESSEL ➔ ROTTERDAM ➔ INTERMODAL RAIL (TR204) ➔ DUISBURG WAREHOUSE", fontFamily = FontFamily.SansSerif, fontSize = 10.sp, color = IndustrialSteel)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Option B
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(IndustrialSurfaceVariant)
                        .border(1.dp, IndustrialAmber)
                        .padding(10.dp)
                ) {
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "OPTION B: TRUCK DOMINANT", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialAmber, fontSize = 12.sp)
                            StatusBadge(status = "HIGHER EMISSIONS")
                        }
                        Text(text = "TRANSIT: 18h · HANDLINGS: 2 · EST COST: $2,420 · RELIABILITY: 88%", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.White)
                        Text(text = "PATH: NINGBO ➔ OCEAN VESSEL ➔ ROTTERDAM ➔ HIGHWAY TRUCK (ATV FLEET) ➔ DUISBURG WAREHOUSE", fontFamily = FontFamily.SansSerif, fontSize = 10.sp, color = IndustrialSteel)
                    }
                }
            }
        }
    }
}
