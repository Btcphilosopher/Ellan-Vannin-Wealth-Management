package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.components.visualizers.SupplyChainTowerCanvas
import com.example.ui.components.visualizers.TelemetryChartCanvas
import com.example.ui.theme.*

@Composable
fun ContainerListScreen(
    containers: List<Container>,
    onSelectContainer: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredContainers = containers.filter { c ->
        val matchesSearch = c.id.contains(searchQuery, ignoreCase = true) ||
                c.cargoType.contains(searchQuery, ignoreCase = true) ||
                c.destination.contains(searchQuery, ignoreCase = true)
        val matchesFilter = when (selectedFilter) {
            "YARD" -> c.status == ContainerStatus.YARD
            "RAIL" -> c.status == ContainerStatus.RAIL
            "TRUCK" -> c.status == ContainerStatus.TRUCK
            "ON_VESSEL" -> c.status == ContainerStatus.ON_VESSEL
            "REEFER" -> c.isReefer
            "HAZARD" -> c.hazardStatus != CargoHazard.NORMAL
            else -> true
        }
        matchesSearch && matchesFilter
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        IndustrialSectionHeader("CONTAINER DIGITAL TWIN REGISTRY (${filteredContainers.size})")

        // Search Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by Container ID, Cargo, Destination...", color = IndustrialSteel) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = IndustrialOrange) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("container_search_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = IndustrialSurface,
                unfocusedContainerColor = IndustrialSurface,
                focusedBorderColor = IndustrialOrange,
                unfocusedBorderColor = IndustrialBorder,
                focusedTextColor = IndustrialText,
                unfocusedTextColor = IndustrialText
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Filter Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ALL", "YARD", "RAIL", "TRUCK", "ON_VESSEL", "REEFER", "HAZARD").forEach { filter ->
                val isSelected = selectedFilter == filter
                Box(
                    modifier = Modifier
                        .background(if (isSelected) IndustrialOrange else IndustrialSurfaceVariant, RoundedCornerShape(2.dp))
                        .border(1.dp, if (isSelected) IndustrialOrange else IndustrialBorder, RoundedCornerShape(2.dp))
                        .clickable { selectedFilter = filter }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("filter_$filter")
                ) {
                    Text(
                        text = filter,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.Black else IndustrialText
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Containers List Table
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filteredContainers) { container ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                        .clickable { onSelectContainer(container.id) }
                        .testTag("container_item_${container.id}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = container.id,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${container.sizeFeet}ft ${container.isoType}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = IndustrialSteel
                                )
                            }
                            StatusBadge(status = container.status.name)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ORIGIN: ${container.origin} ➔ DEST: ${container.destination}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = IndustrialSteelLight
                            )
                            Text(
                                text = "${container.weightTonnes}t · ${container.cargoType}",
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 11.sp,
                                color = IndustrialOrange
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "LOC: ${container.currentLocation}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = IndustrialSteel
                            )

                            if (container.isReefer) {
                                Text(
                                    text = "REEFER: ${String.format("%.1f", container.temperatureC)}°C (SET: ${container.setpointC}°C)",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = IndustrialBlue,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ContainerDetailScreen(
    containerId: String,
    containers: List<Container>,
    events: List<IndustrialEvent>,
    telemetryHistory: Map<String, List<TelemetryPoint>>,
    onBack: () -> Unit
) {
    val container = containers.firstOrNull { it.id == containerId } ?: containers.firstOrNull() ?: Container(id = containerId)
    val points = telemetryHistory[container.id] ?: emptyList()

    var selectedTab by remember { mutableStateOf("OVERVIEW") }
    val tabs = listOf("OVERVIEW", "LOCATION", "TELEMETRY", "CARGO", "EVENTS", "PASSPORT")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        // Top Back Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("container_detail_back")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = IndustrialOrange)
            }
            Text(
                text = "CONTAINER ${container.id}",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color.White
            )
            Spacer(modifier = Modifier.weight(1f))
            StatusBadge(status = container.status.name)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // SUPPLY CHAIN PATH VISUALIZER
        IndustrialSectionHeader("INTERMODAL SUPPLY CHAIN PATH")
        SupplyChainTowerCanvas(container = container)

        Spacer(modifier = Modifier.height(8.dp))

        // TAB BAR
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            tabs.forEach { tab ->
                val isSelected = selectedTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (isSelected) IndustrialOrange else IndustrialSurfaceVariant)
                        .border(1.dp, if (isSelected) IndustrialOrange else IndustrialBorder)
                        .clickable { selectedTab = tab }
                        .padding(vertical = 6.dp)
                        .testTag("tab_$tab"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.Black else IndustrialText
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // TAB CONTENT
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (selectedTab) {
                "OVERVIEW" -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, IndustrialBorder)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("DIGITAL TWIN SUMMARY", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialOrange, fontSize = 12.sp)
                                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = IndustrialBorder)

                                DetailRow("ISO TYPE", "${container.isoType} (${container.sizeFeet}ft High Cube)")
                                DetailRow("GROSS WEIGHT", "${container.weightTonnes} Tonnes")
                                DetailRow("CARGO DESCRIPTION", container.cargoType)
                                DetailRow("ORIGIN PORT", container.origin)
                                DetailRow("DESTINATION PORT", container.destination)
                                DetailRow("CURRENT LOCATION", container.currentLocation)
                                DetailRow("NEXT EVENT / ACTION", container.nextLocation)
                                DetailRow("BOOKING / VOYAGE", "${container.bookingRef} / ${container.voyage}")
                                DetailRow("OWNER / OPERATOR", "${container.owner} / ${container.operator}")
                                DetailRow("CUSTOMS STATUS", container.customsStatus)
                                DetailRow("HAZARD CLASS", container.hazardStatus.name)
                                DetailRow("SEAL STATUS", container.sealStatus)
                                DetailRow("YARD SLOT POSITION", "BLOCK ${container.block} / BAY 0${container.bay} / STACK 0${container.stack} / TIER 0${container.tier}")
                            }
                        }
                    }
                }

                "TELEMETRY" -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, IndustrialBorder)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("SMART CONTAINER IOT SENSOR STREAM", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialBlue, fontSize = 12.sp)

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    IndustrialStatCard("TEMPERATURE", "${String.format("%.1f", container.temperatureC)}°C", "SETPOINT: ${container.setpointC}°C", modifier = Modifier.weight(1f))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    IndustrialStatCard("HUMIDITY", "${container.humidityPct}%", "NORMAL RANGE", modifier = Modifier.weight(1f))
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    IndustrialStatCard("SHOCK / TILT", "${container.shockG}g / ${container.tiltDeg}°", "NO IMPACT DETECTED", modifier = Modifier.weight(1f))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    IndustrialStatCard("DOOR / BATTERY", "${container.doorStatus} / ${container.batteryPct}%", "SEAL INTACT", modifier = Modifier.weight(1f))
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text("TEMPERATURE DRIFT TIMELINE (°C)", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialSteel)
                                TelemetryChartCanvas(points = points)
                            }
                        }
                    }
                }

                "EVENTS" -> {
                    items(events.filter { it.assetId == container.id || it.details.contains(container.id) }) { ev ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, IndustrialBorder)
                        ) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                SeverityBadge(severity = ev.severity)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(text = "${ev.timestamp} · ${ev.summary}", fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = IndustrialText)
                                    Text(text = ev.details, fontFamily = FontFamily.SansSerif, fontSize = 10.sp, color = IndustrialSteel)
                                }
                            }
                        }
                    }
                }

                "PASSPORT" -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, IndustrialBorder)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("ASSET ADMINISTRATION SHELL · DIGITAL PRODUCT PASSPORT", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialOrange, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = """
{
  "asset_id": "${container.id}",
  "type": "CONTAINER_DIGITAL_TWIN",
  "manufacturer": "CIMCO CONTAINER SYSTEMS GMBH",
  "manufacture_date": "2021-04-12",
  "tare_weight_kg": 3800,
  "max_payload_kg": 28200,
  "inspection_cert": "ISO-6346-VERIFIED",
  "iot_device_id": "IOT-SN-992184-X",
  "telemetry_protocol": "OPC_UA_PUBSUB_MQTT",
  "carbon_footprint_kg_co2": 142.8
}
                                    """.trimIndent(),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = IndustrialBlue
                                )
                            }
                        }
                    }
                }

                else -> {
                    item {
                        Text("Operational telemetry and movement details synced live.", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = IndustrialSteel)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialSteel)
        Text(text = value, fontFamily = FontFamily.SansSerif, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IndustrialText)
    }
}
