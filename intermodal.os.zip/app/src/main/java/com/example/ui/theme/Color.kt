package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Industrial Color Palette
val IndustrialBackground = Color(0xFF0C1015)
val IndustrialSurface = Color(0xFF141A22)
val IndustrialSurfaceVariant = Color(0xFF1E2632)
val IndustrialBorder = Color(0xFF2E3B4E)

val IndustrialOrange = Color(0xFFFF6B00)
val IndustrialOrangeLight = Color(0xFFFF8C33)
val IndustrialBlue = Color(0xFF00E5FF)
val IndustrialNavy = Color(0xFF0B192C)

val IndustrialSteel = Color(0xFF8A99AD)
val IndustrialSteelLight = Color(0xFFC0CBD8)
val IndustrialText = Color(0xFFF0F4F8)
val IndustrialTextMuted = Color(0xFF64748B)

val IndustrialGreen = Color(0xFF00E676)
val IndustrialAmber = Color(0xFFFFAB00)
val IndustrialRed = Color(0xFFFF1744)
val IndustrialPurple = Color(0xFFD500F9)

// Container Status Colors
val ContainerYardColor = Color(0xFF00E5FF)
val ContainerVesselColor = Color(0xFF2979FF)
val ContainerRailColor = Color(0xFFFFAB00)
val ContainerTruckColor = Color(0xFFFF6B00)
val ContainerWarehouseColor = Color(0xFF00E676)
val ContainerHazardColor = Color(0xFFFF1744)
