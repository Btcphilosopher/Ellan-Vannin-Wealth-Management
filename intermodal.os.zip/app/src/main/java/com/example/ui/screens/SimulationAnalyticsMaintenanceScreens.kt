package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

// 1. SIMULATION LAB SCREEN
@Composable
fun SimulationLabScreen(
    currentScenario: ScenarioType,
    timeScale: Int,
    isPaused: Boolean,
    isReplayMode: Boolean,
    onTriggerScenario: (ScenarioType) -> Unit,
    onTimeScaleChange: (Int) -> Unit,
    onTogglePause: () -> Unit,
    onToggleReplay: (Boolean) -> Unit,
    computeWhatIf: (Int, Int, Double) -> WhatIfResult
) {
    var whatIfCraneCount by remember { mutableFloatStateOf(8f) }
    var whatIfTruckCount by remember { mutableFloatStateOf(18f) }
    var whatIfYardCap by remember { mutableFloatStateOf(75f) }

    val whatIfResult = computeWhatIf(whatIfCraneCount.toInt(), whatIfTruckCount.toInt(), whatIfYardCap.toDouble())

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            IndustrialSectionHeader("INDUSTRY 4.0 SIMULATION LAB & WHAT-IF ENGINE")
        }

        // SCENARIO SELECTOR
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, IndustrialBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = "SELECT OPERATIONAL SIMULATION SCENARIO", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialOrange, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(8.dp))

                    val scenarios = listOf(
                        ScenarioType.NORMAL_TERMINAL to "NORMAL TERMINAL",
                        ScenarioType.CRANE_FAILURE to "CRANE FAILURE",
                        ScenarioType.REEFER_FAILURE to "REEFER FAULT",
                        ScenarioType.YARD_SATURATION to "YARD SATURATION",
                        ScenarioType.PORT_CONGESTION to "PORT CONGESTION"
                    )

                    scenarios.chunked(2).forEach { pair ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { (sc, label) ->
                                val isSelected = currentScenario == sc
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(if (isSelected) IndustrialOrange else IndustrialSurfaceVariant)
                                        .border(1.dp, if (isSelected) IndustrialOrange else IndustrialBorder)
                                        .clickable { onTriggerScenario(sc) }
                                        .padding(vertical = 8.dp)
                                        .testTag("scenario_btn_${sc.name}"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.Black else IndustrialText
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }
        }

        // WHAT-IF SIMULATOR ENGINE
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, IndustrialBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = "WHAT-IF TERMINAL CAPACITY SIMULATOR", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialBlue, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(text = "QUAY & YARD CRANE COUNT: ${whatIfCraneCount.toInt()}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialSteel)
                    Slider(
                        value = whatIfCraneCount,
                        onValueChange = { whatIfCraneCount = it },
                        valueRange = 2f..16f,
                        steps = 14,
                        colors = SliderDefaults.colors(thumbColor = IndustrialOrange, activeTrackColor = IndustrialOrange)
                    )

                    Text(text = "TERMINAL TRUCK COUNT (ATVs): ${whatIfTruckCount.toInt()}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialSteel)
                    Slider(
                        value = whatIfTruckCount,
                        onValueChange = { whatIfTruckCount = it },
                        valueRange = 5f..40f,
                        steps = 35,
                        colors = SliderDefaults.colors(thumbColor = IndustrialOrange, activeTrackColor = IndustrialOrange)
                    )

                    Text(text = "YARD OCCUPANCY CAPACITY: ${whatIfYardCap.toInt()}%", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialSteel)
                    Slider(
                        value = whatIfYardCap,
                        onValueChange = { whatIfYardCap = it },
                        valueRange = 30f..98f,
                        steps = 68,
                        colors = SliderDefaults.colors(thumbColor = IndustrialOrange, activeTrackColor = IndustrialOrange)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    HorizontalDivider(color = IndustrialBorder)

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(text = "PREDICTED WHAT-IF OUTCOME METRICS", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialOrange, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        IndustrialStatCard("THROUGHPUT", "${whatIfResult.throughputTeuHr} TEU/h", "PREDICTED MOVES", modifier = Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        IndustrialStatCard("AVG DWELL", "${whatIfResult.avgDwellHours}h", "YARD DWELL TIME", modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        IndustrialStatCard("CRANE UTILIZATION", "${whatIfResult.craneUtilizationPct}%", "EQUIPMENT EFFICIENCY", modifier = Modifier.weight(1f))
                        Spacer(modifier = Modifier.width(6.dp))
                        IndustrialStatCard("PRIMARY BOTTLENECK", whatIfResult.bottleneckArea, "DETECTED BOTTLENECK", accentColor = IndustrialRed, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

// 2. ANALYTICS & TERMINAL ENERGY SCREEN
@Composable
fun AnalyticsEnergyScreen(
    yardOccupancyPct: Double
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        IndustrialSectionHeader("TERMINAL ENERGY MANAGEMENT & CARBON ANALYTICS")

        Card(
            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, IndustrialBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "CURRENT TERMINAL POWER LOAD", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Text(text = "8.4 MW", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialOrange, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    IndustrialStatCard("CRANE LOAD", "3.1 MW", "QUAY + RMG", modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    IndustrialStatCard("REEFER LOAD", "1.8 MW", "COLD STORAGE", modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    IndustrialStatCard("WAREHOUSE", "1.4 MW", "AGV CHARGING", modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    IndustrialStatCard("ATV CHARGING", "1.1 MW", "FLEET DEPOT", modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(IndustrialSurfaceVariant)
                        .border(1.dp, IndustrialGreen)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "CARBON ESTIMATE: 12.4 kg CO2e / CONTAINER-MILE (RAIL SHARE 68%) · SIMULATED ESTIMATE",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndustrialGreen
                    )
                }
            }
        }
    }
}

// 3. MAINTENANCE & ALARMS CENTER SCREEN
@Composable
fun MaintenanceScreen(
    events: List<IndustrialEvent>,
    workOrders: List<WorkOrder>,
    onAcknowledgeEvent: (String) -> Unit,
    onUpdateWorkOrderStatus: (String, WorkOrderStatus) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        IndustrialSectionHeader("INDUSTRIAL ALARM CENTER & WORK ORDERS")

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text(text = "PREDICTIVE MAINTENANCE WORK ORDERS", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialOrange, fontSize = 12.sp)
            }

            items(workOrders) { wo ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, IndustrialBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "${wo.id} · ASSET ${wo.assetId}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.White)
                            StatusBadge(status = wo.status.name)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "TYPE: ${wo.type} · ASSIGNED: ${wo.assignedEngineer}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialSteel)
                        Text(text = "NOTES: ${wo.notes}", fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = IndustrialText)

                        if (wo.status != WorkOrderStatus.CLOSED) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Button(
                                onClick = { onUpdateWorkOrderStatus(wo.id, WorkOrderStatus.CLOSED) },
                                colors = ButtonDefaults.buttonColors(containerColor = IndustrialGreen),
                                shape = RoundedCornerShape(2.dp)
                            ) {
                                Text("MARK WORK ORDER RESOLVED / CLOSED", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = Color.Black)
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "ACTIVE ALARMS (NEEDS ACKNOWLEDGEMENT)", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialRed, fontSize = 12.sp)
            }

            items(events.filter { it.severity == EventSeverity.CRITICAL || it.severity == EventSeverity.ALARM }) { ev ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (!ev.acknowledged) IndustrialRed else IndustrialBorder)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            SeverityBadge(severity = ev.severity)
                            if (ev.acknowledged) {
                                StatusBadge(status = "ACKNOWLEDGED")
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "${ev.timestamp} · ${ev.summary}", fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                        Text(text = ev.details, fontFamily = FontFamily.SansSerif, fontSize = 10.sp, color = IndustrialSteel)

                        if (!ev.acknowledged) {
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = { onAcknowledgeEvent(ev.id) },
                                shape = RoundedCornerShape(2.dp),
                                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(IndustrialOrange))
                            ) {
                                Text("ACKNOWLEDGE ALARM", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialOrange)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. FIELD ENGINEER COMPACT MOBILE MODE
@Composable
fun FieldEngineerScreen(
    cranes: List<Crane>,
    workOrders: List<WorkOrder>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        IndustrialSectionHeader("MOBILE FIELD ENGINEER TERMINAL WORKSTATION")

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(cranes.filter { it.motorTempC > 70.0 || it.status == CraneStatus.FAULT }) { crane ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, IndustrialRed)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "FIELD DIAGNOSTIC: ${crane.id} (${crane.name})", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialRed, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "MOTOR TEMP: ${crane.motorTempC}°C · VIBRATION: ${crane.vibrationG}g", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.White)
                        Text(text = "RECOMMENDED ACTION: INSPECT TROLLEY MOTOR & RE-ALIGN SPREADER HOOK", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = IndustrialOrange)
                    }
                }
            }
        }
    }
}
