package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.WorkOrderStatus
import com.example.simulation.IntermodalSimulationEngine
import com.example.ui.components.IndustrialTopHeader
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

data class NavItem(val id: String, val label: String, val icon: ImageVector)

@Composable
fun MainAppShell(
    engine: IntermodalSimulationEngine = IntermodalSimulationEngine(LocalContext.current)
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var currentScreen by remember { mutableStateOf("COMMAND") }
    var selectedContainerId by remember { mutableStateOf<String?>(null) }

    // Engine States
    val containers by engine.containers.collectAsStateWithLifecycle()
    val cranes by engine.cranes.collectAsStateWithLifecycle()
    val trucks by engine.trucks.collectAsStateWithLifecycle()
    val trains by engine.trains.collectAsStateWithLifecycle()
    val vessels by engine.vessels.collectAsStateWithLifecycle()
    val vesselStowage by engine.vesselStowage.collectAsStateWithLifecycle()
    val yardSlots by engine.yardSlots.collectAsStateWithLifecycle()
    val warehouse by engine.warehouse.collectAsStateWithLifecycle()
    val events by engine.events.collectAsStateWithLifecycle()
    val workOrders by engine.workOrders.collectAsStateWithLifecycle()
    val opcUaNodes by engine.opcUaNodes.collectAsStateWithLifecycle()
    val mqttMessages by engine.mqttMessages.collectAsStateWithLifecycle()

    val simTime by engine.simTime.collectAsStateWithLifecycle()
    val timeScale by engine.timeScale.collectAsStateWithLifecycle()
    val isPaused by engine.isPaused.collectAsStateWithLifecycle()
    val currentScenario by engine.currentScenario.collectAsStateWithLifecycle()
    val isReplayMode by engine.isReplayMode.collectAsStateWithLifecycle()

    val activeContainersCount by engine.activeContainersCount.collectAsStateWithLifecycle()
    val inTransitCount by engine.inTransitCount.collectAsStateWithLifecycle()
    val yardOccupancyPct by engine.yardOccupancyPct.collectAsStateWithLifecycle()
    val openIncidentsCount by engine.openIncidentsCount.collectAsStateWithLifecycle()

    val navItems = listOf(
        NavItem("COMMAND", "COMMAND CENTER", Icons.Default.Dashboard),
        NavItem("CONTAINERS", "CONTAINERS", Icons.Default.Inventory2),
        NavItem("YARD", "YARD MANAGEMENT", Icons.Default.GridOn),
        NavItem("VESSELS", "VESSEL STOWAGE", Icons.Default.DirectionsBoat),
        NavItem("CRANES", "CRANES & EQUIPMENT", Icons.Default.Engineering),
        NavItem("TRUCKS", "AUTONOMOUS TRUCKS", Icons.Default.LocalShipping),
        NavItem("RAIL", "INTERMODAL RAIL", Icons.Default.Train),
        NavItem("WAREHOUSE", "WAREHOUSE.OS", Icons.Default.Warehouse),
        NavItem("GATE", "TRUCK GATE KIOSK", Icons.Default.ConfirmationNumber),
        NavItem("DIGITAL_TWIN", "UNIFIED NAMESPACE", Icons.Default.AccountTree),
        NavItem("CONTROL_TOWER", "CONTROL TOWER", Icons.Default.AltRoute),
        NavItem("SIMULATION", "SIMULATION LAB", Icons.Default.Science),
        NavItem("ANALYTICS", "ENERGY & CARBON", Icons.Default.ElectricalServices),
        NavItem("MAINTENANCE", "ALARMS & ORDERS", Icons.Default.Warning),
        NavItem("FIELD_ENGINEER", "FIELD WORKSTATION", Icons.Default.Build)
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = IndustrialNavy,
                drawerContentColor = IndustrialText,
                modifier = Modifier.width(280.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "INTERMODAL.OS",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = IndustrialOrange
                    )
                    Text(
                        text = "SYSTEM NAVIGATION MENU",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = IndustrialSteel
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    HorizontalDivider(color = IndustrialBorder)

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(navItems) { item ->
                            val isSelected = currentScreen == item.id
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isSelected) IndustrialOrange else Color.Transparent, RoundedCornerShape(2.dp))
                                    .clickable {
                                        currentScreen = item.id
                                        selectedContainerId = null
                                        scope.launch { drawerState.close() }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                                    .testTag("nav_${item.id}")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        item.icon,
                                        contentDescription = item.label,
                                        tint = if (isSelected) Color.Black else IndustrialSteelLight,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = item.label,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.Black else IndustrialText
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                IndustrialTopHeader(
                    simTime = simTime,
                    timeScale = timeScale,
                    isPaused = isPaused,
                    onTimeScaleChange = { engine.setTimeScale(it) },
                    onTogglePause = { engine.togglePause() },
                    onMenuClick = { scope.launch { drawerState.open() } }
                )
            },
            bottomBar = {
                // QUICK BOTTOM NAVIGATION BAR
                Surface(
                    color = IndustrialSurface,
                    contentColor = IndustrialText,
                    modifier = Modifier.border(1.dp, IndustrialBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        val bottomNavs = listOf(
                            "COMMAND" to Icons.Default.Dashboard,
                            "CONTAINERS" to Icons.Default.Inventory2,
                            "YARD" to Icons.Default.GridOn,
                            "SIMULATION" to Icons.Default.Science,
                            "MAINTENANCE" to Icons.Default.Warning
                        )

                        bottomNavs.forEach { (navId, icon) ->
                            val isSelected = currentScreen == navId
                            IconButton(
                                onClick = {
                                    currentScreen = navId
                                    selectedContainerId = null
                                },
                                modifier = Modifier.testTag("bottom_nav_$navId")
                            ) {
                                Icon(
                                    icon,
                                    contentDescription = navId,
                                    tint = if (isSelected) IndustrialOrange else IndustrialSteel
                                )
                            }
                        }
                    }
                }
            },
            containerColor = IndustrialBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (selectedContainerId != null) {
                    ContainerDetailScreen(
                        containerId = selectedContainerId!!,
                        containers = containers,
                        events = events,
                        telemetryHistory = engine.telemetryHistory.collectAsStateWithLifecycle().value,
                        onBack = { selectedContainerId = null }
                    )
                } else {
                    when (currentScreen) {
                        "COMMAND" -> CommandCenterScreen(
                            activeContainersCount = activeContainersCount,
                            inTransitCount = inTransitCount,
                            yardOccupancyPct = yardOccupancyPct,
                            openIncidentsCount = openIncidentsCount,
                            cranes = cranes,
                            trucks = trucks,
                            containers = containers,
                            recentEvents = events,
                            onSelectAsset = { type, id ->
                                when (type) {
                                    "CONTAINER" -> selectedContainerId = id
                                    "CRANE" -> currentScreen = "CRANES"
                                    "VESSEL" -> currentScreen = "VESSELS"
                                    "RAIL" -> currentScreen = "RAIL"
                                    "WAREHOUSE" -> currentScreen = "WAREHOUSE"
                                    else -> currentScreen = "MAINTENANCE"
                                }
                            },
                            onNavigateDestination = { dest -> currentScreen = dest }
                        )

                        "CONTAINERS" -> ContainerListScreen(
                            containers = containers,
                            onSelectContainer = { id -> selectedContainerId = id }
                        )

                        "YARD" -> YardManagementScreen(
                            yardSlots = yardSlots,
                            containers = containers,
                            onMoveContainer = { id, b, bay, stack -> engine.moveYardContainer(id, b, bay, stack) },
                            onSelectContainer = { id -> selectedContainerId = id }
                        )

                        "VESSELS" -> VesselsScreen(
                            vessels = vessels,
                            stowageGrid = vesselStowage,
                            onSelectContainer = { id -> selectedContainerId = id }
                        )

                        "CRANES" -> CranesScreen(
                            cranes = cranes,
                            onCreateWorkOrder = { asset, type, prio, notes ->
                                engine.createWorkOrder(asset, type, prio, notes, "ENGINEER 17")
                            }
                        )

                        "TRUCKS" -> TrucksScreen(trucks = trucks)

                        "RAIL" -> RailScreen(
                            trains = trains,
                            onSelectContainer = { id -> selectedContainerId = id }
                        )

                        "WAREHOUSE" -> WarehouseScreen(warehouse = warehouse)

                        "GATE" -> GateScreen()

                        "DIGITAL_TWIN" -> DigitalTwinScreen(
                            opcUaNodes = opcUaNodes,
                            mqttMessages = mqttMessages
                        )

                        "CONTROL_TOWER" -> ControlTowerScreen()

                        "SIMULATION" -> SimulationLabScreen(
                            currentScenario = currentScenario,
                            timeScale = timeScale,
                            isPaused = isPaused,
                            isReplayMode = isReplayMode,
                            onTriggerScenario = { sc -> engine.triggerScenario(sc) },
                            onTimeScaleChange = { sc -> engine.setTimeScale(sc) },
                            onTogglePause = { engine.togglePause() },
                            onToggleReplay = { rep -> engine.toggleReplayMode(rep) },
                            computeWhatIf = { c, t, y -> engine.computeWhatIfSimulation(c, t, y) }
                        )

                        "ANALYTICS" -> AnalyticsEnergyScreen(yardOccupancyPct = yardOccupancyPct)

                        "MAINTENANCE" -> MaintenanceScreen(
                            events = events,
                            workOrders = workOrders,
                            onAcknowledgeEvent = { id -> engine.acknowledgeEvent(id) },
                            onUpdateWorkOrderStatus = { id, st -> engine.updateWorkOrderStatus(id, st) }
                        )

                        "FIELD_ENGINEER" -> FieldEngineerScreen(cranes = cranes, workOrders = workOrders)
                    }
                }
            }
        }
    }
}
