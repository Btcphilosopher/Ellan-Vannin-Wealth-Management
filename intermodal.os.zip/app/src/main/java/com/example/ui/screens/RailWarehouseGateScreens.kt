package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

// 1. RAIL TERMINAL & TRAIN LOADING SCREEN
@Composable
fun RailScreen(
    trains: List<Train>,
    onSelectContainer: (String) -> Unit
) {
    val train = trains.firstOrNull() ?: Train(id = "TR204")
    var selectedWagon by remember { mutableStateOf<Wagon?>(train.wagons.firstOrNull { it.id == 27 }) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        IndustrialSectionHeader("INTERMODAL RAIL CONTROL (${train.id} · ${train.route})")

        Card(
            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, IndustrialBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "TRAIN ${train.id}", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = IndustrialOrange)
                    StatusBadge(status = train.status.name)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "ROUTE: ${train.route} · DEPARTURE: ${train.departureTime} · ETA: ${train.eta}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialSteel)
                Text(text = "TOTAL WAGONS: ${train.wagonsCount} · CONTAINERS LOADED: ${train.containersLoaded} (${train.loadingPct}%)", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialBlue)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        IndustrialSectionHeader("INTERACTIVE WAGON LOADING DIAGRAM (SELECT WAGON)")

        // Wagon diagram horizontal grid
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(IndustrialSurface)
                .border(1.dp, IndustrialBorder)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(train.wagons.chunked(6)) { wagonChunk ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    wagonChunk.forEach { wagon ->
                        val isSelected = selectedWagon?.id == wagon.id
                        val isLoaded = wagon.containerId != null

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .background(if (isLoaded) ContainerRailColor else IndustrialSurfaceVariant)
                                .border(1.dp, if (isSelected) Color.White else IndustrialBorder)
                                .clickable { selectedWagon = wagon }
                                .padding(4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "W${wagon.id}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isLoaded) Color.Black else IndustrialSteel
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // SELECTED WAGON INSPECTOR
        selectedWagon?.let { wagon ->
            Card(
                colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, IndustrialBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = "WAGON #${wagon.id} INSPECTOR", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialOrange, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "TYPE: ${wagon.wagonType} · SECURED LOCK: ${if (wagon.isSecured) "VERIFIED ENGAGED" else "UNLOCKED"}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialSteel)

                    if (wagon.containerId != null) {
                        Text(text = "CONTAINER: ${wagon.containerId} · WEIGHT: ${wagon.weightTonnes}t", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.White)

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = { onSelectContainer(wagon.containerId) },
                            shape = RoundedCornerShape(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IndustrialOrange)
                        ) {
                            Text("INSPECT CONTAINER ${wagon.containerId}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = Color.Black)
                        }
                    } else {
                        Text(text = "WAGON STATUS: EMPTY READY FOR LOADING", fontFamily = FontFamily.Monospace, color = IndustrialGreen)
                    }
                }
            }
        }
    }
}

// 2. WAREHOUSE.OS SCREEN
@Composable
fun WarehouseScreen(
    warehouse: WarehouseData
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            IndustrialSectionHeader("${warehouse.name} (WAREHOUSE.OS)")

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IndustrialStatCard("RECEIVING DOCKS", "${warehouse.receivingCount}", "ACTIVE INFLOW", modifier = Modifier.weight(1f))
                IndustrialStatCard("INVENTORY", "${warehouse.storageCount}", "${warehouse.occupancyPct}% CAPACITY", modifier = Modifier.weight(1f))
            }
        }

        item {
            IndustrialSectionHeader("AUTONOMOUS MOBILE ROBOTS (AMR / AGV FLEET)")
        }

        items(warehouse.amrs) { amr ->
            Card(
                colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, IndustrialBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = amr.id, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = IndustrialGreen)
                        StatusBadge(status = amr.status)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "MISSION: ${amr.mission}", fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                    Text(text = "LOCATION: ${amr.location} ➔ DEST: ${amr.destination} · BATTERY: ${amr.batteryPct}%", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialSteel)
                }
            }
        }
    }
}

// 3. AUTOMATED TRUCK GATE SCREEN
@Composable
fun GateScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IndustrialBackground)
            .padding(12.dp)
    ) {
        IndustrialSectionHeader("AUTOMATED TRUCK GATE KIOSK 02")

        Card(
            colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, IndustrialBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(text = "GATE IN OCR SCANNER & KIOSK", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = IndustrialOrange, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))

                Text(text = "TRUCK REGISTRATION: HH-TR-9920", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.White)
                Text(text = "DRIVER APPOINTMENT: #APT-88219 (VERIFIED)", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialGreen)
                Text(text = "CONTAINER OCR MATCH: CMA-884920-2", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialBlue)
                Text(text = "E-SEAL STATUS: VALIDATED #SL-992", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialGreen)
                Text(text = "CUSTOMS STATUS: CLEARED", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialGreen)
                Text(text = "GROSS WEIGHT SCALE: 28.4 Tonnes", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = IndustrialSteel)

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(IndustrialSurfaceVariant)
                        .border(1.dp, IndustrialOrange)
                        .padding(10.dp)
                ) {
                    Text(
                        text = "DISPATCH INSTRUCTION: PROCEED TO YARD BLOCK B18 / BAY 01 / STACK 01",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = IndustrialOrange,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
