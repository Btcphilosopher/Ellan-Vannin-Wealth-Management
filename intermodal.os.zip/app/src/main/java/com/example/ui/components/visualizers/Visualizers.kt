package com.example.ui.components.visualizers

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.theme.*

@Composable
fun LiveIntermodalMapCanvas(
    cranes: List<Crane>,
    trucks: List<TerminalTruck>,
    containers: List<Container>,
    onSelectAsset: (String, String) -> Unit, // type, id
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(320.dp)
            .background(IndustrialBackground)
            .border(1.dp, IndustrialBorder)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val w = size.width
                        val h = size.height

                        // Detect tap area
                        val xRatio = offset.x / w
                        val yRatio = offset.y / h

                        when {
                            // Ocean & Quay area (Top)
                            yRatio < 0.25f -> onSelectAsset("VESSEL", "VSL-01")
                            // Quay Crane line
                            yRatio in 0.25f..0.38f -> {
                                val clickedCrane = cranes.firstOrNull { c ->
                                    (xRatio - c.positionPct).let { kotlin.math.abs(it) < 0.15f }
                                } ?: cranes.firstOrNull()
                                clickedCrane?.let { onSelectAsset("CRANE", it.id) }
                            }
                            // Yard Block Area (Middle)
                            yRatio in 0.38f..0.65f -> {
                                val container = containers.firstOrNull() ?: Container("CXRU-482193-7")
                                onSelectAsset("CONTAINER", container.id)
                            }
                            // Rail Terminal (Bottom Left)
                            yRatio > 0.65f && xRatio < 0.5f -> onSelectAsset("RAIL", "TR204")
                            // Warehouse (Bottom Right)
                            yRatio > 0.65f && xRatio >= 0.5f -> onSelectAsset("WAREHOUSE", "WH-OS-01")
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // 1. OCEAN & BERTH (Top 25%)
            drawRect(
                color = Color(0xFF0D253A),
                topLeft = Offset(0f, 0f),
                size = Size(w, h * 0.22f)
            )

            // Vessel outline
            val shipPath = Path().apply {
                moveTo(w * 0.1f, h * 0.05f)
                lineTo(w * 0.8f, h * 0.05f)
                lineTo(w * 0.85f, h * 0.12f)
                lineTo(w * 0.8f, h * 0.18f)
                lineTo(w * 0.1f, h * 0.18f)
                close()
            }
            drawPath(shipPath, color = Color(0xFF1E3A5F))
            drawPath(shipPath, color = IndustrialBlue, style = Stroke(width = 2f))

            // 2. QUAY WALL / APRON LINE
            drawLine(
                color = IndustrialSteel,
                start = Offset(0f, h * 0.22f),
                end = Offset(w, h * 0.22f),
                strokeWidth = 3f
            )

            // 3. QUAY CRANES
            cranes.filter { it.type == CraneType.QUAY_CRANE }.forEach { crane ->
                val cx = crane.positionPct * w
                val cy = h * 0.26f

                // Crane base
                drawRect(
                    color = if (crane.status == CraneStatus.FAULT) IndustrialRed else IndustrialOrange,
                    topLeft = Offset(cx - 15f, cy - 10f),
                    size = Size(30f, 20f)
                )
                // Boom line extending over vessel
                drawLine(
                    color = IndustrialOrange,
                    start = Offset(cx, cy),
                    end = Offset(cx, h * 0.10f),
                    strokeWidth = 2.5f
                )
                // Trolley
                val trolleyY = h * 0.10f + (crane.trolleyPct * (cy - h * 0.10f))
                drawCircle(
                    color = IndustrialBlue,
                    radius = 5f,
                    center = Offset(cx, trolleyY)
                )
            }

            // 4. CONTAINER YARD BLOCKS (B12, B14, B15, B18)
            val blockWidth = w * 0.20f
            val blockHeight = h * 0.20f
            val blockY = h * 0.40f

            val blockXList = listOf(w * 0.05f, w * 0.28f, w * 0.51f, w * 0.74f)
            val blockLabels = listOf("BLOCK B12", "BLOCK B14", "BLOCK B15", "BLOCK B18")

            blockXList.forEachIndexed { i, bx ->
                drawRoundRect(
                    color = IndustrialSurfaceVariant,
                    topLeft = Offset(bx, blockY),
                    size = Size(blockWidth, blockHeight),
                    cornerRadius = CornerRadius(4f)
                )
                drawRoundRect(
                    color = IndustrialBorder,
                    topLeft = Offset(bx, blockY),
                    size = Size(blockWidth, blockHeight),
                    cornerRadius = CornerRadius(4f),
                    style = Stroke(width = 1.5f)
                )

                // Draw stacked mini containers inside block
                for (row in 0..3) {
                    for (col in 0..2) {
                        val color = when ((i + row + col) % 4) {
                            0 -> ContainerYardColor
                            1 -> ContainerVesselColor
                            2 -> ContainerRailColor
                            else -> ContainerTruckColor
                        }
                        drawRect(
                            color = color,
                            topLeft = Offset(bx + 6f + col * 18f, blockY + 6f + row * 10f),
                            size = Size(14f, 7f)
                        )
                    }
                }
            }

            // 5. MOVING TERMINAL TRUCKS (ATVs)
            trucks.forEach { truck ->
                val tx = truck.posX * w
                val ty = h * 0.63f
                drawRoundRect(
                    color = IndustrialOrangeLight,
                    topLeft = Offset(tx - 10f, ty - 5f),
                    size = Size(20f, 10f),
                    cornerRadius = CornerRadius(2f)
                )
            }

            // 6. RAIL TERMINAL (Bottom Left)
            val railY = h * 0.78f
            drawLine(color = IndustrialSteel, start = Offset(w * 0.05f, railY), end = Offset(w * 0.45f, railY), strokeWidth = 3f)
            drawLine(color = IndustrialSteel, start = Offset(w * 0.05f, railY + 10f), end = Offset(w * 0.45f, railY + 10f), strokeWidth = 3f)

            // Train wagons
            for (i in 0..5) {
                drawRect(
                    color = IndustrialAmber,
                    topLeft = Offset(w * 0.08f + i * 28f, railY - 12f),
                    size = Size(22f, 10f)
                )
            }

            // 7. WAREHOUSE (Bottom Right)
            drawRoundRect(
                color = IndustrialSurfaceVariant,
                topLeft = Offset(w * 0.55f, h * 0.72f),
                size = Size(w * 0.40f, h * 0.22f),
                cornerRadius = CornerRadius(4f)
            )
            drawRoundRect(
                color = IndustrialGreen,
                topLeft = Offset(w * 0.55f, h * 0.72f),
                size = Size(w * 0.40f, h * 0.22f),
                cornerRadius = CornerRadius(4f),
                style = Stroke(width = 1.5f)
            )
        }

        // Overlay Text Annotations
        Box(modifier = Modifier.padding(8.dp)) {
            Text(
                text = "BERTH 04 [MV NORTH STAR] ◄ TAP TO INSPECT",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = IndustrialBlue
            )
        }
    }
}

@Composable
fun YardStackCanvas(
    yardSlots: List<YardSlot>,
    selectedSlot: YardSlot?,
    onSlotClick: (YardSlot) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .background(IndustrialSurface)
            .border(1.dp, IndustrialBorder)
            .padding(8.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val slotsCount = yardSlots.size.coerceAtLeast(1)
                        val clickedIndex = (offset.x / size.width * slotsCount).toInt().coerceIn(0, slotsCount - 1)
                        if (clickedIndex in yardSlots.indices) {
                            onSlotClick(yardSlots[clickedIndex])
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // Draw Yard Block Bay Stack Grid
            val cols = 8
            val rows = 4
            val cellW = w / cols
            val cellH = h / rows

            yardSlots.take(cols * rows).forEachIndexed { idx, slot ->
                val col = idx % cols
                val row = idx / cols

                val x = col * cellW
                val y = row * cellH

                val isOccupied = slot.containerId != null
                val isSelected = selectedSlot?.block == slot.block && selectedSlot.bay == slot.bay && selectedSlot.stack == slot.stack

                val fillColor = when {
                    !isOccupied -> IndustrialSurfaceVariant
                    slot.containerId?.contains("CXRU-482193-7") == true -> IndustrialOrange
                    slot.optimizationScore > 80 -> ContainerYardColor
                    else -> ContainerRailColor
                }

                drawRoundRect(
                    color = fillColor,
                    topLeft = Offset(x + 3f, y + 3f),
                    size = Size(cellW - 6f, cellH - 6f),
                    cornerRadius = CornerRadius(3f)
                )

                if (isSelected) {
                    drawRoundRect(
                        color = Color.White,
                        topLeft = Offset(x + 1f, y + 1f),
                        size = Size(cellW - 2f, cellH - 2f),
                        cornerRadius = CornerRadius(3f),
                        style = Stroke(width = 2.5f)
                    )
                }
            }
        }
    }
}

@Composable
fun VesselStowageCanvas(
    stowageGrid: List<VesselStowageSlot>,
    onSlotClick: (VesselStowageSlot) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .background(IndustrialSurface)
            .border(1.dp, IndustrialBorder)
            .padding(8.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val count = stowageGrid.size.coerceAtLeast(1)
                        val idx = (offset.x / size.width * count).toInt().coerceIn(0, count - 1)
                        if (idx in stowageGrid.indices) {
                            onSlotClick(stowageGrid[idx])
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            val cols = 8
            val rows = 6
            val cellW = w / cols
            val cellH = h / rows

            stowageGrid.take(cols * rows).forEachIndexed { idx, slot ->
                val col = idx % cols
                val row = idx / cols

                val x = col * cellW
                val y = row * cellH

                val isOccupied = slot.containerId != null
                val color = when {
                    !isOccupied -> IndustrialSurfaceVariant
                    slot.containerId == "MSC-910245-1" -> IndustrialOrange
                    slot.hazardStatus == CargoHazard.HAZARDOUS -> ContainerHazardColor
                    slot.isReefer -> ContainerYardColor
                    else -> ContainerVesselColor
                }

                drawRoundRect(
                    color = color,
                    topLeft = Offset(x + 2f, y + 2f),
                    size = Size(cellW - 4f, cellH - 4f),
                    cornerRadius = CornerRadius(2f)
                )
            }
        }
    }
}

@Composable
fun TelemetryChartCanvas(
    points: List<TelemetryPoint>,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(160.dp)
            .background(IndustrialSurface)
            .border(1.dp, IndustrialBorder)
            .padding(12.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (points.isEmpty()) return@Canvas

            val w = size.width
            val h = size.height

            // Grid lines
            for (i in 1..3) {
                val y = h * (i / 4f)
                drawLine(
                    color = IndustrialBorder,
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1f
                )
            }

            // Plot Temperature curve
            val path = Path()
            val minTemp = 0.0
            val maxTemp = 10.0

            points.forEachIndexed { i, pt ->
                val x = w * (i.toFloat() / (points.size - 1).coerceAtLeast(1))
                val normalizedY = ((pt.tempC - minTemp) / (maxTemp - minTemp)).coerceIn(0.0, 1.0)
                val y = h - (normalizedY * h).toFloat()

                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)

                // Draw data points
                drawCircle(color = IndustrialBlue, radius = 3f, center = Offset(x, y))
            }

            drawPath(path, color = IndustrialBlue, style = Stroke(width = 2.5f))
        }
    }
}

@Composable
fun SupplyChainTowerCanvas(
    container: Container,
    modifier: Modifier = Modifier
) {
    val steps = listOf("FACTORY", "TRUCK", "PORT", "VESSEL", "PORT", "RAIL", "DEPOT", "WAREHOUSE", "CUSTOMER")
    val activeStepIndex = when (container.status) {
        ContainerStatus.BOOKED -> 0
        ContainerStatus.GATED_IN -> 1
        ContainerStatus.YARD -> 2
        ContainerStatus.ON_VESSEL, ContainerStatus.LOADED -> 3
        ContainerStatus.DISCHARGING -> 4
        ContainerStatus.RAIL -> 5
        ContainerStatus.TRUCK -> 6
        ContainerStatus.WAREHOUSE -> 7
        ContainerStatus.DELIVERED -> 8
        else -> 2
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(IndustrialSurface)
            .border(1.dp, IndustrialBorder)
            .padding(12.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
        ) {
            val w = size.width
            val h = size.height
            val stepW = w / (steps.size - 1)

            // Connecting line
            drawLine(
                color = IndustrialBorder,
                start = Offset(0f, h / 2f),
                end = Offset(w, h / 2f),
                strokeWidth = 3f
            )

            // Active path line
            val activeX = stepW * activeStepIndex
            drawLine(
                color = IndustrialOrange,
                start = Offset(0f, h / 2f),
                end = Offset(activeX, h / 2f),
                strokeWidth = 4f
            )

            // Step nodes
            steps.forEachIndexed { i, _ ->
                val x = stepW * i
                val isActive = i <= activeStepIndex
                val isCurrent = i == activeStepIndex

                drawCircle(
                    color = if (isCurrent) IndustrialOrange else if (isActive) IndustrialBlue else IndustrialSurfaceVariant,
                    radius = if (isCurrent) 10f else 6f,
                    center = Offset(x, h / 2f)
                )

                if (isCurrent) {
                    drawCircle(
                        color = Color.White,
                        radius = 12f,
                        center = Offset(x, h / 2f),
                        style = Stroke(width = 2f)
                    )
                }
            }
        }
    }
}
