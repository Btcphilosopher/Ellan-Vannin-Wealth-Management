package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.EventSeverity
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun IndustrialTopHeader(
    simTime: Calendar,
    timeScale: Int,
    isPaused: Boolean,
    onTimeScaleChange: (Int) -> Unit,
    onTogglePause: () -> Unit,
    onMenuClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(simTime.time)
    val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(simTime.time)

    Surface(
        color = IndustrialNavy,
        contentColor = IndustrialText,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, IndustrialBorder)
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            // PROMINENT BANNERS
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onMenuClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("nav_drawer_button")
                    ) {
                        Icon(Icons.Default.Menu, contentDescription = "Navigation Menu", tint = IndustrialOrange)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = "INTERMODAL.OS",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Box(
                        modifier = Modifier
                            .background(IndustrialSurfaceVariant, RoundedCornerShape(2.dp))
                            .border(1.dp, IndustrialOrange, RoundedCornerShape(2.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "INDUSTRY 4.0 DIGITAL TWIN · SYNTHETIC DATA",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = IndustrialOrange
                        )
                    }
                }

                // Network & Clock
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(IndustrialGreen.copy(alpha = 0.15f), RoundedCornerShape(2.dp))
                            .border(1.dp, IndustrialGreen, RoundedCornerShape(2.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(IndustrialGreen, RoundedCornerShape(3.dp))
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "NETWORK: OPERATIONAL",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = IndustrialGreen
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Text(
                        text = "$dateStr $timeStr",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = IndustrialSteelLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // SIMULATION CONTROLS BAR
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "SIM SPEED:",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = IndustrialSteel
                    )
                    Spacer(modifier = Modifier.width(6.dp))

                    val scales = listOf(1, 5, 10, 30, 100)
                    scales.forEach { scale ->
                        val isSelected = timeScale == scale
                        Box(
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (isSelected) IndustrialOrange else IndustrialSurfaceVariant)
                                .border(1.dp, if (isSelected) IndustrialOrange else IndustrialBorder, RoundedCornerShape(2.dp))
                                .clickable { onTimeScaleChange(scale) }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                .testTag("sim_speed_${scale}x")
                        ) {
                            Text(
                                text = "${scale}x",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.Black else IndustrialText
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (isPaused) IndustrialAmber else IndustrialSurfaceVariant)
                            .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                            .clickable { onTogglePause() }
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                            .testTag("sim_pause_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                contentDescription = "Pause or Play Simulation",
                                modifier = Modifier.size(12.dp),
                                tint = if (isPaused) Color.Black else IndustrialOrange
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isPaused) "RESUME" else "PAUSE",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isPaused) Color.Black else IndustrialText
                            )
                        }
                    }
                }

                Text(
                    text = "OPC UA / MQTT PUBSUB ACTIVE",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = IndustrialSteel
                )
            }
        }
    }
}

@Composable
fun IndustrialStatCard(
    title: String,
    value: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    accentColor: Color = IndustrialOrange,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = IndustrialSurface),
        shape = RoundedCornerShape(2.dp),
        modifier = modifier
            .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = IndustrialSteel
                )
                if (icon != null) {
                    Icon(icon, contentDescription = title, tint = accentColor, modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = value,
                fontFamily = FontFamily.Monospace,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = IndustrialText
            )

            if (subtitle != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 10.sp,
                    color = accentColor
                )
            }
        }
    }
}

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = when (status.uppercase()) {
        "OPERATIONAL", "CLEARED", "ON_VESSEL", "SEALED", "COMPLETED", "NORMAL", "LOW", "BALANCED FLOW" -> IndustrialGreen.copy(alpha = 0.2f) to IndustrialGreen
        "YARD", "RAIL", "TRUCK", "LOADING", "IN_PROGRESS" -> IndustrialBlue.copy(alpha = 0.2f) to IndustrialBlue
        "WARNING", "PAUSED", "CONTROLLED", "HIGHER", "WAITING_PARTS" -> IndustrialAmber.copy(alpha = 0.2f) to IndustrialAmber
        "FAULT", "CRITICAL", "ALARM", "EXCEPTION", "HAZARDOUS", "HIGH CONGESTION" -> IndustrialRed.copy(alpha = 0.2f) to IndustrialRed
        else -> IndustrialSurfaceVariant to IndustrialSteel
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(2.dp))
            .border(1.dp, textColor.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = status.uppercase(),
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

@Composable
fun SeverityBadge(severity: EventSeverity) {
    val (color, text) = when (severity) {
        EventSeverity.INFO -> IndustrialBlue to "INFO"
        EventSeverity.WARNING -> IndustrialAmber to "WARNING"
        EventSeverity.ALARM -> IndustrialOrange to "ALARM"
        EventSeverity.CRITICAL -> IndustrialRed to "CRITICAL"
    }
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
            .border(1.dp, color, RoundedCornerShape(2.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
fun IndustrialSectionHeader(title: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(vertical = 6.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(width = 4.dp, height = 14.dp)
                    .background(IndustrialOrange)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title.uppercase(),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = IndustrialSteelLight,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.width(8.dp))
            HorizontalDivider(
                color = IndustrialBorder,
                thickness = 1.dp,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
