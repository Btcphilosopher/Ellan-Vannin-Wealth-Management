package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val IntermodalDarkColorScheme = darkColorScheme(
    primary = IndustrialOrange,
    onPrimary = IndustrialBackground,
    primaryContainer = IndustrialSurfaceVariant,
    onPrimaryContainer = IndustrialOrangeLight,
    secondary = IndustrialBlue,
    onSecondary = IndustrialBackground,
    secondaryContainer = IndustrialSurfaceVariant,
    onSecondaryContainer = IndustrialBlue,
    tertiary = IndustrialSteelLight,
    onTertiary = IndustrialBackground,
    background = IndustrialBackground,
    onBackground = IndustrialText,
    surface = IndustrialSurface,
    onSurface = IndustrialText,
    surfaceVariant = IndustrialSurfaceVariant,
    onSurfaceVariant = IndustrialSteel,
    outline = IndustrialBorder,
    error = IndustrialRed,
    onError = IndustrialText
)

@Composable
fun IntermodalTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = IntermodalDarkColorScheme,
        typography = TechnicalTypography,
        content = content
    )
}
