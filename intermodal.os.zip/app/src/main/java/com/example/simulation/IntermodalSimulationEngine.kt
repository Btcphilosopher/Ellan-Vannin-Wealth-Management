package com.example.simulation

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.EventEntity
import com.example.data.local.WorkOrderEntity
import com.example.domain.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sin

class IntermodalSimulationEngine(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // State Flows
    private val _containers = MutableStateFlow<List<Container>>(emptyList())
    val containers: StateFlow<List<Container>> = _containers.asStateFlow()

    private val _cranes = MutableStateFlow<List<Crane>>(emptyList())
    val cranes: StateFlow<List<Crane>> = _cranes.asStateFlow()

    private val _trucks = MutableStateFlow<List<TerminalTruck>>(emptyList())
    val trucks: StateFlow<List<TerminalTruck>> = _trucks.asStateFlow()

    private val _trains = MutableStateFlow<List<Train>>(emptyList())
    val trains: StateFlow<List<Train>> = _trains.asStateFlow()

    private val _vessels = MutableStateFlow<List<Vessel>>(emptyList())
    val vessels: StateFlow<List<Vessel>> = _vessels.asStateFlow()

    private val _vesselStowage = MutableStateFlow<List<VesselStowageSlot>>(emptyList())
    val vesselStowage: StateFlow<List<VesselStowageSlot>> = _vesselStowage.asStateFlow()

    private val _yardSlots = MutableStateFlow<List<YardSlot>>(emptyList())
    val yardSlots: StateFlow<List<YardSlot>> = _yardSlots.asStateFlow()

    private val _warehouse = MutableStateFlow(WarehouseData())
    val warehouse: StateFlow<WarehouseData> = _warehouse.asStateFlow()

    private val _events = MutableStateFlow<List<IndustrialEvent>>(emptyList())
    val events: StateFlow<List<IndustrialEvent>> = _events.asStateFlow()

    private val _workOrders = MutableStateFlow<List<WorkOrder>>(emptyList())
    val workOrders: StateFlow<List<WorkOrder>> = _workOrders.asStateFlow()

    private val _opcUaNodes = MutableStateFlow<List<OpcUaNode>>(emptyList())
    val opcUaNodes: StateFlow<List<OpcUaNode>> = _opcUaNodes.asStateFlow()

    private val _mqttMessages = MutableStateFlow<List<MqttMessage>>(emptyList())
    val mqttMessages: StateFlow<List<MqttMessage>> = _mqttMessages.asStateFlow()

    // Simulation Parameters
    private val _timeScale = MutableStateFlow(1)
    val timeScale: StateFlow<Int> = _timeScale.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _currentScenario = MutableStateFlow(ScenarioType.NORMAL_TERMINAL)
    val currentScenario: StateFlow<ScenarioType> = _currentScenario.asStateFlow()

    private val _simTime = MutableStateFlow(Calendar.getInstance())
    val simTime: StateFlow<Calendar> = _simTime.asStateFlow()

    private val _telemetryHistory = MutableStateFlow<Map<String, List<TelemetryPoint>>>(emptyMap())
    val telemetryHistory: StateFlow<Map<String, List<TelemetryPoint>>> = _telemetryHistory.asStateFlow()

    // Key Operational Metrics
    private val _activeContainersCount = MutableStateFlow(18492)
    val activeContainersCount: StateFlow<Int> = _activeContainersCount.asStateFlow()

    private val _inTransitCount = MutableStateFlow(7238)
    val inTransitCount: StateFlow<Int> = _inTransitCount.asStateFlow()

    private val _yardOccupancyPct = MutableStateFlow(72.4)
    val yardOccupancyPct: StateFlow<Double> = _yardOccupancyPct.asStateFlow()

    private val _openIncidentsCount = MutableStateFlow(14)
    val openIncidentsCount: StateFlow<Int> = _openIncidentsCount.asStateFlow()

    // Replay mode state
    private val _isReplayMode = MutableStateFlow(false)
    val isReplayMode: StateFlow<Boolean> = _isReplayMode.asStateFlow()

    private val _replayHistory = mutableListOf<IndustrialEvent>()

    init {
        seedInitialData()
        startSimulationLoop()
    }

    private fun seedInitialData() {
        // Containers
        val initContainers = listOf(
            Container(
                id = "CXRU-482193-7",
                isoType = "45R1",
                sizeFeet = 40,
                weightTonnes = 24.8,
                cargoType = "Pharma Cold Chain",
                origin = "NINGBO",
                destination = "ROTTERDAM",
                currentLocation = "RAIL TERMINAL WAGON 27",
                nextLocation = "RAIL DEPARTURE -> DUISBURG",
                status = ContainerStatus.RAIL,
                temperatureC = 4.2,
                setpointC = 4.0,
                isReefer = true,
                block = "B14",
                bay = 7,
                stack = 3,
                tier = 2,
                hazardStatus = CargoHazard.NORMAL
            ),
            Container(
                id = "CXRU-492812-3",
                isoType = "42G1",
                sizeFeet = 40,
                weightTonnes = 18.2,
                cargoType = "Auto Components",
                origin = "SHANGHAI",
                destination = "CHICAGO",
                currentLocation = "YARD BLOCK B14 STACK 07",
                nextLocation = "GATE-OUT TRUCK",
                status = ContainerStatus.YARD,
                temperatureC = 18.5,
                isReefer = false,
                block = "B14",
                bay = 7,
                stack = 4,
                tier = 1,
                hazardStatus = CargoHazard.NORMAL
            ),
            Container(
                id = "MSC-910245-1",
                isoType = "22U1",
                sizeFeet = 20,
                weightTonnes = 21.0,
                cargoType = "Industrial Chemicals",
                origin = "HAMBURG",
                destination = "ROTTERDAM",
                currentLocation = "MV NORTH STAR BAY 18",
                nextLocation = "DISCHARGE QC07",
                status = ContainerStatus.ON_VESSEL,
                temperatureC = 12.0,
                isReefer = false,
                block = "B02",
                bay = 18,
                stack = 6,
                tier = 4,
                hazardStatus = CargoHazard.HAZARDOUS
            ),
            Container(
                id = "HAP-773821-9",
                isoType = "45R1",
                sizeFeet = 40,
                weightTonnes = 26.1,
                cargoType = "Perishable Foodstufs",
                origin = "VALENCIA",
                destination = "DUISBURG",
                currentLocation = "YARD BLOCK B15 STACK 02",
                nextLocation = "RAIL LOADING",
                status = ContainerStatus.YARD,
                temperatureC = 2.1,
                setpointC = 2.0,
                isReefer = true,
                block = "B15",
                bay = 2,
                stack = 2,
                tier = 3,
                hazardStatus = CargoHazard.CONTROLLED
            ),
            Container(
                id = "OOCL-338190-4",
                isoType = "42G1",
                sizeFeet = 40,
                weightTonnes = 19.5,
                cargoType = "Consumer Electronics",
                origin = "SHENZHEN",
                destination = "WAREHOUSE-OS-01",
                currentLocation = "TERMINAL TRUCK ATV-042",
                nextLocation = "WAREHOUSE DOCK-03",
                status = ContainerStatus.TRUCK,
                temperatureC = 21.0,
                isReefer = false,
                block = "B10",
                bay = 4,
                stack = 1,
                tier = 1,
                hazardStatus = CargoHazard.NORMAL
            ),
            Container(
                id = "CMA-884920-2",
                isoType = "22P1",
                sizeFeet = 20,
                weightTonnes = 28.4,
                cargoType = "Heavy Machinery",
                origin = "BUSAN",
                destination = "ANTWERP",
                currentLocation = "GATE KIOSK 02",
                nextLocation = "YARD ASSIGNMENT B18",
                status = ContainerStatus.GATED_IN,
                temperatureC = 16.4,
                isReefer = false,
                block = "B18",
                bay = 1,
                stack = 1,
                tier = 1,
                hazardStatus = CargoHazard.SPECIAL_HANDLING
            )
        )
        _containers.value = initContainers

        // Telemetry initial history
        val timeFmt = SimpleDateFormat("HH:mm", Locale.US)
        val initialHistory = mutableMapOf<String, List<TelemetryPoint>>()
        initContainers.forEach { c ->
            val list = mutableListOf<TelemetryPoint>()
            val now = Calendar.getInstance()
            for (i in 10 downTo 0) {
                val cal = now.clone() as Calendar
                cal.add(Calendar.MINUTE, -i * 5)
                list.add(
                    TelemetryPoint(
                        timeLabel = timeFmt.format(cal.time),
                        tempC = c.temperatureC + (sin(i.toDouble()) * 0.3),
                        humidityPct = c.humidityPct + (i % 3 - 1),
                        shockG = c.shockG + (if (i == 3) 0.15 else 0.0),
                        batteryPct = (c.batteryPct - i * 0.2).toInt()
                    )
                )
            }
            initialHistory[c.id] = list
        }
        _telemetryHistory.value = initialHistory

        // Cranes
        _cranes.value = listOf(
            Crane(id = "QC01", name = "Quay Crane 01", type = CraneType.QUAY_CRANE, status = CraneStatus.MOVING, positionPct = 0.15f, trolleyPct = 0.30f, currentContainerId = "MSC-910245-1", motorTempC = 62.0),
            Crane(id = "QC07", name = "Quay Crane 07", type = CraneType.QUAY_CRANE, status = CraneStatus.LIFTING, positionPct = 0.45f, trolleyPct = 0.65f, loadTonnes = 24.8, currentContainerId = "CXRU-482193-7", motorTempC = 78.4, vibrationG = 0.14, remainingUsefulLifeHrs = 126),
            Crane(id = "QC08", name = "Quay Crane 08", type = CraneType.QUAY_CRANE, status = CraneStatus.IDLE, positionPct = 0.55f, trolleyPct = 0.10f, motorTempC = 55.0),
            Crane(id = "RMG01", name = "Rail RMG 01", type = CraneType.RMG, status = CraneStatus.LOWERING, positionPct = 0.25f, trolleyPct = 0.80f, currentContainerId = "HAP-773821-9", motorTempC = 64.2),
            Crane(id = "RMG02", name = "Rail RMG 02", type = CraneType.RMG, status = CraneStatus.MOVING, positionPct = 0.70f, trolleyPct = 0.40f, motorTempC = 59.8),
            Crane(id = "RTG01", name = "Yard RTG 01", type = CraneType.RTG, status = CraneStatus.PICKING, positionPct = 0.30f, trolleyPct = 0.50f, motorTempC = 71.0),
            Crane(id = "RTG05", name = "Yard RTG 05", type = CraneType.RTG, status = CraneStatus.IDLE, positionPct = 0.80f, trolleyPct = 0.20f, motorTempC = 58.0)
        )

        // Trucks
        _trucks.value = listOf(
            TerminalTruck(id = "ATV-042", name = "Autonomous Truck 042", status = TruckStatus.LOADED, mission = "QC07 -> YARD B14", containerId = "CXRU-482193-7", batteryPct = 74, speedKmh = 18, etaMins = 3.2, posX = 0.30f, posY = 0.48f),
            TerminalTruck(id = "ATV-019", name = "Autonomous Truck 019", status = TruckStatus.DRIVING_EMPTY, mission = "GATE -> YARD B15", containerId = null, batteryPct = 88, speedKmh = 22, etaMins = 1.8, posX = 0.15f, posY = 0.20f),
            TerminalTruck(id = "ATV-088", name = "Autonomous Truck 088", status = TruckStatus.CHARGING, mission = "DEPOT CHARGER 02", containerId = null, batteryPct = 28, speedKmh = 0, etaMins = 15.0, posX = 0.90f, posY = 0.85f),
            TerminalTruck(id = "ATV-104", name = "Autonomous Truck 104", status = TruckStatus.APPROACHING, mission = "YARD B14 -> RAIL", containerId = "CXRU-492812-3", batteryPct = 65, speedKmh = 15, etaMins = 4.1, posX = 0.55f, posY = 0.65f)
        )

        // Trains
        val wagonsList = (1..42).map { i ->
            Wagon(
                id = i,
                wagonType = if (i % 2 == 0) "Sgnss" else "Sgns",
                containerId = if (i == 27) "CXRU-482193-7" else if (i < 30) "CNTR-${1000 + i}" else null,
                weightTonnes = if (i <= 30) 24.0 else 0.0,
                isSecured = true
            )
        }
        _trains.value = listOf(
            Train(id = "TR204", route = "ROTTERDAM -> DUISBURG", wagonsCount = 42, containersLoaded = 30, loadingPct = 71, departureTime = "14:35", eta = "18:20", status = TrainStatus.LOADING, wagons = wagonsList),
            Train(id = "TR108", route = "ROTTERDAM -> HAMBURG", wagonsCount = 38, containersLoaded = 38, loadingPct = 100, departureTime = "11:00", eta = "16:45", status = TrainStatus.EN_ROUTE),
            Train(id = "TR302", route = "ROTTERDAM -> PRAGUE", wagonsCount = 40, containersLoaded = 12, loadingPct = 30, departureTime = "17:15", eta = "06:30", status = TrainStatus.LOADING)
        )

        // Vessels & Stowage
        _vessels.value = listOf(
            Vessel(id = "VSL-01", name = "MV NORTH STAR", imo = "SYN-48291", lengthM = 366, teuCapacity = 14000, currentBerth = "BERTH 04", status = VesselStatus.DISCHARGING, baysLoadedPct = 64, eta = "08:00"),
            Vessel(id = "VSL-02", name = "CMA CGM OCEANUS", imo = "SYN-99120", lengthM = 399, teuCapacity = 18000, currentBerth = "BERTH 02", status = VesselStatus.LOADING, baysLoadedPct = 82, eta = "11:30")
        )

        val stowageGrid = mutableListOf<VesselStowageSlot>()
        for (bay in listOf(14, 18, 22)) {
            for (row in 1..8) {
                for (tier in 1..6) {
                    val occupied = (bay == 18 && row == 6 && tier == 4) || (bay % 2 == 0 && row % 3 == 0)
                    stowageGrid.add(
                        VesselStowageSlot(
                            bay = bay,
                            row = row,
                            tier = tier,
                            containerId = if (bay == 18 && row == 6 && tier == 4) "MSC-910245-1" else if (occupied) "VSL-CNTR-$bay-$row-$tier" else null,
                            weightTonnes = if (occupied) 21.4 else 0.0,
                            destination = if (row > 4) "ROTTERDAM" else "HAMBURG",
                            hazardStatus = if (bay == 18 && row == 6 && tier == 4) CargoHazard.HAZARDOUS else CargoHazard.NORMAL,
                            isReefer = (tier == 1 && row % 2 == 0)
                        )
                    )
                }
            }
        }
        _vesselStowage.value = stowageGrid

        // Yard Slots
        val slots = mutableListOf<YardSlot>()
        for (b in listOf("B12", "B14", "B15", "B18")) {
            for (bay in 1..10) {
                for (stack in 1..4) {
                    val occupied = (b == "B14" && bay == 7 && stack == 3) || (bay * stack % 3 == 0)
                    val score = 100.0 - (stack * 2.5) - (if (b == "B14") 5.0 else 10.0)
                    slots.add(
                        YardSlot(
                            block = b,
                            bay = bay,
                            stack = stack,
                            tier = if (occupied) 2 else 0,
                            containerId = if (b == "B14" && bay == 7 && stack == 3) "CXRU-482193-7" else if (occupied) "CNTR-$b-$bay-$stack" else null,
                            dwellHours = if (occupied) 18 else 0,
                            optimizationScore = score,
                            recommendedAction = if (score > 80) "OPTIMAL FOR RAIL" else "STANDARD STACK"
                        )
                    )
                }
            }
        }
        _yardSlots.value = slots

        // Warehouse
        _warehouse.value = WarehouseData(
            id = "WH-OS-01",
            name = "NORTH INTERMODAL WAREHOUSE",
            receivingCount = 142,
            storageCount = 890,
            pickingCount = 64,
            loadingDocksCount = 12,
            occupancyPct = 68.5,
            amrs = listOf(
                AMR(id = "AMR-019", mission = "PICKUP RACK A-14", location = "RACK A-14", destination = "DOCK-03", batteryPct = 61, status = "EXECUTING"),
                AMR(id = "AMR-004", mission = "STAGING DOCK-01", location = "DOCK-01", destination = "ZONE C-08", batteryPct = 92, status = "IDLE"),
                AMR(id = "AMR-012", mission = "CHARGING", location = "CHARGER 01", destination = "CHARGER 01", batteryPct = 19, status = "CHARGING")
            )
        )

        // Events
        val initialEvents = listOf(
            IndustrialEvent(id = "EV-9901", timestamp = "13:15:00", assetId = "TR204", eventType = "RAIL_LOADING", severity = EventSeverity.INFO, summary = "Container CXRU-482193-7 loaded onto Rail Wagon 27", details = "RMG01 completed loading onto train TR204 in 42s cycle time."),
            IndustrialEvent(id = "EV-9898", timestamp = "12:44:12", assetId = "CXRU-482193-7", eventType = "RAIL_ASSIGNMENT", severity = EventSeverity.INFO, summary = "Rail assignment confirmed for Duisburg line", details = "Customs status verified: CLEARED."),
            IndustrialEvent(id = "EV-9870", timestamp = "10:23:05", assetId = "QC07", eventType = "YARD_PLACEMENT", severity = EventSeverity.INFO, summary = "Container placed at Yard Block B14-07-03", details = "Placement accuracy within 2mm."),
            IndustrialEvent(id = "EV-9850", timestamp = "09:03:10", assetId = "QC07", eventType = "CRANE_PICKUP", severity = EventSeverity.INFO, summary = "Container picked up from Vessel MV NORTH STAR", details = "Spreader locked onto CXRU-482193-7."),
            IndustrialEvent(id = "EV-9812", timestamp = "08:14:00", assetId = "GATE-02", eventType = "GATE_IN", severity = EventSeverity.INFO, summary = "Truck Gate-in validated", details = "OCR matched container ID & e-sealSL-992.")
        )
        _events.value = initialEvents
        _replayHistory.addAll(initialEvents)

        // Work Orders
        _workOrders.value = listOf(
            WorkOrder(id = "WO-4821", assetId = "QC07", type = "PREDICTIVE MAINTENANCE", priority = "HIGH", assignedEngineer = "ENGINEER 17", status = WorkOrderStatus.IN_PROGRESS, notes = "Motor vibration threshold warning (0.18g). Inspection within 72h recommended.", timestamp = "12:00:00"),
            WorkOrder(id = "WO-4809", assetId = "ATV-088", type = "BATTERY CELL REPLACEMENT", priority = "MEDIUM", assignedEngineer = "ENGINEER 04", status = WorkOrderStatus.WAITING_PARTS, notes = "Battery cell #4 degradation detected.", timestamp = "09:30:00")
        )

        // OPC UA Tree
        _opcUaNodes.value = listOf(
            OpcUaNode(nodeId = "ns=2;s=QuayCrane.QC07.Status", path = "PORT/TERMINAL-01/CRANE/QC07/Status", dataType = "String", value = "OPERATIONAL", lastUpdated = "13:15:02"),
            OpcUaNode(nodeId = "ns=2;s=QuayCrane.QC07.MotorTemp", path = "PORT/TERMINAL-01/CRANE/QC07/MotorTemp", dataType = "Float", value = "78.4 °C", lastUpdated = "13:15:02"),
            OpcUaNode(nodeId = "ns=2;s=QuayCrane.QC07.Vibration", path = "PORT/TERMINAL-01/CRANE/QC07/Vibration", dataType = "Float", value = "0.18 g", lastUpdated = "13:15:02"),
            OpcUaNode(nodeId = "ns=2;s=Yard.BlockB14.Occupancy", path = "PORT/TERMINAL-01/YARD/BLOCK-B14/Occupancy", dataType = "Float", value = "78.2 %", lastUpdated = "13:14:55"),
            OpcUaNode(nodeId = "ns=2;s=Container.CXRU4821937.Temp", path = "PORT/TERMINAL-01/CONTAINER/CXRU4821937/Temp", dataType = "Float", value = "+4.2 °C", lastUpdated = "13:15:00")
        )

        // MQTT Stream
        _mqttMessages.value = listOf(
            MqttMessage("intermodal/terminal/crane/QC07/telemetry", "{\"motor_temp\": 78.4, \"vibration\": 0.18, \"load\": 24.8}", "13:15:02"),
            MqttMessage("intermodal/container/CXRU4821937/telemetry", "{\"temp\": 4.2, \"humidity\": 61, \"shock\": 0.12, \"door\": \"SEALED\"}", "13:15:00"),
            MqttMessage("intermodal/rail/train/TR204/status", "{\"wagon\": 27, \"container\": \"CXRU4821937\", \"secured\": true}", "13:14:50")
        )

        // Sync initial Room records
        scope.launch {
            initialEvents.forEach { ev ->
                db.eventDao().insertEvent(
                    EventEntity(
                        id = ev.id,
                        timestamp = ev.timestamp,
                        assetId = ev.assetId,
                        eventType = ev.eventType,
                        severity = ev.severity.name,
                        summary = ev.summary,
                        details = ev.details,
                        acknowledged = ev.acknowledged
                    )
                )
            }
        }
    }

    private fun startSimulationLoop() {
        scope.launch {
            while (isActive) {
                val scale = _timeScale.value
                val delayMs = (1000 / scale.coerceIn(1, 100)).toLong()
                delay(delayMs)

                if (!_isPaused.value && !_isReplayMode.value) {
                    tickSimulation()
                }
            }
        }
    }

    private fun tickSimulation() {
        // Advance clock
        val cal = _simTime.value.clone() as Calendar
        cal.add(Calendar.SECOND, 2)
        _simTime.value = cal
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(cal.time)

        // Update Crane states
        val updatedCranes = _cranes.value.map { c ->
            if (c.status != CraneStatus.FAULT && c.status != CraneStatus.IDLE) {
                var newTrolley = c.trolleyPct + (0.02f * (if (c.status == CraneStatus.MOVING) 1 else -1))
                if (newTrolley > 0.9f || newTrolley < 0.1f) newTrolley = 0.5f
                val newCycles = c.cyclesTotal + 1
                val newRul = (c.remainingUsefulLifeHrs - (if (newCycles % 100 == 0) 1 else 0)).coerceAtLeast(0)
                val newTemp = c.motorTempC + (if (c.status == CraneStatus.LIFTING) 0.1 else -0.05)
                c.copy(trolleyPct = newTrolley, cyclesTotal = newCycles, remainingUsefulLifeHrs = newRul, motorTempC = newTemp)
            } else c
        }
        _cranes.value = updatedCranes

        // Update Truck movements along routes
        val updatedTrucks = _trucks.value.map { t ->
            if (t.status == TruckStatus.LOADED || t.status == TruckStatus.DRIVING_EMPTY) {
                val newX = (t.posX + 0.015f) % 1.0f
                val newEta = (t.etaMins - 0.05).coerceAtLeast(0.1)
                t.copy(posX = newX, etaMins = newEta)
            } else t
        }
        _trucks.value = updatedTrucks

        // Modulate container telemetry
        val updatedContainers = _containers.value.map { c ->
            if (c.isReefer) {
                val scenario = _currentScenario.value
                val tempDelta = if (scenario == ScenarioType.REEFER_FAILURE && c.id == "CXRU-482193-7") 0.4 else (sin(cal.timeInMillis / 10000.0) * 0.05)
                val newTemp = c.temperatureC + tempDelta
                c.copy(temperatureC = newTemp)
            } else c
        }
        _containers.value = updatedContainers

        // Update telemetry graph history for containers
        val history = _telemetryHistory.value.toMutableMap()
        val timeLabel = SimpleDateFormat("HH:mm", Locale.US).format(cal.time)
        updatedContainers.forEach { c ->
            val list = (history[c.id] ?: emptyList()).toMutableList()
            list.add(
                TelemetryPoint(
                    timeLabel = timeLabel,
                    tempC = c.temperatureC,
                    humidityPct = c.humidityPct,
                    shockG = c.shockG,
                    batteryPct = c.batteryPct
                )
            )
            if (list.size > 20) list.removeAt(0)
            history[c.id] = list
        }
        _telemetryHistory.value = history

        // Periodic MQTT telemetry push
        val randomCrane = updatedCranes.random()
        val mqttMsg = MqttMessage(
            topic = "intermodal/terminal/crane/${randomCrane.id}/telemetry",
            payload = "{\"status\": \"${randomCrane.status}\", \"motor_temp\": ${String.format("%.1f", randomCrane.motorTempC)}, \"trolley\": ${String.format("%.2f", randomCrane.trolleyPct)}}",
            timestamp = timeStr
        )
        _mqttMessages.value = (listOf(mqttMsg) + _mqttMessages.value).take(50)

        // Update OPC UA Nodes
        _opcUaNodes.value = _opcUaNodes.value.map { node ->
            when {
                node.nodeId.contains("MotorTemp") -> node.copy(value = "${String.format("%.1f", randomCrane.motorTempC)} °C", lastUpdated = timeStr)
                node.nodeId.contains("Container.CXRU4821937.Temp") -> node.copy(value = "${String.format("%.1f", updatedContainers.first().temperatureC)} °C", lastUpdated = timeStr)
                else -> node.copy(lastUpdated = timeStr)
            }
        }
    }

    // Public API Actions
    fun setTimeScale(scale: Int) {
        _timeScale.value = scale
    }

    fun togglePause() {
        _isPaused.value = !_isPaused.value
    }

    fun triggerScenario(scenario: ScenarioType) {
        _currentScenario.value = scenario
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(_simTime.value.time)

        when (scenario) {
            ScenarioType.CRANE_FAILURE -> {
                // QC07 fails
                _cranes.value = _cranes.value.map { c ->
                    if (c.id == "QC07") c.copy(status = CraneStatus.FAULT, faultMessage = "CRITICAL: Trolley Motor Overheat (88.4°C)", motorTempC = 88.4, vibrationG = 0.42) else c
                }
                _openIncidentsCount.value += 1
                dispatchIndustrialEvent(
                    IndustrialEvent(
                        id = "EV-${System.currentTimeMillis() % 10000}",
                        timestamp = timeStr,
                        assetId = "QC07",
                        eventType = "CRANE_FAULT",
                        severity = EventSeverity.CRITICAL,
                        summary = "Quay Crane QC07 Trolley Motor Fault Detected",
                        details = "Motor temperature 88.4°C exceeded trip threshold. Automatic safety shutdown engaged."
                    )
                )
            }
            ScenarioType.REEFER_FAILURE -> {
                // Reefer container CXRU-482193-7 temp spike
                _containers.value = _containers.value.map { c ->
                    if (c.id == "CXRU-482193-7") c.copy(temperatureC = 8.8, status = ContainerStatus.EXCEPTION) else c
                }
                _openIncidentsCount.value += 1
                dispatchIndustrialEvent(
                    IndustrialEvent(
                        id = "EV-${System.currentTimeMillis() % 10000}",
                        timestamp = timeStr,
                        assetId = "CXRU-482193-7",
                        eventType = "REEFER_ALARM",
                        severity = EventSeverity.ALARM,
                        summary = "Reefer Temperature Excursion (+8.8°C)",
                        details = "Container CXRU-482193-7 temperature drifted above setpoint threshold (+4.0°C). Cold chain risk."
                    )
                )
            }
            ScenarioType.YARD_SATURATION -> {
                _yardOccupancyPct.value = 92.4
                dispatchIndustrialEvent(
                    IndustrialEvent(
                        id = "EV-${System.currentTimeMillis() % 10000}",
                        timestamp = timeStr,
                        assetId = "YARD",
                        eventType = "YARD_SATURATION",
                        severity = EventSeverity.WARNING,
                        summary = "Yard Saturation Alert (92.4% Occupancy)",
                        details = "Block B14 & B15 approaching critical capacity. Reshuffle factor increased by 2.4x."
                    )
                )
            }
            ScenarioType.PORT_CONGESTION -> {
                _inTransitCount.value = 9840
                dispatchIndustrialEvent(
                    IndustrialEvent(
                        id = "EV-${System.currentTimeMillis() % 10000}",
                        timestamp = timeStr,
                        assetId = "PORT",
                        eventType = "PORT_CONGESTION",
                        severity = EventSeverity.WARNING,
                        summary = "Port Anchorage Congestion Surge",
                        details = "Vessel waiting time increased by +2.8h due to quay slot availability."
                    )
                )
            }
            ScenarioType.NORMAL_TERMINAL -> {
                _yardOccupancyPct.value = 72.4
                _inTransitCount.value = 7238
                _cranes.value = _cranes.value.map { c ->
                    if (c.id == "QC07") c.copy(status = CraneStatus.LIFTING, faultMessage = null, motorTempC = 72.0, vibrationG = 0.12) else c
                }
                _containers.value = _containers.value.map { c ->
                    if (c.id == "CXRU-482193-7") c.copy(temperatureC = 4.2, status = ContainerStatus.RAIL) else c
                }
                dispatchIndustrialEvent(
                    IndustrialEvent(
                        id = "EV-${System.currentTimeMillis() % 10000}",
                        timestamp = timeStr,
                        assetId = "SYSTEM",
                        eventType = "NORMAL_OPERATIONS",
                        severity = EventSeverity.INFO,
                        summary = "Terminal returned to normal nominal baseline state.",
                        details = "All automated sub-systems operational."
                    )
                )
            }
            else -> {}
        }
    }

    fun acknowledgeEvent(eventId: String) {
        _events.value = _events.value.map { ev ->
            if (ev.id == eventId) ev.copy(acknowledged = true) else ev
        }
        scope.launch {
            db.eventDao().acknowledgeEvent(eventId)
        }
    }

    fun createWorkOrder(assetId: String, type: String, priority: String, notes: String, assignedEngineer: String) {
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(_simTime.value.time)
        val wo = WorkOrder(
            id = "WO-${(System.currentTimeMillis() % 10000)}",
            assetId = assetId,
            type = type,
            priority = priority,
            assignedEngineer = assignedEngineer,
            status = WorkOrderStatus.IN_PROGRESS,
            notes = notes,
            timestamp = timeStr
        )
        _workOrders.value = listOf(wo) + _workOrders.value
        scope.launch {
            db.workOrderDao().insertWorkOrder(
                WorkOrderEntity(
                    id = wo.id,
                    assetId = wo.assetId,
                    type = wo.type,
                    priority = wo.priority,
                    assignedEngineer = wo.assignedEngineer,
                    status = wo.status.name,
                    notes = wo.notes,
                    timestamp = wo.timestamp
                )
            )
        }
    }

    fun updateWorkOrderStatus(id: String, status: WorkOrderStatus) {
        _workOrders.value = _workOrders.value.map { wo ->
            if (wo.id == id) wo.copy(status = status) else wo
        }
        scope.launch {
            db.workOrderDao().updateWorkOrderStatus(id, status.name)
        }
    }

    private fun dispatchIndustrialEvent(event: IndustrialEvent) {
        _events.value = listOf(event) + _events.value
        _replayHistory.add(event)
        scope.launch {
            db.eventDao().insertEvent(
                EventEntity(
                    id = event.id,
                    timestamp = event.timestamp,
                    assetId = event.assetId,
                    eventType = event.eventType,
                    severity = event.severity.name,
                    summary = event.summary,
                    details = event.details,
                    acknowledged = event.acknowledged
                )
            )
        }
    }

    // What-If Scenario Comparison Calculator
    fun computeWhatIfSimulation(craneCount: Int, truckCount: Int, yardCapPct: Double): WhatIfResult {
        val baseThroughput = 180 + (craneCount * 22) + (truckCount * 2)
        val throughput = (baseThroughput * (1.0 - (yardCapPct - 50.0).coerceAtLeast(0.0) / 100.0)).toInt()
        val avgDwell = (24.0 * (yardCapPct / 50.0) / (craneCount / 6.0)).coerceAtLeast(6.0)
        val craneUtil = ((throughput / (craneCount * 30.0)) * 100.0).coerceIn(40.0, 98.0)
        val truckWait = ((150 - (truckCount * 5)) * (yardCapPct / 70.0)).coerceAtLeast(2.0).toInt()
        val energyMw = 2.0 + (craneCount * 0.45) + (truckCount * 0.02)
        val bottleneck = when {
            yardCapPct > 85.0 -> "YARD STACK CONGESTION"
            craneCount < 6 -> "QUAY CRANE CAPACITY"
            truckCount < 12 -> "TERMINAL TRANSPORT (ATV QUEUE)"
            else -> "BALANCED FLOW"
        }

        return WhatIfResult(
            scenarioName = "CUSTOM WHAT-IF PROJECTION",
            craneCount = craneCount,
            truckCount = truckCount,
            yardCapacityPct = yardCapPct,
            throughputTeuHr = throughput,
            avgDwellHours = String.format("%.1f", avgDwell).toDouble(),
            craneUtilizationPct = String.format("%.1f", craneUtil).toDouble(),
            truckWaitMins = truckWait,
            energyLoadMw = String.format("%.1f", energyMw).toDouble(),
            bottleneckArea = bottleneck
        )
    }

    // Replay mode toggle
    fun toggleReplayMode(enable: Boolean) {
        _isReplayMode.value = enable
    }

    // Move Yard Slot Container
    fun moveYardContainer(containerId: String, targetBlock: String, targetBay: Int, targetStack: Int) {
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(_simTime.value.time)
        _containers.value = _containers.value.map { c ->
            if (c.id == containerId) {
                c.copy(
                    currentLocation = "YARD BLOCK $targetBlock STACK 0$targetStack",
                    block = targetBlock,
                    bay = targetBay,
                    stack = targetStack
                )
            } else c
        }
        dispatchIndustrialEvent(
            IndustrialEvent(
                id = "EV-${System.currentTimeMillis() % 10000}",
                timestamp = timeStr,
                assetId = containerId,
                eventType = "YARD_RELOCATION",
                severity = EventSeverity.INFO,
                summary = "Container $containerId relocated to Block $targetBlock-0$targetBay-0$targetStack",
                details = "Automated RTG relocation order executed."
            )
        )
    }
}
