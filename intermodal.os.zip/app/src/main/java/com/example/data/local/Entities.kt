package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.EventSeverity
import com.example.domain.model.WorkOrderStatus

@Entity(tableName = "industrial_events")
data class EventEntity(
    @PrimaryKey val id: String,
    val timestamp: String,
    val assetId: String,
    val eventType: String,
    val severity: String,
    val summary: String,
    val details: String,
    val acknowledged: Boolean
)

@Entity(tableName = "work_orders")
data class WorkOrderEntity(
    @PrimaryKey val id: String,
    val assetId: String,
    val type: String,
    val priority: String,
    val assignedEngineer: String,
    val status: String,
    val notes: String,
    val timestamp: String
)
