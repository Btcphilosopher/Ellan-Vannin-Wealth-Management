package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EventDao {
    @Query("SELECT * FROM industrial_events ORDER BY timestamp DESC LIMIT 200")
    fun getAllEvents(): Flow<List<EventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: EventEntity)

    @Query("UPDATE industrial_events SET acknowledged = 1 WHERE id = :id")
    suspend fun acknowledgeEvent(id: String)

    @Query("DELETE FROM industrial_events")
    suspend fun clearEvents()
}

@Dao
interface WorkOrderDao {
    @Query("SELECT * FROM work_orders ORDER BY timestamp DESC")
    fun getAllWorkOrders(): Flow<List<WorkOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkOrder(workOrder: WorkOrderEntity)

    @Query("UPDATE work_orders SET status = :status WHERE id = :id")
    suspend fun updateWorkOrderStatus(id: String, status: String)
}
