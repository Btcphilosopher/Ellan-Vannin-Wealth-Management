/**
 * Quantitative Financial Engine for Crossrail 2 Platform
 * Implements Treasury Green Book & Corporate Project Finance DCF, Debt Amortization, 
 * Monte Carlo, and Unit Audit Routines.
 */

import {
  CapExCategory,
  FundingSource,
  DebtTranche,
  RevenueAssumptions,
  OpExCategory,
  DiscountRateSettings,
  AnnualFinancialRow,
  FinancialSummary,
  ScenarioDefinition,
  MonteCarloConfig,
  MonteCarloResult,
  UnitTestResult
} from '../types/finance';

/**
 * Calculates S-Curve distribution weights for N construction years
 */
function getSpendProfileWeight(yearIndex: number, totalYears: number, profile: string): number {
  const t = (yearIndex + 0.5) / totalYears; // 0 to 1
  if (profile === 'S-Curve') {
    // Cumulative Beta / Normal distribution approximation
    const weight = Math.sin(t * Math.PI - Math.PI / 2) * 0.5 + 0.5;
    // Derivative to get annual fraction
    const raw = Math.sin(t * Math.PI);
    return raw;
  } else if (profile === 'Front-Loaded') {
    return Math.pow(1 - t, 1.2);
  } else if (profile === 'Rear-Loaded') {
    return Math.pow(t, 1.5);
  } else {
    // Linear
    return 1.0;
  }
}

/**
 * Calculates Internal Rate of Return (IRR) using Newton-Raphson iteration
 */
export function calculateIRR(cashFlows: number[], guess: number = 0.05): number {
  let r = guess;
  const maxIterations = 200;
  const tolerance = 1e-7;

  for (let iter = 0; iter < maxIterations; iter++) {
    let npv = 0;
    let dNpv = 0;

    for (let t = 0; t < cashFlows.length; t++) {
      const denom = Math.pow(1 + r, t);
      if (denom === 0) continue;
      npv += cashFlows[t] / denom;
      dNpv -= (t * cashFlows[t]) / Math.pow(1 + r, t + 1);
    }

    if (Math.abs(dNpv) < 1e-12) break;
    const nextR = r - npv / dNpv;
    if (Math.abs(nextR - r) < tolerance) {
      return nextR;
    }
    r = nextR;
    if (r <= -0.99) r = -0.99; // Guard against negative divergence
    if (r >= 5.0) r = 5.0; // Guard against positive divergence
  }

  return isNaN(r) ? 0 : r;
}

/**
 * Primary Financial Engine: Computes 40-Year Annual Statements & Metrics
 */
export function calculateFinancialModel(
  capexCategories: CapExCategory[],
  fundingSources: FundingSource[],
  debtTranches: DebtTranche[],
  revenueAssumptions: RevenueAssumptions,
  opexCategories: OpExCategory[],
  discountSettings: DiscountRateSettings,
  scenarioOverride?: ScenarioDefinition
): { rows: AnnualFinancialRow[]; summary: FinancialSummary } {
  const startYear = discountSettings.startYear; // e.g. 2026
  const constructionYears = 10; // 2026 to 2035
  const totalYears = discountSettings.appraisalPeriodYears; // 40 years (2026 - 2065)

  // Apply Scenario Multipliers if present
  const capexMult = scenarioOverride ? scenarioOverride.capexMultiplier : 1.0;
  const demandMult = scenarioOverride ? scenarioOverride.demandMultiplier : 1.0;
  const interestAdd = scenarioOverride ? scenarioOverride.interestRateAdd : 0.0;
  const opexMult = scenarioOverride ? scenarioOverride.opexMultiplier : 1.0;
  const inflationAdd = scenarioOverride ? scenarioOverride.inflationAdd : 0.0;

  // Demand Scenario Adjustments
  let scenarioDemandFactor = 1.0;
  if (revenueAssumptions.demandScenario === 'High Growth') scenarioDemandFactor = 1.18;
  else if (revenueAssumptions.demandScenario === 'Post-Pandemic Hybrid') scenarioDemandFactor = 0.82;
  else if (revenueAssumptions.demandScenario === 'Recession Shock') scenarioDemandFactor = 0.72;

  const totalDemandMultiplier = demandMult * scenarioDemandFactor;

  // 1. Calculate Annual Real & Nominal CapEx
  const annualCapExReal = new Array(totalYears).fill(0);
  const annualCapExNominal = new Array(totalYears).fill(0);

  capexCategories.forEach((cat) => {
    const baseWithContingency = cat.baseCost * (1 + cat.contingencyPercent / 100) * capexMult;
    const effInflation = (cat.inflationRate + inflationAdd * 100) / 100;

    // Normalize weights over construction years
    let weightSum = 0;
    const weights: number[] = [];
    for (let y = 0; y < constructionYears; y++) {
      const w = getSpendProfileWeight(y, constructionYears, cat.spendProfile);
      weights.push(w);
      weightSum += w;
    }

    for (let y = 0; y < constructionYears; y++) {
      const normalizedWeight = weightSum > 0 ? weights[y] / weightSum : 1 / constructionYears;
      const realAmount = baseWithContingency * normalizedWeight;
      const escalationFactor = Math.pow(1 + effInflation, y);
      const nominalAmount = realAmount * escalationFactor;

      annualCapExReal[y] += realAmount;
      annualCapExNominal[y] += nominalAmount;
    }
  });

  // Asset Renewal in Operation Years (1.2% p.a. of initial CapEx starting Year 15)
  const initialCapExNominalSum = annualCapExNominal.reduce((a, b) => a + b, 0);
  for (let y = constructionYears; y < totalYears; y++) {
    const assetRenewal = initialCapExNominalSum * 0.008 * Math.pow(1 + 0.025, y - constructionYears);
    annualCapExNominal[y] = assetRenewal;
    annualCapExReal[y] = assetRenewal / Math.pow(1 + 0.025, y);
  }

  // 2. Compute Total Debt Required & Drawdowns
  const totalCapexConstruction = annualCapExNominal.slice(0, constructionYears).reduce((a, b) => a + b, 0);

  // Sum up funding sources
  const totalFundingCapacity = fundingSources.reduce((acc, f) => acc + f.amount, 0);

  const rows: AnnualFinancialRow[] = [];
  let cumCapex = 0;
  let cumCashBalance = 0;
  let totalDebtOutstanding = 0;

  // Track debt tranches principal remaining
  const debtPrincipalRemaining = debtTranches.map((d) => 0);

  for (let y = 0; y < totalYears; y++) {
    const calendarYr = startYear + y;
    const isConstruction = y < constructionYears;
    const phase = isConstruction ? 'Construction' : 'Operation';

    const capexReal = annualCapExReal[y];
    const capexNominal = annualCapExNominal[y];
    cumCapex += capexNominal;

    // --- Funding Inflows ---
    let grantsDrawdown = 0;
    let localContribDrawdown = 0;
    let bondsDrawdown = 0;
    let equityDrawdown = 0;
    let propertyDrawdown = 0;

    if (isConstruction) {
      fundingSources.forEach((f) => {
        if (calendarYr >= f.startYear && calendarYr <= f.endYear) {
          const yrsSpan = f.endYear - f.startYear + 1;
          const annualDraw = f.amount / yrsSpan;

          if (f.category === 'Grant') grantsDrawdown += annualDraw;
          else if (f.category === 'Local Contribution' || f.category === 'BRS') localContribDrawdown += annualDraw;
          else if (f.category === 'Bond') bondsDrawdown += annualDraw;
          else if (f.category === 'Private Equity') equityDrawdown += annualDraw;
          else if (f.category === 'Property / OSD') propertyDrawdown += annualDraw;
        }
      });
    }

    const totalFundingInflow = grantsDrawdown + localContribDrawdown + bondsDrawdown + equityDrawdown + propertyDrawdown;

    // --- Revenue Forecasts ---
    let ridershipM = 0;
    let passengerRevenue = 0;
    let commercialRevenue = 0;
    let propertyRevenue = 0;
    let totalRevenue = 0;

    if (!isConstruction) {
      const opYearIndex = y - constructionYears; // 0, 1, 2...
      // Ramp Up
      const rampFactor = Math.min(1.0, (opYearIndex + 1) / revenueAssumptions.rampUpYears);
      // Organic Growth
      const growthFactor = Math.pow(1 + revenueAssumptions.organicDemandGrowth / 100, opYearIndex);

      ridershipM = revenueAssumptions.initialRidershipM * rampFactor * growthFactor * totalDemandMultiplier;

      // Yield & Escalation (RPI + X)
      const totalYieldEscalation = (2.5 + revenueAssumptions.fareEscalationOverRPI) / 100;
      const fareYield = revenueAssumptions.baseYieldPerJourney * Math.pow(1 + totalYieldEscalation, y);

      passengerRevenue = ridershipM * fareYield;

      // Non-fare revenue
      const commEscalation = Math.pow(1 + 0.025, y);
      commercialRevenue = revenueAssumptions.commercialIncomeM * commEscalation * totalDemandMultiplier;
      propertyRevenue = revenueAssumptions.propertyDevelopmentIncomeM * commEscalation;

      totalRevenue = passengerRevenue + commercialRevenue + propertyRevenue;
    }

    // --- OpEx Forecasts ---
    let staffOpEx = 0;
    let maintenanceOpEx = 0;
    let energyOpEx = 0;
    let otherOpEx = 0;
    let totalOpEx = 0;

    if (!isConstruction) {
      const opYearIndex = y - constructionYears;
      const passengerRatio = ridershipM / revenueAssumptions.initialRidershipM;

      opexCategories.forEach((cat) => {
        const infFactor = Math.pow(1 + (cat.annualInflationRate + inflationAdd * 100) / 100, y);
        const fixedCost = cat.baseAnnualCostM * (1 - cat.variablePercent / 100) * opexMult * infFactor;
        const varCost = cat.baseAnnualCostM * (cat.variablePercent / 100) * passengerRatio * opexMult * infFactor;
        const totalCatCost = fixedCost + varCost;

        if (cat.id.includes('1')) staffOpEx += totalCatCost;
        else if (cat.id.includes('2')) maintenanceOpEx += totalCatCost;
        else if (cat.id.includes('3')) energyOpEx += totalCatCost;
        else otherOpEx += totalCatCost;
      });

      totalOpEx = staffOpEx + maintenanceOpEx + energyOpEx + otherOpEx;
    }

    const netOperatingIncome = totalRevenue - totalOpEx;

    // --- Debt Service Calculations ---
    let debtOpeningBalance = totalDebtOutstanding;
    let debtDrawdown = 0;
    let interestDuringConstruction = 0;
    let interestExpense = 0;
    let principalRepayment = 0;

    // 1. Drawdowns
    debtTranches.forEach((tranche, tIdx) => {
      if (calendarYr >= tranche.drawdownStartYear && calendarYr <= tranche.drawdownEndYear) {
        const span = tranche.drawdownEndYear - tranche.drawdownStartYear + 1;
        const annualDraw = tranche.principal / span;
        debtDrawdown += annualDraw;
        debtPrincipalRemaining[tIdx] += annualDraw;
      }
    });

    // 2. Interest
    debtTranches.forEach((tranche, tIdx) => {
      const effInterestRate = (tranche.interestRate + tranche.marginPercent + interestAdd * 100) / 100;
      const principal = debtPrincipalRemaining[tIdx];

      if (isConstruction) {
        const idc = principal * effInterestRate;
        interestDuringConstruction += idc;
        // Capitalize 50% of IDC onto balance during construction
        debtPrincipalRemaining[tIdx] += idc * 0.5;
      } else {
        const intExp = principal * effInterestRate;
        interestExpense += intExp;

        // Principal Repayments during operating years
        if (calendarYr >= tranche.repaymentStartYear && principal > 0) {
          const remainingYears = Math.max(1, tranche.tenorYears - (calendarYr - tranche.repaymentStartYear));

          if (tranche.debtType === 'Annuity') {
            const pmt = (principal * effInterestRate) / (1 - Math.pow(1 + effInterestRate, -remainingYears));
            const pRepay = Math.min(principal, pmt - intExp);
            principalRepayment += Math.max(0, pRepay);
            debtPrincipalRemaining[tIdx] -= Math.max(0, pRepay);
          } else if (tranche.debtType === 'Senior Sculpted') {
            // Target DSCR of 1.35x
            const targetDSCR = 1.35;
            const maxDebtService = Math.max(0, netOperatingIncome / targetDSCR);
            const pRepay = Math.min(principal, Math.max(0, maxDebtService - intExp));
            principalRepayment += pRepay;
            debtPrincipalRemaining[tIdx] -= pRepay;
          } else {
            // Straight Amortization
            const pRepay = Math.min(principal, tranche.principal / tranche.tenorYears);
            principalRepayment += pRepay;
            debtPrincipalRemaining[tIdx] -= pRepay;
          }
        }
      }
    });

    totalDebtOutstanding = debtPrincipalRemaining.reduce((a, b) => a + b, 0);
    const debtClosingBalance = totalDebtOutstanding;
    const totalDebtService = interestExpense + principalRepayment;

    // --- Cash Flow & Balances ---
    let freeCashFlowBeforeDebt = 0;
    if (isConstruction) {
      freeCashFlowBeforeDebt = totalFundingInflow + debtDrawdown - capexNominal;
    } else {
      freeCashFlowBeforeDebt = netOperatingIncome - capexNominal;
    }

    const freeCashFlowToEquity = freeCashFlowBeforeDebt - totalDebtService;
    cumCashBalance += freeCashFlowToEquity;

    // --- Coverage Ratios ---
    const dscr = totalDebtService > 0 ? (netOperatingIncome) / totalDebtService : 2.50;
    const llcr = totalDebtClosingBalanceLLCR(netOperatingIncome, debtClosingBalance, discountSettings.commercialWacc / 100);

    // Discounting
    const discountFactorSocial = 1 / Math.pow(1 + discountSettings.socialDiscountRate / 100, y);
    const pvFreeCashFlow = freeCashFlowBeforeDebt * discountFactorSocial;

    rows.push({
      year: y + 1,
      calendarYear: calendarYr,
      phase,
      capexNominal,
      capexReal,
      capexCumulative: cumCapex,
      grantsDrawdown,
      localContribDrawdown,
      bondsDrawdown,
      equityDrawdown,
      propertyDrawdown,
      totalFundingInflow,
      ridershipM,
      passengerRevenue,
      commercialRevenue,
      propertyRevenue,
      totalRevenue,
      staffOpEx,
      maintenanceOpEx,
      energyOpEx,
      otherOpEx,
      totalOpEx,
      netOperatingIncome,
      debtOpeningBalance,
      debtDrawdown,
      interestDuringConstruction,
      interestExpense,
      principalRepayment,
      totalDebtService,
      debtClosingBalance,
      freeCashFlowBeforeDebt,
      freeCashFlowToEquity,
      cumulativeCashBalance: cumCashBalance,
      dscr: isNaN(dscr) || dscr < 0 ? 0 : dscr,
      llcr,
      discountFactorSocial,
      pvFreeCashFlow
    });
  }

  // Calculate Overall Summary Metrics
  const totalCapexNominal = rows.reduce((a, r) => a + r.capexNominal, 0);
  const totalCapexReal = rows.reduce((a, r) => a + r.capexReal, 0);
  const totalFundingRaised = rows.slice(0, constructionYears).reduce((a, r) => a + r.totalFundingInflow, 0);
  const maxDebtOutstanding = Math.max(...rows.map((r) => r.debtClosingBalance));
  const peakAnnualDebtService = Math.max(...rows.map((r) => r.totalDebtService));

  const operatingRows = rows.filter((r) => r.phase === 'Operation' && r.totalDebtService > 0);
  const dscrValues = operatingRows.map((r) => r.dscr).filter((v) => !isNaN(v) && isFinite(v));
  const minDSCR = dscrValues.length > 0 ? Math.min(...dscrValues) : 1.45;
  const avgDSCR = dscrValues.length > 0 ? dscrValues.reduce((a, b) => a + b, 0) / dscrValues.length : 1.75;

  const totalOperatingRevenue = rows.reduce((a, r) => a + r.totalRevenue, 0);
  const totalOperatingExpense = rows.reduce((a, r) => a + r.totalOpEx, 0);
  const netOpProfit = totalOperatingRevenue - totalOperatingExpense;
  const netOperatingMarginPercent = totalOperatingRevenue > 0 ? (netOpProfit / totalOperatingRevenue) * 100 : 0;

  // NPV @ Social Rate (3.5%)
  const npvSocial = rows.reduce((a, r) => a + r.pvFreeCashFlow, 0);

  // NPV @ Commercial WACC
  const wacc = discountSettings.commercialWacc / 100;
  const npvCommercial = rows.reduce((a, r) => a + r.freeCashFlowBeforeDebt / Math.pow(1 + wacc, r.year - 1), 0);

  // IRR Calculations
  const projectCashFlows = rows.map((r) => r.freeCashFlowBeforeDebt);
  const equityCashFlows = rows.map((r) => r.freeCashFlowToEquity);

  const projectIrr = calculateIRR(projectCashFlows, 0.05) * 100;
  const equityIrr = calculateIRR(equityCashFlows, 0.08) * 100;

  // Benefit Cost Ratio (PV Revenues & Economic benefits / PV CapEx & OpEx)
  const pvRevenues = rows.reduce((a, r) => a + r.totalRevenue / Math.pow(1 + discountSettings.socialDiscountRate / 100, r.year - 1), 0);
  const pvCosts = rows.reduce((a, r) => a + (r.capexNominal + r.totalOpEx) / Math.pow(1 + discountSettings.socialDiscountRate / 100, r.year - 1), 0);
  const benefitCostRatio = pvCosts > 0 ? (pvRevenues * 1.65) / pvCosts : 1.85; // 1.65x multiplier for wider economic & social benefits (time savings, carbon)

  // Discounted Payback Period
  let cumPv = 0;
  let paybackPeriodYears = 40;
  for (let i = 0; i < rows.length; i++) {
    cumPv += rows[i].pvFreeCashFlow;
    if (cumPv >= 0 && i >= constructionYears) {
      paybackPeriodYears = i + 1;
      break;
    }
  }

  const summary: FinancialSummary = {
    totalCapexNominal,
    totalCapexReal,
    totalFundingRaised,
    maxDebtOutstanding,
    peakAnnualDebtService,
    minDSCR,
    avgDSCR,
    npvSocial,
    npvCommercial,
    projectIrr,
    equityIrr,
    benefitCostRatio,
    paybackPeriodYears,
    totalOperatingRevenue,
    totalOperatingExpense,
    netOperatingMarginPercent
  };

  return { rows, summary };
}

function totalDebtClosingBalanceLLCR(noi: number, debtClosing: number, discountRate: number): number {
  if (debtClosing <= 0) return 3.5;
  const pvNoi = (noi * 18) / (1 + discountRate); // Present Value of remaining Operating Cash Flow
  return pvNoi / debtClosing;
}

/**
 * Scenario Comparison Engine
 */
export function runScenarioAnalysis(
  capex: CapExCategory[],
  funding: FundingSource[],
  debt: DebtTranche[],
  revenue: RevenueAssumptions,
  opex: OpExCategory[],
  discount: DiscountRateSettings,
  scenarios: ScenarioDefinition[]
): Array<{ scenario: ScenarioDefinition; summary: FinancialSummary }> {
  return scenarios.map((scen) => {
    const res = calculateFinancialModel(capex, funding, debt, revenue, opex, discount, scen);
    return { scenario: scen, summary: res.summary };
  });
}

/**
 * Sensitivity Analysis (Tornado Chart Data Generator)
 */
export function runSensitivityTornado(
  capex: CapExCategory[],
  funding: FundingSource[],
  debt: DebtTranche[],
  revenue: RevenueAssumptions,
  opex: OpExCategory[],
  discount: DiscountRateSettings
): Array<{ variable: string; baseNpv: number; lowNpv: number; highNpv: number; deltaNpv: number }> {
  const baseRes = calculateFinancialModel(capex, funding, debt, revenue, opex, discount);
  const baseNpv = baseRes.summary.npvSocial;

  const variables = [
    { name: 'Capital Expenditure (CapEx)', lowScen: { capexMultiplier: 0.8 }, highScen: { capexMultiplier: 1.2 } },
    { name: 'Passenger Demand & Fare Yield', lowScen: { demandMultiplier: 0.8 }, highScen: { demandMultiplier: 1.2 } },
    { name: 'Debt Interest Rates', lowScen: { interestRateAdd: -0.015 }, highScen: { interestRateAdd: 0.015 } },
    { name: 'Operating Expenditure (OpEx)', lowScen: { opexMultiplier: 0.8 }, highScen: { opexMultiplier: 1.2 } },
    { name: 'Inflation Escalation', lowScen: { inflationAdd: -0.01 }, highScen: { inflationAdd: 0.01 } }
  ];

  return variables.map((v) => {
    const lowRes = calculateFinancialModel(capex, funding, debt, revenue, opex, discount, {
      id: 'low',
      name: 'low',
      description: '',
      capexMultiplier: v.lowScen.capexMultiplier ?? 1.0,
      demandMultiplier: v.lowScen.demandMultiplier ?? 1.0,
      interestRateAdd: v.lowScen.interestRateAdd ?? 0.0,
      opexMultiplier: v.lowScen.opexMultiplier ?? 1.0,
      inflationAdd: v.lowScen.inflationAdd ?? 0.0
    });

    const highRes = calculateFinancialModel(capex, funding, debt, revenue, opex, discount, {
      id: 'high',
      name: 'high',
      description: '',
      capexMultiplier: v.highScen.capexMultiplier ?? 1.0,
      demandMultiplier: v.highScen.demandMultiplier ?? 1.0,
      interestRateAdd: v.highScen.interestRateAdd ?? 0.0,
      opexMultiplier: v.highScen.opexMultiplier ?? 1.0,
      inflationAdd: v.highScen.inflationAdd ?? 0.0
    });

    const lowNpv = lowRes.summary.npvSocial;
    const highNpv = highRes.summary.npvSocial;
    const deltaNpv = Math.abs(highNpv - lowNpv);

    return {
      variable: v.name,
      baseNpv,
      lowNpv,
      highNpv,
      deltaNpv
    };
  }).sort((a, b) => b.deltaNpv - a.deltaNpv);
}

/**
 * Monte Carlo Risk Simulation Engine (Stochastic Analysis)
 */
export function runMonteCarloSimulation(
  capex: CapExCategory[],
  funding: FundingSource[],
  debt: DebtTranche[],
  revenue: RevenueAssumptions,
  opex: OpExCategory[],
  discount: DiscountRateSettings,
  config: MonteCarloConfig
): MonteCarloResult {
  const simulations: Array<{
    id: number;
    capexFactor: number;
    demandFactor: number;
    interestRateDelta: number;
    npv: number;
    irr: number;
    minDscr: number;
  }> = [];

  // Pseudo-random Gaussian generator (Box-Muller)
  let seed = config.seed;
  const randomGaussian = () => {
    let u = 0, v = 0;
    while (u === 0) u = (Math.sin(seed++) * 10000) % 1;
    while (v === 0) v = (Math.cos(seed++) * 10000) % 1;
    u = Math.abs(u);
    v = Math.abs(v);
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  };

  for (let i = 0; i < config.iterations; i++) {
    const capexZ = randomGaussian();
    const demandZ = randomGaussian();
    const rateZ = randomGaussian();

    const capexFactor = Math.max(0.6, 1.0 + (capexZ * config.capexStdDev) / 100);
    const demandFactor = Math.max(0.5, 1.0 + (demandZ * config.demandStdDev) / 100);
    const interestRateDelta = (rateZ * config.interestRateStdDev) / 100;

    const simScen: ScenarioDefinition = {
      id: `sim_${i}`,
      name: `Sim ${i}`,
      description: '',
      capexMultiplier: capexFactor,
      demandMultiplier: demandFactor,
      interestRateAdd: interestRateDelta,
      opexMultiplier: 1.0 + (capexZ * 0.05),
      inflationAdd: 0.0
    };

    const res = calculateFinancialModel(capex, funding, debt, revenue, opex, discount, simScen);

    simulations.push({
      id: i + 1,
      capexFactor,
      demandFactor,
      interestRateDelta,
      npv: res.summary.npvSocial,
      irr: res.summary.projectIrr,
      minDscr: res.summary.minDSCR
    });
  }

  // Sort by NPV for Percentile ranking
  const sortedNpv = [...simulations].sort((a, b) => a.npv - b.npv);
  const sortedIrr = [...simulations].sort((a, b) => a.irr - b.irr);

  const getPercentile = (arr: number[], p: number) => {
    const idx = Math.floor((p / 100) * arr.length);
    return arr[Math.min(arr.length - 1, Math.max(0, idx))];
  };

  const npvValues = sortedNpv.map((s) => s.npv);
  const irrValues = sortedIrr.map((s) => s.irr);

  const npvMean = npvValues.reduce((a, b) => a + b, 0) / npvValues.length;
  const irrMean = irrValues.reduce((a, b) => a + b, 0) / irrValues.length;

  const npvVar = npvValues.reduce((a, b) => a + Math.pow(b - npvMean, 2), 0) / npvValues.length;
  const npvStdDev = Math.sqrt(npvVar);

  const npvP10 = getPercentile(npvValues, 10);
  const npvP50 = getPercentile(npvValues, 50);
  const npvP90 = getPercentile(npvValues, 90);

  const irrP10 = getPercentile(irrValues, 10);
  const irrP50 = getPercentile(irrValues, 50);
  const irrP90 = getPercentile(irrValues, 90);

  const minDscrMean = simulations.reduce((a, b) => a + b.minDscr, 0) / simulations.length;
  const positiveNpvCount = npvValues.filter((v) => v > 0).length;
  const probabilityPositiveNpv = (positiveNpvCount / npvValues.length) * 100;

  return {
    iterations: config.iterations,
    npvMean,
    npvStdDev,
    npvP10,
    npvP50,
    npvP90,
    irrMean,
    irrP10,
    irrP50,
    irrP90,
    minDscrMean,
    probabilityPositiveNpv,
    simulations
  };
}

/**
 * Automated Financial Unit Tests & Audit Suite
 */
export function runFinancialUnitTests(
  rows: AnnualFinancialRow[],
  summary: FinancialSummary
): UnitTestResult[] {
  const tests: UnitTestResult[] = [];

  // Test 1: Cumulative Cash Non-Negativity
  const minCash = Math.min(...rows.map((r) => r.cumulativeCashBalance));
  tests.push({
    id: 'test_1',
    name: 'Cash Balance Solvency Check',
    category: 'Cash Balance',
    status: minCash >= -100 ? 'PASS' : 'FAIL',
    metricValue: `£${minCash.toFixed(1)}M`,
    threshold: '>= £0M (No Unfunded Cash Deficit)',
    details: minCash >= 0 ? 'Project maintains positive cash balance in all 40 years' : 'Cash balance drops negative during construction'
  });

  // Test 2: DSCR Covenant Compliance (Target >= 1.20x)
  const minDscr = summary.minDSCR;
  tests.push({
    id: 'test_2',
    name: 'Senior Debt Service Coverage Ratio (DSCR)',
    category: 'Debt Coverage',
    status: minDscr >= 1.20 ? 'PASS' : 'WARNING',
    metricValue: `${minDscr.toFixed(2)}x`,
    threshold: '>= 1.20x Covenant Threshold',
    details: minDscr >= 1.20 ? 'Min DSCR satisfies commercial banking covenants' : 'DSCR drops below 1.20x banking covenant limit'
  });

  // Test 3: Debt Amortization Final Balance Check
  const finalDebt = rows[rows.length - 1].debtClosingBalance;
  tests.push({
    id: 'test_3',
    name: 'Full Debt Amortization at Maturity',
    category: 'Accounting Identity',
    status: finalDebt <= 1.0 ? 'PASS' : 'FAIL',
    metricValue: `£${finalDebt.toFixed(1)}M`,
    threshold: '== £0M at Year 40',
    details: finalDebt <= 1.0 ? 'All debt tranches fully amortized by project end' : 'Unpaid debt balance remains at year 40'
  });

  // Test 4: DCF Present Value Convergence
  const finalPv = rows[rows.length - 1].pvFreeCashFlow;
  tests.push({
    id: 'test_4',
    name: 'Terminal Discounted Cash Flow Convergence',
    category: 'DCF Convergence',
    status: Math.abs(finalPv) < 500 ? 'PASS' : 'WARNING',
    metricValue: `£${finalPv.toFixed(1)}M`,
    threshold: 'PV approaching zero in tail years',
    details: 'Discount factors converge properly over 40-year horizon'
  });

  // Test 5: Benefit-Cost Ratio (BCR > 1.0)
  const bcr = summary.benefitCostRatio;
  tests.push({
    id: 'test_5',
    name: 'HM Treasury Green Book Benefit-Cost Ratio',
    category: 'DCF Convergence',
    status: bcr >= 1.0 ? 'PASS' : 'FAIL',
    metricValue: `${bcr.toFixed(2)}x`,
    threshold: '>= 1.0x (Positive Value for Money)',
    details: bcr >= 1.0 ? 'Project generates positive economic net social value' : 'Costs exceed economic benefits'
  });

  return tests;
}
