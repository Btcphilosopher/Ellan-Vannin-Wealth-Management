/**
 * Default Crossrail 2 Financial Model Parameters
 * Based on official Transport for London (TfL) & DfT Crossrail 2 Strategic Outline Business Case
 */

import {
  CapExCategory,
  FundingSource,
  DebtTranche,
  RevenueAssumptions,
  OpExCategory,
  DiscountRateSettings,
  ScenarioDefinition,
  MonteCarloConfig
} from '../types/finance';

export const DEFAULT_CAPEX_CATEGORIES: CapExCategory[] = [
  {
    id: 'capex_1',
    name: 'Tunnelling & Civil Works',
    baseCost: 7800, // £7.8B
    contingencyPercent: 18,
    spendProfile: 'S-Curve',
    inflationRate: 2.8,
    description: '37km twin-bore underground running tunnels, shafts & portals'
  },
  {
    id: 'capex_2',
    name: 'Stations & Interchange Hubs',
    baseCost: 6400, // £6.4B
    contingencyPercent: 15,
    spendProfile: 'S-Curve',
    inflationRate: 2.8,
    description: '12 new underground stations (Euston, Victoria, King\'s Cross St Pancras, Wimbledon, etc.)'
  },
  {
    id: 'capex_3',
    name: 'Rolling Stock Fleet',
    baseCost: 3100, // £3.1B
    contingencyPercent: 10,
    spendProfile: 'Rear-Loaded',
    inflationRate: 2.2,
    description: '90 high-capacity 10-car electric multiple unit (EMU) trainsets'
  },
  {
    id: 'capex_4',
    name: 'Depots & Maintenance Facilities',
    baseCost: 1100, // £1.1B
    contingencyPercent: 12,
    spendProfile: 'Linear',
    inflationRate: 2.5,
    description: 'Main maintenance depot at Sunbury & stabling yards at New Southgate'
  },
  {
    id: 'capex_5',
    name: 'Railway Systems & Signalling (ETCS)',
    baseCost: 2300, // £2.3B
    contingencyPercent: 15,
    spendProfile: 'Rear-Loaded',
    inflationRate: 2.5,
    description: 'ETCS Level 2 digital signalling, overhead catenary, traction power & communications'
  },
  {
    id: 'capex_6',
    name: 'Land Acquisition & Safeguarding',
    baseCost: 2600, // £2.6B
    contingencyPercent: 20,
    spendProfile: 'Front-Loaded',
    inflationRate: 3.5,
    description: 'Property acquisition, compulsory purchase orders & environmental mitigation'
  },
  {
    id: 'capex_7',
    name: 'Design, Engineering & Integration',
    baseCost: 1400, // £1.4B
    contingencyPercent: 10,
    spendProfile: 'Front-Loaded',
    inflationRate: 2.5,
    description: 'Detailed engineering design, BIM integration & regulatory compliance'
  },
  {
    id: 'capex_8',
    name: 'Professional Fees & Legal',
    baseCost: 950, // £950M
    contingencyPercent: 10,
    spendProfile: 'Linear',
    inflationRate: 2.5,
    description: 'Project management, legal counsel, parliamentary hybrid bill & procurement'
  },
  {
    id: 'capex_9',
    name: 'Risk & Unforeseen Reserve',
    baseCost: 3500, // £3.5B
    contingencyPercent: 0,
    spendProfile: 'S-Curve',
    inflationRate: 2.8,
    description: 'P80 risk allocation buffer for ground conditions & interface integration'
  }
];

export const DEFAULT_FUNDING_SOURCES: FundingSource[] = [
  {
    id: 'fund_1',
    name: 'UK Central Government DfT Grant',
    category: 'Grant',
    amount: 12500, // £12.5B
    startYear: 2026,
    endYear: 2035,
    seniority: 1,
    isGuaranteed: true,
    notes: 'Direct capital grant allocation from HM Treasury / Department for Transport'
  },
  {
    id: 'fund_2',
    name: 'Mayoral CIL & MCIL2 Developer Levies',
    category: 'Local Contribution',
    amount: 4200, // £4.2B
    startYear: 2026,
    endYear: 2035,
    seniority: 2,
    isGuaranteed: true,
    notes: 'Community Infrastructure Levy charged on new London real estate developments'
  },
  {
    id: 'fund_3',
    name: 'London Business Rate Supplement (BRS)',
    category: 'BRS',
    amount: 3800, // £3.8B
    startYear: 2026,
    endYear: 2035,
    seniority: 3,
    isGuaranteed: true,
    notes: 'Dedicated 2p in the £ rate supplement on commercial rateable properties over £70k'
  },
  {
    id: 'fund_4',
    name: 'Over-Station Property Receipts (OSD)',
    category: 'Property / OSD',
    amount: 2200, // £2.2B
    startYear: 2028,
    endYear: 2035,
    seniority: 4,
    isGuaranteed: false,
    notes: 'Air-rights residential & commercial property sales above new underground stations'
  },
  {
    id: 'fund_5',
    name: 'UK Infrastructure Bank Green Bonds',
    category: 'Bond',
    amount: 5500, // £5.5B
    startYear: 2028,
    endYear: 2035,
    seniority: 5,
    isGuaranteed: true,
    notes: '30-year Green Infrastructure Bonds underwritten by UK Infrastructure Bank (UKIB)'
  },
  {
    id: 'fund_6',
    name: 'Private Equity / Concession Investment',
    category: 'Private Equity',
    amount: 3000, // £3.0B
    startYear: 2030,
    endYear: 2035,
    seniority: 6,
    isGuaranteed: false,
    notes: 'Private co-investment for Rolling Stock & Depot PPP concession'
  }
];

export const DEFAULT_DEBT_TRANCHES: DebtTranche[] = [
  {
    id: 'debt_1',
    name: 'UKIB Senior Green Infrastructure Debt',
    principal: 4500, // £4.5B
    drawdownStartYear: 2028,
    drawdownEndYear: 2035,
    repaymentStartYear: 2036,
    tenorYears: 30,
    interestRate: 4.25, // 4.25%
    debtType: 'Senior Sculpted',
    marginPercent: 0.80
  },
  {
    id: 'debt_2',
    name: 'European Investment Bank / Institutional Bonds',
    principal: 2500, // £2.5B
    drawdownStartYear: 2029,
    drawdownEndYear: 2035,
    repaymentStartYear: 2036,
    tenorYears: 25,
    interestRate: 4.75, // 4.75%
    debtType: 'Annuity',
    marginPercent: 1.10
  },
  {
    id: 'debt_3',
    name: 'Subordinated Mezzanine Facility',
    principal: 1000, // £1.0B
    drawdownStartYear: 2031,
    drawdownEndYear: 2035,
    repaymentStartYear: 2038,
    tenorYears: 20,
    interestRate: 6.50, // 6.5%
    debtType: 'Straight Amortization',
    marginPercent: 2.25
  }
];

export const DEFAULT_REVENUE_ASSUMPTIONS: RevenueAssumptions = {
  initialRidershipM: 270, // 270M annual journeys full opening
  rampUpYears: 5, // 5-year demand ramp up
  baseYieldPerJourney: 4.85, // £4.85 average passenger fare
  fareEscalationOverRPI: 1.0, // RPI + 1.0%
  organicDemandGrowth: 1.2, // 1.2% p.a. population & employment growth
  commercialIncomeM: 145, // £145M / yr retail & advertising
  propertyDevelopmentIncomeM: 95, // £95M / yr ongoing estate rental income
  demandScenario: 'Base Case'
};

export const DEFAULT_OPEX_CATEGORIES: OpExCategory[] = [
  {
    id: 'opex_1',
    name: 'Train Operations & Station Staff',
    baseAnnualCostM: 210, // £210M / yr
    variablePercent: 30,
    annualInflationRate: 2.5,
    description: 'Drivers, station team, customer service, security & control center'
  },
  {
    id: 'opex_2',
    name: 'Track, Signalling & Infrastructure Maintenance',
    baseAnnualCostM: 180, // £180M / yr
    variablePercent: 40,
    annualInflationRate: 2.5,
    description: 'Heavy maintenance, track renewal, catenary & digital signalling servicing'
  },
  {
    id: 'opex_3',
    name: 'Traction Energy & Utility Power',
    baseAnnualCostM: 125, // £125M / yr
    variablePercent: 75,
    annualInflationRate: 3.0,
    description: 'High-voltage electric power supply for 25kV AC overhead catenary'
  },
  {
    id: 'opex_4',
    name: 'Rolling Stock Fleet Availability Lease',
    baseAnnualCostM: 160, // £160M / yr
    variablePercent: 20,
    annualInflationRate: 2.2,
    description: 'ROSCO lease & heavy overhaul maintenance contract'
  },
  {
    id: 'opex_5',
    name: 'Insurance, Administration & Systems',
    baseAnnualCostM: 85, // £85M / yr
    variablePercent: 10,
    annualInflationRate: 2.5,
    description: 'Third-party liability, ticketing IT, marketing, legal & corporate admin'
  }
];

export const DEFAULT_DISCOUNT_RATES: DiscountRateSettings = {
  socialDiscountRate: 3.5, // 3.5% Treasury Green Book standard
  commercialWacc: 6.25, // 6.25% Commercial WACC
  appraisalPeriodYears: 40, // 2026 to 2065
  startYear: 2026
};

export const DEFAULT_SCENARIOS: ScenarioDefinition[] = [
  {
    id: 'scen_base',
    name: 'Base Case (SOBC Baseline)',
    description: 'Official Strategic Outline Business Case assumption set',
    capexMultiplier: 1.0,
    demandMultiplier: 1.0,
    interestRateAdd: 0.0,
    opexMultiplier: 1.0,
    inflationAdd: 0.0
  },
  {
    id: 'scen_cost_overrun',
    name: 'CapEx Cost Overrun (+25%)',
    description: 'Major civil engineering cost inflation and ground condition delay (+25% CapEx)',
    capexMultiplier: 1.25,
    demandMultiplier: 1.0,
    interestRateAdd: 0.005,
    opexMultiplier: 1.05,
    inflationAdd: 0.005
  },
  {
    id: 'scen_demand_shock',
    name: 'Demand Shock / Hybrid Work (-20%)',
    description: 'Sustained remote/hybrid work reducing peak commuter trips (-20% ridership)',
    capexMultiplier: 1.0,
    demandMultiplier: 0.80,
    interestRateAdd: 0.0,
    opexMultiplier: 0.95,
    inflationAdd: 0.0
  },
  {
    id: 'scen_high_inflation',
    name: 'High Inflation & Rates Environment',
    description: 'Persistent macro inflation (+2% CPI/BCIS) and interest rate hike (+200 bps)',
    capexMultiplier: 1.15,
    demandMultiplier: 0.95,
    interestRateAdd: 0.02,
    opexMultiplier: 1.15,
    inflationAdd: 0.02
  },
  {
    id: 'scen_green_optimized',
    name: 'Green Finance Optimised Case',
    description: 'Targeted Green Bond yield discounts (-75 bps interest), high urban density growth (+15% demand)',
    capexMultiplier: 0.95,
    demandMultiplier: 1.15,
    interestRateAdd: -0.0075,
    opexMultiplier: 0.95,
    inflationAdd: 0.0
  }
];

export const DEFAULT_MONTE_CARLO_CONFIG: MonteCarloConfig = {
  iterations: 1000,
  capexStdDev: 12.0, // 12% standard deviation
  demandStdDev: 10.0, // 10% standard deviation
  interestRateStdDev: 0.75, // 0.75 percentage points
  seed: 42
};
