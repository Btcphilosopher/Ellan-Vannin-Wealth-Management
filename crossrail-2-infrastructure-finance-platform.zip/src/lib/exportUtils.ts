/**
 * Export Utilities for Crossrail 2 Platform
 * Handles Excel (.xlsx), PDF Briefing Packs (.pdf), CSV, JSON, and R Script code exports.
 */

import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { AnnualFinancialRow, FinancialSummary } from '../types/finance';
import { STANDALONE_R_SHINY_APP_CODE } from './rCodeTemplates';

/**
 * Generates and downloads a multi-tab Excel Workbook model
 */
export function exportToExcel(
  rows: AnnualFinancialRow[],
  summary: FinancialSummary,
  filename = 'Crossrail2_Financial_Model.xlsx'
) {
  const wb = XLSX.utils.book_new();

  // Tab 1: Executive Summary
  const summaryData = [
    ['CROSSRAIL 2 INFRASTRUCTURE FINANCE PLATFORM - EXECUTIVE SUMMARY'],
    ['Generated Date:', new Date().toLocaleDateString()],
    [''],
    ['Financial Metric', 'Value', 'Unit', 'Benchmark / Covenant'],
    ['Total CapEx (Nominal)', summary.totalCapexNominal.toFixed(1), '£ Millions', 'P80 Estimate'],
    ['Total Funding Capacity', summary.totalFundingRaised.toFixed(1), '£ Millions', 'Target 100% Covered'],
    ['Max Debt Outstanding', summary.maxDebtOutstanding.toFixed(1), '£ Millions', '30-Year Tenor'],
    ['Min Debt Service Coverage (DSCR)', summary.minDSCR.toFixed(2), 'Ratio (x)', '>= 1.20x Banking Covenant'],
    ['HM Treasury Green Book NPV @ 3.5%', summary.npvSocial.toFixed(1), '£ Millions', '> 0 Social Value'],
    ['Commercial WACC NPV @ 6.25%', summary.npvCommercial.toFixed(1), '£ Millions', 'Commercial Return'],
    ['Project Financial IRR', summary.projectIrr.toFixed(2), '% p.a.', 'WACC Benchmark'],
    ['Equity IRR', summary.equityIrr.toFixed(2), '% p.a.', 'Target Equity Yield'],
    ['Benefit-Cost Ratio (BCR)', summary.benefitCostRatio.toFixed(2), 'Ratio (x)', '>= 1.0x Value for Money'],
    ['Discounted Payback Period', summary.paybackPeriodYears.toFixed(0), 'Years', 'Project Horizon'],
    ['Total 30-Yr Operating Revenue', summary.totalOperatingRevenue.toFixed(1), '£ Millions', 'Fare & Commercial'],
    ['Total 30-Yr Operating Expense', summary.totalOperatingExpense.toFixed(1), '£ Millions', 'Staff, Maintenance, Energy'],
    ['Net Operating Margin', summary.netOperatingMarginPercent.toFixed(1), '%', 'EBITDA Margin']
  ];
  const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Executive Summary');

  // Tab 2: 40-Year Financial Statements
  const statementHeaders = [
    'Year',
    'Cal Year',
    'Phase',
    'CapEx Real (£M)',
    'CapEx Nominal (£M)',
    'Grants (£M)',
    'Local & BRS (£M)',
    'Bonds (£M)',
    'Property OSD (£M)',
    'Ridership (M)',
    'Passenger Rev (£M)',
    'Commercial Rev (£M)',
    'Total Rev (£M)',
    'Total OpEx (£M)',
    'Net Op Income (£M)',
    'Debt Drawdown (£M)',
    'Interest Expense (£M)',
    'Principal Repay (£M)',
    'Total Debt Service (£M)',
    'Debt Closing Bal (£M)',
    'FCF Before Debt (£M)',
    'FCF To Equity (£M)',
    'Cum Cash Bal (£M)',
    'DSCR (x)'
  ];

  const statementRows = rows.map((r) => [
    r.year,
    r.calendarYear,
    r.phase,
    r.capexReal.toFixed(1),
    r.capexNominal.toFixed(1),
    r.grantsDrawdown.toFixed(1),
    r.localContribDrawdown.toFixed(1),
    r.bondsDrawdown.toFixed(1),
    r.propertyDrawdown.toFixed(1),
    r.ridershipM.toFixed(1),
    r.passengerRevenue.toFixed(1),
    r.commercialRevenue.toFixed(1),
    r.totalRevenue.toFixed(1),
    r.totalOpEx.toFixed(1),
    r.netOperatingIncome.toFixed(1),
    r.debtDrawdown.toFixed(1),
    r.interestExpense.toFixed(1),
    r.principalRepayment.toFixed(1),
    r.totalDebtService.toFixed(1),
    r.debtClosingBalance.toFixed(1),
    r.freeCashFlowBeforeDebt.toFixed(1),
    r.freeCashFlowToEquity.toFixed(1),
    r.cumulativeCashBalance.toFixed(1),
    r.dscr.toFixed(2)
  ]);

  const wsStatements = XLSX.utils.aoa_to_sheet([statementHeaders, ...statementRows]);
  XLSX.utils.book_append_sheet(wb, wsStatements, '40-Year Financial Model');

  XLSX.writeFile(wb, filename);
}

/**
 * Generates an institutional PDF Executive Briefing Pack
 */
export function exportToPDF(
  rows: AnnualFinancialRow[],
  summary: FinancialSummary,
  filename = 'Crossrail2_Executive_Briefing.pdf'
) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  // Header Banner
  doc.setFillColor(15, 23, 42); // Slate 900
  doc.rect(0, 0, 210, 32, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('CROSSRAIL 2 INFRASTRUCTURE FINANCE PLATFORM', 14, 16);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184); // Slate 400
  doc.text(`Executive Briefing & Strategic Financial Assessment | Issued: ${new Date().toLocaleDateString()}`, 14, 24);

  // Executive Summary Card
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(14, 38, 182, 42, 3, 3, 'F');

  doc.setTextColor(15, 23, 42);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('Project Affordability & Valuation Overview', 18, 46);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  doc.text(`• Total Nominal CapEx: £${(summary.totalCapexNominal / 1000).toFixed(2)} Billion over 10-year construction phase (2026-2035).`, 18, 54);
  doc.text(`• HM Treasury Green Book Net Present Value (NPV @ 3.5%): £${(summary.npvSocial / 1000).toFixed(2)} Billion.`, 18, 60);
  doc.text(`• Project Financial IRR: ${summary.projectIrr.toFixed(2)}% | Equity IRR: ${summary.equityIrr.toFixed(2)}%.`, 18, 66);
  doc.text(`• Minimum Senior Debt Service Coverage Ratio (DSCR): ${summary.minDSCR.toFixed(2)}x (Satisfies Banking Covenant >= 1.20x).`, 18, 72);

  // Key Financial Metrics Table
  autoTable(doc, {
    startY: 86,
    head: [['Key Indicator', 'Project Result', 'Benchmark / Target', 'Audit Status']],
    body: [
      ['Capital Expenditure (Nominal)', `£${summary.totalCapexNominal.toFixed(1)}M`, 'P80 Risk Budget', 'Verified'],
      ['Total Funding Capacity', `£${summary.totalFundingRaised.toFixed(1)}M`, '100% Construction CapEx', 'Secured / Planned'],
      ['Max Debt Outstanding', `£${summary.maxDebtOutstanding.toFixed(1)}M`, '30-Year Tenor', 'Underwritten'],
      ['Min DSCR', `${summary.minDSCR.toFixed(2)}x`, '>= 1.20x Covenant Limit', 'Compliant'],
      ['Benefit-Cost Ratio (BCR)', `${summary.benefitCostRatio.toFixed(2)}x`, '>= 1.0x Value for Money', 'High Value'],
      ['Project IRR', `${summary.projectIrr.toFixed(2)}%`, '6.25% WACC', 'Accretive'],
      ['Net Operating Margin', `${summary.netOperatingMarginPercent.toFixed(1)}%`, '45% Target Margin', 'Robust']
    ],
    theme: 'grid',
    headStyles: { fillColor: [30, 41, 59], textColor: [255, 255, 255], fontStyle: 'bold' },
    styles: { fontSize: 8.5 }
  });

  // Construction Phase Table
  const constRows = rows.slice(0, 10).map((r) => [
    `Year ${r.year} (${r.calendarYear})`,
    `£${r.capexNominal.toFixed(1)}M`,
    `£${r.grantsDrawdown.toFixed(1)}M`,
    `£${r.localContribDrawdown.toFixed(1)}M`,
    `£${r.bondsDrawdown.toFixed(1)}M`,
    `£${r.debtDrawdown.toFixed(1)}M`,
    `£${r.cumulativeCashBalance.toFixed(1)}M`
  ]);

  autoTable(doc, {
    startY: (doc as any).lastAutoTable.finalY + 10,
    head: [['Construction Year', 'CapEx Spend', 'DfT Grants', 'Local & BRS', 'Green Bonds', 'Debt Drawn', 'Cash Balance']],
    body: constRows,
    theme: 'striped',
    headStyles: { fillColor: [51, 65, 85], textColor: [255, 255, 255] },
    styles: { fontSize: 8 }
  });

  // Footer
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(`Crossrail 2 Infrastructure Finance Platform — Page ${i} of ${pageCount}`, 14, 288);
  }

  doc.save(filename);
}

/**
 * Exports complete R source code project
 */
export function downloadRCodeBundle() {
  const blob = new Blob([STANDALONE_R_SHINY_APP_CODE], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'app.R';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
