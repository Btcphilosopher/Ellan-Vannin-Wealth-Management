/**
 * Production Standalone R Shiny Application Template
 * Written in standard R with Shiny, data.table, tidyverse, plotly, gt, openxlsx, duckdb, and arrow.
 */

export const STANDALONE_R_SHINY_APP_CODE = `# ==============================================================================
# Crossrail 2 Infrastructure Finance Platform (R)
# Production Shiny Application & Financial Quantitative Engine
# Packages required: shiny, bslib, data.table, tidyverse, plotly, gt, openxlsx, duckdb, arrow
# ==============================================================================

library(shiny)
library(bslib)
library(data.table)
library(tidyverse)
library(plotly)
library(gt)
library(openxlsx)
library(duckdb)
library(arrow)

# ------------------------------------------------------------------------------
# 1. Financial Functions Engine in R
# ------------------------------------------------------------------------------

calculate_crossrail2_model <- function(
  capex_mult = 1.0,
  demand_mult = 1.0,
  interest_add = 0.0,
  opex_mult = 1.0,
  discount_rate = 0.035,
  wacc = 0.0625
) {
  years <- 1:40
  cal_years <- 2025 + years
  
  # CapEx Profile (2026-2035: £31.2B base escalated)
  base_capex <- c(1800, 2400, 3500, 4200, 4800, 4500, 3800, 2900, 1900, 1400, rep(250, 30))
  capex_nominal <- base_capex * capex_mult * (1.028 ^ (years - 1))
  
  # Funding Inflows (Grants, CIL2, BRS, Bonds)
  grants <- c(rep(1250, 10), rep(0, 30))
  local_contrib <- c(rep(800, 10), rep(0, 30))
  bonds <- c(rep(550, 10), rep(0, 30))
  total_funding <- grants + local_contrib + bonds
  
  # Revenue (30-year operation 2036-2065)
  ridership_base <- c(rep(0, 10), 120, 180, 230, 255, 270 * (1.012 ^ (0:25))) * demand_mult
  passenger_rev <- ridership_base * (4.85 * (1.035 ^ (years - 1)))
  commercial_rev <- c(rep(0, 10), rep(240, 30)) * (1.025 ^ (years - 1))
  total_revenue <- passenger_rev + commercial_rev
  
  # OpEx
  opex_base <- c(rep(0, 10), rep(760, 30)) * opex_mult * (1.025 ^ (years - 1))
  net_operating_income <- total_revenue - opex_base
  
  # Debt Service
  debt_drawdowns <- c(rep(700, 10), rep(0, 30))
  interest_rate <- 0.045 + interest_add
  
  interest_exp <- numeric(40)
  principal_repay <- numeric(40)
  debt_bal <- numeric(40)
  cum_debt <- 0
  
  for (i in 1:40) {
    if (i <= 10) {
      cum_debt <- cum_debt + debt_drawdowns[i]
      interest_exp[i] <- cum_debt * interest_rate
    } else {
      interest_exp[i] <- cum_debt * interest_rate
      p_repay <- min(cum_debt, cum_debt / (31 - (i - 10)))
      principal_repay[i] <- p_repay
      cum_debt <- cum_debt - p_repay
    }
    debt_bal[i] <- cum_debt
  }
  
  total_debt_service <- interest_exp + principal_repay
  
  # Free Cash Flow
  fcf_before_debt <- ifelse(years <= 10, total_funding + debt_drawdowns - capex_nominal, net_operating_income - capex_nominal)
  fcf_equity <- fcf_before_debt - total_debt_service
  cum_cash <- cumsum(fcf_equity)
  
  # DSCR
  dscr <- ifelse(total_debt_service > 0, net_operating_income / total_debt_service, 2.5)
  
  # NPV
  pv_social <- fcf_before_debt / ((1 + discount_rate) ^ (years - 1))
  npv_social <- sum(pv_social)
  
  dt <- data.table(
    Year = years,
    CalYear = cal_years,
    Phase = ifelse(years <= 10, "Construction", "Operation"),
    CapEx_Nominal = capex_nominal,
    Total_Funding = total_funding,
    Ridership_M = ridership_base,
    Total_Revenue = total_revenue,
    Total_OpEx = opex_base,
    NOI = net_operating_income,
    Debt_Drawdown = debt_drawdowns,
    Interest_Expense = interest_exp,
    Principal_Repay = principal_repay,
    Debt_Service = total_debt_service,
    Debt_Balance = debt_bal,
    FCF_Equity = fcf_equity,
    Cum_Cash = cum_cash,
    DSCR = dscr,
    PV_Social = pv_social
  )
  
  list(dt = dt, npv_social = npv_social)
}

# ------------------------------------------------------------------------------
# 2. Shiny UI
# ------------------------------------------------------------------------------

ui <- page_navbar(
  title = "Crossrail 2 Infrastructure Finance Platform (R)",
  theme = bs_theme(version = 5, bootswatch = "flatly", primary = "#0f172a"),
  
  nav_panel(
    "Executive Summary",
    layout_sidebar(
      sidebar = sidebar(
        title = "Model Control Panel",
        sliderInput("capex_slider", "CapEx Cost Overrun (%):", min = -20, max = 50, value = 0, step = 5),
        sliderInput("demand_slider", "Passenger Demand Change (%):", min = -40, max = 30, value = 0, step = 5),
        sliderInput("interest_slider", "Interest Rate Shift (bps):", min = -200, max = 300, value = 0, step = 25),
        numericInput("discount_rate", "Green Book Discount Rate (%):", value = 3.5, step = 0.25),
        hr(),
        downloadButton("export_excel", "Export Excel Model", class = "btn-success w-100")
      ),
      layout_columns(
        fill = FALSE,
        value_box("Total CapEx (Nominal)", textOutput("box_capex"), show_header = FALSE, theme = "primary"),
        value_box("Green Book NPV @ 3.5%", textOutput("box_npv"), show_header = FALSE, theme = "success"),
        value_box("Min DSCR Coverage", textOutput("box_dscr"), show_header = FALSE, theme = "info")
      ),
      card(
        card_header("30-Year Cash Flow & Debt Amortization Profile"),
        plotlyOutput("cash_flow_plot", height = "400px")
      )
    )
  ),
  
  nav_panel(
    "Financial Table (gt)",
    card(
      card_header("40-Year Financial Statement"),
      gt_output("financial_gt_table")
    )
  )
)

# ------------------------------------------------------------------------------
# 3. Shiny Server
# ------------------------------------------------------------------------------

server <- function(input, output, session) {
  
  model_data <- reactive({
    calculate_crossrail2_model(
      capex_mult = 1.0 + (input$capex_slider / 100),
      demand_mult = 1.0 + (input$demand_slider / 100),
      interest_add = input$interest_slider / 10000,
      discount_rate = input$discount_rate / 100
    )
  })
  
  output$box_capex <- renderText({
    m <- model_data()
    paste0("£", round(sum(m$dt$CapEx_Nominal) / 1000, 2), " Billion")
  })
  
  output$box_npv <- renderText({
    m <- model_data()
    paste0("£", round(m$npv_social / 1000, 2), " Billion")
  })
  
  output$box_dscr <- renderText({
    m <- model_data()
    op_dscr <- m$dt[Phase == "Operation" & Debt_Service > 0, DSCR]
    paste0(round(min(op_dscr), 2), "x")
  })
  
  output$cash_flow_plot <- renderPlotly({
    m <- model_data()
    p <- plot_ly(m$dt, x = ~CalYear) %>%
      add_bars(y = ~Total_Revenue, name = "Operating Revenue", marker = list(color = "#10b981")) %>%
      add_bars(y = ~-Total_OpEx, name = "Operating Expense", marker = list(color = "#f43f5e")) %>%
      add_lines(y = ~Debt_Balance, name = "Debt Outstanding", line = list(color = "#3b82f6", width = 3)) %>%
      layout(
        title = "Annual Financial Flows & Debt Trajectory (£M)",
        xaxis = list(title = "Calendar Year"),
        yaxis = list(title = "Amount (£ Millions)"),
        barmode = "relative"
      )
    p
  })
  
  output$financial_gt_table <- render_gt({
    m <- model_data()
    gt(m$dt[1:15, .(CalYear, Phase, CapEx_Nominal, Total_Revenue, Total_OpEx, NOI, Debt_Balance, DSCR)]) %>%
      tab_header(title = "Crossrail 2 Infrastructure Statements", subtitle = "Selected Construction & Early Operational Years") %>%
      fmt_currency(columns = c(CapEx_Nominal, Total_Revenue, Total_OpEx, NOI, Debt_Balance), currency = "GBP", decimals = 1) %>%
      fmt_number(columns = c(DSCR), decimals = 2)
  })
  
  output$export_excel <- downloadHandler(
    filename = function() { "Crossrail2_Financial_Model_R.xlsx" },
    content = function(file) {
      m <- model_data()
      write.xlsx(m$dt, file)
    }
  )
}

shinyApp(ui = ui, server = server)
`;
