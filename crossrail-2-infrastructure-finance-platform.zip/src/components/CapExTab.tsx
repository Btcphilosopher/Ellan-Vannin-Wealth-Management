/**
 * Capital Expenditure (CapEx) Model Tab
 * Detailed breakdown, S-Curve profile customization, inflation escalators, and annual spending profile.
 */

import React from 'react';
import { CapExCategory, AnnualFinancialRow } from '../types/finance';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { Building2, Plus, Trash2, RotateCcw } from 'lucide-react';

interface CapExTabProps {
  categories: CapExCategory[];
  setCategories: React.Dispatch<React.SetStateAction<CapExCategory[]>>;
  rows: AnnualFinancialRow[];
  darkMode: boolean;
}

export const CapExTab: React.FC<CapExTabProps> = ({
  categories,
  setCategories,
  rows,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';
  const inputBg = darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900';

  const handleCategoryChange = (id: string, field: keyof CapExCategory, val: any) => {
    setCategories((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: val } : item))
    );
  };

  const handleAddCategory = () => {
    const newCat: CapExCategory = {
      id: `capex_${Date.now()}`,
      name: 'New CapEx Item',
      baseCost: 500,
      contingencyPercent: 15,
      spendProfile: 'S-Curve',
      inflationRate: 2.5,
      description: 'Custom capital expenditure category'
    };
    setCategories((prev) => [...prev, newCat]);
  };

  const handleDeleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((item) => item.id !== id));
  };

  const totalBaseCost = categories.reduce((sum, c) => sum + c.baseCost, 0);
  const totalWithContingency = categories.reduce(
    (sum, c) => sum + c.baseCost * (1 + c.contingencyPercent / 100),
    0
  );

  const constRows = rows.slice(0, 10);

  return (
    <div className="space-y-6">
      
      {/* Top Header Card */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Building2 className="w-5 h-5 text-blue-500" />
              <h2 className="text-xl font-bold tracking-tight">Capital Expenditure (CapEx) Model</h2>
            </div>
            <p className={`text-xs mt-1 ${textMuted}`}>
              10-Year annual construction expenditure profile across 9 engineering categories with S-Curve and inflation indexation.
            </p>
          </div>

          <div className="flex items-center space-x-6 text-sm">
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Base Unescalated</span>
              <span className="font-bold text-lg text-slate-200">£{totalBaseCost.toLocaleString()}M</span>
            </div>
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>With Contingency</span>
              <span className="font-bold text-lg text-blue-400">£{totalWithContingency.toLocaleString(undefined, { maximumFractionDigits: 0 })}M</span>
            </div>
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Total Escalate Nominal</span>
              <span className="font-bold text-lg text-emerald-400">
                £{constRows.reduce((a, r) => a + r.capexNominal, 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}M
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* S-Curve Construction Profile Chart */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-1">Annual Construction Spend & Escalation Curve (£M)</h3>
        <p className={`text-xs ${textMuted} mb-4`}>Annual spend distribution comparing Real (Base 2026 £) vs. Nominal (Escalated £) construction outflow.</p>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={constRows} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="calendarYear" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} unit="M" />
              <Tooltip contentStyle={{ fontSize: '12px' }} />
              <Legend />
              <Bar dataKey="capexReal" name="Real CapEx (2026 £M)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="capexNominal" name="Nominal CapEx (Escalated £M)" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* CapEx Category Configuration Table */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-base">Engineering & Infrastructure Category Breakdown</h3>
            <p className={`text-xs ${textMuted}`}>Configure base cost estimates, contingency buffers, spend profile distributions, and annual inflation rates.</p>
          </div>
          <button
            onClick={handleAddCategory}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Category</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className={`uppercase border-b font-semibold ${darkMode ? 'border-slate-800 text-slate-400 bg-slate-800/40' : 'border-slate-200 text-slate-600 bg-slate-100'}`}>
              <tr>
                <th className="p-3">Category Name</th>
                <th className="p-3">Base Cost (£M)</th>
                <th className="p-3">Contingency (%)</th>
                <th className="p-3">Total Subtotal (£M)</th>
                <th className="p-3">Spend Profile</th>
                <th className="p-3">Inflation (% p.a.)</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50 font-medium">
              {categories.map((cat) => {
                const subtotal = cat.baseCost * (1 + cat.contingencyPercent / 100);
                return (
                  <tr key={cat.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="p-3">
                      <input
                        type="text"
                        value={cat.name}
                        onChange={(e) => handleCategoryChange(cat.id, 'name', e.target.value)}
                        className={`w-full px-2 py-1 rounded border text-xs focus:outline-none ${inputBg}`}
                      />
                      <span className="block text-[10px] text-slate-500 mt-0.5">{cat.description}</span>
                    </td>
                    <td className="p-3 w-32">
                      <input
                        type="number"
                        value={cat.baseCost}
                        onChange={(e) => handleCategoryChange(cat.id, 'baseCost', Number(e.target.value))}
                        className={`w-full px-2 py-1 rounded border text-xs text-right font-bold focus:outline-none ${inputBg}`}
                      />
                    </td>
                    <td className="p-3 w-28">
                      <input
                        type="number"
                        value={cat.contingencyPercent}
                        onChange={(e) => handleCategoryChange(cat.id, 'contingencyPercent', Number(e.target.value))}
                        className={`w-full px-2 py-1 rounded border text-xs text-right focus:outline-none ${inputBg}`}
                      />
                    </td>
                    <td className="p-3 w-32 font-bold text-blue-400 text-right">
                      £{subtotal.toLocaleString(undefined, { maximumFractionDigits: 1 })}M
                    </td>
                    <td className="p-3 w-36">
                      <select
                        value={cat.spendProfile}
                        onChange={(e) => handleCategoryChange(cat.id, 'spendProfile', e.target.value as any)}
                        className={`w-full px-2 py-1 rounded border text-xs focus:outline-none cursor-pointer ${inputBg}`}
                      >
                        <option value="S-Curve">S-Curve</option>
                        <option value="Linear">Linear</option>
                        <option value="Front-Loaded">Front-Loaded</option>
                        <option value="Rear-Loaded">Rear-Loaded</option>
                      </select>
                    </td>
                    <td className="p-3 w-28">
                      <input
                        type="number"
                        step="0.1"
                        value={cat.inflationRate}
                        onChange={(e) => handleCategoryChange(cat.id, 'inflationRate', Number(e.target.value))}
                        className={`w-full px-2 py-1 rounded border text-xs text-right focus:outline-none ${inputBg}`}
                      />
                    </td>
                    <td className="p-3 w-16 text-center">
                      <button
                        onClick={() => handleDeleteCategory(cat.id)}
                        className="p-1 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors"
                        title="Delete Category"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
