/**
 * Embedded WebR Studio & Interactive R Console
 * Features live execution of real R scripts via @r-wasm/webr with stdout/stderr terminal streams.
 */

import React, { useState, useEffect } from 'react';
import { executeRCode, registerWebROutputListener, isWebRReady } from '../lib/webrEngine';
import { Terminal, Play, Download, Copy, Check, Cpu, RefreshCw } from 'lucide-react';
import { STANDALONE_R_SHINY_APP_CODE } from '../lib/rCodeTemplates';

interface WebRConsoleTabProps {
  darkMode: boolean;
  onExportRCode: () => void;
}

const R_SNIPPETS = {
  capex: `# ==============================================================================
# Crossrail 2 - Capital Expenditure Analysis in R (data.table)
# ==============================================================================
library(data.table)

capex_dt <- data.table(
  Category = c("Tunnelling & Civils", "Stations & Hubs", "Rolling Stock Fleet", 
               "Depots", "Systems & Signalling", "Land & Safeguarding", 
               "Design & Engineering", "Risk Buffer"),
  Base_Cost_M = c(7800, 6400, 3100, 1100, 2300, 2600, 1400, 3500),
  Contingency_Pct = c(18, 15, 10, 12, 15, 20, 10, 0)
)

# Calculate Subtotals
capex_dt[, Contingency_M := Base_Cost_M * (Contingency_Pct / 100)]
capex_dt[, Total_M := Base_Cost_M + Contingency_M]

print(capex_dt)
cat("\\nTotal Real CapEx Estimate: £", sum(capex_dt$Total_M), "Million\\n")`,

  debt: `# ==============================================================================
# Crossrail 2 - Senior Debt Service Schedule & DSCR in R
# ==============================================================================

years <- 2026:2065
noi <- c(rep(0, 10), seq(800, 2200, length.out = 30))
debt_principal <- 4500
tenor <- 30
interest_rate <- 0.0425

debt_balance <- numeric(40)
interest_exp <- numeric(40)
principal_repay <- numeric(40)

bal <- 0
for (i in 1:40) {
  if (i <= 10) {
    bal <- bal + (debt_principal / 10)
    interest_exp[i] <- bal * interest_rate
  } else {
    interest_exp[i] <- bal * interest_rate
    p <- min(bal, bal / (31 - (i - 10)))
    principal_repay[i] <- p
    bal <- bal - p
  }
  debt_balance[i] <- bal
}

dscr <- ifelse((interest_exp + principal_repay) > 0, noi / (interest_exp + principal_repay), NA)

res_df <- data.frame(
  Year = years[1:15],
  NOI = noi[1:15],
  Debt_Balance = debt_balance[1:15],
  Interest = interest_exp[1:15],
  Principal = principal_repay[1:15],
  DSCR = round(dscr[1:15], 2)
)

print(head(res_df, 12))`,

  dcf: `# ==============================================================================
# Crossrail 2 - HM Treasury Green Book Discounted Cash Flow (DCF)
# ==============================================================================

calculate_dcf <- function(discount_rate = 0.035) {
  years <- 1:40
  # Net Cash Flow profile (10 yrs construction, 30 yrs operation)
  net_cash_flow <- c(-1800, -2400, -3500, -4200, -4800, -4500, -3800, -2900, -1900, -1400,
                     rep(1200, 30))
  
  discount_factors <- 1 / ((1 + discount_rate) ^ (years - 1))
  pv_cash_flows <- net_cash_flow * discount_factors
  
  npv <- sum(pv_cash_flows)
  
  cat("HM Treasury Green Book Discount Rate:", discount_rate * 100, "%\\n")
  cat("Calculated Social Net Present Value (NPV): £", round(npv, 2), "Million\\n")
}

calculate_dcf(0.035)`,

  full_app: STANDALONE_R_SHINY_APP_CODE
};

export const WebRConsoleTab: React.FC<WebRConsoleTabProps> = ({
  darkMode,
  onExportRCode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';

  const [activeSnippet, setActiveSnippet] = useState<keyof typeof R_SNIPPETS>('capex');
  const [rCode, setRCode] = useState(R_SNIPPETS.capex);
  const [consoleLogs, setConsoleLogs] = useState<Array<{ type: string; text: string }>>([
    { type: 'system', text: 'WebR v4.3 WebAssembly R Console initialized.' },
    { type: 'system', text: 'Type or edit R code on the left and click "Execute R Code".' }
  ]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const unregister = registerWebROutputListener((msg) => {
      setConsoleLogs((prev) => [...prev, msg]);
    });
    return unregister;
  }, []);

  const handleSnippetSelect = (snippetKey: keyof typeof R_SNIPPETS) => {
    setActiveSnippet(snippetKey);
    setRCode(R_SNIPPETS[snippetKey]);
  };

  const handleExecuteR = async () => {
    setIsExecuting(true);
    setConsoleLogs((prev) => [...prev, { type: 'system', text: '> Executing R statement...' }]);
    const res = await executeRCode(rCode);
    setIsExecuting(false);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(rCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Terminal className="w-5 h-5 text-blue-500" />
              <h2 className="text-xl font-bold tracking-tight">WebR Studio & Live R Console</h2>
              <span className="px-2 py-0.5 text-xs font-semibold rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                WebAssembly R v4.3
              </span>
            </div>
            <p className={`text-xs mt-1 ${textMuted}`}>
              Run native R code, data.table, tidyverse transformations, and Shiny modules live in your browser powered by Posit WebR.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={onExportRCode}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download app.R</span>
            </button>
          </div>
        </div>
      </div>

      {/* Snippet Selection Tabs */}
      <div className="flex space-x-2 border-b border-slate-800 pb-2 text-xs">
        <button
          onClick={() => handleSnippetSelect('capex')}
          className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
            activeSnippet === 'capex' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          capex_model.R
        </button>
        <button
          onClick={() => handleSnippetSelect('debt')}
          className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
            activeSnippet === 'debt' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          debt_schedule.R
        </button>
        <button
          onClick={() => handleSnippetSelect('dcf')}
          className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
            activeSnippet === 'dcf' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          dcf_npv_irr.R
        </button>
        <button
          onClick={() => handleSnippetSelect('full_app')}
          className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
            activeSnippet === 'full_app' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          Complete R Shiny App (app.R)
        </button>
      </div>

      {/* R Code Editor & Live Console Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Code Editor */}
        <div className={`p-4 rounded-xl border shadow-sm ${cardBg} flex flex-col`}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase text-slate-400">R Script Editor</span>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopyCode}
                className="p-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs flex items-center space-x-1 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
              <button
                onClick={handleExecuteR}
                disabled={isExecuting}
                className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors cursor-pointer"
              >
                {isExecuting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                <span>Run R Code</span>
              </button>
            </div>
          </div>

          <textarea
            value={rCode}
            onChange={(e) => setRCode(e.target.value)}
            rows={18}
            className="w-full font-mono text-xs p-3 rounded-lg bg-slate-950 border border-slate-800 text-emerald-400 focus:outline-none resize-none leading-relaxed"
          />
        </div>

        {/* Right Column: R Console Output */}
        <div className={`p-4 rounded-xl border shadow-sm ${cardBg} flex flex-col`}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase text-slate-400">Live R Stdout Terminal</span>
            <button
              onClick={() => setConsoleLogs([])}
              className="text-xs text-slate-500 hover:text-slate-300 cursor-pointer"
            >
              Clear Console
            </button>
          </div>

          <div className="w-full h-96 p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs overflow-y-auto space-y-1 scrollbar-thin">
            {consoleLogs.map((log, index) => {
              let textClass = 'text-slate-300';
              if (log.type === 'system') textClass = 'text-blue-400 italic';
              else if (log.type === 'stderr') textClass = 'text-rose-400 font-semibold';
              else if (log.type === 'stdout') textClass = 'text-emerald-300';

              return (
                <div key={index} className={`whitespace-pre-wrap ${textClass}`}>
                  {log.text}
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
