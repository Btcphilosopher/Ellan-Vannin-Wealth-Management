/**
 * Passenger Demand & Revenue Forecasts Tab
 * Models passenger ridership ramp-up, fare yields (RPI+X), advertising, and station commercial property.
 */

import React from 'react';
import { RevenueAssumptions, AnnualFinancialRow } from '../types/finance';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { TrendingUp, Users, Ticket, Store, Building } from 'lucide-react';

interface RevenueTabProps {
  assumptions: RevenueAssumptions;
  setAssumptions: React.Dispatch<React.SetStateAction<RevenueAssumptions>>;
  rows: AnnualFinancialRow[];
  darkMode: boolean;
}

export const RevenueTab: React.FC<RevenueTabProps> = ({
  assumptions,
  setAssumptions,
  rows,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';
  const inputBg = darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900';

  const opRows = rows.slice(10); // 30 operational years

  const totalOperatingRev = opRows.reduce((a, r) => a + r.totalRevenue, 0);
  const peakRidership = Math.max(...opRows.map((r) => r.ridershipM));

  const chartData = opRows.map((r) => ({
    year: r.calendarYear,
    passenger: r.passengerRevenue,
    commercial: r.commercialRevenue,
    property: r.propertyRevenue,
    ridership: r.ridershipM
  }));

  return (
    <div className="space-y-6">
      
      {/* Top Banner Card */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-emerald-500" />
              <h2 className="text-xl font-bold tracking-tight">Passenger Revenue & Demand Forecasting Engine</h2>
            </div>
            <p className={`text-xs mt-1 ${textMuted}`}>
              Demand elasticity, 5-year post-opening ramp-up curve, RPI+X fare indexation policy, and commercial estate concessions.
            </p>
          </div>

          <div className="flex items-center space-x-6 text-sm">
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Peak Annual Journeys</span>
              <span className="font-bold text-lg text-emerald-400">{peakRidership.toFixed(0)} Million</span>
            </div>
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>30-Yr Total Revenue</span>
              <span className="font-bold text-lg text-slate-200">£{(totalOperatingRev / 1000).toFixed(2)} Billion</span>
            </div>
          </div>
        </div>
      </div>

      {/* Demand Curve Chart */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-1">30-Year Revenue Stream Trajectory (£M)</h3>
        <p className={`text-xs ${textMuted} mb-4`}>Annual revenue composition showing passenger fare box, commercial concessions, and property estate income.</p>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="year" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} unit="M" />
              <Tooltip contentStyle={{ fontSize: '12px' }} />
              <Legend />
              <Area type="monotone" dataKey="passenger" name="Passenger Fares" stackId="a" stroke="#10b981" fill="#10b981" />
              <Area type="monotone" dataKey="commercial" name="Commercial & Advertising" stackId="a" stroke="#3b82f6" fill="#3b82f6" />
              <Area type="monotone" dataKey="property" name="Property Concessions" stackId="a" stroke="#8b5cf6" fill="#8b5cf6" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Key Revenue Assumptions Input Grid */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-4">Passenger Demand & Commercial Assumptions</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Baseline Ridership */}
          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              Full Opening Ridership (M Journeys/Yr)
            </label>
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-emerald-500" />
              <input
                type="number"
                value={assumptions.initialRidershipM}
                onChange={(e) => setAssumptions({ ...assumptions, initialRidershipM: Number(e.target.value) })}
                className={`w-full px-3 py-1.5 rounded border text-sm font-bold focus:outline-none ${inputBg}`}
              />
            </div>
            <span className="block text-[11px] text-slate-500 mt-1">Target journeys at mature operation</span>
          </div>

          {/* Ramp Up Years */}
          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              Demand Ramp-Up Horizon (Years)
            </label>
            <input
              type="number"
              value={assumptions.rampUpYears}
              onChange={(e) => setAssumptions({ ...assumptions, rampUpYears: Number(e.target.value) })}
              className={`w-full px-3 py-1.5 rounded border text-sm font-bold focus:outline-none ${inputBg}`}
            />
            <span className="block text-[11px] text-slate-500 mt-1">Linear build-up to full capacity</span>
          </div>

          {/* Base Fare Yield */}
          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              Base Passenger Fare Yield (£ / Trip)
            </label>
            <div className="flex items-center space-x-2">
              <Ticket className="w-4 h-4 text-blue-500" />
              <input
                type="number"
                step="0.1"
                value={assumptions.baseYieldPerJourney}
                onChange={(e) => setAssumptions({ ...assumptions, baseYieldPerJourney: Number(e.target.value) })}
                className={`w-full px-3 py-1.5 rounded border text-sm font-bold focus:outline-none ${inputBg}`}
              />
            </div>
            <span className="block text-[11px] text-slate-500 mt-1">Average yield per journey in 2026 £</span>
          </div>

          {/* Fare Escalation (RPI+X) */}
          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              Fare Escalation over RPI (% p.a.)
            </label>
            <input
              type="number"
              step="0.1"
              value={assumptions.fareEscalationOverRPI}
              onChange={(e) => setAssumptions({ ...assumptions, fareEscalationOverRPI: Number(e.target.value) })}
              className={`w-full px-3 py-1.5 rounded border text-sm font-bold focus:outline-none ${inputBg}`}
            />
            <span className="block text-[11px] text-slate-500 mt-1">Mayoral RPI + X fare policy</span>
          </div>

          {/* Organic Growth */}
          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              Organic Population Growth (% p.a.)
            </label>
            <input
              type="number"
              step="0.1"
              value={assumptions.organicDemandGrowth}
              onChange={(e) => setAssumptions({ ...assumptions, organicDemandGrowth: Number(e.target.value) })}
              className={`w-full px-3 py-1.5 rounded border text-sm font-bold focus:outline-none ${inputBg}`}
            />
            <span className="block text-[11px] text-slate-500 mt-1">Annual London & SE growth</span>
          </div>

          {/* Commercial Income */}
          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              Retail & Advertising Income (£M/Yr)
            </label>
            <div className="flex items-center space-x-2">
              <Store className="w-4 h-4 text-purple-500" />
              <input
                type="number"
                value={assumptions.commercialIncomeM}
                onChange={(e) => setAssumptions({ ...assumptions, commercialIncomeM: Number(e.target.value) })}
                className={`w-full px-3 py-1.5 rounded border text-sm font-bold focus:outline-none ${inputBg}`}
              />
            </div>
            <span className="block text-[11px] text-slate-500 mt-1">Station retail concessions & ads</span>
          </div>

          {/* Property Development Estate */}
          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              Estate & Property Rental (£M/Yr)
            </label>
            <div className="flex items-center space-x-2">
              <Building className="w-4 h-4 text-amber-500" />
              <input
                type="number"
                value={assumptions.propertyDevelopmentIncomeM}
                onChange={(e) => setAssumptions({ ...assumptions, propertyDevelopmentIncomeM: Number(e.target.value) })}
                className={`w-full px-3 py-1.5 rounded border text-sm font-bold focus:outline-none ${inputBg}`}
              />
            </div>
            <span className="block text-[11px] text-slate-500 mt-1">Ongoing over-station property lease</span>
          </div>

          {/* Demand Scenario Selection */}
          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              Macro Demand Scenario
            </label>
            <select
              value={assumptions.demandScenario}
              onChange={(e) => setAssumptions({ ...assumptions, demandScenario: e.target.value as any })}
              className={`w-full px-3 py-1.5 rounded border text-sm font-bold focus:outline-none cursor-pointer ${inputBg}`}
            >
              <option value="Base Case">Base Case (SOBC)</option>
              <option value="High Growth">High Growth (+18%)</option>
              <option value="Post-Pandemic Hybrid">Post-Pandemic Hybrid (-18%)</option>
              <option value="Recession Shock">Recession Shock (-28%)</option>
            </select>
            <span className="block text-[11px] text-slate-500 mt-1">Scenario adjustment applied</span>
          </div>

        </div>
      </div>

    </div>
  );
};
