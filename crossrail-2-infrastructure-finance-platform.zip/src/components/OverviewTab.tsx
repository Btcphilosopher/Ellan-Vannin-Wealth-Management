/**
 * Executive Summary Overview Tab
 * Visualizes KPI Value Boxes, Cash Flow Waterfall, Debt Profile, Funding Stack, and Revenue vs. OpEx.
 */

import React from 'react';
import { AnnualFinancialRow, FinancialSummary } from '../types/finance';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area
} from 'recharts';
import {
  TrendingUp,
  Building2,
  ShieldCheck,
  Award,
  Clock,
  Coins,
  ArrowUpRight,
  FileSpreadsheet
} from 'lucide-react';

interface OverviewTabProps {
  rows: AnnualFinancialRow[];
  summary: FinancialSummary;
  onExportPDF: () => void;
  onExportExcel: () => void;
  darkMode: boolean;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({
  rows,
  summary,
  onExportPDF,
  onExportExcel,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';

  // Chart Data Preparation
  const chartData = rows.map((r) => ({
    year: r.calendarYear,
    capex: r.capexNominal,
    funding: r.totalFundingInflow,
    revenue: r.totalRevenue,
    opex: r.totalOpEx,
    noi: r.netOperatingIncome,
    debtService: r.totalDebtService,
    debtBalance: r.debtClosingBalance,
    cumCash: r.cumulativeCashBalance,
    dscr: r.dscr
  }));

  // Funding Breakdown Chart Data
  const fundingChartData = rows.slice(0, 10).map((r) => ({
    year: r.calendarYear,
    grants: r.grantsDrawdown,
    local: r.localContribDrawdown,
    bonds: r.bondsDrawdown,
    property: r.propertyDrawdown,
    equity: r.equityDrawdown
  }));

  return (
    <div className="space-y-6">
      
      {/* Strategic Header & Call to Action */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg} flex flex-col md:flex-row md:items-center md:justify-between gap-4`}>
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-1 text-xs font-semibold rounded-md bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300">
              TfL & DfT Strategic Business Case
            </span>
            <span className="text-xs text-slate-400">40-Year Financial Horizon (2026 - 2065)</span>
          </div>
          <h2 className="text-xl font-bold mt-1 tracking-tight">
            Crossrail 2 Financial Valuation & Executive Overview
          </h2>
          <p className={`text-xs mt-0.5 ${textMuted}`}>
            Integrated capital expenditure, debt service amortization, passenger revenue forecasts, and Treasury Green Book discounted cash flow analysis.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={onExportExcel}
            className="flex items-center space-x-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Excel Financial Model</span>
          </button>
          <button
            onClick={onExportPDF}
            className="flex items-center space-x-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-colors cursor-pointer"
          >
            <ArrowUpRight className="w-4 h-4" />
            <span>PDF Executive Briefing</span>
          </button>
        </div>
      </div>

      {/* KPI Value Boxes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
        
        {/* Box 1: Total CapEx */}
        <div className={`p-4 rounded-xl border shadow-sm ${cardBg} relative overflow-hidden`}>
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold uppercase tracking-wider ${textMuted}`}>Total CapEx</span>
            <Building2 className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-2 font-bold text-xl text-blue-600 dark:text-blue-400">
            £{(summary.totalCapexNominal / 1000).toFixed(2)}B
          </div>
          <div className="mt-1 text-xs text-slate-400">P80 Risk Budget Nominal</div>
        </div>

        {/* Box 2: Green Book NPV */}
        <div className={`p-4 rounded-xl border shadow-sm ${cardBg} relative overflow-hidden`}>
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold uppercase tracking-wider ${textMuted}`}>Green Book NPV</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-2 font-bold text-xl text-emerald-600 dark:text-emerald-400">
            £{(summary.npvSocial / 1000).toFixed(2)}B
          </div>
          <div className="mt-1 text-xs text-slate-400">3.5% Social Discount Rate</div>
        </div>

        {/* Box 3: Project & Equity IRR */}
        <div className={`p-4 rounded-xl border shadow-sm ${cardBg} relative overflow-hidden`}>
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold uppercase tracking-wider ${textMuted}`}>Project IRR</span>
            <Award className="w-4 h-4 text-purple-500" />
          </div>
          <div className="mt-2 font-bold text-xl text-purple-600 dark:text-purple-400">
            {summary.projectIrr.toFixed(2)}%
          </div>
          <div className="mt-1 text-xs text-slate-400">Equity IRR: {summary.equityIrr.toFixed(2)}%</div>
        </div>

        {/* Box 4: Min DSCR */}
        <div className={`p-4 rounded-xl border shadow-sm ${cardBg} relative overflow-hidden`}>
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold uppercase tracking-wider ${textMuted}`}>Min DSCR</span>
            <ShieldCheck className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="mt-2 font-bold text-xl text-indigo-600 dark:text-indigo-400">
            {summary.minDSCR.toFixed(2)}x
          </div>
          <div className="mt-1 text-xs text-slate-400">Banking Limit &gt;= 1.20x</div>
        </div>

        {/* Box 5: Benefit-Cost Ratio */}
        <div className={`p-4 rounded-xl border shadow-sm ${cardBg} relative overflow-hidden`}>
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold uppercase tracking-wider ${textMuted}`}>Benefit-Cost (BCR)</span>
            <Coins className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 font-bold text-xl text-amber-600 dark:text-amber-400">
            {summary.benefitCostRatio.toFixed(2)}x
          </div>
          <div className="mt-1 text-xs text-slate-400">High Value for Money</div>
        </div>

        {/* Box 6: Discounted Payback */}
        <div className={`p-4 rounded-xl border shadow-sm ${cardBg} relative overflow-hidden`}>
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold uppercase tracking-wider ${textMuted}`}>Payback Horizon</span>
            <Clock className="w-4 h-4 text-rose-500" />
          </div>
          <div className="mt-2 font-bold text-xl text-rose-600 dark:text-rose-400">
            {summary.paybackPeriodYears} Yrs
          </div>
          <div className="mt-1 text-xs text-slate-400">From Construction Start</div>
        </div>

      </div>

      {/* Main Chart 1: Revenue, OpEx, Debt Balance & Net Operating Income */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-base">30-Year Financial Trajectory & Debt Balance (£ Millions)</h3>
            <p className={`text-xs ${textMuted}`}>Annual passenger & commercial revenues, operating expenses, and senior debt balance curve.</p>
          </div>
          <div className="flex items-center space-x-4 text-xs font-medium">
            <span className="flex items-center space-x-1.5"><span className="w-3 h-3 bg-emerald-500 rounded-sm"></span><span>Revenue</span></span>
            <span className="flex items-center space-x-1.5"><span className="w-3 h-3 bg-rose-500 rounded-sm"></span><span>OpEx</span></span>
            <span className="flex items-center space-x-1.5"><span className="w-3 h-3 bg-blue-500 rounded-sm"></span><span>Debt Outstanding</span></span>
          </div>
        </div>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="year" tick={{ fontSize: 11 }} />
              <YAxis yAxisId="left" tick={{ fontSize: 11 }} unit="M" />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} unit="M" />
              <Tooltip
                contentStyle={{
                  backgroundColor: darkMode ? '#0f172a' : '#ffffff',
                  borderColor: darkMode ? '#334155' : '#cbd5e1',
                  fontSize: '12px'
                }}
              />
              <Legend />
              <Bar yAxisId="left" dataKey="revenue" name="Total Revenue (£M)" fill="#10b981" radius={[2, 2, 0, 0]} />
              <Bar yAxisId="left" dataKey="opex" name="Operating Expense (£M)" fill="#f43f5e" radius={[2, 2, 0, 0]} />
              <Line yAxisId="right" type="monotone" dataKey="debtBalance" name="Debt Outstanding (£M)" stroke="#3b82f6" strokeWidth={3} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Two Grid Charts: Funding Breakdown & Cumulative Cash Reserve */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Funding Breakdown */}
        <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
          <h3 className="font-bold text-base mb-1">Construction Phase Funding Mix (2026-2035)</h3>
          <p className={`text-xs ${textMuted} mb-4`}>Annual drawdown across DfT Grants, Mayoral CIL2, London BRS, and Green Bonds.</p>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={fundingChartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="year" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} unit="M" />
                <Tooltip contentStyle={{ fontSize: '11px' }} />
                <Area type="monotone" dataKey="grants" stackId="1" name="DfT Grants" stroke="#2563eb" fill="#2563eb" />
                <Area type="monotone" dataKey="local" stackId="1" name="Local CIL & BRS" stroke="#059669" fill="#059669" />
                <Area type="monotone" dataKey="bonds" stackId="1" name="Green Bonds" stroke="#d97706" fill="#d97706" />
                <Area type="monotone" dataKey="property" stackId="1" name="Property OSD" stroke="#9333ea" fill="#9333ea" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Cumulative Cash Reserve & FCF */}
        <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
          <h3 className="font-bold text-base mb-1">Cumulative Cash Balance & Reserve (£M)</h3>
          <p className={`text-xs ${textMuted} mb-4`}>Solvency buffer tracking free cash flow to equity over 40-year horizon.</p>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="year" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} unit="M" />
                <Tooltip contentStyle={{ fontSize: '11px' }} />
                <Line type="monotone" dataKey="cumCash" name="Cumulative Cash (£M)" stroke="#10b981" strokeWidth={3} dot={false} />
                <Bar dataKey="debtService" name="Debt Service (£M)" fill="#6366f1" opacity={0.6} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

    </div>
  );
};
