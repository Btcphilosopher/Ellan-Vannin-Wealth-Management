/**
 * Scenario Analysis & Side-by-Side Comparison Matrix
 * Evaluates alternative macro environments, cost overruns, ridership shocks, and green financing.
 */

import React from 'react';
import {
  CapExCategory,
  FundingSource,
  DebtTranche,
  RevenueAssumptions,
  OpExCategory,
  DiscountRateSettings,
  ScenarioDefinition,
  FinancialSummary
} from '../types/finance';
import { runScenarioAnalysis } from '../lib/financeEngine';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { Sparkles, Layers, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface ScenarioTabProps {
  scenarios: ScenarioDefinition[];
  capex: CapExCategory[];
  funding: FundingSource[];
  debt: DebtTranche[];
  revenue: RevenueAssumptions[];
  opex: OpExCategory[];
  discount: DiscountRateSettings;
  darkMode: boolean;
}

export const ScenarioTab: React.FC<ScenarioTabProps> = ({
  scenarios,
  capex,
  funding,
  debt,
  revenue,
  opex,
  discount,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';

  const results = runScenarioAnalysis(capex, funding, debt, revenue[0], opex, discount, scenarios);

  const chartData = results.map((r) => ({
    name: r.scenario.name.replace(' (SOBC Baseline)', ''),
    npv: Math.round(r.summary.npvSocial),
    irr: Number(r.summary.projectIrr.toFixed(2)),
    dscr: Number(r.summary.minDSCR.toFixed(2))
  }));

  const baseResult = results.find((r) => r.scenario.id === 'scen_base')?.summary;

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex items-center space-x-2">
          <Sparkles className="w-5 h-5 text-blue-500" />
          <h2 className="text-xl font-bold tracking-tight">Scenario Analysis & Side-by-Side Evaluation</h2>
        </div>
        <p className={`text-xs mt-1 ${textMuted}`}>
          Comparative financial assessment across 5 macro scenarios evaluating cost overruns, passenger demand shocks, inflation spikes, and green finance optimization.
        </p>
      </div>

      {/* NPV Scenario Visual Bar Chart */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-1">Green Book NPV @ 3.5% Comparison (£ Millions)</h3>
        <p className={`text-xs ${textMuted} mb-4`}>Net Present Value variance across strategic scenarios relative to Base Case baseline.</p>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="name" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} unit="M" />
              <Tooltip contentStyle={{ fontSize: '12px' }} />
              <Bar dataKey="npv" name="Green Book NPV (£M)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Side-by-Side Matrix Table */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-4">Multi-Scenario Key Financial Metrics Matrix</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead className={`uppercase font-semibold border-b ${darkMode ? 'border-slate-800 text-slate-300 bg-slate-800/60' : 'border-slate-200 text-slate-700 bg-slate-100'}`}>
              <tr>
                <th className="p-3">Financial Metric</th>
                {results.map((r) => (
                  <th key={r.scenario.id} className="p-3 text-right">
                    {r.scenario.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50 font-medium">
              
              <tr>
                <td className="p-3 font-semibold text-slate-300">Total CapEx (Nominal)</td>
                {results.map((r) => (
                  <td key={r.scenario.id} className="p-3 text-right font-bold">
                    £{r.summary.totalCapexNominal.toFixed(1)}M
                  </td>
                ))}
              </tr>

              <tr>
                <td className="p-3 font-semibold text-emerald-400">Green Book NPV @ 3.5%</td>
                {results.map((r) => {
                  const delta = baseResult ? r.summary.npvSocial - baseResult.npvSocial : 0;
                  return (
                    <td key={r.scenario.id} className="p-3 text-right font-bold text-emerald-400">
                      £{r.summary.npvSocial.toFixed(1)}M
                      {delta !== 0 && (
                        <span className={`block text-[10px] ${delta >= 0 ? 'text-emerald-500' : 'text-rose-400'}`}>
                          ({delta >= 0 ? '+' : ''}{delta.toFixed(1)}M)
                        </span>
                      )}
                    </td>
                  );
                })}
              </tr>

              <tr>
                <td className="p-3 font-semibold text-purple-400">Project Financial IRR (%)</td>
                {results.map((r) => (
                  <td key={r.scenario.id} className="p-3 text-right font-bold text-purple-400">
                    {r.summary.projectIrr.toFixed(2)}%
                  </td>
                ))}
              </tr>

              <tr>
                <td className="p-3 font-semibold text-indigo-400">Equity IRR (%)</td>
                {results.map((r) => (
                  <td key={r.scenario.id} className="p-3 text-right font-bold text-indigo-400">
                    {r.summary.equityIrr.toFixed(2)}%
                  </td>
                ))}
              </tr>

              <tr>
                <td className="p-3 font-semibold text-blue-400">Minimum Senior DSCR</td>
                {results.map((r) => (
                  <td key={r.scenario.id} className={`p-3 text-right font-bold ${r.summary.minDSCR >= 1.20 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {r.summary.minDSCR.toFixed(2)}x
                  </td>
                ))}
              </tr>

              <tr>
                <td className="p-3 font-semibold text-amber-400">Benefit-Cost Ratio (BCR)</td>
                {results.map((r) => (
                  <td key={r.scenario.id} className="p-3 text-right font-bold text-amber-400">
                    {r.summary.benefitCostRatio.toFixed(2)}x
                  </td>
                ))}
              </tr>

              <tr>
                <td className="p-3 font-semibold text-slate-400">Total 30-Yr Operating Revenue</td>
                {results.map((r) => (
                  <td key={r.scenario.id} className="p-3 text-right">
                    £{r.summary.totalOperatingRevenue.toFixed(1)}M
                  </td>
                ))}
              </tr>

              <tr>
                <td className="p-3 font-semibold text-slate-400">Max Debt Balance</td>
                {results.map((r) => (
                  <td key={r.scenario.id} className="p-3 text-right">
                    £{r.summary.maxDebtOutstanding.toFixed(1)}M
                  </td>
                ))}
              </tr>

            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
