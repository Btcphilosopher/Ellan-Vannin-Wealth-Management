/**
 * Funding Sources & Capital Structure Tab
 * Configures central government grants, local authority contributions, BRS, Green Bonds, and property receipts.
 */

import React from 'react';
import { FundingSource, AnnualFinancialRow } from '../types/finance';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { Coins, Plus, Trash2, CheckCircle, AlertTriangle } from 'lucide-react';

interface FundingTabProps {
  sources: FundingSource[];
  setSources: React.Dispatch<React.SetStateAction<FundingSource[]>>;
  rows: AnnualFinancialRow[];
  totalCapexNominal: number;
  darkMode: boolean;
}

export const FundingTab: React.FC<FundingTabProps> = ({
  sources,
  setSources,
  rows,
  totalCapexNominal,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';
  const inputBg = darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900';

  const handleSourceChange = (id: string, field: keyof FundingSource, val: any) => {
    setSources((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: val } : item))
    );
  };

  const handleAddSource = () => {
    const newSource: FundingSource = {
      id: `fund_${Date.now()}`,
      name: 'New Capital Funding Source',
      category: 'Grant',
      amount: 1000,
      startYear: 2026,
      endYear: 2035,
      seniority: sources.length + 1,
      isGuaranteed: true,
      notes: 'Capital contribution allocation'
    };
    setSources((prev) => [...prev, newSource]);
  };

  const handleDeleteSource = (id: string) => {
    setSources((prev) => prev.filter((item) => item.id !== id));
  };

  const totalFundingAmount = sources.reduce((sum, s) => sum + s.amount, 0);
  const constructionCapex = rows.slice(0, 10).reduce((sum, r) => sum + r.capexNominal, 0);
  const fundingGap = totalFundingAmount - constructionCapex;

  const chartData = rows.slice(0, 10).map((r) => ({
    year: r.calendarYear,
    grants: r.grantsDrawdown,
    local: r.localContribDrawdown,
    bonds: r.bondsDrawdown,
    property: r.propertyDrawdown,
    capex: r.capexNominal
  }));

  return (
    <div className="space-y-6">
      
      {/* Top Banner Card */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Coins className="w-5 h-5 text-amber-500" />
              <h2 className="text-xl font-bold tracking-tight">Funding Sources & Capital Structure</h2>
            </div>
            <p className={`text-xs mt-1 ${textMuted}`}>
              Capital structure allocation across Central Govt grants, Mayoral CIL2, London BRS, UK Infrastructure Bank Green Bonds, and OSD Property receipts.
            </p>
          </div>

          <div className="flex items-center space-x-6 text-sm">
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Construction CapEx</span>
              <span className="font-bold text-lg text-slate-200">£{constructionCapex.toLocaleString(undefined, { maximumFractionDigits: 0 })}M</span>
            </div>
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Total Funding Committed</span>
              <span className="font-bold text-lg text-emerald-400">£{totalFundingAmount.toLocaleString(undefined, { maximumFractionDigits: 0 })}M</span>
            </div>
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Funding Surplus / (Gap)</span>
              <span className={`font-bold text-lg flex items-center space-x-1 ${fundingGap >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {fundingGap >= 0 ? <CheckCircle className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                <span>£{fundingGap.toLocaleString(undefined, { maximumFractionDigits: 0 })}M</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Funding Drawdown vs CapEx Outflow Plot */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-1">Annual Construction Funding Inflows vs CapEx Outflow (£M)</h3>
        <p className={`text-xs ${textMuted} mb-4`}>Compares annual capital inflows from grants, levying, and bonds against construction cash needs.</p>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="year" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} unit="M" />
              <Tooltip contentStyle={{ fontSize: '12px' }} />
              <Legend />
              <Bar dataKey="grants" name="DfT Grants" stackId="a" fill="#2563eb" />
              <Bar dataKey="local" name="Local CIL & BRS" stackId="a" fill="#059669" />
              <Bar dataKey="bonds" name="Green Bonds" stackId="a" fill="#d97706" />
              <Bar dataKey="property" name="Property OSD" stackId="a" fill="#9333ea" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Funding Source Configuration Table */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-base">Capital Funding Sources Specification</h3>
            <p className={`text-xs ${textMuted}`}>Configure capital contributions, drawdown windows, tier seniority, and underwriting guarantees.</p>
          </div>
          <button
            onClick={handleAddSource}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Funding Source</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className={`uppercase border-b font-semibold ${darkMode ? 'border-slate-800 text-slate-400 bg-slate-800/40' : 'border-slate-200 text-slate-600 bg-slate-100'}`}>
              <tr>
                <th className="p-3">Source Name</th>
                <th className="p-3">Category</th>
                <th className="p-3">Total Amount (£M)</th>
                <th className="p-3">Start Year</th>
                <th className="p-3">End Year</th>
                <th className="p-3">Guaranteed</th>
                <th className="p-3">Seniority Tier</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50 font-medium">
              {sources.map((src) => (
                <tr key={src.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="p-3">
                    <input
                      type="text"
                      value={src.name}
                      onChange={(e) => handleSourceChange(src.id, 'name', e.target.value)}
                      className={`w-full px-2 py-1 rounded border text-xs focus:outline-none ${inputBg}`}
                    />
                    <span className="block text-[10px] text-slate-500 mt-0.5">{src.notes}</span>
                  </td>
                  <td className="p-3 w-40">
                    <select
                      value={src.category}
                      onChange={(e) => handleSourceChange(src.id, 'category', e.target.value as any)}
                      className={`w-full px-2 py-1 rounded border text-xs focus:outline-none cursor-pointer ${inputBg}`}
                    >
                      <option value="Grant">Grant</option>
                      <option value="Local Contribution">Local Contribution</option>
                      <option value="BRS">Business Rate Supplement</option>
                      <option value="Bond">Infrastructure Bond</option>
                      <option value="Property / OSD">Property / OSD</option>
                      <option value="Private Equity">Private Equity / PPP</option>
                    </select>
                  </td>
                  <td className="p-3 w-32">
                    <input
                      type="number"
                      value={src.amount}
                      onChange={(e) => handleSourceChange(src.id, 'amount', Number(e.target.value))}
                      className={`w-full px-2 py-1 rounded border text-xs text-right font-bold focus:outline-none ${inputBg}`}
                    />
                  </td>
                  <td className="p-3 w-24">
                    <input
                      type="number"
                      value={src.startYear}
                      onChange={(e) => handleSourceChange(src.id, 'startYear', Number(e.target.value))}
                      className={`w-full px-2 py-1 rounded border text-xs text-center focus:outline-none ${inputBg}`}
                    />
                  </td>
                  <td className="p-3 w-24">
                    <input
                      type="number"
                      value={src.endYear}
                      onChange={(e) => handleSourceChange(src.id, 'endYear', Number(e.target.value))}
                      className={`w-full px-2 py-1 rounded border text-xs text-center focus:outline-none ${inputBg}`}
                    />
                  </td>
                  <td className="p-3 w-24 text-center">
                    <input
                      type="checkbox"
                      checked={src.isGuaranteed}
                      onChange={(e) => handleSourceChange(src.id, 'isGuaranteed', e.target.checked)}
                      className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
                    />
                  </td>
                  <td className="p-3 w-28 text-center font-bold text-amber-400">
                    Tier {src.seniority}
                  </td>
                  <td className="p-3 w-16 text-center">
                    <button
                      onClick={() => handleDeleteSource(src.id)}
                      className="p-1 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors"
                      title="Delete Source"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
