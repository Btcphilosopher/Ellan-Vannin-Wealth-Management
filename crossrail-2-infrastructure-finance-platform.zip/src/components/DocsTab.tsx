/**
 * Institutional Documentation Tab
 * Provides HM Treasury Green Book methodology, assumptions dictionary, model structure, and user guide.
 */

import React, { useState } from 'react';
import { BookOpen, FileText, Code2, HelpCircle, Layers, CheckCircle2 } from 'lucide-react';

interface DocsTabProps {
  darkMode: boolean;
}

export const DocsTab: React.FC<DocsTabProps> = ({ darkMode }) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';

  const [activeSection, setActiveSection] = useState<'methodology' | 'dictionary' | 'r_architecture' | 'user_guide'>('methodology');

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex items-center space-x-2">
          <BookOpen className="w-5 h-5 text-blue-500" />
          <h2 className="text-xl font-bold tracking-tight">Institutional Documentation & Methodology</h2>
        </div>
        <p className={`text-xs mt-1 ${textMuted}`}>
          HM Treasury Green Book valuation standards, DfT Transport Analysis Guidance (TAG), data dictionary, R code architecture, and user guide.
        </p>
      </div>

      {/* Nav Tabs */}
      <div className="flex space-x-2 border-b border-slate-800 pb-2 text-xs font-semibold">
        <button
          onClick={() => setActiveSection('methodology')}
          className={`px-3 py-1.5 rounded-md cursor-pointer ${
            activeSection === 'methodology' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          1. HM Treasury Methodology
        </button>
        <button
          onClick={() => setActiveSection('dictionary')}
          className={`px-3 py-1.5 rounded-md cursor-pointer ${
            activeSection === 'dictionary' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          2. Assumptions Dictionary
        </button>
        <button
          onClick={() => setActiveSection('r_architecture')}
          className={`px-3 py-1.5 rounded-md cursor-pointer ${
            activeSection === 'r_architecture' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          3. Developer & R Architecture
        </button>
        <button
          onClick={() => setActiveSection('user_guide')}
          className={`px-3 py-1.5 rounded-md cursor-pointer ${
            activeSection === 'user_guide' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          4. User Manual & Quick Start
        </button>
      </div>

      {/* Content Sections */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg} text-xs leading-relaxed space-y-4`}>
        
        {activeSection === 'methodology' && (
          <div className="space-y-4">
            <h3 className="text-base font-bold text-blue-400">HM Treasury Green Book Appraisal Methodology</h3>
            <p>
              The Crossrail 2 Infrastructure Finance Platform adheres strictly to <strong>HM Treasury Green Book (2022)</strong> appraisal standards and <strong>Department for Transport (DfT) TAG unit guidance</strong>.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
              <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800 space-y-1">
                <span className="font-bold text-emerald-400 text-xs">Social Discounting Rate (3.5% p.a.)</span>
                <p className="text-slate-400 text-[11px]">
                  Discounting converts future economic costs and passenger fare benefits to Present Value (2026 £). Standard Green Book rate is set at 3.5% for years 1-30, tapering to 3.0% thereafter.
                </p>
              </div>

              <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800 space-y-1">
                <span className="font-bold text-amber-400 text-xs">Benefit-Cost Ratio (BCR Multiplier)</span>
                <p className="text-slate-400 text-[11px]">
                  Combines direct passenger revenues with wider economic impacts (WEIs), journey time savings, decongestion, carbon reduction, and land value uplift.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'dictionary' && (
          <div className="space-y-4">
            <h3 className="text-base font-bold text-blue-400">Assumptions & Variables Data Dictionary</h3>
            <p>
              Comprehensive definition of key financial metrics and variable inputs across CapEx, Debt, and Revenue modules:
            </p>

            <div className="space-y-2">
              <div className="p-3 rounded bg-slate-950/60 border border-slate-800">
                <span className="font-bold text-blue-300">CapEx Nominal (£M):</span> Base unescalated cost multiplied by (1 + Contingency %) escalated annually by BCIS / RPI construction price index.
              </div>
              <div className="p-3 rounded bg-slate-950/60 border border-slate-800">
                <span className="font-bold text-indigo-300">DSCR (Debt Service Coverage Ratio):</span> Calculated as Net Operating Income divided by Annual Total Debt Service (Principal + Interest). Banking covenant limit is &gt;= 1.20x.
              </div>
              <div className="p-3 rounded bg-slate-950/60 border border-slate-800">
                <span className="font-bold text-emerald-300">Mayoral CIL & MCIL2:</span> Dedicated developer levying scheme under the Greater London Authority Act to fund Crossrail 2 station interchanges.
              </div>
            </div>
          </div>
        )}

        {activeSection === 'r_architecture' && (
          <div className="space-y-4">
            <h3 className="text-base font-bold text-blue-400">Developer Architecture & R Software Design</h3>
            <p>
              The platform is architected as an R Shiny application leveraging high-performance <strong>data.table</strong> vectorization and <strong>WebR</strong> WebAssembly compilation:
            </p>

            <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800 space-y-2 font-mono text-[11px]">
              <div>• <strong>shiny & bslib:</strong> Responsive Bootstrap 5 institutional UI layout.</div>
              <div>• <strong>data.table:</strong> High-speed 40-year cash flow matrix calculations in R.</div>
              <div>• <strong>@r-wasm/webr:</strong> WebAssembly R compiler running native R code directly in the client browser.</div>
              <div>• <strong>openxlsx & gt:</strong> Publication-quality financial statements and Excel workbook export.</div>
            </div>
          </div>
        )}

        {activeSection === 'user_guide' && (
          <div className="space-y-4">
            <h3 className="text-base font-bold text-blue-400">User Manual & Quick Start Guide</h3>
            <ol className="list-decimal list-inside space-y-2">
              <li><strong>Select Macro Scenario:</strong> Use the top scenario selector to test Base Case, CapEx Overrun (+25%), or Demand Shock (-20%).</li>
              <li><strong>Adjust CapEx & Debt:</strong> Navigate to CapEx and Debt tabs to modify spending profiles, interest rates, or add custom facilities.</li>
              <li><strong>Run Monte Carlo Risk:</strong> Open Monte Carlo Risk tab and click "Run 1000 Simulations" to generate P10/P50/P90 confidence bounds.</li>
              <li><strong>Export Reports:</strong> Click "Export Reports" in the top bar to download Excel Models or PDF Briefing Packs.</li>
            </ol>
          </div>
        )}

      </div>

    </div>
  );
};
