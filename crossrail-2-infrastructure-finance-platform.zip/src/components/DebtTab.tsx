/**
 * Debt Management & Refinancing Module Tab
 * Controls debt drawdowns, repayment styles (Sculpted, Annuity, Bullet), interest during construction, DSCR & LLCR.
 */

import React from 'react';
import { DebtTranche, AnnualFinancialRow } from '../types/finance';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { Layers, Plus, Trash2, ShieldAlert, Sparkles, Activity } from 'lucide-react';

interface DebtTabProps {
  tranches: DebtTranche[];
  setTranches: React.Dispatch<React.SetStateAction<DebtTranche[]>>;
  rows: AnnualFinancialRow[];
  minDSCR: number;
  maxDebt: number;
  darkMode: boolean;
}

export const DebtTab: React.FC<DebtTabProps> = ({
  tranches,
  setTranches,
  rows,
  minDSCR,
  maxDebt,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';
  const inputBg = darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900';

  const handleTrancheChange = (id: string, field: keyof DebtTranche, val: any) => {
    setTranches((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: val } : item))
    );
  };

  const handleAddTranche = () => {
    const newTranche: DebtTranche = {
      id: `debt_${Date.now()}`,
      name: 'New Senior Debt Facility',
      principal: 1500,
      drawdownStartYear: 2028,
      drawdownEndYear: 2035,
      repaymentStartYear: 2036,
      tenorYears: 25,
      interestRate: 4.50,
      debtType: 'Senior Sculpted',
      marginPercent: 0.90
    };
    setTranches((prev) => [...prev, newTranche]);
  };

  const handleDeleteTranche = (id: string) => {
    setTranches((prev) => prev.filter((item) => item.id !== id));
  };

  const totalPrincipal = tranches.reduce((sum, t) => sum + t.principal, 0);

  const debtChartData = rows.map((r) => ({
    year: r.calendarYear,
    balance: r.debtClosingBalance,
    interest: r.interestExpense,
    principal: r.principalRepayment,
    dscr: r.dscr
  }));

  return (
    <div className="space-y-6">
      
      {/* Top Banner Card */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Layers className="w-5 h-5 text-indigo-500" />
              <h2 className="text-xl font-bold tracking-tight">Debt Management & Refinancing Module</h2>
            </div>
            <p className={`text-xs mt-1 ${textMuted}`}>
              Senior and Subordinated debt facility schedules, Interest During Construction (IDC), Sculpted DSCR repayments, and refinancing models.
            </p>
          </div>

          <div className="flex items-center space-x-6 text-sm">
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Total Debt Principal</span>
              <span className="font-bold text-lg text-indigo-400">£{totalPrincipal.toLocaleString()}M</span>
            </div>
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Peak Debt Outstanding</span>
              <span className="font-bold text-lg text-slate-200">£{maxDebt.toLocaleString(undefined, { maximumFractionDigits: 0 })}M</span>
            </div>
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Min DSCR Ratio</span>
              <span className={`font-bold text-lg flex items-center space-x-1 ${minDSCR >= 1.20 ? 'text-emerald-400' : 'text-rose-400'}`}>
                <Activity className="w-4 h-4" />
                <span>{minDSCR.toFixed(2)}x</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Debt Balance Trajectory & Debt Service Stack */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-1">Debt Amortization & DSCR Trajectory</h3>
        <p className={`text-xs ${textMuted} mb-4`}>Annual principal repayment, interest expense, and DSCR banking covenant tracking (Target &gt;= 1.20x).</p>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={debtChartData} margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="year" tick={{ fontSize: 11 }} />
              <YAxis yAxisId="left" tick={{ fontSize: 11 }} unit="M" />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} domain={[0, 4.0]} />
              <Tooltip contentStyle={{ fontSize: '12px' }} />
              <Legend />
              <Bar yAxisId="left" dataKey="principal" name="Principal Repayment (£M)" fill="#6366f1" stackId="service" />
              <Bar yAxisId="left" dataKey="interest" name="Interest Expense (£M)" fill="#f43f5e" stackId="service" />
              <Line yAxisId="left" type="monotone" dataKey="balance" name="Debt Balance (£M)" stroke="#3b82f6" strokeWidth={3} dot={false} />
              <Line yAxisId="right" type="monotone" dataKey="dscr" name="DSCR Ratio (x)" stroke="#10b981" strokeWidth={2} strokeDasharray="4 4" dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Debt Tranches Configuration Table */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-base">Debt Facilities & Tranche Structure</h3>
            <p className={`text-xs ${textMuted}`}>Specify debt principal, interest rates, margins, repayment styles (Sculpted, Annuity, Straight), and tenors.</p>
          </div>
          <button
            onClick={handleAddTranche}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Debt Tranche</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className={`uppercase border-b font-semibold ${darkMode ? 'border-slate-800 text-slate-400 bg-slate-800/40' : 'border-slate-200 text-slate-600 bg-slate-100'}`}>
              <tr>
                <th className="p-3">Tranche Name</th>
                <th className="p-3">Principal (£M)</th>
                <th className="p-3">Base Rate (%)</th>
                <th className="p-3">Margin (%)</th>
                <th className="p-3">All-In Rate (%)</th>
                <th className="p-3">Drawdown Yrs</th>
                <th className="p-3">Tenor (Yrs)</th>
                <th className="p-3">Repayment Style</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50 font-medium">
              {tranches.map((tr) => {
                const allInRate = tr.interestRate + tr.marginPercent;
                return (
                  <tr key={tr.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="p-3">
                      <input
                        type="text"
                        value={tr.name}
                        onChange={(e) => handleTrancheChange(tr.id, 'name', e.target.value)}
                        className={`w-full px-2 py-1 rounded border text-xs focus:outline-none ${inputBg}`}
                      />
                    </td>
                    <td className="p-3 w-32">
                      <input
                        type="number"
                        value={tr.principal}
                        onChange={(e) => handleTrancheChange(tr.id, 'principal', Number(e.target.value))}
                        className={`w-full px-2 py-1 rounded border text-xs text-right font-bold focus:outline-none ${inputBg}`}
                      />
                    </td>
                    <td className="p-3 w-24">
                      <input
                        type="number"
                        step="0.05"
                        value={tr.interestRate}
                        onChange={(e) => handleTrancheChange(tr.id, 'interestRate', Number(e.target.value))}
                        className={`w-full px-2 py-1 rounded border text-xs text-right focus:outline-none ${inputBg}`}
                      />
                    </td>
                    <td className="p-3 w-24">
                      <input
                        type="number"
                        step="0.05"
                        value={tr.marginPercent}
                        onChange={(e) => handleTrancheChange(tr.id, 'marginPercent', Number(e.target.value))}
                        className={`w-full px-2 py-1 rounded border text-xs text-right focus:outline-none ${inputBg}`}
                      />
                    </td>
                    <td className="p-3 w-28 font-bold text-indigo-400 text-right">
                      {allInRate.toFixed(2)}%
                    </td>
                    <td className="p-3 w-32 text-center text-[11px]">
                      {tr.drawdownStartYear} - {tr.drawdownEndYear}
                    </td>
                    <td className="p-3 w-24">
                      <input
                        type="number"
                        value={tr.tenorYears}
                        onChange={(e) => handleTrancheChange(tr.id, 'tenorYears', Number(e.target.value))}
                        className={`w-full px-2 py-1 rounded border text-xs text-center focus:outline-none ${inputBg}`}
                      />
                    </td>
                    <td className="p-3 w-36">
                      <select
                        value={tr.debtType}
                        onChange={(e) => handleTrancheChange(tr.id, 'debtType', e.target.value as any)}
                        className={`w-full px-2 py-1 rounded border text-xs focus:outline-none cursor-pointer ${inputBg}`}
                      >
                        <option value="Senior Sculpted">Senior Sculpted</option>
                        <option value="Annuity">Annuity</option>
                        <option value="Straight Amortization">Straight Amortization</option>
                        <option value="Bullet">Bullet</option>
                      </select>
                    </td>
                    <td className="p-3 w-16 text-center">
                      <button
                        onClick={() => handleDeleteTranche(tr.id)}
                        className="p-1 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors"
                        title="Delete Facility"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
