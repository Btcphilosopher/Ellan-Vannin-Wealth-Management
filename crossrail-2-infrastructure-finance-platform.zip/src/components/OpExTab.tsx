/**
 * Operating Costs (OpEx) & Maintenance Model Tab
 * Fixed vs. Variable costs, traction power, rolling stock availability lease, and asset renewal.
 */

import React from 'react';
import { OpExCategory, AnnualFinancialRow } from '../types/finance';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { PieChart, Plus, Trash2, Zap, Users, Wrench } from 'lucide-react';

interface OpExTabProps {
  categories: OpExCategory[];
  setCategories: React.Dispatch<React.SetStateAction<OpExCategory[]>>;
  rows: AnnualFinancialRow[];
  darkMode: boolean;
}

export const OpExTab: React.FC<OpExTabProps> = ({
  categories,
  setCategories,
  rows,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';
  const inputBg = darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900';

  const handleCategoryChange = (id: string, field: keyof OpExCategory, val: any) => {
    setCategories((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: val } : item))
    );
  };

  const handleAddCategory = () => {
    const newCat: OpExCategory = {
      id: `opex_${Date.now()}`,
      name: 'New Operating Expense',
      baseAnnualCostM: 50,
      variablePercent: 25,
      annualInflationRate: 2.5,
      description: 'Custom operating cost item'
    };
    setCategories((prev) => [...prev, newCat]);
  };

  const handleDeleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((item) => item.id !== id));
  };

  const totalBaseOpEx = categories.reduce((s, c) => s + c.baseAnnualCostM, 0);
  const opRows = rows.slice(10);
  const totalOpEx30Yrs = opRows.reduce((a, r) => a + r.totalOpEx, 0);

  const chartData = opRows.map((r) => ({
    year: r.calendarYear,
    staff: r.staffOpEx,
    maintenance: r.maintenanceOpEx,
    energy: r.energyOpEx,
    other: r.otherOpEx
  }));

  return (
    <div className="space-y-6">
      
      {/* Top Header Card */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <PieChart className="w-5 h-5 text-rose-500" />
              <h2 className="text-xl font-bold tracking-tight">Operating Costs (OpEx) & Asset Renewal</h2>
            </div>
            <p className={`text-xs mt-1 ${textMuted}`}>
              30-Year operational cost structure incorporating staff, track servicing, 25kV traction power, rolling stock availability leases, and inflation.
            </p>
          </div>

          <div className="flex items-center space-x-6 text-sm">
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Base Annual OpEx</span>
              <span className="font-bold text-lg text-rose-400">£{totalBaseOpEx.toLocaleString()}M / Yr</span>
            </div>
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>30-Yr Escalated Total</span>
              <span className="font-bold text-lg text-slate-200">£{(totalOpEx30Yrs / 1000).toFixed(2)} Billion</span>
            </div>
          </div>
        </div>
      </div>

      {/* OpEx Trajectory Stacked Chart */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-1">Annual Operational Expense Breakdown (£M)</h3>
        <p className={`text-xs ${textMuted} mb-4`}>Annual cost progression across staff, maintenance, traction energy, and fleet leasing.</p>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="year" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} unit="M" />
              <Tooltip contentStyle={{ fontSize: '12px' }} />
              <Legend />
              <Bar dataKey="staff" name="Operations Staff" stackId="a" fill="#3b82f6" />
              <Bar dataKey="maintenance" name="Track Maintenance" stackId="a" fill="#10b981" />
              <Bar dataKey="energy" name="Traction Power" stackId="a" fill="#f59e0b" />
              <Bar dataKey="other" name="Fleet Lease & Admin" stackId="a" fill="#8b5cf6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* OpEx Configuration Table */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-base">Operating Cost Line Items Specification</h3>
            <p className={`text-xs ${textMuted}`}>Configure baseline costs, passenger volume variability ratios, and annual CPI / Wage inflation indices.</p>
          </div>
          <button
            onClick={handleAddCategory}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add OpEx Line Item</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className={`uppercase border-b font-semibold ${darkMode ? 'border-slate-800 text-slate-400 bg-slate-800/40' : 'border-slate-200 text-slate-600 bg-slate-100'}`}>
              <tr>
                <th className="p-3">Cost Category</th>
                <th className="p-3">Base Cost (£M/Yr)</th>
                <th className="p-3">Volume Variable (%)</th>
                <th className="p-3">Fixed Component (%)</th>
                <th className="p-3">Inflation Index (% p.a.)</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50 font-medium">
              {categories.map((cat) => (
                <tr key={cat.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="p-3">
                    <input
                      type="text"
                      value={cat.name}
                      onChange={(e) => handleCategoryChange(cat.id, 'name', e.target.value)}
                      className={`w-full px-2 py-1 rounded border text-xs focus:outline-none ${inputBg}`}
                    />
                    <span className="block text-[10px] text-slate-500 mt-0.5">{cat.description}</span>
                  </td>
                  <td className="p-3 w-32">
                    <input
                      type="number"
                      value={cat.baseAnnualCostM}
                      onChange={(e) => handleCategoryChange(cat.id, 'baseAnnualCostM', Number(e.target.value))}
                      className={`w-full px-2 py-1 rounded border text-xs text-right font-bold focus:outline-none ${inputBg}`}
                    />
                  </td>
                  <td className="p-3 w-28">
                    <input
                      type="number"
                      value={cat.variablePercent}
                      onChange={(e) => handleCategoryChange(cat.id, 'variablePercent', Number(e.target.value))}
                      className={`w-full px-2 py-1 rounded border text-xs text-right focus:outline-none ${inputBg}`}
                    />
                  </td>
                  <td className="p-3 w-28 text-right font-bold text-slate-400">
                    {(100 - cat.variablePercent)}%
                  </td>
                  <td className="p-3 w-28">
                    <input
                      type="number"
                      step="0.1"
                      value={cat.annualInflationRate}
                      onChange={(e) => handleCategoryChange(cat.id, 'annualInflationRate', Number(e.target.value))}
                      className={`w-full px-2 py-1 rounded border text-xs text-right focus:outline-none ${inputBg}`}
                    />
                  </td>
                  <td className="p-3 w-16 text-center">
                    <button
                      onClick={() => handleDeleteCategory(cat.id)}
                      className="p-1 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors"
                      title="Delete Item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
