/**
 * Sensitivity Analysis & Tornado Chart Visualizer
 * Ranks key value drivers (CapEx, Interest Rates, Demand, OpEx, Inflation) by NPV impact.
 */

import React from 'react';
import {
  CapExCategory,
  FundingSource,
  DebtTranche,
  RevenueAssumptions,
  OpExCategory,
  DiscountRateSettings
} from '../types/finance';
import { runSensitivityTornado } from '../lib/financeEngine';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine
} from 'recharts';
import { TrendingUp, BarChart3, HelpCircle } from 'lucide-react';

interface SensitivityTabProps {
  capex: CapExCategory[];
  funding: FundingSource[];
  debt: DebtTranche[];
  revenue: RevenueAssumptions;
  opex: OpExCategory[];
  discount: DiscountRateSettings;
  darkMode: boolean;
}

export const SensitivityTab: React.FC<SensitivityTabProps> = ({
  capex,
  funding,
  debt,
  revenue,
  opex,
  discount,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';

  const tornadoData = runSensitivityTornado(capex, funding, debt, revenue, opex, discount);
  const baseNpv = tornadoData.length > 0 ? tornadoData[0].baseNpv : 0;

  // Format data for Tornado Horizontal Bar Chart
  const chartData = tornadoData.map((item) => ({
    variable: item.variable,
    lowNpv: item.lowNpv,
    highNpv: item.highNpv,
    lowDelta: item.lowNpv - baseNpv,
    highDelta: item.highNpv - baseNpv,
    range: item.deltaNpv
  }));

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex items-center space-x-2">
          <BarChart3 className="w-5 h-5 text-amber-500" />
          <h2 className="text-xl font-bold tracking-tight">Sensitivity Analysis & Tornado Diagram</h2>
        </div>
        <p className={`text-xs mt-1 ${textMuted}`}>
          Single-variable sensitivity ranking assessing NPV impact under +/- 20% independent parameter shocks.
        </p>
      </div>

      {/* Tornado Chart */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-1">Tornado Diagram — Green Book NPV Sensitivity (£M)</h3>
        <p className={`text-xs ${textMuted} mb-4`}>
          Base Case Green Book NPV baseline: <span className="font-bold text-emerald-400">£{baseNpv.toFixed(1)}M</span>
        </p>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              layout="vertical"
              data={chartData}
              margin={{ top: 10, right: 30, left: 140, bottom: 10 }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis type="number" tick={{ fontSize: 11 }} unit="M" />
              <YAxis dataKey="variable" type="category" tick={{ fontSize: 11 }} width={130} />
              <Tooltip contentStyle={{ fontSize: '12px' }} />
              <Legend />
              <ReferenceLine x={baseNpv} stroke="#10b981" strokeWidth={2} label={{ value: 'Base Case NPV', fill: '#10b981', fontSize: 10 }} />
              <Bar dataKey="lowNpv" name="-20% Downside NPV (£M)" fill="#f43f5e" radius={[0, 4, 4, 0]} />
              <Bar dataKey="highNpv" name="+20% Upside NPV (£M)" fill="#3b82f6" radius={[4, 0, 0, 4]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Sensitivity Breakdown Table */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-4">Parameter Value Drivers & Swing Range</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className={`uppercase border-b font-semibold ${darkMode ? 'border-slate-800 text-slate-400 bg-slate-800/40' : 'border-slate-200 text-slate-600 bg-slate-100'}`}>
              <tr>
                <th className="p-3">Rank / Driver</th>
                <th className="p-3">Tested Shock Range</th>
                <th className="p-3 text-right">Downside NPV (£M)</th>
                <th className="p-3 text-right">Base Case NPV (£M)</th>
                <th className="p-3 text-right">Upside NPV (£M)</th>
                <th className="p-3 text-right">Total Swing Range (£M)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50 font-medium">
              {tornadoData.map((item, idx) => (
                <tr key={item.variable} className="hover:bg-slate-800/30 transition-colors">
                  <td className="p-3 font-semibold text-slate-200">
                    #{idx + 1} — {item.variable}
                  </td>
                  <td className="p-3 text-slate-400">
                    +/- 20% Variation
                  </td>
                  <td className="p-3 text-right font-bold text-rose-400">
                    £{item.lowNpv.toFixed(1)}M
                  </td>
                  <td className="p-3 text-right font-bold text-emerald-400">
                    £{item.baseNpv.toFixed(1)}M
                  </td>
                  <td className="p-3 text-right font-bold text-blue-400">
                    £{item.highNpv.toFixed(1)}M
                  </td>
                  <td className="p-3 text-right font-bold text-amber-400">
                    £{item.deltaNpv.toFixed(1)}M
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
