/**
 * Discounted Cash Flow (DCF) & Valuation Model Tab
 * Treasury Green Book Social Discount Rate vs. Commercial WACC, NPV, IRR, BCR, and discounted cash flow waterfall.
 */

import React from 'react';
import { DiscountRateSettings, AnnualFinancialRow, FinancialSummary } from '../types/finance';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { Percent, Award, TrendingUp, DollarSign, Clock, Scale } from 'lucide-react';

interface DcfTabProps {
  discountSettings: DiscountRateSettings;
  setDiscountSettings: React.Dispatch<React.SetStateAction<DiscountRateSettings>>;
  rows: AnnualFinancialRow[];
  summary: FinancialSummary;
  darkMode: boolean;
}

export const DcfTab: React.FC<DcfTabProps> = ({
  discountSettings,
  setDiscountSettings,
  rows,
  summary,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';

  const chartData = rows.map((r) => ({
    year: r.calendarYear,
    fcf: r.freeCashFlowBeforeDebt,
    pvSocial: r.pvFreeCashFlow,
    discountFactor: r.discountFactorSocial
  }));

  return (
    <div className="space-y-6">
      
      {/* Top Banner Card */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Percent className="w-5 h-5 text-emerald-500" />
              <h2 className="text-xl font-bold tracking-tight">Discounted Cash Flow (DCF) & Project Valuation</h2>
            </div>
            <p className={`text-xs mt-1 ${textMuted}`}>
              HM Treasury Green Book social discount rate (3.5% p.a.) & Commercial WACC appraisal framework.
            </p>
          </div>

          <div className="flex items-center space-x-6 text-sm">
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>HM Treasury NPV @ 3.5%</span>
              <span className="font-bold text-lg text-emerald-400">£{(summary.npvSocial / 1000).toFixed(2)} Billion</span>
            </div>
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Commercial NPV @ WACC</span>
              <span className="font-bold text-lg text-blue-400">£{(summary.npvCommercial / 1000).toFixed(2)} Billion</span>
            </div>
            <div>
              <span className={`block text-xs uppercase font-semibold ${textMuted}`}>Benefit-Cost Ratio</span>
              <span className="font-bold text-lg text-amber-400">{summary.benefitCostRatio.toFixed(2)}x</span>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Rate Sliders */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-4">Discount Rate & WACC Calibration</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Social Discount Rate Slider */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-semibold uppercase flex items-center space-x-1.5">
                <Scale className="w-4 h-4 text-emerald-500" />
                <span>HM Treasury Green Book Social Discount Rate</span>
              </label>
              <span className="font-bold text-emerald-400 text-sm">{discountSettings.socialDiscountRate}%</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="7.0"
              step="0.25"
              value={discountSettings.socialDiscountRate}
              onChange={(e) => setDiscountSettings({ ...discountSettings, socialDiscountRate: Number(e.target.value) })}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">
              Official UK government social time preference rate for major public transport infrastructure.
            </p>
          </div>

          {/* Commercial WACC Slider */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-semibold uppercase flex items-center space-x-1.5">
                <Percent className="w-4 h-4 text-blue-500" />
                <span>Commercial Weighted Average Cost of Capital (WACC)</span>
              </label>
              <span className="font-bold text-blue-400 text-sm">{discountSettings.commercialWacc}%</span>
            </div>
            <input
              type="range"
              min="3.0"
              max="12.0"
              step="0.25"
              value={discountSettings.commercialWacc}
              onChange={(e) => setDiscountSettings({ ...discountSettings, commercialWacc: Number(e.target.value) })}
              className="w-full accent-blue-500 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">
              Blended hurdle rate for institutional private debt & equity infrastructure investors.
            </p>
          </div>

        </div>
      </div>

      {/* DCF Waterfall Chart */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-1">Undiscounted Free Cash Flow vs. Discounted Present Value (£M)</h3>
        <p className={`text-xs ${textMuted} mb-4`}>Impact of social time preference discounting over 40-year project horizon.</p>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="year" tick={{ fontSize: 11 }} />
              <YAxis yAxisId="left" tick={{ fontSize: 11 }} unit="M" />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} domain={[0, 1.1]} />
              <Tooltip contentStyle={{ fontSize: '12px' }} />
              <Legend />
              <Bar yAxisId="left" dataKey="fcf" name="Undiscounted Cash Flow (£M)" fill="#64748b" radius={[2, 2, 0, 0]} />
              <Bar yAxisId="left" dataKey="pvSocial" name="Present Value @ 3.5% (£M)" fill="#10b981" radius={[2, 2, 0, 0]} />
              <Line yAxisId="right" type="monotone" dataKey="discountFactor" name="Discount Factor" stroke="#3b82f6" strokeWidth={2} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
};
