/**
 * Sleek Interface - Sidebar & Top Header Navigation Components
 * Provides institutional left sidebar navigation, top header status bar, scenario selector, theme toggle, and export actions.
 */

import React from 'react';
import {
  BarChart3,
  TrendingUp,
  Building2,
  Coins,
  ShieldAlert,
  Terminal,
  FileSpreadsheet,
  CheckCircle2,
  BookOpen,
  Download,
  Sparkles,
  Layers,
  Percent,
  PieChart,
  Cpu,
  Moon,
  Sun,
  Menu,
  X,
  ChevronRight
} from 'lucide-react';
import { isWebRReady } from '../lib/webrEngine';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedScenario: string;
  setSelectedScenario: (scenId: string) => void;
  onExportExcel: () => void;
  onExportPDF: () => void;
  onExportRCode: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export const NAV_ITEMS = [
  { id: 'overview', label: 'Executive Dashboard', icon: BarChart3 },
  { id: 'capex', label: 'Capital Expenditure', icon: Building2 },
  { id: 'funding', label: 'Funding & Financing', icon: Coins },
  { id: 'debt', label: 'Debt Management', icon: Layers },
  { id: 'revenue', label: 'Revenue Forecasts', icon: TrendingUp },
  { id: 'opex', label: 'Operating Costs', icon: PieChart },
  { id: 'dcf', label: 'DCF & Valuation', icon: Percent },
  { id: 'scenarios', label: 'Scenario Matrix', icon: Sparkles },
  { id: 'sensitivity', label: 'Sensitivity Analysis', icon: TrendingUp },
  { id: 'monte_carlo', label: 'Risk (Monte Carlo)', icon: ShieldAlert },
  { id: 'webr', label: 'WebR Studio & Console', icon: Terminal },
  { id: 'import_export', label: 'Import / Export Suite', icon: FileSpreadsheet },
  { id: 'testing', label: 'Audit & Unit Tests', icon: CheckCircle2 },
  { id: 'docs', label: 'Documentation', icon: BookOpen }
];

export const Sidebar: React.FC<{
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}> = ({ activeTab, setActiveTab, isOpen, setIsOpen }) => {
  const webrActive = isWebRReady();

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar Panel */}
      <aside
        className={`fixed lg:static top-0 left-0 bottom-0 z-50 w-64 bg-slate-900 border-r border-slate-800 text-white flex flex-col flex-shrink-0 transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-white text-sm shadow-md shadow-indigo-500/20">
              CR2
            </div>
            <div>
              <div className="font-extrabold text-base tracking-tight text-white flex items-center gap-1">
                CROSSRAIL <span className="text-indigo-500 font-black">2</span>
              </div>
              <span className="text-[10px] text-slate-400 font-medium block">
                R-Engine v2.4.1 (Posit WebR)
              </span>
            </div>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="lg:hidden text-slate-400 hover:text-white p-1 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto scrollbar-thin">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
            Financial Modules
          </div>
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                  isActive
                    ? 'bg-slate-800/90 text-white border-l-4 border-indigo-500 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/40 border-l-4 border-transparent'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {isActive && <ChevronRight className="w-3.5 h-3.5 text-indigo-400" />}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-950/40">
          <div className="flex items-center space-x-2 text-xs text-emerald-400">
            <Cpu className="w-4 h-4 animate-pulse" />
            <span className="font-semibold text-[11px]">
              {webrActive ? 'WebR Engine Active' : 'WebR Engine Ready'}
            </span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">
            HM Treasury Green Book & DfT TAG
          </p>
        </div>
      </aside>
    </>
  );
};

export const Header: React.FC<NavigationProps & { onToggleSidebar: () => void }> = ({
  activeTab,
  selectedScenario,
  setSelectedScenario,
  onExportExcel,
  onExportPDF,
  onExportRCode,
  darkMode,
  setDarkMode,
  onToggleSidebar
}) => {
  const currentNav = NAV_ITEMS.find((n) => n.id === activeTab) || NAV_ITEMS[0];

  return (
    <header className={`h-16 border-b sticky top-0 z-30 transition-colors flex items-center justify-between px-4 sm:px-6 ${
      darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
    }`}>
      {/* Left: Mobile Toggle & Header Title */}
      <div className="flex items-center space-x-3">
        <button
          onClick={onToggleSidebar}
          className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h1 className="text-base sm:text-lg font-bold tracking-tight flex items-center gap-2">
            {currentNav.label}
          </h1>
          <p className="text-xs text-slate-400 hidden sm:block">
            Scenario: <span className="text-indigo-500 font-semibold">{selectedScenario === 'scen_base' ? 'Base Case 2026 (SOBC Baseline)' : selectedScenario}</span>
          </p>
        </div>
      </div>

      {/* Right: Actions & Controls */}
      <div className="flex items-center space-x-3 text-xs">
        
        {/* Discount Rate Badge */}
        <div className={`hidden md:flex items-center px-3 py-1.5 rounded-lg border text-xs font-medium ${
          darkMode ? 'bg-slate-800/80 border-slate-700 text-slate-300' : 'bg-slate-100 border-slate-200 text-slate-700'
        }`}>
          <span className="text-slate-400 mr-1.5">Discount Rate:</span>
          <span className="font-bold text-emerald-500">3.5% Social</span>
        </div>

        {/* Scenario Quick Selector */}
        <div className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border text-xs ${
          darkMode ? 'bg-slate-800/90 border-slate-700 text-white' : 'bg-slate-100 border-slate-200 text-slate-900'
        }`}>
          <span className="text-slate-400 font-medium hidden sm:inline">Scenario:</span>
          <select
            value={selectedScenario}
            onChange={(e) => setSelectedScenario(e.target.value)}
            className="bg-transparent font-semibold focus:outline-none cursor-pointer"
          >
            <option value="scen_base" className={darkMode ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'}>Base Case (SOBC)</option>
            <option value="scen_cost_overrun" className={darkMode ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'}>CapEx Overrun (+25%)</option>
            <option value="scen_demand_shock" className={darkMode ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'}>Demand Shock (-20%)</option>
            <option value="scen_high_inflation" className={darkMode ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'}>High Inflation & Rates</option>
            <option value="scen_green_optimized" className={darkMode ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'}>Green Finance Optimised</option>
          </select>
        </div>

        {/* Theme Toggle */}
        <button
          onClick={() => setDarkMode(!darkMode)}
          className={`p-2 rounded-lg border transition-colors cursor-pointer ${
            darkMode ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300' : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
          }`}
          title="Toggle Theme"
        >
          {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
        </button>

        {/* Primary Export Button */}
        <div className="relative group">
          <button className="flex items-center space-x-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-3.5 py-2 rounded-lg shadow-sm transition-all cursor-pointer">
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export Report</span>
          </button>
          <div className={`absolute right-0 mt-1 w-48 border rounded-lg shadow-xl py-1 hidden group-hover:block z-50 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}>
            <button
              onClick={onExportExcel}
              className={`w-full text-left px-3 py-2 text-xs flex items-center space-x-2 ${
                darkMode ? 'text-slate-200 hover:bg-slate-800' : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-500" />
              <span>Excel Model (.xlsx)</span>
            </button>
            <button
              onClick={onExportPDF}
              className={`w-full text-left px-3 py-2 text-xs flex items-center space-x-2 ${
                darkMode ? 'text-slate-200 hover:bg-slate-800' : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Download className="w-3.5 h-3.5 text-indigo-500" />
              <span>PDF Executive Briefing</span>
            </button>
            <button
              onClick={onExportRCode}
              className={`w-full text-left px-3 py-2 text-xs flex items-center space-x-2 border-t ${
                darkMode ? 'text-slate-200 hover:bg-slate-800 border-slate-800' : 'text-slate-700 hover:bg-slate-100 border-slate-100'
              }`}
            >
              <Terminal className="w-3.5 h-3.5 text-indigo-400" />
              <span>Download R Code (app.R)</span>
            </button>
          </div>
        </div>

      </div>
    </header>
  );
};

