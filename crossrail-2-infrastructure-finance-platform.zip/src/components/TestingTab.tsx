/**
 * Automated Financial Unit Testing & Validation Suite
 * Runs financial accounting audit checks, DSCR covenant tests, and DCF convergence checks.
 */

import React from 'react';
import { AnnualFinancialRow, FinancialSummary } from '../types/finance';
import { runFinancialUnitTests } from '../lib/financeEngine';
import { CheckCircle2, AlertTriangle, XCircle, ShieldCheck, Cpu } from 'lucide-react';

interface TestingTabProps {
  rows: AnnualFinancialRow[];
  summary: FinancialSummary;
  darkMode: boolean;
}

export const TestingTab: React.FC<TestingTabProps> = ({
  rows,
  summary,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';

  const testResults = runFinancialUnitTests(rows, summary);
  const passCount = testResults.filter((t) => t.status === 'PASS').length;
  const totalCount = testResults.length;

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              <h2 className="text-xl font-bold tracking-tight">Automated Financial Unit Testing & Audit Suite</h2>
            </div>
            <p className={`text-xs mt-1 ${textMuted}`}>
              Automated financial accounting integrity checks, banking covenant rules, debt payoff verification, and DCF mathematical convergence checks.
            </p>
          </div>

          <div className="flex items-center space-x-3 bg-emerald-950/60 border border-emerald-800 px-4 py-2 rounded-xl text-emerald-300">
            <ShieldCheck className="w-5 h-5" />
            <div>
              <span className="block font-bold text-sm">{passCount} / {totalCount} Tests Passed</span>
              <span className="block text-[10px] text-emerald-400">Financial Integrity Verified</span>
            </div>
          </div>
        </div>
      </div>

      {/* Test Results Table */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-4">Financial Audit & Sanity Validation Log</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className={`uppercase border-b font-semibold ${darkMode ? 'border-slate-800 text-slate-400 bg-slate-800/40' : 'border-slate-200 text-slate-600 bg-slate-100'}`}>
              <tr>
                <th className="p-3">Status</th>
                <th className="p-3">Audit Test Name</th>
                <th className="p-3">Category</th>
                <th className="p-3">Model Result</th>
                <th className="p-3">Benchmark Threshold</th>
                <th className="p-3">Audit Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50 font-medium">
              {testResults.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="p-3 w-28 font-bold">
                    {t.status === 'PASS' && (
                      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>PASS</span>
                      </span>
                    )}
                    {t.status === 'WARNING' && (
                      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>WARN</span>
                      </span>
                    )}
                    {t.status === 'FAIL' && (
                      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded bg-rose-950 text-rose-400 border border-rose-800">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>FAIL</span>
                      </span>
                    )}
                  </td>
                  <td className="p-3 font-semibold text-slate-200">{t.name}</td>
                  <td className="p-3 text-slate-400">{t.category}</td>
                  <td className="p-3 font-bold text-blue-400">{t.metricValue}</td>
                  <td className="p-3 text-slate-400">{t.threshold}</td>
                  <td className="p-3 text-slate-300">{t.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
