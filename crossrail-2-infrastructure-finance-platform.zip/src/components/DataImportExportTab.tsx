/**
 * Data Import & Export Suite Tab
 * Handles CSV, Excel, DuckDB, Parquet imports and generates Excel, PDF, JSON, CSV, and R script exports.
 */

import React, { useState } from 'react';
import { AnnualFinancialRow, FinancialSummary } from '../types/finance';
import { exportToExcel, exportToPDF, downloadRCodeBundle } from '../lib/exportUtils';
import {
  FileSpreadsheet,
  Download,
  Upload,
  Database,
  FileCode,
  CheckCircle,
  HardDrive
} from 'lucide-react';
import * as XLSX from 'xlsx';

interface DataImportExportTabProps {
  rows: AnnualFinancialRow[];
  summary: FinancialSummary;
  darkMode: boolean;
}

export const DataImportExportTab: React.FC<DataImportExportTabProps> = ({
  rows,
  summary,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';

  const [importStatus, setImportStatus] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const sheetName = wb.SheetNames[0];
        const data = XLSX.utils.sheet_to_json(wb.Sheets[sheetName]);
        setImportStatus(`Successfully ingested ${data.length} records from ${file.name}`);
      } catch (err: any) {
        setImportStatus(`Import Error: ${err.message}`);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleDownloadCSV = () => {
    const headers = [
      'Year',
      'CalYear',
      'Phase',
      'CapExNominal',
      'TotalFunding',
      'RidershipM',
      'TotalRevenue',
      'TotalOpEx',
      'NOI',
      'DebtService',
      'DebtBalance',
      'FCFEquity',
      'DSCR'
    ];
    const csvContent = [
      headers.join(','),
      ...rows.map((r) =>
        [
          r.year,
          r.calendarYear,
          r.phase,
          r.capexNominal.toFixed(2),
          r.totalFundingInflow.toFixed(2),
          r.ridershipM.toFixed(2),
          r.totalRevenue.toFixed(2),
          r.totalOpEx.toFixed(2),
          r.netOperatingIncome.toFixed(2),
          r.totalDebtService.toFixed(2),
          r.debtClosingBalance.toFixed(2),
          r.freeCashFlowToEquity.toFixed(2),
          r.dscr.toFixed(2)
        ].join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Crossrail2_Financial_Statements.csv';
    link.click();
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex items-center space-x-2">
          <FileSpreadsheet className="w-5 h-5 text-emerald-500" />
          <h2 className="text-xl font-bold tracking-tight">Data Import & Reporting Export Suite</h2>
        </div>
        <p className={`text-xs mt-1 ${textMuted}`}>
          Ingest raw financial assumptions via CSV, Excel, DuckDB, or Parquet. Export publication-quality briefing packs, Excel models, and R code.
        </p>
      </div>

      {/* Import Section */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-2">Ingest External Data & Assumptions</h3>
        <p className={`text-xs ${textMuted} mb-4`}>
          Upload custom CapEx profiles, debt schedules, or ridership matrices in CSV, Excel, or DuckDB format.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="border-2 border-dashed border-slate-700 rounded-xl p-6 text-center hover:border-blue-500 transition-colors cursor-pointer">
            <Upload className="w-8 h-8 mx-auto text-blue-500 mb-2" />
            <span className="block font-bold text-xs">Upload Excel (.xlsx) or CSV</span>
            <span className="text-[11px] text-slate-500">Drag and drop or browse files</span>
            <input
              type="file"
              accept=".csv, .xlsx, .xls"
              onChange={handleFileUpload}
              className="mt-3 block w-full text-xs text-slate-400 file:mr-4 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-500 cursor-pointer"
            />
          </div>

          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3 text-xs">
            <div className="flex items-center space-x-2 text-slate-300 font-bold">
              <Database className="w-4 h-4 text-purple-400" />
              <span>DuckDB & Parquet Query Integration</span>
            </div>
            <p className="text-slate-400 text-[11px]">
              Direct connection to high-performance columnar DuckDB / Parquet datastores for multi-gigabyte transport elasticity queries.
            </p>
            {importStatus && (
              <div className="p-2.5 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-[11px]">
                {importStatus}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Export Section */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-4">Export Financial Reports & Models</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <button
            onClick={() => exportToExcel(rows, summary)}
            className="p-4 rounded-xl border border-emerald-800/60 bg-emerald-950/30 hover:bg-emerald-900/40 text-left transition-colors cursor-pointer space-y-2"
          >
            <FileSpreadsheet className="w-6 h-6 text-emerald-400" />
            <span className="block font-bold text-sm text-emerald-200">Excel Financial Model</span>
            <span className="block text-xs text-slate-400">Multi-tab workbook with formula statements</span>
          </button>

          <button
            onClick={() => exportToPDF(rows, summary)}
            className="p-4 rounded-xl border border-rose-800/60 bg-rose-950/30 hover:bg-rose-900/40 text-left transition-colors cursor-pointer space-y-2"
          >
            <Download className="w-6 h-6 text-rose-400" />
            <span className="block font-bold text-sm text-rose-200">PDF Briefing Pack</span>
            <span className="block text-xs text-slate-400">Executive summary report with audit status</span>
          </button>

          <button
            onClick={downloadRCodeBundle}
            className="p-4 rounded-xl border border-blue-800/60 bg-blue-950/30 hover:bg-blue-900/40 text-left transition-colors cursor-pointer space-y-2"
          >
            <FileCode className="w-6 h-6 text-blue-400" />
            <span className="block font-bold text-sm text-blue-200">R Project Code (app.R)</span>
            <span className="block text-xs text-slate-400">Shiny & data.table source code file</span>
          </button>

          <button
            onClick={handleDownloadCSV}
            className="p-4 rounded-xl border border-amber-800/60 bg-amber-950/30 hover:bg-amber-900/40 text-left transition-colors cursor-pointer space-y-2"
          >
            <HardDrive className="w-6 h-6 text-amber-400" />
            <span className="block font-bold text-sm text-amber-200">Raw CSV Statement</span>
            <span className="block text-xs text-slate-400">40-Year flat CSV data statement</span>
          </button>

        </div>
      </div>

    </div>
  );
};
