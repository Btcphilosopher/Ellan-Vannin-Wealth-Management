/**
 * Monte Carlo Risk Simulation Tab (Stochastic Analysis)
 * Runs 1,000 stochastic iterations over CapEx, Demand, and Interest Rates to produce P10/P50/P90 confidence bounds.
 */

import React, { useState } from 'react';
import {
  CapExCategory,
  FundingSource,
  DebtTranche,
  RevenueAssumptions,
  OpExCategory,
  DiscountRateSettings,
  MonteCarloConfig,
  MonteCarloResult
} from '../types/finance';
import { runMonteCarloSimulation } from '../lib/financeEngine';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine
} from 'recharts';
import { ShieldAlert, Play, RotateCcw, Activity, CheckCircle, Percent } from 'lucide-react';

interface MonteCarloTabProps {
  capex: CapExCategory[];
  funding: FundingSource[];
  debt: DebtTranche[];
  revenue: RevenueAssumptions;
  opex: OpExCategory[];
  discount: DiscountRateSettings;
  config: MonteCarloConfig;
  setConfig: React.Dispatch<React.SetStateAction<MonteCarloConfig>>;
  darkMode: boolean;
}

export const MonteCarloTab: React.FC<MonteCarloTabProps> = ({
  capex,
  funding,
  debt,
  revenue,
  opex,
  discount,
  config,
  setConfig,
  darkMode
}) => {
  const cardBg = darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900';
  const textMuted = darkMode ? 'text-slate-400' : 'text-slate-500';
  const inputBg = darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900';

  const [mcResult, setMcResult] = useState<MonteCarloResult>(() =>
    runMonteCarloSimulation(capex, funding, debt, revenue, opex, discount, config)
  );

  const handleRunSimulation = () => {
    const res = runMonteCarloSimulation(capex, funding, debt, revenue, opex, discount, config);
    setMcResult(res);
  };

  // Build Histogram Bins for NPV Density Distribution
  const buildHistogram = () => {
    const npvs = mcResult.simulations.map((s) => s.npv);
    const min = Math.min(...npvs);
    const max = Math.max(...npvs);
    const numBins = 25;
    const binWidth = (max - min) / numBins;

    const bins = new Array(numBins).fill(0).map((_, i) => ({
      binStart: Math.round(min + i * binWidth),
      binEnd: Math.round(min + (i + 1) * binWidth),
      label: `${Math.round((min + i * binWidth) / 1000)}B`,
      count: 0
    }));

    npvs.forEach((npv) => {
      let idx = Math.floor((npv - min) / binWidth);
      if (idx >= numBins) idx = numBins - 1;
      if (idx < 0) idx = 0;
      bins[idx].count++;
    });

    return bins;
  };

  const histogramData = buildHistogram();

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <ShieldAlert className="w-5 h-5 text-rose-500" />
              <h2 className="text-xl font-bold tracking-tight">Monte Carlo Risk Simulation Engine</h2>
            </div>
            <p className={`text-xs mt-1 ${textMuted}`}>
              Stochastic quantitative evaluation running {mcResult.iterations.toLocaleString()} iterations over CapEx variance, passenger demand volatility, and debt interest rates.
            </p>
          </div>

          <button
            onClick={handleRunSimulation}
            className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md transition-colors cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Run {config.iterations} Simulations</span>
          </button>
        </div>
      </div>

      {/* KPI Value Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className={`p-4 rounded-xl border shadow-sm ${cardBg}`}>
          <span className={`text-xs font-semibold uppercase ${textMuted}`}>P10 Optimistic NPV</span>
          <div className="text-xl font-bold text-emerald-400 mt-1">£{(mcResult.npvP90 / 1000).toFixed(2)}B</div>
          <span className="text-xs text-slate-500">10% probability of exceeding</span>
        </div>

        <div className={`p-4 rounded-xl border shadow-sm ${cardBg}`}>
          <span className={`text-xs font-semibold uppercase ${textMuted}`}>P50 Expected Median NPV</span>
          <div className="text-xl font-bold text-blue-400 mt-1">£{(mcResult.npvP50 / 1000).toFixed(2)}B</div>
          <span className="text-xs text-slate-500">Expected median baseline</span>
        </div>

        <div className={`p-4 rounded-xl border shadow-sm ${cardBg}`}>
          <span className={`text-xs font-semibold uppercase ${textMuted}`}>P90 Risk Downside NPV</span>
          <div className="text-xl font-bold text-rose-400 mt-1">£{(mcResult.npvP10 / 1000).toFixed(2)}B</div>
          <span className="text-xs text-slate-500">90% confidence lower bound</span>
        </div>

        <div className={`p-4 rounded-xl border shadow-sm ${cardBg}`}>
          <span className={`text-xs font-semibold uppercase ${textMuted}`}>Positive NPV Probability</span>
          <div className="text-xl font-bold text-amber-400 mt-1">{mcResult.probabilityPositiveNpv.toFixed(1)}%</div>
          <span className="text-xs text-slate-500">Confidence of positive Green Book value</span>
        </div>

      </div>

      {/* Probability Density Distribution Chart */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-1">Stochastic Distribution of Green Book NPV (£ Millions)</h3>
        <p className={`text-xs ${textMuted} mb-4`}>Probability density function histogram over {mcResult.iterations} simulation runs.</p>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={histogramData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="label" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ fontSize: '12px' }} />
              <ReferenceLine x={`${Math.round(mcResult.npvP50 / 1000)}B`} stroke="#3b82f6" strokeWidth={2} label={{ value: 'P50 Median', fill: '#3b82f6', fontSize: 10 }} />
              <Bar dataKey="count" name="Frequency" fill="#e11d48" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Stochastic Controls Table */}
      <div className={`p-6 rounded-xl border shadow-sm ${cardBg}`}>
        <h3 className="font-bold text-base mb-4">Monte Carlo Simulation Volatility Parameters</h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              Iterations Count
            </label>
            <input
              type="number"
              value={config.iterations}
              onChange={(e) => setConfig({ ...config, iterations: Number(e.target.value) })}
              className={`w-full px-3 py-1.5 rounded border text-xs font-bold focus:outline-none ${inputBg}`}
            />
          </div>

          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              CapEx Volatility (Std Dev %)
            </label>
            <input
              type="number"
              step="0.5"
              value={config.capexStdDev}
              onChange={(e) => setConfig({ ...config, capexStdDev: Number(e.target.value) })}
              className={`w-full px-3 py-1.5 rounded border text-xs font-bold focus:outline-none ${inputBg}`}
            />
          </div>

          <div>
            <label className={`block text-xs font-semibold uppercase mb-1 ${textMuted}`}>
              Passenger Demand Volatility (Std Dev %)
            </label>
            <input
              type="number"
              step="0.5"
              value={config.demandStdDev}
              onChange={(e) => setConfig({ ...config, demandStdDev: Number(e.target.value) })}
              className={`w-full px-3 py-1.5 rounded border text-xs font-bold focus:outline-none ${inputBg}`}
            />
          </div>
        </div>
      </div>

    </div>
  );
};
