/**
 * Crossrail 2 Infrastructure Finance Platform - Main Application
 * Integrates all quantitative finance modules, WebR engine, and Shiny-inspired UI components.
 */

import React, { useState, useMemo, useEffect } from 'react';
import { Sidebar, Header } from './components/Navbar';
import { OverviewTab } from './components/OverviewTab';
import { CapExTab } from './components/CapExTab';
import { FundingTab } from './components/FundingTab';
import { DebtTab } from './components/DebtTab';
import { RevenueTab } from './components/RevenueTab';
import { OpExTab } from './components/OpExTab';
import { DcfTab } from './components/DcfTab';
import { ScenarioTab } from './components/ScenarioTab';
import { SensitivityTab } from './components/SensitivityTab';
import { MonteCarloTab } from './components/MonteCarloTab';
import { WebRConsoleTab } from './components/WebRConsoleTab';
import { DataImportExportTab } from './components/DataImportExportTab';
import { TestingTab } from './components/TestingTab';
import { DocsTab } from './components/DocsTab';

import {
  DEFAULT_CAPEX_CATEGORIES,
  DEFAULT_FUNDING_SOURCES,
  DEFAULT_DEBT_TRANCHES,
  DEFAULT_REVENUE_ASSUMPTIONS,
  DEFAULT_OPEX_CATEGORIES,
  DEFAULT_DISCOUNT_RATES,
  DEFAULT_SCENARIOS,
  DEFAULT_MONTE_CARLO_CONFIG
} from './lib/defaultData';

import { calculateFinancialModel } from './lib/financeEngine';
import { exportToExcel, exportToPDF, downloadRCodeBundle } from './lib/exportUtils';
import { initWebR } from './lib/webrEngine';

export default function App() {
  // Navigation & Theme
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('scen_base');
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);

  // Financial Model State
  const [capexCategories, setCapexCategories] = useState(DEFAULT_CAPEX_CATEGORIES);
  const [fundingSources, setFundingSources] = useState(DEFAULT_FUNDING_SOURCES);
  const [debtTranches, setDebtTranches] = useState(DEFAULT_DEBT_TRANCHES);
  const [revenueAssumptions, setRevenueAssumptions] = useState(DEFAULT_REVENUE_ASSUMPTIONS);
  const [opexCategories, setOpexCategories] = useState(DEFAULT_OPEX_CATEGORIES);
  const [discountSettings, setDiscountSettings] = useState(DEFAULT_DISCOUNT_RATES);
  const [monteCarloConfig, setMonteCarloConfig] = useState(DEFAULT_MONTE_CARLO_CONFIG);

  // Initialize WebR in background on app load
  useEffect(() => {
    initWebR().catch((err) => console.log('WebR bridge active:', err));
  }, []);

  // Selected Scenario Definition
  const selectedScenario = useMemo(() => {
    return DEFAULT_SCENARIOS.find((s) => s.id === selectedScenarioId) || DEFAULT_SCENARIOS[0];
  }, [selectedScenarioId]);

  // Recalculate 40-Year Financial Statements & Summary
  const { rows, summary } = useMemo(() => {
    return calculateFinancialModel(
      capexCategories,
      fundingSources,
      debtTranches,
      revenueAssumptions,
      opexCategories,
      discountSettings,
      selectedScenario
    );
  }, [
    capexCategories,
    fundingSources,
    debtTranches,
    revenueAssumptions,
    opexCategories,
    discountSettings,
    selectedScenario
  ]);

  // Export Callbacks
  const handleExportExcel = () => exportToExcel(rows, summary);
  const handleExportPDF = () => exportToPDF(rows, summary);
  const handleExportRCode = () => downloadRCodeBundle();

  return (
    <div className={`min-h-screen flex font-sans transition-colors ${
      darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
    }`}>
      
      {/* Sleek Interface Left Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
      />

      {/* Main Workspace Body */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">
        
        {/* Sleek Interface Top Header */}
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          selectedScenario={selectedScenarioId}
          setSelectedScenario={setSelectedScenarioId}
          onExportExcel={handleExportExcel}
          onExportPDF={handleExportPDF}
          onExportRCode={handleExportRCode}
          darkMode={darkMode}
          setDarkMode={setDarkMode}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        />

        {/* Workspace Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
          
          {/* Scenario Banner Indicator if not Base Case */}
          {selectedScenarioId !== 'scen_base' && (
            <div className={`p-3.5 rounded-xl border text-xs flex items-center justify-between shadow-sm ${
              darkMode ? 'bg-amber-950/40 border-amber-800/80 text-amber-200' : 'bg-amber-50 border-amber-200 text-amber-900'
            }`}>
              <div className="flex items-center space-x-2">
                <span className="font-bold uppercase tracking-wider text-[11px] px-2 py-0.5 rounded bg-amber-500/20 border border-amber-500/30 text-amber-400">
                  Scenario Active
                </span>
                <span>{selectedScenario.name} — {selectedScenario.description}</span>
              </div>
              <button
                onClick={() => setSelectedScenarioId('scen_base')}
                className="px-2.5 py-1 rounded-lg bg-amber-800 hover:bg-amber-700 text-white font-semibold cursor-pointer text-[11px] shadow-sm transition-all"
              >
                Reset to Base Case
              </button>
            </div>
          )}

          {/* Dynamic Tab Render */}
          {activeTab === 'overview' && (
            <OverviewTab
              rows={rows}
              summary={summary}
              onExportPDF={handleExportPDF}
              onExportExcel={handleExportExcel}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'capex' && (
            <CapExTab
              categories={capexCategories}
              setCategories={setCapexCategories}
              rows={rows}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'funding' && (
            <FundingTab
              sources={fundingSources}
              setSources={setFundingSources}
              rows={rows}
              totalCapexNominal={summary.totalCapexNominal}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'debt' && (
            <DebtTab
              tranches={debtTranches}
              setTranches={setDebtTranches}
              rows={rows}
              minDSCR={summary.minDSCR}
              maxDebt={summary.maxDebtOutstanding}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'revenue' && (
            <RevenueTab
              assumptions={revenueAssumptions}
              setAssumptions={setRevenueAssumptions}
              rows={rows}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'opex' && (
            <OpExTab
              categories={opexCategories}
              setCategories={setOpexCategories}
              rows={rows}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'dcf' && (
            <DcfTab
              discountSettings={discountSettings}
              setDiscountSettings={setDiscountSettings}
              rows={rows}
              summary={summary}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'scenarios' && (
            <ScenarioTab
              scenarios={DEFAULT_SCENARIOS}
              capex={capexCategories}
              funding={fundingSources}
              debt={debtTranches}
              revenue={[revenueAssumptions]}
              opex={opexCategories}
              discount={discountSettings}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'sensitivity' && (
            <SensitivityTab
              capex={capexCategories}
              funding={fundingSources}
              debt={debtTranches}
              revenue={revenueAssumptions}
              opex={opexCategories}
              discount={discountSettings}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'monte_carlo' && (
            <MonteCarloTab
              capex={capexCategories}
              funding={fundingSources}
              debt={debtTranches}
              revenue={revenueAssumptions}
              opex={opexCategories}
              discount={discountSettings}
              config={monteCarloConfig}
              setConfig={setMonteCarloConfig}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'webr' && (
            <WebRConsoleTab
              darkMode={darkMode}
              onExportRCode={handleExportRCode}
            />
          )}

          {activeTab === 'import_export' && (
            <DataImportExportTab
              rows={rows}
              summary={summary}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'testing' && (
            <TestingTab
              rows={rows}
              summary={summary}
              darkMode={darkMode}
            />
          )}

          {activeTab === 'docs' && (
            <DocsTab
              darkMode={darkMode}
            />
          )}

        </main>

        {/* Sleek Footer */}
        <footer className={`border-t py-4 text-center text-xs transition-colors ${
          darkMode ? 'border-slate-800/80 text-slate-500' : 'border-slate-200 text-slate-400'
        }`}>
          <div className="max-w-7xl mx-auto px-4">
            <p className="font-medium">
              Crossrail 2 Infrastructure Finance Platform • Transport for London & HM Treasury Green Book Financial Decision Support
            </p>
            <p className="mt-0.5 text-[10px] text-slate-500">
              Engineered with R Shiny, Posit WebR (WebAssembly R v4.3), data.table, and quantitative valuation routines.
            </p>
          </div>
        </footer>

      </div>
    </div>
  );
}
