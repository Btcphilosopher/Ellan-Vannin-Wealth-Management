/**
 * Crossrail 2 Infrastructure Finance Platform - Types Definition
 */

export interface CapExCategory {
  id: string;
  name: string;
  baseCost: number; // in £ Millions
  contingencyPercent: number; // %
  spendProfile: 'S-Curve' | 'Linear' | 'Front-Loaded' | 'Rear-Loaded';
  inflationRate: number; // % per annum
  description: string;
}

export interface FundingSource {
  id: string;
  name: string;
  category: 'Grant' | 'Local Contribution' | 'Bond' | 'Private Equity' | 'Property / OSD' | 'BRS';
  amount: number; // £ Millions
  startYear: number;
  endYear: number;
  seniority: number; // Order of utilization
  isGuaranteed: boolean;
  notes: string;
}

export interface DebtTranche {
  id: string;
  name: string;
  principal: number; // £ Millions
  drawdownStartYear: number;
  drawdownEndYear: number;
  repaymentStartYear: number;
  tenorYears: number;
  interestRate: number; // %
  debtType: 'Senior Sculpted' | 'Annuity' | 'Bullet' | 'Straight Amortization';
  refinancingYear?: number;
  refinancedInterestRate?: number;
  marginPercent: number;
}

export interface RevenueAssumptions {
  initialRidershipM: number; // Million journeys per year
  rampUpYears: number; // Years 1 to N ramp up
  baseYieldPerJourney: number; // £ per journey
  fareEscalationOverRPI: number; // % (RPI + X)
  organicDemandGrowth: number; // % annual population/GDP growth
  commercialIncomeM: number; // Retail & Advertising £M / yr
  propertyDevelopmentIncomeM: number; // Over-Station Development £M / yr
  demandScenario: 'Base Case' | 'High Growth' | 'Post-Pandemic Hybrid' | 'Recession Shock';
}

export interface OpExCategory {
  id: string;
  name: string;
  baseAnnualCostM: number; // £ Millions
  variablePercent: number; // % cost linked to passenger volume
  annualInflationRate: number; // %
  description: string;
}

export interface DiscountRateSettings {
  socialDiscountRate: number; // % (HM Treasury Green Book: 3.5%)
  commercialWacc: number; // % (e.g., 6.5%)
  appraisalPeriodYears: number; // Construction + Operating years (e.g. 40 years)
  startYear: number; // e.g. 2026
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  capexMultiplier: number; // e.g. 1.25 for +25% cost overrun
  demandMultiplier: number; // e.g. 0.85 for -15% ridership
  interestRateAdd: number; // e.g. +0.015 for +150 bps
  opexMultiplier: number; // e.g. 1.10 for +10% opex
  inflationAdd: number; // e.g. +0.01
}

export interface MonteCarloConfig {
  iterations: number; // e.g., 1000
  capexStdDev: number; // % variation (e.g., 15%)
  demandStdDev: number; // % variation (e.g., 12%)
  interestRateStdDev: number; // % points (e.g., 1.0%)
  seed: number;
}

export interface AnnualFinancialRow {
  year: number;
  calendarYear: number;
  phase: 'Construction' | 'Operation';
  
  // CapEx
  capexNominal: number;
  capexReal: number;
  capexCumulative: number;
  
  // Funding Drawdowns
  grantsDrawdown: number;
  localContribDrawdown: number;
  bondsDrawdown: number;
  equityDrawdown: number;
  propertyDrawdown: number;
  totalFundingInflow: number;
  
  // Revenue
  ridershipM: number;
  passengerRevenue: number;
  commercialRevenue: number;
  propertyRevenue: number;
  totalRevenue: number;
  
  // OpEx
  staffOpEx: number;
  maintenanceOpEx: number;
  energyOpEx: number;
  otherOpEx: number;
  totalOpEx: number;
  
  // Operating Profit
  netOperatingIncome: number;
  
  // Debt
  debtOpeningBalance: number;
  debtDrawdown: number;
  interestDuringConstruction: number;
  interestExpense: number;
  principalRepayment: number;
  totalDebtService: number;
  debtClosingBalance: number;
  
  // Cash Flow & Balances
  freeCashFlowBeforeDebt: number;
  freeCashFlowToEquity: number;
  cumulativeCashBalance: number;
  
  // Indicators
  dscr: number; // Debt Service Coverage Ratio
  llcr: number; // Loan Life Coverage Ratio
  discountFactorSocial: number;
  pvFreeCashFlow: number;
}

export interface FinancialSummary {
  totalCapexNominal: number;
  totalCapexReal: number;
  totalFundingRaised: number;
  maxDebtOutstanding: number;
  peakAnnualDebtService: number;
  minDSCR: number;
  avgDSCR: number;
  npvSocial: number; // Net Present Value @ Green Book rate
  npvCommercial: number; // Net Present Value @ WACC
  projectIrr: number; // Project IRR (%)
  equityIrr: number; // Equity IRR (%)
  benefitCostRatio: number; // BCR
  paybackPeriodYears: number; // Discounted Payback
  totalOperatingRevenue: number;
  totalOperatingExpense: number;
  netOperatingMarginPercent: number;
}

export interface MonteCarloResult {
  iterations: number;
  npvMean: number;
  npvStdDev: number;
  npvP10: number;
  npvP50: number;
  npvP90: number;
  irrMean: number;
  irrP10: number;
  irrP50: number;
  irrP90: number;
  minDscrMean: number;
  probabilityPositiveNpv: number;
  simulations: Array<{
    id: number;
    capexFactor: number;
    demandFactor: number;
    interestRateDelta: number;
    npv: number;
    irr: number;
    minDscr: number;
  }>;
}

export interface UnitTestResult {
  id: string;
  name: string;
  category: 'Cash Balance' | 'Debt Coverage' | 'DCF Convergence' | 'Accounting Identity';
  status: 'PASS' | 'FAIL' | 'WARNING';
  metricValue: string;
  threshold: string;
  details: string;
}
