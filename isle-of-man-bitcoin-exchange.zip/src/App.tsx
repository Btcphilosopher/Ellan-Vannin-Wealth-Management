import React from 'react';
import { ExchangeProvider, useExchange } from './context/ExchangeContext';
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { ToastContainer } from './components/common/ToastContainer';
import { VideoModal } from './components/common/VideoModal';

// Pages
import { HomePage } from './pages/HomePage';
import { ProTradeInterface } from './components/trade/ProTradeInterface';
import { MarketsPage } from './pages/MarketsPage';
import { OtcPage } from './pages/OtcPage';
import { EarnPage } from './pages/EarnPage';
import { AboutPage } from './pages/AboutPage';
import { SecurityPage } from './pages/SecurityPage';
import { FeesPage } from './pages/FeesPage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { SupportPage } from './pages/SupportPage';
import { StatusPage } from './pages/StatusPage';
import { LegalTermsPage } from './pages/LegalTermsPage';
import { LegalPrivacyPage } from './pages/LegalPrivacyPage';

const MainContent: React.FC = () => {
  const { currentPage } = useExchange();

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'trade':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <ProTradeInterface />
          </div>
        );
      case 'markets':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <MarketsPage />
          </div>
        );
      case 'otc':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <OtcPage />
          </div>
        );
      case 'earn':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <EarnPage />
          </div>
        );
      case 'about':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <AboutPage />
          </div>
        );
      case 'security':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <SecurityPage />
          </div>
        );
      case 'fees':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <FeesPage />
          </div>
        );
      case 'login':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <LoginPage />
          </div>
        );
      case 'signup':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <SignupPage />
          </div>
        );
      case 'support':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <SupportPage />
          </div>
        );
      case 'status':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <StatusPage />
          </div>
        );
      case 'legal-terms':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <LegalTermsPage />
          </div>
        );
      case 'legal-privacy':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <LegalPrivacyPage />
          </div>
        );
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0D14] text-slate-100 font-sans selection:bg-[#D9A441] selection:text-black flex flex-col justify-between antialiased">
      <div>
        <Header />
        <main>{renderPage()}</main>
      </div>

      <Footer />
      <ToastContainer />
      <VideoModal />
    </div>
  );
};

export default function App() {
  return (
    <ExchangeProvider>
      <MainContent />
    </ExchangeProvider>
  );
}
