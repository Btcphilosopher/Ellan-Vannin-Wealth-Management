export type OrderType = 'buy' | 'sell' | 'convert';
export type TradeOrderKind = 'market' | 'limit' | 'stop_limit';
export type TimeFrame = '1H' | '4H' | '1D' | '1W' | '1M';

export interface MarketPair {
  id: string;
  symbol: string; // e.g. BTC/GBP
  base: string; // BTC
  quote: string; // GBP
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  sparkline: number[];
  category: 'fiat' | 'crypto' | 'stablecoin';
}

export interface OrderBookEntry {
  price: number;
  amount: number;
  total: number;
  depthPercent: number;
}

export interface OrderBook {
  asks: OrderBookEntry[];
  bids: OrderBookEntry[];
  spread: number;
  spreadPercent: number;
}

export interface RecentTrade {
  id: string;
  price: number;
  amount: number;
  time: string;
  type: 'buy' | 'sell';
}

export interface CandleData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface UserWallet {
  gbpBalance: number;
  btcBalance: number;
  ethBalance: number;
  usdtBalance: number;
  solBalance: number;
}

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  verificationLevel: 'Unverified' | 'Tier 1' | 'Tier 2 (IOM Verified)';
  twoFactorEnabled: boolean;
  wallet: UserWallet;
}

export interface ActiveOrder {
  id: string;
  pair: string;
  side: 'buy' | 'sell';
  kind: TradeOrderKind;
  price: number;
  amount: number;
  filled: number;
  status: 'open' | 'partially_filled' | 'filled' | 'cancelled';
  createdAt: string;
}

export interface NotificationToast {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'error' | 'info';
  timestamp: string;
}
