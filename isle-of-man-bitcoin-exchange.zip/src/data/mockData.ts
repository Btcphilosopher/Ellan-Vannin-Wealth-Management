import { MarketPair, OrderBook, CandleData, RecentTrade } from '../types';

export const INITIAL_MARKETS: MarketPair[] = [
  {
    id: 'btc-gbp',
    symbol: 'BTC/GBP',
    base: 'BTC',
    quote: 'GBP',
    price: 75386.21,
    change24h: 2.48,
    high24h: 76120.00,
    low24h: 73200.50,
    volume24h: 12458291,
    sparkline: [73200, 73500, 73800, 74100, 73900, 74400, 74800, 74500, 75100, 75386.21],
    category: 'fiat',
  },
  {
    id: 'btc-eur',
    symbol: 'BTC/EUR',
    base: 'BTC',
    quote: 'EUR',
    price: 88150.40,
    change24h: 2.35,
    high24h: 89000.00,
    low24h: 85900.00,
    volume24h: 9840120,
    sparkline: [85900, 86200, 86800, 87100, 87600, 88150.40],
    category: 'fiat',
  },
  {
    id: 'btc-usdt',
    symbol: 'BTC/USDT',
    base: 'BTC',
    quote: 'USDT',
    price: 96420.00,
    change24h: 2.52,
    high24h: 97100.00,
    low24h: 93800.00,
    volume24h: 45890100,
    sparkline: [93800, 94200, 95100, 95800, 96420],
    category: 'stablecoin',
  },
  {
    id: 'eth-gbp',
    symbol: 'ETH/GBP',
    base: 'ETH',
    quote: 'GBP',
    price: 2680.50,
    change24h: 3.12,
    high24h: 2720.00,
    low24h: 2590.00,
    volume24h: 3820190,
    sparkline: [2590, 2610, 2630, 2650, 2680.50],
    category: 'fiat',
  },
  {
    id: 'sol-gbp',
    symbol: 'SOL/GBP',
    base: 'SOL',
    quote: 'GBP',
    price: 142.80,
    change24h: -0.85,
    high24h: 148.50,
    low24h: 139.20,
    volume24h: 1940500,
    sparkline: [148, 146, 144, 141, 142.80],
    category: 'fiat',
  },
  {
    id: 'ltc-gbp',
    symbol: 'LTC/GBP',
    base: 'LTC',
    quote: 'GBP',
    price: 84.10,
    change24h: 1.15,
    high24h: 86.00,
    low24h: 82.50,
    volume24h: 620400,
    sparkline: [82.5, 83.1, 83.8, 84.10],
    category: 'fiat',
  },
];

export const INITIAL_ORDER_BOOK: OrderBook = {
  asks: [
    { price: 75390.12, amount: 0.2564, total: 19342.49, depthPercent: 45 },
    { price: 75389.21, amount: 0.1321, total: 9948.72, depthPercent: 25 },
    { price: 75388.10, amount: 0.5687, total: 42874.15, depthPercent: 85 },
    { price: 75387.01, amount: 0.2100, total: 15831.27, depthPercent: 38 },
    { price: 75386.50, amount: 0.0843, total: 6355.08, depthPercent: 15 },
  ],
  bids: [
    { price: 75385.20, amount: 0.1548, total: 11669.63, depthPercent: 28 },
    { price: 75384.10, amount: 0.2683, total: 20225.55, depthPercent: 50 },
    { price: 75383.01, amount: 0.4120, total: 31057.80, depthPercent: 72 },
    { price: 75382.20, amount: 0.1056, total: 7960.36, depthPercent: 20 },
    { price: 75381.12, amount: 0.2300, total: 17337.66, depthPercent: 42 },
  ],
  spread: 1.30,
  spreadPercent: 0.0017,
};

export const INITIAL_RECENT_TRADES: RecentTrade[] = [
  { id: '1', price: 75386.21, amount: 0.0520, time: '14:22:04', type: 'buy' },
  { id: '2', price: 75385.80, amount: 0.1240, time: '14:21:58', type: 'sell' },
  { id: '3', price: 75386.21, amount: 0.0150, time: '14:21:45', type: 'buy' },
  { id: '4', price: 75386.00, amount: 0.4500, time: '14:21:30', type: 'buy' },
  { id: '5', price: 75384.90, amount: 0.0890, time: '14:21:12', type: 'sell' },
  { id: '6', price: 75385.10, amount: 0.2100, time: '14:20:55', type: 'buy' },
];

export const CANDLE_DATA_1D: CandleData[] = [
  { time: 'May 1', open: 67200, high: 68500, low: 66800, close: 68100, volume: 420 },
  { time: 'May 5', open: 68100, high: 69400, low: 67900, close: 69050, volume: 510 },
  { time: 'May 10', open: 69050, high: 70800, low: 68700, close: 70200, volume: 680 },
  { time: 'May 15', open: 70200, high: 71500, low: 69800, close: 70900, volume: 590 },
  { time: 'May 20', open: 70900, high: 72400, low: 70500, close: 71800, volume: 730 },
  { time: 'May 25', open: 71800, high: 73100, low: 71200, close: 72600, volume: 610 },
  { time: 'Jun 1', open: 72600, high: 74200, low: 72100, close: 73800, volume: 820 },
  { time: 'Jun 5', open: 73800, high: 75000, low: 73200, close: 74100, volume: 770 },
  { time: 'Jun 10', open: 74100, high: 74800, low: 73100, close: 73500, volume: 640 },
  { time: 'Jun 15', open: 73500, high: 74900, low: 73200, close: 74600, volume: 710 },
  { time: 'Jun 20', open: 74600, high: 75800, low: 74200, close: 75100, volume: 890 },
  { time: 'Jun 25', open: 75100, high: 76200, low: 74700, close: 75386.21, volume: 940 },
];

export const FEE_TIERS = [
  { tier: 'VIP 0', volume: '< £50k', maker: '0.10%', taker: '0.15%' },
  { tier: 'VIP 1', volume: '£50k - £250k', maker: '0.08%', taker: '0.12%' },
  { tier: 'VIP 2', volume: '£250k - £1M', maker: '0.05%', taker: '0.09%' },
  { tier: 'VIP 3', volume: '£1M - £5M', maker: '0.02%', taker: '0.06%' },
  { tier: 'VIP 4 (Institutional)', volume: '> £5M', maker: '0.00%', taker: '0.03%' },
];

export const EARN_PRODUCTS = [
  {
    id: 'btc-flexible',
    asset: 'BTC',
    name: 'Bitcoin Flexible Stacking',
    type: 'Flexible',
    estimatedApy: '4.25%',
    minDeposit: '0.001 BTC',
    payoutInterval: 'Daily',
    description: 'Earn yield on your Bitcoin while maintaining instant withdrawal liquidity. Backed by Isle of Man institutional yield protocols.'
  },
  {
    id: 'btc-fixed-90',
    asset: 'BTC',
    name: 'Bitcoin Sovereign Vault (90 Days)',
    type: 'Locked (90 Days)',
    estimatedApy: '6.80%',
    minDeposit: '0.05 BTC',
    payoutInterval: 'Weekly',
    description: 'Lock your BTC in our Isle of Man regulated cold-storage yield vault for maximum compounding returns.'
  },
  {
    id: 'eth-staking',
    asset: 'ETH',
    name: 'Ethereum Native Staking',
    type: 'Flexible Staking',
    estimatedApy: '5.10%',
    minDeposit: '0.1 ETH',
    payoutInterval: 'Daily',
    description: 'Direct validator staking on institutional non-custodial node infrastructure located in Isle of Man datacentres.'
  },
];
