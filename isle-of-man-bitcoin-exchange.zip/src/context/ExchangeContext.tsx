import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  MarketPair, 
  OrderBook, 
  RecentTrade, 
  CandleData, 
  UserProfile, 
  ActiveOrder, 
  NotificationToast, 
  TimeFrame,
  TradeOrderKind
} from '../types';
import { INITIAL_MARKETS, INITIAL_ORDER_BOOK, INITIAL_RECENT_TRADES, CANDLE_DATA_1D } from '../data/mockData';

interface ExchangeContextType {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  navigateTo: (page: string) => void;
  
  // Auth state
  isLoggedIn: boolean;
  user: UserProfile;
  login: (email: string, pass: string) => boolean;
  logout: () => void;
  signup: (fullName: string, email: string, pass: string) => boolean;
  
  // Market state
  markets: MarketPair[];
  selectedPair: MarketPair;
  setSelectedPairById: (id: string) => void;
  orderBook: OrderBook;
  recentTrades: RecentTrade[];
  candleData: CandleData[];
  timeFrame: TimeFrame;
  setTimeFrame: (tf: TimeFrame) => void;
  
  // Active Orders & Trades
  activeOrders: ActiveOrder[];
  executeQuickTrade: (side: 'buy' | 'sell', amountGbp: number, btcAmount: number) => boolean;
  placeProOrder: (side: 'buy' | 'sell', kind: TradeOrderKind, price: number, amount: number) => boolean;
  cancelOrder: (orderId: string) => void;
  
  // Toast notifications
  toasts: NotificationToast[];
  addToast: (title: string, message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;

  // Video modal
  isVideoModalOpen: boolean;
  setIsVideoModalOpen: (open: boolean) => void;

  // Search filter
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

const DEFAULT_USER: UserProfile = {
  id: 'usr_iom_9921',
  email: 'trader@isleofman.im',
  fullName: 'Ewan Christian',
  verificationLevel: 'Tier 2 (IOM Verified)',
  twoFactorEnabled: true,
  wallet: {
    gbpBalance: 24850.00,
    btcBalance: 1.84520000,
    ethBalance: 8.50000000,
    usdtBalance: 12500.00,
    solBalance: 45.00000000,
  }
};

const ExchangeContext = createContext<ExchangeContextType | undefined>(undefined);

export const ExchangeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true); // Pre-authenticated for rich instant demo
  const [user, setUser] = useState<UserProfile>(DEFAULT_USER);
  
  const [markets, setMarkets] = useState<MarketPair[]>(INITIAL_MARKETS);
  const [selectedPair, setSelectedPair] = useState<MarketPair>(INITIAL_MARKETS[0]);
  const [orderBook, setOrderBook] = useState<OrderBook>(INITIAL_ORDER_BOOK);
  const [recentTrades, setRecentTrades] = useState<RecentTrade[]>(INITIAL_RECENT_TRADES);
  const [candleData, setCandleData] = useState<CandleData[]>(CANDLE_DATA_1D);
  const [timeFrame, setTimeFrame] = useState<TimeFrame>('1D');
  const [activeOrders, setActiveOrders] = useState<ActiveOrder[]>([
    {
      id: 'ord-8831',
      pair: 'BTC/GBP',
      side: 'buy',
      kind: 'limit',
      price: 74500.00,
      amount: 0.25,
      filled: 0.00,
      status: 'open',
      createdAt: 'Today, 11:42 AM'
    },
    {
      id: 'ord-8819',
      pair: 'BTC/GBP',
      side: 'sell',
      kind: 'limit',
      price: 77000.00,
      amount: 0.10,
      filled: 0.00,
      status: 'open',
      createdAt: 'Yesterday, 04:15 PM'
    }
  ]);

  const [toasts, setToasts] = useState<NotificationToast[]>([]);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const navigateTo = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const addToast = (title: string, message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [{ id, title, message, type, timestamp: new Date().toLocaleTimeString() }, ...prev]);
    setTimeout(() => {
      removeToast(id);
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const setSelectedPairById = (id: string) => {
    const found = markets.find((m) => m.id === id);
    if (found) {
      setSelectedPair(found);
    }
  };

  // Live market price simulation tick
  useEffect(() => {
    const interval = setInterval(() => {
      setMarkets((prevMarkets) =>
        prevMarkets.map((pair) => {
          if (pair.id === 'btc-gbp') {
            const delta = (Math.random() - 0.48) * 12.5; // slight positive bias
            const newPrice = Number((pair.price + delta).toFixed(2));
            return {
              ...pair,
              price: newPrice,
              high24h: Math.max(pair.high24h, newPrice),
              low24h: Math.min(pair.low24h, newPrice),
            };
          }
          return pair;
        })
      );
    }, 3500);

    return () => clearInterval(interval);
  }, []);

  // Update selectedPair price whenever markets updates
  useEffect(() => {
    const match = markets.find((m) => m.id === selectedPair.id);
    if (match && match.price !== selectedPair.price) {
      setSelectedPair(match);
      // Update order book spread
      setOrderBook((prev) => {
        const topAskPrice = Number((match.price + 2.50).toFixed(2));
        const topBidPrice = Number((match.price - 1.20).toFixed(2));
        const newAsks = prev.asks.map((ask, idx) => ({
          ...ask,
          price: Number((topAskPrice + idx * 1.5).toFixed(2)),
          total: Number(((topAskPrice + idx * 1.5) * ask.amount).toFixed(2)),
        }));
        const newBids = prev.bids.map((bid, idx) => ({
          ...bid,
          price: Number((topBidPrice - idx * 1.4).toFixed(2)),
          total: Number(((topBidPrice - idx * 1.4) * bid.amount).toFixed(2)),
        }));
        return {
          ...prev,
          asks: newAsks,
          bids: newBids,
          spread: Number((topAskPrice - topBidPrice).toFixed(2)),
        };
      });
    }
  }, [markets, selectedPair.id]);

  const login = (email: string, _pass: string) => {
    setIsLoggedIn(true);
    setUser({
      ...DEFAULT_USER,
      email,
    });
    addToast('Welcome Back', `Successfully authenticated as ${email}`, 'success');
    navigateTo('trade');
    return true;
  };

  const logout = () => {
    setIsLoggedIn(false);
    addToast('Logged Out', 'You have been safely logged out of Isle of Man Exchange', 'info');
    navigateTo('home');
  };

  const signup = (fullName: string, email: string, _pass: string) => {
    setIsLoggedIn(true);
    setUser({
      ...DEFAULT_USER,
      fullName,
      email,
      verificationLevel: 'Tier 1',
    });
    addToast('Account Created', 'Welcome to Isle of Man Bitcoin Exchange! Verification link sent.', 'success');
    navigateTo('trade');
    return true;
  };

  const executeQuickTrade = (side: 'buy' | 'sell', amountGbp: number, btcAmount: number): boolean => {
    if (side === 'buy') {
      if (user.wallet.gbpBalance < amountGbp) {
        addToast('Insufficient Balance', `You need £${amountGbp.toLocaleString()} GBP, but have £${user.wallet.gbpBalance.toLocaleString()}`, 'error');
        return false;
      }
      setUser((prev) => ({
        ...prev,
        wallet: {
          ...prev.wallet,
          gbpBalance: Number((prev.wallet.gbpBalance - amountGbp).toFixed(2)),
          btcBalance: Number((prev.wallet.btcBalance + btcAmount).toFixed(8)),
        },
      }));
      addToast(
        'Order Executed',
        `Successfully bought ${btcAmount.toFixed(6)} BTC for £${amountGbp.toLocaleString('en-GB', { minimumFractionDigits: 2 })} GBP`,
        'success'
      );
    } else {
      if (user.wallet.btcBalance < btcAmount) {
        addToast('Insufficient BTC', `You need ${btcAmount} BTC, but have ${user.wallet.btcBalance} BTC`, 'error');
        return false;
      }
      setUser((prev) => ({
        ...prev,
        wallet: {
          ...prev.wallet,
          btcBalance: Number((prev.wallet.btcBalance - btcAmount).toFixed(8)),
          gbpBalance: Number((prev.wallet.gbpBalance + amountGbp).toFixed(2)),
        },
      }));
      addToast(
        'Order Executed',
        `Successfully sold ${btcAmount.toFixed(6)} BTC for £${amountGbp.toLocaleString('en-GB', { minimumFractionDigits: 2 })} GBP`,
        'success'
      );
    }

    // Add to recent trades
    const newTrade: RecentTrade = {
      id: Math.random().toString(),
      price: selectedPair.price,
      amount: btcAmount,
      time: new Date().toLocaleTimeString(),
      type: side,
    };
    setRecentTrades((prev) => [newTrade, ...prev.slice(0, 15)]);

    return true;
  };

  const placeProOrder = (side: 'buy' | 'sell', kind: TradeOrderKind, price: number, amount: number): boolean => {
    const totalCost = price * amount;
    if (side === 'buy' && user.wallet.gbpBalance < totalCost) {
      addToast('Order Failed', `Insufficient GBP balance. Required: £${totalCost.toFixed(2)}`, 'error');
      return false;
    }
    if (side === 'sell' && user.wallet.btcBalance < amount) {
      addToast('Order Failed', `Insufficient BTC balance. Required: ${amount} BTC`, 'error');
      return false;
    }

    if (kind === 'market') {
      return executeQuickTrade(side, totalCost, amount);
    }

    // Limit or stop_limit order
    const newOrder: ActiveOrder = {
      id: `ord-${Math.floor(Math.random() * 9000 + 1000)}`,
      pair: selectedPair.symbol,
      side,
      kind,
      price,
      amount,
      filled: 0,
      status: 'open',
      createdAt: 'Just now',
    };

    setActiveOrders((prev) => [newOrder, ...prev]);
    addToast('Limit Order Placed', `${side.toUpperCase()} ${amount} ${selectedPair.base} @ £${price.toLocaleString()}`, 'success');
    return true;
  };

  const cancelOrder = (orderId: string) => {
    setActiveOrders((prev) => prev.filter((o) => o.id !== orderId));
    addToast('Order Cancelled', `Order ${orderId} has been cancelled`, 'info');
  };

  return (
    <ExchangeContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        navigateTo,
        isLoggedIn,
        user,
        login,
        logout,
        signup,
        markets,
        selectedPair,
        setSelectedPairById,
        orderBook,
        recentTrades,
        candleData,
        timeFrame,
        setTimeFrame,
        activeOrders,
        executeQuickTrade,
        placeProOrder,
        cancelOrder,
        toasts,
        addToast,
        removeToast,
        isVideoModalOpen,
        setIsVideoModalOpen,
        searchQuery,
        setSearchQuery,
      }}
    >
      {children}
    </ExchangeContext.Provider>
  );
};

export const useExchange = () => {
  const context = useContext(ExchangeContext);
  if (!context) {
    throw new Error('useExchange must be used within an ExchangeProvider');
  }
  return context;
};
