import React from 'react';

export const LegalTermsPage: React.FC = () => {
  return (
    <div className="space-y-6 max-w-4xl mx-auto bg-[#0E131F] border border-[#1F293D] rounded-2xl p-8 text-slate-300 text-xs leading-relaxed">
      <h1 className="text-2xl font-bold text-white mb-4">Terms of Service</h1>
      <p className="text-slate-400">Last updated: August 8, 2026</p>

      <section className="space-y-2">
        <h2 className="text-sm font-bold text-white">1. Regulatory Jurisdiction</h2>
        <p>
          Isle of Man Bitcoin Exchange Ltd is registered with the Isle of Man Financial Services Authority (IOM FSA) under the Designated Businesses (Registration and Oversight) Act 2015.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="text-sm font-bold text-white">2. Account Registration & Verification</h2>
        <p>
          Users must complete statutory Anti-Money Laundering (AML) and Know Your Customer (KYC) verification procedures before executing transactions.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="text-sm font-bold text-white">3. Risk Disclosure</h2>
        <p>
          Digital assets are volatile financial instruments. Trading involves significant risk of monetary loss.
        </p>
      </section>
    </div>
  );
};
