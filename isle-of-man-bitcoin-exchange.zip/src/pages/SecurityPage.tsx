import React, { useState } from 'react';
import { ShieldCheck, Lock, Key, Cpu, CheckCircle2, Server } from 'lucide-react';

export const SecurityPage: React.FC = () => {
  const [proofVerified, setProofVerified] = useState(false);

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Banner */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-8 space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
          <ShieldCheck className="w-4 h-4" />
          Institutional Grade Security Standard
        </div>
        <h1 className="text-3xl font-extrabold text-white">Security Architecture & Proof of Reserves</h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
          Security is built into our core foundation. We enforce strict separation of duties, hardware security modules (HSMs), and multi-signature cold vaults.
        </p>
      </div>

      {/* Grid Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-3">
          <Lock className="w-8 h-8 text-[#D9A441]" />
          <h3 className="text-base font-bold text-white">98% Offline Cold Storage</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            The overwhelming majority of digital assets are held in air-gapped, offline hardware security vaults situated in fortified locations.
          </p>
        </div>

        <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-3">
          <Key className="w-8 h-8 text-[#D9A441]" />
          <h3 className="text-base font-bold text-white">3-of-5 Multi-Sig Custody</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            No single individual can authorize fund transfers. Outgoing transactions require consensus from geographically separated signatories.
          </p>
        </div>

        <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-3">
          <Cpu className="w-8 h-8 text-[#D9A441]" />
          <h3 className="text-base font-bold text-white">Hardware 2FA Enforcement</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Support for FIDO2 / YubiKey hardware security keys, TOTP authenticator apps, and multi-factor withdrawal whitelisting.
          </p>
        </div>
      </div>

      {/* Interactive Cryptographic Proof of Reserves Tool */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Server className="w-4 h-4 text-[#D9A441]" />
          Cryptographic Proof of Reserves Verifier (Merkle Tree)
        </h3>
        <p className="text-xs text-slate-300">
          Verify that your account balance is included in our cryptographically audited Merkle Tree root snapshot.
        </p>

        <div className="p-4 bg-[#0A0D14] border border-[#1F293D] rounded-xl font-mono text-xs space-y-2">
          <div className="flex justify-between text-slate-400">
            <span>Audit Date:</span>
            <span className="text-white">August 8, 2026 (100.0% Solvency)</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Merkle Root Hash:</span>
            <span className="text-[#D9A441] truncate max-w-xs">0x8f2a9b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a</span>
          </div>
        </div>

        <button
          onClick={() => setProofVerified(true)}
          className="px-6 py-2.5 bg-[#1C2436] hover:bg-slate-700 text-[#D9A441] font-bold text-xs rounded-xl border border-[#D9A441]/40 transition-colors"
        >
          Verify Account Cryptographic Inclusion Hash
        </button>

        {proofVerified && (
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Cryptographic Proof Confirmed: Account balance included in Merkle Root hash #8f2a9b3c. Total Exchange Reserves = 2,543.0000 BTC.</span>
          </div>
        )}
      </div>
    </div>
  );
};
