import React, { useState } from 'react';
import { useExchange } from '../context/ExchangeContext';
import { Search, ArrowUpDown, TrendingUp } from 'lucide-react';

export const MarketsPage: React.FC = () => {
  const { markets, setSelectedPairById, navigateTo } = useExchange();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<'all' | 'fiat' | 'crypto' | 'stablecoin'>('all');

  const filtered = markets.filter((m) => {
    const matchesSearch = m.symbol.toLowerCase().includes(search.toLowerCase()) || m.base.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === 'all' || m.category === category;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#D9A441]" />
            Digital Asset Markets
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time market depth, order execution and liquidity across Isle of Man regulated pairs.
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search symbol (e.g. BTC, ETH)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs pl-9 pr-4 py-2.5 rounded-xl focus:outline-none"
          />
        </div>
      </div>

      {/* Categories Bar */}
      <div className="flex items-center gap-2 bg-[#0E131F] border border-[#1F293D] p-1.5 rounded-xl w-fit">
        {(['all', 'fiat', 'stablecoin'] as const).map((cat) => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={`px-4 py-1.5 text-xs font-semibold rounded-lg capitalize transition-all ${
              category === cat
                ? 'bg-[#1C2436] text-[#D9A441] shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat === 'all' ? 'All Markets' : cat === 'fiat' ? 'GBP / Fiat Pairs' : 'Stablecoin Pairs'}
          </button>
        ))}
      </div>

      {/* Markets Table */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#0A0D14] text-slate-400 uppercase text-[10px] tracking-wider border-b border-[#1F293D]">
              <tr>
                <th className="py-3.5 px-6">Pair</th>
                <th className="py-3.5 px-4">Price</th>
                <th className="py-3.5 px-4">24h Change</th>
                <th className="py-3.5 px-4">24h High</th>
                <th className="py-3.5 px-4">24h Low</th>
                <th className="py-3.5 px-4">24h Volume</th>
                <th className="py-3.5 px-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F293D]/60 text-slate-200">
              {filtered.map((m) => (
                <tr key={m.id} className="hover:bg-[#121722] transition-colors">
                  <td className="py-4 px-6 font-bold text-white flex items-center gap-2">
                    <span className="w-7 h-7 rounded-full bg-[#D9A441]/10 border border-[#D9A441] flex items-center justify-center text-[#D9A441] text-xs">
                      {m.base.substring(0, 1)}
                    </span>
                    <span>{m.symbol}</span>
                  </td>
                  <td className="py-4 px-4 font-bold text-white">
                    £{m.price.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                  </td>
                  <td className={`py-4 px-4 font-bold ${m.change24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    <span className="inline-flex items-center gap-1">
                      {m.change24h >= 0 ? '+' : ''}{m.change24h}%
                    </span>
                  </td>
                  <td className="py-4 px-4 text-slate-400">£{m.high24h.toLocaleString()}</td>
                  <td className="py-4 px-4 text-slate-400">£{m.low24h.toLocaleString()}</td>
                  <td className="py-4 px-4 text-slate-300">£{m.volume24h.toLocaleString()}</td>
                  <td className="py-4 px-6 text-right">
                    <button
                      onClick={() => {
                        setSelectedPairById(m.id);
                        navigateTo('trade');
                      }}
                      className="px-4 py-1.5 bg-[#D9A441] hover:bg-[#F0C067] text-[#0A0D14] font-bold text-xs rounded-lg transition-all"
                    >
                      Trade
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
