import React from 'react';

export const LegalPrivacyPage: React.FC = () => {
  return (
    <div className="space-y-6 max-w-4xl mx-auto bg-[#0E131F] border border-[#1F293D] rounded-2xl p-8 text-slate-300 text-xs leading-relaxed">
      <h1 className="text-2xl font-bold text-white mb-4">Privacy Policy</h1>
      <p className="text-slate-400">Last updated: August 8, 2026</p>

      <section className="space-y-2">
        <h2 className="text-sm font-bold text-white">1. Data Controller</h2>
        <p>
          We adhere to the Isle of Man Data Protection Act 2018 (GDPR equivalent). Your personal data is stored securely in Douglas data centres and is never sold to third parties.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="text-sm font-bold text-white">2. Cryptographic Security</h2>
        <p>
          All sensitive user data, including API keys and identification documents, are encrypted at rest using AES-256 and in transit via TLS 1.3.
        </p>
      </section>
    </div>
  );
};
