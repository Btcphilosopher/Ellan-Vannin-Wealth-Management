import React, { useState } from 'react';
import { useExchange } from '../context/ExchangeContext';
import { TriskelionLogo } from '../components/common/TriskelionLogo';
import { Eye, EyeOff, Lock, Mail, User, ShieldCheck, ArrowRight } from 'lucide-react';

export const SignupPage: React.FC = () => {
  const { signup, navigateTo, addToast } = useExchange();
  const [fullName, setFullName] = useState('Ewan Christian');
  const [email, setEmail] = useState('trader@isleofman.im');
  const [password, setPassword] = useState('SovereignKey2026!');
  const [showPassword, setShowPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(true);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreeTerms) {
      addToast('Terms Required', 'Please accept the Isle of Man Terms of Service.', 'error');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      signup(fullName, email, password);
      setLoading(false);
    }, 600);
  };

  return (
    <div className="max-w-md mx-auto py-10 px-4">
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-8 shadow-2xl space-y-6">
        
        {/* Logo */}
        <div className="text-center space-y-2">
          <TriskelionLogo size={44} className="mx-auto" />
          <h2 className="text-2xl font-bold text-white tracking-tight">Create Your Account</h2>
          <p className="text-xs text-slate-400">Register under Isle of Man Financial Regulation</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300 block">Full Name</label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs pl-9 pr-4 py-3 rounded-xl focus:outline-none"
              />
            </div>
          </div>

          {/* Email */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300 block">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs pl-9 pr-4 py-3 rounded-xl focus:outline-none"
              />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300 block">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs pl-9 pr-10 py-3 rounded-xl focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Terms checkbox */}
          <div className="flex items-start gap-2 pt-1">
            <input
              type="checkbox"
              id="terms"
              checked={agreeTerms}
              onChange={(e) => setAgreeTerms(e.target.checked)}
              className="mt-1 rounded bg-[#0A0D14] border-[#1F293D] text-[#D9A441] focus:ring-0 cursor-pointer"
            />
            <label htmlFor="terms" className="text-[11px] text-slate-400 cursor-pointer leading-tight">
              I agree to the <button type="button" onClick={() => navigateTo('legal-terms')} className="text-[#D9A441] underline">Terms of Service</button> and <button type="button" onClick={() => navigateTo('legal-privacy')} className="text-[#D9A441] underline">Privacy Policy</button>.
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-gradient-to-r from-[#E5B354] via-[#D9A441] to-[#C49033] hover:from-[#F0C067] text-[#0A0D14] font-bold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
          >
            {loading ? (
              <span className="w-5 h-5 border-2 border-[#0A0D14] border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>Create Verified Account</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="pt-4 border-t border-[#1F293D] text-center text-xs text-slate-400">
          Already registered?{' '}
          <button onClick={() => navigateTo('login')} className="text-[#D9A441] font-bold hover:underline">
            Log In
          </button>
        </div>

      </div>
    </div>
  );
};
