import React from 'react';
import { HeroSection } from '../components/home/HeroSection';
import { MarketTickerStrip } from '../components/home/MarketTickerStrip';
import { WhyTradeSection } from '../components/home/WhyTradeSection';
import { MainCandleChart } from '../components/home/MainCandleChart';
import { OrderBookPanel } from '../components/home/OrderBookPanel';
import { IomHubCard } from '../components/home/IomHubCard';

export const HomePage: React.FC = () => {
  return (
    <div className="space-y-8 pb-8">
      {/* 1. Hero Section matching screenshot */}
      <HeroSection />

      {/* 2. Ticker Strip matching screenshot */}
      <MarketTickerStrip />

      {/* 3. Lower Dashboard Grid matching screenshot structure */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
          
          {/* Why Trade with Us (3 cols) */}
          <div className="lg:col-span-3">
            <WhyTradeSection />
          </div>

          {/* BTC/GBP Candlestick Chart (4 cols) */}
          <div className="lg:col-span-4 min-h-[380px]">
            <MainCandleChart />
          </div>

          {/* Order Book Panel (3 cols) */}
          <div className="lg:col-span-3 min-h-[380px]">
            <OrderBookPanel />
          </div>

          {/* Isle of Man Digital Finance Hub card (2 cols) */}
          <div className="lg:col-span-2">
            <IomHubCard />
          </div>

        </div>
      </div>
    </div>
  );
};
