import React, { useState } from 'react';
import { useExchange } from '../context/ExchangeContext';
import { EARN_PRODUCTS } from '../data/mockData';
import { ShieldCheck, TrendingUp, Lock, Wallet, ArrowRight } from 'lucide-react';

export const EarnPage: React.FC = () => {
  const { addToast, user, isLoggedIn, navigateTo } = useExchange();
  const [selectedProduct, setSelectedProduct] = useState(EARN_PRODUCTS[0]);
  const [depositBtc, setDepositBtc] = useState<string>('0.1');

  const handleStake = (productName: string) => {
    if (!isLoggedIn) {
      navigateTo('login');
      return;
    }
    const val = parseFloat(depositBtc);
    if (isNaN(val) || val <= 0) {
      addToast('Invalid Amount', 'Please enter a valid deposit amount.', 'error');
      return;
    }
    if (user.wallet.btcBalance < val) {
      addToast('Insufficient BTC', `You have ${user.wallet.btcBalance} BTC available.`, 'error');
      return;
    }
    addToast(
      'Vault Allocated',
      `Successfully allocated ${val} BTC to ${productName}. Earnings generated daily into your wallet.`,
      'success'
    );
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D9A441]/10 border border-[#D9A441]/30 text-[#D9A441] text-xs font-semibold">
            <ShieldCheck className="w-4 h-4" />
            Isle of Man Regulated Stacking Protocol
          </div>
          <h1 className="text-3xl font-extrabold text-white">Bitcoin Sovereign Earn</h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Put your Bitcoin to work without exposing assets to unhedged rehypothecation. All yield strategies are backed 1:1 by Isle of Man institutional cold-vault reserves.
          </p>
        </div>

        <div className="p-4 bg-[#0A0D14] rounded-xl border border-[#1F293D] text-center shrink-0">
          <span className="text-xs text-slate-400 block font-semibold">Max Estimated APY</span>
          <span className="text-3xl font-mono font-extrabold text-[#D9A441]">6.80%</span>
        </div>
      </div>

      {/* Vault Products Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {EARN_PRODUCTS.map((prod) => (
          <div 
            key={prod.id}
            onClick={() => setSelectedProduct(prod)}
            className={`bg-[#0E131F] border rounded-2xl p-6 space-y-4 cursor-pointer transition-all ${
              selectedProduct.id === prod.id
                ? 'border-[#D9A441] shadow-[0_0_20px_rgba(217,164,65,0.2)]'
                : 'border-[#1F293D] hover:border-slate-600'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#D9A441] bg-[#D9A441]/10 px-2.5 py-1 rounded-lg border border-[#D9A441]/20">
                {prod.type}
              </span>
              <span className="text-xs font-mono font-bold text-emerald-400">{prod.estimatedApy} APY</span>
            </div>

            <h3 className="text-base font-bold text-white">{prod.name}</h3>
            <p className="text-xs text-slate-400 leading-relaxed min-h-[40px]">{prod.description}</p>

            <div className="pt-3 border-t border-[#1F293D] flex items-center justify-between text-xs text-slate-300">
              <span>Payouts: <strong>{prod.payoutInterval}</strong></span>
              <span>Min: <strong>{prod.minDeposit}</strong></span>
            </div>
          </div>
        ))}
      </div>

      {/* Staking Allocation Form */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-white tracking-wide">
            Allocate to {selectedProduct.name}
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Selected Plan: <strong className="text-[#D9A441]">{selectedProduct.type}</strong> with <strong className="text-emerald-400">{selectedProduct.estimatedApy} APY</strong>.
          </p>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 block">Deposit Amount (BTC)</label>
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={depositBtc}
                onChange={(e) => setDepositBtc(e.target.value)}
                className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white font-mono font-bold text-base px-4 py-3 rounded-xl focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setDepositBtc(user.wallet.btcBalance.toString())}
                className="px-3 py-3 bg-[#1C2436] hover:bg-slate-700 text-xs font-bold text-[#D9A441] rounded-xl border border-[#1F293D]"
              >
                MAX
              </button>
            </div>
            {isLoggedIn && (
              <p className="text-[11px] text-slate-400 font-mono">
                Available Wallet Balance: {user.wallet.btcBalance.toFixed(4)} BTC
              </p>
            )}
          </div>

          <button
            onClick={() => handleStake(selectedProduct.name)}
            className="w-full py-3.5 bg-gradient-to-r from-[#E5B354] via-[#D9A441] to-[#C49033] hover:from-[#F0C067] text-[#0A0D14] font-bold text-sm rounded-xl shadow-lg transition-all"
          >
            Confirm Vault Allocation
          </button>
        </div>

        {/* Projected Earnings Calculator */}
        <div className="bg-[#0A0D14] border border-[#1F293D] rounded-xl p-6 space-y-4">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Projected Earnings Forecast</h4>
          
          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between py-2 border-b border-[#1F293D]">
              <span className="text-slate-400">Daily Return:</span>
              <span className="text-emerald-400 font-bold">
                +{((parseFloat(depositBtc || '0') * 0.068) / 365).toFixed(6)} BTC
              </span>
            </div>
            <div className="flex justify-between py-2 border-b border-[#1F293D]">
              <span className="text-slate-400">30-Day Compound Return:</span>
              <span className="text-emerald-400 font-bold">
                +{((parseFloat(depositBtc || '0') * 0.068) / 12).toFixed(6)} BTC
              </span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-slate-400">1-Year Annualized Return:</span>
              <span className="text-[#D9A441] font-bold text-sm">
                +{(parseFloat(depositBtc || '0') * 0.068).toFixed(6)} BTC
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
