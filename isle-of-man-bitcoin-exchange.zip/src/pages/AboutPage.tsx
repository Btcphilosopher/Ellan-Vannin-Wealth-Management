import React from 'react';
import { useExchange } from '../context/ExchangeContext';
import { ShieldCheck, Landmark, Building2, MapPin, Award, CheckCircle2 } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { navigateTo } = useExchange();

  return (
    <div className="space-y-12 max-w-5xl mx-auto">
      {/* Hero */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-8 relative overflow-hidden space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D9A441]/10 border border-[#D9A441]/30 text-[#D9A441] text-xs font-semibold">
          <Landmark className="w-4 h-4" />
          The Isle of Man Sovereign Advantage
        </div>

        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          About Isle of Man Bitcoin Exchange
        </h1>

        <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
          Founded in Douglas, Isle of Man, our exchange provides a sovereign, transparent, and legally sound platform for Bitcoin investors worldwide.
        </p>
      </div>

      {/* 4 Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#D9A441]/10 border border-[#D9A441]/30 text-[#D9A441] flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Designated Businesses Act Registration</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Registered under the Isle of Man Financial Services Authority (IOM FSA) Designated Businesses (Registration and Oversight) Act 2015. We adhere to rigorous Anti-Money Laundering (AML) and Countering the Financing of Terrorism (CFT) standards.
          </p>
        </div>

        <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#D9A441]/10 border border-[#D9A441]/30 text-[#D9A441] flex items-center justify-center">
            <Building2 className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Crown Dependency Legal Certainty</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            The Isle of Man is an independent self-governing Crown Dependency with over 1,000 years of unbroken parliamentary history. Its legal framework is derived from English Common Law, offering unprecedented protection for property rights.
          </p>
        </div>

        <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#D9A441]/10 border border-[#D9A441]/30 text-[#D9A441] flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">98% Cold Storage Solvency</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            All customer Bitcoin holdings are stored off-grid in physical, geographically distributed underground vaults in the British Isles. We conduct real-time Proof of Reserves cryptographic verification.
          </p>
        </div>

        <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#D9A441]/10 border border-[#D9A441]/30 text-[#D9A441] flex items-center justify-center">
            <MapPin className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-white">Headquartered in Douglas</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Located at St George's Court, Upper Church Street, Douglas, Isle of Man IM1 1EE. Our engineering and compliance teams operate directly on the island.
          </p>
        </div>
      </div>

      {/* CTA Box */}
      <div className="bg-[#121722] border border-[#D9A441]/40 rounded-2xl p-8 text-center space-y-4">
        <h3 className="text-xl font-bold text-white">Ready to trade on the Isle of Man?</h3>
        <p className="text-xs text-slate-300 max-w-lg mx-auto">
          Create an account in less than 2 minutes and join thousands of global traders utilizing Isle of Man regulated digital asset infrastructure.
        </p>
        <button
          onClick={() => navigateTo('signup')}
          className="px-8 py-3 bg-[#D9A441] hover:bg-[#F0C067] text-[#0A0D14] font-bold text-sm rounded-xl transition-all"
        >
          Open An Account
        </button>
      </div>
    </div>
  );
};
