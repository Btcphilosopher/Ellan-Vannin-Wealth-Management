import React from 'react';
import { CheckCircle2, Activity, ShieldCheck, Server } from 'lucide-react';

export const StatusPage: React.FC = () => {
  const systems = [
    { name: 'Core Matching Engine', status: 'Operational', latency: '1.2ms', uptime: '99.99%' },
    { name: 'Isle of Man Banking API', status: 'Operational', latency: '12ms', uptime: '100.0%' },
    { name: 'Bitcoin Full Node Cluster', status: 'Operational', latency: '0.8ms', uptime: '100.0%' },
    { name: 'Lightning Network Gateway', status: 'Operational', latency: '2.1ms', uptime: '99.98%' },
    { name: 'WebSockets Live Orderbook', status: 'Operational', latency: '3.4ms', uptime: '99.99%' },
    { name: 'Cold Storage Vault Signer', status: 'Operational', latency: 'Air-Gapped', uptime: '100.0%' },
  ];

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-8 space-y-4">
        <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full w-fit">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          All Systems Operational
        </div>
        <h1 className="text-3xl font-extrabold text-white">System Status & Performance Health</h1>
        <p className="text-xs sm:text-sm text-slate-300">
          Real-time latency and uptime telemetry across Douglas infrastructure clusters.
        </p>
      </div>

      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Activity className="w-4 h-4 text-[#D9A441]" />
          Infrastructure Telemetry
        </h3>

        <div className="space-y-2 font-mono text-xs">
          {systems.map((s, i) => (
            <div key={i} className="p-3.5 bg-[#0A0D14] rounded-xl border border-[#1F293D] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-bold text-white">{s.name}</span>
              </div>
              <div className="flex items-center gap-6 text-slate-400 text-[11px]">
                <span>Latency: <strong className="text-slate-200">{s.latency}</strong></span>
                <span>Uptime: <strong className="text-emerald-400">{s.uptime}</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
