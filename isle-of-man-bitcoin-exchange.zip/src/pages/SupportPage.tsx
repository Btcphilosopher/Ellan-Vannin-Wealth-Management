import React, { useState } from 'react';
import { useExchange } from '../context/ExchangeContext';
import { Search, HelpCircle, MessageSquare, Send, CheckCircle2 } from 'lucide-react';

export const SupportPage: React.FC = () => {
  const { addToast } = useExchange();
  const [search, setSearch] = useState('');
  const [ticketSubmitted, setTicketSubmitted] = useState(false);
  const [ticket, setTicket] = useState({ subject: '', category: 'Trading', message: '' });

  const faqs = [
    {
      q: 'How are customer funds protected on the Isle of Man Exchange?',
      a: 'Customer funds are segregated from operational capital and held in 1:1 multi-signature cold storage vaults under the oversight of the Isle of Man Financial Services Authority framework.'
    },
    {
      q: 'What fiat deposit methods are supported for UK and EU residents?',
      a: 'We support instant GBP Faster Payments (0% fee), SEPA Instant Euro transfers, and SWIFT international bank wires.'
    },
    {
      q: 'What is the verification timeline for Tier 2 accounts?',
      a: 'Automated identity verification takes under 3 minutes for UK, EU, and Isle of Man residents.'
    },
    {
      q: 'How do I transfer Bitcoin off the exchange?',
      a: 'Withdrawals can be executed instantly via on-chain transfer or high-capacity Bitcoin Lightning network routing.'
    }
  ];

  const filteredFaqs = faqs.filter(f => f.q.toLowerCase().includes(search.toLowerCase()) || f.a.toLowerCase().includes(search.toLowerCase()));

  const handleTicketSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticket.subject || !ticket.message) {
      addToast('Error', 'Please fill in the subject and message.', 'error');
      return;
    }
    setTicketSubmitted(true);
    addToast('Ticket Opened', 'Your support ticket #IOM-9941 has been submitted to Douglas operations.', 'success');
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-8 space-y-4 text-center">
        <h1 className="text-3xl font-extrabold text-white">Help Centre & Client Support</h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto">
          Our Douglas support team is available 24/7 to assist with trades, compliance, and institutional inquiries.
        </p>

        {/* Search */}
        <div className="relative max-w-md mx-auto pt-2">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 mt-1" />
          <input
            type="text"
            placeholder="Search help articles..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs pl-9 pr-4 py-3 rounded-xl focus:outline-none"
          />
        </div>
      </div>

      {/* FAQs */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-[#D9A441]" />
          Frequently Asked Questions
        </h3>

        <div className="space-y-3">
          {filteredFaqs.map((faq, i) => (
            <div key={i} className="p-4 bg-[#0A0D14] rounded-xl border border-[#1F293D] space-y-1.5">
              <h4 className="text-xs font-bold text-white">{faq.q}</h4>
              <p className="text-xs text-slate-300 leading-relaxed">{faq.a}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Submit Ticket */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-[#D9A441]" />
          Submit a Direct Support Ticket
        </h3>

        {ticketSubmitted ? (
          <div className="p-6 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <h4 className="text-sm font-bold text-white">Ticket Submitted Successfully</h4>
            <p className="text-xs text-slate-300">Ref: #IOM-9941 • Expected response within 15 minutes.</p>
          </div>
        ) : (
          <form onSubmit={handleTicketSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-400 block mb-1">Subject</label>
                <input
                  type="text"
                  required
                  placeholder="Summary of issue..."
                  value={ticket.subject}
                  onChange={(e) => setTicket({ ...ticket, subject: e.target.value })}
                  className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs px-3.5 py-2.5 rounded-xl focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-400 block mb-1">Category</label>
                <select
                  value={ticket.category}
                  onChange={(e) => setTicket({ ...ticket, category: e.target.value })}
                  className="w-full bg-[#0A0D14] border border-[#1F293D] text-white text-xs px-3.5 py-2.5 rounded-xl focus:outline-none"
                >
                  <option value="Trading">Trading & Order Execution</option>
                  <option value="Deposits">Fiat Deposits & Withdrawals</option>
                  <option value="KYC">Identity Verification / KYC</option>
                  <option value="Security">Security & 2FA</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Detailed Message</label>
              <textarea
                rows={4}
                required
                placeholder="Explain how we can help..."
                value={ticket.message}
                onChange={(e) => setTicket({ ...ticket, message: e.target.value })}
                className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs p-3 rounded-xl focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-3 bg-[#D9A441] hover:bg-[#F0C067] text-[#0A0D14] font-bold text-xs rounded-xl transition-all inline-flex items-center gap-2"
            >
              <span>Send Ticket</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
