import React from 'react';
import { FEE_TIERS } from '../data/mockData';
import { ShieldCheck, Zap, CreditCard } from 'lucide-react';

export const FeesPage: React.FC = () => {
  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-8 space-y-4">
        <h1 className="text-3xl font-extrabold text-white">Transparent Fee Schedule</h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
          We operate a volume-tiered fee model. The more you trade over a 30-day rolling period, the lower your trading fees become.
        </p>
      </div>

      {/* Trading Fee Tiers Table */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Zap className="w-5 h-5 text-[#D9A441]" />
          30-Day Volume Tier Schedule
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="bg-[#0A0D14] text-slate-400 uppercase text-[10px] border-b border-[#1F293D]">
              <tr>
                <th className="py-3 px-4">Tier</th>
                <th className="py-3 px-4">30-Day Volume (GBP)</th>
                <th className="py-3 px-4">Maker Fee</th>
                <th className="py-3 px-4">Taker Fee</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F293D]/60 text-slate-200">
              {FEE_TIERS.map((row, index) => (
                <tr key={index} className="hover:bg-slate-800/30">
                  <td className="py-3 px-4 font-bold text-white">{row.tier}</td>
                  <td className="py-3 px-4 text-slate-300">{row.volume}</td>
                  <td className="py-3 px-4 text-emerald-400 font-bold">{row.maker}</td>
                  <td className="py-3 px-4 text-[#D9A441] font-bold">{row.taker}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Deposit & Withdrawal Fees Table */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-[#D9A441]" />
          Fiat & Crypto Deposit / Withdrawal Methods
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div className="p-4 bg-[#0A0D14] rounded-xl border border-[#1F293D] space-y-2">
            <div className="flex justify-between font-bold text-white border-b border-[#1F293D] pb-2">
              <span>GBP Faster Payments</span>
              <span className="text-emerald-400">FREE Deposit</span>
            </div>
            <p className="text-slate-400 text-[11px]">Settlement time: Instant (within 5 minutes). Withdrawal fee: £1.00 flat.</p>
          </div>

          <div className="p-4 bg-[#0A0D14] rounded-xl border border-[#1F293D] space-y-2">
            <div className="flex justify-between font-bold text-white border-b border-[#1F293D] pb-2">
              <span>Bitcoin On-Chain Transfer</span>
              <span className="text-emerald-400">FREE Deposit</span>
            </div>
            <p className="text-slate-400 text-[11px]">Withdrawal fee: Dynamic miner fee (approx 0.00005 BTC / ~£3.50).</p>
          </div>

          <div className="p-4 bg-[#0A0D14] rounded-xl border border-[#1F293D] space-y-2">
            <div className="flex justify-between font-bold text-white border-b border-[#1F293D] pb-2">
              <span>Bitcoin Lightning Network</span>
              <span className="text-emerald-400">FREE Deposit</span>
            </div>
            <p className="text-slate-400 text-[11px]">Instant capacity routing. Withdrawal fee: 1 satoshi flat.</p>
          </div>

          <div className="p-4 bg-[#0A0D14] rounded-xl border border-[#1F293D] space-y-2">
            <div className="flex justify-between font-bold text-white border-b border-[#1F293D] pb-2">
              <span>Card (VISA / Mastercard / Apple Pay)</span>
              <span className="text-white">1.8% Fee</span>
            </div>
            <p className="text-slate-400 text-[11px]">Instant card purchase authorization for immediate trading.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
