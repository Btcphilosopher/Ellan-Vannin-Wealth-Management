import React, { useState } from 'react';
import { useExchange } from '../context/ExchangeContext';
import { ShieldCheck, Building2, Lock, ArrowRight, CheckCircle2 } from 'lucide-react';

export const OtcPage: React.FC = () => {
  const { addToast } = useExchange();

  const [tradeAmount, setTradeAmount] = useState<string>('250000');
  const [tradeSide, setTradeSide] = useState<'buy' | 'sell'>('buy');
  const [asset, setAsset] = useState<'BTC' | 'ETH' | 'SOL'>('BTC');
  const [submitted, setSubmitted] = useState<boolean>(false);

  const [form, setForm] = useState({
    institutionName: '',
    contactName: '',
    email: '',
    phone: '',
    notes: '',
  });

  const btcPrice = 75386.21;
  const estimatedCoins = (parseFloat(tradeAmount || '0') / btcPrice).toFixed(4);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.contactName || !form.email) {
      addToast('Missing Details', 'Please provide your contact name and email address.', 'error');
      return;
    }
    setSubmitted(true);
    addToast(
      'OTC Request Received',
      'An Isle of Man OTC Desk Manager has been assigned to your order request.',
      'success'
    );
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-8 relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 opacity-10 pointer-events-none">
          <Building2 className="w-80 h-80 text-[#D9A441]" />
        </div>

        <div className="max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D9A441]/10 border border-[#D9A441]/30 text-[#D9A441] text-xs font-semibold">
            <ShieldCheck className="w-4 h-4" />
            Isle of Man Institutional Principal Desk
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Institutional OTC Desk
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Execute large-volume digital asset block trades starting from £100,000 with zero market slippage, deep principal liquidity, and same-day GBP/EUR/USD fiat settlement via Isle of Man banking infrastructure.
          </p>
        </div>
      </div>

      {/* Grid: Quote Calculator & Enquiry Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Quote Calculator */}
        <div className="lg:col-span-5 bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 space-y-6">
          <h3 className="text-lg font-bold text-white tracking-wide border-b border-[#1F293D] pb-3">
            Instant OTC Quote Indicative
          </h3>

          <div className="space-y-4">
            {/* Side */}
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1.5">Trade Direction</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setTradeSide('buy')}
                  className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                    tradeSide === 'buy'
                      ? 'bg-emerald-500 text-black border-emerald-400'
                      : 'bg-[#0A0D14] text-slate-400 border-[#1F293D]'
                  }`}
                >
                  Buy Asset
                </button>
                <button
                  type="button"
                  onClick={() => setTradeSide('sell')}
                  className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                    tradeSide === 'sell'
                      ? 'bg-red-500 text-white border-red-400'
                      : 'bg-[#0A0D14] text-slate-400 border-[#1F293D]'
                  }`}
                >
                  Sell Asset
                </button>
              </div>
            </div>

            {/* Amount */}
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1.5">Notional Value (GBP)</label>
              <input
                type="number"
                value={tradeAmount}
                onChange={(e) => setTradeAmount(e.target.value)}
                min="100000"
                step="50000"
                className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white font-mono font-bold text-lg px-4 py-3 rounded-xl focus:outline-none"
              />
              <p className="text-[11px] text-slate-400 mt-1">Minimum trade size: £100,000 GBP</p>
            </div>

            {/* Estimated Output */}
            <div className="p-4 bg-[#0A0D14] rounded-xl border border-[#1F293D] space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Indicative Execution Rate:</span>
                <span className="font-mono text-white">£{btcPrice.toLocaleString()} / BTC</span>
              </div>
              <div className="flex justify-between text-xs text-slate-400">
                <span>Estimated Coins:</span>
                <span className="font-mono text-emerald-400 font-bold">{estimatedCoins} BTC</span>
              </div>
              <div className="flex justify-between text-xs text-slate-400">
                <span>Slippage Protection:</span>
                <span className="text-[#D9A441] font-semibold">0.00% (Guaranteed)</span>
              </div>
            </div>

            <div className="p-3 bg-[#D9A441]/10 border border-[#D9A441]/30 rounded-xl text-xs text-[#D9A441] leading-relaxed">
              <strong>Isle of Man Custody:</strong> Assets settled directly to air-gapped cold storage vaults under multi-signature security.
            </div>
          </div>
        </div>

        {/* Enquiry Form */}
        <div className="lg:col-span-7 bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6">
          <h3 className="text-lg font-bold text-white tracking-wide border-b border-[#1F293D] pb-3 mb-6">
            Institutional Account Representative Contact
          </h3>

          {submitted ? (
            <div className="py-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-xl font-bold text-white">Request Submitted</h4>
              <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                Thank you, {form.contactName}. Your dedicated Isle of Man OTC relationship manager has received your inquiry for £{parseFloat(tradeAmount || '0').toLocaleString()} GBP notional trade.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="px-6 py-2.5 bg-[#121722] border border-[#1F293D] text-white font-semibold text-xs rounded-xl hover:bg-slate-800 transition-colors"
              >
                Submit Another Request
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-400 block mb-1">Institution / Entity Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Douglas Capital Partners Ltd"
                    value={form.institutionName}
                    onChange={(e) => setForm({ ...form, institutionName: e.target.value })}
                    className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs px-3.5 py-2.5 rounded-xl focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-400 block mb-1">Contact Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Your Full Name"
                    value={form.contactName}
                    onChange={(e) => setForm({ ...form, contactName: e.target.value })}
                    className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs px-3.5 py-2.5 rounded-xl focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-400 block mb-1">Corporate Email</label>
                  <input
                    type="email"
                    required
                    placeholder="name@company.com"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs px-3.5 py-2.5 rounded-xl focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-400 block mb-1">Phone / Telegram ID</label>
                  <input
                    type="text"
                    placeholder="+44 1624 000000"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs px-3.5 py-2.5 rounded-xl focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-400 block mb-1">Specific Settlement Instructions / Notes</label>
                <textarea
                  rows={3}
                  placeholder="Include preferred fiat bank transfer currency, timing, or custody arrangements..."
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white text-xs p-3 rounded-xl focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-gradient-to-r from-[#E5B354] via-[#D9A441] to-[#C49033] hover:from-[#F0C067] hover:to-[#D9A441] text-[#0A0D14] font-bold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <span>Request Custom OTC Block Trade Quote</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
