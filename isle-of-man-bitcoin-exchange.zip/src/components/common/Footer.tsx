import React from 'react';
import { useExchange } from '../../context/ExchangeContext';
import { BrandHeader } from './TriskelionLogo';
import { IomMapGraphic } from './IomMapGraphic';
import { Twitter, Send, MessageSquare, ShieldAlert } from 'lucide-react';

export const Footer: React.FC = () => {
  const { navigateTo } = useExchange();

  return (
    <footer className="bg-[#07090E] border-t border-[#1F293D] text-slate-400 text-sm pt-12 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8 pb-12 border-b border-[#1F293D]/60">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <BrandHeader onClick={() => navigateTo('home')} />
            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              The premier Isle of Man regulated digital asset exchange providing institutional liquidity, bank-grade security, and sovereign Bitcoin custody for discerning global investors.
            </p>
            <div className="flex items-center gap-2 text-xs text-[#D9A441] bg-[#D9A441]/10 border border-[#D9A441]/20 px-3 py-1.5 rounded-lg w-fit">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Regulated under Isle of Man Financial Services Authority framework</span>
            </div>
          </div>

          {/* Company Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Company</h4>
            <ul className="space-y-2 text-xs">
              <li><button onClick={() => navigateTo('about')} className="hover:text-[#D9A441] transition-colors">About Us</button></li>
              <li><button onClick={() => navigateTo('about')} className="hover:text-[#D9A441] transition-colors">Careers</button></li>
              <li><button onClick={() => navigateTo('about')} className="hover:text-[#D9A441] transition-colors">Press & Media</button></li>
              <li><button onClick={() => navigateTo('otc')} className="hover:text-[#D9A441] transition-colors">Institutional OTC</button></li>
            </ul>
          </div>

          {/* Support Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Support</h4>
            <ul className="space-y-2 text-xs">
              <li><button onClick={() => navigateTo('support')} className="hover:text-[#D9A441] transition-colors">Help Center</button></li>
              <li><button onClick={() => navigateTo('support')} className="hover:text-[#D9A441] transition-colors">Contact Us</button></li>
              <li><button onClick={() => navigateTo('status')} className="hover:text-[#D9A441] transition-colors">System Status</button></li>
              <li><button onClick={() => navigateTo('security')} className="hover:text-[#D9A441] transition-colors">Security Centre</button></li>
            </ul>
          </div>

          {/* Legal Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Legal</h4>
            <ul className="space-y-2 text-xs">
              <li><button onClick={() => navigateTo('legal-terms')} className="hover:text-[#D9A441] transition-colors">Terms of Service</button></li>
              <li><button onClick={() => navigateTo('legal-privacy')} className="hover:text-[#D9A441] transition-colors">Privacy Policy</button></li>
              <li><button onClick={() => navigateTo('legal-terms')} className="hover:text-[#D9A441] transition-colors">Risk Disclosure</button></li>
              <li><button onClick={() => navigateTo('fees')} className="hover:text-[#D9A441] transition-colors">Regulatory Compliance</button></li>
            </ul>
          </div>

          {/* Community & Island Silhouette */}
          <div className="space-y-3 relative">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Join our community</h4>
            <div className="flex items-center gap-2">
              <a href="#twitter" aria-label="Twitter" className="p-2 bg-[#121722] hover:bg-[#D9A441] hover:text-[#0A0D14] border border-[#1F293D] rounded-lg transition-all text-slate-300">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#telegram" aria-label="Telegram" className="p-2 bg-[#121722] hover:bg-[#D9A441] hover:text-[#0A0D14] border border-[#1F293D] rounded-lg transition-all text-slate-300">
                <Send className="w-4 h-4" />
              </a>
              <a href="#discord" aria-label="Discord" className="p-2 bg-[#121722] hover:bg-[#D9A441] hover:text-[#0A0D14] border border-[#1F293D] rounded-lg transition-all text-slate-300">
                <MessageSquare className="w-4 h-4" />
              </a>
              <a href="#btc" aria-label="Bitcoin" className="p-2 bg-[#121722] hover:bg-[#D9A441] hover:text-[#0A0D14] border border-[#1F293D] text-[#D9A441] font-bold text-xs rounded-lg transition-all">
                ₿
              </a>
            </div>

            <p className="text-xs text-slate-400 font-medium pt-1">
              Secure. Sovereign. Built for Freedom.
            </p>

            <div className="mt-4 flex justify-end">
              <IomMapGraphic className="w-28 h-32" />
            </div>
          </div>
        </div>

        {/* Bottom copyright line */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© 2026 Isle of Man Bitcoin Exchange. All rights reserved.</p>
          <p className="text-slate-400">
            Registered with the Isle of Man Financial Services Authority under the Designated Businesses Act.
          </p>
        </div>
      </div>
    </footer>
  );
};
