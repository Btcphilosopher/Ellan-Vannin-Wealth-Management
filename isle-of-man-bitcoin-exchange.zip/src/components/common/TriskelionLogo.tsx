import React from 'react';

interface TriskelionLogoProps {
  className?: string;
  size?: number;
}

export const TriskelionLogo: React.FC<TriskelionLogoProps> = ({ className = "w-8 h-8", size = 32 }) => {
  return (
    <div className={`inline-flex items-center gap-2.5 ${className}`}>
      {/* Golden Isle of Man Triskelion SVG */}
      <svg 
        width={size} 
        height={size} 
        viewBox="0 0 100 100" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="text-[#D9A441] drop-shadow-[0_0_8px_rgba(217,164,65,0.3)] shrink-0"
      >
        <circle cx="50" cy="50" r="46" stroke="url(#goldGradient)" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.4" />
        <circle cx="50" cy="50" r="40" stroke="url(#goldGradient)" strokeWidth="1" opacity="0.2" />
        
        {/* Core Triskelion Legs Geometry */}
        <g stroke="url(#goldGradient)" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
          {/* Leg 1 - Upward Right */}
          <path d="M50 50 L50 26 Q50 18 62 18 L70 24 Q76 28 72 36 L62 44" />
          <path d="M62 18 L68 12" strokeWidth="2.5" />
          
          {/* Leg 2 - Downward Right */}
          <path d="M50 50 L71 62 Q78 66 72 77 L66 84 Q60 88 52 82 L46 70" />
          <path d="M72 77 L80 81" strokeWidth="2.5" />

          {/* Leg 3 - Downward Left */}
          <path d="M50 50 L29 62 Q22 66 16 55 L14 46 Q12 38 22 38 L36 42" />
          <path d="M16 55 L8 57" strokeWidth="2.5" />
        </g>

        {/* Center Golden Pivot */}
        <circle cx="50" cy="50" r="4.5" fill="url(#goldGradient)" />
        <circle cx="50" cy="50" r="2" fill="#0A0D14" />

        <defs>
          <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F5C870" />
            <stop offset="50%" stopColor="#D9A441" />
            <stop offset="100%" stopColor="#9E7324" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};

export const BrandHeader: React.FC<{ onClick?: () => void }> = ({ onClick }) => {
  return (
    <div 
      onClick={onClick}
      className="flex items-center gap-2.5 cursor-pointer select-none group"
    >
      <TriskelionLogo size={36} />
      <div className="flex flex-col">
        <span className="text-white font-bold tracking-[0.18em] text-[15px] leading-tight group-hover:text-[#F0C067] transition-colors">
          ISLE OF MAN
        </span>
        <span className="text-[#D9A441] text-[9.5px] font-semibold tracking-[0.28em] uppercase leading-tight opacity-90">
          BITCOIN EXCHANGE
        </span>
      </div>
    </div>
  );
};
