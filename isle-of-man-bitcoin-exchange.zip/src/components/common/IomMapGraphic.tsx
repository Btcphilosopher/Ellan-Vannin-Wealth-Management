import React from 'react';

export const IomMapGraphic: React.FC<{ className?: string }> = ({ className = "w-32 h-32" }) => {
  return (
    <div className={`relative ${className} opacity-80 hover:opacity-100 transition-opacity`}>
      <svg 
        viewBox="0 0 160 220" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-[0_0_12px_rgba(217,164,65,0.25)]"
      >
        {/* Island Polygon Outline */}
        <path 
          d="M75 12 L90 28 L105 45 L120 70 L135 105 L145 135 L130 165 L110 190 L95 205 L70 195 L50 170 L35 140 L25 110 L30 80 L45 50 L60 25 Z" 
          fill="url(#mapGradient)" 
          stroke="#D9A441" 
          strokeWidth="1.2"
          strokeDasharray="4 2"
        />

        {/* Topographic Lines */}
        <path d="M60 40 Q85 60 110 90 T125 140" stroke="#D9A441" strokeWidth="0.5" opacity="0.4" />
        <path d="M45 70 Q75 90 100 125 T110 170" stroke="#D9A441" strokeWidth="0.5" opacity="0.3" />
        
        {/* Financial Capital Node - Douglas */}
        <circle cx="115" cy="115" r="4" fill="#D9A441" />
        <circle cx="115" cy="115" r="8" stroke="#F0C067" strokeWidth="1" opacity="0.6">
          <animate attributeName="r" values="4;12;4" dur="3s" repeatCount="indefinite" />
          <animate attributeName="opacity" values="0.8;0;0.8" dur="3s" repeatCount="indefinite" />
        </circle>
        
        {/* Point of Ayre Lighthouse Node - North */}
        <circle cx="78" cy="20" r="3" fill="#F0C067" />
        
        {/* Peel Node - West */}
        <circle cx="35" cy="110" r="2.5" fill="#D9A441" opacity="0.8" />

        <defs>
          <linearGradient id="mapGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#D9A441" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#0A0D14" stopOpacity="0.4" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};
