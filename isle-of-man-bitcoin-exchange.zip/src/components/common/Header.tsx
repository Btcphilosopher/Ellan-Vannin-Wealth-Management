import React, { useState } from 'react';
import { useExchange } from '../../context/ExchangeContext';
import { BrandHeader } from './TriskelionLogo';
import { 
  ChevronDown, 
  Menu, 
  X, 
  Sun, 
  User, 
  LogOut, 
  ShieldCheck, 
  Wallet,
  Activity
} from 'lucide-react';

export const Header: React.FC = () => {
  const { 
    currentPage, 
    navigateTo, 
    isLoggedIn, 
    user, 
    logout 
  } = useExchange();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isEarnDropdownOpen, setIsEarnDropdownOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const navLinks = [
    { id: 'trade', label: 'Trade' },
    { id: 'markets', label: 'Markets' },
    { id: 'otc', label: 'OTC Desk' },
    { id: 'earn', label: 'Earn', hasDropdown: true },
    { id: 'about', label: 'About IOM' },
    { id: 'security', label: 'Security' },
    { id: 'fees', label: 'Fees' },
  ];

  const handleNavClick = (id: string) => {
    navigateTo(id);
    setIsMobileMenuOpen(false);
    setIsEarnDropdownOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0A0B10]/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <BrandHeader onClick={() => navigateTo('home')} />

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-3 text-[11px] font-semibold uppercase tracking-wider">
            {navLinks.map((link) => {
              const isActive = currentPage === link.id;

              if (link.hasDropdown) {
                return (
                  <div key={link.id} className="relative group">
                    <button
                      onClick={() => setIsEarnDropdownOpen(!isEarnDropdownOpen)}
                      onMouseEnter={() => setIsEarnDropdownOpen(true)}
                      className={`flex items-center gap-1 px-2.5 py-1.5 transition-colors rounded ${
                        isActive
                          ? 'text-[#D9A441] font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {link.label}
                      <ChevronDown className="w-3 h-3 opacity-70 group-hover:rotate-180 transition-transform duration-200" />
                    </button>

                    {/* Earn Dropdown */}
                    {isEarnDropdownOpen && (
                      <div 
                        onMouseLeave={() => setIsEarnDropdownOpen(false)}
                        className="absolute top-full left-0 mt-1 w-56 bg-[#111319] border border-white/10 rounded-md shadow-2xl py-2 z-50 animate-in fade-in duration-150 text-normal lowercase tracking-normal"
                      >
                        <button
                          onClick={() => handleNavClick('earn')}
                          className="w-full text-left px-4 py-2 text-xs text-slate-200 hover:bg-white/5 hover:text-[#D9A441] transition-colors flex flex-col"
                        >
                          <span className="font-semibold">Bitcoin Stacking Vault</span>
                          <span className="text-[10px] text-slate-400">Earn up to 6.8% APY on BTC</span>
                        </button>
                        <button
                          onClick={() => handleNavClick('earn')}
                          className="w-full text-left px-4 py-2 text-xs text-slate-200 hover:bg-white/5 hover:text-[#D9A441] transition-colors flex flex-col"
                        >
                          <span className="font-semibold">Flexible Staking</span>
                          <span className="text-[10px] text-slate-400">Instant withdrawal liquidity</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              }

              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`px-2.5 py-1.5 transition-colors rounded ${
                    isActive
                      ? 'text-[#D9A441] font-bold bg-white/5 border border-white/10'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls */}
          <div className="hidden md:flex items-center space-x-3">
            {/* Status indicator pill */}
            <button 
              onClick={() => navigateTo('status')}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/5 border border-white/10 text-emerald-400 text-[10px] font-bold tracking-wider uppercase hover:bg-white/10 transition-colors"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Nodes 100%</span>
            </button>

            {/* Auth Buttons */}
            {!isLoggedIn ? (
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => navigateTo('login')}
                  className="text-[11px] font-bold uppercase tracking-widest text-slate-400 hover:text-white px-3 py-1.5 transition-colors"
                >
                  Log In
                </button>
                <button
                  onClick={() => navigateTo('signup')}
                  className="bg-[#D9A441] text-black text-[11px] font-bold uppercase tracking-widest px-5 py-2 rounded-sm shadow-[0_0_15px_rgba(217,164,65,0.3)] hover:brightness-110 active:scale-95 transition-all"
                >
                  Sign Up
                </button>
              </div>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-[#121722] border border-[#1F293D] hover:border-[#D9A441]/60 rounded-xl transition-all"
                >
                  <div className="w-7 h-7 rounded-full bg-[#D9A441]/20 border border-[#D9A441] flex items-center justify-center text-[#D9A441] font-bold text-xs">
                    EC
                  </div>
                  <div className="text-left hidden lg:block">
                    <div className="text-xs font-bold text-white leading-tight">{user.fullName}</div>
                    <div className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Tier 2 Verified
                    </div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* User Profile Dropdown */}
                {isUserMenuOpen && (
                  <div 
                    onMouseLeave={() => setIsUserMenuOpen(false)}
                    className="absolute right-0 mt-2 w-64 bg-[#121722] border border-[#1F293D] rounded-xl shadow-2xl py-3 z-50 text-slate-200"
                  >
                    <div className="px-4 pb-2 border-b border-[#1F293D]">
                      <p className="text-xs font-semibold text-slate-400">ACCOUNT & BALANCES</p>
                      <p className="text-sm font-bold text-white mt-1">{user.email}</p>
                      <div className="mt-2 p-2 bg-[#0A0D14] rounded-lg border border-[#1F293D]/60 flex items-center justify-between">
                        <span className="text-xs text-slate-400 flex items-center gap-1">
                          <Wallet className="w-3.5 h-3.5 text-[#D9A441]" /> Total Fiat
                        </span>
                        <span className="text-xs font-mono font-bold text-emerald-400">
                          £{user.wallet.gbpBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="mt-1 p-2 bg-[#0A0D14] rounded-lg border border-[#1F293D]/60 flex items-center justify-between">
                        <span className="text-xs text-slate-400 flex items-center gap-1">
                          <Activity className="w-3.5 h-3.5 text-[#D9A441]" /> Bitcoin
                        </span>
                        <span className="text-xs font-mono font-bold text-white">
                          {user.wallet.btcBalance.toFixed(4)} BTC
                        </span>
                      </div>
                    </div>

                    <div className="py-1">
                      <button
                        onClick={() => { navigateTo('trade'); setIsUserMenuOpen(false); }}
                        className="w-full text-left px-4 py-2 text-sm hover:bg-[#1C2436] hover:text-[#D9A441] flex items-center gap-2"
                      >
                        <User className="w-4 h-4 text-slate-400" /> Trading Terminal
                      </button>
                      <button
                        onClick={() => { navigateTo('security'); setIsUserMenuOpen(false); }}
                        className="w-full text-left px-4 py-2 text-sm hover:bg-[#1C2436] hover:text-[#D9A441] flex items-center gap-2"
                      >
                        <ShieldCheck className="w-4 h-4 text-slate-400" /> Security & 2FA
                      </button>
                    </div>

                    <div className="pt-2 border-t border-[#1F293D]">
                      <button
                        onClick={() => { logout(); setIsUserMenuOpen(false); }}
                        className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-red-500/10 flex items-center gap-2 transition-colors"
                      >
                        <LogOut className="w-4 h-4" /> Log Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Theme / settings icon */}
            <button
              className="p-2 text-slate-400 hover:text-[#D9A441] hover:bg-slate-800/40 rounded-lg transition-colors"
              title="Toggle Theme"
            >
              <Sun className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800/60 rounded-lg"
              aria-label="Toggle navigation menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6 text-[#D9A441]" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-[#0D121D] border-b border-[#1F293D] px-4 pt-2 pb-6 space-y-3 animate-in slide-in-from-top-2">
          <div className="grid grid-cols-2 gap-2 pt-2 pb-3 border-b border-[#1F293D]">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`text-left px-3 py-2 text-sm font-medium rounded-lg ${
                  currentPage === link.id
                    ? 'text-[#D9A441] bg-[#D9A441]/10 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/40'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          {!isLoggedIn ? (
            <div className="flex flex-col gap-2 pt-2">
              <button
                onClick={() => handleNavClick('login')}
                className="w-full py-2.5 text-sm font-semibold text-slate-200 bg-[#121722] border border-[#1F293D] rounded-xl text-center"
              >
                Log In
              </button>
              <button
                onClick={() => handleNavClick('signup')}
                className="w-full py-2.5 text-sm font-bold text-[#0A0D14] bg-[#D9A441] rounded-xl text-center shadow-lg"
              >
                Sign Up
              </button>
            </div>
          ) : (
            <div className="pt-2 border-t border-[#1F293D] space-y-2">
              <div className="p-3 bg-[#121722] rounded-xl border border-[#1F293D] flex items-center justify-between">
                <span className="text-xs text-slate-400">Balance (GBP)</span>
                <span className="text-sm font-mono font-bold text-emerald-400">
                  £{user.wallet.gbpBalance.toLocaleString()}
                </span>
              </div>
              <button
                onClick={() => { logout(); setIsMobileMenuOpen(false); }}
                className="w-full py-2 text-sm font-semibold text-red-400 bg-red-500/10 rounded-xl text-center"
              >
                Log Out
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
