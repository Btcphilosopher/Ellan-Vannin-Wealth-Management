import React from 'react';
import { useExchange } from '../../context/ExchangeContext';
import { Modal } from './Modal';
import { ShieldCheck, ExternalLink } from 'lucide-react';

export const VideoModal: React.FC = () => {
  const { isVideoModalOpen, setIsVideoModalOpen } = useExchange();

  return (
    <Modal
      isOpen={isVideoModalOpen}
      onClose={() => setIsVideoModalOpen(false)}
      title="Isle of Man: Global Digital Finance Hub"
      maxWidth="max-w-3xl"
    >
      <div className="space-y-4">
        {/* Simulated Video Player Box */}
        <div className="relative aspect-video rounded-xl overflow-hidden bg-black border border-[#1F293D] flex items-center justify-center">
          <iframe 
            className="w-full h-full"
            src="https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?autoplay=0" 
            title="Isle of Man Financial Services Hub"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
            allowFullScreen
          />
        </div>

        <div className="p-4 rounded-xl bg-[#0A0D14] border border-[#1F293D] space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-[#D9A441]">
            <ShieldCheck className="w-4 h-4" />
            <span>Isle of Man Financial Services Authority (IOM FSA)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The Isle of Man is a self-governing British Crown Dependency known for its political stability, robust legal system based on English Common Law, and progressive digital asset regulatory framework.
          </p>
          <div className="pt-2 flex items-center justify-between text-xs">
            <span className="text-slate-400">Zero Capital Gains Tax • Statutory Insolvency Protections</span>
            <a 
              href="https://www.iomfsa.im" 
              target="_blank" 
              rel="noreferrer"
              className="text-[#D9A441] hover:underline flex items-center gap-1 font-semibold"
            >
              Official IOM FSA Portal <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    </Modal>
  );
};
