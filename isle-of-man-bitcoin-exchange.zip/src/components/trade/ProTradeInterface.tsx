import React, { useState } from 'react';
import { useExchange } from '../../context/ExchangeContext';
import { MainCandleChart } from '../home/MainCandleChart';
import { OrderBookPanel } from '../home/OrderBookPanel';
import { TradeOrderKind } from '../../types';
import { TrendingUp, Wallet, ShieldCheck, Trash2 } from 'lucide-react';

export const ProTradeInterface: React.FC = () => {
  const { 
    markets, 
    selectedPair, 
    setSelectedPairById, 
    recentTrades, 
    activeOrders, 
    cancelOrder, 
    placeProOrder, 
    user,
    isLoggedIn,
    navigateTo
  } = useExchange();

  const [orderSide, setOrderSide] = useState<'buy' | 'sell'>('buy');
  const [orderKind, setOrderKind] = useState<TradeOrderKind>('limit');
  const [priceInput, setPriceInput] = useState<string>(selectedPair.price.toString());
  const [amountInput, setAmountInput] = useState<string>('0.1');

  const numericPrice = parseFloat(priceInput) || selectedPair.price;
  const numericAmount = parseFloat(amountInput) || 0;
  const totalValue = numericPrice * numericAmount;

  const handlePriceChange = (val: string) => {
    if (val === '' || /^\d*\.?\d*$/.test(val)) {
      setPriceInput(val);
    }
  };

  const handleAmountChange = (val: string) => {
    if (val === '' || /^\d*\.?\d*$/.test(val)) {
      setAmountInput(val);
    }
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isLoggedIn) {
      navigateTo('login');
      return;
    }
    if (numericAmount <= 0) return;

    placeProOrder(orderSide, orderKind, numericPrice, numericAmount);
  };

  return (
    <div className="space-y-4">
      {/* Top Pair Selector Bar */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2 overflow-x-auto custom-scrollbar pb-1 sm:pb-0">
          {markets.map((m) => (
            <button
              key={m.id}
              onClick={() => {
                setSelectedPairById(m.id);
                setPriceInput(m.price.toString());
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-2 border transition-all shrink-0 ${
                selectedPair.id === m.id
                  ? 'bg-[#1C2436] text-[#D9A441] border-[#D9A441]'
                  : 'bg-[#0A0D14]/60 text-slate-300 border-[#1F293D] hover:border-slate-600'
              }`}
            >
              <span>{m.symbol}</span>
              <span className="text-white">£{m.price.toLocaleString()}</span>
              <span className={`text-[10px] ${m.change24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {m.change24h >= 0 ? '+' : ''}{m.change24h}%
              </span>
            </button>
          ))}
        </div>

        {/* Selected pair details pill */}
        <div className="hidden xl:flex items-center gap-6 text-xs font-mono text-slate-400 border-l border-[#1F293D] pl-4">
          <div>
            <span className="text-slate-500 block text-[10px]">24h High</span>
            <span className="text-slate-200 font-bold">£{selectedPair.high24h.toLocaleString()}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">24h Low</span>
            <span className="text-slate-200 font-bold">£{selectedPair.low24h.toLocaleString()}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">24h Volume</span>
            <span className="text-slate-200 font-bold">£{(selectedPair.volume24h / 1000000).toFixed(2)}M</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Chart + Order Form (Left/Center) & Order Book + Recent Trades (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* Left/Center Area (Chart + Trade Entry) */}
        <div className="lg:col-span-8 space-y-4">
          {/* Chart Panel */}
          <div className="min-h-[360px]">
            <MainCandleChart />
          </div>

          {/* Trade Entry Panel */}
          <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#1F293D] pb-3">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setOrderSide('buy')}
                  className={`px-5 py-2 font-bold text-xs rounded-xl transition-all ${
                    orderSide === 'buy'
                      ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20'
                      : 'bg-[#121722] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Buy {selectedPair.base}
                </button>
                <button
                  onClick={() => setOrderSide('sell')}
                  className={`px-5 py-2 font-bold text-xs rounded-xl transition-all ${
                    orderSide === 'sell'
                      ? 'bg-red-500 text-white shadow-lg shadow-red-500/20'
                      : 'bg-[#121722] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Sell {selectedPair.base}
                </button>
              </div>

              {/* Order Kind Tabs */}
              <div className="flex items-center gap-2 bg-[#0A0D14] border border-[#1F293D] p-1 rounded-xl text-xs font-semibold">
                <button
                  onClick={() => setOrderKind('limit')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    orderKind === 'limit' ? 'bg-[#1C2436] text-[#D9A441]' : 'text-slate-400'
                  }`}
                >
                  Limit
                </button>
                <button
                  onClick={() => setOrderKind('market')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    orderKind === 'market' ? 'bg-[#1C2436] text-[#D9A441]' : 'text-slate-400'
                  }`}
                >
                  Market
                </button>
                <button
                  onClick={() => setOrderKind('stop_limit')}
                  className={`px-3 py-1 rounded-lg transition-all ${
                    orderKind === 'stop_limit' ? 'bg-[#1C2436] text-[#D9A441]' : 'text-slate-400'
                  }`}
                >
                  Stop
                </button>
              </div>
            </div>

            {/* Inputs Form */}
            <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Price Input */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400">Order Price (GBP)</label>
                <input
                  type="text"
                  disabled={orderKind === 'market'}
                  value={orderKind === 'market' ? selectedPair.price.toString() : priceInput}
                  onChange={(e) => handlePriceChange(e.target.value)}
                  className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white font-mono font-bold text-sm px-3 py-2.5 rounded-xl focus:outline-none disabled:opacity-50"
                />
              </div>

              {/* Amount Input */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-400">Amount ({selectedPair.base})</label>
                <input
                  type="text"
                  value={amountInput}
                  onChange={(e) => handleAmountChange(e.target.value)}
                  className="w-full bg-[#0A0D14] border border-[#1F293D] focus:border-[#D9A441] text-white font-mono font-bold text-sm px-3 py-2.5 rounded-xl focus:outline-none"
                />
              </div>

              {/* Total & Submit */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-400 font-semibold">
                  <span>Total Value</span>
                  <span className="font-mono text-white">£{totalValue.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                </div>
                <button
                  type="submit"
                  className={`w-full py-2.5 font-bold text-xs rounded-xl shadow-lg transition-all ${
                    orderSide === 'buy'
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-black hover:from-emerald-400'
                      : 'bg-gradient-to-r from-red-500 to-rose-600 text-white hover:from-red-400'
                  }`}
                >
                  {orderSide === 'buy' ? 'Place Buy Order' : 'Place Sell Order'}
                </button>
              </div>
            </form>

            {/* Wallet Balance Bar */}
            <div className="p-3 bg-[#0A0D14] rounded-xl border border-[#1F293D] flex flex-wrap items-center justify-between text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-[#D9A441]" />
                <span>Available Balances:</span>
              </div>
              <div className="flex items-center gap-4 font-mono font-bold">
                <span className="text-emerald-400">£{user.wallet.gbpBalance.toLocaleString()} GBP</span>
                <span className="text-white">{user.wallet.btcBalance.toFixed(4)} BTC</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar: Order Book & Recent Trades */}
        <div className="lg:col-span-4 space-y-4">
          <div className="h-[380px]">
            <OrderBookPanel />
          </div>

          {/* Recent Trades Table */}
          <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-4 space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2">Market Trades</h4>
            <div className="grid grid-cols-3 text-[10px] font-bold text-slate-400 uppercase border-b border-[#1F293D] pb-1">
              <span>Price (GBP)</span>
              <span className="text-right">Amount</span>
              <span className="text-right">Time</span>
            </div>
            <div className="space-y-1 font-mono text-[11px] max-h-36 overflow-y-auto custom-scrollbar">
              {recentTrades.map((t) => (
                <div key={t.id} className="grid grid-cols-3 py-0.5">
                  <span className={t.type === 'buy' ? 'text-emerald-400' : 'text-red-400'}>
                    £{t.price.toLocaleString()}
                  </span>
                  <span className="text-right text-slate-300">{t.amount}</span>
                  <span className="text-right text-slate-500">{t.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* Active Orders Section */}
      <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#1F293D] pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#D9A441]" />
            Active Limit Orders ({activeOrders.length})
          </h3>
        </div>

        {activeOrders.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-400">No active limit orders currently pending.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead className="text-[10px] text-slate-400 uppercase border-b border-[#1F293D] pb-2">
                <tr>
                  <th className="py-2">Order ID</th>
                  <th className="py-2">Pair</th>
                  <th className="py-2">Side</th>
                  <th className="py-2">Price</th>
                  <th className="py-2">Amount</th>
                  <th className="py-2">Created</th>
                  <th className="py-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F293D]/60 text-slate-200">
                {activeOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-800/30">
                    <td className="py-2.5 font-bold text-white">{ord.id}</td>
                    <td className="py-2.5">{ord.pair}</td>
                    <td className={`py-2.5 uppercase font-bold ${ord.side === 'buy' ? 'text-emerald-400' : 'text-red-400'}`}>
                      {ord.side}
                    </td>
                    <td className="py-2.5">£{ord.price.toLocaleString()}</td>
                    <td className="py-2.5">{ord.amount} BTC</td>
                    <td className="py-2.5 text-slate-400 text-[11px]">{ord.createdAt}</td>
                    <td className="py-2.5 text-right">
                      <button
                        onClick={() => cancelOrder(ord.id)}
                        className="p-1 text-slate-400 hover:text-red-400 transition-colors"
                        title="Cancel order"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
