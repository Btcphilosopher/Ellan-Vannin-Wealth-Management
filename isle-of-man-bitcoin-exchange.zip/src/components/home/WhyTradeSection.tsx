import React from 'react';
import { ShieldCheck, Lock, Landmark, Cpu } from 'lucide-react';

export const WhyTradeSection: React.FC = () => {
  const reasons = [
    {
      icon: ShieldCheck,
      title: 'Regulated in the Isle of Man',
      description: 'Trusted jurisdiction with strong financial oversight and statutory stability.',
    },
    {
      icon: Lock,
      title: 'Security First',
      description: 'Industry-leading security, air-gapped multi-sig cold storage, and risk management.',
    },
    {
      icon: Landmark,
      title: 'Sovereignty & Privacy',
      description: 'Respecting your rights. No unnecessary KYC or invasive data sharing.',
    },
    {
      icon: Cpu,
      title: 'Built for Bitcoiners',
      description: 'Designed by Bitcoiners, for Bitcoiners, with zero compromises on performance.',
    },
  ];

  return (
    <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-6 h-full flex flex-col justify-between">
      <h3 className="text-lg font-bold text-white tracking-wide mb-5 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#D9A441]" />
        Why Trade with Us?
      </h3>

      <div className="space-y-4">
        {reasons.map((item, index) => {
          const IconComponent = item.icon;
          return (
            <div key={index} className="flex items-start gap-3.5 p-3 rounded-xl bg-[#0A0D14]/60 border border-[#1F293D]/60 hover:border-[#D9A441]/40 transition-colors">
              <div className="p-2 rounded-lg bg-[#D9A441]/10 text-[#D9A441] border border-[#D9A441]/20 shrink-0 mt-0.5">
                <IconComponent className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white tracking-wide">{item.title}</h4>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">{item.description}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
