import React from 'react';
import { useExchange } from '../../context/ExchangeContext';
import { TradingWidget } from './TradingWidget';
import { ShieldCheck, Lock, Zap, ArrowRight } from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { navigateTo } = useExchange();

  return (
    <section className="relative pt-8 pb-12 overflow-hidden bg-[#0A0B10]">
      {/* Background Ambient Glow & Light Overlay */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-20">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gradient-to-bl from-[#D9A441]/20 to-transparent rounded-full blur-[120px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-gradient-to-tr from-blue-900/30 to-transparent rounded-full blur-[100px]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Text & CTA */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Tag Badges */}
            <div className="mb-4 flex flex-wrap gap-2.5">
              <span className="text-[10px] bg-white/5 border border-white/10 px-2.5 py-1 rounded text-[#D9A441] font-bold tracking-tighter uppercase">
                IOM Regulated
              </span>
              <span className="text-[10px] bg-white/5 border border-white/10 px-2.5 py-1 rounded text-slate-400 font-bold tracking-tighter uppercase">
                Cold Storage
              </span>
              <span className="text-[10px] bg-white/5 border border-white/10 px-2.5 py-1 rounded text-emerald-400 font-bold tracking-tighter uppercase">
                100% Solvency
              </span>
            </div>

            {/* Immersive Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light leading-[1.1] mb-6 text-white tracking-tight">
              Trade Bitcoin on the <br />
              <span className="font-serif italic text-[#D9A441]">Isle of Man</span>
            </h1>

            <p className="text-slate-400 text-base sm:text-lg max-w-lg mb-8 leading-relaxed">
              Experience sovereign digital finance with institutional-grade security and low fees from a premier global hub.
            </p>

            {/* Live Ticker Stats Row */}
            <div className="flex flex-wrap items-center gap-6 sm:gap-8 py-5 border-y border-white/10 mb-8">
              <div>
                <div className="text-[10px] uppercase tracking-widest text-slate-500 mb-1 font-semibold">
                  BTC / GBP Price
                </div>
                <div className="text-xl font-mono text-[#D9A441] tracking-tight font-bold">
                  £75,386.21 <span className="text-emerald-400 text-xs ml-2 font-normal">+3.42%</span>
                </div>
              </div>

              <div className="hidden sm:block w-px h-10 bg-white/10" />

              <div>
                <div className="text-[10px] uppercase tracking-widest text-slate-500 mb-1 font-semibold">
                  24H Volume
                </div>
                <div className="text-xl font-mono tracking-tight text-white font-bold">
                  £1.2B
                </div>
              </div>

              <div className="hidden sm:block w-px h-10 bg-white/10" />

              <div>
                <div className="text-[10px] uppercase tracking-widest text-slate-500 mb-1 font-semibold">
                  Active Traders
                </div>
                <div className="text-xl font-mono tracking-tight text-white font-bold">
                  14,802
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={() => navigateTo('trade')}
                className="bg-[#D9A441] text-black text-[11px] font-bold uppercase tracking-[0.2em] px-7 py-3 rounded-sm shadow-[0_0_15px_rgba(217,164,65,0.3)] hover:brightness-110 transition-all flex items-center gap-2 active:scale-95"
              >
                <span>Start Trading</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => navigateTo('about')}
                className="bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 text-[11px] font-bold uppercase tracking-[0.15em] px-6 py-3 rounded-sm transition-all"
              >
                Learn More
              </button>
            </div>
          </div>

          {/* Right Floating Trading Widget */}
          <div className="lg:col-span-5">
            <TradingWidget />
          </div>

        </div>
      </div>
    </section>
  );
};
