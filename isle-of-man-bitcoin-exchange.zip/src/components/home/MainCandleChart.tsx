import React from 'react';
import { useExchange } from '../../context/ExchangeContext';
import { TimeFrame } from '../../types';
import { ResponsiveContainer, ComposedChart, Area, Bar, XAxis, YAxis, Tooltip } from 'recharts';

export const MainCandleChart: React.FC = () => {
  const { candleData, timeFrame, setTimeFrame, selectedPair } = useExchange();

  const timeFrames: TimeFrame[] = ['1H', '4H', '1D', '1W', '1M'];

  const currentPriceFormatted = selectedPair.price.toLocaleString('en-GB', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return (
    <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-5 flex flex-col justify-between h-full relative overflow-hidden">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-3">
          <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#D9A441]" />
            BTC/GBP
          </h3>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded font-semibold">
            +{selectedPair.change24h}%
          </span>
        </div>

        {/* Timeframe Selectors */}
        <div className="flex items-center bg-[#0A0D14] border border-[#1F293D] p-1 rounded-lg">
          {timeFrames.map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeFrame(tf)}
              className={`px-2.5 py-1 text-xs font-mono font-bold rounded transition-all ${
                timeFrame === tf
                  ? 'bg-[#1C2436] text-[#D9A441] shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* Chart Canvas Area */}
      <div className="relative w-full h-[280px] sm:h-[300px]">
        {/* Floating Current Price Badge */}
        <div className="absolute right-2 top-8 z-20 bg-[#D9A441] text-[#0A0D14] font-mono font-extrabold text-xs px-2.5 py-1 rounded shadow-lg border border-[#F0C067]">
          {currentPriceFormatted} GBP
        </div>

        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={candleData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <defs>
              <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#D9A441" stopOpacity={0.4} />
                <stop offset="100%" stopColor="#D9A441" stopOpacity={0.0} />
              </linearGradient>
            </defs>

            <XAxis 
              dataKey="time" 
              stroke="#475569" 
              fontSize={10} 
              tickLine={false} 
              axisLine={{ stroke: '#1F293D' }} 
            />

            <YAxis 
              yAxisId="price" 
              domain={['dataMin - 1000', 'dataMax + 1000']} 
              orientation="right" 
              stroke="#475569" 
              fontSize={10} 
              tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} 
              tickLine={false} 
              axisLine={{ stroke: '#1F293D' }} 
            />

            <YAxis 
              yAxisId="volume" 
              orientation="left" 
              hide={true} 
              domain={[0, 'dataMax * 3']} 
            />

            <Tooltip 
              contentStyle={{
                backgroundColor: '#121722',
                borderColor: '#1F293D',
                borderRadius: '8px',
                color: '#fff',
                fontSize: '12px',
                fontFamily: 'monospace',
              }}
              formatter={(value: any, name: any) => [
                name === 'close' ? `£${Number(value).toLocaleString()}` : `${value} BTC`,
                name === 'close' ? 'Price' : 'Volume',
              ]}
            />

            {/* Volume bars at bottom */}
            <Bar yAxisId="volume" dataKey="volume" fill="#232D42" opacity={0.6} radius={[2, 2, 0, 0]} />

            {/* Price Line & Area Gradient */}
            <Area
              yAxisId="price"
              type="monotone"
              dataKey="close"
              stroke="#D9A441"
              strokeWidth={2}
              fill="url(#priceGradient)"
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-[#1F293D]/60">
        <span>24H High: £{selectedPair.high24h.toLocaleString()}</span>
        <span>24H Low: £{selectedPair.low24h.toLocaleString()}</span>
        <span>Vol: £{(selectedPair.volume24h / 1000000).toFixed(2)}M</span>
      </div>
    </div>
  );
};
