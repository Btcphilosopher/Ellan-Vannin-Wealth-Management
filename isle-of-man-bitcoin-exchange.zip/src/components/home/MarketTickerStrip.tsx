import React from 'react';
import { useExchange } from '../../context/ExchangeContext';
import { TriskelionLogo } from '../common/TriskelionLogo';
import { Users, Lock, TrendingUp } from 'lucide-react';

export const MarketTickerStrip: React.FC = () => {
  const { selectedPair } = useExchange();

  const priceFormatted = selectedPair.price.toLocaleString('en-GB', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return (
    <div className="bg-[#08090D] border-y border-white/10 py-4 text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 items-center">
          
          {/* 1. BTC/GBP Ticker */}
          <div className="flex items-center gap-3 p-3 rounded bg-[#111319] border border-white/10 hover:border-[#D9A441]/40 transition-all">
            <div className="w-8 h-8 rounded-full bg-[#D9A441]/10 border border-[#D9A441]/40 flex items-center justify-center text-[#D9A441] font-bold text-base shrink-0">
              ₿
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">BTC/GBP</div>
              <div className="text-base font-mono font-bold text-white tracking-tight">
                £{priceFormatted}
              </div>
              <div className="text-[10px] font-semibold text-emerald-400 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +{selectedPair.change24h}% (24h)
              </div>
            </div>
            {/* Sparkline chart SVG */}
            <svg className="w-14 h-7 text-emerald-400 shrink-0" viewBox="0 0 60 30" fill="none">
              <path d="M0 25 L10 22 L20 24 L30 18 L40 12 L50 15 L60 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>

          {/* 2. 24H VOLUME */}
          <div className="flex items-center gap-3 p-3 rounded bg-[#111319] border border-white/10">
            <div className="flex-1">
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">24H VOLUME</div>
              <div className="text-base font-mono font-bold text-white mt-0.5">
                £12,458,291
              </div>
            </div>
            <svg className="w-14 h-7 text-[#D9A441] shrink-0" viewBox="0 0 60 30" fill="none">
              <path d="M0 20 L12 22 L24 16 L36 18 L48 8 L60 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>

          {/* 3. ACTIVE TRADERS */}
          <div className="flex items-center gap-3 p-3 rounded bg-[#111319] border border-white/10">
            <div className="p-2 rounded bg-white/5 text-slate-300">
              <Users className="w-4 h-4 text-[#D9A441]" />
            </div>
            <div>
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">ACTIVE TRADERS</div>
              <div className="text-base font-mono font-bold text-white mt-0.5">
                14,802
              </div>
            </div>
          </div>

          {/* 4. BTC HELD */}
          <div className="flex items-center gap-3 p-3 rounded bg-[#111319] border border-white/10">
            <div className="p-2 rounded bg-white/5 text-slate-300">
              <Lock className="w-4 h-4 text-[#D9A441]" />
            </div>
            <div>
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">COLD RESERVES</div>
              <div className="text-base font-mono font-bold text-white mt-0.5">
                2,543 BTC
              </div>
            </div>
          </div>

          {/* 5. IOM ADVANTAGE */}
          <div className="flex items-center gap-3 p-3 rounded bg-[#111319] border border-[#D9A441]/30">
            <TriskelionLogo size={24} className="shrink-0" />
            <div>
              <div className="text-xs font-bold text-[#D9A441]">IOM ADVANTAGE</div>
              <div className="text-[11px] font-semibold text-white">Crown Dependency</div>
              <div className="text-[10px] text-slate-400 truncate max-w-[140px]">
                Regulated Digital Asset Hub
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
