import React from 'react';
import { useExchange } from '../../context/ExchangeContext';

export const OrderBookPanel: React.FC = () => {
  const { orderBook, selectedPair } = useExchange();

  return (
    <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-5 h-full flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between pb-3 mb-2 border-b border-[#1F293D]">
          <h3 className="text-sm font-bold text-white tracking-wide">Order Book</h3>
          <span className="text-[10px] text-slate-400 font-mono">
            Spread: {orderBook.spread} ({orderBook.spreadPercent}%)
          </span>
        </div>

        {/* Table Column Titles */}
        <div className="grid grid-cols-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 px-1">
          <span className="text-left">Price (GBP)</span>
          <span className="text-right">Amount (BTC)</span>
          <span className="text-right">Total (GBP)</span>
        </div>

        {/* Asks (Sell Orders - Red) */}
        <div className="space-y-1 font-mono text-[11px]">
          {orderBook.asks.map((ask, index) => (
            <div key={`ask-${index}`} className="relative grid grid-cols-3 py-1 px-1 rounded hover:bg-slate-800/40 transition-colors">
              {/* Depth fill indicator */}
              <div
                className="absolute right-0 top-0 bottom-0 bg-red-500/10 rounded-r pointer-events-none"
                style={{ width: `${ask.depthPercent}%` }}
              />
              <span className="text-red-400 font-semibold relative z-10">
                {ask.price.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-right text-slate-300 relative z-10">
                {ask.amount.toFixed(4)}
              </span>
              <span className="text-right text-slate-400 relative z-10">
                {ask.total.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
              </span>
            </div>
          ))}
        </div>

        {/* Mid Price Banner */}
        <div className="my-2.5 py-2 px-3 bg-[#121722] border-y border-[#1F293D] flex items-center justify-between">
          <span className="text-xs text-slate-400">Mark Price</span>
          <span className="text-sm font-mono font-extrabold text-[#D9A441]">
            {selectedPair.price.toLocaleString('en-GB', { minimumFractionDigits: 2 })} GBP
          </span>
        </div>

        {/* Bids (Buy Orders - Green) */}
        <div className="space-y-1 font-mono text-[11px]">
          {orderBook.bids.map((bid, index) => (
            <div key={`bid-${index}`} className="relative grid grid-cols-3 py-1 px-1 rounded hover:bg-slate-800/40 transition-colors">
              {/* Depth fill indicator */}
              <div
                className="absolute right-0 top-0 bottom-0 bg-emerald-500/10 rounded-r pointer-events-none"
                style={{ width: `${bid.depthPercent}%` }}
              />
              <span className="text-emerald-400 font-semibold relative z-10">
                {bid.price.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-right text-slate-300 relative z-10">
                {bid.amount.toFixed(4)}
              </span>
              <span className="text-right text-slate-400 relative z-10">
                {bid.total.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
