import React from 'react';
import { useExchange } from '../../context/ExchangeContext';
import { Play, ArrowRight, ShieldCheck } from 'lucide-react';

export const IomHubCard: React.FC = () => {
  const { navigateTo, setIsVideoModalOpen } = useExchange();

  return (
    <div className="bg-[#0E131F] border border-[#1F293D] rounded-2xl p-5 h-full flex flex-col justify-between group">
      <div>
        <h3 className="text-sm font-bold text-white tracking-wide mb-3 flex items-center justify-between">
          <span>Isle of Man: A Global Digital Finance Hub</span>
          <span className="text-[10px] text-[#D9A441] bg-[#D9A441]/10 px-2 py-0.5 rounded font-semibold border border-[#D9A441]/20">
            IOM FSA
          </span>
        </h3>

        {/* Video Thumbnail with Play Button */}
        <div 
          onClick={() => setIsVideoModalOpen(true)}
          className="relative rounded-xl overflow-hidden cursor-pointer aspect-video mb-4 border border-[#1F293D] group-hover:border-[#D9A441]/60 transition-all shadow-lg"
        >
          <img
            src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80"
            alt="Isle of Man Coastline"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0D14]/90 via-black/30 to-transparent" />

          {/* Center Play Button */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-md border border-white/40 flex items-center justify-center text-white shadow-2xl group-hover:scale-110 group-hover:bg-[#D9A441] group-hover:text-[#0A0D14] transition-all">
              <Play className="w-5 h-5 fill-current ml-0.5" />
            </div>
          </div>

          <div className="absolute bottom-2 left-3 right-3 text-[11px] font-medium text-slate-200 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-[#D9A441]" />
            <span>Watch: The Sovereign Advantage (3 mins)</span>
          </div>
        </div>

        {/* Description text */}
        <p className="text-xs text-slate-300 font-medium leading-relaxed">
          <strong className="text-white">Stable. Innovative. Forward-Thinking.</strong> Discover why the Isle of Man is the ideal jurisdiction for the future of finance.
        </p>
      </div>

      {/* Action link */}
      <div className="pt-4 border-t border-[#1F293D] mt-3">
        <button
          onClick={() => navigateTo('about')}
          className="text-xs font-bold text-[#D9A441] hover:text-[#F0C067] inline-flex items-center gap-1.5 transition-all group-hover:translate-x-1"
        >
          <span>Learn more about IOM</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
