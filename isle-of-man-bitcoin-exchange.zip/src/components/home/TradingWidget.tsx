import React, { useState, useEffect } from 'react';
import { useExchange } from '../../context/ExchangeContext';
import { ArrowUpDown, Info, Check, ShieldCheck } from 'lucide-react';

export const TradingWidget: React.FC = () => {
  const { selectedPair, executeQuickTrade, isLoggedIn, navigateTo, addToast, user } = useExchange();

  const [activeTab, setActiveTab] = useState<'buy' | 'sell' | 'convert'>('buy');
  const [payAmount, setPayAmount] = useState<string>('1000');
  const [payCurrency, setPayCurrency] = useState<'GBP' | 'EUR' | 'USD'>('GBP');
  const [receiveCurrency, setReceiveCurrency] = useState<'BTC' | 'ETH' | 'SOL'>('BTC');
  const [receiveAmount, setReceiveAmount] = useState<string>('0.013271');
  const [isFeeInfoOpen, setIsFeeInfoOpen] = useState<boolean>(false);
  const [isConfirming, setIsConfirming] = useState<boolean>(false);

  const btcPriceGbp = selectedPair.price; // e.g. 75386.21

  // Currency multiplier relative to GBP
  const currencyRate = payCurrency === 'GBP' ? 1.0 : payCurrency === 'EUR' ? 1.17 : 1.28;

  // Recalculate receive amount based on payAmount
  useEffect(() => {
    const val = parseFloat(payAmount);
    if (!isNaN(val) && val > 0) {
      const gbpEquivalent = val / currencyRate;
      const btc = gbpEquivalent / btcPriceGbp;
      if (receiveCurrency === 'BTC') {
        setReceiveAmount(btc.toFixed(6));
      } else if (receiveCurrency === 'ETH') {
        setReceiveAmount((gbpEquivalent / 2680.50).toFixed(4));
      } else {
        setReceiveAmount((gbpEquivalent / 142.80).toFixed(2));
      }
    } else {
      setReceiveAmount('0.000000');
    }
  }, [payAmount, payCurrency, receiveCurrency, btcPriceGbp, currencyRate]);

  const handlePayAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value === '' || /^\d*\.?\d*$/.test(value)) {
      setPayAmount(value);
    }
  };

  const handleSwap = () => {
    if (activeTab === 'buy') {
      setActiveTab('sell');
    } else if (activeTab === 'sell') {
      setActiveTab('buy');
    }
  };

  const handleTradeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isLoggedIn) {
      addToast('Authentication Required', 'Please log in or sign up to execute digital asset transactions.', 'info');
      navigateTo('login');
      return;
    }

    const numericPay = parseFloat(payAmount);
    const numericBtc = parseFloat(receiveAmount);

    if (isNaN(numericPay) || numericPay <= 0) {
      addToast('Invalid Amount', 'Please enter a valid amount to trade.', 'error');
      return;
    }

    setIsConfirming(true);
    setTimeout(() => {
      const success = executeQuickTrade(
        activeTab === 'sell' ? 'sell' : 'buy',
        numericPay / currencyRate,
        numericBtc
      );
      setIsConfirming(false);
      if (success) {
        setPayAmount('1000');
      }
    }, 600);
  };

  return (
    <div className="w-full bg-[#111319] border border-white/10 p-6 rounded-lg shadow-2xl relative overflow-hidden text-white">
      {/* Golden left vertical accent bar from design theme */}
      <div className="absolute top-0 left-0 w-1 h-full bg-[#D9A441]" />

      {/* Tabs: Buy / Sell / Convert */}
      <div className="flex gap-6 mb-6 border-b border-white/5 pb-4">
        <button
          type="button"
          onClick={() => setActiveTab('buy')}
          className={`text-sm font-bold uppercase tracking-wider pb-1 transition-all ${
            activeTab === 'buy'
              ? 'text-[#D9A441] border-b-2 border-[#D9A441]'
              : 'text-slate-500 hover:text-white'
          }`}
        >
          Buy
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('sell')}
          className={`text-sm font-bold uppercase tracking-wider pb-1 transition-all ${
            activeTab === 'sell'
              ? 'text-[#D9A441] border-b-2 border-[#D9A441]'
              : 'text-slate-500 hover:text-white'
          }`}
        >
          Sell
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('convert')}
          className={`text-sm font-bold uppercase tracking-wider pb-1 transition-all ${
            activeTab === 'convert'
              ? 'text-[#D9A441] border-b-2 border-[#D9A441]'
              : 'text-slate-500 hover:text-white'
          }`}
        >
          Convert
        </button>
      </div>

      <form onSubmit={handleTradeSubmit} className="space-y-4">
        {/* You Pay / Pay With Box */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="block text-[10px] uppercase tracking-widest text-slate-500 font-bold">
              {activeTab === 'sell' ? 'You Sell' : 'Pay With'}
            </label>
            {isLoggedIn && (
              <span className="text-[10px] text-slate-400 font-mono">
                Available: £{user.wallet.gbpBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
              </span>
            )}
          </div>
          <div className="flex bg-[#0A0B10] border border-white/10 rounded overflow-hidden focus-within:border-[#D9A441] transition-colors">
            <input
              type="text"
              value={payAmount}
              onChange={handlePayAmountChange}
              placeholder="0.00"
              className="bg-transparent flex-1 px-4 py-3 outline-none font-mono text-lg text-white"
            />
            <div className="relative border-l border-white/10">
              <select
                value={payCurrency}
                onChange={(e) => setPayCurrency(e.target.value as 'GBP' | 'EUR' | 'USD')}
                className="appearance-none bg-white/5 h-full px-4 font-bold text-sm text-white cursor-pointer focus:outline-none pr-8"
              >
                <option value="GBP" className="bg-[#111319] text-white">GBP</option>
                <option value="EUR" className="bg-[#111319] text-white">EUR</option>
                <option value="USD" className="bg-[#111319] text-white">USD</option>
              </select>
            </div>
          </div>
        </div>

        {/* Middle Swap Icon */}
        <div className="flex justify-center -my-2 relative z-10">
          <button
            type="button"
            onClick={handleSwap}
            className="bg-[#111319] p-1.5 border border-white/10 rounded-full cursor-pointer hover:border-[#D9A441] transition-colors text-slate-400 hover:text-[#D9A441]"
            title="Swap direction"
          >
            <ArrowUpDown className="w-4 h-4" />
          </button>
        </div>

        {/* You Receive Box */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="block text-[10px] uppercase tracking-widest text-slate-500 font-bold">
              Receive
            </label>
            {isLoggedIn && (
              <span className="text-[10px] text-slate-400 font-mono">
                BTC Balance: {user.wallet.btcBalance.toFixed(4)} BTC
              </span>
            )}
          </div>
          <div className="flex bg-[#0A0B10] border border-white/10 rounded overflow-hidden">
            <input
              type="text"
              value={receiveAmount}
              readOnly
              className="bg-transparent flex-1 px-4 py-3 outline-none font-mono text-lg text-[#D9A441] font-bold"
            />
            <div className="relative border-l border-white/10">
              <select
                value={receiveCurrency}
                onChange={(e) => setReceiveCurrency(e.target.value as 'BTC' | 'ETH' | 'SOL')}
                className="appearance-none bg-white/5 h-full px-4 font-bold text-sm text-white cursor-pointer focus:outline-none pr-8"
              >
                <option value="BTC" className="bg-[#111319] text-white">BTC</option>
                <option value="ETH" className="bg-[#111319] text-white">ETH</option>
                <option value="SOL" className="bg-[#111319] text-white">SOL</option>
              </select>
            </div>
          </div>
        </div>

        {/* Rate Info Line */}
        <div className="pt-2 flex justify-between items-center text-[11px] text-slate-400 font-mono">
          <span className="italic">Est. Fee: £12.50 (0.1%)</span>
          <span className="text-slate-300">1 BTC = £{btcPriceGbp.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
        </div>

        {/* Main Immersive Theme CTA Button */}
        <button
          type="submit"
          disabled={isConfirming}
          className="w-full bg-[#D9A441] text-black font-bold uppercase tracking-[0.2em] py-4 rounded-sm mt-4 hover:brightness-110 transition-all shadow-lg active:scale-[0.98] text-sm"
        >
          {isConfirming ? (
            <span className="flex items-center justify-center gap-2">
              <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
              Processing Order...
            </span>
          ) : (
            <span>
              {activeTab === 'buy' ? 'Buy Bitcoin' : activeTab === 'sell' ? 'Sell Bitcoin' : 'Convert Assets'}
            </span>
          )}
        </button>

        {/* Payment options footer */}
        <div className="pt-3 border-t border-white/5 flex items-center justify-between text-slate-500 text-[10px] uppercase font-mono tracking-wider">
          <span>Faster Payments</span>
          <span>VISA</span>
          <span>Mastercard</span>
          <span>Apple Pay</span>
        </div>
      </form>
    </div>
  );
};
