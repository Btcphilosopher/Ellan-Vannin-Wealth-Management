import { ReservoirAsset, AnnualCashFlow, ValuationMetrics, PriceScenario } from '../types';

/**
 * Calculates the production forecast for a reservoir asset.
 */
export function forecastProduction(
  asset: ReservoirAsset,
  horizonYears: number
): number[] {
  const q0 = asset.currentProduction;
  const d = asset.declineRate;
  const b = asset.hyperbolicB;
  const flat = asset.flatPeriod;
  const type = asset.declineType;

  const forecast: number[] = [];

  for (let year = 1; year <= horizonYears; year++) {
    if (year <= flat) {
      forecast.push(q0);
      continue;
    }

    const tDecline = year - flat;

    if (type === 'exponential') {
      // Exponential decline: q_t = q0 * (1 - d)^tDecline
      const qt = q0 * Math.pow(1 - d, tDecline);
      forecast.push(Math.max(0, qt));
    } else if (type === 'hyperbolic') {
      // Hyperbolic decline: q_t = q0 / (1 + b * d * tDecline)^(1/b)
      // Guard against b = 0
      const safeB = Math.max(0.01, Math.min(0.99, b));
      const qt = q0 / Math.pow(1 + safeB * d * tDecline, 1 / safeB);
      forecast.push(Math.max(0, qt));
    } else {
      // User defined or fallback
      if (asset.userProductionProfile && asset.userProductionProfile[year - 1] !== undefined) {
        forecast.push(Math.max(0, asset.userProductionProfile[year - 1]));
      } else {
        // Fallback to exponential decline
        const qt = q0 * Math.pow(1 - d, tDecline);
        forecast.push(Math.max(0, qt));
      }
    }
  }

  return forecast;
}

/**
 * Generates the full annual cash flow schedule.
 */
export function calculateCashFlows(
  asset: ReservoirAsset,
  scenario: PriceScenario,
  discountRate: number,
  horizonYears: number
): AnnualCashFlow[] {
  const productionProfile = forecastProduction(asset, horizonYears);
  const schedule: AnnualCashFlow[] = [];
  let cumulativeProd = 0;

  // Distribute CAPEX over capexDuration
  const annualCapexBase = asset.capex / Math.max(1, asset.capexDuration);

  for (let i = 0; i < horizonYears; i++) {
    const yearIdx = i + 1;
    const prod = productionProfile[i];
    cumulativeProd += prod;

    // Apply inflation to commodity prices and costs
    const inflationFactor = Math.pow(1 + scenario.inflationRate, i);
    const oilPrice = scenario.oilPrice * inflationFactor;
    const gasPrice = scenario.gasPrice * inflationFactor;

    // Revenue calculation
    // Production is in MMboe. Let's assume the mix is 70% oil and 30% gas for standard conversion.
    // 1 boe = 5.8 Mscf of gas. Let's say:
    // Oil fraction is 0.70 (sold at oilPrice $/bbl)
    // Gas fraction is 0.30 * 5.8 = 1.74 Mscf (sold at gasPrice $/Mscf)
    // Revenue ($) per boe = (0.7 * oilPrice) + (0.3 * 5.8 * gasPrice)
    const revPerBoe = (0.7 * oilPrice) + (0.3 * 5.8 * gasPrice);
    const revenue = prod * revPerBoe; // MMboe * $/boe = Million $

    // OPEX calculations
    const opexFixed = yearIdx <= asset.remainingLife ? asset.opexFixed * inflationFactor : 0;
    const opexVariable = yearIdx <= asset.remainingLife ? (prod * asset.opexVariable) * inflationFactor : 0; // MMboe * $/boe = Million $
    const opexTotal = opexFixed + opexVariable;

    // CAPEX distribution
    let capex = 0;
    if (yearIdx <= asset.capexDuration) {
      capex = annualCapexBase * inflationFactor;
    }

    // Decommissioning provision spent in the last year of remaining life
    let decommissioning = 0;
    if (yearIdx === asset.remainingLife) {
      decommissioning = asset.decommissioningProvision * inflationFactor;
    }

    // Carbon cost calculation
    // carbonIntensity is kg CO2/boe. Total CO2 (tonnes) = prod * 1,000,000 boe * carbonIntensity / 1000
    // Total CO2 = prod * carbonIntensity * 1000 tonnes CO2
    // Carbon cost = Total CO2 * carbonTax / 1,000,000 Million $
    // Carbon cost = prod * carbonIntensity * 1000 * carbonTax / 1e6 = prod * carbonIntensity * carbonTax / 1000 Million $
    const carbonEmissionsTonnes = prod * asset.carbonIntensity * 1000; // tonnes CO2
    const carbonCost = (carbonEmissionsTonnes * scenario.carbonTax) / 1000000; // Million $

    const totalCost = opexTotal + capex + decommissioning + carbonCost;
    const freeCashFlow = revenue - totalCost;

    // Discounting
    const discountedCashFlow = freeCashFlow / Math.pow(1 + discountRate, yearIdx);

    schedule.push({
      year: yearIdx,
      production: prod,
      cumulativeProduction: cumulativeProd,
      oilPrice,
      gasPrice,
      revenue,
      opexFixed,
      opexVariable,
      opexTotal,
      capex,
      carbonCost,
      decommissioning,
      totalCost,
      freeCashFlow,
      discountedCashFlow,
    });
  }

  return schedule;
}

/**
 * Calculates Net Present Value (NPV)
 */
export function calculateNPV(cashFlows: AnnualCashFlow[]): number {
  return cashFlows.reduce((sum, cf) => sum + cf.discountedCashFlow, 0);
}

/**
 * Calculates Internal Rate of Return (IRR) using Bisection Method
 */
export function calculateIRR(cashFlows: AnnualCashFlow[]): number {
  const fcf = cashFlows.map(cf => cf.freeCashFlow);
  
  // Check if there is at least one sign change
  let hasPositive = false;
  let hasNegative = false;
  for (const val of fcf) {
    if (val > 0) hasPositive = true;
    if (val < 0) hasNegative = true;
  }
  if (!hasPositive || !hasNegative) {
    return NaN; // No IRR possible if all cash flows are positive or all negative
  }

  // Bisection search
  let low = -0.999;
  let high = 5.0; // 500% max
  const maxIterations = 100;
  const tolerance = 1e-6;

  const npvFunc = (rate: number) => {
    let sum = 0;
    for (let i = 0; i < cashFlows.length; i++) {
      sum += cashFlows[i].freeCashFlow / Math.pow(1 + rate, cashFlows[i].year);
    }
    return sum;
  };

  let fLow = npvFunc(low);
  let fHigh = npvFunc(high);

  if (fLow * fHigh > 0) {
    // If the signs are the same, try expanding the search region
    high = 20.0; // Up to 2000%
    fHigh = npvFunc(high);
    if (fLow * fHigh > 0) {
      return NaN;
    }
  }

  let mid = 0;
  for (let iter = 0; iter < maxIterations; iter++) {
    mid = (low + high) / 2;
    const fMid = npvFunc(mid);

    if (Math.abs(fMid) < tolerance) {
      return mid;
    }

    if (fLow * fMid < 0) {
      high = mid;
      fHigh = fMid;
    } else {
      low = mid;
      fLow = fMid;
    }
  }

  return mid;
}

/**
 * Calculates Payback Period in years
 */
export function calculatePaybackPeriod(cashFlows: AnnualCashFlow[]): number {
  let cumulativeCash = 0;
  let lastNegativeYear = 0;
  let lastNegativeCash = 0;

  for (let i = 0; i < cashFlows.length; i++) {
    cumulativeCash += cashFlows[i].freeCashFlow;
    if (cumulativeCash < 0) {
      lastNegativeYear = cashFlows[i].year;
      lastNegativeCash = cumulativeCash;
    } else {
      // Crossed into positive
      if (lastNegativeYear === 0) {
        // Cash flow was positive in year 1
        return 0;
      }
      // Linear interpolation: fraction of the year
      const nextCash = cashFlows[i].freeCashFlow;
      const fraction = Math.abs(lastNegativeCash) / nextCash;
      return lastNegativeYear + fraction;
    }
  }

  return NaN; // Never pays back
}

/**
 * Calculates Profitability Index (PI)
 */
export function calculateProfitabilityIndex(
  cashFlows: AnnualCashFlow[]
): number {
  // Profitability Index = (PV of Positive Cash Flows) / (PV of Negative Cash Flows)
  // Let's compute standard PI: 1 + (NPV / PV of CAPEX)
  let pvCapex = 0;
  let pvPositiveFCF = 0;

  for (let i = 0; i < cashFlows.length; i++) {
    const cf = cashFlows[i];
    if (cf.capex > 0) {
      pvCapex += cf.capex / Math.pow(1.1, cf.year); // standardized discount rate for Capex or 0%
    }
    if (cf.freeCashFlow > 0) {
      pvPositiveFCF += cf.discountedCashFlow;
    }
  }

  // Standard industry formula: PI = PV of future cash flows / Initial investment
  const totalCapex = cashFlows.reduce((sum, cf) => sum + cf.capex, 0);
  if (totalCapex === 0) return 1.0;

  const npv = calculateNPV(cashFlows);
  return 1 + (npv / totalCapex);
}

/**
 * Combines all financial valuation metrics
 */
export function evaluateAsset(
  asset: ReservoirAsset,
  scenario: PriceScenario,
  discountRate: number,
  horizonYears: number
): ValuationMetrics {
  const cashFlows = calculateCashFlows(asset, scenario, discountRate, horizonYears);
  
  const npv = calculateNPV(cashFlows);
  const irr = calculateIRR(cashFlows);
  const paybackPeriod = calculatePaybackPeriod(cashFlows);
  const profitabilityIndex = calculateProfitabilityIndex(cashFlows);

  const totalProduction = cashFlows.reduce((sum, cf) => sum + cf.production, 0);
  const totalRevenue = cashFlows.reduce((sum, cf) => sum + cf.revenue, 0);
  const totalCapex = cashFlows.reduce((sum, cf) => sum + cf.capex, 0);
  const totalOpex = cashFlows.reduce((sum, cf) => sum + cf.opexTotal, 0);
  const totalFreeCashFlow = cashFlows.reduce((sum, cf) => sum + cf.freeCashFlow, 0);

  return {
    npv,
    irr,
    paybackPeriod,
    profitabilityIndex,
    totalProduction,
    totalRevenue,
    totalCapex,
    totalOpex,
    totalFreeCashFlow,
  };
}
