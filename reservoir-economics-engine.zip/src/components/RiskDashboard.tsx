import React, { useMemo } from 'react';
import { ReservoirAsset, PriceScenario } from '../types';
import { calculateCashFlows, evaluateAsset } from '../utils/economics';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { ShieldAlert, AlertTriangle, RefreshCw, BarChart2, PieChart as PieIcon, HelpCircle } from 'lucide-react';

interface RiskDashboardProps {
  assets: ReservoirAsset[];
  scenario: PriceScenario;
  scenarios: PriceScenario[];
  discountRate: number;
  horizonYears: number;
}

export default function RiskDashboard({
  assets,
  scenario,
  scenarios,
  discountRate,
  horizonYears,
}: RiskDashboardProps) {
  // Aggregate portfolio metrics for calculations
  const riskAnalysis = useMemo(() => {
    let totalPortfolioReserves = 0;
    let totalPortfolioNPV = 0;
    
    // 1. Calculate exposures under Base vs Low
    let basePortfolioNPV = 0;
    let lowPortfolioNPV = 0;

    const operatorReservesMap: { [key: string]: number } = {};
    const countryReservesMap: { [key: string]: number } = {};

    const assetsRiskEvaluated = assets.map(asset => {
      const baseMetrics = evaluateAsset(asset, scenario, discountRate, horizonYears);
      totalPortfolioReserves += asset.remainingReserves;
      totalPortfolioNPV += baseMetrics.npv;
      basePortfolioNPV += baseMetrics.npv;

      // Low price evaluation
      const lowSc = scenarios.find(s => s.name === 'Low') || scenarios[0];
      const lowMetrics = evaluateAsset(asset, lowSc, discountRate, horizonYears);
      lowPortfolioNPV += lowMetrics.npv;

      // Concentration calculations
      operatorReservesMap[asset.operator] = (operatorReservesMap[asset.operator] || 0) + asset.remainingReserves;
      countryReservesMap[asset.country] = (countryReservesMap[asset.country] || 0) + asset.remainingReserves;

      // Price risk: NPV loss percentage from Base to Low
      const priceRiskNpvLoss = baseMetrics.npv > 0 
        ? ((baseMetrics.npv - lowMetrics.npv) / baseMetrics.npv) * 100
        : 100;

      // Cost Inflation risk: high if OPEX is a large % of revenue
      const opexRevenueRatio = baseMetrics.totalRevenue > 0
        ? (baseMetrics.totalOpex / baseMetrics.totalRevenue) * 100
        : 0;

      // Production decline risk: high decline rates represent high geological decline uncertainty
      const declineUncertainty = asset.declineRate * 100;

      return {
        asset,
        baseNPV: baseMetrics.npv,
        lowNPV: lowMetrics.npv,
        priceRiskNpvLoss,
        opexRevenueRatio,
        declineUncertainty,
      };
    });

    // Format concentration charts
    const operatorConcentration = Object.keys(operatorReservesMap).map(key => ({
      name: key,
      value: Number(((operatorReservesMap[key] / Math.max(1, totalPortfolioReserves)) * 100).toFixed(1)),
      reserves: operatorReservesMap[key],
    })).sort((a, b) => b.value - a.value);

    const regionalConcentration = Object.keys(countryReservesMap).map(key => ({
      name: key,
      value: Number(((countryReservesMap[key] / Math.max(1, totalPortfolioReserves)) * 100).toFixed(1)),
      reserves: countryReservesMap[key],
    })).sort((a, b) => b.value - a.value);

    // Portfolio overall exposures
    const commodityExposureValue = basePortfolioNPV > 0
      ? ((basePortfolioNPV - lowPortfolioNPV) / basePortfolioNPV) * 100
      : 0;

    // Highest exposure asset
    const highestRiskPriceAsset = [...assetsRiskEvaluated].sort((a, b) => b.priceRiskNpvLoss - a.priceRiskNpvLoss)[0];
    const highestOpexRatioAsset = [...assetsRiskEvaluated].sort((a, b) => b.opexRevenueRatio - a.opexRevenueRatio)[0];

    return {
      assetsRiskEvaluated,
      operatorConcentration,
      regionalConcentration,
      commodityExposurePercent: Number(commodityExposureValue.toFixed(1)),
      totalPortfolioReserves,
      highestRiskPriceAsset,
      highestOpexRatioAsset,
    };
  }, [assets, scenario, scenarios, discountRate, horizonYears]);

  const COLORS = ['#ef4444', '#f59e0b', '#FDBA74', '#10b981', '#8b5cf6', '#ec4899', '#14b8a6'];

  // Risk Rating Score for Portfolio
  const portfolioRiskRating = useMemo(() => {
    let score = 0;
    
    // 1. Commodity risk
    if (riskAnalysis.commodityExposurePercent > 60) score += 3;
    else if (riskAnalysis.commodityExposurePercent > 30) score += 2;
    else score += 1;

    // 2. Operator Concentration risk
    const maxOpPercent = riskAnalysis.operatorConcentration[0]?.value || 0;
    if (maxOpPercent > 50) score += 3;
    else if (maxOpPercent > 25) score += 2;
    else score += 1;

    // 3. Regional Concentration risk
    const maxRegionPercent = riskAnalysis.regionalConcentration[0]?.value || 0;
    if (maxRegionPercent > 50) score += 3;
    else if (maxRegionPercent > 25) score += 2;
    else score += 1;

    // Average Score out of 3
    const avgScore = score / 3;
    if (avgScore > 2.3) return { label: 'CRITICAL', color: 'text-rose-400 border-rose-950 bg-rose-950/20' };
    if (avgScore > 1.6) return { label: 'MEDIUM RISK', color: 'text-amber-400 border-amber-950 bg-amber-950/20' };
    return { label: 'LOW RISK', color: 'text-emerald-400 border-emerald-950 bg-emerald-950/20' };
  }, [riskAnalysis]);

  return (
    <div id="risk-assessment" className="space-y-6">
      {/* Portfolio Overall Risk Rating */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Portfolio Risk Level</span>
            <span className="text-2xl font-bold text-white block mt-1">Aggregated Profile</span>
          </div>
          <div className={`px-4 py-2 rounded-lg border font-black tracking-widest text-sm ${portfolioRiskRating.color}`}>
            {portfolioRiskRating.label}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Price Collapse Exposure</span>
          <span className="text-2xl font-bold mt-1 block text-rose-400">{riskAnalysis.commodityExposurePercent}%</span>
          <p className="text-[10px] text-slate-500 mt-1">Value lost if market collapses to Low scenario ($45 oil)</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Concentration Threshold</span>
          <span className="text-2xl font-bold mt-1 block text-amber-400">
            {(riskAnalysis.operatorConcentration[0]?.value || 0).toFixed(0)}% <span className="text-sm font-normal text-slate-400">max</span>
          </span>
          <p className="text-[10px] text-slate-500 mt-1">Held under single operator ({riskAnalysis.operatorConcentration[0]?.name})</p>
        </div>
      </div>

      {/* Main Risk Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Concentration charts */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg flex flex-col justify-between">
          <div className="flex items-center gap-2 mb-4">
            <PieIcon className="w-5 h-5 text-peach" />
            <h3 className="text-lg font-bold text-white">Operator Concentration Risk</h3>
          </div>

          <div className="h-60 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={riskAnalysis.operatorConcentration}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                >
                  {riskAnalysis.operatorConcentration.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: any) => [`${value}% Portfolio Reserves`]} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-slate-500 italic text-center mt-2">
            Higher operator concentrations introduce counterparty risk. High-leverage partners should be audited.
          </p>
        </div>

        {/* Geographic concentration risk */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg flex flex-col justify-between">
          <div className="flex items-center gap-2 mb-4">
            <BarChart2 className="w-5 h-5 text-emerald-400" />
            <h3 className="text-lg font-bold text-white">Geographic Reserve Distribution</h3>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={riskAnalysis.regionalConcentration} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} unit="%" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                  formatter={(value: any) => [`${value}% Reserves`]}
                />
                <Bar dataKey="value" fill="#10b981" radius={[4, 4, 0, 0]}>
                  {riskAnalysis.regionalConcentration.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-slate-500 italic text-center mt-2">
            Exposure by country. Assets situated in unstable jurisdictions can be discounted or hedged.
          </p>
        </div>

        {/* Risk Assessment Matrix (Probability vs Impact) */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-bold text-white">Asset Risk Matrix (Probability vs Impact)</h3>
          </div>

          {/* 3x3 Risk Matrix Grid */}
          <div className="grid grid-cols-4 gap-2 text-center text-xs font-bold font-mono">
            {/* Headers */}
            <div className="text-slate-500 flex items-center justify-center text-[10px]">Impact \ Prob</div>
            <div className="py-2 bg-slate-950 text-slate-400 rounded-lg">Low</div>
            <div className="py-2 bg-slate-950 text-slate-400 rounded-lg">Medium</div>
            <div className="py-2 bg-slate-950 text-slate-400 rounded-lg">High</div>

            {/* Row 3: High Impact */}
            <div className="bg-slate-950 text-slate-400 py-4 flex items-center justify-center rounded-lg">High</div>
            <div className="bg-amber-500/10 text-amber-400 p-2 rounded-lg border border-amber-900/40 flex flex-col items-center justify-center">
              <span className="text-[10px] font-semibold text-slate-400 block mb-1">Amber Risk</span>
              {riskAnalysis.assetsRiskEvaluated.filter(a => a.priceRiskNpvLoss > 40 && a.opexRevenueRatio < 30).map(a => (
                <span key={a.asset.id} className="text-[9px] block text-white bg-slate-800 px-1 rounded truncate w-full mt-0.5">{a.asset.name}</span>
              ))}
            </div>
            <div className="bg-rose-500/10 text-rose-400 p-2 rounded-lg border border-rose-900/40 flex flex-col items-center justify-center">
              <span className="text-[10px] font-semibold text-slate-400 block mb-1">High Risk</span>
              {riskAnalysis.assetsRiskEvaluated.filter(a => a.priceRiskNpvLoss > 50 && a.opexRevenueRatio >= 30).map(a => (
                <span key={a.asset.id} className="text-[9px] block text-white bg-slate-800 px-1 rounded truncate w-full mt-0.5">{a.asset.name}</span>
              ))}
            </div>
            <div className="bg-rose-950/40 text-rose-500 p-2 rounded-lg border border-rose-900 flex flex-col items-center justify-center">
              <span className="text-[10px] font-semibold text-slate-400 block mb-1">CRITICAL</span>
              {riskAnalysis.assetsRiskEvaluated.filter(a => a.priceRiskNpvLoss > 70 && a.declineUncertainty > 10).map(a => (
                <span key={a.asset.id} className="text-[9px] block text-white bg-slate-800 px-1 rounded truncate w-full mt-0.5">{a.asset.name}</span>
              ))}
            </div>

            {/* Row 2: Medium Impact */}
            <div className="bg-slate-950 text-slate-400 py-4 flex items-center justify-center rounded-lg">Medium</div>
            <div className="bg-emerald-500/10 text-emerald-400 p-2 rounded-lg border border-emerald-900/40 flex flex-col items-center justify-center">
              <span className="text-[10px] font-semibold text-slate-400 block mb-1">Green Risk</span>
              {riskAnalysis.assetsRiskEvaluated.filter(a => a.priceRiskNpvLoss <= 40 && a.opexRevenueRatio < 20).map(a => (
                <span key={a.asset.id} className="text-[9px] block text-white bg-slate-800 px-1 rounded truncate w-full mt-0.5">{a.asset.name}</span>
              ))}
            </div>
            <div className="bg-amber-500/10 text-amber-400 p-2 rounded-lg border border-amber-900/40 flex flex-col items-center justify-center">
              <span className="text-[10px] font-semibold text-slate-400 block mb-1">Amber Risk</span>
              {riskAnalysis.assetsRiskEvaluated.filter(a => a.priceRiskNpvLoss > 30 && a.priceRiskNpvLoss <= 50 && a.opexRevenueRatio >= 20).map(a => (
                <span key={a.asset.id} className="text-[9px] block text-white bg-slate-800 px-1 rounded truncate w-full mt-0.5">{a.asset.name}</span>
              ))}
            </div>
            <div className="bg-rose-500/10 text-rose-400 p-2 rounded-lg border border-rose-900/40 flex flex-col items-center justify-center">
              <span className="text-[10px] font-semibold text-slate-400 block mb-1">High Risk</span>
              {riskAnalysis.assetsRiskEvaluated.filter(a => a.priceRiskNpvLoss > 60 && a.opexRevenueRatio < 30).map(a => (
                <span key={a.asset.id} className="text-[9px] block text-white bg-slate-800 px-1 rounded truncate w-full mt-0.5">{a.asset.name}</span>
              ))}
            </div>

            {/* Row 1: Low Impact */}
            <div className="bg-slate-950 text-slate-400 py-4 flex items-center justify-center rounded-lg">Low</div>
            <div className="bg-emerald-500/10 text-emerald-400 p-2 rounded-lg border border-emerald-900/40 flex flex-col items-center justify-center">
              <span className="text-[10px] font-semibold text-slate-400 block mb-1">Green Risk</span>
              {riskAnalysis.assetsRiskEvaluated.filter(a => a.priceRiskNpvLoss < 20).map(a => (
                <span key={a.asset.id} className="text-[9px] block text-white bg-slate-800 px-1 rounded truncate w-full mt-0.5">{a.asset.name}</span>
              ))}
            </div>
            <div className="bg-emerald-500/10 text-emerald-400 p-2 rounded-lg border border-emerald-900/40 flex flex-col items-center justify-center">
              <span className="text-[10px] font-semibold text-slate-400 block mb-1">Green Risk</span>
              {riskAnalysis.assetsRiskEvaluated.filter(a => a.priceRiskNpvLoss >= 20 && a.priceRiskNpvLoss <= 30 && a.opexRevenueRatio < 20).map(a => (
                <span key={a.asset.id} className="text-[9px] block text-white bg-slate-800 px-1 rounded truncate w-full mt-0.5">{a.asset.name}</span>
              ))}
            </div>
            <div className="bg-amber-500/10 text-amber-400 p-2 rounded-lg border border-amber-900/40 flex flex-col items-center justify-center">
              <span className="text-[10px] font-semibold text-slate-400 block mb-1">Amber Risk</span>
              {riskAnalysis.assetsRiskEvaluated.filter(a => a.priceRiskNpvLoss > 30 && a.priceRiskNpvLoss <= 50 && a.declineUncertainty < 8).map(a => (
                <span key={a.asset.id} className="text-[9px] block text-white bg-slate-800 px-1 rounded truncate w-full mt-0.5">{a.asset.name}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Highest Risk Vulnerability HUDs */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div className="flex items-center gap-2 mb-4">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <h3 className="text-lg font-bold text-white">Critical Project Risk Alerts</h3>
          </div>

          <div className="space-y-4 flex-1 justify-center flex flex-col">
            {riskAnalysis.highestRiskPriceAsset && (
              <div className="p-4 bg-rose-950/20 border border-rose-900/60 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-rose-400 uppercase tracking-widest">Market Vulnerability</span>
                  <span className="text-[10px] text-slate-400 font-mono">ID: {riskAnalysis.highestRiskPriceAsset.asset.id}</span>
                </div>
                <h4 className="text-sm font-semibold text-white">{riskAnalysis.highestRiskPriceAsset.asset.name}</h4>
                <p className="text-xs text-slate-300">
                  This asset exhibits highest commodity price leverage. In a Low Scenario, NPV crashes by{' '}
                  <strong className="text-rose-400">{riskAnalysis.highestRiskPriceAsset.priceRiskNpvLoss.toFixed(1)}%</strong>
                  , sliding from <strong className="text-white">${riskAnalysis.highestRiskPriceAsset.baseNPV.toFixed(1)}M</strong> to{' '}
                  <strong className="text-rose-400">${riskAnalysis.highestRiskPriceAsset.lowNPV.toFixed(1)}M</strong>.
                </p>
              </div>
            )}

            {riskAnalysis.highestOpexRatioAsset && (
              <div className="p-4 bg-amber-950/20 border border-amber-900/60 rounded-xl space-y-2 mt-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">OpEx Inflation Exposure</span>
                  <span className="text-[10px] text-slate-400 font-mono">Ratio: {riskAnalysis.highestOpexRatioAsset.opexRevenueRatio.toFixed(1)}%</span>
                </div>
                <h4 className="text-sm font-semibold text-white">{riskAnalysis.highestOpexRatioAsset.asset.name}</h4>
                <p className="text-xs text-slate-300">
                  This asset suffers severe cost-inflation sensitivity. OPEX represents{' '}
                  <strong className="text-amber-400">{riskAnalysis.highestOpexRatioAsset.opexRevenueRatio.toFixed(1)}%</strong>{' '}
                  of projected revenue. Any rise in global supply-chain cost escalates operating margins directly.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
