import React, { useState, useMemo } from 'react';
import { ReservoirAsset, PriceScenario, PriceScenarioName } from '../types';
import { calculateCashFlows } from '../utils/economics';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Sliders, Flame, ShieldAlert, Coins, DollarSign } from 'lucide-react';

interface PriceScenarioProps {
  asset: ReservoirAsset;
  scenarios: PriceScenario[];
  onUpdateScenarios: (scenarios: PriceScenario[]) => void;
  discountRate: number;
  horizonYears: number;
}

export default function PriceScenarioComponent({
  asset,
  scenarios,
  onUpdateScenarios,
  discountRate,
  horizonYears,
}: PriceScenarioProps) {
  const [selectedScenarioIdx, setSelectedScenarioIdx] = useState(1); // 'Base' by default
  const activeSc = scenarios[selectedScenarioIdx];

  // Editable parameters for the active scenario
  const [oilPrice, setOilPrice] = useState(activeSc.oilPrice);
  const [gasPrice, setGasPrice] = useState(activeSc.gasPrice);
  const [carbonTax, setCarbonTax] = useState(activeSc.carbonTax);
  const [inflationRate, setInflationRate] = useState(activeSc.inflationRate * 100);

  // Sync state when active scenario index shifts
  useMemo(() => {
    const sc = scenarios[selectedScenarioIdx];
    setOilPrice(sc.oilPrice);
    setGasPrice(sc.gasPrice);
    setCarbonTax(sc.carbonTax);
    setInflationRate(sc.inflationRate * 100);
  }, [selectedScenarioIdx, scenarios]);

  const handleUpdateActiveScenario = () => {
    const nextScenarios = [...scenarios];
    nextScenarios[selectedScenarioIdx] = {
      ...activeSc,
      oilPrice,
      gasPrice,
      carbonTax,
      inflationRate: inflationRate / 100,
    };
    onUpdateScenarios(nextScenarios);
    alert(`Commodity pricing scenario "${activeSc.name}" customized successfully!`);
  };

  // Compare FCF & Revenue for this asset under all 4 scenarios
  const scenarioComparisons = useMemo(() => {
    return scenarios.map(sc => {
      // If editing current, use current state values instead of stored scenarios values for realtime feedback!
      const currentSc = sc.name === activeSc.name ? {
        ...sc,
        oilPrice,
        gasPrice,
        carbonTax,
        inflationRate: inflationRate / 100
      } : sc;

      const cf = calculateCashFlows(asset, currentSc, discountRate, horizonYears);
      const totalRevenue = cf.reduce((sum, item) => sum + item.revenue, 0);
      const totalFCF = cf.reduce((sum, item) => sum + item.freeCashFlow, 0);
      const npv = cf.reduce((sum, item) => sum + item.discountedCashFlow, 0);

      return {
        name: sc.name,
        Revenue: Number(totalRevenue.toFixed(1)),
        FCF: Number(totalFCF.toFixed(1)),
        NPV: Number(npv.toFixed(1)),
        oil: currentSc.oilPrice,
        gas: currentSc.gasPrice,
      };
    });
  }, [asset, scenarios, activeSc, oilPrice, gasPrice, carbonTax, inflationRate, discountRate, horizonYears]);

  // Generate inflated price trends over the horizon for chart
  const priceTrendData = useMemo(() => {
    const trends: any[] = [];
    for (let year = 1; year <= horizonYears; year++) {
      const inf = Math.pow(1 + (inflationRate / 100), year - 1);
      trends.push({
        yearLabel: `Year ${year}`,
        Oil: Number((oilPrice * inf).toFixed(2)),
        Gas: Number((gasPrice * inf).toFixed(2)),
      });
    }
    return trends;
  }, [oilPrice, gasPrice, inflationRate, horizonYears]);

  return (
    <div id="price-scenario-analysis" className="space-y-6">
      {/* Upper Grid: Pricing Scenarios Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {scenarios.map((sc, idx) => {
          const isSelected = selectedScenarioIdx === idx;
          const displayMetrics = scenarioComparisons[idx];

          return (
            <button
              key={sc.name}
              onClick={() => setSelectedScenarioIdx(idx)}
              className={`p-5 rounded-xl text-left border transition shadow-lg flex flex-col justify-between ${
                isSelected
                  ? 'bg-peach/5 border-peach/80 ring-1 ring-peach'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex justify-between items-center w-full">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest">{sc.name} Scenario</span>
                  <Flame className={`w-4 h-4 ${sc.name === 'High' ? 'text-emerald-400' : sc.name === 'Low' ? 'text-rose-400' : 'text-peach'}`} />
                </div>
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-white">${sc.name === activeSc.name ? oilPrice : sc.oilPrice}</span>
                  <span className="text-xs text-slate-400">/bbl Oil</span>
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  Gas: ${sc.name === activeSc.name ? gasPrice : sc.gasPrice}/Mscf
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800/80 w-full flex justify-between items-center text-xs">
                <span className="text-slate-400">NPV:</span>
                <span className={`font-bold ${displayMetrics.NPV >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  ${displayMetrics.NPV}M
                </span>
              </div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Editor Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-6">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
            <Sliders className="w-5 h-5 text-peach" />
            <h3 className="text-lg font-bold text-white">Customize Scenario</h3>
          </div>

          <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800/80">
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Modifying Scenario</span>
            <span className="text-sm font-semibold text-white block mt-0.5">{activeSc.name}</span>
          </div>

          <div className="space-y-4">
            {/* Oil Price */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="text-slate-400">Oil Base Price ($/bbl)</span>
                <input
                  type="number"
                  value={oilPrice}
                  onChange={(e) => setOilPrice(Number(e.target.value))}
                  className="w-20 px-1.5 py-0.5 text-right text-xs bg-slate-950 text-white border border-slate-800 rounded"
                />
              </div>
              <input
                type="range"
                min="20"
                max="150"
                step="1"
                value={oilPrice}
                onChange={(e) => setOilPrice(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-peach"
              />
            </div>

            {/* Gas Price */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="text-slate-400">Gas Base Price ($/Mscf)</span>
                <input
                  type="number"
                  value={gasPrice}
                  onChange={(e) => setGasPrice(Number(e.target.value))}
                  className="w-20 px-1.5 py-0.5 text-right text-xs bg-slate-950 text-white border border-slate-800 rounded"
                />
              </div>
              <input
                type="range"
                min="1.0"
                max="15.0"
                step="0.10"
                value={gasPrice}
                onChange={(e) => setGasPrice(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-peach"
              />
            </div>

            {/* Carbon Tax */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="text-slate-400">Carbon Tax ($/tonne CO2)</span>
                <input
                  type="number"
                  value={carbonTax}
                  onChange={(e) => setCarbonTax(Number(e.target.value))}
                  className="w-20 px-1.5 py-0.5 text-right text-xs bg-slate-950 text-white border border-slate-800 rounded"
                />
              </div>
              <input
                type="range"
                min="0"
                max="200"
                step="5"
                value={carbonTax}
                onChange={(e) => setCarbonTax(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-peach"
              />
            </div>

            {/* Inflation Rate */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1">
                <span className="text-slate-400">Annual Price Inflation (%)</span>
                <input
                  type="number"
                  value={inflationRate}
                  onChange={(e) => setInflationRate(Number(e.target.value))}
                  className="w-20 px-1.5 py-0.5 text-right text-xs bg-slate-950 text-white border border-slate-800 rounded"
                />
              </div>
              <input
                type="range"
                min="0"
                max="10"
                step="0.1"
                value={inflationRate}
                onChange={(e) => setInflationRate(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-peach"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={handleUpdateActiveScenario}
              className="w-full py-2 bg-peach hover:bg-peach/90 text-slate-950 rounded-lg text-xs font-bold transition shadow-md shadow-peach/10"
            >
              Save Scenario Adjustments
            </button>
          </div>
        </div>

        {/* Charts Panel */}
        <div className="lg:col-span-2 space-y-6">
          {/* Chart 1: Inflation adjusted commodity trends */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col">
            <div className="flex items-center gap-2 mb-4">
              <Coins className="w-5 h-5 text-amber-400" />
              <h3 className="text-lg font-bold text-white">Nominal Price Paths (Inflation Escalated)</h3>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={priceTrendData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="yearLabel" stroke="#94a3b8" fontSize={11} />
                  <YAxis yAxisId="left" stroke="#94a3b8" fontSize={11} label={{ value: 'Oil ($/bbl)', angle: -90, position: 'insideLeft', style: { fill: '#94a3b8', fontSize: 10 } }} />
                  <YAxis yAxisId="right" orientation="right" stroke="#94a3b8" fontSize={11} label={{ value: 'Gas ($/Mscf)', angle: 90, position: 'insideRight', style: { fill: '#94a3b8', fontSize: 10 } }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                    labelStyle={{ fontWeight: 'bold' }}
                  />
                  <Legend verticalAlign="top" height={36} iconType="circle" />
                  <Line yAxisId="left" type="monotone" dataKey="Oil" name="Oil Price ($/bbl)" stroke="#FDBA74" strokeWidth={2.5} dot={false} />
                  <Line yAxisId="right" type="monotone" dataKey="Gas" name="Gas Price ($/Mscf)" stroke="#10b981" strokeWidth={2.5} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <p className="text-[11px] text-slate-500 italic text-center mt-2">
              Values escalated at {inflationRate}% compounded annually. This represents the nominal commodity pricing assumptions.
            </p>
          </div>

          {/* Chart 2: Scenario Revenue impact comparisons */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col">
            <div className="flex items-center gap-2 mb-4">
              <DollarSign className="w-5 h-5 text-emerald-400" />
              <h3 className="text-lg font-bold text-white">Scenario Comparison for {asset.name}</h3>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={scenarioComparisons} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                  <YAxis stroke="#94a3b8" fontSize={11} unit="M" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                    formatter={(value: any) => [`$${value}M`]}
                  />
                  <Legend verticalAlign="top" height={36} />
                  <Bar dataKey="Revenue" name="Cumulative Revenue" fill="#FDBA74" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="FCF" name="Cumulative Free Cash Flow" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
