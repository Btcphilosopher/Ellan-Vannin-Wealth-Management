import React, { useState, useMemo } from 'react';
import { ReservoirAsset, PriceScenario, ValuationMetrics, AnnualCashFlow } from '../types';
import { calculateCashFlows, evaluateAsset } from '../utils/economics';
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Database, TrendingUp, DollarSign, Percent, Landmark, BarChart3, PieChartIcon, ShieldAlert } from 'lucide-react';

interface PortfolioDashboardProps {
  assets: ReservoirAsset[];
  scenario: PriceScenario;
  scenarios: PriceScenario[];
  discountRate: number;
  horizonYears: number;
  onSelectAsset: (asset: ReservoirAsset) => void;
  onSelectTab: (tab: string) => void;
}

export default function PortfolioDashboard({
  assets,
  scenario,
  scenarios,
  discountRate,
  horizonYears,
  onSelectAsset,
  onSelectTab,
}: PortfolioDashboardProps) {
  // Aggregate Metrics
  const summary = useMemo(() => {
    let totalReserves = 0;
    let totalProduction = 0;
    let totalRevenue = 0;
    let totalNPV = 0;
    let totalCapex = 0;
    let totalOpex = 0;
    let totalFCF = 0;
    let weightedIrrSum = 0;

    const evaluatedAssets = assets.map(asset => {
      const metrics = evaluateAsset(asset, scenario, discountRate, horizonYears);
      totalReserves += asset.remainingReserves;
      totalProduction += asset.currentProduction; // current annual prod
      totalRevenue += metrics.totalRevenue;
      totalNPV += metrics.npv;
      totalCapex += metrics.totalCapex;
      totalOpex += metrics.totalOpex;
      totalFCF += metrics.totalFreeCashFlow;
      
      // Weight IRR by NPV (or reserves)
      const weight = Math.max(0, metrics.npv);
      weightedIrrSum += (isNaN(metrics.irr) ? 0 : metrics.irr) * weight;

      return { asset, metrics };
    });

    const sumNPVPositive = evaluatedAssets.reduce((sum, item) => sum + Math.max(0, item.metrics.npv), 0);
    const weightedAvgIrr = sumNPVPositive > 0 ? (weightedIrrSum / sumNPVPositive) : 0.08;

    return {
      totalReserves,
      totalProduction,
      expectedAnnualRevenue: totalRevenue / horizonYears,
      portfolioNPV: totalNPV,
      weightedAvgIrr,
      annualFreeCashFlow: totalFCF / horizonYears,
      evaluatedAssets,
    };
  }, [assets, scenario, discountRate, horizonYears]);

  // Year-by-year production & cash flow curves aggregated for the portfolio
  const portfolioTimeline = useMemo(() => {
    const timeline: { [year: number]: { production: number; fcf: number; revenue: number; capex: number; opex: number } } = {};

    for (let year = 1; year <= horizonYears; year++) {
      timeline[year] = { production: 0, fcf: 0, revenue: 0, capex: 0, opex: 0 };
    }

    assets.forEach(asset => {
      const cashFlows = calculateCashFlows(asset, scenario, discountRate, horizonYears);
      cashFlows.forEach(cf => {
        if (timeline[cf.year]) {
          timeline[cf.year].production += cf.production;
          timeline[cf.year].fcf += cf.freeCashFlow;
          timeline[cf.year].revenue += cf.revenue;
          timeline[cf.year].capex += cf.capex;
          timeline[cf.year].opex += cf.opexTotal;
        }
      });
    });

    return Object.keys(timeline).map(year => ({
      year: `Year ${year}`,
      production: Number(timeline[Number(year)].production.toFixed(2)),
      fcf: Number(timeline[Number(year)].fcf.toFixed(2)),
      revenue: Number(timeline[Number(year)].revenue.toFixed(2)),
      capex: Number(timeline[Number(year)].capex.toFixed(2)),
      opex: Number(timeline[Number(year)].opex.toFixed(2)),
    }));
  }, [assets, scenario, discountRate, horizonYears]);

  // Asset allocation by Country and Operator
  const allocationData = useMemo(() => {
    const countryMap: { [key: string]: number } = {};
    const operatorMap: { [key: string]: number } = {};

    summary.evaluatedAssets.forEach(({ asset, metrics }) => {
      const npvVal = Math.max(0, metrics.npv);
      countryMap[asset.country] = (countryMap[asset.country] || 0) + npvVal;
      operatorMap[asset.operator] = (operatorMap[asset.operator] || 0) + npvVal;
    });

    const countryData = Object.keys(countryMap).map(key => ({
      name: key,
      value: Number(countryMap[key].toFixed(1)),
    })).sort((a, b) => b.value - a.value);

    const operatorData = Object.keys(operatorMap).map(key => ({
      name: key,
      value: Number(operatorMap[key].toFixed(1)),
    })).sort((a, b) => b.value - a.value);

    return { countryData, operatorData };
  }, [summary]);

  // Scenario Comparison Data
  const scenarioNPVData = useMemo(() => {
    return scenarios.map(sc => {
      let totalNPV = 0;
      assets.forEach(asset => {
        const cashFlows = calculateCashFlows(asset, sc, discountRate, horizonYears);
        const npv = cashFlows.reduce((sum, cf) => sum + cf.discountedCashFlow, 0);
        totalNPV += npv;
      });
      return {
        name: sc.name,
        NPV: Number(totalNPV.toFixed(1)),
        oilPrice: sc.oilPrice,
      };
    });
  }, [assets, scenarios, discountRate, horizonYears]);

  const COLORS = ['#FDBA74', '#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  return (
    <div id="portfolio-dashboard" className="space-y-6 text-slate-100">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Ellan Vannin Portfolio Dashboard</h1>
          <p className="text-slate-400 text-sm mt-1">
            Overview of {assets.length} reservoir assets. Active Valuation Scenario: <span className="text-peach font-semibold">{scenario.name}</span> (Oil: ${scenario.oilPrice}/bbl, Gas: ${scenario.gasPrice}/Mscf)
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => onSelectTab('assets')}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-medium transition duration-150 shadow border border-slate-700/60"
          >
            Manage Assets
          </button>
          <button
            onClick={() => onSelectTab('reporting')}
            className="px-4 py-2 bg-peach hover:bg-peach/90 text-slate-950 rounded-lg text-sm font-bold transition duration-150 shadow"
          >
            Export Committee Memo
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 text-peach/10 group-hover:text-peach/20 transition-colors">
            <Database className="w-16 h-16" />
          </div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Total Reserves</span>
          <span className="text-3xl font-bold mt-2 block text-white">{summary.totalReserves.toFixed(1)} <span className="text-sm font-normal text-slate-400">MMboe</span></span>
          <p className="text-xs text-slate-500 mt-2">Combined portfolio volume</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 text-emerald-500/10 group-hover:text-emerald-500/20 transition-colors">
            <TrendingUp className="w-16 h-16" />
          </div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Current Production</span>
          <span className="text-3xl font-bold mt-2 block text-white">{summary.totalProduction.toFixed(2)} <span className="text-sm font-normal text-slate-400">MMboe/y</span></span>
          <p className="text-xs text-slate-500 mt-2">Current annual operating rate</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 text-amber-500/10 group-hover:text-amber-500/20 transition-colors">
            <DollarSign className="w-16 h-16" />
          </div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Expected Revenue</span>
          <span className="text-3xl font-bold mt-2 block text-white">${summary.expectedAnnualRevenue.toFixed(1)}M <span className="text-sm font-normal text-slate-400">/yr</span></span>
          <p className="text-xs text-slate-500 mt-2">Expected yearly sales average</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 text-violet-500/10 group-hover:text-violet-500/20 transition-colors">
            <Landmark className="w-16 h-16" />
          </div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Portfolio NPV</span>
          <span className="text-3xl font-bold mt-2 block text-emerald-400">${summary.portfolioNPV.toFixed(1)}M</span>
          <p className="text-xs text-slate-500 mt-2">At {discountRate * 100}% discount rate</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 text-rose-500/10 group-hover:text-rose-500/20 transition-colors">
            <Percent className="w-16 h-16" />
          </div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Weighted IRR</span>
          <span className="text-3xl font-bold mt-2 block text-peach">{(summary.weightedAvgIrr * 100).toFixed(1)}%</span>
          <p className="text-xs text-slate-500 mt-2">Weighted by asset positive NPV</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 text-teal-500/10 group-hover:text-teal-500/20 transition-colors">
            <DollarSign className="w-16 h-16" />
          </div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Avg Free Cash Flow</span>
          <span className="text-3xl font-bold mt-2 block text-teal-400">${summary.annualFreeCashFlow.toFixed(1)}M <span className="text-sm font-normal text-slate-400">/yr</span></span>
          <p className="text-xs text-slate-500 mt-2">Yearly operating cash yield</p>
        </div>
      </div>

      {/* Main Analytical Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Production Profile Over Time */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-peach" />
            <h3 className="text-lg font-semibold text-white">Cumulative Production Forecast (Portfolio)</h3>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={portfolioTimeline} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorProd" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FDBA74" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#FDBA74" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="year" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} unit="M" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                  labelStyle={{ fontWeight: 'bold', color: '#94a3b8' }}
                />
                <Area type="monotone" dataKey="production" name="Combined Production (MMboe)" stroke="#FDBA74" strokeWidth={2} fillOpacity={1} fill="url(#colorProd)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <span className="text-xs text-slate-400 mt-2 text-center italic">Combined production profiles decaying per customized exponential/hyperbolic decline rules.</span>
        </div>

        {/* Chart 2: Annual FCF Schedule */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <h3 className="text-lg font-semibold text-white">Aggregated Free Cash Flow Schedule</h3>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={portfolioTimeline} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="year" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} unit="M" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                  formatter={(value: any) => [`$${value}M`, 'Free Cash Flow']}
                />
                <Bar 
                  dataKey="fcf" 
                  name="FCF ($ Millions)" 
                  fill="#10b981"
                  radius={[4, 4, 0, 0]}
                >
                  {portfolioTimeline.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fcf >= 0 ? '#10b981' : '#f43f5e'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <span className="text-xs text-slate-400 mt-2 text-center italic">Includes capital expenditure, operating costs, emissions costs, and decommissioning.</span>
        </div>

        {/* Chart 3: Asset NPV Distribution (Allocation) */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <PieChartIcon className="w-5 h-5 text-amber-400" />
              <h3 className="text-lg font-semibold text-white">Portfolio Value by operator</h3>
            </div>
          </div>
          <div className="h-64 w-full flex flex-col md:flex-row items-center justify-center gap-6">
            <div className="w-1/2 h-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={allocationData.operatorData.filter(d => d.value > 0)}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {allocationData.operatorData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: any) => [`$${value}M NPV`, 'Value Contribution']} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="w-1/2 space-y-2">
              <h4 className="text-sm font-semibold text-slate-300">Operator Contribution (NPV)</h4>
              <div className="max-h-48 overflow-y-auto space-y-1 pr-2">
                {allocationData.operatorData.map((entry, idx) => (
                  <div key={entry.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 truncate">
                      <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                      <span className="text-slate-400 truncate">{entry.name}</span>
                    </div>
                    <span className="font-semibold text-white">${entry.value}M</span>
                  </div>
                ))}
                {allocationData.operatorData.length === 0 && (
                  <p className="text-slate-500 italic">No positive asset value allocated.</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Chart 4: Scenario NPV Comparison */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="w-5 h-5 text-violet-400" />
            <h3 className="text-lg font-semibold text-white">Market Scenario Impact on Portfolio NPV</h3>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={scenarioNPVData} layout="vertical" margin={{ top: 10, right: 20, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis type="number" stroke="#94a3b8" fontSize={11} unit="M" />
                <YAxis dataKey="name" type="category" stroke="#94a3b8" fontSize={11} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                  formatter={(value: any) => [`$${value}M`, 'Portfolio NPV']}
                />
                <Bar dataKey="NPV" fill="#8b5cf6" radius={[0, 4, 4, 0]}>
                  {scenarioNPVData.map((entry, index) => {
                    let color = '#8b5cf6';
                    if (entry.name === 'Low') color = '#f43f5e';
                    if (entry.name === 'High') color = '#10b981';
                    if (entry.name === 'Base') color = '#FDBA74';
                    return <Cell key={`cell-${index}`} fill={color} />;
                  })}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <span className="text-xs text-slate-400 mt-1 text-center">Portfolio NPV dynamically aggregated across Low ($45), Base ($75), High ($105), and Custom scenarios.</span>
        </div>
      </div>

      {/* Assets Asset Table Summary */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <h3 className="text-lg font-semibold text-white mb-4">Asset Performance Ranking</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-xs uppercase tracking-wider">
                <th className="py-3 px-4">Asset</th>
                <th className="py-3 px-4">Operator</th>
                <th className="py-3 px-4">Country</th>
                <th className="py-3 px-4 text-right">Reserves (MMboe)</th>
                <th className="py-3 px-4 text-right">NPV ({discountRate * 100}%)</th>
                <th className="py-3 px-4 text-right">IRR %</th>
                <th className="py-3 px-4 text-right">Payback (Yrs)</th>
                <th className="py-3 px-4 text-right">Carbon Intensity</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {summary.evaluatedAssets.map(({ asset, metrics }) => (
                <tr key={asset.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-medium text-white">{asset.name}</td>
                  <td className="py-3 px-4 text-slate-400">{asset.operator}</td>
                  <td className="py-3 px-4 text-slate-400">{asset.country}</td>
                  <td className="py-3 px-4 text-right">{asset.remainingReserves.toFixed(1)}</td>
                  <td className={`py-3 px-4 text-right font-semibold ${metrics.npv >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    ${metrics.npv.toFixed(1)}M
                  </td>
                  <td className="py-3 px-4 text-right text-peach font-semibold">
                    {isNaN(metrics.irr) ? 'N/A' : `${(metrics.irr * 100).toFixed(1)}%`}
                  </td>
                  <td className="py-3 px-4 text-right">
                    {isNaN(metrics.paybackPeriod) ? 'N/A' : `${metrics.paybackPeriod.toFixed(1)} y`}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-400">
                    {asset.carbonIntensity.toFixed(1)} <span className="text-[10px]">kg/boe</span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => onSelectAsset(asset)}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 hover:text-white rounded text-xs transition-colors"
                    >
                      Analyze
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
