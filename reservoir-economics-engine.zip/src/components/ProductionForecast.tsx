import React, { useState, useMemo } from 'react';
import { ReservoirAsset, DeclineType } from '../types';
import { forecastProduction } from '../utils/economics';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Sliders, Calendar, ChevronRight, HelpCircle, Save, Info } from 'lucide-react';

interface ProductionForecastProps {
  asset: ReservoirAsset;
  onUpdateAsset: (asset: ReservoirAsset) => void;
  horizonYears: number;
}

export default function ProductionForecast({
  asset,
  onUpdateAsset,
  horizonYears,
}: ProductionForecastProps) {
  const [localHorizon, setLocalHorizon] = useState(horizonYears);
  
  // Local editable variables for reactive simulations
  const [initialProd, setInitialProd] = useState(asset.currentProduction);
  const [declineRate, setDeclineRate] = useState(asset.declineRate * 100); // as percentage
  const [declineType, setDeclineType] = useState<DeclineType>(asset.declineType);
  const [hyperbolicB, setHyperbolicB] = useState(asset.hyperbolicB);
  const [flatPeriod, setFlatPeriod] = useState(asset.flatPeriod);

  // User Custom Profile Editor
  const [customProfileStr, setCustomProfileStr] = useState(
    asset.userProductionProfile
      ? asset.userProductionProfile.join(', ')
      : Array.from({ length: 15 }, (_, i) => Math.max(0, asset.currentProduction * Math.pow(0.9, i)).toFixed(1)).join(', ')
  );

  const [customProfileError, setCustomProfileError] = useState<string | null>(null);

  // Sync state if asset changes
  useMemo(() => {
    setInitialProd(asset.currentProduction);
    setDeclineRate(asset.declineRate * 100);
    setDeclineType(asset.declineType);
    setHyperbolicB(asset.hyperbolicB);
    setFlatPeriod(asset.flatPeriod);
    setCustomProfileStr(
      asset.userProductionProfile
        ? asset.userProductionProfile.join(', ')
        : Array.from({ length: 15 }, (_, i) => Math.max(0, asset.currentProduction * Math.pow(0.9, i)).toFixed(1)).join(', ')
    );
  }, [asset]);

  // Forecast results based on active local inputs
  const simulatedAsset = useMemo<ReservoirAsset>(() => {
    let customArr: number[] | undefined;
    if (declineType === 'user-defined') {
      try {
        customArr = customProfileStr
          .split(',')
          .map(v => Number(v.trim()))
          .filter(v => !isNaN(v));
      } catch (e) {}
    }

    return {
      ...asset,
      currentProduction: initialProd,
      declineRate: declineRate / 100,
      declineType,
      hyperbolicB,
      flatPeriod,
      userProductionProfile: customArr,
    };
  }, [asset, initialProd, declineRate, declineType, hyperbolicB, flatPeriod, customProfileStr]);

  // Forecast computation
  const forecastResults = useMemo(() => {
    // Generate exponential curve for comparison
    const expAsset: ReservoirAsset = { ...simulatedAsset, declineType: 'exponential' };
    const expProfile = forecastProduction(expAsset, localHorizon);

    // Generate hyperbolic curve for comparison
    const hypAsset: ReservoirAsset = { ...simulatedAsset, declineType: 'hyperbolic' };
    const hypProfile = forecastProduction(hypAsset, localHorizon);

    // Generate active selected profile
    const activeProfile = forecastProduction(simulatedAsset, localHorizon);

    let cumulativeActive = 0;
    const tableData = activeProfile.map((prod, idx) => {
      cumulativeActive += prod;
      const remainingReserves = Math.max(0, asset.remainingReserves - cumulativeActive);

      return {
        year: idx + 1,
        yearLabel: `Year ${idx + 1}`,
        production: Number(prod.toFixed(2)),
        cumulativeProduction: Number(cumulativeActive.toFixed(2)),
        remainingReserves: Number(remainingReserves.toFixed(2)),
        exponentialProd: Number(expProfile[idx].toFixed(2)),
        hyperbolicProd: Number(hypProfile[idx].toFixed(2)),
      };
    });

    return { tableData, activeProfile, finalCumulative: cumulativeActive };
  }, [simulatedAsset, localHorizon, asset.remainingReserves]);

  const handleApplyToAsset = () => {
    onUpdateAsset(simulatedAsset);
    alert('Production parameters updated in asset register!');
  };

  const handleCustomProfileSave = () => {
    try {
      const arr = customProfileStr
        .split(',')
        .map(v => {
          const num = Number(v.trim());
          if (isNaN(num)) throw new Error('Invalid number');
          return num;
        });
      setCustomProfileError(null);
      const updated = { ...simulatedAsset, userProductionProfile: arr, declineType: 'user-defined' as DeclineType };
      onUpdateAsset(updated);
      setDeclineType('user-defined');
      alert('Custom production profile applied and saved!');
    } catch (e) {
      setCustomProfileError('Failed to parse comma-separated numbers. Ensure only numbers and commas are present.');
    }
  };

  return (
    <div id="production-forecasting" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Parameters Panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-6">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
          <Sliders className="w-5 h-5 text-peach" />
          <h3 className="text-lg font-bold text-white">Decline Assumptions</h3>
        </div>

        {/* Selected Asset Info Banner */}
        <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800/80">
          <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block">Currently Forecasting</span>
          <span className="text-sm font-semibold text-white block mt-0.5">{asset.name}</span>
          <span className="text-xs text-slate-400 block mt-0.5">Estimated Reserves: <strong className="text-slate-300">{asset.remainingReserves.toFixed(1)} MMboe</strong></span>
        </div>

        {/* Decline Type Select */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">Decline Methodology</label>
          <select
            value={declineType}
            onChange={(e) => setDeclineType(e.target.value as DeclineType)}
            className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-peach focus:ring-1 focus:ring-peach rounded-lg outline-none cursor-pointer"
          >
            <option value="exponential">Exponential Decline (Standard)</option>
            <option value="hyperbolic">Hyperbolic Decline (Arps Equation)</option>
            <option value="user-defined">User Defined Production Profile</option>
          </select>
        </div>

        {/* Inputs Sliders Grid */}
        <div className="space-y-4">
          {/* Initial Production */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400">Initial Production (q0)</span>
              <span className="font-mono font-semibold text-white">{initialProd.toFixed(2)} MMboe/y</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="50"
              step="0.1"
              value={initialProd}
              onChange={(e) => setInitialProd(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-peach"
            />
          </div>

          {/* Decline Rate */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400">Nominal Decline Rate (di)</span>
              <span className="font-mono font-semibold text-white">{declineRate.toFixed(1)}% /yr</span>
            </div>
            <input
              type="range"
              min="1"
              max="40"
              step="0.5"
              value={declineRate}
              onChange={(e) => setDeclineRate(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-peach"
            />
          </div>

          {/* Flat Plateau Period */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400">Flat Plateau Period</span>
              <span className="font-mono font-semibold text-white">{flatPeriod} Years</span>
            </div>
            <input
              type="range"
              min="0"
              max="10"
              step="1"
              value={flatPeriod}
              onChange={(e) => setFlatPeriod(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-peach"
            />
          </div>

          {/* Hyperbolic B Factor */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className={`text-slate-400 ${declineType !== 'hyperbolic' ? 'opacity-30' : ''}`}>Arps Exponent (b-factor)</span>
              <span className={`font-mono font-semibold text-white ${declineType !== 'hyperbolic' ? 'opacity-30' : ''}`}>{hyperbolicB.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="0.9"
              step="0.05"
              disabled={declineType !== 'hyperbolic'}
              value={hyperbolicB}
              onChange={(e) => setHyperbolicB(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none disabled:opacity-30 cursor-pointer accent-peach"
            />
          </div>

          {/* Horizon Slider */}
          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400">Forecast Horizon</span>
              <span className="font-mono font-semibold text-white">{localHorizon} Years</span>
            </div>
            <input
              type="range"
              min="5"
              max="40"
              step="1"
              value={localHorizon}
              onChange={(e) => setLocalHorizon(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-peach"
            />
          </div>
        </div>

        {/* User-Defined Input Fields */}
        {declineType === 'user-defined' && (
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-3">
            <div className="flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-xs font-semibold text-slate-300">Custom Yearly Schedule</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Input comma-separated production rates (MMboe/year) for each year starting from Year 1.
            </p>
            <textarea
              value={customProfileStr}
              onChange={(e) => setCustomProfileStr(e.target.value)}
              rows={3}
              className="w-full p-2 bg-slate-900 border border-slate-800 rounded text-xs text-slate-200 outline-none focus:border-blue-500 font-mono"
            />
            {customProfileError && (
              <span className="text-[10px] text-rose-400 block">{customProfileError}</span>
            )}
            <button
              onClick={handleCustomProfileSave}
              className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Apply Custom Profile</span>
            </button>
          </div>
        )}

        {/* Apply/Save Button */}
        <div className="pt-4 border-t border-slate-800">
          <button
            onClick={handleApplyToAsset}
            className="w-full py-2 bg-peach hover:bg-peach/90 text-slate-950 rounded-lg text-xs font-bold transition shadow-md shadow-peach/10"
          >
            Save Assumptions to Asset
          </button>
        </div>
      </div>

      {/* Forecasting Charts & Profiles */}
      <div className="lg:col-span-2 space-y-6">
        {/* Decline Chart Comparison */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <h3 className="text-lg font-bold text-white">Decline Forecast Curve Comparison</h3>
          </div>

          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={forecastResults.tableData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="yearLabel" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} unit="M" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                  labelStyle={{ fontWeight: 'bold' }}
                />
                <Legend verticalAlign="top" height={36} iconType="circle" />
                
                {/* Always show Exponential & Hyperbolic as comparisons */}
                <Line 
                  type="monotone" 
                  dataKey="exponentialProd" 
                  name="Exponential Decline" 
                  stroke="#ef4444" 
                  strokeDasharray="4 4"
                  strokeWidth={1.5}
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="hyperbolicProd" 
                  name="Hyperbolic (Arps) Decline" 
                  stroke="#FDBA74" 
                  strokeDasharray="4 4"
                  strokeWidth={1.5}
                  dot={false}
                />

                {/* Show Selected Active Profile */}
                <Line 
                  type="monotone" 
                  dataKey="production" 
                  name="Active Forecast Curve" 
                  stroke="#10b981" 
                  strokeWidth={3}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs text-slate-400 text-center mt-2">
            Active methodology: <span className="font-semibold text-emerald-400 capitalize">{declineType} decline</span>. Cumulative production under active scenario is <span className="font-semibold text-white">{forecastResults.finalCumulative.toFixed(1)} MMboe</span>.
          </p>
        </div>

        {/* Detailed Annual Schedule Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <h4 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Annual Production Forecast Schedule</h4>
          <div className="max-h-64 overflow-y-auto border border-slate-800 rounded-lg">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950/70 border-b border-slate-800 text-slate-400 font-semibold select-none">
                  <th className="py-2.5 px-4">Year</th>
                  <th className="py-2.5 px-4 text-right">Production (MMboe)</th>
                  <th className="py-2.5 px-4 text-right">Cumulative Prod (MMboe)</th>
                  <th className="py-2.5 px-4 text-right">Remaining Recoverable (MMboe)</th>
                  <th className="py-2.5 px-4 text-right">Depletion Ratio %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300 font-mono">
                {forecastResults.tableData.map((row) => {
                  const depletionRatio = (row.cumulativeProduction / asset.remainingReserves) * 100;
                  return (
                    <tr key={row.year} className="hover:bg-slate-800/20">
                      <td className="py-2 px-4 text-slate-400">Year {row.year}</td>
                      <td className="py-2 px-4 text-right text-emerald-400 font-semibold">{row.production.toFixed(2)}</td>
                      <td className="py-2 px-4 text-right text-slate-300">{row.cumulativeProduction.toFixed(2)}</td>
                      <td className="py-2 px-4 text-right text-slate-400">{row.remainingReserves.toFixed(2)}</td>
                      <td className="py-2 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <span className="text-[10px] text-slate-400">{depletionRatio.toFixed(1)}%</span>
                          <div className="w-12 bg-slate-950 h-1.5 rounded-full overflow-hidden shrink-0">
                            <div className="bg-peach h-full" style={{ width: `${Math.min(100, depletionRatio)}%` }} />
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
