import React, { useState, useMemo } from 'react';
import { ReservoirAsset, FieldStatus, DeclineType } from '../types';
import { Plus, Download, Upload, Trash2, Edit2, Search, Filter, HelpCircle, X, ChevronDown, ChevronUp } from 'lucide-react';

interface AssetRegisterProps {
  assets: ReservoirAsset[];
  onAddAsset: (asset: ReservoirAsset) => void;
  onUpdateAsset: (asset: ReservoirAsset) => void;
  onDeleteAsset: (id: string) => void;
  onSelectAsset: (asset: ReservoirAsset) => void;
}

export default function AssetRegister({
  assets,
  onAddAsset,
  onUpdateAsset,
  onDeleteAsset,
  onSelectAsset,
}: AssetRegisterProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [sortField, setSortField] = useState<keyof ReservoirAsset>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  
  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<ReservoirAsset | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Form State
  const [formName, setFormName] = useState('');
  const [formOperator, setFormOperator] = useState('');
  const [formCountry, setFormCountry] = useState('');
  const [formWaterDepth, setFormWaterDepth] = useState(0);
  const [formFieldStatus, setFormFieldStatus] = useState<FieldStatus>('Production');
  const [formStartYear, setFormStartYear] = useState(2020);
  const [formRemainingReserves, setFormRemainingReserves] = useState(100);
  const [formCurrentProduction, setFormCurrentProduction] = useState(10);
  const [formDeclineRate, setFormDeclineRate] = useState(10); // UI displays percentage
  const [formDeclineType, setFormDeclineType] = useState<DeclineType>('exponential');
  const [formHyperbolicB, setFormHyperbolicB] = useState(0.4);
  const [formFlatPeriod, setFormFlatPeriod] = useState(0);
  const [formOpexFixed, setFormOpexFixed] = useState(15);
  const [formOpexVariable, setFormOpexVariable] = useState(10);
  const [formCapex, setFormCapex] = useState(100);
  const [formCapexDuration, setFormCapexDuration] = useState(3);
  const [formRemainingLife, setFormRemainingLife] = useState(15);
  const [formDecommissioning, setFormDecommissioning] = useState(50);
  const [formCarbonIntensity, setFormCarbonIntensity] = useState(15);
  const [formLatitude, setFormLatitude] = useState(0);
  const [formLongitude, setFormLongitude] = useState(0);

  // Sorting handler
  const handleSort = (field: keyof ReservoirAsset) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Filter & Search
  const filteredAssets = useMemo(() => {
    return assets
      .filter(asset => {
        const matchesSearch =
          asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          asset.operator.toLowerCase().includes(searchTerm.toLowerCase()) ||
          asset.country.toLowerCase().includes(searchTerm.toLowerCase());
        
        const matchesStatus = statusFilter === 'All' || asset.fieldStatus === statusFilter;
        
        return matchesSearch && matchesStatus;
      })
      .sort((a, b) => {
        let aVal = a[sortField];
        let bVal = b[sortField];

        if (typeof aVal === 'string' && typeof bVal === 'string') {
          return sortDirection === 'asc'
            ? aVal.localeCompare(bVal)
            : bVal.localeCompare(aVal);
        }

        if (typeof aVal === 'number' && typeof bVal === 'number') {
          return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
        }

        return 0;
      });
  }, [assets, searchTerm, statusFilter, sortField, sortDirection]);

  // Open modal for Add
  const handleOpenAdd = () => {
    setEditingAsset(null);
    setFormName('');
    setFormOperator('');
    setFormCountry('');
    setFormWaterDepth(0);
    setFormFieldStatus('Production');
    setFormStartYear(new Date().getFullYear());
    setFormRemainingReserves(100);
    setFormCurrentProduction(8.5);
    setFormDeclineRate(8);
    setFormDeclineType('exponential');
    setFormHyperbolicB(0.4);
    setFormFlatPeriod(0);
    setFormOpexFixed(20);
    setFormOpexVariable(12);
    setFormCapex(120);
    setFormCapexDuration(3);
    setFormRemainingLife(15);
    setFormDecommissioning(40);
    setFormCarbonIntensity(14);
    setFormLatitude(30);
    setFormLongitude(10);
    setErrorMsg(null);
    setIsModalOpen(true);
  };

  // Open modal for Edit
  const handleOpenEdit = (asset: ReservoirAsset, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingAsset(asset);
    setFormName(asset.name);
    setFormOperator(asset.operator);
    setFormCountry(asset.country);
    setFormWaterDepth(asset.waterDepth);
    setFormFieldStatus(asset.fieldStatus);
    setFormStartYear(asset.startYear);
    setFormRemainingReserves(asset.remainingReserves);
    setFormCurrentProduction(asset.currentProduction);
    setFormDeclineRate(asset.declineRate * 100);
    setFormDeclineType(asset.declineType);
    setFormHyperbolicB(asset.hyperbolicB);
    setFormFlatPeriod(asset.flatPeriod);
    setFormOpexFixed(asset.opexFixed);
    setFormOpexVariable(asset.opexVariable);
    setFormCapex(asset.capex);
    setFormCapexDuration(asset.capexDuration);
    setFormRemainingLife(asset.remainingLife);
    setFormDecommissioning(asset.decommissioningProvision);
    setFormCarbonIntensity(asset.carbonIntensity);
    setFormLatitude(asset.latitude);
    setFormLongitude(asset.longitude);
    setErrorMsg(null);
    setIsModalOpen(true);
  };

  // Submit modal form
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formOperator.trim() || !formCountry.trim()) {
      setErrorMsg('Name, Operator, and Country are required fields.');
      return;
    }

    const payload: ReservoirAsset = {
      id: editingAsset ? editingAsset.id : `res-${Date.now()}`,
      name: formName.trim(),
      operator: formOperator.trim(),
      country: formCountry.trim(),
      waterDepth: Number(formWaterDepth),
      fieldStatus: formFieldStatus,
      startYear: Number(formStartYear),
      remainingReserves: Number(formRemainingReserves),
      currentProduction: Number(formCurrentProduction),
      declineRate: Number(formDeclineRate) / 100,
      declineType: formDeclineType,
      hyperbolicB: Number(formHyperbolicB),
      flatPeriod: Number(formFlatPeriod),
      opexFixed: Number(formOpexFixed),
      opexVariable: Number(formOpexVariable),
      capex: Number(formCapex),
      capexDuration: Number(formCapexDuration),
      remainingLife: Number(formRemainingLife),
      decommissioningProvision: Number(formDecommissioning),
      carbonIntensity: Number(formCarbonIntensity),
      latitude: Number(formLatitude),
      longitude: Number(formLongitude),
      userProductionProfile: editingAsset?.userProductionProfile,
    };

    if (editingAsset) {
      onUpdateAsset(payload);
    } else {
      onAddAsset(payload);
    }
    setIsModalOpen(false);
  };

  // Export to CSV
  const handleExportCSV = () => {
    const headers = [
      'id', 'name', 'operator', 'country', 'waterDepth', 'fieldStatus', 'startYear',
      'remainingReserves', 'currentProduction', 'declineRate', 'declineType', 'hyperbolicB',
      'flatPeriod', 'opexFixed', 'opexVariable', 'capex', 'capexDuration', 'remainingLife',
      'decommissioningProvision', 'carbonIntensity', 'latitude', 'longitude'
    ];

    const rows = assets.map(asset => [
      asset.id,
      `"${asset.name.replace(/"/g, '""')}"`,
      `"${asset.operator.replace(/"/g, '""')}"`,
      `"${asset.country.replace(/"/g, '""')}"`,
      asset.waterDepth,
      asset.fieldStatus,
      asset.startYear,
      asset.remainingReserves,
      asset.currentProduction,
      asset.declineRate,
      asset.declineType,
      asset.hyperbolicB,
      asset.flatPeriod,
      asset.opexFixed,
      asset.opexVariable,
      asset.capex,
      asset.capexDuration,
      asset.remainingLife,
      asset.decommissioningProvision,
      asset.carbonIntensity,
      asset.latitude,
      asset.longitude
    ]);

    const csvContent = [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `ree_asset_register_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Import from CSV
  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      try {
        const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
        if (lines.length <= 1) throw new Error('No data found in file');

        const headers = lines[0].split(',').map(h => h.trim().replace(/^["']|["']$/g, ''));
        const importedList: ReservoirAsset[] = [];

        for (let i = 1; i < lines.length; i++) {
          // simple CSV splitter helper that respects quotes
          const rowValues: string[] = [];
          let currentVal = '';
          let inQuotes = false;
          
          for (let charIdx = 0; charIdx < lines[i].length; charIdx++) {
            const char = lines[i][charIdx];
            if (char === '"' || char === "'") {
              inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
              rowValues.push(currentVal.trim().replace(/^["']|["']$/g, ''));
              currentVal = '';
            } else {
              currentVal += char;
            }
          }
          rowValues.push(currentVal.trim().replace(/^["']|["']$/g, ''));

          // Map values
          const item: any = {};
          headers.forEach((header, index) => {
            const val = rowValues[index];
            if (val === undefined) return;
            
            // cast to number if possible
            if (['waterDepth', 'startYear', 'remainingReserves', 'currentProduction', 'declineRate', 'hyperbolicB', 'flatPeriod', 'opexFixed', 'opexVariable', 'capex', 'capexDuration', 'remainingLife', 'decommissioningProvision', 'carbonIntensity', 'latitude', 'longitude'].includes(header)) {
              item[header] = Number(val);
            } else {
              item[header] = val;
            }
          });

          // check structural integrity
          if (item.name && item.operator && item.country) {
            importedList.push({
              id: item.id || `res-${Date.now()}-${i}`,
              name: item.name,
              operator: item.operator,
              country: item.country,
              waterDepth: item.waterDepth || 0,
              fieldStatus: (item.fieldStatus as FieldStatus) || 'Production',
              startYear: item.startYear || 2020,
              remainingReserves: item.remainingReserves || 50,
              currentProduction: item.currentProduction || 5,
              declineRate: item.declineRate || 0.1,
              declineType: (item.declineType as DeclineType) || 'exponential',
              hyperbolicB: item.hyperbolicB || 0.4,
              flatPeriod: item.flatPeriod || 0,
              opexFixed: item.opexFixed || 10,
              opexVariable: item.opexVariable || 12,
              capex: item.capex || 50,
              capexDuration: item.capexDuration || 3,
              remainingLife: item.remainingLife || 15,
              decommissioningProvision: item.decommissioningProvision || 20,
              carbonIntensity: item.carbonIntensity || 15,
              latitude: item.latitude || 0,
              longitude: item.longitude || 0,
            });
          }
        }

        if (importedList.length > 0) {
          importedList.forEach(asset => onAddAsset(asset));
          alert(`Successfully imported ${importedList.length} assets!`);
        } else {
          alert('Could not find any valid reservoir records to import.');
        }
      } catch (err: any) {
        alert(`Failed to parse CSV: ${err.message}`);
      }
    };
    reader.readAsText(file);
    // Reset file input target
    e.target.value = '';
  };

  const renderSortIcon = (field: keyof ReservoirAsset) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? <ChevronUp className="w-4 h-4 ml-1" /> : <ChevronDown className="w-4 h-4 ml-1" />;
  };

  return (
    <div id="asset-register" className="space-y-6">
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            Asset Registry Database
          </h2>
          <p className="text-slate-400 text-sm">
            Maintain high-integrity records of reservoir physical parameters, cost configurations, and coordinates.
          </p>
        </div>
        
        {/* Actions Button Row */}
        <div className="flex flex-wrap items-center gap-3">
          <label className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-medium transition cursor-pointer border border-slate-700/60 shadow">
            <Upload className="w-4 h-4 text-slate-300" />
            <span>Import CSV</span>
            <input
              type="file"
              accept=".csv"
              onChange={handleImportCSV}
              className="hidden"
            />
          </label>
          
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-medium transition border border-slate-700/60 shadow"
          >
            <Download className="w-4 h-4 text-slate-300" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-2 px-4 py-1.5 bg-peach hover:bg-peach/90 text-slate-950 rounded-lg text-sm font-bold shadow transition duration-150"
          >
            <Plus className="w-4 h-4" />
            <span>New Asset</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800/80">
        <div className="relative md:col-span-2">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name, operator, or country..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-950/70 text-sm text-slate-200 border border-slate-800 focus:border-peach focus:ring-1 focus:ring-peach rounded-lg outline-none transition"
          />
        </div>
        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 bg-slate-950/70 text-sm text-slate-200 border border-slate-800 focus:border-peach focus:ring-1 focus:ring-peach rounded-lg outline-none transition cursor-pointer"
          >
            <option value="All">All Field Statuses</option>
            <option value="Exploration">Exploration</option>
            <option value="Development">Development</option>
            <option value="Production">Production</option>
            <option value="Decline">Decline</option>
            <option value="Decommissioned">Decommissioned</option>
          </select>
        </div>
        <div className="flex items-center gap-2 justify-end text-xs text-slate-400">
          <span>Displaying <strong>{filteredAssets.length}</strong> of <strong>{assets.length}</strong> assets</span>
        </div>
      </div>

      {/* Main Asset Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="bg-slate-950/40 border-b border-slate-800 text-slate-400 text-xs font-semibold uppercase tracking-wider select-none">
                <th onClick={() => handleSort('name')} className="py-3 px-4 cursor-pointer hover:bg-slate-800/30 transition-colors">
                  <div className="flex items-center">Asset Name {renderSortIcon('name')}</div>
                </th>
                <th onClick={() => handleSort('operator')} className="py-3 px-4 cursor-pointer hover:bg-slate-800/30 transition-colors">
                  <div className="flex items-center">Operator {renderSortIcon('operator')}</div>
                </th>
                <th onClick={() => handleSort('country')} className="py-3 px-4 cursor-pointer hover:bg-slate-800/30 transition-colors">
                  <div className="flex items-center">Country {renderSortIcon('country')}</div>
                </th>
                <th onClick={() => handleSort('fieldStatus')} className="py-3 px-4 cursor-pointer hover:bg-slate-800/30 transition-colors">
                  <div className="flex items-center">Status {renderSortIcon('fieldStatus')}</div>
                </th>
                <th onClick={() => handleSort('remainingReserves')} className="py-3 px-4 text-right cursor-pointer hover:bg-slate-800/30 transition-colors">
                  <div className="flex items-center justify-end">Reserves (MMboe) {renderSortIcon('remainingReserves')}</div>
                </th>
                <th onClick={() => handleSort('currentProduction')} className="py-3 px-4 text-right cursor-pointer hover:bg-slate-800/30 transition-colors">
                  <div className="flex items-center justify-end">Prod (MMboe/y) {renderSortIcon('currentProduction')}</div>
                </th>
                <th onClick={() => handleSort('declineRate')} className="py-3 px-4 text-right cursor-pointer hover:bg-slate-800/30 transition-colors">
                  <div className="flex items-center justify-end">Decline Rate {renderSortIcon('declineRate')}</div>
                </th>
                <th onClick={() => handleSort('remainingLife')} className="py-3 px-4 text-right cursor-pointer hover:bg-slate-800/30 transition-colors">
                  <div className="flex items-center justify-end">Life (Yrs) {renderSortIcon('remainingLife')}</div>
                </th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {filteredAssets.map((asset) => (
                <tr
                  key={asset.id}
                  onClick={() => onSelectAsset(asset)}
                  className="hover:bg-slate-800/40 cursor-pointer transition-colors"
                >
                  <td className="py-3 px-4 font-medium text-white">{asset.name}</td>
                  <td className="py-3 px-4 text-slate-400">{asset.operator}</td>
                  <td className="py-3 px-4 text-slate-400">{asset.country}</td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium uppercase border ${
                      asset.fieldStatus === 'Production'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        : asset.fieldStatus === 'Decline'
                        ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        : asset.fieldStatus === 'Development'
                        ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                        : asset.fieldStatus === 'Exploration'
                        ? 'bg-violet-500/10 text-violet-400 border-violet-500/20'
                        : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                    }`}>
                      {asset.fieldStatus}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-medium text-slate-100">
                    {asset.remainingReserves.toFixed(1)}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-300">
                    {asset.currentProduction.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-right text-slate-400 font-mono">
                    {(asset.declineRate * 100).toFixed(0)}%
                    <span className="text-[10px] text-slate-500 capitalize ml-1">({asset.declineType})</span>
                  </td>
                  <td className="py-3 px-4 text-right text-slate-300 font-mono">
                    {asset.remainingLife} y
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={(e) => handleOpenEdit(asset, e)}
                        className="p-1.5 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded transition"
                        title="Edit Asset Settings"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`Are you sure you want to delete ${asset.name}?`)) {
                            onDeleteAsset(asset.id);
                          }
                        }}
                        className="p-1.5 text-slate-500 hover:text-rose-400 bg-slate-800/50 hover:bg-rose-950/20 rounded transition"
                        title="Delete Asset"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredAssets.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500 italic">
                    No assets found matching search criteria. Try modifying your search or filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Asset Editing/Creation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto flex flex-col shadow-2xl">
            {/* Modal Header */}
            <div className="flex justify-between items-center px-6 py-4 border-b border-slate-800">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                {editingAsset ? `Edit Asset: ${editingAsset.name}` : 'Register New Asset'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleFormSubmit} className="flex-1 p-6 space-y-6">
              {errorMsg && (
                <div className="p-3 bg-rose-950/30 border border-rose-900/60 text-rose-400 text-sm rounded-lg">
                  {errorMsg}
                </div>
              )}

              {/* Grid 1: Basic Identifiers */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">Asset Name *</label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Forties Field"
                    className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-lg outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">Operator *</label>
                  <input
                    type="text"
                    required
                    value={formOperator}
                    onChange={(e) => setFormOperator(e.target.value)}
                    placeholder="e.g. BP, Shell"
                    className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-lg outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">Country *</label>
                  <input
                    type="text"
                    required
                    value={formCountry}
                    onChange={(e) => setFormCountry(e.target.value)}
                    placeholder="e.g. United Kingdom"
                    className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-lg outline-none transition"
                  />
                </div>
              </div>

              {/* Grid 2: Operational Parameters */}
              <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800 space-y-4">
                <h4 className="text-xs font-bold text-blue-400 uppercase tracking-widest">Physical & Status Parameters</h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Field Status</label>
                    <select
                      value={formFieldStatus}
                      onChange={(e) => setFormFieldStatus(e.target.value as FieldStatus)}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none cursor-pointer"
                    >
                      <option value="Exploration">Exploration</option>
                      <option value="Development">Development</option>
                      <option value="Production">Production</option>
                      <option value="Decline">Decline</option>
                      <option value="Decommissioned">Decommissioned</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Start Year</label>
                    <input
                      type="number"
                      value={formStartYear}
                      onChange={(e) => setFormStartYear(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Water Depth (meters)</label>
                    <input
                      type="number"
                      value={formWaterDepth}
                      onChange={(e) => setFormWaterDepth(Number(e.target.value))}
                      placeholder="0 for Onshore"
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Remaining Asset Life (Yrs)</label>
                    <input
                      type="number"
                      value={formRemainingLife}
                      onChange={(e) => setFormRemainingLife(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Latitude Coordinate</label>
                    <input
                      type="number"
                      step="any"
                      value={formLatitude}
                      onChange={(e) => setFormLatitude(Number(e.target.value))}
                      placeholder="e.g. 56.4"
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Longitude Coordinate</label>
                    <input
                      type="number"
                      step="any"
                      value={formLongitude}
                      onChange={(e) => setFormLongitude(Number(e.target.value))}
                      placeholder="e.g. -2.1"
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Grid 3: Production Decline Assumptions */}
              <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800 space-y-4">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-widest">Production & Decline Assumptions</h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Remaining Reserves (MMboe)</label>
                    <input
                      type="number"
                      step="any"
                      value={formRemainingReserves}
                      onChange={(e) => setFormRemainingReserves(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Current Production (MMboe/y)</label>
                    <input
                      type="number"
                      step="any"
                      value={formCurrentProduction}
                      onChange={(e) => setFormCurrentProduction(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Annual Decline Rate (%)</label>
                    <input
                      type="number"
                      step="any"
                      value={formDeclineRate}
                      onChange={(e) => setFormDeclineRate(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Decline Formula Type</label>
                    <select
                      value={formDeclineType}
                      onChange={(e) => setFormDeclineType(e.target.value as DeclineType)}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none cursor-pointer"
                    >
                      <option value="exponential">Exponential Decline</option>
                      <option value="hyperbolic">Hyperbolic Decline</option>
                      <option value="user-defined">User Defined Profile</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">
                      Hyperbolic Exponent (b-factor) <span className="text-[10px] text-slate-500 font-normal">(0.1 - 0.9, Hyperbolic only)</span>
                    </label>
                    <input
                      type="number"
                      step="any"
                      disabled={formDeclineType !== 'hyperbolic'}
                      value={formHyperbolicB}
                      onChange={(e) => setFormHyperbolicB(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 disabled:opacity-40 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Flat Plateau Period (Years)</label>
                    <input
                      type="number"
                      value={formFlatPeriod}
                      onChange={(e) => setFormFlatPeriod(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Grid 4: Capital & Operating Expenditures */}
              <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800 space-y-4">
                <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-widest">CapEx, OpEx & Decommissioning</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Fixed Operating Cost (Million $/y)</label>
                    <input
                      type="number"
                      step="any"
                      value={formOpexFixed}
                      onChange={(e) => setFormOpexFixed(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Variable Operating Cost ($/boe)</label>
                    <input
                      type="number"
                      step="any"
                      value={formOpexVariable}
                      onChange={(e) => setFormOpexVariable(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Carbon Intensity (kg CO2 / boe)</label>
                    <input
                      type="number"
                      step="any"
                      value={formCarbonIntensity}
                      onChange={(e) => setFormCarbonIntensity(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Development CapEx (Million $)</label>
                    <input
                      type="number"
                      step="any"
                      value={formCapex}
                      onChange={(e) => setFormCapex(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">CapEx Spending Duration (Years)</label>
                    <input
                      type="number"
                      value={formCapexDuration}
                      onChange={(e) => setFormCapexDuration(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Decommissioning Provision (Million $)</label>
                    <input
                      type="number"
                      step="any"
                      value={formDecommissioning}
                      onChange={(e) => setFormDecommissioning(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 text-sm text-slate-200 border border-slate-800 focus:border-blue-500 rounded-lg outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Modal Footer Buttons */}
              <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-medium transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-sm font-semibold transition"
                >
                  {editingAsset ? 'Save Asset' : 'Register Asset'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
