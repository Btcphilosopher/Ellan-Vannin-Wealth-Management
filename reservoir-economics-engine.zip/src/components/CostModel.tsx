import React, { useMemo } from 'react';
import { ReservoirAsset, PriceScenario } from '../types';
import { calculateCashFlows } from '../utils/economics';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ShieldAlert, Activity, DollarSign, Database, Flame } from 'lucide-react';

interface CostModelProps {
  asset: ReservoirAsset;
  scenario: PriceScenario;
  discountRate: number;
  horizonYears: number;
}

export default function CostModel({
  asset,
  scenario,
  discountRate,
  horizonYears,
}: CostModelProps) {
  const cashFlows = useMemo(() => {
    return calculateCashFlows(asset, scenario, discountRate, horizonYears);
  }, [asset, scenario, discountRate, horizonYears]);

  // Totals
  const totals = useMemo(() => {
    let opexFixedTotal = 0;
    let opexVariableTotal = 0;
    let capexTotal = 0;
    let decommissioningTotal = 0;
    let carbonCostTotal = 0;
    let combinedTotal = 0;

    cashFlows.forEach(cf => {
      opexFixedTotal += cf.opexFixed;
      opexVariableTotal += cf.opexVariable;
      capexTotal += cf.capex;
      decommissioningTotal += cf.decommissioning;
      carbonCostTotal += cf.carbonCost;
      combinedTotal += cf.totalCost;
    });

    return {
      opexFixed: Number(opexFixedTotal.toFixed(1)),
      opexVariable: Number(opexVariableTotal.toFixed(1)),
      capex: Number(capexTotal.toFixed(1)),
      decommissioning: Number(decommissioningTotal.toFixed(1)),
      carbonCost: Number(carbonCostTotal.toFixed(1)),
      total: Number(combinedTotal.toFixed(1)),
    };
  }, [cashFlows]);

  // Format chart data
  const chartData = useMemo(() => {
    return cashFlows.map(cf => ({
      yearLabel: `Year ${cf.year}`,
      'Fixed OPEX': Number(cf.opexFixed.toFixed(2)),
      'Variable OPEX': Number(cf.opexVariable.toFixed(2)),
      'Development CAPEX': Number(cf.capex.toFixed(2)),
      'Carbon Costs': Number(cf.carbonCost.toFixed(2)),
      Decommissioning: Number(cf.decommissioning.toFixed(2)),
    }));
  }, [cashFlows]);

  return (
    <div id="cost-model" className="space-y-6">
      {/* Upper Cards: Cost distribution summary */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest block">Development CAPEX</span>
          <span className="text-2xl font-bold mt-1 block text-white">${totals.capex}M</span>
          <p className="text-[10px] text-slate-500 mt-1">Distributed over first {asset.capexDuration} years</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest block">Fixed Operating OPEX</span>
          <span className="text-2xl font-bold mt-1 block text-white">${totals.opexFixed}M</span>
          <p className="text-[10px] text-slate-500 mt-1">Base maintenance and logistics</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest block">Variable Production OPEX</span>
          <span className="text-2xl font-bold mt-1 block text-white">${totals.opexVariable}M</span>
          <p className="text-[10px] text-slate-500 mt-1">At ${asset.opexVariable}/boe variable cost</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest block">Decommissioning Asset</span>
          <span className="text-2xl font-bold mt-1 block text-amber-400">${totals.decommissioning}M</span>
          <p className="text-[10px] text-slate-500 mt-1">Spent in Year {asset.remainingLife} (final life year)</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest block">Carbon Emissions Tax</span>
          <span className="text-2xl font-bold mt-1 block text-rose-400">${totals.carbonCost}M</span>
          <p className="text-[10px] text-slate-500 mt-1">At ${scenario.carbonTax}/tonne CO2 tax</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Cost Schedule Area Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-5 h-5 text-peach" />
            <h3 className="text-lg font-bold text-white">Cumulative Cost Profile Schedule</h3>
          </div>

          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="yearLabel" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} unit="M" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                  labelStyle={{ fontWeight: 'bold' }}
                />
                <Legend verticalAlign="top" height={36} iconType="circle" />
                <Area type="monotone" dataKey="Development CAPEX" stackId="1" stroke="#FDBA74" fill="#FDBA74" fillOpacity={0.6} />
                <Area type="monotone" dataKey="Fixed OPEX" stackId="1" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.6} />
                <Area type="monotone" dataKey="Variable OPEX" stackId="1" stroke="#ec4899" fill="#ec4899" fillOpacity={0.6} />
                <Area type="monotone" dataKey="Carbon Costs" stackId="1" stroke="#ef4444" fill="#ef4444" fillOpacity={0.6} />
                <Area type="monotone" dataKey="Decommissioning" stackId="1" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-slate-400 italic text-center mt-2">
            Life-of-field aggregated cost is estimated at <strong className="text-white">${totals.total}M</strong>. This schedule includes inflation escalation factor of {scenario.inflationRate * 100}% per year.
          </p>
        </div>

        {/* Cost Schedule Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-white mb-3 uppercase tracking-wider">Life-of-Field Expenditure breakdown</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/60">
                <span className="text-slate-400">Total Capital Investment</span>
                <span className="font-semibold text-white font-mono">${totals.capex} Million</span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/60">
                <span className="text-slate-400">Total Operating Expenses (Fixed)</span>
                <span className="font-semibold text-white font-mono">${totals.opexFixed} Million</span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/60">
                <span className="text-slate-400">Total Operating Expenses (Variable)</span>
                <span className="font-semibold text-white font-mono">${totals.opexVariable} Million</span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/60">
                <span className="text-slate-400">Total Carbon/Emissions Taxes</span>
                <span className="font-semibold text-white font-mono">${totals.carbonCost} Million</span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800/60">
                <span className="text-slate-400">Total Decommissioning Costs</span>
                <span className="font-semibold text-white font-mono">${totals.decommissioning} Million</span>
              </div>
              <div className="flex justify-between items-center text-sm pt-1 pb-1 text-emerald-400 font-bold">
                <span>Grand Total Expenditure</span>
                <span className="font-mono">${totals.total}M</span>
              </div>
            </div>
          </div>

          {/* Cost Warnings Banner */}
          <div className="p-3 bg-rose-950/15 border border-rose-900/40 rounded-lg mt-4 flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="text-[10px] text-slate-400">
              <strong className="text-rose-400">Emissions Intensity Alert:</strong> {asset.name} has a Carbon Intensity of <strong className="text-slate-300">{asset.carbonIntensity} kg/boe</strong>. Under High Carbon taxation ($100/t), emissions will penalize NPV by <strong className="text-slate-300">${(totals.carbonCost * (100 / Math.max(1, scenario.carbonTax))).toFixed(1)}M</strong>.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
