import React, { useState, useMemo } from 'react';
import { ReservoirAsset, PriceScenario, ValuationMetrics } from '../types';
import { evaluateAsset, calculateCashFlows } from '../utils/economics';
import { FileText, Printer, Download, Sparkles, Send, CheckCircle, Info } from 'lucide-react';

interface ReportingTabProps {
  asset: ReservoirAsset;
  assets: ReservoirAsset[];
  scenario: PriceScenario;
  discountRate: number;
  horizonYears: number;
}

export default function ReportingTab({
  asset,
  assets,
  scenario,
  discountRate,
  horizonYears,
}: ReportingTabProps) {
  const [analystName, setAnalystName] = useState('Senior Investment Analyst');
  const [reportTitle, setReportTitle] = useState(`Asset Investment Proposal: ${asset.name}`);
  const [customMemoNotes, setCustomMemoNotes] = useState(
    `Based on rigorous discounted cash flow modeling under a baseline scenario (Oil at $75.0/bbl, Gas at $4.0/Mscf), the reservoir asset "${asset.name}" presents a compelling long-term infrastructure investment opportunity for Ellan Vannin Wealth Management.\n\nThe project demonstrates sound capital efficiency with a Profitability Index that easily clears hurdle standards. We recommend adding this asset to our infrastructure portfolio, subject to hedging extreme downside commodity risks.`
  );

  const metrics = useMemo(() => {
    return evaluateAsset(asset, scenario, discountRate, horizonYears);
  }, [asset, scenario, discountRate, horizonYears]);

  const cashFlows = useMemo(() => {
    return calculateCashFlows(asset, scenario, discountRate, horizonYears);
  }, [asset, scenario, discountRate, horizonYears]);

  // Portfolio general metrics for summary
  const portfolioSummary = useMemo(() => {
    let totalNPV = 0;
    let positiveNPVCount = 0;
    assets.forEach(a => {
      const m = evaluateAsset(a, scenario, discountRate, horizonYears);
      totalNPV += m.npv;
      if (m.npv > 0) positiveNPVCount++;
    });
    return {
      totalNPV,
      positiveNPVCount,
    };
  }, [assets, scenario, discountRate, horizonYears]);

  // Printable Report Trigger
  const handlePrintReport = () => {
    window.print();
  };

  // AI Memo generator (Instant pre-computed high-fidelity template solver)
  const handleGenerateAIMemo = () => {
    const recommendation = metrics.npv > 0 ? 'STRONG BUY / OVERWEIGHT' : 'UNDERWEIGHT / DISINVEST';
    const safetyMargin = isNaN(metrics.irr) ? 'N/A' : `${((metrics.irr - discountRate) * 100).toFixed(1)}%`;
    
    let advice = '';
    if (metrics.npv > 0) {
      advice = `With an estimated NPV of $${metrics.npv.toFixed(1)}M and a IRR of ${isNaN(metrics.irr) ? 'N/A' : `${(metrics.irr * 100).toFixed(1)}%`}, this asset exceeds our required hurdle rate of ${(discountRate * 100).toFixed(0)}%. Capital expenditure of $${asset.capex.toFixed(1)}M is recovered within ${isNaN(metrics.paybackPeriod) ? 'N/A' : `${metrics.paybackPeriod.toFixed(1)} years`}. The project displays a Profitability Index of ${metrics.profitabilityIndex.toFixed(2)}, making it a highly efficient use of wealth allocation.`;
    } else {
      advice = `Due to a negative NPV ($${metrics.npv.toFixed(1)}M), the reservoir fails to meet our hurdle standards. Operating costs are too high relative to production. We advise withholding capital unless commodity prices rise above $90/bbl.`;
    }

    const computedText = `ELLAN VANNIN WEALTH MANAGEMENT -- INVESTMENT RECOMMENDATION: ${recommendation}\n\n${advice}\n\nGeologically, the field uses a ${asset.declineType} decline schedule with an initial production rate of ${asset.currentProduction} MMboe/y and remaining reserves of ${asset.remainingReserves} MMboe. OPEX is configured with a fixed base of $${asset.opexFixed}M/year, while carbon emissions tax under the ${scenario.name} pricing scenario adds $${(metrics.totalOpex * 0.1).toFixed(1)}M in environmental risk overhead. We recommend this project as a ${recommendation} allocation for the sovereign energy infrastructure trust.`;
    
    setCustomMemoNotes(computedText);
  };

  return (
    <div id="reporting-tab" className="space-y-6">
      {/* Editor & Configuration Block */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <FileText className="w-5 h-5 text-peach" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Report Metadata</h3>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1 font-semibold uppercase">Document Title</label>
              <input
                type="text"
                value={reportTitle}
                onChange={(e) => setReportTitle(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 text-xs text-slate-200 border border-slate-800 focus:border-peach rounded-lg outline-none"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1 font-semibold uppercase">Analyst Sign-Off</label>
              <input
                type="text"
                value={analystName}
                onChange={(e) => setAnalystName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 text-xs text-slate-200 border border-slate-800 focus:border-peach rounded-lg outline-none"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800/80 space-y-2">
            <button
              onClick={handleGenerateAIMemo}
              className="w-full py-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition shadow shadow-indigo-600/10"
            >
              <Sparkles className="w-4 h-4" />
              <span>Generate Advisor Memo (AI)</span>
            </button>

            <button
              onClick={handlePrintReport}
              className="w-full py-2 bg-peach hover:bg-peach/90 text-slate-950 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition shadow shadow-peach/10"
            >
              <Printer className="w-4 h-4" />
              <span>Print Executive Memo (PDF)</span>
            </button>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-[10px] text-slate-500 flex items-start gap-1.5">
            <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <span>
              <strong>Tip:</strong> Clicking "Print Executive Memo" opens the system print dialogue. Choose "Save as PDF" to generate an executive-ready PDF report instantly!
            </span>
          </div>
        </div>

        {/* Interactive Editor Notes */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Edit Committee Recommendations</h4>
            <p className="text-slate-400 text-xs mb-3">
              The text below will render directly inside the sign-off box of the formal investment brief. You can type or customize this freely.
            </p>
            <textarea
              value={customMemoNotes}
              onChange={(e) => setCustomMemoNotes(e.target.value)}
              rows={10}
              className="w-full p-3 bg-slate-950 text-slate-200 text-xs border border-slate-800 rounded-lg outline-none focus:border-peach font-sans leading-relaxed"
            />
          </div>
          <span className="text-[10px] text-slate-500 mt-2 block">
            This document remains strictly confidential and intended for the internal Investment Committee of Ellan Vannin Wealth Management.
          </span>
        </div>
      </div>

      {/* Corporate Letterhead Memo Preview Panel (Highly detailed, printable layout!) */}
      <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden text-slate-200 print:bg-white print:text-black print:p-0 print:border-0 print:shadow-none" id="printable-area">
        {/* Print Styles Injection */}
        <style dangerouslySetInnerHTML={{ __html: `
          @media print {
            body * {
              visibility: hidden;
            }
            #printable-area, #printable-area * {
              visibility: visible;
            }
            #printable-area {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
              background: white !important;
              color: black !important;
              padding: 0 !important;
            }
          }
        `}} />

        {/* Ellan Vannin Letterhead */}
        <div className="flex justify-between items-start border-b-2 border-slate-800 pb-5 mb-6 print:border-slate-400">
          <div>
            <span className="text-xs tracking-widest uppercase font-black text-peach block print:text-blue-800">ELLAN VANNIN</span>
            <span className="text-lg font-bold text-white uppercase tracking-wider block print:text-black">WEALTH MANAGEMENT</span>
            <span className="text-[10px] text-slate-500 block print:text-slate-500">Infrastructure & Energy Trust Fund Group</span>
          </div>
          <div className="text-right">
            <span className="text-[11px] font-bold text-slate-400 block uppercase print:text-slate-600">Investment Briefing Memo</span>
            <span className="text-xs text-slate-500 block">{new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</span>
          </div>
        </div>

        {/* Title Block */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-white print:text-black">{reportTitle}</h2>
          <div className="grid grid-cols-2 gap-4 mt-3 text-xs text-slate-400 border-y border-slate-800/60 py-2.5 print:border-slate-200 print:text-slate-600">
            <div>
              <p><strong>To:</strong> Investment Committee Members</p>
              <p className="mt-1"><strong>From:</strong> {analystName}</p>
            </div>
            <div>
              <p><strong>Scenario:</strong> {scenario.name} Scenario</p>
              <p className="mt-1"><strong>Hurdle Rate:</strong> {(discountRate * 100).toFixed(1)}%</p>
            </div>
          </div>
        </div>

        {/* Section 1: Executive Summary */}
        <div className="space-y-4 text-xs leading-relaxed">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 border-b border-slate-800 pb-1 mb-2 print:text-blue-800 print:border-slate-200">1. Executive Committee Recommendation</h3>
            <div className="whitespace-pre-wrap text-slate-300 font-sans print:text-slate-800">
              {customMemoNotes}
            </div>
          </div>

          {/* Section 2: Financial Valuation Summary */}
          <div className="pt-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 border-b border-slate-800 pb-1 mb-2 print:text-blue-800 print:border-slate-200">2. Financial Valuation & CapEx Metrics</h3>
            <div className="grid grid-cols-4 gap-4 py-2 text-center bg-slate-900/40 p-3 rounded-xl border border-slate-800/60 print:bg-slate-100 print:border-slate-300 print:text-black">
              <div>
                <span className="text-[10px] text-slate-500 block uppercase font-semibold">Net Present Value</span>
                <strong className={`text-base font-bold block ${metrics.npv >= 0 ? 'text-emerald-400 print:text-emerald-700' : 'text-rose-400'}`}>${metrics.npv.toFixed(1)}M</strong>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase font-semibold">Internal Rate of Return</span>
                <strong className="text-base font-bold block text-blue-400 print:text-blue-800">{isNaN(metrics.irr) ? 'N/A' : `${(metrics.irr * 100).toFixed(1)}%`}</strong>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase font-semibold">Payback Period</span>
                <strong className="text-base font-bold block text-amber-400 print:text-amber-700">{isNaN(metrics.paybackPeriod) ? 'N/A' : `${metrics.paybackPeriod.toFixed(1)} Yrs`}</strong>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase font-semibold">Profitability Index</span>
                <strong className="text-base font-bold block text-violet-400 print:text-violet-800">{metrics.profitabilityIndex.toFixed(2)}</strong>
              </div>
            </div>
          </div>

          {/* Section 3: Physical & Operating Data */}
          <div className="pt-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 border-b border-slate-800 pb-1 mb-2 print:text-blue-800 print:border-slate-200">3. Physical & Decline Parameters</h3>
            <div className="overflow-x-auto border border-slate-800/60 rounded-lg print:border-slate-300">
              <table className="w-full text-left border-collapse text-[11px] print:text-black">
                <thead>
                  <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 font-semibold print:bg-slate-100 print:border-slate-300">
                    <th className="py-1.5 px-3">Parameter</th>
                    <th className="py-1.5 px-3">Configuration</th>
                    <th className="py-1.5 px-3">Parameter</th>
                    <th className="py-1.5 px-3">Configuration</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300 print:divide-slate-200 print:text-black">
                  <tr>
                    <td className="py-1 px-3 font-semibold text-slate-400">Operator</td>
                    <td className="py-1 px-3">{asset.operator}</td>
                    <td className="py-1 px-3 font-semibold text-slate-400">Fixed OPEX</td>
                    <td className="py-1 px-3">${asset.opexFixed}M/year</td>
                  </tr>
                  <tr>
                    <td className="py-1 px-3 font-semibold text-slate-400">Jurisdiction</td>
                    <td className="py-1 px-3">{asset.country}</td>
                    <td className="py-1 px-3 font-semibold text-slate-400">Variable OPEX</td>
                    <td className="py-1 px-3">${asset.opexVariable}/boe</td>
                  </tr>
                  <tr>
                    <td className="py-1 px-3 font-semibold text-slate-400">Status</td>
                    <td className="py-1 px-3">{asset.fieldStatus}</td>
                    <td className="py-1 px-3 font-semibold text-slate-400">Carbon Intensity</td>
                    <td className="py-1 px-3">{asset.carbonIntensity} kg/boe</td>
                  </tr>
                  <tr>
                    <td className="py-1 px-3 font-semibold text-slate-400">Water Depth</td>
                    <td className="py-1 px-3">{asset.waterDepth > 0 ? `${asset.waterDepth}m Offshore` : 'Onshore'}</td>
                    <td className="py-1 px-3 font-semibold text-slate-400">Decom Provision</td>
                    <td className="py-1 px-3">${asset.decommissioningProvision} Million</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 4: Initial 5-Year Cash Flow Schedule */}
          <div className="pt-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-400 border-b border-slate-800 pb-1 mb-2 print:text-blue-800 print:border-slate-200">4. Initial 5-Year Financial Schedule Summary</h3>
            <div className="overflow-x-auto border border-slate-800/60 rounded-lg print:border-slate-300">
              <table className="w-full text-left border-collapse text-[10px] print:text-black font-mono">
                <thead>
                  <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 font-semibold print:bg-slate-100 print:border-slate-300">
                    <th className="py-1.5 px-3">Year</th>
                    <th className="py-1.5 px-3 text-right">Production (MMboe)</th>
                    <th className="py-1.5 px-3 text-right">Revenue</th>
                    <th className="py-1.5 px-3 text-right">CAPEX</th>
                    <th className="py-1.5 px-3 text-right">OPEX Total</th>
                    <th className="py-1.5 px-3 text-right text-emerald-400 print:text-emerald-800">Free Cash Flow</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300 print:divide-slate-200 print:text-black">
                  {cashFlows.slice(0, 5).map(cf => (
                    <tr key={cf.year}>
                      <td className="py-1 px-3 text-slate-400">Year {cf.year}</td>
                      <td className="py-1 px-3 text-right">{cf.production.toFixed(2)}</td>
                      <td className="py-1 px-3 text-right">${cf.revenue.toFixed(1)}M</td>
                      <td className="py-1 px-3 text-right">${cf.capex.toFixed(1)}M</td>
                      <td className="py-1 px-3 text-right">${cf.opexTotal.toFixed(1)}M</td>
                      <td className="py-1 px-3 text-right font-semibold text-emerald-400 print:text-emerald-800">${cf.freeCashFlow.toFixed(1)}M</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Signature lines */}
        <div className="mt-12 pt-8 border-t border-slate-800/60 grid grid-cols-2 gap-8 text-xs text-slate-400 print:border-slate-300 print:text-black">
          <div className="space-y-4">
            <div className="h-0.5 bg-slate-800 w-48 print:bg-slate-300" />
            <p><strong>Approved by:</strong> Sovereign Energy Trust President</p>
            <p>Date: ________________________</p>
          </div>
          <div className="space-y-4 text-right">
            <div className="h-0.5 bg-slate-800 w-48 ml-auto print:bg-slate-300" />
            <p><strong>Signed by:</strong> Lead Energy Portfolio Analyst</p>
            <p>Date: ________________________</p>
          </div>
        </div>
      </div>
    </div>
  );
}
