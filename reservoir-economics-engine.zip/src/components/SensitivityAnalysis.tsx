import React, { useState, useMemo } from 'react';
import { ReservoirAsset, PriceScenario } from '../types';
import { calculateCashFlows, calculateNPV, calculateIRR } from '../utils/economics';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Sliders, HelpCircle, Activity, BarChart2 } from 'lucide-react';

interface SensitivityAnalysisProps {
  asset: ReservoirAsset;
  scenario: PriceScenario;
  discountRate: number;
  horizonYears: number;
}

export default function SensitivityAnalysis({
  asset,
  scenario,
  discountRate,
  horizonYears,
}: SensitivityAnalysisProps) {
  const [metricToAnalyze, setMetricToAnalyze] = useState<'NPV' | 'IRR'>('NPV');

  // Compute sensitivity points dynamically for -30%, -20%, -10%, 0%, 10%, 20%, 30%
  const percentageSteps = [-30, -20, -10, 0, 10, 20, 30];

  const sensitivityData = useMemo(() => {
    return percentageSteps.map(step => {
      const multiplier = 1 + (step / 100);

      // 1. Commodity Price Sensitivity
      const priceSc = {
        ...scenario,
        oilPrice: scenario.oilPrice * multiplier,
        gasPrice: scenario.gasPrice * multiplier,
      };
      const priceCF = calculateCashFlows(asset, priceSc, discountRate, horizonYears);
      const priceVal = metricToAnalyze === 'NPV' ? calculateNPV(priceCF) : calculateIRR(priceCF) * 100;

      // 2. OPEX Sensitivity
      const opexAsset = {
        ...asset,
        opexFixed: asset.opexFixed * multiplier,
        opexVariable: asset.opexVariable * multiplier,
      };
      const opexCF = calculateCashFlows(opexAsset, scenario, discountRate, horizonYears);
      const opexVal = metricToAnalyze === 'NPV' ? calculateNPV(opexCF) : calculateIRR(opexCF) * 100;

      // 3. CAPEX Sensitivity
      const capexAsset = {
        ...asset,
        capex: asset.capex * multiplier,
      };
      const capexCF = calculateCashFlows(capexAsset, scenario, discountRate, horizonYears);
      const capexVal = metricToAnalyze === 'NPV' ? calculateNPV(capexCF) : calculateIRR(capexCF) * 100;

      // 4. Decline Rate Sensitivity (increasing decline rate reduces production)
      const declineAsset = {
        ...asset,
        declineRate: Math.max(0.01, Math.min(0.5, asset.declineRate * multiplier)),
      };
      const declineCF = calculateCashFlows(declineAsset, scenario, discountRate, horizonYears);
      const declineVal = metricToAnalyze === 'NPV' ? calculateNPV(declineCF) : calculateIRR(declineCF) * 100;

      // 5. Discount Rate Sensitivity (only makes sense for NPV)
      let discountVal = 0;
      if (metricToAnalyze === 'NPV') {
        const discRate = Math.max(0, discountRate * multiplier);
        const discCF = calculateCashFlows(asset, scenario, discRate, horizonYears);
        discountVal = calculateNPV(discCF);
      }

      return {
        stepLabel: `${step >= 0 ? '+' : ''}${step}%`,
        stepValue: step,
        'Commodity Price': Number(priceVal.toFixed(2)),
        'Operating Costs (OPEX)': Number(opexVal.toFixed(2)),
        'Capital Expenditure (CAPEX)': Number(capexVal.toFixed(2)),
        'Decline Rate': Number(declineVal.toFixed(2)),
        ...(metricToAnalyze === 'NPV' ? { 'Discount Rate': Number(discountVal.toFixed(2)) } : {}),
      };
    });
  }, [asset, scenario, discountRate, horizonYears, metricToAnalyze]);

  // Find base value (0% change)
  const baseValue = useMemo(() => {
    const basePoint = sensitivityData.find(d => d.stepValue === 0);
    return basePoint ? basePoint['Commodity Price'] : 0;
  }, [sensitivityData]);

  // Tornado Chart data representation for -30% to +30% extremes
  const tornadoData = useMemo(() => {
    const params = [
      { name: 'Commodity Price', key: 'Commodity Price' as const },
      { name: 'Operating Costs (OPEX)', key: 'Operating Costs (OPEX)' as const },
      { name: 'Capital Expenditure (CAPEX)', key: 'Capital Expenditure (CAPEX)' as const },
      { name: 'Decline Rate', key: 'Decline Rate' as const },
      ...(metricToAnalyze === 'NPV' ? [{ name: 'Discount Rate', key: 'Discount Rate' as const }] : []),
    ];

    return params.map(p => {
      const p30 = sensitivityData.find(d => d.stepValue === 30)?.[p.key] || 0;
      const m30 = sensitivityData.find(d => d.stepValue === -30)?.[p.key] || 0;

      const minVal = Math.min(p30, m30);
      const maxVal = Math.max(p30, m30);
      const width = maxVal - minVal;

      return {
        name: p.name,
        min: Number(minVal.toFixed(1)),
        max: Number(maxVal.toFixed(1)),
        width: Number(width.toFixed(1)),
        lowLabel: `-30% Var: $${m30.toFixed(1)}M`,
        highLabel: `+30% Var: $${p30.toFixed(1)}M`,
      };
    }).sort((a, b) => b.width - a.width); // sort by influence (width)
  }, [sensitivityData, metricToAnalyze]);

  return (
    <div id="sensitivity-analysis" className="space-y-6">
      {/* Configuration Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg">
        <div>
          <h3 className="text-base font-bold text-white uppercase tracking-wider">Sensitivity Simulation</h3>
          <p className="text-slate-400 text-xs mt-1">
            Simulate how project performance alters under -30% to +30% adjustments to key risk parameters.
          </p>
        </div>

        {/* Metric Selector Toggle */}
        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 self-start md:self-auto">
          <button
            onClick={() => setMetricToAnalyze('NPV')}
            className={`px-4 py-1.5 rounded-md text-xs font-bold transition ${
              metricToAnalyze === 'NPV'
                ? 'bg-peach text-slate-950 shadow font-extrabold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Net Present Value (NPV)
          </button>
          <button
            onClick={() => setMetricToAnalyze('IRR')}
            className={`px-4 py-1.5 rounded-md text-xs font-bold transition ${
              metricToAnalyze === 'IRR'
                ? 'bg-peach text-slate-950 shadow font-extrabold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Internal Rate of Return (IRR)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Line Chart: Spider Sensitivity Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-5 h-5 text-peach" />
            <h3 className="text-lg font-bold text-white">Spider Plot: {metricToAnalyze} Sensitivity</h3>
          </div>

          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sensitivityData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="stepLabel" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} unit={metricToAnalyze === 'NPV' ? 'M' : '%'} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                  labelStyle={{ fontWeight: 'bold' }}
                />
                <Legend verticalAlign="top" height={36} iconType="circle" />
                <ReferenceLine y={baseValue} stroke="#475569" strokeDasharray="3 3" />
                
                <Line type="monotone" dataKey="Commodity Price" stroke="#FDBA74" strokeWidth={2.5} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="Operating Costs (OPEX)" stroke="#ec4899" strokeWidth={2} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="Capital Expenditure (CAPEX)" stroke="#f59e0b" strokeWidth={2} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="Decline Rate" stroke="#ef4444" strokeWidth={2} dot={{ r: 4 }} />
                {metricToAnalyze === 'NPV' && (
                  <Line type="monotone" dataKey="Discount Rate" stroke="#8b5cf6" strokeWidth={2} dot={{ r: 4 }} />
                )}
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-slate-500 italic text-center mt-2">
            Base Case value (0% change) is <strong className="text-white">{metricToAnalyze === 'NPV' ? `$${baseValue.toFixed(1)}M` : `${baseValue.toFixed(1)}%`}</strong>. Steeper curves indicate higher vulnerability to that specific variable.
          </p>
        </div>

        {/* Tornado Analysis chart representation */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <BarChart2 className="w-5 h-5 text-amber-400" />
              <h3 className="text-base font-bold text-white">Impact Leverage Analysis</h3>
            </div>
            <p className="text-slate-400 text-xs mb-4">
              The variables below are ranked by their leverage on {metricToAnalyze} at extreme bounds (±30% variance).
            </p>

            <div className="space-y-4">
              {tornadoData.map((item, idx) => {
                // Find relative width to scale
                const maxWidth = Math.max(...tornadoData.map(d => d.width));
                const percentWidth = maxWidth > 0 ? (item.width / maxWidth) * 100 : 0;

                return (
                  <div key={item.name} className="space-y-1">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-slate-300 truncate">{item.name}</span>
                      <span className="font-mono text-[11px] text-slate-400">Δ {metricToAnalyze === 'NPV' ? `$${item.width.toFixed(1)}M` : `${item.width.toFixed(1)}%`}</span>
                    </div>
                    {/* Bar visualization */}
                    <div className="w-full bg-slate-950 h-3.5 rounded overflow-hidden flex relative items-center">
                      <div 
                        className="bg-peach/80 h-full rounded transition-all duration-300"
                        style={{ width: `${percentWidth}%`, marginLeft: `${(100 - percentWidth) / 2}%` }}
                      />
                      {/* Label overlay */}
                      <span className="absolute left-2 text-[8px] font-bold text-slate-400 select-none">{item.lowLabel}</span>
                      <span className="absolute right-2 text-[8px] font-bold text-slate-400 select-none">{item.highLabel}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg mt-4 text-[10px] text-slate-400">
            <HelpCircle className="w-4 h-4 text-slate-400 shrink-0 float-left mr-2" />
            <span>
              <strong>Interpretation:</strong> Commodity prices generally dominate reservoir value. However, high-decline fields suffer severe downside from production decline rate volatility.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
