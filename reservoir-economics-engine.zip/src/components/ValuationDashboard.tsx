import React, { useMemo } from 'react';
import { ReservoirAsset, PriceScenario } from '../types';
import { calculateCashFlows, evaluateAsset } from '../utils/economics';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Landmark, TrendingUp, DollarSign, Hourglass, ShieldAlert, FileText, Download } from 'lucide-react';

interface ValuationDashboardProps {
  asset: ReservoirAsset;
  scenario: PriceScenario;
  discountRate: number;
  onUpdateDiscountRate: (rate: number) => void;
  horizonYears: number;
}

export default function ValuationDashboard({
  asset,
  scenario,
  discountRate,
  onUpdateDiscountRate,
  horizonYears,
}: ValuationDashboardProps) {
  const cashFlows = useMemo(() => {
    return calculateCashFlows(asset, scenario, discountRate, horizonYears);
  }, [asset, scenario, discountRate, horizonYears]);

  const metrics = useMemo(() => {
    return evaluateAsset(asset, scenario, discountRate, horizonYears);
  }, [asset, scenario, discountRate, horizonYears]);

  // Export cash flows to CSV
  const handleExportCashFlowCSV = () => {
    const headers = [
      'Year', 'Production (MMboe)', 'Cumulative Production (MMboe)',
      'Revenue (Million $)', 'Fixed OPEX (Million $)', 'Variable OPEX (Million $)',
      'CAPEX (Million $)', 'Carbon Cost (Million $)', 'Decommissioning (Million $)',
      'Total Cost (Million $)', 'Free Cash Flow (Million $)', 'Discounted Cash Flow (Million $)'
    ];

    const rows = cashFlows.map(cf => [
      cf.year,
      cf.production.toFixed(4),
      cf.cumulativeProduction.toFixed(4),
      cf.revenue.toFixed(4),
      cf.opexFixed.toFixed(4),
      cf.opexVariable.toFixed(4),
      cf.capex.toFixed(4),
      cf.carbonCost.toFixed(4),
      cf.decommissioning.toFixed(4),
      cf.totalCost.toFixed(4),
      cf.freeCashFlow.toFixed(4),
      cf.discountedCashFlow.toFixed(4)
    ]);

    const csvContent = [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `ree_cash_flow_${asset.name.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const chartData = useMemo(() => {
    return cashFlows.map(cf => ({
      yearLabel: `Year ${cf.year}`,
      'Free Cash Flow': Number(cf.freeCashFlow.toFixed(2)),
      'Discounted Cash Flow': Number(cf.discountedCashFlow.toFixed(2)),
    }));
  }, [cashFlows]);

  return (
    <div id="valuation-and-cashflows" className="space-y-6">
      {/* Top Slider and Summary banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg">
        <div className="flex-1">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1.5">Discount Rate Configuration</h3>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="0"
              max="25"
              step="0.5"
              value={discountRate * 100}
              onChange={(e) => onUpdateDiscountRate(Number(e.target.value) / 100)}
              className="w-full max-w-md h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-peach"
            />
            <span className="text-lg font-bold text-peach font-mono">{(discountRate * 100).toFixed(1)}%</span>
          </div>
        </div>
        <div>
          <button
            onClick={handleExportCashFlowCSV}
            className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold border border-slate-700 shadow-sm transition"
          >
            <Download className="w-4 h-4 text-slate-400" />
            <span>Export Cash Flow Table (CSV)</span>
          </button>
        </div>
      </div>

      {/* Main KPI metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* NPV */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 p-3 text-emerald-500/5">
            <Landmark className="w-16 h-16" />
          </div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Net Present Value (NPV)</span>
          <span className={`text-3xl font-extrabold mt-2 block ${metrics.npv >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            ${metrics.npv.toFixed(2)}M
          </span>
          <p className="text-xs text-slate-500 mt-2">Discounted at {(discountRate * 100).toFixed(1)}% annually</p>
        </div>

        {/* IRR */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 p-3 text-peach/5">
            <TrendingUp className="w-16 h-16" />
          </div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Internal Rate of Return (IRR)</span>
          <span className="text-3xl font-extrabold text-peach mt-2 block">
            {isNaN(metrics.irr) ? 'N/A' : `${(metrics.irr * 100).toFixed(2)}%`}
          </span>
          <p className="text-xs text-slate-500 mt-2">Discount rate where NPV equals zero</p>
        </div>

        {/* Payback Period */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 p-3 text-amber-500/5">
            <Hourglass className="w-16 h-16" />
          </div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Payback Period</span>
          <span className="text-3xl font-extrabold text-amber-400 mt-2 block font-mono">
            {isNaN(metrics.paybackPeriod) ? 'Never' : `${metrics.paybackPeriod.toFixed(2)} y`}
          </span>
          <p className="text-xs text-slate-500 mt-2">Time required to recover initial capex</p>
        </div>

        {/* Profitability Index */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 p-3 text-violet-500/5">
            <DollarSign className="w-16 h-16" />
          </div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Profitability Index</span>
          <span className="text-3xl font-extrabold text-violet-400 mt-2 block font-mono">
            {metrics.profitabilityIndex.toFixed(2)}
          </span>
          <p className="text-xs text-slate-500 mt-2">Capital efficiency ratio (NPV + PV Capex)/PV Capex</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* FCF vs DCF Cash Flow Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <h3 className="text-lg font-bold text-white">Free Cash Flow vs. Discounted Cash Flow</h3>
          </div>

          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="yearLabel" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} unit="M" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                  labelStyle={{ fontWeight: 'bold' }}
                />
                <Legend verticalAlign="top" height={36} />
                <Bar dataKey="Free Cash Flow" fill="#10b981" fillOpacity={0.85} radius={[4, 4, 0, 0]} />
                <Bar dataKey="Discounted Cash Flow" fill="#FDBA74" fillOpacity={0.85} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-slate-500 italic text-center mt-2">
            The difference between Free Cash Flow and Discounted Cash Flow represents the time-value penalty of later years at {discountRate * 100}% discount rate.
          </p>
        </div>

        {/* Valuation Notes / Quick Memo */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Investment Decision Notes</h4>
            <div className="space-y-3 text-xs text-slate-300">
              <p>
                <strong>NPV Verdict:</strong> {metrics.npv >= 0 ? (
                  <span className="text-emerald-400 font-semibold">PASS. This asset clears the {(discountRate * 100).toFixed(1)}% hurdle rate, generating surplus economic value.</span>
                ) : (
                  <span className="text-rose-400 font-semibold">FAIL. This asset fails to clear the {(discountRate * 100).toFixed(1)}% hurdle rate, yielding negative economic value.</span>
                )}
              </p>
              <p>
                <strong>IRR Cushion:</strong> The IRR of <strong className="text-peach">{isNaN(metrics.irr) ? 'N/A' : `${(metrics.irr * 100).toFixed(1)}%`}</strong> represents a cushion of <strong className="text-slate-200">{isNaN(metrics.irr) ? 'N/A' : `${((metrics.irr - discountRate) * 100).toFixed(1)}%`}</strong> over the requested hurdle.
              </p>
              <p>
                <strong>Capital Efficiency:</strong> A Profitability Index of <strong className="text-violet-400">{metrics.profitabilityIndex.toFixed(2)}</strong> indicates that for every $1.00 of CAPEX invested, the project creates <strong className="text-slate-200">${Math.max(0, metrics.profitabilityIndex - 1).toFixed(2)}</strong> of incremental discounted net benefit.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-850/30 border border-slate-700/50 rounded-lg mt-4 flex gap-2 text-[10px] text-slate-400">
            <FileText className="w-4 h-4 text-peach shrink-0 mt-0.5" />
            <div>
              <strong className="text-peach">Wealth Management Advisory:</strong> For long-term infrastructure investment portfolios, Ellan Vannin recommends a hurdle rate of <strong className="text-slate-300">8.0% to 12.0%</strong>. This asset provides a {metrics.npv >= 0 ? 'viable' : 'highly questionable'} return-on-capital.
            </div>
          </div>
        </div>
      </div>

      {/* Cash Flow Engine Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-base font-semibold text-white uppercase tracking-wider">Annual Cash Flow Schedule (Financial Model)</h3>
          <span className="text-xs text-slate-500">All figures in $ Millions, except unit prices</span>
        </div>

        <div className="overflow-x-auto border border-slate-800 rounded-lg">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/70 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider select-none">
                <th className="py-3 px-3">Yr</th>
                <th className="py-3 px-3 text-right">Prod (MMboe)</th>
                <th className="py-3 px-3 text-right">Oil ($)</th>
                <th className="py-3 px-3 text-right">Revenue</th>
                <th className="py-3 px-3 text-right">Fixed OPEX</th>
                <th className="py-3 px-3 text-right">Var OPEX</th>
                <th className="py-3 px-3 text-right">CAPEX</th>
                <th className="py-3 px-3 text-right">Carbon Cost</th>
                <th className="py-3 px-3 text-right">Decom</th>
                <th className="py-3 px-3 text-right font-bold text-slate-300">Free CF</th>
                <th className="py-3 px-3 text-right font-bold text-peach">Discounted CF</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300 font-mono">
              {cashFlows.map((cf) => (
                <tr key={cf.year} className="hover:bg-slate-800/20 transition-colors">
                  <td className="py-2.5 px-3 text-slate-400">Yr {cf.year}</td>
                  <td className="py-2.5 px-3 text-right text-slate-300">{cf.production.toFixed(2)}</td>
                  <td className="py-2.5 px-3 text-right text-slate-500">${cf.oilPrice.toFixed(0)}</td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-medium">${cf.revenue.toFixed(1)}</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">${cf.opexFixed.toFixed(1)}</td>
                  <td className="py-2.5 px-3 text-right text-slate-400">${cf.opexVariable.toFixed(1)}</td>
                  <td className="py-2.5 px-3 text-right text-slate-300">${cf.capex.toFixed(1)}</td>
                  <td className="py-2.5 px-3 text-right text-rose-400">${cf.carbonCost.toFixed(1)}</td>
                  <td className="py-2.5 px-3 text-right text-amber-500">${cf.decommissioning.toFixed(1)}</td>
                  <td className={`py-2.5 px-3 text-right font-semibold ${cf.freeCashFlow >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    ${cf.freeCashFlow.toFixed(1)}
                  </td>
                  <td className={`py-2.5 px-3 text-right font-bold ${cf.discountedCashFlow >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                    ${cf.discountedCashFlow.toFixed(1)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
