import React, { useState, useMemo } from 'react';
import { ReservoirAsset, PriceScenario } from '../types';
import { evaluateAsset } from '../utils/economics';
import { Globe, Search, Navigation, Info, Shield, Layers } from 'lucide-react';

interface GeographicAnalysisProps {
  assets: ReservoirAsset[];
  scenario: PriceScenario;
  discountRate: number;
  horizonYears: number;
  onSelectAsset: (asset: ReservoirAsset) => void;
}

export default function GeographicAnalysis({
  assets,
  scenario,
  discountRate,
  horizonYears,
  onSelectAsset,
}: GeographicAnalysisProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(assets[0]?.id || null);

  const evaluatedAssets = useMemo(() => {
    return assets.map(asset => {
      const metrics = evaluateAsset(asset, scenario, discountRate, horizonYears);
      return {
        ...asset,
        metrics,
      };
    });
  }, [assets, scenario, discountRate, horizonYears]);

  const activeAsset = useMemo(() => {
    return evaluatedAssets.find(a => a.id === selectedAssetId) || evaluatedAssets[0] || null;
  }, [evaluatedAssets, selectedAssetId]);

  // Convert Latitude and Longitude to SVG (X, Y) coordinates
  // Lat: -90 to 90 -> Y: 300 to 0 (scaled)
  // Lon: -180 to 180 -> X: 0 to 600 (scaled)
  const mapCoordinates = (lat: number, lon: number) => {
    // Mercator or standard projection scaling for a 650x320 SVG canvas
    const x = ((lon + 180) * 650) / 360;
    const y = ((90 - lat) * 320) / 180;
    return { x, y };
  };

  const filteredAssets = useMemo(() => {
    return evaluatedAssets.filter(a =>
      a.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.country.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [evaluatedAssets, searchTerm]);

  // Simple static global major cities/regions as backing anchors on the map
  const landmarks = [
    { name: 'Houston (GoM Hub)', lat: 29.7, lon: -95.3 },
    { name: 'Aberdeen (North Sea Hub)', lat: 57.1, lon: -2.1 },
    { name: 'Singapore (ASEAN Hub)', lat: 1.3, lon: 103.8 },
    { name: 'Riyadh (Middle East)', lat: 24.7, lon: 46.7 },
    { name: 'Perth (NW Shelf)', lat: -31.9, lon: 115.8 },
  ];

  return (
    <div id="geographic-analysis" className="space-y-6">
      {/* Header Info */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-lg">
        <h3 className="text-base font-bold text-white uppercase tracking-wider">Spatial Reservoir Mapping</h3>
        <p className="text-slate-400 text-xs mt-1">
          Geographic visualizer displaying asset coordinates, operating status, remaining reserves, and estimated NPV valuations.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: GIS Controller & Asset Search */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search reservoirs or country..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-950/70 text-xs text-slate-200 border border-slate-800 focus:border-peach rounded-lg outline-none outline-0"
            />
          </div>

          <div className="flex-1 overflow-y-auto max-h-[350px] space-y-2 pr-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Reservoir Markers</span>
            {filteredAssets.map(asset => {
              const isSelected = selectedAssetId === asset.id;
              return (
                <button
                  key={asset.id}
                  onClick={() => setSelectedAssetId(asset.id)}
                  className={`w-full p-3 rounded-lg text-left border flex items-center justify-between transition ${
                    isSelected
                      ? 'bg-peach/5 border-peach/80 text-peach font-semibold'
                      : 'bg-slate-950/40 border-slate-800/80 hover:bg-slate-800/20'
                  }`}
                >
                  <div className="truncate">
                    <span className="text-xs font-semibold text-white block truncate">{asset.name}</span>
                    <span className="text-[10px] text-slate-400 block truncate">{asset.country} · {asset.operator}</span>
                  </div>

                  <div className="text-right shrink-0">
                    <span className={`inline-block w-2.5 h-2.5 rounded-full ${
                      asset.fieldStatus === 'Production'
                        ? 'bg-emerald-400'
                        : asset.fieldStatus === 'Decline'
                        ? 'bg-amber-400'
                        : 'bg-peach'
                    }`} />
                    <span className="text-[10px] font-semibold text-slate-300 block font-mono">${asset.metrics.npv.toFixed(0)}M</span>
                  </div>
                </button>
              );
            })}
            {filteredAssets.length === 0 && (
              <p className="text-xs text-slate-500 italic text-center py-6">No assets match your search.</p>
            )}
          </div>
        </div>

        {/* Center: Vector GIS SVG Map Canvas */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-peach" />
              <h3 className="text-lg font-bold text-white">Interactive Global Reservoir Map</h3>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">Projection: Equirectangular</span>
          </div>

          {/* Interactive Map Wrapper */}
          <div className="relative border border-slate-800 rounded-lg bg-slate-950/80 p-2 overflow-hidden">
            <svg viewBox="0 0 650 320" className="w-full h-auto select-none">
              {/* Latitude and Longitude Grid Lines */}
              <g stroke="#1e293b" strokeWidth={0.5} strokeDasharray="3 3">
                {/* Latitudes */}
                <line x1={0} y1={53.3} x2={650} y2={53.3} />  {/* 60 N */}
                <line x1={0} y1={106.6} x2={650} y2={106.6} /> {/* 30 N */}
                <line x1={0} y1={160} x2={650} y2={160} stroke="#334155" />    {/* Equator */}
                <line x1={0} y1={213.3} x2={650} y2={213.3} /> {/* 30 S */}
                <line x1={0} y1={266.6} x2={650} y2={266.6} /> {/* 60 S */}

                {/* Longitudes */}
                <line x1={108.3} y1={0} x2={108.3} y2={320} /> {/* 120 W */}
                <line x1={216.6} y1={0} x2={216.6} y2={320} /> {/* 60 W */}
                <line x1={325} y1={0} x2={325} y2={320} stroke="#334155" />    {/* Prime Meridian */}
                <line x1={433.3} y1={0} x2={433.3} y2={320} /> {/* 60 E */}
                <line x1={541.6} y1={0} x2={541.6} y2={320} /> {/* 120 E */}
              </g>

              {/* Highly stylized simplified world continents outline (for visual backing) */}
              <g fill="#1e293b/40" stroke="#334155" strokeWidth={1} fillOpacity={0.3}>
                {/* North America */}
                <path d="M50,40 L160,40 L210,120 L150,150 L110,130 L90,140 L50,100 Z" />
                {/* South America */}
                <path d="M160,150 L220,170 L200,280 L180,290 L160,220 Z" />
                {/* Eurasia & Africa */}
                <path d="M300,50 L580,30 L610,100 L540,150 L460,110 L440,160 L400,140 L380,80 Z" />
                <path d="M300,120 L360,120 L380,180 L350,260 L310,260 L290,170 Z" />
                {/* Australia */}
                <path d="M510,210 L590,210 L570,270 L510,260 Z" />
              </g>

              {/* Draw Landmark Anchors */}
              <g>
                {landmarks.map((l, idx) => {
                  const { x, y } = mapCoordinates(l.lat, l.lon);
                  return (
                    <g key={idx}>
                      <circle cx={x} cy={y} r={1.5} fill="#475569" />
                      <text x={x + 3} y={y + 3} fontSize={7} fill="#64748b" className="pointer-events-none">{l.name}</text>
                    </g>
                  );
                })}
              </g>

              {/* Draw Reservoir Nodes */}
              <g>
                {filteredAssets.map(asset => {
                  const { x, y } = mapCoordinates(asset.latitude, asset.longitude);
                  const isSelected = selectedAssetId === asset.id;
                  
                  // Color status mapping
                  let nodeColor = '#FDBA74'; // Peach for Development / exploration
                  if (asset.fieldStatus === 'Production') nodeColor = '#10b981'; // Green
                  if (asset.fieldStatus === 'Decline') nodeColor = '#f59e0b'; // Amber
                  if (asset.fieldStatus === 'Decommissioned') nodeColor = '#f43f5e'; // Red

                  // Node size based on reserves
                  const size = Math.max(4, Math.min(12, 4 + (asset.remainingReserves / 120)));

                  return (
                    <g 
                      key={asset.id} 
                      onClick={() => setSelectedAssetId(asset.id)}
                      className="cursor-pointer"
                    >
                      {/* Pulse effect if selected */}
                      {isSelected && (
                        <circle cx={x} cy={y} r={size + 8} fill={nodeColor} fillOpacity={0.15} className="animate-ping" />
                      )}
                      
                      <circle 
                        cx={x} 
                        cy={y} 
                        r={size} 
                        fill={nodeColor} 
                        stroke="#0f172a" 
                        strokeWidth={1.5} 
                        fillOpacity={isSelected ? 1.0 : 0.75}
                        className="transition hover:fill-opacity-100"
                      />
                      
                      {/* Small text label */}
                      <text 
                        x={x + size + 3} 
                        y={y + 3} 
                        fontSize={8} 
                        fontWeight={isSelected ? 'bold' : 'normal'} 
                        fill={isSelected ? '#ffffff' : '#94a3b8'}
                      >
                        {asset.name}
                      </text>
                    </g>
                  );
                })}
              </g>
            </svg>
          </div>

          {/* Quick HUD for Selected Reservoir on Map */}
          {activeAsset && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-950 p-4 border border-slate-800 rounded-lg mt-4 animate-fade-in">
              <div className="border-r border-slate-800 pr-3">
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Active Focus</span>
                <span className="text-sm font-bold text-white block truncate">{activeAsset.name}</span>
                <span className="text-xs text-slate-400 block truncate">{activeAsset.operator} · {activeAsset.country}</span>
              </div>

              <div className="border-r border-slate-800 px-3">
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Reserves & Depth</span>
                <span className="text-sm font-bold text-slate-300 block font-mono">{activeAsset.remainingReserves.toFixed(1)} MMboe</span>
                <span className="text-xs text-slate-400 block">{activeAsset.waterDepth > 0 ? `${activeAsset.waterDepth}m Offshore` : 'Onshore'}</span>
              </div>

              <div className="border-r border-slate-800 px-3">
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Economic Value</span>
                <span className="text-sm font-bold text-emerald-400 block font-mono">${activeAsset.metrics.npv.toFixed(1)}M</span>
                <span className="text-xs text-slate-400 block">IRR: {isNaN(activeAsset.metrics.irr) ? 'N/A' : `${(activeAsset.metrics.irr * 100).toFixed(1)}%`}</span>
              </div>

              <div className="pl-3 flex flex-col justify-center">
                <button
                  onClick={() => onSelectAsset(activeAsset)}
                  className="w-full py-1.5 bg-peach hover:bg-peach/90 text-slate-950 rounded text-xs font-bold flex items-center justify-center gap-1 transition"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Deep Evaluation</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
