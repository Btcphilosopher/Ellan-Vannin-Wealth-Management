import React, { useState, useMemo } from 'react';
import { ReservoirAsset, PriceScenario } from './types';
import { SAMPLE_ASSETS, DEFAULT_SCENARIOS } from './data/sampleAssets';
import { evaluateAsset } from './utils/economics';
import PortfolioDashboard from './components/PortfolioDashboard';
import AssetRegister from './components/AssetRegister';
import ProductionForecast from './components/ProductionForecast';
import PriceScenarioComponent from './components/PriceScenario';
import CostModel from './components/CostModel';
import ValuationDashboard from './components/ValuationDashboard';
import SensitivityAnalysis from './components/SensitivityAnalysis';
import GeographicAnalysis from './components/GeographicAnalysis';
import RiskDashboard from './components/RiskDashboard';
import ReportingTab from './components/ReportingTab';
import {
  Briefcase,
  Database,
  TrendingUp,
  Coins,
  Activity,
  Landmark,
  Compass,
  AlertTriangle,
  FileSpreadsheet,
  Settings,
  HelpCircle,
  Bell,
  ChevronRight,
  Shield,
  Gauge
} from 'lucide-react';

export default function App() {
  // Global States
  const [assets, setAssets] = useState<ReservoirAsset[]>(SAMPLE_ASSETS);
  const [scenarios, setScenarios] = useState<PriceScenario[]>(DEFAULT_SCENARIOS);
  const [selectedAssetId, setSelectedAssetId] = useState<string>(SAMPLE_ASSETS[0].id);
  const [selectedScenarioName, setSelectedScenarioName] = useState<string>('Base');
  const [discountRate, setDiscountRate] = useState<number>(0.08); // 8% base hurdle
  const [horizonYears, setHorizonYears] = useState<number>(15); // 15 years standard evaluation

  // Navigation Group and Tab State
  const [activeTab, setActiveTab] = useState<string>('portfolio');

  // Resolved active asset and scenario
  const activeAsset = useMemo(() => {
    return assets.find(a => a.id === selectedAssetId) || assets[0];
  }, [assets, selectedAssetId]);

  const activeScenario = useMemo(() => {
    return scenarios.find(s => s.name === selectedScenarioName) || scenarios[1];
  }, [scenarios, selectedScenarioName]);

  // Dynamic portfolio metrics for header styled like Sophisticated Dark
  const headerMetrics = useMemo(() => {
    let totalReserves = 0;
    let totalNPV = 0;
    let weightedIrrSum = 0;
    
    assets.forEach(asset => {
      const metrics = evaluateAsset(asset, activeScenario, discountRate, horizonYears);
      totalReserves += asset.remainingReserves;
      totalNPV += metrics.npv;
      
      const weight = Math.max(0, metrics.npv);
      weightedIrrSum += (isNaN(metrics.irr) ? 0 : metrics.irr) * weight;
    });

    const sumNPVPositive = assets.reduce((sum, asset) => {
      const metrics = evaluateAsset(asset, activeScenario, discountRate, horizonYears);
      return sum + Math.max(0, metrics.npv);
    }, 0);
    
    const weightedAvgIrr = sumNPVPositive > 0 ? (weightedIrrSum / sumNPVPositive) : 0.08;

    return {
      totalReserves,
      portfolioNPV: totalNPV,
      weightedAvgIrr,
    };
  }, [assets, activeScenario, discountRate, horizonYears]);

  // Asset action handlers
  const handleAddAsset = (newAsset: ReservoirAsset) => {
    setAssets(prev => {
      // Check if ID already exists, overwrite or append
      const idx = prev.findIndex(a => a.id === newAsset.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = newAsset;
        return updated;
      }
      return [...prev, newAsset];
    });
    setSelectedAssetId(newAsset.id);
  };

  const handleUpdateAsset = (updatedAsset: ReservoirAsset) => {
    setAssets(prev => prev.map(a => a.id === updatedAsset.id ? updatedAsset : a));
  };

  const handleDeleteAsset = (idToDelete: string) => {
    setAssets(prev => {
      const filtered = prev.filter(a => a.id !== idToDelete);
      // Fallback selection if active is deleted
      if (selectedAssetId === idToDelete && filtered.length > 0) {
        setSelectedAssetId(filtered[0].id);
      }
      return filtered;
    });
  };

  const handleUpdateScenarios = (nextScenarios: PriceScenario[]) => {
    setScenarios(nextScenarios);
  };

  // Structured Tab Categories
  const navigationGroups = [
    {
      groupName: 'Portfolio Analytics',
      items: [
        { id: 'portfolio', label: 'Dashboard', icon: Briefcase },
        { id: 'map', label: 'Spatial Mapping', icon: Compass },
        { id: 'risk', label: 'Risk Assessment', icon: AlertTriangle },
      ]
    },
    {
      groupName: 'Reservoir Modeler',
      items: [
        { id: 'register', label: 'Asset Register', icon: Database },
        { id: 'forecast', label: 'Decline Curve', icon: TrendingUp },
        { id: 'pricing', label: 'Price Scenario', icon: Coins },
        { id: 'costs', label: 'Expenditures', icon: Activity },
      ]
    },
    {
      groupName: 'Investment Committee',
      items: [
        { id: 'valuation', label: 'Financial Statements', icon: Landmark },
        { id: 'sensitivity', label: 'Leverage Sensitivity', icon: Gauge },
        { id: 'reporting', label: 'Committee Memo', icon: FileSpreadsheet },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none antialiased">
      {/* Top Professional Executive Header with Sophisticated Dark style */}
      <header className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 shrink-0">
        <div className="flex flex-col md:flex-row md:items-center gap-6 w-full lg:w-auto justify-between lg:justify-start">
          <div>
            <h1 className="font-serif text-2xl font-light tracking-wider text-slate-100">
              ELLAN VANNIN <span className="text-slate-400">WEALTH MANAGEMENT</span>
            </h1>
            <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mt-0.5 font-sans font-semibold">
              Reservoir Economics Engine v4.2
            </p>
          </div>

          {/* Quick-Access Global Model Controls Bar */}
          <div className="flex flex-wrap items-center gap-4 bg-slate-950/40 p-2.5 rounded-lg border border-slate-800 w-full md:w-auto">
            {/* Active Asset Selector */}
            <div className="flex flex-col">
              <span className="text-[9px] text-slate-500 uppercase tracking-widest font-semibold">Active Reservoir</span>
              <select
                value={selectedAssetId}
                onChange={(e) => setSelectedAssetId(e.target.value)}
                className="bg-transparent text-xs text-slate-200 font-bold outline-none cursor-pointer pr-4 focus:text-peach mt-0.5"
              >
                {assets.map(a => (
                  <option key={a.id} value={a.id} className="bg-slate-950 text-slate-300">
                    {a.name} ({a.operator})
                  </option>
                ))}
              </select>
            </div>

            <div className="h-6 w-px bg-slate-800 hidden sm:block" />

            {/* Pricing Scenario Selector */}
            <div className="flex flex-col">
              <span className="text-[9px] text-slate-500 uppercase tracking-widest font-semibold">Valuation Pricing</span>
              <select
                value={selectedScenarioName}
                onChange={(e) => setSelectedScenarioName(e.target.value)}
                className="bg-transparent text-xs text-slate-200 font-bold outline-none cursor-pointer pr-4 focus:text-peach mt-0.5"
              >
                {scenarios.map(s => (
                  <option key={s.name} value={s.name} className="bg-slate-950 text-slate-300">
                    {s.name} Scenario
                  </option>
                ))}
              </select>
            </div>

            <div className="h-6 w-px bg-slate-800 hidden sm:block" />

            {/* Hurdle Discount Rate Displays */}
            <div className="flex flex-col">
              <span className="text-[9px] text-slate-500 uppercase tracking-widest font-semibold">Hurdle Rate (WACC)</span>
              <span className="text-xs text-peach font-extrabold font-mono mt-0.5">{(discountRate * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>

        {/* Dynamic Portfolio Metrics */}
        <div className="flex gap-8 md:gap-10 self-end lg:self-auto w-full lg:w-auto justify-between lg:justify-end border-t border-slate-800/50 lg:border-t-0 pt-4 lg:pt-0">
          <div className="text-right">
            <div className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider">Portfolio NPV ({(discountRate * 100).toFixed(0)}%)</div>
            <div className="font-mono text-base md:text-xl text-peach font-bold">
              {headerMetrics.portfolioNPV >= 1000 
                ? `$${(headerMetrics.portfolioNPV / 1000).toFixed(3)}B` 
                : `$${headerMetrics.portfolioNPV.toFixed(1)}M`}
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider">Weighted Avg IRR</div>
            <div className="font-mono text-base md:text-xl text-peach font-bold">
              {(headerMetrics.weightedAvgIrr * 100).toFixed(1)}%
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider">Remaining Reserves</div>
            <div className="font-mono text-base md:text-xl text-peach font-bold">
              {headerMetrics.totalReserves.toLocaleString(undefined, { maximumFractionDigits: 0 })} MMboe
            </div>
          </div>
        </div>
      </header>

      {/* Main Structural Framework Panel */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Left Navigation Sidebar */}
        <nav className="w-full md:w-64 bg-slate-900 border-r border-slate-800/80 py-4 px-3 flex flex-col justify-between shrink-0 overflow-y-auto md:max-h-full">
          <div className="space-y-6">
            {navigationGroups.map(group => (
              <div key={group.groupName} className="space-y-1.5">
                <span className="px-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">
                  {group.groupName}
                </span>

                {group.items.map(item => {
                  const isActive = activeTab === item.id;
                  const Icon = item.icon;

                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold tracking-wide transition border ${
                        isActive
                          ? 'bg-slate-800 border-l-2 border-l-peach border-slate-700/50 text-white font-bold'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className={`w-4 h-4 ${isActive ? 'text-peach' : 'text-slate-400'}`} />
                        <span>{item.label}</span>
                      </div>
                      {isActive && <ChevronRight className="w-3.5 h-3.5 text-peach" />}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>

          {/* Sidebar Footer branding */}
          <div className="pt-6 border-t border-slate-800/60 mt-6 px-3 flex flex-col gap-1.5 text-[11px] text-slate-500">
            <div className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-slate-600 shrink-0" />
              <span>EVWM Secure Engine Access</span>
            </div>
            <p className="text-[10px] leading-relaxed">
              Confidential platform for evaluating sovereign energy infrastructure securities.
            </p>
          </div>
        </nav>

        {/* Right Dashboard Workbench Viewport */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 bg-slate-950">
          <div className="max-w-7xl mx-auto space-y-6">
            {activeTab === 'portfolio' && (
              <PortfolioDashboard
                assets={assets}
                scenario={activeScenario}
                scenarios={scenarios}
                discountRate={discountRate}
                horizonYears={horizonYears}
                onSelectAsset={(asset) => {
                  setSelectedAssetId(asset.id);
                  setActiveTab('forecast');
                }}
                onSelectTab={(tab) => {
                  if (tab === 'assets') setActiveTab('register');
                  if (tab === 'reporting') setActiveTab('reporting');
                }}
              />
            )}

            {activeTab === 'register' && (
              <AssetRegister
                assets={assets}
                onAddAsset={handleAddAsset}
                onUpdateAsset={handleUpdateAsset}
                onDeleteAsset={handleDeleteAsset}
                onSelectAsset={(asset) => {
                  setSelectedAssetId(asset.id);
                  setActiveTab('forecast');
                }}
              />
            )}

            {activeTab === 'forecast' && (
              <ProductionForecast
                asset={activeAsset}
                onUpdateAsset={handleUpdateAsset}
                horizonYears={horizonYears}
              />
            )}

            {activeTab === 'pricing' && (
              <PriceScenarioComponent
                asset={activeAsset}
                scenarios={scenarios}
                onUpdateScenarios={handleUpdateScenarios}
                discountRate={discountRate}
                horizonYears={horizonYears}
              />
            )}

            {activeTab === 'costs' && (
              <CostModel
                asset={activeAsset}
                scenario={activeScenario}
                discountRate={discountRate}
                horizonYears={horizonYears}
              />
            )}

            {activeTab === 'valuation' && (
              <ValuationDashboard
                asset={activeAsset}
                scenario={activeScenario}
                discountRate={discountRate}
                onUpdateDiscountRate={setDiscountRate}
                horizonYears={horizonYears}
              />
            )}

            {activeTab === 'sensitivity' && (
              <SensitivityAnalysis
                asset={activeAsset}
                scenario={activeScenario}
                discountRate={discountRate}
                horizonYears={horizonYears}
              />
            )}

            {activeTab === 'map' && (
              <GeographicAnalysis
                assets={assets}
                scenario={activeScenario}
                discountRate={discountRate}
                horizonYears={horizonYears}
                onSelectAsset={(asset) => {
                  setSelectedAssetId(asset.id);
                  setActiveTab('forecast');
                }}
              />
            )}

            {activeTab === 'risk' && (
              <RiskDashboard
                assets={assets}
                scenario={activeScenario}
                scenarios={scenarios}
                discountRate={discountRate}
                horizonYears={horizonYears}
              />
            )}

            {activeTab === 'reporting' && (
              <ReportingTab
                asset={activeAsset}
                assets={assets}
                scenario={activeScenario}
                discountRate={discountRate}
                horizonYears={horizonYears}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
