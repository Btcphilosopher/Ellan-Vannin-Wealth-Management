export type FieldStatus = 'Exploration' | 'Development' | 'Production' | 'Decline' | 'Decommissioned';
export type DeclineType = 'exponential' | 'hyperbolic' | 'user-defined';

export interface ReservoirAsset {
  id: string;
  name: string;
  operator: string;
  country: string;
  waterDepth: number; // in meters (0 for onshore)
  fieldStatus: FieldStatus;
  startYear: number;
  remainingReserves: number; // MMboe (Million Barrels of Oil Equivalent)
  currentProduction: number; // MMboe/year
  declineRate: number; // fractional, e.g., 0.08 for 8%
  declineType: DeclineType;
  hyperbolicB: number; // hyperbolic exponent b, 0.1 - 0.9 (ignored if exponential)
  flatPeriod: number; // flat production years before decline
  opexFixed: number; // Million $/year
  opexVariable: number; // $/boe
  capex: number; // Million $
  capexDuration: number; // years over which CAPEX is distributed
  remainingLife: number; // years
  decommissioningProvision: number; // Million $ spent in the final year
  carbonIntensity: number; // kg CO2 / boe
  latitude: number;
  longitude: number;
  userProductionProfile?: number[]; // custom production values for remainingLife years (MMboe/year)
}

export type PriceScenarioName = 'Low' | 'Base' | 'High' | 'Custom';

export interface PriceScenario {
  name: PriceScenarioName;
  oilPrice: number; // $/bbl
  gasPrice: number; // $/Mscf
  carbonTax: number; // $/tonne CO2
  inflationRate: number; // fractional, e.g., 0.02 for 2%
}

export interface AnnualCashFlow {
  year: number;
  production: number; // MMboe
  cumulativeProduction: number; // MMboe
  oilPrice: number; // $/bbl
  gasPrice: number; // $/Mscf
  revenue: number; // Million $
  opexFixed: number; // Million $
  opexVariable: number; // Million $
  opexTotal: number; // Million $
  capex: number; // Million $
  carbonCost: number; // Million $
  decommissioning: number; // Million $
  totalCost: number; // Million $
  freeCashFlow: number; // Million $
  discountedCashFlow: number; // Million $
}

export interface ValuationMetrics {
  npv: number; // Million $
  irr: number; // fractional
  paybackPeriod: number; // years
  profitabilityIndex: number; // Ratio
  totalProduction: number; // MMboe
  totalRevenue: number; // Million $
  totalCapex: number; // Million $
  totalOpex: number; // Million $
  totalFreeCashFlow: number; // Million $
}

export interface SensitivityPoint {
  percentChange: number; // e.g. -30, -20, -10, 0, 10, 20, 30
  value: number; // NPV or IRR
}

export interface SensitivityData {
  parameter: string; // 'Commodity Price' | 'OPEX' | 'CAPEX' | 'Decline Rate' | 'Discount Rate'
  points: SensitivityPoint[];
}
