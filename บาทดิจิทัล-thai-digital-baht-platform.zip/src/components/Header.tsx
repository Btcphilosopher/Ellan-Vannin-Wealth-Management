/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Header.tsx
 * Top Bar Contract component for Thai Digital Baht Platform
 */

import React from 'react';
import { 
  Wallet, 
  Store, 
  Building2, 
  Cpu, 
  Globe2, 
  Activity, 
  Terminal, 
  FileCode2, 
  Shield,
  RotateCcw
} from 'lucide-react';
import { digitalBahtStore } from '../services/store';

export type ActiveTab = 
  | 'wallet'
  | 'merchant'
  | 'central-bank'
  | 'programmable'
  | 'cross-border'
  | 'stress-test'
  | 'cli'
  | 'api-docs'
  | 'privacy';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  const navItems: { id: ActiveTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'wallet', label: 'กระเป๋าเงิน', icon: Wallet },
    { id: 'merchant', label: 'ร้านค้า POS', icon: Store },
    { id: 'central-bank', label: 'ศูนย์ธนาคารกลาง', icon: Building2 },
    { id: 'programmable', label: 'ชำระแบบกำหนดเงื่อนไข', icon: Cpu },
    { id: 'cross-border', label: 'ข้ามพรมแดน', icon: Globe2 },
    { id: 'stress-test', label: 'ทดสอบความคงทน', icon: Activity },
    { id: 'cli', label: 'CLI Terminal', icon: Terminal },
    { id: 'api-docs', label: 'OpenAPI Gateway', icon: FileCode2 },
    { id: 'privacy', label: 'ความเป็นส่วนตัว', icon: Shield },
  ];

  return (
    <header className="bg-slate-950 border-b border-slate-800 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand title (single text element wordmark) */}
        <a 
          href="#home" 
          onClick={(e) => { e.preventDefault(); setActiveTab('wallet'); }} 
          className="flex items-center gap-2.5 text-white hover:opacity-90 transition-opacity shrink-0"
        >
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center font-bold text-slate-950 text-xl shadow-inner border border-amber-300/30">
            ฿
          </div>
          <div>
            <div className="text-base font-bold tracking-tight leading-none text-amber-400">
              บาทดิจิทัล
            </div>
            <div className="text-[10px] font-mono tracking-wider text-slate-400 leading-tight">
              DIGITAL BAHT CORE
            </div>
          </div>
        </a>

        {/* Zone 2: Navigation Links (single line, horizontal scroll on smaller viewports) */}
        <nav className="flex items-center gap-1 overflow-x-auto no-scrollbar py-1 px-2 bg-slate-900/80 rounded-xl border border-slate-800/80">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              if (confirm('ยืนยันรีเซ็ตข้อมูลจำลองการทดสอบทั้งหมดเป็นค่าเริ่มต้น?')) {
                digitalBahtStore.resetSimulation();
              }
            }}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors"
            title="รีเซ็ตจำลองระบบ"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span>รีเซ็ตจำลอง</span>
          </button>

          <div className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-mono flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-medium hidden md:inline">SIMULATION ACTIVE</span>
            <span className="font-medium md:hidden">SIM</span>
          </div>
        </div>
      </div>
    </header>
  );
};
