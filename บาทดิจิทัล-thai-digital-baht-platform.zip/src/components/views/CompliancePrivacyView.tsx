/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * CompliancePrivacyView.tsx
 * Privacy Center, Consent Management & AML Compliance Engine
 */

import React, { useState, useEffect } from 'react';
import { ShieldCheck, Lock, AlertTriangle, Eye, CheckCircle2, UserCheck } from 'lucide-react';
import { digitalBahtStore } from '../../services/store';
import { AmlAlert, ConsentRecord } from '../../types';

export const CompliancePrivacyView: React.FC = () => {
  const [alerts, setAlerts] = useState<AmlAlert[]>(digitalBahtStore.amlAlerts);
  const [consents, setConsents] = useState<ConsentRecord[]>([
    {
      consent_id: 'CONSENT-001',
      customer_id: 'CUST-TH-1100800921',
      purpose: 'การยืนยันตัวตนระดับ KYC2 เพื่อเปิดใช้วงเงินบาทดิจิทัล 100,000 บาท',
      data_type: 'ข้อมูลบัตรประชาชนและใบหน้า',
      recipient: 'ธนาคารแห่งประเทศไทย และ ธนาคารกรุงศรีอยุธยา',
      granted_at: '2026-02-15T09:00:00Z',
      expires_at: '2027-02-15T09:00:00Z',
      status: 'ACTIVE'
    },
    {
      consent_id: 'CONSENT-002',
      customer_id: 'CUST-TH-1100800921',
      purpose: 'การวิเคราะห์การชำระเงินเพื่อป้องกันการทุจริตในระบบออฟไลน์',
      data_type: 'หมายเลขประจำอุปกรณ์ (Device ID)',
      recipient: 'ศูนย์เฝ้าระวังภัยทุจริตทางการเงินกลาง',
      granted_at: '2026-03-01T10:00:00Z',
      expires_at: '2027-03-01T10:00:00Z',
      status: 'ACTIVE'
    }
  ]);

  useEffect(() => {
    const unsub = digitalBahtStore.subscribe(() => {
      setAlerts([...digitalBahtStore.amlAlerts]);
    });
    return unsub;
  }, []);

  const handleRevokeConsent = (consentId: string) => {
    setConsents(prev =>
      prev.map(c => (c.consent_id === consentId ? { ...c, status: 'REVOKED' } : c))
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>PRIVACY-BY-DESIGN & COMPLIANCE CENTER</span>
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            ศูนย์ความเป็นส่วนตัว และการจัดการความยินยอม (Privacy & Consent)
          </h2>

          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            คุ้มครองข้อมูลส่วนบุคคลตามหลัก Data Minimisation แยกฐานข้อมูลสิทธิความเป็นส่วนตัวออกจากประวัติธุรกรรม และระบบเฝ้าระวัง AML ทุจริต
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Consent Center */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-emerald-400" />
            <span>รายการความยินยอมการเปิดเผยข้อมูล (Consent Records)</span>
          </h3>

          <div className="space-y-3">
            {consents.map(c => (
              <div key={c.consent_id} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs">
                <div className="flex justify-between items-start">
                  <div className="font-semibold text-slate-200">{c.purpose}</div>
                  <span className={`px-2 py-0.5 rounded font-mono text-[10px] ${
                    c.status === 'ACTIVE' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {c.status}
                  </span>
                </div>

                <div className="text-slate-400">ประเภทข้อมูล: <span className="text-slate-300 font-medium">{c.data_type}</span></div>
                <div className="text-slate-400">ผู้รับข้อมูล: <span className="text-slate-300 font-medium">{c.recipient}</span></div>

                {c.status === 'ACTIVE' && (
                  <button
                    onClick={() => handleRevokeConsent(c.consent_id)}
                    className="mt-2 py-1 px-3 rounded bg-slate-800 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-[11px] transition-colors"
                  >
                    ถอนความยินยอม (Revoke Consent)
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* AML & Fraud Cases */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <span>ระบบตรวจสอบธุรกรรมผิดปกติ (AML & Fraud Monitoring)</span>
          </h3>

          <div className="space-y-3">
            {alerts.length === 0 ? (
              <div className="p-6 text-center text-slate-500 text-xs border border-dashed border-slate-800 rounded-xl">
                ไม่พบรายการเตือนภัยทุจริตร้ายแรง
              </div>
            ) : (
              alerts.map(al => (
                <div key={al.alert_id} className="p-4 bg-slate-950 rounded-xl border border-rose-500/30 space-y-2 text-xs">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-rose-400">{al.trigger_reason}</span>
                    <span className="font-mono text-amber-400 font-bold">Risk Score: {al.risk_score}/100</span>
                  </div>

                  <div className="text-slate-400">ผู้ถือ Wallet: <span className="text-slate-200">{al.customer_name}</span></div>
                  <div className="text-slate-400">ยอดเงิน: <span className="font-mono text-amber-300 font-bold">฿{al.amount}</span></div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
