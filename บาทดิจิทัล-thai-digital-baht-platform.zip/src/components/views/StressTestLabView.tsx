/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * StressTestLabView.tsx
 * CBDC Stress Test, Resilience & Reconciliation Audit Lab
 */

import React, { useState } from 'react';
import { Activity, ShieldAlert, Cpu, RefreshCw, CheckCircle2, AlertTriangle } from 'lucide-react';
import { digitalBahtStore } from '../../services/store';

export const StressTestLabView: React.FC = () => {
  const [logs, setLogs] = useState(digitalBahtStore.auditLogs);

  const handleRunScenario = (scenario: 'TPS_SPIKE' | 'BANK_OUTAGE' | 'DOUBLE_SPEND_ATTACK' | 'RECONCILIATION_AUDIT') => {
    digitalBahtStore.runStressTest(scenario);
    setLogs([...digitalBahtStore.auditLogs]);
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-rose-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold flex items-center gap-1">
              <Activity className="w-3.5 h-3.5" />
              <span>CBDC STRESS TEST & RESILIENCE LAB</span>
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            ห้องทดสอบความคงทนและจำลองวิกฤตระบบชำระเงิน
          </h2>

          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            ทดสอบประสิทธิภาพความปลอดภัยระดับโครงสร้างพื้นฐาน การยับยั้ง Double-Spend attack, สถานการณ์ธนาคารพาณิชย์หยุดทำงาน และการกระทบยอดบัญชีอัตโนมัติ (Reconciliation)
          </p>
        </div>
      </div>

      {/* Scenario Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          onClick={() => handleRunScenario('TPS_SPIKE')}
          className="p-5 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 rounded-2xl text-left transition-all group"
        >
          <Cpu className="w-6 h-6 text-amber-400 mb-2 group-hover:scale-110 transition-transform" />
          <h4 className="font-bold text-slate-100 text-sm">TPS Peak Load Spike</h4>
          <p className="text-xs text-slate-400 mt-1">จำลองโหลดชำระเงินพร้อมกัน 100,000 TPS</p>
        </button>

        <button
          onClick={() => handleRunScenario('DOUBLE_SPEND_ATTACK')}
          className="p-5 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-rose-500/50 rounded-2xl text-left transition-all group"
        >
          <ShieldAlert className="w-6 h-6 text-rose-400 mb-2 group-hover:scale-110 transition-transform" />
          <h4 className="font-bold text-slate-100 text-sm">Double-Spend Defence</h4>
          <p className="text-xs text-slate-400 mt-1">ส่ง 5,000 ธุรกรรมซ้ำเพื่อทดสอบการบล็อก</p>
        </button>

        <button
          onClick={() => handleRunScenario('BANK_OUTAGE')}
          className="p-5 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-purple-500/50 rounded-2xl text-left transition-all group"
        >
          <AlertTriangle className="w-6 h-6 text-purple-400 mb-2 group-hover:scale-110 transition-transform" />
          <h4 className="font-bold text-slate-100 text-sm">Bank Outage Failover</h4>
          <p className="text-xs text-slate-400 mt-1">จำลองธนาคารพาณิชย์ล่ม และการทำงานทดแทน</p>
        </button>

        <button
          onClick={() => handleRunScenario('RECONCILIATION_AUDIT')}
          className="p-5 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-emerald-500/50 rounded-2xl text-left transition-all group"
        >
          <CheckCircle2 className="w-6 h-6 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
          <h4 className="font-bold text-slate-100 text-sm">Reconciliation Audit</h4>
          <p className="text-xs text-slate-400 mt-1">กระทบยอด Ledger Liability 100%</p>
        </button>
      </div>

      {/* Real-time Audit Trail Console */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <h3 className="font-bold text-slate-100 text-base">บันทึกผลการทดสอบระบบ (Stress Test Audit Journal)</h3>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs space-y-2 max-h-96 overflow-y-auto">
          {logs.map((log) => (
            <div key={log.audit_id} className="p-2.5 rounded bg-slate-900/60 border border-slate-800 flex items-start gap-3">
              <span className={`px-1.5 py-0.5 rounded text-[10px] shrink-0 font-bold ${
                log.status === 'SUCCESS' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
              }`}>
                {log.status}
              </span>

              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-slate-200 font-sans font-semibold text-xs">
                  {log.details_th}
                </div>
                <div className="text-slate-500 text-[10px] flex items-center gap-2">
                  <span>Actor: {log.actor}</span>
                  <span>·</span>
                  <span>Action: {log.action}</span>
                  <span>·</span>
                  <span>{new Date(log.timestamp).toLocaleTimeString('th-TH')}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
