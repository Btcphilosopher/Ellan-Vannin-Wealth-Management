/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * MerchantAppView.tsx
 * Merchant Portal & Digital Baht POS (Bangkok Coffee Sukhumvit)
 */

import React, { useState, useEffect } from 'react';
import { 
  Store, 
  QrCode, 
  DollarSign, 
  TrendingUp, 
  Receipt, 
  RotateCcw, 
  CheckCircle2, 
  ShieldCheck, 
  Plus, 
  Coffee,
  ShoppingBag,
  Utensils
} from 'lucide-react';
import { digitalBahtStore } from '../../services/store';
import { Merchant, DigitalBahtPayment } from '../../types';

interface MerchantAppViewProps {
  onSelectPaymentForReceipt: (p: DigitalBahtPayment) => void;
}

export const MerchantAppView: React.FC<MerchantAppViewProps> = ({ onSelectPaymentForReceipt }) => {
  const [merchant, setMerchant] = useState<Merchant | undefined>(
    digitalBahtStore.merchants.get('DB-MERCHANT-042')
  );
  const [merchantWalletBalance, setMerchantWalletBalance] = useState(
    digitalBahtStore.wallets.get('DB-MERCHANT-042')?.balance || '0.00'
  );
  const [payments, setPayments] = useState<DigitalBahtPayment[]>([]);

  // POS State
  const [posAmount, setPosAmount] = useState('185.00');
  const [posItemName, setPosItemName] = useState('ชุดกาแฟและขนมหวานเดลี่');
  const [activeQr, setActiveQr] = useState<string | null>(null);

  // Refund Modal State
  const [selectedRefundPayment, setSelectedRefundPayment] = useState<DigitalBahtPayment | null>(null);
  const [refundReason, setRefundReason] = useState('ลูกค้าขอคืนสินค้า');
  const [refundStatusMsg, setRefundStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    const unsub = digitalBahtStore.subscribe(() => {
      setMerchant(digitalBahtStore.merchants.get('DB-MERCHANT-042'));
      setMerchantWalletBalance(digitalBahtStore.wallets.get('DB-MERCHANT-042')?.balance || '0.00');
      // Filter merchant payments
      setPayments(digitalBahtStore.payments.filter(p => p.payee_wallet === 'DB-MERCHANT-042' || p.payer_wallet === 'DB-MERCHANT-042'));
    });

    setPayments(digitalBahtStore.payments.filter(p => p.payee_wallet === 'DB-MERCHANT-042' || p.payer_wallet === 'DB-MERCHANT-042'));
    return unsub;
  }, []);

  const handleGeneratePosQr = () => {
    setActiveQr(`SYNTHETIC-POS-QR-${Date.now()}-${posAmount}`);
  };

  const handleSimulateCustomerPayPos = () => {
    const res = digitalBahtStore.processPayment(
      'DB-WALLET-0000421',
      'DB-MERCHANT-042',
      posAmount,
      posItemName,
      `POS-AUTO-${Date.now()}`
    );

    if (res.success && res.payment) {
      setActiveQr(null);
      onSelectPaymentForReceipt(res.payment);
    }
  };

  const handleExecuteRefund = () => {
    if (!selectedRefundPayment) return;
    setRefundStatusMsg(null);
    const res = digitalBahtStore.refundPayment(selectedRefundPayment.payment_id, refundReason);
    if (res.success) {
      setRefundStatusMsg('ดำเนินการคืนเงินบาทดิจิทัลสำเร็จ บันทึกลง Ledger เรียบร้อยแล้ว');
      setSelectedRefundPayment(null);
    } else {
      setRefundStatusMsg(`การคืนเงินล้มเหลว: ${res.error}`);
    }
  };

  if (!merchant) return null;

  return (
    <div className="space-y-6">
      {/* 1. Merchant Banner Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 rounded-3xl p-6 sm:p-8 border border-amber-500/30 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold flex items-center gap-1">
              <Store className="w-3.5 h-3.5" />
              <span>ร้านค้าพันธมิตรรองรับบาทดิจิทัล</span>
            </span>
            <span className="text-xs text-slate-400 font-mono">ID: {merchant.merchant_id}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            {merchant.merchant_name}
          </h2>

          <p className="text-xs text-slate-400">
            หมวดหมู่: <span className="text-slate-200 font-medium">{merchant.category}</span> · พร้อมรับชำระผ่าน PromptPay / Retail CBDC
          </p>
        </div>

        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1 text-right min-w-[220px]">
          <div className="text-xs text-slate-400">ยอดเงินคงเหลือสะสมร้านค้า:</div>
          <div className="text-3xl font-extrabold font-mono text-amber-400">
            ฿{merchantWalletBalance}
          </div>
          <div className="text-[11px] text-emerald-400 font-medium flex items-center justify-end gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>พร้อมชำระบัญชี (Settlement Ready)</span>
          </div>
        </div>
      </div>

      {/* 2. Key Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>ยอดขายวันนี้ (Today's Sales)</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            ฿{merchant.daily_sales}
          </div>
          <p className="text-[11px] text-slate-500">เงินบาทดิจิทัลเข้าบัญชีทันที</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>จำนวนรายการวันนี้</span>
            <Receipt className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {merchant.transaction_count} <span className="text-xs text-slate-400 font-normal">รายการ</span>
          </div>
          <p className="text-[11px] text-slate-500">อัตราทำรายการสำเร็จ 100%</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>ยอดเฉลี่ยต่อบิล (Avg Ticket)</span>
            <TrendingUp className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-blue-400">
            ฿{merchant.average_ticket}
          </div>
          <p className="text-[11px] text-slate-500">ค่าธรรมเนียมธุรกรรม 0.00%</p>
        </div>
      </div>

      {/* 3. Main Split View: POS Mode vs Transaction/Refund Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Digital Baht POS Screen */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
              <QrCode className="w-5 h-5 text-amber-400" />
              <span>DIGITAL BAHT POS TERMINAL</span>
            </h3>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 font-mono px-2 py-0.5 rounded">
              POS MODE
            </span>
          </div>

          {/* Preset Item Quick Buttons */}
          <div>
            <label className="block text-xs text-slate-400 mb-2">เลือกเมนูด่วน:</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => { setPosItemName('กาแฟลาเต้ร้อน'); setPosAmount('95.00'); }}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition-colors"
              >
                <Coffee className="w-4 h-4 text-amber-400 mb-1" />
                <div className="text-xs font-semibold text-slate-200">ลาเต้ร้อน</div>
                <div className="text-[11px] font-mono text-amber-400">฿95.00</div>
              </button>

              <button
                onClick={() => { setPosItemName('แซนวิชแฮมชีส'); setPosAmount('140.00'); }}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition-colors"
              >
                <ShoppingBag className="w-4 h-4 text-emerald-400 mb-1" />
                <div className="text-xs font-semibold text-slate-200">แซนวิช</div>
                <div className="text-[11px] font-mono text-amber-400">฿140.00</div>
              </button>

              <button
                onClick={() => { setPosItemName('ชุดอาหารเช้าสมบูรณ์แบบ'); setPosAmount('185.00'); }}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition-colors"
              >
                <Utensils className="w-4 h-4 text-blue-400 mb-1" />
                <div className="text-xs font-semibold text-slate-200">ชุดอาหารเช้า</div>
                <div className="text-[11px] font-mono text-amber-400">฿185.00</div>
              </button>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">
                รายการสินค้า / หมายเหตุ:
              </label>
              <input
                type="text"
                value={posItemName}
                onChange={(e) => setPosItemName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">
                จำนวนเงินที่ต้องชำระ (บาท):
              </label>
              <input
                type="number"
                step="0.01"
                value={posAmount}
                onChange={(e) => setPosAmount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-2xl font-extrabold text-amber-400 font-mono"
              />
            </div>

            <button
              onClick={handleGeneratePosQr}
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition-colors shadow-lg shadow-amber-500/20"
            >
              สร้าง Dynamic QR รับเงินบาทดิจิทัล
            </button>
          </div>

          {/* Generated QR Screen */}
          {activeQr && (
            <div className="p-4 bg-slate-950 rounded-2xl border border-amber-500/40 text-center space-y-3 animate-fade-in">
              <div className="p-3 bg-white rounded-xl inline-block">
                <QrCode className="w-32 h-32 text-slate-950" />
              </div>

              <div>
                <div className="text-xs text-slate-400">สแกนชำระจำนวนเงิน:</div>
                <div className="text-2xl font-bold font-mono text-amber-400">฿{posAmount}</div>
                <div className="text-xs text-slate-300 font-medium mt-0.5">{posItemName}</div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  onClick={() => setActiveQr(null)}
                  className="w-1/2 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
                >
                  ยกเลิก QR
                </button>
                <button
                  onClick={handleSimulateCustomerPayPos}
                  className="w-1/2 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20"
                >
                  จำลองลูกค้าจ่ายแล้ว
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Merchant Transactions & Refunds */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
              <Receipt className="w-5 h-5 text-amber-400" />
              <span>รายการรับเงินล่าสุด & คืนเงิน (Merchant Ledger)</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              {payments.length} รายการ
            </span>
          </div>

          {refundStatusMsg && (
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{refundStatusMsg}</span>
            </div>
          )}

          <div className="divide-y divide-slate-800">
            {payments.map((p) => (
              <div
                key={p.payment_id}
                className="py-3 flex items-center justify-between gap-4 hover:bg-slate-800/40 px-2 rounded-xl"
              >
                <div>
                  <div className="text-sm font-semibold text-slate-200">
                    {p.purpose}
                  </div>
                  <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5 font-mono">
                    <span>{p.payment_id}</span>
                    <span>·</span>
                    <span>{new Date(p.created_at).toLocaleTimeString('th-TH')}</span>
                  </div>
                </div>

                <div className="text-right flex items-center gap-3">
                  <div>
                    <div className="text-base font-bold font-mono text-emerald-400">
                      +฿{p.amount}
                    </div>
                    <div className="text-[10px] font-mono text-slate-400 text-right">
                      {p.status}
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onSelectPaymentForReceipt(p)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
                      title="ดูใบเสร็จ"
                    >
                      <Receipt className="w-4 h-4 text-amber-400" />
                    </button>

                    {p.status === 'SETTLED' && (
                      <button
                        onClick={() => setSelectedRefundPayment(p)}
                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs border border-rose-500/30"
                        title="คืนเงินให้ลูกค้า"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Refund Confirmation Dialog */}
      {selectedRefundPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-rose-400 flex items-center gap-2">
              <RotateCcw className="w-5 h-5" />
              <span>ยืนยันการคืนเงินบาทดิจิทัล (Refund Execution)</span>
            </h3>

            <div className="p-3 bg-slate-950 rounded-xl text-xs space-y-1">
              <div className="text-slate-400">รายการ: <span className="text-slate-200 font-semibold">{selectedRefundPayment.purpose}</span></div>
              <div className="text-slate-400">จำนวนเงินคืน: <span className="text-rose-400 font-mono font-bold">฿{selectedRefundPayment.amount}</span></div>
              <div className="text-slate-400">Transaction ID: <span className="font-mono text-slate-300">{selectedRefundPayment.payment_id}</span></div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">ระบุเหตุผลในการคืนเงิน:</label>
              <input
                type="text"
                value={refundReason}
                onChange={(e) => setRefundReason(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setSelectedRefundPayment(null)}
                className="w-1/2 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
              >
                ยกเลิก
              </button>
              <button
                onClick={handleExecuteRefund}
                className="w-1/2 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/20"
              >
                ยืนยันการคืนเงินทันที
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
