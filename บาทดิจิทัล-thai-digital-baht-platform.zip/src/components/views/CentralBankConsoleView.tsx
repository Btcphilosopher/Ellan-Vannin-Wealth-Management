/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * CentralBankConsoleView.tsx
 * Bank of Thailand Retail CBDC Operations Terminal (ศูนย์ปฏิบัติการเงินบาทดิจิทัล)
 */

import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Coins, 
  Users, 
  Store, 
  Activity, 
  PlusCircle, 
  MinusCircle, 
  ShieldAlert, 
  CheckCircle2, 
  BarChart3, 
  Database,
  Cpu,
  RefreshCw
} from 'lucide-react';
import { digitalBahtStore } from '../../services/store';

export const CentralBankConsoleView: React.FC = () => {
  const [metrics, setMetrics] = useState(digitalBahtStore.metrics);
  const [ledgerAccounts, setLedgerAccounts] = useState(Array.from(digitalBahtStore.ledgerAccounts.values()));
  const [ledgerEntries, setLedgerEntries] = useState(digitalBahtStore.ledgerEntries);

  // Mint / Redeem Simulator state
  const [mintAmount, setMintAmount] = useState('100000.00');
  const [mintWalletId, setMintWalletId] = useState('DB-WALLET-0000421');
  const [mintReason, setMintReason] = useState('จัดสรรสภาพคล่องการทดสอบนำร่อง Retail CBDC');
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const [redeemAmount, setRedeemAmount] = useState('50000.00');
  const [redeemWalletId, setRedeemWalletId] = useState('DB-WALLET-0000421');

  useEffect(() => {
    const unsub = digitalBahtStore.subscribe(() => {
      setMetrics({ ...digitalBahtStore.metrics });
      setLedgerAccounts(Array.from(digitalBahtStore.ledgerAccounts.values()));
      setLedgerEntries([...digitalBahtStore.ledgerEntries]);
    });
    return unsub;
  }, []);

  const handleExecuteMint = (e: React.FormEvent) => {
    e.preventDefault();
    setActionNotice(null);
    const res = digitalBahtStore.mintCBDC(mintAmount, mintWalletId, mintReason);
    if (res.success) {
      setActionNotice(`[SIMULATION ONLY] ออกเงินบาทดิจิทัลเพิ่ม ฿${mintAmount} สำเร็จ!`);
    } else {
      setActionNotice(`เกิดข้อผิดพลาด: ${res.error}`);
    }
  };

  const handleExecuteRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    setActionNotice(null);
    const res = digitalBahtStore.redeemCBDC(redeemAmount, redeemWalletId, 'BAY-BANK-09921');
    if (res.success) {
      setActionNotice(`[SIMULATION ONLY] แลกคืนเงินบาทดิจิทัล ฿${redeemAmount} กลับเป็นเงินสำรองสำเร็จ!`);
    } else {
      setActionNotice(`เกิดข้อผิดพลาด: ${res.error}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Terminal Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5" />
                <span>ศูนย์ควบคุมและปฏิบัติการธนาคารกลาง (BOT Retail CBDC Console)</span>
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              ระบบออกเงิน ชำระบัญชี และควบคุมความเสี่ยงบาทดิจิทัล
            </h2>

            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              โครงสร้างพื้นฐานจำลองระดับประเทศสำหรับการออกเงินบาทดิจิทัล (Retail CBDC Issuance), Double-Entry Reconciliation และการเฝ้าระวังระบบชำระเงินเรียลไทม์
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-right min-w-[240px]">
            <div className="text-xs text-slate-400">ปริมาณเงินบาทดิจิทัลคงค้างทั้งหมด:</div>
            <div className="text-3xl font-extrabold font-mono text-amber-400 tracking-tight">
              ฿{(parseFloat(metrics.cbdc_outstanding) / 1000000000).toFixed(2)} พันล้าน
            </div>
            <div className="text-[11px] text-slate-400 font-mono mt-1">
              (฿{metrics.cbdc_outstanding} THB)
            </div>
          </div>
        </div>
      </div>

      {/* 2. Central Metrics Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>กระเป๋าเงินรวม (Wallets)</span>
            <Users className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {metrics.total_wallets.toLocaleString()}
          </div>
          <p className="text-[10px] text-emerald-400">KYC Level 2 & 3 Verified</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>ร้านค้าที่ลงทะเบียน</span>
            <Store className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {metrics.total_merchants.toLocaleString()}
          </div>
          <p className="text-[10px] text-slate-400">PromptPay / CBDC Enabled</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Settlement Latency</span>
            <Activity className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-blue-400">
            {metrics.avg_latency_ms} <span className="text-xs text-slate-400 font-normal">ms</span>
          </div>
          <p className="text-[10px] text-blue-400">อัตราสำเร็จ {metrics.settlement_success_rate}%</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>TPS Current Peak</span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-purple-400">
            {metrics.tps_current.toLocaleString()} <span className="text-xs text-slate-400 font-normal">tx/s</span>
          </div>
          <p className="text-[10px] text-purple-400">รองรับสูงสุด 100,000 TPS</p>
        </div>
      </div>

      {/* 3. Minting & Redemption Simulator Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Issuance Simulator */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
              <PlusCircle className="w-5 h-5 text-emerald-400" />
              <span>เครื่องมือจำลองการออกเงินบาทดิจิทัล (CBDC Minting)</span>
            </h3>
            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-mono px-2 py-0.5 rounded">
              SIMULATION ONLY
            </span>
          </div>

          <form onSubmit={handleExecuteMint} className="space-y-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">จำนวนเงินบาทดิจิทัลที่ออกเพิ่ม (THB):</label>
              <input
                type="number"
                value={mintAmount}
                onChange={(e) => setMintAmount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-lg font-mono font-bold text-emerald-400"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">กระเป๋าเงินผู้รับโอน:</label>
              <input
                type="text"
                value={mintWalletId}
                onChange={(e) => setMintWalletId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">เหตุผลเชิงนโยบาย:</label>
              <input
                type="text"
                value={mintReason}
                onChange={(e) => setMintReason(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors shadow-lg shadow-emerald-600/20"
            >
              ดำเนินการออกเงินบาทดิจิทัล (Mint)
            </button>
          </form>
        </div>

        {/* Redemption Simulator */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
              <MinusCircle className="w-5 h-5 text-rose-400" />
              <span>เครื่องมือจำลองการแลกคืนเงินบาทดิจิทัล (Redemption)</span>
            </h3>
            <span className="text-[10px] bg-rose-500/20 text-rose-300 font-mono px-2 py-0.5 rounded">
              SIMULATION ONLY
            </span>
          </div>

          <form onSubmit={handleExecuteRedeem} className="space-y-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">จำนวนเงินที่ต้องการแลกคืน (THB):</label>
              <input
                type="number"
                value={redeemAmount}
                onChange={(e) => setRedeemAmount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-lg font-mono font-bold text-rose-400"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">กระเป๋าเงินต้นทาง:</label>
              <input
                type="text"
                value={redeemWalletId}
                onChange={(e) => setRedeemWalletId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-100"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-500/30 font-bold text-xs transition-colors"
            >
              ดำเนินการแลกคืนเงินบาทดิจิทัล (Redeem to THB)
            </button>
          </form>
        </div>
      </div>

      {actionNotice && (
        <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-xl text-xs flex items-center gap-2 font-mono">
          <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* 4. Double-Entry Ledger Inspector */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
            <Database className="w-5 h-5 text-amber-400" />
            <span>บัญชีแยกประเภทคู่เงินบาทดิจิทัล (Central Double-Entry Accounts)</span>
          </h3>
          <span className="text-xs text-emerald-400 font-mono">
            INVARIANT: TOTAL LIABILITY == OUTSTANDING
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {ledgerAccounts.map((acc) => (
            <div key={acc.account_id} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
              <div className="text-[11px] font-mono text-slate-400">{acc.account_id}</div>
              <div className="text-xs font-semibold text-slate-200 line-clamp-1">{acc.account_name}</div>
              <div className="text-xl font-bold font-mono text-amber-400 pt-1">
                ฿{acc.balance}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
