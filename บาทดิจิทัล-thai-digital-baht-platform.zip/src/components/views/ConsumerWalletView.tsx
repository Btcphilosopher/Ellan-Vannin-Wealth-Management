/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ConsumerWalletView.tsx
 * Thai Digital Baht Retail Consumer Wallet View (Khun Somchai DB-WALLET-0000421)
 */

import React, { useState, useEffect } from 'react';
import { 
  QrCode, 
  Send, 
  Download, 
  PlusCircle, 
  History, 
  Users, 
  ShieldCheck, 
  WifiOff, 
  Split, 
  ArrowUpRight, 
  ArrowDownLeft, 
  CheckCircle2, 
  AlertCircle,
  Copy,
  Check
} from 'lucide-react';
import { digitalBahtStore } from '../../services/store';
import { DigitalBahtWallet, DigitalBahtPayment } from '../../types';

interface ConsumerWalletViewProps {
  onOpenScanner: () => void;
  onSelectPaymentForReceipt: (p: DigitalBahtPayment) => void;
}

export const ConsumerWalletView: React.FC<ConsumerWalletViewProps> = ({ 
  onOpenScanner, 
  onSelectPaymentForReceipt 
}) => {
  const [wallet, setWallet] = useState<DigitalBahtWallet | undefined>(
    digitalBahtStore.wallets.get('DB-WALLET-0000421')
  );
  const [payments, setPayments] = useState<DigitalBahtPayment[]>(digitalBahtStore.payments);
  const [copied, setCopied] = useState(false);

  // Tab inside wallet view
  const [subTab, setSubTab] = useState<'OVERVIEW' | 'TRANSFER' | 'RECEIVE' | 'SPLIT' | 'OFFLINE'>('OVERVIEW');

  // P2P Transfer Form
  const [p2pPayee, setP2pPayee] = useState('DB-WALLET-0000998');
  const [p2pAmount, setP2pAmount] = useState('500.00');
  const [p2pPurpose, setP2pPurpose] = useState('โอนเงินให้เพื่อนคุณวิภาวรรณ');
  const [transferStatus, setTransferStatus] = useState<{ msg: string; isError: boolean } | null>(null);

  // Split Bill Form
  const [splitAmount, setSplitAmount] = useState('1200.00');
  const [splitPeopleCount, setSplitPeopleCount] = useState('4');
  const [splitResult, setSplitResult] = useState<string | null>(null);

  // Offline Payment State
  const [offlineNonce, setOfflineNonce] = useState(101);
  const [offlineAmount, setOfflineAmount] = useState('150.00');
  const [offlineStatusMsg, setOfflineStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    const unsub = digitalBahtStore.subscribe(() => {
      setWallet(digitalBahtStore.wallets.get('DB-WALLET-0000421'));
      setPayments([...digitalBahtStore.payments]);
    });
    return unsub;
  }, []);

  const handleCopyWalletId = () => {
    if (wallet) {
      navigator.clipboard.writeText(wallet.wallet_id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleExecuteP2p = (e: React.FormEvent) => {
    e.preventDefault();
    setTransferStatus(null);
    const res = digitalBahtStore.processPayment(
      'DB-WALLET-0000421',
      p2pPayee,
      p2pAmount,
      p2pPurpose
    );
    if (res.success && res.payment) {
      setTransferStatus({ msg: `โอนเงินบาทดิจิทัล ฿${p2pAmount} สำเร็จแล้ว!`, isError: false });
      setP2pAmount('100.00');
      onSelectPaymentForReceipt(res.payment);
    } else {
      setTransferStatus({ msg: res.error?.message_th || 'การโอนเงินล้มเหลว', isError: true });
    }
  };

  const handleCalculateSplit = () => {
    const res = digitalBahtStore.splitBill(splitAmount, ['1', '2', '3', '4'], 'ค่าอาหารสังสรรค์');
    if (res.success && res.per_person) {
      setSplitResult(`สร้างคำขอเก็บเงินคนละ ฿${res.per_person} สำหรับ ${splitPeopleCount} คนสำเร็จแล้ว`);
    }
  };

  const handleOfflinePayment = (isDoubleSpendAttempt: boolean) => {
    setOfflineStatusMsg(null);
    const nonceToUse = isDoubleSpendAttempt ? offlineNonce - 1 : offlineNonce;

    const res = digitalBahtStore.processOfflinePayment(
      'DB-WALLET-0000421',
      'DB-MERCHANT-042',
      offlineAmount,
      nonceToUse
    );

    if (!isDoubleSpendAttempt && res.success) {
      setOfflineNonce(n => n + 1);
      setOfflineStatusMsg(`[OFFLINE TOKEN SYNC] ซิงก์ธุรกรรมออฟไลน์ ฿${offlineAmount} เข้า Ledger สำเร็จ`);
    } else if (!res.success) {
      setOfflineStatusMsg(`[DEFENCE TRIGGERED] ${res.error?.message_th}`);
    }
  };

  if (!wallet) return null;

  return (
    <div className="space-y-6">
      {/* 1. Main Wallet Balance Card (Thai Financial Modernism) */}
      <div className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 p-6 sm:p-8 border border-amber-500/30 shadow-2xl overflow-hidden">
        {/* Background Decorative Element */}
        <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>สถานะ: พร้อมใช้งาน</span>
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {wallet.provider_name}
              </span>
            </div>

            <div>
              <div className="text-xs font-medium text-slate-400">
                ยอดคงเหลือเงินบาทดิจิทัล (Digital Baht Balance)
              </div>
              <div className="text-4xl sm:text-5xl font-extrabold font-mono text-amber-400 tracking-tight mt-1 flex items-baseline gap-2">
                <span>฿{wallet.balance}</span>
                <span className="text-xs font-sans text-slate-400 font-normal">THB</span>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs text-slate-300 pt-1">
              <div>
                <span className="text-slate-400">ยอดที่ใช้ได้: </span>
                <span className="font-mono text-emerald-400 font-semibold">฿{wallet.available_balance}</span>
              </div>
              <div className="text-slate-600">|</div>
              <div>
                <span className="text-slate-400">ยอดกันไว้ (Reserved): </span>
                <span className="font-mono text-amber-300 font-semibold">฿{wallet.reserved_balance}</span>
              </div>
            </div>
          </div>

          {/* User & Wallet Identifier */}
          <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-2 min-w-[260px]">
            <div className="text-xs text-slate-400">เจ้าของกระเป๋าเงินบาทดิจิทัล:</div>
            <div className="text-sm font-bold text-white">{wallet.customer_name}</div>
            <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-800">
              <div className="text-xs font-mono text-amber-300/90 truncate">
                {wallet.wallet_id}
              </div>
              <button
                onClick={handleCopyWalletId}
                className="p-1 text-slate-400 hover:text-white rounded bg-slate-900 border border-slate-800 transition-colors shrink-0"
                title="คัดลอก Wallet ID"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="mt-8 grid grid-cols-2 sm:grid-cols-5 gap-3 pt-6 border-t border-slate-800/80">
          <button
            onClick={onOpenScanner}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs gap-1.5 transition-all shadow-lg shadow-amber-500/20 active:scale-95"
          >
            <QrCode className="w-5 h-5" />
            <span>สแกนเพื่อจ่าย</span>
          </button>

          <button
            onClick={() => setSubTab('TRANSFER')}
            className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-xs font-semibold gap-1.5 transition-all ${
              subTab === 'TRANSFER'
                ? 'bg-slate-800 border-amber-500 text-amber-400'
                : 'bg-slate-900/90 border-slate-800 text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Send className="w-5 h-5 text-amber-400" />
            <span>โอนเงิน</span>
          </button>

          <button
            onClick={() => setSubTab('RECEIVE')}
            className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-xs font-semibold gap-1.5 transition-all ${
              subTab === 'RECEIVE'
                ? 'bg-slate-800 border-amber-500 text-amber-400'
                : 'bg-slate-900/90 border-slate-800 text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Download className="w-5 h-5 text-emerald-400" />
            <span>รับเงิน</span>
          </button>

          <button
            onClick={() => setSubTab('SPLIT')}
            className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-xs font-semibold gap-1.5 transition-all ${
              subTab === 'SPLIT'
                ? 'bg-slate-800 border-amber-500 text-amber-400'
                : 'bg-slate-900/90 border-slate-800 text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Split className="w-5 h-5 text-blue-400" />
            <span>แบ่งบิล / ขอเงิน</span>
          </button>

          <button
            onClick={() => setSubTab('OFFLINE')}
            className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-xs font-semibold gap-1.5 transition-all col-span-2 sm:col-span-1 ${
              subTab === 'OFFLINE'
                ? 'bg-slate-800 border-amber-500 text-amber-400'
                : 'bg-slate-900/90 border-slate-800 text-slate-200 hover:bg-slate-800'
            }`}
          >
            <WifiOff className="w-5 h-5 text-purple-400" />
            <span>ชำระออฟไลน์</span>
          </button>
        </div>
      </div>

      {/* 2. Sub-Tab Panes */}
      {subTab === 'TRANSFER' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 animate-fade-in">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
              <Send className="w-5 h-5 text-amber-400" />
              <span>โอนเงินบาทดิจิทัลให้บุคคล (P2P Transfer)</span>
            </h3>
            <button
              onClick={() => setSubTab('OVERVIEW')}
              className="text-xs text-slate-400 hover:text-white"
            >
              ปิดหน้าต่าง
            </button>
          </div>

          {transferStatus && (
            <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
              transferStatus.isError 
                ? 'bg-rose-500/10 border border-rose-500/30 text-rose-300' 
                : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
            }`}>
              {transferStatus.isError ? <AlertCircle className="w-4 h-4 shrink-0" /> : <CheckCircle2 className="w-4 h-4 shrink-0" />}
              <span>{transferStatus.msg}</span>
            </div>
          )}

          <form onSubmit={handleExecuteP2p} className="space-y-4 max-w-lg">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">
                ระบุ Wallet ID ผู้รับเงิน:
              </label>
              <input
                type="text"
                value={p2pPayee}
                onChange={(e) => setP2pPayee(e.target.value)}
                placeholder="เช่น DB-WALLET-0000998"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 font-mono focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">
                จำนวนเงิน (บาท):
              </label>
              <input
                type="number"
                step="0.01"
                value={p2pAmount}
                onChange={(e) => setP2pAmount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-lg font-bold text-amber-400 font-mono focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">
                หมายเหตุ:
              </label>
              <input
                type="text"
                value={p2pPurpose}
                onChange={(e) => setP2pPurpose(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition-colors shadow-lg shadow-amber-500/20"
            >
              ยืนยันการโอนเงินบาทดิจิทัล
            </button>
          </form>
        </div>
      )}

      {subTab === 'RECEIVE' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-center space-y-4 animate-fade-in max-w-md mx-auto">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-slate-100 text-base">QR รับเงินบาทดิจิทัลส่วนบุคคล</h3>
            <button onClick={() => setSubTab('OVERVIEW')} className="text-xs text-slate-400">ปิด</button>
          </div>

          <div className="p-4 bg-white rounded-2xl inline-block shadow-xl border-4 border-amber-500/30">
            {/* Synthetic PromptPay QR Graphic */}
            <div className="w-56 h-56 bg-slate-950 p-3 rounded-lg flex flex-col items-center justify-center text-white relative">
              <div className="text-[10px] font-bold text-amber-400 tracking-wider mb-2">PROMPTPAY / DIGITAL BAHT</div>
              <QrCode className="w-36 h-36 text-amber-400" />
              <div className="text-[9px] font-mono text-slate-400 mt-2">{wallet.wallet_id}</div>
            </div>
          </div>

          <div>
            <div className="text-sm font-bold text-white">{wallet.customer_name}</div>
            <div className="text-xs text-slate-400 font-mono mt-0.5">{wallet.wallet_id}</div>
          </div>
          <p className="text-xs text-slate-400">
            ผู้โอนสามารถสแกน QR นี้เพื่อโอนเงินบาทดิจิทัลเข้ากระเป๋าของคุณทันทีแบบ Settlement 24/7
          </p>
        </div>
      )}

      {subTab === 'SPLIT' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 animate-fade-in max-w-lg">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
              <Split className="w-5 h-5 text-blue-400" />
              <span>แบ่งบิลค่าใช้จ่าย (Split Bill)</span>
            </h3>
            <button onClick={() => setSubTab('OVERVIEW')} className="text-xs text-slate-400">ปิด</button>
          </div>

          {splitResult && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{splitResult}</span>
            </div>
          )}

          <div className="space-y-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">ยอดรวมของบิล (บาท):</label>
              <input
                type="number"
                value={splitAmount}
                onChange={(e) => setSplitAmount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-lg font-mono font-bold text-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">จำนวนคนรวมคุณด้วย:</label>
              <input
                type="number"
                value={splitPeopleCount}
                onChange={(e) => setSplitPeopleCount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100"
              />
            </div>

            <button
              onClick={handleCalculateSplit}
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors"
            >
              คำนวณและสร้าง Payment Request
            </button>
          </div>
        </div>
      )}

      {subTab === 'OFFLINE' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 animate-fade-in max-w-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
              <WifiOff className="w-5 h-5 text-purple-400" />
              <span>ห้องทดสอบการชำระเงินออฟไลน์ (Offline Payment Lab)</span>
            </h3>
            <button onClick={() => setSubTab('OVERVIEW')} className="text-xs text-slate-400">ปิด</button>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            จำลองสถานการณ์ชำระเงินเมื่อสมาร์ตโฟนไม่มีสัญญาณอินเทอร์เน็ต ผ่าน Secure Element Token และ Nonce Sequence ยืนยันบนอุปกรณ์
          </p>

          {offlineStatusMsg && (
            <div className="p-3 bg-purple-500/10 border border-purple-500/30 text-purple-300 rounded-xl text-xs font-mono">
              {offlineStatusMsg}
            </div>
          )}

          <div className="grid grid-cols-2 gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div>
              <div className="text-[11px] text-slate-400">Device ID / KeyStore:</div>
              <div className="text-xs font-mono text-slate-200 mt-0.5">{wallet.device_id}</div>
            </div>
            <div>
              <div className="text-[11px] text-slate-400">Offline Nonce Sequence:</div>
              <div className="text-xs font-mono text-purple-400 font-bold mt-0.5">#{offlineNonce}</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="number"
              value={offlineAmount}
              onChange={(e) => setOfflineAmount(e.target.value)}
              className="w-32 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm font-mono text-amber-400 font-bold"
            />
            <button
              onClick={() => handleOfflinePayment(false)}
              className="py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition-colors"
            >
              ส่ง Offline Token ปรกติ
            </button>
            <button
              onClick={() => handleOfflinePayment(true)}
              className="py-2.5 px-4 rounded-xl bg-rose-600/30 hover:bg-rose-600/50 border border-rose-500/50 text-rose-200 font-bold text-xs transition-colors"
              title="ทดสอบใช้ Nonce เดิมเพื่อลอง Double Spend"
            >
              ทดสอบ Double-Spend
            </button>
          </div>
        </div>
      )}

      {/* 3. Transaction History List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-slate-100 text-base">ประวัติรายการเงินบาทดิจิทัลล่าสุด</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            ทั้งหมด {payments.length} รายการ
          </span>
        </div>

        <div className="divide-y divide-slate-800/60">
          {payments.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-xs">ยังไม่มีประวัติธุรกรรม</div>
          ) : (
            payments.map((p) => {
              const isPayer = p.payer_wallet === 'DB-WALLET-0000421';
              return (
                <div
                  key={p.payment_id}
                  onClick={() => onSelectPaymentForReceipt(p)}
                  className="py-3.5 flex items-center justify-between gap-4 hover:bg-slate-800/40 px-2 rounded-xl cursor-pointer transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isPayer ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}>
                      {isPayer ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownLeft className="w-5 h-5" />}
                    </div>

                    <div>
                      <div className="text-sm font-semibold text-slate-200 group-hover:text-amber-300 transition-colors">
                        {isPayer ? p.payee_name || p.payee_wallet : p.payer_name || p.payer_wallet}
                      </div>
                      <div className="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <span>{p.purpose}</span>
                        <span>·</span>
                        <span className="font-mono text-[11px]">{new Date(p.created_at).toLocaleTimeString('th-TH')}</span>
                        {p.is_offline && <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300">OFFLINE</span>}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className={`text-base font-bold font-mono ${isPayer ? 'text-slate-200' : 'text-emerald-400'}`}>
                      {isPayer ? `-฿${p.amount}` : `+฿${p.amount}`}
                    </div>
                    <div className="text-[10px] font-mono text-emerald-400 flex items-center justify-end gap-1 mt-0.5">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>{p.status}</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
