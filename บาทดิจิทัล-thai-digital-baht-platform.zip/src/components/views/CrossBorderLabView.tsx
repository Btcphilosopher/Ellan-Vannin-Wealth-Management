/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * CrossBorderLabView.tsx
 * mBridge-Style Cross-Border CBDC Settlement Simulation Corridor
 */

import React, { useState } from 'react';
import { Globe2, ArrowRight, CheckCircle2, ShieldCheck, RefreshCw } from 'lucide-react';
import { digitalBahtStore } from '../../services/store';

export const CrossBorderLabView: React.FC = () => {
  const [targetCurrency, setTargetCurrency] = useState<'HKD' | 'SGD' | 'CNY' | 'AED'>('HKD');
  const [amountThb, setAmountThb] = useState('10000.00');
  const [lastTxResult, setLastTxResult] = useState<{
    corridor_id: string;
    source_currency: string;
    target_currency: string;
    fx_rate: string;
    tx_hash: string;
    estimated_time_ms: number;
  } | null>(null);

  const rateMap = { HKD: 0.22, SGD: 0.039, CNY: 0.20, AED: 0.10 };

  const handleExecuteCrossBorder = (e: React.FormEvent) => {
    e.preventDefault();
    const result = digitalBahtStore.executeCrossBorderSettlement(targetCurrency, amountThb);
    setLastTxResult(result);
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-blue-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-semibold flex items-center gap-1">
                <Globe2 className="w-3.5 h-3.5" />
                <span>MULTILATERAL CROSS-BORDER CBDC (mBridge Abstraction)</span>
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              ระบบชำระเงินข้ามพรมแดนทันทีด้วย Retail/Wholesale CBDC
            </h2>

            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              จำลองระเบียงชำระเงินระหว่างประเทศ (Cross-Border Corridor) ระหว่างเงินบาทดิจิทัล (THB) และธนาคารกลางพันธมิตร (HKD, SGD, CNY, AED) แบบ Atomic Delivery-versus-Payment
            </p>
          </div>
        </div>
      </div>

      {/* Main Interactive Form */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="font-bold text-slate-100 text-base">การโอนเงินบาทดิจิทัลระหว่างประเทศ</h3>

          <form onSubmit={handleExecuteCrossBorder} className="space-y-4">
            <div>
              <label className="block text-xs text-slate-400 mb-1">เลือกสกุลเงินปลายทาง:</label>
              <div className="grid grid-cols-4 gap-2">
                {(['HKD', 'SGD', 'CNY', 'AED'] as const).map((curr) => (
                  <button
                    key={curr}
                    type="button"
                    onClick={() => setTargetCurrency(curr)}
                    className={`p-2.5 rounded-xl border text-center font-bold text-xs font-mono transition-all ${
                      targetCurrency === curr
                        ? 'bg-blue-600 border-blue-400 text-white shadow-md'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {curr}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">จำนวนเงินบาทดิจิทัลต้นทาง (THB):</label>
              <input
                type="number"
                value={amountThb}
                onChange={(e) => setAmountThb(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xl font-bold font-mono text-amber-400"
              />
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1">
              <div className="flex justify-between text-slate-400">
                <span>อัตราแลกเปลี่ยนจำลอง (Synthetic FX):</span>
                <span className="font-mono text-amber-300 font-bold">1 THB = {rateMap[targetCurrency]} {targetCurrency}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>ยอดเงินปลายทางโดยประมาณ:</span>
                <span className="font-mono text-emerald-400 font-bold">
                  {(parseFloat(amountThb) * rateMap[targetCurrency]).toFixed(2)} {targetCurrency}
                </span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors shadow-lg shadow-blue-600/20"
            >
              ดำเนินการโอนข้ามพรมแดนแบบ Atomic DvP
            </button>
          </form>
        </div>

        {/* Transaction Proof Result */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="font-bold text-slate-100 text-base">ใบยืนยันการชำระเงินข้ามพรมแดน mBridge</h3>

          {lastTxResult ? (
            <div className="p-4 bg-slate-950 rounded-2xl border border-emerald-500/40 space-y-3 animate-fade-in text-xs">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5" />
                <span>mBridge Atomic Settlement Complete</span>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="flex justify-between">
                  <span className="text-slate-400">Corridor ID:</span>
                  <span className="font-mono text-amber-300">{lastTxResult.corridor_id}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-400">FX Rate:</span>
                  <span className="font-mono text-slate-200">1 THB = {lastTxResult.fx_rate} {lastTxResult.target_currency}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-400">Settlement Time:</span>
                  <span className="font-mono text-emerald-400 font-bold">{lastTxResult.estimated_time_ms} ms</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-400">Ledger Hash:</span>
                  <span className="font-mono text-[10px] text-slate-400 truncate max-w-[200px]">{lastTxResult.tx_hash}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500 text-xs border-2 border-dashed border-slate-800 rounded-2xl">
              ระบุสกุลเงินและกดยืนยันเพื่อจำลองธุรกรรมข้ามพรมแดน
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
