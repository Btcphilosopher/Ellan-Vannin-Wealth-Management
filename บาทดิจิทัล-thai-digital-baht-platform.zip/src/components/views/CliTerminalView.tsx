/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * CliTerminalView.tsx
 * Interactive Thai Web Terminal for `digital-baht` CLI
 */

import React, { useState, useRef, useEffect } from 'react';
import { Terminal as TerminalIcon, CornerDownLeft, Play } from 'lucide-react';
import { digitalBahtStore } from '../../services/store';

export const CliTerminalView: React.FC = () => {
  const [history, setHistory] = useState<Array<{ cmd: string; output: string[] }>>([
    {
      cmd: 'digital-baht --help',
      output: [
        'บาทดิจิทัล (DIGITAL BAHT CLI v2.4.0) — เครื่องมือบรรทัดคำสั่งระบบจำลอง Retail CBDC',
        'คำสั่งที่รองรับ:',
        '  digital-baht wallet                - แสดงข้อมูลกระเป๋าเงินบาทดิจิทัล',
        '  digital-baht payment               - แสดงประวัติและสร้างธุรกรรมชำระเงิน',
        '  digital-baht merchant              - ตรวจสอบยอดและข้อมูลร้านค้า',
        '  digital-baht qr                    - สร้างคิวอาร์โค้ดรับชำระเงิน',
        '  digital-baht ledger                - ตรวจสอบบัญชีแยกประเภทคู่ (Double-Entry)',
        '  digital-baht settlement            - จำลองการชำระบัญชีทันที',
        '  digital-baht cbdc                  - ตรวจสอบยอดออกเงินบาทดิจิทัล (CBDC Liability)',
        '  digital-baht programmable          - ตรวจสอบและรันเงื่อนไข Programmable Rules',
        '  digital-baht escrow                - ตรวจสอบและปล่อยเงินสัญญา Escrow',
        '  digital-baht fraud                 - ตรวจสอบระบบเฝ้าระวัง AML & Fraud Alert',
        '  digital-baht stress                - ทดสอบความคงทนโหลดสูง (Stress Lab)',
        '  digital-baht reconcile             - กระทบยอดบัญชีแยกประเภทคู่',
        '  digital-baht simulate --seed 42    - จำลองผู้ใช้ 1,000,000 และ 10,000,000 รายการ',
        'พิมพ์คำสั่งที่ต้องการแล้วกด Enter'
      ]
    }
  ]);

  const [inputCmd, setInputCmd] = useState('digital-baht wallet');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const executeCommand = (cmdStr: string) => {
    const trimmed = cmdStr.trim();
    if (!trimmed) return;

    let outputLines: string[] = [];

    if (trimmed === 'clear') {
      setHistory([]);
      setInputCmd('');
      return;
    }

    if (trimmed === 'digital-baht wallet') {
      const w = digitalBahtStore.wallets.get('DB-WALLET-0000421');
      outputLines = [
        '=== ข้อมูลกระเป๋าเงินบาทดิจิทัล (DIGITAL BAHT WALLET) ===',
        `Wallet ID:       ${w?.wallet_id}`,
        `เจ้าของ:         ${w?.customer_name}`,
        `ผู้ให้บริการ:    ${w?.provider_name}`,
        `ยอดคงเหลือรวม:   ฿${w?.balance} THB`,
        `ยอดเงินใช้ได้:   ฿${w?.available_balance} THB`,
        `ยอดเงินกันไว้:   ฿${w?.reserved_balance} THB`,
        `สถานะ KYC:       ${w?.kyc_status} (ยืนยันตัวตนเรียบร้อย)`
      ];
    } else if (trimmed === 'digital-baht ledger') {
      const accs = Array.from(digitalBahtStore.ledgerAccounts.values());
      outputLines = [
        '=== บัญชีแยกประเภทคู่ (DOUBLE-ENTRY LEDGER ACCOUNTS) ===',
        ...accs.map(a => `[${a.account_id}] ${a.account_name} : ฿${a.balance} THB`)
      ];
    } else if (trimmed === 'digital-baht merchant') {
      const m = digitalBahtStore.merchants.get('DB-MERCHANT-042');
      outputLines = [
        '=== ข้อมูลร้านค้ารองรับบาทดิจิทัล ===',
        `Merchant ID:     ${m?.merchant_id}`,
        `ชื่อร้านค้า:     ${m?.merchant_name}`,
        `ยอดขายวันนี้:   ฿${m?.daily_sales} THB`,
        `จำนวนธุรกรรม:   ${m?.transaction_count} รายการ`,
        `ยอดเฉลี่ยต่อบิล: ฿${m?.average_ticket} THB`
      ];
    } else if (trimmed === 'digital-baht cbdc') {
      outputLines = [
        '=== สถานะเงินบาทดิจิทัลของประเทศ (CENTRAL BANK CBDC STATUS) ===',
        `ปริมาณเงินหมุนเวียนคงค้าง: ฿${digitalBahtStore.metrics.cbdc_outstanding} THB`,
        `อัตราส่วนทุนสำรอง:          100.00% (Central Bank Reserve Backing)`,
        `สถานะระบบชำระบัญชี:         พร้อมใช้งาน 24/7 (Settlement Latency 180ms)`
      ];
    } else if (trimmed === 'digital-baht escrow') {
      const e = digitalBahtStore.rules.filter(r => r.rule_type === 'ESCROW');
      outputLines = [
        '=== สัญญาพักเงินตามเงื่อนไข (PROGRAMMABLE ESCROW) ===',
        ...e.map(r => `[${r.rule_id}] ${r.title} | ฿${r.amount} THB | สถานะ: ${r.status}`)
      ];
    } else if (trimmed.includes('simulate')) {
      outputLines = [
        '=== ดำเนินการจำลองสเกลใหญ่ (LARGE SCALE CBDC SIMULATION) ===',
        'จำลอง Seed 42:',
        '  - ประชาชนจำลอง: 1,000,000 คน',
        '  - ร้านค้าจำลอง:  100,000 ร้าน',
        '  - กระเป๋าเงิน:  1,200,000 กระเป๋า',
        '  - ธุรกรรมชำระเงิน: 10,000,000 รายการ',
        '  - เงินบาทดิจิทัลจำลอง: ฿50,000,000,000.00 THB',
        'ผลการ Reconcile: บัญชีแยกประเภทคู่สมดุล 100.00%'
      ];
    } else {
      outputLines = [
        `คำสั่ง '${trimmed}' ไม่พบในระบบ. พิมพ์ 'digital-baht --help' เพื่อดูคำสั่งทั้งหมด`
      ];
    }

    setHistory(prev => [...prev, { cmd: trimmed, output: outputLines }]);
    setInputCmd('');
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executeCommand(inputCmd);
  };

  return (
    <div className="space-y-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <TerminalIcon className="w-5 h-5 text-amber-400" />
          <h3 className="font-bold text-slate-100 text-sm">DIGITAL BAHT INTERACTIVE WEB CLI</h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => executeCommand('digital-baht wallet')}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-mono text-amber-300"
          >
            wallet
          </button>
          <button
            onClick={() => executeCommand('digital-baht ledger')}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-mono text-emerald-300"
          >
            ledger
          </button>
          <button
            onClick={() => executeCommand('digital-baht simulate --seed 42')}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-mono text-purple-300"
          >
            simulate
          </button>
        </div>
      </div>

      <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 font-mono text-xs text-slate-200 shadow-2xl h-[500px] flex flex-col justify-between">
        {/* Terminal Output */}
        <div className="overflow-y-auto space-y-4 pr-2 flex-1">
          {history.map((item, idx) => (
            <div key={idx} className="space-y-1">
              <div className="flex items-center gap-2 text-amber-400">
                <span>user@digital-baht-core:~$</span>
                <span className="text-white font-bold">{item.cmd}</span>
              </div>
              <div className="pl-4 space-y-0.5 text-slate-300 text-[11px] leading-relaxed">
                {item.output.map((line, lIdx) => (
                  <div key={lIdx}>{line}</div>
                ))}
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Input Bar */}
        <form onSubmit={handleFormSubmit} className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-2">
          <span className="text-amber-400 font-bold shrink-0">user@digital-baht-core:~$</span>
          <input
            type="text"
            value={inputCmd}
            onChange={(e) => setInputCmd(e.target.value)}
            placeholder="พิมพ์คำสั่ง CLI เช่น digital-baht wallet..."
            className="w-full bg-transparent border-none text-white text-xs font-mono focus:outline-none focus:ring-0"
          />
          <button type="submit" className="p-1 text-slate-400 hover:text-amber-400">
            <CornerDownLeft className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
