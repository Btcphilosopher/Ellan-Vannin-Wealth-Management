/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ProgrammableEngineView.tsx
 * Programmable Payment Engine, Escrow, Purpose-Bound Funds & Tokenized Asset Lab
 */

import React, { useState, useEffect } from 'react';
import { 
  Cpu, 
  Lock, 
  Unlock, 
  CheckCircle2, 
  ShieldCheck, 
  Building, 
  Layers, 
  ArrowRight,
  Sparkles,
  FileText
} from 'lucide-react';
import { digitalBahtStore } from '../../services/store';
import { ProgrammablePaymentRule, GovernmentProgram, TokenizedAsset } from '../../types';

export const ProgrammableEngineView: React.FC = () => {
  const [rules, setRules] = useState<ProgrammablePaymentRule[]>(digitalBahtStore.rules);
  const [programs, setPrograms] = useState<GovernmentProgram[]>(digitalBahtStore.programs);
  const [assets, setAssets] = useState<TokenizedAsset[]>(digitalBahtStore.assets);

  const [activeTab, setActiveTab] = useState<'ESCROW' | 'PURPOSE' | 'GOV' | 'ASSETS'>('ESCROW');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    const unsub = digitalBahtStore.subscribe(() => {
      setRules([...digitalBahtStore.rules]);
      setPrograms([...digitalBahtStore.programs]);
      setAssets([...digitalBahtStore.assets]);
    });
    return unsub;
  }, []);

  const handleReleaseEscrow = (ruleId: string) => {
    setStatusMsg(null);
    const res = digitalBahtStore.releaseEscrow(ruleId);
    if (res.success) {
      setStatusMsg(`เงื่อนไขสัญญาสำเร็จ: ปล่อยเงินออกจาก Escrow ให้กับผู้ขายเรียบร้อยแล้ว!`);
    } else {
      setStatusMsg(`ข้อผิดพลาด: ${res.error}`);
    }
  };

  const handleSimulateAssetPurchase = (asset: TokenizedAsset) => {
    const res = digitalBahtStore.processPayment(
      'DB-WALLET-0000421',
      'DB-MERCHANT-042',
      asset.unit_price_cbdc,
      `ซื้อ ${asset.asset_name} แบบ Atomic Delivery-versus-Payment`
    );

    if (res.success) {
      setStatusMsg(`ชำระเงินบาทดิจิทัล ฿${asset.unit_price_cbdc} เพื่อซื้อ ${asset.asset_name} สำเร็จ! โอนกรรมสิทธิ์ทันที`);
    } else {
      setStatusMsg(`การชำระเงินล้มเหลว: ${res.error?.message_th}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Top Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-semibold flex items-center gap-1">
                <Cpu className="w-3.5 h-3.5" />
                <span>PROGRAMMABLE PAYMENT & ENHANCED SANDBOX LAB</span>
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              ระบบการชำระเงินแบบกำหนดเงื่อนไขโปรแกรมได้
            </h2>

            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              สอดคล้องกับแนวคิดการศึกษาสมรรถนะด้าน Programmability ของธนาคารแห่งประเทศไทย สำหรับกรณี Escrow สัญญาพักเงิน, Purpose-Bound Funds และการชำระบัญชีเชื่อมต่อ Tokenized Assets
            </p>
          </div>

          {/* Tab Selector */}
          <div className="flex flex-wrap gap-1 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 shrink-0">
            <button
              onClick={() => setActiveTab('ESCROW')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'ESCROW' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Escrow Protection
            </button>
            <button
              onClick={() => setActiveTab('PURPOSE')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'PURPOSE' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Purpose-Bound
            </button>
            <button
              onClick={() => setActiveTab('GOV')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'GOV' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Government Programs
            </button>
            <button
              onClick={() => setActiveTab('ASSETS')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'ASSETS' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Tokenized Assets
            </button>
          </div>
        </div>
      </div>

      {statusMsg && (
        <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 rounded-2xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{statusMsg}</span>
        </div>
      )}

      {/* TAB 1: ESCROW */}
      {activeTab === 'ESCROW' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-100 text-base">รายการสัญญาพักเงินตามเงื่อนไข (Conditional Escrow Contracts)</h3>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {rules.filter(r => r.rule_type === 'ESCROW').map(rule => (
              <div key={rule.rule_id} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white">{rule.title}</span>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                        rule.status === 'HELD' ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'
                      }`}>
                        {rule.status === 'HELD' ? 'เงินถูกกันไว้ (HELD IN ESCROW)' : 'ปล่อยเงินแล้ว (EXECUTED)'}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 font-mono mt-0.5">{rule.rule_id}</div>
                  </div>

                  <div className="text-right">
                    <div className="text-2xl font-bold font-mono text-amber-400">฿{rule.amount}</div>
                    <div className="text-xs text-slate-400">{rule.purpose}</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs">
                  <div>
                    <div className="text-slate-400">ผู้ซื้อ (Payer): <span className="text-slate-200 font-semibold">{rule.payer_wallet}</span></div>
                    <div className="text-slate-400 mt-1">ผู้ขาย (Payee): <span className="text-slate-200 font-semibold">{rule.payee_wallet}</span></div>
                  </div>

                  <div>
                    <div className="text-slate-400">เงื่อนไขการปล่อยเงิน: <span className="text-amber-300 font-medium">ยืนยันการได้รับสินค้าแล้ว</span></div>
                    <div className="text-slate-400 mt-1">สถานะส่งมอบ: <span className={rule.conditions.delivery_confirmed ? 'text-emerald-400 font-semibold' : 'text-amber-400'}>
                      {rule.conditions.delivery_confirmed ? 'ยืนยันแล้ว' : 'รอยืนยันการส่งมอบ'}
                    </span></div>
                  </div>
                </div>

                {rule.status === 'HELD' && (
                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() => handleReleaseEscrow(rule.rule_id)}
                      className="py-2.5 px-5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all"
                    >
                      <Unlock className="w-4 h-4" />
                      <span>ยืนยันการรับสินค้าและปล่อยเงิน ฿{rule.amount}</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: PURPOSE-BOUND */}
      {activeTab === 'PURPOSE' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="font-bold text-slate-100 text-base">การกำหนดวัตถุประสงค์การใช้เงิน (Purpose-Bound Digital Money)</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            จำลองเงินบาทดิจิทัลที่ลงรหัสล็อกเงื่อนไข เช่น งบอาหารกลางวัน ซึ่งผู้ถือเงินสามารถใช้ชำระได้เฉพาะกับร้านค้าในหมวดหมู่ "อาหารและเครื่องดื่ม" เท่านั้น
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {rules.filter(r => r.rule_type === 'PURPOSE_BOUND').map(rule => (
              <div key={rule.rule_id} className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-slate-200 text-sm">{rule.title}</h4>
                    <span className="text-[10px] font-mono text-indigo-400">{rule.rule_id}</span>
                  </div>
                  <span className="text-xl font-bold font-mono text-amber-400">฿{rule.amount}</span>
                </div>

                <div className="p-3 bg-slate-900 rounded-lg text-xs space-y-1">
                  <div className="text-slate-400">หมวดหมู่ร้านค้าที่ใช้ได้: <span className="text-emerald-400 font-semibold">{rule.conditions.merchant_category}</span></div>
                  <div className="text-slate-400">วันหมดอายุ: <span className="text-slate-200">{rule.conditions.expiry_date}</span></div>
                </div>

                <div className="text-[11px] text-slate-400">
                  ระบบ Smart Rule Engine จะปฏิเสธการชำระเงินอัตโนมัติทันที หากพยายามนำไปใช้กับร้านค้านอกหมวดหมู่ที่กำหนด
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: GOVERNMENT PROGRAMS */}
      {activeTab === 'GOV' && (
        <div className="space-y-4">
          <h3 className="font-bold text-slate-100 text-base">โครงการโอนเงินภาครัฐจำลอง (DEMO Government Welfare Programs)</h3>

          <div className="grid grid-cols-1 gap-4">
            {programs.map(prog => (
              <div key={prog.program_id} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div>
                    <h4 className="text-base font-bold text-amber-400">{prog.title_th}</h4>
                    <p className="text-xs text-slate-400">{prog.description_th}</p>
                  </div>
                  <span className="text-xs font-mono bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-3 py-1 rounded-full shrink-0">
                    {prog.program_id}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs">
                  <div>
                    <div className="text-slate-400">งบประมาณจัดสรร:</div>
                    <div className="text-base font-bold font-mono text-white mt-0.5">฿{(parseFloat(prog.budget_allocated) / 1000000000).toFixed(2)} พันล้าน</div>
                  </div>
                  <div>
                    <div className="text-slate-400">จัดสรรแล้ว:</div>
                    <div className="text-base font-bold font-mono text-emerald-400 mt-0.5">฿{(parseFloat(prog.budget_distributed) / 1000000000).toFixed(2)} พันล้าน</div>
                  </div>
                  <div>
                    <div className="text-slate-400">ผู้ได้รับสิทธิ์:</div>
                    <div className="text-base font-bold font-mono text-slate-200 mt-0.5">{prog.eligible_citizens_count.toLocaleString()} คน</div>
                  </div>
                  <div>
                    <div className="text-slate-400">ระยะเวลา:</div>
                    <div className="text-xs font-mono text-slate-300 mt-1">{prog.start_date} ถึง {prog.end_date}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: TOKENIZED ASSETS */}
      {activeTab === 'ASSETS' && (
        <div className="space-y-4">
          <h3 className="font-bold text-slate-100 text-base">การชำระเงินบาทดิจิทัลซื้อขายสินทรัพย์ดิจิทัล (Tokenized Asset Settlement)</h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {assets.map(asset => (
              <div key={asset.asset_id} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 flex flex-col justify-between">
                <div className="space-y-2">
                  <span className="text-[10px] font-mono bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded">
                    {asset.asset_type}
                  </span>
                  <h4 className="font-bold text-slate-100 text-sm">{asset.asset_name}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">{asset.description_th}</p>
                </div>

                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">ราคาต่อหน่วย:</span>
                    <span className="text-amber-400 font-bold">฿{asset.unit_price_cbdc}</span>
                  </div>

                  <button
                    onClick={() => handleSimulateAssetPurchase(asset)}
                    className="w-full py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition-colors shadow-md shadow-indigo-600/20"
                  >
                    ซื้อสินทรัพย์แบบ Atomic DvP
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
