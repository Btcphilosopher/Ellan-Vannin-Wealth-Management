/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ApiGatewayDocsView.tsx
 * OpenAPI 3.1 Documentation & Interactive API Gateway Console
 */

import React, { useState } from 'react';
import { FileCode2, Play, CheckCircle2, ShieldCheck, Copy, Check } from 'lucide-react';
import { digitalBahtStore } from '../../services/store';

export const ApiGatewayDocsView: React.FC = () => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('POST /api/v1/payments');
  const [requestBody, setRequestBody] = useState<string>(
    JSON.stringify(
      {
        payer_wallet: 'DB-WALLET-0000421',
        payee_wallet: 'DB-MERCHANT-042',
        amount: '185.00',
        currency: 'THB',
        purpose: 'อาหารเช้าแซนวิชแฮมชีส'
      },
      null,
      2
    )
  );
  const [responseResult, setResponseResult] = useState<string | null>(null);

  const endpoints = [
    {
      method: 'POST',
      path: '/api/v1/payments',
      title: 'สร้างและชำระเงินบาทดิจิทัล (Process Payment)',
      desc: 'โอนเงินบาทดิจิทัลระหว่างกระเป๋าเงินพร้อมบันทึกบัญชีแยกประเภทคู่ (Double-Entry Ledger) และ Settlement ทันที',
      sampleReq: {
        payer_wallet: 'DB-WALLET-0000421',
        payee_wallet: 'DB-MERCHANT-042',
        amount: '185.00',
        currency: 'THB',
        purpose: 'อาหารเช้าแซนวิชแฮมชีส'
      }
    },
    {
      method: 'GET',
      path: '/api/v1/wallets/DB-WALLET-0000421',
      title: 'เรียกดูข้อมูลกระเป๋าเงินบาทดิจิทัล (Get Wallet Balance)',
      desc: 'ตรวจสอบยอดเงินคงเหลือ ยอดที่ใช้ได้ ยอดที่กันไว้ และสถานะ KYC ของกระเป๋าเงิน',
      sampleReq: null
    },
    {
      method: 'POST',
      path: '/api/v1/programmable-payments',
      title: 'สร้างเงื่อนไขชำระเงินโปรแกรมได้ (Create Programmable Payment)',
      desc: 'สร้างสัญญา Escrow หรือกำหนดวัตถุประสงค์การใช้เงินแบบ Purpose-Bound',
      sampleReq: {
        title: 'สัญญาซื้อขายอุปกรณ์ไอที',
        rule_type: 'ESCROW',
        payer_wallet: 'DB-WALLET-0000421',
        payee_wallet: 'DB-MERCHANT-042',
        amount: '10000.00',
        currency: 'THB',
        purpose: 'ซื้อเครื่องชงกาแฟ'
      }
    },
    {
      method: 'GET',
      path: '/api/v1/ledger/accounts',
      title: 'ตรวจสอบผังบัญชีแยกประเภทคู่ (Get Ledger Accounts)',
      desc: 'เรียกดูสมดุลบัญชีภาระผูกพันเงินบาทดิจิทัลของธนาคารกลาง',
      sampleReq: null
    }
  ];

  const handleSelectEndpoint = (ep: typeof endpoints[0]) => {
    setSelectedEndpoint(`${ep.method} ${ep.path}`);
    if (ep.sampleReq) {
      setRequestBody(JSON.stringify(ep.sampleReq, null, 2));
    } else {
      setRequestBody('');
    }
    setResponseResult(null);
  };

  const handleExecuteApiCall = () => {
    if (selectedEndpoint.includes('POST /api/v1/payments')) {
      try {
        const parsed = JSON.parse(requestBody);
        const res = digitalBahtStore.processPayment(
          parsed.payer_wallet,
          parsed.payee_wallet,
          parsed.amount,
          parsed.purpose,
          `API-KEY-${Date.now()}`
        );
        if (res.success && res.payment) {
          setResponseResult(
            JSON.stringify(
              {
                payment_id: res.payment.payment_id,
                status: res.payment.status,
                amount: res.payment.amount,
                currency: res.payment.currency,
                payer_wallet: res.payment.payer_wallet,
                payee_wallet: res.payment.payee_wallet,
                settled_at: res.payment.settled_at
              },
              null,
              2
            )
          );
        } else {
          setResponseResult(JSON.stringify(res.error, null, 2));
        }
      } catch (err) {
        setResponseResult(JSON.stringify({ error: 'JSON Payload ไม่ถูกต้อง' }));
      }
    } else if (selectedEndpoint.includes('GET /api/v1/wallets')) {
      const w = digitalBahtStore.wallets.get('DB-WALLET-0000421');
      setResponseResult(JSON.stringify(w, null, 2));
    } else if (selectedEndpoint.includes('GET /api/v1/ledger')) {
      const accs = Array.from(digitalBahtStore.ledgerAccounts.values());
      setResponseResult(JSON.stringify(accs, null, 2));
    } else {
      setResponseResult(
        JSON.stringify(
          {
            status: '200 OK',
            message_th: 'API Call จำลองสำเร็จ'
          },
          null,
          2
        )
      );
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-1">
              <FileCode2 className="w-3.5 h-3.5" />
              <span>OPENAPI 3.1 SPECIFICATION & GATEWAY</span>
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            เอกสาร API และระบบทดสอบเชื่อมต่อ REST Gateway
          </h2>

          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            รองรับ Idempotency-Key Header, Decimal String Amounts และ ISO 20022 Data Mapping สำหรับสถาบันการเงินและผู้ให้บริการทางการเงิน
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Endpoint List */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <h3 className="font-bold text-slate-100 text-sm border-b border-slate-800 pb-2">
            รายการ REST API Endpoints
          </h3>

          <div className="space-y-2">
            {endpoints.map((ep) => {
              const fullKey = `${ep.method} ${ep.path}`;
              const isSelected = selectedEndpoint === fullKey;
              return (
                <button
                  key={fullKey}
                  onClick={() => handleSelectEndpoint(ep)}
                  className={`w-full text-left p-3 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-slate-800 border-amber-500/60 shadow-md'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      ep.method === 'POST' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-blue-500/20 text-blue-400'
                    }`}>
                      {ep.method}
                    </span>
                    <span className="text-xs font-mono font-semibold text-slate-200">{ep.path}</span>
                  </div>
                  <div className="text-xs font-semibold text-slate-300 mt-1.5">{ep.title}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">{ep.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Interactive Console */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-slate-100 text-base font-mono text-amber-400">
              {selectedEndpoint}
            </h3>
            <button
              onClick={handleExecuteApiCall}
              className="py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors shadow-lg shadow-amber-500/20"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>ทดสอบส่ง Request</span>
            </button>
          </div>

          {requestBody && (
            <div className="space-y-1">
              <label className="block text-xs font-mono text-slate-400">Request Body (JSON Payload):</label>
              <textarea
                rows={6}
                value={requestBody}
                onChange={(e) => setRequestBody(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-xs text-slate-200 focus:outline-none focus:border-amber-500"
              />
            </div>
          )}

          <div className="space-y-1">
            <label className="block text-xs font-mono text-slate-400">Response Output (HTTP 200 OK):</label>
            <div className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-emerald-400 min-h-[160px] overflow-x-auto whitespace-pre">
              {responseResult ? responseResult : '// กดยืนยันปุ่ม "ทดสอบส่ง Request" เพื่อดู Response สดจากระบบ'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
