/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ReceiptModal.tsx
 * Thai Digital Baht E-Receipt Component
 */

import React from 'react';
import { CheckCircle2, Download, Share2, X, ShieldCheck } from 'lucide-react';
import { DigitalBahtPayment } from '../../types';

interface ReceiptModalProps {
  payment: DigitalBahtPayment | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ payment, onClose }) => {
  if (!payment) return null;

  // Format date to Thai BE calendar e.g., 29 กันยายน 2569
  const formatThaiDate = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const day = date.getDate();
      const monthNames = [
        'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
        'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
      ];
      const month = monthNames[date.getMonth()];
      const yearBE = date.getFullYear() + 543; // Thai Buddhist Era
      const hours = date.getHours().toString().padStart(2, '0');
      const minutes = date.getMinutes().toString().padStart(2, '0');
      const seconds = date.getSeconds().toString().padStart(2, '0');

      return `${day} ${month} พ.ศ. ${yearBE} เวลา ${hours}:${minutes}:${seconds} น.`;
    } catch {
      return isoString;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl text-slate-100 relative">
        {/* Header background decoration */}
        <div className="bg-gradient-to-b from-emerald-600/20 via-slate-900 to-slate-900 p-6 text-center border-b border-slate-800/80 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-full bg-slate-800/80 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-emerald-500/10">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <h3 className="text-lg font-bold text-white">ชำระเงินสำเร็จ</h3>
          <p className="text-xs text-emerald-400 font-medium">Digital Baht Settlement Complete</p>
          <div className="mt-1 inline-flex items-center gap-1 text-[11px] text-slate-400 bg-slate-950/60 px-2.5 py-0.5 rounded-full border border-slate-800">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>ใบเสร็จดิจิทัลอย่างเป็นทางการ (Synthetic)</span>
          </div>
        </div>

        {/* Receipt Body */}
        <div className="p-6 space-y-5 bg-slate-900">
          <div className="text-center pb-4 border-b border-dashed border-slate-800">
            <div className="text-xs text-slate-400">จำนวนเงินชำระ (Amount):</div>
            <div className="text-3xl font-extrabold font-mono text-amber-400 tracking-tight mt-1">
              ฿{payment.amount}
            </div>
            <div className="text-xs text-slate-400 mt-1 font-medium">
              1 THB CBDC = 1 THB (ไม่มีค่าธรรมเนียม)
            </div>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">ผู้รับเงิน (Payee):</span>
              <span className="font-semibold text-slate-200 text-right">{payment.payee_name || payment.payee_wallet}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">ผู้ชำระเงิน (Payer):</span>
              <span className="font-semibold text-slate-200 text-right">{payment.payer_name || payment.payer_wallet}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">วัตถุประสงค์ (Purpose):</span>
              <span className="font-medium text-slate-300 text-right">{payment.purpose}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">วันที่-เวลา (Date & Time):</span>
              <span className="font-mono text-slate-300 text-right">{formatThaiDate(payment.settled_at || payment.created_at)}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">เลขที่รายการ (Transaction ID):</span>
              <span className="font-mono text-amber-300/90 text-right text-[11px]">{payment.payment_id}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">สถานะ (Status):</span>
              <span className="font-semibold text-emerald-400 text-right">SETTLED (สำเร็จ)</span>
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 text-center leading-relaxed">
            <p>บันทึกในบัญชีแยกประเภทคู่ (Double-Entry Ledger) ของระบบจำลองเงินบาทดิจิทัล</p>
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => alert('ดาวน์โหลดใบเสร็จ e-Receipt เรียบร้อยแล้ว')}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Download className="w-4 h-4 text-slate-400" />
              <span>บันทึกใบเสร็จ</span>
            </button>
            <button
              onClick={() => alert('แชร์ใบเสร็จ e-Receipt สำเร็จ')}
              className="py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-lg shadow-amber-500/20"
            >
              <Share2 className="w-4 h-4" />
              <span>แชร์ใบเสร็จ</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
