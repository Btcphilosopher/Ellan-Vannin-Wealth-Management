/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * QrScannerModal.tsx
 * Synthetic PromptPay / Digital Baht QR Scanner & Payment Confirmation
 */

import React, { useState } from 'react';
import { QrCode, CheckCircle2, ShieldCheck, ArrowRight, X, AlertCircle } from 'lucide-react';
import { digitalBahtStore } from '../../services/store';
import { DigitalBahtPayment } from '../../types';

interface QrScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: (payment: DigitalBahtPayment) => void;
}

export const QrScannerModal: React.FC<QrScannerModalProps> = ({ isOpen, onClose, onPaymentSuccess }) => {
  const [step, setStep] = useState<'SCAN' | 'CONFIRM' | 'PIN'>('SCAN');
  const [selectedMerchant, setSelectedMerchant] = useState<{ id: string; name: string; walletId: string; defaultAmount: string; purpose: string }>({
    id: 'DB-MERCHANT-042',
    name: 'ร้านกาแฟกรุงเทพ (Sukhumvit Branch)',
    walletId: 'DB-MERCHANT-042',
    defaultAmount: '185.00',
    purpose: 'อาหารเช้าและเครื่องดื่ม'
  });

  const [amount, setAmount] = useState('185.00');
  const [purpose, setPurpose] = useState('อาหารเช้าและเครื่องดื่ม');
  const [pin, setPin] = useState(['', '', '', '', '', '']);
  const [errorMessage, setErrorMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const presets = [
    { id: 'DB-MERCHANT-042', name: 'ร้านกาแฟกรุงเทพ (Sukhumvit Branch)', walletId: 'DB-MERCHANT-042', defaultAmount: '185.00', purpose: 'กาแฟและขนมหวาน' },
    { id: 'DB-MERCHANT-042', name: 'ร้านกาแฟสุขุมวิท', walletId: 'DB-MERCHANT-042', defaultAmount: '95.00', purpose: 'กาแฟลาเต้ร้อน' },
    { id: 'DB-WALLET-0000998', name: 'คุณวิภาวรรณ ศรีสุข (P2P Transfer)', walletId: 'DB-WALLET-0000998', defaultAmount: '500.00', purpose: 'โอนเงินคืนค่าอาหาร' },
  ];

  const handleSelectPreset = (p: typeof presets[0]) => {
    setSelectedMerchant(p);
    setAmount(p.defaultAmount);
    setPurpose(p.purpose);
    setStep('CONFIRM');
  };

  const handlePinInput = (index: number, val: string) => {
    if (val.length > 1) val = val.slice(-1);
    const newPin = [...pin];
    newPin[index] = val;
    setPin(newPin);

    if (val && index < 5) {
      const nextInput = document.getElementById(`pin-input-${index + 1}`);
      nextInput?.focus();
    }

    if (newPin.every(digit => digit !== '')) {
      // Complete PIN entry
      executePayment();
    }
  };

  const executePayment = () => {
    setIsProcessing(true);
    setErrorMessage('');

    setTimeout(() => {
      const result = digitalBahtStore.processPayment(
        'DB-WALLET-0000421',
        selectedMerchant.walletId,
        amount,
        purpose,
        `QR-PAY-${Date.now()}`
      );

      setIsProcessing(false);

      if (result.success && result.payment) {
        onPaymentSuccess(result.payment);
        onClose();
        // Reset state
        setStep('SCAN');
        setPin(['', '', '', '', '', '']);
      } else {
        setErrorMessage(result.error?.message_th || 'การชำระเงินไม่สำเร็จ');
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl text-slate-100">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100 text-base">
                {step === 'SCAN' && 'สแกน QR เพื่อจ่ายเงินบาทดิจิทัล'}
                {step === 'CONFIRM' && 'ยืนยันรายละเอียดการชำระเงิน'}
                {step === 'PIN' && 'ระบุรหัส PIN 6 หลักเพื่อยืนยัน'}
              </h3>
              <p className="text-xs text-slate-400">Digital Baht PromptPay Abstraction</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5">
          {errorMessage && (
            <div className="mb-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* STEP 1: SCAN SIMULATION */}
          {step === 'SCAN' && (
            <div className="space-y-4">
              {/* Synthetic Camera Viewport */}
              <div className="relative aspect-square w-full rounded-xl bg-slate-950 border-2 border-dashed border-amber-500/40 overflow-hidden flex flex-col items-center justify-center p-6 text-center">
                <div className="absolute inset-4 border-2 border-amber-400/80 rounded-lg pointer-events-none animate-pulse"></div>
                <QrCode className="w-16 h-16 text-amber-400/60 mb-2" />
                <p className="text-xs text-slate-300 font-medium">จำลองการสแกน QR Code ร้านค้า</p>
                <p className="text-[11px] text-slate-500 mt-1">วางกล้องให้ตรงกับคิวอาร์โค้ด หรือเลือกรายการจำลองด้านล่าง</p>
              </div>

              <div>
                <p className="text-xs font-medium text-slate-400 mb-2">หรือเลือกรายการคิวอาร์จำลอง (Synthetic QR Samples):</p>
                <div className="space-y-2">
                  {presets.map((p, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSelectPreset(p)}
                      className="w-full text-left p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-amber-500/50 transition-all flex items-center justify-between group"
                    >
                      <div>
                        <div className="text-sm font-semibold text-slate-200 group-hover:text-amber-300">
                          {p.name}
                        </div>
                        <div className="text-xs text-slate-400">
                          {p.purpose} · ฿{p.defaultAmount}
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-amber-400 transition-transform group-hover:translate-x-1" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: CONFIRMATION */}
          {step === 'CONFIRM' && (
            <div className="space-y-4">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div className="text-xs text-slate-400 mb-1">ผู้รับชำระ (Payee):</div>
                <div className="text-base font-bold text-amber-400 flex items-center gap-1.5">
                  <span>{selectedMerchant.name}</span>
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-xs text-slate-500 font-mono mt-0.5">
                  Wallet ID: {selectedMerchant.walletId}
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    จำนวนเงินบาทดิจิทัล (THB CBDC):
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-400 font-semibold text-lg">฿</span>
                    <input
                      type="number"
                      step="0.01"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-4 py-2 text-xl font-bold font-mono text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    บันทึกช่วยจำ / วัตถุประสงค์ (Purpose):
                  </label>
                  <input
                    type="text"
                    value={purpose}
                    onChange={(e) => setPurpose(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="p-3 bg-slate-800/40 rounded-xl text-xs text-slate-300 flex justify-between items-center">
                <span>ยอดคงเหลือในกระเป๋าใช้ได้:</span>
                <span className="font-mono font-bold text-amber-300">
                  ฿{digitalBahtStore.wallets.get('DB-WALLET-0000421')?.available_balance || '24,850.00'}
                </span>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  onClick={() => setStep('SCAN')}
                  className="w-1/3 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
                >
                  ย้อนกลับ
                </button>
                <button
                  onClick={() => setStep('PIN')}
                  className="w-2/3 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-colors shadow-lg shadow-amber-500/20"
                >
                  ถัดไป (ใส่ PIN ยืนยัน)
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: PIN ENTER */}
          {step === 'PIN' && (
            <div className="space-y-6 text-center py-2">
              <div>
                <p className="text-sm font-semibold text-slate-200">ยืนยันการชำระเงินบาทดิจิทัล ฿{amount}</p>
                <p className="text-xs text-slate-400 mt-1">ไปยัง {selectedMerchant.name}</p>
              </div>

              <div className="flex justify-center gap-2 my-4">
                {pin.map((digit, idx) => (
                  <input
                    key={idx}
                    id={`pin-input-${idx}`}
                    type="password"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handlePinInput(idx, e.target.value)}
                    className="w-10 h-12 text-center text-xl font-bold bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-lg text-white font-mono focus:outline-none"
                  />
                ))}
              </div>

              <p className="text-[11px] text-slate-500">
                สแกนใบหน้า Biometric / PIN abstraction สำเร็จทันทีเมื่อป้อนครบ 6 หลัก
              </p>

              {isProcessing && (
                <div className="flex items-center justify-center gap-2 text-amber-400 text-xs font-medium">
                  <div className="w-4 h-4 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"></div>
                  <span>กำลังปรับสมดุล Ledger และชำระบัญชีทันที...</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
