/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * NoticeBanner.tsx
 * Mandatory clear disclaimer for Thai Digital Baht Simulation Platform
 */

import React, { useState } from 'react';
import { AlertTriangle, Info, ShieldCheck, X } from 'lucide-react';

export const NoticeBanner: React.FC = () => {
  const [showDetails, setShowDetails] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="bg-slate-900 border-b border-amber-500/30 text-slate-200 px-4 py-2 text-xs sm:text-sm">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
        <div className="flex items-center gap-2 font-medium text-amber-300">
          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
          <span>
            <strong>ระบบจำลองเพื่อการศึกษา วิจัย และพัฒนาซอฟต์แวร์</strong> — ไม่ใช่บริการเงินบาทดิจิทัลจริง และไม่ใช่ระบบของธนาคารแห่งประเทศไทย
          </span>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="text-amber-400 hover:text-amber-200 underline decoration-amber-400/50 flex items-center gap-1 transition-colors text-xs"
          >
            <Info className="w-3.5 h-3.5" />
            {showDetails ? 'ซ่อนรายละเอียดสถานะ Retail CBDC' : 'อ่านคำชี้แจงสถานะโครงการนำร่อง'}
          </button>
          <button
            onClick={() => setDismissed(true)}
            className="text-slate-400 hover:text-slate-200 p-0.5 rounded hover:bg-slate-800 transition-colors"
            title="ปิดประกาศ"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showDetails && (
        <div className="max-w-7xl mx-auto mt-2 pt-2 border-t border-slate-800 text-xs text-slate-300 leading-relaxed bg-slate-950/80 p-3 rounded-lg border border-amber-500/20">
          <div className="flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-amber-200 mb-1">
                สถานะ Retail CBDC ของประเทศไทย และการออกแบบแพลตฟอร์มวิจัยนี้:
              </p>
              <ul className="list-disc list-inside space-y-1 text-slate-300">
                <li>
                  ธนาคารแห่งประเทศไทย (BOT) ได้ทดสอบ Retail CBDC ในโครงการนำร่อง (Pilot Project) แล้ว และระบุว่าปัจจุบัน<strong>ยังไม่มีแผนออก Retail CBDC ให้ใช้งานทั่วไปในทันที</strong>
                </li>
                <li>
                  แอปพลิเคชันนี้ถูกออกแบบในฐานะ <strong>Future Digital Baht Simulation / Research Platform</strong> โดยใช้ข้อมูลจำลอง (Synthetic Data) ทั้งหมด
                </li>
                <li>
                  หลักการสำคัญ: <strong>1 THB CBDC = 1 THB</strong> (เปรียบได้กับธนบัตรดิจิทัล ไม่ใช่ Cryptocurrency หรือ Stablecoin เก็งกำไร)
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
