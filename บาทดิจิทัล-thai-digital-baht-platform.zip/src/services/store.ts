/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * DIGITAL BAHT CORE ENGINE & SIMULATION STORE
 * Handles double-entry ledger, monetary invariants, state transitions,
 * programmable payments, fraud detection, and stress tests.
 */

import {
  DigitalBahtWallet,
  DigitalBahtPayment,
  DigitalBahtUnit,
  LedgerAccount,
  LedgerEntry,
  ProgrammablePaymentRule,
  GovernmentProgram,
  TokenizedAsset,
  Merchant,
  AmlAlert,
  ConsentRecord,
  CrossBorderQuote,
  AuditLogEntry,
  ApiErrorResponse
} from '../types';

class DigitalBahtStore {
  // 1. Wallets
  wallets: Map<string, DigitalBahtWallet> = new Map();
  
  // 2. Payments Journal
  payments: DigitalBahtPayment[] = [];
  
  // 3. Double-Entry Ledger
  ledgerAccounts: Map<string, LedgerAccount> = new Map();
  ledgerEntries: LedgerEntry[] = [];
  
  // 4. Token Units
  units: DigitalBahtUnit[] = [];

  // 5. Programmable Payment Rules / Escrows
  rules: ProgrammablePaymentRule[] = [];

  // 6. Government Programs
  programs: GovernmentProgram[] = [];

  // 7. Tokenized Assets
  assets: TokenizedAsset[] = [];

  // 8. Merchants
  merchants: Map<string, Merchant> = new Map();

  // 9. Compliance & Privacy
  amlAlerts: AmlAlert[] = [];
  consents: ConsentRecord[] = [];

  // 10. Audit Logs
  auditLogs: AuditLogEntry[] = [];

  // 11. System Metrics (Simulation scale)
  metrics = {
    cbdc_outstanding: '50000000000.00', // 50 Billion THB
    total_wallets: 1200000,
    total_merchants: 100000,
    total_transactions: 10000000,
    settlement_success_rate: 99.98,
    avg_latency_ms: 180,
    tps_current: 2450,
    tps_peak: 100000,
    offline_tx_count: 1420
  };

  // Listeners for reactivity
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.seedInitialData();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  /**
   * Seed synthetic initial data according to BOT Retail CBDC Pilot simulation specs
   */
  private seedInitialData() {
    // A. Ledger Accounts (Double-Entry)
    const initialLedgerAccounts: LedgerAccount[] = [
      { account_id: 'ACC-CBDC-ISSUE', account_name: 'บัญชีออกเงินบาทดิจิทัล (CBDC Issuance Liability)', type: 'CBDC_ISSUANCE', balance: '50000000000.00', currency: 'THB', created_at: '2026-01-01T00:00:00Z' },
      { account_id: 'ACC-WALLET-LIAB', account_name: 'บัญชีภาระผูกพันกระเป๋าเงินประชาชน (Customer Wallet Liability)', type: 'WALLET_LIABILITY', balance: '24850.00', currency: 'THB', created_at: '2026-01-01T00:00:00Z' },
      { account_id: 'ACC-MERCHANT-BAL', account_name: 'บัญชียอดเงินร้านค้าชำระเงิน (Merchant Settlement Liability)', type: 'MERCHANT_BALANCE', balance: '48250.00', currency: 'THB', created_at: '2026-01-01T00:00:00Z' },
      { account_id: 'ACC-SETTLEMENT-MAIN', account_name: 'บัญชีศูนย์ชำระบัญชีกลาง (Central Settlement Account)', type: 'SETTLEMENT_ACCOUNT', balance: '0.00', currency: 'THB', created_at: '2026-01-01T00:00:00Z' },
      { account_id: 'ACC-ESCROW-HOLD', account_name: 'บัญชีพักเงินตามเงื่อนไข (Programmable Escrow Hold)', type: 'SUSPENSE_ACCOUNT', balance: '10000.00', currency: 'THB', created_at: '2026-01-01T00:00:00Z' },
      { account_id: 'ACC-BOT-RESERVE', account_name: 'บัญชีทุนสำรองธนาคารกลาง 100% (Central Bank 100% Reserve)', type: 'RESERVE_ACCOUNT', balance: '50000000000.00', currency: 'THB', created_at: '2026-01-01T00:00:00Z' },
    ];
    initialLedgerAccounts.forEach(acc => this.ledgerAccounts.set(acc.account_id, acc));

    // B. Wallets
    const somchaiWallet: DigitalBahtWallet = {
      wallet_id: 'DB-WALLET-0000421',
      customer_id: 'CUST-TH-1100800921',
      customer_name: 'คุณสมชาย วงศ์สวัสดิ์',
      provider_id: 'PROVIDER-BAY',
      provider_name: 'ธนาคารกรุงศรีอยุธยา (Synthetic Provider)',
      balance: '24850.00',
      available_balance: '24850.00',
      reserved_balance: '0.00',
      status: 'ACTIVE',
      kyc_status: 'VERIFIED',
      daily_limit: '100000.00',
      transaction_limit: '50000.00',
      created_at: '2026-02-15T09:00:00Z',
      updated_at: new Date().toISOString(),
      device_id: 'DEV-TH-IOS-88912'
    };

    const coffeeMerchantWallet: DigitalBahtWallet = {
      wallet_id: 'DB-MERCHANT-042',
      customer_id: 'CUST-BIZ-0994000182',
      customer_name: 'ร้านกาแฟกรุงเทพ (Sukhumvit Branch)',
      provider_id: 'PROVIDER-KBANK',
      provider_name: 'ธนาคารกสิกรไทย (Synthetic Provider)',
      balance: '48250.00',
      available_balance: '48250.00',
      reserved_balance: '0.00',
      status: 'ACTIVE',
      kyc_status: 'VERIFIED',
      daily_limit: '5000000.00',
      transaction_limit: '1000000.00',
      created_at: '2026-01-10T08:30:00Z',
      updated_at: new Date().toISOString(),
      is_merchant: true
    };

    const friendWallet: DigitalBahtWallet = {
      wallet_id: 'DB-WALLET-0000998',
      customer_id: 'CUST-TH-1100800772',
      customer_name: 'คุณวิภาวรรณ ศรีสุข',
      provider_id: 'PROVIDER-SCB',
      provider_name: 'ธนาคารไทยพาณิชย์ (Synthetic Provider)',
      balance: '12500.00',
      available_balance: '12500.00',
      reserved_balance: '0.00',
      status: 'ACTIVE',
      kyc_status: 'VERIFIED',
      daily_limit: '100000.00',
      transaction_limit: '50000.00',
      created_at: '2026-03-01T10:00:00Z',
      updated_at: new Date().toISOString()
    };

    this.wallets.set(somchaiWallet.wallet_id, somchaiWallet);
    this.wallets.set(coffeeMerchantWallet.wallet_id, coffeeMerchantWallet);
    this.wallets.set(friendWallet.wallet_id, friendWallet);

    // C. Merchants
    this.merchants.set('DB-MERCHANT-042', {
      merchant_id: 'DB-MERCHANT-042',
      merchant_name: 'ร้านกาแฟกรุงเทพ (Sukhumvit Branch)',
      category: 'อาหารและเครื่องดื่ม',
      wallet_id: 'DB-MERCHANT-042',
      daily_sales: '48250.00',
      transaction_count: 218,
      average_ticket: '221.33',
      settlement_status: 'READY',
      promptpay_qr_alias: '0812345678'
    });

    // D. Historical Demo Payments
    this.payments = [
      {
        payment_id: 'DB-PAY-20260929-001',
        payer_wallet: 'DB-WALLET-0000421',
        payer_name: 'คุณสมชาย วงศ์สวัสดิ์',
        payee_wallet: 'DB-MERCHANT-042',
        payee_name: 'ร้านกาแฟกรุงเทพ',
        amount: '95.00',
        currency: 'THB',
        purpose: 'กาแฟลาเต้ร้อน',
        status: 'SETTLED',
        created_at: '2026-09-29T08:15:22Z',
        authorized_at: '2026-09-29T08:15:22Z',
        settled_at: '2026-09-29T08:15:23Z'
      },
      {
        payment_id: 'DB-PAY-20260929-002',
        payer_wallet: 'DB-WALLET-0000421',
        payer_name: 'คุณสมชาย วงศ์สวัสดิ์',
        payee_wallet: 'DB-MERCHANT-042',
        payee_name: 'ร้านกาแฟกรุงเทพ',
        amount: '185.00',
        currency: 'THB',
        purpose: 'อาหารเช้าแซนวิชแฮมชีส',
        status: 'SETTLED',
        created_at: '2026-09-29T12:30:10Z',
        authorized_at: '2026-09-29T12:30:10Z',
        settled_at: '2026-09-29T12:30:11Z'
      },
      {
        payment_id: 'DB-PAY-20260928-088',
        payer_wallet: 'DB-WALLET-0000421',
        payer_name: 'คุณสมชาย วงศ์สวัสดิ์',
        payee_wallet: 'DB-WALLET-0000998',
        payee_name: 'คุณวิภาวรรณ ศรีสุข',
        amount: '1000.00',
        currency: 'THB',
        purpose: 'คืนค่าอาหารเย็นสัปดาห์ก่อน',
        status: 'SETTLED',
        created_at: '2026-09-28T19:04:00Z',
        authorized_at: '2026-09-28T19:04:01Z',
        settled_at: '2026-09-28T19:04:01Z'
      }
    ];

    // E. Programmable Escrow Rules
    this.rules = [
      {
        rule_id: 'RULE-ESCROW-1002',
        title: 'สัญญาการซื้อขายอุปกรณ์ไอทีแบบพักเงิน (Escrow Protection)',
        rule_type: 'ESCROW',
        payer_wallet: 'DB-WALLET-0000421',
        payee_wallet: 'DB-MERCHANT-042',
        amount: '10000.00',
        currency: 'THB',
        purpose: 'ซื้อเครื่องชงกาแฟเอสเปรสโซพาณิชย์',
        conditions: {
          delivery_confirmed: false,
          expiry_date: '2026-10-30T23:59:59Z'
        },
        status: 'HELD',
        created_at: '2026-10-01T10:00:00Z'
      },
      {
        rule_id: 'RULE-PURPOSE-3001',
        title: 'เงินสนับสนุนงบประมาณอาหาร (Purpose-Bound Food Budget)',
        rule_type: 'PURPOSE_BOUND',
        payer_wallet: 'DB-GOV-PROGRAM-FOOD',
        payee_wallet: 'DB-WALLET-0000421',
        amount: '2000.00',
        currency: 'THB',
        purpose: 'สวัสดิการอาหารกลางวันพนักงาน',
        conditions: {
          merchant_category: 'อาหารและเครื่องดื่ม',
          expiry_date: '2026-12-31T23:59:59Z'
        },
        status: 'PENDING',
        created_at: '2026-10-02T09:00:00Z'
      }
    ];

    // F. Government Welfare Programs
    this.programs = [
      {
        program_id: 'GOV-PROG-2026-SME',
        title_th: 'โครงการเงินสนับสนุนการปรับตัวดิจิทัลสำหรับ SME ไทย (DEMO)',
        description_th: 'งบประมาณช่วยเหลือผู้ประกอบการรายย่อยเพื่อเปลี่ยนผ่านสู่ชำระเงินดิจิทัลไร้รอยต่อ',
        budget_allocated: '5000000000.00', // 5 Billion THB
        budget_distributed: '1250000000.00',
        eligible_citizens_count: 250000,
        purpose_category: 'SME Digital Infrastructure',
        rules_summary: 'จำกัดการใช้เฉพาะซื้ออุปกรณ์ POS หรือซอฟต์แวร์ระบบบัญชีดิจิทัล',
        start_date: '2026-01-01',
        end_date: '2026-12-31',
        status: 'ACTIVE'
      },
      {
        program_id: 'GOV-PROG-2026-FLOOD',
        title_th: 'โครงการเงินช่วยเหลือเยียวยาผู้ประสบภัยธรรมชาติฉุกเฉิน (DEMO)',
        description_th: 'เยียวยาครัวเรือนที่ได้รับผลกระทบจากอุทกภัยแบบเจาะจงพื้นที่และรับเงินทันที',
        budget_allocated: '2000000000.00',
        budget_distributed: '1800000000.00',
        eligible_citizens_count: 120000,
        purpose_category: 'Disaster Relief',
        rules_summary: 'โอนตรงเข้ากระเป๋าเงินบาทดิจิทัลประชาชนที่ผ่านการยืนยันพิกัด KYC',
        start_date: '2026-08-01',
        end_date: '2026-10-31',
        status: 'ACTIVE'
      }
    ];

    // G. Tokenized Assets
    this.assets = [
      {
        asset_id: 'ASSET-BOND-2026A',
        asset_name: 'พันธบัตรรัฐบาลบาทดิจิทัล รุ่นออมทรัพย์ดิจิทัล 1 ปี',
        asset_type: 'GOVERNMENT_BOND',
        total_supply: '100000000.00',
        unit_price_cbdc: '1.00',
        issuer: 'กระทรวงการคลังร่วมกับธนาคารแห่งประเทศไทย (Synthetic)',
        description_th: 'พันธบัตรรัฐบาลจำลอง ชำระและรับดอกเบี้ยด้วยเงินบาทดิจิทัลแบบ Atomic Settlement'
      },
      {
        asset_id: 'ASSET-GOLD-TH999',
        asset_name: 'ทองคำบริสุทธิ์ 99.99% Tokenized Gold Certificate',
        asset_type: 'GOLD',
        total_supply: '50000.00',
        unit_price_cbdc: '42500.00',
        issuer: 'สมาคมค้าทองคำประเทศไทย (Synthetic)',
        description_th: 'ใบรับรองสิทธิในทองคำแท่ง ชำระเงินบาทดิจิทัลพร้อมโอนกรรมสิทธิ์ทันที 24/7'
      },
      {
        asset_id: 'ASSET-CARBON-TH01',
        asset_name: 'คาร์บอนเครดิตป่าไม้ชุมชนไทย (T-VER Certified)',
        asset_type: 'CARBON_CREDIT',
        total_supply: '500000.00',
        unit_price_cbdc: '250.00',
        issuer: 'องค์การบริหารจัดการก๊าซเรือนกระจก (Synthetic)',
        description_th: 'คาร์บอนเครดิตจำลองเพื่อการชดเชยการปล่อยก๊าซเรือนกระจกขององค์กร'
      }
    ];

    // H. Audit Log Seed
    this.addAuditLog('SYSTEM', 'MINT_SIMULATION_BOOT', 'CENTRAL_BANK_BOT', 'SUCCESS', 'ระบบเริ่มต้นการจำลองฐานข้อมูลเงินบาทดิจิทัล 50,000 ล้านบาท');
  }

  public addAuditLog(actor: string, action: string, resource: string, status: 'SUCCESS' | 'FAILURE' | 'WARNING', details_th: string) {
    const entry: AuditLogEntry = {
      audit_id: `AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      actor,
      action,
      resource,
      status,
      correlation_id: `CORR-${Math.floor(Math.random() * 1000000)}`,
      details_th
    };
    this.auditLogs.unshift(entry);
    if (this.auditLogs.length > 200) this.auditLogs.pop();
  }

  // Helper numeric calculation avoiding floating point errors for display
  private formatDecimal(val: number): string {
    return val.toFixed(2);
  }

  /**
   * Process a Digital Baht Payment
   * Follows Double-Entry Ledger and Invariant rules:
   * 1 THB CBDC = 1 THB
   */
  public processPayment(
    payer_wallet_id: string,
    payee_wallet_id: string,
    amount_str: string,
    purpose: string,
    idempotency_key?: string
  ): { success: boolean; payment?: DigitalBahtPayment; error?: ApiErrorResponse } {
    const amount = parseFloat(amount_str);

    if (isNaN(amount) || amount <= 0) {
      return {
        success: false,
        error: {
          error_code: 'DB-PAYMENT-FAILED',
          message_th: 'จำนวนเงินที่ระบุไม่ถูกต้อง',
          timestamp: new Date().toISOString()
        }
      };
    }

    // Idempotency Check
    if (idempotency_key) {
      const existing = this.payments.find(p => p.idempotency_key === idempotency_key);
      if (existing) {
        return { success: true, payment: existing };
      }
    }

    const payer = this.wallets.get(payer_wallet_id);
    const payee = this.wallets.get(payee_wallet_id);

    if (!payer) {
      return {
        success: false,
        error: {
          error_code: 'DB-WALLET-NOT-FOUND',
          message_th: 'ไม่พบกระเป๋าเงินผู้ชำระ',
          timestamp: new Date().toISOString()
        }
      };
    }

    if (!payee) {
      return {
        success: false,
        error: {
          error_code: 'DB-WALLET-NOT-FOUND',
          message_th: 'ไม่พบกระเป๋าเงินผู้รับชำระ',
          timestamp: new Date().toISOString()
        }
      };
    }

    const payerBalance = parseFloat(payer.available_balance);
    if (payerBalance < amount) {
      this.addAuditLog(payer.customer_name, 'PAYMENT_REJECTED', payer_wallet_id, 'FAILURE', `ยอดเงินไม่พอ: ต้องการ ${amount_str} ฿ แต่มียอดใช้ได้ ${payer.available_balance} ฿`);
      return {
        success: false,
        error: {
          error_code: 'DB-INSUFFICIENT-BALANCE',
          message_th: 'ยอดเงินบาทดิจิทัลคงเหลือในกระเป๋าไม่เพียงพอ',
          details: { requested: amount_str, available: payer.available_balance },
          timestamp: new Date().toISOString()
        }
      };
    }

    // AML / Fraud Rule Simulation: Flag transactions > ฿50,000 or high velocity
    if (amount > 50000) {
      const alert: AmlAlert = {
        alert_id: `AML-${Date.now()}`,
        transaction_id: `DB-PAY-${Date.now()}`,
        wallet_id: payer_wallet_id,
        customer_name: payer.customer_name,
        amount: amount_str,
        risk_score: 78,
        trigger_reason: 'ยอดธุรกรรมบาทดิจิทัลเกินวงเงินเฝ้าระวัง 50,000 บาท',
        status: 'PENDING_REVIEW',
        created_at: new Date().toISOString()
      };
      this.amlAlerts.unshift(alert);
    }

    // State Machine: CREATED -> VALIDATING -> AUTHORIZED -> SETTLED
    const now = new Date().toISOString();
    const paymentId = `DB-PAY-${now.substring(0, 10).replace(/-/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;

    // Debit Payer Wallet
    const newPayerBal = this.formatDecimal(payerBalance - amount);
    payer.balance = newPayerBal;
    payer.available_balance = newPayerBal;
    payer.updated_at = now;

    // Credit Payee Wallet
    const payeeBalance = parseFloat(payee.balance);
    const newPayeeBal = this.formatDecimal(payeeBalance + amount);
    payee.balance = newPayeeBal;
    payee.available_balance = newPayeeBal;
    payee.updated_at = now;

    // Double-Entry Ledger Entry
    const ledgerEntry: LedgerEntry = {
      entry_id: `ENT-${Date.now()}`,
      transaction_id: paymentId,
      debit_account: payer.is_merchant ? 'ACC-MERCHANT-BAL' : 'ACC-WALLET-LIAB',
      credit_account: payee.is_merchant ? 'ACC-MERCHANT-BAL' : 'ACC-WALLET-LIAB',
      amount: amount_str,
      currency: 'THB',
      timestamp: now,
      description: `การชำระเงินบาทดิจิทัล: ${purpose}`,
      reference: paymentId
    };
    this.ledgerEntries.unshift(ledgerEntry);

    const payment: DigitalBahtPayment = {
      payment_id: paymentId,
      payer_wallet: payer_wallet_id,
      payer_name: payer.customer_name,
      payee_wallet: payee_wallet_id,
      payee_name: payee.customer_name,
      merchant_id: payee.is_merchant ? payee_wallet_id : undefined,
      merchant_name: payee.is_merchant ? payee.customer_name : undefined,
      amount: amount_str,
      currency: 'THB',
      purpose,
      status: 'SETTLED',
      idempotency_key,
      created_at: now,
      authorized_at: now,
      settled_at: now
    };

    this.payments.unshift(payment);

    // Update Merchant statistics if applicable
    if (payee.is_merchant) {
      const merchant = this.merchants.get(payee_wallet_id);
      if (merchant) {
        const curSales = parseFloat(merchant.daily_sales) + amount;
        const curCount = merchant.transaction_count + 1;
        merchant.daily_sales = this.formatDecimal(curSales);
        merchant.transaction_count = curCount;
        merchant.average_ticket = this.formatDecimal(curSales / curCount);
      }
    }

    this.addAuditLog(payer.customer_name, 'PAYMENT_SETTLED', paymentId, 'SUCCESS', `โอนเงินบาทดิจิทัล ฿${amount_str} ไปยัง ${payee.customer_name} (${purpose}) สำเร็จ`);

    this.notify();
    return { success: true, payment };
  }

  /**
   * Refund a transaction
   */
  public refundPayment(paymentId: string, reason: string): { success: boolean; error?: string } {
    const original = this.payments.find(p => p.payment_id === paymentId);
    if (!original) {
      return { success: false, error: 'ไม่พบรายการธุรกรรมเดิม' };
    }
    if (original.status === 'REVERSED') {
      return { success: false, error: 'รายการนี้ได้รับการคืนเงินไปแล้ว' };
    }

    const res = this.processPayment(
      original.payee_wallet,
      original.payer_wallet,
      original.amount,
      `คืนเงินบาทดิจิทัล (${reason}): ${original.purpose}`
    );

    if (res.success) {
      original.status = 'REVERSED';
      original.reversed_at = new Date().toISOString();
      this.addAuditLog('MERCHANT', 'REFUND_COMPLETED', paymentId, 'SUCCESS', `ดำเนินการคืนเงิน ฿${original.amount} สำหรับรายการ ${paymentId}`);
      this.notify();
      return { success: true };
    }

    return { success: false, error: res.error?.message_th || 'การคืนเงินล้มเหลว' };
  }

  /**
   * Issuance / Mint Simulator (Central Bank ONLY)
   */
  public mintCBDC(amount_str: string, target_wallet_id: string, reason: string) {
    const amount = parseFloat(amount_str);
    const wallet = this.wallets.get(target_wallet_id);
    if (!wallet) return { success: false, error: 'ไม่พบกระเป๋าเงินปลายทาง' };

    const newBal = this.formatDecimal(parseFloat(wallet.balance) + amount);
    wallet.balance = newBal;
    wallet.available_balance = newBal;

    // Update Central Bank Ledger
    const issueAcc = this.ledgerAccounts.get('ACC-CBDC-ISSUE');
    if (issueAcc) {
      issueAcc.balance = this.formatDecimal(parseFloat(issueAcc.balance) + amount);
    }

    this.metrics.cbdc_outstanding = this.formatDecimal(parseFloat(this.metrics.cbdc_outstanding) + amount);

    this.addAuditLog('CENTRAL_BANK_BOT', 'CBDC_MINTED', target_wallet_id, 'SUCCESS', `[SIMULATION ONLY] ออกเงินบาทดิจิทัลเพิ่ม ฿${amount_str} ไปยังกระเป๋า ${wallet.customer_name} (เหตุผล: ${reason})`);
    this.notify();
    return { success: true };
  }

  /**
   * Redemption Simulator (Central Bank / Commercial Bank)
   */
  public redeemCBDC(amount_str: string, source_wallet_id: string, bank_account: string) {
    const amount = parseFloat(amount_str);
    const wallet = this.wallets.get(source_wallet_id);
    if (!wallet) return { success: false, error: 'ไม่พบกระเป๋าเงิน' };

    const curBal = parseFloat(wallet.available_balance);
    if (curBal < amount) return { success: false, error: 'ยอดเงินบาทดิจิทัลไม่เพียงพอสำหรับการแลกคืน' };

    const newBal = this.formatDecimal(curBal - amount);
    wallet.balance = newBal;
    wallet.available_balance = newBal;

    const issueAcc = this.ledgerAccounts.get('ACC-CBDC-ISSUE');
    if (issueAcc) {
      issueAcc.balance = this.formatDecimal(parseFloat(issueAcc.balance) - amount);
    }

    this.addAuditLog(wallet.customer_name, 'CBDC_REDEEMED', source_wallet_id, 'SUCCESS', `แลกคืนเงินบาทดิจิทัล ฿${amount_str} เข้าบัญชีธนาคาร commercial ${bank_account} (จำลอง)`);
    this.notify();
    return { success: true };
  }

  /**
   * Programmable Escrow - Release
   */
  public releaseEscrow(rule_id: string) {
    const rule = this.rules.find(r => r.rule_id === rule_id);
    if (!rule || rule.status !== 'HELD') return { success: false, error: 'ไม่พบสัญญา Escrow หรือถูกดำเนินการไปแล้ว' };

    const res = this.processPayment(
      rule.payer_wallet,
      rule.payee_wallet,
      rule.amount,
      `ปล่อยเงินตามเงื่อนไขสัญญา Escrow (${rule.title})`
    );

    if (res.success) {
      rule.status = 'EXECUTED';
      rule.executed_at = new Date().toISOString();
      rule.conditions.delivery_confirmed = true;
      this.addAuditLog('ESCROW_ENGINE', 'ESCROW_RELEASED', rule_id, 'SUCCESS', `เงื่อนไขครบถ้วน: ปล่อยเงิน ฿${rule.amount} ให้กับร้านค้าปลายทางสำเร็จ`);
      this.notify();
      return { success: true };
    }

    return { success: false, error: res.error?.message_th || 'การปล่อยเงินล้มเหลว' };
  }

  /**
   * Split Bill Helper
   */
  public splitBill(total_amount_str: string, participants: string[], purpose: string) {
    const total = parseFloat(total_amount_str);
    if (participants.length === 0) return { success: false, error: 'ไม่มีผู้ร่วมหารบิล' };
    const perPerson = this.formatDecimal(total / participants.length);

    this.addAuditLog('CONSUMER_APP', 'SPLIT_BILL_CREATED', 'SPLIT-SESSION', 'SUCCESS', `สร้างการแบ่งบิล ฿${total_amount_str} สำหรับ ${participants.length} คน (ตกคนละ ฿${perPerson})`);
    this.notify();
    return { success: true, per_person: perPerson };
  }

  /**
   * Offline Payment Simulation
   */
  public processOfflinePayment(payer_wallet_id: string, payee_wallet_id: string, amount_str: string, nonce: number) {
    // Check for double-spend simulation
    const existingPmt = this.payments.find(p => p.is_offline && p.idempotency_key === `OFFLINE-NONCE-${payer_wallet_id}-${nonce}`);
    if (existingPmt) {
      this.addAuditLog('DOUBLE_SPEND_ENGINE', 'DOUBLE_SPEND_BLOCKED', payer_wallet_id, 'WARNING', `[DOUBLE-SPEND DEFENCE] ตรวจพบการพยายามใช้ Offline Token ซ้ำ (Nonce: ${nonce}) - ระบบปฏิเสธธุรกรรม`);
      return {
        success: false,
        error: {
          error_code: 'DB-DOUBLE-SPEND-DETECTED',
          message_th: 'ตรวจพบธุรกรรมซ้ำในระบบ Offline Tokens - ระบบป้องกันการใช้เงินสองครั้งสำเร็จ',
          timestamp: new Date().toISOString()
        }
      };
    }

    const res = this.processPayment(
      payer_wallet_id,
      payee_wallet_id,
      amount_str,
      'ชำระเงินบาทดิจิทัลโหมดออฟไลน์ (Offline Token Sync)',
      `OFFLINE-NONCE-${payer_wallet_id}-${nonce}`
    );

    if (res.success && res.payment) {
      res.payment.is_offline = true;
      this.metrics.offline_tx_count += 1;
      this.addAuditLog('OFFLINE_SYNC_ENGINE', 'OFFLINE_SETTLED', res.payment.payment_id, 'SUCCESS', `ซิงก์ธุรกรรมออฟไลน์สำเร็จเมื่ออุปกรณ์กลับมาออนไลน์`);
      this.notify();
    }

    return res;
  }

  /**
   * Cross-Border Settlement (mBridge Style Abstraction)
   */
  public executeCrossBorderSettlement(targetCurrency: 'HKD' | 'SGD' | 'CNY' | 'AED', amount_thb: string): CrossBorderQuote & { status: string; tx_hash: string } {
    const rateMap = { HKD: 0.22, SGD: 0.039, CNY: 0.20, AED: 0.10 };
    const fxRate = rateMap[targetCurrency] || 0.20;
    const thbVal = parseFloat(amount_thb);
    const foreignVal = (thbVal * fxRate).toFixed(2);

    const txHash = `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`;

    this.addAuditLog('CROSS_BORDER_mBRIDGE', 'ATOMIC_DvP_SETTLED', targetCurrency, 'SUCCESS', `จำลองการชำระเงินข้ามพรมแดน: THB ฿${amount_thb} ➔ ${targetCurrency} ${foreignVal} (Atomic Settlement via mBridge Platform)`);

    this.notify();

    return {
      corridor_id: `CORRIDOR-THB-${targetCurrency}`,
      source_currency: 'THB',
      target_currency: targetCurrency,
      fx_rate: fxRate.toString(),
      fee_cbdc: '0.00',
      settlement_type: 'mBridge Atomic Delivery-versus-Payment',
      estimated_time_ms: 120,
      status: 'SETTLED_FINAL',
      tx_hash: txHash
    };
  }

  /**
   * Run Stress Test Scenario
   */
  public runStressTest(scenario: 'TPS_SPIKE' | 'BANK_OUTAGE' | 'DOUBLE_SPEND_ATTACK' | 'RECONCILIATION_AUDIT') {
    if (scenario === 'TPS_SPIKE') {
      this.metrics.tps_current = 98450;
      this.addAuditLog('STRESS_LAB', 'STRESS_TEST_RUN', 'ENGINE', 'SUCCESS', 'ทดสอบ Stress Test: จำลองโหลดธุรกรรมชำระเงินสูงถึง 98,450 TPS — ระบบ Ledger รองรับได้ไร้รอยต่อ');
    } else if (scenario === 'BANK_OUTAGE') {
      this.addAuditLog('STRESS_LAB', 'PROVIDER_OUTAGE_SIM', 'SCB_ADAPTER', 'WARNING', 'จำลองสถานการณ์ ธนาคารพาณิชย์หยุดทำงาน — Retail CBDC ยังคงทำชำระเงินโดยตรงบนโครงสร้างพื้นฐานธนาคารกลางได้ 100%');
    } else if (scenario === 'DOUBLE_SPEND_ATTACK') {
      this.addAuditLog('STRESS_LAB', 'DOUBLE_SPEND_ATTACK', 'DEFENCE_ENGINE', 'SUCCESS', 'จำลองการโจมตี Double-Spend 5,000 รายการพร้อมกัน — Invariant Engine ยับยั้งได้ครบ 100%');
    } else if (scenario === 'RECONCILIATION_AUDIT') {
      this.addAuditLog('STRESS_LAB', 'RECONCILIATION_SUCCESS', 'AUDIT_MODULE', 'SUCCESS', 'ตรวจสอบความถูกต้องทางบัญชี (Reconciliation): Total CBDC Liability == Total Wallet Balances (ตรงกัน 100.00%)');
    }

    this.notify();
  }

  /**
   * Reset simulation state
   */
  public resetSimulation() {
    this.payments = [];
    this.ledgerEntries = [];
    this.amlAlerts = [];
    this.seedInitialData();
    this.notify();
  }
}

export const digitalBahtStore = new DigitalBahtStore();
