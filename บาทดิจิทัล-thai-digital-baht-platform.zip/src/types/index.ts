/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * THAI DIGITAL BAHT (บาทดิจิทัล) - RETAIL CBDC PLATFORM TYPES
 */

export type Currency = 'THB' | 'HKD' | 'SGD' | 'CNY' | 'AED';

export type WalletStatus = 'ACTIVE' | 'FROZEN' | 'SUSPENDED' | 'PENDING_KYC';

export type KycStatus = 'UNVERIFIED' | 'PENDING' | 'VERIFIED' | 'REJECTED';

export type PaymentStatus = 
  | 'CREATED'
  | 'VALIDATING'
  | 'AUTHORIZED'
  | 'RESERVED'
  | 'SUBMITTED'
  | 'SETTLING'
  | 'SETTLED'
  | 'FAILED'
  | 'EXPIRED'
  | 'REVERSED';

export type UnitStatus = 'ISSUED' | 'CIRCULATING' | 'HELD' | 'REDEEMED';

export type LedgerAccountType = 
  | 'CBDC_ISSUANCE'
  | 'WALLET_LIABILITY'
  | 'MERCHANT_BALANCE'
  | 'SETTLEMENT_ACCOUNT'
  | 'REDEMPTION_ACCOUNT'
  | 'RESERVE_ACCOUNT'
  | 'FEE_ACCOUNT'
  | 'SUSPENSE_ACCOUNT';

export type RuleType = 'ESCROW' | 'PURPOSE_BOUND' | 'GOVERNMENT_PROGRAM' | 'TOKENIZED_ASSET';

/**
 * 1. Digital Money Unit Abstraction (Tokenized Bearer Money)
 */
export interface DigitalBahtUnit {
  unit_id: string;
  currency: 'THB';
  face_value: string; // Decimal string e.g. "1.00", "500.00"
  owner_wallet: string;
  issuer: 'CENTRAL_BANK_BOT';
  status: UnitStatus;
  created_at: string;
  transferred_at: string;
  settled_at?: string;
  metadata?: Record<string, unknown>;
}

/**
 * 2. Wallet Model
 */
export interface DigitalBahtWallet {
  wallet_id: string;
  customer_id: string;
  customer_name: string;
  provider_id: string; // e.g., 'PROVIDER-BAY', 'PROVIDER-KBANK', 'PROVIDER-BOT'
  provider_name: string;
  balance: string; // Decimal string e.g. "24850.00"
  available_balance: string;
  reserved_balance: string;
  status: WalletStatus;
  kyc_status: KycStatus;
  daily_limit: string;
  transaction_limit: string;
  created_at: string;
  updated_at: string;
  device_id?: string;
  is_merchant?: boolean;
}

/**
 * 3. Double-Entry Ledger Entry
 */
export interface LedgerAccount {
  account_id: string;
  account_name: string;
  type: LedgerAccountType;
  balance: string;
  currency: 'THB';
  created_at: string;
}

export interface LedgerEntry {
  entry_id: string;
  transaction_id: string;
  debit_account: string;
  credit_account: string;
  amount: string;
  currency: 'THB';
  timestamp: string;
  description: string;
  reference: string;
}

/**
 * 4. Payment Object
 */
export interface DigitalBahtPayment {
  payment_id: string;
  payer_wallet: string;
  payer_name?: string;
  payee_wallet: string;
  payee_name?: string;
  merchant_id?: string;
  merchant_name?: string;
  amount: string; // Decimal string e.g. "185.00"
  currency: 'THB';
  purpose: string; // e.g., 'อาหารและเครื่องดื่ม', 'ค่าไฟ', 'โอนเงิน P2P'
  qr_reference?: string;
  status: PaymentStatus;
  idempotency_key?: string;
  created_at: string;
  authorized_at?: string;
  settled_at?: string;
  reversed_at?: string;
  error_code?: string;
  error_message_th?: string;
  is_offline?: boolean;
}

/**
 * 5. Programmable Payment Rules & Escrow
 */
export interface ProgrammablePaymentRule {
  rule_id: string;
  title: string;
  rule_type: RuleType;
  payer_wallet: string;
  payee_wallet: string;
  amount: string;
  currency: 'THB';
  purpose: string;
  conditions: {
    merchant_category?: string;
    delivery_confirmed?: boolean;
    expiry_date?: string;
    program_id?: string;
    asset_id?: string;
  };
  status: 'PENDING' | 'HELD' | 'EXECUTED' | 'EXPIRED' | 'CANCELLED';
  created_at: string;
  executed_at?: string;
}

/**
 * 6. Government Program Simulator
 */
export interface GovernmentProgram {
  program_id: string;
  title_th: string;
  description_th: string;
  budget_allocated: string;
  budget_distributed: string;
  eligible_citizens_count: number;
  purpose_category: string;
  rules_summary: string;
  start_date: string;
  end_date: string;
  status: 'ACTIVE' | 'COMPLETED' | 'PAUSED';
}

/**
 * 7. Tokenized Assets
 */
export interface TokenizedAsset {
  asset_id: string;
  asset_name: string;
  asset_type: 'GOVERNMENT_BOND' | 'GOLD' | 'CARBON_CREDIT' | 'REAL_ESTATE';
  total_supply: string;
  unit_price_cbdc: string;
  issuer: string;
  description_th: string;
}

/**
 * 8. Merchant Object
 */
export interface Merchant {
  merchant_id: string;
  merchant_name: string;
  category: string;
  wallet_id: string;
  daily_sales: string;
  transaction_count: number;
  average_ticket: string;
  settlement_status: 'READY' | 'SETTLING' | 'SETTLED';
  promptpay_qr_alias?: string;
}

/**
 * 9. Offline Payment Token & State
 */
export interface OfflinePaymentToken {
  token_id: string;
  wallet_id: string;
  device_id: string;
  nonce: number;
  max_amount: string;
  expires_at: string;
  device_signature_hash: string;
}

/**
 * 10. Compliance & Privacy
 */
export interface AmlAlert {
  alert_id: string;
  transaction_id: string;
  wallet_id: string;
  customer_name: string;
  amount: string;
  risk_score: number; // 0 to 100
  trigger_reason: string;
  status: 'PENDING_REVIEW' | 'CLEARED' | 'BLOCKED';
  created_at: string;
}

export interface ConsentRecord {
  consent_id: string;
  customer_id: string;
  purpose: string;
  data_type: string;
  recipient: string;
  granted_at: string;
  expires_at: string;
  status: 'ACTIVE' | 'REVOKED';
}

/**
 * 11. Cross-Border Corridor
 */
export interface CrossBorderQuote {
  corridor_id: string;
  source_currency: 'THB';
  target_currency: 'HKD' | 'SGD' | 'CNY' | 'AED';
  fx_rate: string;
  fee_cbdc: string;
  settlement_type: 'mBridge Atomic Delivery-versus-Payment';
  estimated_time_ms: number;
}

/**
 * 12. Audit Log Event
 */
export interface AuditLogEntry {
  audit_id: string;
  timestamp: string;
  actor: string;
  action: string;
  resource: string;
  status: 'SUCCESS' | 'FAILURE' | 'WARNING';
  correlation_id: string;
  details_th: string;
}

/**
 * 13. Error Model
 */
export interface ApiErrorResponse {
  error_code: 
    | 'DB-WALLET-NOT-FOUND'
    | 'DB-INSUFFICIENT-BALANCE'
    | 'DB-PAYMENT-EXPIRED'
    | 'DB-PAYMENT-DUPLICATE'
    | 'DB-PAYMENT-FAILED'
    | 'DB-QR-INVALID'
    | 'DB-SETTLEMENT-FAILED'
    | 'DB-RULE-VIOLATION'
    | 'DB-COMPLIANCE-HOLD'
    | 'DB-DOUBLE-SPEND-DETECTED'
    | 'DB-FRAUD-HOLD';
  message_th: string;
  details?: Record<string, unknown>;
  timestamp: string;
}
