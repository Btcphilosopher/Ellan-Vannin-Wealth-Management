/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * App.tsx
 * THAI DIGITAL BAHT (บาทดิจิทัล) - RETAIL CBDC PAYMENT & FINANCIAL INFRASTRUCTURE PLATFORM
 */

import React, { useState } from 'react';
import { NoticeBanner } from './components/NoticeBanner';
import { Header, ActiveTab } from './components/Header';
import { ConsumerWalletView } from './components/views/ConsumerWalletView';
import { MerchantAppView } from './components/views/MerchantAppView';
import { CentralBankConsoleView } from './components/views/CentralBankConsoleView';
import { ProgrammableEngineView } from './components/views/ProgrammableEngineView';
import { CrossBorderLabView } from './components/views/CrossBorderLabView';
import { StressTestLabView } from './components/views/StressTestLabView';
import { CliTerminalView } from './components/views/CliTerminalView';
import { ApiGatewayDocsView } from './components/views/ApiGatewayDocsView';
import { CompliancePrivacyView } from './components/views/CompliancePrivacyView';
import { QrScannerModal } from './components/modals/QrScannerModal';
import { ReceiptModal } from './components/modals/ReceiptModal';
import { DigitalBahtPayment } from './types';
import { ShieldCheck, Info } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('wallet');
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [selectedReceiptPayment, setSelectedReceiptPayment] = useState<DigitalBahtPayment | null>(null);

  const handlePaymentSuccess = (payment: DigitalBahtPayment) => {
    setSelectedReceiptPayment(payment);
  };

  return (
    <div className="min-h-screen bg-[#0b1322] text-slate-100 flex flex-col font-sans selection:bg-amber-500/20 selection:text-amber-300">
      {/* Mandatory Notice Banner */}
      <NoticeBanner />

      {/* Top Navigation Header */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 sm:py-8 space-y-6">
        {activeTab === 'wallet' && (
          <ConsumerWalletView
            onOpenScanner={() => setIsScannerOpen(true)}
            onSelectPaymentForReceipt={(p) => setSelectedReceiptPayment(p)}
          />
        )}

        {activeTab === 'merchant' && (
          <MerchantAppView
            onSelectPaymentForReceipt={(p) => setSelectedReceiptPayment(p)}
          />
        )}

        {activeTab === 'central-bank' && <CentralBankConsoleView />}

        {activeTab === 'programmable' && <ProgrammableEngineView />}

        {activeTab === 'cross-border' && <CrossBorderLabView />}

        {activeTab === 'stress-test' && <StressTestLabView />}

        {activeTab === 'cli' && <CliTerminalView />}

        {activeTab === 'api-docs' && <ApiGatewayDocsView />}

        {activeTab === 'privacy' && <CompliancePrivacyView />}
      </main>

      {/* Modals */}
      <QrScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onPaymentSuccess={handlePaymentSuccess}
      />

      <ReceiptModal
        payment={selectedReceiptPayment}
        onClose={() => setSelectedReceiptPayment(null)}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-8 text-slate-400 text-xs">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-amber-500 text-slate-950 font-bold flex items-center justify-center text-xs">
              ฿
            </div>
            <div>
              <span className="font-bold text-slate-200">บาทดิจิทัล THAI DIGITAL BAHT</span>
              <span className="text-slate-500 ml-2">· Future Digital Baht Research Platform</span>
            </div>
          </div>

          <div className="text-center md:text-right text-[11px] text-slate-500 space-y-1">
            <p>
              ระบบนี้เป็นระบบจำลองเพื่อการศึกษา วิจัย และพัฒนาซอฟต์แวร์ ไม่ใช่บริการเงินบาทดิจิทัลจริง
            </p>
            <p className="text-amber-500/80 font-mono">
              1 THB CBDC = 1 THB · Thai Financial Modernism Architecture
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
