import { MarketPrice, InfrastructureAsset, StorageFacility, PipelineFlow, PortfolioAsset, ForecastData } from './types';

// ==========================================
// MODULE 1: HISTORICAL SPOT PRICES
// ==========================================
export const generateHistoricalPrices = (): MarketPrice[] => {
  const baseDate = new Date(2026, 0, 1);
  const data: MarketPrice[] = [];
  
  // Create 120 days of data ending today
  for (let i = 120; i >= 0; i--) {
    const date = new Date(baseDate);
    date.setDate(baseDate.getDate() - i);
    const dateString = date.toISOString().split('T')[0];
    
    // Simulate realistic trends with some volatility
    const trend = Math.sin(i / 15) * 8 + (120 - i) * 0.15;
    const noise = Math.sin(i * 1.5) * 2 + Math.cos(i * 0.7) * 1.5;
    
    data.push({
      date: dateString,
      nbpSpot: Math.round((78.5 + trend + noise) * 10) / 10,
      dayAhead: Math.round((79.2 + trend + noise * 0.9) * 10) / 10,
      monthAhead: Math.round((82.0 + trend * 0.8 + noise * 0.5) * 10) / 10,
      seasonalForward: Math.round((88.5 + (120 - i) * 0.05 + Math.sin(i / 30) * 3) * 10) / 10,
      brentCrude: Math.round((74.2 + (trend * 0.12) + noise * 0.3) * 10) / 10,
      ukCarbon: Math.round((42.1 + Math.cos(i / 20) * 2.5 + noise * 0.1) * 10) / 10,
      electricityPrice: Math.round((68.0 + (trend * 1.1) + noise * 1.8) * 10) / 10,
    });
  }
  return data;
};

// ==========================================
// MODULE 4: NATIONAL INFRASTRUCTURE ASSETS
// ==========================================
export const infrastructureAssets: InfrastructureAsset[] = [
  // OFFSHORE FIELDS
  {
    id: 'field_brent',
    name: 'Brent Field (Historical Hub)',
    type: 'Offshore Field',
    operator: 'Shell UK',
    latitude: 56.4,
    longitude: 1.5,
    utilisationPercent: 88,
    annualThroughput: '12.4 Bcm/year equivalent',
    estimatedValueGbp: 4200000000,
    maintenanceSchedule: 'Sep 15 - Oct 01, 2026',
    description: 'Northeastern North Sea structural field supporting crude benchmark blends and associated gas piping.',
    irr: 14.2,
    remainingLifeYears: 12,
    maintenanceRisk: 'Medium',
    carbonExposure: 'High',
    assetScore: 72
  },
  {
    id: 'field_buzzard',
    name: 'Buzzard Oil Field',
    type: 'Offshore Field',
    operator: 'CNOOC International',
    latitude: 54.9,
    longitude: 0.8,
    utilisationPercent: 94,
    annualThroughput: '18.2 Mboe/year',
    estimatedValueGbp: 6100000000,
    maintenanceSchedule: 'July 10 - July 20, 2026 (Completed)',
    description: 'Major UK continental shelf oil producer. Linked via Forties pipeline system.',
    irr: 16.5,
    remainingLifeYears: 18,
    maintenanceRisk: 'Medium',
    carbonExposure: 'High',
    assetScore: 78
  },
  {
    id: 'field_clair',
    name: 'Clair Field (West of Shetland)',
    type: 'Offshore Field',
    operator: 'BP Exploration',
    latitude: 59.8,
    longitude: -2.1,
    utilisationPercent: 78,
    annualThroughput: '22.0 Mboe/year',
    estimatedValueGbp: 8500000000,
    maintenanceSchedule: 'Jun 01 - Jun 15, 2027',
    description: 'Giant oil field, pioneering advanced water alternating gas (WAG) recovery. High strategic reserve relevance.',
    irr: 18.2,
    remainingLifeYears: 32,
    maintenanceRisk: 'High',
    carbonExposure: 'Medium',
    assetScore: 84
  },
  // GAS TERMINALS
  {
    id: 'term_st_fergus',
    name: 'St Fergus Gas Terminal',
    type: 'Gas Terminal',
    operator: 'National Grid Gas / Shell / Total',
    latitude: 57.5,
    longitude: -1.8,
    utilisationPercent: 64,
    annualThroughput: '15.8 Bcm/year',
    estimatedValueGbp: 3200000000,
    maintenanceSchedule: 'Aug 02 - Aug 09, 2026',
    description: 'Critical reception point for Norwegian imports via Vesterled pipeline and UK northern North Sea gas fields.',
    irr: 11.5,
    remainingLifeYears: 25,
    maintenanceRisk: 'Low',
    carbonExposure: 'Medium',
    assetScore: 86
  },
  {
    id: 'term_bacton',
    name: 'Bacton Gas Terminal',
    type: 'Gas Terminal',
    operator: 'Shell / Eni / National Gas',
    latitude: 52.8,
    longitude: 1.4,
    utilisationPercent: 48,
    annualThroughput: '18.5 Bcm/year',
    estimatedValueGbp: 3800000000,
    maintenanceSchedule: 'Jul 22 - Jul 28, 2026 (Active)',
    description: 'Southeastern UK import/export gateway connected to Belgium (IUK) and Netherlands (BBL) interconnectors.',
    irr: 9.8,
    remainingLifeYears: 20,
    maintenanceRisk: 'Low',
    carbonExposure: 'Low',
    assetScore: 81
  },
  {
    id: 'term_easington',
    name: 'Easington Gas Terminal',
    type: 'Gas Terminal',
    operator: 'Gassco / Centrica Storage',
    latitude: 53.6,
    longitude: 0.1,
    utilisationPercent: 82,
    annualThroughput: '24.2 Bcm/year',
    estimatedValueGbp: 4500000000,
    maintenanceSchedule: 'Oct 05 - Oct 12, 2026',
    description: 'Landing point of Langeled pipeline from Norway and interface for Rough Offshore Storage field.',
    irr: 12.8,
    remainingLifeYears: 28,
    maintenanceRisk: 'Low',
    carbonExposure: 'Medium',
    assetScore: 89
  },
  // LNG TERMINALS
  {
    id: 'lng_milford_haven',
    name: 'South Hook LNG (Milford Haven)',
    type: 'LNG Terminal',
    operator: 'QatarEnergy / ExxonMobil',
    latitude: 51.7,
    longitude: -5.0,
    utilisationPercent: 72,
    annualThroughput: '15.6 Bcm/year capacity',
    estimatedValueGbp: 5200000000,
    maintenanceSchedule: 'No major shut-down scheduled',
    description: 'One of Europe\'s largest LNG regasification terminals, processing supercooled cargoes from Qatar and USA.',
    irr: 13.5,
    remainingLifeYears: 35,
    maintenanceRisk: 'Low',
    carbonExposure: 'Low',
    assetScore: 92
  },
  {
    id: 'lng_isle_of_grain',
    name: 'Isle of Grain LNG',
    type: 'LNG Terminal',
    operator: 'National Grid LNG',
    latitude: 51.4,
    longitude: 0.7,
    utilisationPercent: 55,
    annualThroughput: '20.0 Bcm/year',
    estimatedValueGbp: 4800000000,
    maintenanceSchedule: 'Nov 12 - Nov 15, 2026',
    description: 'Southeastern LNG hub serving London and surrounding markets with extensive thermal storage capacity.',
    irr: 10.9,
    remainingLifeYears: 40,
    maintenanceRisk: 'Low',
    carbonExposure: 'Low',
    assetScore: 90
  },
  // STORAGE FACILITIES
  {
    id: 'store_rough',
    name: 'Rough Gas Storage (Offshore)',
    type: 'Storage Facility',
    operator: 'Centrica Storage',
    latitude: 53.8,
    longitude: 1.1,
    utilisationPercent: 86,
    annualThroughput: '1.6 Bcm capacity',
    estimatedValueGbp: 2200000000,
    maintenanceSchedule: 'Jun 10 - Jun 30, 2026 (Completed)',
    description: 'Depleted offshore gas reservoir repurposed for strategic seasonal buffering. Core energy security anchor.',
    irr: 15.1,
    remainingLifeYears: 15,
    maintenanceRisk: 'Medium',
    carbonExposure: 'Medium',
    assetScore: 95
  },
  {
    id: 'store_aldbrough',
    name: 'Aldbrough Gas Storage (Salt Caverns)',
    type: 'Storage Facility',
    operator: 'SSE Thermal / Equinor',
    latitude: 53.8,
    longitude: -0.1,
    utilisationPercent: 78,
    annualThroughput: '0.33 Bcm working volume',
    estimatedValueGbp: 1400000000,
    maintenanceSchedule: 'None planned',
    description: 'High-deliverability onshore salt caverns allowing rapid injection and fast-cycle market stabilization.',
    irr: 12.2,
    remainingLifeYears: 45,
    maintenanceRisk: 'Low',
    carbonExposure: 'Low',
    assetScore: 88
  },
  // REFINERIES
  {
    id: 'ref_fawley',
    name: 'Fawley Refinery',
    type: 'Refinery',
    operator: 'ExxonMobil',
    latitude: 50.8,
    longitude: -1.3,
    utilisationPercent: 91,
    annualThroughput: '270,000 barrels/day',
    estimatedValueGbp: 5800000000,
    maintenanceSchedule: 'Mar 10 - Apr 20, 2027',
    description: 'The largest oil refinery in the United Kingdom, producing chemical feedstocks and transport fuels.',
    irr: 11.2,
    remainingLifeYears: 20,
    maintenanceRisk: 'Medium',
    carbonExposure: 'High',
    assetScore: 68
  },
  // POWER STATIONS
  {
    id: 'power_pembroke',
    name: 'Pembroke CCGT Power Station',
    type: 'Power Station',
    operator: 'RWE Generation',
    latitude: 51.6,
    longitude: -4.9,
    utilisationPercent: 62,
    annualThroughput: '2,200 MW capacity',
    estimatedValueGbp: 2100000000,
    maintenanceSchedule: 'Oct 15 - Nov 05, 2026',
    description: 'Highly efficient Combined Cycle Gas Turbine generating enough electricity to power 4 million homes.',
    irr: 12.5,
    remainingLifeYears: 22,
    maintenanceRisk: 'Low',
    carbonExposure: 'High',
    assetScore: 74
  }
];

// ==========================================
// MODULE 5: STORAGE INTEL
// ==========================================
export const storageFacilitiesData: StorageFacility[] = [
  {
    id: 'store_rough',
    name: 'Rough (Offshore Reservoir)',
    operator: 'Centrica Storage',
    type: 'Long-Term',
    capacityMcm: 1600,
    currentInventoryMcm: 1376,
    injectionRateMcm: 15,
    withdrawalRateMcm: 22,
    utilisationPercent: 86,
    daysOfSupplyRemaining: 62,
    estimatedValueGbp: 2200000000,
    maintenanceStatus: 'Operational'
  },
  {
    id: 'store_aldbrough',
    name: 'Aldbrough (Onshore Caverns)',
    operator: 'SSE Thermal / Equinor',
    type: 'Medium-Term',
    capacityMcm: 330,
    currentInventoryMcm: 254,
    injectionRateMcm: 20,
    withdrawalRateMcm: 40,
    utilisationPercent: 77,
    daysOfSupplyRemaining: 6,
    estimatedValueGbp: 1400000000,
    maintenanceStatus: 'Operational'
  },
  {
    id: 'store_holford',
    name: 'Holford (Salt Caverns)',
    operator: 'Uniper Energy',
    type: 'Short-Term',
    capacityMcm: 260,
    currentInventoryMcm: 213,
    injectionRateMcm: 18,
    withdrawalRateMcm: 32,
    utilisationPercent: 82,
    daysOfSupplyRemaining: 7,
    estimatedValueGbp: 1100000000,
    maintenanceStatus: 'Operational'
  },
  {
    id: 'store_stublach',
    name: 'Stublach (Salt Caverns)',
    operator: 'Storengy (ENGIE)',
    type: 'Short-Term',
    capacityMcm: 400,
    currentInventoryMcm: 328,
    injectionRateMcm: 24,
    withdrawalRateMcm: 44,
    utilisationPercent: 82,
    daysOfSupplyRemaining: 7,
    estimatedValueGbp: 1650000000,
    maintenanceStatus: 'Operational'
  },
  {
    id: 'store_grain_lng',
    name: 'Grain LNG Peak Storage',
    operator: 'National Grid',
    type: 'LNG Tank',
    capacityMcm: 120,
    currentInventoryMcm: 96,
    injectionRateMcm: 5,
    withdrawalRateMcm: 15,
    utilisationPercent: 80,
    daysOfSupplyRemaining: 6,
    estimatedValueGbp: 950000000,
    maintenanceStatus: 'Operational'
  }
];

// ==========================================
// MODULE 7: PIPELINES
// ==========================================
export const pipelinesData: PipelineFlow[] = [
  {
    id: 'pipe_langeled',
    name: 'Langeled North Sea Pipeline',
    source: 'Nyhamna (Norway)',
    destination: 'Easington Gas Terminal',
    capacityMcm: 74,
    currentFlowMcm: 65,
    utilisationPercent: 88,
    maintenanceStatus: 'Operational',
    pressureBarg: 142
  },
  {
    id: 'pipe_vesterled',
    name: 'Vesterled Pipeline',
    source: 'Heimdal (Norway)',
    destination: 'St Fergus Terminal',
    capacityMcm: 36,
    currentFlowMcm: 31,
    utilisationPercent: 86,
    maintenanceStatus: 'Operational',
    pressureBarg: 135
  },
  {
    id: 'pipe_bbl',
    name: 'BBL Interconnector',
    source: 'Bacton (UK)',
    destination: 'Balgzand (Netherlands)',
    capacityMcm: 42,
    currentFlowMcm: -12, // Negative shows export from UK
    utilisationPercent: 28,
    maintenanceStatus: 'Operational',
    pressureBarg: 68
  },
  {
    id: 'pipe_iuk',
    name: 'IUK Interconnector',
    source: 'Bacton (UK)',
    destination: 'Zeebrugge (Belgium)',
    capacityMcm: 54,
    currentFlowMcm: -15, // Negative shows export from UK
    utilisationPercent: 27,
    maintenanceStatus: 'Operational',
    pressureBarg: 72
  },
  {
    id: 'pipe_scotland_ni',
    name: 'SNIP (Scotland to Northern Ireland)',
    source: 'Twynholm (Scotland)',
    destination: 'Ballylumford (NI)',
    capacityMcm: 8,
    currentFlowMcm: 5.2,
    utilisationPercent: 65,
    maintenanceStatus: 'Operational',
    pressureBarg: 64
  },
  {
    id: 'pipe_moyle',
    name: 'Moyle Interconnector (Power)',
    source: 'Scotland',
    destination: 'Northern Ireland',
    capacityMcm: 12,
    currentFlowMcm: 10,
    utilisationPercent: 83,
    maintenanceStatus: 'Operational',
    pressureBarg: 0 // Not applicable
  }
];

// ==========================================
// MODULE 9: FORECAST DATA SAMPLES
// ==========================================
export const forecastDemandData = (): ForecastData[] => {
  const data: ForecastData[] = [];
  const baseDate = new Date(2026, 6, 25); // Mid Summer 2026
  
  // 15 days historical
  for (let i = 15; i > 0; i--) {
    const date = new Date(baseDate);
    date.setDate(baseDate.getDate() - i);
    const demand = 160 + Math.sin(i / 3) * 12 + Math.random() * 6;
    data.push({
      date: date.toISOString().split('T')[0],
      actualDemand: Math.round(demand),
      arimaDemand: Math.round(demand + Math.random() * 2),
      prophetDemand: Math.round(demand - Math.random() * 1.5),
      expSmoothingDemand: Math.round(demand + Math.random() * 1),
      scenarioOptimistic: Math.round(demand),
      scenarioPessimistic: Math.round(demand)
    });
  }
  
  // 15 days future forecasts
  for (let i = 0; i <= 20; i++) {
    const date = new Date(baseDate);
    date.setDate(baseDate.getDate() + i);
    // Base wintering forecast starts modeling an upward drift towards autumn
    const arima = 162 + (i * 0.8) + Math.sin(i / 4) * 10;
    const prophet = 160 + (i * 0.75) + Math.cos(i / 5) * 8;
    const expSmooth = 163 + (i * 0.6) + Math.sin(i / 3) * 6;
    
    data.push({
      date: date.toISOString().split('T')[0],
      arimaDemand: Math.round(arima),
      prophetDemand: Math.round(prophet),
      expSmoothingDemand: Math.round(expSmooth),
      scenarioOptimistic: Math.round(prophet * 0.88), // Lower demand scenario
      scenarioPessimistic: Math.round(arima * 1.15) // High demand cold-snap scenario
    });
  }
  return data;
};

// ==========================================
// MODULE 11: ELLAN VANNIN WEALTH PORTFOLIO
// ==========================================
export const portfolioHoldings: PortfolioAsset[] = [
  {
    id: 'port_rough_equity',
    name: 'Centrica Storage Ltd (Rough Holding)',
    type: 'Equity',
    allocatedCapitalGbp: 450000000,
    currentValuationGbp: 525000000,
    irrAchieved: 14.8,
    annualCashFlowGbp: 38000000,
    holdingPercent: 12.5,
    riskRating: 'AA'
  },
  {
    id: 'port_clair_jv',
    name: 'Clair Field Infrastructure JV',
    type: 'Infrastructure Joint Venture',
    allocatedCapitalGbp: 380000000,
    currentValuationGbp: 420000000,
    irrAchieved: 16.2,
    annualCashFlowGbp: 45000000,
    holdingPercent: 4.5,
    riskRating: 'A'
  },
  {
    id: 'port_uk_gilt_2040',
    name: 'UK Sovereign Green Gilt (2040)',
    type: 'Sovereign Debt',
    allocatedCapitalGbp: 250000000,
    currentValuationGbp: 242000000,
    irrAchieved: 4.2,
    annualCashFlowGbp: 10500000,
    holdingPercent: 0.8,
    riskRating: 'AAA'
  },
  {
    id: 'port_sse_bond_2035',
    name: 'SSE Thermal Infrastructure Bond (4.85%)',
    type: 'Corporate Bond',
    allocatedCapitalGbp: 150000000,
    currentValuationGbp: 154000000,
    irrAchieved: 5.1,
    annualCashFlowGbp: 7275000,
    holdingPercent: 2.3,
    riskRating: 'AA'
  },
  {
    id: 'port_south_hook_jv',
    name: 'South Hook LNG Regasification Unit B',
    type: 'Infrastructure Joint Venture',
    allocatedCapitalGbp: 320000000,
    currentValuationGbp: 375000000,
    irrAchieved: 12.9,
    annualCashFlowGbp: 31000000,
    holdingPercent: 8.0,
    riskRating: 'AA'
  }
];

// ==========================================
// SOURCE CODE FILES FOR MODULE 13 & 14 (R & Rust)
// ==========================================

export const rSourceCode = `## =========================================================================
## NORTHSTAR MARKET™ - R Shiny Executive Commodity Dashboard
## Client: Ellan Vannin Wealth Management
## Language: R (Analytics) - shiny, tidyverse, data.table, plotly, leaflet, forecast
## =========================================================================

library(shiny)
library(tidyverse)
library(data.table)
library(plotly)
library(leaflet)
library(sf)
library(forecast)
library(xts)

## Institutional Styling Palette (Matte Graphite & Brass)
THEME_BG <- "#1A1A1A"
THEME_CARD <- "#262626"
THEME_ACCENT_BRASS <- "#C5A880"
THEME_GREEN_EMERALD <- "#10B981"
THEME_AMBER_WARNING <- "#F59E0B"
THEME_RED_CRIMSON <- "#EF4444"

## Load Simulated Ingestion pipeline
load_operational_data <- function() {
  ## Real-world connection script placeholder:
  ## read_csv("https://api.nationalgas.com/data/v1/flow-summary.csv")
  
  dt <- data.table(
    timestamp = seq(Sys.time() - 86400 * 30, Sys.time(), by = "3600"),
    nbp_spot = rnorm(721, mean = 80, sd = 3),
    norwegian_import = rnorm(721, mean = 65, sd = 4),
    lng_import = rnorm(721, mean = 45, sd = 5),
    domestic_production = rnorm(721, mean = 85, sd = 2),
    total_demand = rnorm(721, mean = 180, sd = 10)
  )
  return(dt)
}

ui <- fluidPage(
  theme = shinytheme("superhero"),
  tags$head(
    tags$style(HTML(paste0("
      body { background-color: ", THEME_BG, "; color: #E5E5E5; font-family: 'Plus Jakarta Sans', sans-serif; }
      .navbar { background-color: ", THEME_CARD, "; border-color: ", THEME_ACCENT_BRASS, "; }
      .card-panel { background-color: ", THEME_CARD, "; border: 1px solid #333; padding: 20px; margin-bottom: 20px; border-radius: 4px; }
      .text-brass { color: ", THEME_ACCENT_BRASS, "; }
      .metric-value { font-size: 28px; font-weight: bold; color: #FFFFFF; }
      .positive { color: ", THEME_GREEN_EMERALD, "; }
      .negative { color: ", THEME_RED_CRIMSON, "; }
    ")))
  ),
  
  navbarPage(
    title = "NORTHSTAR MARKET™ | EVWM",
    tabPanel("Executive Overview",
      fluidRow(
        column(3, div(class = "card-panel",
          h4("NBP Spot Gas", class = "text-brass"),
          div(class = "metric-value", "78.2 p/th"),
          span(class = "positive", "▲ +1.4% Day-Ahead")
        )),
        column(3, div(class = "card-panel",
          h4("Brent Crude Oil", class = "text-brass"),
          div(class = "metric-value", "$74.50/bbl"),
          span(class = "negative", "▼ -0.8% Weekly Trend")
        )),
        column(3, div(class = "card-panel",
          h4("Import Dependency", class = "text-brass"),
          div(class = "metric-value", "58.4%"),
          span(class = "positive", "Stable supply routing")
        )),
        column(3, div(class = "card-panel",
          h4("Energy Security Index", class = "text-brass"),
          div(class = "metric-value", "84 / 100"),
          span(class = "positive", "Status: SECURE")
        ))
      ),
      fluidRow(
        column(8, div(class = "card-panel",
          h3("UK Supply-Demand Balance Stream", class = "text-brass"),
          plotlyOutput("supplyDemandChart")
        )),
        column(4, div(class = "card-panel",
          h3("National Transmission System", class = "text-brass"),
          leafletOutput("infrastructureMap", height = "400px")
        ))
      )
    ),
    
    tabPanel("Forecasting (ARIMA Engine)",
      sidebarLayout(
        sidebarPanel(
          style = paste0("background-color: ", THEME_CARD, "; border: none;"),
          sliderInput("horizon", "Forecast Horizon (Days)", min = 5, max = 30, value = 14),
          selectInput("model_type", "Model Selection", choices = c("Auto-ARIMA", "Exponential Smoothing (ETS)", "Prophet")),
          actionButton("run_model", "Execute Quantitative Engine", class = "btn-warning")
        ),
        mainPanel(
          div(class = "card-panel",
            h3("Forecasting Model Projections (mcm/d)", class = "text-brass"),
            plotlyOutput("forecastChart")
          )
        )
      )
    )
  )
)

server <- function(input, output, session) {
  data <- reactive({ load_operational_data() })
  
  output$supplyDemandChart <- renderPlotly({
    dt <- data()
    p <- ggplot(dt, aes(x = timestamp)) +
      geom_line(aes(y = norwegian_import + lng_import + domestic_production, color = "Total Supply"), size = 1) +
      geom_line(aes(y = total_demand, color = "Total Demand"), size = 1, linetype = "dashed") +
      scale_color_manual(values = c("Total Supply" = THEME_ACCENT_BRASS, "Total Demand" = THEME_RED_CRIMSON)) +
      theme_minimal() +
      labs(y = "Flow Rate (mcm/d)", x = "Timestamp") +
      theme(
        panel.background = element_rect(fill = THEME_CARD, color = NA),
        plot.background = element_rect(fill = THEME_CARD, color = NA),
        text = element_text(color = "#FFFFFF")
      )
    ggplotly(p)
  })
  
  output$infrastructureMap <- renderLeaflet({
    leaflet() %>%
      addProviderTiles(providers$CartoDB.DarkMatter) %>%
      setView(lng = -1.5, lat = 54.5, zoom = 5) %>%
      addCircleMarkers(lng = -1.8, lat = 57.5, label = "St Fergus Terminal", color = THEME_ACCENT_BRASS, radius = 8) %>%
      addCircleMarkers(lng = 1.1, lat = 53.8, label = "Rough Offshore Storage", color = THEME_GREEN_EMERALD, radius = 10) %>%
      addCircleMarkers(lng = -5.0, lat = 51.7, label = "South Hook LNG Terminal", color = "#60A5FA", radius = 9)
  })
  
  output$forecastChart <- renderPlotly({
    ## Pull ts
    dt <- data()
    demand_ts <- ts(dt$total_demand, frequency = 24)
    fit <- auto.arima(demand_ts)
    fore <- forecast(fit, h = input$horizon * 24)
    
    fore_df <- data.frame(
      time = seq(length(fore$mean)),
      mean = as.numeric(fore$mean),
      upper = as.numeric(fore$upper[,2]),
      lower = as.numeric(fore$lower[,2])
    )
    
    p <- ggplot(fore_df, aes(x = time)) +
      geom_ribbon(aes(ymin = lower, ymax = upper), fill = THEME_ACCENT_BRASS, alpha = 0.2) +
      geom_line(aes(y = mean), color = THEME_ACCENT_BRASS, size = 1) +
      labs(title = "Auto-ARIMA 95% Confidence Band Interval", y = "Forecast Demand (mcm/d)") +
      theme_minimal() +
      theme_dark()
    ggplotly(p)
  })
}

shinyApp(ui = ui, server = server)
`;

export const rustSourceCode = `// =========================================================================
// NORTHSTAR MARKET™ - Real-Time Ingestion & Analytics Pipeline Backend
// Client: Ellan Vannin Wealth Management
// Language: Rust - Tokio, Axum, Serde, Polars, SQLx
// =========================================================================

use axum::{
    routing::{get, post},
    Json, Router, Extension,
};
use serde::{Serialize, Deserialize};
use tokio::sync::RwLock;
use std::sync::Arc;
use polars::prelude::*;
use chrono::{DateTime, Utc};

// Institutional Assets Definition
#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Asset {
    pub id: String,
    pub name: String,
    pub asset_type: String,
    pub operator: String,
    pub capacity_mcm: f64,
    pub utilisation_percent: f64,
    pub valuation_gbp: u64,
}

// Ingestion Payload
#[derive(Debug, Deserialize, Clone)]
pub struct SpotMarketTick {
    pub timestamp: DateTime<Utc>,
    pub nbp_spot_pence: f64,
    pub brent_crude_usd: f64,
    pub supply_total_mcm: f64,
    pub demand_total_mcm: f64,
}

// Global System Shared State
pub struct SystemState {
    pub assets: Vec<Asset>,
    pub historical_ticks: Vec<SpotMarketTick>,
}

#[tokio::main]
async fn main() {
    println!("Initializing NORTHSTAR MARKET™ Systems Backend Core...");
    
    // Seed initial operational assets
    let initial_assets = vec![
        Asset {
            id: "store_rough".to_string(),
            name: "Rough Gas Storage".to_string(),
            asset_type: "Storage Facility".to_string(),
            operator: "Centrica Storage".to_string(),
            capacity_mcm: 1600.0,
            utilisation_percent: 86.4,
            valuation_gbp: 2200000000,
        },
        Asset {
            id: "term_st_fergus".to_string(),
            name: "St Fergus Gas Terminal".to_string(),
            asset_type: "Gas Terminal".to_string(),
            operator: "National Grid".to_string(),
            capacity_mcm: 120.0,
            utilisation_percent: 64.2,
            valuation_gbp: 3200000000,
        }
    ];

    let state = Arc::new(RwLock::new(SystemState {
        assets: initial_assets,
        historical_ticks: Vec::new(),
    }));

    // Setup Routing with CORS & Shared Arc State
    let app = Router::new()
        .route("/api/health", get(health_check))
        .route("/api/assets", get(get_assets))
        .route("/api/assets/score", post(calculate_asset_risk_scores))
        .route("/api/market/tick", post(ingest_market_tick))
        .layer(Extension(state));

    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000")
        .await
        .expect("Failed to bind to TCP address");
        
    println!("NORTHSTAR Live Core Listening on: http://0.0.0.0:3000");
    axum::serve(listener, app).await.expect("Axum engine termination failure");
}

// Health check endpoint
async fn health_check() -> &'static str {
    "NORTHSTAR CORE OK - DATABASE CONNECTED - OVERSIGHT INGESTION ONLINE"
}

// Get managed assets
async fn get_assets(Extension(state): Extension<Arc<RwLock<SystemState>>>) -> Json<Vec<Asset>> {
    let read_state = state.read().await;
    Json(read_state.assets.clone())
}

// Real-Time Ingest Pipeline Endpoint
async fn ingest_market_tick(
    Extension(state): Extension<Arc<RwLock<SystemState>>>,
    Json(payload): Json<SpotMarketTick>
) -> Json<serde_json::Value> {
    let mut write_state = state.write().await;
    write_state.historical_ticks.push(payload.clone());
    
    println!("Tick Ingested: NBP Gas {} p/th, Brent Crude USD {}", payload.nbp_spot_pence, payload.brent_crude_usd);
    
    // Auto-alert check (Module 6 Supply-Demand Balance Engine)
    let margin = payload.supply_total_mcm - payload.demand_total_mcm;
    let alert_triggered = margin < 10.0; // Trigger alert when margin < 10 mcm/d
    
    Json(serde_json::into_value(serde_json::json!({
        "status": "INGESTED",
        "margin": margin,
        "critical_alert": alert_triggered
    })).unwrap())
}

// Quantitative Risk Engine using Polars for high-performance Vectorized computation
async fn calculate_asset_risk_scores(
    Extension(state): Extension<Arc<RwLock<SystemState>>>,
    Json(risk_params): Json<serde_json::Value>
) -> Json<serde_json::Value> {
    let read_state = state.read().await;
    
    // Create Polars Series
    let names: Vec<String> = read_state.assets.iter().map(|a| a.name.clone()).collect();
    let utilisations: Vec<f64> = read_state.assets.iter().map(|a| a.utilisation_percent).collect();
    
    let s_names = Series::new("name".into(), names);
    let s_util = Series::new("utilisation".into(), utilisations);
    
    let dfResult = DataFrame::new(vec![s_names, s_util]).unwrap();
    
    // Calculate custom analytical stress coefficient: (Utilisation * 1.15)
    let stress_modifier = dfResult.column("utilisation").unwrap().f64().unwrap() * 1.15;
    
    println!("Polars analytical vectors successfully generated for asset score simulation");
    
    Json(serde_json::json!({
        "calculated_on": Utc::now().to_rfc3339(),
        "polars_dataframe_rows": dfResult.height(),
        "stress_scores_sample": stress_modifier.into_iter().collect::<Vec<Option<f64>>>()
    }))
}
`;

export const postgresSchema = `-- =========================================================================
-- NORTHSTAR MARKET™ - Sovereign-Grade PostgreSQL Database Schema
-- Client: Ellan Vannin Wealth Management
-- Purpose: Schema supporting persistent live flows, asset indices, and financial ledgers
-- =========================================================================

CREATE DATABASE northstar_energy;
\\c northstar_energy;

-- 1. Institutional Asset Registry
CREATE TABLE assets (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    asset_type VARCHAR(50) NOT NULL,
    operator VARCHAR(100) NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    annual_throughput VARCHAR(100),
    estimated_value_gbp NUMERIC(15, 2) NOT NULL,
    maintenance_schedule VARCHAR(200),
    remaining_life_years INT NOT NULL,
    irr_target NUMERIC(5, 2) NOT NULL,
    asset_score INT CHECK (asset_score BETWEEN 0 AND 100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Real-time Market Ticks
CREATE TABLE market_prices (
    tick_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    nbp_spot NUMERIC(6, 2) NOT NULL, -- pence per therm
    day_ahead NUMERIC(6, 2) NOT NULL,
    month_ahead NUMERIC(6, 2) NOT NULL,
    seasonal_forward NUMERIC(6, 2) NOT NULL,
    brent_crude NUMERIC(6, 2) NOT NULL, -- USD per barrel
    uk_carbon NUMERIC(6, 2) NOT NULL, -- GBP per tonne
    electricity_price NUMERIC(6, 2) NOT NULL, -- GBP/MWh
    PRIMARY KEY (tick_time)
);

-- 3. Pipeline Flow Logging
CREATE TABLE pipeline_flows (
    flow_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    pipeline_id VARCHAR(50) REFERENCES assets(id) ON DELETE CASCADE,
    current_flow_mcm NUMERIC(6, 2) NOT NULL,
    utilisation_percent NUMERIC(5, 2) NOT NULL,
    pressure_barg NUMERIC(5, 2) NOT NULL,
    PRIMARY KEY (flow_time, pipeline_id)
);

-- 4. Storage Facility Overwatches
CREATE TABLE storage_status (
    status_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    facility_id VARCHAR(50) REFERENCES assets(id) ON DELETE CASCADE,
    current_inventory_mcm NUMERIC(8, 2) NOT NULL,
    injection_rate_mcm NUMERIC(6, 2) NOT NULL,
    withdrawal_rate_mcm NUMERIC(6, 2) NOT NULL,
    days_of_supply INT NOT NULL,
    PRIMARY KEY (status_time, facility_id)
);

-- 5. Ellan Vannin Wealth Management Portfolio Ledger
CREATE TABLE portfolio_holdings (
    id VARCHAR(50) PRIMARY KEY,
    asset_id VARCHAR(50) REFERENCES assets(id),
    name VARCHAR(100) NOT NULL,
    allocated_capital NUMERIC(15, 2) NOT NULL,
    current_valuation NUMERIC(15, 2) NOT NULL,
    irr_achieved NUMERIC(5, 2) NOT NULL,
    annual_cash_flow NUMERIC(15, 2) NOT NULL,
    holding_percent NUMERIC(5, 2) NOT NULL,
    risk_rating VARCHAR(5) NOT NULL,
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indices for performance optimisation on Polars/SQLx aggregation
CREATE INDEX idx_market_prices_time ON market_prices(tick_time DESC);
CREATE INDEX idx_pipeline_flows_time ON pipeline_flows(flow_time DESC, pipeline_id);
CREATE INDEX idx_storage_status_time ON storage_status(status_time DESC, facility_id);
`;
