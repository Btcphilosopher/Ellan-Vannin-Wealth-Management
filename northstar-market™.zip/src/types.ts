/**
 * NORTHSTAR MARKET™ - Type Definitions
 * Professional commodity market and sovereign-grade infrastructure investment types.
 */

export interface MarketPrice {
  date: string;
  nbpSpot: number;     // pence per therm (p/th)
  dayAhead: number;    // p/th
  monthAhead: number;  // p/th
  seasonalForward: number; // p/th
  brentCrude: number;  // USD/bbl
  ukCarbon: number;    // GBP/tCO2e
  electricityPrice: number; // GBP/MWh
}

export interface SupplyData {
  domesticGas: number;       // mcm/d (million cubic meters per day)
  domesticOil: number;       // kbd (thousand barrels per day)
  condensates: number;       // kbd
  norwayPipelines: number;   // mcm/d
  lngImports: number;        // mcm/d
  interconnectorBBL: number; // mcm/d (Belgium)
  interconnectorIUK: number; // mcm/d (Netherlands)
  gasExports: number;        // mcm/d
  oilExports: number;        // kbd
  
  // Computed
  domesticSupplyGasPercent: number;
  importDependencyPercent: number;
  exportRatio: number;
}

export interface DemandData {
  residential: number;      // mcm/d
  industrial: number;       // mcm/d
  powerGen: number;         // mcm/d
  commercial: number;       // mcm/d
  storageInjection: number; // mcm/d
  exports: number;          // mcm/d
  weatherAdjusted: number;  // mcm/d
  peakForecast: number;     // mcm/d
}

export interface StorageFacility {
  id: string;
  name: string;
  operator: string;
  type: 'Long-Term' | 'Medium-Term' | 'Short-Term' | 'LNG Tank';
  capacityMcm: number;
  currentInventoryMcm: number;
  injectionRateMcm: number;
  withdrawalRateMcm: number;
  utilisationPercent: number;
  daysOfSupplyRemaining: number;
  estimatedValueGbp: number;
  maintenanceStatus: 'Operational' | 'Scheduled Maintenance' | 'Unscheduled Outage';
}

export interface InfrastructureAsset {
  id: string;
  name: string;
  type: 'Offshore Field' | 'Gas Terminal' | 'LNG Terminal' | 'Pipeline Hub' | 'Storage Facility' | 'Refinery' | 'Power Station' | 'Port';
  operator: string;
  latitude: number;  // For UK projection
  longitude: number; // For UK projection
  utilisationPercent: number;
  annualThroughput: string;
  estimatedValueGbp: number;
  maintenanceSchedule: string;
  description: string;
  
  // Financial metrics (Module 10)
  irr: number;
  remainingLifeYears: number;
  maintenanceRisk: 'Low' | 'Medium' | 'High';
  carbonExposure: 'Low' | 'Medium' | 'High';
  assetScore: number; // 0-100 rating
}

export interface BalanceSheet {
  domesticGas: number;
  pipelineImports: number;
  lngImports: number;
  storageWithdrawal: number;
  availableSupply: number;
  
  residentialDemand: number;
  industrialDemand: number;
  powerDemand: number;
  exportsDemand: number;
  storageInjection: number;
  totalDemand: number;
  
  supplyMargin: number;    // Available Supply - Total Demand
  marketBalance: number;   // mcm/d
  systemStressLevel: 'Normal' | 'Elevated' | 'Critical';
}

export interface PipelineFlow {
  id: string;
  name: string;
  source: string;
  destination: string;
  capacityMcm: number;
  currentFlowMcm: number;
  utilisationPercent: number;
  maintenanceStatus: 'Operational' | 'Alert' | 'Maintenance';
  pressureBarg: number;
  outageDescription?: string;
}

export interface EnergySecurityMetric {
  indexScore: number; // 0 - 100
  importDependency: number;
  northSeaTrend: 'Rising' | 'Stable' | 'Declining';
  lngDiversification: number; // Herfindahl-Hirschman Index (HHI) or score
  storageResilienceDays: number;
  supplyDiversityScore: number;
  status: 'Secure' | 'Vulnerable' | 'Critical';
}

export interface ForecastData {
  date: string;
  actualDemand?: number;
  arimaDemand: number;
  prophetDemand: number;
  expSmoothingDemand: number;
  scenarioOptimistic: number;
  scenarioPessimistic: number;
}

export interface PortfolioAsset {
  id: string;
  name: string;
  type: 'Equity' | 'Infrastructure Joint Venture' | 'Sovereign Debt' | 'Corporate Bond';
  allocatedCapitalGbp: number;
  currentValuationGbp: number;
  irrAchieved: number;
  annualCashFlowGbp: number;
  holdingPercent: number;
  riskRating: 'A' | 'AA' | 'AAA' | 'BBB';
}
