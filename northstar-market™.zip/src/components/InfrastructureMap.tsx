import { useState, useMemo } from 'react';
import { infrastructureAssets } from '../data';
import { InfrastructureAsset } from '../types';
import { Shield, MapPin, Layers, Briefcase, Percent, Anchor, ChevronRight, Activity, TrendingUp, DollarSign } from 'lucide-react';

export default function InfrastructureMap() {
  const [selectedAssetId, setSelectedAssetId] = useState<string>('term_st_fergus');
  const [filterType, setFilterType] = useState<string>('All');

  const selectedAsset = useMemo(() => {
    return infrastructureAssets.find(a => a.id === selectedAssetId) || infrastructureAssets[0];
  }, [selectedAssetId]);

  const filteredAssets = useMemo(() => {
    if (filterType === 'All') return infrastructureAssets;
    return infrastructureAssets.filter(a => a.type === filterType);
  }, [filterType]);

  // Types of assets to filter by
  const assetTypes = ['All', 'Offshore Field', 'Gas Terminal', 'LNG Terminal', 'Storage Facility', 'Refinery', 'Power Station'];

  // Scale coordinates to fit into our 400x550 SVG map container beautifully
  // UK is roughly Lat 50 to 61 North, Lon -8 to 2 East
  // We can convert these to X,Y coordinate percentages
  const getCoords = (lat: number, lon: number) => {
    const minLat = 49.5;
    const maxLat = 61.5;
    const minLon = -9.0;
    const maxLon = 3.0;

    const x = ((lon - minLon) / (maxLon - minLon)) * 100;
    // Invert Y because SVG coordinates start from top-left
    const y = 100 - (((lat - minLat) / (maxLat - minLat)) * 100);
    
    return { x: `${x}%`, y: `${y}%` };
  };

  return (
    <div id="infrastructure_map_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 04 // GIS Geospatial Overview</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">National Infrastructure Map</h2>
        </div>
        
        {/* Filter buttons */}
        <div className="flex flex-wrap gap-1 mt-4 md:mt-0">
          {assetTypes.map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-2.5 py-1 text-[10px] font-bold rounded transition border ${
                filterType === type
                  ? 'bg-[#C5A059] text-[#121212] border-[#C5A059]'
                  : 'text-[#8E9299] border-[#2A2C2E] hover:text-white'
              }`}
            >
              {type === 'All' ? 'All Assets' : type}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* SVG Interactive GIS Map */}
        <div className="lg:col-span-6 bg-[#111315] rounded-lg border border-[#2A2C2E] p-4 flex flex-col justify-between relative overflow-hidden h-[540px]">
          {/* Compass / Legend */}
          <div className="absolute top-4 left-4 z-10 bg-[#1A1C1E]/90 p-3 rounded border border-[#2A2C2E] text-[10px] space-y-1">
            <div className="text-white font-bold uppercase tracking-wider mb-1 flex items-center">
              <Shield className="h-3 w-3 text-[#C5A059] mr-1" /> Grid Indicators
            </div>
            <div className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#C5A059] mr-2 inline-block"></span> Gas Terminal</div>
            <div className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#10B981] mr-2 inline-block"></span> Storage Hub</div>
            <div className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#3B82F6] mr-2 inline-block"></span> LNG Regas</div>
            <div className="flex items-center"><span className="w-2 h-2 rounded-full bg-[#EF4444] mr-2 inline-block"></span> Oil Field / Refinery</div>
          </div>

          <div className="absolute top-4 right-4 z-10 text-[10px] bg-[#1A1C1E]/90 px-2 py-1 rounded border border-[#2A2C2E] font-mono text-[#8E9299]">
            PROJ: WGS-84 / UK Grid
          </div>

          {/* Styled GIS SVG Viewport */}
          <div className="w-full h-full flex items-center justify-center relative">
            <svg viewBox="0 0 400 550" className="w-full h-full max-h-[480px]">
              {/* Coastline Path representation */}
              {/* Great Britain general outline */}
              <path 
                d="M 120 480 Q 110 460 120 440 T 140 400 T 150 350 T 140 310 T 130 260 T 150 200 T 160 150 T 145 100 T 165 70 T 195 50 T 190 110 T 175 140 T 210 170 T 235 220 T 240 270 T 265 310 T 250 340 T 260 380 T 285 410 T 270 450 T 230 465 T 190 470 T 150 490 Z" 
                fill="#1E2022" 
                stroke="#2A2C2E" 
                strokeWidth="1.5" 
              />
              {/* Ireland coast preview */}
              <path 
                d="M 60 380 Q 50 320 60 280 T 80 230 T 95 190 T 70 170 T 50 210 T 40 280 T 45 340 Z" 
                fill="#141618" 
                stroke="#222" 
                strokeWidth="1" 
                strokeDasharray="2 2"
              />
              
              {/* Maritime Boundaries */}
              <line x1="210" y1="50" x2="250" y2="480" stroke="#C5A059" strokeWidth="0.5" strokeDasharray="5 5" opacity="0.3" />
              <text x="260" y="240" fill="#C5A059" fontSize="8" opacity="0.4" transform="rotate(75, 260, 240)">UK / NORWAY BOUNDARY LINE</text>

              {/* Major Maritime Pipelines (Sleipner / Langeled) */}
              <path d="M 330 120 L 265 310" stroke="#334155" strokeWidth="1.5" strokeDasharray="3 3" />
              <path d="M 230 80 L 175 140" stroke="#334155" strokeWidth="1.5" strokeDasharray="3 3" />

              {/* Interactive Asset Node Markers */}
              {filteredAssets.map((asset) => {
                const { x, y } = getCoords(asset.latitude, asset.longitude);
                const isSelected = asset.id === selectedAssetId;
                
                let markerColor = '#C5A059';
                if (asset.type === 'Storage Facility') markerColor = '#10B981';
                else if (asset.type === 'LNG Terminal') markerColor = '#3B82F6';
                else if (asset.type === 'Offshore Field') markerColor = '#EF4444';
                else if (asset.type === 'Refinery' || asset.type === 'Power Station') markerColor = '#8B5CF6';

                return (
                  <g 
                    key={asset.id} 
                    className="cursor-pointer" 
                    onClick={() => setSelectedAssetId(asset.id)}
                  >
                    {/* Ring highlight if selected */}
                    {isSelected && (
                      <circle cx={x} cy={y} r="12" fill="none" stroke={markerColor} strokeWidth="1.5" className="animate-ping" style={{ transformOrigin: `${x} ${y}` }} />
                    )}
                    <circle 
                      cx={x} 
                      cy={y} 
                      r={isSelected ? '7' : '5'} 
                      fill={markerColor} 
                      stroke="#111315" 
                      strokeWidth="1.5" 
                      className="transition-all duration-300 hover:scale-150"
                    />
                    
                    {/* Tiny text label for critical terminals */}
                    {asset.type === 'Gas Terminal' && (
                      <text x={x} y={parseFloat(y) - 8 + '%'} fill="#FFF" fontSize="6" textAnchor="middle" opacity="0.6">
                        {asset.name.split(' ')[0]}
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          <div className="text-center text-[10px] text-[#8E9299] border-t border-[#2A2C2E]/50 pt-2">
            Click on any highlighted infrastructure node to retrieve high-fidelity telemetry.
          </div>
        </div>

        {/* Bloomberg-Style Asset Report Panel */}
        <div className="lg:col-span-6 bg-[#1A1C1E] border border-[#2A2C2E] p-6 rounded-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-[#2A2C2E] pb-4 mb-4">
              <div>
                <span className="text-[10px] font-bold text-[#C5A059] tracking-wider uppercase">{selectedAsset.type} Telemetry</span>
                <h3 className="text-xl font-bold text-white tracking-tight">{selectedAsset.name}</h3>
              </div>
              <span className={`px-2 py-1 text-[10px] font-bold rounded ${
                selectedAsset.utilisationPercent > 80 
                  ? 'bg-[#EF4444]/10 text-[#EF4444] border border-[#EF4444]/20'
                  : 'bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/20'
              }`}>
                Utilisation: {selectedAsset.utilisationPercent}%
              </span>
            </div>

            <p className="text-xs text-white/80 leading-relaxed mb-6 bg-[#121212] p-3 rounded border border-[#2A2C2E] italic">
              "{selectedAsset.description}"
            </p>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#121212] p-3 rounded border border-[#2A2C2E]/60">
                  <div className="text-[10px] text-[#8E9299] uppercase">Operator / Owner</div>
                  <div className="text-xs font-bold text-white mt-1 flex items-center">
                    <Briefcase className="h-3 w-3 text-[#C5A059] mr-1.5" />
                    {selectedAsset.operator}
                  </div>
                </div>
                <div className="bg-[#121212] p-3 rounded border border-[#2A2C2E]/60">
                  <div className="text-[10px] text-[#8E9299] uppercase">Annual Throughput</div>
                  <div className="text-xs font-bold text-white mt-1 flex items-center">
                    <Activity className="h-3 w-3 text-[#C5A059] mr-1.5" />
                    {selectedAsset.annualThroughput}
                  </div>
                </div>
              </div>

              {/* Capital and Lifecycle analytics (Module 10 Infrastructure Investment) */}
              <div className="bg-[#121212] p-4 rounded border border-[#2A2C2E]">
                <h4 className="text-xs font-bold text-[#C5A059] uppercase tracking-wider mb-3">Sovereign Investment Analytics</h4>
                <div className="grid grid-cols-3 gap-2">
                  <div className="text-center border-r border-[#222]">
                    <span className="text-[9px] text-[#8E9299] uppercase">Est. Value</span>
                    <div className="text-xs font-extrabold text-white mt-1">£{(selectedAsset.estimatedValueGbp / 1e9).toFixed(1)}B</div>
                  </div>
                  <div className="text-center border-r border-[#222]">
                    <span className="text-[9px] text-[#8E9299] uppercase">Target IRR</span>
                    <div className="text-xs font-extrabold text-[#10B981] mt-1 flex items-center justify-center">
                      <TrendingUp className="h-3 w-3 text-[#10B981] mr-0.5" /> {selectedAsset.irr}%
                    </div>
                  </div>
                  <div className="text-center">
                    <span className="text-[9px] text-[#8E9299] uppercase">Remaining Life</span>
                    <div className="text-xs font-extrabold text-white mt-1">{selectedAsset.remainingLifeYears} yrs</div>
                  </div>
                </div>
              </div>

              {/* Risk scores */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-[#121212] p-3 rounded border border-[#2A2C2E] text-center">
                  <span className="text-[9px] text-[#8E9299] uppercase">Maintenance Risk</span>
                  <div className={`text-xs font-bold mt-1 ${
                    selectedAsset.maintenanceRisk === 'High' ? 'text-[#EF4444]' : selectedAsset.maintenanceRisk === 'Medium' ? 'text-[#F59E0B]' : 'text-[#10B981]'
                  }`}>{selectedAsset.maintenanceRisk}</div>
                </div>
                <div className="bg-[#121212] p-3 rounded border border-[#2A2C2E] text-center">
                  <span className="text-[9px] text-[#8E9299] uppercase">Carbon Exposure</span>
                  <div className={`text-xs font-bold mt-1 ${
                    selectedAsset.carbonExposure === 'High' ? 'text-[#EF4444]' : selectedAsset.carbonExposure === 'Medium' ? 'text-[#F59E0B]' : 'text-[#10B981]'
                  }`}>{selectedAsset.carbonExposure}</div>
                </div>
                <div className="bg-[#121212]/70 p-3 rounded border border-[#2A2C2E] text-center border-dashed">
                  <span className="text-[9px] text-[#C5A059] uppercase">Asset Quality Score</span>
                  <div className="text-xs font-extrabold text-white mt-1 font-mono">{selectedAsset.assetScore} / 100</div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 border-t border-[#2A2C2E] pt-4 flex items-center justify-between">
            <div className="flex items-center text-[10px] text-[#8E9299]">
              <MapPin className="h-3.5 w-3.5 mr-1 text-[#C5A059]" />
              Lat: <span className="font-mono text-white ml-0.5 mr-2">{selectedAsset.latitude}</span> 
              Lon: <span className="font-mono text-white ml-0.5">{selectedAsset.longitude}</span>
            </div>
            <div className="text-[10px] text-[#8E9299]">
              Maintenance: <span className="text-[#F59E0B] font-semibold">{selectedAsset.maintenanceSchedule}</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
