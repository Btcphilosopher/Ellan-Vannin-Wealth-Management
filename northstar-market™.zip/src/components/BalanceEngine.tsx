import { useState, useMemo } from 'react';
import { BalanceSheet } from '../types';
import { ShieldAlert, AlertCircle, RefreshCw, Radio, CheckCircle, Flame } from 'lucide-react';

export default function BalanceEngine() {
  const [norwayOutage, setNorwayOutage] = useState<boolean>(false);
  const [winterColdSnap, setWinterColdSnap] = useState<boolean>(false);
  const [roughStorageInterruption, setRoughStorageInterruption] = useState<boolean>(false);

  // Computations based on triggers
  const balance: BalanceSheet = useMemo(() => {
    // Standard baseline values
    let domesticGas = 88.5; // mcm/d
    let pipelineImports = 96.0; // mcm/d (mainly Norway)
    let lngImports = 48.0; // mcm/d
    let storageWithdrawal = 10.0; // mcm/d
    
    let residentialDemand = 54.2; // mcm/d
    let industrialDemand = 32.5; // mcm/d
    let powerDemand = 48.0; // mcm/d
    let exportsDemand = 22.0; // mcm/d
    let storageInjection = 14.5; // mcm/d

    // Apply simulation modifiers
    if (norwayOutage) {
      pipelineImports -= 45.0; // Heavy drop in Norwegian flows
    }
    if (winterColdSnap) {
      residentialDemand += 48.0; // Heating demand spikes
      powerDemand += 15.0; // CCGT power generation backup spikes
      storageWithdrawal += 25.0; // Higher withdraw to balance
      storageInjection = 0; // Freeze injections
    }
    if (roughStorageInterruption) {
      storageWithdrawal = 0; // Complete loss of storage deliverability
    }

    const availableSupply = domesticGas + pipelineImports + lngImports + storageWithdrawal;
    const totalDemand = residentialDemand + industrialDemand + powerDemand + exportsDemand + storageInjection;
    
    const marketBalance = availableSupply - totalDemand;
    const supplyMargin = (marketBalance / availableSupply) * 100;

    let systemStressLevel: 'Normal' | 'Elevated' | 'Critical' = 'Normal';
    if (supplyMargin <= 2.0 || marketBalance < 0) {
      systemStressLevel = 'Critical';
    } else if (supplyMargin < 8.0) {
      systemStressLevel = 'Elevated';
    }

    return {
      domesticGas,
      pipelineImports,
      lngImports,
      storageWithdrawal,
      availableSupply: Number(availableSupply.toFixed(1)),
      residentialDemand,
      industrialDemand,
      powerDemand,
      exportsDemand,
      storageInjection,
      totalDemand: Number(totalDemand.toFixed(1)),
      supplyMargin: Number(supplyMargin.toFixed(1)),
      marketBalance: Number(marketBalance.toFixed(1)),
      systemStressLevel,
    };
  }, [norwayOutage, winterColdSnap, roughStorageInterruption]);

  return (
    <div id="balance_engine_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 06 // Market Balancing Node</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">Supply-Demand Balance Engine</h2>
        </div>

        {/* Real-Time Stress Indicator badge */}
        <div className="flex items-center space-x-2 mt-4 lg:mt-0">
          <span className="text-xs text-[#8E9299] font-semibold">Stress Overwatch:</span>
          <span className={`px-3 py-1 text-xs font-black tracking-widest rounded uppercase ${
            balance.systemStressLevel === 'Critical'
              ? 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/40 animate-pulse'
              : balance.systemStressLevel === 'Elevated'
              ? 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40'
              : 'bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40'
          }`}>
            {balance.systemStressLevel}
          </span>
        </div>
      </div>

      {/* Grid: Balance Sheet Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-8">
        
        {/* Left Side: Calculations Ledger */}
        <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Supply Column */}
          <div className="bg-[#121212] p-5 rounded border border-[#2A2C2E]">
            <h3 className="text-xs font-extrabold text-[#C5A059] uppercase tracking-wider border-b border-[#2A2C2E] pb-2 mb-4 flex items-center justify-between">
              <span>Cumulative Available Supply</span>
              <span className="font-mono text-white text-sm">{balance.availableSupply} mcm/d</span>
            </h3>

            <div className="space-y-3.5 text-xs">
              <div className="flex justify-between">
                <span className="text-[#8E9299]">Domestic North Sea Gas</span>
                <span className="font-mono text-white font-bold">{balance.domesticGas.toFixed(1)} mcm/d</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8E9299]">Pipeline Imports (Norway/EU)</span>
                <span className="font-mono text-white font-bold">{balance.pipelineImports.toFixed(1)} mcm/d</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8E9299]">LNG Terminal Regasification</span>
                <span className="font-mono text-white font-bold">{balance.lngImports.toFixed(1)} mcm/d</span>
              </div>
              <div className="flex justify-between border-t border-[#2A2C2E] pt-2">
                <span className="text-[#8E9299]">Strategic Storage Withdrawal</span>
                <span className="font-mono text-[#10B981] font-bold">{balance.storageWithdrawal.toFixed(1)} mcm/d</span>
              </div>
            </div>
          </div>

          {/* Demand Column */}
          <div className="bg-[#121212] p-5 rounded border border-[#2A2C2E]">
            <h3 className="text-xs font-extrabold text-[#EF4444] uppercase tracking-wider border-b border-[#2A2C2E] pb-2 mb-4 flex items-center justify-between">
              <span>Cumulative Total Demand</span>
              <span className="font-mono text-white text-sm">{balance.totalDemand} mcm/d</span>
            </h3>

            <div className="space-y-3.5 text-xs">
              <div className="flex justify-between">
                <span className="text-[#8E9299]">Residential Gas Heating</span>
                <span className="font-mono text-white font-bold">{balance.residentialDemand.toFixed(1)} mcm/d</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8E9299]">CCGT Power Generation</span>
                <span className="font-mono text-white font-bold">{balance.powerDemand.toFixed(1)} mcm/d</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8E9299]">Industrial Processes / Feedstock</span>
                <span className="font-mono text-white font-bold">{balance.industrialDemand.toFixed(1)} mcm/d</span>
              </div>
              <div className="flex justify-between border-t border-[#2A2C2E] pt-2">
                <span className="text-[#8E9299]">Continental Interconnector Exports</span>
                <span className="font-mono text-white font-bold">{balance.exportsDemand.toFixed(1)} mcm/d</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8E9299]">Active Storage Re-Injections</span>
                <span className="font-mono text-white">{balance.storageInjection.toFixed(1)} mcm/d</span>
              </div>
            </div>
          </div>
          
        </div>

        {/* Right Side: Risk Simulations */}
        <div className="lg:col-span-4 bg-[#1A1C1E] border border-[#2A2C2E] p-5 rounded-md flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight mb-2 flex items-center">
              <Radio className="h-4 w-4 mr-1.5 text-[#F59E0B] animate-pulse" />
              NTS System Stress Simulator
            </h3>
            <p className="text-[11px] text-[#8E9299] mb-4">
              Toggle risk vectors to audit the UK energy network's stress tolerances in real-time.
            </p>

            <div className="space-y-3">
              {/* Norway Pipeline outage */}
              <label className="flex items-center justify-between p-3 bg-[#121212] rounded border border-[#2A2C2E] cursor-pointer hover:border-[#8E9299] transition">
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-white">Norwegian Import Outage</span>
                  <span className="text-[10px] text-[#8E9299]">-45 mcm/d pipeline supply</span>
                </div>
                <input 
                  type="checkbox" 
                  checked={norwayOutage} 
                  onChange={(e) => setNorwayOutage(e.target.checked)} 
                  className="rounded border-gray-300 text-[#C5A059] focus:ring-[#C5A059] bg-zinc-900"
                />
              </label>

              {/* Winter Cold Snap */}
              <label className="flex items-center justify-between p-3 bg-[#121212] rounded border border-[#2A2C2E] cursor-pointer hover:border-[#8E9299] transition">
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-white">Severe Winter Cold Snap</span>
                  <span className="text-[10px] text-[#8E9299]">+63 mcm/d heating/power surge</span>
                </div>
                <input 
                  type="checkbox" 
                  checked={winterColdSnap} 
                  onChange={(e) => setWinterColdSnap(e.target.checked)} 
                  className="rounded border-gray-300 text-[#C5A059] focus:ring-[#C5A059] bg-zinc-900"
                />
              </label>

              {/* Rough Storage Interruption */}
              <label className="flex items-center justify-between p-3 bg-[#121212] rounded border border-[#2A2C2E] cursor-pointer hover:border-[#8E9299] transition">
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-white">Rough Reservoir Interruption</span>
                  <span className="text-[10px] text-[#8E9299]">Zero storage withdrawal deliverability</span>
                </div>
                <input 
                  type="checkbox" 
                  checked={roughStorageInterruption} 
                  onChange={(e) => setRoughStorageInterruption(e.target.checked)} 
                  className="rounded border-gray-300 text-[#C5A059] focus:ring-[#C5A059] bg-zinc-900"
                />
              </label>
            </div>
          </div>

          <div className="mt-6 border-t border-[#2A2C2E] pt-4">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="text-[#8E9299]">Calculated Margin Balance:</span>
              <span className={`font-mono font-bold ${
                balance.marketBalance < 0 ? 'text-[#EF4444]' : 'text-[#10B981]'
              }`}>
                {balance.marketBalance > 0 ? `+${balance.marketBalance}` : balance.marketBalance} mcm/day
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#8E9299]">Reserve Supply Margin:</span>
              <span className={`font-mono font-bold ${
                balance.supplyMargin < 5 ? 'text-[#EF4444]' : 'text-white'
              }`}>
                {balance.supplyMargin}%
              </span>
            </div>
          </div>

        </div>

      </div>

      {/* Warning Flash alerts */}
      {balance.systemStressLevel === 'Critical' && (
        <div className="bg-[#EF4444]/10 border border-[#EF4444]/40 p-4 rounded-md flex items-start space-x-3 text-[#EF4444] animate-pulse">
          <ShieldAlert className="h-5 w-5 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider">CRITICAL NTS BALANCING DEFICIT</h4>
            <p className="text-xs text-white/80 mt-1 leading-relaxed">
              Available supply is failing to sustain demand margins. National Gas must trigger emergency storage withdrawal mandates, curtail heavy industrial feedstocks, or request voluntary power sector fuel-switching to maintain system pressure above minimum safety limits.
            </p>
          </div>
        </div>
      )}

      {balance.systemStressLevel === 'Elevated' && (
        <div className="bg-[#F59E0B]/10 border border-[#F59E0B]/40 p-4 rounded-md flex items-start space-x-3 text-[#F59E0B]">
          <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider">SYSTEM BALANCE STRESS WARNING</h4>
            <p className="text-xs text-white/80 mt-1 leading-relaxed">
              Gas storage buffers are actively discharging above standard seasonal rates to cover supply shortfalls. Strategic planning groups advise tracking weather forecasts carefully to prepare for extended high demand.
            </p>
          </div>
        </div>
      )}

      {balance.systemStressLevel === 'Normal' && (
        <div className="bg-[#10B981]/10 border border-[#10B981]/40 p-4 rounded-md flex items-start space-x-3 text-[#10B981]">
          <CheckCircle className="h-5 w-5 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider">NETWORK BALANCE STABLE</h4>
            <p className="text-xs text-white/80 mt-1 leading-relaxed">
              Current supplies exceed demand by a secure margin of {balance.marketBalance} mcm/day. Pressure levels are nominal.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
