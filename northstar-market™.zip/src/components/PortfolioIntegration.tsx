import { useMemo } from 'react';
import { portfolioHoldings } from '../data';
import { PortfolioAsset } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, ReferenceLine } from 'recharts';
import { Briefcase, Landmark, Coins, TrendingUp, ShieldCheck } from 'lucide-react';

export default function PortfolioIntegration() {
  const holdings = useMemo(() => portfolioHoldings, []);

  // Portfolio Totals
  const totalAllocated = useMemo(() => holdings.reduce((sum, h) => sum + h.allocatedCapitalGbp, 0), [holdings]);
  const currentValuation = useMemo(() => holdings.reduce((sum, h) => sum + h.currentValuationGbp, 0), [holdings]);
  const totalCashFlow = useMemo(() => holdings.reduce((sum, h) => sum + h.annualCashFlowGbp, 0), [holdings]);
  
  const averageIrr = useMemo(() => {
    const sum = holdings.reduce((acc, curr) => acc + curr.irrAchieved, 0);
    return Number((sum / holdings.length).toFixed(2));
  }, [holdings]);

  // Transform data for Recharts Comparison (Allocated vs Current Valuation)
  const chartData = useMemo(() => {
    return holdings.map((h) => ({
      name: h.name.split(' (')[0].split(' Field')[0],
      'Allocated Capital': h.allocatedCapitalGbp / 1e6, // In Millions
      'Current Valuation': h.currentValuationGbp / 1e6, // In Millions
    }));
  }, [holdings]);

  return (
    <div id="portfolio_integration_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 11 // Sovereign Fund Integration</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">Ellan Vannin Portfolio Strategy</h2>
        </div>
        
        <div className="flex items-center text-xs text-[#8E9299] bg-[#121212] py-1.5 px-3 rounded border border-[#2A2C2E] font-mono mt-4 lg:mt-0">
          CLIENT ID: EVWM_RESERVE_STAKE_1
        </div>
      </div>

      {/* Aggregate metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {/* Allocated Capital */}
        <div className="bg-[#121212] border border-[#2A2C2E] p-4 rounded text-center relative">
          <div className="text-[10px] text-[#8E9299] uppercase tracking-wider font-bold">Total Capital Committed</div>
          <div className="text-2xl font-extrabold text-white mt-2 font-mono">£{(totalAllocated / 1e6).toFixed(1)}M</div>
          <div className="text-[10px] text-[#8E9299] mt-1">Across 5 infrastructure positions</div>
        </div>

        {/* Current Valuation */}
        <div className="bg-[#121212] border border-[#2A2C2E] p-4 rounded text-center relative">
          <div className="text-[10px] text-[#8E9299] uppercase tracking-wider font-bold">Portfolio Asset Valuation</div>
          <div className="text-2xl font-extrabold text-[#10B981] mt-2 font-mono">£{(currentValuation / 1e6).toFixed(1)}M</div>
          <div className="text-[10px] text-[#10B981] font-bold mt-1">▲ +{(((currentValuation - totalAllocated) / totalAllocated) * 100).toFixed(1)}% Yield Gain</div>
        </div>

        {/* Annual Cash Flow */}
        <div className="bg-[#121212] border border-[#2A2C2E] p-4 rounded text-center relative">
          <div className="text-[10px] text-[#8E9299] uppercase tracking-wider font-bold">Annual Cash Flow Net</div>
          <div className="text-2xl font-extrabold text-white mt-2 font-mono">£{(totalCashFlow / 1e6).toFixed(2)}M</div>
          <div className="text-[10px] text-[#8E9299] mt-1">Buffered by Gilt / Bond interest</div>
        </div>

        {/* Weighted average IRR */}
        <div className="bg-[#121212] border border-[#2A2C2E] p-4 rounded text-center relative">
          <div className="text-[10px] text-[#8E9299] uppercase tracking-wider font-bold">Portfolio Average Yield (IRR)</div>
          <div className="text-2xl font-extrabold text-[#C5A059] mt-2 font-mono">+{averageIrr}%</div>
          <div className="text-[10px] text-white/50 mt-1 flex items-center justify-center">
            <ShieldCheck className="h-3 w-3 text-[#C5A059] mr-1" /> Risk Rating: AA-
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left: Valuations Chart */}
        <div className="lg:col-span-7 bg-[#1A1C1E] border border-[#2A2C2E] p-6 rounded-md">
          <h3 className="text-sm font-bold text-white tracking-tight mb-4 flex items-center uppercase font-mono">
            <Coins className="h-4 w-4 mr-1.5 text-[#C5A059]" />
            Committed Capital vs Present Asset Value (£ Millions)
          </h3>

          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2C2E" />
                <XAxis dataKey="name" stroke="#666" fontSize={10} tickLine={false} />
                <YAxis stroke="#666" fontSize={10} tickLine={false} />
                <Tooltip contentStyle={{ backgroundColor: '#1A1C1E', borderColor: '#2A2C2E', color: '#FFF' }} />
                <Legend verticalAlign="top" height={36} iconSize={10} wrapperStyle={{ fontSize: 11 }} />
                <Bar name="Committed Capital" dataKey="Allocated Capital" fill="#C5A059" radius={[4, 4, 0, 0]} />
                <Bar name="Present Valuation" dataKey="Current Valuation" fill="#10B981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right: Holding Assets list */}
        <div className="lg:col-span-5 bg-[#1A1C1E] border border-[#2A2C2E] p-6 rounded-md">
          <h3 className="text-xs font-bold text-[#8E9299] uppercase tracking-wider mb-4">Securitised Holdings Directory</h3>

          <div className="space-y-3 max-h-[290px] overflow-y-auto pr-1">
            {holdings.map((hold) => (
              <div key={hold.id} className="bg-[#121212] p-3 rounded border border-[#2A2C2E] flex items-center justify-between hover:border-[#8E9299] transition">
                <div className="max-w-[70%]">
                  <h4 className="text-xs font-black text-white truncate">{hold.name}</h4>
                  <p className="text-[9px] text-[#8E9299] mt-0.5 uppercase tracking-wide font-mono">{hold.type} // {hold.riskRating} rated</p>
                </div>

                <div className="text-right">
                  <div className="text-xs font-bold text-white font-mono">£{(hold.currentValuationGbp / 1e6).toFixed(1)}M</div>
                  <div className="text-[9px] text-[#10B981] font-mono font-bold">+{hold.irrAchieved}% Yield</div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
