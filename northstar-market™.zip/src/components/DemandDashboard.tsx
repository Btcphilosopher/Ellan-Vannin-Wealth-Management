import { useMemo, useState } from 'react';
import { DemandData } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from 'recharts';
import { Thermometer, Zap, Factory, Landmark, Wind, Server } from 'lucide-react';

export default function DemandDashboard() {
  const [winterScenario, setWinterScenario] = useState<'Standard' | 'ColdSnap' | 'Mild'>('Standard');

  const demand: DemandData = useMemo(() => {
    return {
      residential: 54.2,
      industrial: 32.5,
      powerGen: 48.0,
      commercial: 18.2,
      storageInjection: 14.5,
      exports: 22.0,
      weatherAdjusted: 195.0,
      peakForecast: winterScenario === 'Standard' ? 245.0 : winterScenario === 'ColdSnap' ? 295.0 : 210.0,
    };
  }, [winterScenario]);

  const demandBreakdown = [
    { name: 'Residential (Heating)', value: demand.residential, icon: Thermometer, color: '#F59E0B' },
    { name: 'Power Generation (CCGT)', value: demand.powerGen, icon: Zap, color: '#C5A059' },
    { name: 'Industrial Processing', value: demand.industrial, icon: Factory, color: '#60A5FA' },
    { name: 'Exports (Interconnectors)', value: demand.exports, icon: Wind, color: '#34D399' },
    { name: 'Commercial Operations', value: demand.commercial, icon: Landmark, color: '#A78BFA' },
    { name: 'Storage Injections', value: demand.storageInjection, icon: Server, color: '#F43F5E' },
  ];

  const totalDemandValue = demandBreakdown.reduce((acc, curr) => acc + curr.value, 0);

  // Historical weather adjustments
  const weatherTrends = [
    { name: 'Oct', actual: 162, weatherAdjusted: 165 },
    { name: 'Nov', actual: 185, weatherAdjusted: 180 },
    { name: 'Dec', actual: 220, weatherAdjusted: 215 },
    { name: 'Jan', actual: 245, weatherAdjusted: 235 },
    { name: 'Feb', actual: 230, weatherAdjusted: 228 },
    { name: 'Mar', actual: 195, weatherAdjusted: 202 },
    { name: 'Apr', actual: 160, weatherAdjusted: 168 },
    { name: 'May', actual: 135, weatherAdjusted: 142 },
    { name: 'Jun', actual: 110, weatherAdjusted: 115 },
    { name: 'Jul', actual: 105, weatherAdjusted: 108 },
  ];

  return (
    <div id="demand_dashboard_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 03 // Market Consumption</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">National Grid Demand Analytics</h2>
        </div>

        {/* Peak Demand Simulation */}
        <div className="flex items-center space-x-2 mt-4 lg:mt-0">
          <span className="text-xs text-[#8E9299] font-semibold">Peak Forecast Scenario:</span>
          <div className="flex bg-[#121212] p-1 rounded border border-[#2A2C2E]">
            {(['Mild', 'Standard', 'ColdSnap'] as const).map((scen) => (
              <button
                key={scen}
                onClick={() => setWinterScenario(scen)}
                className={`px-2.5 py-1 text-[11px] font-bold rounded transition ${
                  winterScenario === scen
                    ? 'bg-[#F59E0B] text-[#121212]'
                    : 'text-[#8E9299] hover:text-white'
                }`}
              >
                {scen === 'ColdSnap' ? 'Cold Snap' : scen}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Grid of Sector Demands */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        {demandBreakdown.map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.name} className="bg-[#121212] border-y border-r border-[#2A2C2E] border-l-[3px] border-l-[#C5A059] p-4 rounded-r hover:border-[#C5A059] transition">
              <div className="flex items-center justify-between text-[#8E9299] text-[10px] font-bold uppercase tracking-wider">
                <span className="truncate max-w-[85%]">{item.name.split(' (')[0]}</span>
                <Icon className="h-3.5 w-3.5 text-[#C5A059]" />
              </div>
              <div className="text-xl font-bold text-white mt-1.5 font-mono">{item.value.toFixed(1)} <span className="text-[10px] font-normal text-[#8E9299]">mcm/d</span></div>
              <div className="text-[10px] text-[#8E9299] mt-1">Share: {((item.value / totalDemandValue) * 100).toFixed(1)}%</div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Sector Allocation Circle */}
        <div className="lg:col-span-5 bg-[#1A1C1E] border border-[#2A2C2E] p-6 rounded-md flex flex-col justify-between">
          <div>
            <h3 className="text-lg font-semibold text-white tracking-tight mb-2">Demand Allocation</h3>
            <p className="text-xs text-[#8E9299] mb-6">Visual representation of real-time pipeline deliveries across UK economic sectors.</p>
          </div>

          <div className="h-[220px] flex items-center justify-center relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={demandBreakdown}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {demandBreakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            
            {/* Center Summary text */}
            <div className="absolute text-center">
              <span className="text-[10px] uppercase tracking-widest text-[#8E9299] font-semibold">Total Load</span>
              <div className="text-2xl font-black text-white font-mono">{totalDemandValue.toFixed(1)}</div>
              <span className="text-[10px] text-[#C5A059] font-bold">mcm/day</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-[10px] border-t border-[#2A2C2E] pt-4 mt-4">
            {demandBreakdown.map((e) => (
              <div key={e.name} className="flex items-center">
                <span className="w-2 h-2 rounded-full mr-1.5 shrink-0" style={{ backgroundColor: e.color }} />
                <span className="text-[#8E9299] truncate">{e.name.split(' (')[0]}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Weather Normalisation Trends */}
        <div className="lg:col-span-7 bg-[#1A1C1E] border border-[#2A2C2E] p-6 rounded-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-white tracking-tight">Weather-Adjusted Consumption</h3>
              <p className="text-xs text-[#8E9299] mt-0.5">Smoothing out temperature-related load variations to reveal structural demand patterns.</p>
            </div>
            <div className="text-right">
              <div className="text-xs text-[#8E9299] font-semibold">Simulated Peak load</div>
              <div className="text-base font-extrabold text-[#F59E0B] font-mono">{demand.peakForecast} mcm/d</div>
            </div>
          </div>

          <div className="h-[240px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weatherTrends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#C5A059" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#C5A059" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorNormal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#60A5FA" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#60A5FA" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2C2E" />
                <XAxis dataKey="name" stroke="#666" fontSize={10} tickLine={false} />
                <YAxis stroke="#666" fontSize={10} tickLine={false} />
                <Tooltip contentStyle={{ backgroundColor: '#1A1C1E', borderColor: '#2A2C2E', color: '#FFF' }} />
                <Legend verticalAlign="top" height={36} iconSize={10} wrapperStyle={{ fontSize: 11 }} />
                <Area name="Actual Grid Load" type="monotone" dataKey="actual" stroke="#C5A059" fillOpacity={1} fill="url(#colorActual)" strokeWidth={2} />
                <Area name="Temperature Normalised" type="monotone" dataKey="weatherAdjusted" stroke="#60A5FA" fillOpacity={1} fill="url(#colorNormal)" strokeWidth={1.5} strokeDasharray="4 4" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
}
