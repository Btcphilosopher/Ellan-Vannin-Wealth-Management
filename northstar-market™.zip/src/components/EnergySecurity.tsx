import { useMemo } from 'react';
import { EnergySecurityMetric } from '../types';
import { Shield, ShieldAlert, Zap, Globe, HardDrive, RefreshCw, Layers } from 'lucide-react';

export default function EnergySecurity() {
  const metric: EnergySecurityMetric = useMemo(() => {
    return {
      indexScore: 82, // Out of 100
      importDependency: 58.4, // %
      northSeaTrend: 'Stable',
      lngDiversification: 0.22, // Herfindahl-Hirschman Index (lower is more diversified/secure)
      storageResilienceDays: 18.5, // Days of peak winter supply stored in strategic gas
      supplyDiversityScore: 88, // Score out of 100
      status: 'Secure',
    };
  }, []);

  return (
    <div id="energy_security_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 08 // Geopolitical Strategic Risk</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">Energy Security Dashboard</h2>
        </div>
        <div className="flex items-center text-xs text-[#8E9299] bg-[#121212] py-1 px-3 rounded border border-[#2A2C2E] mt-4 sm:mt-0 font-mono">
          MODEL: UK-SEC-OVERWATCH v4.1
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Index Core Gauge */}
        <div className="lg:col-span-5 bg-[#121212] border border-[#2A2C2E] p-6 rounded-md flex flex-col justify-between items-center text-center">
          <div className="w-full">
            <h3 className="text-xs font-extrabold text-[#C5A059] uppercase tracking-wider mb-2">Energy Security Index (ESI)</h3>
            <p className="text-[10px] text-[#8E9299] px-4">Composite risk metric weighing storage capacity, pipeline dependencies, and supplier diversification.</p>
          </div>

          <div className="relative flex items-center justify-center my-6">
            {/* Styled Circular Gauge */}
            <svg className="w-36 h-36">
              <circle cx="72" cy="72" r="64" fill="none" stroke="#2A2C2E" strokeWidth="8" />
              <circle 
                cx="72" 
                cy="72" 
                r="64" 
                fill="none" 
                stroke="#C5A059" 
                strokeWidth="8" 
                strokeDasharray="402" 
                strokeDashoffset={402 - (402 * metric.indexScore) / 100} 
                strokeLinecap="round"
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="absolute text-center">
              <span className="text-4xl font-black text-white font-mono">{metric.indexScore}</span>
              <span className="text-[10px] text-[#8E9299] block font-bold uppercase tracking-widest mt-0.5">Scale pts</span>
            </div>
          </div>

          <div className="w-full">
            <span className="px-3 py-1 text-xs font-bold bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/20 rounded-full">
              System Classification: {metric.status.toUpperCase()}
            </span>
          </div>
        </div>

        {/* Breakdown Analytics */}
        <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Storage Resilience */}
          <div className="bg-[#1A1C1E] border border-[#2A2C2E] p-4 rounded flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#8E9299] text-[10px] font-bold uppercase">
              <span>Storage Buffer Resilience</span>
              <HardDrive className="h-4 w-4 text-[#C5A059]" />
            </div>
            <div className="mt-4">
              <div className="text-2xl font-bold text-white font-mono">{metric.storageResilienceDays} days</div>
              <p className="text-[10px] text-[#8E9299] mt-1">Number of continuous winter peak load days that can be covered solely by existing strategic gas reserves.</p>
            </div>
          </div>

          {/* Import Dependency */}
          <div className="bg-[#1A1C1E] border border-[#2A2C2E] p-4 rounded flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#8E9299] text-[10px] font-bold uppercase">
              <span>Import Dependency Rate</span>
              <Globe className="h-4 w-4 text-[#EF4444]" />
            </div>
            <div className="mt-4">
              <div className="text-2xl font-bold text-[#EF4444] font-mono">{metric.importDependency}%</div>
              <p className="text-[10px] text-[#8E9299] mt-1">Proportion of net domestic consumption satisfied through non-UKCS pipeline and seaborne LNG cargos.</p>
            </div>
          </div>

          {/* Diversity of Supply */}
          <div className="bg-[#1A1C1E] border border-[#2A2C2E] p-4 rounded flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#8E9299] text-[10px] font-bold uppercase">
              <span>Supply Diversity Index</span>
              <Layers className="h-4 w-4 text-[#10B981]" />
            </div>
            <div className="mt-4">
              <div className="text-2xl font-bold text-white font-mono">{metric.supplyDiversityScore} / 100</div>
              <p className="text-[10px] text-[#8E9299] mt-1">Origin dispersion score. High scores represent a safe, balanced spread across Norway, US LNG, Qatar LNG, and EU lines.</p>
            </div>
          </div>

          {/* North Sea Trend */}
          <div className="bg-[#1A1C1E] border border-[#2A2C2E] p-4 rounded flex flex-col justify-between">
            <div className="flex items-center justify-between text-[#8E9299] text-[10px] font-bold uppercase">
              <span>North Sea Trendline</span>
              <Zap className="h-4 w-4 text-[#F59E0B]" />
            </div>
            <div className="mt-4">
              <div className="text-2xl font-bold text-[#F59E0B] font-mono">{metric.northSeaTrend}</div>
              <p className="text-[10px] text-[#8E9299] mt-1">Cumulative North Sea production glide path. Stabilized by recent West of Shetland (Clair Field) expansions.</p>
            </div>
          </div>

        </div>

      </div>

      <div className="mt-6 bg-[#121212] p-4 rounded border border-[#2A2C2E] text-xs text-[#8E9299] leading-relaxed">
        <span className="text-white font-bold block mb-1">Executive Advisory Summary (Ellan Vannin Strategic Capital)</span>
        The UK energy system relies on a delicate balance. High LNG regasification limits provide robust merchant flexibility, but seasonal cold snaps require active storage drawdowns. Expanding domestic projects West of Shetland is essential to offset standard southern North Sea basin declines and secure our long-term capital deployments.
      </div>
    </div>
  );
}
