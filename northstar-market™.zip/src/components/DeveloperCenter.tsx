import { useState } from 'react';
import { rSourceCode, rustSourceCode, postgresSchema } from '../data';
import { Code, Terminal, Database, BookOpen, Copy, Check, FileText } from 'lucide-react';

export default function DeveloperCenter() {
  const [activeFile, setActiveFile] = useState<'R' | 'Rust' | 'SQL' | 'Deploy'>('R');
  const [copied, setCopied] = useState<boolean>(false);

  const activeContent = {
    R: rSourceCode,
    Rust: rustSourceCode,
    SQL: postgresSchema,
    Deploy: `# =========================================================================
# NORTHSTAR MARKET™ - Installation & Production Deployment Guide
# Client: Ellan Vannin Wealth Management
# R Shiny Analytics + Rust Tokio Backend + PostgreSQL Stack
# =========================================================================

## 1. Prerequisites & Host Requirements
- **Host OS**: Red Hat Enterprise Linux (RHEL) 9 or Ubuntu Server 22.04 LTS
- **Cores / RAM**: 4 vCPUs, 16GB RAM minimum (for Polars vector alignments)
- **R Runtime**: v4.3+ with compilers (gcc, g++, gfortran)
- **Rust Toolchain**: Stable v1.75+ (rustc, cargo)
- **Database Engine**: PostgreSQL 15+ (Local or Cloud-managed RDS instance)

---

## 2. PostgreSQL Schema Setup
Seed the initial relational tables on your database node using the provided SQL DDL:

\`\`\`bash
# Access your database cluster
psql -h pg-db.ellan-vannin.int -U admin -d postgres

# Create and seed schema (injecting the DDL from SQL Tab)
psql -h pg-db.ellan-vannin.int -U admin -f /opt/northstar/db/schema.sql
\`\`\`

---

## 3. Rust Backend Service Deployment
Compile and run the low-latency Axum telemetry ingest server:

\`\`\`bash
# 1. Clone source and enter directory
cd /opt/northstar/backend

# 2. Configure environment file
cat <<EOT >> .env
DATABASE_URL="postgres://admin:secret@pg-db.ellan-vannin.int:5432/northstar_energy"
PORT=3000
NODE_ENV=production
EOT

# 3. Build optimized static production binary
cargo build --release

# 4. Bind Axum pipeline to systemd for daemonized process control
sudo cp northstar-backend.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now northstar-backend
\`\`\`

---

## 4. R Shiny Applet Hosting (Shiny Server)
Host the executive UI using standard enterprise R Shiny Server:

\`\`\`bash
# 1. Install necessary library dependencies from CRAN
R -e "install.packages(c('shiny', 'tidyverse', 'data.table', 'plotly', 'leaflet', 'sf', 'forecast', 'xts', 'shinythemes'), repos='https://cloud.r-project.org')"

# 2. Deploy dashboard script
sudo cp app.R /srv/shiny-server/northstar/

# 3. Start Shiny server daemon
sudo systemctl enable --now shiny-server
\`\`\`

---

## 5. Security Architecture
- **In-transit Cryptography**: All data routes are protected via TLS v1.3.
- **Access Protections**: Internal subnet binds; public proxy routing via Nginx.
`,
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(activeContent[activeFile]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="developer_center_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 13 & 14 // Engineering Deliverables</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">Sovereign Developer Center</h2>
        </div>

        {/* Tab selection */}
        <div className="flex bg-[#121212] p-1 rounded border border-[#2A2C2E] mt-4 lg:mt-0">
          <button
            onClick={() => setActiveFile('R')}
            className={`px-3 py-1.5 text-xs font-bold rounded transition flex items-center space-x-1.5 ${
              activeFile === 'R' ? 'bg-[#C5A059] text-[#1A1C1E]' : 'text-[#8E9299] hover:text-white'
            }`}
          >
            <Code className="h-3.5 w-3.5" />
            <span>R Analytics Code</span>
          </button>
          
          <button
            onClick={() => setActiveFile('Rust')}
            className={`px-3 py-1.5 text-xs font-bold rounded transition flex items-center space-x-1.5 ${
              activeFile === 'Rust' ? 'bg-[#C5A059] text-[#1A1C1E]' : 'text-[#8E9299] hover:text-white'
            }`}
          >
            <Terminal className="h-3.5 w-3.5" />
            <span>Rust Backend</span>
          </button>

          <button
            onClick={() => setActiveFile('SQL')}
            className={`px-3 py-1.5 text-xs font-bold rounded transition flex items-center space-x-1.5 ${
              activeFile === 'SQL' ? 'bg-[#C5A059] text-[#1A1C1E]' : 'text-[#8E9299] hover:text-white'
            }`}
          >
            <Database className="h-3.5 w-3.5" />
            <span>PostgreSQL Schema</span>
          </button>

          <button
            onClick={() => setActiveFile('Deploy')}
            className={`px-3 py-1.5 text-xs font-bold rounded transition flex items-center space-x-1.5 ${
              activeFile === 'Deploy' ? 'bg-[#C5A059] text-[#1A1C1E]' : 'text-[#8E9299] hover:text-white'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5" />
            <span>Deployment Guide</span>
          </button>
        </div>
      </div>

      {/* Code Viewer Console */}
      <div className="bg-[#121212] rounded-lg border border-[#2A2C2E] overflow-hidden flex flex-col h-[520px]">
        {/* Header toolbar */}
        <div className="bg-[#1E2022] px-4 py-3 border-b border-[#2A2C2E] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#EF4444]" />
            <div className="w-3 h-3 rounded-full bg-[#F59E0B]" />
            <div className="w-3 h-3 rounded-full bg-[#10B981]" />
            <span className="text-[10px] text-[#8E9299] font-mono ml-4">
              {activeFile === 'R' && 'app.R // Shiny Web Dashboard'}
              {activeFile === 'Rust' && 'main.rs // Tokio Axum Pipeline'}
              {activeFile === 'SQL' && 'schema.sql // PostgreSQL Relations'}
              {activeFile === 'Deploy' && 'DEPLOYMENT_MANUAL.md // Capital Ops'}
            </span>
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center space-x-1 text-[10px] font-bold text-[#8E9299] hover:text-white transition bg-[#25282B] px-2.5 py-1 rounded border border-[#2A2C2E]"
          >
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5 text-[#10B981]" />
                <span className="text-[#10B981]">COPIED</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" />
                <span>COPY SOURCE</span>
              </>
            )}
          </button>
        </div>

        {/* Text Area Code Box */}
        <div className="p-5 font-mono text-xs text-white/90 overflow-y-auto flex-1 leading-relaxed bg-[#0E0E0E]">
          <pre className="whitespace-pre-wrap selection:bg-[#C5A059]/30 select-text">
            {activeContent[activeFile]}
          </pre>
        </div>
      </div>
    </div>
  );
}
