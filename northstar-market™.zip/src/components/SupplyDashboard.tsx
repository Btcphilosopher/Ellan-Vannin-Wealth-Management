import { useMemo } from 'react';
import { SupplyData } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Cell, PieChart, Pie } from 'recharts';
import { Ship, Anchor, ArrowRight, ArrowLeft, RefreshCw, Layers } from 'lucide-react';

export default function SupplyDashboard() {
  const supply: SupplyData = useMemo(() => {
    const domesticGas = 88.5; // mcm/d
    const norwayPipelines = 96.0; // mcm/d
    const lngImports = 48.0; // mcm/d
    const interconnectors = 18.5; // mcm/d (Inbound/outbound net)
    const gasExports = 22.0; // mcm/d
    
    const domesticOil = 760; // kbd
    const condensates = 110; // kbd
    const oilExports = 420; // kbd
    
    const totalGasSupply = domesticGas + norwayPipelines + lngImports + interconnectors;
    const netGasSupply = totalGasSupply - gasExports;
    
    return {
      domesticGas,
      domesticOil,
      condensates,
      norwayPipelines,
      lngImports,
      interconnectorBBL: 10.5,
      interconnectorIUK: 8.0,
      gasExports,
      oilExports,
      domesticSupplyGasPercent: Number(((domesticGas / totalGasSupply) * 100).toFixed(1)),
      importDependencyPercent: Number((((norwayPipelines + lngImports + interconnectors) / totalGasSupply) * 100).toFixed(1)),
      exportRatio: Number(((gasExports / domesticGas) * 100).toFixed(1)),
    };
  }, []);

  const gasSupplyMix = [
    { name: 'UK North Sea Gas', value: supply.domesticGas, color: '#C5A059' },
    { name: 'Norway Pipelines', value: supply.norwayPipelines, color: '#60A5FA' },
    { name: 'LNG Regasification', value: supply.lngImports, color: '#34D399' },
    { name: 'BBL/IUK Interconnectors', value: supply.interconnectorBBL + supply.interconnectorIUK, color: '#A78BFA' },
  ];

  const totalGasVolume = gasSupplyMix.reduce((acc, curr) => acc + curr.value, 0);

  return (
    <div id="supply_dashboard_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 02 // Resource Flows</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">UK Production & Supply Matrix</h2>
        </div>
        <div className="flex items-center text-xs text-[#8E9299] bg-[#121212] py-1.5 px-3 rounded border border-[#2A2C2E] font-mono mt-4 sm:mt-0">
          <RefreshCw className="h-3 w-3 text-[#C5A059] mr-2 animate-spin-slow" />
          SYSTEM STATE: INGESTION STABLE
        </div>
      </div>

      {/* KPI Overviews */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Domestic Supply Ratio */}
        <div className="bg-[#121212] border border-[#2A2C2E] border-l-[3px] border-l-[#10B981] p-5 rounded-r relative overflow-hidden">
          <div className="text-xs text-[#8E9299] font-semibold uppercase tracking-wider">Domestic Supply Gas %</div>
          <div className="text-4xl font-extrabold text-white mt-2 font-mono">{supply.domesticSupplyGasPercent}%</div>
          <p className="text-xs text-[#8E9299] mt-3">Percentage of total UK gas grid supply drawn directly from UK Continental Shelf (UKCS) fields.</p>
          <div className="absolute right-3 top-3 h-1.5 w-1.5 rounded-full bg-[#10B981]" />
        </div>

        {/* Import Dependency Ratio */}
        <div className="bg-[#121212] border border-[#2A2C2E] border-l-[3px] border-l-[#EF4444] p-5 rounded-r relative overflow-hidden">
          <div className="text-xs text-[#8E9299] font-semibold uppercase tracking-wider">Import Dependency %</div>
          <div className="text-4xl font-extrabold text-[#EF4444] mt-2 font-mono">{supply.importDependencyPercent}%</div>
          <p className="text-xs text-[#8E9299] mt-3">Calculated exposure to imported pipeline and LNG flows required to meet cumulative demand requirements.</p>
          <div className="absolute right-3 top-3 h-1.5 w-1.5 rounded-full bg-[#EF4444]" />
        </div>

        {/* Export Ratio */}
        <div className="bg-[#121212] border border-[#2A2C2E] border-l-[3px] border-l-[#C5A059] p-5 rounded-r relative overflow-hidden">
          <div className="text-xs text-[#8E9299] font-semibold uppercase tracking-wider">Gas Export Ratio</div>
          <div className="text-4xl font-extrabold text-[#C5A059] mt-2 font-mono">{supply.exportRatio}%</div>
          <p className="text-xs text-[#8E9299] mt-3">Proportion of UK domestic gas production routed back to European mainland via continental links.</p>
          <div className="absolute right-3 top-3 h-1.5 w-1.5 rounded-full bg-[#C5A059]" />
        </div>
      </div>

      {/* Gas and Oil Layout Splits */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Gas Supply Breakdown */}
        <div className="lg:col-span-7 bg-[#1A1C1E] border border-[#2A2C2E] p-6 rounded-md">
          <h3 className="text-lg font-semibold text-white tracking-tight mb-4 flex items-center">
            <Layers className="h-5 w-5 text-[#C5A059] mr-2" />
            Gas Supply Breakdown <span className="text-xs font-normal text-[#8E9299] ml-2">({totalGasVolume.toFixed(1)} mcm/d Cumulative)</span>
          </h3>
          
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={gasSupplyMix} layout="vertical" margin={{ top: 10, right: 10, left: 30, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2C2E" />
                <XAxis type="number" stroke="#666" fontSize={10} unit=" mcm/d" />
                <YAxis type="category" dataKey="name" stroke="#666" fontSize={10} width={120} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1A1C1E', borderColor: '#2A2C2E', color: '#FFF' }}
                  formatter={(value) => [`${value} mcm/d`, 'Flow Rate']}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {gasSupplyMix.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Liquid Hydrocarbons */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
          
          {/* Oil & Condensates Hub */}
          <div className="bg-[#1A1C1E] border border-[#2A2C2E] p-6 rounded-md flex-1">
            <h3 className="text-lg font-semibold text-white tracking-tight mb-4 flex items-center">
              <Anchor className="h-5 w-5 text-[#10B981] mr-2" />
              Liquid Hydrocarbons (Oil)
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-[#2A2C2E] pb-3">
                <span className="text-sm text-[#8E9299]">Domestic Oil Production</span>
                <span className="text-base font-bold text-white font-mono">{supply.domesticOil} <span className="text-xs text-[#8E9299]">kbd</span></span>
              </div>
              <div className="flex items-center justify-between border-b border-[#2A2C2E] pb-3">
                <span className="text-sm text-[#8E9299]">Condensate Extraction</span>
                <span className="text-base font-bold text-white font-mono">{supply.condensates} <span className="text-xs text-[#8E9299]">kbd</span></span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-[#8E9299]">Crude Exports (Forties/Brent)</span>
                <span className="text-base font-bold text-[#EF4444] font-mono">{supply.oilExports} <span className="text-xs text-[#8E9299]">kbd</span></span>
              </div>
            </div>

            <div className="mt-6 bg-[#121212] p-4 rounded border border-[#2A2C2E]">
              <div className="text-xs text-[#8E9299] uppercase tracking-wide">Refinery Feedstock Integration</div>
              <p className="text-xs text-white/70 mt-1 leading-relaxed">
                UK refineries process domestic North Sea light sweet crude while balancing heavier imported sour crudes from West Africa and Northern America.
              </p>
            </div>
          </div>

          {/* Inflow vs Outflow Net Pipeline Indicator */}
          <div className="bg-[#1A1C1E] border border-[#2A2C2E] p-6 rounded-md">
            <h4 className="text-xs font-semibold uppercase text-[#8E9299] tracking-wider mb-3">Live Interconnector Status</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#121212] p-3 rounded border border-[#2A2C2E]">
                <div className="text-[10px] text-[#8E9299] uppercase">Bacton (BBL Link)</div>
                <div className="text-sm font-bold text-[#EF4444] mt-1 flex items-center">
                  <ArrowRight className="h-3 w-3 mr-1 text-[#EF4444]" /> Exporting 10.5 mcm/d
                </div>
              </div>
              <div className="bg-[#121212] p-3 rounded border border-[#2A2C2E]">
                <div className="text-[10px] text-[#8E9299] uppercase">Bacton (IUK Link)</div>
                <div className="text-sm font-bold text-[#EF4444] mt-1 flex items-center">
                  <ArrowRight className="h-3 w-3 mr-1 text-[#EF4444]" /> Exporting 8.0 mcm/d
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  );
}
