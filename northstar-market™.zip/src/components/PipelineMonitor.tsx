import { useMemo, useState } from 'react';
import { pipelinesData } from '../data';
import { PipelineFlow } from '../types';
import { Network, Compass, Gauge, AlertTriangle, ArrowRight, CheckCircle2, ShieldClose } from 'lucide-react';

export default function PipelineMonitor() {
  const [selectedPipelineId, setSelectedPipelineId] = useState<string>('pipe_langeled');
  const pipelines = useMemo(() => pipelinesData, []);

  const activePipe = useMemo(() => {
    return pipelines.find(p => p.id === selectedPipelineId) || pipelines[0];
  }, [selectedPipelineId, pipelines]);

  return (
    <div id="pipeline_monitor_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 07 // Transit Logistics</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">Interconnector & Pipeline Overwatch</h2>
        </div>
        <div className="flex items-center space-x-2 text-[11px] font-mono mt-4 sm:mt-0">
          <span className="text-[#8E9299]">NTS Compressors:</span>
          <span className="text-[#10B981] font-bold">14 ONLINE</span>
          <span className="text-[#8E9299]">// Pressure:</span>
          <span className="text-white font-bold">Nominal</span>
        </div>
      </div>

      {/* Modular Pipeline Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {pipelines.map((pipe) => (
          <div 
            key={pipe.id}
            onClick={() => setSelectedPipelineId(pipe.id)}
            className={`p-4 rounded border transition cursor-pointer flex flex-col justify-between ${
              selectedPipelineId === pipe.id
                ? 'bg-[#25282B] border-[#C5A059]'
                : 'bg-[#121212] border-[#2A2C2E] hover:bg-[#1E2022]'
            }`}
          >
            <div className="flex items-center justify-between border-b border-[#2A2C2E]/40 pb-2 mb-3">
              <span className="text-xs font-extrabold text-white truncate max-w-[80%]">{pipe.name}</span>
              <Gauge className={`h-3.5 w-3.5 ${selectedPipelineId === pipe.id ? 'text-[#C5A059]' : 'text-[#8E9299]'}`} />
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-[#8E9299]">Current flow:</span>
                <span className="font-mono text-white font-bold">
                  {pipe.currentFlowMcm < 0 ? `Export: ${Math.abs(pipe.currentFlowMcm)}` : `${pipe.currentFlowMcm} mcm/d`}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8E9299]">Operating pressure:</span>
                <span className="font-mono text-white">{pipe.pressureBarg > 0 ? `${pipe.pressureBarg} Barg` : 'N/A'}</span>
              </div>
              <div className="flex justify-between items-center pt-1.5">
                <span className="text-[#8E9299]">Utilisation:</span>
                <span className={`font-mono font-bold ${pipe.utilisationPercent > 80 ? 'text-[#EF4444]' : 'text-white'}`}>
                  {pipe.utilisationPercent}%
                </span>
              </div>
            </div>

            {/* Tiny progress meter */}
            <div className="w-full bg-[#111] h-1 rounded overflow-hidden mt-3">
              <div 
                className={`h-full rounded ${pipe.utilisationPercent > 80 ? 'bg-[#EF4444]' : 'bg-[#C5A059]'}`} 
                style={{ width: `${pipe.utilisationPercent}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Downstream Chain Schematic (North Sea -> Terminal -> Transmission -> Distribution -> Consumers) */}
      <div className="bg-[#121212] border border-[#2A2C2E] p-6 rounded-md mb-6">
        <h3 className="text-xs font-bold text-[#C5A059] uppercase tracking-wider mb-5 flex items-center">
          <Network className="h-4 w-4 mr-2 text-[#C5A059]" />
          Downstream Infrastructure Transit Chain
        </h3>

        {/* Schematic Flow */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
          
          {/* Node 1: North Sea */}
          <div className="bg-[#1A1C1E] p-4 rounded border border-[#2A2C2E] text-center relative group hover:border-[#EF4444] transition">
            <span className="text-[9px] text-[#EF4444] font-bold uppercase tracking-widest">Stage 01</span>
            <div className="text-xs font-bold text-white mt-1">North Sea Fields</div>
            <p className="text-[10px] text-[#8E9299] mt-1.5">Domestic extraction rigs sending crude & wet gas mixtures.</p>
          </div>

          {/* Arrow 1 */}
          <div className="hidden md:flex justify-center text-slate-600">
            <ArrowRight className="h-5 w-5 animate-pulse text-[#C5A059]" />
          </div>

          {/* Node 2: Terminal */}
          <div className="bg-[#1A1C1E] p-4 rounded border border-[#2A2C2E] text-center relative group hover:border-[#C5A059] transition">
            <span className="text-[9px] text-[#C5A059] font-bold uppercase tracking-widest">Stage 02</span>
            <div className="text-xs font-bold text-white mt-1">Gas Terminals</div>
            <p className="text-[10px] text-[#8E9299] mt-1.5">Processing centers separating condensates, drying gas feed.</p>
          </div>

          {/* Arrow 2 */}
          <div className="hidden md:flex justify-center text-slate-600">
            <ArrowRight className="h-5 w-5 animate-pulse text-[#C5A059]" />
          </div>

          {/* Node 3: Transmission */}
          <div className="bg-[#1A1C1E] p-4 rounded border border-[#2A2C2E] text-center relative group hover:border-blue-500 transition">
            <span className="text-[9px] text-blue-400 font-bold uppercase tracking-widest">Stage 03</span>
            <div className="text-xs font-bold text-white mt-1">NTS Network</div>
            <p className="text-[10px] text-[#8E9299] mt-1.5">High pressure pipelines transiting volume across regions.</p>
          </div>

        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center mt-4">
          <div className="hidden md:block col-span-2"></div>
          {/* Vertical linkage representation placeholder */}
          <div className="hidden md:flex justify-center text-slate-600">
            <ArrowRight className="h-5 w-5 rotate-90 text-[#C5A059]" />
          </div>
          <div className="hidden md:block col-span-2"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center mt-4">
          
          <div className="hidden md:block"></div>
          <div className="hidden md:block"></div>

          {/* Node 4: Distribution */}
          <div className="bg-[#1A1C1E] p-4 rounded border border-[#2A2C2E] text-center relative group hover:border-[#F59E0B] transition">
            <span className="text-[9px] text-[#F59E0B] font-bold uppercase tracking-widest">Stage 04</span>
            <div className="text-xs font-bold text-white mt-1">Local Distribution</div>
            <p className="text-[10px] text-[#8E9299] mt-1.5">Regional networks odorizing & letting down pressure.</p>
          </div>

          {/* Arrow 4 */}
          <div className="hidden md:flex justify-center text-slate-600">
            <ArrowRight className="h-5 w-5 animate-pulse text-[#C5A059]" />
          </div>

          {/* Node 5: Consumers */}
          <div className="bg-[#1A1C1E] p-4 rounded border border-[#2A2C2E] text-center relative group hover:border-[#10B981] transition">
            <span className="text-[9px] text-[#10B981] font-bold uppercase tracking-widest">Stage 05</span>
            <div className="text-xs font-bold text-white mt-1">End Consumers</div>
            <p className="text-[10px] text-[#8E9299] mt-1.5">Providing heating, CCGT fuel, and industrial input.</p>
          </div>

        </div>
      </div>
    </div>
  );
}
