import { useMemo, useState } from 'react';
import { storageFacilitiesData } from '../data';
import { StorageFacility } from '../types';
import { Database, AlertTriangle, ArrowUp, ArrowDown, Activity, ShieldAlert } from 'lucide-react';

export default function StorageIntelligence() {
  const [selectedStore, setSelectedStore] = useState<string>('store_rough');

  const facilities = useMemo(() => storageFacilitiesData, []);

  const activeStore = useMemo(() => {
    return facilities.find(f => f.id === selectedStore) || facilities[0];
  }, [selectedStore, facilities]);

  // Aggregate stats
  const totalCapacity = facilities.reduce((sum, f) => sum + f.capacityMcm, 0);
  const totalInventory = facilities.reduce((sum, f) => sum + f.currentInventoryMcm, 0);
  const averageUtilisation = Math.round((totalInventory / totalCapacity) * 100);

  // Generate ASCII/Block progress bar
  const generateProgressBar = (percent: number) => {
    const totalBlocks = 12;
    const filledBlocks = Math.round((percent / 100) * totalBlocks);
    const emptyBlocks = totalBlocks - filledBlocks;
    
    return '█'.repeat(filledBlocks) + '░'.repeat(emptyBlocks);
  };

  return (
    <div id="storage_intelligence_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 05 // Strategic Reserves</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">Storage Intelligence Overwatch</h2>
        </div>
        
        {/* Terminal Style Aggregate Gauge */}
        <div className="mt-4 sm:mt-0 bg-[#121212] p-3 rounded border border-[#2A2C2E] font-mono flex items-center space-x-4">
          <div>
            <div className="text-[10px] text-[#8E9299] uppercase tracking-wider">UK Net Storage Level</div>
            <div className="text-sm font-bold text-[#10B981] flex items-center mt-1">
              <span className="mr-2 text-white">{generateProgressBar(averageUtilisation)}</span>
              {averageUtilisation}%
            </div>
          </div>
          <div className="border-l border-[#2A2C2E] pl-4">
            <div className="text-[10px] text-[#8E9299] uppercase">Total Inventory</div>
            <div className="text-sm font-extrabold text-white mt-1">{totalInventory} / {totalCapacity} mcm</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left: Facilities List & Selection */}
        <div className="lg:col-span-5 space-y-3">
          <h3 className="text-xs font-bold text-[#8E9299] uppercase tracking-wider mb-2">Storage Node Directory</h3>
          
          {facilities.map((fac) => (
            <div 
              key={fac.id}
              onClick={() => setSelectedStore(fac.id)}
              className={`p-4 rounded border transition cursor-pointer flex items-center justify-between ${
                selectedStore === fac.id
                  ? 'bg-[#25282B] border-[#C5A059]'
                  : 'bg-[#121212] border-[#2A2C2E] hover:bg-[#1E2022]'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Database className={`h-5 w-5 ${selectedStore === fac.id ? 'text-[#C5A059]' : 'text-[#8E9299]'}`} />
                <div>
                  <h4 className="text-xs font-bold text-white">{fac.name}</h4>
                  <p className="text-[10px] text-[#8E9299] mt-0.5">{fac.type} // {fac.operator}</p>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-xs font-bold text-white font-mono">{fac.utilisationPercent}%</div>
                <div className="text-[9px] text-[#10B981] font-mono">{generateProgressBar(fac.utilisationPercent)}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Right: Active Detail Oversight */}
        <div className="lg:col-span-7 bg-[#1A1C1E] border border-[#2A2C2E] p-6 rounded-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-[#2A2C2E] pb-4 mb-4">
              <div>
                <span className="text-[9px] font-bold text-[#C5A059] uppercase tracking-widest">{activeStore.type} Node Details</span>
                <h3 className="text-lg font-bold text-white tracking-tight mt-1">{activeStore.name}</h3>
              </div>
              <span className="px-2.5 py-1 text-[10px] font-bold bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/20 rounded">
                Status: {activeStore.maintenanceStatus}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-[#121212] p-4 rounded border border-[#2A2C2E]/60">
                <span className="text-[10px] text-[#8E9299] uppercase tracking-wide">Injection Flow Deliverability</span>
                <div className="text-lg font-extrabold text-[#F59E0B] font-mono mt-2 flex items-center">
                  <ArrowDown className="h-4 w-4 mr-1 text-[#F59E0B]" />
                  {activeStore.injectionRateMcm} <span className="text-xs font-normal text-[#8E9299] ml-1">mcm/d max</span>
                </div>
              </div>

              <div className="bg-[#121212] p-4 rounded border border-[#2A2C2E]/60">
                <span className="text-[10px] text-[#8E9299] uppercase tracking-wide">Withdrawal Flow Deliverability</span>
                <div className="text-lg font-extrabold text-[#60A5FA] font-mono mt-2 flex items-center">
                  <ArrowUp className="h-4 w-4 mr-1 text-[#60A5FA]" />
                  {activeStore.withdrawalRateMcm} <span className="text-xs font-normal text-[#8E9299] ml-1">mcm/d max</span>
                </div>
              </div>
            </div>

            {/* Micro Ascii Dashboard Panel */}
            <div className="bg-[#121212] p-4 rounded border border-[#2A2C2E] font-mono mb-4">
              <div className="text-xs text-[#C5A059] uppercase font-bold tracking-wider border-b border-[#2A2C2E] pb-2 mb-3 flex items-center justify-between">
                <span>RESERVE BUFFER MATRIX</span>
                <Activity className="h-3.5 w-3.5 text-[#C5A059]" />
              </div>
              
              <div className="space-y-3 text-xs text-[#E5E5E5]">
                <div className="flex justify-between">
                  <span>FACILITY CAPACITY:</span>
                  <span className="text-white font-bold">{activeStore.capacityMcm} mcm</span>
                </div>
                <div className="flex justify-between">
                  <span>CURRENT WORKING VOLUME:</span>
                  <span className="text-[#10B981] font-bold">{activeStore.currentInventoryMcm} mcm</span>
                </div>
                <div className="flex justify-between items-center border-t border-[#2A2C2E] pt-2">
                  <span>ESTIMATED SECURITY WINDOW:</span>
                  <span className="text-[#F59E0B] font-bold text-sm bg-[#F59E0B]/10 px-1.5 py-0.5 rounded">{activeStore.daysOfSupplyRemaining} days of continuous supply</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#121212] p-3 rounded border border-[#2A2C2E]/60 text-[11px] text-[#8E9299] flex items-center">
            <ShieldAlert className="h-4 w-4 mr-2 text-[#C5A059] shrink-0" />
            <span>
              Rough offshore storage delivers heavy seasonal buffering. Faster onshore caverns like Aldbrough offer daily market arbitrage operations.
            </span>
          </div>
        </div>

      </div>
    </div>
  );
}
