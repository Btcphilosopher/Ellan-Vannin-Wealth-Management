import { useState, useMemo } from 'react';
import { generateHistoricalPrices } from '../data';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, TrendingDown, Layers, Landmark, DollarSign, Leaf, Zap, HelpCircle } from 'lucide-react';

export default function SpotMarket() {
  const [timeframe, setTimeframe] = useState<'1D' | '1W' | '1M' | '1Y' | '10Y'>('1M');
  const [activeSeries, setActiveSeries] = useState<'gas' | 'oil' | 'power' | 'carbon'>('gas');

  // Load baseline historical data
  const rawData = useMemo(() => generateHistoricalPrices(), []);

  // Filter or scale data to simulate different time horizons realistically
  const chartData = useMemo(() => {
    switch (timeframe) {
      case '1D':
        // Generate hourly points for 1 day
        return Array.from({ length: 24 }).map((_, i) => {
          const hour = `${String(i).padStart(2, '0')}:00`;
          const noise = Math.sin(i / 3) * 0.4;
          return {
            date: hour,
            nbpSpot: Number((78.2 + noise).toFixed(1)),
            dayAhead: Number((78.5 + noise * 1.1).toFixed(1)),
            monthAhead: 81.2,
            brentCrude: Number((74.5 + noise * 0.2).toFixed(2)),
            ukCarbon: Number((41.8 + noise * 0.05).toFixed(2)),
            electricityPrice: Number((69.2 + noise * 0.8).toFixed(1)),
          };
        });
      case '1W':
        return rawData.slice(-7);
      case '1M':
        return rawData.slice(-30);
      case '1Y':
        // Downsample or show full 120 points
        return rawData;
      case '10Y':
        // Generate multi-year aggregated points (2016-2026) to reflect 10-year commodities macrocycle
        return [
          { date: '2016', nbpSpot: 42.1, dayAhead: 41.5, monthAhead: 43.2, brentCrude: 45.1, ukCarbon: 12.4, electricityPrice: 38.5 },
          { date: '2017', nbpSpot: 45.6, dayAhead: 44.8, monthAhead: 46.5, brentCrude: 54.3, ukCarbon: 14.8, electricityPrice: 42.1 },
          { date: '2018', nbpSpot: 58.2, dayAhead: 57.1, monthAhead: 59.0, brentCrude: 71.3, ukCarbon: 18.2, electricityPrice: 56.4 },
          { date: '2019', nbpSpot: 36.4, dayAhead: 35.8, monthAhead: 38.1, brentCrude: 64.2, ukCarbon: 22.5, electricityPrice: 41.2 },
          { date: '2020', nbpSpot: 25.1, dayAhead: 24.5, monthAhead: 27.2, brentCrude: 41.8, ukCarbon: 26.1, electricityPrice: 32.5 },
          { date: '2021', nbpSpot: 115.4, dayAhead: 114.2, monthAhead: 118.0, brentCrude: 70.9, ukCarbon: 55.4, electricityPrice: 125.1 },
          { date: '2022', nbpSpot: 285.0, dayAhead: 290.5, monthAhead: 278.4, brentCrude: 99.0, ukCarbon: 78.5, electricityPrice: 245.0 },
          { date: '2023', nbpSpot: 105.2, dayAhead: 104.1, monthAhead: 110.5, brentCrude: 82.1, ukCarbon: 56.2, electricityPrice: 94.2 },
          { date: '2024', nbpSpot: 85.4, dayAhead: 86.0, monthAhead: 89.1, brentCrude: 80.5, ukCarbon: 48.0, electricityPrice: 78.1 },
          { date: '2025', nbpSpot: 76.8, dayAhead: 76.2, monthAhead: 80.4, brentCrude: 72.8, ukCarbon: 44.5, electricityPrice: 66.8 },
          { date: '2026', nbpSpot: 78.2, dayAhead: 78.5, monthAhead: 82.0, brentCrude: 74.5, ukCarbon: 41.8, electricityPrice: 69.2 },
        ];
    }
  }, [timeframe, rawData]);

  // Current real-time display states
  const currentPrices = {
    nbpSpot: 78.2,
    dayAhead: 78.5,
    monthAhead: 82.0,
    seasonalForward: 88.5,
    brentCrude: 74.50,
    ukCarbon: 41.80,
    electricityPrice: 69.20,
  };

  return (
    <div id="spot_market_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 01 // Commodity Spot Operations</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">Spot Market Intelligence</h2>
        </div>
        
        {/* Timeframe Selectors */}
        <div className="flex space-x-1 bg-[#121212] p-1 rounded-md border border-[#2A2C2E] mt-4 lg:mt-0">
          {(['1D', '1W', '1M', '1Y', '10Y'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTimeframe(t)}
              className={`px-3 py-1.5 text-xs font-semibold tracking-wide rounded transition ${
                timeframe === t 
                  ? 'bg-[#C5A059] text-[#121212]' 
                  : 'text-[#8E9299] hover:text-white hover:bg-[#25282B]'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Prices */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-8">
        
        {/* NBP Spot */}
        <div className={`bg-[#121212] border-y border-r border-[#2A2C2E] border-l-[3px] p-4 rounded-r hover:border-[#C5A059] transition group cursor-pointer ${activeSeries === 'gas' ? 'border-l-[#C5A059] bg-[#1A1C1E]' : 'border-l-[#8E9299]/30'}`} onClick={() => setActiveSeries('gas')}>
          <div className="flex items-center justify-between text-[#8E9299] text-xs font-semibold uppercase">
            <span>NBP Gas Spot</span>
            <Layers className="h-3.5 w-3.5 text-[#C5A059]" />
          </div>
          <div className="text-2xl font-bold text-white mt-1 group-hover:text-[#C5A059] transition">{currentPrices.nbpSpot} <span className="text-xs text-[#8E9299]">p/th</span></div>
          <div className="text-xs text-[#10B981] font-semibold mt-1 flex items-center">
            <TrendingUp className="h-3 w-3 mr-0.5" /> +1.2%
          </div>
        </div>

        {/* Day Ahead */}
        <div className={`bg-[#121212] border-y border-r border-[#2A2C2E] border-l-[3px] p-4 rounded-r hover:border-[#C5A059] transition group cursor-pointer ${activeSeries === 'gas' ? 'border-l-[#C5A059] bg-[#1A1C1E]' : 'border-l-[#8E9299]/30'}`} onClick={() => setActiveSeries('gas')}>
          <div className="flex items-center justify-between text-[#8E9299] text-xs font-semibold uppercase">
            <span>Day-Ahead</span>
            <Layers className="h-3.5 w-3.5 text-[#C5A059]" />
          </div>
          <div className="text-2xl font-bold text-white mt-1 group-hover:text-[#C5A059] transition">{currentPrices.dayAhead} <span className="text-xs text-[#8E9299]">p/th</span></div>
          <div className="text-xs text-[#10B981] font-semibold mt-1 flex items-center">
            <TrendingUp className="h-3 w-3 mr-0.5" /> +1.5%
          </div>
        </div>

        {/* Month Ahead */}
        <div className={`bg-[#121212] border-y border-r border-[#2A2C2E] border-l-[3px] p-4 rounded-r hover:border-[#C5A059] transition group cursor-pointer ${activeSeries === 'gas' ? 'border-l-[#C5A059] bg-[#1A1C1E]' : 'border-l-[#8E9299]/30'}`} onClick={() => setActiveSeries('gas')}>
          <div className="flex items-center justify-between text-[#8E9299] text-xs font-semibold uppercase">
            <span>Month-Ahead</span>
            <Layers className="h-3.5 w-3.5 text-slate-500" />
          </div>
          <div className="text-2xl font-bold text-white mt-1 group-hover:text-[#C5A059] transition">{currentPrices.monthAhead} <span className="text-xs text-[#8E9299]">p/th</span></div>
          <div className="text-xs text-[#F59E0B] font-semibold mt-1 flex items-center">
            <TrendingUp className="h-3 w-3 mr-0.5" /> +0.4%
          </div>
        </div>

        {/* Seasonal Forwards */}
        <div className={`bg-[#121212] border-y border-r border-[#2A2C2E] border-l-[3px] p-4 rounded-r hover:border-[#C5A059] transition group cursor-pointer ${activeSeries === 'gas' ? 'border-l-[#C5A059] bg-[#1A1C1E]' : 'border-l-[#8E9299]/30'}`} onClick={() => setActiveSeries('gas')}>
          <div className="flex items-center justify-between text-[#8E9299] text-xs font-semibold uppercase">
            <span>Seasonal Fwd</span>
            <Layers className="h-3.5 w-3.5 text-slate-500" />
          </div>
          <div className="text-2xl font-bold text-white mt-1 group-hover:text-[#C5A059] transition">{currentPrices.seasonalForward} <span className="text-xs text-[#8E9299]">p/th</span></div>
          <div className="text-xs text-[#EF4444] font-semibold mt-1 flex items-center">
            <TrendingDown className="h-3 w-3 mr-0.5" /> -0.8%
          </div>
        </div>

        {/* Brent Crude */}
        <div className={`bg-[#121212] border-y border-r border-[#2A2C2E] border-l-[3px] p-4 rounded-r hover:border-[#C5A059] transition group cursor-pointer ${activeSeries === 'oil' ? 'border-l-[#10B981] bg-[#1A1C1E]' : 'border-l-[#8E9299]/30'}`} onClick={() => setActiveSeries('oil')}>
          <div className="flex items-center justify-between text-[#8E9299] text-xs font-semibold uppercase">
            <span>Brent Crude</span>
            <DollarSign className="h-3.5 w-3.5 text-[#10B981]" />
          </div>
          <div className="text-2xl font-bold text-white mt-1 group-hover:text-[#C5A059] transition">${currentPrices.brentCrude.toFixed(2)}</div>
          <div className="text-xs text-[#EF4444] font-semibold mt-1 flex items-center">
            <TrendingDown className="h-3 w-3 mr-0.5" /> -0.6%
          </div>
        </div>

        {/* UK Carbon */}
        <div className={`bg-[#121212] border-y border-r border-[#2A2C2E] border-l-[3px] p-4 rounded-r hover:border-[#C5A059] transition group cursor-pointer ${activeSeries === 'carbon' ? 'border-l-[#3B82F6] bg-[#1A1C1E]' : 'border-l-[#8E9299]/30'}`} onClick={() => setActiveSeries('carbon')}>
          <div className="flex items-center justify-between text-[#8E9299] text-xs font-semibold uppercase">
            <span>Carbon Price</span>
            <Leaf className="h-3.5 w-3.5 text-[#10B981]" />
          </div>
          <div className="text-2xl font-bold text-white mt-1 group-hover:text-[#C5A059] transition">£{currentPrices.ukCarbon.toFixed(2)}</div>
          <div className="text-xs text-[#10B981] font-semibold mt-1 flex items-center">
            <TrendingUp className="h-3 w-3 mr-0.5" /> +2.3%
          </div>
        </div>

        {/* Electricity */}
        <div className={`bg-[#121212] border-y border-r border-[#2A2C2E] border-l-[3px] p-4 rounded-r hover:border-[#C5A059] transition group cursor-pointer ${activeSeries === 'power' ? 'border-l-[#F59E0B] bg-[#1A1C1E]' : 'border-l-[#8E9299]/30'}`} onClick={() => setActiveSeries('power')}>
          <div className="flex items-center justify-between text-[#8E9299] text-xs font-semibold uppercase">
            <span>UK Power</span>
            <Zap className="h-3.5 w-3.5 text-[#F59E0B]" />
          </div>
          <div className="text-2xl font-bold text-white mt-1 group-hover:text-[#C5A059] transition">£{currentPrices.electricityPrice.toFixed(1)} <span className="text-[10px] text-[#8E9299]">/MWh</span></div>
          <div className="text-xs text-[#10B981] font-semibold mt-1 flex items-center">
            <TrendingUp className="h-3 w-3 mr-0.5" /> +3.4%
          </div>
        </div>
      </div>

      {/* Interactive Chart Container */}
      <div className="bg-[#121212] border border-[#2A2C2E] p-6 rounded-md">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-white tracking-tight">
              {activeSeries === 'gas' && 'UK Natural Gas (NBP) Price Spectrum'}
              {activeSeries === 'oil' && 'Brent Crude Oil Benchmark'}
              {activeSeries === 'power' && 'UK Baseload Electricity Forwards'}
              {activeSeries === 'carbon' && 'UK Carbon Allowance (UK ETS) Price Trend'}
            </h3>
            <p className="text-xs text-[#8E9299] mt-1">
              {activeSeries === 'gas' && 'Tracking NBP Spot, Day-Ahead, and Month-Ahead forward curves in p/th.'}
              {activeSeries === 'oil' && 'Brent crude oil benchmark pricing in USD per barrel (bbl).'}
              {activeSeries === 'power' && 'Baseload electricity contracts indexed in GBP per Megawatt Hour.'}
              {activeSeries === 'carbon' && 'UK Emissions Trading Scheme spot permit cost per tCO2e.'}
            </p>
          </div>

          {/* Commodity Series Selector */}
          <div className="flex space-x-2 mt-4 sm:mt-0">
            <button
              onClick={() => setActiveSeries('gas')}
              className={`px-3 py-1.5 rounded text-xs font-medium border ${
                activeSeries === 'gas'
                  ? 'border-[#C5A059] bg-[#C5A059]/10 text-[#C5A059]'
                  : 'border-[#2A2C2E] text-[#8E9299] hover:text-white'
              }`}
            >
              NBP Gas
            </button>
            <button
              onClick={() => setActiveSeries('oil')}
              className={`px-3 py-1.5 rounded text-xs font-medium border ${
                activeSeries === 'oil'
                  ? 'border-[#10B981] bg-[#10B981]/10 text-[#10B981]'
                  : 'border-[#2A2C2E] text-[#8E9299] hover:text-white'
              }`}
            >
              Brent Crude
            </button>
            <button
              onClick={() => setActiveSeries('power')}
              className={`px-3 py-1.5 rounded text-xs font-medium border ${
                activeSeries === 'power'
                  ? 'border-[#F59E0B] bg-[#F59E0B]/10 text-[#F59E0B]'
                  : 'border-[#2A2C2E] text-[#8E9299] hover:text-white'
              }`}
            >
              UK Power
            </button>
            <button
              onClick={() => setActiveSeries('carbon')}
              className={`px-3 py-1.5 rounded text-xs font-medium border ${
                activeSeries === 'carbon'
                  ? 'border-[#3B82F6] bg-[#3B82F6]/10 text-[#3B82F6]'
                  : 'border-[#2A2C2E] text-[#8E9299] hover:text-white'
              }`}
            >
              Carbon
            </button>
          </div>
        </div>

        {/* Chart Window */}
        <div className="h-[380px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" />
              <XAxis 
                dataKey="date" 
                stroke="#666" 
                fontSize={10}
                tickLine={false}
              />
              <YAxis 
                stroke="#666" 
                fontSize={10} 
                domain={['auto', 'auto']}
                tickLine={false}
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1A1C1E', borderColor: '#2A2C2E', color: '#FFF', borderRadius: 4 }} 
                labelStyle={{ fontWeight: 'bold', color: '#C5A059' }}
              />
              <Legend verticalAlign="top" height={36} iconSize={10} wrapperStyle={{ fontSize: 11 }} />
              
              {activeSeries === 'gas' && (
                <>
                  <Line name="NBP Spot" type="monotone" dataKey="nbpSpot" stroke="#C5A059" strokeWidth={2} dot={false} activeDot={{ r: 6 }} />
                  <Line name="Day-Ahead" type="monotone" dataKey="dayAhead" stroke="#A78BFA" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                  <Line name="Month-Ahead" type="monotone" dataKey="monthAhead" stroke="#60A5FA" strokeWidth={1.5} strokeDasharray="2 2" dot={false} />
                </>
              )}

              {activeSeries === 'oil' && (
                <Line name="Brent Oil ($/bbl)" type="monotone" dataKey="brentCrude" stroke="#10B981" strokeWidth={2.5} dot={false} activeDot={{ r: 6 }} />
              )}

              {activeSeries === 'power' && (
                <Line name="Baseload Power (£/MWh)" type="monotone" dataKey="electricityPrice" stroke="#F59E0B" strokeWidth={2.5} dot={false} activeDot={{ r: 6 }} />
              )}

              {activeSeries === 'carbon' && (
                <Line name="UK Carbon Allowance (£/t)" type="monotone" dataKey="ukCarbon" stroke="#3B82F6" strokeWidth={2.5} dot={false} activeDot={{ r: 6 }} />
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Legend footnotes */}
        <div className="flex flex-wrap items-center justify-between text-[11px] text-[#8E9299] border-t border-[#2A2C2E] pt-4 mt-4 gap-2">
          <div className="flex items-center space-x-4">
            <span className="flex items-center">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10B981] mr-1.5 inline-block"></span>
              Sovereign wealth asset filter active
            </span>
            <span className="flex items-center">
              <span className="w-2.5 h-2.5 rounded-full bg-[#C5A059] mr-1.5 inline-block"></span>
              National Gas Portal Synced
            </span>
          </div>
          <div>Data feeds updated: <span className="font-mono text-[#C5A059]">Real-time (15m delay)</span></div>
        </div>
      </div>
    </div>
  );
}
