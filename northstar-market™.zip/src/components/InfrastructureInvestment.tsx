import { useMemo, useState } from 'react';
import { infrastructureAssets } from '../data';
import { InfrastructureAsset } from '../types';
import { Award, ShieldAlert, BarChart3, ArrowUpDown, ChevronRight, Check, Leaf, Landmark } from 'lucide-react';

export default function InfrastructureInvestment() {
  const [sortBy, setSortBy] = useState<'assetScore' | 'irr' | 'estimatedValueGbp' | 'remainingLifeYears'>('assetScore');
  const [selectedAssetId, setSelectedAssetId] = useState<string>('store_rough');

  const sortedAssets = useMemo(() => {
    return [...infrastructureAssets].sort((a, b) => {
      if (sortBy === 'estimatedValueGbp' || sortBy === 'remainingLifeYears') {
        return b[sortBy] - a[sortBy];
      }
      return b[sortBy] - a[sortBy];
    });
  }, [sortBy]);

  const selectedAsset = useMemo(() => {
    return infrastructureAssets.find(a => a.id === selectedAssetId) || infrastructureAssets[0];
  }, [selectedAssetId]);

  return (
    <div id="infrastructure_investment_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 10 // Capital Allocation</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">Infrastructure Investment Ledger</h2>
        </div>

        {/* Sort filters */}
        <div className="flex items-center space-x-2 mt-4 md:mt-0">
          <span className="text-xs text-[#8E9299] font-semibold">Sort By Yield:</span>
          <div className="flex bg-[#121212] p-1 rounded border border-[#2A2C2E]">
            {(['assetScore', 'irr', 'estimatedValueGbp', 'remainingLifeYears'] as const).map((opt) => (
              <button
                key={opt}
                onClick={() => setSortBy(opt)}
                className={`px-2.5 py-1.5 text-[10px] font-bold rounded transition ${
                  sortBy === opt
                    ? 'bg-[#C5A059] text-[#1A1C1E]'
                    : 'text-[#8E9299] hover:text-white'
                }`}
              >
                {opt === 'assetScore' && 'Asset Score'}
                {opt === 'irr' && 'Target IRR'}
                {opt === 'estimatedValueGbp' && 'Value'}
                {opt === 'remainingLifeYears' && 'Remaining Life'}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Table: List of Assets sorted */}
        <div className="lg:col-span-7 bg-[#121212] rounded-lg border border-[#2A2C2E] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[#1E2022] text-[#8E9299] font-bold border-b border-[#2A2C2E]">
                  <th className="p-4">Rank</th>
                  <th className="p-4">Asset Name</th>
                  <th className="p-4 text-center">Quality Score</th>
                  <th className="p-4 text-center">Target IRR</th>
                  <th className="p-4 text-right">Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2A2C2E]">
                {sortedAssets.map((asset, index) => (
                  <tr 
                    key={asset.id} 
                    onClick={() => setSelectedAssetId(asset.id)}
                    className={`cursor-pointer transition hover:bg-[#1E2022] ${
                      selectedAssetId === asset.id ? 'bg-[#C5A059]/10 border-l-2 border-l-[#C5A059]' : ''
                    }`}
                  >
                    <td className="p-4 font-mono font-bold text-[#8E9299]">{String(index + 1).padStart(2, '0')}</td>
                    <td className="p-4">
                      <div className="font-bold text-white">{asset.name}</div>
                      <div className="text-[10px] text-[#8E9299]">{asset.type}</div>
                    </td>
                    <td className="p-4 text-center">
                      <span className="font-mono font-bold text-white bg-[#25282B] px-2 py-0.5 rounded border border-[#2A2C2E]">
                        {asset.assetScore}
                      </span>
                    </td>
                    <td className="p-4 text-center font-mono font-bold text-[#10B981]">+{asset.irr}%</td>
                    <td className="p-4 text-right font-mono text-[#8E9299]">£{(asset.estimatedValueGbp / 1e9).toFixed(1)}B</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Asset Analysis Dossier Card */}
        <div className="lg:col-span-5 bg-[#1A1C1E] border border-[#2A2C2E] p-6 rounded-md flex flex-col justify-between">
          <div>
            <div className="border-b border-[#2A2C2E] pb-4 mb-4 flex items-center justify-between">
              <div>
                <span className="text-[9px] font-bold text-[#C5A059] uppercase tracking-wider">Asset Investment Analysis</span>
                <h3 className="text-lg font-bold text-white tracking-tight mt-1">{selectedAsset.name}</h3>
              </div>
              <div className="h-10 w-10 rounded bg-[#C5A059]/10 flex items-center justify-center border border-[#C5A059]/20">
                <Landmark className="h-5 w-5 text-[#C5A059]" />
              </div>
            </div>

            <p className="text-xs text-[#8E9299] italic leading-relaxed mb-6">
              "{selectedAsset.description}"
            </p>

            <div className="space-y-4">
              <div className="bg-[#121212] p-4 rounded border border-[#2A2C2E]/60">
                <div className="text-[10px] text-[#8E9299] uppercase tracking-wide">Target IRR Yield</div>
                <div className="text-2xl font-black text-[#10B981] font-mono mt-1 flex items-center">
                  +{selectedAsset.irr}% <span className="text-xs font-normal text-[#8E9299] ml-2">Compound Annual</span>
                </div>
              </div>

              {/* Carbon Exposure and maintenance indicators */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#121212] p-3 rounded border border-[#2A2C2E] text-center flex flex-col justify-between">
                  <span className="text-[9px] text-[#8E9299] uppercase">Carbon Policy Exposure</span>
                  <div className="flex items-center justify-center mt-2">
                    <Leaf className={`h-4 w-4 mr-1.5 ${
                      selectedAsset.carbonExposure === 'High' ? 'text-[#EF4444]' : 'text-[#10B981]'
                    }`} />
                    <span className="text-xs font-bold text-white">{selectedAsset.carbonExposure}</span>
                  </div>
                </div>

                <div className="bg-[#121212] p-3 rounded border border-[#2A2C2E] text-center flex flex-col justify-between">
                  <span className="text-[9px] text-[#8E9299] uppercase">Priority Re-rating</span>
                  <div className="mt-2 text-xs font-extrabold text-white">
                    {selectedAsset.irr > 14 ? 'CORE ACQUIRE' : 'STABLE HOLD'}
                  </div>
                </div>
              </div>

              {/* Maintenance risk alert */}
              {selectedAsset.maintenanceRisk === 'High' && (
                <div className="bg-[#EF4444]/15 border border-[#EF4444]/30 p-3 rounded text-[11px] text-[#EF4444] flex items-center">
                  <ShieldAlert className="h-4 w-4 mr-2 shrink-0" />
                  <span>High maintenance risk West of Shetland dictates conservative cash reserves allocation.</span>
                </div>
              )}
            </div>
          </div>

          <div className="mt-6 border-t border-[#2A2C2E] pt-4">
            <button className="w-full bg-[#C5A059] text-[#1A1C1E] py-2.5 rounded font-black text-xs hover:bg-[#B38F4B] transition flex items-center justify-center uppercase tracking-wider">
              <Check className="h-4 w-4 mr-2" /> Add to Ellan Vannin Portfolio Strategy
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
