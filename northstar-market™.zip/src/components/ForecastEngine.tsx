import { useState, useMemo } from 'react';
import { forecastDemandData } from '../data';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, LineChart, Line } from 'recharts';
import { LineChart as ChartIcon, Zap, Sliders, Play, Calculator } from 'lucide-react';

export default function ForecastEngine() {
  const [model, setModel] = useState<'ARIMA' | 'Prophet' | 'ExpSmoothing'>('ARIMA');
  const [metric, setMetric] = useState<'GasDemand' | 'OilDemand' | 'StorageInventory'>('GasDemand');
  const [scenario, setScenario] = useState<'Baseline' | 'Optimistic' | 'Pessimistic'>('Baseline');

  const rawData = useMemo(() => forecastDemandData(), []);

  // Compute forecast outputs based on selections
  const finalChartData = useMemo(() => {
    // We adjust values to reflect the chosen metric
    let multiplier = 1;
    if (metric === 'OilDemand') multiplier = 4.2; // scale to simulate oil (kbd)
    else if (metric === 'StorageInventory') multiplier = 6.8; // scale to simulate storage (mcm)

    return rawData.map((d) => {
      const scaleVal = (val?: number) => val !== undefined ? Number((val * multiplier).toFixed(1)) : undefined;
      const calcArima = d.arimaDemand * multiplier;
      const calcProphet = d.prophetDemand * multiplier;
      const calcExp = d.expSmoothingDemand * multiplier;

      let chosenForecast = calcArima;
      if (model === 'Prophet') chosenForecast = calcProphet;
      if (model === 'ExpSmoothing') chosenForecast = calcExp;

      // Scenario ranges
      let optimisticFactor = 0.9;
      let pessimisticFactor = 1.12;

      if (metric === 'StorageInventory') {
        // Optimistic storage means full reserves (higher)
        optimisticFactor = 1.15;
        pessimisticFactor = 0.85;
      }

      const optVal = Number((chosenForecast * optimisticFactor).toFixed(1));
      const pesVal = Number((chosenForecast * pessimisticFactor).toFixed(1));

      return {
        date: d.date,
        actual: scaleVal(d.actualDemand),
        prediction: Number(chosenForecast.toFixed(1)),
        lowerConfidence: Number((chosenForecast * 0.94).toFixed(1)),
        upperConfidence: Number((chosenForecast * 1.06).toFixed(1)),
        scenarioVal: scenario === 'Baseline' ? Number(chosenForecast.toFixed(1)) : scenario === 'Optimistic' ? optVal : pesVal,
      };
    });
  }, [rawData, model, metric, scenario]);

  return (
    <div id="forecast_engine_module" className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between pb-6 border-b border-[#2A2C2E] mb-6">
        <div>
          <span className="text-xs font-semibold tracking-wider text-[#C5A059] uppercase">Module 09 // Quantitative Modeling</span>
          <h2 className="text-2xl font-bold text-white tracking-tight mt-1">Predictive Forecasting Engine</h2>
        </div>

        {/* Model Selector tabs */}
        <div className="flex bg-[#121212] p-1 rounded border border-[#2A2C2E] mt-4 lg:mt-0">
          {(['ARIMA', 'Prophet', 'ExpSmoothing'] as const).map((m) => (
            <button
               key={m}
               onClick={() => setModel(m)}
               className={`px-3 py-1.5 text-xs font-bold rounded transition ${
                model === m
                   ? 'bg-[#C5A059] text-[#1A1C1E]'
                   : 'text-[#8E9299] hover:text-white'
               }`}
            >
              {m === 'ExpSmoothing' ? 'Exponential Smoothing' : m}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Controls Panel */}
        <div className="lg:col-span-4 bg-[#1A1C1E] border border-[#2A2C2E] p-5 rounded-md flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight mb-4 flex items-center">
              <Sliders className="h-4 w-4 mr-2 text-[#C5A059]" />
              Model Parameters
            </h3>

            {/* Target Metric Selection */}
            <div className="space-y-4">
              <div>
                <label className="text-[10px] text-[#8E9299] uppercase font-bold block mb-2">Target Variable</label>
                <div className="grid grid-cols-1 gap-2">
                  <button 
                    onClick={() => setMetric('GasDemand')}
                    className={`p-2.5 rounded text-xs font-bold text-left border ${
                      metric === 'GasDemand' ? 'border-[#C5A059] bg-[#C5A059]/10 text-white' : 'border-[#2A2C2E] text-[#8E9299] hover:text-white'
                    }`}
                  >
                    National Gas Demand (mcm/d)
                  </button>
                  <button 
                    onClick={() => setMetric('OilDemand')}
                    className={`p-2.5 rounded text-xs font-bold text-left border ${
                      metric === 'OilDemand' ? 'border-[#10B981] bg-[#10B981]/10 text-white' : 'border-[#2A2C2E] text-[#8E9299] hover:text-white'
                    }`}
                  >
                    Crude Oil Demand (kbd)
                  </button>
                  <button 
                    onClick={() => setMetric('StorageInventory')}
                    className={`p-2.5 rounded text-xs font-bold text-left border ${
                      metric === 'StorageInventory' ? 'border-[#3B82F6] bg-[#3B82F6]/10 text-white' : 'border-[#2A2C2E] text-[#8E9299] hover:text-white'
                    }`}
                  >
                    Strategic Storage Inventory (mcm)
                  </button>
                </div>
              </div>

              {/* Scenario Toggles */}
              <div>
                <label className="text-[10px] text-[#8E9299] uppercase font-bold block mb-2">Macroeconomic Scenario</label>
                <div className="flex bg-[#121212] p-1 rounded border border-[#2A2C2E]">
                  {(['Optimistic', 'Baseline', 'Pessimistic'] as const).map((scen) => (
                    <button
                      key={scen}
                      onClick={() => setScenario(scen)}
                      className={`flex-1 py-2 text-[10px] font-bold rounded transition ${
                        scenario === scen
                          ? 'bg-[#F59E0B] text-[#121212]'
                          : 'text-[#8E9299] hover:text-white'
                      }`}
                    >
                      {scen}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 bg-[#121212] p-4 rounded border border-[#2A2C2E] text-xs space-y-2">
            <div className="text-[#C5A059] font-bold uppercase tracking-wider flex items-center">
              <Calculator className="h-4 w-4 mr-1.5" /> Mathematical Summary
            </div>
            <div className="text-[#8E9299] leading-relaxed">
              {model === 'ARIMA' && 'Auto-Regressive Integrated Moving Average models autoregressive trends with differencing d=1 and moving average noise.'}
              {model === 'Prophet' && 'Prophet additive model isolates weekly, monthly, and yearly seasonalities, adjusting for pipeline maintenance events.'}
              {model === 'ExpSmoothing' && 'Triple Exponential Smoothing (Holt-Winters) applies exponentially decreasing weights to older observations.'}
            </div>
          </div>
        </div>

        {/* Interactive Chart Visualizer */}
        <div className="lg:col-span-8 bg-[#121212] rounded-lg border border-[#2A2C2E] p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                Model: {model} // Scenario: {scenario}
              </h3>
              <p className="text-[10px] text-[#8E9299] mt-0.5">Shaded region displays the 95% forecast confidence interval boundary.</p>
            </div>
            <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-mono font-bold uppercase">
              R-Squared: {model === 'ARIMA' ? '0.94' : model === 'Prophet' ? '0.96' : '0.91'}
            </span>
          </div>

          <div className="h-[320px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={finalChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorConfidence" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#C5A059" stopOpacity={0.12}/>
                    <stop offset="95%" stopColor="#C5A059" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A2C2E" />
                <XAxis dataKey="date" stroke="#666" fontSize={9} tickLine={false} />
                <YAxis stroke="#666" fontSize={9} tickLine={false} />
                <Tooltip contentStyle={{ backgroundColor: '#1A1C1E', borderColor: '#2A2C2E', color: '#FFF' }} />
                <Legend verticalAlign="top" height={36} iconSize={10} wrapperStyle={{ fontSize: 11 }} />
                
                {/* 95% Confidence Shaded Area */}
                <Area name="95% Confidence Band" type="monotone" dataKey="upperConfidence" stroke="none" fill="url(#colorConfidence)" />
                <Area name="Lower Confidence Band" type="monotone" dataKey="lowerConfidence" stroke="none" fill="none" />
                
                {/* Historical Observed Actual */}
                <Line name="Observed Actual" type="monotone" dataKey="actual" stroke="#FFF" strokeWidth={2.5} dot={false} activeDot={{ r: 6 }} />
                
                {/* Scenario Forecast */}
                <Line name="Scenario Projection" type="monotone" dataKey="scenarioVal" stroke="#C5A059" strokeWidth={2} strokeDasharray="4 4" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
}
