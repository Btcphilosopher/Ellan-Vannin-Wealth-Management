import { useMemo } from 'react';
import { 
  TrendingUp, TrendingDown, Layers, HelpCircle, Activity, ShieldAlert, CheckCircle, Flame, DollarSign, Database, Gauge, Zap, Leaf 
} from 'lucide-react';

interface ExecutiveSummaryProps {
  onTabChange: (tab: string) => void;
}

export default function ExecutiveSummary({ onTabChange }: ExecutiveSummaryProps) {
  // Hardcoded real-time state reflecting live UK parameters
  const metrics = useMemo(() => [
    {
      id: 'nbp_spot',
      label: 'NBP Spot Gas',
      value: '78.2 p/th',
      trend: '+1.2%',
      trendDir: 'up',
      detail: 'Day-Ahead: 78.5 p/th',
      icon: Layers,
      color: 'text-[#C5A059]',
      tabLink: 'spot'
    },
    {
      id: 'brent_oil',
      label: 'Brent Crude Oil',
      value: '$74.50/bbl',
      trend: '-0.6%',
      trendDir: 'down',
      detail: 'Weekly: -$0.45/bbl',
      icon: DollarSign,
      color: 'text-[#10B981]',
      tabLink: 'spot'
    },
    {
      id: 'gas_demand',
      label: 'UK Gas Demand',
      value: '191.4 mcm/d',
      trend: '+3.4%',
      trendDir: 'up',
      detail: 'Normalised: 195.0 mcm/d',
      icon: Flame,
      color: 'text-[#F59E0B]',
      tabLink: 'demand'
    },
    {
      id: 'north_sea_prod',
      label: 'North Sea Production',
      value: '88.5 mcm/d',
      trend: 'STABLE',
      trendDir: 'stable',
      detail: 'West of Shetland active',
      icon: Activity,
      color: 'text-white',
      tabLink: 'supply'
    },
    {
      id: 'lng_imports',
      label: 'LNG Terminal Regas',
      value: '48.0 mcm/d',
      trend: '+12.4%',
      trendDir: 'up',
      detail: 'South Hook at 72% cap',
      icon: Activity,
      color: 'text-[#60A5FA]',
      tabLink: 'supply'
    },
    {
      id: 'storage_level',
      label: 'Strategic Reserves',
      value: '82%',
      trend: 'SECURE',
      trendDir: 'stable',
      detail: '62 days peak supply',
      icon: Database,
      color: 'text-[#10B981]',
      tabLink: 'storage'
    },
    {
      id: 'pipeline_util',
      label: 'Pipeline Utilisation',
      value: '88%',
      trend: 'Langeled Max',
      trendDir: 'stable',
      detail: 'Norway: 96.0 mcm/d net',
      icon: Gauge,
      color: 'text-[#F59E0B]',
      tabLink: 'pipeline'
    },
    {
      id: 'gas_power',
      label: 'Gas-to-Power Grid',
      value: '48.0 mcm/d',
      trend: '+4.5%',
      trendDir: 'up',
      detail: 'CCGT share: 38%',
      icon: Zap,
      color: 'text-[#C5A059]',
      tabLink: 'demand'
    },
    {
      id: 'carbon_price',
      label: 'UK Carbon ETS',
      value: '£41.80/t',
      trend: '+2.3%',
      trendDir: 'up',
      detail: 'Monthly peak contract',
      icon: Leaf,
      color: 'text-[#3B82F6]',
      tabLink: 'spot'
    },
    {
      id: 'market_balance',
      label: 'NTS Market Balance',
      value: '+51.6 mcm/d',
      trend: 'NOMINAL',
      trendDir: 'stable',
      detail: 'Flow rate: 243.0 mcm/d',
      icon: Activity,
      color: 'text-[#10B981]',
      tabLink: 'balance'
    },
    {
      id: 'supply_margin',
      label: 'Supply Margin Buffer',
      value: '21.2%',
      trend: 'SECURE',
      trendDir: 'stable',
      detail: 'Total cap: 298.0 mcm/d',
      icon: Gauge,
      color: 'text-white',
      tabLink: 'balance'
    },
    {
      id: 'system_status',
      label: 'NTS System Status',
      value: 'SECURE',
      trend: '100% GREEN',
      trendDir: 'stable',
      detail: 'Emergency buffers nominal',
      icon: CheckCircle,
      color: 'text-[#10B981]',
      tabLink: 'balance'
    }
  ], []);

  return (
    <div id="executive_summary_dashboard">
      <div className="bg-[#1A1C1E] border border-[#2A2C2E] rounded-lg p-6 mb-8 relative overflow-hidden">
        {/* Subtle background glow representing sovereign wealth intelligence */}
        <div className="absolute right-0 top-0 w-80 h-80 bg-[#C5A059]/5 rounded-full filter blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
          <div>
            <span className="text-xs font-semibold tracking-widest text-[#C5A059] uppercase">Sovereign-Grade Market Analytics</span>
            <h1 className="text-3xl font-black text-white tracking-tight mt-1">NORTHSTAR MARKET™ Terminal</h1>
            <p className="text-xs text-[#8E9299] mt-2 leading-relaxed max-w-3xl">
              Strategic Commodity & Infrastructure Intelligence Platform configured for <span className="text-white font-bold">Ellan Vannin Wealth Management</span>. Monitoring UK North Sea drilling basins, continental pipeline interconnectors, LNG regasification flows, and macro financial indicators.
            </p>
          </div>
          <div className="mt-4 md:mt-0 text-right bg-[#121212] p-3 rounded border border-[#2A2C2E]">
            <div className="text-[10px] text-[#8E9299] uppercase tracking-wider font-semibold">Active Portfolios Value</div>
            <div className="text-xl font-bold text-white font-mono mt-0.5">£1,716,000,000</div>
          </div>
        </div>
      </div>

      {/* Main Grid of 12 Cards */}
      <h2 className="text-xs font-bold text-[#8E9299] uppercase tracking-widest mb-4">Real-Time Operational Summary Cards</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <div 
              key={metric.id}
              onClick={() => onTabChange(metric.tabLink)}
              className="bg-[#1A1C1E] border border-[#2A2C2E] border-l-[3px] border-l-[#C5A059] p-5 rounded-r hover:border-[#C5A059] transition group cursor-pointer flex flex-col justify-between"
            >
              <div className="flex items-center justify-between text-[#8E9299] text-[10px] font-extrabold uppercase tracking-wider">
                <span>{metric.label}</span>
                <Icon className={`h-4 w-4 ${metric.color}`} />
              </div>

              <div className="mt-3">
                <div className="text-2xl font-black text-white font-mono group-hover:text-[#C5A059] transition">
                  {metric.value}
                </div>
                
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#2A2C2E]/40 text-[10px]">
                  <span className="text-[#8E9299]">{metric.detail}</span>
                  <span className={`font-bold flex items-center ${
                    metric.trendDir === 'up' 
                      ? 'text-[#10B981]' 
                      : metric.trendDir === 'down' 
                      ? 'text-[#EF4444]' 
                      : 'text-[#C5A059]'
                  }`}>
                    {metric.trendDir === 'up' && <TrendingUp className="h-3 w-3 mr-0.5" />}
                    {metric.trendDir === 'down' && <TrendingDown className="h-3 w-3 mr-0.5" />}
                    {metric.trend}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
