import { useState } from 'react';
import { motion } from 'motion/react';
import ExecutiveSummary from './components/ExecutiveSummary';
import SpotMarket from './components/SpotMarket';
import SupplyDashboard from './components/SupplyDashboard';
import DemandDashboard from './components/DemandDashboard';
import InfrastructureMap from './components/InfrastructureMap';
import StorageIntelligence from './components/StorageIntelligence';
import BalanceEngine from './components/BalanceEngine';
import PipelineMonitor from './components/PipelineMonitor';
import EnergySecurity from './components/EnergySecurity';
import ForecastEngine from './components/ForecastEngine';
import InfrastructureInvestment from './components/InfrastructureInvestment';
import PortfolioIntegration from './components/PortfolioIntegration';
import DeveloperCenter from './components/DeveloperCenter';

import { 
  Home, Layers, Landmark, BarChart3, Map, Database, Scale, Network, Shield, Cpu, Briefcase, Coins, CodeXml, Flame, Landmark as Bank, Activity
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');

  const navItems = [
    { id: 'home', label: 'Terminal Home', icon: Home },
    { id: 'spot', label: 'Spot Market (M01)', icon: Layers },
    { id: 'supply', label: 'UK Supply (M02)', icon: Activity },
    { id: 'demand', label: 'Demand Matrix (M03)', icon: Flame },
    { id: 'map', label: 'GIS Infrastructure (M04)', icon: Map },
    { id: 'storage', label: 'Storage Intel (M05)', icon: Database },
    { id: 'balance', label: 'Balance Engine (M06)', icon: Scale },
    { id: 'pipeline', label: 'Pipeline Monitor (M07)', icon: Network },
    { id: 'security', label: 'Energy Security (M08)', icon: Shield },
    { id: 'forecast', label: 'Forecast Engine (M09)', icon: Cpu },
    { id: 'investment', label: 'Asset Ledger (M10)', icon: Briefcase },
    { id: 'portfolio', label: 'EVWM Portfolio (M11)', icon: Coins },
    { id: 'developer', label: 'Sovereign Dev Center', icon: CodeXml },
  ];

  return (
    <div className="min-h-screen bg-[#121212] text-[#E4E3E0] font-sans flex flex-col antialiased">
      
      {/* Dynamic Bloomberg-style Top Ticker */}
      <div className="bg-[#0A0B0C] border-b border-[#2A2C2E] py-2.5 px-6 text-xs flex items-center justify-between font-mono shrink-0 overflow-x-auto whitespace-nowrap gap-8 select-none">
        <div className="flex items-center space-x-2">
          <span className="text-[#C5A059] font-black tracking-widest text-[10px]">NORTHSTAR MARKET™</span>
          <span className="text-[#8E9299]">|</span>
          <span className="text-[#8E9299] font-bold text-[10px]">ELLAN VANNIN WEALTH MANAGEMENT</span>
        </div>

        <div className="flex items-center space-x-6 text-[11px]">
          <div className="flex items-center space-x-1.5">
            <span className="text-[#8E9299]">NBP Spot:</span>
            <span className="text-white font-bold">78.2 p/th</span>
            <span className="text-[#10B981] font-semibold">▲ +1.2%</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="text-[#8E9299]">Brent:</span>
            <span className="text-white font-bold">$74.50</span>
            <span className="text-[#EF4444] font-semibold">▼ -0.6%</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="text-[#8E9299]">UK ETS:</span>
            <span className="text-white font-bold">£41.80</span>
            <span className="text-[#10B981] font-semibold">▲ +2.3%</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="text-[#8E9299]">UK Power:</span>
            <span className="text-white font-bold">£69.20</span>
            <span className="text-[#10B981] font-semibold">▲ +3.4%</span>
          </div>
        </div>

        <div className="text-[#8E9299] text-[10px] flex items-center">
          <span className="w-2 h-2 bg-[#10B981] rounded-full mr-2 animate-pulse" />
          NTS LIVE STREAM // SECURE
        </div>
      </div>

      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        
        {/* Master Navigation Sidebar */}
        <nav className="w-full md:w-64 bg-[#1A1C1E] border-r border-[#2A2C2E] p-4 flex flex-col justify-between shrink-0 overflow-y-auto">
          <div className="space-y-6">
            <div className="flex items-center space-x-3 pb-4 border-b border-[#2A2C2E]">
              <div className="h-9 w-9 rounded bg-[#C5A059]/10 flex items-center justify-center border border-[#C5A059]/20">
                <Bank className="h-5 w-5 text-[#C5A059]" />
              </div>
              <div>
                <div className="text-xs font-black tracking-widest text-[#C5A059]">NORTHSTAR</div>
                <div className="text-[9px] text-[#8E9299] uppercase tracking-wide">Sovereign Intel</div>
              </div>
            </div>

            {/* Nav list */}
            <div className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded text-xs font-bold transition duration-200 ${
                      isActive 
                        ? 'bg-[#C5A059] text-[#121212]' 
                        : 'text-[#8E9299] hover:text-white hover:bg-[#25282B]'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Footer of Sidebar */}
          <div className="pt-6 mt-6 border-t border-[#2A2C2E] text-[10px] text-[#8E9299] space-y-1">
            <div>Sovereign Access Level: <span className="text-white font-bold">L3-EXEC</span></div>
            <div>Database Node: <span className="text-white font-bold font-mono">EVWM-PROD-01</span></div>
            <div className="text-[#C5A059] font-bold mt-2">© 2026 ELLAN VANNIN WM</div>
          </div>
        </nav>

        {/* Scrollable Dashboard Viewport */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8 bg-[#121212]">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'home' && <ExecutiveSummary onTabChange={setActiveTab} />}
            {activeTab === 'spot' && <SpotMarket />}
            {activeTab === 'supply' && <SupplyDashboard />}
            {activeTab === 'demand' && <DemandDashboard />}
            {activeTab === 'map' && <InfrastructureMap />}
            {activeTab === 'storage' && <StorageIntelligence />}
            {activeTab === 'balance' && <BalanceEngine />}
            {activeTab === 'pipeline' && <PipelineMonitor />}
            {activeTab === 'security' && <EnergySecurity />}
            {activeTab === 'forecast' && <ForecastEngine />}
            {activeTab === 'investment' && <InfrastructureInvestment />}
            {activeTab === 'portfolio' && <PortfolioIntegration />}
            {activeTab === 'developer' && <DeveloperCenter />}
          </motion.div>
        </main>

      </div>
    </div>
  );
}
