# ==============================================================================
# testthat unit tests for AUREOM.AI — PRICE.OS
# ==============================================================================

library(testthat)
source("../R/pricing_calculations.R")
source("../R/elasticity.R")
source("../R/optimisation.R")

test_that("Markup calculation is mathematically sound", {
  cost <- 40
  markup <- 0.50
  expect_equal(calculate_markup_price(cost, markup), 60)
  expect_equal(calculate_markup(60, 40), 0.50)
})

test_that("Target margin calculation distinguishes margin from markup", {
  cost <- 40
  margin <- 0.40
  price <- calculate_margin_price(cost, margin)
  expect_equal(round(price, 2), 66.67)
  expect_equal(round(calculate_margin(price, cost), 2), 0.40)
  # Ensure margin price != markup price
  expect_gt(calculate_margin_price(cost, margin), calculate_markup_price(cost, margin))
})

test_that("Break-even rejects zero or negative contribution margin", {
  expect_error(calculate_break_even_volume(10000, 0))
  expect_error(calculate_break_even_volume(10000, -5))
  expect_equal(calculate_break_even_volume(10000, 25), 400)
})

test_that("Constant elasticity demand function obeys power law", {
  p0 <- 100
  q0 <- 500
  e <- -1.5
  # Price doubling
  p_double <- 200
  q_expected <- q0 * (200 / 100)^(-1.5)
  expect_equal(estimate_demand(p_double, p0, q0, e), q_expected)
})

test_that("Price optimiser respects margin floor constraint", {
  res <- optimise_price(
    baseline_price = 50,
    baseline_demand = 100,
    elasticity = -2.5,
    unit_cost = 30,
    min_price = 20,
    max_price = 80,
    min_margin = 0.40,
    objective = "profit"
  )
  # Margin floor is 30 / (1 - 0.4) = 50
  expect_gte(res$recommended_price, 50)
  expect_gte(res$expected_margin, 0.40)
})
