# ==============================================================================
# AUREOM.AI — PRICE.OS: Enterprise Dynamic Pricing & Optimisation Engine
# Shiny Application Entry Point
# ==============================================================================

library(shiny)
library(bslib)
library(plotly)

source("R/pricing_calculations.R")
source("R/elasticity.R")
source("R/optimisation.R")

# Custom dark theme
theme <- bs_theme(
  bg = "#0B0F19",
  fg = "#F1F5F9",
  primary = "#10B981",
  secondary = "#64748B",
  base_font = font_google("Plus Jakarta Sans"),
  code_font = font_google("JetBrains Mono")
)

ui <- page_navbar(
  title = "AUREOM.AI — PRICE.OS",
  theme = theme,
  sidebar = sidebar(
    title = "Pricing Parameters",
    selectInput("product_select", "Select Product", choices = c(
      "Acoustic Pro Wireless ANC (TECH-01)" = "p1",
      "CloudStrider Running Shoes (APP-01)" = "p2",
      "Ethiopian Yirgacheffe Beans (FNB-01)" = "p3"
    )),
    numericInput("unit_cost", "Unit Cost (£)", value = 74.50, min = 0, step = 0.50),
    numericInput("baseline_price", "Current Price (£)", value = 199.99, min = 0, step = 1.00),
    numericInput("baseline_demand", "Weekly Demand (Units)", value = 340, min = 0, step = 10),
    sliderInput("elasticity", "Price Elasticity (ε)", min = -3.5, max = -0.5, value = -1.82, step = 0.05),
    hr(),
    numericInput("min_price", "Min Price Boundary (£)", value = 149.00, min = 0),
    numericInput("max_price", "Max Price Boundary (£)", value = 249.00, min = 0),
    sliderInput("min_margin", "Min Margin Floor (%)", min = 10, max = 80, value = 40, step = 5),
    selectInput("objective", "Optimisation Objective", choices = c(
      "Maximise Profit" = "profit",
      "Maximise Revenue" = "revenue"
    )),
    actionButton("btn_calculate", "Recalculate Optimal Price", class = "btn-success w-100")
  ),
  nav_panel("Quick Calculator",
    fluidRow(
      value_box(
        title = "Recommended Price",
        value = textOutput("vb_rec_price"),
        showcase = icon("tag"),
        theme = "primary"
      ),
      value_box(
        title = "Expected Profit",
        value = textOutput("vb_exp_profit"),
        showcase = icon("chart-line"),
        theme = "teal"
      ),
      value_box(
        title = "Expected Margin",
        value = textOutput("vb_exp_margin"),
        showcase = icon("percent"),
        theme = "info"
      )
    ),
    card(
      card_header("Price-Profit & Demand Response Curves"),
      plotlyOutput("opt_chart", height = "450px")
    )
  ),
  nav_panel("R Architecture",
    card(
      card_header("Engine Specifications"),
      p("AUREOM.AI PRICE.OS is architected for high-performance econometric pricing optimization in R."),
      p("Modules include: pricing_calculations.R, elasticity.R, optimisation.R, forecasting.R, and testthat validation suites.")
    )
  )
)

server <- function(input, output, session) {
  opt_result <- reactive({
    input$btn_calculate
    isolate({
      optimise_price(
        baseline_price = input$baseline_price,
        baseline_demand = input$baseline_demand,
        elasticity = input$elasticity,
        unit_cost = input$unit_cost,
        min_price = input$min_price,
        max_price = input$max_price,
        min_margin = input$min_margin / 100,
        objective = input$objective
      )
    })
  })

  output$vb_rec_price <- renderText({
    paste0("£", format(opt_result()$recommended_price, nsmall = 2))
  })

  output$vb_exp_profit <- renderText({
    paste0("£", format(opt_result()$expected_profit, nsmall = 2, big.mark = ","))
  })

  output$vb_exp_margin <- renderText({
    paste0(round(opt_result()$expected_margin * 100, 1), "%")
  })

  output$opt_chart <- renderPlotly({
    res <- opt_result()
    p_seq <- seq(input$min_price * 0.8, input$max_price * 1.2, length.out = 100)
    d_seq <- estimate_demand(p_seq, input$baseline_price, input$baseline_demand, input$elasticity)
    profit_seq <- (p_seq - input$unit_cost) * d_seq

    df <- data.frame(Price = p_seq, Profit = profit_seq, Demand = d_seq)

    plot_ly(df, x = ~Price) %>%
      add_lines(y = ~Profit, name = "Expected Profit (£)", line = list(color = "#10B981", width = 3)) %>%
      add_trace(x = res$recommended_price, y = res$expected_profit, type = "scatter", mode = "markers",
                name = "Optimal Price", marker = list(color = "#F59E0B", size = 12)) %>%
      layout(
        paper_bgcolor = "#111827",
        plot_bgcolor = "#111827",
        font = list(color = "#F1F5F9"),
        xaxis = list(title = "Selling Price (£)", gridcolor = "#1E293B"),
        yaxis = list(title = "Expected Profit (£)", gridcolor = "#1E293B")
      )
  })
}

shinyApp(ui, server)
