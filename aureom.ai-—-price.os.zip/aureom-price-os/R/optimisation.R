# ==============================================================================
# AUREOM.AI — PRICE.OS: Price Optimisation Engine
# Golden-section and numerical optimization for profit and revenue under constraints
# ==============================================================================

source("R/elasticity.R")

#' Optimise Price for Maximum Profit or Revenue
#'
#' @param baseline_price Numeric: Current product price (> 0)
#' @param baseline_demand Numeric: Baseline sales velocity (>= 0)
#' @param elasticity Numeric: Price elasticity of demand (< 0)
#' @param unit_cost Numeric: Direct unit cost (>= 0)
#' @param min_price Numeric: Lower bound on candidate price
#' @param max_price Numeric: Upper bound on candidate price
#' @param min_margin Numeric: Minimum allowable gross margin (0 to 0.95)
#' @param objective Character: "profit" or "revenue"
#' @return list containing optimal price, expected profit, demand, and revenue
#' @export
optimise_price <- function(
  baseline_price,
  baseline_demand,
  elasticity,
  unit_cost,
  min_price,
  max_price,
  min_margin = 0.20,
  objective = c("profit", "revenue")
) {
  objective <- match.arg(objective)

  stopifnot(
    baseline_price > 0,
    baseline_demand >= 0,
    unit_cost >= 0,
    min_price > 0,
    max_price >= min_price,
    is.finite(elasticity)
  )

  # Margin constraint floor: price >= unit_cost / (1 - min_margin)
  margin_floor <- if (min_margin < 0.99) unit_cost / (1 - min_margin) else unit_cost
  effective_min <- max(min_price, margin_floor)

  if (effective_min > max_price) {
    warning("Margin floor exceeds configured maximum price ceiling. Binding to margin floor.")
    effective_max <- effective_min
  } else {
    effective_max <- max_price
  }

  eval_func <- function(p) {
    d <- estimate_demand(p, baseline_price, baseline_demand, elasticity)
    if (objective == "profit") {
      val <- (p - unit_cost) * d
    } else {
      val <- p * d
    }
    # optimize minimizes by default
    -val
  }

  if (effective_min == effective_max) {
    opt_price <- effective_min
    expected_metric <- -eval_func(opt_price)
  } else {
    result <- optimize(eval_func, interval = c(effective_min, effective_max))
    opt_price <- result$minimum
    expected_metric <- -result$objective
  }

  opt_demand <- estimate_demand(opt_price, baseline_price, baseline_demand, elasticity)
  opt_revenue <- opt_price * opt_demand
  opt_profit <- (opt_price - unit_cost) * opt_demand
  opt_margin <- (opt_price - unit_cost) / opt_price

  list(
    recommended_price = round(opt_price, 2),
    expected_demand = round(opt_demand, 1),
    expected_revenue = round(opt_revenue, 2),
    expected_profit = round(opt_profit, 2),
    expected_margin = round(opt_margin, 4),
    is_constrained = (abs(opt_price - effective_min) < 0.05 || abs(opt_price - effective_max) < 0.05),
    binding_floor = effective_min,
    binding_ceiling = effective_max
  )
}
