# ==============================================================================
# AUREOM.AI — PRICE.OS: Core Pricing Calculation Library
# Mathematical formulas for cost-plus, target margin, contribution margin & break-even
# ==============================================================================

#' Cost-Plus Pricing Calculation
#'
#' @param cost Numeric: Direct unit cost (must be >= 0)
#' @param markup Numeric: Desired markup rate as decimal (e.g., 0.50 for 50%)
#' @return Numeric: Recommended selling price
#' @export
calculate_markup_price <- function(cost, markup) {
  stopifnot(is.finite(cost), cost >= 0)
  stopifnot(is.finite(markup), markup >= 0)

  cost * (1 + markup)
}

#' Target Gross Margin Pricing Calculation
#'
#' @param cost Numeric: Direct unit cost (must be >= 0)
#' @param margin Numeric: Desired gross margin as decimal (0 <= margin < 1.0)
#' @return Numeric: Required selling price
#' @export
calculate_margin_price <- function(cost, margin) {
  stopifnot(is.finite(cost), cost >= 0)
  stopifnot(is.finite(margin), margin >= 0, margin < 1.0)

  cost / (1 - margin)
}

#' Calculate Gross Margin Percentage from Price and Cost
#'
#' @param price Numeric: Selling price (> 0)
#' @param cost Numeric: Direct unit cost (>= 0)
#' @return Numeric: Gross margin ratio
#' @export
calculate_margin <- function(price, cost) {
  stopifnot(is.finite(price), price > 0)
  stopifnot(is.finite(cost), cost >= 0)

  (price - cost) / price
}

#' Calculate Markup Percentage from Price and Cost
#'
#' @param price Numeric: Selling price (> 0)
#' @param cost Numeric: Direct unit cost (> 0)
#' @return Numeric: Markup ratio
#' @export
calculate_markup <- function(price, cost) {
  stopifnot(is.finite(price), price > 0)
  stopifnot(is.finite(cost), cost > 0)

  (price - cost) / cost
}

#' Contribution Margin per Unit
#'
#' @param net_revenue Numeric: Net selling revenue after payment fees and tax
#' @param variable_costs Numeric: Total direct variable costs per unit
#' @return Numeric: Contribution margin per unit
#' @export
calculate_contribution_margin <- function(net_revenue, variable_costs) {
  stopifnot(is.finite(net_revenue), is.finite(variable_costs))
  net_revenue - variable_costs
}

#' Break-Even Sales Volume
#'
#' @param fixed_costs Numeric: Total fixed overhead costs
#' @param unit_contribution_margin Numeric: Unit contribution margin (> 0)
#' @return Numeric: Required sales volume to break even
#' @export
calculate_break_even_volume <- function(fixed_costs, unit_contribution_margin) {
  stopifnot(is.finite(fixed_costs), fixed_costs >= 0)
  stopifnot(is.finite(unit_contribution_margin))

  if (unit_contribution_margin <= 0) {
    stop("Unit contribution margin must be strictly positive to achieve break-even.")
  }

  ceiling(fixed_costs / unit_contribution_margin)
}

#' Break-Even Selling Price
#'
#' @param variable_cost Numeric: Variable cost per unit
#' @param fixed_costs Numeric: Total fixed overhead costs
#' @param volume Numeric: Expected sales volume (> 0)
#' @return Numeric: Minimum selling price to cover all costs
#' @export
calculate_break_even_price <- function(variable_cost, fixed_costs, volume) {
  stopifnot(is.finite(variable_cost), variable_cost >= 0)
  stopifnot(is.finite(fixed_costs), fixed_costs >= 0)
  stopifnot(is.finite(volume), volume > 0)

  variable_cost + (fixed_costs / volume)
}
