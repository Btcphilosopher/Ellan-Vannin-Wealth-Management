# ==============================================================================
# AUREOM.AI — PRICE.OS: Demand Elasticity Library
# Point elasticity, arc elasticity, constant elasticity demand model & log-log OLS
# ==============================================================================

#' Constant Elasticity Demand Response Model
#'
#' @param price Numeric: Candidate selling price (> 0)
#' @param baseline_price Numeric: Current or baseline reference price (> 0)
#' @param baseline_demand Numeric: Baseline demand at reference price (>= 0)
#' @param elasticity Numeric: Price elasticity of demand (typically < 0)
#' @return Numeric: Expected demand at candidate price
#' @export
estimate_demand <- function(price, baseline_price, baseline_demand, elasticity) {
  stopifnot(
    is.finite(price), price > 0,
    is.finite(baseline_price), baseline_price > 0,
    is.finite(baseline_demand), baseline_demand >= 0,
    is.finite(elasticity)
  )

  baseline_demand * (price / baseline_price)^elasticity
}

#' Arc Elasticity Calculation
#'
#' @param p1 Numeric: Initial price
#' @param q1 Numeric: Initial quantity
#' @param p2 Numeric: New price
#' @param q2 Numeric: New quantity
#' @return Numeric: Arc elasticity coefficient
#' @export
calculate_arc_elasticity <- function(p1, q1, p2, q2) {
  stopifnot(
    is.finite(p1), is.finite(q1), is.finite(p2), is.finite(q2),
    p1 > 0, p2 > 0, q1 >= 0, q2 >= 0
  )

  avg_q <- (q1 + q2) / 2
  avg_p <- (p1 + p2) / 2

  if (avg_q == 0 || avg_p == 0 || p1 == p2) {
    return(NA_real_)
  }

  pct_change_q <- (q2 - q1) / avg_q
  pct_change_p <- (p2 - p1) / avg_p

  pct_change_q / pct_change_p
}

#' Log-Log Econometric Regression for Price Elasticity
#'
#' @param sales_df data.frame with columns 'price' and 'units_sold'
#' @return list containing regression diagnostics, elasticity, p-value, and confidence interval
#' @export
estimate_log_log_elasticity <- function(sales_df) {
  stopifnot(is.data.frame(sales_df))
  stopifnot(all(c("price", "units_sold") %in% names(sales_df)))

  clean_df <- sales_df[sales_df$price > 0 & sales_df$units_sold > 0, ]
  if (nrow(clean_df) < 5) {
    stop("At least 5 non-zero observations required for econometric estimation.")
  }

  model <- lm(log(units_sold) ~ log(price), data = clean_df)
  summary_model <- summary(model)

  coefs <- summary_model$coefficients
  elasticity <- coefs["log(price)", "Estimate"]
  std_err <- coefs["log(price)", "Std. Error"]
  p_val <- coefs["log(price)", "Pr(>|t|)"]
  r_sq <- summary_model$r.squared

  ci <- confint(model, "log(price)", level = 0.95)

  list(
    elasticity = elasticity,
    standard_error = std_err,
    p_value = p_val,
    r_squared = r_sq,
    confidence_interval_95 = as.numeric(ci),
    sample_size = nrow(clean_df)
  )
}
