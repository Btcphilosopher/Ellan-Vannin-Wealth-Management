export type CurrencyCode = 'GBP' | 'USD' | 'EUR' | 'CAD' | 'AUD';

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  name: string;
  rateAgainstGBP: number; // GBP is base = 1.0
}

export type UserRole = 
  | 'Viewer' 
  | 'Pricing Analyst' 
  | 'Revenue Manager' 
  | 'Finance Manager' 
  | 'Pricing Approver' 
  | 'Administrator';

export type OptimisationObjective = 
  | 'maximise_profit' 
  | 'maximise_revenue' 
  | 'maximise_volume' 
  | 'target_margin' 
  | 'balance_profit_volume';

export type RecommendationStatus = 
  | 'DRAFT' 
  | 'CALCULATED' 
  | 'PENDING_REVIEW' 
  | 'APPROVED' 
  | 'REJECTED' 
  | 'SCHEDULED' 
  | 'PUBLISHED' 
  | 'ROLLED_BACK';

export type ProductCategory = 
  | 'Consumer Tech' 
  | 'Apparel & Footwear' 
  | 'Specialty Food & Beverage' 
  | 'Hospitality & Rooms' 
  | 'SaaS & Subscriptions' 
  | 'Industrial Supplies';

export interface CompetitorQuote {
  name: string;
  price: number;
  lastObserved: string;
  inStock: boolean;
  reliabilityScore: number;
}

export interface HistoricalSalePoint {
  date: string;
  price: number;
  cost: number;
  unitsSold: number;
  isPromo: boolean;
  competitorMedian: number;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: ProductCategory;
  currentPrice: number;
  unitCost: number;
  fixedAllocatedCost: number;
  baselineDemand: number; // Units per week
  elasticity: number; // e.g. -1.85
  elasticityStandardError: number;
  inventoryOnHand: number;
  replenishmentLeadDays: number;
  holdingCostPerUnitWeek: number;
  shelfLifeDays?: number; // for perishables
  competitors: CompetitorQuote[];
  minPriceFloor: number;
  maxPriceCeiling: number;
  minMarginThreshold: number; // e.g. 0.35 (35%)
  priceEnding: '.99' | '.95' | '.50' | '.00' | 'none';
  salesHistory: HistoricalSalePoint[];
  recommendedPrice?: number;
  status: RecommendationStatus;
  lastRepricedDate: string;
}

export interface QuickCalculatorInputs {
  productName: string;
  sku: string;
  currency: CurrencyCode;
  unitCost: number;
  currentPrice: number;
  desiredMargin: number; // as ratio (0 - 0.95)
  desiredMarkup: number; // as ratio
  taxRate: number; // as ratio (e.g. 0.20 for 20% VAT)
  taxInclusive: boolean;
  shippingCost: number;
  packagingCost: number;
  paymentFeePercent: number; // e.g. 0.029 (2.9%)
  paymentFeeFixed: number; // e.g. 0.30
  additionalVariableCost: number;
  fixedOverheadCost: number;
  expectedVolume: number;
  discountRate: number; // e.g. 0.05
}

export interface QuickCalculatorOutputs {
  costPlusPrice: number;
  targetMarginPrice: number;
  netSellingRevenue: number;
  totalVariableCostPerUnit: number;
  contributionMarginPerUnit: number;
  contributionMarginRatio: number;
  grossProfitPerUnit: number;
  grossMarginPercent: number;
  markupPercent: number;
  breakEvenVolume: number;
  breakEvenPrice: number;
  totalExpectedRevenue: number;
  totalExpectedProfit: number;
  isMarginHealthy: boolean;
}

export interface OptimisationParams {
  productId: string;
  baselinePrice: number;
  baselineDemand: number;
  unitCost: number;
  elasticity: number;
  minPrice: number;
  maxPrice: number;
  minMargin: number;
  objective: OptimisationObjective;
  currentInventory?: number;
  competitorMedian?: number;
}

export interface OptimisationResult {
  optimalPrice: number;
  expectedDemand: number;
  expectedRevenue: number;
  expectedProfit: number;
  expectedMargin: number;
  currentPrice: number;
  currentDemand: number;
  currentRevenue: number;
  currentProfit: number;
  currentMargin: number;
  revenueDeltaPercent: number;
  profitDeltaPercent: number;
  demandDeltaPercent: number;
  curveData: {
    price: number;
    demand: number;
    revenue: number;
    profit: number;
    margin: number;
    isFeasible: boolean;
  }[];
  isConstrained: boolean;
  bindingConstraint?: string;
  explanation: string;
}

export interface MonteCarloScenario {
  baselinePrice: number;
  candidatePrice: number;
  cost: number;
  elasticityMean: number;
  elasticityStdDev: number;
  baselineDemandMean: number;
  baselineDemandStdDev: number;
  costVariancePercent: number;
  iterations: number;
}

export interface MonteCarloResult {
  profitPercentiles: { p10: number; p25: number; p50: number; p75: number; p90: number; p95: number };
  revenuePercentiles: { p10: number; p50: number; p90: number };
  demandPercentiles: { p10: number; p50: number; p90: number };
  winProbability: number; // Probability profit > baseline
  downsideRiskProbability: number; // Probability profit < 0 or lower than baseline by 5%
  distribution: { bin: number; count: number; profit: number }[];
}

export interface PriceRecommendation {
  id: string;
  productId: string;
  productName: string;
  sku: string;
  category: ProductCategory;
  currentPrice: number;
  recommendedPrice: number;
  priceDelta: number;
  priceDeltaPercent: number;
  expectedDemandDeltaPercent: number;
  expectedRevenueDelta: number;
  expectedProfitDelta: number;
  marginAtRecommended: number;
  confidenceScore: number; // 0 - 100
  rationale: string;
  status: RecommendationStatus;
  createdAt: string;
  reviewerNotes?: string;
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  role: UserRole;
  action: string;
  targetSku: string;
  details: string;
  previousValue?: string;
  newValue?: string;
}

export interface PriceExperiment {
  id: string;
  name: string;
  sku: string;
  category: ProductCategory;
  status: 'DRAFT' | 'RUNNING' | 'CONCLUDED' | 'PAUSED';
  startDate: string;
  endDate: string;
  controlPrice: number;
  treatmentPrice: number;
  trafficSplit: number; // e.g. 50/50
  sampleSizeTarget: number;
  controlUnitsSold: number;
  treatmentUnitsSold: number;
  controlRevenue: number;
  treatmentRevenue: number;
  controlConversionRate: number;
  treatmentConversionRate: number;
  pValue: number;
  statisticallySignificant: boolean;
  estimatedElasticity: number;
  confidenceInterval: [number, number];
}
