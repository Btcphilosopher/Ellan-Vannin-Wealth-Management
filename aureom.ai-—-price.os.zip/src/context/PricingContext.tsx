import React, { createContext, useContext, useState, useMemo } from 'react';
import {
  Product,
  CurrencyCode,
  UserRole,
  RecommendationStatus,
  PriceRecommendation,
  AuditLogEntry,
  OptimisationObjective,
  ProductCategory,
} from '../types/pricing';
import { INITIAL_PRODUCTS } from '../lib/data/syntheticProducts';
import { optimiseProductPrice } from '../lib/math/optimisation';

interface PricingContextType {
  products: Product[];
  selectedProduct: Product;
  selectedProductId: string;
  setSelectedProductId: (id: string) => void;
  activeNav: string;
  setActiveNav: (nav: string) => void;
  currency: CurrencyCode;
  setCurrency: (c: CurrencyCode) => void;
  formatCurrency: (amountInGBP: number) => string;
  convertCurrency: (amountInGBP: number) => number;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  recommendations: PriceRecommendation[];
  auditLogs: AuditLogEntry[];
  updateProduct: (id: string, updates: Partial<Product>) => void;
  updateRecommendationStatus: (recId: string, status: RecommendationStatus, note?: string) => void;
  runBulkOptimisation: (objective: OptimisationObjective, categoryFilter?: ProductCategory | 'ALL') => void;
  savedScenarios: { id: string; name: string; timestamp: string; productId: string; candidatePrice: number; expectedProfit: number }[];
  saveScenario: (name: string, productId: string, candidatePrice: number, expectedProfit: number) => void;
  exportCatalogCSV: () => void;
  taxRate: number;
  setTaxRate: (rate: number) => void;
  taxInclusive: boolean;
  setTaxInclusive: (val: boolean) => void;
}

const CURRENCY_RATES: Record<CurrencyCode, { symbol: string; rate: number }> = {
  GBP: { symbol: '£', rate: 1.0 },
  USD: { symbol: '$', rate: 1.28 },
  EUR: { symbol: '€', rate: 1.16 },
  CAD: { symbol: 'CA$', rate: 1.74 },
  AUD: { symbol: 'A$', rate: 1.95 },
};

const PricingContext = createContext<PricingContextType | null>(null);

export const PricingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [selectedProductId, setSelectedProductId] = useState<string>('prod-001');
  const [activeNav, setActiveNav] = useState<string>('overview');
  const [currency, setCurrency] = useState<CurrencyCode>('GBP');
  const [userRole, setUserRole] = useState<UserRole>('Revenue Manager');
  const [taxRate, setTaxRate] = useState<number>(0.20);
  const [taxInclusive, setTaxInclusive] = useState<boolean>(true);

  const [savedScenarios, setSavedScenarios] = useState([
    { id: 'sc-1', name: 'Q4 Holiday Promotion Wave', timestamp: '2026-11-05 14:20', productId: 'prod-001', candidatePrice: 209.99, expectedProfit: 42150 },
    { id: 'sc-2', name: 'Supply Shortage Cost Pass-through', timestamp: '2026-11-06 09:45', productId: 'prod-002', candidatePrice: 32.99, expectedProfit: 27400 },
  ]);

  // Generate initial recommendations from products
  const [recommendations, setRecommendations] = useState<PriceRecommendation[]>(() => {
    return INITIAL_PRODUCTS.slice(0, 15).map((p, idx) => {
      const recPrice = p.recommendedPrice || p.currentPrice;
      const delta = recPrice - p.currentPrice;
      const deltaPct = (delta / p.currentPrice) * 100;
      const opt = optimiseProductPrice({
        productId: p.id,
        baselinePrice: p.currentPrice,
        baselineDemand: p.baselineDemand,
        unitCost: p.unitCost,
        elasticity: p.elasticity,
        minPrice: p.minPriceFloor,
        maxPrice: p.maxPriceCeiling,
        minMargin: p.minMarginThreshold,
        objective: 'maximise_profit',
        competitorMedian: p.competitors[0]?.price,
      });

      return {
        id: `rec-${idx + 101}`,
        productId: p.id,
        productName: p.name,
        sku: p.sku,
        category: p.category,
        currentPrice: p.currentPrice,
        recommendedPrice: opt.optimalPrice,
        priceDelta: Number((opt.optimalPrice - p.currentPrice).toFixed(2)),
        priceDeltaPercent: Number((((opt.optimalPrice - p.currentPrice) / p.currentPrice) * 100).toFixed(1)),
        expectedDemandDeltaPercent: opt.demandDeltaPercent,
        expectedRevenueDelta: Number((opt.expectedRevenue - opt.currentRevenue).toFixed(2)),
        expectedProfitDelta: Number((opt.expectedProfit - opt.currentProfit).toFixed(2)),
        marginAtRecommended: opt.expectedMargin,
        confidenceScore: Math.round(85 + (1 - Math.min(0.5, p.elasticityStandardError)) * 14),
        rationale: opt.explanation,
        status: p.status,
        createdAt: '2026-11-06 18:30',
      };
    });
  });

  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([
    {
      id: 'log-101',
      timestamp: '2026-11-07 08:32',
      user: 'Sarah Jenkins',
      role: 'Pricing Approver',
      action: 'APPROVE_PRICE_CHANGE',
      targetSku: 'TECH-ANC-01',
      details: 'Approved repricing to £209.99 following elastic demand review.',
      previousValue: '£199.99',
      newValue: '£209.99',
    },
    {
      id: 'log-100',
      timestamp: '2026-11-06 16:15',
      user: 'Marcus Vance',
      role: 'Revenue Manager',
      action: 'RECALCULATE_OPTIMUM',
      targetSku: 'TECH-CHG-65W',
      details: 'Re-ran Nelder-Mead solver with updated competitor quote.',
      previousValue: '£34.99',
      newValue: '£31.99',
    },
    {
      id: 'log-099',
      timestamp: '2026-11-05 11:20',
      user: 'Elena Rostova',
      role: 'Pricing Analyst',
      action: 'REJECT_PRICE_CHANGE',
      targetSku: 'APP-DNM-SLM',
      details: 'Rejected proposed increase due to competitor promotion window.',
      previousValue: '£98.00',
      newValue: '£108.00',
    },
  ]);

  const selectedProduct = useMemo(() => {
    return products.find(p => p.id === selectedProductId) || products[0];
  }, [products, selectedProductId]);

  const convertCurrency = (amountInGBP: number): number => {
    const rate = CURRENCY_RATES[currency].rate;
    return Number((amountInGBP * rate).toFixed(2));
  };

  const formatCurrency = (amountInGBP: number): string => {
    const { symbol, rate } = CURRENCY_RATES[currency];
    const converted = amountInGBP * rate;
    return `${symbol}${converted.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts(prev => prev.map(p => (p.id === id ? { ...p, ...updates } : p)));
  };

  const updateRecommendationStatus = (
    recId: string,
    status: RecommendationStatus,
    note?: string
  ) => {
    setRecommendations(prev =>
      prev.map(r => {
        if (r.id === recId) {
          return {
            ...r,
            status,
            reviewerNotes: note || r.reviewerNotes,
            reviewedBy: `${userRole} (${userRole === 'Pricing Approver' ? 'Authorised' : 'System'})`,
            reviewedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
          };
        }
        return r;
      })
    );

    // Sync product status if applicable
    const rec = recommendations.find(r => r.id === recId);
    if (rec) {
      updateProduct(rec.productId, { status });
      // Add audit log
      setAuditLogs(prev => [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
          user: 'Current Session User',
          role: userRole,
          action: `SET_STATUS_${status}`,
          targetSku: rec.sku,
          details: note || `Status updated to ${status} for recommendation #${recId}`,
          previousValue: rec.status,
          newValue: status,
        },
        ...prev,
      ]);
    }
  };

  const runBulkOptimisation = (
    objective: OptimisationObjective,
    categoryFilter: ProductCategory | 'ALL' = 'ALL'
  ) => {
    const targetProducts = categoryFilter === 'ALL'
      ? products
      : products.filter(p => p.category === categoryFilter);

    const updated = products.map(p => {
      if (categoryFilter !== 'ALL' && p.category !== categoryFilter) return p;
      const opt = optimiseProductPrice({
        productId: p.id,
        baselinePrice: p.currentPrice,
        baselineDemand: p.baselineDemand,
        unitCost: p.unitCost,
        elasticity: p.elasticity,
        minPrice: p.minPriceFloor,
        maxPrice: p.maxPriceCeiling,
        minMargin: p.minMarginThreshold,
        objective,
        competitorMedian: p.competitors[0]?.price,
      });

      return {
        ...p,
        recommendedPrice: opt.optimalPrice,
        status: 'CALCULATED' as RecommendationStatus,
      };
    });

    setProducts(updated);

    // Append to audit log
    setAuditLogs(prev => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
        user: 'Current Session User',
        role: userRole,
        action: 'RUN_BULK_OPTIMISATION',
        targetSku: categoryFilter === 'ALL' ? 'ALL_CATALOG' : categoryFilter,
        details: `Bulk optimization executed across ${targetProducts.length} products with objective: ${objective}.`,
      },
      ...prev,
    ]);
  };

  const saveScenario = (
    name: string,
    productId: string,
    candidatePrice: number,
    expectedProfit: number
  ) => {
    setSavedScenarios(prev => [
      {
        id: `sc-${Date.now()}`,
        name,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
        productId,
        candidatePrice,
        expectedProfit,
      },
      ...prev,
    ]);
  };

  const exportCatalogCSV = () => {
    const headers = [
      'Product ID',
      'SKU',
      'Name',
      'Category',
      'Current Price (GBP)',
      'Unit Cost (GBP)',
      'Gross Margin %',
      'Baseline Demand/wk',
      'Elasticity',
      'Inventory',
      'Competitor Median (GBP)',
      'Recommended Price (GBP)',
      'Status',
    ];

    const rows = products.map(p => {
      const margin = p.currentPrice > 0 ? ((p.currentPrice - p.unitCost) / p.currentPrice) * 100 : 0;
      const compMedian = p.competitors.length > 0 ? p.competitors[0].price : p.currentPrice;
      return [
        p.id,
        p.sku,
        `"${p.name.replace(/"/g, '""')}"`,
        `"${p.category}"`,
        p.currentPrice.toFixed(2),
        p.unitCost.toFixed(2),
        margin.toFixed(1),
        p.baselineDemand,
        p.elasticity.toFixed(2),
        p.inventoryOnHand,
        compMedian.toFixed(2),
        (p.recommendedPrice || p.currentPrice).toFixed(2),
        p.status,
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `AUREOM_PRICE_OS_CATALOG_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <PricingContext.Provider
      value={{
        products,
        selectedProduct,
        selectedProductId,
        setSelectedProductId,
        activeNav,
        setActiveNav,
        currency,
        setCurrency,
        formatCurrency,
        convertCurrency,
        userRole,
        setUserRole,
        recommendations,
        auditLogs,
        updateProduct,
        updateRecommendationStatus,
        runBulkOptimisation,
        savedScenarios,
        saveScenario,
        exportCatalogCSV,
        taxRate,
        setTaxRate,
        taxInclusive,
        setTaxInclusive,
      }}
    >
      {children}
    </PricingContext.Provider>
  );
};

export const usePricing = () => {
  const context = useContext(PricingContext);
  if (!context) {
    throw new Error('usePricing must be used within a PricingProvider');
  }
  return context;
};
