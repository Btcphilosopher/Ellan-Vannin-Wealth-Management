import React from 'react';
import { usePricing } from '../../context/PricingContext';
import {
  LayoutDashboard,
  Calculator,
  Cpu,
  TrendingUp,
  Activity,
  Users,
  PieChart,
  Target,
  Sliders,
  Boxes,
  Percent,
  Layers,
  FlaskConical,
  CheckCircle2,
  FileSpreadsheet,
  Database,
  ShieldCheck,
  Settings,
  Code2,
} from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  section: string;
}

const NAV_ITEMS: NavItem[] = [
  // Core Intelligence
  { id: 'overview', label: 'Overview', icon: LayoutDashboard, section: 'INTELLIGENCE' },
  { id: 'quick_calc', label: 'Quick Price Calculator', icon: Calculator, section: 'INTELLIGENCE' },
  { id: 'dynamic_engine', label: 'Dynamic Pricing Engine', icon: Cpu, section: 'INTELLIGENCE' },
  { id: 'forecasting', label: 'Demand Forecasting', icon: TrendingUp, section: 'INTELLIGENCE' },
  { id: 'elasticity', label: 'Price Elasticity', icon: Activity, section: 'INTELLIGENCE' },
  { id: 'competitors', label: 'Competitor Analysis', icon: Users, section: 'INTELLIGENCE' },
  { id: 'cost_margin', label: 'Cost & Margin Analysis', icon: PieChart, section: 'INTELLIGENCE' },
  { id: 'optimisation', label: 'Price Optimisation', icon: Target, section: 'INTELLIGENCE' },

  // Simulation & Strategy
  { id: 'scenario_lab', label: 'Scenario Simulator', icon: Sliders, section: 'SIMULATION' },
  { id: 'inventory', label: 'Inventory Pricing', icon: Boxes, section: 'SIMULATION' },
  { id: 'promotions', label: 'Promotions & Discounts', icon: Percent, section: 'SIMULATION' },
  { id: 'portfolio', label: 'Product Portfolio', icon: Layers, section: 'SIMULATION' },
  { id: 'experiments', label: 'Price Experiments', icon: FlaskConical, section: 'SIMULATION' },

  // Governance & System
  { id: 'recommendations', label: 'Recommendations', icon: CheckCircle2, section: 'GOVERNANCE' },
  { id: 'reports', label: 'Reports & Audit', icon: FileSpreadsheet, section: 'GOVERNANCE' },
  { id: 'data_mgmt', label: 'Data Management', icon: Database, section: 'GOVERNANCE' },
  { id: 'admin', label: 'Administration', icon: ShieldCheck, section: 'GOVERNANCE' },
  { id: 'settings', label: 'Settings', icon: Settings, section: 'GOVERNANCE' },
  { id: 'r_source', label: 'R Engine Source Code', icon: Code2, section: 'GOVERNANCE' },
];

export const Sidebar: React.FC = () => {
  const { activeNav, setActiveNav, recommendations } = usePricing();

  const pendingCount = recommendations.filter(r => r.status === 'PENDING_REVIEW' || r.status === 'CALCULATED').length;

  const sections = ['INTELLIGENCE', 'SIMULATION', 'GOVERNANCE'];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800/80 flex flex-col shrink-0 select-none">
      {/* Brand Header */}
      <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800/80">
        <div className="flex items-baseline gap-2">
          <span className="font-bold text-base tracking-tight text-white font-sans">AUREOM.AI</span>
          <span className="text-xs font-mono text-emerald-400 font-semibold tracking-wider">PRICE.OS</span>
        </div>
        <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">R CORE</span>
      </div>

      {/* Navigation Links */}
      <div className="flex-1 overflow-y-auto py-3 px-3 space-y-5">
        {sections.map(sectionName => (
          <div key={sectionName} className="space-y-1">
            <div className="px-3 py-1 text-[11px] font-mono uppercase tracking-wider text-slate-500 font-medium">
              {sectionName}
            </div>
            {NAV_ITEMS.filter(item => item.section === sectionName).map(item => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              const isRec = item.id === 'recommendations';

              return (
                <button
                  key={item.id}
                  onClick={() => setActiveNav(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition-colors text-left ${
                    isActive
                      ? 'bg-slate-800/90 text-emerald-400 shadow-sm border border-slate-700/60 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <span className="truncate">{item.label}</span>
                  </div>
                  {isRec && pendingCount > 0 && (
                    <span className="text-[10px] font-mono tabular-nums px-1.5 py-0.2 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded">
                      {pendingCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Bottom Engine Specs Info */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/60">
        <div className="px-2 py-1.5 rounded bg-slate-900/60 border border-slate-800/60 text-[11px] text-slate-400">
          <div className="flex justify-between items-center mb-1">
            <span className="text-slate-500">Mathematical Solver</span>
            <span className="font-mono text-emerald-400 font-medium">Brent-1D / OLS</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-500">Catalog Coverage</span>
            <span className="font-mono tabular-nums text-slate-300">100 SKUs</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
