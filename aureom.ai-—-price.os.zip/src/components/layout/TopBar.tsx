import React from 'react';
import { usePricing } from '../../context/PricingContext';
import { CurrencyCode, UserRole } from '../../types/pricing';
import { Download, PlayCircle, Shield, ChevronDown } from 'lucide-react';

export const TopBar: React.FC = () => {
  const {
    products,
    selectedProductId,
    setSelectedProductId,
    currency,
    setCurrency,
    userRole,
    setUserRole,
    exportCatalogCSV,
    activeNav,
    runBulkOptimisation,
  } = usePricing();

  const activeProduct = products.find(p => p.id === selectedProductId) || products[0];

  const breadcrumbLabels: Record<string, string> = {
    overview: 'Executive Dashboard',
    quick_calc: 'Quick Price Calculator',
    dynamic_engine: 'Dynamic Pricing Engine',
    forecasting: 'Demand Forecasting',
    elasticity: 'Price Elasticity Econometrics',
    competitors: 'Competitor Intelligence',
    cost_margin: 'Cost & Margin Breakdown',
    optimisation: 'Price Optimisation Solver',
    scenario_lab: 'Pricing Lab & Monte Carlo',
    inventory: 'Inventory & Perishable Pricing',
    promotions: 'Promotions & Discount Rules',
    portfolio: 'Product Portfolio Catalog',
    experiments: 'A/B Price Experiments',
    recommendations: 'Price Recommendation Queue',
    reports: 'Reports & Audit Log',
    data_mgmt: 'Data Hygiene & Validation',
    admin: 'Role-Based Administration',
    settings: 'Multi-Currency & Tax Config',
    r_source: 'R Architecture & Source Files',
  };

  const roles: UserRole[] = [
    'Pricing Analyst',
    'Revenue Manager',
    'Finance Manager',
    'Pricing Approver',
    'Administrator',
    'Viewer',
  ];

  const currencies: CurrencyCode[] = ['GBP', 'USD', 'EUR', 'CAD', 'AUD'];

  return (
    <header className="h-16 bg-slate-950 border-b border-slate-800/80 px-6 flex items-center justify-between gap-6 shrink-0 z-10">
      {/* Zone 1: Context Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        <span className="text-xs font-mono text-slate-500 uppercase tracking-wider">AUREOM</span>
        <span className="text-slate-600 font-mono">/</span>
        <h1 className="text-sm font-semibold text-slate-100 truncate">
          {breadcrumbLabels[activeNav] || 'Workspace'}
        </h1>
      </div>

      {/* Zone 2: Contextual Active Product Selector */}
      <div className="flex items-center gap-2 max-w-md w-full">
        <label htmlFor="product-select" className="text-xs text-slate-400 whitespace-nowrap font-medium">
          Active SKU:
        </label>
        <div className="relative flex-1">
          <select
            id="product-select"
            value={selectedProductId}
            onChange={(e) => setSelectedProductId(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded px-2.5 py-1.5 appearance-none pr-8 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 font-sans cursor-pointer truncate"
          >
            {products.map(p => (
              <option key={p.id} value={p.id}>
                {p.sku} — {p.name} ({p.category})
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
      </div>

      {/* Zone 3: Currency, Role & Action */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Currency Switcher */}
        <div className="flex items-center border border-slate-800 rounded bg-slate-900/80 p-0.5">
          {currencies.map(c => (
            <button
              key={c}
              onClick={() => setCurrency(c)}
              className={`px-2 py-1 text-[11px] font-mono rounded transition-colors ${
                currency === c
                  ? 'bg-emerald-500/15 text-emerald-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        {/* Role Switcher */}
        <div className="relative">
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 text-slate-300 text-xs rounded px-2.5 py-1.5">
            <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <select
              value={userRole}
              onChange={(e) => setUserRole(e.target.value as UserRole)}
              className="bg-transparent border-none text-xs text-slate-200 focus:outline-none cursor-pointer pr-4 font-medium"
            >
              {roles.map(r => (
                <option key={r} value={r} className="bg-slate-900 text-slate-200">
                  {r}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={exportCatalogCSV}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700/80 rounded transition-colors whitespace-nowrap"
          title="Export complete 100-SKU catalog to CSV"
        >
          <Download className="w-3.5 h-3.5 text-slate-400" />
          <span>Export CSV</span>
        </button>
      </div>
    </header>
  );
};
