import React, { useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import { PieChart, ArrowDown, DollarSign } from 'lucide-react';

export const CostMarginWaterfallView: React.FC = () => {
  const { selectedProduct, formatCurrency, taxRate, taxInclusive } = usePricing();

  const price = selectedProduct.currentPrice;
  const cost = selectedProduct.unitCost;
  const fixed = selectedProduct.fixedAllocatedCost;

  // Waterfall breakdown items
  const waterfall = useMemo(() => {
    const headline = price;
    const discount = headline * 0.05; // 5% promotional discount
    const discountedPrice = headline - discount;
    const tax = taxInclusive ? discountedPrice - (discountedPrice / (1 + taxRate)) : 0;
    const netPrice = discountedPrice - tax;
    const paymentFee = (discountedPrice * 0.029) + 0.30;
    const netRetainedRevenue = netPrice - paymentFee;

    const cogs = cost;
    const fulfillment = 4.50; // packaging + shipping
    const totalVar = cogs + fulfillment;
    const contributionMargin = netRetainedRevenue - totalVar;
    const operatingProfit = contributionMargin - fixed;

    return [
      { label: 'Headline List Price', amount: headline, type: 'total', cumulative: headline },
      { label: 'Promotional Discounts', amount: -discount, type: 'deduction', cumulative: headline - discount },
      { label: 'VAT / Tax Withholding', amount: -tax, type: 'deduction', cumulative: headline - discount - tax },
      { label: 'Payment Gateway Processing', amount: -paymentFee, type: 'deduction', cumulative: netRetainedRevenue },
      { label: 'Net Retained Revenue', amount: netRetainedRevenue, type: 'subtotal', cumulative: netRetainedRevenue },
      { label: 'Direct Unit COGS', amount: -cogs, type: 'deduction', cumulative: netRetainedRevenue - cogs },
      { label: 'Shipping & Packaging', amount: -fulfillment, type: 'deduction', cumulative: contributionMargin },
      { label: 'Unit Contribution Margin', amount: contributionMargin, type: 'subtotal', cumulative: contributionMargin },
      { label: 'Allocated Fixed Overhead', amount: -fixed, type: 'deduction', cumulative: operatingProfit },
      { label: 'Net Operating Profit', amount: operatingProfit, type: 'total', cumulative: operatingProfit },
    ];
  }, [price, cost, fixed, taxRate, taxInclusive]);

  const maxVal = price * 1.05;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 font-semibold">{selectedProduct.sku}</span>
            <span className="text-slate-600">·</span>
            <h2 className="text-xl font-bold text-slate-100 tracking-tight">{selectedProduct.name}</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Financial margin waterfall: Step-by-step reconciliation from headline price to net contribution profit.
          </p>
        </div>
      </div>

      {/* Waterfall Visualization & Ledger */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="text-sm font-semibold text-slate-200">Reconciliation Waterfall Matrix</h3>

        <div className="space-y-3">
          {waterfall.map((step, idx) => {
            const isDeduction = step.type === 'deduction';
            const isSubtotal = step.type === 'subtotal';
            const isTotal = step.type === 'total';
            const widthPct = Math.min(100, Math.max(5, (Math.abs(step.cumulative) / maxVal) * 100));

            return (
              <div key={idx} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${
                      isTotal ? 'bg-emerald-400' : isSubtotal ? 'bg-teal-400' : 'bg-rose-400'
                    }`} />
                    <span className="font-sans font-medium text-slate-200">{step.label}</span>
                  </div>
                  <div className="flex items-center gap-4 tabular-nums">
                    <span className={isDeduction ? 'text-rose-400 font-semibold' : 'text-emerald-400 font-bold'}>
                      {isDeduction ? '-' : ''}{formatCurrency(Math.abs(step.amount))}
                    </span>
                    <span className="text-slate-400 font-medium w-24 text-right">
                      Eq: {formatCurrency(step.cumulative)}
                    </span>
                  </div>
                </div>

                <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden flex">
                  <div
                    style={{ width: `${widthPct}%` }}
                    className={`h-full rounded-full transition-all duration-300 ${
                      isTotal ? 'bg-emerald-500' : isSubtotal ? 'bg-teal-500' : 'bg-rose-500/80'
                    }`}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
