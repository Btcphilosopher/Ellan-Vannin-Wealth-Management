import React, { useState, useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import { Boxes, AlertTriangle, Clock, TrendingDown, Check } from 'lucide-react';

export const InventoryPricingView: React.FC = () => {
  const { selectedProduct, formatCurrency, updateProduct } = usePricing();

  const stock = selectedProduct.inventoryOnHand;
  const leadDays = selectedProduct.replenishmentLeadDays;
  const weeklyDemand = selectedProduct.baselineDemand;
  const dailyDemand = weeklyDemand / 7;
  const daysRemaining = dailyDemand > 0 ? stock / dailyDemand : 999;
  const unitCost = selectedProduct.unitCost;
  const price = selectedProduct.currentPrice;

  // Perishable shelf life
  const [shelfLifeDays, setShelfLifeDays] = useState(selectedProduct.shelfLifeDays || 60);
  const [daysElapsed, setDaysElapsed] = useState(35);

  const daysToExpiry = Math.max(1, shelfLifeDays - daysElapsed);

  // Dynamic clearance markdown calculation for perishables
  const perishableDiscount = useMemo(() => {
    // If > 50% shelf life remaining: full price
    // If 20%-50% remaining: mild discount 10-20%
    // If < 20% remaining: steep clearance discount 35-50%
    const ratioRemaining = daysToExpiry / shelfLifeDays;
    let disc = 0;
    if (ratioRemaining < 0.15) disc = 0.45;
    else if (ratioRemaining < 0.30) disc = 0.25;
    else if (ratioRemaining < 0.50) disc = 0.10;

    const clearedPrice = Math.max(unitCost * 1.05, price * (1 - disc));
    return {
      ratioRemaining,
      disc,
      clearedPrice,
    };
  }, [daysToExpiry, shelfLifeDays, price, unitCost]);

  // Inventory Health Assessment
  let inventoryStatus = 'Optimal Velocity';
  let statusColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
  let pricingRecommendation = 'Maintain baseline pricing';

  if (daysRemaining < leadDays) {
    inventoryStatus = 'Critical Stockout Risk';
    statusColor = 'text-rose-400 bg-rose-500/10 border-rose-500/20';
    pricingRecommendation = `Raise price by 5–10% to throttle velocity while replenishment arrives (${leadDays}d lead time).`;
  } else if (daysRemaining > leadDays * 4) {
    inventoryStatus = 'Excess Holding Inventory';
    statusColor = 'text-amber-400 bg-amber-500/10 border-amber-500/20';
    pricingRecommendation = 'Apply promotional markdown to avoid carrying holding costs.';
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 font-semibold">{selectedProduct.sku}</span>
            <span className="text-slate-600">·</span>
            <h2 className="text-xl font-bold text-slate-100 tracking-tight">{selectedProduct.name}</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Inventory-aware pricing and perishable shelf-life decay models to minimize holding costs and eliminate stockout disruptions.
          </p>
        </div>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Current Inventory</span>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            {stock.toLocaleString()} <span className="text-xs font-normal text-slate-500 font-sans">units</span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Value: {formatCurrency(stock * unitCost)}</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Run-Out Runway</span>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            {daysRemaining.toFixed(0)} <span className="text-xs font-normal text-slate-500 font-sans">days</span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Lead Time: {leadDays} days</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Velocity Run-Rate</span>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            {dailyDemand.toFixed(1)} <span className="text-xs font-normal text-slate-500 font-sans">units/day</span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono">{weeklyDemand.toLocaleString()} units/wk</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Holding Cost</span>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            {formatCurrency(stock * selectedProduct.holdingCostPerUnitWeek)}
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Per week in warehouse</span>
        </div>
      </div>

      {/* Inventory Health & Perishable Decay Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Inventory Velocity Assessment */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-200">Stock Runway & Lead Time Analysis</h3>

          <div className={`p-4 rounded border ${statusColor} space-y-2`}>
            <div className="flex items-center justify-between text-xs font-mono font-bold">
              <span>STATUS: {inventoryStatus}</span>
              <span>{daysRemaining.toFixed(0)}d vs {leadDays}d Lead</span>
            </div>
            <p className="text-xs font-sans leading-relaxed text-slate-300">
              {pricingRecommendation}
            </p>
          </div>

          <div className="space-y-2 text-xs font-mono pt-2">
            <div className="flex justify-between py-1.5 border-b border-slate-800">
              <span className="text-slate-400">Stockout Risk Threshold:</span>
              <span className="text-slate-200 font-bold">&lt; {leadDays} days</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-800">
              <span className="text-slate-400">Reorder Trigger Date:</span>
              <span className="text-emerald-400 font-bold">
                {new Date(Date.now() + Math.max(1, daysRemaining - leadDays) * 86400000).toISOString().split('T')[0]}
              </span>
            </div>
          </div>
        </div>

        {/* Perishable Shelf Life Dynamic Markdown */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-200">Perishable Shelf-Life Decay Pricing</h3>
            <span className="text-[11px] font-mono text-amber-400">Freshness Decay Curve</span>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400">Total Shelf Life:</span>
                <span className="font-mono text-slate-200">{shelfLifeDays} days</span>
              </div>
              <input
                type="range"
                min="10"
                max="180"
                value={shelfLifeDays}
                onChange={(e) => setShelfLifeDays(parseInt(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400">Days Elapsed since Packing:</span>
                <span className="font-mono text-amber-400">{daysElapsed} days ({daysToExpiry}d remaining)</span>
              </div>
              <input
                type="range"
                min="0"
                max={shelfLifeDays}
                value={daysElapsed}
                onChange={(e) => setDaysElapsed(parseInt(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 flex justify-between items-center text-xs">
              <div>
                <span className="text-slate-400 block font-mono">Dynamic Clearance Price:</span>
                <span className="text-xs text-slate-500 font-sans">
                  Discount: {(perishableDiscount.disc * 100).toFixed(0)}% to clear prior to spoilage
                </span>
              </div>
              <div className="text-right">
                <div className="text-xl font-bold font-mono text-emerald-400">
                  {formatCurrency(perishableDiscount.clearedPrice)}
                </div>
                <button
                  onClick={() => updateProduct(selectedProduct.id, { recommendedPrice: Number(perishableDiscount.clearedPrice.toFixed(2)), status: 'CALCULATED' })}
                  className="text-[10px] text-teal-400 hover:underline font-mono"
                >
                  Set as Target
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
