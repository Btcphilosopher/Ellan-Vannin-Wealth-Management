import React, { useState, useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import { calculateLogLogElasticity, calculateArcElasticity, getPooledElasticity } from '../../lib/math/elasticity';
import { Activity, ArrowRight, Info, CheckCircle2 } from 'lucide-react';

export const ElasticityLabView: React.FC = () => {
  const { selectedProduct, formatCurrency } = usePricing();

  // Regression on product's historical points
  const regression = useMemo(() => {
    return calculateLogLogElasticity(selectedProduct.salesHistory);
  }, [selectedProduct]);

  // Empirical Bayes category pooling
  const categoryPrior = -1.65;
  const pooled = useMemo(() => {
    return getPooledElasticity(regression.elasticity, regression.sampleSize, categoryPrior);
  }, [regression, categoryPrior]);

  // Arc Elasticity Interactive Sandbox
  const [arcP1, setArcP1] = useState(selectedProduct.currentPrice);
  const [arcQ1, setArcQ1] = useState(selectedProduct.baselineDemand);
  const [arcP2, setArcP2] = useState(Number((selectedProduct.currentPrice * 1.10).toFixed(2)));
  const [arcQ2, setArcQ2] = useState(Number((selectedProduct.baselineDemand * Math.pow(1.10, selectedProduct.elasticity)).toFixed(0)));

  const computedArc = useMemo(() => {
    return calculateArcElasticity(arcP1, arcQ1, arcP2, arcQ2);
  }, [arcP1, arcQ1, arcP2, arcQ2]);

  // Scatter plot setup
  const chartWidth = 680;
  const chartHeight = 260;
  const padding = { top: 20, right: 30, bottom: 40, left: 55 };

  const points = selectedProduct.salesHistory;
  const minPrice = Math.min(...points.map(p => p.price)) * 0.95;
  const maxPrice = Math.max(...points.map(p => p.price)) * 1.05;
  const minUnits = Math.min(...points.map(p => p.unitsSold)) * 0.85;
  const maxUnits = Math.max(...points.map(p => p.unitsSold)) * 1.15;

  const getX = (price: number) => {
    return padding.left + ((price - minPrice) / (maxPrice - minPrice)) * (chartWidth - padding.left - padding.right);
  };

  const getY = (units: number) => {
    return chartHeight - padding.bottom - ((units - minUnits) / (maxUnits - minUnits)) * (chartHeight - padding.top - padding.bottom);
  };

  // Fitted regression points
  const fittedP1 = minPrice;
  const fittedQ1 = Math.exp(regression.intercept + regression.elasticity * Math.log(fittedP1));
  const fittedP2 = maxPrice;
  const fittedQ2 = Math.exp(regression.intercept + regression.elasticity * Math.log(fittedP2));

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 font-semibold">{selectedProduct.sku}</span>
            <span className="text-slate-600">·</span>
            <h2 className="text-xl font-bold text-slate-100 tracking-tight">{selectedProduct.name}</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Econometric price elasticity of demand estimation via log-log ordinary least squares and empirical Bayes category pooling.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Classification:</span>
          <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            {regression.classification} (ε = {regression.elasticity.toFixed(2)})
          </span>
        </div>
      </div>

      {/* Regression Diagnostics KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Elasticity Coefficient (β)</span>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {regression.elasticity.toFixed(3)}
          </div>
          <span className="text-[11px] text-slate-500 font-mono">SE: ±{regression.standardError.toFixed(3)}</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Statistical Fit (R²)</span>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            {(regression.rSquared * 100).toFixed(1)}%
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Variance explained</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">95% Confidence Interval</span>
          <div className="text-sm font-bold font-mono text-slate-200 mt-2">
            [{regression.confidenceInterval95[0]} , {regression.confidenceInterval95[1]}]
          </div>
          <span className="text-[11px] text-slate-500 font-mono">p-value: {regression.pValue.toFixed(4)}</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Hierarchical Shrinkage</span>
          <div className="text-2xl font-bold font-mono text-teal-400 mt-1">
            {pooled.pooled.toFixed(2)}
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Weight on Product: {(pooled.weightOnProduct * 100).toFixed(0)}%</span>
        </div>
      </div>

      {/* Main Grid: Scatter Plot on Left, Arc Elasticity Calculator on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Scatter Plot with Fitted Regression Line */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-200">Log-Log OLS Empirical Demand Scatter</h3>
            <span className="text-[11px] font-mono text-slate-500">ln(Q) = {regression.intercept} + ({regression.elasticity})·ln(P)</span>
          </div>

          <div className="w-full overflow-x-auto">
            <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-64 select-none">
              {/* Axes */}
              <line x1={padding.left} y1={chartHeight - padding.bottom} x2={chartWidth - padding.right} y2={chartHeight - padding.bottom} stroke="#334155" />
              <line x1={padding.left} y1={padding.top} x2={padding.left} y2={chartHeight - padding.bottom} stroke="#334155" />

              {/* Axis Labels */}
              <text x={chartWidth / 2} y={chartHeight - 10} fill="#94a3b8" fontSize="11" textAnchor="middle" fontFamily="monospace">
                Historical Selling Price (£)
              </text>
              <text x={18} y={chartHeight / 2} fill="#94a3b8" fontSize="11" textAnchor="middle" transform={`rotate(-90 18 ${chartHeight/2})`} fontFamily="monospace">
                Daily Units Sold
              </text>

              {/* Fitted Regression Line */}
              <line
                x1={getX(fittedP1)}
                y1={getY(fittedQ1)}
                x2={getX(fittedP2)}
                y2={getY(fittedQ2)}
                stroke="#10b981"
                strokeWidth="2"
                strokeDasharray="4 4"
              />

              {/* Data points */}
              {points.map((pt, i) => (
                <circle
                  key={i}
                  cx={getX(pt.price)}
                  cy={getY(pt.unitsSold)}
                  r="4"
                  fill="#38bdf8"
                  fillOpacity="0.75"
                  stroke="#0f172a"
                  strokeWidth="1"
                />
              ))}
            </svg>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded text-xs text-slate-300 font-sans leading-relaxed">
            <span className="font-semibold text-emerald-400">Interpretation: </span>
            {regression.description}
          </div>
        </div>

        {/* Arc Elasticity Sandbox */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-200">Arc Elasticity Sandbox</h3>
          <p className="text-xs text-slate-400">
            Calculate empirical mid-point arc elasticity between two discrete observations (P₁, Q₁) and (P₂, Q₂).
          </p>

          <div className="space-y-3 pt-1">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1 font-mono">P₁ (Initial Price)</label>
                <input
                  type="number"
                  step="0.5"
                  value={arcP1}
                  onChange={(e) => setArcP1(parseFloat(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-400 block mb-1 font-mono">Q₁ (Initial Units)</label>
                <input
                  type="number"
                  step="10"
                  value={arcQ1}
                  onChange={(e) => setArcQ1(parseInt(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1 font-mono">P₂ (New Price)</label>
                <input
                  type="number"
                  step="0.5"
                  value={arcP2}
                  onChange={(e) => setArcP2(parseFloat(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-400 block mb-1 font-mono">Q₂ (New Units)</label>
                <input
                  type="number"
                  step="10"
                  value={arcQ2}
                  onChange={(e) => setArcQ2(parseInt(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                />
              </div>
            </div>

            <div className="p-3.5 bg-slate-950 rounded border border-slate-800 text-center space-y-1 mt-4">
              <span className="text-[11px] font-mono text-slate-400 uppercase">Calculated Arc Elasticity</span>
              <div className="text-2xl font-bold font-mono text-emerald-400">
                {isFinite(computedArc) ? computedArc.toFixed(3) : 'Undefined'}
              </div>
              <span className="text-[10px] text-slate-500 font-mono block">
                %ΔQ = {(((arcQ2 - arcQ1) / ((arcQ1 + arcQ2) / 2)) * 100).toFixed(1)}% / %ΔP = {(((arcP2 - arcP1) / ((arcP1 + arcP2) / 2)) * 100).toFixed(1)}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
