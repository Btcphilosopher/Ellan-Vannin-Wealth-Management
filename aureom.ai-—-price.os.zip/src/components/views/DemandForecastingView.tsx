import React, { useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import { runHoltWintersForecast } from '../../lib/math/forecasting';
import { TrendingUp, Calendar, CheckCircle2 } from 'lucide-react';

export const DemandForecastingView: React.FC = () => {
  const { selectedProduct } = usePricing();

  const history = useMemo(() => {
    return selectedProduct.salesHistory.map(h => ({
      date: h.date,
      unitsSold: h.unitsSold,
    }));
  }, [selectedProduct]);

  const forecast = useMemo(() => {
    return runHoltWintersForecast(history, 14, 7);
  }, [history]);

  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  // SVG Chart Setup
  const chartWidth = 760;
  const chartHeight = 260;
  const padding = { top: 20, right: 25, bottom: 35, left: 50 };

  const points = forecast.points;
  const maxVal = Math.max(...points.map(p => Math.max(p.actual || 0, p.upper95))) * 1.15;
  const n = points.length;

  const getX = (i: number) => {
    return padding.left + (i / (n - 1)) * (chartWidth - padding.left - padding.right);
  };

  const getY = (v: number) => {
    return chartHeight - padding.bottom - (v / maxVal) * (chartHeight - padding.top - padding.bottom);
  };

  // 95% Band Polygon
  const band95Path = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(p.upper95)}`).join(' ') +
    ' ' + points.slice().reverse().map((p, i) => `L ${getX(n - 1 - i)} ${getY(p.lower95)}`).join(' ') + ' Z';

  // 80% Band Polygon
  const band80Path = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(p.upper80)}`).join(' ') +
    ' ' + points.slice().reverse().map((p, i) => `L ${getX(n - 1 - i)} ${getY(p.lower80)}`).join(' ') + ' Z';

  // Actual Line (for historical days)
  const actualCount = history.length;
  const actualPath = points.slice(0, actualCount).map((p, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(p.actual || 0)}`).join(' ');

  // Forecast Line
  const forecastPath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(p.forecast)}`).join(' ');

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 font-semibold">{selectedProduct.sku}</span>
            <span className="text-slate-600">·</span>
            <h2 className="text-xl font-bold text-slate-100 tracking-tight">{selectedProduct.name}</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Time-series econometric forecasting utilizing Holt-Winters Multiplicative Seasonality and 80%/95% prediction intervals.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-400">Method:</span>
          <span className="text-xs font-mono text-emerald-400 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
            {forecast.method}
          </span>
        </div>
      </div>

      {/* Accuracy & Decomposition KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Forecast Accuracy (MAPE)</span>
          <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
            {forecast.mape}%
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Mean Absolute Pct Error</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Root Mean Square Error</span>
          <div className="text-xl font-bold font-mono text-slate-100 mt-1">
            {forecast.rmse} <span className="text-xs font-normal text-slate-500 font-sans">units</span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Residual Standard Dev</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Observed Trend</span>
          <div className="text-xl font-bold font-mono text-slate-100 mt-1">
            {forecast.trendDirection}
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Damped linear component</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Forecast Horizon</span>
          <div className="text-xl font-bold font-mono text-slate-100 mt-1">
            +14 Days
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Through {points[points.length - 1]?.date}</span>
        </div>
      </div>

      {/* Interactive Time Series Chart */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-slate-200">
              <span className="w-2.5 h-0.5 bg-slate-200 inline-block"></span> Actual Sales
            </span>
            <span className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-2.5 h-0.5 bg-emerald-400 inline-block"></span> Model Forecast
            </span>
            <span className="flex items-center gap-1.5 text-emerald-500/40">
              <span className="w-2.5 h-2 bg-emerald-500/20 inline-block border border-emerald-500/40"></span> 80% / 95% Confidence Band
            </span>
          </div>
          <span className="text-[11px] font-mono text-slate-500">History: 30 Days · Projection: 14 Days</span>
        </div>

        {/* SVG Plot */}
        <div className="w-full overflow-x-auto">
          <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-64 select-none">
            {/* Confidence Bands */}
            <path d={band95Path} fill="rgba(16, 185, 129, 0.08)" />
            <path d={band80Path} fill="rgba(16, 185, 129, 0.15)" />

            {/* Split Line between Actuals and Forecast */}
            <line
              x1={getX(actualCount - 1)}
              y1={padding.top}
              x2={getX(actualCount - 1)}
              y2={chartHeight - padding.bottom}
              stroke="#64748b"
              strokeDasharray="4 4"
            />
            <text
              x={getX(actualCount - 1) - 6}
              y={padding.top + 12}
              fill="#64748b"
              fontSize="10"
              fontFamily="monospace"
              textAnchor="end"
            >
              Historical Actuals
            </text>
            <text
              x={getX(actualCount - 1) + 6}
              y={padding.top + 12}
              fill="#10b981"
              fontSize="10"
              fontFamily="monospace"
              textAnchor="start"
            >
              Out-of-Sample Forecast →
            </text>

            {/* Grid & Axes */}
            <line
              x1={padding.left}
              y1={chartHeight - padding.bottom}
              x2={chartWidth - padding.right}
              y2={chartHeight - padding.bottom}
              stroke="#334155"
            />
            <line
              x1={padding.left}
              y1={padding.top}
              x2={padding.left}
              y2={chartHeight - padding.bottom}
              stroke="#334155"
            />

            {/* Lines */}
            <path d={forecastPath} fill="none" stroke="#10b981" strokeWidth="2" strokeDasharray="3 3" />
            <path d={actualPath} fill="none" stroke="#f1f5f9" strokeWidth="2" />

            {/* Data points for actuals */}
            {points.slice(0, actualCount).map((p, i) => (
              <circle
                key={p.date}
                cx={getX(i)}
                cy={getY(p.actual || 0)}
                r="2.5"
                fill="#f1f5f9"
              />
            ))}
          </svg>
        </div>

        <div className="p-3 bg-slate-950 border border-slate-800 rounded text-xs text-slate-300 font-sans">
          <span className="font-semibold text-emerald-400">Diagnostic Summary: </span>
          {forecast.summary}
        </div>
      </div>

      {/* Seasonality Decomposition (DOW Profile) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3">
        <h3 className="text-sm font-semibold text-slate-200">Day-of-Week Seasonality Decomposition</h3>
        <p className="text-xs text-slate-400">Multiplicative index relative to weekly average (1.0 = average demand).</p>

        <div className="grid grid-cols-7 gap-3 pt-2">
          {forecast.seasonalIndices.map((idx, dow) => {
            const isWeekend = dow === 0 || dow === 6;
            return (
              <div key={dow} className="p-3 bg-slate-950 rounded border border-slate-800 text-center space-y-1">
                <span className="text-xs font-semibold text-slate-300">{daysOfWeek[dow]}</span>
                <div className={`text-base font-bold font-mono tabular-nums ${idx >= 1.05 ? 'text-emerald-400' : idx <= 0.95 ? 'text-slate-400' : 'text-slate-200'}`}>
                  {idx.toFixed(2)}×
                </div>
                <span className="text-[10px] text-slate-500 font-mono block">
                  {idx >= 1.0 ? `+${((idx - 1) * 100).toFixed(0)}%` : `${((idx - 1) * 100).toFixed(0)}%`}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
