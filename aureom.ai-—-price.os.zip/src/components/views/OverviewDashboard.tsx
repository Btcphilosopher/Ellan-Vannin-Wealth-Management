import React, { useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Sparkles,
  ArrowUpRight,
  ShieldAlert,
  ArrowRight,
  DollarSign,
  Package,
} from 'lucide-react';

export const OverviewDashboard: React.FC = () => {
  const { products, formatCurrency, setActiveNav, setSelectedProductId } = usePricing();

  // Aggregate executive metrics
  const stats = useMemo(() => {
    let totalRev = 0;
    let totalCost = 0;
    let belowMarginCount = 0;
    let repriceCandidateCount = 0;
    let potentialProfitUplift = 0;
    let potentialRevUplift = 0;

    products.forEach(p => {
      const weeklyRev = p.currentPrice * p.baselineDemand;
      const weeklyCost = p.unitCost * p.baselineDemand;
      totalRev += weeklyRev;
      totalCost += weeklyCost;

      const currentMargin = (p.currentPrice - p.unitCost) / p.currentPrice;
      if (currentMargin < p.minMarginThreshold) {
        belowMarginCount++;
      }

      if (p.recommendedPrice && Math.abs(p.recommendedPrice - p.currentPrice) > 0.5) {
        repriceCandidateCount++;
        // Rough expected weekly uplift
        const recMargin = (p.recommendedPrice - p.unitCost) * (p.baselineDemand * Math.pow(p.recommendedPrice / p.currentPrice, p.elasticity));
        const currProfit = (p.currentPrice - p.unitCost) * p.baselineDemand;
        if (recMargin > currProfit) {
          potentialProfitUplift += (recMargin - currProfit);
        }
        const recRev = p.recommendedPrice * (p.baselineDemand * Math.pow(p.recommendedPrice / p.currentPrice, p.elasticity));
        if (recRev > weeklyRev) {
          potentialRevUplift += (recRev - weeklyRev);
        }
      }
    });

    const grossProfit = totalRev - totalCost;
    const grossMarginPct = totalRev > 0 ? (grossProfit / totalRev) * 100 : 0;
    const avgPrice = products.reduce((sum, p) => sum + p.currentPrice, 0) / products.length;

    return {
      annualizedRevenue: totalRev * 52,
      weeklyGrossProfit: grossProfit,
      annualizedGrossProfit: grossProfit * 52,
      grossMarginPct,
      avgPrice,
      belowMarginCount,
      repriceCandidateCount,
      annualizedProfitOpportunity: potentialProfitUplift * 52,
      annualizedRevOpportunity: potentialRevUplift * 52,
    };
  }, [products]);

  // Category performance grouping
  const categoryStats = useMemo(() => {
    const cats: Record<string, { count: number; rev: number; profit: number }> = {};
    products.forEach(p => {
      if (!cats[p.category]) cats[p.category] = { count: 0, rev: 0, profit: 0 };
      const rev = p.currentPrice * p.baselineDemand;
      const profit = (p.currentPrice - p.unitCost) * p.baselineDemand;
      cats[p.category].count++;
      cats[p.category].rev += rev;
      cats[p.category].profit += profit;
    });

    return Object.entries(cats).map(([name, data]) => ({
      name,
      count: data.count,
      weeklyRev: data.rev,
      margin: data.rev > 0 ? (data.profit / data.rev) * 100 : 0,
    }));
  }, [products]);

  // Top urgent re-pricing opportunities
  const topOpportunities = useMemo(() => {
    return products
      .filter(p => p.recommendedPrice && p.recommendedPrice !== p.currentPrice)
      .slice(0, 5);
  }, [products]);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner / Executive Summary */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 tracking-tight">Executive Pricing Intelligence</h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time econometric revenue management and mathematical price optimization across 100 catalog SKUs.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveNav('quick_calc')}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs rounded font-medium transition-colors"
          >
            Open Calculator
          </button>
          <button
            onClick={() => setActiveNav('recommendations')}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs rounded font-medium transition-colors flex items-center gap-1.5"
          >
            <span>Review {stats.repriceCandidateCount} Recommendations</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Primary KPI Grid (High Density) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Annualized Revenue</span>
          <div className="text-xl font-bold font-mono tabular-nums text-slate-100 mt-1">
            {formatCurrency(stats.annualizedRevenue)}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 mt-2 font-mono">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+4.2% YoY Run-rate</span>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Gross Margin</span>
          <div className="text-xl font-bold font-mono tabular-nums text-emerald-400 mt-1">
            {stats.grossMarginPct.toFixed(1)}%
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-2 font-mono">
            <span>Weekly GP: {formatCurrency(stats.weeklyGrossProfit)}</span>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Estimated Profit Opportunity</span>
          <div className="text-xl font-bold font-mono tabular-nums text-emerald-300 mt-1">
            +{formatCurrency(stats.annualizedProfitOpportunity)}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 mt-2 font-mono">
            <span>+{((stats.annualizedProfitOpportunity / Math.max(1, stats.annualizedGrossProfit)) * 100).toFixed(1)}% Expansion</span>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Constraint Health</span>
          <div className="text-xl font-bold font-mono tabular-nums text-amber-400 mt-1">
            {stats.belowMarginCount} SKUs At Risk
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-2 font-mono">
            <span>{100 - stats.belowMarginCount} / 100 within floor</span>
          </div>
        </div>
      </div>

      {/* Main Charts & Breakdown Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Margin & Revenue Matrix */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-100">Category Profitability & Volume Matrix</h3>
              <p className="text-xs text-slate-400">Weekly revenue run-rates and realized gross margins by division</p>
            </div>
            <span className="text-xs font-mono text-slate-500">6 Business Sectors</span>
          </div>

          <div className="space-y-3.5">
            {categoryStats.map(cat => {
              const maxRev = Math.max(...categoryStats.map(c => c.weeklyRev));
              const revWidth = `${Math.min(100, Math.max(8, (cat.weeklyRev / maxRev) * 100))}%`;

              return (
                <div key={cat.name} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-200">{cat.name}</span>
                    <div className="flex items-center gap-4 font-mono tabular-nums">
                      <span className="text-slate-400">{cat.count} SKUs</span>
                      <span className="text-slate-300 font-semibold">{formatCurrency(cat.weeklyRev)}/wk</span>
                      <span className={`px-1.5 py-0.5 rounded text-[11px] font-bold ${
                        cat.margin >= 50 ? 'text-emerald-400 bg-emerald-500/10' :
                        cat.margin >= 35 ? 'text-slate-300 bg-slate-800' : 'text-amber-400 bg-amber-500/10'
                      }`}>
                        {cat.margin.toFixed(1)}% Margin
                      </span>
                    </div>
                  </div>
                  <div className="h-2 w-full bg-slate-800/80 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-600 to-teal-400 rounded-full transition-all duration-500"
                      style={{ width: revWidth }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Pricing Recommendations Quick Review */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-slate-100">High-Impact Recommendations</h3>
              <span className="text-[11px] font-mono text-emerald-400">Optimal Alpha</span>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Products with highest predicted contribution profit change if re-priced to calculated optimum.
            </p>

            <div className="space-y-2.5">
              {topOpportunities.map(p => {
                const delta = (p.recommendedPrice || p.currentPrice) - p.currentPrice;
                const deltaPct = (delta / p.currentPrice) * 100;

                return (
                  <div
                    key={p.id}
                    onClick={() => {
                      setSelectedProductId(p.id);
                      setActiveNav('optimisation');
                    }}
                    className="p-2.5 rounded bg-slate-950/60 border border-slate-800/80 hover:border-emerald-500/50 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200 truncate max-w-[140px]">{p.sku}</span>
                      <span className={`font-mono font-semibold tabular-nums ${delta >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {delta >= 0 ? '+' : ''}{deltaPct.toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1 font-mono tabular-nums">
                      <span>Now: {formatCurrency(p.currentPrice)}</span>
                      <span className="text-slate-100 font-bold">Target: {formatCurrency(p.recommendedPrice || p.currentPrice)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => setActiveNav('recommendations')}
            className="w-full mt-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium rounded transition-colors text-center"
          >
            View Full Recommendation Queue
          </button>
        </div>
      </div>

      {/* Model Invariants & Audit Banner */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-lg p-4 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-slate-400 font-mono">
        <div className="flex items-center gap-3">
          <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
            ENGINE STATUS: ACTIVE
          </span>
          <span>Optimizer: Golden-Section / Brent Search</span>
          <span className="hidden md:inline">·</span>
          <span>Demand Model: Q(P) = Q₀(P/P₀)^ε</span>
        </div>
        <span className="text-slate-500 text-[11px]">Audit Timestamp: 2026-11-07 08:35 UTC</span>
      </div>
    </div>
  );
};
