import React, { useState, useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import { ProductCategory, OptimisationObjective } from '../../types/pricing';
import { Search, Filter, Play, Check, AlertTriangle, Layers, ArrowUpDown } from 'lucide-react';

export const ProductPortfolioView: React.FC = () => {
  const {
    products,
    formatCurrency,
    selectedProductId,
    setSelectedProductId,
    setActiveNav,
    runBulkOptimisation,
  } = usePricing();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [filterBelowMargin, setFilterBelowMargin] = useState(false);
  const [filterRepriceCandidates, setFilterRepriceCandidates] = useState(false);
  const [bulkObjective, setBulkObjective] = useState<OptimisationObjective>('maximise_profit');
  const [bulkSuccessMsg, setBulkSuccessMsg] = useState(false);

  // Sorting
  const [sortField, setSortField] = useState<'sku' | 'price' | 'cost' | 'margin' | 'demand'>('sku');
  const [sortAsc, setSortAsc] = useState(true);

  const categories: (ProductCategory | 'ALL')[] = [
    'ALL',
    'Consumer Tech',
    'Apparel & Footwear',
    'Specialty Food & Beverage',
    'Hospitality & Rooms',
    'SaaS & Subscriptions',
    'Industrial Supplies',
  ];

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchesSearch = p.sku.toLowerCase().includes(search.toLowerCase()) ||
        p.name.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = selectedCategory === 'ALL' || p.category === selectedCategory;
      const currentMargin = p.currentPrice > 0 ? (p.currentPrice - p.unitCost) / p.currentPrice : 0;
      const matchesMargin = !filterBelowMargin || currentMargin < p.minMarginThreshold;
      const matchesReprice = !filterRepriceCandidates || (p.recommendedPrice && p.recommendedPrice !== p.currentPrice);

      return matchesSearch && matchesCategory && matchesMargin && matchesReprice;
    }).sort((a, b) => {
      let valA: any = a.sku;
      let valB: any = b.sku;
      if (sortField === 'price') { valA = a.currentPrice; valB = b.currentPrice; }
      else if (sortField === 'cost') { valA = a.unitCost; valB = b.unitCost; }
      else if (sortField === 'margin') {
        valA = (a.currentPrice - a.unitCost) / a.currentPrice;
        valB = (b.currentPrice - b.unitCost) / b.currentPrice;
      } else if (sortField === 'demand') { valA = a.baselineDemand; valB = b.baselineDemand; }

      if (valA < valB) return sortAsc ? -1 : 1;
      if (valA > valB) return sortAsc ? 1 : -1;
      return 0;
    });
  }, [products, search, selectedCategory, filterBelowMargin, filterRepriceCandidates, sortField, sortAsc]);

  const handleBulkRun = () => {
    runBulkOptimisation(bulkObjective, selectedCategory === 'ALL' ? 'ALL' : (selectedCategory as ProductCategory));
    setBulkSuccessMsg(true);
    setTimeout(() => setBulkSuccessMsg(false), 3500);
  };

  const handleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 tracking-tight">Enterprise Product Portfolio (100 SKUs)</h2>
          <p className="text-xs text-slate-400 mt-1">
            Centralized multi-category pricing catalog with live elasticity diagnostics, inventory tracking, and batch numerical optimization.
          </p>
        </div>
      </div>

      {bulkSuccessMsg && (
        <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded text-xs text-emerald-400 font-mono">
          ✓ Bulk optimization solver successfully completed for {filteredProducts.length} items. Recommendations updated in queue.
        </div>
      )}

      {/* Bulk Solver Action Strip */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Layers className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <span className="text-xs font-semibold text-slate-200">Bulk Portfolio Optimiser</span>
            <p className="text-[11px] text-slate-400">Apply non-linear solver across current selection ({filteredProducts.length} SKUs)</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={bulkObjective}
            onChange={(e) => setBulkObjective(e.target.value as OptimisationObjective)}
            className="bg-slate-950 border border-slate-800 text-xs text-slate-200 rounded px-3 py-1.5 focus:outline-none focus:border-emerald-500 font-sans"
          >
            <option value="maximise_profit">Objective: Maximise Contribution Profit</option>
            <option value="maximise_revenue">Objective: Maximise Gross Revenue</option>
            <option value="balance_profit_volume">Objective: Balanced Profit & Volume</option>
          </select>

          <button
            onClick={handleBulkRun}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs rounded font-medium transition-colors"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Execute Batch Solver</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Search */}
          <div className="relative w-full md:w-80">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Filter by SKU or Product Name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded pl-9 pr-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Quick Filters */}
          <div className="flex items-center gap-2 w-full md:w-auto">
            <button
              onClick={() => setFilterBelowMargin(!filterBelowMargin)}
              className={`px-2.5 py-1 text-xs rounded border transition-colors ${
                filterBelowMargin
                  ? 'bg-rose-500/15 text-rose-300 border-rose-500/40'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              Below Margin Floor
            </button>
            <button
              onClick={() => setFilterRepriceCandidates(!filterRepriceCandidates)}
              className={`px-2.5 py-1 text-xs rounded border transition-colors ${
                filterRepriceCandidates
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              Reprice Candidates
            </button>
          </div>
        </div>

        {/* Category Segmented Controls */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {categories.map(c => (
            <button
              key={c}
              onClick={() => setSelectedCategory(c)}
              className={`px-2.5 py-1 rounded whitespace-nowrap transition-colors ${
                selectedCategory === c
                  ? 'bg-slate-800 text-emerald-400 font-semibold border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {c === 'ALL' ? 'All Industries (100)' : c}
            </button>
          ))}
        </div>
      </div>

      {/* 100-SKU Data Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono uppercase text-slate-400 select-none">
              <tr>
                <th onClick={() => handleSort('sku')} className="py-2.5 px-3 cursor-pointer hover:text-slate-200">
                  <div className="flex items-center gap-1">
                    <span>SKU / Product</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-2.5 px-3">Category</th>
                <th onClick={() => handleSort('price')} className="py-2.5 px-3 text-right cursor-pointer hover:text-slate-200">
                  <div className="flex items-center justify-end gap-1">
                    <span>Current Price</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th onClick={() => handleSort('cost')} className="py-2.5 px-3 text-right cursor-pointer hover:text-slate-200">
                  <span>Unit Cost</span>
                </th>
                <th onClick={() => handleSort('margin')} className="py-2.5 px-3 text-right cursor-pointer hover:text-slate-200">
                  <span>Gross Margin</span>
                </th>
                <th onClick={() => handleSort('demand')} className="py-2.5 px-3 text-right cursor-pointer hover:text-slate-200">
                  <span>Demand/wk</span>
                </th>
                <th className="py-2.5 px-3 text-right">Elasticity (ε)</th>
                <th className="py-2.5 px-3 text-right">Recommended</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                <th className="py-2.5 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono tabular-nums">
              {filteredProducts.map(p => {
                const margin = p.currentPrice > 0 ? ((p.currentPrice - p.unitCost) / p.currentPrice) * 100 : 0;
                const isBelow = margin < p.minMarginThreshold * 100;
                const isSelected = p.id === selectedProductId;
                const recDelta = p.recommendedPrice ? p.recommendedPrice - p.currentPrice : 0;

                return (
                  <tr
                    key={p.id}
                    className={`transition-colors ${
                      isSelected ? 'bg-emerald-500/10' : 'hover:bg-slate-800/40'
                    }`}
                  >
                    <td className="py-2.5 px-3 font-sans">
                      <div className="font-semibold text-slate-100 font-mono">{p.sku}</div>
                      <div className="text-[11px] text-slate-400 truncate max-w-xs">{p.name}</div>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300 font-sans">{p.category}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-100">{formatCurrency(p.currentPrice)}</td>
                    <td className="py-2.5 px-3 text-right text-slate-400">{formatCurrency(p.unitCost)}</td>
                    <td className="py-2.5 px-3 text-right">
                      <span className={`px-1.5 py-0.5 rounded text-[11px] font-bold ${
                        isBelow ? 'text-rose-400 bg-rose-500/10' : 'text-slate-200'
                      }`}>
                        {margin.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">{p.baselineDemand.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right text-teal-400">{p.elasticity.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right">
                      <span className="font-bold text-emerald-400 font-mono">
                        {formatCurrency(p.recommendedPrice || p.currentPrice)}
                      </span>
                      {recDelta !== 0 && (
                        <span className={`block text-[10px] ${recDelta > 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                          {recDelta > 0 ? '+' : ''}{((recDelta / p.currentPrice) * 100).toFixed(1)}%
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className={`text-[10px] px-2 py-0.5 rounded font-sans font-semibold ${
                        p.status === 'APPROVED' ? 'bg-emerald-500/10 text-emerald-400' :
                        p.status === 'PUBLISHED' ? 'bg-teal-500/10 text-teal-400' :
                        p.status === 'PENDING_REVIEW' ? 'bg-amber-500/10 text-amber-400' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <button
                        onClick={() => {
                          setSelectedProductId(p.id);
                          setActiveNav('optimisation');
                        }}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] rounded transition-colors font-sans"
                      >
                        Optimise
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
