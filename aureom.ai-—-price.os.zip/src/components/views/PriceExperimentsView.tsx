import React, { useState } from 'react';
import { usePricing } from '../../context/PricingContext';
import { PriceExperiment } from '../../types/pricing';
import { FlaskConical, Play, CheckCircle2, AlertCircle, BarChart3, Plus } from 'lucide-react';

export const PriceExperimentsView: React.FC = () => {
  const { selectedProduct, formatCurrency } = usePricing();

  const [experiments, setExperiments] = useState<PriceExperiment[]>([
    {
      id: 'exp-01',
      name: 'Wireless ANC Q4 Elasticity Calibration',
      sku: 'TECH-ANC-01',
      category: 'Consumer Tech',
      status: 'RUNNING',
      startDate: '2026-10-25',
      endDate: '2026-11-15',
      controlPrice: 199.99,
      treatmentPrice: 209.99,
      trafficSplit: 50,
      sampleSizeTarget: 1500,
      controlUnitsSold: 284,
      treatmentUnitsSold: 262,
      controlRevenue: 56797.16,
      treatmentRevenue: 55017.38,
      controlConversionRate: 3.42,
      treatmentConversionRate: 3.18,
      pValue: 0.042,
      statisticallySignificant: true,
      estimatedElasticity: -1.54,
      confidenceInterval: [-1.82, -1.26],
    },
    {
      id: 'exp-02',
      name: 'GaN Charger Low-Price Penetration Test',
      sku: 'TECH-CHG-65W',
      category: 'Consumer Tech',
      status: 'CONCLUDED',
      startDate: '2026-10-01',
      endDate: '2026-10-21',
      controlPrice: 34.99,
      treatmentPrice: 31.99,
      trafficSplit: 50,
      sampleSizeTarget: 3000,
      controlUnitsSold: 580,
      treatmentUnitsSold: 712,
      controlRevenue: 20294.20,
      treatmentRevenue: 22776.88,
      controlConversionRate: 5.12,
      treatmentConversionRate: 6.35,
      pValue: 0.008,
      statisticallySignificant: true,
      estimatedElasticity: -2.48,
      confidenceInterval: [-2.85, -2.11],
    },
  ]);

  const activeExp = experiments[0];

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 tracking-tight">Controlled Price Experiments (A/B Testing)</h2>
          <p className="text-xs text-slate-400 mt-1">
            Statistically rigorous randomized pricing trials with causal elasticity estimation, traffic randomization, and sample size power testing.
          </p>
        </div>

        <button
          onClick={() => {
            const newExp: PriceExperiment = {
              id: `exp-${Date.now()}`,
              name: `${selectedProduct.sku} New Price Test`,
              sku: selectedProduct.sku,
              category: selectedProduct.category,
              status: 'RUNNING',
              startDate: '2026-11-07',
              endDate: '2026-11-28',
              controlPrice: selectedProduct.currentPrice,
              treatmentPrice: selectedProduct.recommendedPrice || Number((selectedProduct.currentPrice * 1.05).toFixed(2)),
              trafficSplit: 50,
              sampleSizeTarget: 2000,
              controlUnitsSold: 0,
              treatmentUnitsSold: 0,
              controlRevenue: 0,
              treatmentRevenue: 0,
              controlConversionRate: 0,
              treatmentConversionRate: 0,
              pValue: 1.0,
              statisticallySignificant: false,
              estimatedElasticity: selectedProduct.elasticity,
              confidenceInterval: [selectedProduct.elasticity - 0.3, selectedProduct.elasticity + 0.3],
            };
            setExperiments(prev => [newExp, ...prev]);
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs rounded font-medium transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Launch Experiment on Active SKU</span>
        </button>
      </div>

      {/* Featured Active Experiment Card */}
      {activeExp && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-emerald-400 font-bold">{activeExp.sku}</span>
                <span className="text-slate-600">·</span>
                <h3 className="text-sm font-semibold text-slate-100">{activeExp.name}</h3>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                Period: {activeExp.startDate} through {activeExp.endDate} · 50/50 Traffic Randomization
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold ${
                activeExp.statisticallySignificant ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-800 text-slate-400'
              }`}>
                {activeExp.statisticallySignificant ? `Statistically Significant (p = ${activeExp.pValue})` : 'Collecting Samples'}
              </span>
            </div>
          </div>

          {/* Side by side Control vs Treatment */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-950 rounded border border-slate-800 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-slate-300">Control Cohort (A)</span>
                <span className="font-mono text-slate-400">50% Traffic</span>
              </div>
              <div className="text-2xl font-bold font-mono text-slate-100">
                {formatCurrency(activeExp.controlPrice)}
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-slate-800/80">
                <div>
                  <span className="text-slate-500 block text-[10px]">Conversion Rate</span>
                  <span className="text-slate-200 font-bold">{activeExp.controlConversionRate}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Units Sold</span>
                  <span className="text-slate-200 font-bold">{activeExp.controlUnitsSold}</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded border border-emerald-500/40 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-emerald-400">Treatment Cohort (B)</span>
                <span className="font-mono text-slate-400">50% Traffic</span>
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-400">
                {formatCurrency(activeExp.treatmentPrice)}
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-slate-800/80">
                <div>
                  <span className="text-slate-500 block text-[10px]">Conversion Rate</span>
                  <span className="text-emerald-300 font-bold">{activeExp.treatmentConversionRate}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Units Sold</span>
                  <span className="text-slate-200 font-bold">{activeExp.treatmentUnitsSold}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded text-xs text-slate-300 font-mono">
            <span className="text-emerald-400 font-semibold">Causal Econometric Estimate: </span>
            Empirical price elasticity derived from randomized trial is ε = {activeExp.estimatedElasticity} (95% CI: [{activeExp.confidenceInterval[0]}, {activeExp.confidenceInterval[1]}]).
          </div>
        </div>
      )}

      {/* Experiments Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3">
        <h3 className="text-sm font-semibold text-slate-200">Experiment Registry</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono uppercase text-slate-400">
              <tr>
                <th className="py-2.5 px-3">Experiment Name</th>
                <th className="py-2.5 px-3">SKU</th>
                <th className="py-2.5 px-3 text-right">Control Price</th>
                <th className="py-2.5 px-3 text-right">Treatment Price</th>
                <th className="py-2.5 px-3 text-right">Status</th>
                <th className="py-2.5 px-3 text-right">p-value</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono tabular-nums">
              {experiments.map(e => (
                <tr key={e.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">{e.name}</td>
                  <td className="py-2.5 px-3 text-slate-400">{e.sku}</td>
                  <td className="py-2.5 px-3 text-right text-slate-100">{formatCurrency(e.controlPrice)}</td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-bold">{formatCurrency(e.treatmentPrice)}</td>
                  <td className="py-2.5 px-3 text-right">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-sans font-semibold ${
                      e.status === 'RUNNING' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {e.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300">{e.pValue}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
