import React, { useState } from 'react';
import { Code2, Copy, Download, Check, Terminal } from 'lucide-react';

const R_FILES: Record<string, { filename: string; path: string; description: string; code: string }> = {
  'pricing_calculations': {
    filename: 'pricing_calculations.R',
    path: 'R/pricing_calculations.R',
    description: 'Core financial formulas: Markup, target gross margin, contribution margin, and break-even calculations.',
    code: `#' Cost-Plus Pricing Calculation
calculate_markup_price <- function(cost, markup) {
  stopifnot(is.finite(cost), cost >= 0)
  stopifnot(is.finite(markup), markup >= 0)
  cost * (1 + markup)
}

#' Target Gross Margin Pricing Calculation
calculate_margin_price <- function(cost, margin) {
  stopifnot(is.finite(cost), cost >= 0)
  stopifnot(is.finite(margin), margin >= 0, margin < 1.0)
  cost / (1 - margin)
}

#' Calculate Gross Margin Ratio
calculate_margin <- function(price, cost) {
  stopifnot(is.finite(price), price > 0, is.finite(cost), cost >= 0)
  (price - cost) / price
}

#' Contribution Margin per Unit
calculate_contribution_margin <- function(net_revenue, variable_costs) {
  stopifnot(is.finite(net_revenue), is.finite(variable_costs))
  net_revenue - variable_costs
}

#' Break-Even Sales Volume
calculate_break_even_volume <- function(fixed_costs, unit_contribution_margin) {
  stopifnot(is.finite(fixed_costs), fixed_costs >= 0)
  if (unit_contribution_margin <= 0) {
    stop("Unit contribution margin must be strictly positive to achieve break-even.")
  }
  ceiling(fixed_costs / unit_contribution_margin)
}`
  },
  'elasticity': {
    filename: 'elasticity.R',
    path: 'R/elasticity.R',
    description: 'Demand response model Q(P) = Q₀(P/P₀)^ε, arc elasticity, and log-log econometric OLS regression.',
    code: `#' Constant Elasticity Demand Response Model
estimate_demand <- function(price, baseline_price, baseline_demand, elasticity) {
  stopifnot(
    is.finite(price), price > 0,
    is.finite(baseline_price), baseline_price > 0,
    is.finite(baseline_demand), baseline_demand >= 0,
    is.finite(elasticity)
  )
  baseline_demand * (price / baseline_price)^elasticity
}

#' Arc Elasticity Calculation
calculate_arc_elasticity <- function(p1, q1, p2, q2) {
  avg_q <- (q1 + q2) / 2
  avg_p <- (p1 + p2) / 2
  if (avg_q == 0 || avg_p == 0 || p1 == p2) return(NA_real_)
  ((q2 - q1) / avg_q) / ((p2 - p1) / avg_p)
}

#' Log-Log Econometric Regression for Price Elasticity
estimate_log_log_elasticity <- function(sales_df) {
  clean_df <- sales_df[sales_df$price > 0 & sales_df$units_sold > 0, ]
  model <- lm(log(units_sold) ~ log(price), data = clean_df)
  summary_model <- summary(model)
  coefs <- summary_model$coefficients
  ci <- confint(model, "log(price)", level = 0.95)

  list(
    elasticity = coefs["log(price)", "Estimate"],
    standard_error = coefs["log(price)", "Std. Error"],
    p_value = coefs["log(price)", "Pr(>|t|)"],
    r_squared = summary_model$r.squared,
    confidence_interval_95 = as.numeric(ci)
  )
}`
  },
  'optimisation': {
    filename: 'optimisation.R',
    path: 'R/optimisation.R',
    description: 'Golden-section numerical bounded optimizer for profit and revenue subject to margin floors.',
    code: `#' Optimise Price for Maximum Profit or Revenue
optimise_price <- function(
  baseline_price,
  baseline_demand,
  elasticity,
  unit_cost,
  min_price,
  max_price,
  min_margin = 0.20,
  objective = c("profit", "revenue")
) {
  objective <- match.arg(objective)

  # Margin constraint floor: price >= unit_cost / (1 - min_margin)
  margin_floor <- unit_cost / (1 - min_margin)
  effective_min <- max(min_price, margin_floor)
  effective_max <- max(effective_min, max_price)

  eval_func <- function(p) {
    d <- estimate_demand(p, baseline_price, baseline_demand, elasticity)
    val <- if (objective == "profit") (p - unit_cost) * d else p * d
    -val # optimize minimizes
  }

  result <- optimize(eval_func, interval = c(effective_min, effective_max))
  opt_price <- result$minimum
  opt_demand <- estimate_demand(opt_price, baseline_price, baseline_demand, elasticity)

  list(
    recommended_price = round(opt_price, 2),
    expected_demand = round(opt_demand, 1),
    expected_profit = round((opt_price - unit_cost) * opt_demand, 2),
    expected_revenue = round(opt_price * opt_demand, 2),
    expected_margin = round((opt_price - unit_cost) / opt_price, 4)
  )
}`
  },
  'tests': {
    filename: 'test_pricing.R',
    path: 'tests/testthat/test_pricing.R',
    description: 'testthat unit test suite covering markup, target margin, break-even, and optimization invariants.',
    code: `library(testthat)
source("../R/pricing_calculations.R")
source("../R/elasticity.R")
source("../R/optimisation.R")

test_that("Markup calculation is mathematically sound", {
  cost <- 40
  markup <- 0.50
  expect_equal(calculate_markup_price(cost, markup), 60)
  expect_equal(calculate_markup(60, 40), 0.50)
})

test_that("Target margin calculation distinguishes margin from markup", {
  cost <- 40
  margin <- 0.40
  price <- calculate_margin_price(cost, margin)
  expect_equal(round(price, 2), 66.67)
  expect_gt(calculate_margin_price(cost, margin), calculate_markup_price(cost, margin))
})

test_that("Break-even rejects zero or negative contribution margin", {
  expect_error(calculate_break_even_volume(10000, 0))
  expect_error(calculate_break_even_volume(10000, -5))
  expect_equal(calculate_break_even_volume(10000, 25), 400)
})

test_that("Price optimiser respects margin floor constraint", {
  res <- optimise_price(50, 100, -2.5, 30, 20, 80, 0.40, "profit")
  expect_gte(res$recommended_price, 50)
  expect_gte(res$expected_margin, 0.40)
})`
  },
  'shiny_app': {
    filename: 'app.R',
    path: 'app.R',
    description: 'Full R Shiny user interface with bslib theme, plotly charts, and reactive parameter evaluation.',
    code: `library(shiny)
library(bslib)
library(plotly)

source("R/pricing_calculations.R")
source("R/elasticity.R")
source("R/optimisation.R")

theme <- bs_theme(
  bg = "#0B0F19", fg = "#F1F5F9",
  primary = "#10B981", secondary = "#64748B",
  base_font = font_google("Plus Jakarta Sans"),
  code_font = font_google("JetBrains Mono")
)

ui <- page_navbar(
  title = "AUREOM.AI — PRICE.OS",
  theme = theme,
  sidebar = sidebar(
    numericInput("unit_cost", "Unit Cost (£)", value = 74.50),
    numericInput("baseline_price", "Current Price (£)", value = 199.99),
    sliderInput("elasticity", "Price Elasticity (ε)", min = -3.5, max = -0.5, value = -1.82, step = 0.05),
    actionButton("btn_calculate", "Recalculate Optimal Price", class = "btn-success w-100")
  ),
  nav_panel("Optimizer",
    plotlyOutput("opt_chart", height = "450px")
  )
)

server <- function(input, output, session) {
  # Server logic invoking optimise_price()
}

shinyApp(ui, server)`
  }
};

export const RSourceCodeView: React.FC = () => {
  const [selectedKey, setSelectedKey] = useState<string>('pricing_calculations');
  const [copied, setCopied] = useState(false);

  const activeFile = R_FILES[selectedKey];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([activeFile.code], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = activeFile.filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Code2 className="w-5 h-5 text-emerald-400" />
            <h2 className="text-xl font-bold text-slate-100 tracking-tight">R Pricing Engine Source & Architecture</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Production-grade, fully functional R mathematical libraries, testthat validation suites, and Shiny modules created in <code className="text-emerald-400 font-mono">/aureom-price-os/</code>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs rounded font-medium transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            <span>{copied ? 'Copied' : 'Copy Code'}</span>
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs rounded font-medium transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download {activeFile.filename}</span>
          </button>
        </div>
      </div>

      {/* Execution Instructions Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 font-mono text-xs text-slate-300 space-y-2">
        <div className="flex items-center gap-2 text-emerald-400 font-semibold">
          <Terminal className="w-4 h-4" />
          <span>Local R Execution Command Line Instructions:</span>
        </div>
        <div className="p-2.5 bg-slate-950 rounded border border-slate-800 text-[11px] text-slate-400 space-y-1">
          <div><span className="text-slate-600"># 1. Launch R Shiny Application:</span></div>
          <div className="text-emerald-300 font-bold">$ Rscript -e "shiny::runApp('aureom-price-os/app.R', port = 3838)"</div>
          <div className="pt-1"><span className="text-slate-600"># 2. Run testthat Automated Mathematical Test Suite:</span></div>
          <div className="text-teal-300 font-bold">$ Rscript -e "testthat::test_dir('aureom-price-os/tests/testthat')"</div>
        </div>
      </div>

      {/* Code Browser Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Module Picker */}
        <div className="space-y-2">
          <span className="text-[11px] font-mono uppercase text-slate-400 tracking-wider block mb-1">
            Engine R Modules
          </span>
          {Object.entries(R_FILES).map(([key, f]) => (
            <button
              key={key}
              onClick={() => setSelectedKey(key)}
              className={`w-full text-left p-3 rounded border text-xs transition-colors font-mono ${
                selectedKey === key
                  ? 'bg-slate-800 border-emerald-500/70 text-emerald-400 font-semibold'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <div className="font-bold">{f.filename}</div>
              <div className="text-[10px] text-slate-500 font-sans mt-0.5 truncate">{f.path}</div>
            </button>
          ))}
        </div>

        {/* Source Code View */}
        <div className="lg:col-span-3 bg-slate-900/95 border border-slate-800 rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <span className="font-mono text-xs font-bold text-slate-100">{activeFile.path}</span>
              <p className="text-[11px] text-slate-400 mt-0.5">{activeFile.description}</p>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 uppercase bg-emerald-500/10 px-2 py-0.5 rounded">
              R Lang
            </span>
          </div>

          <pre className="p-4 bg-slate-950 rounded border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto leading-relaxed select-text">
            {activeFile.code}
          </pre>
        </div>
      </div>
    </div>
  );
};
