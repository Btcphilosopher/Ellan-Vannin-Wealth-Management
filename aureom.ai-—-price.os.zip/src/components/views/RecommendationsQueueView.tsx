import React, { useState } from 'react';
import { usePricing } from '../../context/PricingContext';
import { RecommendationStatus, PriceRecommendation } from '../../types/pricing';
import { CheckCircle2, XCircle, Clock, Send, ShieldCheck, ArrowRight, MessageSquare } from 'lucide-react';

export const RecommendationsQueueView: React.FC = () => {
  const { recommendations, formatCurrency, userRole, updateRecommendationStatus } = usePricing();

  const [activeFilter, setActiveFilter] = useState<string>('ALL');
  const [selectedRecForNote, setSelectedRecForNote] = useState<PriceRecommendation | null>(null);
  const [noteText, setNoteText] = useState('');

  const isAuthorisedApprover = userRole === 'Pricing Approver' || userRole === 'Administrator';

  const filtered = recommendations.filter(r => {
    if (activeFilter === 'ALL') return true;
    return r.status === activeFilter;
  });

  const handleAction = (recId: string, status: RecommendationStatus) => {
    updateRecommendationStatus(recId, status);
  };

  const handleSaveNote = () => {
    if (selectedRecForNote) {
      updateRecommendationStatus(selectedRecForNote.id, selectedRecForNote.status, noteText);
      setSelectedRecForNote(null);
      setNoteText('');
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 tracking-tight">Price Recommendation & Governance Queue</h2>
          <p className="text-xs text-slate-400 mt-1">
            Human-in-the-loop review workflow: Enforces role-based approvals, mathematical explainability, and publication safeguards.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-400">Current Session Role:</span>
          <span className={`text-xs font-mono font-semibold px-2.5 py-1 rounded border ${
            isAuthorisedApprover
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
              : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
          }`}>
            {userRole} {isAuthorisedApprover ? '(Authorised to Approve)' : '(Review Only)'}
          </span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs">
        {['ALL', 'CALCULATED', 'PENDING_REVIEW', 'APPROVED', 'PUBLISHED', 'REJECTED'].map(f => (
          <button
            key={f}
            onClick={() => setActiveFilter(f)}
            className={`px-3 py-1.5 rounded transition-colors font-mono ${
              activeFilter === f
                ? 'bg-slate-800 text-emerald-400 font-semibold border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {f} ({f === 'ALL' ? recommendations.length : recommendations.filter(r => r.status === f).length})
          </button>
        ))}
      </div>

      {/* Recommendations Cards List */}
      <div className="space-y-4">
        {filtered.map(rec => {
          const delta = rec.recommendedPrice - rec.currentPrice;
          const deltaPct = rec.priceDeltaPercent;

          return (
            <div
              key={rec.id}
              className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4"
            >
              {/* Top Row */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-slate-300">{rec.sku}</span>
                    <span className="text-slate-600">·</span>
                    <h3 className="text-sm font-semibold text-slate-100">{rec.productName}</h3>
                    <span className="text-xs text-slate-500 font-sans">({rec.category})</span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">Created: {rec.createdAt}</span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-slate-400">Confidence:</span>
                  <span className="text-xs font-mono font-bold text-emerald-400">{rec.confidenceScore}%</span>
                  <span className={`text-[10px] font-sans font-semibold px-2 py-0.5 rounded ${
                    rec.status === 'APPROVED' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                    rec.status === 'PUBLISHED' ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20' :
                    rec.status === 'REJECTED' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                    'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  }`}>
                    {rec.status}
                  </span>
                </div>
              </div>

              {/* Price Delta Comparison Strip */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
                <div className="p-3 bg-slate-950 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Current Selling Price</span>
                  <div className="text-base font-bold text-slate-200 mt-0.5">
                    {formatCurrency(rec.currentPrice)}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Recommended Price</span>
                  <div className="text-base font-bold text-emerald-400 mt-0.5 flex items-center gap-1.5">
                    <span>{formatCurrency(rec.recommendedPrice)}</span>
                    <span className={`text-xs ${delta >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      ({delta >= 0 ? '+' : ''}{deltaPct}%)
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Expected Weekly GP Delta</span>
                  <div className={`text-base font-bold mt-0.5 ${rec.expectedProfitDelta >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {rec.expectedProfitDelta >= 0 ? '+' : ''}{formatCurrency(rec.expectedProfitDelta)}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Gross Margin</span>
                  <div className="text-base font-bold text-slate-200 mt-0.5">
                    {(rec.marginAtRecommended * 100).toFixed(1)}%
                  </div>
                </div>
              </div>

              {/* Rationale Narrative */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 text-xs text-slate-300 font-sans leading-relaxed">
                <span className="font-semibold text-emerald-400 font-mono">Mathematical Rationale: </span>
                {rec.rationale}
              </div>

              {/* Reviewer Note if present */}
              {rec.reviewerNotes && (
                <div className="text-xs font-mono text-slate-400 pl-3 border-l-2 border-emerald-500">
                  <span>Note from {rec.reviewedBy} at {rec.reviewedAt}:</span>
                  <p className="text-slate-200 italic mt-0.5 font-sans">"{rec.reviewerNotes}"</p>
                </div>
              )}

              {/* Action Buttons for Approver */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
                <button
                  onClick={() => {
                    setSelectedRecForNote(rec);
                    setNoteText(rec.reviewerNotes || '');
                  }}
                  className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 font-sans"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>{rec.reviewerNotes ? 'Edit Reviewer Comment' : 'Add Note'}</span>
                </button>

                <div className="flex items-center gap-2">
                  {rec.status !== 'APPROVED' && rec.status !== 'PUBLISHED' && (
                    <button
                      onClick={() => handleAction(rec.id, 'APPROVED')}
                      disabled={!isAuthorisedApprover}
                      className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded font-medium transition-colors ${
                        isAuthorisedApprover
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                      title={isAuthorisedApprover ? 'Approve recommendation' : 'Requires Pricing Approver or Admin role'}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Approve</span>
                    </button>
                  )}

                  {rec.status === 'APPROVED' && (
                    <button
                      onClick={() => handleAction(rec.id, 'PUBLISHED')}
                      disabled={!isAuthorisedApprover}
                      className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded font-medium transition-colors ${
                        isAuthorisedApprover
                          ? 'bg-teal-600 hover:bg-teal-500 text-white'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Publish Live</span>
                    </button>
                  )}

                  {rec.status !== 'REJECTED' && (
                    <button
                      onClick={() => handleAction(rec.id, 'REJECTED')}
                      disabled={!isAuthorisedApprover}
                      className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded font-medium transition-colors ${
                        isAuthorisedApprover
                          ? 'bg-slate-800 hover:bg-rose-950/40 text-rose-400 border border-slate-700 hover:border-rose-700'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-800'
                      }`}
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Note Modal */}
      {selectedRecForNote && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-700 rounded-lg p-5 max-w-md w-full space-y-4">
            <h3 className="text-sm font-semibold text-slate-100">Reviewer Note & Comments</h3>
            <p className="text-xs text-slate-400">
              Provide justification or audit commentary for recommendation on {selectedRecForNote.sku}.
            </p>
            <textarea
              rows={3}
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              placeholder="e.g. Approved following review of competitor promotion timeline..."
              className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
            />
            <div className="flex justify-end gap-2 text-xs">
              <button
                onClick={() => setSelectedRecForNote(null)}
                className="px-3 py-1.5 text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveNote}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-medium"
              >
                Save Comment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
