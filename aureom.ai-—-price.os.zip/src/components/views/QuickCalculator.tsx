import React, { useState, useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import { QuickCalculatorInputs } from '../../types/pricing';
import { solveQuickCalculator } from '../../lib/math/pricingCalculations';
import { Calculator, ArrowRight, HelpCircle, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';

export const QuickCalculator: React.FC = () => {
  const { formatCurrency, selectedProduct } = usePricing();

  const [inputs, setInputs] = useState<QuickCalculatorInputs>({
    productName: selectedProduct.name,
    sku: selectedProduct.sku,
    currency: 'GBP',
    unitCost: selectedProduct.unitCost,
    currentPrice: selectedProduct.currentPrice,
    desiredMargin: 0.40, // 40%
    desiredMarkup: 0.50, // 50%
    taxRate: 0.20, // 20%
    taxInclusive: true,
    shippingCost: 3.50,
    packagingCost: 1.20,
    paymentFeePercent: 0.029, // 2.9%
    paymentFeeFixed: 0.30,
    additionalVariableCost: 0.50,
    fixedOverheadCost: 4500,
    expectedVolume: selectedProduct.baselineDemand,
    discountRate: 0.0,
  });

  const outputs = useMemo(() => {
    return solveQuickCalculator(inputs);
  }, [inputs]);

  const updateInput = <K extends keyof QuickCalculatorInputs>(key: K, val: QuickCalculatorInputs[K]) => {
    setInputs(prev => ({ ...prev, [key]: val }));
  };

  // Sync with active selected SKU if clicked
  const handleLoadActiveSku = () => {
    setInputs(prev => ({
      ...prev,
      productName: selectedProduct.name,
      sku: selectedProduct.sku,
      unitCost: selectedProduct.unitCost,
      currentPrice: selectedProduct.currentPrice,
      expectedVolume: selectedProduct.baselineDemand,
    }));
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 tracking-tight">Quick Price Calculator & Financial Engine</h2>
          <p className="text-xs text-slate-400 mt-1">
            Calculate cost-plus, target margin, contribution margin, and break-even pricing with real-time fee and tax deductions.
          </p>
        </div>
        <button
          onClick={handleLoadActiveSku}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs rounded font-medium transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
          <span>Load Active SKU ({selectedProduct.sku})</span>
        </button>
      </div>

      {/* Main Grid: Inputs on Left (2 cols), Live Calculated Results on Right (1 col) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* INPUTS COLUMN */}
        <div className="lg:col-span-2 space-y-5">
          {/* Card 1: Core Price & Margin Targets */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <span>01. Primary Pricing Parameters</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Unit Cost (COGS)</label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-xs">£</span>
                  <input
                    type="number"
                    step="0.10"
                    min="0"
                    value={inputs.unitCost}
                    onChange={(e) => updateInput('unitCost', parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 pl-7 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">Current Selling Price</label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-xs">£</span>
                  <input
                    type="number"
                    step="0.50"
                    min="0"
                    value={inputs.currentPrice}
                    onChange={(e) => updateInput('currentPrice', parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 pl-7 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">Expected Sales Volume (Units)</label>
                <input
                  type="number"
                  step="10"
                  min="1"
                  value={inputs.expectedVolume}
                  onChange={(e) => updateInput('expectedVolume', parseInt(e.target.value) || 1)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs text-slate-400">Desired Target Margin</label>
                  <span className="text-xs font-mono text-emerald-400 font-bold">{(inputs.desiredMargin * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.85"
                  step="0.01"
                  value={inputs.desiredMargin}
                  onChange={(e) => updateInput('desiredMargin', parseFloat(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs text-slate-400">Desired Markup</label>
                  <span className="text-xs font-mono text-teal-400 font-bold">{(inputs.desiredMarkup * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="2.5"
                  step="0.05"
                  value={inputs.desiredMarkup}
                  onChange={(e) => updateInput('desiredMarkup', parseFloat(e.target.value))}
                  className="w-full accent-teal-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">Headline Discount (%)</label>
                <input
                  type="number"
                  step="1"
                  min="0"
                  max="90"
                  value={(inputs.discountRate * 100).toFixed(0)}
                  onChange={(e) => updateInput('discountRate', (parseFloat(e.target.value) || 0) / 100)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Card 2: Fulfillment, Processing Fees & Taxes */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-200">02. Variable Costs & Deductions</h3>
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-400">Tax Pricing:</span>
                <button
                  onClick={() => updateInput('taxInclusive', !inputs.taxInclusive)}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono border transition-colors ${
                    inputs.taxInclusive
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {inputs.taxInclusive ? 'Tax-Inclusive (Gross)' : 'Tax-Exclusive (Net)'}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Shipping per Unit</label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-xs">£</span>
                  <input
                    type="number"
                    step="0.25"
                    min="0"
                    value={inputs.shippingCost}
                    onChange={(e) => updateInput('shippingCost', parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 pl-7 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">Packaging per Unit</label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-xs">£</span>
                  <input
                    type="number"
                    step="0.10"
                    min="0"
                    value={inputs.packagingCost}
                    onChange={(e) => updateInput('packagingCost', parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 pl-7 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">Payment Fee (% + Fixed)</label>
                <div className="flex gap-1.5">
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={(inputs.paymentFeePercent * 100).toFixed(1)}
                    onChange={(e) => updateInput('paymentFeePercent', (parseFloat(e.target.value) || 0) / 100)}
                    className="w-16 bg-slate-950 border border-slate-800 rounded px-2 py-1.5 text-xs font-mono text-slate-100 text-center"
                    placeholder="%"
                  />
                  <input
                    type="number"
                    step="0.05"
                    min="0"
                    value={inputs.paymentFeeFixed}
                    onChange={(e) => updateInput('paymentFeeFixed', parseFloat(e.target.value) || 0)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded px-2 py-1.5 text-xs font-mono text-slate-100"
                    placeholder="£ Fixed"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">VAT / Tax Rate (%)</label>
                <input
                  type="number"
                  step="1"
                  min="0"
                  max="50"
                  value={(inputs.taxRate * 100).toFixed(0)}
                  onChange={(e) => updateInput('taxRate', (parseFloat(e.target.value) || 0) / 100)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="text-xs text-slate-400 block mb-1">Additional Variable Expenses (Labour / Commissions)</label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-xs">£</span>
                  <input
                    type="number"
                    step="0.20"
                    min="0"
                    value={inputs.additionalVariableCost}
                    onChange={(e) => updateInput('additionalVariableCost', parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 pl-7 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="md:col-span-2">
                <label className="text-xs text-slate-400 block mb-1">Allocated Fixed Overhead (Period / Campaign)</label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-xs">£</span>
                  <input
                    type="number"
                    step="250"
                    min="0"
                    value={inputs.fixedOverheadCost}
                    onChange={(e) => updateInput('fixedOverheadCost', parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 pl-7 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Educational Formula Distinction Box */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 text-xs text-slate-400 space-y-2">
            <div className="font-semibold text-slate-200 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-emerald-400" />
              <span>Markup vs. Gross Margin: Fundamental Distinction</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1 font-mono text-[11px]">
              <div className="p-2.5 rounded bg-slate-950/80 border border-slate-800">
                <div className="text-emerald-400 font-bold mb-1">Cost-Plus Markup Formula:</div>
                <div>Price = Cost × (1 + Markup)</div>
                <div className="text-slate-500 mt-1">E.g., £{inputs.unitCost.toFixed(2)} cost @ {(inputs.desiredMarkup * 100).toFixed(0)}% markup = £{outputs.costPlusPrice.toFixed(2)}</div>
              </div>
              <div className="p-2.5 rounded bg-slate-950/80 border border-slate-800">
                <div className="text-teal-400 font-bold mb-1">Target Margin Formula:</div>
                <div>Price = Cost / (1 − Target Margin)</div>
                <div className="text-slate-500 mt-1">E.g., £{inputs.unitCost.toFixed(2)} cost @ {(inputs.desiredMargin * 100).toFixed(0)}% margin = £{outputs.targetMarginPrice.toFixed(2)}</div>
              </div>
            </div>
          </div>
        </div>

        {/* RESULTS COLUMN */}
        <div className="space-y-5">
          {/* Output Card */}
          <div className="bg-slate-900/95 border border-slate-800 rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-semibold text-slate-100">Calculated Pricing Outputs</h3>
              <span className={`text-[11px] font-mono font-semibold px-2 py-0.5 rounded ${
                outputs.isMarginHealthy ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
              }`}>
                {outputs.isMarginHealthy ? 'Healthy Margin' : 'Sub-Target Margin'}
              </span>
            </div>

            {/* Core Calculated Selling Prices */}
            <div className="space-y-3">
              <div className="p-3 rounded-md bg-slate-950 border border-slate-800">
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Target Margin Price</span>
                <div className="text-2xl font-bold font-mono text-emerald-400 mt-0.5">
                  {formatCurrency(outputs.targetMarginPrice)}
                </div>
                <span className="text-[11px] text-slate-500 font-mono mt-1 block">
                  Delivers exact {(inputs.desiredMargin * 100).toFixed(0)}% gross margin on COGS
                </span>
              </div>

              <div className="p-3 rounded-md bg-slate-950 border border-slate-800">
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Cost-Plus Selling Price</span>
                <div className="text-xl font-bold font-mono text-teal-400 mt-0.5">
                  {formatCurrency(outputs.costPlusPrice)}
                </div>
                <span className="text-[11px] text-slate-500 font-mono mt-1 block">
                  Applies {(inputs.desiredMarkup * 100).toFixed(0)}% markup over £{inputs.unitCost.toFixed(2)} cost
                </span>
              </div>
            </div>

            {/* Breakdown Ledger */}
            <div className="pt-2 border-t border-slate-800 space-y-2 text-xs font-mono">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Net Retained Revenue/unit:</span>
                <span className="text-slate-100 font-bold">{formatCurrency(outputs.netSellingRevenue)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Total Variable Cost/unit:</span>
                <span className="text-slate-300">{formatCurrency(outputs.totalVariableCostPerUnit)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Contribution Margin/unit:</span>
                <span className={`font-bold ${outputs.contributionMarginPerUnit > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {formatCurrency(outputs.contributionMarginPerUnit)} ({(outputs.contributionMarginRatio * 100).toFixed(1)}%)
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Gross Margin %:</span>
                <span className="text-slate-100 font-bold">{outputs.grossMarginPercent.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Realized Markup %:</span>
                <span className="text-slate-100 font-bold">{outputs.markupPercent.toFixed(1)}%</span>
              </div>
            </div>

            {/* Break-Even Analysis Box */}
            <div className="p-3.5 rounded bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="font-semibold text-slate-200">Break-Even Equilibrium:</div>
              <div className="flex justify-between font-mono text-[11px]">
                <span className="text-slate-400">Required Unit Volume:</span>
                <span className="text-amber-400 font-bold tabular-nums">
                  {outputs.breakEvenVolume.toLocaleString()} units
                </span>
              </div>
              <div className="flex justify-between font-mono text-[11px]">
                <span className="text-slate-400">Minimum Viable Price:</span>
                <span className="text-amber-400 font-bold tabular-nums">
                  {formatCurrency(outputs.breakEvenPrice)}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-800 flex justify-between font-mono text-xs">
                <span className="text-slate-300 font-medium">Expected Total Profit:</span>
                <span className={`font-bold ${outputs.totalExpectedProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {formatCurrency(outputs.totalExpectedProfit)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
