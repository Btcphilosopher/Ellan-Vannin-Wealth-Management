import React from 'react';
import { usePricing } from '../../context/PricingContext';
import { Download, FileText, CheckCircle2, History, ArrowDown } from 'lucide-react';

export const ReportsExportView: React.FC = () => {
  const { products, formatCurrency, exportCatalogCSV, auditLogs } = usePricing();

  const handlePrint = () => {
    window.print();
  };

  const totalWeeklyRev = products.reduce((sum, p) => sum + (p.currentPrice * p.baselineDemand), 0);
  const totalWeeklyCost = products.reduce((sum, p) => sum + (p.unitCost * p.baselineDemand), 0);
  const totalWeeklyGP = totalWeeklyRev - totalWeeklyCost;
  const overallMargin = totalWeeklyRev > 0 ? (totalWeeklyGP / totalWeeklyRev) * 100 : 0;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 tracking-tight">Executive Financial Reporting & Audit Trail</h2>
          <p className="text-xs text-slate-400 mt-1">
            Downloadable audit reports, catalog data extracts, and immutable price change logs for compliance review.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs rounded font-medium transition-colors"
          >
            <FileText className="w-3.5 h-3.5 text-teal-400" />
            <span>Print Executive Summary</span>
          </button>
          <button
            onClick={exportCatalogCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs rounded font-medium transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Full Catalog CSV</span>
          </button>
        </div>
      </div>

      {/* Printable Executive Snapshot Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">Enterprise Pricing Performance Summary</h3>
            <span className="text-[11px] font-mono text-slate-400">Statement as of 2026-11-07 · 100 Active Catalog Products</span>
          </div>
          <span className="text-xs font-mono text-emerald-400 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
            AUDITED
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase">Annual Revenue Run-Rate</span>
            <div className="text-base font-bold text-slate-100 mt-1">{formatCurrency(totalWeeklyRev * 52)}</div>
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase">Annual Gross Profit</span>
            <div className="text-base font-bold text-emerald-400 mt-1">{formatCurrency(totalWeeklyGP * 52)}</div>
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase">Portfolio Gross Margin</span>
            <div className="text-base font-bold text-slate-100 mt-1">{overallMargin.toFixed(1)}%</div>
          </div>
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase">Average Catalog Price</span>
            <div className="text-base font-bold text-slate-100 mt-1">
              {formatCurrency(products.reduce((s, p) => s + p.currentPrice, 0) / products.length)}
            </div>
          </div>
        </div>
      </div>

      {/* Compliance Audit Trail */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-emerald-400" />
          <h3 className="text-sm font-semibold text-slate-200">Price Governance Audit Log</h3>
        </div>
        <p className="text-xs text-slate-400">
          Immutable ledger of all optimization runs, status transitions, reviewer identities, and published price overrides.
        </p>

        <div className="overflow-x-auto pt-2">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono uppercase text-slate-400">
              <tr>
                <th className="py-2.5 px-3">Timestamp (UTC)</th>
                <th className="py-2.5 px-3">Actor / User</th>
                <th className="py-2.5 px-3">Role</th>
                <th className="py-2.5 px-3">Action</th>
                <th className="py-2.5 px-3">Target SKU</th>
                <th className="py-2.5 px-3">Audit Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {auditLogs.map(log => (
                <tr key={log.id} className="hover:bg-slate-800/40">
                  <td className="py-2 px-3 text-slate-400">{log.timestamp}</td>
                  <td className="py-2 px-3 text-slate-200 font-sans font-medium">{log.user}</td>
                  <td className="py-2 px-3 text-teal-400">{log.role}</td>
                  <td className="py-2 px-3 font-semibold text-emerald-400">{log.action}</td>
                  <td className="py-2 px-3 text-slate-300 font-bold">{log.targetSku}</td>
                  <td className="py-2 px-3 text-slate-400 font-sans">{log.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
