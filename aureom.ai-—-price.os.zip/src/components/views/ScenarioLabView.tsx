import React, { useState, useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import { estimateDemand } from '../../lib/math/elasticity';
import { runMonteCarloSimulation } from '../../lib/math/monteCarlo';
import { Sliders, Play, RefreshCw, BarChart2, ShieldCheck, TrendingUp, AlertTriangle } from 'lucide-react';

export const ScenarioLabView: React.FC = () => {
  const { selectedProduct, formatCurrency, saveScenario } = usePricing();

  // Interactive slider candidate price
  const [candidatePrice, setCandidatePrice] = useState<number>(() => {
    return selectedProduct.recommendedPrice || selectedProduct.currentPrice;
  });

  // Monte Carlo parameters
  const [elasticityNoise, setElasticityNoise] = useState<number>(0.15);
  const [demandNoise, setDemandNoise] = useState<number>(0.10);
  const [costNoise, setCostNoise] = useState<number>(0.05);
  const [simSeed, setSimSeed] = useState<number>(42);

  // Sync when product changes
  React.useEffect(() => {
    setCandidatePrice(selectedProduct.recommendedPrice || selectedProduct.currentPrice);
  }, [selectedProduct]);

  const p0 = selectedProduct.currentPrice;
  const q0 = selectedProduct.baselineDemand;
  const c = selectedProduct.unitCost;
  const e = selectedProduct.elasticity;

  // Immediate live recalculations for candidate price
  const candidateEval = useMemo(() => {
    const demand = estimateDemand(candidatePrice, p0, q0, e);
    const revenue = candidatePrice * demand;
    const profit = (candidatePrice - c) * demand;
    const margin = candidatePrice > 0 ? (candidatePrice - c) / candidatePrice : 0;

    const baseDemand = q0;
    const baseRevenue = p0 * q0;
    const baseProfit = (p0 - c) * q0;
    const baseMargin = p0 > 0 ? (p0 - c) / p0 : 0;

    const deltaPricePct = ((candidatePrice - p0) / p0) * 100;
    const deltaDemandPct = ((demand - baseDemand) / baseDemand) * 100;
    const deltaRevPct = ((revenue - baseRevenue) / baseRevenue) * 100;
    const deltaProfPct = ((profit - baseProfit) / baseProfit) * 100;

    return {
      demand,
      revenue,
      profit,
      margin,
      baseProfit,
      baseRevenue,
      baseDemand,
      baseMargin,
      deltaPricePct,
      deltaDemandPct,
      deltaRevPct,
      deltaProfPct,
    };
  }, [candidatePrice, p0, q0, c, e]);

  // Comparative scenarios table
  const scenarioComparisons = useMemo(() => {
    const conservativePrice = Number((p0 * 0.95).toFixed(2));
    const aggressivePrice = Number((p0 * 1.15).toFixed(2));
    const optimalPrice = selectedProduct.recommendedPrice || p0;

    const evalRow = (name: string, price: number) => {
      const d = estimateDemand(price, p0, q0, e);
      const rev = price * d;
      const prof = (price - c) * d;
      const m = (price - c) / price;
      return {
        name,
        price,
        demand: Math.round(d),
        revenue: rev,
        profit: prof,
        margin: m * 100,
        risk: m < selectedProduct.minMarginThreshold ? 'High (Sub-Margin)' : prof > candidateEval.baseProfit ? 'Low' : 'Moderate',
      };
    };

    return [
      evalRow('Baseline (Current)', p0),
      evalRow('Conservative (-5%)', conservativePrice),
      evalRow('Model Recommended', optimalPrice),
      evalRow('Aggressive (+15%)', aggressivePrice),
      evalRow('Interactive Slider', candidatePrice),
    ];
  }, [p0, q0, c, e, selectedProduct, candidatePrice, candidateEval.baseProfit]);

  // Monte Carlo simulation runner
  const mcResult = useMemo(() => {
    return runMonteCarloSimulation(
      {
        baselinePrice: p0,
        candidatePrice: candidatePrice,
        cost: c,
        elasticityMean: e,
        elasticityStdDev: Math.abs(e * elasticityNoise),
        baselineDemandMean: q0,
        baselineDemandStdDev: q0 * demandNoise,
        costVariancePercent: costNoise,
        iterations: 1000,
      },
      simSeed
    );
  }, [p0, candidatePrice, c, e, q0, elasticityNoise, demandNoise, costNoise, simSeed]);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 font-semibold">PRICING LAB</span>
            <span className="text-slate-600">·</span>
            <h2 className="text-xl font-bold text-slate-100 tracking-tight">Scenario Simulator & Monte Carlo Engine</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Simulate real-time price elastic response, compare risk bounds, and execute 1,000-run stochastic uncertainty modelling.
          </p>
        </div>

        <button
          onClick={() => saveScenario(`Lab: ${selectedProduct.sku} @ £${candidatePrice}`, selectedProduct.id, candidatePrice, candidateEval.profit)}
          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs rounded font-medium transition-colors"
        >
          Save Current Scenario
        </button>
      </div>

      {/* Interactive Price Slider Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono text-slate-300 uppercase tracking-wider font-semibold">
            Interactive Selling Price Controller
          </span>
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-400">Baseline: <strong className="text-slate-200 font-mono">{formatCurrency(p0)}</strong></span>
            <span className="text-slate-600">|</span>
            <span className="text-xs text-slate-400">Candidate: <strong className="text-emerald-400 font-mono text-sm">{formatCurrency(candidatePrice)}</strong></span>
            <span className={`text-xs font-mono font-bold ${candidateEval.deltaPricePct >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
              ({candidateEval.deltaPricePct >= 0 ? '+' : ''}{candidateEval.deltaPricePct.toFixed(1)}%)
            </span>
          </div>
        </div>

        <div className="space-y-2">
          <input
            type="range"
            min={Math.max(c * 1.05, selectedProduct.minPriceFloor * 0.8)}
            max={selectedProduct.maxPriceCeiling * 1.2}
            step={0.50}
            value={candidatePrice}
            onChange={(e) => setCandidatePrice(parseFloat(e.target.value))}
            className="w-full accent-emerald-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[11px] font-mono text-slate-500">
            <span>Floor: £{Math.max(c * 1.05, selectedProduct.minPriceFloor * 0.8).toFixed(2)}</span>
            <span>Current: £{p0.toFixed(2)}</span>
            <span>Ceiling: £{(selectedProduct.maxPriceCeiling * 1.2).toFixed(2)}</span>
          </div>
        </div>

        {/* Live Delta Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2 border-t border-slate-800">
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-[11px] font-mono text-slate-400 uppercase">Weekly Demand</span>
            <div className="text-lg font-bold font-mono text-slate-100 mt-0.5">
              {Math.round(candidateEval.demand).toLocaleString()} <span className="text-xs text-slate-500 font-normal">units</span>
            </div>
            <span className={`text-[11px] font-mono ${candidateEval.deltaDemandPct >= 0 ? 'text-emerald-400' : 'text-slate-400'}`}>
              {candidateEval.deltaDemandPct >= 0 ? '+' : ''}{candidateEval.deltaDemandPct.toFixed(1)}% vs baseline
            </span>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-[11px] font-mono text-slate-400 uppercase">Weekly Revenue</span>
            <div className="text-lg font-bold font-mono text-slate-100 mt-0.5">
              {formatCurrency(candidateEval.revenue)}
            </div>
            <span className={`text-[11px] font-mono ${candidateEval.deltaRevPct >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
              {candidateEval.deltaRevPct >= 0 ? '+' : ''}{candidateEval.deltaRevPct.toFixed(1)}% vs baseline
            </span>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-[11px] font-mono text-slate-400 uppercase">Weekly Contribution Profit</span>
            <div className="text-lg font-bold font-mono text-emerald-400 mt-0.5">
              {formatCurrency(candidateEval.profit)}
            </div>
            <span className={`text-[11px] font-mono font-semibold ${candidateEval.deltaProfPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {candidateEval.deltaProfPct >= 0 ? '+' : ''}{candidateEval.deltaProfPct.toFixed(1)}% vs baseline
            </span>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-[11px] font-mono text-slate-400 uppercase">Gross Margin</span>
            <div className="text-lg font-bold font-mono text-slate-100 mt-0.5">
              {(candidateEval.margin * 100).toFixed(1)}%
            </div>
            <span className={`text-[11px] font-mono ${candidateEval.margin >= selectedProduct.minMarginThreshold ? 'text-emerald-400' : 'text-rose-400'}`}>
              Target: {(selectedProduct.minMarginThreshold * 100).toFixed(0)}% floor
            </span>
          </div>
        </div>
      </div>

      {/* Scenario Comparison Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3">
        <h3 className="text-sm font-semibold text-slate-200">Scenario Sensitivity Matrix</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono uppercase text-slate-400">
              <tr>
                <th className="py-2.5 px-3">Scenario</th>
                <th className="py-2.5 px-3 text-right">Price</th>
                <th className="py-2.5 px-3 text-right">Demand/wk</th>
                <th className="py-2.5 px-3 text-right">Weekly Revenue</th>
                <th className="py-2.5 px-3 text-right">Weekly Profit</th>
                <th className="py-2.5 px-3 text-right">Margin %</th>
                <th className="py-2.5 px-3 text-right">Risk Assessment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono tabular-nums">
              {scenarioComparisons.map(s => {
                const isSelected = s.name.includes('Slider');
                return (
                  <tr key={s.name} className={isSelected ? 'bg-emerald-500/10 font-bold' : 'hover:bg-slate-800/40'}>
                    <td className="py-2.5 px-3 font-sans font-medium text-slate-200">{s.name}</td>
                    <td className="py-2.5 px-3 text-right text-slate-100">{formatCurrency(s.price)}</td>
                    <td className="py-2.5 px-3 text-right text-slate-300">{s.demand.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right text-slate-300">{formatCurrency(s.revenue)}</td>
                    <td className="py-2.5 px-3 text-right text-emerald-400 font-semibold">{formatCurrency(s.profit)}</td>
                    <td className="py-2.5 px-3 text-right text-slate-300">{s.margin.toFixed(1)}%</td>
                    <td className="py-2.5 px-3 text-right">
                      <span className={`text-[11px] px-2 py-0.5 rounded font-sans ${
                        s.risk.includes('Low') ? 'bg-emerald-500/10 text-emerald-400' :
                        s.risk.includes('Moderate') ? 'bg-slate-800 text-slate-300' : 'bg-rose-500/10 text-rose-400'
                      }`}>
                        {s.risk}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Monte Carlo 1,000-Iteration Stochastic Engine */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-emerald-400" />
              <span>Monte Carlo Uncertainty Simulation (1,000 Iterations)</span>
            </h3>
            <p className="text-xs text-slate-400">
              Perturbs elasticity N(ε, σ²), demand volume, and direct cost simultaneously to calculate profit distribution.
            </p>
          </div>

          <button
            onClick={() => setSimSeed(prev => prev + 1)}
            className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs rounded transition-colors self-start md:self-auto"
          >
            <RefreshCw className="w-3.5 h-3.5 text-teal-400" />
            <span>Re-seed Simulation</span>
          </button>
        </div>

        {/* Confidence Metrics Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-[11px] font-mono text-slate-400 uppercase">Win Probability</span>
            <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
              {mcResult.winProbability}%
            </div>
            <span className="text-[11px] text-slate-500 font-mono">Pr(Profit &gt; Baseline)</span>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-[11px] font-mono text-slate-400 uppercase">Downside Risk</span>
            <div className="text-xl font-bold font-mono text-amber-400 mt-1">
              {mcResult.downsideRiskProbability}%
            </div>
            <span className="text-[11px] text-slate-500 font-mono">Pr(Profit &lt; 95% Base)</span>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-[11px] font-mono text-slate-400 uppercase">P50 (Median Profit)</span>
            <div className="text-xl font-bold font-mono text-slate-100 mt-1">
              {formatCurrency(mcResult.profitPercentiles.p50)}
            </div>
            <span className="text-[11px] text-slate-500 font-mono">Expected central outcome</span>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800">
            <span className="text-[11px] font-mono text-slate-400 uppercase">80% Confidence Band</span>
            <div className="text-xs font-bold font-mono text-slate-200 mt-2">
              {formatCurrency(mcResult.profitPercentiles.p10)} — {formatCurrency(mcResult.profitPercentiles.p90)}
            </div>
            <span className="text-[11px] text-slate-500 font-mono">P10 to P90 Range</span>
          </div>
        </div>

        {/* Histogram Distribution Chart */}
        <div className="space-y-1.5 pt-2">
          <div className="flex justify-between text-xs text-slate-400 font-mono">
            <span>Simulated Profit Distribution (Weekly Contribution)</span>
            <span>N = 1,000 Iterations</span>
          </div>
          <div className="h-28 flex items-end gap-1 bg-slate-950 p-2.5 rounded border border-slate-800">
            {mcResult.distribution.map((bin) => {
              const maxCount = Math.max(...mcResult.distribution.map(d => d.count));
              const heightPct = Math.max(4, (bin.count / maxCount) * 100);
              const isProfitPositive = bin.profit >= candidateEval.baseProfit;

              return (
                <div
                  key={bin.bin}
                  className="flex-1 flex flex-col items-center justify-end h-full group relative"
                >
                  <div
                    style={{ height: `${heightPct}%` }}
                    className={`w-full rounded-t transition-all ${
                      isProfitPositive ? 'bg-emerald-500/70 hover:bg-emerald-400' : 'bg-slate-700 hover:bg-slate-600'
                    }`}
                  />
                  {/* Tooltip */}
                  <div className="absolute bottom-full mb-1 hidden group-hover:block bg-slate-900 border border-slate-700 p-1.5 rounded text-[10px] font-mono text-slate-200 whitespace-nowrap z-20 shadow-lg">
                    £{bin.profit.toFixed(0)} ({bin.count} runs)
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
