import React, { useState, useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import { OptimisationObjective, OptimisationParams } from '../../types/pricing';
import { optimiseProductPrice } from '../../lib/math/optimisation';
import { Target, TrendingUp, Sliders, Check, AlertCircle, RefreshCw, BookmarkPlus } from 'lucide-react';

export const OptimisationEngineView: React.FC = () => {
  const { selectedProduct, formatCurrency, saveScenario, updateProduct } = usePricing();

  const [params, setParams] = useState<OptimisationParams>({
    productId: selectedProduct.id,
    baselinePrice: selectedProduct.currentPrice,
    baselineDemand: selectedProduct.baselineDemand,
    unitCost: selectedProduct.unitCost,
    elasticity: selectedProduct.elasticity,
    minPrice: selectedProduct.minPriceFloor,
    maxPrice: selectedProduct.maxPriceCeiling,
    minMargin: selectedProduct.minMarginThreshold,
    objective: 'maximise_profit',
    competitorMedian: selectedProduct.competitors[0]?.price,
  });

  const [scenarioSavedMsg, setScenarioSavedMsg] = useState(false);

  // Sync when user selects a different SKU from header
  React.useEffect(() => {
    setParams({
      productId: selectedProduct.id,
      baselinePrice: selectedProduct.currentPrice,
      baselineDemand: selectedProduct.baselineDemand,
      unitCost: selectedProduct.unitCost,
      elasticity: selectedProduct.elasticity,
      minPrice: selectedProduct.minPriceFloor,
      maxPrice: selectedProduct.maxPriceCeiling,
      minMargin: selectedProduct.minMarginThreshold,
      objective: 'maximise_profit',
      competitorMedian: selectedProduct.competitors[0]?.price,
    });
  }, [selectedProduct]);

  // Live optimization result
  const result = useMemo(() => {
    return optimiseProductPrice(params);
  }, [params]);

  const handleApplyToCatalog = () => {
    updateProduct(selectedProduct.id, {
      recommendedPrice: result.optimalPrice,
      status: 'CALCULATED',
    });
    setScenarioSavedMsg(true);
    setTimeout(() => setScenarioSavedMsg(false), 3000);
  };

  const handleSaveScenario = () => {
    saveScenario(
      `Optimization: ${selectedProduct.sku} (${params.objective})`,
      selectedProduct.id,
      result.optimalPrice,
      result.expectedProfit
    );
    setScenarioSavedMsg(true);
    setTimeout(() => setScenarioSavedMsg(false), 3000);
  };

  // SVG Chart Dimensions
  const chartWidth = 720;
  const chartHeight = 280;
  const padding = { top: 25, right: 30, bottom: 40, left: 60 };

  const curve = result.curveData;
  const minP = curve[0]?.price || 10;
  const maxP = curve[curve.length - 1]?.price || 100;
  const maxProf = Math.max(...curve.map(c => Math.max(0, c.profit)), result.expectedProfit * 1.15, 100);

  const getX = (price: number) => {
    return padding.left + ((price - minP) / (maxP - minP)) * (chartWidth - padding.left - padding.right);
  };

  const getY = (val: number) => {
    return chartHeight - padding.bottom - (Math.max(0, val) / maxProf) * (chartHeight - padding.top - padding.bottom);
  };

  // Build SVG Path for profit curve
  const profitPath = curve.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${getX(pt.price)} ${getY(pt.profit)}`).join(' ');
  const revPath = curve.map((pt, i) => {
    // scale revenue so it fits nicely
    const maxRev = Math.max(...curve.map(c => c.revenue));
    const normalizedY = chartHeight - padding.bottom - (pt.revenue / maxRev) * (chartHeight - padding.top - padding.bottom);
    return `${i === 0 ? 'M' : 'L'} ${getX(pt.price)} ${normalizedY}`;
  }).join(' ');

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 font-semibold">{selectedProduct.sku}</span>
            <span className="text-slate-600">·</span>
            <h2 className="text-xl font-bold text-slate-100 tracking-tight">{selectedProduct.name}</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Brent & Golden-Section bounded solver evaluates continuous profit & revenue surfaces subject to margin floors.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSaveScenario}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs rounded font-medium transition-colors"
          >
            <BookmarkPlus className="w-3.5 h-3.5 text-teal-400" />
            <span>Save Scenario</span>
          </button>
          <button
            onClick={handleApplyToCatalog}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs rounded font-medium transition-colors"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Queue as Recommendation</span>
          </button>
        </div>
      </div>

      {scenarioSavedMsg && (
        <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded text-xs text-emerald-400 font-mono">
          ✓ Optimisation result recorded successfully in session state.
        </div>
      )}

      {/* Grid: Left Controls (1 col), Right Interactive Charts & Diagnostics (2 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SOLVER PARAMETERS */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-200 flex items-center justify-between">
            <span>Solver Parameters</span>
            <span className="text-[11px] font-mono text-slate-500">Numerical Model</span>
          </h3>

          <div className="space-y-3.5">
            <div>
              <label className="text-xs text-slate-400 block mb-1">Optimisation Objective</label>
              <select
                value={params.objective}
                onChange={(e) => setParams(prev => ({ ...prev, objective: e.target.value as OptimisationObjective }))}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded px-2.5 py-1.5 focus:outline-none focus:border-emerald-500 font-sans"
              >
                <option value="maximise_profit">Maximise Contribution Profit</option>
                <option value="maximise_revenue">Maximise Gross Revenue</option>
                <option value="maximise_volume">Maximise Units Sold</option>
                <option value="balance_profit_volume">Balance Profit & Market Share (70/30)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Baseline Price</label>
                <input
                  type="number"
                  step="0.5"
                  value={params.baselinePrice}
                  onChange={(e) => setParams(prev => ({ ...prev, baselinePrice: parseFloat(e.target.value) || 1 }))}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">Direct Unit Cost</label>
                <input
                  type="number"
                  step="0.25"
                  value={params.unitCost}
                  onChange={(e) => setParams(prev => ({ ...prev, unitCost: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-slate-400 block mb-1">Baseline Demand/wk</label>
                <input
                  type="number"
                  step="10"
                  value={params.baselineDemand}
                  onChange={(e) => setParams(prev => ({ ...prev, baselineDemand: parseInt(e.target.value) || 1 }))}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1">Elasticity (ε)</label>
                <input
                  type="number"
                  step="0.05"
                  value={params.elasticity}
                  onChange={(e) => setParams(prev => ({ ...prev, elasticity: parseFloat(e.target.value) || -1 }))}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                />
              </div>
            </div>

            {/* Constraints */}
            <div className="pt-2 border-t border-slate-800 space-y-3">
              <span className="text-[11px] font-mono uppercase text-slate-400 tracking-wider block">Boundary Constraints</span>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Min Price Floor</label>
                  <input
                    type="number"
                    step="0.5"
                    value={params.minPrice}
                    onChange={(e) => setParams(prev => ({ ...prev, minPrice: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">Max Price Ceiling</label>
                  <input
                    type="number"
                    step="0.5"
                    value={params.maxPrice}
                    onChange={(e) => setParams(prev => ({ ...prev, maxPrice: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs text-slate-400">Min Gross Margin Floor</label>
                  <span className="text-xs font-mono text-emerald-400 font-bold">{(params.minMargin * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.10"
                  max="0.80"
                  step="0.05"
                  value={params.minMargin}
                  onChange={(e) => setParams(prev => ({ ...prev, minMargin: parseFloat(e.target.value) }))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* RESULTS & INTERACTIVE VISUALISATION */}
        <div className="lg:col-span-2 space-y-5">
          {/* Comparison KPI Row */}
          <div className="grid grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Optimal Price</span>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
                {formatCurrency(result.optimalPrice)}
              </div>
              <div className="flex items-center gap-1 text-[11px] font-mono text-slate-400 mt-1">
                <span>Baseline: {formatCurrency(result.currentPrice)}</span>
                <span className={`font-semibold ${result.optimalPrice >= result.currentPrice ? 'text-emerald-400' : 'text-amber-400'}`}>
                  ({result.optimalPrice >= result.currentPrice ? '+' : ''}
                  {(((result.optimalPrice - result.currentPrice) / result.currentPrice) * 100).toFixed(1)}%)
                </span>
              </div>
            </div>

            <div className="p-4 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Weekly Contribution Profit</span>
              <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
                {formatCurrency(result.expectedProfit)}
              </div>
              <div className="text-[11px] font-mono text-emerald-400 mt-1">
                {result.profitDeltaPercent >= 0 ? '+' : ''}{result.profitDeltaPercent}% vs Current
              </div>
            </div>

            <div className="p-4 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">Expected Velocity</span>
              <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
                {result.expectedDemand.toLocaleString()} <span className="text-xs text-slate-500 font-sans">units/wk</span>
              </div>
              <div className="text-[11px] font-mono text-slate-400 mt-1">
                Margin: {(result.expectedMargin * 100).toFixed(1)}%
              </div>
            </div>
          </div>

          {/* Interactive Chart Container */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-4 text-xs font-mono">
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <span className="w-2.5 h-0.5 bg-emerald-400 inline-block"></span> Expected Profit
                </span>
                <span className="flex items-center gap-1.5 text-teal-300">
                  <span className="w-2.5 h-0.5 bg-teal-300 inline-block"></span> Expected Revenue (Scaled)
                </span>
                <span className="flex items-center gap-1.5 text-amber-400">
                  <span className="w-2 h-2 rounded-full bg-amber-400 inline-block"></span> Optimal Price
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-500">Domain: £{minP.toFixed(0)} — £{maxP.toFixed(0)}</span>
            </div>

            {/* SVG Plot */}
            <div className="w-full overflow-x-auto">
              <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-64 select-none">
                {/* Feasible Region Shading */}
                <rect
                  x={getX(params.minPrice)}
                  y={padding.top}
                  width={Math.max(0, getX(params.maxPrice) - getX(params.minPrice))}
                  height={chartHeight - padding.top - padding.bottom}
                  fill="rgba(16, 185, 129, 0.05)"
                  stroke="rgba(16, 185, 129, 0.2)"
                  strokeDasharray="4 4"
                />

                {/* Grid Lines */}
                <line
                  x1={padding.left}
                  y1={chartHeight - padding.bottom}
                  x2={chartWidth - padding.right}
                  y2={chartHeight - padding.bottom}
                  stroke="#334155"
                  strokeWidth="1"
                />
                <line
                  x1={padding.left}
                  y1={padding.top}
                  x2={padding.left}
                  y2={chartHeight - padding.bottom}
                  stroke="#334155"
                  strokeWidth="1"
                />

                {/* Curves */}
                <path d={revPath} fill="none" stroke="#2dd4bf" strokeWidth="1.5" strokeOpacity="0.7" />
                <path d={profitPath} fill="none" stroke="#10b981" strokeWidth="2.5" />

                {/* Current Price Marker */}
                <line
                  x1={getX(result.currentPrice)}
                  y1={padding.top}
                  x2={getX(result.currentPrice)}
                  y2={chartHeight - padding.bottom}
                  stroke="#94a3b8"
                  strokeWidth="1"
                  strokeDasharray="3 3"
                />
                <text
                  x={getX(result.currentPrice)}
                  y={chartHeight - padding.bottom + 16}
                  fill="#94a3b8"
                  fontSize="10"
                  textAnchor="middle"
                  fontFamily="monospace"
                >
                  Current £{result.currentPrice.toFixed(0)}
                </text>

                {/* Optimal Price Marker */}
                <line
                  x1={getX(result.optimalPrice)}
                  y1={padding.top}
                  x2={getX(result.optimalPrice)}
                  y2={chartHeight - padding.bottom}
                  stroke="#f59e0b"
                  strokeWidth="1.5"
                />
                <circle
                  cx={getX(result.optimalPrice)}
                  cy={getY(result.expectedProfit)}
                  r="5"
                  fill="#f59e0b"
                  stroke="#0f172a"
                  strokeWidth="2"
                />
                <text
                  x={getX(result.optimalPrice)}
                  y={chartHeight - padding.bottom + 16}
                  fill="#f59e0b"
                  fontSize="10"
                  fontWeight="bold"
                  textAnchor="middle"
                  fontFamily="monospace"
                >
                  Opt £{result.optimalPrice.toFixed(0)}
                </text>
              </svg>
            </div>

            {/* Diagnostic Rationale */}
            <div className="mt-3 p-3 rounded bg-slate-950 border border-slate-800 text-xs text-slate-300 font-sans leading-relaxed">
              <span className="font-semibold text-emerald-400">Econometric Analysis: </span>
              {result.explanation}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
