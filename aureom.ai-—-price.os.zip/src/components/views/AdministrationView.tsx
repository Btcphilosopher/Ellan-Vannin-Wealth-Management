import React from 'react';
import { usePricing } from '../../context/PricingContext';
import { UserRole } from '../../types/pricing';
import { ShieldCheck, Lock, Users, Check } from 'lucide-react';

export const AdministrationView: React.FC = () => {
  const { userRole, setUserRole } = usePricing();

  const roles: { role: UserRole; desc: string; canApprove: boolean; canPublish: boolean; canEditParams: boolean }[] = [
    { role: 'Viewer', desc: 'Read-only access to dashboards, charts, and forecasts.', canApprove: false, canPublish: false, canEditParams: false },
    { role: 'Pricing Analyst', desc: 'Can run simulations, calibrate elasticities, and draft proposals.', canApprove: false, canPublish: false, canEditParams: true },
    { role: 'Revenue Manager', desc: 'Can configure pricing policies, run optimizers, and submit recommendations.', canApprove: false, canPublish: false, canEditParams: true },
    { role: 'Finance Manager', desc: 'Can audit margins, review break-evens, and inspect compliance ledgers.', canApprove: false, canPublish: false, canEditParams: true },
    { role: 'Pricing Approver', desc: 'Authorised to approve price recommendations and schedule deployments.', canApprove: true, canPublish: true, canEditParams: true },
    { role: 'Administrator', desc: 'Full enterprise privileges including role administration and database keys.', canApprove: true, canPublish: true, canEditParams: true },
  ];

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 tracking-tight">Enterprise Administration & Role-Based Access (RBAC)</h2>
          <p className="text-xs text-slate-400 mt-1">
            Separation of duties governance: Prevents unauthorized price changes and enforces dual-custody approval thresholds.
          </p>
        </div>
      </div>

      {/* Role Switcher & Permissions Matrix */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="text-sm font-semibold text-slate-200">Session Role Permissions Matrix</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono uppercase text-slate-400">
              <tr>
                <th className="py-2.5 px-3">Role Designation</th>
                <th className="py-2.5 px-3">Scope & Governance Rationale</th>
                <th className="py-2.5 px-3 text-center">Edit Models</th>
                <th className="py-2.5 px-3 text-center">Approve Changes</th>
                <th className="py-2.5 px-3 text-center">Publish Live</th>
                <th className="py-2.5 px-3 text-right">Switch Current Session</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {roles.map(r => {
                const isCurrent = userRole === r.role;
                return (
                  <tr key={r.role} className={isCurrent ? 'bg-emerald-500/10 font-medium' : 'hover:bg-slate-800/40'}>
                    <td className="py-3 px-3 font-semibold text-slate-100 flex items-center gap-2">
                      <ShieldCheck className={`w-3.5 h-3.5 ${isCurrent ? 'text-emerald-400' : 'text-slate-500'}`} />
                      <span>{r.role}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-400 max-w-md">{r.desc}</td>
                    <td className="py-3 px-3 text-center font-mono">
                      {r.canEditParams ? <span className="text-emerald-400">✓</span> : <span className="text-slate-600">—</span>}
                    </td>
                    <td className="py-3 px-3 text-center font-mono">
                      {r.canApprove ? <span className="text-emerald-400">✓</span> : <span className="text-slate-600">—</span>}
                    </td>
                    <td className="py-3 px-3 text-center font-mono">
                      {r.canPublish ? <span className="text-emerald-400">✓</span> : <span className="text-slate-600">—</span>}
                    </td>
                    <td className="py-3 px-3 text-right">
                      {isCurrent ? (
                        <span className="text-[11px] font-mono font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/15">
                          ACTIVE
                        </span>
                      ) : (
                        <button
                          onClick={() => setUserRole(r.role)}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] rounded transition-colors font-mono"
                        >
                          Switch
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Security Policies */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3 text-xs">
          <h4 className="font-semibold text-slate-200">Price Change Guardrail Policies</h4>
          <ul className="space-y-2 text-slate-400 font-sans list-disc list-inside">
            <li>Material price changes (&gt; 15% delta) require dual approval from Revenue Manager and Finance Manager.</li>
            <li>No candidate price may breach the strict minimum gross margin floor under any circumstance.</li>
            <li>All price publications generate an immutable cryptographically timestamped audit log record.</li>
          </ul>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3 text-xs">
          <h4 className="font-semibold text-slate-200">Database Connection Security</h4>
          <p className="text-slate-400 font-sans leading-relaxed">
            Enterprise PostgreSQL pool instance initialized with TLS 1.3 encryption and row-level tenant security (RLS). Demonstrations operate seamlessly in local SQLite in-memory mode without external dependencies.
          </p>
          <div className="font-mono text-[11px] text-emerald-400">
            CONNECTION: LOCAL_ISOLATED_MODE (DEMO RESTRICTED)
          </div>
        </div>
      </div>
    </div>
  );
};
