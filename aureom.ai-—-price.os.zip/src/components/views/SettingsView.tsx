import React from 'react';
import { usePricing } from '../../context/PricingContext';
import { Settings, DollarSign, Percent, Check } from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    currency,
    setCurrency,
    taxRate,
    setTaxRate,
    taxInclusive,
    setTaxInclusive,
  } = usePricing();

  const rates = [
    { code: 'GBP', symbol: '£', rate: '1.000 (Base)', name: 'British Pound Sterling' },
    { code: 'USD', symbol: '$', rate: '1.280', name: 'US Dollar' },
    { code: 'EUR', symbol: '€', rate: '1.160', name: 'Euro' },
    { code: 'CAD', symbol: 'CA$', rate: '1.740', name: 'Canadian Dollar' },
    { code: 'AUD', symbol: 'A$', rate: '1.950', name: 'Australian Dollar' },
  ];

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 tracking-tight">System & Pricing Configuration</h2>
          <p className="text-xs text-slate-400 mt-1">
            Global multi-currency exchange rates, tax inclusion rules, and psychological price ending heuristics.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Multi-Currency Matrix */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-200">Supported Currencies & Conversion Rates</h3>
            <span className="text-[11px] font-mono text-emerald-400">Base: GBP (£)</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono uppercase text-slate-400">
                <tr>
                  <th className="py-2 px-3">Currency</th>
                  <th className="py-2 px-3">Symbol</th>
                  <th className="py-2 px-3 text-right">FX Rate to GBP</th>
                  <th className="py-2 px-3 text-right">Select Active</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {rates.map(r => (
                  <tr key={r.code} className={currency === r.code ? 'bg-emerald-500/10 font-bold' : 'hover:bg-slate-800/40'}>
                    <td className="py-2.5 px-3 text-slate-200 font-sans">{r.name} ({r.code})</td>
                    <td className="py-2.5 px-3 text-slate-300">{r.symbol}</td>
                    <td className="py-2.5 px-3 text-right text-slate-300">{r.rate}</td>
                    <td className="py-2.5 px-3 text-right">
                      {currency === r.code ? (
                        <span className="text-[11px] font-mono text-emerald-400 font-bold">ACTIVE</span>
                      ) : (
                        <button
                          onClick={() => setCurrency(r.code as any)}
                          className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] rounded transition-colors font-sans"
                        >
                          Select
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Tax & Psychological Price Endings */}
        <div className="space-y-6">
          {/* Tax Settings */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-200">Tax & Fiscal Policy</h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Standard VAT / Sales Tax Rate (%)</label>
                <input
                  type="number"
                  step="1"
                  min="0"
                  max="40"
                  value={(taxRate * 100).toFixed(0)}
                  onChange={(e) => setTaxRate((parseFloat(e.target.value) || 0) / 100)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs font-mono text-slate-100"
                />
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={taxInclusive}
                    onChange={(e) => setTaxInclusive(e.target.checked)}
                    className="accent-emerald-500"
                  />
                  <span className="text-slate-200">
                    <strong>Tax-Inclusive Headline Pricing (UK / EU VAT model)</strong>
                  </span>
                </label>
                <p className="text-[11px] text-slate-500 mt-1 ml-5">
                  When enabled, tax is backed out of the selling price: Net Price = Gross / (1 + Tax Rate).
                </p>
              </div>
            </div>
          </div>

          {/* Psychological Price Endings */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-3 text-xs">
            <h3 className="text-sm font-semibold text-slate-200">Charm & Psychological Price Endings</h3>
            <p className="text-slate-400">
              Configure automated rounding rules for consumer retail price points (.99, .95, .00).
            </p>
            <div className="grid grid-cols-3 gap-3 font-mono">
              <div className="p-2.5 bg-slate-950 rounded border border-emerald-500/40 text-center">
                <span className="text-emerald-400 font-bold block text-sm">.99</span>
                <span className="text-[10px] text-slate-500">Retail Consumer</span>
              </div>
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800 text-center">
                <span className="text-slate-200 font-bold block text-sm">.95</span>
                <span className="text-[10px] text-slate-500">Specialty Food</span>
              </div>
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800 text-center">
                <span className="text-slate-200 font-bold block text-sm">.00</span>
                <span className="text-[10px] text-slate-500">SaaS / Enterprise</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
