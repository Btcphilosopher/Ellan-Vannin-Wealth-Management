import React, { useState, useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import { Users, TrendingUp, ShieldAlert, Check, ArrowRight } from 'lucide-react';

export const CompetitorAnalysisView: React.FC = () => {
  const { selectedProduct, formatCurrency, updateProduct } = usePricing();

  const competitors = selectedProduct.competitors;
  const currentPrice = selectedProduct.currentPrice;
  const unitCost = selectedProduct.unitCost;

  const stats = useMemo(() => {
    if (competitors.length === 0) {
      return { min: currentPrice, max: currentPrice, median: currentPrice, avg: currentPrice };
    }
    const prices = competitors.map(c => c.price).sort((a, b) => a - b);
    const min = prices[0];
    const max = prices[prices.length - 1];
    const avg = prices.reduce((a, b) => a + b, 0) / prices.length;
    const median = prices[Math.floor(prices.length / 2)];
    return { min, max, median, avg };
  }, [competitors, currentPrice]);

  // Price Index = (Own Price / Competitor Median) * 100
  const priceIndex = stats.median > 0 ? (currentPrice / stats.median) * 100 : 100;

  // Competitive strategy simulated prices
  const [selectedStrategy, setSelectedStrategy] = useState<string>('match_median');

  const strategyPrices = useMemo(() => {
    const marginFloor = unitCost / (1 - selectedProduct.minMarginThreshold);

    return {
      match_median: Math.max(marginFloor, stats.median),
      undercut_5: Math.max(marginFloor, Number((stats.min * 0.95).toFixed(2))),
      premium_10: Math.max(marginFloor, Number((stats.median * 1.10).toFixed(2))),
      cost_protected: Math.max(marginFloor, Number((unitCost * 1.45).toFixed(2))),
    };
  }, [stats, unitCost, selectedProduct.minMarginThreshold]);

  const recommendedFromStrategy = strategyPrices[selectedStrategy as keyof typeof strategyPrices] || currentPrice;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 font-semibold">{selectedProduct.sku}</span>
            <span className="text-slate-600">·</span>
            <h2 className="text-xl font-bold text-slate-100 tracking-tight">{selectedProduct.name}</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Competitive pricing intelligence, price index monitoring, and strategy rules with strict margin floor guardrails.
          </p>
        </div>

        <button
          onClick={() => {
            updateProduct(selectedProduct.id, {
              recommendedPrice: recommendedFromStrategy,
              status: 'CALCULATED',
            });
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs rounded font-medium transition-colors"
        >
          <Check className="w-3.5 h-3.5" />
          <span>Apply Strategy ({formatCurrency(recommendedFromStrategy)})</span>
        </button>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Our Selling Price</span>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            {formatCurrency(currentPrice)}
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Cost: {formatCurrency(unitCost)}</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Competitor Median Price</span>
          <div className="text-2xl font-bold font-mono text-teal-400 mt-1">
            {formatCurrency(stats.median)}
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Range: {formatCurrency(stats.min)} — {formatCurrency(stats.max)}</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Competitive Price Index</span>
          <div className={`text-2xl font-bold font-mono mt-1 ${priceIndex <= 102 && priceIndex >= 98 ? 'text-emerald-400' : priceIndex > 102 ? 'text-amber-400' : 'text-teal-400'}`}>
            {priceIndex.toFixed(1)}%
          </div>
          <span className="text-[11px] text-slate-500 font-mono">{priceIndex > 100 ? `${(priceIndex - 100).toFixed(1)}% Premium` : `${(100 - priceIndex).toFixed(1)}% Discount`}</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Margin Floor Guardrail</span>
          <div className="text-2xl font-bold font-mono text-slate-200 mt-1">
            {formatCurrency(unitCost / (1 - selectedProduct.minMarginThreshold))}
          </div>
          <span className="text-[11px] text-emerald-400 font-mono">{(selectedProduct.minMarginThreshold * 100).toFixed(0)}% Min Floor Protected</span>
        </div>
      </div>

      {/* Competitor Quotes Table & Strategy Rules */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Table of Observed Competitors */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-200">Observed Competitor Benchmarks</h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono uppercase text-slate-400">
                <tr>
                  <th className="py-2.5 px-3">Competitor Brand</th>
                  <th className="py-2.5 px-3 text-right">Price</th>
                  <th className="py-2.5 px-3 text-right">Index vs Us</th>
                  <th className="py-2.5 px-3 text-center">Availability</th>
                  <th className="py-2.5 px-3 text-right">Last Observed</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono tabular-nums">
                {competitors.map((c, i) => {
                  const compIndex = currentPrice > 0 ? (c.price / currentPrice) * 100 : 100;
                  return (
                    <tr key={i} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-sans font-medium text-slate-200">{c.name}</td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-100">{formatCurrency(c.price)}</td>
                      <td className="py-2.5 px-3 text-right text-slate-300">{compIndex.toFixed(1)}%</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`text-[10px] px-2 py-0.5 rounded font-sans font-medium ${c.inStock ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                          {c.inStock ? 'In Stock' : 'Stockout'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-400">{c.lastObserved}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Strategy Selector */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-200">Competitive Rules & Policies</h3>
          <p className="text-xs text-slate-400">
            Select automated repositioning policy. System guarantees minimum margin protection to prevent loss-leader trap.
          </p>

          <div className="space-y-2.5">
            {[
              { id: 'match_median', label: 'Match Market Median', price: strategyPrices.match_median, desc: 'Align exactly with median competitor price.' },
              { id: 'undercut_5', label: 'Price Below Market (-5%)', price: strategyPrices.undercut_5, desc: 'Undercut cheapest competitor by 5% subject to margin floor.' },
              { id: 'premium_10', label: 'Premium Positioning (+10%)', price: strategyPrices.premium_10, desc: 'Command 10% brand premium above market median.' },
              { id: 'cost_protected', label: 'Cost-Protected Target (45%)', price: strategyPrices.cost_protected, desc: 'Guarantee 45% margin regardless of market price cuts.' },
            ].map(item => (
              <div
                key={item.id}
                onClick={() => setSelectedStrategy(item.id)}
                className={`p-3 rounded border cursor-pointer transition-colors ${
                  selectedStrategy === item.id
                    ? 'bg-slate-800 border-emerald-500/60 shadow-sm'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">{item.label}</span>
                  <span className="font-mono font-bold text-emerald-400">{formatCurrency(item.price)}</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
