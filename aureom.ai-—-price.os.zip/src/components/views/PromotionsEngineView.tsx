import React, { useState } from 'react';
import { usePricing } from '../../context/PricingContext';
import { Percent, ShieldAlert, Check, Plus, Trash2 } from 'lucide-react';

interface Tier {
  minQty: number;
  maxQty: number;
  discountPct: number;
}

export const PromotionsEngineView: React.FC = () => {
  const { selectedProduct, formatCurrency } = usePricing();

  const [tiers, setTiers] = useState<Tier[]>([
    { minQty: 1, maxQty: 9, discountPct: 0 },
    { minQty: 10, maxQty: 49, discountPct: 8 },
    { minQty: 50, maxQty: 199, discountPct: 15 },
    { minQty: 200, maxQty: 9999, discountPct: 22 },
  ]);

  const [preventStacking, setPreventStacking] = useState(true);
  const [allowPromoWithTier, setAllowPromoWithTier] = useState(false);

  const price = selectedProduct.currentPrice;
  const cost = selectedProduct.unitCost;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 font-semibold">{selectedProduct.sku}</span>
            <span className="text-slate-600">·</span>
            <h2 className="text-xl font-bold text-slate-100 tracking-tight">{selectedProduct.name}</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Automated volume discounting schedules, non-stackable promotion validation, and contribution margin protection.
          </p>
        </div>
      </div>

      {/* Volume Tier Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-200">Volume-Based Pricing Tiers</h3>
            <span className="text-xs font-mono text-slate-400">Base Price: {formatCurrency(price)}</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono uppercase text-slate-400">
                <tr>
                  <th className="py-2.5 px-3">Order Quantity Range</th>
                  <th className="py-2.5 px-3 text-right">Discount</th>
                  <th className="py-2.5 px-3 text-right">Effective Unit Price</th>
                  <th className="py-2.5 px-3 text-right">Unit Profit</th>
                  <th className="py-2.5 px-3 text-right">Gross Margin %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono tabular-nums">
                {tiers.map((t, idx) => {
                  const effectivePrice = price * (1 - t.discountPct / 100);
                  const unitProfit = effectivePrice - cost;
                  const marginPct = (unitProfit / effectivePrice) * 100;
                  const isHealthy = marginPct >= selectedProduct.minMarginThreshold * 100;

                  return (
                    <tr key={idx} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-sans font-medium text-slate-200">
                        {t.minQty} – {t.maxQty >= 9999 ? '∞ units' : `${t.maxQty} units`}
                      </td>
                      <td className="py-2.5 px-3 text-right text-teal-400 font-semibold">{t.discountPct}%</td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-100">{formatCurrency(effectivePrice)}</td>
                      <td className="py-2.5 px-3 text-right text-emerald-400">{formatCurrency(unitProfit)}</td>
                      <td className="py-2.5 px-3 text-right">
                        <span className={`px-1.5 py-0.5 rounded text-[11px] font-bold ${
                          isHealthy ? 'text-emerald-400 bg-emerald-500/10' : 'text-rose-400 bg-rose-500/10'
                        }`}>
                          {marginPct.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Guardrail Policy Rules */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-200">Promotion Stacking Safeguards</h3>

          <div className="space-y-3 pt-1 text-xs">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={preventStacking}
                onChange={(e) => setPreventStacking(e.target.checked)}
                className="mt-0.5 accent-emerald-500"
              />
              <span className="text-slate-300">
                <strong>Enforce Non-Stackable Rule:</strong> Block simultaneous application of coupon codes on top of existing volume tiers.
              </span>
            </label>

            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={allowPromoWithTier}
                onChange={(e) => setAllowPromoWithTier(e.target.checked)}
                className="mt-0.5 accent-emerald-500"
              />
              <span className="text-slate-300">
                <strong>Allow Seasonal Campaign Overwrite:</strong> Only if headline promo discount exceeds volume tier rate.
              </span>
            </label>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 text-[11px] font-mono text-slate-400 leading-relaxed">
              <span className="font-semibold text-emerald-400">System Policy Check: </span>
              Minimum gross margin constraint of {(selectedProduct.minMarginThreshold * 100).toFixed(0)}% is permanently active. Any discount combination violating floor is automatically rejected at checkout.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
