import React, { useState, useMemo } from 'react';
import { usePricing } from '../../context/PricingContext';
import { Cpu, Check, Sliders, ShieldCheck } from 'lucide-react';

export const DynamicPricingEngine: React.FC = () => {
  const { selectedProduct, formatCurrency, updateProduct } = usePricing();

  // Configurable Rule Weights
  const [elasticityWeight, setElasticityWeight] = useState(0.35);
  const [competitorWeight, setCompetitorWeight] = useState(0.30);
  const [inventoryWeight, setInventoryWeight] = useState(0.20);
  const [seasonalityWeight, setSeasonalityWeight] = useState(0.15);

  const p0 = selectedProduct.currentPrice;
  const cost = selectedProduct.unitCost;
  const compMedian = selectedProduct.competitors[0]?.price || p0;

  // Inventory velocity run-rate: days remaining
  const dailyDemand = selectedProduct.baselineDemand / 7;
  const daysOnHand = dailyDemand > 0 ? selectedProduct.inventoryOnHand / dailyDemand : 999;
  const leadDays = selectedProduct.replenishmentLeadDays;

  // Factor Calculations
  const factors = useMemo(() => {
    // 1. Elasticity factor: If highly elastic (|e| > 1.8), bias toward slight reduction or price holding
    // If inelastic (|e| < 1.2), strong upward pricing power
    let elastAdj = 0;
    if (Math.abs(selectedProduct.elasticity) < 1.0) elastAdj = +0.08;
    else if (Math.abs(selectedProduct.elasticity) < 1.5) elastAdj = +0.03;
    else if (Math.abs(selectedProduct.elasticity) > 2.0) elastAdj = -0.05;

    // 2. Competitor factor: Price gap relative to median
    const compGap = (compMedian - p0) / compMedian;
    const compAdj = compGap * 0.5; // pull 50% toward competitor

    // 3. Inventory factor:
    // If daysOnHand < leadDays * 1.2 (Stockout risk) -> increase price to dampen demand
    // If daysOnHand > leadDays * 4.0 (Overstock) -> discount to accelerate sell-through
    let invAdj = 0;
    if (daysOnHand < leadDays * 1.3) invAdj = +0.07;
    else if (daysOnHand > leadDays * 3.5) invAdj = -0.08;

    // 4. Seasonality factor
    const today = new Date();
    const dow = today.getDay();
    const seasonAdj = (dow === 5 || dow === 6 || dow === 0) ? +0.04 : -0.01;

    // Weighted composite recommended adjustment
    const netAdjustment =
      (elasticityWeight * elastAdj) +
      (competitorWeight * compAdj) +
      (inventoryWeight * invAdj) +
      (seasonalityWeight * seasonAdj);

    let rawPrice = p0 * (1 + netAdjustment);

    // Apply strict margin floor
    const marginFloor = cost / (1 - selectedProduct.minMarginThreshold);
    let constrainedPrice = Math.max(marginFloor, Math.max(selectedProduct.minPriceFloor, Math.min(selectedProduct.maxPriceCeiling, rawPrice)));

    return {
      elastAdj,
      compAdj,
      invAdj,
      seasonAdj,
      netAdjustment,
      rawPrice,
      constrainedPrice,
      marginFloor,
    };
  }, [selectedProduct, p0, cost, compMedian, daysOnHand, leadDays, elasticityWeight, competitorWeight, inventoryWeight, seasonalityWeight]);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 font-semibold">{selectedProduct.sku}</span>
            <span className="text-slate-600">·</span>
            <h2 className="text-xl font-bold text-slate-100 tracking-tight">{selectedProduct.name}</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Explainable dynamic repricing engine: Multi-factor scoring across demand elasticity, competitor parity, inventory velocity, and seasonality.
          </p>
        </div>

        <button
          onClick={() => {
            updateProduct(selectedProduct.id, {
              recommendedPrice: Number(factors.constrainedPrice.toFixed(2)),
              status: 'CALCULATED',
            });
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs rounded font-medium transition-colors"
        >
          <Check className="w-3.5 h-3.5" />
          <span>Apply Engine Recommendation ({formatCurrency(factors.constrainedPrice)})</span>
        </button>
      </div>

      {/* Recommended Output Hero */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Engine Recommended Price</span>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {formatCurrency(factors.constrainedPrice)}
          </div>
          <span className="text-[11px] text-slate-500 font-mono">
            {factors.netAdjustment >= 0 ? '+' : ''}{(factors.netAdjustment * 100).toFixed(1)}% Net Composite Shift
          </span>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Current Baseline Price</span>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">
            {formatCurrency(p0)}
          </div>
          <span className="text-[11px] text-slate-500 font-mono">Cost: {formatCurrency(cost)}</span>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Enforced Floor Boundary</span>
          <div className="text-2xl font-bold font-mono text-slate-200 mt-1">
            {formatCurrency(factors.marginFloor)}
          </div>
          <span className="text-[11px] text-emerald-400 font-mono">{(selectedProduct.minMarginThreshold * 100).toFixed(0)}% Margin Protected</span>
        </div>
      </div>

      {/* Configurable Multi-Factor Weights & Decomposition */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Factor Weights Config */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-200 flex items-center justify-between">
            <span>Dynamic Engine Scoring Weights</span>
            <span className="text-[11px] font-mono text-slate-500">Total: 100%</span>
          </h3>

          <div className="space-y-4 pt-1">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Price Elasticity Weight</span>
                <span className="font-mono text-emerald-400 font-semibold">{(elasticityWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.60"
                step="0.05"
                value={elasticityWeight}
                onChange={(e) => setElasticityWeight(parseFloat(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Competitor Positioning Weight</span>
                <span className="font-mono text-teal-400 font-semibold">{(competitorWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.60"
                step="0.05"
                value={competitorWeight}
                onChange={(e) => setCompetitorWeight(parseFloat(e.target.value))}
                className="w-full accent-teal-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Inventory Velocity Weight</span>
                <span className="font-mono text-amber-400 font-semibold">{(inventoryWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.05"
                max="0.40"
                step="0.05"
                value={inventoryWeight}
                onChange={(e) => setInventoryWeight(parseFloat(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Seasonality & Calendar Weight</span>
                <span className="font-mono text-purple-400 font-semibold">{(seasonalityWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.05"
                max="0.30"
                step="0.05"
                value={seasonalityWeight}
                onChange={(e) => setSeasonalityWeight(parseFloat(e.target.value))}
                className="w-full accent-purple-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Explainability Breakdown */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-semibold text-slate-200">Mathematical Rationale Ledger</h3>

          <div className="space-y-3 text-xs font-mono">
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 flex justify-between items-center">
              <div>
                <span className="text-slate-300 font-medium">1. Elasticity Signal (ε = {selectedProduct.elasticity}):</span>
                <span className="text-[11px] text-slate-500 block font-sans">
                  {Math.abs(selectedProduct.elasticity) < 1.2 ? 'Inelastic pricing power' : 'Elastic demand sensitivity'}
                </span>
              </div>
              <span className={`font-bold tabular-nums ${factors.elastAdj >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {factors.elastAdj >= 0 ? '+' : ''}{(factors.elastAdj * 100).toFixed(1)}%
              </span>
            </div>

            <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 flex justify-between items-center">
              <div>
                <span className="text-slate-300 font-medium">2. Competitor Signal (Ref: £{compMedian.toFixed(2)}):</span>
                <span className="text-[11px] text-slate-500 block font-sans">Market median parity adjustment</span>
              </div>
              <span className={`font-bold tabular-nums ${factors.compAdj >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {factors.compAdj >= 0 ? '+' : ''}{(factors.compAdj * 100).toFixed(1)}%
              </span>
            </div>

            <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 flex justify-between items-center">
              <div>
                <span className="text-slate-300 font-medium">3. Inventory Urgency ({Math.round(daysOnHand)}d on hand):</span>
                <span className="text-[11px] text-slate-500 block font-sans">Lead time: {leadDays} days</span>
              </div>
              <span className={`font-bold tabular-nums ${factors.invAdj >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {factors.invAdj >= 0 ? '+' : ''}{(factors.invAdj * 100).toFixed(1)}%
              </span>
            </div>

            <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 flex justify-between items-center">
              <div>
                <span className="text-slate-300 font-medium">4. Seasonality Uplift:</span>
                <span className="text-[11px] text-slate-500 block font-sans">Day-of-week demand coefficient</span>
              </div>
              <span className={`font-bold tabular-nums ${factors.seasonAdj >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {factors.seasonAdj >= 0 ? '+' : ''}{(factors.seasonAdj * 100).toFixed(1)}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
