export interface ElasticityRegressionResult {
  elasticity: number; // Slope beta
  intercept: number;
  rSquared: number;
  standardError: number;
  tStatistic: number;
  pValue: number;
  sampleSize: number;
  confidenceInterval95: [number, number];
  classification: 'Inelastic' | 'Unit Elastic' | 'Elastic' | 'Highly Elastic' | 'Positive/Anomalous';
  description: string;
}

/**
 * Constant Elasticity Demand Model:
 * Q(P) = Q0 * (P / P0)^elasticity
 */
export function estimateDemand(
  candidatePrice: number,
  baselinePrice: number,
  baselineDemand: number,
  elasticity: number
): number {
  if (candidatePrice <= 0 || baselinePrice <= 0 || baselineDemand <= 0) {
    return 0;
  }
  // Prevent runaway numbers if candidate price is close to 0 or extremely high
  const priceRatio = candidatePrice / baselinePrice;
  const demand = baselineDemand * Math.pow(priceRatio, elasticity);
  return Math.max(0, isFinite(demand) ? demand : 0);
}

/**
 * Arc Elasticity:
 * e = ((Q2 - Q1) / ((Q1 + Q2) / 2)) / ((P2 - P1) / ((P1 + P2) / 2))
 */
export function calculateArcElasticity(p1: number, q1: number, p2: number, q2: number): number {
  if (p1 === p2 || q1 + q2 === 0 || p1 + p2 === 0) return 0;
  const deltaQ = q2 - q1;
  const avgQ = (q1 + q2) / 2;
  const deltaP = p2 - p1;
  const avgP = (p1 + p2) / 2;

  const pctChangeQ = deltaQ / avgQ;
  const pctChangeP = deltaP / avgP;

  return pctChangeQ / pctChangeP;
}

/**
 * Log-Log Ordinary Least Squares (OLS) Regression for Price Elasticity:
 * ln(Q) = alpha + beta * ln(P) + epsilon
 * beta is the empirical price elasticity of demand
 */
export function calculateLogLogElasticity(
  observations: { price: number; unitsSold: number }[]
): ElasticityRegressionResult {
  const valid = observations.filter(o => o.price > 0 && o.unitsSold > 0);
  const n = valid.length;

  if (n < 3) {
    return {
      elasticity: -1.5,
      intercept: 5.0,
      rSquared: 0,
      standardError: 0.5,
      tStatistic: 0,
      pValue: 1,
      sampleSize: n,
      confidenceInterval95: [-2.5, -0.5],
      classification: 'Elastic',
      description: 'Insufficient observational data points for rigorous regression; using category prior.',
    };
  }

  const logP = valid.map(o => Math.log(o.price));
  const logQ = valid.map(o => Math.log(o.unitsSold));

  const meanLogP = logP.reduce((sum, v) => sum + v, 0) / n;
  const meanLogQ = logQ.reduce((sum, v) => sum + v, 0) / n;

  let sxx = 0;
  let sxy = 0;
  let syy = 0;

  for (let i = 0; i < n; i++) {
    const diffP = logP[i] - meanLogP;
    const diffQ = logQ[i] - meanLogQ;
    sxx += diffP * diffP;
    sxy += diffP * diffQ;
    syy += diffQ * diffQ;
  }

  if (sxx === 0) {
    return {
      elasticity: -1.0,
      intercept: meanLogQ,
      rSquared: 0,
      standardError: 0.5,
      tStatistic: 0,
      pValue: 1,
      sampleSize: n,
      confidenceInterval95: [-2.0, 0],
      classification: 'Unit Elastic',
      description: 'Zero price variance in historical sample.',
    };
  }

  const beta = sxy / sxx;
  const alpha = meanLogQ - (beta * meanLogP);

  // Residual sum of squares
  let ssRes = 0;
  for (let i = 0; i < n; i++) {
    const predictedLogQ = alpha + beta * logP[i];
    const residual = logQ[i] - predictedLogQ;
    ssRes += residual * residual;
  }

  const rSquared = syy > 0 ? Math.max(0, Math.min(1, 1 - (ssRes / syy))) : 0;
  const degreesOfFreedom = n - 2;
  const varianceResidual = degreesOfFreedom > 0 ? ssRes / degreesOfFreedom : 0;
  const standardError = Math.sqrt(varianceResidual / sxx);

  const tStat = standardError > 0 ? Math.abs(beta / standardError) : 0;
  // Approximate two-tailed p-value for large n or normal approximation
  const pValue = Math.min(1, Math.max(0.0001, 2 * (1 - normalCdf(tStat))));

  const marginOfError = 1.96 * standardError;
  const ci95: [number, number] = [
    Number((beta - marginOfError).toFixed(3)),
    Number((beta + marginOfError).toFixed(3)),
  ];

  let classification: ElasticityRegressionResult['classification'] = 'Elastic';
  if (beta > 0) classification = 'Positive/Anomalous';
  else if (Math.abs(beta) < 0.8) classification = 'Inelastic';
  else if (Math.abs(beta) >= 0.8 && Math.abs(beta) <= 1.2) classification = 'Unit Elastic';
  else if (Math.abs(beta) > 2.5) classification = 'Highly Elastic';
  else classification = 'Elastic';

  let description = '';
  if (Math.abs(beta) < 1.0) {
    description = `Inelastic demand (|ε| = ${Math.abs(beta).toFixed(2)} < 1.0). Price increases yield net revenue growth as quantity loss is proportionally smaller than price gain.`;
  } else if (Math.abs(beta) > 1.0) {
    description = `Elastic demand (|ε| = ${Math.abs(beta).toFixed(2)} > 1.0). Quantity demanded is sensitive to price adjustments. Price hikes risk reducing total revenue.`;
  } else {
    description = `Unit elastic (|ε| ≈ 1.0). Percentage change in quantity exactly offsets percentage change in price.`;
  }

  return {
    elasticity: Number(beta.toFixed(3)),
    intercept: Number(alpha.toFixed(3)),
    rSquared: Number(rSquared.toFixed(3)),
    standardError: Number(standardError.toFixed(3)),
    tStatistic: Number(tStat.toFixed(2)),
    pValue: Number(pValue.toFixed(4)),
    sampleSize: n,
    confidenceInterval95: ci95,
    classification,
    description,
  };
}

/**
 * Standard Normal CDF approximation (Abramowitz & Stegun)
 */
function normalCdf(x: number): number {
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 0.3989423 * Math.exp(-x * x / 2);
  const prob = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return x > 0 ? 1 - prob : prob;
}

/**
 * Category-level hierarchical pooling:
 * Blends product-specific empirical elasticity with category prior
 * based on sample variance and observational sample size
 */
export function getPooledElasticity(
  productElasticity: number,
  productSampleSize: number,
  categoryPriorElasticity: number
): { pooled: number; weightOnProduct: number } {
  // If sample size is 0, rely 100% on prior
  if (productSampleSize <= 0) {
    return { pooled: categoryPriorElasticity, weightOnProduct: 0 };
  }
  // Empirical Bayes shrinkage factor
  const m = 15; // Credibility parameter (samples needed for 50/50 weight)
  const weight = productSampleSize / (productSampleSize + m);
  const pooled = (weight * productElasticity) + ((1 - weight) * categoryPriorElasticity);

  return {
    pooled: Number(pooled.toFixed(3)),
    weightOnProduct: Number(weight.toFixed(2)),
  };
}
