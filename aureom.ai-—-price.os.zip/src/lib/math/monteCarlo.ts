import { MonteCarloResult, MonteCarloScenario } from '../../types/pricing';
import { estimateDemand } from './elasticity';

/**
 * Seedable Pseudo-Random Number Generator (Linear Congruential Generator)
 */
class LCG {
  private seed: number;
  constructor(seed: number = 42) {
    this.seed = seed;
  }
  next(): number {
    this.seed = (this.seed * 1664525 + 1013904223) % 4294967296;
    return this.seed / 4294967296;
  }
}

/**
 * Box-Muller transform for generating standard normal random values
 */
function randomNormal(rng: LCG, mean: number = 0, stdDev: number = 1): number {
  let u1 = rng.next();
  let u2 = rng.next();
  while (u1 <= 1e-15) u1 = rng.next(); // Avoid log(0)
  const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  return mean + z0 * stdDev;
}

/**
 * Run 1,000-run Monte Carlo Simulation for Price Uncertainty
 */
export function runMonteCarloSimulation(
  scenario: MonteCarloScenario,
  randomSeed: number = 1337
): MonteCarloResult {
  const {
    baselinePrice,
    candidatePrice,
    cost,
    elasticityMean,
    elasticityStdDev,
    baselineDemandMean,
    baselineDemandStdDev,
    costVariancePercent,
    iterations = 1000,
  } = scenario;

  const rng = new LCG(randomSeed);

  const profits: number[] = [];
  const revenues: number[] = [];
  const demands: number[] = [];

  let winCount = 0; // candidate profit > baseline profit
  let downsideCount = 0; // candidate profit < 0.95 * baseline profit

  for (let i = 0; i < iterations; i++) {
    // 1. Sample stochastic inputs
    const simElasticity = randomNormal(rng, elasticityMean, Math.max(0.05, elasticityStdDev));
    const simBaselineDemand = Math.max(1, randomNormal(rng, baselineDemandMean, Math.max(1, baselineDemandStdDev)));
    const simCost = Math.max(0.01, randomNormal(rng, cost, cost * Math.max(0.01, costVariancePercent)));

    // 2. Evaluate candidate price
    const simDemandCand = estimateDemand(candidatePrice, baselinePrice, simBaselineDemand, simElasticity);
    const simRevCand = candidatePrice * simDemandCand;
    const simProfCand = (candidatePrice - simCost) * simDemandCand;

    // 3. Evaluate baseline price for comparative alpha
    const simDemandBase = estimateDemand(baselinePrice, baselinePrice, simBaselineDemand, simElasticity);
    const simProfBase = (baselinePrice - simCost) * simDemandBase;

    profits.push(simProfCand);
    revenues.push(simRevCand);
    demands.push(simDemandCand);

    if (simProfCand > simProfBase) {
      winCount++;
    }
    if (simProfCand < (simProfBase * 0.95)) {
      downsideCount++;
    }
  }

  // Sort for percentile calculation
  profits.sort((a, b) => a - b);
  revenues.sort((a, b) => a - b);
  demands.sort((a, b) => a - b);

  const getPercentile = (arr: number[], p: number) => {
    const idx = Math.min(arr.length - 1, Math.max(0, Math.floor((p / 100) * arr.length)));
    return arr[idx];
  };

  const profitPercentiles = {
    p10: Number(getPercentile(profits, 10).toFixed(2)),
    p25: Number(getPercentile(profits, 25).toFixed(2)),
    p50: Number(getPercentile(profits, 50).toFixed(2)),
    p75: Number(getPercentile(profits, 75).toFixed(2)),
    p90: Number(getPercentile(profits, 90).toFixed(2)),
    p95: Number(getPercentile(profits, 95).toFixed(2)),
  };

  const revenuePercentiles = {
    p10: Number(getPercentile(revenues, 10).toFixed(2)),
    p50: Number(getPercentile(revenues, 50).toFixed(2)),
    p90: Number(getPercentile(revenues, 90).toFixed(2)),
  };

  const demandPercentiles = {
    p10: Number(getPercentile(demands, 10).toFixed(1)),
    p50: Number(getPercentile(demands, 50).toFixed(1)),
    p90: Number(getPercentile(demands, 90).toFixed(1)),
  };

  // Build histogram distribution (20 bins)
  const minP = profits[0];
  const maxP = profits[profits.length - 1];
  const binCount = 20;
  const binWidth = (maxP - minP) / binCount;
  const distribution: { bin: number; count: number; profit: number }[] = [];

  for (let b = 0; b < binCount; b++) {
    const binStart = minP + b * binWidth;
    const binEnd = binStart + binWidth;
    const count = profits.filter(v => v >= binStart && (b === binCount - 1 ? v <= binEnd : v < binEnd)).length;
    distribution.push({
      bin: b + 1,
      count,
      profit: Number((binStart + binWidth / 2).toFixed(2)),
    });
  }

  return {
    profitPercentiles,
    revenuePercentiles,
    demandPercentiles,
    winProbability: Number(((winCount / iterations) * 100).toFixed(1)),
    downsideRiskProbability: Number(((downsideCount / iterations) * 100).toFixed(1)),
    distribution,
  };
}
