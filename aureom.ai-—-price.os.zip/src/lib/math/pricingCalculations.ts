import { QuickCalculatorInputs, QuickCalculatorOutputs } from '../../types/pricing';

/**
 * Cost-Plus Pricing:
 * Price = Cost * (1 + Markup Rate)
 */
export function calculateMarkupPrice(cost: number, markupRate: number): number {
  if (cost < 0 || markupRate < 0) return 0;
  return cost * (1 + markupRate);
}

/**
 * Target Margin Pricing:
 * Price = Cost / (1 - Target Margin)
 * Strictly enforces margin < 1.0 (100%) to avoid division by zero.
 */
export function calculateMarginPrice(cost: number, targetMargin: number): number {
  if (cost < 0 || targetMargin < 0) return 0;
  if (targetMargin >= 0.999) return cost * 1000;
  return cost / (1 - targetMargin);
}

/**
 * Calculate markup percentage from price and cost
 * Markup = (Price - Cost) / Cost
 */
export function calculateMarkupFromPrices(price: number, cost: number): number {
  if (cost <= 0) return 0;
  return (price - cost) / cost;
}

/**
 * Calculate gross margin percentage from price and cost
 * Margin = (Price - Cost) / Price
 */
export function calculateMarginFromPrices(price: number, cost: number): number {
  if (price <= 0) return 0;
  return (price - cost) / price;
}

/**
 * Contribution Margin per Unit:
 * CM = Net Selling Revenue - Variable Costs
 */
export function calculateContributionMargin(netRevenue: number, totalVariableCost: number): number {
  return netRevenue - totalVariableCost;
}

/**
 * Break-even Volume:
 * Q_be = Fixed Costs / Unit Contribution Margin
 * Returns null or Infinity if CM <= 0
 */
export function calculateBreakEvenVolume(fixedCosts: number, unitContributionMargin: number): number {
  if (unitContributionMargin <= 0) return Infinity;
  return Math.ceil(fixedCosts / unitContributionMargin);
}

/**
 * Break-even Price:
 * P_be = Variable Cost + (Fixed Costs / Volume)
 */
export function calculateBreakEvenPrice(variableCost: number, fixedCosts: number, volume: number): number {
  if (volume <= 0) return variableCost;
  return variableCost + (fixedCosts / volume);
}

/**
 * Comprehensive Quick Calculator solver supporting fees, taxes, discounts, and overhead
 */
export function solveQuickCalculator(inputs: QuickCalculatorInputs): QuickCalculatorOutputs {
  const {
    unitCost,
    currentPrice,
    desiredMargin,
    desiredMarkup,
    taxRate,
    taxInclusive,
    shippingCost,
    packagingCost,
    paymentFeePercent,
    paymentFeeFixed,
    additionalVariableCost,
    fixedOverheadCost,
    expectedVolume,
    discountRate,
  } = inputs;

  // 1. Basic formula prices
  const costPlusPrice = calculateMarkupPrice(unitCost, desiredMarkup);
  const targetMarginPrice = calculateMarginPrice(unitCost, desiredMargin);

  // 2. Variable costs per unit
  const directVariableCost = unitCost + shippingCost + packagingCost + additionalVariableCost;

  // 3. For current price evaluation:
  // Apply headline discount
  const effectiveHeadlinePrice = currentPrice * (1 - Math.max(0, Math.min(1, discountRate)));

  // Account for tax if inclusive
  // If price is tax-inclusive: Net Price = Gross / (1 + taxRate)
  // If price is tax-exclusive: Net Price = Gross
  const netRevenueBeforePaymentFee = taxInclusive
    ? effectiveHeadlinePrice / (1 + taxRate)
    : effectiveHeadlinePrice;

  // Payment processing fee is taken on total billed amount
  const paymentFee = (effectiveHeadlinePrice * paymentFeePercent) + paymentFeeFixed;

  // Net revenue actually retained
  const netSellingRevenue = Math.max(0, netRevenueBeforePaymentFee - paymentFee);

  // Total variable cost includes direct variable cost
  const totalVariableCostPerUnit = directVariableCost;

  // Contribution Margin
  const contributionMarginPerUnit = netSellingRevenue - totalVariableCostPerUnit;
  const contributionMarginRatio = netSellingRevenue > 0
    ? contributionMarginPerUnit / netSellingRevenue
    : 0;

  // Gross Profit based on standard COGS
  const grossProfitPerUnit = netRevenueBeforePaymentFee - unitCost;
  const grossMarginPercent = netRevenueBeforePaymentFee > 0
    ? (grossProfitPerUnit / netRevenueBeforePaymentFee) * 100
    : 0;
  const markupPercent = unitCost > 0
    ? ((netRevenueBeforePaymentFee - unitCost) / unitCost) * 100
    : 0;

  // Break-even metrics
  const breakEvenVolume = calculateBreakEvenVolume(fixedOverheadCost, contributionMarginPerUnit);
  const breakEvenPrice = calculateBreakEvenPrice(totalVariableCostPerUnit, fixedOverheadCost, expectedVolume);

  // Totals
  const totalExpectedRevenue = netSellingRevenue * expectedVolume;
  const totalExpectedProfit = (contributionMarginPerUnit * expectedVolume) - fixedOverheadCost;

  const isMarginHealthy = grossMarginPercent >= (desiredMargin * 100);

  return {
    costPlusPrice: Number(costPlusPrice.toFixed(2)),
    targetMarginPrice: Number(targetMarginPrice.toFixed(2)),
    netSellingRevenue: Number(netSellingRevenue.toFixed(2)),
    totalVariableCostPerUnit: Number(totalVariableCostPerUnit.toFixed(2)),
    contributionMarginPerUnit: Number(contributionMarginPerUnit.toFixed(2)),
    contributionMarginRatio: Number(contributionMarginRatio.toFixed(4)),
    grossProfitPerUnit: Number(grossProfitPerUnit.toFixed(2)),
    grossMarginPercent: Number(grossMarginPercent.toFixed(2)),
    markupPercent: Number(markupPercent.toFixed(2)),
    breakEvenVolume: isFinite(breakEvenVolume) ? breakEvenVolume : 0,
    breakEvenPrice: Number(breakEvenPrice.toFixed(2)),
    totalExpectedRevenue: Number(totalExpectedRevenue.toFixed(2)),
    totalExpectedProfit: Number(totalExpectedProfit.toFixed(2)),
    isMarginHealthy,
  };
}
