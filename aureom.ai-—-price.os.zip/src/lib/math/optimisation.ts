import { OptimisationParams, OptimisationResult } from '../../types/pricing';
import { estimateDemand } from './elasticity';

/**
 * Enterprise Price Optimisation Engine:
 * Implements bounded golden-section search and grid discretization
 * with constraint checking and explainability diagnostics.
 */
export function optimiseProductPrice(params: OptimisationParams): OptimisationResult {
  const {
    baselinePrice,
    baselineDemand,
    unitCost,
    elasticity,
    minPrice,
    maxPrice,
    minMargin,
    objective,
    currentInventory,
    competitorMedian,
  } = params;

  // 1. Calculate margin floor price: P >= c / (1 - minMargin)
  const marginFloorPrice = minMargin < 0.99 ? unitCost / (1 - minMargin) : unitCost * 1.5;

  // Effective lower bound considering margin requirements
  const effectiveMinPrice = Math.max(minPrice, marginFloorPrice);
  const effectiveMaxPrice = Math.max(effectiveMinPrice, maxPrice);

  // 2. Baseline current metrics
  const currentDemand = estimateDemand(baselinePrice, baselinePrice, baselineDemand, elasticity);
  const currentRevenue = baselinePrice * currentDemand;
  const currentProfit = (baselinePrice - unitCost) * currentDemand;
  const currentMargin = baselinePrice > 0 ? (baselinePrice - unitCost) / baselinePrice : 0;

  // 3. Unconstrained theoretical optimal price for profit if elasticity < -1
  // Formula: P* = c * (elasticity / (1 + elasticity))
  let unconstrainedProfitOptimal: number | null = null;
  if (elasticity < -1 && unitCost > 0) {
    unconstrainedProfitOptimal = unitCost * (elasticity / (1 + elasticity));
  }

  // 4. Define Objective Function
  function evaluatePrice(p: number): {
    score: number;
    demand: number;
    revenue: number;
    profit: number;
    margin: number;
    feasible: boolean;
  } {
    const d = estimateDemand(p, baselinePrice, baselineDemand, elasticity);
    const rev = p * d;
    const prof = (p - unitCost) * d;
    const m = p > 0 ? (p - unitCost) / p : 0;
    const feasible = p >= marginFloorPrice && p >= minPrice && p <= maxPrice;

    let score = prof;
    if (objective === 'maximise_revenue') {
      score = rev;
    } else if (objective === 'maximise_volume') {
      score = feasible ? d : -1e9;
    } else if (objective === 'target_margin') {
      // Penalty function for distance from target margin
      const targetM = minMargin + 0.05;
      score = -Math.abs(m - targetM) * 10000;
    } else if (objective === 'balance_profit_volume') {
      // 70% profit, 30% volume normalized
      const normalizedProf = currentProfit > 0 ? prof / currentProfit : prof;
      const normalizedVol = currentDemand > 0 ? d / currentDemand : d;
      score = (0.7 * normalizedProf) + (0.3 * normalizedVol);
    }

    return { score, demand: d, revenue: rev, profit: prof, margin: m, feasible };
  }

  // 5. Golden Section Search on [effectiveMinPrice, effectiveMaxPrice]
  const goldenRatio = (Math.sqrt(5) - 1) / 2;
  let a = effectiveMinPrice;
  let b = effectiveMaxPrice;
  const tolerance = 0.01; // Cent-level precision
  let c = b - goldenRatio * (b - a);
  let d = a + goldenRatio * (b - a);

  while (Math.abs(b - a) > tolerance) {
    const evalC = evaluatePrice(c);
    const evalD = evaluatePrice(d);

    if (evalC.score < evalD.score) {
      a = c;
    } else {
      b = d;
    }

    c = b - goldenRatio * (b - a);
    d = a + goldenRatio * (b - a);
  }

  let optimalPrice = Number(((a + b) / 2).toFixed(2));

  // Determine if constrained by bounds
  let isConstrained = false;
  let bindingConstraint: string | undefined = undefined;

  if (Math.abs(optimalPrice - marginFloorPrice) < 0.1) {
    isConstrained = true;
    bindingConstraint = `Minimum Gross Margin Floor (${(minMargin * 100).toFixed(0)}% = £${marginFloorPrice.toFixed(2)})`;
    optimalPrice = Math.max(optimalPrice, marginFloorPrice);
  } else if (Math.abs(optimalPrice - maxPrice) < 0.1) {
    isConstrained = true;
    bindingConstraint = `Maximum Price Ceiling (Configured boundary £${maxPrice.toFixed(2)})`;
  } else if (Math.abs(optimalPrice - minPrice) < 0.1) {
    isConstrained = true;
    bindingConstraint = `Minimum Price Floor (Configured boundary £${minPrice.toFixed(2)})`;
  }

  // 6. Optimal Metrics
  const optEval = evaluatePrice(optimalPrice);
  const expectedDemand = optEval.demand;
  const expectedRevenue = optEval.revenue;
  const expectedProfit = optEval.profit;
  const expectedMargin = optEval.margin;

  const revenueDeltaPercent = currentRevenue > 0
    ? ((expectedRevenue - currentRevenue) / currentRevenue) * 100
    : 0;
  const profitDeltaPercent = currentProfit > 0
    ? ((expectedProfit - currentProfit) / currentProfit) * 100
    : 0;
  const demandDeltaPercent = currentDemand > 0
    ? ((expectedDemand - currentDemand) / currentDemand) * 100
    : 0;

  // 7. Generate Dense Curve Grid for Visualisations
  const gridPoints = 60;
  const plotMin = Math.max(unitCost * 0.9, minPrice * 0.7);
  const plotMax = maxPrice * 1.25;
  const step = (plotMax - plotMin) / (gridPoints - 1);
  const curveData: OptimisationResult['curveData'] = [];

  for (let i = 0; i < gridPoints; i++) {
    const p = Number((plotMin + i * step).toFixed(2));
    const ev = evaluatePrice(p);
    curveData.push({
      price: p,
      demand: Number(ev.demand.toFixed(1)),
      revenue: Number(ev.revenue.toFixed(2)),
      profit: Number(ev.profit.toFixed(2)),
      margin: Number(ev.margin.toFixed(3)),
      isFeasible: p >= marginFloorPrice && p >= minPrice && p <= maxPrice,
    });
  }

  // 8. Human-Readable Explanation
  const priceDirection = optimalPrice > baselinePrice ? 'an increase' : optimalPrice < baselinePrice ? 'a decrease' : 'maintaining';
  const priceDeltaAbs = Math.abs(optimalPrice - baselinePrice);
  const priceDeltaPct = baselinePrice > 0 ? (priceDeltaAbs / baselinePrice) * 100 : 0;

  let explanation = `Model recommends ${priceDirection} of £${priceDeltaAbs.toFixed(2)} (${priceDeltaPct.toFixed(1)}%) to £${optimalPrice.toFixed(2)}. `;
  if (objective === 'maximise_profit') {
    explanation += `Under elasticity ε = ${elasticity.toFixed(2)}, this candidate maximises expected contribution profit to £${expectedProfit.toFixed(2)} (${profitDeltaPercent >= 0 ? '+' : ''}${profitDeltaPercent.toFixed(1)}% vs baseline). Expected demand shifts by ${demandDeltaPercent >= 0 ? '+' : ''}${demandDeltaPercent.toFixed(1)}%.`;
  } else if (objective === 'maximise_revenue') {
    explanation += `This candidate maximises gross revenue to £${expectedRevenue.toFixed(2)} (${revenueDeltaPercent >= 0 ? '+' : ''}${revenueDeltaPercent.toFixed(1)}% vs baseline).`;
  } else {
    explanation += `This recommendation balances volume preservation and margin efficiency with an expected gross margin of ${(expectedMargin * 100).toFixed(1)}%.`;
  }

  if (isConstrained && bindingConstraint) {
    explanation += ` Note: Output is bound by ${bindingConstraint}.`;
  }

  if (competitorMedian && competitorMedian > 0) {
    const index = (optimalPrice / competitorMedian) * 100;
    explanation += ` Relative to competitor median (£${competitorMedian.toFixed(2)}), recommended price indexes at ${index.toFixed(0)}%.`;
  }

  return {
    optimalPrice,
    expectedDemand: Number(expectedDemand.toFixed(1)),
    expectedRevenue: Number(expectedRevenue.toFixed(2)),
    expectedProfit: Number(expectedProfit.toFixed(2)),
    expectedMargin: Number(expectedMargin.toFixed(3)),
    currentPrice: baselinePrice,
    currentDemand: Number(currentDemand.toFixed(1)),
    currentRevenue: Number(currentRevenue.toFixed(2)),
    currentProfit: Number(currentProfit.toFixed(2)),
    currentMargin: Number(currentMargin.toFixed(3)),
    revenueDeltaPercent: Number(revenueDeltaPercent.toFixed(1)),
    profitDeltaPercent: Number(profitDeltaPercent.toFixed(1)),
    demandDeltaPercent: Number(demandDeltaPercent.toFixed(1)),
    curveData,
    isConstrained,
    bindingConstraint,
    explanation,
  };
}
