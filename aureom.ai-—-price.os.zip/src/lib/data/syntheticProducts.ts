import { Product, ProductCategory } from '../../types/pricing';

export const INITIAL_PRODUCTS: Product[] = [
  // 1. Consumer Tech
  {
    id: 'prod-001',
    sku: 'TECH-ANC-01',
    name: 'Acoustic Pro Wireless ANC Headphones',
    category: 'Consumer Tech',
    currentPrice: 199.99,
    unitCost: 74.50,
    fixedAllocatedCost: 12.00,
    baselineDemand: 340,
    elasticity: -1.82,
    elasticityStandardError: 0.14,
    inventoryOnHand: 820,
    replenishmentLeadDays: 21,
    holdingCostPerUnitWeek: 0.85,
    competitors: [
      { name: 'SoundMaster Ultra', price: 189.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.95 },
      { name: 'Apex Audio X1', price: 219.99, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.92 },
      { name: 'Volt Acoustic 300', price: 195.00, lastObserved: '2026-11-05', inStock: false, reliabilityScore: 0.88 },
    ],
    minPriceFloor: 149.00,
    maxPriceCeiling: 249.00,
    minMarginThreshold: 0.40,
    priceEnding: '.99',
    salesHistory: generateHistory(199.99, 74.50, 340, -1.82, 30),
    recommendedPrice: 209.99,
    status: 'CALCULATED',
    lastRepricedDate: '2026-10-15',
  },
  {
    id: 'prod-002',
    sku: 'TECH-CHG-65W',
    name: '65W GaN Dual-Port Fast Wall Charger',
    category: 'Consumer Tech',
    currentPrice: 34.99,
    unitCost: 11.20,
    fixedAllocatedCost: 1.50,
    baselineDemand: 1250,
    elasticity: -2.35,
    elasticityStandardError: 0.18,
    inventoryOnHand: 2400,
    replenishmentLeadDays: 14,
    holdingCostPerUnitWeek: 0.12,
    competitors: [
      { name: 'AnkerPower 65W', price: 32.99, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.98 },
      { name: 'UGreen Nexode', price: 35.99, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.95 },
    ],
    minPriceFloor: 24.99,
    maxPriceCeiling: 45.00,
    minMarginThreshold: 0.45,
    priceEnding: '.99',
    salesHistory: generateHistory(34.99, 11.20, 1250, -2.35, 30),
    recommendedPrice: 31.99,
    status: 'PENDING_REVIEW',
    lastRepricedDate: '2026-10-28',
  },
  {
    id: 'prod-003',
    sku: 'TECH-MEC-KEY',
    name: 'Tactile Mechanical Keyboard RGB Hot-Swap',
    category: 'Consumer Tech',
    currentPrice: 119.50,
    unitCost: 48.00,
    fixedAllocatedCost: 7.20,
    baselineDemand: 420,
    elasticity: -1.65,
    elasticityStandardError: 0.12,
    inventoryOnHand: 310,
    replenishmentLeadDays: 28,
    holdingCostPerUnitWeek: 0.65,
    competitors: [
      { name: 'Keychron K2 Pro', price: 115.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.96 },
      { name: 'Epomaker RT100', price: 124.99, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.90 },
    ],
    minPriceFloor: 95.00,
    maxPriceCeiling: 145.00,
    minMarginThreshold: 0.38,
    priceEnding: '.00',
    salesHistory: generateHistory(119.50, 48.00, 420, -1.65, 30),
    recommendedPrice: 124.00,
    status: 'APPROVED',
    lastRepricedDate: '2026-11-01',
  },
  {
    id: 'prod-004',
    sku: 'TECH-CAM-4K',
    name: 'Ultra HD 4K Streaming Webcam with HDR',
    category: 'Consumer Tech',
    currentPrice: 89.99,
    unitCost: 32.50,
    fixedAllocatedCost: 4.50,
    baselineDemand: 680,
    elasticity: -1.95,
    elasticityStandardError: 0.15,
    inventoryOnHand: 1150,
    replenishmentLeadDays: 18,
    holdingCostPerUnitWeek: 0.35,
    competitors: [
      { name: 'Logi Brio Stream', price: 94.99, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.98 },
      { name: 'Razer Kiyo Pro', price: 87.00, lastObserved: '2026-11-05', inStock: true, reliabilityScore: 0.91 },
    ],
    minPriceFloor: 69.99,
    maxPriceCeiling: 119.99,
    minMarginThreshold: 0.40,
    priceEnding: '.99',
    salesHistory: generateHistory(89.99, 32.50, 680, -1.95, 30),
    recommendedPrice: 89.99,
    status: 'PUBLISHED',
    lastRepricedDate: '2026-11-03',
  },

  // 2. Apparel & Footwear
  {
    id: 'prod-005',
    sku: 'APP-RUN-SHOE',
    name: 'CloudStrider Carbon Road Running Shoes',
    category: 'Apparel & Footwear',
    currentPrice: 165.00,
    unitCost: 52.00,
    fixedAllocatedCost: 15.00,
    baselineDemand: 510,
    elasticity: -1.45,
    elasticityStandardError: 0.11,
    inventoryOnHand: 920,
    replenishmentLeadDays: 35,
    holdingCostPerUnitWeek: 0.90,
    competitors: [
      { name: 'Nike Vaporfly Zoom', price: 179.99, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.97 },
      { name: 'Saucony Endorphin Pro', price: 159.00, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.94 },
    ],
    minPriceFloor: 129.00,
    maxPriceCeiling: 199.00,
    minMarginThreshold: 0.50,
    priceEnding: '.00',
    salesHistory: generateHistory(165.00, 52.00, 510, -1.45, 30),
    recommendedPrice: 169.00,
    status: 'CALCULATED',
    lastRepricedDate: '2026-10-20',
  },
  {
    id: 'prod-006',
    sku: 'APP-MER-HOOD',
    name: 'Fine Merino Wool Technical Zip Hoodie',
    category: 'Apparel & Footwear',
    currentPrice: 120.00,
    unitCost: 41.50,
    fixedAllocatedCost: 8.50,
    baselineDemand: 380,
    elasticity: -1.30,
    elasticityStandardError: 0.09,
    inventoryOnHand: 440,
    replenishmentLeadDays: 28,
    holdingCostPerUnitWeek: 0.50,
    competitors: [
      { name: 'Icebreaker RealFleece', price: 135.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.91 },
      { name: 'Smartwool Thermal Zip', price: 118.00, lastObserved: '2026-11-05', inStock: true, reliabilityScore: 0.93 },
    ],
    minPriceFloor: 89.00,
    maxPriceCeiling: 150.00,
    minMarginThreshold: 0.45,
    priceEnding: '.00',
    salesHistory: generateHistory(120.00, 41.50, 380, -1.30, 30),
    recommendedPrice: 128.00,
    status: 'CALCULATED',
    lastRepricedDate: '2026-10-18',
  },
  {
    id: 'prod-007',
    sku: 'APP-DNM-SLM',
    name: 'Selvedge Organic Indigo Raw Denim Jeans',
    category: 'Apparel & Footwear',
    currentPrice: 98.00,
    unitCost: 34.00,
    fixedAllocatedCost: 6.00,
    baselineDemand: 620,
    elasticity: -1.72,
    elasticityStandardError: 0.13,
    inventoryOnHand: 1100,
    replenishmentLeadDays: 25,
    holdingCostPerUnitWeek: 0.40,
    competitors: [
      { name: 'Nudie Lean Dean', price: 110.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.95 },
      { name: 'Unbranded 201', price: 88.00, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.89 },
    ],
    minPriceFloor: 75.00,
    maxPriceCeiling: 125.00,
    minMarginThreshold: 0.45,
    priceEnding: '.00',
    salesHistory: generateHistory(98.00, 34.00, 620, -1.72, 30),
    recommendedPrice: 95.00,
    status: 'PENDING_REVIEW',
    lastRepricedDate: '2026-10-25',
  },

  // 3. Specialty Food & Beverage (Perishable)
  {
    id: 'prod-008',
    sku: 'FNB-ETH-ROAST',
    name: 'Ethiopian Yirgacheffe Single-Origin Beans (1kg)',
    category: 'Specialty Food & Beverage',
    currentPrice: 28.50,
    unitCost: 11.40,
    fixedAllocatedCost: 2.10,
    baselineDemand: 850,
    elasticity: -1.55,
    elasticityStandardError: 0.10,
    inventoryOnHand: 650,
    replenishmentLeadDays: 7,
    holdingCostPerUnitWeek: 0.25,
    shelfLifeDays: 45,
    competitors: [
      { name: 'Origin Special Roast', price: 29.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.96 },
      { name: 'Blue Bottle Single', price: 32.00, lastObserved: '2026-11-05', inStock: true, reliabilityScore: 0.92 },
      { name: 'Union Coffee Roasters', price: 27.50, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.94 },
    ],
    minPriceFloor: 21.00,
    maxPriceCeiling: 36.00,
    minMarginThreshold: 0.40,
    priceEnding: '.50',
    salesHistory: generateHistory(28.50, 11.40, 850, -1.55, 30),
    recommendedPrice: 29.50,
    status: 'CALCULATED',
    lastRepricedDate: '2026-11-01',
  },
  {
    id: 'prod-009',
    sku: 'FNB-MAT-CER',
    name: 'Uji Ceremonial Grade Matcha Powder (100g)',
    category: 'Specialty Food & Beverage',
    currentPrice: 38.00,
    unitCost: 14.80,
    fixedAllocatedCost: 3.20,
    baselineDemand: 410,
    elasticity: -1.22,
    elasticityStandardError: 0.08,
    inventoryOnHand: 320,
    replenishmentLeadDays: 14,
    holdingCostPerUnitWeek: 0.30,
    shelfLifeDays: 90,
    competitors: [
      { name: 'Ippodo Sayaka', price: 42.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.97 },
      { name: 'Marukyu Koyamaen', price: 39.50, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.95 },
    ],
    minPriceFloor: 28.00,
    maxPriceCeiling: 48.00,
    minMarginThreshold: 0.45,
    priceEnding: '.00',
    salesHistory: generateHistory(38.00, 14.80, 410, -1.22, 30),
    recommendedPrice: 41.00,
    status: 'APPROVED',
    lastRepricedDate: '2026-10-22',
  },
  {
    id: 'prod-010',
    sku: 'FNB-OLV-XVRG',
    name: 'Estate Cold-Pressed Extra Virgin Olive Oil (750ml)',
    category: 'Specialty Food & Beverage',
    currentPrice: 22.00,
    unitCost: 8.90,
    fixedAllocatedCost: 1.80,
    baselineDemand: 980,
    elasticity: -1.68,
    elasticityStandardError: 0.12,
    inventoryOnHand: 1400,
    replenishmentLeadDays: 14,
    holdingCostPerUnitWeek: 0.20,
    shelfLifeDays: 180,
    competitors: [
      { name: 'Frantoio Muraglia', price: 24.50, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.93 },
      { name: 'Castillo de Canena', price: 21.00, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.96 },
    ],
    minPriceFloor: 16.00,
    maxPriceCeiling: 28.00,
    minMarginThreshold: 0.40,
    priceEnding: '.00',
    salesHistory: generateHistory(22.00, 8.90, 980, -1.68, 30),
    recommendedPrice: 21.50,
    status: 'PUBLISHED',
    lastRepricedDate: '2026-11-04',
  },

  // 4. Hospitality & Rooms
  {
    id: 'prod-011',
    sku: 'HOSP-DEL-KNG',
    name: 'Executive Deluxe King Suite (Weekend Night)',
    category: 'Hospitality & Rooms',
    currentPrice: 280.00,
    unitCost: 65.00,
    fixedAllocatedCost: 45.00,
    baselineDemand: 84, // rooms booked
    elasticity: -1.75,
    elasticityStandardError: 0.13,
    inventoryOnHand: 120, // total room capacity
    replenishmentLeadDays: 0,
    holdingCostPerUnitWeek: 0.0,
    competitors: [
      { name: 'Grand Central Landmark', price: 295.00, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.98 },
      { name: 'The Savoy Boutique', price: 310.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.95 },
      { name: 'Metropolitan Design Hotel', price: 265.00, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.92 },
    ],
    minPriceFloor: 180.00,
    maxPriceCeiling: 420.00,
    minMarginThreshold: 0.50,
    priceEnding: '.00',
    salesHistory: generateHistory(280.00, 65.00, 84, -1.75, 30),
    recommendedPrice: 295.00,
    status: 'CALCULATED',
    lastRepricedDate: '2026-11-05',
  },
  {
    id: 'prod-012',
    sku: 'HOSP-STD-QUN',
    name: 'Superior Queen City Room (Midweek Night)',
    category: 'Hospitality & Rooms',
    currentPrice: 175.00,
    unitCost: 42.00,
    fixedAllocatedCost: 35.00,
    baselineDemand: 160,
    elasticity: -2.10,
    elasticityStandardError: 0.16,
    inventoryOnHand: 200,
    replenishmentLeadDays: 0,
    holdingCostPerUnitWeek: 0.0,
    competitors: [
      { name: 'CitizenM City Centre', price: 169.00, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.97 },
      { name: 'Apex Temple Place', price: 185.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.94 },
    ],
    minPriceFloor: 120.00,
    maxPriceCeiling: 250.00,
    minMarginThreshold: 0.45,
    priceEnding: '.00',
    salesHistory: generateHistory(175.00, 42.00, 160, -2.10, 30),
    recommendedPrice: 165.00,
    status: 'PENDING_REVIEW',
    lastRepricedDate: '2026-10-31',
  },

  // 5. SaaS & Subscriptions
  {
    id: 'prod-013',
    sku: 'SAAS-PRO-MTH',
    name: 'Growth Tier Professional Seat (Monthly)',
    category: 'SaaS & Subscriptions',
    currentPrice: 49.00,
    unitCost: 6.20,
    fixedAllocatedCost: 4.80,
    baselineDemand: 2450,
    elasticity: -1.15,
    elasticityStandardError: 0.07,
    inventoryOnHand: 99999,
    replenishmentLeadDays: 0,
    holdingCostPerUnitWeek: 0.0,
    competitors: [
      { name: 'Mixpanel Growth', price: 55.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.99 },
      { name: 'Amplitude Starter Plus', price: 49.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.99 },
      { name: 'Heap Scale', price: 60.00, lastObserved: '2026-11-05', inStock: true, reliabilityScore: 0.90 },
    ],
    minPriceFloor: 35.00,
    maxPriceCeiling: 79.00,
    minMarginThreshold: 0.70,
    priceEnding: '.00',
    salesHistory: generateHistory(49.00, 6.20, 2450, -1.15, 30),
    recommendedPrice: 54.00,
    status: 'APPROVED',
    lastRepricedDate: '2026-10-10',
  },
  {
    id: 'prod-014',
    sku: 'SAAS-ENT-ANN',
    name: 'Enterprise Dedicated Instance (Annual Contract/mo)',
    category: 'SaaS & Subscriptions',
    currentPrice: 450.00,
    unitCost: 48.00,
    fixedAllocatedCost: 35.00,
    baselineDemand: 180,
    elasticity: -0.85,
    elasticityStandardError: 0.06,
    inventoryOnHand: 99999,
    replenishmentLeadDays: 0,
    holdingCostPerUnitWeek: 0.0,
    competitors: [
      { name: 'Datadog Enterprise Pro', price: 490.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.98 },
      { name: 'New Relic High Velocity', price: 420.00, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.95 },
    ],
    minPriceFloor: 350.00,
    maxPriceCeiling: 650.00,
    minMarginThreshold: 0.75,
    priceEnding: '.00',
    salesHistory: generateHistory(450.00, 48.00, 180, -0.85, 30),
    recommendedPrice: 495.00,
    status: 'CALCULATED',
    lastRepricedDate: '2026-09-30',
  },

  // 6. Industrial Supplies
  {
    id: 'prod-015',
    sku: 'IND-VALV-316L',
    name: '316L Stainless Steel Sanitary Butterfly Valve (2-inch)',
    category: 'Industrial Supplies',
    currentPrice: 145.00,
    unitCost: 62.00,
    fixedAllocatedCost: 14.00,
    baselineDemand: 290,
    elasticity: -1.20,
    elasticityStandardError: 0.08,
    inventoryOnHand: 580,
    replenishmentLeadDays: 30,
    holdingCostPerUnitWeek: 0.75,
    competitors: [
      { name: 'Swagelok SS-Series', price: 165.00, lastObserved: '2026-11-05', inStock: true, reliabilityScore: 0.98 },
      { name: 'Spirax Sarco BV2', price: 152.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.94 },
    ],
    minPriceFloor: 110.00,
    maxPriceCeiling: 185.00,
    minMarginThreshold: 0.40,
    priceEnding: '.00',
    salesHistory: generateHistory(145.00, 62.00, 290, -1.20, 30),
    recommendedPrice: 155.00,
    status: 'CALCULATED',
    lastRepricedDate: '2026-10-12',
  },
  {
    id: 'prod-016',
    sku: 'IND-BRG-6204',
    name: 'Deep Groove Ball Bearing 6204-2RS (Box of 10)',
    category: 'Industrial Supplies',
    currentPrice: 48.50,
    unitCost: 17.20,
    fixedAllocatedCost: 3.50,
    baselineDemand: 740,
    elasticity: -1.90,
    elasticityStandardError: 0.14,
    inventoryOnHand: 1850,
    replenishmentLeadDays: 20,
    holdingCostPerUnitWeek: 0.22,
    competitors: [
      { name: 'SKF Explorer 6204', price: 52.00, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.98 },
      { name: 'NSK Precision 2RS', price: 47.00, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.96 },
    ],
    minPriceFloor: 35.00,
    maxPriceCeiling: 65.00,
    minMarginThreshold: 0.45,
    priceEnding: '.50',
    salesHistory: generateHistory(48.50, 17.20, 740, -1.90, 30),
    recommendedPrice: 47.50,
    status: 'PUBLISHED',
    lastRepricedDate: '2026-11-02',
  },
];

// Dynamically generate the remaining 84 products to complete the full 100-product enterprise catalog
const CATEGORIES: ProductCategory[] = [
  'Consumer Tech',
  'Apparel & Footwear',
  'Specialty Food & Beverage',
  'Hospitality & Rooms',
  'SaaS & Subscriptions',
  'Industrial Supplies',
];

const PRODUCT_TEMPLATES: Record<ProductCategory, { names: string[]; prefix: string; priceRange: [number, number]; costRatio: number; elasticityRange: [number, number] }> = {
  'Consumer Tech': {
    prefix: 'TECH',
    names: [
      'MagSafe Power Bank 10,000mAh', 'Noise-Cancelling USB Microphone', 'Mini Projector 1080p LED',
      'Ergonomic Vertical Wireless Mouse', 'Smart LED Monitor Light Bar', 'Foldable 3-in-1 Charging Stand',
      'Thunderbolt 4 Docking Station 12-in-1', 'Portable SSD 2TB Rugged USB-C', 'Smart Home Zigbee Bridge Hub',
      'Spatial Audio Earbuds IPX8', 'High-Speed HDMI 2.1 Braided Cable', 'Magnetic iPad Stand Aluminum',
      'Webcam Ring Light Kit Bi-Color', 'Mechanical Switch Sample Pack',
    ],
    priceRange: [19.99, 189.99],
    costRatio: 0.38,
    elasticityRange: [-1.6, -2.4],
  },
  'Apparel & Footwear': {
    prefix: 'APP',
    names: [
      'Waterproof Trail Gore-Tex Jacket', 'Breathable Bamboo Crew Socks (5-pk)', 'Thermal Base Layer Merino Top',
      'Polarized Aviator Titanium Sunglasses', 'Heritage Canvas Duffel Bag 45L', 'All-Weather Commuter Trench Coat',
      'Lightweight Packable Windbreaker', 'Seamless Performance Yoga Leggings', 'Italian Nappa Leather Dress Belt',
      'Heavyweight Cotton Boxy Tee', 'Quick-Dry Tactical Cargo Shorts', 'Merino Wool Beanie Ribbed',
      'Water-Resistant Laptop Backpack', 'Handcrafted Leather Chelsea Boots',
    ],
    priceRange: [25.00, 220.00],
    costRatio: 0.35,
    elasticityRange: [-1.2, -1.8],
  },
  'Specialty Food & Beverage': {
    prefix: 'FNB',
    names: [
      'Artisanal Sourdough Starter Kit', 'Raw Manuka Honey MGO 550+ (250g)', 'Single-Estate Darjeeling 1st Flush',
      'Aged Modena Balsamic Vinegar 12yr', 'Dark Chocolate Madagascar 85% (3-pk)', 'Cold-Pressed Sicilian Pistachio Butter',
      'Organic Ceremonial Sencha Green Tea', 'Wild Truffle Infused Sea Salt', 'Cold Brew Nitro Concentrate Keg 5L',
      'Non-Alcoholic Botanical Botanical Spirit', 'Fermented Kimchi Handcrafted Glass Jar', 'Himalayan Pink Rock Salt Grinder',
      'Smoked Chipotle Artisan Hot Sauce', 'Single-Origin Guatamalan Cacao Nibs',
    ],
    priceRange: [9.50, 48.00],
    costRatio: 0.42,
    elasticityRange: [-1.3, -2.1],
  },
  'Hospitality & Rooms': {
    prefix: 'HOSP',
    names: [
      'Panoramic Penthouse Suite (Midweek)', 'Riverside Junior Suite (Weekend)', 'Standard Double City View (Weekday)',
      'Garden Villa with Private Plunge Pool', 'Boutique Courtyard Room (Sunday)', 'Executive Club Room with Lounge Access',
      'Accessible King Studio (Weekly Rate)', 'Historic Tower Suite (Holiday Peak)', 'Modern Micro-Room Solo Traveler',
      'Family Adjoining Suite (School Break)', 'Penthouse Terrace Jacuzzi Suite', 'Heritage Classic Room (Breakfast Inc)',
      'Skyline View Corner Room', 'Wellness Spa Suite with Sauna',
    ],
    priceRange: [110.00, 550.00],
    costRatio: 0.28,
    elasticityRange: [-1.5, -2.3],
  },
  'SaaS & Subscriptions': {
    prefix: 'SAAS',
    names: [
      'Analytics Starter Tier (Monthly)', 'Team Collaboration Seat (Annual/mo)', 'Security & Compliance Addon',
      'API Usage Overage Block (1M req)', 'Custom Domain SSO Identity Tier', 'Priority 24/7 SLA Support Tier',
      'Advanced Audit & DLP Retention Vault', 'AI Token Pipeline Acceleration Pack', 'White-Label Portal License',
      'Developer Sandbox Multi-Cluster', 'CRM Two-Way Sync Connector Plan', 'Data Warehouse ETL Ingestion Pipeline',
      'Zero-Trust Network Access Gateway', 'Compliance Reporting SOC2 Generator',
    ],
    priceRange: [29.00, 750.00],
    costRatio: 0.15,
    elasticityRange: [-0.75, -1.35],
  },
  'Industrial Supplies': {
    prefix: 'IND',
    names: [
      'Pneumatic Quick-Connect Coupler 1/4"', 'Tungsten Carbide End Mill 4-Flute', 'Heavy-Duty C-Clamp Forged Steel 8"',
      'EPDM High-Temp O-Ring Assortment', 'Digital Caliper IP67 Stainless Steel', 'Vibration Damping Mount M10 (4-pk)',
      'PTFE Thread Seal Tape Industrial 10-pk', 'LED Explosion-Proof Work Light', 'Linear Motion Guide Rail 1000mm',
      'Hydraulic Hose Assembly 5000 PSI', 'Torque Wrench Dual-Direction 1/2"', 'Zinc-Plated Hex Cap Screw Grade 8 (100-pk)',
      'Laser Distance Measurer 100m Class 2', 'Nitrile Chemical Resistant Gloves (100-ct)',
    ],
    priceRange: [18.00, 240.00],
    costRatio: 0.45,
    elasticityRange: [-1.05, -1.75],
  },
};

let currentId = 17;
for (const cat of CATEGORIES) {
  const meta = PRODUCT_TEMPLATES[cat];
  for (let i = 0; i < meta.names.length; i++) {
    const name = meta.names[i];
    const sku = `${meta.prefix}-${100 + i}`;
    const price = Number((meta.priceRange[0] + Math.random() * (meta.priceRange[1] - meta.priceRange[0])).toFixed(2));
    const cost = Number((price * meta.costRatio * (0.85 + Math.random() * 0.3)).toFixed(2));
    const elasticity = Number((meta.elasticityRange[0] + Math.random() * (meta.elasticityRange[1] - meta.elasticityRange[0])).toFixed(2));
    const baselineDemand = Math.floor(100 + Math.random() * 1200);
    const minFloor = Number((cost * 1.25).toFixed(2));
    const maxCeil = Number((price * 1.5).toFixed(2));
    const inventory = cat === 'SaaS & Subscriptions' ? 99999 : Math.floor(150 + Math.random() * 1800);

    const comp1 = Number((price * (0.92 + Math.random() * 0.16)).toFixed(2));
    const comp2 = Number((price * (0.90 + Math.random() * 0.20)).toFixed(2));

    const recDelta = (Math.random() - 0.4) * 0.15; // slightly positive bias
    const recPrice = Number(Math.max(minFloor, Math.min(maxCeil, price * (1 + recDelta))).toFixed(2));

    const statuses: Product['status'][] = ['CALCULATED', 'PENDING_REVIEW', 'APPROVED', 'PUBLISHED', 'DRAFT'];
    const status = statuses[Math.floor(Math.random() * statuses.length)];

    INITIAL_PRODUCTS.push({
      id: `prod-${String(currentId).padStart(3, '0')}`,
      sku,
      name,
      category: cat,
      currentPrice: price,
      unitCost: cost,
      fixedAllocatedCost: Number((cost * 0.2).toFixed(2)),
      baselineDemand,
      elasticity,
      elasticityStandardError: Number((0.08 + Math.random() * 0.08).toFixed(2)),
      inventoryOnHand: inventory,
      replenishmentLeadDays: cat === 'Hospitality & Rooms' || cat === 'SaaS & Subscriptions' ? 0 : Math.floor(7 + Math.random() * 28),
      holdingCostPerUnitWeek: Number((cost * 0.015).toFixed(2)),
      shelfLifeDays: cat === 'Specialty Food & Beverage' ? Math.floor(30 + Math.random() * 120) : undefined,
      competitors: [
        { name: `${name.split(' ')[0]} Direct Competitor`, price: comp1, lastObserved: '2026-11-06', inStock: true, reliabilityScore: 0.94 },
        { name: 'Market Alternate Brand', price: comp2, lastObserved: '2026-11-07', inStock: true, reliabilityScore: 0.91 },
      ],
      minPriceFloor: minFloor,
      maxPriceCeiling: maxCeil,
      minMarginThreshold: 0.35,
      priceEnding: '.00',
      salesHistory: generateHistory(price, cost, baselineDemand, elasticity, 30),
      recommendedPrice: recPrice,
      status,
      lastRepricedDate: `2026-10-${Math.floor(10 + Math.random() * 20)}`,
    });

    currentId++;
    if (INITIAL_PRODUCTS.length >= 100) break;
  }
  if (INITIAL_PRODUCTS.length >= 100) break;
}

/**
 * Generate 30 daily realistic historical points with elasticity-grounded price shifts,
 * weekend demand peaks, and competitor observations
 */
function generateHistory(
  basePrice: number,
  cost: number,
  weeklyDemand: number,
  elasticity: number,
  days: number = 30
) {
  const dailyBase = weeklyDemand / 7;
  const history = [];
  const today = new Date('2026-11-07');

  for (let d = days; d >= 1; d--) {
    const date = new Date(today);
    date.setDate(date.getDate() - d);
    const dow = date.getDay(); // 0 is Sun, 6 is Sat
    const weekendMultiplier = (dow === 0 || dow === 6) ? 1.35 : (dow === 5 ? 1.15 : 0.92);

    // Random slight price experimentation in past
    const priceShock = (d % 8 === 0) ? (Math.random() > 0.5 ? 1.05 : 0.95) : 1.0;
    const pastPrice = Number((basePrice * priceShock).toFixed(2));

    // Demand based on elasticity + day-of-week + noise
    const priceRatio = pastPrice / basePrice;
    const elasticityEffect = Math.pow(priceRatio, elasticity);
    const noise = 0.92 + Math.random() * 0.16;

    const unitsSold = Math.max(1, Math.round(dailyBase * weekendMultiplier * elasticityEffect * noise));
    const compMedian = Number((pastPrice * (0.95 + Math.random() * 0.10)).toFixed(2));

    history.push({
      date: date.toISOString().split('T')[0],
      price: pastPrice,
      cost: cost,
      unitsSold,
      isPromo: priceShock < 0.98,
      competitorMedian: compMedian,
    });
  }

  return history;
}
