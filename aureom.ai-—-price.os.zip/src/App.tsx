/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PricingProvider, usePricing } from './context/PricingContext';
import { Sidebar } from './components/layout/Sidebar';
import { TopBar } from './components/layout/TopBar';

// Views
import { OverviewDashboard } from './components/views/OverviewDashboard';
import { QuickCalculator } from './components/views/QuickCalculator';
import { DynamicPricingEngine } from './components/views/DynamicPricingEngine';
import { DemandForecastingView } from './components/views/DemandForecastingView';
import { ElasticityLabView } from './components/views/ElasticityLabView';
import { CompetitorAnalysisView } from './components/views/CompetitorAnalysisView';
import { CostMarginWaterfallView } from './components/views/CostMarginWaterfallView';
import { OptimisationEngineView } from './components/views/OptimisationEngineView';
import { ScenarioLabView } from './components/views/ScenarioLabView';
import { InventoryPricingView } from './components/views/InventoryPricingView';
import { PromotionsEngineView } from './components/views/PromotionsEngineView';
import { ProductPortfolioView } from './components/views/ProductPortfolioView';
import { PriceExperimentsView } from './components/views/PriceExperimentsView';
import { RecommendationsQueueView } from './components/views/RecommendationsQueueView';
import { ReportsExportView } from './components/views/ReportsExportView';
import { DataManagementView } from './components/views/DataManagementView';
import { AdministrationView } from './components/views/AdministrationView';
import { SettingsView } from './components/views/SettingsView';
import { RSourceCodeView } from './components/views/RSourceCodeView';

const MainContent: React.FC = () => {
  const { activeNav } = usePricing();

  const renderView = () => {
    switch (activeNav) {
      case 'overview':
        return <OverviewDashboard />;
      case 'quick_calc':
        return <QuickCalculator />;
      case 'dynamic_engine':
        return <DynamicPricingEngine />;
      case 'forecasting':
        return <DemandForecastingView />;
      case 'elasticity':
        return <ElasticityLabView />;
      case 'competitors':
        return <CompetitorAnalysisView />;
      case 'cost_margin':
        return <CostMarginWaterfallView />;
      case 'optimisation':
        return <OptimisationEngineView />;
      case 'scenario_lab':
        return <ScenarioLabView />;
      case 'inventory':
        return <InventoryPricingView />;
      case 'promotions':
        return <PromotionsEngineView />;
      case 'portfolio':
        return <ProductPortfolioView />;
      case 'experiments':
        return <PriceExperimentsView />;
      case 'recommendations':
        return <RecommendationsQueueView />;
      case 'reports':
        return <ReportsExportView />;
      case 'data_mgmt':
        return <DataManagementView />;
      case 'admin':
        return <AdministrationView />;
      case 'settings':
        return <SettingsView />;
      case 'r_source':
        return <RSourceCodeView />;
      default:
        return <OverviewDashboard />;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-slate-950 text-slate-100">
      {renderView()}
    </div>
  );
};

export default function App() {
  return (
    <PricingProvider>
      <div className="flex h-screen w-screen overflow-hidden bg-slate-950 font-sans text-slate-100">
        <Sidebar />
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <TopBar />
          <MainContent />
        </div>
      </div>
    </PricingProvider>
  );
}
