package com.example.petrotrade.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.petrotrade.model.*
import com.example.petrotrade.model.engine.PetroTradeEngine
import java.math.BigDecimal

@Composable
fun InventoryScreen() {
    val state by PetroTradeEngine.state.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Storage, contentDescription = null, tint = Color(0xFF0284C7))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TERMINAL- & TANKLAGERBESTÄNDE",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Wichtig: VERFÜGBARE MENGE ≠ GESAMTBESTAND (Berücksichtigt vertragliche Reservierungen)",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFF59E0B)
                    )
                }
            }
        }

        items(state.terminals) { terminal ->
            TerminalCard(terminal = terminal)
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.AssignmentTurnedIn, contentDescription = null, tint = Color(0xFF10B981))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Physikalische Produktchargen & Qualitätszertifikate",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Demo Chargen / Physical Batches list
        items(state.allocations) { alloc ->
            alloc.allokationen.forEach { ta ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Charge: ${ta.chargenId ?: "CH-2026-DIESEL-091"}",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8),
                                fontFamily = FontFamily.Monospace
                            )
                            StatusBadge(statusText = "FREIGEGEBEN (SGS Labor)", isSuccess = true)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Lagerort: ${ta.terminalName} (${ta.tankId})", fontSize = 12.sp, color = Color.White)
                        Text(text = "Allokierte Menge: ${ta.allokierteMengeMT} MT | Prüfergebnis: ISO/IEC 17025 Konform", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalCard(terminal: Terminal) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = terminal.name,
                style = MaterialTheme.typography.titleSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${terminal.standort} • Gesamt Verfügbar: ${terminal.gesamtVerfuegbarMT} MT",
                fontSize = 12.sp,
                color = Color(0xFF38BDF8)
            )

            Spacer(modifier = Modifier.height(10.dp))

            terminal.tanks.forEach { tank ->
                TankGaugeRow(tank = tank)
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun TankGaugeRow(tank: Tank) {
    val gesamt = tank.gesamtbestandMT.toFloat().coerceAtLeast(1f)
    val reserviert = tank.reservierteMengeMT.toFloat()
    val verfuegbar = tank.verfuegbareMengeMT.toFloat()

    val verfuegbarRatio = (verfuegbar / gesamt).coerceIn(0f, 1f)
    val reserviertRatio = (reserviert / gesamt).coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = tank.tankName, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(
                text = "${tank.verfuegbareMengeMT} MT frei",
                fontSize = 12.sp,
                color = Color(0xFF10B981),
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Progress Bar (Green = Available, Amber = Reserved, Gray = Empty)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(Color(0xFF334155))
        ) {
            if (verfuegbarRatio > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(verfuegbarRatio)
                        .background(Color(0xFF10B981))
                )
            }
            if (reserviertRatio > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(reserviertRatio)
                        .background(Color(0xFFF59E0B))
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "Gesamtbestand: ${tank.gesamtbestandMT} MT", fontSize = 10.sp, color = Color(0xFF94A3B8))
            Text(text = "Reserviert: ${tank.reservierteMengeMT} MT", fontSize = 10.sp, color = Color(0xFFF59E0B))
        }
    }
}
