package com.example.petrotrade.model

enum class DealStatus(val displayName: String) {
    BESTAETIGT("Bestätigt"),
    IN_ALLOKATION("In Allokation"),
    DISPONIERT("Disponiert"),
    GELIEFERT("Geliefert"),
    ABGESCHLOSSEN("Abgeschlossen"),
    STORNIERT("Storniert")
}

data class Deal(
    val geschaeftId: String,               // z.B. "GES-2026-001982"
    val angebotId: String,                 // z.B. "ANG-2026-000184"
    val kundeId: String,
    val kundenName: String,
    val status: DealStatus,
    val preisSnapshot: QuoteSnapshot,
    val gesamtwert: Money,
    val erstellerUser: String,
    val erstellerZeitstempel: String,
    val idempotencyKey: String,
    val correlationId: String
)

enum class IncotermCode(val code: String, val fullName: String) {
    EXW("EXW", "Ex Works (Ab Werk)"),
    FCA("FCA", "Free Carrier (Frei Frachtführer)"),
    FOB("FOB", "Free On Board (Frei an Bord)"),
    CFR("CFR", "Cost and Freight (Kosten und Fracht)"),
    CIF("CIF", "Cost, Insurance and Freight (Kosten, Versicherung und Fracht)"),
    CPT("CPT", "Carriage Paid To (Frachtfrei)"),
    CIP("CIP", "Carriage and Insurance Paid To (Frachtfrei versichert)"),
    DAP("DAP", "Delivered At Place (Geliefert benannter Ort)"),
    DPU("DPU", "Delivered at Place Unloaded (Geliefert entladen)"),
    DDP("DDP", "Delivered Duty Paid (Geliefert verzollt)")
}

data class IncotermRuleInfo(
    val code: IncotermCode,
    val transportOrganisator: String,  // "Käufer" oder "Verkäufer"
    val kostentraeger: String,          // Wer trägt Fracht- & Nebenkosten
    val risikoUebergang: String,       // Wann geht Gefahr / Risiko über
    val lieferortRelevanz: String       // Welcher Ort ist vertraglich bindend
)

object IncotermsMatrix {
    private val rulesMap = mapOf(
        IncotermCode.EXW to IncotermRuleInfo(IncotermCode.EXW, "Käufer", "Käufer trägt alle Transport- & Verladekosten ab Werk", "Abhol-Raffinerie / Tanklager bei Bereitstellung", "Raffinerietor / Abholterminal"),
        IncotermCode.FOB to IncotermRuleInfo(IncotermCode.FOB, "Käufer ab Schiff / Verkäufer bis Verladung", "Käufer zahlt Hauptseetransport", "An Bord des Schiffs im Verladehafen", "Schiffskopplung im Verladehafen"),
        IncotermCode.CIF to IncotermRuleInfo(IncotermCode.CIF, "Verkäufer organisiert Seetransport & Seeversicherung", "Verkäufer trägt Fracht & Seeversicherung bis Bestimmungshafen", "An Bord im Verladehafen (Schiffskopplung)", "Bestimmungshafen / Löschterminal"),
        IncotermCode.DAP to IncotermRuleInfo(IncotermCode.DAP, "Verkäufer", "Verkäufer trägt alle Transportkosten bis Bestimmungsort unentladen", "Bei Ankunft am Bestimmungsort vor Entladung", "Kunden-Tanklager / Zielterminal"),
        IncotermCode.DDP to IncotermRuleInfo(IncotermCode.DDP, "Verkäufer", "Verkäufer trägt Transport, Einfuhrabgaben & Steuern komplett", "Bei Übergabe am Zielort verzollt", "Kundenlager / Empfangsstelle")
    )

    fun getInfo(codeStr: String): IncotermRuleInfo {
        val enumCode = try { IncotermCode.valueOf(codeStr.uppercase()) } catch (e: Exception) { IncotermCode.DAP }
        return rulesMap[enumCode] ?: IncotermRuleInfo(enumCode, "Verkäufer", "Kosten gemäß Sondervereinbarung", "Bei Übergabe", "Zielort")
    }
}

enum class ContractStatus(val displayName: String) {
    VERTRAG_ENTWURF("Vertrag im Entwurf"),
    RECHTSGUELTIG("Rechtsgültig Gezeichnet"),
    IN_ERFUELLUNG("In Erfüllung"),
    ERFUELLT("Vollständig Erfüllt"),
    STORNIERT("Storniert")
}

data class Contract(
    val vertragsNummer: String,            // z.B. "VT-2026-88392"
    val geschaeftId: String,
    val kaeufer: String,                   // Käufer Firmenname / Legal Entity
    val verkaeufer: String,                // Verkäufer Firmenname (z.B. PetroTrade Global S.A.)
    val produktName: String,
    val menge: Quantity,
    val vereinbarterPreis: Money,
    val preisformelHinweis: String,
    val waehrung: String,
    val incoterm: IncotermCode,
    val lieferort: String,
    val lieferfenster: DeliveryWindow,
    val qualitaetsAnforderungen: String,   // z.B. "Gemäß Spezifikation EN 590 max 10 ppm Schwefel"
    val zahlungsBedingungen: String,       // z.B. "30 Tage netto nach Rechnungsstellung"
    val eigentumsUebergang: String,        // z.B. "Eigentum geht nach vollständiger Bezahlung über"
    val risikoTransfer: String,            // z.B. "Gefahrenübergang gemäß DAP Hamburg Incoterms 2020"
    val vertragsStatus: ContractStatus,
    val erstellungsDatum: String
)
