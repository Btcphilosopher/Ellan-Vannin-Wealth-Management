package com.example.petrotrade.model

import java.math.BigDecimal

enum class InvoiceStatus(val displayName: String) {
    ENTWURF("Rechnungsentwurf"),
    AUSGESTELLT("Offene Rechnung"),
    PARTIELL_BEZAHLT("Teilweise Bezahlt"),
    BEZAHLT("Vollständig Beglichen"),
    UEBERBEZAHLT("Überbezahlt"),
    MAHNUNG("In Mahnung"),
    STORNIERT("Storniert")
}

data class PaymentTerms(
    val termsCode: String,              // z.B. "NET_30"
    val bezeichnung: String,             // z.B. "30 Tage netto nach Rechnungsdatum"
    val tageNetto: Int = 30,
    val skontoProzent: BigDecimal = BigDecimal.ZERO,
    val skontoTage: Int = 0
)

data class Invoice(
    val rechnungsNummer: String,         // z.B. "REC-2026-100293"
    val lieferungsId: String,
    val vertragId: String,
    val geschaeftId: String,
    val kundeId: String,
    val empfaengerLegalEntity: String,
    val nettowert: Money,
    val steuernBetrag: Money,            // z.B. 19% MwSt. oder Steuerbefreit nach Innergemeinschaftlicher Lieferung
    val zuschlaegeBetrag: Money,
    val rabatteBetrag: Money,
    val gesamtbetrag: Money,
    val offenBetrag: Money,
    val waehrung: String,
    val rechnungsDatum: String,
    val zahlungsZielDatum: String,
    val paymentTerms: PaymentTerms,
    val status: InvoiceStatus
)

data class Payment(
    val zahlungsId: String,              // z.B. "ZHL-2026-55012"
    val rechnungsNummer: String,
    val betrag: Money,
    val zahlungsDatum: String,
    val buchungsReferenz: String,       // z.B. "BANK-REF-9938120"
    val zahlungsArt: String              // "SEPA_OVERNIGHT", "SWIFT_WIRE", "LETTER_OF_CREDIT"
)

enum class SettlementDiscrepancyType(val displayName: String) {
    KEINE("Keine Differenz"),
    UNTERZAHLUNG("Unterzahlung (Offener Restbetrag)"),
    UEBERZAHLUNG("Überzahlung (Guthaben)"),
    QUALITAETS_REKLAMATION("Qualitäts-/Mengenreklamation"),
    SKONTO_ABZUG("Berechtigter Skontoabzug")
}

data class Settlement(
    val abrechnungsId: String,           // z.B. "SET-2026-00481"
    val rechnungsNummer: String,
    val kundeId: String,
    val kundenName: String,
    val rechnungsBetrag: Money,
    val erfassteZahlungen: List<Payment>,
    val kumulierteZahlungen: Money,
    val verbleibenderOffenerBetrag: Money,
    val differenzTyp: SettlementDiscrepancyType,
    val statusText: String
)
