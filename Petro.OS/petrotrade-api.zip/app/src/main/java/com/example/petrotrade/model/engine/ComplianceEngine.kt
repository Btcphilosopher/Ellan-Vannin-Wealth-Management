package com.example.petrotrade.model.engine

import com.example.petrotrade.model.*
import java.math.BigDecimal

object ComplianceEngine {

    fun pruefeGeschaeftCompliance(
        kunde: Customer,
        handelswert: Money,
        lieferlandIso: String = "DE",
        aktuellerBenutzerRole: UserRole = UserRole.TRADER
    ): ComplianceCheckResult {
        val abweichungen = mutableListOf<String>()

        // 1. KYC / KYB Prüfung
        val kycOk = kunde.kycStatus == "VERIFIZIERT"
        if (!kycOk) {
            abweichungen.add("Kunde ${kunde.firmenname} ist KYC-seitig nicht verifiziert (Status: ${kunde.kycStatus}).")
        }

        // 2. Länderrestriktion / Sanktionsliste
        val laenderOk = !kunde.laenderSperre && lieferlandIso.uppercase() !in listOf("RU", "IR", "KP", "SY")
        if (!laenderOk) {
            abweichungen.add("Sanktions- / Exportkontroll-Sperre für Land $lieferlandIso oder Kunde.")
        }

        // 3. Kreditlimit-Prüfung
        val verfuegbar = kunde.creditLimitInfo.verfuegbarerKredit
        val kreditOk = verfuegbar.amount >= handelswert.amount
        if (!kreditOk) {
            abweichungen.add("Handelswert (${handelswert.formatted()}) übersteigt verfügbares Kreditlimit (${verfuegbar.formatted()}).")
        }

        // 4. Risikolimit & Vier-Augen-Prinzip
        val betragEur = handelswert.amount.toDouble()
        val approvalLevel = when {
            betragEur < 100000.0 -> ApprovalLevel.AUTOMATISCH
            betragEur <= 1000000.0 -> ApprovalLevel.MANAGER_FREIGEGEBEN
            else -> ApprovalLevel.VIER_AUGEN_PRINZIP
        }

        // Status bestimmen
        val status = when {
            !kycOk || !laenderOk -> ComplianceStatus.GESCHAEFT_BLOCKIERT
            !kreditOk -> ComplianceStatus.MANUELLE_PRUEFUNG
            approvalLevel == ApprovalLevel.VIER_AUGEN_PRINZIP -> ComplianceStatus.MANUELLE_PRUEFUNG
            else -> ComplianceStatus.FREIGEGEBEN
        }

        return ComplianceCheckResult(
            pruefungsId = "COMP-2026-${(1000..9999).random()}",
            kundeId = kunde.id,
            kundenName = kunde.firmenname,
            handelswertEUR = handelswert,
            kycValidiert = kycOk,
            sanktionslisteOK = laenderOk,
            exportKontrolleOK = laenderOk,
            laenderRestriktionOK = laenderOk,
            kreditlimitHerangezogen = true,
            kreditlimitAusreichend = kreditOk,
            erforderlichesFreigabeLevel = approvalLevel,
            status = status,
            abweichungsGruende = abweichungen,
            erstelltAm = java.time.Instant.now().toString()
        )
    }
}
