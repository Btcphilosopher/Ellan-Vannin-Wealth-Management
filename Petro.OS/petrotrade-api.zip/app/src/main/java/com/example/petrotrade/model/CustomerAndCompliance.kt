package com.example.petrotrade.model

enum class ComplianceStatus(val displayName: String) {
    FREIGEGEBEN("Freigegeben (Compliance Passed)"),
    MANUELLE_PRUEFUNG("Manuelle Compliance-Prüfung Erforderlich"),
    GESCHAEFT_BLOCKIERT("Geschäft Blockiert (Sanktion / Limit Exceeded)")
}

enum class ApprovalLevel(val displayName: String, val thresholdEUR: Double) {
    AUTOMATISCH("Automatische Freigabe", 100000.0),
    MANAGER_FREIGEGEBEN("Manager-Freigabe Erforderlich", 1000000.0),
    VIER_AUGEN_PRINZIP("Vier-Augen-Prinzip (Trader + Risk Officer)", Double.MAX_VALUE)
}

data class ComplianceCheckResult(
    val pruefungsId: String,               // z.B. "COMP-2026-8812"
    val kundeId: String,
    val kundenName: String,
    val handelswertEUR: Money,
    val kycValidiert: Boolean = true,
    val sanktionslisteOK: Boolean = true,
    val exportKontrolleOK: Boolean = true,
    val laenderRestriktionOK: Boolean = true,
    val kreditlimitHerangezogen: Boolean = true,
    val kreditlimitAusreichend: Boolean = true,
    val erforderlichesFreigabeLevel: ApprovalLevel,
    val status: ComplianceStatus,
    val abweichungsGruende: List<String> = emptyList(),
    val erstelltAm: String
)

data class CreditLimitInfo(
    val gesamtKreditlimit: Money,
    val offeneForderungen: Money,
    val reservierterHandelswert: Money
) {
    val verfuegbarerKredit: Money
        get() = (gesamtKreditlimit - offeneForderungen) - reservierterHandelswert
}

data class Customer(
    val id: String,                         // z.B. "K-10024"
    val firmenname: String,                 // z.B. "DEMO ENERGY GMBH"
    val legalEntity: String,                // z.B. "DEMO Energy Handels GmbH & Co. KG"
    val ustIdNr: String,                    // z.B. "DE812345679"
    val landIso: String,                    // z.B. "DE"
    val billingAccountNo: String,           // z.B. "ACC-DE-99210"
    val creditLimitInfo: CreditLimitInfo,
    val paymentTerms: PaymentTerms,
    val kycStatus: String = "VERIFIZIERT",
    val laenderSperre: Boolean = false,
    val priceAgreements: List<String> = listOf("DIESEL_EN590_STANDARD_FORMULA")
)
