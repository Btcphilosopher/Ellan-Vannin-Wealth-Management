package com.example.petrotrade.model

enum class AuditEventType(val displayName: String) {
    ANGEBOT_ERSTELLT("Angebot Erstellt"),
    ANGEBOT_GEAENDERT("Angebot Geändert"),
    ANGEBOT_ANGENOMMEN("Angebot Vom Kunden Angenommen"),
    GESCHAEFT_ERSTELLT("Geschäft Erstellt"),
    GESCHAEFT_FREIGEGEBEN("Geschäft Freigegeben (4-Augen)"),
    ALLOKATION_ERSTELLT("Mengenallokation Erstellt"),
    LIEFERUNG_GESTARTET("Lieferung Gestartet"),
    LIEFERUNG_BESTAETIGT("Lieferung Empfangen & Quittiert"),
    RECHNUNG_ERSTELLT("Rechnung Erstellt"),
    ZAHLUNG_VERBUCHT("Zahlung Verbucht")
}

data class AuditEvent(
    val eventId: String,                   // z.B. "AUD-2026-990182"
    val zeitpunkt: String,                 // ISO-8601
    val benutzer: String,                  // z.B. "trader.mensch@petrotrade.de"
    val organisation: String,              // z.B. "PetroTrade Deutschland GmbH"
    val aktion: AuditEventType,
    val zielObjektId: String,              // z.B. "ANG-2026-000184"
    val alterZustand: String? = null,
    val neuerZustand: String,
    val clientIp: String = "192.168.10.45",
    val correlationId: String,
    val tenantId: String = "TENANT-PETROTRADE-EU"
)

enum class UserRole(val roleName: String, val permissions: List<String>) {
    TRADER("Junior / Senior Trader", listOf("preise:lesen", "angebote:erstellen", "angebote:annehmen", "geschaefte:lesen")),
    RISK_OFFICER("Risk & Compliance Officer", listOf("preise:lesen", "geschaefte:lesen", "compliance:freigeben", "admin:verwalten")),
    LOGISTICS_DISPATCHER("Logistik & Umschlag-Disponent", listOf("geschaefte:lesen", "allokation:verwalten", "lieferungen:verwalten")),
    ACCOUNTANT("Finanzbuchhalter & Settlement Specialist", listOf("geschaefte:lesen", "rechnungen:lesen", "rechnungen:erstellen", "abrechnung:buchen")),
    ADMIN("System Administrator", listOf("preise:lesen", "angebote:erstellen", "angebote:annehmen", "geschaefte:lesen", "lieferungen:verwalten", "rechnungen:lesen", "admin:verwalten"))
}

data class TenantContext(
    val tenantId: String,                  // z.B. "TENANT-PETROTRADE-EU"
    val tenantName: String,                // z.B. "PetroTrade Europe B.V."
    val userEmail: String,
    val userRole: UserRole,
    val activeScopes: List<String>
)

data class WebhookEvent(
    val eventId: String,                   // z.B. "WH-2026-77123"
    val topic: String,                     // z.B. "angebot.angenommen", "geschaeft.bestaetigt"
    val payloadJson: String,
    val hmacSignature: String,
    val erstellungsZeitstempel: String,
    val zustellVersuche: Int = 1,
    val status: String = "ZUGESTELLT"      // "ZUGESTELLT", "RETRY_IN_BACKOFF", "FEHLGESCHLAGEN"
)

data class ApiErrorDetail(
    val code: String,                      // z.B. "ANGEBOT_ABGELAUFEN", "CREDIT_LIMIT_EXCEEDED"
    val nachricht: String,                 // z.B. "Das Angebot ist nicht mehr gültig."
    val korrelationsId: String
)

data class ApiErrorResponse(
    val fehler: ApiErrorDetail
)
