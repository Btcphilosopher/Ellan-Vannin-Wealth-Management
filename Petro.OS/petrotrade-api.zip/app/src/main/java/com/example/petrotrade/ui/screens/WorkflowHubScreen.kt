package com.example.petrotrade.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.petrotrade.model.*
import com.example.petrotrade.model.engine.PetroTradeEngine
import java.math.BigDecimal
import java.util.UUID

@Composable
fun WorkflowHubScreen() {
    val state by PetroTradeEngine.state.collectAsState()
    var selectedQuote by remember { mutableStateOf<Quote?>(null) }
    var idempotencyKeyInput by remember { mutableStateOf(UUID.randomUUID().toString()) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isExecutingAutoTrade by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = "B2B COMMERCE WORKFLOW ENGINE",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFFF59E0B),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Prozesskette vom Marktpreis bis zur Abrechnung",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(
                            onClick = { idempotencyKeyInput = UUID.randomUUID().toString() },
                            modifier = Modifier.testTag("refresh_idempotency_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Neuen Idempotency Key erzeugen",
                                tint = Color(0xFF38BDF8)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Horizontal Process Pipeline Visualizer
                    val steps = listOf("MARKT", "PREIS", "ANGEBOT", "ANNAHME", "GESCHÄFT", "VERTRAG", "ALLOKATION", "LOGISTIK", "RECHNUNG", "ABRECHNUNG")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        steps.forEachIndexed { index, step ->
                            val isActive = when (step) {
                                "MARKT", "PREIS" -> true
                                "ANGEBOT" -> state.quotes.isNotEmpty()
                                "ANNAHME", "GESCHÄFT", "VERTRAG" -> state.deals.isNotEmpty()
                                "ALLOKATION" -> state.allocations.isNotEmpty()
                                "LOGISTIK" -> state.shipments.isNotEmpty()
                                "RECHNUNG" -> state.invoices.isNotEmpty()
                                "ABRECHNUNG" -> state.settlements.isNotEmpty()
                                else -> false
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(if (isActive) Color(0xFF0284C7) else Color(0xFF334155))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = step,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isActive) Color.White else Color(0xFF94A3B8)
                                )
                            }

                            if (index < steps.size - 1) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier
                                        .padding(horizontal = 4.dp)
                                        .size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quick Action Buttons
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "1-Klick Demo-Handelsabschluss (DEMO ENERGY GMBH)",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Führt die gesamte Kette (5.000 MT Diesel EN590 DAP Hamburg @ 812.40 EUR/MT) Ende-zu-Ende aus.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                isExecutingAutoTrade = true
                                val q = PetroTradeEngine.erzeugeAngebot(
                                    kundeId = "K-10024",
                                    produktId = "DIESEL-EN590",
                                    mengeWert = BigDecimal("5000"),
                                    mengeneinheit = QuantityUnit.MT,
                                    lieferort = "Hamburg",
                                    incoterm = "DAP",
                                    lieferfenster = DeliveryWindow("2026-10-15", "2026-10-20"),
                                    waehrung = "EUR"
                                )
                                val res = PetroTradeEngine.akzeptiereAngebotUndErzeugeGeschaeft(
                                    angebotId = q.angebotsId,
                                    idempotencyKey = idempotencyKeyInput
                                )
                                res.fold(
                                    onSuccess = { deal ->
                                        statusMessage = "Geschäft ${deal.geschaeftId} erfolgreich abgeschlossen & Vertrag/Allokation/Rechnung erzeugt!"
                                    },
                                    onFailure = { err ->
                                        statusMessage = "Fehler: ${err.message}"
                                    }
                                )
                                isExecutingAutoTrade = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("execute_demo_trade_button")
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Vollständiges Geschäft Ausführen", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                PetroTradeEngine.erzeugeAngebot(
                                    kundeId = "K-10024",
                                    produktId = "BENZIN-E10",
                                    mengeWert = BigDecimal("3000"),
                                    mengeneinheit = QuantityUnit.MT,
                                    lieferort = "Rotterdam",
                                    incoterm = "FOB",
                                    lieferfenster = DeliveryWindow("2026-10-18", "2026-10-25"),
                                    waehrung = "EUR"
                                )
                                statusMessage = "Neues Angebot für Benzin E10 ausgestellt."
                            },
                            modifier = Modifier.testTag("create_new_quote_button")
                        ) {
                            Text("Neues Angebot Erstellen")
                        }
                    }

                    statusMessage?.let { msg ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = msg,
                            fontSize = 12.sp,
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Active Quotes List
        item {
            Text(
                text = "Kommerzielle Angebote (${state.quotes.size})",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }

        items(state.quotes) { quote ->
            QuoteCard(
                quote = quote,
                idempotencyKey = idempotencyKeyInput,
                onAcceptQuote = { q ->
                    val res = PetroTradeEngine.akzeptiereAngebotUndErzeugeGeschaeft(
                        angebotId = q.angebotsId,
                        idempotencyKey = idempotencyKeyInput
                    )
                    res.fold(
                        onSuccess = { deal ->
                            statusMessage = "Angebot ${q.angebotsId} angenommen -> Geschäft ${deal.geschaeftId} erzeugt!"
                        },
                        onFailure = { err ->
                            statusMessage = "Fehler: ${err.message}"
                        }
                    )
                }
            )
        }

        // Confirmed Deals
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Bestätigte Geschäfte & Verträge (${state.deals.size})",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }

        items(state.deals) { deal ->
            DealCard(deal = deal)
        }
    }
}

@Composable
fun QuoteCard(
    quote: Quote,
    idempotencyKey: String,
    onAcceptQuote: (Quote) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = quote.angebotsId,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF59E0B),
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "v${quote.version}",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }

                StatusBadge(statusText = quote.status.displayName, isSuccess = quote.status == QuoteStatus.ANGENOMMEN)
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${quote.kundenName} • ${quote.produktName}",
                style = MaterialTheme.typography.titleSmall,
                color = Color.White,
                fontWeight = FontWeight.SemiBold
            )

            Text(
                text = "Menge: ${quote.menge.formatted()} | Incoterm: ${quote.incoterm} ${quote.lieferort} | Fenster: ${quote.lieferfenster.formatted()}",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Endpreis / Einheit:", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Text(
                        text = "${quote.preisBreakdown.endpreisProEinheit.formatted()} / ${quote.menge.unit.name}",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF38BDF8)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Gesamtwert:", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Text(
                        text = quote.gesamtwert.formatted(),
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF10B981)
                    )
                }
            }

            if (quote.status == QuoteStatus.AUSGESTELLT || quote.status == QuoteStatus.BERECHNET) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Idempotency-Key: ${idempotencyKey.take(8)}...",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B),
                        fontFamily = FontFamily.Monospace
                    )

                    Button(
                        onClick = { onAcceptQuote(quote) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        modifier = Modifier.testTag("accept_quote_button_${quote.angebotsId}")
                    ) {
                        Text("Kundenannahme & Abschluss", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun DealCard(deal: Deal) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = deal.geschaeftId,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF10B981),
                    fontFamily = FontFamily.Monospace
                )
                StatusBadge(statusText = deal.status.displayName, isSuccess = true)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Kunde: ${deal.kundenName} (Angebot: ${deal.angebotId})", color = Color.White, fontSize = 13.sp)
            Text(text = "Gesamtwert: ${deal.gesamtwert.formatted()} | Ersteller: ${deal.erstellerUser}", color = Color(0xFF94A3B8), fontSize = 12.sp)

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A), RoundedCornerShape(4.dp))
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Idempotency-Key: ${deal.idempotencyKey}", fontSize = 10.sp, color = Color(0xFF64748B), fontFamily = FontFamily.Monospace)
                Text(text = "Fixiert am: ${deal.erstellerZeitstempel.take(19)}", fontSize = 10.sp, color = Color(0xFF64748B))
            }
        }
    }
}

@Composable
fun StatusBadge(statusText: String, isSuccess: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSuccess) Color(0xFF065F46) else Color(0xFF9A3412))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = statusText,
            color = if (isSuccess) Color(0xFF34D399) else Color(0xFFFDBA74),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
