package com.example.petrotrade.model

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Currency

/**
 * Explizit typisierte Geldbeträge nach Finanzierungs- und Buchhaltungsstandards.
 * Verwendet BigDecimal zur Vermeidung von Gleitkomma-Ungenauigkeiten.
 */
data class Money(
    val amount: BigDecimal,
    val currency: String = "EUR"
) {
    operator fun plus(other: Money): Money {
        require(currency == other.currency) { "Währungsmismatch: $currency vs ${other.currency}" }
        return Money((amount + other.amount).setScale(2, RoundingMode.HALF_UP), currency)
    }

    operator fun minus(other: Money): Money {
        require(currency == other.currency) { "Währungsmismatch: $currency vs ${other.currency}" }
        return Money((amount - other.amount).setScale(2, RoundingMode.HALF_UP), currency)
    }

    operator fun times(factor: BigDecimal): Money {
        return Money((amount * factor).setScale(2, RoundingMode.HALF_UP), currency)
    }

    fun formatted(): String {
        return "%,.2f %s".format(amount.toDouble(), currency)
    }

    companion object {
        fun zero(currency: String = "EUR") = Money(BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP), currency)
        fun of(value: Double, currency: String = "EUR") = Money(BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP), currency)
        fun of(value: String, currency: String = "EUR") = Money(BigDecimal(value).setScale(2, RoundingMode.HALF_UP), currency)
    }
}

/**
 * Unterstüzte Einheiten im physischen Rohstoff- und Petrochemiehandel.
 */
enum class QuantityUnit(val displayName: String, val isMass: Boolean) {
    MT("Metrische Tonne (MT)", isMass = true),
    M3("Kubikmeter (m³)", isMass = false),
    LITER("Liter (L)", isMass = false),
    BARREL("Barrel (bbl)", isMass = false),
    KG("Kilogramm (kg)", isMass = true),
    GAL("US Gallonen (gal)", isMass = false)
}

/**
 * Explizit typisierte Mengen mit Mengeneinheit.
 */
data class Quantity(
    val value: BigDecimal,
    val unit: QuantityUnit
) {
    fun formatted(): String {
        return "%,.2f %s".format(value.toDouble(), unit.name)
    }

    companion object {
        fun zero(unit: QuantityUnit) = Quantity(BigDecimal.ZERO.setScale(3, RoundingMode.HALF_UP), unit)
        fun of(value: Double, unit: QuantityUnit) = Quantity(BigDecimal.valueOf(value).setScale(3, RoundingMode.HALF_UP), unit)
        fun of(value: String, unit: QuantityUnit) = Quantity(BigDecimal(value).setScale(3, RoundingMode.HALF_UP), unit)
    }
}

/**
 * Robustes Modul zur Einheitenumrechnung unter Berücksichtigung der Produktdichte.
 * Dichte wird typischerweise in kg/m³ bei Standardtemperatur (z.B. 15°C) angegeben.
 */
object UnitConverter {
    // Standard-Dichte für Diesel (EN 590) ca. 835 kg/m³ = 0.835 kg/L
    const val DEFAULT_DIESEL_DENSITY_KG_M3 = 835.0
    const val BARREL_TO_LITERS = 158.987294928
    const val GALLON_TO_LITERS = 3.785411784

    fun convert(
        source: Quantity,
        targetUnit: QuantityUnit,
        densityKgPerM3: Double = DEFAULT_DIESEL_DENSITY_KG_M3
    ): Quantity {
        if (source.unit == targetUnit) return source

        // Schritt 1: Convert to Base Volume in Liters or Base Mass in KG
        val densityFactor = densityKgPerM3 // kg / m3 -> 1 m3 = densityKgPerM3 kg
        val kgPerLiter = densityKgPerM3 / 1000.0

        val totalKg: BigDecimal = when (source.unit) {
            QuantityUnit.KG -> source.value
            QuantityUnit.MT -> source.value * BigDecimal("1000")
            QuantityUnit.LITER -> source.value * BigDecimal.valueOf(kgPerLiter)
            QuantityUnit.M3 -> source.value * BigDecimal.valueOf(densityKgPerM3)
            QuantityUnit.BARREL -> source.value * BigDecimal.valueOf(BARREL_TO_LITERS * kgPerLiter)
            QuantityUnit.GAL -> source.value * BigDecimal.valueOf(GALLON_TO_LITERS * kgPerLiter)
        }

        // Schritt 2: Convert Total KG to Target Unit
        val resultValue = when (targetUnit) {
            QuantityUnit.KG -> totalKg
            QuantityUnit.MT -> totalKg / BigDecimal("1000")
            QuantityUnit.LITER -> totalKg / BigDecimal.valueOf(kgPerLiter)
            QuantityUnit.M3 -> totalKg / BigDecimal.valueOf(densityKgPerM3)
            QuantityUnit.BARREL -> (totalKg / BigDecimal.valueOf(kgPerLiter)) / BigDecimal.valueOf(BARREL_TO_LITERS)
            QuantityUnit.GAL -> (totalKg / BigDecimal.valueOf(kgPerLiter)) / BigDecimal.valueOf(GALLON_TO_LITERS)
        }

        return Quantity(resultValue.setScale(3, RoundingMode.HALF_UP), targetUnit)
    }
}
