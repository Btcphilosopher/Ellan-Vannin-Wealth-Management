package com.example.petrotrade.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.petrotrade.api.OpenApiSpec
import com.example.petrotrade.api.RestApiSimulator
import com.example.petrotrade.api.SimHttpResponse
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiConsoleScreen() {
    var selectedMethod by remember { mutableStateOf("POST") }
    var selectedEndpoint by remember { mutableStateOf("/angebote/ANG-2026-000184/annahme") }
    var inputIdempotencyKey by remember { mutableStateOf("7f93c8d1-92ba-4b21-9981-a90f") }
    var lastResponse by remember { mutableStateOf<SimHttpResponse?>(null) }
    var showOpenApiSpec by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = Color(0xFF38BDF8))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "INTERAKTIVE REST-API KONSOLE (GERMAN SWAGGER)",
                                style = MaterialTheme.typography.titleSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        TextButton(
                            onClick = { showOpenApiSpec = !showOpenApiSpec },
                            modifier = Modifier.testTag("toggle_openapi_spec_button")
                        ) {
                            Text(if (showOpenApiSpec) "Konsole Zeigen" else "OpenAPI Doku", fontSize = 12.sp)
                        }
                    }

                    if (showOpenApiSpec) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(300.dp)
                                .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                                .horizontalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = OpenApiSpec.getGermanOpenApiJson(),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = Color(0xFF34D399)
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.height(12.dp))

                        // Method & Endpoint Selectors
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("GET", "POST").forEach { m ->
                                FilterChip(
                                    selected = m == selectedMethod,
                                    onClick = { selectedMethod = m },
                                    label = { Text(m, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        val endpoints = listOf(
                            "/produkte",
                            "/preise",
                            "/angebote",
                            "/angebote/ANG-2026-000184/annahme",
                            "/geschaefte",
                            "/allokationen",
                            "/lieferungen",
                            "/rechnungen"
                        )

                        OutlinedTextField(
                            value = selectedEndpoint,
                            onValueChange = { selectedEndpoint = it },
                            label = { Text("Endpoint Pfad (/api/v1/...)", fontSize = 11.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("api_endpoint_input"),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = inputIdempotencyKey,
                            onValueChange = { inputIdempotencyKey = it },
                            label = { Text("Header: Idempotency-Key", fontSize = 11.sp) },
                            trailingIcon = {
                                IconButton(onClick = { inputIdempotencyKey = UUID.randomUUID().toString() }) {
                                    Text("Neu", fontSize = 10.sp, color = Color(0xFF38BDF8))
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("api_idempotency_input"),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                val hdrs = mapOf(
                                    "Idempotency-Key" to inputIdempotencyKey,
                                    "X-Tenant-ID" to "TENANT-PETROTRADE-EU"
                                )
                                lastResponse = RestApiSimulator.handleRequest(
                                    method = selectedMethod,
                                    path = selectedEndpoint,
                                    headers = hdrs,
                                    bodyJson = null
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("send_api_request_button")
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("API Request Senden ($selectedMethod $selectedEndpoint)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Response Display Box
        lastResponse?.let { resp ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (resp.statusCode in 200..299) Color(0xFF10B981) else Color(0xFFEF4444)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "HTTP STATUS: ${resp.statusCode}",
                                fontWeight = FontWeight.Bold,
                                color = if (resp.statusCode in 200..299) Color(0xFF10B981) else Color(0xFFEF4444)
                            )
                            Text(
                                text = "X-Correlation-ID: ${resp.headers["X-Correlation-ID"] ?: "COR-78291"}",
                                fontSize = 10.sp,
                                color = Color(0xFF94A3B8),
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF1E293B), RoundedCornerShape(6.dp))
                                .padding(10.dp)
                                .horizontalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = resp.bodyJson,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = Color(0xFFF8FAFC)
                            )
                        }
                    }
                }
            }
        }
    }
}
