package com.example.petrotrade.model

import java.math.BigDecimal
import java.math.RoundingMode

enum class PriceModel(val displayName: String) {
    FESTPREIS("Fixer Festpreis"),
    INDEXPREIS("Indexpreis (Börsen- / Marktreferenz)"),
    INDEX_PLUS_DIFFERENZ("Index + Differential"),
    FORMELPREIS("Konfigurierbarer Formelpreis"),
    SPOTPREIS("Spotmarkt-Tagespreis"),
    VERTRAGSPREIS("Laufender Vertragspreis")
}

data class MarketPrice(
    val preisId: String,
    val produktId: String,
    val quelle: String,                  // z.B. "ICE Brent / Platts ARA / Synthetic Market"
    val zeitstempel: String,             // ISO-8601
    val preis: Money,
    val einheit: QuantityUnit,
    val markt: String,                   // z.B. "ARA Hub Rotterdam / Hamburg DAP"
    val preisart: PriceModel,
    val gueltigBis: String,              // ISO-8601
    val isSynthetisch: Boolean = true    // Synthetische Marktdaten zur Demonstration
)

enum class PricingComponentType(val displayName: String, val isDeduction: Boolean = false) {
    REFERENZPREIS("Referenzpreis / Basispreis"),
    PREISDIFFERENZ("Preisdifferential / Aufschlag"),
    QUALITAETSANPASSUNG("Qualitätsanpassung (z.B. Schwefel-Bonus/Malus)"),
    LOGISTIK("Logistik- & Umschlagskosten"),
    LAGERUNG("Tanklagergebühr"),
    FRACHT("Fracht & Transport"),
    VERSICHERUNG("Transportversicherung"),
    ZUSCHLAEGE("Energie- & Umweltzuschläge"),
    RABATTE("Mengenrabatt / Kundenrabatt", isDeduction = true),
    FINANZIERUNGSKOSTEN("Finanzierungskosten & Zahlungsziel-Aufschlag")
}

data class PricingComponent(
    val type: PricingComponentType,
    val bezeichnung: String,
    val betragProEinheit: Money,
    val formelHinweis: String? = null
)

data class PricingBreakdown(
    val grundpreisProEinheit: Money,
    val komponenten: List<PricingComponent>,
    val endpreisProEinheit: Money,
    val mengeneinheit: QuantityUnit,
    val berechnungsFormelString: String,
    val berechnungsZeitpunkt: String
) {
    fun berechneGesamtwert(menge: BigDecimal): Money {
        val total = endpreisProEinheit.amount * menge
        return Money(total.setScale(2, RoundingMode.HALF_UP), endpreisProEinheit.currency)
    }
}

/**
 * Sicherer, versionierter Formelrechner für Rohstoffpreise.
 */
data class PriceFormula(
    val formulaId: String,
    val name: String,
    val referenzIndex: String,                 // z.B. "PLATTS_ULSD_10PPM_ARA"
    val differentialProEinheit: BigDecimal,    // z.B. +12.50
    val frachtProEinheit: BigDecimal,          // z.B. +18.00
    val terminalGebuehrProEinheit: BigDecimal, // z.B. +4.50
    val versicherungProzent: BigDecimal,       // z.B. 0.005 (0.5%)
    val rabattProEinheit: BigDecimal           // z.B. -2.00
) {
    fun berechne(
        referenzBetrag: BigDecimal,
        waehrung: String,
        einheit: QuantityUnit
    ): PricingBreakdown {
        val refMoney = Money(referenzBetrag.setScale(2, RoundingMode.HALF_UP), waehrung)
        val diffMoney = Money(differentialProEinheit.setScale(2, RoundingMode.HALF_UP), waehrung)
        val frachtMoney = Money(frachtProEinheit.setScale(2, RoundingMode.HALF_UP), waehrung)
        val terminalMoney = Money(terminalGebuehrProEinheit.setScale(2, RoundingMode.HALF_UP), waehrung)
        val versichMoney = Money((referenzBetrag * versicherungProzent).setScale(2, RoundingMode.HALF_UP), waehrung)
        val rabattMoney = Money(rabattProEinheit.setScale(2, RoundingMode.HALF_UP), waehrung)

        val list = listOf(
            PricingComponent(PricingComponentType.REFERENZPREIS, "Basisindex $referenzIndex", refMoney),
            PricingComponent(PricingComponentType.PREISDIFFERENZ, "Regionales Markt-Differential", diffMoney),
            PricingComponent(PricingComponentType.FRACHT, "Transport & Schiffsfracht", frachtMoney),
            PricingComponent(PricingComponentType.LAGERUNG, "Terminal- & Umschlaggebühr", terminalMoney),
            PricingComponent(PricingComponentType.VERSICHERUNG, "Transportversicherung", versichMoney),
            PricingComponent(PricingComponentType.RABATTE, "Handelsrabatt", rabattMoney)
        )

        var sum = referenzBetrag + differentialProEinheit + frachtProEinheit + terminalGebuehrProEinheit + (referenzBetrag * versicherungProzent) - rabattProEinheit
        sum = sum.setScale(2, RoundingMode.HALF_UP)

        val endMoney = Money(sum, waehrung)
        val formelStr = "($referenzIndex + $differentialProEinheit + $frachtProEinheit + $terminalGebuehrProEinheit + ${versicherungProzent * BigDecimal(100)}% Vers.) - $rabattProEinheit"

        return PricingBreakdown(
            grundpreisProEinheit = refMoney,
            komponenten = list,
            endpreisProEinheit = endMoney,
            mengeneinheit = einheit,
            berechnungsFormelString = formelStr,
            berechnungsZeitpunkt = java.time.Instant.now().toString()
        )
    }
}
