package com.example.petrotrade.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.petrotrade.model.*
import com.example.petrotrade.model.engine.PetroTradeEngine
import com.example.petrotrade.model.engine.PricingEngine
import java.math.BigDecimal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PricingEngineScreen() {
    val state by PetroTradeEngine.state.collectAsState()

    var selectedProduct by remember { mutableStateOf(state.products.first()) }
    var selectedIncoterm by remember { mutableStateOf("DAP") }
    var inputMengeText by remember { mutableStateOf("5000") }
    var inputUnit by remember { mutableStateOf(QuantityUnit.MT) }
    var inputLieferort by remember { mutableStateOf("Hamburg") }
    var customDiffText by remember { mutableStateOf("12.50") }
    var customFrachtText by remember { mutableStateOf("18.00") }

    // Unit Conversion State
    var convertFromVal by remember { mutableStateOf("1000") }
    var convertFromUnit by remember { mutableStateOf(QuantityUnit.MT) }
    var convertToUnit by remember { mutableStateOf(QuantityUnit.M3) }
    var convertDensityVal by remember { mutableStateOf("835.0") }

    val mktPrice = state.marketPrices.find { it.produktId == selectedProduct.id } ?: state.marketPrices.first()

    val calculatedBreakdown = remember(selectedProduct, inputMengeText, inputUnit, selectedIncoterm, inputLieferort, customDiffText, customFrachtText) {
        val mengeBD = inputMengeText.toBigDecimalOrNull() ?: BigDecimal("5000")
        val diffBD = customDiffText.toBigDecimalOrNull() ?: BigDecimal("12.50")
        val frachtBD = customFrachtText.toBigDecimalOrNull() ?: BigDecimal("18.00")

        PricingEngine.berechneVerkaufspreis(
            produkt = selectedProduct,
            menge = Quantity(mengeBD, inputUnit),
            incoterm = selectedIncoterm,
            lieferort = inputLieferort,
            zielWaehrung = "EUR",
            marktReferenzPreis = mktPrice,
            customDifferential = diffBD,
            customFracht = frachtBD
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Calculate, contentDescription = null, tint = Color(0xFFF59E0B))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PREIS ENGINE & FORMEL-KALKULATOR",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Product Selector Chips
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        state.products.take(3).forEach { p ->
                            FilterChip(
                                selected = p.id == selectedProduct.id,
                                onClick = { selectedProduct = p },
                                label = { Text(p.id, fontSize = 11.sp) },
                                modifier = Modifier.testTag("select_product_chip_${p.id}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = inputMengeText,
                            onValueChange = { inputMengeText = it },
                            label = { Text("Menge", fontSize = 11.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pricing_menge_input"),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )

                        OutlinedTextField(
                            value = inputLieferort,
                            onValueChange = { inputLieferort = it },
                            label = { Text("Lieferort", fontSize = 11.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pricing_lieferort_input"),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )

                        OutlinedTextField(
                            value = selectedIncoterm,
                            onValueChange = { selectedIncoterm = it },
                            label = { Text("Incoterm", fontSize = 11.sp) },
                            modifier = Modifier
                                .weight(0.8f)
                                .testTag("pricing_incoterm_input"),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                    }
                }
            }
        }

        // Pricing Breakdown Result Table
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF0284C7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Transparentes Preis-Breakdown Resultat",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Formel: ${calculatedBreakdown.berechnungsFormelString}",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8),
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    calculatedBreakdown.komponenten.forEach { comp ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = comp.bezeichnung,
                                fontSize = 12.sp,
                                color = if (comp.type.isDeduction) Color(0xFFF87171) else Color.White
                            )
                            Text(
                                text = "${if (comp.type.isDeduction) "-" else "+"}${comp.betragProEinheit.formatted()} / ${calculatedBreakdown.mengeneinheit.name}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (comp.type.isDeduction) Color(0xFFF87171) else Color(0xFF38BDF8)
                            )
                        }
                        Divider(color = Color(0xFF1E293B))
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Endpreis pro Einheit:", fontSize = 11.sp, color = Color(0xFF94A3B8))
                            Text(
                                text = "${calculatedBreakdown.endpreisProEinheit.formatted()} / ${calculatedBreakdown.mengeneinheit.name}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF10B981)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("Gesamtwert Vertrag:", fontSize = 11.sp, color = Color(0xFF94A3B8))
                            val mengeVal = inputMengeText.toBigDecimalOrNull() ?: BigDecimal("5000")
                            Text(
                                text = calculatedBreakdown.berechneGesamtwert(mengeVal).formatted(),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF59E0B)
                            )
                        }
                    }
                }
            }
        }

        // Unit Conversion Tool
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, tint = Color(0xFF38BDF8))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Robustes Einheiten- & Dichteumrechnungs-Tool",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = convertFromVal,
                            onValueChange = { convertFromVal = it },
                            label = { Text("Eingabemenge", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )

                        OutlinedTextField(
                            value = convertDensityVal,
                            onValueChange = { convertDensityVal = it },
                            label = { Text("Dichte (kg/m³)", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val srcQuantity = Quantity(convertFromVal.toBigDecimalOrNull() ?: BigDecimal("1000"), convertFromUnit)
                    val densityDbl = convertDensityVal.toDoubleOrNull() ?: 835.0
                    val convertedM3 = UnitConverter.convert(srcQuantity, QuantityUnit.M3, densityDbl)
                    val convertedLiters = UnitConverter.convert(srcQuantity, QuantityUnit.LITER, densityDbl)
                    val convertedBarrels = UnitConverter.convert(srcQuantity, QuantityUnit.BARREL, densityDbl)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                text = "Umrechnungsergebnis für ${srcQuantity.formatted()} (Dichte: $densityDbl kg/m³):",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                            Text(
                                text = "• Volume: ${convertedM3.formatted()} = ${convertedLiters.formatted()}",
                                fontSize = 12.sp,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "• US Barrel: ${convertedBarrels.formatted()}",
                                fontSize = 12.sp,
                                color = Color(0xFF38BDF8),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Market Prices Ticker
        item {
            Text(
                text = "Synthetischer Marktpreis-Index (Referenzdaten)",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }

        items(state.marketPrices) { mp ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = mp.produktId, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(text = mp.quelle, fontSize = 11.sp, color = Color(0xFF94A3B8))
                        Text(text = "Markt: ${mp.markt}", fontSize = 10.sp, color = Color(0xFF64748B))
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${mp.preis.formatted()} / ${mp.einheit.name}",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF59E0B)
                        )
                        Text(
                            text = "[SYNTHETISCHE MARKTDATEN]",
                            fontSize = 9.sp,
                            color = Color(0xFF10B981),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
