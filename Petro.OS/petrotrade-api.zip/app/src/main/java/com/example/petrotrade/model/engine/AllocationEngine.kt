package com.example.petrotrade.model.engine

import com.example.petrotrade.model.*
import java.math.BigDecimal

object AllocationEngine {

    fun erzeugeAllokation(
        vertragId: String,
        geschaeftId: String,
        sollMengeMT: BigDecimal,
        produktId: String,
        verfuegbareTerminals: List<Terminal>
    ): Pair<Allocation, List<Terminal>> {
        var restMenge = sollMengeMT
        val allokationenList = mutableListOf<TerminalAllocation>()

        // Kopie der Terminals für aktualisierte Tankstände
        val aktualisierteTerminals = verfuegbareTerminals.map { term ->
            val neusTanks = term.tanks.map { tank ->
                if (tank.produktId == produktId && restMenge > BigDecimal.ZERO && tank.verfuegbareMengeMT > BigDecimal.ZERO) {
                    val allokierbar = tank.verfuegbareMengeMT.min(restMenge)
                    restMenge -= allokierbar

                    allokationenList.add(
                        TerminalAllocation(
                            terminalId = term.terminalId,
                            terminalName = term.name,
                            tankId = tank.tankId,
                            allokierteMengeMT = allokierbar,
                            chargenId = "CH-2026-${produktId.take(6)}-${(100..999).random()}"
                        )
                    )

                    tank.copy(reservierteMengeMT = tank.reservierteMengeMT + allokierbar)
                } else {
                    tank
                }
            }
            term.copy(tanks = neusTanks)
        }

        check(restMenge == BigDecimal.ZERO) {
            "Überallokation verhindert: Nicht genügend freie Lagerkapazität vorhanden (Fehlbetrag: $restMenge MT)."
        }

        val allocation = Allocation(
            allokationsId = "ALL-2026-${(10000..99999).random()}",
            vertragId = vertragId,
            geschaeftId = geschaeftId,
            gesamtMengeMT = sollMengeMT,
            allokationen = allokationenList,
            erstellungsZeitstempel = java.time.Instant.now().toString()
        )

        return Pair(allocation, aktualisierteTerminals)
    }
}
