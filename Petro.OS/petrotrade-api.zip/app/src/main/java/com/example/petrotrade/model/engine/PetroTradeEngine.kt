package com.example.petrotrade.model.engine

import com.example.petrotrade.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDate

data class PetroTradeSystemState(
    val products: List<Product>,
    val customers: List<Customer>,
    val marketPrices: List<MarketPrice>,
    val terminals: List<Terminal>,
    val quotes: List<Quote>,
    val deals: List<Deal>,
    val contracts: List<Contract>,
    val allocations: List<Allocation>,
    val shipments: List<Shipment>,
    val invoices: List<Invoice>,
    val settlements: List<Settlement>,
    val auditLogs: List<AuditEvent>,
    val webhooks: List<WebhookEvent>,
    val tenantContext: TenantContext
)

object PetroTradeEngine {

    private val initialProducts = listOf(
        Product(
            id = "DIESEL-EN590",
            name = "Diesel Kraftstoff",
            handelsname = "Ultraschwefelarmer Diesel EN 590",
            produktKlasse = ProductClass.RAFFINERIEPRODUKT,
            standardEinheit = QuantityUnit.MT,
            dichteKgM3 = 835.0,
            schwefelgehaltMgKg = 10.0,
            wassergehaltPpm = 45.0,
            reinheitProzent = 99.9,
            oktanzahlCetanzahl = 53.0,
            temperaturBasisGradC = 15.0,
            herkunft = "Raffinerie Schwedt / Hamburg",
            gefahrgutKlasse = DangerousGoodsClass.CLASS_3_FLAMMABLE_LIQUID,
            standardSpezifikation = ProductSpecification(
                specCode = "EN 590",
                name = "Europäische Dieselspezifikation DIN EN 590:2022",
                parameterList = listOf(
                    QualityParameter("Schwefelgehalt", "10", "mg/kg", maxLimit = "10"),
                    QualityParameter("Dichte bei 15°C", "835.0", "kg/m³", minLimit = "820", maxLimit = "845"),
                    QualityParameter("Cetanzahl", "53.0", "-", minLimit = "51.0"),
                    QualityParameter("Flammpunkt", "58.0", "°C", minLimit = "55.0")
                )
            )
        ),
        Product(
            id = "BENZIN-E10",
            name = "Super E10 Kraftstoff",
            handelsname = "Super E10 DIN EN 228 (10% Bioethanol)",
            produktKlasse = ProductClass.RAFFINERIEPRODUKT,
            standardEinheit = QuantityUnit.MT,
            dichteKgM3 = 745.0,
            schwefelgehaltMgKg = 8.0,
            wassergehaltPpm = 30.0,
            reinheitProzent = 99.8,
            oktanzahlCetanzahl = 95.0,
            temperaturBasisGradC = 15.0,
            herkunft = "Raffinerie Leuna / Hamburg",
            gefahrgutKlasse = DangerousGoodsClass.CLASS_3_FLAMMABLE_LIQUID,
            standardSpezifikation = ProductSpecification(
                specCode = "DIN EN 228",
                name = "Kraftstoffe für Kraftfahrzeuge - Super E10",
                parameterList = listOf(
                    QualityParameter("Oktanzahl ROZ", "95.0", "ROZ", minLimit = "95.0"),
                    QualityParameter("Ethanolgehalt", "9.8", "Vol-%", minLimit = "5.0", maxLimit = "10.0"),
                    QualityParameter("Dichte bei 15°C", "745.0", "kg/m³", minLimit = "720", maxLimit = "775")
                )
            )
        ),
        Product(
            id = "JET-A1",
            name = "Flugturbinenkraftstoff Jet A-1",
            handelsname = "Aviation Turbine Fuel Jet A-1 (AFQRJOS)",
            produktKlasse = ProductClass.RAFFINERIEPRODUKT,
            standardEinheit = QuantityUnit.MT,
            dichteKgM3 = 800.0,
            schwefelgehaltMgKg = 5.0,
            wassergehaltPpm = 15.0,
            reinheitProzent = 99.95,
            oktanzahlCetanzahl = null,
            temperaturBasisGradC = 15.0,
            herkunft = "Raffinerie Heide / Rotterdam",
            gefahrgutKlasse = DangerousGoodsClass.CLASS_3_FLAMMABLE_LIQUID,
            standardSpezifikation = ProductSpecification(
                specCode = "DEF STAN 91-091",
                name = "British Ministry of Defence Standard Jet A-1 Issue 14",
                parameterList = listOf(
                    QualityParameter("Gefrierpunkt", "-47.0", "°C", maxLimit = "-47.0"),
                    QualityParameter("Flammpunkt", "42.0", "°C", minLimit = "38.0"),
                    QualityParameter("Wassergehalt", "15", "ppm", maxLimit = "30")
                )
            )
        ),
        Product(
            id = "ETHYLEN-P",
            name = "Polymer-Grade Ethylen",
            handelsname = "Ethylen Reinheit 99.95% (ARG Pipeline)",
            produktKlasse = ProductClass.PETROCHEMISCHES_PRODUKT,
            standardEinheit = QuantityUnit.MT,
            dichteKgM3 = 568.0,
            schwefelgehaltMgKg = 1.0,
            wassergehaltPpm = 2.0,
            reinheitProzent = 99.95,
            oktanzahlCetanzahl = null,
            temperaturBasisGradC = 15.0,
            herkunft = "Steamcracker Dormagen / Rotterdam",
            gefahrgutKlasse = DangerousGoodsClass.CLASS_2_GASES,
            standardSpezifikation = ProductSpecification(
                specCode = "ETH-9995-SPEC",
                name = "Petrochemische Spezifikation Ethylen Polymer Grade",
                parameterList = listOf(
                    QualityParameter("Reinheit", "99.95", "%", minLimit = "99.90"),
                    QualityParameter("Acetylen", "2.0", "ppm", maxLimit = "5.0")
                )
            )
        ),
        Product(
            id = "METHANOL-IND",
            name = "Industrielles Methanol",
            handelsname = "Methanol Grade A (IMPCA Standard)",
            produktKlasse = ProductClass.PETROCHEMISCHES_PRODUKT,
            standardEinheit = QuantityUnit.MT,
            dichteKgM3 = 791.0,
            schwefelgehaltMgKg = 0.5,
            wassergehaltPpm = 100.0,
            reinheitProzent = 99.85,
            oktanzahlCetanzahl = null,
            temperaturBasisGradC = 15.0,
            herkunft = "Leuna Werke / Rotterdam Hub",
            gefahrgutKlasse = DangerousGoodsClass.CLASS_3_FLAMMABLE_LIQUID,
            standardSpezifikation = ProductSpecification(
                specCode = "IMPCA-METHANOL",
                name = "International Methanol Producers & Consumers Association Spec",
                parameterList = listOf(
                    QualityParameter("Reinheit", "99.85", "%", minLimit = "99.80"),
                    QualityParameter("Wassergehalt", "0.05", "Gew-%", maxLimit = "0.10")
                )
            )
        )
    )

    private val initialCustomer = Customer(
        id = "K-10024",
        firmenname = "DEMO ENERGY GMBH",
        legalEntity = "DEMO Energy Handels GmbH & Co. KG",
        ustIdNr = "DE812345679",
        landIso = "DE",
        billingAccountNo = "ACC-DE-99210",
        creditLimitInfo = CreditLimitInfo(
            gesamtKreditlimit = Money.of(5000000.0, "EUR"),
            offeneForderungen = Money.of(850000.0, "EUR"),
            reservierterHandelswert = Money.of(400000.0, "EUR")
        ),
        paymentTerms = PaymentTerms("NET_30", "30 Tage netto nach Rechnungsstellung", 30),
        kycStatus = "VERIFIZIERT"
    )

    private val initialMarketPrices = listOf(
        MarketPrice("PR-ICE-001", "DIESEL-EN590", "Platts ULSD 10ppm ARA / ICE Gasoil", Instant.now().toString(), Money.of(742.50, "EUR"), QuantityUnit.MT, "ARA Hub / Hamburg", PriceModel.INDEX_PLUS_DIFFERENZ, "2026-10-04T18:00:00Z", isSynthetisch = true),
        MarketPrice("PR-ICE-002", "BENZIN-E10", "Platts Eurobob E10 Barges FOB AR", Instant.now().toString(), Money.of(785.00, "EUR"), QuantityUnit.MT, "Rotterdam / Hamburg", PriceModel.INDEX_PLUS_DIFFERENZ, "2026-10-04T18:00:00Z", isSynthetisch = true),
        MarketPrice("PR-ICE-003", "JET-A1", "Platts Jet A1 CIF NWE", Instant.now().toString(), Money.of(810.20, "EUR"), QuantityUnit.MT, "NWE / Hamburg", PriceModel.INDEX_PLUS_DIFFERENZ, "2026-10-04T18:00:00Z", isSynthetisch = true),
        MarketPrice("PR-ICE-004", "ETHYLEN-P", "ICIS Ethylen Pipe FD NWE", Instant.now().toString(), Money.of(980.00, "EUR"), QuantityUnit.MT, "ARG Pipeline NWE", PriceModel.FORMELPREIS, "2026-10-04T18:00:00Z", isSynthetisch = true),
        MarketPrice("PR-ICE-005", "METHANOL-IND", "IMPCA Methanol FOB Rotterdam", Instant.now().toString(), Money.of(320.00, "EUR"), QuantityUnit.MT, "Rotterdam Hub", PriceModel.SPOTPREIS, "2026-10-04T18:00:00Z", isSynthetisch = true)
    )

    private val initialTerminals = listOf(
        Terminal(
            terminalId = "TERM-HH-ELBE",
            name = "Tanklager Hamburg Nord-Elbe",
            standort = "Hamburg Hafen, Deutschland",
            angebundeneTransportWege = listOf(TransportMode.SCHIFF, TransportMode.BINNENSCHIFF, TransportMode.TANKWAGEN, TransportMode.BAHN),
            tanks = listOf(
                Tank("TANK-HH-01", "Tank 1 - Ultra-Low Sulfur Diesel EN590", 25000.0, BigDecimal("18500.00"), BigDecimal("3500.00"), "DIESEL-EN590"),
                Tank("TANK-HH-02", "Tank 2 - Super E10 Kraftstoff", 20000.0, BigDecimal("12000.00"), BigDecimal("2000.00"), "BENZIN-E10")
            )
        ),
        Terminal(
            terminalId = "TERM-SCHWEDT",
            name = "Raffinerie-Tanklager Schwedt",
            standort = "Schwedt/Oder, Deutschland",
            angebundeneTransportWege = listOf(TransportMode.PIPELINE, TransportMode.BAHN, TransportMode.TANKWAGEN),
            tanks = listOf(
                Tank("TANK-SW-01", "Tank 10 - Diesel EN590 Pipeline-Kopplung", 40000.0, BigDecimal("32000.00"), BigDecimal("5000.00"), "DIESEL-EN590"),
                Tank("TANK-SW-02", "Tank 12 - Jet A-1 Flugturbinenkraftstoff", 15000.0, BigDecimal("11000.00"), BigDecimal("1000.00"), "JET-A1")
            )
        ),
        Terminal(
            terminalId = "TERM-ROTTERDAM",
            name = "Petrochemie Terminal Rotterdam Europort",
            standort = "Rotterdam, Niederlande",
            angebundeneTransportWege = listOf(TransportMode.SCHIFF, TransportMode.BINNENSCHIFF, TransportMode.PIPELINE, TransportMode.CONTAINER),
            tanks = listOf(
                Tank("TANK-RTM-01", "Tank CR-1 - Polymer Grade Ethylen Pipeline", 30000.0, BigDecimal("21000.00"), BigDecimal("4000.00"), "ETHYLEN-P"),
                Tank("TANK-RTM-02", "Tank ME-2 - Methanol Bulk Storage", 35000.0, BigDecimal("28000.00"), BigDecimal("3000.00"), "METHANOL-IND")
            )
        )
    )

    private val idempotencyCache = mutableMapOf<String, Deal>()

    private val _state = MutableStateFlow(
        PetroTradeSystemState(
            products = initialProducts,
            customers = listOf(initialCustomer),
            marketPrices = initialMarketPrices,
            terminals = initialTerminals,
            quotes = emptyList(),
            deals = emptyList(),
            contracts = emptyList(),
            allocations = emptyList(),
            shipments = emptyList(),
            invoices = emptyList(),
            settlements = emptyList(),
            auditLogs = emptyList(),
            webhooks = emptyList(),
            tenantContext = TenantContext(
                tenantId = "TENANT-PETROTRADE-EU",
                tenantName = "PetroTrade Europe B.V.",
                userEmail = "trader.mensch@petrotrade.de",
                userRole = UserRole.TRADER,
                activeScopes = UserRole.TRADER.permissions
            )
        )
    )

    val state: StateFlow<PetroTradeSystemState> = _state.asStateFlow()

    init {
        // Erstes Demosequenzangebot für schnellen Start vorbereiten
        erzeugeAngebot(
            kundeId = "K-10024",
            produktId = "DIESEL-EN590",
            mengeWert = BigDecimal("5000"),
            mengeneinheit = QuantityUnit.MT,
            lieferort = "Hamburg",
            incoterm = "DAP",
            lieferfenster = DeliveryWindow(LocalDate.now().plusDays(10).toString(), LocalDate.now().plusDays(15).toString()),
            waehrung = "EUR"
        )
    }

    fun setTenantUserRole(role: UserRole) {
        val current = _state.value
        _state.value = current.copy(
            tenantContext = current.tenantContext.copy(
                userRole = role,
                activeScopes = role.permissions
            )
        )
    }

    /**
     * POST /api/v1/angebote
     */
    fun erzeugeAngebot(
        kundeId: String,
        produktId: String,
        mengeWert: BigDecimal,
        mengeneinheit: QuantityUnit,
        lieferort: String,
        incoterm: String,
        lieferfenster: DeliveryWindow,
        waehrung: String = "EUR"
    ): Quote {
        val currState = _state.value
        val kunde = currState.customers.find { it.id == kundeId } ?: initialCustomer
        val produkt = currState.products.find { it.id == produktId } ?: initialProducts.first()
        val mktPrice = currState.marketPrices.find { it.produktId == produktId } ?: initialMarketPrices.first()

        val quantity = Quantity(mengeWert, mengeneinheit)
        val breakdown = PricingEngine.berechneVerkaufspreis(
            produkt = produkt,
            menge = quantity,
            incoterm = incoterm,
            lieferort = lieferort,
            zielWaehrung = waehrung,
            marktReferenzPreis = mktPrice
        )

        val totalValue = breakdown.berechneGesamtwert(mengeWert)
        val angebotsId = "ANG-2026-${(100000..999999).random()}"
        val gueltigBisIso = Instant.now().plusSeconds(86400).toString()

        val snapshot = QuoteSnapshot(
            snapshotId = "SNP-${(10000..99999).random()}",
            erstellerZeitstempel = Instant.now().toString(),
            preisquelle = mktPrice.quelle,
            basisPreisProEinheit = breakdown.grundpreisProEinheit,
            differentialProEinheit = Money.of(12.50, waehrung),
            gebuehrenProEinheit = Money.of(6.00, waehrung),
            steuernProzent = BigDecimal("19.00"),
            waehrung = waehrung,
            wechselkursEUR = BigDecimal.ONE,
            menge = quantity,
            produktId = produkt.id,
            produktSpezifikationCode = produkt.standardSpezifikation.specCode,
            incotermCode = incoterm,
            lieferort = lieferort,
            lieferfenster = lieferfenster,
            gueltigBis = gueltigBisIso,
            version = 1
        )

        val quote = Quote(
            angebotsId = angebotsId,
            kundeId = kunde.id,
            kundenName = kunde.firmenname,
            produktId = produkt.id,
            produktName = produkt.handelsname,
            menge = quantity,
            lieferort = lieferort,
            incoterm = incoterm,
            lieferfenster = lieferfenster,
            waehrung = waehrung,
            status = QuoteStatus.AUSGESTELLT,
            preisBreakdown = breakdown,
            gesamtwert = totalValue,
            gueltigBis = gueltigBisIso,
            erstelltAm = Instant.now().toString(),
            version = 1,
            snapshot = snapshot
        )

        val newAudit = AuditEvent(
            eventId = "AUD-${(100000..999999).random()}",
            zeitpunkt = Instant.now().toString(),
            benutzer = currState.tenantContext.userEmail,
            organisation = currState.tenantContext.tenantName,
            aktion = AuditEventType.ANGEBOT_ERSTELLT,
            zielObjektId = quote.angebotsId,
            alterZustand = null,
            neuerZustand = "Status: AUSGESTELLT, Gesamtwert: ${totalValue.formatted()}",
            correlationId = "COR-${(10000..99999).random()}"
        )

        _state.value = currState.copy(
            quotes = listOf(quote) + currState.quotes,
            auditLogs = listOf(newAudit) + currState.auditLogs
        )

        return quote
    }

    /**
     * POST /api/v1/geschaefte/{angebotId}/annahme
     * Mit Idempotency-Key
     */
    fun akzeptiereAngebotUndErzeugeGeschaeft(
        angebotId: String,
        idempotencyKey: String,
        correlationId: String = "COR-${(10000..99999).random()}"
    ): Result<Deal> {
        // 1. Idempotenz-Prüfung
        idempotencyCache[idempotencyKey]?.let { existingDeal ->
            return Result.success(existingDeal)
        }

        val currState = _state.value
        val quote = currState.quotes.find { it.angebotsId == angebotId }
            ?: return Result.failure(IllegalArgumentException("Angebot $angebotId wurde nicht gefunden."))

        if (quote.status != QuoteStatus.AUSGESTELLT && quote.status != QuoteStatus.BERECHNET) {
            return Result.failure(IllegalStateException("Angebot $angebotId befindet sich im Status ${quote.status.displayName} und kann nicht angenommen werden."))
        }

        val kunde = currState.customers.find { it.id == quote.kundeId } ?: initialCustomer

        // 2. Compliance & Kreditlimit Prüfung
        val complianceRes = ComplianceEngine.pruefeGeschaeftCompliance(
            kunde = kunde,
            handelswert = quote.gesamtwert,
            lieferlandIso = kunde.landIso,
            aktuellerBenutzerRole = currState.tenantContext.userRole
        )

        if (complianceRes.status == ComplianceStatus.GESCHAEFT_BLOCKIERT) {
            return Result.failure(IllegalStateException("Geschäft blockiert wegen Compliance: ${complianceRes.abweichungsGruende.joinToString("; ")}"))
        }

        // 3. Deal Objekt erzeugen
        val geschaeftId = "GES-2026-${(100000..999999).random()}"
        val deal = Deal(
            geschaeftId = geschaeftId,
            angebotId = angebotId,
            kundeId = kunde.id,
            kundenName = kunde.firmenname,
            status = DealStatus.BESTAETIGT,
            preisSnapshot = quote.snapshot,
            gesamtwert = quote.gesamtwert,
            erstellerUser = currState.tenantContext.userEmail,
            erstellerZeitstempel = Instant.now().toString(),
            idempotencyKey = idempotencyKey,
            correlationId = correlationId
        )

        // 4. Vertrag erzeugen
        val vertrag = Contract(
            vertragsNummer = "VT-2026-${(10000..99999).random()}",
            geschaeftId = geschaeftId,
            kaeufer = kunde.legalEntity,
            verkaeufer = "PetroTrade Europe B.V.",
            produktName = quote.produktName,
            menge = quote.menge,
            vereinbarterPreis = quote.preisBreakdown.endpreisProEinheit,
            preisformelHinweis = quote.preisBreakdown.berechnungsFormelString,
            waehrung = quote.waehrung,
            incoterm = IncotermCode.valueOf(quote.incoterm.uppercase()),
            lieferort = quote.lieferort,
            lieferfenster = quote.lieferfenster,
            qualitaetsAnforderungen = "Gemäß Spezifikation ${quote.snapshot.produktSpezifikationCode} schwefelarm max 10 ppm",
            zahlungsBedingungen = kunde.paymentTerms.bezeichnung,
            eigentumsUebergang = "Eigentumsübertragung nach physikalischer Übergabe am Terminal",
            risikoTransfer = "Gefahrenübergang gemäß Incoterm ${quote.incoterm} ${quote.lieferort}",
            vertragsStatus = ContractStatus.RECHTSGUELTIG,
            erstellungsDatum = Instant.now().toString()
        )

        // 5. Allokation im Tanklager erzeugen
        val (allokation, aktualisierteTerminals) = AllocationEngine.erzeugeAllokation(
            vertragId = vertrag.vertragsNummer,
            geschaeftId = geschaeftId,
            sollMengeMT = quote.menge.value,
            produktId = quote.produktId,
            verfuegbareTerminals = currState.terminals
        )

        // 6. Logistik & Shipment erzeugen
        val shipment = Shipment(
            lieferungsId = "LFR-2026-${(10000..99999).random()}",
            vertragId = vertrag.vertragsNummer,
            geschaeftId = geschaeftId,
            kundenName = kunde.firmenname,
            produktName = quote.produktName,
            sollmmenge = quote.menge,
            effektiveLiefermenge = quote.menge,
            lieferort = quote.lieferort,
            transportMode = TransportMode.BINNENSCHIFF,
            transportEtappen = listOf(
                TransportLeg(
                    etappenNummer = 1,
                    transportMode = TransportMode.BINNENSCHIFF,
                    verladestelle = "Tanklager Hamburg Nord-Elbe Terminal 1",
                    zielstelle = quote.lieferort,
                    transportmittelKennung = "MTS ELBE-PETRO 92 (Binnenschiff)",
                    geplanteAbfahrt = quote.lieferfenster.von,
                    geplanteAnkunft = quote.lieferfenster.bis
                )
            ),
            deliveryWindow = quote.lieferfenster,
            status = DeliveryStatus.VERSANDBEREIT,
            chargenNummer = allokation.allokationen.firstOrNull()?.chargenId ?: "CH-2026-DIESEL-901",
            fuehrendesBinnenschiffOderFahrzeug = "MTS ELBE-PETRO 92",
            aktuellerStandort = "Hamburg Hafen Pier 4"
        )

        // 7. Rechnung erzeugen
        val netAmt = quote.gesamtwert
        val taxAmt = netAmt * BigDecimal("0.19")
        val grossAmt = netAmt + taxAmt

        val rechnung = Invoice(
            rechnungsNummer = "REC-2026-${(100000..999999).random()}",
            lieferungsId = shipment.lieferungsId,
            vertragId = vertrag.vertragsNummer,
            geschaeftId = geschaeftId,
            kundeId = kunde.id,
            empfaengerLegalEntity = kunde.legalEntity,
            nettowert = netAmt,
            steuernBetrag = taxAmt,
            zuschlaegeBetrag = Money.zero(quote.waehrung),
            rabatteBetrag = Money.zero(quote.waehrung),
            gesamtbetrag = grossAmt,
            offenBetrag = grossAmt,
            waehrung = quote.waehrung,
            rechnungsDatum = Instant.now().toString(),
            zahlungsZielDatum = LocalDate.now().plusDays(30).toString(),
            paymentTerms = kunde.paymentTerms,
            status = InvoiceStatus.AUSGESTELLT
        )

        // 8. Settlement vorbereiten
        val settlement = Settlement(
            abrechnungsId = "SET-2026-${(1000..9999).random()}",
            rechnungsNummer = rechnung.rechnungsNummer,
            kundeId = kunde.id,
            kundenName = kunde.firmenname,
            rechnungsBetrag = grossAmt,
            erfassteZahlungen = emptyList(),
            kumulierteZahlungen = Money.zero(quote.waehrung),
            verbleibenderOffenerBetrag = grossAmt,
            differenzTyp = SettlementDiscrepancyType.KEINE,
            statusText = "Rechnung ausgestellt - Warten auf Zahlungsziel (30 Tage)"
        )

        // Status des Angebots aktualisieren
        val updatedQuotes = currState.quotes.map {
            if (it.angebotsId == angebotId) it.copy(status = QuoteStatus.ANGENOMMEN) else it
        }

        // Audit & Webhook
        val auditList = mutableListOf<AuditEvent>()
        auditList.add(AuditEvent("AUD-${(100000..999999).random()}", Instant.now().toString(), currState.tenantContext.userEmail, currState.tenantContext.tenantName, AuditEventType.ANGEBOT_ANGENOMMEN, angebotId, "AUSGESTELLT", "ANGENOMMEN", correlationId = correlationId))
        auditList.add(AuditEvent("AUD-${(100000..999999).random()}", Instant.now().toString(), currState.tenantContext.userEmail, currState.tenantContext.tenantName, AuditEventType.GESCHAEFT_ERSTELLT, geschaeftId, null, "Status: BESTAETIGT, Betrag: ${deal.gesamtwert.formatted()}", correlationId = correlationId))
        auditList.add(AuditEvent("AUD-${(100000..999999).random()}", Instant.now().toString(), currState.tenantContext.userEmail, currState.tenantContext.tenantName, AuditEventType.ALLOKATION_ERSTELLT, allokation.allokationsId, null, "Menge: ${allokation.gesamtMengeMT} MT", correlationId = correlationId))
        auditList.add(AuditEvent("AUD-${(100000..999999).random()}", Instant.now().toString(), currState.tenantContext.userEmail, currState.tenantContext.tenantName, AuditEventType.RECHNUNG_ERSTELLT, rechnung.rechnungsNummer, null, "Betrag: ${rechnung.gesamtbetrag.formatted()}", correlationId = correlationId))

        val webhook = WebhookEvent(
            eventId = "WH-2026-${(10000..99999).random()}",
            topic = "geschaeft.bestaetigt",
            payloadJson = "{\"geschaeftId\":\"$geschaeftId\",\"status\":\"BESTAETIGT\",\"angebotId\":\"$angebotId\",\"gesamtwert\":\"${deal.gesamtwert.formatted()}\"}",
            hmacSignature = "sha256=a8f93c01b9382f71029831...",
            erstellungsZeitstempel = Instant.now().toString()
        )

        idempotencyCache[idempotencyKey] = deal

        _state.value = currState.copy(
            quotes = updatedQuotes,
            deals = listOf(deal) + currState.deals,
            contracts = listOf(vertrag) + currState.contracts,
            terminals = aktualisierteTerminals,
            allocations = listOf(allokation) + currState.allocations,
            shipments = listOf(shipment) + currState.shipments,
            invoices = listOf(rechnung) + currState.invoices,
            settlements = listOf(settlement) + currState.settlements,
            auditLogs = auditList + currState.auditLogs,
            webhooks = listOf(webhook) + currState.webhooks
        )

        return Result.success(deal)
    }

    fun bucheZahlungFuerSettlement(
        rechnungsNummer: String,
        zahlungsBetragVal: Double,
        buchungsRef: String
    ): Settlement {
        val currState = _state.value
        val invoice = currState.invoices.find { it.rechnungsNummer == rechnungsNummer }
            ?: throw IllegalArgumentException("Rechnung $rechnungsNummer nicht gefunden")

        val payment = Payment(
            zahlungsId = "ZHL-2026-${(10000..99999).random()}",
            rechnungsNummer = rechnungsNummer,
            betrag = Money.of(zahlungsBetragVal, invoice.waehrung),
            zahlungsDatum = LocalDate.now().toString(),
            buchungsReferenz = buchungsRef,
            zahlungsArt = "SEPA_OVERNIGHT"
        )

        val targetSettlement = currState.settlements.find { it.rechnungsNummer == rechnungsNummer }
            ?: Settlement("SET-${(1000..9999).random()}", rechnungsNummer, invoice.kundeId, invoice.empfaengerLegalEntity, invoice.gesamtbetrag, emptyList(), Money.zero(invoice.waehrung), invoice.gesamtbetrag, SettlementDiscrepancyType.KEINE, "Erfasst")

        val newPayments = targetSettlement.erfassteZahlungen + payment
        val newKumulierte = targetSettlement.kumulierteZahlungen + payment.betrag
        val newOffen = targetSettlement.rechnungsBetrag - newKumulierte

        val diffTyp = when {
            newOffen.amount == BigDecimal.ZERO -> SettlementDiscrepancyType.KEINE
            newOffen.amount > BigDecimal.ZERO -> SettlementDiscrepancyType.UNTERZAHLUNG
            else -> SettlementDiscrepancyType.UEBERZAHLUNG
        }

        val updatedSettlement = targetSettlement.copy(
            erfassteZahlungen = newPayments,
            kumulierteZahlungen = newKumulierte,
            verbleibenderOffenerBetrag = newOffen,
            differenzTyp = diffTyp,
            statusText = if (newOffen.amount <= BigDecimal.ZERO) "Rechnung vollständig beglichen!" else "Teilzahlung verbucht. Offener Restbetrag: ${newOffen.formatted()}"
        )

        val updatedInvoices = currState.invoices.map {
            if (it.rechnungsNummer == rechnungsNummer) {
                it.copy(
                    offenBetrag = newOffen,
                    status = if (newOffen.amount <= BigDecimal.ZERO) InvoiceStatus.BEZAHLT else InvoiceStatus.PARTIELL_BEZAHLT
                )
            } else it
        }

        val updatedSettlements = currState.settlements.map {
            if (it.rechnungsNummer == rechnungsNummer) updatedSettlement else it
        }

        val newAudit = AuditEvent(
            eventId = "AUD-${(100000..999999).random()}",
            zeitpunkt = Instant.now().toString(),
            benutzer = currState.tenantContext.userEmail,
            organisation = currState.tenantContext.tenantName,
            aktion = AuditEventType.ZAHLUNG_VERBUCHT,
            zielObjektId = rechnungsNummer,
            alterZustand = "Offen: ${targetSettlement.verbleibenderOffenerBetrag.formatted()}",
            neuerZustand = "Zahlung verbucht: ${payment.betrag.formatted()}, Rest: ${newOffen.formatted()}",
            correlationId = "COR-${(10000..99999).random()}"
        )

        _state.value = currState.copy(
            invoices = updatedInvoices,
            settlements = updatedSettlements,
            auditLogs = listOf(newAudit) + currState.auditLogs
        )

        return updatedSettlement
    }

    fun advanceShipmentStatus(lieferungsId: String): Shipment {
        val currState = _state.value
        val shipment = currState.shipments.find { it.lieferungsId == lieferungsId }
            ?: throw IllegalArgumentException("Lieferung $lieferungsId nicht gefunden")

        val nextStatus = when (shipment.status) {
            DeliveryStatus.GEPLANT -> DeliveryStatus.ALLOKIERT
            DeliveryStatus.ALLOKIERT -> DeliveryStatus.VERSANDBEREIT
            DeliveryStatus.VERSANDBEREIT -> DeliveryStatus.VERLADUNG
            DeliveryStatus.VERLADUNG -> DeliveryStatus.UNTERWEGS
            DeliveryStatus.UNTERWEGS -> DeliveryStatus.ANGEKOMMEN
            DeliveryStatus.ANGEKOMMEN -> DeliveryStatus.GELIEFERT
            DeliveryStatus.GELIEFERT -> DeliveryStatus.ABGESCHLOSSEN
            DeliveryStatus.ABGESCHLOSSEN -> DeliveryStatus.ABGESCHLOSSEN
        }

        val updatedShipment = shipment.copy(
            status = nextStatus,
            aktuellerStandort = when (nextStatus) {
                DeliveryStatus.VERLADUNG -> "Terminal Verladesteg Tank 1"
                DeliveryStatus.UNTERWEGS -> "Auf der Elbe Richtung Hamburg-Harburg"
                DeliveryStatus.ANGEKOMMEN -> "Ziel-Anlegestelle Hamburg-Harburg"
                DeliveryStatus.GELIEFERT -> "Kunden-Tanklager entladen"
                else -> shipment.aktuellerStandort
            }
        )

        val updatedList = currState.shipments.map {
            if (it.lieferungsId == lieferungsId) updatedShipment else it
        }

        val newAudit = AuditEvent(
            eventId = "AUD-${(100000..999999).random()}",
            zeitpunkt = Instant.now().toString(),
            benutzer = currState.tenantContext.userEmail,
            organisation = currState.tenantContext.tenantName,
            aktion = AuditEventType.LIEFERUNG_BESTAETIGT,
            zielObjektId = lieferungsId,
            alterZustand = shipment.status.displayName,
            neuerZustand = nextStatus.displayName,
            correlationId = "COR-${(10000..99999).random()}"
        )

        _state.value = currState.copy(
            shipments = updatedList,
            auditLogs = listOf(newAudit) + currState.auditLogs
        )

        return updatedShipment
    }
}
