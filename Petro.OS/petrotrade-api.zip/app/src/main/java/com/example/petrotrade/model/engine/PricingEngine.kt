package com.example.petrotrade.model.engine

import com.example.petrotrade.model.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant

/**
 * Das Herzstück der API: PricingEngine
 * Berechnet Verkaufspreise aus Referenzpreis, Differential, Qualitätsanpassung, Logistik,
 * Lagerung, Fracht, Versicherung, Zuschlägen, Rabatten und Finanzierungskosten.
 */
object PricingEngine {

    fun berechneVerkaufspreis(
        produkt: Product,
        menge: Quantity,
        incoterm: String,
        lieferort: String,
        zielWaehrung: String,
        marktReferenzPreis: MarketPrice,
        customDifferential: BigDecimal = BigDecimal("12.50"),
        customFracht: BigDecimal = BigDecimal("18.00"),
        customRabatt: BigDecimal = BigDecimal.ZERO
    ): PricingBreakdown {
        // 1. Umrechnung der Referenz-Mengeneinheit falls notwendig
        val basisRefBetrag = marktReferenzPreis.preis.amount

        // 2. Qualitätsanpassung (z.B. Schwefelgehalt < 10 ppm gibt 2.50 EUR/MT Qualitätsbonus)
        val qualitaetsBonus = if (produkt.schwefelgehaltMgKg <= 10.0) BigDecimal("2.50") else BigDecimal.ZERO

        // 3. Incoterm & Logistik-Zuschläge
        val terminalGebuehr = when (incoterm.uppercase()) {
            "EXW" -> BigDecimal.ZERO
            "FOB" -> BigDecimal("3.50")
            "DAP" -> BigDecimal("6.00")
            "DDP" -> BigDecimal("11.00")
            else -> BigDecimal("5.00")
        }

        // 4. Fracht & Versicherung
        val frachtBetrag = if (incoterm.uppercase() in listOf("DAP", "DDP", "CIF", "CIP")) customFracht else BigDecimal.ZERO
        val versicherungsAnteil = if (incoterm.uppercase() in listOf("CIF", "CIP", "DDP")) basisRefBetrag * BigDecimal("0.004") else BigDecimal.ZERO

        // 5. Finanzierungskosten (Zahlungsziel 30 Tage = 0.8% Aufschlag)
        val finanzierung = basisRefBetrag * BigDecimal("0.008")

        val komponenten = mutableListOf<PricingComponent>()

        komponenten.add(PricingComponent(PricingComponentType.REFERENZPREIS, "Marktindex (${marktReferenzPreis.quelle})", Money(basisRefBetrag, zielWaehrung)))
        komponenten.add(PricingComponent(PricingComponentType.PREISDIFFERENZ, "Handelsdifferential $lieferort", Money(customDifferential, zielWaehrung)))

        if (qualitaetsBonus > BigDecimal.ZERO) {
            komponenten.add(PricingComponent(PricingComponentType.QUALITAETSANPASSUNG, "Qualitätsbonus (${produkt.standardSpezifikation.specCode})", Money(qualitaetsBonus, zielWaehrung)))
        }

        if (terminalGebuehr > BigDecimal.ZERO) {
            komponenten.add(PricingComponent(PricingComponentType.LAGERUNG, "Terminal- & Umschlaggebühr", Money(terminalGebuehr, zielWaehrung)))
        }

        if (frachtBetrag > BigDecimal.ZERO) {
            komponenten.add(PricingComponent(PricingComponentType.FRACHT, "Frachtaufschlag ($incoterm $lieferort)", Money(frachtBetrag, zielWaehrung)))
        }

        if (versicherungsAnteil > BigDecimal.ZERO) {
            komponenten.add(PricingComponent(PricingComponentType.VERSICHERUNG, "Transportversicherung", Money(versicherungsAnteil.setScale(2, RoundingMode.HALF_UP), zielWaehrung)))
        }

        komponenten.add(PricingComponent(PricingComponentType.FINANZIERUNGSKOSTEN, "Finanzierung & Zahlungsziel (30 Tage)", Money(finanzierung.setScale(2, RoundingMode.HALF_UP), zielWaehrung)))

        if (customRabatt > BigDecimal.ZERO) {
            komponenten.add(PricingComponent(PricingComponentType.RABATTE, "Kunden-Mengenrabatt", Money(customRabatt, zielWaehrung)))
        }

        // Gesamtsumme pro Einheit
        var totalProEinheit = basisRefBetrag + customDifferential + qualitaetsBonus + terminalGebuehr + frachtBetrag + versicherungsAnteil + finanzierung - customRabatt
        totalProEinheit = totalProEinheit.setScale(2, RoundingMode.HALF_UP)

        val endpreis = Money(totalProEinheit, zielWaehrung)
        val formelString = "(${marktReferenzPreis.quelle} + Diff + Quali + Term + Fracht + Vers + Fin) - Rabatt"

        return PricingBreakdown(
            grundpreisProEinheit = Money(basisRefBetrag, zielWaehrung),
            komponenten = komponenten,
            endpreisProEinheit = endpreis,
            mengeneinheit = menge.unit,
            berechnungsFormelString = formelString,
            berechnungsZeitpunkt = Instant.now().toString()
        )
    }
}
