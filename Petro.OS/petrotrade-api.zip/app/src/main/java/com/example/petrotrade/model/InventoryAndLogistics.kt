package com.example.petrotrade.model

import java.math.BigDecimal

enum class TransportMode(val displayName: String) {
    PIPELINE("Pipeline-Auspumpung"),
    TANKWAGEN("Straßentankwagen (TKW)"),
    BAHN("Kesselwagen / Bahn (RTC)"),
    SCHIFF("Seeschiff / Tanker (Vessel)"),
    BINNENSCHIFF("Binnenschiff (Barge)"),
    CONTAINER("ISO-Tankcontainer")
}

data class Tank(
    val tankId: String,                    // z.B. "TANK-HH-04"
    val tankName: String,                  // z.B. "Tank 4 (EN590 Diesel)"
    val kapazitaetM3: Double,              // z.B. 25000.0 m³
    val gesamtbestandMT: BigDecimal,        // Physikalisch im Tank
    val reservierteMengeMT: BigDecimal,    // Für bestehende Verträge reserviert
    val produktId: String
) {
    val verfuegbareMengeMT: BigDecimal
        get() = (gesamtbestandMT - reservierteMengeMT).coerceAtLeast(BigDecimal.ZERO)
}

data class Batch(
    val chargenId: String,                 // z.B. "CH-2026-DIESEL-091"
    val produktId: String,
    val mengeMT: BigDecimal,
    val herkunft: String,                  // z.B. "Raffinerie Schwedt Destillation 2"
    val produktionsDatum: String,
    val lagerOrt: String,                  // z.B. "Hamburg Tanklager A - Tank 04"
    val zertifikat: QualityCertificate,
    val inspektionsErgebnis: InspectionResult,
    val status: String = "FREIGEGEBEN"
)

data class Terminal(
    val terminalId: String,                // z.B. "TERM-HH-NORTH"
    val name: String,                      // z.B. "Tanklager Hamburg Nord-Elbe"
    val standort: String,                  // z.B. "Hamburg, Deutschland"
    val angebundeneTransportWege: List<TransportMode>,
    val tanks: List<Tank>
) {
    val gesamtVerfuegbarMT: BigDecimal
        get() = tanks.fold(BigDecimal.ZERO) { acc, t -> acc + t.verfuegbareMengeMT }
}

data class TerminalAllocation(
    val terminalId: String,
    val terminalName: String,
    val tankId: String,
    val allokierteMengeMT: BigDecimal,
    val chargenId: String? = null
)

data class Allocation(
    val allokationsId: String,            // z.B. "ALL-2026-90041"
    val vertragId: String,
    val geschaeftId: String,
    val gesamtMengeMT: BigDecimal,
    val allokationen: List<TerminalAllocation>,
    val erstellungsZeitstempel: String,
    val status: String = "AKTIV"
)

enum class DeliveryStatus(val displayName: String) {
    GEPLANT("Geplant"),
    ALLOKIERT("Allokiert"),
    VERSANDBEREIT("Versandbereit"),
    VERLADUNG("In Verladung"),
    UNTERWEGS("Unterwegs / In Transit"),
    ANGEKOMMEN("Am Zielort Angekommen"),
    GELIEFERT("Physical Geliefert & Quittiert"),
    ABGESCHLOSSEN("Logistisch Abgeschlossen");

    fun canTransitionTo(target: DeliveryStatus): Boolean {
        val order = listOf(GEPLANT, ALLOKIERT, VERSANDBEREIT, VERLADUNG, UNTERWEGS, ANGEKOMMEN, GELIEFERT, ABGESCHLOSSEN)
        val currentIndex = order.indexOf(this)
        val targetIndex = order.indexOf(target)
        return targetIndex == currentIndex + 1 || (this == GEPLANT && target == ALLOKIERT)
    }
}

data class TransportLeg(
    val etappenNummer: Int,
    val transportMode: TransportMode,
    val verladestelle: String,
    val zielstelle: String,
    val transportmittelKennung: String, // z.B. "Binnenschiff MTS ELBE 3" oder "Zug-Nr. 49201"
    val geplanteAbfahrt: String,
    val geplanteAnkunft: String
)

data class Shipment(
    val lieferungsId: String,               // z.B. "LFR-2026-77312"
    val vertragId: String,
    val geschaeftId: String,
    val kundenName: String,
    val produktName: String,
    val sollmmenge: Quantity,
    val effektiveLiefermenge: Quantity? = null, // Werden nach Mengenbestätigung im Hafenterminal eingetragen
    val lieferort: String,
    val transportMode: TransportMode,
    val transportEtappen: List<TransportLeg>,
    val deliveryWindow: DeliveryWindow,
    val status: DeliveryStatus,
    val chargenNummer: String,
    val fuehrendesBinnenschiffOderFahrzeug: String,
    val aktuellerStandort: String
)
