package com.example.petrotrade.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupervisorAccount
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.petrotrade.model.*
import com.example.petrotrade.model.engine.ComplianceEngine
import com.example.petrotrade.model.engine.PetroTradeEngine

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComplianceAndRiskScreen() {
    val state by PetroTradeEngine.state.collectAsState()
    var testHandelswertText by remember { mutableStateOf("1250000") } // 1.25M EUR to trigger 4-Eyes Principle!
    var complianceResult by remember { mutableStateOf<ComplianceCheckResult?>(null) }

    val customer = state.customers.first()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Active Tenant Role Switcher
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.SupervisorAccount, contentDescription = null, tint = Color(0xFFF59E0B))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "MANDANTEN- & ROLLEN-STEUERUNG",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Aktueller Mandant: ${state.tenantContext.tenantName} (${state.tenantContext.tenantId})",
                        fontSize = 12.sp,
                        color = Color(0xFF38BDF8)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Rolle Wechseln:", fontSize = 11.sp, color = Color(0xFF94A3B8))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        UserRole.entries.forEach { r ->
                            FilterChip(
                                selected = r == state.tenantContext.userRole,
                                onClick = { PetroTradeEngine.setTenantUserRole(r) },
                                label = { Text(r.name, fontSize = 10.sp) },
                                modifier = Modifier.testTag("switch_role_chip_${r.name}")
                            )
                        }
                    }
                }
            }
        }

        // Customer Credit Limit Meter
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "B2B Kreditlimit-Rechner (${customer.firmenname})",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val info = customer.creditLimitInfo
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Gesamtes Kreditlimit:", fontSize = 12.sp, color = Color(0xFF94A3B8))
                            Text(info.gesamtKreditlimit.formatted(), fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("- Offene Rechnungsforderungen:", fontSize = 12.sp, color = Color(0xFFF87171))
                            Text(info.offeneForderungen.formatted(), fontSize = 12.sp, color = Color(0xFFF87171))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("- Reservierte Angebote & Geschäfte:", fontSize = 12.sp, color = Color(0xFFF59E0B))
                            Text(info.reservierterHandelswert.formatted(), fontSize = 12.sp, color = Color(0xFFF59E0B))
                        }
                        Divider(modifier = Modifier.padding(vertical = 6.dp), color = Color(0xFF334155))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("= Verfügbarer Kredit:", fontSize = 13.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                            Text(info.verfuegbarerKredit.formatted(), fontSize = 13.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Live Compliance Tester
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = Color(0xFFF59E0B))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "COMPLIANCE & VIER-AUGEN-PRINZIP PRÜFER",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = testHandelswertText,
                        onValueChange = { testHandelswertText = it },
                        label = { Text("Geplanter Handelswert (EUR)", fontSize = 11.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("compliance_handelswert_input"),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val betrag = testHandelswertText.toDoubleOrNull() ?: 1250000.0
                            complianceResult = ComplianceEngine.pruefeGeschaeftCompliance(
                                kunde = customer,
                                handelswert = Money.of(betrag, "EUR"),
                                lieferlandIso = "DE",
                                aktuellerBenutzerRole = state.tenantContext.userRole
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("run_compliance_check_button")
                    ) {
                        Text("Compliance & Limit-Prüfung Ausführen", color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    complianceResult?.let { res ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "Prüfungs-ID: ${res.pruefungsId}", fontSize = 11.sp, color = Color(0xFF38BDF8))
                                    StatusBadge(statusText = res.status.displayName, isSuccess = res.status == ComplianceStatus.FREIGEGEBEN)
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Erforderliche Freigabestufe: ${res.erforderlichesFreigabeLevel.displayName}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFF59E0B)
                                )

                                Text(text = "• KYC / KYB Validiert: ${if (res.kycValidiert) "Ja ✓" else "Nein ✗"}", fontSize = 11.sp, color = Color.White)
                                Text(text = "• Sanktionslisten-Check: ${if (res.sanktionslisteOK) "Bestanden ✓" else "Gesperrt ✗"}", fontSize = 11.sp, color = Color.White)
                                Text(text = "• Kreditlimit Ausreichend: ${if (res.kreditlimitAusreichend) "Ja ✓" else "Überschritten ✗"}", fontSize = 11.sp, color = Color.White)

                                if (res.abweichungsGruende.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Hinweise: ${res.abweichungsGruende.joinToString("; ")}",
                                        fontSize = 11.sp,
                                        color = Color(0xFFF87171)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
