package com.example.petrotrade.model

import java.time.Instant

enum class ProductClass(val displayName: String) {
    RAFFINERIEPRODUKT("Raffinerieprodukt"),
    PETROCHEMISCHES_PRODUKT("Petrochemisches Produkt"),
    SPECIALTY_CHEMICAL("Spezialchemikalie"),
    BIOFUEL("Biokraftstoff")
}

enum class DangerousGoodsClass(val code: String, val description: String) {
    CLASS_3_FLAMMABLE_LIQUID("3", "Entzündbare flüssige Stoffe (z.B. Benzin, Diesel, Jet)"),
    CLASS_2_GASES("2.1", "Entzündbare Gase (z.B. LPG, Ethylen)"),
    CLASS_8_CORROSIVE("8", "Ätzende Stoffe"),
    NONE("KEINE", "Kein Gefahrgut")
}

data class QualityParameter(
    val name: String,              // z.B. "Schwefelgehalt", "Dichte bei 15°C", "Oktanzahl ROZ"
    val wert: String,              // z.B. "10", "835.0", "95.0"
    val einheit: String,           // z.B. "mg/kg", "kg/m³", "ROZ"
    val minLimit: String? = null,
    val maxLimit: String? = null
)

data class ProductSpecification(
    val specCode: String,          // z.B. "EN 590", "DIN EN 228", "JET A-1"
    val name: String,              // z.B. "Europäische Dieselspezifikation EN 590"
    val parameterList: List<QualityParameter>
)

data class QualityCertificate(
    val certifikatId: String,
    val ausstellungsDatum: String,
    val pruefLabor: String,        // z.B. "SGS Inspection Services Hamburg"
    val chargenNummer: String,
    val konformitaetBestaetigt: Boolean = true,
    val verifizierteParameter: List<QualityParameter>
)

data class InspectionResult(
    val inspektionsId: String,
    val inspektor: String,
    val datum: String,
    val status: String,            // "BESTANDEN", "ABWEICHUNG_AKZEPTIERT", "ABGELEHNT"
    val bemerkung: String
)

data class Product(
    val id: String,                         // z.B. "DIESEL-EN590"
    val name: String,                       // z.B. "Diesel Kraftstoff"
    val handelsname: String,                // z.B. "Ultraschwefelarmer Diesel EN590"
    val produktKlasse: ProductClass,
    val standardEinheit: QuantityUnit,
    val dichteKgM3: Double,                 // z.B. 835.0
    val schwefelgehaltMgKg: Double,         // z.B. 10.0
    val wassergehaltPpm: Double = 50.0,
    val reinheitProzent: Double = 99.9,
    val oktanzahlCetanzahl: Double? = 51.0, // Cetanzahl für Diesel, ROZ für Benzin
    val temperaturBasisGradC: Double = 15.0,
    val herkunft: String = "Raffinerie Schwedt / Hamburg",
    val zulaessigeMaerkte: List<String> = listOf("EU", "DACH", "ARA_HUB"),
    val gefahrgutKlasse: DangerousGoodsClass = DangerousGoodsClass.CLASS_3_FLAMMABLE_LIQUID,
    val dynamischeParameter: List<QualityParameter> = emptyList(),
    val standardSpezifikation: ProductSpecification
)
