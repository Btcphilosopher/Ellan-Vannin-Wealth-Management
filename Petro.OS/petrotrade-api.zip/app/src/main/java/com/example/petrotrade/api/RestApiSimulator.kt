package com.example.petrotrade.api

import com.example.petrotrade.model.*
import com.example.petrotrade.model.engine.PetroTradeEngine
import java.math.BigDecimal

data class SimHttpResponse(
    val statusCode: Int,
    val headers: Map<String, String>,
    val bodyJson: String
)

object RestApiSimulator {

    fun handleRequest(
        method: String,
        path: String,
        headers: Map<String, String>,
        bodyJson: String?
    ): SimHttpResponse {
        val corrId = headers["X-Correlation-ID"] ?: "COR-${(10000..99999).random()}"
        val respHeaders = mapOf(
            "Content-Type" to "application/json; charset=utf-8",
            "X-Correlation-ID" to corrId,
            "X-Tenant-ID" to (headers["X-Tenant-ID"] ?: "TENANT-PETROTRADE-EU")
        )

        return try {
            when {
                // 1. GET /produkte
                method == "GET" && path.startsWith("/produkte") -> {
                    val products = PetroTradeEngine.state.value.products
                    val json = buildString {
                        append("[\n")
                        append(products.joinToString(",\n") { p ->
                            """  { "produktId": "${p.id}", "name": "${p.name}", "handelsname": "${p.handelsname}", "klasse": "${p.produktKlasse.displayName}", "spezifikation": "${p.standardSpezifikation.specCode}", "dichteKgM3": ${p.dichteKgM3}, "schwefelgehaltMgKg": ${p.schwefelgehaltMgKg} }"""
                        })
                        append("\n]")
                    }
                    SimHttpResponse(200, respHeaders, json)
                }

                // 2. POST /preise
                method == "POST" && path.startsWith("/preise") -> {
                    val mktPrice = PetroTradeEngine.state.value.marketPrices.first()
                    val json = """
{
  "preis": ${mktPrice.preis.amount},
  "waehrung": "${mktPrice.preis.currency}",
  "einheit": "${mktPrice.einheit.name}",
  "preisart": "${mktPrice.preisart.name}",
  "markt": "${mktPrice.markt}",
  "gueltigBis": "${mktPrice.gueltigBis}",
  "isSynthetisch": true
}
                    """.trimIndent()
                    SimHttpResponse(200, respHeaders, json)
                }

                // 3. POST /angebote
                method == "POST" && path.startsWith("/angebote") && !path.contains("/annahme") -> {
                    val quote = PetroTradeEngine.erzeugeAngebot(
                        kundeId = "K-10024",
                        produktId = "DIESEL-EN590",
                        mengeWert = BigDecimal("5000"),
                        mengeneinheit = QuantityUnit.MT,
                        lieferort = "Hamburg",
                        incoterm = "DAP",
                        lieferfenster = DeliveryWindow("2026-10-15", "2026-10-20"),
                        waehrung = "EUR"
                    )
                    val json = """
{
  "angebotsId": "${quote.angebotsId}",
  "status": "${quote.status.name}",
  "kundeId": "${quote.kundeId}",
  "kundenName": "${quote.kundenName}",
  "produktId": "${quote.produktId}",
  "preis": {
    "betrag": ${quote.preisBreakdown.endpreisProEinheit.amount},
    "waehrung": "${quote.waehrung}",
    "einheit": "${quote.menge.unit.name}"
  },
  "gesamtwert": ${quote.gesamtwert.amount},
  "gueltigBis": "${quote.gueltigBis}"
}
                    """.trimIndent()
                    SimHttpResponse(201, respHeaders, json)
                }

                // 4. POST /angebote/{angebotId}/annahme
                method == "POST" && path.contains("/angebote/") && path.endsWith("/annahme") -> {
                    val pathSegments = path.split("/")
                    val angebotId = pathSegments.getOrNull(pathSegments.indexOf("angebote") + 1) ?: "ANG-2026-000184"
                    val idempotencyKey = headers["Idempotency-Key"] ?: headers["idempotency-key"] ?: "KEY-DEF-${(1000..9999).random()}"

                    val result = PetroTradeEngine.akzeptiereAngebotUndErzeugeGeschaeft(
                        angebotId = angebotId,
                        idempotencyKey = idempotencyKey,
                        correlationId = corrId
                    )

                    result.fold(
                        onSuccess = { deal ->
                            val json = """
{
  "geschaeftId": "${deal.geschaeftId}",
  "status": "${deal.status.name}",
  "angebotId": "${deal.angebotId}",
  "kundeId": "${deal.kundeId}",
  "kundenName": "${deal.kundenName}",
  "gesamtwert": {
    "betrag": ${deal.gesamtwert.amount},
    "waehrung": "${deal.gesamtwert.currency}"
  },
  "idempotencyKey": "${deal.idempotencyKey}",
  "erstellerZeitstempel": "${deal.erstellerZeitstempel}"
}
                            """.trimIndent()
                            SimHttpResponse(200, respHeaders, json)
                        },
                        onFailure = { err ->
                            val json = """
{
  "fehler": {
    "code": "ANGEBOT_ABGELAUFEN_ODER_UNGUELTIG",
    "nachricht": "${err.message ?: "Das Angebot kann nicht mehr angenommen werden."}",
    "korrelationsId": "$corrId"
  }
}
                            """.trimIndent()
                            SimHttpResponse(422, respHeaders, json)
                        }
                    )
                }

                // 5. GET /geschaefte
                method == "GET" && path.startsWith("/geschaefte") -> {
                    val deals = PetroTradeEngine.state.value.deals
                    val json = buildString {
                        append("[\n")
                        append(deals.joinToString(",\n") { d ->
                            """  { "geschaeftId": "${d.geschaeftId}", "status": "${d.status.name}", "angebotId": "${d.angebotId}", "kunde": "${d.kundenName}", "gesamtwert": "${d.gesamtwert.formatted()}" }"""
                        })
                        append("\n]")
                    }
                    SimHttpResponse(200, respHeaders, json)
                }

                // 6. GET /allokationen
                method == "GET" && path.startsWith("/allokationen") -> {
                    val allocs = PetroTradeEngine.state.value.allocations
                    val json = buildString {
                        append("[\n")
                        append(allocs.joinToString(",\n") { a ->
                            """  { "allokationsId": "${a.allokationsId}", "vertragId": "${a.vertragId}", "gesamtMengeMT": ${a.gesamtMengeMT}, "status": "${a.status}" }"""
                        })
                        append("\n]")
                    }
                    SimHttpResponse(200, respHeaders, json)
                }

                // 7. GET /lieferungen
                method == "GET" && path.startsWith("/lieferungen") -> {
                    val shipments = PetroTradeEngine.state.value.shipments
                    val json = buildString {
                        append("[\n")
                        append(shipments.joinToString(",\n") { s ->
                            """  { "lieferungsId": "${s.lieferungsId}", "status": "${s.status.name}", "produkt": "${s.produktName}", "menge": "${s.sollmmenge.formatted()}", "ort": "${s.lieferort}" }"""
                        })
                        append("\n]")
                    }
                    SimHttpResponse(200, respHeaders, json)
                }

                // 8. GET /rechnungen
                method == "GET" && path.startsWith("/rechnungen") -> {
                    val invoices = PetroTradeEngine.state.value.invoices
                    val json = buildString {
                        append("[\n")
                        append(invoices.joinToString(",\n") { i ->
                            """  { "rechnungsNummer": "${i.rechnungsNummer}", "status": "${i.status.name}", "gesamtbetrag": "${i.gesamtbetrag.formatted()}", "offenBetrag": "${i.offenBetrag.formatted()}" }"""
                        })
                        append("\n]")
                    }
                    SimHttpResponse(200, respHeaders, json)
                }

                // Default Fallback
                else -> {
                    val json = """
{
  "fehler": {
    "code": "PFAD_NICHT_GEFUNDEN",
    "nachricht": "Der angeforderte Endpoint $method $path existiert nicht in der PetroTrade API.",
    "korrelationsId": "$corrId"
  }
}
                    """.trimIndent()
                    SimHttpResponse(404, respHeaders, json)
                }
            }
        } catch (e: Exception) {
            val json = """
{
  "fehler": {
    "code": "INTERNER_SERVER_FEHLER",
    "nachricht": "Unerwarteter Fehler bei der API-Verarbeitung: ${e.message}",
    "korrelationsId": "$corrId"
  }
}
            """.trimIndent()
            SimHttpResponse(500, respHeaders, json)
        }
    }
}
