package com.example.petrotrade.model

import java.math.BigDecimal

enum class QuoteStatus(val displayName: String) {
    ENTWURF("Entwurf"),
    BERECHNET("Kalkuliert"),
    AUSGESTELLT("Gültig Ausgestellt"),
    ANGENOMMEN("Vom Kunden Angenommen"),
    ABGELEHNT("Abgelehnt"),
    ABGELAUFEN("Abgelaufen");

    fun canTransitionTo(target: QuoteStatus): Boolean {
        return when (this) {
            ENTWURF -> target == BERECHNET || target == ABGELEHNT
            BERECHNET -> target == AUSGESTELLT || target == ENTWURF || target == ABGELEHNT
            AUSGESTELLT -> target == ANGENOMMEN || target == ABGELEHNT || target == ABGELAUFEN
            ANGENOMMEN -> false // Endzustand (erzeugt Geschäft)
            ABGELEHNT -> false
            ABGELAUFEN -> false
        }
    }
}

data class DeliveryWindow(
    val von: String, // YYYY-MM-DD
    val bis: String  // YYYY-MM-DD
) {
    fun formatted(): String = "$von bis $bis"
}

data class QuoteSnapshot(
    val snapshotId: String,
    val erstellerZeitstempel: String,
    val preisquelle: String,
    val basisPreisProEinheit: Money,
    val differentialProEinheit: Money,
    val gebuehrenProEinheit: Money,
    val steuernProzent: BigDecimal,
    val waehrung: String,
    val wechselkursEUR: BigDecimal, // EUR Wechselkurs-Snapshot
    val menge: Quantity,
    val produktId: String,
    val produktSpezifikationCode: String,
    val incotermCode: String,
    val lieferort: String,
    val lieferfenster: DeliveryWindow,
    val gueltigBis: String,
    val version: Int
)

data class Quote(
    val angebotsId: String,                // z.B. "ANG-2026-000184"
    val kundeId: String,                   // z.B. "K-10024"
    val kundenName: String,                // z.B. "DEMO ENERGY GMBH"
    val produktId: String,                // z.B. "DIESEL-EN590"
    val produktName: String,
    val menge: Quantity,
    val lieferort: String,
    val incoterm: String,                  // z.B. "DAP"
    val lieferfenster: DeliveryWindow,
    val waehrung: String,
    val status: QuoteStatus,
    val preisBreakdown: PricingBreakdown,
    val gesamtwert: Money,
    val gueltigBis: String,                // ISO-8601
    val erstelltAm: String,                // ISO-8601
    val version: Int = 1,
    val snapshot: QuoteSnapshot
)
