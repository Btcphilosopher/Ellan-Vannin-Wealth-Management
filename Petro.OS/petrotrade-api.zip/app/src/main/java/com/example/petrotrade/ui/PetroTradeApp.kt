package com.example.petrotrade.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.petrotrade.model.engine.PetroTradeEngine
import com.example.petrotrade.ui.screens.*

enum class PetroTradeTab(
    val title: String,
    val icon: ImageVector,
    val testTag: String
) {
    WORKFLOW("Handelsablauf", Icons.Default.PlayCircle, "tab_workflow"),
    PRICING("Preise & Formeln", Icons.Default.Calculate, "tab_pricing"),
    INVENTORY("Terminals & Bestand", Icons.Default.Storage, "tab_inventory"),
    COMPLIANCE("Compliance & Risiko", Icons.Default.Shield, "tab_compliance"),
    API_CONSOLE("API & Swagger", Icons.Default.Code, "tab_api_console"),
    AUDIT("Audit & Events", Icons.Default.History, "tab_audit")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetroTradeApp() {
    var activeTab by remember { mutableStateOf(PetroTradeTab.WORKFLOW) }
    val state by PetroTradeEngine.state.collectAsState()

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "PETROTRADE",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp,
                                    color = Color(0xFFF59E0B)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "API v1.0",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF38BDF8)
                                )
                            }
                            Text(
                                text = "Digitale Handelsinfrastruktur für Raffinerieprodukte & Petrochemikalien",
                                fontSize = 10.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    },
                    actions = {
                        Box(
                            modifier = Modifier
                                .padding(end = 12.dp)
                                .background(Color(0xFF334155), androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${state.tenantContext.userRole.name} • ${state.tenantContext.tenantName.take(16)}...",
                                fontSize = 11.sp,
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
                )

                // Ticker Bar for Live Synthetic Market Reference Prices
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E293B))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MARKTTICKER (SYNTHETISCH):",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF59E0B)
                    )
                    Spacer(modifier = Modifier.width(8.dp))

                    state.marketPrices.forEach { mp ->
                        Text(
                            text = "${mp.produktId}: ${mp.preis.formatted()} | ",
                            fontSize = 10.sp,
                            color = Color(0xFF38BDF8)
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0F172A)) {
                PetroTradeTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        icon = { Icon(imageVector = tab.icon, contentDescription = tab.title) },
                        label = { Text(tab.title, fontSize = 9.sp, fontWeight = if (activeTab == tab) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFF59E0B),
                            selectedTextColor = Color(0xFFF59E0B),
                            unselectedIconColor = Color(0xFF64748B),
                            unselectedTextColor = Color(0xFF64748B),
                            indicatorColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
        },
        containerColor = Color(0xFF0F172A)
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (activeTab) {
                PetroTradeTab.WORKFLOW -> WorkflowHubScreen()
                PetroTradeTab.PRICING -> PricingEngineScreen()
                PetroTradeTab.INVENTORY -> InventoryScreen()
                PetroTradeTab.COMPLIANCE -> ComplianceAndRiskScreen()
                PetroTradeTab.API_CONSOLE -> ApiConsoleScreen()
                PetroTradeTab.AUDIT -> AuditAndStreamScreen()
            }
        }
    }
}
