package com.example.petrotrade.api

object OpenApiSpec {

    fun getGermanOpenApiJson(): String {
        return """
{
  "openapi": "3.0.3",
  "info": {
    "title": "PETROTRADE API",
    "description": "Digitale Handelsinfrastruktur für Raffinerieprodukte und Petrochemikalien. Vollständige B2B-Prozesskette von Marktpreisen bis zur Rechnungsabrechnung.",
    "version": "1.0.0",
    "contact": {
      "name": "PetroTrade Engineering Support",
      "email": "api-support@petrotrade.de"
    }
  },
  "servers": [
    {
      "url": "https://api.petrotrade.de/api/v1",
      "description": "Produktionsnahe Handels-API"
    }
  ],
  "security": [
    {
      "OAuth2": ["preise:lesen", "angebote:erstellen", "angebote:annehmen", "geschaefte:lesen"]
    }
  ],
  "paths": {
    "/produkte": {
      "get": {
        "summary": "Produktkatalog abfragen",
        "description": "Liefert alle verfügbaren Raffinerieprodukte und Petrochemikalien mit Qualitäts- und Gefahrgutparametern.",
        "responses": {
          "200": {
            "description": "Erfolgreiche Abfrage des Produktkatalogs"
          }
        }
      }
    },
    "/preise": {
      "post": {
        "summary": "Preiskalkulation anfordern",
        "description": "Berechnet den vollständigen Preis-Breakdown (Referenzpreis, Differential, Qualitätsanpassung, Fracht, Umschlag, Versicherung, Rabatt).",
        "responses": {
          "200": {
            "description": "Berechneter Preis-Breakdown"
          }
        }
      }
    },
    "/angebote": {
      "post": {
        "summary": "Kommerzielles Handelsangebot erstellen",
        "description": "Generiert ein unveränderbares Angebot im Status AUSGESTELLT mit Gültigkeitsdauer und Preis-Snapshot.",
        "responses": {
          "201": {
            "description": "Angebot erfolgreich ausgestellt"
          }
        }
      }
    },
    "/angebote/{angebotId}/annahme": {
      "post": {
        "summary": "Handelsabschluss durch Angebotsannahme",
        "description": "Führt Compliance-, Kreditlimit- und Verfügbarkeitsprüfungen durch. Fixiert den Preis-Snapshot und erzeugt ein rechtsgültiges Geschäft mit Vertrag, Allokation und Logistikauftrag. Unterstützt den Idempotency-Key Header.",
        "parameters": [
          {
            "name": "angebotId",
            "in": "path",
            "required": true,
            "schema": { "type": "string" },
            "example": "ANG-2026-000184"
          },
          {
            "name": "Idempotency-Key",
            "in": "header",
            "required": true,
            "schema": { "type": "string" },
            "example": "7f93c8d1-92ba-4b21-9981-a90f"
          }
        ],
        "responses": {
          "200": {
            "description": "Geschäft erfolgreich bestätigt"
          },
          "400": {
            "description": "Ungültiger Angebotsstatus oder abgelaufenes Angebot"
          },
          "422": {
            "description": "Compliance-Sperre oder Kreditlimit überschritten"
          }
        }
      }
    },
    "/geschaefte": {
      "get": {
        "summary": "Bestätigte Handelsgeschäfte abfragen",
        "responses": {
          "200": {
            "description": "Liste der bestätigten Geschäfte"
          }
        }
      }
    },
    "/allokationen": {
      "get": {
        "summary": "Tanklager- & Mengenallokationen abfragen",
        "responses": {
          "200": {
            "description": "Allokationsübersicht"
          }
        }
      }
    },
    "/lieferungen": {
      "get": {
        "summary": "Liefer- & Logistikstatus abfragen",
        "responses": {
          "200": {
            "description": "Lieferaufträge und Transportmedien"
          }
        }
      }
    },
    "/rechnungen": {
      "get": {
        "summary": "Rechnungen & Abrechnung verwalten",
        "responses": {
          "200": {
            "description": "Rechnungsliste"
          }
        }
      }
    }
  }
}
        """.trimIndent()
    }
}
