package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.petrotrade.model.*
import com.example.petrotrade.model.engine.ComplianceEngine
import com.example.petrotrade.model.engine.PetroTradeEngine
import com.example.petrotrade.model.engine.PricingEngine
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.math.BigDecimal

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("PETROTRADE", appName)
    }

    @Test
    fun `test unit converter density math`() {
        val src = Quantity.of(1000.0, QuantityUnit.MT) // 1000 MT Diesel
        val convertedM3 = UnitConverter.convert(src, QuantityUnit.M3, 835.0) // 835 kg/m³
        assertEquals(BigDecimal("1197.605"), convertedM3.value)

        val convertedLiters = UnitConverter.convert(src, QuantityUnit.LITER, 835.0)
        assertEquals(BigDecimal("1197604.790"), convertedLiters.value)
    }

    @Test
    fun `test pricing engine formula breakdown sum invariant`() {
        val product = PetroTradeEngine.state.value.products.first()
        val mktPrice = PetroTradeEngine.state.value.marketPrices.first()

        val breakdown = PricingEngine.berechneVerkaufspreis(
            produkt = product,
            menge = Quantity.of(5000.0, QuantityUnit.MT),
            incoterm = "DAP",
            lieferort = "Hamburg",
            zielWaehrung = "EUR",
            marktReferenzPreis = mktPrice
        )

        val totalValue = breakdown.berechneGesamtwert(BigDecimal("5000"))
        assertTrue(totalValue.amount > BigDecimal.ZERO)
        assertEquals("EUR", totalValue.currency)
    }

    @Test
    fun `test deal acceptance idempotency key`() {
        val quote = PetroTradeEngine.erzeugeAngebot(
            kundeId = "K-10024",
            produktId = "DIESEL-EN590",
            mengeWert = BigDecimal("5000"),
            mengeneinheit = QuantityUnit.MT,
            lieferort = "Hamburg",
            incoterm = "DAP",
            lieferfenster = DeliveryWindow("2026-10-15", "2026-10-20")
        )

        val idempotencyKey = "TEST-IDEMPOTENCY-KEY-99128"

        // First call
        val dealRes1 = PetroTradeEngine.akzeptiereAngebotUndErzeugeGeschaeft(quote.angebotsId, idempotencyKey)
        assertTrue(dealRes1.isSuccess)
        val deal1 = dealRes1.getOrThrow()

        // Second call with same Idempotency-Key
        val dealRes2 = PetroTradeEngine.akzeptiereAngebotUndErzeugeGeschaeft(quote.angebotsId, idempotencyKey)
        assertTrue(dealRes2.isSuccess)
        val deal2 = dealRes2.getOrThrow()

        // Must return identical deal ID
        assertEquals(deal1.geschaeftId, deal2.geschaeftId)
    }
}
