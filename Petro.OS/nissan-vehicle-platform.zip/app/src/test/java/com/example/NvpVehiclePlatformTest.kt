package com.example

import com.example.api.NvpApiService
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.model.ChargingStatus
import com.example.simulation.VehicleSimulationEngine
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NvpVehiclePlatformTest {

    private lateinit var engine: VehicleSimulationEngine
    private lateinit var apiService: NvpApiService

    @Before
    fun setUp() {
        engine = VehicleSimulationEngine()
        apiService = NvpApiService(engine)
    }

    @Test
    fun testInitialVehicleState() {
        val vehicle = engine.vehicleState.value
        assertEquals("NVP-DEMO-001", vehicle.vehicleId)
        assertEquals("Ariya", vehicle.model)
        assertEquals("D", vehicle.gear)
        assertEquals(74, vehicle.speedKph)
        assertTrue(vehicle.batteryPercent > 80f)
        assertEquals(438, vehicle.rangeKm)
    }

    @Test
    fun testChargingStateMachine() {
        assertEquals(ChargingStatus.DISCONNECTED, engine.chargingState.value.status)
        engine.startCharging()
        assertEquals(ChargingStatus.AUTHENTICATING, engine.chargingState.value.status)
        
        engine.stopCharging()
        assertEquals(ChargingStatus.DISCONNECTED, engine.chargingState.value.status)
    }

    @Test
    fun testClimateUpdate() {
        engine.updateClimate(tempC = 24, fan = 4, ac = true, heat = false)
        val climate = engine.climateState.value
        assertEquals(24, climate.cabinTempC)
        assertEquals(4, climate.fanLevel)
        assertTrue(climate.acActive)
        assertFalse(climate.heatingActive)
    }

    @Test
    fun testApiGetVehicle() {
        val response = apiService.executeApiCall("/api/v1/vehicle", "GET", "")
        assertEquals(200, response.statusCode)
        assertTrue(response.responseBodyJson.contains("NVP-DEMO-001"))
        assertTrue(response.responseBodyJson.contains("Ariya"))
    }

    @Test
    fun testApiClimateValidationError() {
        val invalidRequestBody = """{"temperatureC": 35, "fanLevel": 3}"""
        val response = apiService.executeApiCall("/api/v1/climate", "POST", invalidRequestBody)
        assertEquals(400, response.statusCode)
        assertTrue(response.responseBodyJson.contains("INVALID_PARAMETER"))
    }

    @Test
    fun testLocalisation() {
        val jaRange = Strings.t("battery.range", AppLanguage.JA)
        assertEquals("航続可能距離", jaRange)

        val enRange = Strings.t("battery.range", AppLanguage.EN)
        assertEquals("Remaining Range", enRange)
    }
}
