package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.ui.theme.*
import com.example.viewmodel.SurfaceType

@Composable
fun NvpHeaderBar(
    currentLanguage: AppLanguage,
    currentSurface: SurfaceType,
    onLanguageToggle: (AppLanguage) -> Unit,
    onSurfaceSelect: (SurfaceType) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = NissanSurfaceDark,
        tonalElevation = 4.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Nissan Brand & Vehicle Model
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(NissanSurfaceVariantDark)
                            .border(1.dp, NissanBorderDark, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "N",
                            color = NissanElectricBlue,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column {
                        Text(
                            text = Strings.t("app.title", currentLanguage),
                            color = NissanTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = Strings.t("app.vehicle_model", currentLanguage),
                            color = NissanElectricBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 0.8.sp
                        )
                    }
                }

                // Language Selector Toggle
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(NissanSurfaceVariantDark)
                        .border(1.dp, NissanBorderDark, RoundedCornerShape(20.dp))
                        .padding(3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppLanguage.values().forEach { lang ->
                        val isSelected = lang == currentLanguage
                        Box(
                            modifier = Modifier
                                .testTag("lang_toggle_${lang.code}")
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) NissanElectricBlue else Color.Transparent)
                                .clickable { onLanguageToggle(lang) }
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = lang.label,
                                color = if (isSelected) Color.Black else NissanTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Surface Toggle Tabs: DRIVER vs DEVELOPER
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(NissanDarkBackground)
                    .border(1.dp, NissanBorderDark, RoundedCornerShape(8.dp))
                    .padding(3.dp)
            ) {
                SurfaceTabButton(
                    title = Strings.t("nav.driver", currentLanguage),
                    icon = Icons.Default.DirectionsCar,
                    isSelected = currentSurface == SurfaceType.DRIVER,
                    testTag = "surface_driver_tab",
                    onClick = { onSurfaceSelect(SurfaceType.DRIVER) },
                    modifier = Modifier.weight(1f)
                )

                SurfaceTabButton(
                    title = Strings.t("nav.developer", currentLanguage),
                    icon = Icons.Default.Code,
                    isSelected = currentSurface == SurfaceType.DEVELOPER,
                    testTag = "surface_developer_tab",
                    onClick = { onSurfaceSelect(SurfaceType.DEVELOPER) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun SurfaceTabButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) NissanSurfaceVariantDark else Color.Transparent)
            .border(
                width = if (isSelected) 1.dp else 0.dp,
                color = if (isSelected) NissanElectricBlueDim else Color.Transparent,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) NissanElectricBlue else NissanTextMuted,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = title,
                color = if (isSelected) NissanTextPrimary else NissanTextSecondary,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                letterSpacing = 0.5.sp
            )
        }
    }
}
