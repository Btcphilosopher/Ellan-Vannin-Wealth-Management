package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.model.ChargingState
import com.example.model.ChargingStatus
import com.example.ui.theme.*

@Composable
fun ChargingPanelView(
    charging: ChargingState,
    language: AppLanguage,
    onRequestStartCharging: () -> Unit,
    onStopCharging: () -> Unit,
    modifier: Modifier = Modifier
) {
    var targetSocSlider by remember { mutableStateOf(charging.targetSoc.toFloat()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Charging State Machine Card
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = Strings.t("charging.title", language),
                        color = NissanTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = charging.type,
                        color = NissanElectricBlue,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Active State Badge
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            when (charging.status) {
                                ChargingStatus.CHARGING -> NissanRegenGreen.copy(alpha = 0.2f)
                                ChargingStatus.AUTHENTICATING -> NissanWarningAmber.copy(alpha = 0.2f)
                                ChargingStatus.ERROR -> NissanNissanRed.copy(alpha = 0.2f)
                                else -> NissanSurfaceVariantDark
                            }
                        )
                        .border(
                            1.dp,
                            when (charging.status) {
                                ChargingStatus.CHARGING -> NissanRegenGreen
                                ChargingStatus.AUTHENTICATING -> NissanWarningAmber
                                ChargingStatus.ERROR -> NissanNissanRed
                                else -> NissanBorderDark
                            },
                            RoundedCornerShape(8.dp)
                        )
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = when (charging.status) {
                                ChargingStatus.CHARGING -> Icons.Default.Bolt
                                ChargingStatus.AUTHENTICATING -> Icons.Default.Sync
                                ChargingStatus.ERROR -> Icons.Default.Error
                                else -> Icons.Default.Power
                            },
                            contentDescription = null,
                            tint = when (charging.status) {
                                ChargingStatus.CHARGING -> NissanRegenGreen
                                ChargingStatus.AUTHENTICATING -> NissanWarningAmber
                                ChargingStatus.ERROR -> NissanNissanRed
                                else -> NissanTextSecondary
                            }
                        )
                        Text(
                            text = when (charging.status) {
                                ChargingStatus.DISCONNECTED -> Strings.t("charging.disconnected", language)
                                ChargingStatus.CONNECTED -> Strings.t("charging.connected", language)
                                ChargingStatus.AUTHENTICATING -> Strings.t("charging.authenticating", language)
                                ChargingStatus.CHARGING -> Strings.t("charging.charging", language)
                                ChargingStatus.PAUSED -> Strings.t("charging.paused", language)
                                ChargingStatus.COMPLETE -> Strings.t("charging.complete", language)
                                ChargingStatus.ERROR -> Strings.t("charging.error", language)
                            },
                            color = NissanTextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Live Power & Time Remaining metrics
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(NissanSurfaceVariantDark)
                            .border(1.dp, NissanBorderDark, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(text = Strings.t("charging.rate", language), color = NissanTextSecondary, fontSize = 11.sp)
                            Text(
                                text = String.format("%.1f kW", charging.powerKw),
                                color = NissanElectricBlue,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(NissanSurfaceVariantDark)
                            .border(1.dp, NissanBorderDark, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(text = Strings.t("charging.time_remaining", language), color = NissanTextSecondary, fontSize = 11.sp)
                            Text(
                                text = "${charging.timeRemainingMinutes} mins",
                                color = NissanTextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Target SOC Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = Strings.t("charging.target_soc", language), color = NissanTextSecondary, fontSize = 13.sp)
                        Text(text = "${targetSocSlider.toInt()}%", color = NissanElectricBlue, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = targetSocSlider,
                        onValueChange = { targetSocSlider = it },
                        valueRange = 50f..100f,
                        steps = 9,
                        colors = SliderDefaults.colors(
                            thumbColor = NissanElectricBlue,
                            activeTrackColor = NissanElectricBlue
                        )
                    )
                }

                // Action Start / Stop Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (charging.status != ChargingStatus.CHARGING) {
                        Button(
                            onClick = onRequestStartCharging,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("start_charging_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NissanElectricBlue,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = Strings.t("charging.start", language), fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = onStopCharging,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("stop_charging_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NissanNissanRed,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = Strings.t("charging.stop", language), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
