package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun VehicleStatusView(
    vehicle: VehicleState,
    language: AppLanguage,
    onRequestLock: () -> Unit,
    onRequestUnlock: () -> Unit,
    onTriggerHorn: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Core Vehicle Control Card
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = Strings.t("vehicle.status", language),
                    color = NissanTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Lock Control Action
                    ControlStatusTile(
                        icon = if (vehicle.doorsLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                        title = Strings.t("vehicle.doors", language),
                        statusText = if (vehicle.doorsLocked) Strings.t("vehicle.locked", language) else Strings.t("vehicle.unlocked", language),
                        isActive = vehicle.doorsLocked,
                        testTag = "lock_toggle_tile",
                        onClick = {
                            if (vehicle.doorsLocked) onRequestUnlock() else onRequestLock()
                        },
                        modifier = Modifier.weight(1f)
                    )

                    // Windows Tile
                    ControlStatusTile(
                        icon = Icons.Default.Window,
                        title = Strings.t("vehicle.windows", language),
                        statusText = if (vehicle.windowsClosed) Strings.t("vehicle.closed", language) else Strings.t("vehicle.opened", language),
                        isActive = vehicle.windowsClosed,
                        testTag = "windows_tile",
                        onClick = {},
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Lights Tile
                    ControlStatusTile(
                        icon = Icons.Default.LightMode,
                        title = Strings.t("vehicle.lights", language),
                        statusText = Strings.t("vehicle.auto", language),
                        isActive = true,
                        testTag = "lights_tile",
                        onClick = {},
                        modifier = Modifier.weight(1f)
                    )

                    // Horn Action
                    ControlStatusTile(
                        icon = Icons.Default.VolumeUp,
                        title = Strings.t("Horn / クラクション", language),
                        statusText = if (vehicle.hornActive) "SOUNDING!" else "Ready",
                        isActive = vehicle.hornActive,
                        testTag = "horn_tile",
                        onClick = onTriggerHorn,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Tire Pressures Monitoring Card
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Tire Pressure System / 空気圧",
                        color = NissanTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "230 kPa (OK)",
                        color = NissanRegenGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    TirePressureItem("FL", "230 kPa")
                    TirePressureItem("FR", "230 kPa")
                    TirePressureItem("RL", "232 kPa")
                    TirePressureItem("RR", "231 kPa")
                }
            }
        }
    }
}

@Composable
private fun ControlStatusTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    statusText: String,
    isActive: Boolean,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(10.dp))
            .background(NissanSurfaceVariantDark)
            .border(1.dp, if (isActive) NissanElectricBlueDim else NissanBorderDark, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isActive) NissanElectricBlue else NissanTextMuted,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = title,
                    color = NissanTextSecondary,
                    fontSize = 12.sp
                )
            }
            Text(
                text = statusText,
                color = NissanTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun TirePressureItem(label: String, valStr: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .background(NissanSurfaceVariantDark, RoundedCornerShape(8.dp))
            .border(1.dp, NissanBorderDark, RoundedCornerShape(8.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text = label, color = NissanTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text(text = valStr, color = NissanTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
