package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nissan Vehicle Platform (NVP) Japanese Industrial Palette
val NissanDarkBackground = Color(0xFF0E1114)
val NissanSurfaceDark = Color(0xFF161A1E)
val NissanSurfaceVariantDark = Color(0xFF20252B)
val NissanBorderDark = Color(0xFF2E353D)

val NissanElectricBlue = Color(0xFF00D2FF)
val NissanElectricBlueDim = Color(0xFF0088B3)
val NissanRegenGreen = Color(0xFF10B981)
val NissanNissanRed = Color(0xFFE53E3E)
val NissanWarningAmber = Color(0xFFF59E0B)

val NissanTextPrimary = Color(0xFFF1F5F9)
val NissanTextSecondary = Color(0xFF94A3B8)
val NissanTextMuted = Color(0xFF64748B)

val NissanSilverChrome = Color(0xFFE2E8F0)
val NissanGraphite = Color(0xFF1A1D20)
