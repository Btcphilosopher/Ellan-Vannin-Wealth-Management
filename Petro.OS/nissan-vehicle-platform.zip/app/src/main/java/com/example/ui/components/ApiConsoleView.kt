package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.api.ApiEndpointMeta
import com.example.api.ApiResponse
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.ui.theme.*

@Composable
fun ApiConsoleView(
    endpoints: List<ApiEndpointMeta>,
    selectedIndex: Int,
    requestBodyInput: String,
    apiResponse: ApiResponse?,
    language: AppLanguage,
    onSelectEndpoint: (Int) -> Unit,
    onRequestBodyChange: (String) -> Unit,
    onExecuteRequest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    val currentEp = endpoints.getOrNull(selectedIndex)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Endpoint Selection Chips Row
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "NVP API Endpoints / REST API",
                    color = NissanTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                // Scrollable or Column list of endpoints
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    endpoints.forEachIndexed { idx, ep ->
                        val isSelected = idx == selectedIndex
                        Box(
                            modifier = Modifier
                                .testTag("api_endpoint_chip_$idx")
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NissanElectricBlue.copy(alpha = 0.15f) else NissanSurfaceVariantDark)
                                .border(1.dp, if (isSelected) NissanElectricBlue else NissanBorderDark, RoundedCornerShape(8.dp))
                                .clickable { onSelectEndpoint(idx) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (ep.method == "GET") NissanElectricBlue else NissanWarningAmber)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = ep.method,
                                            color = Color.Black,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    Text(
                                        text = ep.path,
                                        color = NissanTextPrimary,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = if (language == AppLanguage.JA) ep.summaryJa else ep.summaryEn,
                                    color = NissanTextSecondary,
                                    fontSize = 11.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // Endpoint Details & Interactive Try Request Box
        if (currentEp != null) {
            Surface(
                color = NissanSurfaceDark,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${currentEp.method} ${currentEp.path}",
                            color = NissanElectricBlue,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        // TRY REQUEST Button
                        Button(
                            onClick = onExecuteRequest,
                            modifier = Modifier.testTag("try_request_btn"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NissanElectricBlue,
                                contentColor = Color.Black
                            )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text(text = Strings.t("api.try_request", language), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    Text(
                        text = if (language == AppLanguage.JA) currentEp.summaryJa else currentEp.summaryEn,
                        color = NissanTextSecondary,
                        fontSize = 13.sp
                    )

                    if (currentEp.method == "POST") {
                        Text(
                            text = "Request Body (JSON)",
                            color = NissanTextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = requestBodyInput,
                            onValueChange = onRequestBodyChange,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                                .testTag("request_body_input"),
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = NissanTextPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NissanElectricBlue,
                                unfocusedBorderColor = NissanBorderDark,
                                focusedContainerColor = NissanSurfaceVariantDark,
                                unfocusedContainerColor = NissanSurfaceVariantDark
                            )
                        )
                    }

                    // Response Output Section
                    if (apiResponse != null) {
                        Divider(color = NissanBorderDark, modifier = Modifier.padding(vertical = 4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (apiResponse.statusCode == 200) NissanRegenGreen else NissanNissanRed)
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${apiResponse.statusCode} ${apiResponse.statusText}",
                                        color = Color.Black,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Text(
                                    text = "${apiResponse.latencyMs} ms",
                                    color = NissanTextMuted,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            IconButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(apiResponse.responseBodyJson))
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("copy_json_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy",
                                    tint = NissanElectricBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Formatted Response Code Block
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(NissanDarkBackground)
                                .border(1.dp, NissanBorderDark, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = apiResponse.responseBodyJson,
                                color = NissanTextPrimary,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
