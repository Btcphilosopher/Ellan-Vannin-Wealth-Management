package com.example.model

enum class DriveMode {
    NORMAL, ECO, SPORT, SNOW
}

enum class ChargingStatus {
    DISCONNECTED, CONNECTED, AUTHENTICATING, CHARGING, PAUSED, COMPLETE, ERROR
}

enum class DiagnosticHealth {
    NORMAL, WARNING, SERVICE_REQUIRED
}

data class DiagnosticCode(
    val code: String,
    val description: String,
    val severity: String,
    val timestamp: String
)

data class VehicleState(
    val vehicleId: String = "NVP-DEMO-001",
    val model: String = "Ariya",
    val variant: String = "e-4ORCE AWD",
    val speedKph: Int = 74,
    val gear: String = "D",
    val batteryPercent: Float = 81.4f,
    val rangeKm: Int = 438,
    val outsideTemperatureC: Int = 18,
    val cabinTemperatureC: Int = 22,
    val driveMode: DriveMode = DriveMode.NORMAL,
    val charging: Boolean = false,
    val chargingStatus: ChargingStatus = ChargingStatus.DISCONNECTED,
    val doorsLocked: Boolean = true,
    val windowsClosed: Boolean = true,
    val lightsMode: String = "AUTO",
    val hornActive: Boolean = false,
    val latitude: Double = 35.6762,
    val longitude: Double = 139.6503,
    val locationName: String = "Tokyo",
    val destination: String = "Yokohama Station",
    val destinationDistanceKm: Float = 31.8f,
    val destinationEtaMinutes: Int = 48,
    val arrivalTime: String = "19:32",
    val motorSpeedRpm: Int = 6200,
    val motorTorqueNm: Float = 240.5f,
    val acceleratorPosition: Float = 32.0f,
    val brakePosition: Float = 0.0f,
    val steeringAngleDeg: Float = 1.2f
)

data class BatteryState(
    val soc: Float = 81.4f,
    val soh: Float = 98.3f,
    val voltage: Float = 708.2f,
    val current: Float = -38.4f,
    val powerKw: Float = 27.2f,
    val temperatureC: Float = 28.7f,
    val rangeKm: Int = 438,
    val capacityKwh: Float = 87.0f,
    val consumptionKwhPer100Km: Float = 18.2f
)

data class ChargingState(
    val status: ChargingStatus = ChargingStatus.DISCONNECTED,
    val type: String = "DC Fast Charging",
    val powerKw: Float = 0.0f,
    val voltage: Float = 708.0f,
    val current: Float = 0.0f,
    val timeRemainingMinutes: Int = 0,
    val targetSoc: Int = 90
)

data class ClimateState(
    val cabinTempC: Int = 22,
    val driverTempC: Int = 22,
    val passengerTempC: Int = 22,
    val fanLevel: Int = 3,
    val acActive: Boolean = true,
    val heatingActive: Boolean = false,
    val defrostActive: Boolean = false,
    val recircActive: Boolean = true,
    val driverSeatHeating: Int = 1,
    val passengerSeatHeating: Int = 0,
    val steeringHeatActive: Boolean = false
)

data class EnergyState(
    val drivingKwh: Float = 18.2f,
    val climateKwh: Float = 1.1f,
    val batteryConditioningKwh: Float = 0.4f,
    val regenerationKwh: Float = -3.4f,
    val netKwh: Float = 16.3f
)

data class DiagnosticsState(
    val batteryStatus: DiagnosticHealth = DiagnosticHealth.NORMAL,
    val motorStatus: DiagnosticHealth = DiagnosticHealth.NORMAL,
    val inverterStatus: DiagnosticHealth = DiagnosticHealth.NORMAL,
    val chargingStatus: DiagnosticHealth = DiagnosticHealth.NORMAL,
    val hvacStatus: DiagnosticHealth = DiagnosticHealth.NORMAL,
    val connectivityStatus: DiagnosticHealth = DiagnosticHealth.NORMAL,
    val activeDtcCodes: List<DiagnosticCode> = emptyList()
)

data class ConnectedServicesState(
    val vehicleConnected: Boolean = true,
    val remoteClimateAvailable: Boolean = true,
    val vehicleLocationAvailable: Boolean = true,
    val chargingStatusAvailable: Boolean = true,
    val digitalKeyActive: Boolean = true,
    val digitalKeyDevice: String = "iPhone 15 Pro Demo",
    val serviceStatus: String = "Normal"
)

data class TelemetryPoint(
    val timestampMs: Long,
    val timestampFormatted: String,
    val eventType: String,
    val value: String,
    val speedKph: Float,
    val batterySoc: Float,
    val powerKw: Float,
    val motorTempC: Float,
    val batteryTempC: Float
)

data class ApiErrorDetails(
    val code: String,
    val message: String,
    val requestId: String
)

data class ApiErrorResponse(
    val error: ApiErrorDetails
)
