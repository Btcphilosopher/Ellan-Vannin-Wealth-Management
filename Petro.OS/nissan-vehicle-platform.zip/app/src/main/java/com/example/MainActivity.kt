package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.NissanDarkBackground
import com.example.ui.theme.NvpTheme
import com.example.viewmodel.*

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            NvpTheme {
                NvpMainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun NvpMainApp(viewModel: MainViewModel) {
    val language by viewModel.language.collectAsStateWithLifecycle()
    val surface by viewModel.surface.collectAsStateWithLifecycle()
    val driverTab by viewModel.driverTab.collectAsStateWithLifecycle()
    val developerTab by viewModel.developerTab.collectAsStateWithLifecycle()
    val confirmationDialog by viewModel.confirmationDialog.collectAsStateWithLifecycle()

    val vehicleState by viewModel.vehicleState.collectAsStateWithLifecycle()
    val batteryState by viewModel.batteryState.collectAsStateWithLifecycle()
    val chargingState by viewModel.chargingState.collectAsStateWithLifecycle()
    val climateState by viewModel.climateState.collectAsStateWithLifecycle()
    val energyState by viewModel.energyState.collectAsStateWithLifecycle()
    val diagnosticsState by viewModel.diagnosticsState.collectAsStateWithLifecycle()
    val connectedState by viewModel.connectedState.collectAsStateWithLifecycle()
    val telemetryStream by viewModel.telemetryStream.collectAsStateWithLifecycle()
    val telemetryHistory by viewModel.telemetryHistory.collectAsStateWithLifecycle()

    val selectedEndpointIndex by viewModel.selectedEndpointIndex.collectAsStateWithLifecycle()
    val requestBodyInput by viewModel.requestBodyInput.collectAsStateWithLifecycle()
    val apiResponseResult by viewModel.apiResponseResult.collectAsStateWithLifecycle()
    val eventFilter by viewModel.eventFilter.collectAsStateWithLifecycle()
    val graphTimeRange by viewModel.graphTimeRange.collectAsStateWithLifecycle()

    // Handle back button behavior
    BackHandler(enabled = driverTab != DriverTab.COCKPIT || surface != SurfaceType.DRIVER) {
        if (surface == SurfaceType.DEVELOPER) {
            viewModel.setSurface(SurfaceType.DRIVER)
        } else if (driverTab != DriverTab.COCKPIT) {
            viewModel.setDriverTab(DriverTab.COCKPIT)
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(NissanDarkBackground),
        topBar = {
            NvpHeaderBar(
                currentLanguage = language,
                currentSurface = surface,
                onLanguageToggle = { viewModel.setLanguage(it) },
                onSurfaceSelect = { viewModel.setSurface(it) },
                modifier = Modifier.statusBarsPadding()
            )
        },
        bottomBar = {
            if (surface == SurfaceType.DRIVER) {
                DriverBottomNav(
                    activeTab = driverTab,
                    language = language,
                    onTabSelect = { viewModel.setDriverTab(it) }
                )
            } else {
                DeveloperBottomNav(
                    activeTab = developerTab,
                    language = language,
                    onTabSelect = { viewModel.setDeveloperTab(it) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(NissanDarkBackground)
        ) {
            if (surface == SurfaceType.DRIVER) {
                when (driverTab) {
                    DriverTab.COCKPIT -> DigitalCockpitView(
                        vehicle = vehicleState,
                        language = language,
                        onGearSelect = { viewModel.setGear(it) },
                        onDriveModeSelect = { viewModel.setDriveMode(it) }
                    )

                    DriverTab.STATUS -> VehicleStatusView(
                        vehicle = vehicleState,
                        language = language,
                        onRequestLock = { viewModel.requestLockVehicle() },
                        onRequestUnlock = { viewModel.requestUnlockVehicle() },
                        onTriggerHorn = { viewModel.triggerHorn() }
                    )

                    DriverTab.BATTERY -> BatteryEnergyView(
                        battery = batteryState,
                        energy = energyState,
                        language = language
                    )

                    DriverTab.CHARGING -> ChargingPanelView(
                        charging = chargingState,
                        language = language,
                        onRequestStartCharging = { viewModel.requestStartCharging() },
                        onStopCharging = { viewModel.stopCharging() }
                    )

                    DriverTab.CLIMATE -> ClimatePanelView(
                        climate = climateState,
                        language = language,
                        onUpdateClimate = { temp, fan, ac, heat ->
                            viewModel.updateClimate(temp, fan, ac, heat)
                        }
                    )

                    DriverTab.NAVIGATION -> NavigationPanelView(
                        vehicle = vehicleState,
                        language = language,
                        onSelectDestination = { viewModel.engine.setDestination(it) }
                    )

                    DriverTab.CONNECTED -> ConnectedServicesView(
                        connected = connectedState,
                        language = language,
                        onRequestLock = { viewModel.requestLockVehicle() },
                        onRequestUnlock = { viewModel.requestUnlockVehicle() }
                    )

                    DriverTab.DIAGNOSTICS -> DiagnosticsView(
                        diagnostics = diagnosticsState,
                        language = language,
                        onTriggerFault = { viewModel.triggerFault() },
                        onClearFaults = { viewModel.clearFaults() }
                    )
                }
            } else {
                when (developerTab) {
                    DeveloperTab.API_CONSOLE -> ApiConsoleView(
                        endpoints = viewModel.apiService.endpoints,
                        selectedIndex = selectedEndpointIndex,
                        requestBodyInput = requestBodyInput,
                        apiResponse = apiResponseResult,
                        language = language,
                        onSelectEndpoint = { viewModel.selectApiEndpoint(it) },
                        onRequestBodyChange = { viewModel.setRequestBodyInput(it) },
                        onExecuteRequest = { viewModel.executeApiRequest() }
                    )

                    DeveloperTab.TELEMETRY_STREAM -> TelemetryStreamView(
                        telemetryStream = telemetryStream,
                        isPaused = viewModel.engine.isPaused(),
                        filter = eventFilter,
                        language = language,
                        onTogglePause = { viewModel.toggleStreamPause() },
                        onFilterChange = { viewModel.setEventFilter(it) }
                    )

                    DeveloperTab.TELEMETRY_GRAPHS -> TelemetryGraphView(
                        history = telemetryHistory,
                        timeRange = graphTimeRange,
                        language = language,
                        onTimeRangeSelect = { viewModel.setGraphTimeRange(it) }
                    )
                }
            }

            // Command Confirmation Modal
            ConfirmationModal(
                dialogState = confirmationDialog,
                language = language,
                onDismiss = { viewModel.closeConfirmationDialog() }
            )
        }
    }
}
