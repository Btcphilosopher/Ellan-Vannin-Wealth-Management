package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.ui.theme.*
import com.example.viewmodel.DeveloperTab
import com.example.viewmodel.DriverTab

@Composable
fun DriverBottomNav(
    activeTab: DriverTab,
    language: AppLanguage,
    onTabSelect: (DriverTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = NissanSurfaceDark,
        tonalElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        ScrollableTabRow(
            selectedTabIndex = activeTab.ordinal,
            containerColor = NissanSurfaceDark,
            contentColor = NissanElectricBlue,
            edgePadding = 8.dp,
            divider = {}
        ) {
            DriverTab.values().forEach { tab ->
                val isSelected = tab == activeTab
                Tab(
                    selected = isSelected,
                    onClick = { onTabSelect(tab) },
                    modifier = Modifier
                        .testTag("driver_tab_${tab.name}")
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    text = {
                        Text(
                            text = when (tab) {
                                DriverTab.COCKPIT -> Strings.t("tab.cockpit", language)
                                DriverTab.STATUS -> Strings.t("tab.status", language)
                                DriverTab.BATTERY -> Strings.t("tab.battery", language)
                                DriverTab.CHARGING -> Strings.t("tab.charging", language)
                                DriverTab.CLIMATE -> Strings.t("tab.climate", language)
                                DriverTab.NAVIGATION -> Strings.t("tab.navigation", language)
                                DriverTab.CONNECTED -> Strings.t("tab.connected", language)
                                DriverTab.DIAGNOSTICS -> Strings.t("tab.diagnostics", language)
                            },
                            color = if (isSelected) NissanElectricBlue else NissanTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    icon = {
                        Icon(
                            imageVector = when (tab) {
                                DriverTab.COCKPIT -> Icons.Default.Speed
                                DriverTab.STATUS -> Icons.Default.DirectionsCar
                                DriverTab.BATTERY -> Icons.Default.BatteryChargingFull
                                DriverTab.CHARGING -> Icons.Default.EvStation
                                DriverTab.CLIMATE -> Icons.Default.AcUnit
                                DriverTab.NAVIGATION -> Icons.Default.Navigation
                                DriverTab.CONNECTED -> Icons.Default.CellTower
                                DriverTab.DIAGNOSTICS -> Icons.Default.Build
                            },
                            contentDescription = null,
                            tint = if (isSelected) NissanElectricBlue else NissanTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )
            }
        }
    }
}

@Composable
fun DeveloperBottomNav(
    activeTab: DeveloperTab,
    language: AppLanguage,
    onTabSelect: (DeveloperTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = NissanSurfaceDark,
        tonalElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            DeveloperTab.values().forEach { tab ->
                val isSelected = tab == activeTab
                Box(
                    modifier = Modifier
                        .testTag("developer_tab_${tab.name}")
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) NissanSurfaceVariantDark else Color.Transparent)
                        .border(1.dp, if (isSelected) NissanElectricBlueDim else Color.Transparent, RoundedCornerShape(8.dp))
                        .clickable { onTabSelect(tab) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = when (tab) {
                                DeveloperTab.API_CONSOLE -> Icons.Default.Api
                                DeveloperTab.TELEMETRY_STREAM -> Icons.Default.Terminal
                                DeveloperTab.TELEMETRY_GRAPHS -> Icons.Default.ShowChart
                            },
                            contentDescription = null,
                            tint = if (isSelected) NissanElectricBlue else NissanTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = when (tab) {
                                DeveloperTab.API_CONSOLE -> Strings.t("tab.api_console", language)
                                DeveloperTab.TELEMETRY_STREAM -> Strings.t("tab.telemetry_stream", language)
                                DeveloperTab.TELEMETRY_GRAPHS -> Strings.t("tab.telemetry_graphs", language)
                            },
                            color = if (isSelected) NissanTextPrimary else NissanTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
