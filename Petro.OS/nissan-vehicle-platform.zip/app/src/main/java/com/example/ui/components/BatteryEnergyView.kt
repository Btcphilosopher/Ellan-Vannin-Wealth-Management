package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.model.BatteryState
import com.example.model.EnergyState
import com.example.ui.theme.*

@Composable
fun BatteryEnergyView(
    battery: BatteryState,
    energy: EnergyState,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // High-Voltage Battery Telemetry Grid Card
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = Strings.t("battery.title", language),
                        color = NissanTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "87.0 kWh Nominal",
                        color = NissanElectricBlue,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BatteryMetricCard(
                        title = Strings.t("battery.soc", language),
                        value = String.format("%.1f%%", battery.soc),
                        color = NissanRegenGreen,
                        modifier = Modifier.weight(1f)
                    )
                    BatteryMetricCard(
                        title = Strings.t("battery.soh", language),
                        value = String.format("%.1f%%", battery.soh),
                        color = NissanElectricBlue,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BatteryMetricCard(
                        title = Strings.t("battery.voltage", language),
                        value = String.format("%.1f V", battery.voltage),
                        color = NissanTextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    BatteryMetricCard(
                        title = Strings.t("battery.current", language),
                        value = String.format("%.1f A", battery.current),
                        color = if (battery.current < 0) NissanNissanRed else NissanRegenGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BatteryMetricCard(
                        title = Strings.t("battery.power", language),
                        value = String.format("%.1f kW", battery.powerKw),
                        color = if (battery.powerKw < 0) NissanRegenGreen else NissanElectricBlue,
                        modifier = Modifier.weight(1f)
                    )
                    BatteryMetricCard(
                        title = Strings.t("battery.temp", language),
                        value = String.format("%.1f °C", battery.temperatureC),
                        color = NissanWarningAmber,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Animated Energy Flow Schematic Diagram
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Energy Flow Diagram / エネルギーフロー",
                        color = NissanTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (battery.powerKw < 0) NissanRegenGreen.copy(alpha = 0.2f)
                                else NissanElectricBlue.copy(alpha = 0.2f)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (battery.powerKw < 0) "REGENERATION" else "DRIVING POWER",
                            color = if (battery.powerKw < 0) NissanRegenGreen else NissanElectricBlue,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Schematic Nodes Row: BATTERY -> INVERTER -> MOTOR -> WHEELS
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    EnergyNode("BATTERY", Icons.Default.BatteryFull)
                    FlowArrow(isRegen = battery.powerKw < 0)
                    EnergyNode("INVERTER", Icons.Default.Transform)
                    FlowArrow(isRegen = battery.powerKw < 0)
                    EnergyNode("MOTOR", Icons.Default.ElectricBolt)
                    FlowArrow(isRegen = battery.powerKw < 0)
                    EnergyNode("WHEELS", Icons.Default.TripOrigin)
                }
            }
        }

        // Energy Consumption Breakdown Table
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = Strings.t("energy.title", language),
                    color = NissanTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                EnergyTableRow(
                    label = Strings.t("energy.driving", language),
                    value = String.format("%.1f kWh", energy.drivingKwh),
                    color = NissanTextPrimary
                )
                EnergyTableRow(
                    label = Strings.t("energy.climate", language),
                    value = String.format("%.1f kWh", energy.climateKwh),
                    color = NissanTextPrimary
                )
                EnergyTableRow(
                    label = Strings.t("energy.conditioning", language),
                    value = String.format("%.1f kWh", energy.batteryConditioningKwh),
                    color = NissanTextPrimary
                )
                EnergyTableRow(
                    label = Strings.t("energy.regeneration", language),
                    value = String.format("%.1f kWh", energy.regenerationKwh),
                    color = NissanRegenGreen
                )

                Divider(color = NissanBorderDark, modifier = Modifier.padding(vertical = 4.dp))

                EnergyTableRow(
                    label = Strings.t("energy.total", language),
                    value = String.format("%.1f kWh", energy.drivingKwh + energy.climateKwh + energy.batteryConditioningKwh + energy.regenerationKwh),
                    color = NissanElectricBlue,
                    isBold = true
                )
            }
        }
    }
}

@Composable
private fun BatteryMetricCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(NissanSurfaceVariantDark)
            .border(1.dp, NissanBorderDark, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = title, color = NissanTextSecondary, fontSize = 11.sp)
            Text(
                text = value,
                color = color,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun EnergyNode(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(NissanSurfaceVariantDark)
                .border(1.dp, NissanElectricBlueDim, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = NissanElectricBlue, modifier = Modifier.size(20.dp))
        }
        Text(text = label, color = NissanTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun FlowArrow(isRegen: Boolean) {
    Icon(
        imageVector = if (isRegen) Icons.Default.ArrowBack else Icons.Default.ArrowForward,
        contentDescription = null,
        tint = if (isRegen) NissanRegenGreen else NissanElectricBlue,
        modifier = Modifier.size(16.dp)
    )
}

@Composable
private fun EnergyTableRow(
    label: String,
    value: String,
    color: Color,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = NissanTextSecondary, fontSize = 13.sp, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal)
        Text(text = value, color = color, fontSize = 13.sp, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal, fontFamily = FontFamily.Monospace)
    }
}
