package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun NavigationPanelView(
    vehicle: VehicleState,
    language: AppLanguage,
    onSelectDestination: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val destinations = listOf("Yokohama Station", "Haneda Airport (HND)", "Tokyo Station", "Minato Mirai 21")

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = Strings.t("nav_service.title", language),
                        color = NissanTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "GPS LOCKED",
                        color = NissanRegenGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Active Destination Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NissanSurfaceVariantDark)
                        .border(1.dp, NissanElectricBlueDim, RoundedCornerShape(10.dp))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Place, contentDescription = null, tint = NissanElectricBlue)
                            Text(text = vehicle.destination, color = NissanTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }

                        Divider(color = NissanBorderDark)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = Strings.t("nav_service.dist_remaining", language), color = NissanTextSecondary, fontSize = 11.sp)
                                Text(text = "${vehicle.destinationDistanceKm} km", color = NissanTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }

                            Column {
                                Text(text = Strings.t("nav_service.duration", language), color = NissanTextSecondary, fontSize = 11.sp)
                                Text(text = "${vehicle.destinationEtaMinutes} min", color = NissanTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }

                            Column {
                                Text(text = Strings.t("vehicle.eta", language), color = NissanTextSecondary, fontSize = 11.sp)
                                Text(text = vehicle.arrivalTime, color = NissanElectricBlue, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }

                // Select Preset Destination
                Text(
                    text = "Select Destination Preset",
                    color = NissanTextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    destinations.forEach { dest ->
                        val isSelected = vehicle.destination == dest
                        Box(
                            modifier = Modifier
                                .testTag("dest_preset_$dest")
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NissanElectricBlue.copy(alpha = 0.15f) else NissanSurfaceVariantDark)
                                .border(1.dp, if (isSelected) NissanElectricBlue else NissanBorderDark, RoundedCornerShape(8.dp))
                                .clickable { onSelectDestination(dest) }
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = dest, color = if (isSelected) NissanTextPrimary else NissanTextSecondary, fontSize = 13.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                                if (isSelected) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = NissanElectricBlue, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
