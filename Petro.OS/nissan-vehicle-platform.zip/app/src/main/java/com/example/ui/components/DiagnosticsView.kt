package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.model.DiagnosticHealth
import com.example.model.DiagnosticsState
import com.example.ui.theme.*

@Composable
fun DiagnosticsView(
    diagnostics: DiagnosticsState,
    language: AppLanguage,
    onTriggerFault: () -> Unit,
    onClearFaults: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // System Health Diagnostics Grid
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = Strings.t("diagnostics.title", language),
                        color = NissanTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "CAN / ETH SELF-DIAG",
                        color = NissanElectricBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiagnosticHealthItem("Battery System / バッテリー", diagnostics.batteryStatus, language)
                    DiagnosticHealthItem(Strings.t("diagnostics.motor", language), diagnostics.motorStatus, language)
                    DiagnosticHealthItem(Strings.t("diagnostics.inverter", language), diagnostics.inverterStatus, language)
                    DiagnosticHealthItem(Strings.t("charging.title", language), diagnostics.chargingStatus, language)
                    DiagnosticHealthItem(Strings.t("diagnostics.hvac", language), diagnostics.hvacStatus, language)
                    DiagnosticHealthItem(Strings.t("connected.status", language), diagnostics.connectivityStatus, language)
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Action Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onTriggerFault,
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("trigger_fault_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NissanWarningAmber,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = Strings.t("diagnostics.trigger_demo_fault", language), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onClearFaults,
                        modifier = Modifier
                            .weight(0.8f)
                            .testTag("clear_faults_btn"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NissanTextSecondary)
                    ) {
                        Text(text = "Clear / クリア", fontSize = 11.sp)
                    }
                }
            }
        }

        // Active DTC Trouble Codes List
        if (diagnostics.activeDtcCodes.isNotEmpty()) {
            Surface(
                color = NissanSurfaceDark,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NissanNissanRed, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = NissanNissanRed)
                        Text(text = "Active DTC Fault Logs", color = NissanNissanRed, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    diagnostics.activeDtcCodes.forEach { dtc ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(NissanSurfaceVariantDark)
                                .border(1.dp, NissanBorderDark, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = dtc.code, color = NissanWarningAmber, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                                    Text(text = dtc.severity, color = NissanNissanRed, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Text(text = dtc.description, color = NissanTextPrimary, fontSize = 12.sp)
                                Text(text = "Logged: ${dtc.timestamp}", color = NissanTextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagnosticHealthItem(
    label: String,
    health: DiagnosticHealth,
    language: AppLanguage
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(NissanSurfaceVariantDark)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = NissanTextSecondary, fontSize = 13.sp)

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(
                    when (health) {
                        DiagnosticHealth.NORMAL -> NissanRegenGreen.copy(alpha = 0.2f)
                        DiagnosticHealth.WARNING -> NissanWarningAmber.copy(alpha = 0.2f)
                        DiagnosticHealth.SERVICE_REQUIRED -> NissanNissanRed.copy(alpha = 0.2f)
                    }
                )
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(
                text = when (health) {
                    DiagnosticHealth.NORMAL -> Strings.t("diagnostics.normal", language)
                    DiagnosticHealth.WARNING -> Strings.t("diagnostics.warning", language)
                    DiagnosticHealth.SERVICE_REQUIRED -> Strings.t("diagnostics.service_required", language)
                },
                color = when (health) {
                    DiagnosticHealth.NORMAL -> NissanRegenGreen
                    DiagnosticHealth.WARNING -> NissanWarningAmber
                    DiagnosticHealth.SERVICE_REQUIRED -> NissanNissanRed
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
