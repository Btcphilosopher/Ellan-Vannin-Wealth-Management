package com.example.simulation

import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class VehicleSimulationEngine {
    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private val _vehicleState = MutableStateFlow(VehicleState())
    val vehicleState: StateFlow<VehicleState> = _vehicleState.asStateFlow()

    private val _batteryState = MutableStateFlow(BatteryState())
    val batteryState: StateFlow<BatteryState> = _batteryState.asStateFlow()

    private val _chargingState = MutableStateFlow(ChargingState())
    val chargingState: StateFlow<ChargingState> = _chargingState.asStateFlow()

    private val _climateState = MutableStateFlow(ClimateState())
    val climateState: StateFlow<ClimateState> = _climateState.asStateFlow()

    private val _energyState = MutableStateFlow(EnergyState())
    val energyState: StateFlow<EnergyState> = _energyState.asStateFlow()

    private val _diagnosticsState = MutableStateFlow(DiagnosticsState())
    val diagnosticsState: StateFlow<DiagnosticsState> = _diagnosticsState.asStateFlow()

    private val _connectedState = MutableStateFlow(ConnectedServicesState())
    val connectedState: StateFlow<ConnectedServicesState> = _connectedState.asStateFlow()

    private val _telemetryStream = MutableStateFlow<List<TelemetryPoint>>(emptyList())
    val telemetryStream: StateFlow<List<TelemetryPoint>> = _telemetryStream.asStateFlow()

    private val _telemetryHistory = MutableStateFlow<List<TelemetryPoint>>(emptyList())
    val telemetryHistory: StateFlow<List<TelemetryPoint>> = _telemetryHistory.asStateFlow()

    private var simulationJob: Job? = null
    private var isPaused = false

    private var stepCounter = 0L

    init {
        startSimulation()
    }

    fun startSimulation() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            while (isActive) {
                if (!isPaused) {
                    tickSimulation()
                }
                delay(100) // 10 Hz (100ms interval)
            }
        }
    }

    fun setPaused(paused: Boolean) {
        isPaused = paused
    }

    fun isPaused(): Boolean = isPaused

    private fun tickSimulation() {
        stepCounter++
        val now = System.currentTimeMillis()
        val formattedTime = timeFormat.format(Date(now))

        val currentVehicle = _vehicleState.value
        val currentBattery = _batteryState.value
        val currentCharging = _chargingState.value

        // 1. Calculate dynamic values based on gear & driving / charging state
        var speed = currentVehicle.speedKph
        var soc = currentBattery.soc
        var power = currentBattery.powerKw
        var current = currentBattery.current
        var voltage = currentBattery.voltage
        var motorTemp = 42.0f + sin(stepCounter * 0.05f) * 2.5f
        var batteryTemp = currentBattery.temperatureC

        if (currentCharging.status == ChargingStatus.CHARGING) {
            // Charging Simulation (DC Fast Charge ~124 kW)
            speed = 0
            power = 124.0f + (Random.nextFloat() * 1.5f - 0.75f)
            voltage = 718.0f + sin(stepCounter * 0.1f) * 2.0f
            current = (power * 1000f) / voltage // Positive incoming charging current
            
            // Increment SOC slowly (10Hz tick)
            soc = min(100.0f, soc + 0.002f)
            batteryTemp = min(38.0f, batteryTemp + 0.001f)

            if (soc >= currentCharging.targetSoc) {
                _chargingState.value = currentCharging.copy(
                    status = ChargingStatus.COMPLETE,
                    powerKw = 0f,
                    current = 0f,
                    timeRemainingMinutes = 0
                )
            } else {
                val remainingKwh = (currentCharging.targetSoc - soc) / 100f * 87.0f
                val remainingMins = ((remainingKwh / power) * 60).toInt()
                _chargingState.value = currentCharging.copy(
                    powerKw = power,
                    current = current,
                    voltage = voltage,
                    timeRemainingMinutes = max(1, remainingMins)
                )
            }
        } else if (currentVehicle.gear == "D" && speed > 0) {
            // Driving Simulation
            // Slight oscillation around target speed (74 km/h)
            val speedNoise = (Random.nextFloat() * 0.8f - 0.4f)
            val currentSpeedFloat = max(0f, speed + speedNoise)
            speed = currentSpeedFloat.toInt()

            // Power consumption varies with speed
            val regenActive = (stepCounter % 120 > 100) // Periodic regen deceleration
            if (regenActive) {
                power = -(8.0f + Random.nextFloat() * 4.0f) // Negative power = Regeneration
                current = (power * 1000f) / voltage
            } else {
                power = 22.0f + (speed / 100f) * 15f + Random.nextFloat() * 1.5f
                current = -(power * 1000f) / voltage
            }

            // SOC depletion
            soc = max(0.0f, soc - 0.0003f)
            batteryTemp = 28.5f + sin(stepCounter * 0.02f) * 1.2f
        } else {
            // Stationary / Parked
            power = 1.2f // Idle auxiliary climate power
            current = -(power * 1000f) / voltage
        }

        // Calculate Range from SOC (Max ~540km at 100%)
        val remainingRange = ((soc / 100f) * 538).toInt()

        // Update states
        val updatedVehicle = currentVehicle.copy(
            speedKph = speed,
            batteryPercent = soc,
            rangeKm = remainingRange,
            charging = (currentCharging.status == ChargingStatus.CHARGING),
            chargingStatus = currentCharging.status,
            motorSpeedRpm = if (speed > 0) (speed * 85 + Random.nextInt(10)) else 0,
            motorTorqueNm = if (speed > 0) (power * 10f / (speed / 10f + 1f)) else 0f
        )
        _vehicleState.value = updatedVehicle

        val updatedBattery = currentBattery.copy(
            soc = soc,
            voltage = voltage,
            current = current,
            powerKw = power,
            temperatureC = batteryTemp,
            rangeKm = remainingRange
        )
        _batteryState.value = updatedBattery

        // Energy Flow
        _energyState.value = _energyState.value.copy(
            drivingKwh = 18.2f + (stepCounter * 0.0001f),
            regenerationKwh = -3.4f - (if (power < 0) 0.01f else 0f)
        )

        // Telemetry Point
        val eventTypeAndVal = when ((stepCounter % 5).toInt()) {
            0 -> "VEHICLE_SPEED" to "$speed km/h"
            1 -> "BATTERY_SOC" to String.format(Locale.US, "%.1f%%", soc)
            2 -> "MOTOR_POWER" to String.format(Locale.US, "%.1f kW", power)
            3 -> "GPS_UPDATE" to "${currentVehicle.locationName} (${currentVehicle.latitude}, ${currentVehicle.longitude})"
            else -> "ENERGY_FLOW" to String.format(Locale.US, "%.1f kW", power)
        }

        val point = TelemetryPoint(
            timestampMs = now,
            timestampFormatted = formattedTime,
            eventType = eventTypeAndVal.first,
            value = eventTypeAndVal.second,
            speedKph = speed.toFloat(),
            batterySoc = soc,
            powerKw = power,
            motorTempC = motorTemp,
            batteryTempC = batteryTemp
        )

        // Keep last 100 entries for real-time live log stream
        val currentLogs = _telemetryStream.value.toMutableList()
        currentLogs.add(0, point)
        if (currentLogs.size > 100) currentLogs.removeAt(currentLogs.size - 1)
        _telemetryStream.value = currentLogs

        // Keep last 300 entries (~30 seconds) for graphs
        val historyLogs = _telemetryHistory.value.toMutableList()
        historyLogs.add(point)
        if (historyLogs.size > 300) historyLogs.removeAt(0)
        _telemetryHistory.value = historyLogs
    }

    // Command Handlers
    fun setGear(gear: String) {
        _vehicleState.value = _vehicleState.value.copy(
            gear = gear,
            speedKph = if (gear == "P" || gear == "N") 0 else _vehicleState.value.speedKph
        )
    }

    fun setDriveMode(mode: DriveMode) {
        _vehicleState.value = _vehicleState.value.copy(driveMode = mode)
    }

    fun setDoorsLocked(locked: Boolean) {
        _vehicleState.value = _vehicleState.value.copy(doorsLocked = locked)
    }

    fun setWindowsClosed(closed: Boolean) {
        _vehicleState.value = _vehicleState.value.copy(windowsClosed = closed)
    }

    fun setLightsMode(mode: String) {
        _vehicleState.value = _vehicleState.value.copy(lightsMode = mode)
    }

    fun triggerHorn() {
        scope.launch {
            _vehicleState.value = _vehicleState.value.copy(hornActive = true)
            delay(1000)
            _vehicleState.value = _vehicleState.value.copy(hornActive = false)
        }
    }

    fun startCharging(): Boolean {
        val current = _chargingState.value
        _chargingState.value = current.copy(
            status = ChargingStatus.AUTHENTICATING,
            powerKw = 0f
        )
        scope.launch {
            delay(1500)
            _chargingState.value = current.copy(
                status = ChargingStatus.CHARGING,
                powerKw = 124.0f,
                type = "DC Fast Charging (150kW Peak)"
            )
            _vehicleState.value = _vehicleState.value.copy(charging = true, speedKph = 0)
        }
        return true
    }

    fun stopCharging(): Boolean {
        _chargingState.value = _chargingState.value.copy(
            status = ChargingStatus.DISCONNECTED,
            powerKw = 0f,
            current = 0f
        )
        _vehicleState.value = _vehicleState.value.copy(charging = false)
        return true
    }

    fun updateClimate(tempC: Int, fan: Int, ac: Boolean, heat: Boolean) {
        _climateState.value = _climateState.value.copy(
            cabinTempC = tempC,
            driverTempC = tempC,
            passengerTempC = tempC,
            fanLevel = fan,
            acActive = ac,
            heatingActive = heat
        )
    }

    fun setDestination(dest: String) {
        _vehicleState.value = _vehicleState.value.copy(
            destination = dest,
            destinationDistanceKm = 31.8f,
            destinationEtaMinutes = 48,
            arrivalTime = "19:32"
        )
    }

    fun triggerSyntheticFault() {
        val current = _diagnosticsState.value
        val newCode = DiagnosticCode(
            code = "HVAC-204",
            description = "Cabin temperature sensor deviation detected (+3.2°C offset)",
            severity = "WARNING",
            timestamp = timeFormat.format(Date())
        )
        _diagnosticsState.value = current.copy(
            hvacStatus = DiagnosticHealth.WARNING,
            activeDtcCodes = current.activeDtcCodes + newCode
        )
    }

    fun clearFaults() {
        _diagnosticsState.value = DiagnosticsState()
    }
}
