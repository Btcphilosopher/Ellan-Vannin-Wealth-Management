package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.model.DriveMode
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun DigitalCockpitView(
    vehicle: VehicleState,
    language: AppLanguage,
    onGearSelect: (String) -> Unit,
    onDriveModeSelect: (DriveMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Warning Banner if any active fault
        if (vehicle.chargingStatus == com.example.model.ChargingStatus.ERROR) {
            Surface(
                color = NissanNissanRed.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NissanNissanRed, RoundedCornerShape(8.dp))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = NissanNissanRed
                    )
                    Text(
                        text = "CHARGING SYSTEM FAULT DETECTED",
                        color = NissanTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Main Instrumental Cluster Card
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(16.dp),
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Status Strip: Time, Location, Drive Mode
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = NissanElectricBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = vehicle.locationName,
                            color = NissanTextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Active Drive Mode Pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(NissanElectricBlue.copy(alpha = 0.15f))
                            .border(1.dp, NissanElectricBlueDim, RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = vehicle.driveMode.name,
                            color = NissanElectricBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Hero Speed Gauge & Gear Cluster
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Gear Selection Vertical / Horizontal Pillar
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        listOf("P", "R", "N", "D").forEach { g ->
                            val isSelected = vehicle.gear == g
                            Box(
                                modifier = Modifier
                                    .testTag("gear_button_$g")
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) NissanElectricBlue else NissanSurfaceVariantDark)
                                    .border(
                                        1.dp,
                                        if (isSelected) NissanElectricBlue else NissanBorderDark,
                                        CircleShape
                                    )
                                    .clickable { onGearSelect(g) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = g,
                                    color = if (isSelected) Color.Black else NissanTextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    // Main Numerical Speedometer
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "${vehicle.speedKph}",
                            color = NissanTextPrimary,
                            fontSize = 68.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = (-2).sp
                        )
                        Text(
                            text = "km/h",
                            color = NissanElectricBlue,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    // Motor RPM & Torque Stats
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Column {
                            Text(
                                text = "MOTOR",
                                color = NissanTextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "${vehicle.motorSpeedRpm} rpm",
                                color = NissanTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column {
                            Text(
                                text = "TORQUE",
                                color = NissanTextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = String.format("%.1f Nm", vehicle.motorTorqueNm),
                                color = NissanTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Hero Nissan Ariya Graphic
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(NissanSurfaceVariantDark, NissanDarkBackground)
                            )
                        )
                        .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.nissan_ariya_hero_1790867398604),
                        contentDescription = "Nissan Ariya EV",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Battery SOC & Range Summary Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NissanSurfaceVariantDark)
                        .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Battery SOC %
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BatteryChargingFull,
                            contentDescription = null,
                            tint = NissanRegenGreen,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = Strings.t("battery.soc", language),
                                color = NissanTextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = String.format("%.1f%%", vehicle.batteryPercent),
                                color = NissanTextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Divider(
                        modifier = Modifier
                            .height(30.dp)
                            .width(1.dp),
                        color = NissanBorderDark
                    )

                    // Remaining Range
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Navigation,
                            contentDescription = null,
                            tint = NissanElectricBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = Strings.t("battery.range", language),
                                color = NissanTextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "${vehicle.rangeKm} km",
                                color = NissanTextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Turn-by-Turn Navigation Overlay Card
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(NissanElectricBlue.copy(alpha = 0.2f))
                        .border(1.dp, NissanElectricBlue, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.TurnRight,
                        contentDescription = null,
                        tint = NissanElectricBlue,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (language == AppLanguage.JA) "800m先 出口" else "Exit in 800 m",
                            color = NissanTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = vehicle.arrivalTime,
                            color = NissanElectricBlue,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "${vehicle.locationName} → ${vehicle.destination} (${vehicle.destinationDistanceKm} km)",
                        color = NissanTextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Drive Mode Switcher Section
        Column {
            Text(
                text = Strings.t("vehicle.drive_mode", language),
                color = NissanTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DriveMode.values().forEach { mode ->
                    val isSelected = vehicle.driveMode == mode
                    Box(
                        modifier = Modifier
                            .testTag("drive_mode_${mode.name}")
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) NissanElectricBlue else NissanSurfaceDark)
                            .border(1.dp, if (isSelected) NissanElectricBlue else NissanBorderDark, RoundedCornerShape(8.dp))
                            .clickable { onDriveModeSelect(mode) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mode.name,
                            color = if (isSelected) Color.Black else NissanTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
