package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NvpDarkColorScheme = darkColorScheme(
    primary = NissanElectricBlue,
    onPrimary = Color.Black,
    primaryContainer = NissanSurfaceVariantDark,
    onPrimaryContainer = NissanTextPrimary,
    secondary = NissanSilverChrome,
    onSecondary = Color.Black,
    secondaryContainer = NissanSurfaceVariantDark,
    onSecondaryContainer = NissanTextPrimary,
    tertiary = NissanRegenGreen,
    onTertiary = Color.Black,
    background = NissanDarkBackground,
    onBackground = NissanTextPrimary,
    surface = NissanSurfaceDark,
    onSurface = NissanTextPrimary,
    surfaceVariant = NissanSurfaceVariantDark,
    onSurfaceVariant = NissanTextSecondary,
    outline = NissanBorderDark,
    error = NissanNissanRed,
    onError = Color.White
)

@Composable
fun NvpTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NvpDarkColorScheme,
        typography = Typography,
        content = content
    )
}
