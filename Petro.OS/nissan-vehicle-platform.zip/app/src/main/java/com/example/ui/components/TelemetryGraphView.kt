package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.model.TelemetryPoint
import com.example.ui.theme.*

@Composable
fun TelemetryGraphView(
    history: List<TelemetryPoint>,
    timeRange: String,
    language: AppLanguage,
    onTimeRangeSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val ranges = listOf("10sec", "1min", "5min", "30min")

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Time Range Selector Card
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Telemetry Engineering Graphs",
                    color = NissanTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ranges.forEach { r ->
                        val isSelected = r == timeRange
                        Box(
                            modifier = Modifier
                                .testTag("time_range_$r")
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) NissanElectricBlue else NissanSurfaceVariantDark)
                                .border(1.dp, if (isSelected) NissanElectricBlue else NissanBorderDark, RoundedCornerShape(6.dp))
                                .clickable { onTimeRangeSelect(r) }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = r,
                                color = if (isSelected) Color.Black else NissanTextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Speed Chart Card
        TelemetryLineChartCard(
            title = "Vehicle Speed (km/h) / 走行速度",
            points = history.map { it.speedKph },
            minVal = 0f,
            maxVal = 140f,
            lineColor = NissanElectricBlue
        )

        // Battery SOC Chart Card
        TelemetryLineChartCard(
            title = "Battery State of Charge (%) / SOC",
            points = history.map { it.batterySoc },
            minVal = 0f,
            maxVal = 100f,
            lineColor = NissanRegenGreen
        )

        // Power Draw / Regen Chart Card
        TelemetryLineChartCard(
            title = "Power Demand / Regeneration (kW)",
            points = history.map { it.powerKw },
            minVal = -20f,
            maxVal = 150f,
            lineColor = NissanWarningAmber
        )
    }
}

@Composable
private fun TelemetryLineChartCard(
    title: String,
    points: List<Float>,
    minVal: Float,
    maxVal: Float,
    lineColor: Color
) {
    Surface(
        color = NissanSurfaceDark,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = NissanTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                val latest = points.lastOrNull() ?: 0f
                Text(
                    text = String.format("%.1f", latest),
                    color = lineColor,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Canvas Chart
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(NissanDarkBackground)
                    .border(1.dp, NissanBorderDark, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    if (points.size < 2) return@Canvas

                    val width = size.width
                    val height = size.height
                    val range = maxVal - minVal

                    val path = Path()
                    points.forEachIndexed { idx, value ->
                        val x = (idx.toFloat() / (points.size - 1)) * width
                        val clampedVal = value.coerceIn(minVal, maxVal)
                        val y = height - ((clampedVal - minVal) / range) * height

                        if (idx == 0) {
                            path.moveTo(x, y)
                        } else {
                            path.lineTo(x, y)
                        }
                    }

                    drawPath(
                        path = path,
                        color = lineColor,
                        style = Stroke(width = 3f)
                    )
                }
            }
        }
    }
}
