package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.AppLanguage
import com.example.i18n.Strings
import com.example.model.ClimateState
import com.example.ui.theme.*

@Composable
fun ClimatePanelView(
    climate: ClimateState,
    language: AppLanguage,
    onUpdateClimate: (temp: Int, fan: Int, ac: Boolean, heat: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var tempVal by remember(climate.cabinTempC) { mutableStateOf(climate.cabinTempC) }
    var fanVal by remember(climate.fanLevel) { mutableStateOf(climate.fanLevel) }
    var acActive by remember(climate.acActive) { mutableStateOf(climate.acActive) }
    var heatActive by remember(climate.heatingActive) { mutableStateOf(climate.heatingActive) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            color = NissanSurfaceDark,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NissanBorderDark, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = Strings.t("climate.title", language),
                    color = NissanTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                // Temperature Stepper Control
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NissanSurfaceVariantDark)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (tempVal > 16) {
                                tempVal--
                                onUpdateClimate(tempVal, fanVal, acActive, heatActive)
                            }
                        },
                        modifier = Modifier
                            .testTag("temp_minus_btn")
                            .size(42.dp)
                            .background(NissanDarkBackground, CircleShape)
                    ) {
                        Text(text = "-", color = NissanElectricBlue, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = Strings.t("climate.cabin_temp", language),
                            color = NissanTextSecondary,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "$tempVal °C",
                            color = NissanTextPrimary,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    IconButton(
                        onClick = {
                            if (tempVal < 28) {
                                tempVal++
                                onUpdateClimate(tempVal, fanVal, acActive, heatActive)
                            }
                        },
                        modifier = Modifier
                            .testTag("temp_plus_btn")
                            .size(42.dp)
                            .background(NissanDarkBackground, CircleShape)
                    ) {
                        Text(text = "+", color = NissanElectricBlue, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Fan Level Selector
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = Strings.t("climate.fan_speed", language), color = NissanTextSecondary, fontSize = 13.sp)
                        Text(text = "LEVEL $fanVal", color = NissanElectricBlue, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        (1..5).forEach { level ->
                            val isSelected = fanVal == level
                            Box(
                                modifier = Modifier
                                    .testTag("fan_level_$level")
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) NissanElectricBlue else NissanSurfaceVariantDark)
                                    .border(1.dp, if (isSelected) NissanElectricBlue else NissanBorderDark, RoundedCornerShape(8.dp))
                                    .clickable {
                                        fanVal = level
                                        onUpdateClimate(tempVal, fanVal, acActive, heatActive)
                                    }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$level",
                                    color = if (isSelected) Color.Black else NissanTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }

                // Toggle Buttons: AC / Heating / Defrost / Steering
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ClimateToggleTile(
                        label = Strings.t("climate.ac", language),
                        icon = Icons.Default.AcUnit,
                        isActive = acActive,
                        testTag = "ac_toggle",
                        onClick = {
                            acActive = !acActive
                            onUpdateClimate(tempVal, fanVal, acActive, heatActive)
                        },
                        modifier = Modifier.weight(1f)
                    )

                    ClimateToggleTile(
                        label = Strings.t("climate.heating", language),
                        icon = Icons.Default.WbSunny,
                        isActive = heatActive,
                        testTag = "heating_toggle",
                        onClick = {
                            heatActive = !heatActive
                            onUpdateClimate(tempVal, fanVal, acActive, heatActive)
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ClimateToggleTile(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isActive) NissanElectricBlue.copy(alpha = 0.15f) else NissanSurfaceVariantDark)
            .border(1.dp, if (isActive) NissanElectricBlue else NissanBorderDark, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = if (isActive) NissanElectricBlue else NissanTextMuted, modifier = Modifier.size(18.dp))
            Text(text = label, color = if (isActive) NissanTextPrimary else NissanTextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}
