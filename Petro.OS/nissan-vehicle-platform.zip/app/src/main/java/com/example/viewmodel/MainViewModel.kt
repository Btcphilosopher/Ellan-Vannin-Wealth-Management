package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.ApiResponse
import com.example.api.NvpApiService
import com.example.i18n.AppLanguage
import com.example.model.*
import com.example.simulation.VehicleSimulationEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class SurfaceType {
    DRIVER, DEVELOPER
}

enum class DriverTab {
    COCKPIT, STATUS, BATTERY, CHARGING, CLIMATE, NAVIGATION, CONNECTED, DIAGNOSTICS
}

enum class DeveloperTab {
    API_CONSOLE, TELEMETRY_STREAM, TELEMETRY_GRAPHS
}

data class ConfirmationDialogState(
    val isOpen: Boolean = false,
    val titleKey: String = "",
    val messageKey: String = "",
    val onConfirmAction: () -> Unit = {}
)

class MainViewModel : ViewModel() {

    val engine = VehicleSimulationEngine()
    val apiService = NvpApiService(engine)

    private val _language = MutableStateFlow(AppLanguage.JA)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _surface = MutableStateFlow(SurfaceType.DRIVER)
    val surface: StateFlow<SurfaceType> = _surface.asStateFlow()

    private val _driverTab = MutableStateFlow(DriverTab.COCKPIT)
    val driverTab: StateFlow<DriverTab> = _driverTab.asStateFlow()

    private val _developerTab = MutableStateFlow(DeveloperTab.API_CONSOLE)
    val developerTab: StateFlow<DeveloperTab> = _developerTab.asStateFlow()

    private val _confirmationDialog = MutableStateFlow(ConfirmationDialogState())
    val confirmationDialog: StateFlow<ConfirmationDialogState> = _confirmationDialog.asStateFlow()

    // API Console State
    private val _selectedEndpointIndex = MutableStateFlow(0)
    val selectedEndpointIndex: StateFlow<Int> = _selectedEndpointIndex.asStateFlow()

    private val _requestBodyInput = MutableStateFlow("")
    val requestBodyInput: StateFlow<String> = _requestBodyInput.asStateFlow()

    private val _apiResponseResult = MutableStateFlow<ApiResponse?>(null)
    val apiResponseResult: StateFlow<ApiResponse?> = _apiResponseResult.asStateFlow()

    // Event Stream Filter
    private val _eventFilter = MutableStateFlow("ALL")
    val eventFilter: StateFlow<String> = _eventFilter.asStateFlow()

    // Graph Time Range
    private val _graphTimeRange = MutableStateFlow("1min") // 10sec, 1min, 5min, 30min
    val graphTimeRange: StateFlow<String> = _graphTimeRange.asStateFlow()

    // Expose Simulation Flows
    val vehicleState = engine.vehicleState
    val batteryState = engine.batteryState
    val chargingState = engine.chargingState
    val climateState = engine.climateState
    val energyState = engine.energyState
    val diagnosticsState = engine.diagnosticsState
    val connectedState = engine.connectedState
    val telemetryStream = engine.telemetryStream
    val telemetryHistory = engine.telemetryHistory

    init {
        // Initialize request body input with example from first endpoint
        val firstEp = apiService.endpoints.firstOrNull()
        if (firstEp != null) {
            _requestBodyInput.value = firstEp.exampleRequestJson
        }
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
    }

    fun setSurface(surf: SurfaceType) {
        _surface.value = surf
    }

    fun setDriverTab(tab: DriverTab) {
        _driverTab.value = tab
    }

    fun setDeveloperTab(tab: DeveloperTab) {
        _developerTab.value = tab
    }

    fun setGear(gear: String) {
        engine.setGear(gear)
    }

    fun setDriveMode(mode: DriveMode) {
        engine.setDriveMode(mode)
    }

    fun requestLockVehicle() {
        _confirmationDialog.value = ConfirmationDialogState(
            isOpen = true,
            titleKey = "confirm.title",
            messageKey = "confirm.lock_msg",
            onConfirmAction = {
                engine.setDoorsLocked(true)
            }
        )
    }

    fun requestUnlockVehicle() {
        _confirmationDialog.value = ConfirmationDialogState(
            isOpen = true,
            titleKey = "confirm.title",
            messageKey = "confirm.unlock_msg",
            onConfirmAction = {
                engine.setDoorsLocked(false)
            }
        )
    }

    fun requestStartCharging() {
        _confirmationDialog.value = ConfirmationDialogState(
            isOpen = true,
            titleKey = "confirm.title",
            messageKey = "confirm.start_charge_msg",
            onConfirmAction = {
                engine.startCharging()
            }
        )
    }

    fun stopCharging() {
        engine.stopCharging()
    }

    fun closeConfirmationDialog() {
        _confirmationDialog.value = ConfirmationDialogState(isOpen = false)
    }

    fun updateClimate(tempC: Int, fan: Int, ac: Boolean, heat: Boolean) {
        engine.updateClimate(tempC, fan, ac, heat)
    }

    fun triggerHorn() {
        engine.triggerHorn()
    }

    fun triggerFault() {
        engine.triggerSyntheticFault()
    }

    fun clearFaults() {
        engine.clearFaults()
    }

    // API Console Actions
    fun selectApiEndpoint(index: Int) {
        _selectedEndpointIndex.value = index
        val endpoint = apiService.endpoints.getOrNull(index)
        if (endpoint != null) {
            _requestBodyInput.value = endpoint.exampleRequestJson
            _apiResponseResult.value = null
        }
    }

    fun setRequestBodyInput(body: String) {
        _requestBodyInput.value = body
    }

    fun executeApiRequest() {
        val endpoint = apiService.endpoints.getOrNull(_selectedEndpointIndex.value) ?: return
        viewModelScope.launch {
            val response = apiService.executeApiCall(
                endpointPath = endpoint.path,
                method = endpoint.method,
                requestBody = _requestBodyInput.value
            )
            _apiResponseResult.value = response
        }
    }

    fun toggleStreamPause() {
        engine.setPaused(!engine.isPaused())
    }

    fun setEventFilter(filter: String) {
        _eventFilter.value = filter
    }

    fun setGraphTimeRange(range: String) {
        _graphTimeRange.value = range
    }
}
