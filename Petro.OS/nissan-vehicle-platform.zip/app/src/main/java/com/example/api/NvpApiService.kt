package com.example.api

import com.example.model.*
import com.example.simulation.VehicleSimulationEngine
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.random.Random

data class ApiEndpointMeta(
    val id: String,
    val method: String,
    val path: String,
    val summaryJa: String,
    val summaryEn: String,
    val parametersJson: String,
    val requestSchemaJson: String,
    val responseSchemaJson: String,
    val exampleRequestJson: String,
    val exampleResponseJson: String
)

data class ApiResponse(
    val statusCode: Int,
    val statusText: String,
    val latencyMs: Long,
    val requestId: String,
    val responseBodyJson: String
)

class NvpApiService(private val engine: VehicleSimulationEngine) {

    val endpoints: List<ApiEndpointMeta> = listOf(
        ApiEndpointMeta(
            id = "get_vehicle",
            method = "GET",
            path = "/api/v1/vehicle",
            summaryJa = "車両の基本情報および主要ステータスを取得します",
            summaryEn = "Retrieve core vehicle identification and summary status",
            parametersJson = "None",
            requestSchemaJson = "None",
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "vehicleId": { "type": "string" },
                    "model": { "type": "string" },
                    "variant": { "type": "string" },
                    "speedKph": { "type": "integer" },
                    "gear": { "type": "string" },
                    "batteryPercent": { "type": "number" },
                    "rangeKm": { "type": "integer" },
                    "driveMode": { "type": "string" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = "GET /api/v1/vehicle HTTP/1.1",
            exampleResponseJson = """
                {
                  "vehicleId": "NVP-DEMO-001",
                  "model": "Ariya",
                  "variant": "e-4ORCE AWD",
                  "speedKph": 74,
                  "gear": "D",
                  "batteryPercent": 81.4,
                  "rangeKm": 438,
                  "driveMode": "NORMAL"
                }
            """.trimIndent()
        ),
        ApiEndpointMeta(
            id = "get_battery",
            method = "GET",
            path = "/api/v1/battery",
            summaryJa = "高電圧バッテリーのSOC、電圧、電流、温度データを取得します",
            summaryEn = "Get high-voltage EV battery state of charge, voltage, current and temp",
            parametersJson = "None",
            requestSchemaJson = "None",
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "soc": { "type": "number", "minimum": 0, "maximum": 100 },
                    "soh": { "type": "number" },
                    "voltage": { "type": "number" },
                    "current": { "type": "number" },
                    "powerKw": { "type": "number" },
                    "temperatureC": { "type": "number" },
                    "rangeKm": { "type": "integer" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = "GET /api/v1/battery HTTP/1.1",
            exampleResponseJson = """
                {
                  "soc": 81.4,
                  "soh": 98.3,
                  "voltage": 708.2,
                  "current": -38.4,
                  "powerKw": 27.2,
                  "temperatureC": 28.7,
                  "rangeKm": 438
                }
            """.trimIndent()
        ),
        ApiEndpointMeta(
            id = "get_charging",
            method = "GET",
            path = "/api/v1/charging",
            summaryJa = "現在の充電状態および充電スピードパラメータを取得します",
            summaryEn = "Retrieve current EV charging session state and power metrics",
            parametersJson = "None",
            requestSchemaJson = "None",
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "status": { "type": "string", "enum": ["DISCONNECTED", "CONNECTED", "AUTHENTICATING", "CHARGING", "PAUSED", "COMPLETE", "ERROR"] },
                    "type": { "type": "string" },
                    "powerKw": { "type": "number" },
                    "timeRemainingMinutes": { "type": "integer" },
                    "targetSoc": { "type": "integer" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = "GET /api/v1/charging HTTP/1.1",
            exampleResponseJson = """
                {
                  "status": "DISCONNECTED",
                  "type": "DC Fast Charging",
                  "powerKw": 0.0,
                  "timeRemainingMinutes": 0,
                  "targetSoc": 90
                }
            """.trimIndent()
        ),
        ApiEndpointMeta(
            id = "post_charging_start",
            method = "POST",
            path = "/api/v1/charging/start",
            summaryJa = "充電セッションをリモートで開始します",
            summaryEn = "Remotely initiate EV charging session",
            parametersJson = "None",
            requestSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "targetSoc": { "type": "integer", "minimum": 50, "maximum": 100 }
                  }
                }
            """.trimIndent(),
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "success": { "type": "boolean" },
                    "status": { "type": "string" },
                    "message": { "type": "string" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = """
                {
                  "targetSoc": 90
                }
            """.trimIndent(),
            exampleResponseJson = """
                {
                  "success": true,
                  "status": "AUTHENTICATING",
                  "message": "Charging sequence initiated successfully"
                }
            """.trimIndent()
        ),
        ApiEndpointMeta(
            id = "post_charging_stop",
            method = "POST",
            path = "/api/v1/charging/stop",
            summaryJa = "進行中の充電セッションを停止します",
            summaryEn = "Halt an ongoing EV charging session",
            parametersJson = "None",
            requestSchemaJson = "{}",
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "success": { "type": "boolean" },
                    "status": { "type": "string" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = "{}",
            exampleResponseJson = """
                {
                  "success": true,
                  "status": "DISCONNECTED"
                }
            """.trimIndent()
        ),
        ApiEndpointMeta(
            id = "get_climate",
            method = "GET",
            path = "/api/v1/climate",
            summaryJa = "車内空調・エアコン設定状況を取得します",
            summaryEn = "Retrieve current HVAC and cabin climate control settings",
            parametersJson = "None",
            requestSchemaJson = "None",
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "temperatureC": { "type": "integer" },
                    "fanLevel": { "type": "integer" },
                    "ac": { "type": "boolean" },
                    "heating": { "type": "boolean" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = "GET /api/v1/climate HTTP/1.1",
            exampleResponseJson = """
                {
                  "temperatureC": 22,
                  "fanLevel": 3,
                  "ac": true,
                  "heating": false
                }
            """.trimIndent()
        ),
        ApiEndpointMeta(
            id = "post_climate",
            method = "POST",
            path = "/api/v1/climate",
            summaryJa = "車内エアコン設定温度および風量を更新します",
            summaryEn = "Update cabin target temperature and HVAC fan settings",
            parametersJson = "None",
            requestSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "temperatureC": { "type": "integer", "minimum": 16, "maximum": 28 },
                    "fanLevel": { "type": "integer", "minimum": 1, "maximum": 5 },
                    "ac": { "type": "boolean" }
                  }
                }
            """.trimIndent(),
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "success": { "type": "boolean" },
                    "temperatureC": { "type": "integer" },
                    "fanLevel": { "type": "integer" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = """
                {
                  "temperatureC": 22,
                  "fanLevel": 3,
                  "ac": true
                }
            """.trimIndent(),
            exampleResponseJson = """
                {
                  "success": true,
                  "temperatureC": 22,
                  "fanLevel": 3
                }
            """.trimIndent()
        ),
        ApiEndpointMeta(
            id = "get_navigation",
            method = "GET",
            path = "/api/v1/navigation",
            summaryJa = "目的地およびルート案内の進行状況を取得します",
            summaryEn = "Get navigation destination and turn-by-turn route state",
            parametersJson = "None",
            requestSchemaJson = "None",
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "destination": { "type": "string" },
                    "distanceKm": { "type": "number" },
                    "durationMinutes": { "type": "integer" },
                    "arrivalTime": { "type": "string" },
                    "traffic": { "type": "string" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = "GET /api/v1/navigation HTTP/1.1",
            exampleResponseJson = """
                {
                  "destination": "Yokohama Station",
                  "distanceKm": 31.8,
                  "durationMinutes": 48,
                  "arrivalTime": "19:32",
                  "traffic": "MODERATE"
                }
            """.trimIndent()
        ),
        ApiEndpointMeta(
            id = "get_energy",
            method = "GET",
            path = "/api/v1/energy",
            summaryJa = "走行・空調・回生エネルギーの内訳消費を取得します",
            summaryEn = "Get detailed power consumption and regeneration breakdown",
            parametersJson = "None",
            requestSchemaJson = "None",
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "drivingKwh": { "type": "number" },
                    "climateKwh": { "type": "number" },
                    "batteryConditioningKwh": { "type": "number" },
                    "regenerationKwh": { "type": "number" },
                    "netKwh": { "type": "number" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = "GET /api/v1/energy HTTP/1.1",
            exampleResponseJson = """
                {
                  "drivingKwh": 18.2,
                  "climateKwh": 1.1,
                  "batteryConditioningKwh": 0.4,
                  "regenerationKwh": -3.4,
                  "netKwh": 16.3
                }
            """.trimIndent()
        ),
        ApiEndpointMeta(
            id = "get_diagnostics",
            method = "GET",
            path = "/api/v1/diagnostics",
            summaryJa = "車両全サブシステムの自己診断ステータスを取得します",
            summaryEn = "Get self-diagnostic system health and active fault codes",
            parametersJson = "None",
            requestSchemaJson = "None",
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "battery": { "type": "string" },
                    "motor": { "type": "string" },
                    "inverter": { "type": "string" },
                    "hvac": { "type": "string" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = "GET /api/v1/diagnostics HTTP/1.1",
            exampleResponseJson = """
                {
                  "battery": "NORMAL",
                  "motor": "NORMAL",
                  "inverter": "NORMAL",
                  "charging": "NORMAL",
                  "hvac": "NORMAL",
                  "connectivity": "NORMAL"
                }
            """.trimIndent()
        ),
        ApiEndpointMeta(
            id = "get_connected",
            method = "GET",
            path = "/api/v1/connected-services",
            summaryJa = "コネクテッドサービスおよびデジタルキーの稼働状況を取得します",
            summaryEn = "Retrieve Nissan Connected Services and Digital Key status",
            parametersJson = "None",
            requestSchemaJson = "None",
            responseSchemaJson = """
                {
                  "type": "object",
                  "properties": {
                    "vehicle": { "type": "string" },
                    "remoteClimate": { "type": "string" },
                    "vehicleLocation": { "type": "string" },
                    "digitalKey": { "type": "string" }
                  }
                }
            """.trimIndent(),
            exampleRequestJson = "GET /api/v1/connected-services HTTP/1.1",
            exampleResponseJson = """
                {
                  "vehicle": "Connected",
                  "remoteClimate": "Available",
                  "vehicleLocation": "Available",
                  "chargingStatus": "Available",
                  "digitalKey": "Available",
                  "serviceStatus": "Normal"
                }
            """.trimIndent()
        )
    )

    fun executeApiCall(endpointPath: String, method: String, requestBody: String): ApiResponse {
        val startTime = System.currentTimeMillis()
        val requestId = "req-demo-" + (1000..9999).random()

        // Artificial processing delay (20-50ms) to simulate realistic RPC latency
        Thread.sleep((25..45).random().toLong())

        val vehicle = engine.vehicleState.value
        val battery = engine.batteryState.value
        val charging = engine.chargingState.value
        val climate = engine.climateState.value
        val energy = engine.energyState.value
        val diagnostics = engine.diagnosticsState.value
        val connected = engine.connectedState.value

        val json = JSONObject()

        val latency = System.currentTimeMillis() - startTime

        try {
            when (endpointPath) {
                "/api/v1/vehicle" -> {
                    json.put("vehicleId", vehicle.vehicleId)
                    json.put("model", vehicle.model)
                    json.put("variant", vehicle.variant)
                    json.put("speedKph", vehicle.speedKph)
                    json.put("gear", vehicle.gear)
                    json.put("batteryPercent", Math.round(battery.soc * 10) / 10.0)
                    json.put("rangeKm", vehicle.rangeKm)
                    json.put("outsideTemperatureC", vehicle.outsideTemperatureC)
                    json.put("cabinTemperatureC", vehicle.cabinTemperatureC)
                    json.put("driveMode", vehicle.driveMode.name)
                    json.put("charging", vehicle.charging)
                    json.put("doorsLocked", vehicle.doorsLocked)
                    return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                }

                "/api/v1/battery" -> {
                    json.put("soc", Math.round(battery.soc * 10) / 10.0)
                    json.put("soh", battery.soh)
                    json.put("voltage", Math.round(battery.voltage * 10) / 10.0)
                    json.put("current", Math.round(battery.current * 10) / 10.0)
                    json.put("powerKw", Math.round(battery.powerKw * 10) / 10.0)
                    json.put("temperatureC", Math.round(battery.temperatureC * 10) / 10.0)
                    json.put("rangeKm", battery.rangeKm)
                    return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                }

                "/api/v1/charging" -> {
                    json.put("status", charging.status.name)
                    json.put("type", charging.type)
                    json.put("powerKw", Math.round(charging.powerKw * 10) / 10.0)
                    json.put("voltage", Math.round(charging.voltage * 10) / 10.0)
                    json.put("current", Math.round(charging.current * 10) / 10.0)
                    json.put("timeRemainingMinutes", charging.timeRemainingMinutes)
                    json.put("targetSoc", charging.targetSoc)
                    return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                }

                "/api/v1/charging/start" -> {
                    engine.startCharging()
                    json.put("success", true)
                    json.put("status", "AUTHENTICATING")
                    json.put("message", "Charging sequence initiated successfully")
                    return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                }

                "/api/v1/charging/stop" -> {
                    engine.stopCharging()
                    json.put("success", true)
                    json.put("status", "DISCONNECTED")
                    return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                }

                "/api/v1/climate" -> {
                    if (method == "POST" && requestBody.isNotBlank()) {
                        val reqJson = JSONObject(requestBody)
                        val targetTemp = reqJson.optInt("temperatureC", climate.cabinTempC)
                        val fan = reqJson.optInt("fanLevel", climate.fanLevel)
                        val ac = reqJson.optBoolean("ac", climate.acActive)

                        // Validation Check
                        if (targetTemp < 16 || targetTemp > 28) {
                            val errJson = JSONObject()
                            val errDetail = JSONObject()
                            errDetail.put("code", "INVALID_PARAMETER")
                            errDetail.put("message", "temperatureC must be between 16 and 28")
                            errDetail.put("requestId", requestId)
                            errJson.put("error", errDetail)
                            return ApiResponse(400, "Bad Request", latency, requestId, errJson.toString(2))
                        }

                        engine.updateClimate(targetTemp, fan, ac, climate.heatingActive)
                        json.put("success", true)
                        json.put("temperatureC", targetTemp)
                        json.put("fanLevel", fan)
                        json.put("ac", ac)
                        return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                    } else {
                        json.put("temperatureC", climate.cabinTempC)
                        json.put("fanLevel", climate.fanLevel)
                        json.put("ac", climate.acActive)
                        json.put("heating", climate.heatingActive)
                        return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                    }
                }

                "/api/v1/navigation" -> {
                    json.put("destination", vehicle.destination)
                    json.put("distanceKm", vehicle.destinationDistanceKm)
                    json.put("durationMinutes", vehicle.destinationEtaMinutes)
                    json.put("arrivalTime", vehicle.arrivalTime)
                    json.put("traffic", "MODERATE")
                    return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                }

                "/api/v1/energy" -> {
                    json.put("drivingKwh", Math.round(energy.drivingKwh * 10) / 10.0)
                    json.put("climateKwh", Math.round(energy.climateKwh * 10) / 10.0)
                    json.put("batteryConditioningKwh", Math.round(energy.batteryConditioningKwh * 10) / 10.0)
                    json.put("regenerationKwh", Math.round(energy.regenerationKwh * 10) / 10.0)
                    json.put("netKwh", Math.round((energy.drivingKwh + energy.climateKwh + energy.batteryConditioningKwh + energy.regenerationKwh) * 10) / 10.0)
                    return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                }

                "/api/v1/diagnostics" -> {
                    json.put("battery", diagnostics.batteryStatus.name)
                    json.put("motor", diagnostics.motorStatus.name)
                    json.put("inverter", diagnostics.inverterStatus.name)
                    json.put("charging", diagnostics.chargingStatus.name)
                    json.put("hvac", diagnostics.hvacStatus.name)
                    json.put("connectivity", diagnostics.connectivityStatus.name)
                    
                    val dtcArray = JSONArray()
                    diagnostics.activeDtcCodes.forEach { code ->
                        val codeObj = JSONObject()
                        codeObj.put("code", code.code)
                        codeObj.put("description", code.description)
                        codeObj.put("severity", code.severity)
                        codeObj.put("timestamp", code.timestamp)
                        dtcArray.put(codeObj)
                    }
                    json.put("activeDtcCodes", dtcArray)
                    return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                }

                "/api/v1/connected-services" -> {
                    json.put("vehicle", if (connected.vehicleConnected) "Connected" else "Offline")
                    json.put("remoteClimate", if (connected.remoteClimateAvailable) "Available" else "Unavailable")
                    json.put("vehicleLocation", if (connected.vehicleLocationAvailable) "Available" else "Unavailable")
                    json.put("chargingStatus", if (connected.chargingStatusAvailable) "Available" else "Unavailable")
                    json.put("digitalKey", if (connected.digitalKeyActive) "Available" else "Unavailable")
                    json.put("digitalKeyDevice", connected.digitalKeyDevice)
                    json.put("serviceStatus", connected.serviceStatus)
                    return ApiResponse(200, "OK", latency, requestId, json.toString(2))
                }

                else -> {
                    val errJson = JSONObject()
                    val errDetail = JSONObject()
                    errDetail.put("code", "NOT_FOUND")
                    errDetail.put("message", "Endpoint $endpointPath not found")
                    errDetail.put("requestId", requestId)
                    errJson.put("error", errDetail)
                    return ApiResponse(404, "Not Found", latency, requestId, errJson.toString(2))
                }
            }
        } catch (e: Exception) {
            val errJson = JSONObject()
            val errDetail = JSONObject()
            errDetail.put("code", "INTERNAL_ERROR")
            errDetail.put("message", e.localizedMessage ?: "System error processing vehicle request")
            errDetail.put("requestId", requestId)
            errJson.put("error", errDetail)
            return ApiResponse(500, "Internal Server Error", latency, requestId, errJson.toString(2))
        }
    }
}
