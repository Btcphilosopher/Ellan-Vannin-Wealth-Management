import { GoogleGenAI } from '@google/genai';
import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json({ limit: '10mb' }));

// Lazy Google GenAI initialization
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env['GEMINI_API_KEY'];
    if (!key) {
      throw new Error('GEMINI_API_KEY environment variable is required for AI features');
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// REST API Endpoints
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    system: 'Ford Vehicle Simulation Studio API',
    version: '2026.4.0',
    capabilities: [
      '3D Vehicle Dynamics',
      'Truck & Heavy Towing Simulator',
      'Bronco Off-Road Articulation',
      'EV Battery & Thermal Digital Twin',
      'Ford Pro Fleet Telematics',
      'Digital Twin Manufacturing Line',
      'AI Engineering Diagnostic Assistant'
    ]
  });
});

app.post('/api/ai-assistant', async (req, res) => {
  try {
    const { prompt, vehicleState, context } = req.body;
    if (!prompt) {
      res.status(400).json({ error: 'Prompt is required' });
      return;
    }

    const ai = getAI();
    const systemPrompt = `You are the Lead Automotive Engineering & Simulation Assistant for the Ford Vehicle Simulation Studio.
You specialize in vehicle dynamics, computational geometry, truck payload & towing dynamics, off-road 4x4 articulation, ICE/Hybrid/EV powertrain models, thermal management, and fleet telematics.
You inspect synthetic simulation telemetry and engineering parameters to provide rigorous, clear, concise, and technically accurate analysis.
Never claim access to confidential Ford proprietary internal CAD, source code, or private trade secrets; all calculations are based on the physics engine and computational digital-twin state.

Current Vehicle State Context:
${JSON.stringify(vehicleState || {}, null, 2)}
Simulation Context:
${JSON.stringify(context || {}, null, 2)}

Answer the user's engineering question directly with structured technical points, mathematical insights where relevant (e.g. load transfer, Pacejka slip friction, aerodynamic drag, battery C-rate/heat generation, tongue weight leverage), and actionable simulation adjustments.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      },
    });

    res.json({ response: response.text });
  } catch (error: unknown) {
    const errMessage = error instanceof Error ? error.message : 'Failed to generate engineering analysis';
    console.error('AI Assistant error:', error);
    res.status(500).json({
      error: errMessage,
      fallbackResponse: 'Engineering analysis: Load distribution indicates front-to-rear weight shift under dynamic braking. Check tire slip ratios and suspension damping settings.'
    });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Ford Vehicle Simulation Studio Server running on port ${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
