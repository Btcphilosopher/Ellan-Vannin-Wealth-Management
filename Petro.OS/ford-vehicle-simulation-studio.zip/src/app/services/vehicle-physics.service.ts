import { Injectable, signal } from '@angular/core';
import {
  VehicleFamily,
  VehicleTrim,
  VehicleLiveState,
  DriveMode,
  TerrainType,
  TrailerSpec,
  CargoItem,
  TelemetryDataPoint,
} from '../models/vehicle.model';

@Injectable({
  providedIn: 'root',
})
export class VehiclePhysicsService {
  // Signals for reactive UI state
  readonly activeVehicleFamily = signal<VehicleFamily | null>(null);
  readonly activeTrim = signal<VehicleTrim | null>(null);
  readonly currentDriveMode = signal<DriveMode>('NORMAL');
  readonly currentTerrain = signal<TerrainType>('DRY_ASPHALT');
  readonly attachedTrailer = signal<TrailerSpec | null>(null);
  readonly loadedCargos = signal<CargoItem[]>([]);
  readonly roadGradePercent = signal<number>(0); // e.g. 0% to 25% incline

  // Live state signal
  readonly liveState = signal<VehicleLiveState>(this.getInitialLiveState());
  readonly telemetryHistory = signal<TelemetryDataPoint[]>([]);

  // Simulation controls
  isSimulationRunning = true;
  private lastUpdateTimestamp = performance.now();
  private maxTelemetryPoints = 120;
  private simTimeElapsedSec = 0;

  // Key controls state
  private keyControls = {
    accelerator: 0,
    brake: 0,
    steering: 0,
    handbrake: false,
  };

  initVehicle(family: VehicleFamily, trim: VehicleTrim) {
    this.activeVehicleFamily.set(family);
    this.activeTrim.set(trim);
    this.resetSimulationState();
  }

  setDriveMode(mode: DriveMode) {
    this.currentDriveMode.set(mode);
    const trim = this.activeTrim();
    if (!trim) return;
    
    // Auto-configure 4x4 / diff locks based on drive mode
    let fourXFour: '2H' | '4A' | '4H' | '4L' = '2H';
    let rearLock = false;
    let frontLock = false;
    let swayDisc = false;

    if (mode === 'MUD_RUTS' || mode === 'SAND') {
      fourXFour = '4H';
      rearLock = true;
    } else if (mode === 'ROCK_CRAWL') {
      fourXFour = '4L';
      rearLock = true;
      frontLock = true;
      swayDisc = true;
    } else if (mode === 'BAJA') {
      fourXFour = '4H';
    } else if (mode === 'SLIPPERY' || mode === 'TOW_HAUL') {
      fourXFour = '4A';
    } else if (mode === 'SPORT' || mode === 'TRACK') {
      fourXFour = trim.drive === 'AWD' || trim.drive === '4WD' ? '4A' : '2H';
    }

    this.liveState.update((s) => ({
      ...s,
      fourWheelDriveMode: fourXFour,
      rearDiffLocked: rearLock,
      frontDiffLocked: frontLock,
      swayBarDisconnected: swayDisc,
    }));
  }

  setTerrain(terrain: TerrainType) {
    this.currentTerrain.set(terrain);
  }

  setTrailer(trailer: TrailerSpec | null) {
    this.attachedTrailer.set(trailer);
  }

  addCargo(cargo: CargoItem) {
    this.loadedCargos.update((list) => [...list, cargo]);
  }

  removeCargo(cargoId: string) {
    this.loadedCargos.update((list) => list.filter((c) => c.id !== cargoId));
  }

  clearAllCargo() {
    this.loadedCargos.set([]);
  }

  setRoadGrade(gradePercent: number) {
    this.roadGradePercent.set(gradePercent);
  }

  updateInputControls(accel: number, brake: number, steer: number, handbrake = false) {
    this.keyControls.accelerator = Math.max(0, Math.min(1, accel));
    this.keyControls.brake = Math.max(0, Math.min(1, brake));
    this.keyControls.steering = Math.max(-1, Math.min(1, steer));
    this.keyControls.handbrake = handbrake;
  }

  toggleMechanism(mechanism: 'hood' | 'tailgate' | 'doorFL' | 'doorFR' | 'doorRL' | 'doorRR' | 'roof' | 'doorsRemoved') {
    this.liveState.update((s) => {
      const next = { ...s };
      if (mechanism === 'hood') next.hoodOpen = !next.hoodOpen;
      if (mechanism === 'tailgate') next.tailgateOpen = !next.tailgateOpen;
      if (mechanism === 'doorFL') next.doorsOpen[0] = !next.doorsOpen[0];
      if (mechanism === 'doorFR') next.doorsOpen[1] = !next.doorsOpen[1];
      if (mechanism === 'doorRL') next.doorsOpen[2] = !next.doorsOpen[2];
      if (mechanism === 'doorRR') next.doorsOpen[3] = !next.doorsOpen[3];
      if (mechanism === 'roof') next.roofRemoved = !next.roofRemoved;
      if (mechanism === 'doorsRemoved') next.doorsRemoved = !next.doorsRemoved;
      return next;
    });
  }

  toggleLights() {
    this.liveState.update((s) => ({
      ...s,
      headlightsOn: !s.headlightsOn,
    }));
  }

  toggleTurnSignal(signal: 'OFF' | 'LEFT' | 'RIGHT' | 'HAZARD') {
    this.liveState.update((s) => ({
      ...s,
      turnSignal: s.turnSignal === signal ? 'OFF' : signal,
    }));
  }

  shiftGear(newGear: number) {
    this.liveState.update((s) => ({
      ...s,
      gear: newGear,
    }));
  }

  startCharging() {
    this.liveState.update((s) => ({
      ...s,
      chargingStatus: 'CHARGING',
      chargePowerKw: 150,
    }));
  }

  stopCharging() {
    this.liveState.update((s) => ({
      ...s,
      chargingStatus: 'DISCONNECTED',
      chargePowerKw: 0,
    }));
  }

  /**
   * High-frequency Deterministic Physics Step
   */
  stepPhysics(dtSec: number) {
    const trim = this.activeTrim();
    const family = this.activeVehicleFamily();
    if (!trim || !family) return;

    const state = { ...this.liveState() };
    const trailer = this.attachedTrailer();
    const cargos = this.loadedCargos();
    const grade = this.roadGradePercent();

    // 1. Calculate Total Mass & CG
    let cargoMass = 0;
    for (const c of cargos) {
      cargoMass += c.massKg;
    }
    const vehicleMass = trim.curbWeightKg + cargoMass;
    const trailerMass = trailer ? trailer.curbMassKg + trailer.currentPayloadKg : 0;
    const totalMass = vehicleMass + trailerMass;

    // Tongue weight transfer from trailer
    const tongueWeight = trailer ? trailerMass * (trailer.tongueWeightPercentage / 100) : 0;
    
    // Front/Rear Static Axle distribution
    const baseFrontFrac = trim.weightDistributionFrontPercent / 100;
    const frontStaticKg = vehicleMass * baseFrontFrac;
    const rearStaticKg = vehicleMass * (1 - baseFrontFrac) + tongueWeight;

    // 2. Terrain Friction Coefficient (mu)
    let terrainMu = 1.0;
    const terrain = this.currentTerrain();
    switch (terrain) {
      case 'DRY_ASPHALT':
        terrainMu = 1.05;
        break;
      case 'WET_ASPHALT':
        terrainMu = 0.72;
        break;
      case 'MUD':
        terrainMu = 0.45;
        break;
      case 'SAND':
        terrainMu = 0.52;
        break;
      case 'ROCK':
        terrainMu = 0.88;
        break;
      case 'SNOW_ICE':
        terrainMu = 0.28;
        break;
      case 'GRAVEL':
        terrainMu = 0.65;
        break;
    }

    // 3. User Controls & Powertrain Forces
    const throttle = this.keyControls.accelerator;
    const brake = this.keyControls.brake;
    const steer = this.keyControls.steering;
    const g = 9.80665;
    const rhoAir = 1.225; // kg/m^3

    let speedMps = state.speedMps;
    let rpm = state.rpm;
    let gear = state.gear;
    let driveForceN = 0;
    let enginePowerHp = 0;
    let engineTorqueNm = 0;
    let evPowerKw = 0;
    let regenPowerKw = 0;

    // Powertrain calculations
    if (trim.propulsion === 'ICE') {
      const engine = trim.iceEngine!;
      const trans = trim.transmission;
      
      // Automatic transmission shift logic
      if (gear === 0) gear = 1; // Default drive in 1st
      
      const wheelRadiusM = (trim.tyres.rimDiameterInches * 0.0254) / 2 + (trim.tyres.widthMm * (trim.tyres.aspectRatio / 100)) / 1000;
      const finalDrive = trans.finalDriveRatio * (state.fourWheelDriveMode === '4L' && trans.transferCaseLowRatio ? trans.transferCaseLowRatio : 1.0);
      const gearRatio = trans.gearRatios[Math.max(0, Math.min(gear - 1, trans.gearRatios.length - 1))];
      
      // Calculate RPM from wheel speed
      const wheelRps = speedMps / (2 * Math.PI * wheelRadiusM);
      const expectedRpm = wheelRps * gearRatio * finalDrive * 60;
      
      // Smooth RPM transition
      rpm = Math.max(engine.idleRpm, expectedRpm);
      if (throttle > 0 && expectedRpm < engine.idleRpm + 1200) {
        rpm = engine.idleRpm + throttle * 2800; // Torque converter slip
      }

      // Auto shifting up/down
      if (rpm > engine.redlineRpm * 0.88 && gear < trans.gearRatios.length) {
        gear++;
      } else if (rpm < engine.idleRpm + 900 && gear > 1) {
        gear--;
      }

      // Torque curve approximation
      const rpmFrac = (rpm - engine.idleRpm) / (engine.redlineRpm - engine.idleRpm);
      const torqueMultiplier = Math.sin(Math.max(0.1, Math.min(Math.PI * 0.9, rpmFrac * Math.PI)));
      const peakTorqueNm = engine.maxTorqueLbFt * 1.35582;
      engineTorqueNm = peakTorqueNm * (0.65 + 0.35 * torqueMultiplier) * throttle;
      
      const omega = (2 * Math.PI * rpm) / 60;
      const powerWatts = engineTorqueNm * omega;
      enginePowerHp = powerWatts / 745.7;

      const wheelTorqueNm = engineTorqueNm * gearRatio * finalDrive * 0.92; // 92% drivetrain efficiency
      driveForceN = wheelTorqueNm / wheelRadiusM;

    } else if (trim.propulsion === 'BEV') {
      const motor = trim.evMotor!;
      const wheelRadiusM = (trim.tyres.rimDiameterInches * 0.0254) / 2 + (trim.tyres.widthMm * (trim.tyres.aspectRatio / 100)) / 1000;
      const ratio = motor.gearReductionRatio;
      
      rpm = (speedMps / (2 * Math.PI * wheelRadiusM)) * ratio * 60;
      const maxMotorHp = (motor.frontMotorHp || 0) + (motor.rearMotorHp || 0);
      const maxTorqueNm = ((motor.frontMotorTorqueLbFt || 0) + (motor.rearMotorTorqueLbFt || 0)) * 1.35582;

      if (throttle > 0) {
        evPowerKw = (maxMotorHp * 0.7457) * throttle;
        driveForceN = (maxTorqueNm * ratio * 0.96 * throttle) / wheelRadiusM;
        enginePowerHp = maxMotorHp * throttle;
        engineTorqueNm = maxTorqueNm * throttle;
      } else if (brake > 0 || speedMps > 1) {
        // Regenerative braking
        const regenDemand = Math.min(motor.maxRegenPowerKw, (brake > 0 ? brake * 80 : 25));
        regenPowerKw = regenDemand;
        driveForceN = -((regenDemand * 1000) / Math.max(1, speedMps));
      }
    } else if (trim.propulsion === 'HEV') {
      // PowerBoost Hybrid blended mode
      const engine = trim.iceEngine!;
      const motor = trim.evMotor!;
      const trans = trim.transmission;
      
      const wheelRadiusM = (trim.tyres.rimDiameterInches * 0.0254) / 2 + (trim.tyres.widthMm * (trim.tyres.aspectRatio / 100)) / 1000;
      const gearRatio = trans.gearRatios[Math.max(0, Math.min(gear - 1, trans.gearRatios.length - 1))];
      const finalDrive = trans.finalDriveRatio;
      
      rpm = Math.max(engine.idleRpm, (speedMps / (2 * Math.PI * wheelRadiusM)) * gearRatio * finalDrive * 60);
      
      const peakTorqueNm = (engine.maxTorqueLbFt + (motor.rearMotorTorqueLbFt || 0)) * 1.35582;
      engineTorqueNm = peakTorqueNm * throttle;
      enginePowerHp = (engine.maxPowerHp + (motor.rearMotorHp || 0)) * throttle;
      
      const wheelTorqueNm = engineTorqueNm * gearRatio * finalDrive * 0.94;
      driveForceN = wheelTorqueNm / wheelRadiusM;

      if (brake > 0) {
        regenPowerKw = Math.min(motor.maxRegenPowerKw, brake * 40);
      }
    }

    // 4. Resistance Forces
    // Aerodynamic drag: F = 0.5 * rho * Cd * A * v^2
    const cd = trim.dragCoefficientCd + (trailer ? trailer.dragCoeff * 0.3 : 0);
    const frontalArea = trim.frontalAreaM2 + (trailer ? trailer.frontalAreaM2 * 0.25 : 0);
    const aeroDragN = 0.5 * rhoAir * cd * frontalArea * speedMps * speedMps;

    // Rolling resistance: F = Crr * m * g
    const crr = trim.tyres.rollingResistanceCoeff * (terrain === 'SAND' ? 2.5 : terrain === 'MUD' ? 2.0 : 1.0);
    const rollResistanceN = crr * totalMass * g;

    // Grade resistance: F = m * g * sin(theta)
    const gradeAngleRad = Math.atan(grade / 100);
    const gradeForceN = totalMass * g * Math.sin(gradeAngleRad);

    // Friction Braking Force
    const maxBrakingFriction = totalMass * g * terrainMu * trim.tyres.pacejkaD;
    const brakeForceN = brake * maxBrakingFriction + (this.keyControls.handbrake ? maxBrakingFriction * 0.4 : 0);

    // Net Longitudinal Force
    const netForceN = driveForceN - aeroDragN - rollResistanceN - gradeForceN - (speedMps > 0.05 ? brakeForceN : 0);
    const accelMps2 = netForceN / totalMass;

    // Integrate speed
    speedMps = Math.max(0, speedMps + accelMps2 * dtSec);
    const speedKmh = speedMps * 3.6;

    // 5. Dynamic Weight Transfer (Load shift under accel/brake)
    const longAccelG = accelMps2 / g;
    const cgHeightM = trim.centerOfGravityHeightM;
    const wheelbaseM = family.dimensions.wheelbase / 1000;
    
    // Dynamic axle load shift = (m * a_x * h_cg) / L
    const deltaAxleLoadKg = (vehicleMass * longAccelG * cgHeightM) / wheelbaseM;
    const dynamicFrontKg = Math.max(200, frontStaticKg - deltaAxleLoadKg);
    const dynamicRearKg = Math.max(200, rearStaticKg + deltaAxleLoadKg);

    // 6. Steering & Cornering Lateral Dynamics
    const maxSteerAngle = 38.0; // deg
    const wheelSteerDeg = steer * maxSteerAngle;
    const yawRateDegS = (speedMps / wheelbaseM) * Math.tan((wheelSteerDeg * Math.PI) / 180) * (180 / Math.PI) * (1 / (1 + 0.002 * speedMps * speedMps));
    const lateralG = (speedMps * speedMps * Math.tan((wheelSteerDeg * Math.PI) / 180)) / (wheelbaseM * g);

    // 7. Suspension travel & Articulation
    const frontTravelMm = Math.max(0, Math.min(trim.suspension.frontMaxTravelMm, 80 + (dynamicFrontKg - frontStaticKg) * 0.08));
    const rearTravelMm = Math.max(0, Math.min(trim.suspension.rearMaxTravelMm, 90 + (dynamicRearKg - rearStaticKg) * 0.09));
    
    // Pitch & Roll angles
    const pitchDeg = -longAccelG * 3.2;
    const rollDeg = lateralG * 4.5 * (state.swayBarDisconnected ? 1.4 : 1.0);

    // 4 Corner loads & slips
    const slipBase = Math.min(0.85, (Math.abs(accelMps2) / 12) * (1.1 - terrainMu * 0.6) + (this.keyControls.handbrake ? 0.6 : 0));
    const flSlip = Math.max(0.01, slipBase * (1 + steer * 0.2));
    const frSlip = Math.max(0.01, slipBase * (1 - steer * 0.2));
    const rlSlip = Math.max(0.01, slipBase * 1.1);
    const rrSlip = Math.max(0.01, slipBase * 1.1);

    // 8. Thermal Updates
    let coolantTemp = state.engineCoolantTempC;
    let oilTemp = state.engineOilTempC;
    let batteryTemp = state.batteryPackTempC;
    let brakeTemps: [number, number, number, number] = [...state.brakeDiscTempsC];

    // Engine heat generated vs radiator cooling
    if (trim.propulsion === 'ICE' || trim.propulsion === 'HEV') {
      const heatGen = (enginePowerHp / 100) * throttle * 0.4;
      const cooling = (speedMps * 0.02 + 0.05);
      coolantTemp = Math.min(115, Math.max(75, coolantTemp + (heatGen - cooling) * dtSec));
      oilTemp = Math.min(128, Math.max(80, oilTemp + (heatGen * 0.8 - cooling * 0.7) * dtSec));
    }

    // Battery heat generated
    if (trim.battery) {
      const cRate = (evPowerKw + regenPowerKw) / trim.battery.usableCapacityKwh;
      const battHeat = cRate * cRate * 0.08;
      const battCooling = 0.03;
      batteryTemp = Math.min(58, Math.max(22, batteryTemp + (battHeat - battCooling) * dtSec));
    }

    // Brake rotor heat under friction braking
    if (brake > 0) {
      const brakeHeat = brake * speedKmh * 0.15;
      brakeTemps[0] = Math.min(650, brakeTemps[0] + brakeHeat * dtSec);
      brakeTemps[1] = Math.min(650, brakeTemps[1] + brakeHeat * dtSec);
      brakeTemps[2] = Math.min(550, brakeTemps[2] + brakeHeat * 0.7 * dtSec);
      brakeTemps[3] = Math.min(550, brakeTemps[3] + brakeHeat * 0.7 * dtSec);
    } else {
      // Cooling
      const coolFactor = (0.2 + speedKmh * 0.01) * dtSec;
      brakeTemps = [
        Math.max(45, brakeTemps[0] - coolFactor * 4),
        Math.max(45, brakeTemps[1] - coolFactor * 4),
        Math.max(40, brakeTemps[2] - coolFactor * 3),
        Math.max(40, brakeTemps[3] - coolFactor * 3),
      ];
    }

    // 9. Consumable Depletion
    let fuelLevel = state.fuelLevelPercent;
    let soc = state.batterySocPercent;
    
    if (throttle > 0) {
      if (trim.iceEngine) {
        fuelLevel = Math.max(0, fuelLevel - (enginePowerHp / 400) * 0.002 * dtSec);
      }
      if (trim.battery && evPowerKw > 0) {
        soc = Math.max(0, soc - (evPowerKw / trim.battery.usableCapacityKwh) * 0.025 * dtSec);
      }
    }
    if (regenPowerKw > 0 && trim.battery) {
      soc = Math.min(100, soc + (regenPowerKw / trim.battery.usableCapacityKwh) * 0.02 * dtSec);
    }

    // Trailer sway oscillation
    let trailerSway = 0;
    if (trailer) {
      trailerSway = Math.sin(this.simTimeElapsedSec * 4) * (lateralG * 6.5);
    }

    this.simTimeElapsedSec += dtSec;

    // Update Live State
    const updatedState: VehicleLiveState = {
      ...state,
      speedKmh,
      speedMps,
      rpm: Math.round(rpm),
      gear,
      throttleInput: throttle,
      brakeInput: brake,
      steeringInputAngleDeg: steer * 450,
      wheelSteerAngleDeg: wheelSteerDeg,
      yawRateDegPerS: yawRateDegS,
      lateralAccelG: lateralG,
      longitudinalAccelG: longAccelG,
      pitchAngleDeg: pitchDeg,
      rollAngleDeg: rollDeg,
      engineTorqueNm: Math.round(engineTorqueNm),
      enginePowerHp: Math.round(enginePowerHp),
      evPowerKw: Math.round(evPowerKw),
      regenPowerKw: Math.round(regenPowerKw),
      engineCoolantTempC: Math.round(coolantTemp * 10) / 10,
      engineOilTempC: Math.round(oilTemp * 10) / 10,
      batteryPackTempC: Math.round(batteryTemp * 10) / 10,
      brakeDiscTempsC: [
        Math.round(brakeTemps[0]),
        Math.round(brakeTemps[1]),
        Math.round(brakeTemps[2]),
        Math.round(brakeTemps[3]),
      ],
      suspensionTravelMm: [
        Math.round(frontTravelMm),
        Math.round(frontTravelMm),
        Math.round(rearTravelMm),
        Math.round(rearTravelMm),
      ],
      wheelSlipRatio: [flSlip, frSlip, rlSlip, rrSlip],
      wheelVerticalLoadsN: [
        Math.round((dynamicFrontKg / 2) * g),
        Math.round((dynamicFrontKg / 2) * g),
        Math.round((dynamicRearKg / 2) * g),
        Math.round((dynamicRearKg / 2) * g),
      ],
      terrainContactFriction: terrainMu,
      totalVehicleMassKg: Math.round(totalMass),
      currentPayloadKg: Math.round(cargoMass),
      tongueWeightKg: Math.round(tongueWeight),
      trailerSwayAngleDeg: trailerSway,
      axleLoadingFrontKg: Math.round(dynamicFrontKg),
      axleLoadingRearKg: Math.round(dynamicRearKg),
      fuelLevelPercent: Math.max(0, fuelLevel),
      fuelConsumptionLPer100Km: speedKmh > 5 ? (enginePowerHp * 0.08) / (speedKmh / 100) : 12.5,
      batterySocPercent: Math.max(0, Math.min(100, soc)),
      brakeLightsOn: brake > 0.05,
    };

    this.liveState.set(updatedState);

    // Record Telemetry
    if (this.telemetryHistory().length > this.maxTelemetryPoints) {
      this.telemetryHistory.update((hist) => [
        ...hist.slice(1),
        this.createTelemetryPoint(updatedState),
      ]);
    } else {
      this.telemetryHistory.update((hist) => [
        ...hist,
        this.createTelemetryPoint(updatedState),
      ]);
    }
  }

  private createTelemetryPoint(state: VehicleLiveState): TelemetryDataPoint {
    return {
      timestampMs: Date.now(),
      timeSec: Math.round(this.simTimeElapsedSec * 10) / 10,
      speedKmh: Math.round(state.speedKmh),
      rpm: state.rpm,
      powerHp: state.enginePowerHp,
      torqueNm: state.engineTorqueNm,
      socPercent: Math.round(state.batterySocPercent),
      fuelPercent: Math.round(state.fuelLevelPercent),
      brakeTempC: Math.round(state.brakeDiscTempsC[0]),
      lateralG: Math.round(state.lateralAccelG * 100) / 100,
      longitudinalG: Math.round(state.longitudinalAccelG * 100) / 100,
      suspensionSagFrontMm: state.suspensionTravelMm[0],
      suspensionSagRearMm: state.suspensionTravelMm[2],
      slipAvg: Math.round(
        ((state.wheelSlipRatio[0] +
          state.wheelSlipRatio[1] +
          state.wheelSlipRatio[2] +
          state.wheelSlipRatio[3]) /
          4) *
          100
      ),
      energyFlowKw: state.evPowerKw > 0 ? state.evPowerKw : -state.regenPowerKw,
    };
  }

  private resetSimulationState() {
    this.liveState.set(this.getInitialLiveState());
    this.telemetryHistory.set([]);
    this.simTimeElapsedSec = 0;
  }

  private getInitialLiveState(): VehicleLiveState {
    return {
      speedKmh: 0,
      speedMps: 0,
      rpm: 650,
      gear: 1,
      throttleInput: 0,
      brakeInput: 0,
      steeringInputAngleDeg: 0,
      wheelSteerAngleDeg: 0,
      yawRateDegPerS: 0,
      lateralAccelG: 0,
      longitudinalAccelG: 0,
      pitchAngleDeg: 0,
      rollAngleDeg: 0,
      engineTorqueNm: 0,
      enginePowerHp: 0,
      evPowerKw: 0,
      regenPowerKw: 0,
      proPowerOnboardLoadKw: 0,
      fourWheelDriveMode: '2H',
      rearDiffLocked: false,
      frontDiffLocked: false,
      swayBarDisconnected: false,
      engineCoolantTempC: 88,
      engineOilTempC: 92,
      batteryPackTempC: 25,
      inverterTempC: 35,
      frontMotorTempC: 40,
      rearMotorTempC: 42,
      transmissionTempC: 82,
      brakeDiscTempsC: [55, 55, 48, 48],
      suspensionTravelMm: [80, 80, 90, 90],
      wheelSlipRatio: [0.01, 0.01, 0.01, 0.01],
      wheelVerticalLoadsN: [6000, 6000, 5500, 5500],
      terrainContactFriction: 1.05,
      fuelLevelPercent: 92,
      fuelConsumptionLPer100Km: 11.2,
      batterySocPercent: 86,
      batterySohPercent: 99,
      estimatedRemainingRangeKm: 520,
      chargingStatus: 'DISCONNECTED',
      chargePowerKw: 0,
      totalVehicleMassKg: 2200,
      currentPayloadKg: 0,
      tongueWeightKg: 0,
      trailerSwayAngleDeg: 0,
      axleLoadingFrontKg: 1150,
      axleLoadingRearKg: 1050,
      headlightsOn: true,
      highBeamsOn: false,
      turnSignal: 'OFF',
      brakeLightsOn: false,
      doorsOpen: [false, false, false, false],
      hoodOpen: false,
      tailgateOpen: false,
      roofRemoved: false,
      doorsRemoved: false,
    };
  }
}
