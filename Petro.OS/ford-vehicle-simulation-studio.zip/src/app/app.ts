import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { VehiclePhysicsService } from './services/vehicle-physics.service';
import { FORD_VEHICLE_REGISTRY } from './data/vehicle-registry';
import { VehicleViewport } from './components/vehicle-viewport/vehicle-viewport';
import { TelemetryDashboard } from './components/telemetry-dashboard/telemetry-dashboard';
import { PowertrainConfigurator } from './components/powertrain-configurator/powertrain-configurator';
import { FleetTelematicsPanel } from './components/fleet-telematics-panel/fleet-telematics-panel';
import { ManufacturingDigitalTwin } from './components/manufacturing-digital-twin/manufacturing-digital-twin';
import { AICopilot } from './components/ai-copilot/ai-copilot';

export type ActiveRightTab = 'TELEMETRY' | 'FLEET' | 'MANUFACTURING' | 'AI_COPILOT';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    VehicleViewport,
    TelemetryDashboard,
    PowertrainConfigurator,
    FleetTelematicsPanel,
    ManufacturingDigitalTwin,
    AICopilot,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  physics = inject(VehiclePhysicsService);

  readonly activeTab = signal<ActiveRightTab>('TELEMETRY');
  readonly isConfigOpen = signal(true);
  readonly isRightPanelOpen = signal(true);
  readonly isHelpModalOpen = signal(false);

  ngOnInit() {
    // Initialize default canonical vehicle: Mustang Dark Horse
    const defaultFamily = FORD_VEHICLE_REGISTRY[0];
    const defaultTrim = defaultFamily.trims[0];
    this.physics.initVehicle(defaultFamily, defaultTrim);
  }

  setRightTab(tab: ActiveRightTab) {
    this.activeTab.set(tab);
    if (!this.isRightPanelOpen()) {
      this.isRightPanelOpen.set(true);
    }
  }

  toggleConfigPanel() {
    this.isConfigOpen.update((v) => !v);
  }

  toggleRightPanel() {
    this.isRightPanelOpen.update((v) => !v);
  }

  resetVehicleSimulation() {
    const family = this.physics.activeVehicleFamily();
    const trim = this.physics.activeTrim();
    if (family && trim) {
      this.physics.initVehicle(family, trim);
    }
  }
}
