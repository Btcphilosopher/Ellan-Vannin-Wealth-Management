export type VehicleCategory =
  | 'CAR'
  | 'SUV'
  | 'PICKUP'
  | 'HEAVY_DUTY'
  | 'COMMERCIAL_VAN'
  | 'OFF_ROAD'
  | 'EV'
  | 'HYBRID';

export type PropulsionType = 'ICE' | 'HEV' | 'PHEV' | 'BEV';
export type DriveLayout = 'RWD' | 'FWD' | 'AWD' | '4WD';

export type TerrainType =
  | 'DRY_ASPHALT'
  | 'WET_ASPHALT'
  | 'MUD'
  | 'SAND'
  | 'ROCK'
  | 'SNOW_ICE'
  | 'GRAVEL';

export type DriveMode =
  | 'NORMAL'
  | 'SPORT'
  | 'ECO'
  | 'SLIPPERY'
  | 'TOW_HAUL'
  | 'MUD_RUTS'
  | 'SAND'
  | 'ROCK_CRAWL'
  | 'BAJA'
  | 'TRACK'
  | 'DRAG_STRIP';

export interface VehicleDimensions {
  length: number; // mm
  width: number; // mm
  height: number; // mm
  wheelbase: number; // mm
  trackFront: number; // mm
  trackRear: number; // mm
  groundClearance: number; // mm
  approachAngle: number; // deg
  departureAngle: number; // deg
  breakoverAngle: number; // deg
  bedLength?: number; // mm for pickups
  bedWidth?: number; // mm
  cargoVolume?: number; // Liters
}

export interface ICEEngineConfig {
  name: string;
  displacementLiters: number;
  cylinders: number;
  aspiration: 'NATURAL' | 'TURBO' | 'TWIN_TURBO' | 'SUPERCHARGED';
  maxPowerHp: number;
  maxPowerRpm: number;
  maxTorqueLbFt: number;
  maxTorqueRpm: number;
  redlineRpm: number;
  idleRpm: number;
  boreMm: number;
  strokeMm: number;
  compressionRatio: number;
  fuelType: 'GASOLINE' | 'DIESEL' | 'E85';
  thermalEfficiencyPeak: number; // e.g. 0.38
}

export interface EVMotorConfig {
  frontMotorHp?: number;
  frontMotorTorqueLbFt?: number;
  frontMotorMaxRpm?: number;
  rearMotorHp?: number;
  rearMotorTorqueLbFt?: number;
  rearMotorMaxRpm?: number;
  inverterEfficiency: number; // 0.96
  gearReductionRatio: number; // e.g. 9.05:1
  maxRegenPowerKw: number; // e.g. 180
}

export interface BatteryConfig {
  usableCapacityKwh: number;
  grossCapacityKwh: number;
  nominalVoltage: number; // 400V or 800V
  maxChargeRateKw: number; // 150kW or 350kW
  chemistry: 'NMC' | 'LFP';
  thermalCoolingType: 'LIQUID_GLYCOL' | 'REFRIGERANT';
  cellCount: number;
  targetOperatingTempC: number;
}

export interface TransmissionConfig {
  type: 'AUTOMATIC_10_SPEED' | 'AUTOMATIC_8_SPEED' | 'MANUAL_6_SPEED' | 'MANUAL_7_SPEED_CRAWLER' | 'SINGLE_SPEED_DIRECT' | 'POWER_SPLIT_E_CVT';
  gearRatios: number[];
  reverseRatio: number;
  finalDriveRatio: number;
  transferCaseLowRatio?: number; // e.g. 2.72 or 3.06 for 4x4 low
}

export interface SuspensionConfig {
  frontType: 'INDEPENDENT_DOUBLE_WISHBONE' | 'MACPHERSON_STRUT' | 'SOLID_AXLE_COIL' | 'TWIN_I_BEAM';
  rearType: 'INDEPENDENT_MULTI_LINK' | 'SOLID_AXLE_LEAF_SPRING' | 'SOLID_AXLE_5_LINK_COIL' | 'SEMI_INDEPENDENT';
  frontSpringRateNPerM: number;
  rearSpringRateNPerM: number;
  frontDamperBoundNPerMPerS: number;
  frontDamperReboundNPerMPerS: number;
  rearDamperBoundNPerMPerS: number;
  rearDamperReboundNPerMPerS: number;
  frontMaxTravelMm: number;
  rearMaxTravelMm: number;
  swayBarDiameterFrontMm: number;
  swayBarDiameterRearMm: number;
  hasSwayBarDisconnect?: boolean;
  damperTech: 'PASSIVE_MONOTUBE' | 'FOX_LIVE_VALVE' | 'MAGNERIDE_MAGNETORHEOLOGICAL' | 'HEAVY_DUTY_GAS';
}

export interface TyreWheelConfig {
  name: string;
  rimDiameterInches: number;
  widthMm: number;
  aspectRatio: number;
  compound: 'ALL_SEASON' | 'ALL_TERRAIN' | 'MUD_TERRAIN' | 'SUMMER_HIGH_PERFORMANCE' | 'COMMERCIAL_HEAVY_DUTY';
  coldPressurePsi: number;
  pacejkaB: number;
  pacejkaC: number;
  pacejkaD: number; // Peak friction coefficient multiplier
  pacejkaE: number;
  rollingResistanceCoeff: number;
}

export interface TrailerSpec {
  id: string;
  name: string;
  type: 'BOX_UTILITY' | 'BOAT_TRAILER' | 'EQUIPMENT_FLATBED' | 'CARAVAN_CAMPER' | 'GOOSENECK_HEAVY_FLATBED' | 'FIFTH_WHEEL_HAULER';
  curbMassKg: number;
  maxGvwrKg: number;
  currentPayloadKg: number;
  axles: number;
  lengthM: number;
  frontalAreaM2: number;
  dragCoeff: number;
  hitchType: 'BUMPER_RECEIVER_CLASS_IV' | 'GOOSENECK' | 'FIFTH_WHEEL';
  tongueWeightPercentage: number; // standard 10-15%
}

export interface CargoItem {
  id: string;
  name: string;
  massKg: number;
  category: 'TOOLS' | 'BUILDING_SUPPLIES' | 'PALLET_FREIGHT' | 'CAMPING_GEAR' | 'HEAVY_EQUIPMENT' | 'REFRIGERATED_GOODS';
  positionOffsetM: [number, number, number]; // [x, y, z] relative to bed / cargo floor
}

export interface CommercialUpfit {
  id: string;
  name: string;
  category: 'STANDARD_CARGO' | 'SERVICE_UTILITY_BODY' | 'REFRIGERATED_COOLING' | 'INTERIOR_SHELVING_RACKS' | 'MOBILE_WORKSHOP' | 'AERIAL_BUCKET' | 'LUXURY_CAMPER';
  addedMassKg: number;
  cgShiftZ: number; // meter shift in vertical CG
  dragCoeffDelta: number;
  description: string;
  equipmentItems: string[];
}

export interface VehicleTrim {
  id: string;
  trimName: string;
  modelYear: number;
  startingMsrpUsd: number;
  propulsion: PropulsionType;
  drive: DriveLayout;
  curbWeightKg: number;
  grossVehicleWeightRatingKg: number;
  maxTowingCapacityKg: number;
  maxPayloadCapacityKg: number;
  dragCoefficientCd: number;
  frontalAreaM2: number;
  centerOfGravityHeightM: number; // ground to CG
  weightDistributionFrontPercent: number; // e.g. 54% front, 46% rear
  iceEngine?: ICEEngineConfig;
  evMotor?: EVMotorConfig;
  battery?: BatteryConfig;
  transmission: TransmissionConfig;
  suspension: SuspensionConfig;
  tyres: TyreWheelConfig;
  availableColors: { name: string; hex: string; metallic: boolean }[];
  availableUpfits?: CommercialUpfit[];
}

export interface VehicleFamily {
  id: string;
  familyKey: string;
  name: string;
  subTitle: string;
  category: VehicleCategory;
  generation: string;
  dimensions: VehicleDimensions;
  description: string;
  highlightFeatures: string[];
  trims: VehicleTrim[];
  badgeSvg?: string;
}

export interface VehicleLiveState {
  // Kinematics
  speedKmh: number;
  speedMps: number;
  rpm: number;
  gear: number; // 0=N, -1=R, 1..10
  throttleInput: number; // 0..1
  brakeInput: number; // 0..1
  steeringInputAngleDeg: number; // -450 to +450
  wheelSteerAngleDeg: number; // front wheel turn angle
  yawRateDegPerS: number;
  lateralAccelG: number;
  longitudinalAccelG: number;
  pitchAngleDeg: number;
  rollAngleDeg: number;
  
  // Power & Drivetrain
  engineTorqueNm: number;
  enginePowerHp: number;
  evPowerKw: number;
  regenPowerKw: number;
  proPowerOnboardLoadKw: number;
  fourWheelDriveMode: '2H' | '4A' | '4H' | '4L';
  rearDiffLocked: boolean;
  frontDiffLocked: boolean;
  swayBarDisconnected: boolean;

  // Thermal States (deg C)
  engineCoolantTempC: number;
  engineOilTempC: number;
  batteryPackTempC: number;
  inverterTempC: number;
  frontMotorTempC: number;
  rearMotorTempC: number;
  transmissionTempC: number;
  brakeDiscTempsC: [number, number, number, number]; // FL, FR, RL, RR

  // Suspension & Dynamics
  suspensionTravelMm: [number, number, number, number]; // FL, FR, RL, RR
  wheelSlipRatio: [number, number, number, number]; // 0..1
  wheelVerticalLoadsN: [number, number, number, number];
  terrainContactFriction: number;
  
  // Consumables & Range
  fuelLevelPercent: number;
  fuelConsumptionLPer100Km: number;
  batterySocPercent: number;
  batterySohPercent: number;
  estimatedRemainingRangeKm: number;
  chargingStatus: 'DISCONNECTED' | 'CONNECTED' | 'PRECONDITIONING' | 'CHARGING' | 'THROTTLED' | 'COMPLETE';
  chargePowerKw: number;

  // Truck & Towing Dynamics
  totalVehicleMassKg: number;
  currentPayloadKg: number;
  tongueWeightKg: number;
  trailerSwayAngleDeg: number;
  axleLoadingFrontKg: number;
  axleLoadingRearKg: number;

  // Lights & Mechanisms
  headlightsOn: boolean;
  highBeamsOn: boolean;
  turnSignal: 'OFF' | 'LEFT' | 'RIGHT' | 'HAZARD';
  brakeLightsOn: boolean;
  doorsOpen: [boolean, boolean, boolean, boolean]; // FL, FR, RL, RR
  hoodOpen: boolean;
  tailgateOpen: boolean;
  roofRemoved: boolean; // Bronco
  doorsRemoved: boolean; // Bronco
}

export interface TelemetryDataPoint {
  timestampMs: number;
  timeSec: number;
  speedKmh: number;
  rpm: number;
  powerHp: number;
  torqueNm: number;
  socPercent: number;
  fuelPercent: number;
  brakeTempC: number;
  lateralG: number;
  longitudinalG: number;
  suspensionSagFrontMm: number;
  suspensionSagRearMm: number;
  slipAvg: number;
  energyFlowKw: number;
}

export interface FleetVehicleInstance {
  vin: string;
  unitNumber: string;
  familyId: string;
  familyName: string;
  trimName: string;
  category: VehicleCategory;
  propulsion: PropulsionType;
  assignedDriver: string;
  currentLocation: { lat: number; lng: number; address: string };
  headingDeg: number;
  status: 'IN_TRANSIT' | 'IDLE_DEPOT' | 'CHARGING' | 'LOADING' | 'MAINTENANCE_REQUIRED';
  currentSpeedKmh: number;
  odometerKm: number;
  socOrFuelPercent: number;
  healthScorePercent: number;
  activePayloadKg: number;
  destination: string;
  etaMinutes: number;
  dailyDistanceKm: number;
  alerts: string[];
}

export interface ManufacturingStation {
  id: number;
  code: string;
  name: string;
  description: string;
  cycleTimeSeconds: number;
  status: 'OPERATIONAL' | 'INSPECTION_ACTIVE' | 'MAINTENANCE';
  currentVehicleVin: string;
  installedComponents: string[];
  qualityMetrics: {
    laserToleranceMm: number;
    torqueSpecPass: boolean;
    weldIntegrityScore: number;
    paintThicknessMicrons: number;
  };
  inspectionResult: 'PASS' | 'WARNING' | 'FAIL';
}
