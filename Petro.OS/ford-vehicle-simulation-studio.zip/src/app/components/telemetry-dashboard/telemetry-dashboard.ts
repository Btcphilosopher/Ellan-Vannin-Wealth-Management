import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { VehiclePhysicsService } from '../../services/vehicle-physics.service';

@Component({
  selector: 'app-telemetry-dashboard',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-900 border-l border-slate-800 text-slate-200 overflow-y-auto custom-scrollbar">
      <!-- Header -->
      <div class="p-4 border-b border-slate-800 bg-slate-950/60 sticky top-0 z-10 backdrop-blur">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-blue-500 !w-5 !h-5 !text-lg">speed</mat-icon>
            <span class="font-bold text-sm text-white uppercase tracking-wider">CAN-Bus Telemetry Hub</span>
          </div>
          <div class="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>60 Hz LIVE</span>
          </div>
        </div>
      </div>

      <!-- Main Gauges Grid -->
      <div class="p-4 space-y-4">
        <!-- 1. Primary Speed & Powertrain Cluster -->
        <div class="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-4 shadow-inner">
          <div class="flex items-end justify-between">
            <div>
              <div class="text-[10px] font-mono uppercase text-slate-400">Vehicle Speed</div>
              <div class="flex items-baseline gap-1">
                <span class="text-4xl font-black font-mono tracking-tight text-white">{{ physics.liveState().speedKmh }}</span>
                <span class="text-xs font-semibold text-slate-400">KM/H</span>
                <span class="text-xs font-mono text-slate-500 ml-1">({{ (physics.liveState().speedKmh * 0.621371).toFixed(0) }} MPH)</span>
              </div>
            </div>

            <div class="text-right">
              @if (physics.activeTrim()?.propulsion === 'BEV') {
                <div class="text-[10px] font-mono uppercase text-sky-400">e-Motor Power</div>
                <div class="flex items-baseline justify-end gap-1">
                  <span class="text-3xl font-black font-mono" [class.text-sky-400]="physics.liveState().evPowerKw >= 0" [class.text-emerald-400]="physics.liveState().regenPowerKw > 0">
                    {{ physics.liveState().evPowerKw > 0 ? physics.liveState().evPowerKw : -physics.liveState().regenPowerKw }}
                  </span>
                  <span class="text-xs font-semibold text-slate-400">kW</span>
                </div>
              } @else {
                <div class="text-[10px] font-mono uppercase text-amber-400">Engine Tachometer</div>
                <div class="flex items-baseline justify-end gap-1">
                  <span class="text-3xl font-black font-mono text-amber-400">{{ physics.liveState().rpm }}</span>
                  <span class="text-xs font-semibold text-slate-400">RPM</span>
                </div>
              }
            </div>
          </div>

          <!-- Tach / Power Bar -->
          <div class="mt-3">
            <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden flex">
              @if (physics.activeTrim()?.propulsion === 'BEV') {
                <div
                  class="bg-gradient-to-r from-sky-500 to-indigo-500 h-full transition-all duration-75"
                  [style.width.%]="(physics.liveState().evPowerKw / ((physics.activeTrim()?.evMotor?.frontMotorHp || 300) * 0.745)) * 100"
                ></div>
              } @else {
                <div
                  class="bg-gradient-to-r from-emerald-500 via-amber-500 to-red-500 h-full transition-all duration-75"
                  [style.width.%]="(physics.liveState().rpm / (physics.activeTrim()?.iceEngine?.redlineRpm || 7000)) * 100"
                ></div>
              }
            </div>
            <div class="flex justify-between text-[9px] font-mono text-slate-500 mt-1">
              <span>0</span>
              <span>Gear: {{ physics.liveState().gear > 0 ? 'D' + physics.liveState().gear : (physics.liveState().gear === -1 ? 'R' : 'N') }}</span>
              <span>Max: {{ physics.activeTrim()?.propulsion === 'BEV' ? 'Peak kW' : (physics.activeTrim()?.iceEngine?.redlineRpm || 7000) + ' RPM' }}</span>
            </div>
          </div>
        </div>

        <!-- 2. G-Force & Inclinometer Matrix -->
        <div class="grid grid-cols-2 gap-3">
          <!-- G-G Diagram -->
          <div class="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3">
            <div class="flex items-center justify-between mb-2">
              <span class="text-[11px] font-semibold text-slate-300">G-G Dynamics</span>
              <span class="text-[10px] font-mono text-slate-400">{{ physics.liveState().lateralAccelG.toFixed(2) }} G Lat</span>
            </div>
            
            <div class="relative w-full aspect-square bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-center overflow-hidden">
              <!-- Concentric G rings -->
              <div class="absolute w-3/4 h-3/4 rounded-full border border-slate-800/70"></div>
              <div class="absolute w-1/2 h-1/2 rounded-full border border-slate-800/70"></div>
              <!-- Crosshairs -->
              <div class="absolute w-full h-[1px] bg-slate-800"></div>
              <div class="absolute h-full w-[1px] bg-slate-800"></div>
              <!-- G-Point Indicator -->
              <div
                class="w-3.5 h-3.5 rounded-full bg-blue-500 border-2 border-white shadow-lg transition-all duration-75 absolute"
                [style.left.%]="50 + physics.liveState().lateralAccelG * 35"
                [style.top.%]="50 - physics.liveState().longitudinalAccelG * 35"
              ></div>
            </div>
            <div class="flex justify-between text-[9px] font-mono text-slate-500 mt-1.5">
              <span>-1.0G</span>
              <span>Long: {{ physics.liveState().longitudinalAccelG.toFixed(2) }}G</span>
              <span>+1.0G</span>
            </div>
          </div>

          <!-- Roll & Pitch Inclinometer -->
          <div class="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3">
            <div class="flex items-center justify-between mb-2">
              <span class="text-[11px] font-semibold text-slate-300">Inclinometer</span>
              <span class="text-[10px] font-mono text-amber-400">{{ physics.liveState().pitchAngleDeg.toFixed(1) }}° Pitch</span>
            </div>

            <div class="h-[105px] flex flex-col justify-around py-1">
              <div>
                <div class="flex justify-between text-[10px] text-slate-400 mb-1">
                  <span>Pitch (Grade / Squat)</span>
                  <span class="font-mono text-white">{{ physics.liveState().pitchAngleDeg.toFixed(1) }}°</span>
                </div>
                <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden relative">
                  <div
                    class="bg-amber-500 h-full transition-all duration-75 absolute"
                    [style.left.%]="50"
                    [style.width.%]="Math.abs(physics.liveState().pitchAngleDeg) * 4"
                    [style.transform]="physics.liveState().pitchAngleDeg < 0 ? 'translateX(-100%)' : 'none'"
                  ></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-[10px] text-slate-400 mb-1">
                  <span>Roll (Camber / Bank)</span>
                  <span class="font-mono text-white">{{ physics.liveState().rollAngleDeg.toFixed(1) }}°</span>
                </div>
                <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden relative">
                  <div
                    class="bg-blue-500 h-full transition-all duration-75 absolute"
                    [style.left.%]="50"
                    [style.width.%]="Math.abs(physics.liveState().rollAngleDeg) * 4"
                    [style.transform]="physics.liveState().rollAngleDeg < 0 ? 'translateX(-100%)' : 'none'"
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 3. Four-Corner Tire Slip & Axle Load Distribution -->
        <div class="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5">
          <div class="flex items-center justify-between mb-3">
            <div class="flex items-center gap-1.5">
              <mat-icon class="text-blue-400 !w-4 !h-4 !text-base">adjust</mat-icon>
              <span class="text-xs font-semibold text-slate-300">4-Corner Tire Grip & Dynamic Loads</span>
            </div>
            <span class="text-[10px] font-mono text-slate-400">Pacejka Non-Linear</span>
          </div>

          <div class="grid grid-cols-2 gap-2.5">
            <!-- Front Left -->
            <div class="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px]">
              <div class="flex justify-between text-slate-400 font-semibold mb-1">
                <span>Front Left</span>
                <span class="font-mono text-white">{{ physics.liveState().wheelVerticalLoadsN[0] }} N</span>
              </div>
              <div class="flex justify-between text-slate-500 font-mono">
                <span>Travel: {{ physics.liveState().suspensionTravelMm[0] }}mm</span>
                <span [class.text-red-400]="physics.liveState().wheelSlipRatio[0] > 0.15" class="text-emerald-400">
                  Slip: {{ (physics.liveState().wheelSlipRatio[0] * 100).toFixed(1) }}%
                </span>
              </div>
              <div class="w-full bg-slate-800 h-1 rounded-full mt-1.5 overflow-hidden">
                <div class="bg-blue-500 h-full" [style.width.%]="(physics.liveState().wheelVerticalLoadsN[0] / 12000) * 100"></div>
              </div>
            </div>

            <!-- Front Right -->
            <div class="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px]">
              <div class="flex justify-between text-slate-400 font-semibold mb-1">
                <span>Front Right</span>
                <span class="font-mono text-white">{{ physics.liveState().wheelVerticalLoadsN[1] }} N</span>
              </div>
              <div class="flex justify-between text-slate-500 font-mono">
                <span>Travel: {{ physics.liveState().suspensionTravelMm[1] }}mm</span>
                <span [class.text-red-400]="physics.liveState().wheelSlipRatio[1] > 0.15" class="text-emerald-400">
                  Slip: {{ (physics.liveState().wheelSlipRatio[1] * 100).toFixed(1) }}%
                </span>
              </div>
              <div class="w-full bg-slate-800 h-1 rounded-full mt-1.5 overflow-hidden">
                <div class="bg-blue-500 h-full" [style.width.%]="(physics.liveState().wheelVerticalLoadsN[1] / 12000) * 100"></div>
              </div>
            </div>

            <!-- Rear Left -->
            <div class="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px]">
              <div class="flex justify-between text-slate-400 font-semibold mb-1">
                <span>Rear Left</span>
                <span class="font-mono text-white">{{ physics.liveState().wheelVerticalLoadsN[2] }} N</span>
              </div>
              <div class="flex justify-between text-slate-500 font-mono">
                <span>Travel: {{ physics.liveState().suspensionTravelMm[2] }}mm</span>
                <span [class.text-red-400]="physics.liveState().wheelSlipRatio[2] > 0.15" class="text-emerald-400">
                  Slip: {{ (physics.liveState().wheelSlipRatio[2] * 100).toFixed(1) }}%
                </span>
              </div>
              <div class="w-full bg-slate-800 h-1 rounded-full mt-1.5 overflow-hidden">
                <div class="bg-indigo-500 h-full" [style.width.%]="(physics.liveState().wheelVerticalLoadsN[2] / 12000) * 100"></div>
              </div>
            </div>

            <!-- Rear Right -->
            <div class="bg-slate-900 border border-slate-800 rounded-lg p-2 text-[10px]">
              <div class="flex justify-between text-slate-400 font-semibold mb-1">
                <span>Rear Right</span>
                <span class="font-mono text-white">{{ physics.liveState().wheelVerticalLoadsN[3] }} N</span>
              </div>
              <div class="flex justify-between text-slate-500 font-mono">
                <span>Travel: {{ physics.liveState().suspensionTravelMm[3] }}mm</span>
                <span [class.text-red-400]="physics.liveState().wheelSlipRatio[3] > 0.15" class="text-emerald-400">
                  Slip: {{ (physics.liveState().wheelSlipRatio[3] * 100).toFixed(1) }}%
                </span>
              </div>
              <div class="w-full bg-slate-800 h-1 rounded-full mt-1.5 overflow-hidden">
                <div class="bg-indigo-500 h-full" [style.width.%]="(physics.liveState().wheelVerticalLoadsN[3] / 12000) * 100"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- 4. Thermal Systems & Consumables -->
        <div class="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5">
          <div class="flex items-center justify-between mb-3">
            <div class="flex items-center gap-1.5">
              <mat-icon class="text-amber-400 !w-4 !h-4 !text-base">thermostat</mat-icon>
              <span class="text-xs font-semibold text-slate-300">Thermal State & Energy Reservoir</span>
            </div>
          </div>

          <div class="grid grid-cols-3 gap-2 text-[11px]">
            @if (physics.activeTrim()?.propulsion === 'BEV' || physics.activeTrim()?.propulsion === 'HEV') {
              <div class="bg-slate-900 p-2 rounded-lg border border-slate-800 text-center">
                <div class="text-[9px] text-slate-400 uppercase font-mono">Battery Temp</div>
                <div class="font-mono font-bold text-white text-base mt-0.5">{{ physics.liveState().batteryPackTempC }}°C</div>
                <div class="text-[9px] text-emerald-400">Liquid Glycol</div>
              </div>
              <div class="bg-slate-900 p-2 rounded-lg border border-slate-800 text-center">
                <div class="text-[9px] text-slate-400 uppercase font-mono">Battery SOC</div>
                <div class="font-mono font-bold text-sky-400 text-base mt-0.5">{{ physics.liveState().batterySocPercent.toFixed(0) }}%</div>
                <div class="text-[9px] text-slate-500">{{ physics.activeTrim()?.battery?.usableCapacityKwh || 91 }} kWh</div>
              </div>
            } @else {
              <div class="bg-slate-900 p-2 rounded-lg border border-slate-800 text-center">
                <div class="text-[9px] text-slate-400 uppercase font-mono">Coolant Temp</div>
                <div class="font-mono font-bold text-white text-base mt-0.5">{{ physics.liveState().engineCoolantTempC }}°C</div>
                <div class="text-[9px] text-emerald-400">Nominal</div>
              </div>
              <div class="bg-slate-900 p-2 rounded-lg border border-slate-800 text-center">
                <div class="text-[9px] text-slate-400 uppercase font-mono">Fuel Level</div>
                <div class="font-mono font-bold text-amber-400 text-base mt-0.5">{{ physics.liveState().fuelLevelPercent.toFixed(0) }}%</div>
                <div class="text-[9px] text-slate-500">Unleaded/Diesel</div>
              </div>
            }

            <div class="bg-slate-900 p-2 rounded-lg border border-slate-800 text-center">
              <div class="text-[9px] text-slate-400 uppercase font-mono">Brake Rotors</div>
              <div class="font-mono font-bold text-base mt-0.5" [class.text-red-400]="physics.liveState().brakeDiscTempsC[0] > 300" [class.text-white]="physics.liveState().brakeDiscTempsC[0] <= 300">
                {{ physics.liveState().brakeDiscTempsC[0] }}°C
              </div>
              <div class="text-[9px]" [class.text-red-400]="physics.liveState().brakeDiscTempsC[0] > 300" [class.text-slate-500]="physics.liveState().brakeDiscTempsC[0] <= 300">
                {{ physics.liveState().brakeDiscTempsC[0] > 300 ? 'GLOWING' : 'Vented' }}
              </div>
            </div>
          </div>
        </div>

        <!-- 5. Truck Towing & Payload Dynamics (If attached) -->
        @if (physics.attachedTrailer() || physics.loadedCargos().length > 0) {
          <div class="bg-slate-950/70 border border-blue-900/50 rounded-xl p-3.5 bg-gradient-to-br from-blue-950/30 to-slate-950">
            <div class="flex items-center justify-between mb-2">
              <div class="flex items-center gap-1.5">
                <mat-icon class="text-blue-400 !w-4 !h-4 !text-base">rv_hookup</mat-icon>
                <span class="text-xs font-semibold text-white">Truck & Towing Dynamic State</span>
              </div>
              <span class="text-[10px] font-mono text-emerald-400">Within GCWR</span>
            </div>

            <div class="space-y-1.5 text-[11px] font-mono">
              <div class="flex justify-between">
                <span class="text-slate-400">Total Train Mass:</span>
                <span class="text-white font-bold">{{ physics.liveState().totalVehicleMassKg }} kg</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Hitch Tongue Weight:</span>
                <span class="text-amber-400 font-bold">{{ physics.liveState().tongueWeightKg }} kg</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Trailer Sway Oscillation:</span>
                <span class="text-sky-400">{{ physics.liveState().trailerSwayAngleDeg.toFixed(2) }}°</span>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `],
})
export class TelemetryDashboard {
  physics = inject(VehiclePhysicsService);
  protected readonly Math = Math;
}
