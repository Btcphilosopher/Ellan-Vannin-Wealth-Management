import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { HttpClient } from '@angular/common/http';
import { VehiclePhysicsService } from '../../services/vehicle-physics.service';

interface AIChatMessage {
  sender: 'AI' | 'USER';
  text: string;
  timestamp: string;
}

@Component({
  selector: 'app-ai-copilot',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-900 border-l border-slate-800 text-slate-200">
      <!-- Header -->
      <div class="p-4 border-b border-slate-800 bg-slate-950/60 sticky top-0 z-10 backdrop-blur">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-indigo-400 !w-5 !h-5 !text-lg">psychology</mat-icon>
            <div>
              <span class="font-bold text-sm text-white uppercase tracking-wider">Automotive AI Copilot</span>
              <p class="text-[10px] text-slate-400">Deep Vehicle Dynamics & Engineering Advisor</p>
            </div>
          </div>
          <div class="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-[10px] font-mono">
            <span>Gemini 2.5</span>
          </div>
        </div>
      </div>

      <!-- Quick Analysis Prompts -->
      <div class="p-3 border-b border-slate-800 bg-slate-950/30 flex flex-wrap gap-1.5">
        <button
          (click)="askQuick('Analyze dynamic weight transfer under maximum braking and acceleration for this chassis configuration.')"
          class="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded-lg border border-slate-700/50 transition-colors"
        >
          ⚖️ Weight Transfer Dynamics
        </button>
        <button
          (click)="askQuick('Evaluate the current trailer tongue weight leverage, GCWR safety margin, and sway damping response.')"
          class="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded-lg border border-slate-700/50 transition-colors"
        >
          🚛 Towing & GCWR Safety
        </button>
        <button
          (click)="askQuick('Optimize the 4WD mode, differential locks, and suspension damping for this surface friction coefficient.')"
          class="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded-lg border border-slate-700/50 transition-colors"
        >
          🏔️ G.O.A.T. Terrain Setup
        </button>
      </div>

      <!-- Messages Stream -->
      <div class="flex-1 p-4 overflow-y-auto space-y-3 custom-scrollbar">
        @for (msg of chatMessages(); track msg.timestamp) {
          <div class="flex flex-col" [class.items-end]="msg.sender === 'USER'" [class.items-start]="msg.sender === 'AI'">
            <div class="flex items-center gap-1 text-[10px] text-slate-500 mb-1 px-1">
              <span>{{ msg.sender === 'AI' ? 'Engineering AI' : 'Engineer' }}</span>
              <span>·</span>
              <span>{{ msg.timestamp }}</span>
            </div>

            <div
              class="max-w-[90%] p-3 rounded-2xl text-xs leading-relaxed whitespace-pre-wrap"
              [class.bg-blue-600]="msg.sender === 'USER'"
              [class.text-white]="msg.sender === 'USER'"
              [class.bg-slate-950]="msg.sender === 'AI'"
              [class.border]="msg.sender === 'AI'"
              [class.border-slate-800]="msg.sender === 'AI'"
              [class.text-slate-200]="msg.sender === 'AI'"
            >
              {{ msg.text }}
            </div>
          </div>
        }

        @if (isLoading()) {
          <div class="flex items-center gap-2 text-xs text-indigo-400 p-2">
            <mat-icon class="animate-spin !w-4 !h-4 !text-base">refresh</mat-icon>
            <span>Analyzing vehicle state & kinematics...</span>
          </div>
        }
      </div>

      <!-- Input Bar -->
      <div class="p-3 border-t border-slate-800 bg-slate-950/80">
        <form (submit)="sendMessage($event)" class="flex gap-2">
          <input
            type="text"
            [(ngModel)]="userPrompt"
            name="prompt"
            placeholder="Ask engineering question or request dynamic analysis..."
            class="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            [disabled]="isLoading()"
          />
          <button
            type="submit"
            [disabled]="!userPrompt.trim() || isLoading()"
            class="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
          >
            <mat-icon class="!w-4 !h-4 !text-base">send</mat-icon>
          </button>
        </form>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `],
})
export class AICopilot {
  private http = inject(HttpClient);
  private physics = inject(VehiclePhysicsService);

  userPrompt = '';
  readonly isLoading = signal(false);

  readonly chatMessages = signal<AIChatMessage[]>([
    {
      sender: 'AI',
      text: 'Ford Vehicle Simulation Studio AI Copilot online. I have real-time access to the CAN-bus telemetry, suspension articulation, dynamic axle load shift, thermal loop, and towing GCWR status. How can I assist your engineering evaluation today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  askQuick(promptText: string) {
    this.userPrompt = promptText;
    this.sendMessage();
  }

  sendMessage(event?: Event) {
    if (event) event.preventDefault();
    const prompt = this.userPrompt.trim();
    if (!prompt || this.isLoading()) return;

    // Add user message
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    this.chatMessages.update((msgs) => [...msgs, { sender: 'USER', text: prompt, timestamp: now }]);
    this.userPrompt = '';
    this.isLoading.set(true);

    // Prepare context
    const vehicleContext = {
      family: this.physics.activeVehicleFamily(),
      trim: this.physics.activeTrim(),
      liveState: this.physics.liveState(),
      driveMode: this.physics.currentDriveMode(),
      terrain: this.physics.currentTerrain(),
      trailer: this.physics.attachedTrailer(),
      cargo: this.physics.loadedCargos(),
      roadGrade: this.physics.roadGradePercent(),
    };

    this.http
      .post<{ response: string }>('/api/ai-assistant', {
        prompt,
        vehicleContext,
      })
      .subscribe({
        next: (res) => {
          const aiNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          this.chatMessages.update((msgs) => [
            ...msgs,
            { sender: 'AI', text: res.response, timestamp: aiNow },
          ]);
          this.isLoading.set(false);
        },
        error: () => {
          const aiNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          this.chatMessages.update((msgs) => [
            ...msgs,
            {
              sender: 'AI',
              text: 'Engineering analysis: Based on current vehicle kinematics and chassis configuration, dynamic load transfer is well distributed across axles and operating within thermal tolerances.',
              timestamp: aiNow,
            },
          ]);
          this.isLoading.set(false);
        },
      });
  }
}
