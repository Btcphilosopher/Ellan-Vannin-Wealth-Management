import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { VehiclePhysicsService } from '../../services/vehicle-physics.service';
import { FORD_VEHICLE_REGISTRY, SYNTHETIC_TRAILER_CATALOG, SYNTHETIC_CARGO_CATALOG } from '../../data/vehicle-registry';
import { VehicleFamily, VehicleTrim, DriveMode, TerrainType, CargoItem } from '../../models/vehicle.model';

@Component({
  selector: 'app-powertrain-configurator',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-900 border-r border-slate-800 text-slate-200 overflow-y-auto custom-scrollbar">
      <!-- Header -->
      <div class="p-4 border-b border-slate-800 bg-slate-950/60 sticky top-0 z-10 backdrop-blur">
        <div class="flex items-center gap-2">
          <mat-icon class="text-blue-500 !w-5 !h-5 !text-lg">tune</mat-icon>
          <span class="font-bold text-sm text-white uppercase tracking-wider">Engineering Configurator</span>
        </div>
        <p class="text-xs text-slate-400 mt-0.5">Canonical Vehicle Engine & Terrain Tuning</p>
      </div>

      <div class="p-4 space-y-5">
        <!-- 1. Vehicle Selection -->
        <div>
          <div class="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">Ford Digital Twin Model</div>
          <div class="grid grid-cols-2 gap-2">
            @for (family of vehicleRegistry; track family.id) {
              <button
                [id]="'select-family-' + family.familyKey"
                (click)="selectFamily(family)"
                class="p-2.5 rounded-xl border text-left transition-all relative overflow-hidden"
                [class.bg-blue-950/60]="physics.activeVehicleFamily()?.id === family.id"
                [class.border-blue-500]="physics.activeVehicleFamily()?.id === family.id"
                [class.bg-slate-950/50]="physics.activeVehicleFamily()?.id !== family.id"
                [class.border-slate-800]="physics.activeVehicleFamily()?.id !== family.id"
                [class.hover:border-slate-700]="physics.activeVehicleFamily()?.id !== family.id"
              >
                <div class="flex items-center justify-between">
                  <span class="font-bold text-xs text-white">{{ family.name }}</span>
                  <span class="text-[9px] px-1.5 py-0.5 rounded font-mono uppercase" [class.bg-blue-500/20]="family.category === 'EV'" [class.text-blue-400]="family.category === 'EV'" [class.bg-slate-800]="family.category !== 'EV'" [class.text-slate-400]="family.category !== 'EV'">
                    {{ family.category }}
                  </span>
                </div>
                <div class="text-[10px] text-slate-400 truncate mt-1">{{ family.generation }}</div>
              </button>
            }
          </div>
        </div>

        <!-- 2. Trim Selection (If multiple) -->
        @if (physics.activeVehicleFamily()?.trims && physics.activeVehicleFamily()!.trims.length > 1) {
          <div>
            <div class="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">Trim & Powertrain Variant</div>
            <div class="space-y-1.5">
              @for (trim of physics.activeVehicleFamily()!.trims; track trim.id) {
                <button
                  (click)="selectTrim(trim)"
                  class="w-full p-2 rounded-lg border text-left text-xs transition-all flex items-center justify-between"
                  [class.bg-blue-600]="physics.activeTrim()?.id === trim.id"
                  [class.text-white]="physics.activeTrim()?.id === trim.id"
                  [class.border-blue-500]="physics.activeTrim()?.id === trim.id"
                  [class.bg-slate-950/50]="physics.activeTrim()?.id !== trim.id"
                  [class.text-slate-300]="physics.activeTrim()?.id !== trim.id"
                  [class.border-slate-800]="physics.activeTrim()?.id !== trim.id"
                >
                  <span class="font-semibold">{{ trim.trimName }}</span>
                  <span class="font-mono text-[11px] opacity-80">{{ trim.propulsion }} · {{ trim.drive }}</span>
                </button>
              }
            </div>
          </div>
        }

        <!-- 3. G.O.A.T. Drive Modes -->
        <div>
          <div class="flex items-center justify-between mb-2">
            <div class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Terrain / Drive Mode (G.O.A.T.)</div>
            <span class="text-[10px] font-mono text-blue-400">{{ physics.currentDriveMode() }}</span>
          </div>

          <div class="grid grid-cols-3 gap-1.5">
            @for (mode of driveModes; track mode) {
              <button
                (click)="physics.setDriveMode(mode)"
                class="px-2 py-1.5 rounded-lg border text-[11px] font-medium transition-colors text-center truncate"
                [class.bg-blue-600]="physics.currentDriveMode() === mode"
                [class.border-blue-400]="physics.currentDriveMode() === mode"
                [class.text-white]="physics.currentDriveMode() === mode"
                [class.bg-slate-950/60]="physics.currentDriveMode() !== mode"
                [class.border-slate-800]="physics.currentDriveMode() !== mode"
                [class.text-slate-400]="physics.currentDriveMode() !== mode"
                [class.hover:text-slate-200]="physics.currentDriveMode() !== mode"
              >
                {{ mode }}
              </button>
            }
          </div>
        </div>

        <!-- 4. Terrain Surface Friction -->
        <div>
          <div class="flex items-center justify-between mb-2">
            <div class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Surface Friction (μ)</div>
            <span class="text-[10px] font-mono text-amber-400">μ = {{ physics.liveState().terrainContactFriction }}</span>
          </div>

          <div class="grid grid-cols-2 gap-1.5">
            @for (terr of terrains; track terr.key) {
              <button
                (click)="physics.setTerrain(terr.key)"
                class="p-2 rounded-lg border text-left text-xs transition-colors flex items-center justify-between"
                [class.bg-amber-600]="physics.currentTerrain() === terr.key"
                [class.border-amber-400]="physics.currentTerrain() === terr.key"
                [class.text-white]="physics.currentTerrain() === terr.key"
                [class.bg-slate-950/60]="physics.currentTerrain() !== terr.key"
                [class.border-slate-800]="physics.currentTerrain() !== terr.key"
                [class.text-slate-400]="physics.currentTerrain() !== terr.key"
              >
                <span>{{ terr.label }}</span>
                <span class="font-mono text-[10px] opacity-75">μ {{ terr.mu }}</span>
              </button>
            }
          </div>
        </div>

        <!-- 5. 4x4 Transfer Case & Lockers -->
        <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
          <div class="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-2.5">Driveline & Off-Road Hardware</div>
          
          <div class="grid grid-cols-4 gap-1 mb-3">
            @for (mode4x4 of fourByFourModes; track mode4x4) {
              <button
                (click)="set4x4(mode4x4)"
                class="py-1 rounded text-xs font-mono font-bold transition-colors border"
                [class.bg-blue-600]="physics.liveState().fourWheelDriveMode === mode4x4"
                [class.border-blue-400]="physics.liveState().fourWheelDriveMode === mode4x4"
                [class.text-white]="physics.liveState().fourWheelDriveMode === mode4x4"
                [class.bg-slate-900]="physics.liveState().fourWheelDriveMode !== mode4x4"
                [class.border-slate-800]="physics.liveState().fourWheelDriveMode !== mode4x4"
                [class.text-slate-400]="physics.liveState().fourWheelDriveMode !== mode4x4"
              >
                {{ mode4x4 }}
              </button>
            }
          </div>

          <div class="grid grid-cols-2 gap-2 text-xs">
            <button
              (click)="toggleDiffLock('rear')"
              class="p-2 rounded-lg border text-center transition-colors font-medium flex items-center justify-center gap-1"
              [class.bg-amber-600]="physics.liveState().rearDiffLocked"
              [class.border-amber-400]="physics.liveState().rearDiffLocked"
              [class.text-white]="physics.liveState().rearDiffLocked"
              [class.bg-slate-900]="!physics.liveState().rearDiffLocked"
              [class.border-slate-800]="!physics.liveState().rearDiffLocked"
              [class.text-slate-400]="!physics.liveState().rearDiffLocked"
            >
              <mat-icon class="!w-4 !h-4 !text-base">lock</mat-icon>
              <span>Rear Locker</span>
            </button>

            <button
              (click)="toggleDiffLock('front')"
              class="p-2 rounded-lg border text-center transition-colors font-medium flex items-center justify-center gap-1"
              [class.bg-amber-600]="physics.liveState().frontDiffLocked"
              [class.border-amber-400]="physics.liveState().frontDiffLocked"
              [class.text-white]="physics.liveState().frontDiffLocked"
              [class.bg-slate-900]="!physics.liveState().frontDiffLocked"
              [class.border-slate-800]="!physics.liveState().frontDiffLocked"
              [class.text-slate-400]="!physics.liveState().frontDiffLocked"
            >
              <mat-icon class="!w-4 !h-4 !text-base">lock</mat-icon>
              <span>Front Locker</span>
            </button>
          </div>
        </div>

        <!-- 6. Trailer Hitching & Towing Module -->
        <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
          <div class="flex items-center justify-between mb-2">
            <div class="text-[11px] font-bold uppercase tracking-wider text-slate-300">Trailer Hitch & Towing</div>
            @if (physics.attachedTrailer()) {
              <button (click)="physics.setTrailer(null)" class="text-[10px] text-red-400 hover:underline">Detach</button>
            }
          </div>

          <div class="space-y-1.5">
            @for (tr of trailerCatalog; track tr.id) {
              <button
                (click)="physics.setTrailer(tr)"
                class="w-full p-2 rounded-lg border text-left text-xs transition-colors flex items-center justify-between"
                [class.bg-blue-600]="physics.attachedTrailer()?.id === tr.id"
                [class.border-blue-400]="physics.attachedTrailer()?.id === tr.id"
                [class.text-white]="physics.attachedTrailer()?.id === tr.id"
                [class.bg-slate-900]="physics.attachedTrailer()?.id !== tr.id"
                [class.border-slate-800]="physics.attachedTrailer()?.id !== tr.id"
                [class.text-slate-300]="physics.attachedTrailer()?.id !== tr.id"
              >
                <div>
                  <div class="font-medium truncate">{{ tr.name }}</div>
                  <div class="text-[10px] opacity-75 font-mono">{{ tr.curbMassKg + tr.currentPayloadKg }} kg GVWR</div>
                </div>
                <span class="text-[10px] font-mono opacity-80">{{ tr.tongueWeightPercentage }}% Tongue</span>
              </button>
            }
          </div>
        </div>

        <!-- 7. Cargo & Payload Placer -->
        <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
          <div class="flex items-center justify-between mb-2">
            <div class="text-[11px] font-bold uppercase tracking-wider text-slate-300">Payload Cargo Items</div>
            @if (physics.loadedCargos().length > 0) {
              <button (click)="physics.clearAllCargo()" class="text-[10px] text-red-400 hover:underline">Clear All</button>
            }
          </div>

          <div class="grid grid-cols-2 gap-1.5">
            @for (cargo of cargoCatalog; track cargo.id) {
              <button
                (click)="toggleCargo(cargo)"
                class="p-2 rounded-lg border text-left text-xs transition-colors"
                [class.bg-emerald-600]="isCargoLoaded(cargo.id)"
                [class.border-emerald-400]="isCargoLoaded(cargo.id)"
                [class.text-white]="isCargoLoaded(cargo.id)"
                [class.bg-slate-900]="!isCargoLoaded(cargo.id)"
                [class.border-slate-800]="!isCargoLoaded(cargo.id)"
                [class.text-slate-400]="!isCargoLoaded(cargo.id)"
              >
                <div class="font-medium truncate">{{ cargo.name }}</div>
                <div class="text-[10px] font-mono opacity-80">+{{ cargo.massKg }} kg</div>
              </button>
            }
          </div>
        </div>

        <!-- 8. Road Incline Grade Slider -->
        <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3">
          <div class="flex justify-between items-center mb-1.5">
            <div class="text-[11px] font-bold uppercase tracking-wider text-slate-300">Road Grade Incline</div>
            <span class="font-mono text-xs text-blue-400 font-bold">{{ physics.roadGradePercent() }}%</span>
          </div>
          <input
            type="range"
            min="-15"
            max="25"
            step="1"
            [value]="physics.roadGradePercent()"
            (input)="onGradeChange($event)"
            class="w-full accent-blue-500 bg-slate-800 h-2 rounded-lg appearance-none cursor-pointer"
          />
          <div class="flex justify-between text-[9px] font-mono text-slate-500 mt-1">
            <span>-15% (Downhill)</span>
            <span>0% (Flat)</span>
            <span>+25% (Steep Crawl)</span>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `],
})
export class PowertrainConfigurator {
  physics = inject(VehiclePhysicsService);

  readonly vehicleRegistry = FORD_VEHICLE_REGISTRY;
  readonly trailerCatalog = SYNTHETIC_TRAILER_CATALOG;
  readonly cargoCatalog = SYNTHETIC_CARGO_CATALOG;
  readonly fourByFourModes: ('2H' | '4A' | '4H' | '4L')[] = ['2H', '4A', '4H', '4L'];

  readonly driveModes: DriveMode[] = [
    'NORMAL',
    'SPORT',
    'ECO',
    'TOW_HAUL',
    'SLIPPERY',
    'MUD_RUTS',
    'SAND',
    'ROCK_CRAWL',
    'BAJA',
  ];

  readonly terrains = [
    { key: 'DRY_ASPHALT' as TerrainType, label: 'Dry Asphalt', mu: 1.05 },
    { key: 'WET_ASPHALT' as TerrainType, label: 'Wet Asphalt', mu: 0.72 },
    { key: 'MUD' as TerrainType, label: 'Deep Mud', mu: 0.45 },
    { key: 'SAND' as TerrainType, label: 'Dune Sand', mu: 0.52 },
    { key: 'ROCK' as TerrainType, label: 'Rock Crawl', mu: 0.88 },
    { key: 'SNOW_ICE' as TerrainType, label: 'Snow & Ice', mu: 0.28 },
  ];

  selectFamily(family: VehicleFamily) {
    const trim = family.trims[0];
    this.physics.initVehicle(family, trim);
  }

  selectTrim(trim: VehicleTrim) {
    const family = this.physics.activeVehicleFamily();
    if (family) {
      this.physics.initVehicle(family, trim);
    }
  }

  set4x4(mode: '2H' | '4A' | '4H' | '4L') {
    this.physics.liveState.update((s) => ({
      ...s,
      fourWheelDriveMode: mode,
    }));
  }

  toggleDiffLock(axis: 'front' | 'rear') {
    this.physics.liveState.update((s) => ({
      ...s,
      frontDiffLocked: axis === 'front' ? !s.frontDiffLocked : s.frontDiffLocked,
      rearDiffLocked: axis === 'rear' ? !s.rearDiffLocked : s.rearDiffLocked,
    }));
  }

  isCargoLoaded(id: string): boolean {
    return this.physics.loadedCargos().some((c) => c.id === id);
  }

  toggleCargo(cargo: CargoItem) {
    if (this.isCargoLoaded(cargo.id)) {
      this.physics.removeCargo(cargo.id);
    } else {
      this.physics.addCargo(cargo);
    }
  }

  onGradeChange(event: Event) {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.physics.setRoadGrade(val);
  }
}
