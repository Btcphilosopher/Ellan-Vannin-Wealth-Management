import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MANUFACTURING_STATIONS } from '../../data/manufacturing-data';
import { ManufacturingStation } from '../../models/vehicle.model';

@Component({
  selector: 'app-manufacturing-digital-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-900 border-l border-slate-800 text-slate-200 overflow-y-auto custom-scrollbar">
      <!-- Header -->
      <div class="p-4 border-b border-slate-800 bg-slate-950/60 sticky top-0 z-10 backdrop-blur">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-blue-500 !w-5 !h-5 !text-lg">factory</mat-icon>
            <div>
              <span class="font-bold text-sm text-white uppercase tracking-wider">Dearborn & Rouge Plant</span>
              <p class="text-[10px] text-slate-400">Assembly Line Digital Twin & Metrology</p>
            </div>
          </div>
          <div class="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono">
            <span>TAKT 53s</span>
          </div>
        </div>
      </div>

      <!-- Assembly Line Sequence -->
      <div class="p-4 space-y-3">
        @for (st of stations(); track st.id) {
          <button
            type="button"
            (click)="selectedStation.set(st)"
            class="w-full text-left p-3 rounded-xl border transition-all cursor-pointer block"
            [class.bg-blue-950/40]="selectedStation()?.id === st.id"
            [class.border-blue-500]="selectedStation()?.id === st.id"
            [class.bg-slate-950/60]="selectedStation()?.id !== st.id"
            [class.border-slate-800]="selectedStation()?.id !== st.id"
          >
            <div class="flex items-center justify-between mb-1.5">
              <div class="flex items-center gap-2">
                <span class="font-mono font-bold text-xs text-blue-400">{{ st.code }}</span>
                <span class="text-xs font-semibold text-white">{{ st.name }}</span>
              </div>
              <span class="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono">
                {{ st.qualityMetrics.laserToleranceMm }}mm TOL
              </span>
            </div>

            <p class="text-[11px] text-slate-400 leading-relaxed mb-2">{{ st.description }}</p>

            <div class="grid grid-cols-2 gap-2 text-[10px] font-mono pt-2 border-t border-slate-800 text-slate-400">
              <div>Weld/Structural: <span class="text-white font-bold">{{ st.qualityMetrics.weldIntegrityScore }}%</span></div>
              <div>Cycle Time: <span class="text-white font-bold">{{ st.cycleTimeSeconds }}s</span></div>
            </div>

            <div class="mt-2 flex flex-wrap gap-1">
              @for (comp of st.installedComponents; track comp) {
                <span class="text-[9px] bg-slate-900 border border-slate-800 text-slate-400 px-1.5 py-0.5 rounded">
                  {{ comp }}
                </span>
              }
            </div>
          </button>
        }
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `],
})
export class ManufacturingDigitalTwin {
  readonly stations = signal<ManufacturingStation[]>(MANUFACTURING_STATIONS);
  readonly selectedStation = signal<ManufacturingStation | null>(MANUFACTURING_STATIONS[0]);
}
