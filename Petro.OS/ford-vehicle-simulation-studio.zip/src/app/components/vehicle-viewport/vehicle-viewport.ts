import {
  Component,
  ElementRef,
  ViewChild,
  OnInit,
  OnDestroy,
  NgZone,
  inject,
  HostListener,
  ChangeDetectionStrategy,
  signal,
  effect,
  PLATFORM_ID,
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { VehiclePhysicsService } from '../../services/vehicle-physics.service';
import { VehicleTrim, VehicleFamily, TerrainType, TrailerSpec, VehicleLiveState } from '../../models/vehicle.model';

export type ViewportCameraMode = 'ORBIT' | 'CHASE' | 'COCKPIT' | 'CHASSIS_BOTTOM' | 'HITCH_FOCUS';
export type VisualRenderMode = 'SOLID' | 'XRAY_POWERTRAIN' | 'THERMAL_HEATMAP' | 'AERO_STREAMLINES' | 'WIREFRAME';

@Component({
  selector: 'app-vehicle-viewport',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full overflow-hidden bg-slate-950 select-none" #canvasContainer>
      <!-- 3D Canvas -->
      <canvas #glCanvas class="w-full h-full block cursor-grab active:cursor-grabbing"></canvas>

      <!-- Viewport Overlays & Heads-Up Display Controls -->
      <div class="absolute top-4 left-4 flex flex-wrap items-center gap-2 z-10">
        <!-- Camera Mode Selector -->
        <div class="bg-slate-900/90 backdrop-blur border border-slate-800 rounded-xl p-1 flex items-center shadow-lg">
          <button
            id="cam-orbit-btn"
            (click)="setCameraMode('ORBIT')"
            class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            [class.bg-blue-600]="cameraMode() === 'ORBIT'"
            [class.text-white]="cameraMode() === 'ORBIT'"
            [class.text-slate-400]="cameraMode() !== 'ORBIT'"
            [class.hover:text-slate-200]="cameraMode() !== 'ORBIT'"
            title="360° Free Orbit Camera"
          >
            <mat-icon class="!w-4 !h-4 !text-base">360</mat-icon>
            <span>Orbit</span>
          </button>
          <button
            id="cam-chase-btn"
            (click)="setCameraMode('CHASE')"
            class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            [class.bg-blue-600]="cameraMode() === 'CHASE'"
            [class.text-white]="cameraMode() === 'CHASE'"
            [class.text-slate-400]="cameraMode() !== 'CHASE'"
            [class.hover:text-slate-200]="cameraMode() !== 'CHASE'"
            title="Dynamic Chase Follow"
          >
            <mat-icon class="!w-4 !h-4 !text-base">videocam</mat-icon>
            <span>Chase</span>
          </button>
          <button
            id="cam-cockpit-btn"
            (click)="setCameraMode('COCKPIT')"
            class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            [class.bg-blue-600]="cameraMode() === 'COCKPIT'"
            [class.text-white]="cameraMode() === 'COCKPIT'"
            [class.text-slate-400]="cameraMode() !== 'COCKPIT'"
            [class.hover:text-slate-200]="cameraMode() !== 'COCKPIT'"
            title="Driver POV Cockpit"
          >
            <mat-icon class="!w-4 !h-4 !text-base">airline_seat_recline_extra</mat-icon>
            <span>Cockpit</span>
          </button>
          <button
            id="cam-chassis-btn"
            (click)="setCameraMode('CHASSIS_BOTTOM')"
            class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            [class.bg-blue-600]="cameraMode() === 'CHASSIS_BOTTOM'"
            [class.text-white]="cameraMode() === 'CHASSIS_BOTTOM'"
            [class.text-slate-400]="cameraMode() !== 'CHASSIS_BOTTOM'"
            [class.hover:text-slate-200]="cameraMode() !== 'CHASSIS_BOTTOM'"
            title="Underbody & Powertrain Inspection"
          >
            <mat-icon class="!w-4 !h-4 !text-base">car_repair</mat-icon>
            <span>Underbody</span>
          </button>
        </div>

        <!-- Render Mode Selector -->
        <div class="bg-slate-900/90 backdrop-blur border border-slate-800 rounded-xl p-1 flex items-center shadow-lg">
          <button
            id="render-solid-btn"
            (click)="setRenderMode('SOLID')"
            class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            [class.bg-indigo-600]="renderMode() === 'SOLID'"
            [class.text-white]="renderMode() === 'SOLID'"
            [class.text-slate-400]="renderMode() !== 'SOLID'"
            [class.hover:text-slate-200]="renderMode() !== 'SOLID'"
            title="Standard Exterior Realism"
          >
            <mat-icon class="!w-4 !h-4 !text-base">palette</mat-icon>
            <span>Solid</span>
          </button>
          <button
            id="render-xray-btn"
            (click)="setRenderMode('XRAY_POWERTRAIN')"
            class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            [class.bg-indigo-600]="renderMode() === 'XRAY_POWERTRAIN'"
            [class.text-white]="renderMode() === 'XRAY_POWERTRAIN'"
            [class.text-slate-400]="renderMode() !== 'XRAY_POWERTRAIN'"
            [class.hover:text-slate-200]="renderMode() !== 'XRAY_POWERTRAIN'"
            title="X-Ray Drivetrain & Battery Structural View"
          >
            <mat-icon class="!w-4 !h-4 !text-base">visibility</mat-icon>
            <span>X-Ray</span>
          </button>
          <button
            id="render-thermal-btn"
            (click)="setRenderMode('THERMAL_HEATMAP')"
            class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            [class.bg-indigo-600]="renderMode() === 'THERMAL_HEATMAP'"
            [class.text-white]="renderMode() === 'THERMAL_HEATMAP'"
            [class.text-slate-400]="renderMode() !== 'THERMAL_HEATMAP'"
            [class.hover:text-slate-200]="renderMode() !== 'THERMAL_HEATMAP'"
            title="Thermal Heatmap: Engine, Battery, Inverters & Brakes"
          >
            <mat-icon class="!w-4 !h-4 !text-base">whatshot</mat-icon>
            <span>Thermal</span>
          </button>
          <button
            id="render-aero-btn"
            (click)="setRenderMode('AERO_STREAMLINES')"
            class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
            [class.bg-indigo-600]="renderMode() === 'AERO_STREAMLINES'"
            [class.text-white]="renderMode() === 'AERO_STREAMLINES'"
            [class.text-slate-400]="renderMode() !== 'AERO_STREAMLINES'"
            [class.hover:text-slate-200]="renderMode() !== 'AERO_STREAMLINES'"
            title="CFD Aerodynamic Airflow Streamlines"
          >
            <mat-icon class="!w-4 !h-4 !text-base">air</mat-icon>
            <span>Aero CFD</span>
          </button>
        </div>
      </div>

      <!-- Interactive Kinematics Overlay (Doors, Hood, Tailgate, Roof) -->
      <div class="absolute top-4 right-4 flex flex-col gap-2 z-10">
        <div class="bg-slate-900/90 backdrop-blur border border-slate-800 rounded-xl p-2 flex flex-col gap-1.5 shadow-lg">
          <div class="text-[10px] uppercase font-bold tracking-wider text-slate-400 px-1 mb-0.5">Kinematic Actions</div>
          <div class="grid grid-cols-2 gap-1">
            <button
              id="toggle-hood-btn"
              (click)="physics.toggleMechanism('hood')"
              class="px-2 py-1 rounded text-xs transition-colors flex items-center gap-1"
              [class.bg-amber-600]="physics.liveState().hoodOpen"
              [class.text-white]="physics.liveState().hoodOpen"
              [class.bg-slate-800]="!physics.liveState().hoodOpen"
              [class.text-slate-300]="!physics.liveState().hoodOpen"
            >
              <mat-icon class="!w-3.5 !h-3.5 !text-sm">precision_manufacturing</mat-icon>
              <span>Hood</span>
            </button>
            <button
              id="toggle-tailgate-btn"
              (click)="physics.toggleMechanism('tailgate')"
              class="px-2 py-1 rounded text-xs transition-colors flex items-center gap-1"
              [class.bg-amber-600]="physics.liveState().tailgateOpen"
              [class.text-white]="physics.liveState().tailgateOpen"
              [class.bg-slate-800]="!physics.liveState().tailgateOpen"
              [class.text-slate-300]="!physics.liveState().tailgateOpen"
            >
              <mat-icon class="!w-3.5 !h-3.5 !text-sm">back_hand</mat-icon>
              <span>Tailgate</span>
            </button>
            <button
              id="toggle-door-fl-btn"
              (click)="physics.toggleMechanism('doorFL')"
              class="px-2 py-1 rounded text-xs transition-colors flex items-center gap-1"
              [class.bg-amber-600]="physics.liveState().doorsOpen[0]"
              [class.text-white]="physics.liveState().doorsOpen[0]"
              [class.bg-slate-800]="!physics.liveState().doorsOpen[0]"
              [class.text-slate-300]="!physics.liveState().doorsOpen[0]"
            >
              <mat-icon class="!w-3.5 !h-3.5 !text-sm">sensor_door</mat-icon>
              <span>Dr FL</span>
            </button>
            <button
              id="toggle-door-fr-btn"
              (click)="physics.toggleMechanism('doorFR')"
              class="px-2 py-1 rounded text-xs transition-colors flex items-center gap-1"
              [class.bg-amber-600]="physics.liveState().doorsOpen[1]"
              [class.text-white]="physics.liveState().doorsOpen[1]"
              [class.bg-slate-800]="!physics.liveState().doorsOpen[1]"
              [class.text-slate-300]="!physics.liveState().doorsOpen[1]"
            >
              <mat-icon class="!w-3.5 !h-3.5 !text-sm">sensor_door</mat-icon>
              <span>Dr FR</span>
            </button>
          </div>

          @if (physics.activeVehicleFamily()?.familyKey === 'bronco') {
            <div class="grid grid-cols-2 gap-1 mt-1 pt-1 border-t border-slate-800">
              <button
                id="toggle-roof-btn"
                (click)="physics.toggleMechanism('roof')"
                class="px-2 py-1 rounded text-xs transition-colors flex items-center gap-1"
                [class.bg-emerald-600]="physics.liveState().roofRemoved"
                [class.text-white]="physics.liveState().roofRemoved"
                [class.bg-slate-800]="!physics.liveState().roofRemoved"
                [class.text-slate-300]="!physics.liveState().roofRemoved"
              >
                <mat-icon class="!w-3.5 !h-3.5 !text-sm">roofing</mat-icon>
                <span>Roof Off</span>
              </button>
              <button
                id="toggle-doors-removed-btn"
                (click)="physics.toggleMechanism('doorsRemoved')"
                class="px-2 py-1 rounded text-xs transition-colors flex items-center gap-1"
                [class.bg-emerald-600]="physics.liveState().doorsRemoved"
                [class.text-white]="physics.liveState().doorsRemoved"
                [class.bg-slate-800]="!physics.liveState().doorsRemoved"
                [class.text-slate-300]="!physics.liveState().doorsRemoved"
              >
                <mat-icon class="!w-3.5 !h-3.5 !text-sm">door_sliding</mat-icon>
                <span>Doors Off</span>
              </button>
            </div>
          }

          <div class="flex items-center justify-between mt-1 pt-1 border-t border-slate-800">
            <button
              id="toggle-lights-btn"
              (click)="physics.toggleLights()"
              class="px-2 py-1 rounded text-xs transition-colors flex items-center gap-1 flex-1 justify-center"
              [class.bg-yellow-500]="physics.liveState().headlightsOn"
              [class.text-slate-950]="physics.liveState().headlightsOn"
              [class.font-semibold]="physics.liveState().headlightsOn"
              [class.bg-slate-800]="!physics.liveState().headlightsOn"
              [class.text-slate-300]="!physics.liveState().headlightsOn"
            >
              <mat-icon class="!w-3.5 !h-3.5 !text-sm">light_mode</mat-icon>
              <span>Lights</span>
            </button>
          </div>
        </div>
      </div>

      <!-- Dynamic Vehicle Spec Mini Badge -->
      <div class="absolute bottom-4 left-4 bg-slate-900/85 backdrop-blur border border-slate-800 rounded-xl p-3 shadow-xl max-w-sm pointer-events-none">
        <div class="flex items-center gap-2">
          <div class="w-2.5 h-2.5 rounded-full" [class.bg-emerald-400]="physics.liveState().speedKmh > 0" [class.bg-blue-400]="physics.liveState().speedKmh === 0"></div>
          <span class="text-xs font-semibold text-white tracking-wide uppercase">{{ physics.activeVehicleFamily()?.name }}</span>
          <span class="text-[11px] text-slate-400 font-mono">{{ physics.activeTrim()?.trimName }}</span>
        </div>
        <div class="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-slate-800 text-[11px]">
          <div>
            <div class="text-slate-500">Speed</div>
            <div class="text-white font-mono font-bold">{{ physics.liveState().speedKmh }} <span class="text-[9px] font-normal text-slate-400">km/h</span></div>
          </div>
          <div>
            <div class="text-slate-500">Powertrain</div>
            <div class="text-white font-mono font-bold">
              @if (physics.activeTrim()?.propulsion === 'BEV') {
                {{ physics.liveState().evPowerKw }} <span class="text-[9px] font-normal text-slate-400">kW</span>
              } @else {
                {{ physics.liveState().rpm }} <span class="text-[9px] font-normal text-slate-400">RPM</span>
              }
            </div>
          </div>
          <div>
            <div class="text-slate-500">Mass / Load</div>
            <div class="text-white font-mono font-bold">{{ physics.liveState().totalVehicleMassKg }} <span class="text-[9px] font-normal text-slate-400">kg</span></div>
          </div>
        </div>
      </div>

      <!-- Quick Guidance -->
      <div class="absolute bottom-4 right-4 bg-slate-900/75 backdrop-blur border border-slate-800 text-[10px] text-slate-400 rounded-lg px-2.5 py-1.5 flex items-center gap-2 pointer-events-none">
        <span><kbd class="bg-slate-800 px-1 py-0.5 rounded text-slate-300 font-mono">W/S</kbd> Throttle/Brake</span>
        <span><kbd class="bg-slate-800 px-1 py-0.5 rounded text-slate-300 font-mono">A/D</kbd> Steer</span>
        <span><kbd class="bg-slate-800 px-1 py-0.5 rounded text-slate-300 font-mono">Mouse</kbd> Drag to Orbit</span>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
})
export class VehicleViewport implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) containerRef!: ElementRef<HTMLDivElement>;
  @ViewChild('glCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  physics = inject(VehiclePhysicsService);
  private ngZone = inject(NgZone);
  private platformId = inject(PLATFORM_ID);

  readonly cameraMode = signal<ViewportCameraMode>('ORBIT');
  readonly renderMode = signal<VisualRenderMode>('SOLID');

  // Three.js Core
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;
  private resizeObserver!: ResizeObserver;

  // 3D Scene Components
  private vehicleGroup = new THREE.Group();
  private chassisMeshGroup = new THREE.Group();
  private wheelsGroup: THREE.Group[] = [];
  private brakeDiscs: THREE.Mesh[] = [];
  private animatedSuspensionSprings: THREE.Mesh[] = [];
  private hoodMesh: THREE.Group | null = null;
  private tailgateMesh: THREE.Group | null = null;
  private doorMeshes: (THREE.Group | null)[] = [null, null, null, null];
  private roofMesh: THREE.Mesh | null = null;
  private aeroStreamlineParticles: THREE.Points | null = null;
  private proPowerOutletGlow: THREE.PointLight | null = null;
  private headlightsLight: THREE.SpotLight | null = null;
  private trailerGroup: THREE.Group | null = null;
  private groundMesh!: THREE.Mesh;
  private groundGrid!: THREE.GridHelper;

  // Materials Cache
  private carPaintMaterial!: THREE.MeshPhysicalMaterial;
  private glassMaterial!: THREE.MeshPhysicalMaterial;
  private chromeMaterial!: THREE.MeshStandardMaterial;
  private matteBlackMaterial!: THREE.MeshStandardMaterial;
  private tireRubberMaterial!: THREE.MeshStandardMaterial;
  private brakeSteelMaterial!: THREE.MeshStandardMaterial;
  private glowBrakeMaterial!: THREE.MeshBasicMaterial;
  private batteryPackMaterial!: THREE.MeshStandardMaterial;
  private engineBlockMaterial!: THREE.MeshStandardMaterial;
  private copperWiringMaterial!: THREE.MeshStandardMaterial;

  // Orbit / Interaction State
  private isMouseDown = false;
  private mousePrevX = 0;
  private mousePrevY = 0;
  private orbitSpherical = new THREE.Spherical(7.5, Math.PI / 3, Math.PI / 4);
  private orbitTarget = new THREE.Vector3(0, 0.8, 0);

  constructor() {
    // React to vehicle change to rebuild 3D digital twin
    effect(() => {
      const family = this.physics.activeVehicleFamily();
      const trim = this.physics.activeTrim();
      if (family && trim && this.scene) {
        this.buildVehicleDigitalTwin(family, trim);
      }
    });

    // React to trailer change
    effect(() => {
      const trailer = this.physics.attachedTrailer();
      if (this.scene) {
        this.buildTrailerDigitalTwin(trailer);
      }
    });

    // React to terrain change
    effect(() => {
      const terrain = this.physics.currentTerrain();
      if (this.groundMesh) {
        this.updateTerrainVisual(terrain);
      }
    });
  }

  ngOnInit() {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }

    this.ngZone.runOutsideAngular(() => {
      this.initThreeJs();
      this.startRenderLoop();
    });

    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => {
        this.onResize();
      });
      this.resizeObserver.observe(this.containerRef.nativeElement);
    }
  }

  ngOnDestroy() {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }
    if (this.animationFrameId !== null && typeof cancelAnimationFrame !== 'undefined') {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    this.renderer?.dispose();
  }

  setCameraMode(mode: ViewportCameraMode) {
    this.cameraMode.set(mode);
    if (mode === 'ORBIT') {
      this.orbitSpherical.radius = 7.5;
      this.orbitSpherical.phi = Math.PI / 3;
      this.orbitSpherical.theta = Math.PI / 4;
      this.orbitTarget.set(0, 0.8, 0);
    } else if (mode === 'CHASSIS_BOTTOM') {
      this.orbitSpherical.radius = 5.2;
      this.orbitSpherical.phi = (Math.PI * 0.95);
      this.orbitSpherical.theta = 0;
      this.orbitTarget.set(0, 0.4, 0);
    }
  }

  setRenderMode(mode: VisualRenderMode) {
    this.renderMode.set(mode);
    this.updateMaterialRenderModes();
  }

  private initThreeJs() {
    const container = this.containerRef.nativeElement;
    const canvas = this.canvasRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0d14);
    this.scene.fog = new THREE.FogExp2(0x0a0d14, 0.015);

    // Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 200);
    this.updateCameraPosition();

    // Renderer
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;

    // Environment Lighting
    this.setupEnvironmentLighting();

    // Materials
    this.initSharedMaterials();

    // Proving Grounds Base
    this.setupProvingGrounds();

    // Add Vehicle Group
    this.scene.add(this.vehicleGroup);

    // Aerodynamic CFD Streamlines Particles
    this.setupAeroParticles();

    // Canvas Mouse / Touch Listeners
    this.setupOrbitControls();

    // Build initial vehicle if ready
    const family = this.physics.activeVehicleFamily();
    const trim = this.physics.activeTrim();
    if (family && trim) {
      this.buildVehicleDigitalTwin(family, trim);
    }
  }

  private setupEnvironmentLighting() {
    // Ambient fill
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambientLight);

    // Main Key Sunlight
    const dirLight = new THREE.DirectionalLight(0xffffff, 1.8);
    dirLight.position.set(15, 25, 15);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 60;
    const d = 10;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0005;
    this.scene.add(dirLight);

    // Studio Rim Light Blue
    const rimLightBlue = new THREE.DirectionalLight(0x38bdf8, 1.2);
    rimLightBlue.position.set(-15, 12, -15);
    this.scene.add(rimLightBlue);

    // Studio Warm Fill
    const fillLight = new THREE.DirectionalLight(0xfef08a, 0.6);
    fillLight.position.set(0, -5, 10);
    this.scene.add(fillLight);
  }

  private initSharedMaterials() {
    this.carPaintMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x1c2841,
      metalness: 0.9,
      roughness: 0.18,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
    });

    this.glassMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x111827,
      metalness: 0.1,
      roughness: 0.05,
      transmission: 0.85,
      transparent: true,
      opacity: 0.6,
      ior: 1.5,
    });

    this.chromeMaterial = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      metalness: 0.95,
      roughness: 0.08,
    });

    this.matteBlackMaterial = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.3,
      roughness: 0.85,
    });

    this.tireRubberMaterial = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      metalness: 0.1,
      roughness: 0.92,
    });

    this.brakeSteelMaterial = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.9,
      roughness: 0.25,
    });

    this.glowBrakeMaterial = new THREE.MeshBasicMaterial({
      color: 0xff3300,
    });

    this.batteryPackMaterial = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      metalness: 0.7,
      roughness: 0.3,
    });

    this.engineBlockMaterial = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.8,
      roughness: 0.35,
    });

    this.copperWiringMaterial = new THREE.MeshStandardMaterial({
      color: 0xf97316,
      metalness: 0.9,
      roughness: 0.2,
    });
  }

  private setupProvingGrounds() {
    // High-resolution ground plane
    const groundGeo = new THREE.PlaneGeometry(160, 160, 32, 32);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.75,
      metalness: 0.2,
    });
    this.groundMesh = new THREE.Mesh(groundGeo, groundMat);
    this.groundMesh.rotation.x = -Math.PI / 2;
    this.groundMesh.position.y = 0;
    this.groundMesh.receiveShadow = true;
    this.scene.add(this.groundMesh);

    // Studio Proving Grounds Grid
    this.groundGrid = new THREE.GridHelper(120, 60, 0x38bdf8, 0x1e293b);
    this.groundGrid.position.y = 0.005;
    this.scene.add(this.groundGrid);
  }

  private updateTerrainVisual(terrain: TerrainType) {
    const mat = this.groundMesh.material as THREE.MeshStandardMaterial;
    switch (terrain) {
      case 'DRY_ASPHALT':
        mat.color.setHex(0x0f172a);
        mat.roughness = 0.75;
        break;
      case 'WET_ASPHALT':
        mat.color.setHex(0x090d16);
        mat.roughness = 0.15;
        mat.metalness = 0.5;
        break;
      case 'MUD':
        mat.color.setHex(0x3e2723);
        mat.roughness = 0.9;
        break;
      case 'SAND':
        mat.color.setHex(0xc2a649);
        mat.roughness = 0.95;
        break;
      case 'ROCK':
        mat.color.setHex(0x475569);
        mat.roughness = 0.85;
        break;
      case 'SNOW_ICE':
        mat.color.setHex(0xe2e8f0);
        mat.roughness = 0.3;
        break;
      case 'GRAVEL':
        mat.color.setHex(0x52525b);
        mat.roughness = 0.9;
        break;
    }
  }

  private setupAeroParticles() {
    const particleCount = 600;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3 + 0] = (Math.random() - 0.5) * 3.5;
      positions[i * 3 + 1] = 0.2 + Math.random() * 2.2;
      positions[i * 3 + 2] = -6 + Math.random() * 12;

      // Blue to cyan gradient
      colors[i * 3 + 0] = 0.1;
      colors[i * 3 + 1] = 0.6 + Math.random() * 0.4;
      colors[i * 3 + 2] = 1.0;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.06,
      vertexColors: true,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
    });

    this.aeroStreamlineParticles = new THREE.Points(geometry, particleMat);
    this.aeroStreamlineParticles.visible = false;
    this.scene.add(this.aeroStreamlineParticles);
  }

  /**
   * Procedurally generates the 3D canonical Ford Digital Twin
   */
  private buildVehicleDigitalTwin(family: VehicleFamily, trim: VehicleTrim) {
    // Clear existing vehicle elements
    while (this.vehicleGroup.children.length > 0) {
      const child = this.vehicleGroup.children[0];
      this.vehicleGroup.remove(child);
    }
    this.wheelsGroup = [];
    this.brakeDiscs = [];
    this.animatedSuspensionSprings = [];
    this.hoodMesh = null;
    this.tailgateMesh = null;
    this.doorMeshes = [null, null, null, null];
    this.roofMesh = null;

    // Dimensions in meters
    const lengthM = family.dimensions.length / 1000;
    const widthM = family.dimensions.width / 1000;
    const heightM = family.dimensions.height / 1000;
    const wheelbaseM = family.dimensions.wheelbase / 1000;
    const trackWidthM = family.dimensions.trackFront / 1000;
    const rideHeightM = family.dimensions.groundClearance / 1000;

    // Set paint color
    const colorHex = trim.availableColors[0]?.hex || '#1c2841';
    this.carPaintMaterial.color.setStyle(colorHex);

    // Main Chassis Group
    this.chassisMeshGroup = new THREE.Group();
    this.chassisMeshGroup.position.y = rideHeightM;

    // 1. High-Strength Ladder Frame / Unibody Base Subframe
    const frameLength = lengthM * 0.92;
    const frameWidth = trackWidthM * 0.65;
    const frameRailGeo = new THREE.BoxGeometry(0.12, 0.15, frameLength);
    const frameRailMat = this.matteBlackMaterial;

    const leftRail = new THREE.Mesh(frameRailGeo, frameRailMat);
    leftRail.position.set(-frameWidth / 2, 0.1, 0);
    leftRail.castShadow = true;
    this.chassisMeshGroup.add(leftRail);

    const rightRail = new THREE.Mesh(frameRailGeo, frameRailMat);
    rightRail.position.set(frameWidth / 2, 0.1, 0);
    rightRail.castShadow = true;
    this.chassisMeshGroup.add(rightRail);

    // Crossmembers
    for (let z = -frameLength / 2 + 0.4; z <= frameLength / 2 - 0.4; z += frameLength / 5) {
      const crossGeo = new THREE.BoxGeometry(frameWidth, 0.1, 0.1);
      const crossMesh = new THREE.Mesh(crossGeo, frameRailMat);
      crossMesh.position.set(0, 0.1, z);
      crossMesh.castShadow = true;
      this.chassisMeshGroup.add(crossMesh);
    }

    // 2. Body Architecture according to Vehicle Category
    this.buildCategorySpecificBody(family, trim, lengthM, widthM, heightM, wheelbaseM, rideHeightM);

    // 3. Powertrain Mechanical Objects (Engine / Battery / Motors / Exhaust / Trans)
    this.buildPowertrainComponents(trim, lengthM, widthM, wheelbaseM);

    // 4. Wheels, Tyres, Brakes & Animated Suspension Coilovers
    this.buildWheelsAndSuspension(trim, wheelbaseM, trackWidthM);

    // 5. Lighting & Headlight Spotlights
    this.setupVehicleLights(lengthM, widthM);

    this.vehicleGroup.add(this.chassisMeshGroup);
  }

  private buildCategorySpecificBody(
    family: VehicleFamily,
    _trim: VehicleTrim,
    lengthM: number,
    widthM: number,
    heightM: number,
    wheelbaseM: number,
    rideHeightM: number
  ) {
    const isPickup = family.category === 'PICKUP' || family.category === 'HEAVY_DUTY';
    const isOffroad = family.category === 'OFF_ROAD';
    const isVan = family.category === 'COMMERCIAL_VAN';
    const isCoupe = family.category === 'CAR';

    const bodyElevation = 0.2;

    if (isPickup) {
      // Cab (Cabin)
      const cabLength = wheelbaseM * 0.7;
      const cabWidth = widthM * 0.92;
      const cabHeight = (heightM - rideHeightM) * 0.85;
      const cabGeo = new THREE.BoxGeometry(cabWidth, cabHeight, cabLength);
      const cabMesh = new THREE.Mesh(cabGeo, this.carPaintMaterial);
      cabMesh.position.set(0, bodyElevation + cabHeight / 2, -wheelbaseM * 0.12);
      cabMesh.castShadow = true;
      cabMesh.receiveShadow = true;
      this.chassisMeshGroup.add(cabMesh);

      // Glass Windshield & Windows
      const glassGeo = new THREE.BoxGeometry(cabWidth * 0.96, cabHeight * 0.45, cabLength * 0.85);
      const glassMesh = new THREE.Mesh(glassGeo, this.glassMaterial);
      glassMesh.position.set(0, bodyElevation + cabHeight * 0.75, -wheelbaseM * 0.12);
      this.chassisMeshGroup.add(glassMesh);

      // Hood & Engine Bay (Front)
      const hoodLength = lengthM * 0.28;
      const hoodWidth = cabWidth * 0.92;
      const hoodHeight = cabHeight * 0.55;
      const hoodGroup = new THREE.Group();
      hoodGroup.position.set(0, bodyElevation + hoodHeight / 2, wheelbaseM * 0.28);

      const hoodMesh = new THREE.Mesh(new THREE.BoxGeometry(hoodWidth, hoodHeight, hoodLength), this.carPaintMaterial);
      hoodMesh.castShadow = true;
      hoodGroup.add(hoodMesh);

      // Front Ford Grille
      const grilleGeo = new THREE.BoxGeometry(hoodWidth * 0.85, hoodHeight * 0.7, 0.08);
      const grilleMesh = new THREE.Mesh(grilleGeo, this.matteBlackMaterial);
      grilleMesh.position.set(0, 0, hoodLength / 2 + 0.04);
      hoodGroup.add(grilleMesh);

      this.hoodMesh = hoodGroup;
      this.chassisMeshGroup.add(hoodGroup);

      // Pickup Bed (Rear)
      const bedLength = lengthM * 0.38;
      const bedWidth = cabWidth;
      const bedHeight = cabHeight * 0.52;
      const bedGeo = new THREE.BoxGeometry(bedWidth, bedHeight, bedLength);
      const bedMesh = new THREE.Mesh(bedGeo, this.carPaintMaterial);
      bedMesh.position.set(0, bodyElevation + bedHeight / 2, -wheelbaseM * 0.62);
      bedMesh.castShadow = true;
      this.chassisMeshGroup.add(bedMesh);

      // Tailgate
      const tailgateGroup = new THREE.Group();
      tailgateGroup.position.set(0, bodyElevation + 0.1, -wheelbaseM * 0.62 - bedLength / 2);
      const tailgateMesh = new THREE.Mesh(new THREE.BoxGeometry(bedWidth * 0.95, bedHeight * 0.85, 0.08), this.carPaintMaterial);
      tailgateMesh.position.set(0, bedHeight * 0.42, 0);
      tailgateMesh.castShadow = true;
      tailgateGroup.add(tailgateMesh);
      this.tailgateMesh = tailgateGroup;
      this.chassisMeshGroup.add(tailgateGroup);

      // Pro Power Onboard bed electrical outlet box
      const ppoGeo = new THREE.BoxGeometry(0.12, 0.18, 0.08);
      const ppoMesh = new THREE.Mesh(ppoGeo, this.matteBlackMaterial);
      ppoMesh.position.set(-bedWidth / 2 + 0.08, bodyElevation + bedHeight * 0.5, -wheelbaseM * 0.55);
      this.chassisMeshGroup.add(ppoMesh);

    } else if (isOffroad) {
      // Bronco Modular Off-Road Body
      const cabLength = wheelbaseM * 0.92;
      const cabWidth = widthM * 0.88;
      const cabHeight = (heightM - rideHeightM) * 0.82;

      // Lower Body Tub
      const tubGeo = new THREE.BoxGeometry(cabWidth, cabHeight * 0.6, cabLength);
      const tubMesh = new THREE.Mesh(tubGeo, this.carPaintMaterial);
      tubMesh.position.set(0, bodyElevation + (cabHeight * 0.6) / 2, 0);
      tubMesh.castShadow = true;
      this.chassisMeshGroup.add(tubMesh);

      // Removable Hardtop Roof
      const roofGeo = new THREE.BoxGeometry(cabWidth * 0.94, cabHeight * 0.42, cabLength * 0.65);
      this.roofMesh = new THREE.Mesh(roofGeo, this.matteBlackMaterial);
      this.roofMesh.position.set(0, bodyElevation + cabHeight * 0.78, -cabLength * 0.12);
      this.roofMesh.castShadow = true;
      this.chassisMeshGroup.add(this.roofMesh);

      // Bronco Rear Spare Tire
      const spareTireGeo = new THREE.CylinderGeometry(0.44, 0.44, 0.28, 24);
      const spareTireMesh = new THREE.Mesh(spareTireGeo, this.tireRubberMaterial);
      spareTireMesh.rotation.z = Math.PI / 2;
      spareTireMesh.position.set(0, bodyElevation + cabHeight * 0.5, -cabLength / 2 - 0.22);
      spareTireMesh.castShadow = true;
      this.chassisMeshGroup.add(spareTireMesh);

      // Heavy Duty Steel Winch Bumper (Front)
      const bumperGeo = new THREE.BoxGeometry(cabWidth * 1.05, 0.18, 0.22);
      const bumperMesh = new THREE.Mesh(bumperGeo, this.matteBlackMaterial);
      bumperMesh.position.set(0, bodyElevation + 0.1, cabLength / 2 + 0.12);
      bumperMesh.castShadow = true;
      this.chassisMeshGroup.add(bumperMesh);

    } else if (isVan) {
      // Transit High-Roof Cargo Van
      const vanLength = lengthM * 0.92;
      const vanWidth = widthM * 0.9;
      const vanHeight = (heightM - rideHeightM) * 0.92;

      const vanGeo = new THREE.BoxGeometry(vanWidth, vanHeight, vanLength);
      const vanMesh = new THREE.Mesh(vanGeo, this.carPaintMaterial);
      vanMesh.position.set(0, bodyElevation + vanHeight / 2, 0);
      vanMesh.castShadow = true;
      this.chassisMeshGroup.add(vanMesh);

      // Windshield slope
      const windGeo = new THREE.BoxGeometry(vanWidth * 0.92, vanHeight * 0.35, vanLength * 0.25);
      const windMesh = new THREE.Mesh(windGeo, this.glassMaterial);
      windMesh.position.set(0, bodyElevation + vanHeight * 0.65, vanLength * 0.35);
      this.chassisMeshGroup.add(windMesh);

    } else if (isCoupe) {
      // Mustang Fastback Sports Coupe
      const coupeLength = lengthM * 0.92;
      const coupeWidth = widthM * 0.92;
      const coupeHeight = (heightM - rideHeightM) * 0.88;

      // Sleek Lower Body
      const lowBodyGeo = new THREE.BoxGeometry(coupeWidth, coupeHeight * 0.55, coupeLength);
      const lowBodyMesh = new THREE.Mesh(lowBodyGeo, this.carPaintMaterial);
      lowBodyMesh.position.set(0, bodyElevation + (coupeHeight * 0.55) / 2, 0);
      lowBodyMesh.castShadow = true;
      this.chassisMeshGroup.add(lowBodyMesh);

      // Aerodynamic Fastback Glasshouse
      const glasshouseGeo = new THREE.BoxGeometry(coupeWidth * 0.82, coupeHeight * 0.48, coupeLength * 0.55);
      const glasshouseMesh = new THREE.Mesh(glasshouseGeo, this.glassMaterial);
      glasshouseMesh.position.set(0, bodyElevation + coupeHeight * 0.72, -coupeLength * 0.08);
      this.chassisMeshGroup.add(glasshouseMesh);

      // Rear Decklid Spoiler
      const spoilerGeo = new THREE.BoxGeometry(coupeWidth * 0.88, 0.05, 0.25);
      const spoilerMesh = new THREE.Mesh(spoilerGeo, this.matteBlackMaterial);
      spoilerMesh.position.set(0, bodyElevation + coupeHeight * 0.58, -coupeLength / 2 + 0.15);
      this.chassisMeshGroup.add(spoilerMesh);

      // Quad Exhaust Tips (Rear)
      for (const x of [-0.6, -0.45, 0.45, 0.6]) {
        const exhaustGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.25, 16);
        const exhaustMesh = new THREE.Mesh(exhaustGeo, this.chromeMaterial);
        exhaustMesh.rotation.x = Math.PI / 2;
        exhaustMesh.position.set(x, bodyElevation + 0.08, -coupeLength / 2 - 0.08);
        this.chassisMeshGroup.add(exhaustMesh);
      }
    } else {
      // SUV (Explorer, Mach-E)
      const suvLength = lengthM * 0.92;
      const suvWidth = widthM * 0.9;
      const suvHeight = (heightM - rideHeightM) * 0.85;

      const suvGeo = new THREE.BoxGeometry(suvWidth, suvHeight * 0.6, suvLength);
      const suvMesh = new THREE.Mesh(suvGeo, this.carPaintMaterial);
      suvMesh.position.set(0, bodyElevation + (suvHeight * 0.6) / 2, 0);
      suvMesh.castShadow = true;
      this.chassisMeshGroup.add(suvMesh);

      // Roof & Glass
      const roofGeo = new THREE.BoxGeometry(suvWidth * 0.88, suvHeight * 0.42, suvLength * 0.7);
      const roofMesh = new THREE.Mesh(roofGeo, this.glassMaterial);
      roofMesh.position.set(0, bodyElevation + suvHeight * 0.75, -suvLength * 0.05);
      this.chassisMeshGroup.add(roofMesh);
    }
  }

  private buildPowertrainComponents(trim: VehicleTrim, lengthM: number, widthM: number, wheelbaseM: number) {
    if (trim.propulsion === 'BEV' || trim.propulsion === 'HEV') {
      // 1. Structural High-Voltage Battery Pack (Between Frame Rails)
      const battLength = wheelbaseM * 0.68;
      const battWidth = widthM * 0.62;
      const battThickness = 0.18;
      const battGeo = new THREE.BoxGeometry(battWidth, battThickness, battLength);
      const battMesh = new THREE.Mesh(battGeo, this.batteryPackMaterial);
      battMesh.position.set(0, 0.12, 0);
      battMesh.castShadow = true;
      this.chassisMeshGroup.add(battMesh);

      // Orange High-Voltage Shielded Busbar Cables
      const cableGeo = new THREE.CylinderGeometry(0.025, 0.025, battLength * 1.1, 12);
      const cableLeft = new THREE.Mesh(cableGeo, this.copperWiringMaterial);
      cableLeft.rotation.x = Math.PI / 2;
      cableLeft.position.set(-battWidth / 2 + 0.06, 0.22, 0);
      this.chassisMeshGroup.add(cableLeft);

      // Front & Rear Electric Motors
      if (trim.evMotor?.frontMotorHp) {
        const frontMotorGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.42, 20);
        const frontMotorMesh = new THREE.Mesh(frontMotorGeo, this.matteBlackMaterial);
        frontMotorMesh.rotation.z = Math.PI / 2;
        frontMotorMesh.position.set(0, 0.15, wheelbaseM / 2);
        this.chassisMeshGroup.add(frontMotorMesh);
      }

      if (trim.evMotor?.rearMotorHp) {
        const rearMotorGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.45, 20);
        const rearMotorMesh = new THREE.Mesh(rearMotorGeo, this.matteBlackMaterial);
        rearMotorMesh.rotation.z = Math.PI / 2;
        rearMotorMesh.position.set(0, 0.15, -wheelbaseM / 2);
        this.chassisMeshGroup.add(rearMotorMesh);
      }
    }

    if (trim.propulsion === 'ICE' || trim.propulsion === 'HEV') {
      // V8 / V6 Engine Block under the hood
      const engineGeo = new THREE.BoxGeometry(0.55, 0.45, 0.65);
      const engineMesh = new THREE.Mesh(engineGeo, this.engineBlockMaterial);
      engineMesh.position.set(0, 0.35, wheelbaseM / 2 - 0.2);
      engineMesh.castShadow = true;
      this.chassisMeshGroup.add(engineMesh);

      // 10-Speed Transmission behind engine
      const transGeo = new THREE.CylinderGeometry(0.16, 0.18, 0.75, 16);
      const transMesh = new THREE.Mesh(transGeo, this.matteBlackMaterial);
      transMesh.rotation.x = Math.PI / 2;
      transMesh.position.set(0, 0.25, wheelbaseM * 0.1);
      this.chassisMeshGroup.add(transMesh);

      // Driveshaft to Rear Axle
      const driveShaftGeo = new THREE.CylinderGeometry(0.04, 0.04, wheelbaseM * 0.55, 12);
      const driveShaft = new THREE.Mesh(driveShaftGeo, this.chromeMaterial);
      driveShaft.rotation.x = Math.PI / 2;
      driveShaft.position.set(0, 0.18, -wheelbaseM * 0.25);
      this.chassisMeshGroup.add(driveShaft);
    }
  }

  private buildWheelsAndSuspension(trim: VehicleTrim, wheelbaseM: number, trackWidthM: number) {
    const rimRadiusM = (trim.tyres.rimDiameterInches * 0.0254) / 2;
    const tireWidthM = trim.tyres.widthMm / 1000;
    const tireRadiusM = rimRadiusM + (trim.tyres.widthMm * (trim.tyres.aspectRatio / 100)) / 1000;

    // 4 Corner Positions: FL, FR, RL, RR
    const cornerPositions: [number, number, number][] = [
      [-trackWidthM / 2, 0, wheelbaseM / 2],  // FL
      [trackWidthM / 2, 0, wheelbaseM / 2],   // FR
      [-trackWidthM / 2, 0, -wheelbaseM / 2], // RL
      [trackWidthM / 2, 0, -wheelbaseM / 2],  // RR
    ];

    for (let i = 0; i < 4; i++) {
      const [posX, , posZ] = cornerPositions[i];
      const isLeft = i % 2 === 0;

      const wheelHub = new THREE.Group();
      wheelHub.position.set(posX, tireRadiusM, posZ);

      // Tire Tread Mesh
      const tireGeo = new THREE.CylinderGeometry(tireRadiusM, tireRadiusM, tireWidthM, 32);
      const tireMesh = new THREE.Mesh(tireGeo, this.tireRubberMaterial);
      tireMesh.rotation.z = Math.PI / 2;
      tireMesh.castShadow = true;
      wheelHub.add(tireMesh);

      // Alloy Rim Mesh
      const rimGeo = new THREE.CylinderGeometry(rimRadiusM, rimRadiusM, tireWidthM * 1.02, 24);
      const rimMesh = new THREE.Mesh(rimGeo, this.chromeMaterial);
      rimMesh.rotation.z = Math.PI / 2;
      wheelHub.add(rimMesh);

      // Brake Rotor Disc
      const discGeo = new THREE.CylinderGeometry(rimRadiusM * 0.72, rimRadiusM * 0.72, 0.03, 24);
      const discMesh = new THREE.Mesh(discGeo, this.brakeSteelMaterial);
      discMesh.rotation.z = Math.PI / 2;
      discMesh.position.x = isLeft ? 0.06 : -0.06;
      wheelHub.add(discMesh);
      this.brakeDiscs.push(discMesh);

      // Brembo / High Performance Caliper
      const caliperGeo = new THREE.BoxGeometry(0.08, 0.12, 0.18);
      const caliperMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, metalness: 0.8, roughness: 0.2 });
      const caliperMesh = new THREE.Mesh(caliperGeo, caliperMat);
      caliperMesh.position.set(isLeft ? 0.06 : -0.06, rimRadiusM * 0.45, 0);
      wheelHub.add(caliperMesh);

      // Active Coilover Spring / Shock Absorber (Connected from hub to chassis)
      const springGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.35, 12);
      const springMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.9, roughness: 0.2 });
      const springMesh = new THREE.Mesh(springGeo, springMat);
      springMesh.position.set(isLeft ? 0.12 : -0.12, 0.2, 0);
      wheelHub.add(springMesh);
      this.animatedSuspensionSprings.push(springMesh);

      this.wheelsGroup.push(wheelHub);
      this.vehicleGroup.add(wheelHub);
    }
  }

  private setupVehicleLights(lengthM: number, widthM: number) {
    // LED Headlight Beams (Front)
    const headLeft = new THREE.SpotLight(0xffffff, 2.5, 45, Math.PI / 6, 0.4, 1.2);
    headLeft.position.set(-widthM * 0.35, 0.8, lengthM * 0.46);
    headLeft.target.position.set(-widthM * 0.35, 0, lengthM * 0.46 + 15);
    this.scene.add(headLeft.target);
    this.chassisMeshGroup.add(headLeft);
    this.headlightsLight = headLeft;

    const headRight = new THREE.SpotLight(0xffffff, 2.5, 45, Math.PI / 6, 0.4, 1.2);
    headRight.position.set(widthM * 0.35, 0.8, lengthM * 0.46);
    headRight.target.position.set(widthM * 0.35, 0, lengthM * 0.46 + 15);
    this.scene.add(headRight.target);
    this.chassisMeshGroup.add(headRight);
  }

  private buildTrailerDigitalTwin(trailer: TrailerSpec | null) {
    if (this.trailerGroup) {
      this.scene.remove(this.trailerGroup);
      this.trailerGroup = null;
    }

    if (!trailer) return;

    this.trailerGroup = new THREE.Group();
    const family = this.physics.activeVehicleFamily();
    const wheelbaseM = (family?.dimensions.wheelbase || 3683) / 1000;
    const hitchPosZ = -wheelbaseM * 0.72;

    this.trailerGroup.position.set(0, 0.4, hitchPosZ - 1.5);

    // Trailer Frame
    const tLength = 6.0;
    const tWidth = 2.2;
    const tGeo = new THREE.BoxGeometry(tWidth, 0.15, tLength);
    const tMat = this.matteBlackMaterial;
    const tMesh = new THREE.Mesh(tGeo, tMat);
    tMesh.position.set(0, 0.1, -tLength / 2);
    tMesh.castShadow = true;
    this.trailerGroup.add(tMesh);

    // Trailer Payload Box / Boat / Equipment
    const payloadGeo = new THREE.BoxGeometry(tWidth * 0.9, 1.2, tLength * 0.75);
    const payloadMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.5, roughness: 0.4 });
    const payloadMesh = new THREE.Mesh(payloadGeo, payloadMat);
    payloadMesh.position.set(0, 0.75, -tLength / 2);
    payloadMesh.castShadow = true;
    this.trailerGroup.add(payloadMesh);

    // Trailer Wheels
    for (const x of [-tWidth / 2 - 0.1, tWidth / 2 + 0.1]) {
      const twGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.22, 20);
      const twMesh = new THREE.Mesh(twGeo, this.tireRubberMaterial);
      twMesh.rotation.z = Math.PI / 2;
      twMesh.position.set(x, 0.05, -tLength * 0.6);
      twMesh.castShadow = true;
      this.trailerGroup.add(twMesh);
    }

    this.scene.add(this.trailerGroup);
  }

  private updateMaterialRenderModes() {
    const mode = this.renderMode();
    if (mode === 'XRAY_POWERTRAIN') {
      this.carPaintMaterial.transparent = true;
      this.carPaintMaterial.opacity = 0.22;
      this.carPaintMaterial.wireframe = false;
      this.batteryPackMaterial.color.setHex(0x00f0ff);
      this.engineBlockMaterial.color.setHex(0xffaa00);
      if (this.aeroStreamlineParticles) this.aeroStreamlineParticles.visible = false;
    } else if (mode === 'THERMAL_HEATMAP') {
      this.carPaintMaterial.transparent = true;
      this.carPaintMaterial.opacity = 0.35;
      this.carPaintMaterial.wireframe = false;
      if (this.aeroStreamlineParticles) this.aeroStreamlineParticles.visible = false;
    } else if (mode === 'AERO_STREAMLINES') {
      this.carPaintMaterial.transparent = true;
      this.carPaintMaterial.opacity = 0.4;
      this.carPaintMaterial.wireframe = false;
      if (this.aeroStreamlineParticles) this.aeroStreamlineParticles.visible = true;
    } else if (mode === 'WIREFRAME') {
      this.carPaintMaterial.transparent = false;
      this.carPaintMaterial.wireframe = true;
      if (this.aeroStreamlineParticles) this.aeroStreamlineParticles.visible = false;
    } else {
      // SOLID
      this.carPaintMaterial.transparent = false;
      this.carPaintMaterial.opacity = 1.0;
      this.carPaintMaterial.wireframe = false;
      if (this.aeroStreamlineParticles) this.aeroStreamlineParticles.visible = false;
    }
    this.carPaintMaterial.needsUpdate = true;
  }

  private startRenderLoop() {
    let lastTime = performance.now();

    const animate = (currentTime: number) => {
      this.animationFrameId = requestAnimationFrame(animate);

      const dt = Math.min(0.05, (currentTime - lastTime) / 1000);
      lastTime = currentTime;

      // 1. Run physics step
      this.physics.stepPhysics(dt);
      const state = this.physics.liveState();

      // 2. Animate 3D Vehicle Kinematics
      this.update3DLiveVisuals(state, dt);

      // 3. Update Camera Mode
      this.updateCameraForFrame();

      // 4. Render Frame
      this.renderer.render(this.scene, this.camera);
    };

    this.animationFrameId = requestAnimationFrame(animate);
  }

  private update3DLiveVisuals(state: VehicleLiveState, dt: number) {
    // Pitch & Roll angles of the body on suspension
    this.chassisMeshGroup.rotation.x = THREE.MathUtils.degToRad(state.pitchAngleDeg || 0);
    this.chassisMeshGroup.rotation.z = THREE.MathUtils.degToRad(-state.rollAngleDeg || 0);

    // Wheel Steer & Rotation
    const wheelRollSpeed = (state.speedMps / 0.42) * dt;
    const steerRad = THREE.MathUtils.degToRad(state.wheelSteerAngleDeg || 0);

    for (let i = 0; i < this.wheelsGroup.length; i++) {
      const wheel = this.wheelsGroup[i];
      const isFront = i < 2;

      // Rotation around axle
      wheel.children[0].rotation.x += wheelRollSpeed; // Tire
      wheel.children[1].rotation.x += wheelRollSpeed; // Rim

      // Front wheel steering yaw
      if (isFront) {
        wheel.rotation.y = steerRad;
      }

      // Suspension travel displacement
      const travelMm = state.suspensionTravelMm[i] || 80;
      wheel.position.y = 0.42 - (travelMm - 80) * 0.001;

      // Brake glow under heat
      const brakeTemp = state.brakeDiscTempsC[i] || 50;
      if (this.brakeDiscs[i]) {
        const mat = this.brakeDiscs[i].material as THREE.MeshStandardMaterial;
        if (brakeTemp > 300) {
          const glowFrac = Math.min(1.0, (brakeTemp - 300) / 300);
          mat.emissive.setRGB(glowFrac * 0.9, glowFrac * 0.2, 0);
        } else {
          mat.emissive.setRGB(0, 0, 0);
        }
      }
    }

    // Kinematic Hood Open/Close
    if (this.hoodMesh) {
      const targetAngle = state.hoodOpen ? -Math.PI / 4 : 0;
      this.hoodMesh.rotation.x = THREE.MathUtils.lerp(this.hoodMesh.rotation.x, targetAngle, 0.15);
    }

    // Kinematic Tailgate Open/Close
    if (this.tailgateMesh) {
      const targetAngle = state.tailgateOpen ? -Math.PI / 2 : 0;
      this.tailgateMesh.rotation.x = THREE.MathUtils.lerp(this.tailgateMesh.rotation.x, targetAngle, 0.15);
    }

    // Bronco Roof / Doors visibility
    if (this.roofMesh) {
      this.roofMesh.visible = !state.roofRemoved;
    }

    // Headlights beam
    if (this.headlightsLight) {
      this.headlightsLight.visible = state.headlightsOn;
    }

    // Trailer Sway
    if (this.trailerGroup) {
      this.trailerGroup.rotation.y = THREE.MathUtils.degToRad(state.trailerSwayAngleDeg || 0);
    }

    // Aerodynamic particles flow animation
    if (this.aeroStreamlineParticles && this.aeroStreamlineParticles.visible) {
      const posAttr = this.aeroStreamlineParticles.geometry.attributes['position'] as THREE.BufferAttribute;
      const positions = posAttr.array as Float32Array;
      const speed = Math.max(10, state.speedKmh) * 0.05;

      for (let i = 0; i < positions.length / 3; i++) {
        positions[i * 3 + 2] -= speed * dt;
        if (positions[i * 3 + 2] < -6) {
          positions[i * 3 + 2] = 6;
        }
      }
      posAttr.needsUpdate = true;
    }
  }

  private updateCameraForFrame() {
    const mode = this.cameraMode();

    if (mode === 'ORBIT' || mode === 'CHASSIS_BOTTOM') {
      this.updateCameraPosition();
    } else if (mode === 'CHASE') {
      // Dynamic follow chase camera
      const targetPos = new THREE.Vector3(0, 1.8, 6.5);
      this.camera.position.lerp(targetPos, 0.08);
      this.camera.lookAt(0, 0.8, -2);
    } else if (mode === 'COCKPIT') {
      // Driver POV
      this.camera.position.set(-0.45, 1.25, 0.1);
      this.camera.lookAt(-0.45, 1.15, 10);
    }
  }

  private updateCameraPosition() {
    this.camera.position.setFromSpherical(this.orbitSpherical).add(this.orbitTarget);
    this.camera.lookAt(this.orbitTarget);
  }

  private setupOrbitControls() {
    const canvas = this.canvasRef.nativeElement;

    canvas.addEventListener('mousedown', (e) => {
      if (this.cameraMode() !== 'ORBIT' && this.cameraMode() !== 'CHASSIS_BOTTOM') return;
      this.isMouseDown = true;
      this.mousePrevX = e.clientX;
      this.mousePrevY = e.clientY;
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isMouseDown) return;
      const dx = e.clientX - this.mousePrevX;
      const dy = e.clientY - this.mousePrevY;
      this.mousePrevX = e.clientX;
      this.mousePrevY = e.clientY;

      this.orbitSpherical.theta -= dx * 0.006;
      this.orbitSpherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, this.orbitSpherical.phi - dy * 0.006));
      this.updateCameraPosition();
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
    });

    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      if (this.cameraMode() !== 'ORBIT' && this.cameraMode() !== 'CHASSIS_BOTTOM') return;
      this.orbitSpherical.radius = Math.max(3.2, Math.min(22.0, this.orbitSpherical.radius + e.deltaY * 0.008));
      this.updateCameraPosition();
    }, { passive: false });
  }

  private onResize() {
    const container = this.containerRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    if (this.camera && this.renderer) {
      this.camera.aspect = width / height;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(width, height);
    }
  }

  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent) {
    if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;

    if (event.key === 'w' || event.key === 'ArrowUp') {
      this.physics.updateInputControls(1.0, 0, this.physics.liveState().steeringInputAngleDeg / 450);
    } else if (event.key === 's' || event.key === 'ArrowDown') {
      this.physics.updateInputControls(0, 1.0, this.physics.liveState().steeringInputAngleDeg / 450);
    } else if (event.key === 'a' || event.key === 'ArrowLeft') {
      this.physics.updateInputControls(
        this.physics.liveState().throttleInput,
        this.physics.liveState().brakeInput,
        -0.8
      );
    } else if (event.key === 'd' || event.key === 'ArrowRight') {
      this.physics.updateInputControls(
        this.physics.liveState().throttleInput,
        this.physics.liveState().brakeInput,
        0.8
      );
    } else if (event.key === ' ') {
      this.physics.updateInputControls(0, 1.0, 0, true);
    }
  }

  @HostListener('window:keyup', ['$event'])
  handleKeyUp(event: KeyboardEvent) {
    if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;

    if (event.key === 'w' || event.key === 'ArrowUp' || event.key === 's' || event.key === 'ArrowDown') {
      this.physics.updateInputControls(0, 0, this.physics.liveState().steeringInputAngleDeg / 450);
    } else if (event.key === 'a' || event.key === 'ArrowLeft' || event.key === 'd' || event.key === 'ArrowRight') {
      this.physics.updateInputControls(
        this.physics.liveState().throttleInput,
        this.physics.liveState().brakeInput,
        0
      );
    } else if (event.key === ' ') {
      this.physics.updateInputControls(0, 0, 0, false);
    }
  }
}
