import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { INITIAL_FLEET_VEHICLES } from '../../data/fleet-data';
import { FleetVehicleInstance } from '../../models/vehicle.model';

@Component({
  selector: 'app-fleet-telematics-panel',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-900 border-l border-slate-800 text-slate-200 overflow-y-auto custom-scrollbar">
      <!-- Header -->
      <div class="p-4 border-b border-slate-800 bg-slate-950/60 sticky top-0 z-10 backdrop-blur">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-blue-500 !w-5 !h-5 !text-lg">local_shipping</mat-icon>
            <div>
              <span class="font-bold text-sm text-white uppercase tracking-wider">Ford Pro™ Telematics</span>
              <p class="text-[10px] text-slate-400">Commercial Fleet Operations & Logistics</p>
            </div>
          </div>
          <div class="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-[10px] font-mono">
            <span>{{ fleetVehicles().length }} Active Units</span>
          </div>
        </div>
      </div>

      <!-- Fleet Overview KPI Cards -->
      <div class="p-4 space-y-4">
        <div class="grid grid-cols-3 gap-2">
          <div class="bg-slate-950/70 border border-slate-800 p-2.5 rounded-xl text-center">
            <div class="text-[9px] text-slate-400 uppercase font-mono">In Transit</div>
            <div class="text-lg font-bold font-mono text-emerald-400 mt-0.5">7</div>
            <div class="text-[9px] text-slate-500">Live GPS</div>
          </div>

          <div class="bg-slate-950/70 border border-slate-800 p-2.5 rounded-xl text-center">
            <div class="text-[9px] text-slate-400 uppercase font-mono">Avg Health</div>
            <div class="text-lg font-bold font-mono text-sky-400 mt-0.5">96.8%</div>
            <div class="text-[9px] text-slate-500">CAN-Bus DTC</div>
          </div>

          <div class="bg-slate-950/70 border border-slate-800 p-2.5 rounded-xl text-center">
            <div class="text-[9px] text-slate-400 uppercase font-mono">Depot / Charge</div>
            <div class="text-lg font-bold font-mono text-amber-400 mt-0.5">3</div>
            <div class="text-[9px] text-slate-500">Staged</div>
          </div>
        </div>

        <!-- Vehicle Fleet Roster -->
        <div class="space-y-2">
          <div class="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">Fleet Asset Stream</div>

          @for (veh of fleetVehicles(); track veh.vin) {
            <button
              type="button"
              (click)="selectedVehicle.set(veh)"
              class="w-full text-left p-3 rounded-xl border transition-all cursor-pointer block"
              [class.bg-blue-950/40]="selectedVehicle()?.vin === veh.vin"
              [class.border-blue-500]="selectedVehicle()?.vin === veh.vin"
              [class.bg-slate-950/60]="selectedVehicle()?.vin !== veh.vin"
              [class.border-slate-800]="selectedVehicle()?.vin !== veh.vin"
              [class.hover:border-slate-700]="selectedVehicle()?.vin !== veh.vin"
            >
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="font-bold text-xs text-white font-mono">{{ veh.unitNumber }}</span>
                  <span class="text-xs font-semibold text-slate-300">{{ veh.familyName }}</span>
                </div>

                <!-- Status Badge -->
                <span
                  class="text-[9px] px-1.5 py-0.5 rounded font-mono uppercase"
                  [class.bg-emerald-500/20]="veh.status === 'IN_TRANSIT'"
                  [class.text-emerald-400]="veh.status === 'IN_TRANSIT'"
                  [class.bg-amber-500/20]="veh.status === 'CHARGING' || veh.status === 'IDLE_DEPOT'"
                  [class.text-amber-400]="veh.status === 'CHARGING' || veh.status === 'IDLE_DEPOT'"
                  [class.bg-red-500/20]="veh.status === 'MAINTENANCE_REQUIRED'"
                  [class.text-red-400]="veh.status === 'MAINTENANCE_REQUIRED'"
                >
                  {{ veh.status.replace('_', ' ') }}
                </span>
              </div>

              <div class="grid grid-cols-3 gap-2 text-[10px] font-mono mt-2 pt-2 border-t border-slate-800/80 text-slate-400">
                <div>
                  <span>Speed: </span>
                  <span class="text-white font-bold">{{ veh.currentSpeedKmh }} km/h</span>
                </div>
                <div>
                  <span>{{ veh.propulsion === 'BEV' ? 'SOC' : 'Fuel' }}: </span>
                  <span [class.text-emerald-400]="veh.socOrFuelPercent > 50" [class.text-amber-400]="veh.socOrFuelPercent <= 50" class="font-bold">
                    {{ veh.socOrFuelPercent }}%
                  </span>
                </div>
                <div>
                  <span>Health: </span>
                  <span class="text-sky-400 font-bold">{{ veh.healthScorePercent }}%</span>
                </div>
              </div>

              <div class="text-[10px] text-slate-400 mt-1.5 flex items-center justify-between">
                <span class="truncate">Driver: {{ veh.assignedDriver }}</span>
                <span class="text-slate-500 font-mono">{{ veh.etaMinutes }}m ETA</span>
              </div>

              @if (veh.alerts.length > 0) {
                <div class="mt-2 bg-red-950/40 border border-red-900/40 rounded px-2 py-1 text-[10px] text-red-300 flex items-center gap-1">
                  <mat-icon class="!w-3.5 !h-3.5 !text-sm text-red-400">warning</mat-icon>
                  <span class="truncate">{{ veh.alerts[0] }}</span>
                </div>
              }
            </button>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `],
})
export class FleetTelematicsPanel {
  readonly fleetVehicles = signal<FleetVehicleInstance[]>(INITIAL_FLEET_VEHICLES);
  readonly selectedVehicle = signal<FleetVehicleInstance | null>(INITIAL_FLEET_VEHICLES[0]);
}
