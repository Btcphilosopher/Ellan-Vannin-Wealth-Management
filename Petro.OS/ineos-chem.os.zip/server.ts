/**
 * INEOS CHEM.OS - Express Server
 * REST API, Real-time SSE Telemetry Stream & Gemini AI Intelligence Integration
 */

import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import {
  SITES,
  MATERIALS,
  GRADES,
  BATCHES,
  TANKS,
  SAMPLES,
  ORDERS,
  SHIPMENTS,
  EVENT_STREAM,
  MARKET_PRICES,
  calculateBlendingProposal,
  runScenarioSimulation
} from './src/services/syntheticData';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json({ limit: '10mb' }));

// Server-side Gemini AI Initialization
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// ----------------------------------------------------
// REST API ENDPOINTS
// ----------------------------------------------------

// Sites
app.get('/api/sites', (req: Request, res: Response) => {
  res.json({ status: 'ok', count: SITES.length, sites: SITES });
});

app.get('/api/sites/:id', (req: Request, res: Response) => {
  const site = SITES.find((s) => s.id === req.params.id);
  if (!site) {
    return res.status(404).json({ error: 'Site not found' });
  }
  res.json({ site });
});

// Materials & Grades
app.get('/api/materials', (req: Request, res: Response) => {
  res.json({ count: MATERIALS.length, materials: MATERIALS });
});

app.get('/api/grades', (req: Request, res: Response) => {
  res.json({ count: GRADES.length, grades: GRADES });
});

// Batches & Provenance
app.get('/api/batches', (req: Request, res: Response) => {
  res.json({ count: BATCHES.length, batches: BATCHES });
});

app.get('/api/batches/:id/provenance', (req: Request, res: Response) => {
  const batch = BATCHES.find((b) => b.id === req.params.id);
  if (!batch) {
    return res.status(404).json({ error: 'Batch not found' });
  }

  const site = SITES.find((s) => s.id === batch.siteId);
  const material = MATERIALS.find((m) => m.id === batch.materialId);
  const grade = GRADES.find((g) => g.id === batch.gradeId);
  const samples = SAMPLES.filter((s) => s.batchId === batch.id);
  const shipment = SHIPMENTS.find((shp) => shp.batchId === batch.id);
  const order = shipment ? ORDERS.find((o) => o.id === shipment.orderId) : undefined;
  const tank = TANKS.find((t) => t.id === batch.storageTankId);

  res.json({
    batch,
    provenance: {
      feedstockLot: batch.feedstockLotId,
      siteName: site?.name || 'INEOS UK Site',
      unitId: batch.unitId,
      campaignId: batch.campaignId,
      recipeVersion: batch.recipeVersion,
      material: material?.chemicalName,
      grade: grade?.gradeCode,
      labSamples: samples,
      storageTank: tank ? { id: tank.id, code: tank.tankCode, level: tank.currentLevelTons } : null,
      shipment: shipment ? { id: shipment.id, code: shipment.shipmentNumber, mode: shipment.mode } : null,
      customer: order ? order.customerName : 'UK Industrial Distributer'
    }
  });
});

// Tanks
app.get('/api/tanks', (req: Request, res: Response) => {
  res.json({ count: TANKS.length, tanks: TANKS });
});

// Orders & Shipments
app.get('/api/orders', (req: Request, res: Response) => {
  res.json({ count: ORDERS.length, orders: ORDERS });
});

app.get('/api/shipments', (req: Request, res: Response) => {
  res.json({ count: SHIPMENTS.length, shipments: SHIPMENTS });
});

// Market
app.get('/api/market', (req: Request, res: Response) => {
  res.json({ count: MARKET_PRICES.length, prices: MARKET_PRICES });
});

// Events
app.get('/api/events', (req: Request, res: Response) => {
  res.json({ count: EVENT_STREAM.length, events: EVENT_STREAM });
});

// Blending Engine POST
app.post('/api/blends', (req: Request, res: Response) => {
  const { targetGradeId, targetMassTons } = req.body;
  if (!targetGradeId || !targetMassTons) {
    return res.status(400).json({ error: 'targetGradeId and targetMassTons are required' });
  }

  const proposal = calculateBlendingProposal(targetGradeId, Number(targetMassTons));
  res.json({ proposal });
});

// Scenario Simulation POST
app.post('/api/scenarios/run', (req: Request, res: Response) => {
  const { affectedSiteId, capacityReductionPercent } = req.body;
  const result = runScenarioSimulation(affectedSiteId || 'SITE-RUNCORN', Number(capacityReductionPercent) || 25);
  res.json({ scenarioResult: result });
});

// Real-Time SSE Telemetry Stream
app.get('/api/telemetry/stream', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const interval = setInterval(() => {
    // Generate slight live fluctuations in throughput and pressure for realism
    const liveUpdate = {
      timestamp: new Date().toISOString(),
      activeBatchCount: BATCHES.length,
      runcornCellroom01Pressure: (1.15 + (Math.random() * 0.04 - 0.02)).toFixed(2),
      runcornCellroom01Temp: (88.5 + (Math.random() * 0.6 - 0.3)).toFixed(1),
      grangemouthCrackerFlow: (145.0 + (Math.random() * 2.0 - 1.0)).toFixed(1),
      totalNetworkProductionTonsToday: 18450 + Math.floor(Math.random() * 10)
    };

    res.write(`data: ${JSON.stringify(liveUpdate)}\n\n`);
  }, 3000);

  req.on('close', () => {
    clearInterval(interval);
  });
});

// CHEM.OS Intelligence AI Endpoint (Powered by Gemini Server SDK)
app.post('/api/ai/intelligence', async (req: Request, res: Response) => {
  const { prompt, contextModule } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  if (!ai) {
    // Return structured industrial response if API key is not yet set
    return res.json({
      answer: `[CHEM.OS INTELLIGENCE OFFLINE SIMULATION MODE]
Analysis for request: "${prompt}"

1. PRODUCTION CONSTRAINT DIAGNOSTIC:
- Primary constraint identified in Chlor-Alkali Cellroom Line 1 (Runcorn). Membrane degradation index is 4.2%.
- Secondary buffer capacity at Teesside Terminal stands at 82%, allowing 14-day load shedding.

2. ORDER ALLOCATION RISK:
- Order ORD-2026-8812 (850t Rigid PVC) is 100% matched with Batch B26-09142. Quality release CoA-8812 verified.
- Delivery ETA to Birmingham Hub is September 29, 15:20 GMT.

3. RECOMMENDATION:
- Maintain Runcorn cellroom current density at 4.2 kA/m2.
- Reroute surplus ethylene from Grangemouth KG Cracker to Hull Acetyls loop.`
    });
  }

  try {
    const systemPrompt = `You are CHEM.OS INTELLIGENCE, the internal executive chemical industrial AI engine for INEOS CHEM.OS.
You analyze vertical integration across Feedstock -> Sites -> Processes -> Reaction -> Blending -> Quality -> Tank Storage -> Logistics -> Customer Orders.
Current System Context:
- 20 UK Industrial Sites (Runcorn, Grangemouth, Teesside, Hull, Stanlow, etc.)
- Runcorn: Chlor-Alkali, Chlorine, Caustic Soda, Hydrogen, Salt, HCL.
- Grangemouth: Ethane Cracker, HDPE, Polypropylene, Olefins.
- Active Batches: Batch B26-09142 (PVC-UK-042, 850t), Batch B26-09143 (Caustic Rayon Grade, 1200t).
Respond in a precise, quantitative, senior chemical engineering tone. Highlight key metrics, risk factors, and actionable operational decisions.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.3
      }
    });

    res.json({ answer: response.text });
  } catch (err: any) {
    console.error('Gemini API error:', err);
    res.status(500).json({ error: 'AI Intelligence query failed', details: err.message });
  }
});

// Vite middleware setup for Development
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve production static assets
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[INEOS CHEM.OS] Industrial Server active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
