import React from 'react';
import { NavigationTab } from '../types/chem_os';
import {
  Play,
  Factory,
  ShoppingBag,
  Sliders,
  AlertTriangle,
  GitCommit,
  ArrowRight
} from 'lucide-react';

interface SignatureDemosViewProps {
  onLaunchDemo: (tab: NavigationTab, demoId: number) => void;
}

export const SignatureDemosView: React.FC<SignatureDemosViewProps> = ({ onLaunchDemo }) => {
  const demos = [
    {
      id: 1,
      title: 'SIGNATURE DEMO 1 — RUNCORN CHLOR-ALKALI FLOW',
      subtitle: 'SALT → CHLOR-ALKALI → CHLORINE / CAUSTIC / H2 → DERIVATIVES → STORAGE',
      description: 'Inspect the complete integrated Chlor-Alkali flow at the Runcorn complex, including salt evaporation, electrolysis cellrooms, HCL burners, and pressurized chlorine storage.',
      targetTab: 'SITES' as NavigationTab,
      icon: Factory
    },
    {
      id: 2,
      title: 'SIGNATURE DEMO 2 — CUSTOMER ORDER TO CASH (5,000t PVC)',
      subtitle: 'ORDER → INVENTORY CHECK → CAMPAIGN ALLOCATION → QUALITY RELEASE → SHIPMENT',
      description: 'Trace Order ORD-2026-8812 for 850t Rigid PVC Compound from initial customer demand, through Batch B26-09142 quality release CoA, tank transfer, and road tanker dispatch to Birmingham.',
      targetTab: 'ORDERS' as NavigationTab,
      icon: ShoppingBag
    },
    {
      id: 3,
      title: 'SIGNATURE DEMO 3 — FORMULATION & BLENDING ENGINE',
      subtitle: 'TARGET GRADE X → LOT INVENTORY → 4-COMPONENT BLEND → MASS BALANCE CLOSURE',
      description: 'Calculate a 1,000t PVC-UK-042 formulation proposal across 4 components with strict mass balance validation (620t VCM, 240t Chlorine, 90t Ethanol, 50t Additive).',
      targetTab: 'BLENDING' as NavigationTab,
      icon: Sliders
    },
    {
      id: 4,
      title: 'SIGNATURE DEMO 4 — 25% RUNCORN PLANT OUTAGE PROPAGATION',
      subtitle: 'CAPACITY LOSS → SHORTFALL → INVENTORY DRAW → ORDER RISK → LOGISTICS RE-PLAN',
      description: 'Simulate a 25% capacity loss at Runcorn and propagate consequences across inventory draw, order risks, revenue impact, and automated AI mitigation recommendations.',
      targetTab: 'ORDERS' as NavigationTab,
      icon: AlertTriangle
    },
    {
      id: 5,
      title: 'SIGNATURE DEMO 5 — COMPLETE DIGITAL THREAD PROVENANCE',
      subtitle: 'CUSTOMER ← SHIPMENT ← TANK ← QUALITY ← BATCH ← PROCESS ← PLANT ← FEEDSTOCK LOT',
      description: 'Inspect the node-by-node digital history of Batch B26-09142, verifying backward provenance to Cheshire vacuum salt feedstock and forward provenance to customer delivery.',
      targetTab: 'DIGITAL_THREAD' as NavigationTab,
      icon: GitCommit
    }
  ];

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg">
        <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
          <span>INEOS CHEM.OS SIGNATURE DEMO SUITE</span>
          <span>·</span>
          <span>5 CORE INDUSTRIAL LIFECYCLE DEMONSTRATIONS</span>
        </div>
        <h1 className="text-2xl font-bold font-display text-white mt-1">
          Signature Industrial Demonstrations
        </h1>
        <p className="text-sm text-slate-400 mt-0.5">
          Select any signature demonstration scenario to launch the interactive simulation flow.
        </p>
      </div>

      {/* Demo Cards Grid */}
      <div className="space-y-4">
        {demos.map((demo) => {
          const Icon = demo.icon;
          return (
            <div
              key={demo.id}
              className="bg-slate-900 border border-slate-800 hover:border-amber-500/50 p-5 rounded-lg transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 group"
            >
              <div className="space-y-2 max-w-4xl">
                <div className="flex items-center gap-2">
                  <Icon className="w-5 h-5 text-amber-400 shrink-0" />
                  <span className="text-xs font-mono font-bold text-amber-400">{demo.title}</span>
                </div>

                <div className="text-xs font-mono text-slate-300 font-bold tracking-wide">
                  {demo.subtitle}
                </div>

                <p className="text-xs text-slate-400 font-sans leading-relaxed">
                  {demo.description}
                </p>
              </div>

              <button
                onClick={() => onLaunchDemo(demo.targetTab, demo.id)}
                className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold font-mono text-xs rounded transition-colors flex items-center gap-2 shrink-0 self-start md:self-center"
              >
                <Play className="w-4 h-4" />
                <span>Launch Demo {demo.id}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
