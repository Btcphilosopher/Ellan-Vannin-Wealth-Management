import React, { useState } from 'react';
import { Cpu, Send, Sparkles, AlertCircle, Bot, CheckCircle2 } from 'lucide-react';

export const ChemOsIntelligenceView: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const samplePrompts = [
    'Which chemical products currently have the greatest production constraints?',
    'What happens across the UK network if Runcorn Cellroom Line 1 loses 20% capacity?',
    'Which active inventory lots should be allocated to Order ORD-2026-8812 to minimize cost?',
    'Which production campaigns currently deliver the highest synthetic contribution margin?'
  ];

  const handleQuery = async (queryText: string) => {
    setIsLoading(true);
    setResponse(null);

    try {
      const res = await fetch('/api/ai/intelligence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: queryText, contextModule: 'EXECUTIVE_GRAPH' })
      });

      const data = await res.json();
      setResponse(data.answer || data.error || 'No analysis generated.');
    } catch (err: any) {
      setResponse(`Query execution failed: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>CHEM.OS INTELLIGENCE AI LAYER</span>
            <span>·</span>
            <span>GEMINI 3.8 SERVER SDK</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Restrained Industrial AI Assistant</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Operates directly on the internal synthetic data graph: Materials + Production + Quality + Inventory + Logistics + Orders.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs font-mono text-slate-300">
          <Cpu className="w-4 h-4 text-amber-400" />
          <span>MODEL: GEMINI-3.8-FLASH</span>
        </div>
      </div>

      {/* Suggested Quick Queries */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {samplePrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => {
              setPrompt(p);
              handleQuery(p);
            }}
            className="p-3.5 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 hover:border-amber-500/50 rounded text-left text-xs font-mono text-slate-200 transition-colors flex items-center justify-between group"
          >
            <span>"{p}"</span>
            <Sparkles className="w-3.5 h-3.5 text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity shrink-0 ml-2" />
          </button>
        ))}
      </div>

      {/* Custom Prompt Input Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (prompt.trim()) handleQuery(prompt);
          }}
          className="flex gap-3"
        >
          <input
            type="text"
            placeholder="Ask CHEM.OS Intelligence about plant capacity, order risks, or blending proposals..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-700 text-xs text-white p-3 rounded focus:outline-none focus:border-amber-400 font-mono"
          />

          <button
            type="submit"
            disabled={isLoading || !prompt.trim()}
            className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded text-xs font-mono transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Analyze</span>
          </button>
        </form>

        {/* AI Output Response Container */}
        {isLoading && (
          <div className="p-6 bg-slate-950 rounded border border-slate-800 text-center text-xs font-mono text-slate-400 flex items-center justify-center gap-3">
            <span className="w-3 h-3 rounded-full bg-amber-400 animate-ping" />
            <span>CHEM.OS Intelligence evaluating industrial graph and executing constraints analysis...</span>
          </div>
        )}

        {response && !isLoading && (
          <div className="p-5 bg-slate-950 border border-amber-500/30 rounded font-mono text-xs text-slate-200 space-y-3 whitespace-pre-wrap leading-relaxed">
            <div className="flex items-center gap-2 text-amber-400 font-bold border-b border-slate-800 pb-2">
              <Bot className="w-4 h-4" />
              <span>CHEM.OS INTELLIGENCE DIAGNOSTIC REPORT</span>
            </div>

            <div>{response}</div>
          </div>
        )}
      </div>
    </div>
  );
};
