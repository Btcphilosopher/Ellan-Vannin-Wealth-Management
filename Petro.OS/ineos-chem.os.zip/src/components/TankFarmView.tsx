import React, { useState } from 'react';
import { Tank } from '../types/chem_os';
import {
  Database,
  Thermometer,
  Gauge,
  ArrowRightLeft,
  CheckCircle2,
  AlertTriangle,
  Play
} from 'lucide-react';

interface TankFarmViewProps {
  tanks: Tank[];
}

export const TankFarmView: React.FC<TankFarmViewProps> = ({ tanks }) => {
  const [selectedTankId, setSelectedTankId] = useState<string>('TANK-RUN-T204');
  const [transferAmount, setTransferAmount] = useState<number>(200);

  const currentTank = tanks.find((t) => t.id === selectedTankId) || tanks[0];

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>TANK FARM & BULK STORAGE DIGITAL TWIN</span>
            <span>·</span>
            <span>PIPELINE NETWORK</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Tank Farm Visualizer & Fluid Transfer</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Real-time vertical tank level monitoring, thermal/pressure instrumentation, and pipeline transfer control.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs font-mono text-slate-300">
          <Database className="w-4 h-4 text-amber-400" />
          <span>ACTIVE TANKS: {tanks.length} IN SERVICE</span>
        </div>
      </div>

      {/* Main Grid: Vertical Tank Cards Visualizer & Detail Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Tanks Grid (Vertical Level Visualizer) */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="pb-3 border-b border-slate-800 mb-4 flex items-center justify-between">
            <h2 className="text-sm font-bold font-display text-white">
              Storage Tank Inventory Array ({tanks.length})
            </h2>
            <span className="text-xs font-mono text-slate-500">CLICK TANK TO INSPECT TELEMETRY</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 max-h-[550px] overflow-y-auto pr-1">
            {tanks.map((tank) => {
              const isSelected = tank.id === selectedTankId;
              return (
                <div
                  key={tank.id}
                  onClick={() => setSelectedTankId(tank.id)}
                  className={`p-3.5 rounded border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-400 text-white shadow-sm'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between text-xs font-mono mb-1">
                      <span className="font-bold text-amber-400">{tank.tankCode}</span>
                      <span className="text-[10px] text-slate-400">{tank.fillPercentage}%</span>
                    </div>

                    <div className="text-xs font-semibold text-white font-display truncate">{tank.materialName}</div>
                  </div>

                  {/* Vertical Level Graphic */}
                  <div className="my-3 h-28 bg-slate-900 border border-slate-800 rounded relative overflow-hidden flex flex-col justify-end">
                    <div
                      style={{ height: `${tank.fillPercentage}%` }}
                      className={`w-full transition-all duration-500 ${
                        tank.fillPercentage > 85 ? 'bg-amber-500' : 'bg-sky-500'
                      }`}
                    />
                    <div className="absolute inset-0 flex items-center justify-center text-[10px] font-mono text-white font-bold drop-shadow">
                      {tank.currentLevelTons.toLocaleString()}t
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1 border-t border-slate-800">
                    <span>{tank.temperatureCelsius}°C</span>
                    <span className="text-emerald-400 font-bold">{tank.qualityStatus}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Tank Inspector & Pipeline Transfer Control */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-5">
          <div className="pb-3 border-b border-slate-800">
            <div className="text-xs font-mono text-amber-400 font-bold">TANK TELEMETRY & CONTROL</div>
            <h2 className="text-xl font-bold font-display text-white mt-1">{currentTank.tankCode}</h2>
            <div className="text-xs font-mono text-slate-400 mt-0.5">{currentTank.materialName}</div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs font-mono">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500">CURRENT MASS</div>
              <div className="text-base font-bold text-white mt-0.5 tabular-nums">{currentTank.currentLevelTons.toLocaleString()} t</div>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500">CAPACITY</div>
              <div className="text-base font-bold text-white mt-0.5 tabular-nums">{currentTank.capacityTons.toLocaleString()} t</div>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500 flex items-center gap-1">
                <Thermometer className="w-3.5 h-3.5 text-amber-400" /> TEMP
              </div>
              <div className="text-base font-bold text-white mt-0.5 tabular-nums">{currentTank.temperatureCelsius} °C</div>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500 flex items-center gap-1">
                <Gauge className="w-3.5 h-3.5 text-sky-400" /> PRESSURE
              </div>
              <div className="text-base font-bold text-white mt-0.5 tabular-nums">{currentTank.pressureBar} bar</div>
            </div>
          </div>

          {/* Transfer Event Simulation Box */}
          <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <ArrowRightLeft className="w-4 h-4" />
              <span>Pipeline Transfer Simulator</span>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Transfer Tonnage (tonnes):</label>
              <input
                type="number"
                value={transferAmount}
                onChange={(e) => setTransferAmount(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 text-white p-2 rounded focus:outline-none focus:border-amber-400"
              />
            </div>

            <button
              onClick={() => {
                alert(`Simulated transfer of ${transferAmount} tonnes from ${currentTank.tankCode} to Teesside Terminal Pipeline Node executed.`);
              }}
              className="w-full py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded transition-colors flex items-center justify-center gap-2"
            >
              <Play className="w-3.5 h-3.5" /> Execute Pipeline Transfer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
