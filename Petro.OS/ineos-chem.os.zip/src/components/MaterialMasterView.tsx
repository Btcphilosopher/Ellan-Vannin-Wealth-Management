import React, { useState } from 'react';
import { ChemicalMaterial, ChemicalGrade } from '../types/chem_os';
import {
  Search,
  Filter,
  FlaskConical,
  Award,
  ShieldAlert,
  ArrowUpDown,
  SlidersHorizontal,
  CheckCircle2
} from 'lucide-react';

interface MaterialMasterViewProps {
  materials: ChemicalMaterial[];
  grades: ChemicalGrade[];
}

export const MaterialMasterView: React.FC<MaterialMasterViewProps> = ({
  materials,
  grades
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFamily, setSelectedFamily] = useState<string>('ALL');
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>('MAT-PVC-RIGID');

  const filteredMaterials = materials.filter((m) => {
    const matchesQuery =
      m.chemicalName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.commonName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.code.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFamily = selectedFamily === 'ALL' || m.family === selectedFamily;
    return matchesQuery && matchesFamily;
  });

  const currentMaterial = materials.find((m) => m.id === selectedMaterialId) || materials[0];
  const materialGrades = grades.filter((g) => g.materialId === currentMaterial.id);

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Headline Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
            <span>MATERIAL & GRADE MASTER SYSTEM</span>
            <span>·</span>
            <span>SPECIFICATION ENGINE</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Chemical Material Database & Grade Explorer</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Full physical, chemical, hazard, storage, and quality specification parameters across all manufactured product lines.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search material or CAS..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-xs text-white pl-9 pr-3 py-2 rounded focus:outline-none focus:border-amber-400 font-mono w-56"
            />
          </div>

          <select
            value={selectedFamily}
            onChange={(e) => setSelectedFamily(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-xs font-mono text-white px-3 py-2 rounded focus:outline-none focus:border-amber-400"
          >
            <option value="ALL">All Families</option>
            <option value="BASE_CHEMICALS">Base Chemicals</option>
            <option value="SOLVENTS">Solvents</option>
            <option value="INTERMEDIATES">Intermediates</option>
            <option value="POLYMERS">Polymers</option>
          </select>
        </div>
      </div>

      {/* Main Grid: Materials Table & Grade Spec Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Materials Table */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="pb-3 border-b border-slate-800 mb-3 flex items-center justify-between">
            <h2 className="text-sm font-bold font-display text-white">
              Master Chemical Catalog ({filteredMaterials.length})
            </h2>
            <span className="text-xs font-mono text-slate-500">INEOS SPECIFICATION COMPLIANT</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-2.5">Code / Name</th>
                  <th className="p-2.5">Family</th>
                  <th className="p-2.5">State</th>
                  <th className="p-2.5">Target Purity</th>
                  <th className="p-2.5">Inventory</th>
                  <th className="p-2.5">Cost / Tonne</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredMaterials.map((mat) => {
                  const isSelected = mat.id === selectedMaterialId;
                  return (
                    <tr
                      key={mat.id}
                      onClick={() => setSelectedMaterialId(mat.id)}
                      className={`hover:bg-slate-800/50 cursor-pointer transition-colors ${
                        isSelected ? 'bg-amber-500/10 text-white font-semibold' : 'text-slate-300'
                      }`}
                    >
                      <td className="p-2.5">
                        <div className="font-bold text-amber-400">{mat.code}</div>
                        <div className="text-[11px] text-slate-400">{mat.commonName}</div>
                      </td>
                      <td className="p-2.5">
                        <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] text-slate-300">
                          {mat.family}
                        </span>
                      </td>
                      <td className="p-2.5 text-slate-400">{mat.physicalState}</td>
                      <td className="p-2.5 font-bold tabular-nums text-emerald-400">{mat.purityPercentTarget}%</td>
                      <td className="p-2.5 tabular-nums text-slate-200">{mat.currentInventoryTons.toLocaleString()} t</td>
                      <td className="p-2.5 tabular-nums font-bold text-slate-100">£{mat.costPerTonneGBP}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Selected Material & Grade Inspector */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-5">
          <div className="pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
              <FlaskConical className="w-4 h-4" />
              <span>MATERIAL SPECIFICATION DATASHEET</span>
            </div>
            <h2 className="text-xl font-bold font-display text-white mt-1">
              {currentMaterial.chemicalName}
            </h2>
            <div className="text-xs font-mono text-slate-400 mt-0.5">CAS NO: {currentMaterial.casNumber}</div>
          </div>

          {/* Physical Parameters Table */}
          <div className="grid grid-cols-2 gap-3 text-xs font-mono">
            <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500">DENSITY</div>
              <div className="text-sm font-bold text-white mt-0.5 tabular-nums">{currentMaterial.densityGcm3} g/cm³</div>
            </div>
            <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500">VISCOSITY</div>
              <div className="text-sm font-bold text-white mt-0.5 tabular-nums">{currentMaterial.viscosityCp} cP</div>
            </div>
            <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500">BOILING POINT</div>
              <div className="text-sm font-bold text-white mt-0.5 tabular-nums">{currentMaterial.boilingPointC} °C</div>
            </div>
            <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500">HAZARD CLASS</div>
              <div className="text-xs font-bold text-amber-400 mt-1 truncate">{currentMaterial.hazardClass}</div>
            </div>
          </div>

          {/* Storage & Packaging */}
          <div className="bg-slate-950/70 p-3.5 rounded border border-slate-800 space-y-2 text-xs font-mono">
            <div className="text-slate-400">STORAGE REQUIREMENTS:</div>
            <div className="text-slate-200">{currentMaterial.storageRequirements}</div>
            <div className="text-slate-400 pt-1">DEFAULT PACKAGING:</div>
            <div className="text-slate-200">{currentMaterial.defaultPackaging}</div>
          </div>

          {/* Associated Product Grades */}
          <div>
            <div className="text-xs font-mono text-slate-400 uppercase mb-2 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>Commercial Grades ({materialGrades.length})</span>
            </div>

            {materialGrades.map((grade) => (
              <div key={grade.id} className="p-3 bg-slate-950 border border-slate-800 rounded space-y-2 text-xs font-mono">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-400 text-sm">{grade.gradeCode}</span>
                  <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded text-[10px]">
                    {grade.qualityStatus}
                  </span>
                </div>
                <div className="text-slate-200 font-sans font-semibold">{grade.gradeName}</div>
                <div className="text-slate-400">Application: {grade.application}</div>

                <div className="pt-2 border-t border-slate-800/80 grid grid-cols-3 gap-2 text-[11px] text-slate-300">
                  <div>Min: {grade.minPurityPercent}%</div>
                  <div>Target: {grade.targetPurityPercent}%</div>
                  <div>Max: {grade.maxPurityPercent}%</div>
                </div>
              </div>
            ))}

            {materialGrades.length === 0 && (
              <div className="text-xs font-mono text-slate-500 italic p-3 border border-dashed border-slate-800 rounded text-center">
                Standard technical grade specification applies.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
