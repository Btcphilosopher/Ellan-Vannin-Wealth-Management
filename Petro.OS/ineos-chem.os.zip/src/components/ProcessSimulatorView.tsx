import React, { useState } from 'react';
import { ProcessSimulatorState } from '../types/chem_os';
import { Scale, RefreshCw, AlertTriangle, CheckCircle2, ArrowRight } from 'lucide-react';

export const ProcessSimulatorView: React.FC = () => {
  const [feedRate, setFeedRate] = useState<number>(1000);
  const [catalystAge, setCatalystAge] = useState<number>(25);

  // Simplified chemical engineering mass balance calculation
  const productOutput = Math.round(feedRate * (0.925 - catalystAge * 0.0005));
  const byproductOutput = Math.round(feedRate * 0.042);
  const processLosses = Math.round(feedRate * 0.018);
  const unaccountedDelta = feedRate - (productOutput + byproductOutput + processLosses);

  const isClosed = Math.abs(unaccountedDelta) <= 15;

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>PROCESS SIMULATOR & MASS BALANCE ENGINE</span>
            <span>·</span>
            <span>CHEMICAL CONVERSION LOOP</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Generic Process Simulator & Mass Balance</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Models feed transformation, catalyst decay, heat exchanger energy duty, and validates mass balance closure.
          </p>
        </div>

        <div className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-mono font-bold border ${
          isClosed ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
        }`}>
          <Scale className="w-4 h-4" />
          <span>MASS BALANCE: {isClosed ? 'CLOSED (WITHIN TOLERANCE)' : 'EXCEPTION DETECTED'}</span>
        </div>
      </div>

      {/* Simulator Inputs & Mass Balance Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-5 font-mono text-xs">
          <div className="pb-3 border-b border-slate-800">
            <h2 className="text-sm font-bold text-white">Process Operating Variables</h2>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-slate-300">
              <span>Feedstock Feed Rate:</span>
              <span className="text-amber-400 font-bold tabular-nums">{feedRate} tonnes/hr</span>
            </div>
            <input
              type="range"
              min="100"
              max="2000"
              step="50"
              value={feedRate}
              onChange={(e) => setFeedRate(Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-slate-300">
              <span>Catalyst Age / Degradation:</span>
              <span className="text-amber-400 font-bold tabular-nums">{catalystAge}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={catalystAge}
              onChange={(e) => setCatalystAge(Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>
        </div>

        {/* Mass Balance Ledger Results */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4 font-mono text-xs">
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
            <h2 className="text-sm font-bold text-white">Mass Balance Closure Ledger</h2>
            <span className="text-slate-500">TOLERANCE ±15t</span>
          </div>

          <div className="space-y-2 text-slate-200">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded flex items-center justify-between">
              <span>+ INPUT FEEDSTOCK MASS:</span>
              <span className="font-bold text-sky-400 tabular-nums">{feedRate.toLocaleString()} t</span>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded flex items-center justify-between">
              <span>- MAIN CHEMICAL PRODUCT YIELD:</span>
              <span className="font-bold text-emerald-400 tabular-nums">{productOutput.toLocaleString()} t</span>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded flex items-center justify-between">
              <span>- RECOVERED BYPRODUCT MASS:</span>
              <span className="font-bold text-slate-300 tabular-nums">{byproductOutput.toLocaleString()} t</span>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded flex items-center justify-between">
              <span>- KNOWN PROCESS LOSSES:</span>
              <span className="font-bold text-amber-400 tabular-nums">{processLosses.toLocaleString()} t</span>
            </div>

            <div className="p-3 bg-slate-950 border border-amber-500/40 rounded flex items-center justify-between font-bold">
              <span>= UNACCOUNTED DELTA (BALANCE DELTA):</span>
              <span className="text-amber-400 tabular-nums">{unaccountedDelta.toLocaleString()} t</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
