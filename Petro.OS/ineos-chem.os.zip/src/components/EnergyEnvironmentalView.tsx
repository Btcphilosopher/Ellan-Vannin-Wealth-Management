import React from 'react';
import { EnvironmentalRecord } from '../types/chem_os';
import { Zap, Leaf, Droplets, Recycle } from 'lucide-react';

export const EnergyEnvironmentalView: React.FC = () => {
  const records: EnvironmentalRecord[] = [
    { id: 'ENV-RUN', siteId: 'SITE-RUNCORN', siteName: 'INEOS Runcorn Complex', period: '2026-Q3', electricityMWh: 142000, naturalGasMWh: 38000, steamTons: 62000, hydrogenFuelTons: 4100, totalEnergyMWh: 180000, co2eTonsTotal: 39500, co2eKgPerTonneProduct: 312, waterUsageM3: 410000, wasteRecycledPercent: 94.2 },
    { id: 'ENV-GRA', siteId: 'SITE-GRANGEMOUTH', siteName: 'INEOS Grangemouth Complex', period: '2026-Q3', electricityMWh: 210000, naturalGasMWh: 115000, steamTons: 140000, hydrogenFuelTons: 6800, totalEnergyMWh: 325000, co2eTonsTotal: 78000, co2eKgPerTonneProduct: 485, waterUsageM3: 890000, wasteRecycledPercent: 91.8 },
    { id: 'ENV-TEE', siteId: 'SITE-TEESSIDE', siteName: 'INEOS Teesside Terminal', period: '2026-Q3', electricityMWh: 54000, naturalGasMWh: 18000, steamTons: 28000, hydrogenFuelTons: 1200, totalEnergyMWh: 72000, co2eTonsTotal: 18200, co2eKgPerTonneProduct: 280, waterUsageM3: 210000, wasteRecycledPercent: 96.0 }
  ];

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto font-mono text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4 font-sans">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>ENERGY & CARBON ENVIRONMENTAL LEDGER</span>
            <span>·</span>
            <span>PROVENANCE VERIFIED</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Industrial Energy & CO₂e Environmental Ledger</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Tracks electricity, gas, steam, hydrogen fuel displacement, water usage, and CO₂e intensity per tonne of product.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs font-mono text-emerald-400 font-bold">
          <Leaf className="w-4 h-4 text-emerald-400" />
          <span>AVERAGE CO₂e: 312 kg / TONNE</span>
        </div>
      </div>

      {/* Environmental Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-white font-sans">Site Environmental & Energy Records (Q3 2026)</h2>
          <span className="text-slate-500">ISO 14001 MODEL COMPLIANT</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-2.5">Site Name</th>
                <th className="p-2.5">Electricity</th>
                <th className="p-2.5">Natural Gas</th>
                <th className="p-2.5">H₂ Fuel Displaced</th>
                <th className="p-2.5">Total Energy</th>
                <th className="p-2.5">CO₂e Total</th>
                <th className="p-2.5">CO₂e / Tonne</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {records.map((r) => (
                <tr key={r.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-2.5 font-bold text-white">{r.siteName}</td>
                  <td className="p-2.5 tabular-nums">{r.electricityMWh.toLocaleString()} MWh</td>
                  <td className="p-2.5 tabular-nums">{r.naturalGasMWh.toLocaleString()} MWh</td>
                  <td className="p-2.5 tabular-nums text-emerald-400 font-bold">{r.hydrogenFuelTons.toLocaleString()} t</td>
                  <td className="p-2.5 tabular-nums text-amber-400 font-bold">{r.totalEnergyMWh.toLocaleString()} MWh</td>
                  <td className="p-2.5 tabular-nums">{r.co2eTonsTotal.toLocaleString()} t</td>
                  <td className="p-2.5 tabular-nums text-emerald-400 font-bold">{r.co2eKgPerTonneProduct} kg/t</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
