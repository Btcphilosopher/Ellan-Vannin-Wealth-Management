import React, { useState } from 'react';
import { Site, Batch } from '../types/chem_os';
import {
  Factory,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Zap,
  Leaf,
  DollarSign,
  Boxes,
  Truck,
  ArrowRight,
  Filter,
  Layers
} from 'lucide-react';

interface OverviewViewProps {
  sites: Site[];
  batches: Batch[];
  onSelectSite: (siteId: string) => void;
  onSelectBatch: (batchId: string) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  sites,
  batches,
  onSelectSite,
  onSelectBatch
}) => {
  const [selectedRegion, setSelectedRegion] = useState<string>('ALL');
  const [selectedSiteId, setSelectedSiteId] = useState<string | null>('SITE-RUNCORN');

  const totalCapacity = sites.reduce((sum, s) => sum + s.capacityTonsPerYear, 0);
  const avgUtilization = (
    sites.reduce((sum, s) => sum + s.currentUtilizationPercent, 0) / sites.length
  ).toFixed(1);

  const activeBatchesCount = batches.filter((b) => b.status !== 'RELEASED' && b.status !== 'REJECTED').length;
  const qualityHoldsCount = batches.filter((b) => b.status === 'QUALITY_HOLD' || b.qualityReleaseStatus === 'CONDITIONAL').length;

  const currentSite = sites.find((s) => s.id === selectedSiteId) || sites[0];

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Executive Headline Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-5 rounded-lg shadow-sm">
        <div>
          <div className="flex items-center gap-2 text-xs text-amber-400 font-mono font-semibold uppercase tracking-wider mb-1">
            <span>INEOS GROUP EXECUTIVE NETWORK BOARD</span>
            <span>·</span>
            <span>UK INDUSTRIAL GRAPH</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white tracking-tight">
            UK Chemical Manufacturing & Logistics Network
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-3xl">
            Vertically integrated continuous graph: Salt & Ethane Feedstocks → Chlor-Alkali & Cracker Sites → Intermediates & Polymers → Quality Release → Bulk Logistics.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right font-mono">
            <div className="text-xs text-slate-500 uppercase">System Status</div>
            <div className="text-sm font-bold text-emerald-400 flex items-center gap-1.5 justify-end">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              OPTIMAL OPERATIONAL FLOW
            </div>
          </div>
        </div>
      </div>

      {/* Top Level Industrial KPIs Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-1">
            <span>TOTAL CAPACITY</span>
            <Factory className="w-3.5 h-3.5 text-slate-500" />
          </div>
          <div className="text-lg font-bold font-mono text-white tabular-nums">
            {(totalCapacity / 1000000).toFixed(2)}M <span className="text-xs text-slate-400 font-normal">t/yr</span>
          </div>
          <div className="text-[11px] text-emerald-400 font-mono mt-1">20 Integrated UK Sites</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-1">
            <span>PLANT UTILISATION</span>
            <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-lg font-bold font-mono text-amber-400 tabular-nums">
            {avgUtilization}%
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">Target: &gt;90.0%</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-1">
            <span>ACTIVE BATCHES</span>
            <Boxes className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div className="text-lg font-bold font-mono text-white tabular-nums">
            {batches.length} <span className="text-xs text-slate-400 font-normal">in campaign</span>
          </div>
          <div className="text-[11px] text-sky-400 font-mono mt-1">{activeBatchesCount} live processing</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-1">
            <span>QUALITY HOLDS</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="text-lg font-bold font-mono text-amber-400 tabular-nums">
            {qualityHoldsCount} <span className="text-xs text-slate-400 font-normal">batches</span>
          </div>
          <div className="text-[11px] text-amber-500/90 font-mono mt-1">Under Q-Lab Review</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-1">
            <span>ENERGY / TONNE</span>
            <Zap className="w-3.5 h-3.5 text-yellow-400" />
          </div>
          <div className="text-lg font-bold font-mono text-white tabular-nums">
            1.42 <span className="text-xs text-slate-400 font-normal">MWh/t</span>
          </div>
          <div className="text-[11px] text-emerald-400 font-mono mt-1">-3.4% vs 2025 baseline</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-1">
            <span>CO₂e INTENSITY</span>
            <Leaf className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
            312 <span className="text-xs text-slate-400 font-normal">kg/t</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-1">Hydrogen fuel displaced</div>
        </div>
      </div>

      {/* Main Split View: Synthetic UK Network Visualizer & Drill-Down Hierarchy */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* UK Network Sites Map List */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div>
                <h2 className="text-base font-bold font-display text-white">
                  UK Industrial Manufacturing Sites
                </h2>
                <p className="text-xs text-slate-400">Integrated Chlor-Alkali, Petrochemical, Intermediates & Pipeline Nodes</p>
              </div>

              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="text-slate-500">Filter:</span>
                <button
                  onClick={() => setSelectedRegion('ALL')}
                  className={`px-2 py-0.5 rounded ${selectedRegion === 'ALL' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'}`}
                >
                  ALL UK
                </button>
              </div>
            </div>

            {/* Sites Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[520px] overflow-y-auto pr-1">
              {sites.slice(0, 8).map((site) => {
                const isSelected = site.id === selectedSiteId;
                return (
                  <div
                    key={site.id}
                    onClick={() => {
                      setSelectedSiteId(site.id);
                      onSelectSite(site.id);
                    }}
                    className={`p-3.5 rounded border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/10 border-amber-500/50 text-white shadow-sm'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-mono font-bold text-amber-400">{site.locationCode}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-400">
                        {site.currentUtilizationPercent}% Utilized
                      </span>
                    </div>

                    <div className="text-sm font-semibold text-white truncate font-display">{site.name}</div>
                    <div className="text-xs text-slate-400 mt-1">{site.region}</div>

                    <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
                      <span>{(site.capacityTonsPerYear / 1000).toFixed(0)}k t/yr</span>
                      <span className="text-slate-500">{site.activeCampaignsCount} campaigns</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Showing primary integrated sites. Additional 12 UK terminals & depots active.</span>
            <button 
              onClick={() => onSelectSite('SITE-RUNCORN')}
              className="text-amber-400 hover:underline flex items-center gap-1 font-semibold"
            >
              Open Site Digital Twin <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Drill-Down Hierarchy Panel */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="pb-3 border-b border-slate-800 mb-4">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400 uppercase">
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              <span>Hierarchical Drill-Down Inspector</span>
            </div>
            <h2 className="text-base font-bold font-display text-white mt-0.5">
              {currentSite.name}
            </h2>
          </div>

          {/* Breadcrumb Hierarchy */}
          <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400 bg-slate-950 p-2.5 rounded border border-slate-800 mb-4 overflow-x-auto">
            <span className="text-slate-500">GROUP</span>
            <span>/</span>
            <span className="text-slate-300">UK REGION</span>
            <span>/</span>
            <span className="text-amber-400 font-bold">{currentSite.locationCode}</span>
          </div>

          {/* Site Detail Breakdown */}
          <div className="space-y-4">
            <div className="bg-slate-950/60 p-3.5 rounded border border-slate-800/80 space-y-2">
              <div className="text-xs font-mono text-slate-400 uppercase">Primary Chemical Outputs:</div>
              <div className="flex flex-wrap gap-1.5">
                {currentSite.primaryOutputs.map((output, idx) => (
                  <span key={idx} className="text-xs bg-slate-900 border border-slate-800 text-slate-200 px-2 py-0.5 rounded font-mono">
                    {output}
                  </span>
                ))}
              </div>
            </div>

            {/* Process Areas & Units */}
            <div>
              <div className="text-xs font-mono text-slate-400 uppercase mb-2">Active Process Units ({currentSite.processAreas.reduce((sum, a) => sum + a.units.length, 0)}):</div>
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {currentSite.processAreas.flatMap((area) => area.units).map((unit) => (
                  <div key={unit.id} className="p-2.5 bg-slate-950 border border-slate-800/80 rounded flex items-center justify-between text-xs">
                    <div>
                      <div className="font-mono font-bold text-slate-200">{unit.code} - {unit.name}</div>
                      <div className="text-[11px] text-slate-500 font-mono">Type: {unit.type} · Temp: {unit.temperatureCelsius}°C · Press: {unit.pressureBar} bar</div>
                    </div>
                    <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono text-[10px] rounded font-bold">
                      {unit.status}
                    </span>
                  </div>
                ))}

                {currentSite.processAreas.length === 0 && (
                  <div className="text-xs text-slate-500 font-mono italic p-3 text-center border border-dashed border-slate-800 rounded">
                    Storage & Logistics Terminal Node. No direct chemical synthesis units.
                  </div>
                )}
              </div>
            </div>

            {/* Active Batches at Site */}
            <div>
              <div className="text-xs font-mono text-slate-400 uppercase mb-2">Site Batches in Production:</div>
              <div className="space-y-1.5">
                {batches.filter((b) => b.siteId === currentSite.id).slice(0, 3).map((batch) => (
                  <div
                    key={batch.id}
                    onClick={() => onSelectBatch(batch.id)}
                    className="p-2 bg-slate-950 border border-slate-800 hover:border-amber-500/50 rounded flex items-center justify-between text-xs cursor-pointer"
                  >
                    <div className="font-mono text-amber-400 font-bold">{batch.batchNumber}</div>
                    <div className="text-slate-300 font-mono">{batch.quantityTons}t</div>
                    <span className="text-[10px] font-mono text-emerald-400 px-1.5 py-0.5 bg-emerald-950 rounded border border-emerald-800">
                      {batch.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
