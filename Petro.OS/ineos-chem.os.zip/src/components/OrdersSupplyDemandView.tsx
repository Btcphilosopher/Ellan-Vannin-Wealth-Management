import React, { useState } from 'react';
import { Order, ScenarioResult } from '../types/chem_os';
import { runScenarioSimulation } from '../services/syntheticData';
import {
  ShoppingBag,
  AlertTriangle,
  Play,
  TrendingDown,
  DollarSign,
  Truck,
  CheckCircle2,
  ShieldAlert
} from 'lucide-react';

interface OrdersSupplyDemandViewProps {
  orders: Order[];
}

export const OrdersSupplyDemandView: React.FC<OrdersSupplyDemandViewProps> = ({ orders }) => {
  const [outagePercent, setOutagePercent] = useState<number>(25);
  const [activeScenarioResult, setActiveScenarioResult] = useState<ScenarioResult | null>(null);

  const handleRunSimulation = () => {
    const result = runScenarioSimulation('SITE-RUNCORN', outagePercent);
    setActiveScenarioResult(result);
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>ORDER-TO-CASH & SUPPLY-DEMAND SCENARIO ENGINE</span>
            <span>·</span>
            <span>FAILURE SIMULATION LAB</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Order Pipeline & Scenario Propagation Lab</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Connects customer orders directly to plant capacity and simulates industrial failure cascades across the value chain.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs font-mono text-slate-300">
          <ShoppingBag className="w-4 h-4 text-amber-400" />
          <span>LIVE ORDERS: {orders.length}</span>
        </div>
      </div>

      {/* Main Grid: Orders Table & Scenario Lab */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Orders Board */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="pb-3 border-b border-slate-800 mb-4 flex items-center justify-between">
            <h2 className="text-sm font-bold font-display text-white">
              Customer Orders & Promise Dates
            </h2>
            <span className="text-xs font-mono text-slate-500">FULFILLMENT MATCHED</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-2.5">Order / Customer</th>
                  <th className="p-2.5">Grade</th>
                  <th className="p-2.5">Quantity</th>
                  <th className="p-2.5">Total Value</th>
                  <th className="p-2.5">Type</th>
                  <th className="p-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {orders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-800/40 transition-colors text-slate-300">
                    <td className="p-2.5">
                      <div className="font-bold text-amber-400">{ord.orderNumber}</div>
                      <div className="text-[11px] text-slate-300 font-sans font-medium">{ord.customerName}</div>
                    </td>
                    <td className="p-2.5 font-bold text-white">{ord.gradeCode}</td>
                    <td className="p-2.5 font-bold tabular-nums text-amber-400">{ord.quantityTons.toLocaleString()} t</td>
                    <td className="p-2.5 font-bold tabular-nums text-slate-100">£{ord.totalValueGBP.toLocaleString()}</td>
                    <td className="p-2.5">
                      <span className="px-2 py-0.5 bg-slate-950 border border-slate-800 text-[10px] text-slate-300 rounded font-bold">
                        {ord.fulfillmentType}
                      </span>
                    </td>
                    <td className="p-2.5">
                      <span className="px-2.5 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-bold">
                        {ord.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Failure Simulation Lab */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-5">
          <div className="pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono text-amber-400 font-bold">
              <AlertTriangle className="w-4 h-4" />
              <span>FAILURE SIMULATION LABORATORY</span>
            </div>
            <h2 className="text-lg font-bold font-display text-white mt-0.5">
              Runcorn Site Outage Stress Test
            </h2>
            <p className="text-xs text-slate-400">Propagate supply shortfall through inventory buffers to customer deliveries.</p>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between text-slate-300">
              <span>Site Capacity Reduction:</span>
              <span className="text-amber-400 font-bold">{outagePercent}% Loss</span>
            </div>

            <input
              type="range"
              min="5"
              max="50"
              step="5"
              value={outagePercent}
              onChange={(e) => setOutagePercent(Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />

            <button
              onClick={handleRunSimulation}
              className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded transition-colors flex items-center justify-center gap-2 text-xs"
            >
              <Play className="w-4 h-4" /> Run Scenario Propagation Simulation
            </button>
          </div>

          {/* Results Output */}
          {activeScenarioResult && (
            <div className="bg-slate-950 p-4 rounded border border-amber-500/40 space-y-3 font-mono text-xs">
              <div className="text-amber-400 font-bold uppercase flex items-center justify-between">
                <span>SIMULATION RESULTS OUTPUT</span>
                <span className="text-emerald-400">CONSEQUENCES CALCULATED</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="p-2 bg-slate-900 border border-slate-800 rounded">
                  <div className="text-slate-500">CAPACITY LOSS</div>
                  <div className="text-sm font-bold text-amber-400 tabular-nums">{activeScenarioResult.capacityLossTons.toLocaleString()} t</div>
                </div>
                <div className="p-2 bg-slate-900 border border-slate-800 rounded">
                  <div className="text-slate-500">SHORTFALL</div>
                  <div className="text-sm font-bold text-white tabular-nums">{activeScenarioResult.productionShortfallTons.toLocaleString()} t</div>
                </div>
                <div className="p-2 bg-slate-900 border border-slate-800 rounded">
                  <div className="text-slate-500">ORDERS AT RISK</div>
                  <div className="text-sm font-bold text-red-400 tabular-nums">{activeScenarioResult.ordersAtRiskCount} orders</div>
                </div>
                <div className="p-2 bg-slate-900 border border-slate-800 rounded">
                  <div className="text-slate-500">REVENUE AT RISK</div>
                  <div className="text-sm font-bold text-white tabular-nums">£{(activeScenarioResult.revenueRiskGBP / 1000).toFixed(0)}k</div>
                </div>
              </div>

              <div className="p-3 bg-slate-900 border border-slate-800 rounded text-[11px] space-y-1">
                <div className="text-amber-400 font-bold">CHEM.OS MITIGATION RECOMMENDATION:</div>
                <div className="text-slate-300 font-sans leading-relaxed">{activeScenarioResult.mitigationRecommendation}</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
