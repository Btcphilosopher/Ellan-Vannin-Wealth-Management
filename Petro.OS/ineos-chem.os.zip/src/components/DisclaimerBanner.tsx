import React from 'react';
import { AlertTriangle, Info } from 'lucide-react';

export const DisclaimerBanner: React.FC = () => {
  return (
    <div className="bg-slate-900 border-b border-amber-500/20 px-4 py-1.5 text-xs text-slate-300 flex items-center justify-between gap-3">
      <div className="flex items-center gap-2 max-w-[1700px] mx-auto w-full">
        <Info className="w-3.5 h-3.5 text-amber-400 shrink-0" />
        <span className="font-mono text-[11px] text-slate-300">
          <strong className="text-amber-400 font-bold">SYNTHETIC SIMULATION ENVIRONMENT:</strong> This platform is a synthetic operating system & decision support prototype for chemical manufacturing, blending, quality, and logistics. All data, telemetry, and calculations are deterministic simulation models.
        </span>
      </div>
    </div>
  );
};
