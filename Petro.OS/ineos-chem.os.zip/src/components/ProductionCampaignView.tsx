import React from 'react';
import { ProductionCampaign } from '../types/chem_os';
import { Clock, CheckCircle2, Play, Layers } from 'lucide-react';

export const ProductionCampaignView: React.FC = () => {
  const campaign: ProductionCampaign = {
    id: 'CAMP-26-091',
    campaignCode: 'CAMPAIGN 26-091',
    siteId: 'SITE-RUNCORN',
    unitId: 'UNIT-CA-01',
    materialId: 'MAT-PVC-RIGID',
    gradeId: 'GRADE-PVC-042',
    startDate: '2026-09-28T00:00:00Z',
    endDate: '2026-09-29T08:00:00Z',
    targetTonnage: 1200,
    actualYieldTons: 1180,
    expectedYieldTons: 1200,
    status: 'ACTIVE',
    feedstockRequiredTons: 1350,
    energyRequirementMWh: 1704,
    timelineSteps: [
      { stepNumber: 1, timeOffsetHours: 0, title: '00:00 FEEDSTOCK PREPARATION', description: 'Cheshire vacuum salt brine purification and electrochemical cellroom priming.', status: 'COMPLETED' },
      { stepNumber: 2, timeOffsetHours: 2, title: '02:00 PROCESS START', description: 'Electrolysis membrane power ramp to 28.4 MW. Chlorine gas header pressurized.', status: 'COMPLETED' },
      { stepNumber: 3, timeOffsetHours: 8, title: '08:00 STEADY PRODUCTION', description: 'Steady-state chlor-alkali synthesis. Throughput 48.5 t/h.', status: 'COMPLETED' },
      { stepNumber: 4, timeOffsetHours: 18, title: '18:00 QUALITY SAMPLE', description: 'Automated pneumatic sampler extracts Sample S-55120 for Q-Lab 1.', status: 'COMPLETED' },
      { stepNumber: 5, timeOffsetHours: 20, title: '20:00 QUALITY RELEASE', description: 'Purity 99.82% verified. Digital Certificate of Analysis CoA-8812 issued.', status: 'COMPLETED' },
      { stepNumber: 6, timeOffsetHours: 22, title: '22:00 TRANSFER', description: 'Pressurized pipeline transfer into refrigerated holding Tank T-204.', status: 'COMPLETED' },
      { stepNumber: 7, timeOffsetHours: 24, title: '24:00 BLENDING', description: 'Formulation blending with modifier additives per Recipe V4.2.', status: 'IN_PROGRESS' },
      { stepNumber: 8, timeOffsetHours: 28, title: '28:00 PACKAGING', description: 'Bulk silo truck and 1,000kg octabin automated bagging line.', status: 'PENDING' },
      { stepNumber: 9, timeOffsetHours: 32, title: '32:00 SHIPPING', description: 'Dispatch via TRUCK 7812 for Birmingham Distribution Hub delivery.', status: 'PENDING' }
    ]
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>PRODUCTION CAMPAIGN SCHEDULER & TIMELINE</span>
            <span>·</span>
            <span>RUNCORN COMPLEX</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">{campaign.campaignCode} · Rigid PVC Production</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Sequential campaign timeline tracking from initial feedstock preparation to final customer dispatch.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 rounded text-xs font-mono text-emerald-400 font-bold">
          <CheckCircle2 className="w-4 h-4" />
          <span>CAMPAIGN STATUS: ACTIVE (98.3% YIELD)</span>
        </div>
      </div>

      {/* Campaign Timeline Step Cards */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold font-display text-white">
            Campaign Timeline Sequence ({campaign.timelineSteps.length} Milestones)
          </h2>
          <span className="text-xs font-mono text-slate-500">SIMULATION TIMELINE</span>
        </div>

        <div className="space-y-3">
          {campaign.timelineSteps.map((step) => (
            <div
              key={step.stepNumber}
              className={`p-4 rounded border font-mono text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                step.status === 'COMPLETED'
                  ? 'bg-slate-950 border-slate-800 text-slate-200'
                  : step.status === 'IN_PROGRESS'
                  ? 'bg-amber-500/15 border-amber-400 text-white font-bold'
                  : 'bg-slate-950/50 border-slate-800/60 text-slate-500'
              }`}
            >
              <div className="space-y-1">
                <div className="text-amber-400 font-bold">{step.title}</div>
                <div className="text-slate-300 font-sans">{step.description}</div>
              </div>

              <span className={`px-2.5 py-1 rounded text-[10px] font-bold self-start sm:self-center shrink-0 ${
                step.status === 'COMPLETED'
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                  : step.status === 'IN_PROGRESS'
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-500 border border-slate-800'
              }`}>
                {step.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
