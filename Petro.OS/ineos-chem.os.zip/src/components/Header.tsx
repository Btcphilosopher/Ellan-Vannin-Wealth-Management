import React from 'react';
import { NavigationTab } from '../types/chem_os';
import { Activity, RefreshCw, Cpu, Server, ShieldCheck } from 'lucide-react';

interface HeaderProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  isLiveStreaming: boolean;
  onResetData: () => void;
  onOpenDemo: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  isLiveStreaming,
  onResetData,
  onOpenDemo
}) => {
  const primaryNavItems: { id: NavigationTab; label: string }[] = [
    { id: 'OVERVIEW', label: 'Overview' },
    { id: 'SITES', label: 'Sites & Twin' },
    { id: 'MATERIALS', label: 'Materials' },
    { id: 'CAMPAIGN', label: 'Campaigns' },
    { id: 'BLENDING', label: 'Blending' },
    { id: 'SIMULATOR', label: 'Simulator' },
    { id: 'QUALITY', label: 'Quality Lab' },
    { id: 'DIGITAL_THREAD', label: 'Digital Thread' },
    { id: 'TANKS', label: 'Tank Farm' },
    { id: 'LOGISTICS', label: 'Logistics' },
    { id: 'ORDERS', label: 'Orders' },
    { id: 'ENERGY', label: 'Energy & CO₂e' },
    { id: 'COST_MARKET', label: 'Economics' },
    { id: 'CONTROL_ROOM', label: 'Control Room' },
    { id: 'INTELLIGENCE', label: 'AI Intelligence' },
    { id: 'DEMOS', label: 'Signature Demos' },
    { id: 'EVENTS', label: 'Event Log' }
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50 text-slate-100 shadow-md">
      {/* Zone 1: Wordmark & Top Industrial Controls Bar */}
      <div className="max-w-[1700px] mx-auto px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Brand Zone - Single element wordmark */}
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setActiveTab('OVERVIEW')}
            className="flex items-center gap-2 text-[17px] font-bold tracking-tight text-white font-display focus:outline-none hover:text-amber-400 transition-colors"
          >
            <span className="bg-amber-500 text-slate-950 px-1.5 py-0.5 rounded text-xs font-mono font-black">INEOS</span>
            <span>CHEM.OS</span>
          </button>

          <span className="hidden sm:inline-block text-xs text-slate-500 font-mono">| UK INDUSTRIAL GRAPH</span>
        </div>

        {/* Zone 2: Navigation Tabs */}
        <nav className="hidden lg:flex items-center gap-1 overflow-x-auto py-0.5 scrollbar-none">
          {primaryNavItems.slice(0, 11).map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions & Status */}
        <div className="flex items-center gap-2">
          {/* Live Telemetry Indicator */}
          <div className="hidden sm:flex items-center gap-1.5 px-2 py-1 bg-slate-950/80 border border-slate-800 rounded text-[11px] font-mono text-slate-400">
            <span className={`w-2 h-2 rounded-full ${isLiveStreaming ? 'bg-emerald-400 animate-pulse' : 'bg-amber-500'}`} />
            <span>{isLiveStreaming ? 'SSE LIVE' : 'SIMULATION'}</span>
          </div>

          <button
            onClick={onOpenDemo}
            className="px-3 py-1 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap flex items-center gap-1.5 shadow-sm"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Signature Demos</span>
          </button>

          <button
            onClick={onResetData}
            title="Reset Simulation State"
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Secondary Sub-Navigation for Remaining Modules */}
      <div className="border-t border-slate-800/60 bg-slate-950/60 px-4 py-1 text-xs">
        <div className="max-w-[1700px] mx-auto flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-[11px] font-mono text-slate-500 uppercase tracking-wider shrink-0">Modules:</span>
          {primaryNavItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-2 py-0.5 text-[11px] font-mono rounded transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-amber-400 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
