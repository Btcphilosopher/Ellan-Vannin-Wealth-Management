import React, { useState } from 'react';
import { ChemicalGrade, BlendingProposal } from '../types/chem_os';
import { calculateBlendingProposal } from '../services/syntheticData';
import {
  Sliders,
  CheckCircle2,
  AlertTriangle,
  DollarSign,
  Scale,
  Layers,
  ArrowRight
} from 'lucide-react';

interface BlendingEngineViewProps {
  grades: ChemicalGrade[];
}

export const BlendingEngineView: React.FC<BlendingEngineViewProps> = ({ grades }) => {
  const [selectedGradeId, setSelectedGradeId] = useState<string>('GRADE-PVC-042');
  const [targetMass, setTargetMass] = useState<number>(1000);

  const proposal: BlendingProposal = calculateBlendingProposal(selectedGradeId, targetMass);

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>INEOS FORMULATION & BLENDING ENGINE</span>
            <span>·</span>
            <span>MASS BALANCE VALIDATION</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Chemical Blending & Formulation Calculator</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Calculates component ratios, checks lot inventory & material compatibility, and validates mass balance closure.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs font-mono text-slate-300">
          <Scale className="w-4 h-4 text-amber-400" />
          <span>MASS BALANCE CONSTRAINT: ACTIVE</span>
        </div>
      </div>

      {/* Main Grid: Controls & Proposal Result */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Blending Parameters Form */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-6">
          <div className="pb-3 border-b border-slate-800">
            <h2 className="text-base font-bold font-display text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>Formulation Parameters</span>
            </h2>
          </div>

          {/* Grade Selector */}
          <div className="space-y-2">
            <label className="text-xs font-mono text-slate-400 block uppercase">Target Chemical Grade:</label>
            <select
              value={selectedGradeId}
              onChange={(e) => setSelectedGradeId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-xs font-mono text-white p-2.5 rounded focus:outline-none focus:border-amber-400"
            >
              {grades.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.gradeCode} - {g.gradeName}
                </option>
              ))}
            </select>
          </div>

          {/* Mass Slider & Input */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400 uppercase">Target Tonnage Mass:</span>
              <span className="text-amber-400 font-bold text-sm tabular-nums">{targetMass.toLocaleString()} tonnes</span>
            </div>

            <input
              type="range"
              min="100"
              max="10000"
              step="50"
              value={targetMass}
              onChange={(e) => setTargetMass(Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />

            <div className="flex justify-between text-[11px] font-mono text-slate-500">
              <span>100 t</span>
              <span>5,000 t</span>
              <span>10,000 t</span>
            </div>
          </div>

          {/* Validation Summary Box */}
          <div className={`p-4 rounded border text-xs font-mono space-y-2 ${
            proposal.massBalanceValid
              ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
              : 'bg-amber-500/10 border-amber-500/40 text-amber-300'
          }`}>
            <div className="flex items-center justify-between font-bold">
              <span>MASS BALANCE VALIDATION</span>
              <span>{proposal.massBalanceValid ? 'CLOSED (100.0%)' : 'EXCEPTION'}</span>
            </div>
            <div className="text-[11px] text-slate-300">
              Target Mass: {targetMass.toLocaleString()}t | Sum Calculated: {proposal.totalCalculatedMassTons.toLocaleString()}t
            </div>
          </div>

          <div className="bg-slate-950 p-3.5 rounded border border-slate-800 space-y-2 text-xs font-mono">
            <div className="text-slate-400">ECONOMIC CONTRIBUTION:</div>
            <div className="text-lg font-bold text-white tabular-nums">
              £{proposal.totalCostGBP.toLocaleString()}
              <span className="text-xs font-normal text-slate-400 ml-2">(£{proposal.averageCostPerTonneGBP}/tonne)</span>
            </div>
          </div>
        </div>

        {/* Calculated Proposal & Component Breakdown Table */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-5">
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-mono text-amber-400 font-bold">FORMULATION PROPOSAL</div>
              <h2 className="text-lg font-bold font-display text-white mt-0.5">
                {proposal.targetGradeCode} · Blend Proposal
              </h2>
            </div>

            <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded text-xs font-mono font-bold">
              PROJECTED PURITY: {proposal.projectedPurityPercent}%
            </span>
          </div>

          {/* Component Ratios Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-2.5">Component / Lot</th>
                  <th className="p-2.5">Target %</th>
                  <th className="p-2.5">Proposed Mass</th>
                  <th className="p-2.5">Available Mass</th>
                  <th className="p-2.5">Cost Contribution</th>
                  <th className="p-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {proposal.components.map((c, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-2.5">
                      <div className="font-bold text-white">{c.materialName}</div>
                      <div className="text-[11px] text-amber-400">{c.lotId}</div>
                    </td>
                    <td className="p-2.5 font-bold tabular-nums text-slate-300">{c.targetPercentage}%</td>
                    <td className="p-2.5 font-bold tabular-nums text-amber-400">{c.proposedMassTons.toLocaleString()} t</td>
                    <td className="p-2.5 tabular-nums text-slate-400">{c.availableMassTons.toLocaleString()} t</td>
                    <td className="p-2.5 tabular-nums text-slate-200">£{(c.proposedMassTons * c.costPerTonneGBP).toLocaleString()}</td>
                    <td className="p-2.5">
                      <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded text-[10px] font-bold">
                        {c.qualityStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Total Bar Balance Visualizer */}
          <div className="space-y-1.5 pt-2">
            <div className="flex justify-between text-xs font-mono text-slate-400">
              <span>BLEND RATIO DISTRIBUTION</span>
              <span>TOTAL = 100%</span>
            </div>

            <div className="h-4 bg-slate-950 rounded overflow-hidden flex border border-slate-800">
              <div style={{ width: '62%' }} className="bg-amber-500 h-full" title="VCM 62%" />
              <div style={{ width: '24%' }} className="bg-sky-500 h-full" title="Chlorine 24%" />
              <div style={{ width: '9%' }} className="bg-emerald-500 h-full" title="Ethanol 9%" />
              <div style={{ width: '5%' }} className="bg-purple-500 h-full" title="Additive 5%" />
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1">
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-amber-500 rounded-full" /> VCM (62%)</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-sky-500 rounded-full" /> Chlorine (24%)</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-emerald-500 rounded-full" /> Ethanol (9%)</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-purple-500 rounded-full" /> Additive (5%)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
