import React, { useState } from 'react';
import { IndustrialEvent } from '../types/chem_os';
import { EVENT_STREAM } from '../services/syntheticData';
import { Play, Pause, RotateCcw, Activity, Clock } from 'lucide-react';

export const EventStreamReplayView: React.FC = () => {
  const [events, setEvents] = useState<IndustrialEvent[]>(EVENT_STREAM);
  const [isReplaying, setIsReplaying] = useState<boolean>(false);
  const [replayIndex, setReplayIndex] = useState<number>(EVENT_STREAM.length);

  const visibleEvents = events.slice(0, replayIndex);

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto font-mono text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4 font-sans">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>IMMUTABLE EVENT STREAM & REPLAY ENGINE</span>
            <span>·</span>
            <span>AUDIT LEDGER</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Industrial Event Stream Ledger & Time Replay</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Event-driven architecture recording material movement, reaction milestones, lab results, and logistics events.
          </p>
        </div>

        {/* Replay Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setReplayIndex(1)}
            className="p-2 bg-slate-950 hover:bg-slate-800 border border-slate-700 text-white rounded transition-colors"
            title="Reset to Start"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => {
              if (replayIndex < events.length) {
                setReplayIndex((prev) => prev + 1);
              } else {
                setReplayIndex(1);
              }
            }}
            className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded transition-colors flex items-center gap-1.5"
          >
            <Play className="w-3.5 h-3.5" /> Step Next Event
          </button>
        </div>
      </div>

      {/* Scrubber Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-2">
        <div className="flex justify-between text-slate-400">
          <span>EVENT STREAM SCRUBBER</span>
          <span className="text-amber-400 font-bold">{replayIndex} / {events.length} EVENTS</span>
        </div>

        <input
          type="range"
          min="1"
          max={events.length}
          value={replayIndex}
          onChange={(e) => setReplayIndex(Number(e.target.value))}
          className="w-full accent-amber-400 cursor-pointer"
        />
      </div>

      {/* Events Log Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="pb-3 border-b border-slate-800 mb-4 flex items-center justify-between">
          <h2 className="text-sm font-bold text-white font-sans">Immutable Event Stream</h2>
          <span className="text-slate-500">AUDIT SIGNED</span>
        </div>

        <div className="space-y-2">
          {visibleEvents.map((evt) => (
            <div
              key={evt.id}
              className="p-3 bg-slate-950 border border-slate-800 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-2"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-amber-400 font-bold">{evt.eventType}</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-300">{evt.siteId}</span>
                </div>
                <div className="text-slate-200 font-sans">{evt.details}</div>
              </div>

              <div className="text-right text-[11px] text-slate-500 shrink-0">
                <div>{new Date(evt.timestamp).toUTCString()}</div>
                <div className="text-slate-400">Actor: {evt.actor}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
