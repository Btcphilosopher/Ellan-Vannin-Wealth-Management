import React, { useState } from 'react';
import { LabSample } from '../types/chem_os';
import { SAMPLES } from '../services/syntheticData';
import { FlaskConical, CheckCircle2, ShieldCheck, FileText, AlertTriangle } from 'lucide-react';

export const QualityLabView: React.FC = () => {
  const [samplesList, setSamplesList] = useState<LabSample[]>(SAMPLES);
  const [selectedSampleId, setSelectedSampleId] = useState<string>('SAMPLE-S-55120');

  const currentSample = samplesList.find((s) => s.id === selectedSampleId) || samplesList[0];

  const handleUpdateStatus = (newStatus: 'PASS' | 'FAIL' | 'HOLD') => {
    setSamplesList((prev) =>
      prev.map((s) => (s.id === currentSample.id ? { ...s, status: newStatus } : s))
    );
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>LABORATORY INFORMATION MANAGEMENT SYSTEM (LIMS)</span>
            <span>·</span>
            <span>Q-LAB 1</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Quality Assurance & Certificate of Analysis</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Sample verification workflow. A batch cannot enter unrestricted inventory until quality release clearance.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs font-mono text-slate-300">
          <FlaskConical className="w-4 h-4 text-amber-400" />
          <span>SAMPLES IN QUEUE: {samplesList.length}</span>
        </div>
      </div>

      {/* Main Grid: Sample Queue & Certificate Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sample Queue */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="pb-3 border-b border-slate-800 mb-4 flex items-center justify-between">
            <h2 className="text-sm font-bold font-display text-white">Laboratory Analytical Queue</h2>
            <span className="text-xs font-mono text-slate-500">LIMS ACTIVE</span>
          </div>

          <div className="space-y-3">
            {samplesList.map((sample) => {
              const isSelected = sample.id === selectedSampleId;
              return (
                <div
                  key={sample.id}
                  onClick={() => setSelectedSampleId(sample.id)}
                  className={`p-4 rounded border transition-all cursor-pointer font-mono text-xs flex items-center justify-between ${
                    isSelected ? 'bg-amber-500/10 border-amber-400 text-white font-semibold' : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div>
                    <div className="font-bold text-amber-400">{sample.sampleCode}</div>
                    <div className="text-slate-200 font-sans font-semibold mt-0.5">{sample.batchId}</div>
                    <div className="text-[11px] text-slate-400">{sample.samplingLocation}</div>
                  </div>

                  <span className={`px-2.5 py-1 rounded text-[10px] font-bold ${
                    sample.status === 'PASS'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                  }`}>
                    {sample.status}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Sample Analysis Certificate */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-5 font-mono text-xs">
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-amber-400 font-bold">CERTIFICATE OF ANALYSIS (CoA)</div>
              <h2 className="text-lg font-bold font-display text-white mt-0.5">{currentSample.sampleCode}</h2>
            </div>

            <FileText className="w-5 h-5 text-amber-400" />
          </div>

          <div className="grid grid-cols-2 gap-3 text-slate-300">
            <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500">MEASURED PURITY</div>
              <div className="text-base font-bold text-emerald-400 mt-0.5 tabular-nums">{currentSample.measuredPurityPercent}%</div>
            </div>
            <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500">MEASURED DENSITY</div>
              <div className="text-base font-bold text-white mt-0.5 tabular-nums">{currentSample.measuredDensityGcm3} g/cm³</div>
            </div>
            <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500">VISCOSITY</div>
              <div className="text-base font-bold text-white mt-0.5 tabular-nums">{currentSample.measuredViscosityCp} cP</div>
            </div>
            <div className="p-2.5 bg-slate-950 border border-slate-800 rounded">
              <div className="text-slate-500">MOISTURE</div>
              <div className="text-base font-bold text-white mt-0.5 tabular-nums">{currentSample.measuredMoisturePpm} ppm</div>
            </div>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded text-slate-300 leading-relaxed font-sans">
            <strong className="text-amber-400 font-mono">Analyst Notes:</strong> {currentSample.notes}
          </div>

          <div className="pt-2 flex gap-3">
            <button
              onClick={() => handleUpdateStatus('PASS')}
              className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded transition-colors"
            >
              Approve Quality Release
            </button>
            <button
              onClick={() => handleUpdateStatus('HOLD')}
              className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded transition-colors"
            >
              Place Quality Hold
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
