import React, { useState } from 'react';
import { CommodityMarketPrice } from '../types/chem_os';
import { MARKET_PRICES } from '../services/syntheticData';
import { DollarSign, TrendingUp, Sliders, ArrowUpRight } from 'lucide-react';

export const CostMarketView: React.FC = () => {
  const [energyMultiplier, setEnergyMultiplier] = useState<number>(1.0);
  const [pricesList, setPricesList] = useState<CommodityMarketPrice[]>(MARKET_PRICES);

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto font-mono text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4 font-sans">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>COMMODITY MARKET & COST ENGINE</span>
            <span>·</span>
            <span>MARGIN SENSITIVITY</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Commodity Benchmarks & Contribution Economics</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Synthetic market benchmarks and real-time sensitivity analysis against feedstock and energy cost fluctuations.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs font-mono text-amber-400 font-bold">
          <DollarSign className="w-4 h-4" />
          <span>GROSS MARGIN AVG: 32.4%</span>
        </div>
      </div>

      {/* Sensitivity Slider & Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Slider Controls */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4 font-sans">
          <h2 className="text-sm font-bold text-white flex items-center gap-2 font-mono">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>Energy Price Shock Sensitivity</span>
          </h2>

          <div className="space-y-2 font-mono text-xs">
            <div className="flex justify-between text-slate-300">
              <span>Energy Price Factor:</span>
              <span className="text-amber-400 font-bold">{energyMultiplier.toFixed(2)}x Baseline</span>
            </div>

            <input
              type="range"
              min="0.5"
              max="2.5"
              step="0.1"
              value={energyMultiplier}
              onChange={(e) => setEnergyMultiplier(Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>
        </div>

        {/* Commodity Prices Table */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
            <h2 className="text-sm font-bold text-white font-sans">Chemical Benchmark Margins</h2>
            <span className="text-slate-500 font-mono">SPOT & CONTRACT BASIS</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-2.5">Material</th>
                  <th className="p-2.5">Ref Price</th>
                  <th className="p-2.5">Adj Cost</th>
                  <th className="p-2.5">Gross Margin</th>
                  <th className="p-2.5">24h Change</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {pricesList.map((p) => {
                  const adjCost = Math.round(p.internalCostGBP * energyMultiplier);
                  const adjMargin = (((p.referencePriceGBP - adjCost) / p.referencePriceGBP) * 100).toFixed(1);
                  return (
                    <tr key={p.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-2.5 font-bold text-white">{p.materialName}</td>
                      <td className="p-2.5 tabular-nums text-amber-400 font-bold">£{p.referencePriceGBP}</td>
                      <td className="p-2.5 tabular-nums text-slate-200">£{adjCost}</td>
                      <td className="p-2.5 tabular-nums font-bold text-emerald-400">{adjMargin}%</td>
                      <td className="p-2.5 tabular-nums text-emerald-400 font-bold">+{p.priceChange24hPercent}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
