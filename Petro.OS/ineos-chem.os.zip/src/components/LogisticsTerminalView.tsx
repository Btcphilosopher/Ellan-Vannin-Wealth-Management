import React from 'react';
import { LogisticsShipment } from '../types/chem_os';
import {
  Truck,
  Train,
  Ship,
  GitBranch,
  Clock,
  CheckCircle2,
  FileCheck,
  Search
} from 'lucide-react';

interface LogisticsTerminalViewProps {
  shipments: LogisticsShipment[];
}

export const LogisticsTerminalView: React.FC<LogisticsTerminalViewProps> = ({ shipments }) => {
  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>TERMINAL LOGISTICS BOARD</span>
            <span>·</span>
            <span>UK INTERMODAL DISPATCH</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Chemical Logistics & Shipping Terminal</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Real-time tracking of bulk road tankers, block rail freight, sea gas carriers, and regional pipeline networks.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs font-mono text-slate-300">
          <Truck className="w-4 h-4 text-amber-400" />
          <span>ACTIVE SHIPMENTS: {shipments.length}</span>
        </div>
      </div>

      {/* Shipments Board Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="pb-3 border-b border-slate-800 mb-4 flex items-center justify-between">
          <h2 className="text-sm font-bold font-display text-white">
            Today's Intermodal Movements Board
          </h2>
          <span className="text-xs font-mono text-slate-500">REAL-TIME POSITION & ETA FEED</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-3">Shipment / Mode</th>
                <th className="p-3">Product / Grade</th>
                <th className="p-3">Quantity</th>
                <th className="p-3">Origin → Destination</th>
                <th className="p-3">Departure / ETA</th>
                <th className="p-3">Vehicle / Vessel</th>
                <th className="p-3">Quality Cert</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {shipments.map((shp) => (
                <tr key={shp.id} className="hover:bg-slate-800/40 transition-colors text-slate-300">
                  <td className="p-3">
                    <div className="font-bold text-amber-400">{shp.shipmentNumber}</div>
                    <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                      {shp.mode === 'ROAD_TANKER' && <Truck className="w-3 h-3 text-sky-400" />}
                      {shp.mode === 'RAIL_FREIGHT' && <Train className="w-3 h-3 text-emerald-400" />}
                      {shp.mode === 'SEA_VESSEL' && <Ship className="w-3 h-3 text-indigo-400" />}
                      {shp.mode === 'PIPELINE' && <GitBranch className="w-3 h-3 text-yellow-400" />}
                      <span>{shp.mode}</span>
                    </div>
                  </td>
                  <td className="p-3">
                    <div className="font-bold text-white">{shp.materialName}</div>
                    <div className="text-[11px] text-slate-400">{shp.gradeCode}</div>
                  </td>
                  <td className="p-3 font-bold tabular-nums text-amber-400">{shp.quantityTons.toLocaleString()} t</td>
                  <td className="p-3">
                    <div className="text-slate-200 font-semibold">{shp.originName}</div>
                    <div className="text-[11px] text-slate-400">→ {shp.destinationName}</div>
                  </td>
                  <td className="p-3">
                    <div>Dep: {new Date(shp.departureTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                    <div className="text-amber-400 font-bold">ETA: {new Date(shp.estimatedTimeArrival).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                  </td>
                  <td className="p-3 font-mono text-slate-300">
                    <div>{shp.vehicleVesselId}</div>
                    <div className="text-[11px] text-slate-500">{shp.driverVesselMaster}</div>
                  </td>
                  <td className="p-3">
                    {shp.qualityCertificateAttached ? (
                      <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-bold flex items-center gap-1 w-max">
                        <FileCheck className="w-3 h-3" /> CoA ATTACHED
                      </span>
                    ) : (
                      <span className="text-slate-500 text-[10px]">PENDING</span>
                    )}
                  </td>
                  <td className="p-3">
                    <span className="px-2.5 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded font-bold text-xs">
                      {shp.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
