import React from 'react';
import { AlertTriangle, CheckCircle2, Activity, ShieldAlert, Zap, Truck, ShoppingBag } from 'lucide-react';

export const ControlRoomView: React.FC = () => {
  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto font-mono text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4 font-sans">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>OPERATIONS CONTROL ROOM</span>
            <span>·</span>
            <span>ACTIVE MONITORING CONSOLE</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">Central Operations Control Room</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Real-time exception monitoring console for process deviations, quality holds, low inventory, and shipment tracking.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 rounded text-xs font-mono text-emerald-400 font-bold">
          <Activity className="w-4 h-4" />
          <span>ALL SYSTEMS NOMINAL</span>
        </div>
      </div>

      {/* Control Room Status Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-sans">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded">
          <div className="text-xs text-slate-400 font-mono">PRODUCTION STATUS</div>
          <div className="text-lg font-bold text-emerald-400 mt-1 font-mono">98.4% ON PLAN</div>
        </div>
        <div className="p-4 bg-slate-900 border border-slate-800 rounded">
          <div className="text-xs text-slate-400 font-mono">QUALITY CLEARANCE</div>
          <div className="text-lg font-bold text-emerald-400 mt-1 font-mono">97.9% PASSED</div>
        </div>
        <div className="p-4 bg-slate-900 border border-slate-800 rounded">
          <div className="text-xs text-slate-400 font-mono">INVENTORY BUFFER</div>
          <div className="text-lg font-bold text-amber-400 mt-1 font-mono">82.1% CAPACITY</div>
        </div>
        <div className="p-4 bg-slate-900 border border-slate-800 rounded">
          <div className="text-xs text-slate-400 font-mono">LOGISTICS ON-TIME</div>
          <div className="text-lg font-bold text-emerald-400 mt-1 font-mono">94.2% ON ETA</div>
        </div>
      </div>

      {/* Exceptions Stream */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4 font-mono">
        <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-white font-sans">Active Operational Exceptions & Alerts</h2>
          <span className="text-slate-500">AUTO-TRIAGED BY CHEM.OS</span>
        </div>

        <div className="space-y-3">
          <div className="p-3.5 bg-slate-950 border border-amber-500/40 rounded flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <div>
                <div className="font-bold text-amber-400">QUALITY HOLD — BATCH B26-09142</div>
                <div className="text-[11px] text-slate-300">Purity variance 0.02% under standard. Retest initiated at Q-Lab 1.</div>
              </div>
            </div>
            <span className="px-2 py-0.5 bg-amber-500/10 text-amber-400 rounded text-[10px] font-bold">MEDIUM PRIORITY</span>
          </div>

          <div className="p-3.5 bg-slate-950 border border-slate-800 rounded flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Truck className="w-4 h-4 text-sky-400 shrink-0" />
              <div>
                <div className="font-bold text-slate-200">LOGISTICS ETA ADVISORY — SHIP-8821</div>
                <div className="text-[11px] text-slate-400">Heavy traffic on M6 Southbound. ETA shifted +15 mins to 15:35 GMT.</div>
              </div>
            </div>
            <span className="px-2 py-0.5 bg-sky-500/10 text-sky-400 rounded text-[10px] font-bold">LOW PRIORITY</span>
          </div>
        </div>
      </div>
    </div>
  );
};
