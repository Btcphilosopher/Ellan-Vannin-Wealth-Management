import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { Site, ProcessUnit } from '../types/chem_os';
import {
  Box,
  Layers,
  Thermometer,
  Gauge,
  Zap,
  Activity,
  Maximize2,
  RefreshCw,
  Sliders,
  Play
} from 'lucide-react';

interface SitesDigitalTwinViewProps {
  sites: Site[];
  selectedSiteId: string;
  onSelectSite: (siteId: string) => void;
}

export const SitesDigitalTwinView: React.FC<SitesDigitalTwinViewProps> = ({
  sites,
  selectedSiteId,
  onSelectSite
}) => {
  const [viewMode, setViewMode] = useState<'2D_SCHEMATIC' | '3D_DIGITAL_TWIN'>('3D_DIGITAL_TWIN');
  const [activeUnitId, setActiveUnitId] = useState<string>('UNIT-CA-01');

  const site = sites.find((s) => s.id === selectedSiteId) || sites[0];

  // 3D Canvas Ref
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (viewMode !== '3D_DIGITAL_TWIN' || !mountRef.current) return;

    // Initialize Three.js Scene
    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight || 500;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x090d16);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(25, 20, 30);
    camera.lookAt(0, 4, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    mountRef.current.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xf59e0b, 1.2);
    dirLight.position.set(20, 40, 20);
    scene.add(dirLight);

    const gridHelper = new THREE.GridHelper(60, 30, 0x334155, 0x1e293b);
    scene.add(gridHelper);

    // Render 3D Plant Structures
    // 1. Storage Tanks
    const tankMaterial = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      metalness: 0.6,
      roughness: 0.2
    });

    const tankGroup = new THREE.Group();
    for (let i = 0; i < 4; i++) {
      const geo = new THREE.CylinderGeometry(2.5, 2.5, 7, 24);
      const mesh = new THREE.Mesh(geo, tankMaterial);
      mesh.position.set(-15 + i * 8, 3.5, -10);
      tankGroup.add(mesh);
    }
    scene.add(tankGroup);

    // 2. Distillation / Electrolyzer Columns
    const columnMaterial = new THREE.MeshStandardMaterial({
      color: 0x64748b,
      metalness: 0.8,
      roughness: 0.1
    });

    for (let i = 0; i < 2; i++) {
      const colGeo = new THREE.CylinderGeometry(1.8, 1.8, 14, 24);
      const colMesh = new THREE.Mesh(colGeo, columnMaterial);
      colMesh.position.set(-5 + i * 12, 7, 5);
      scene.add(colMesh);
    }

    // 3. Reactor Vessels
    const reactorGeo = new THREE.SphereGeometry(3.5, 32, 16);
    const reactorMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.5, roughness: 0.3 });
    const reactor = new THREE.Mesh(reactorGeo, reactorMat);
    reactor.position.set(12, 4, 8);
    scene.add(reactor);

    // Pipe Bridges
    const pipeGeo = new THREE.CylinderGeometry(0.3, 0.3, 30, 16);
    const pipeMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9, roughness: 0.1 });
    const pipe = new THREE.Mesh(pipeGeo, pipeMat);
    pipe.rotation.z = Math.PI / 2;
    pipe.position.set(0, 10, -5);
    scene.add(pipe);

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      reactor.rotation.y += 0.005;
      tankGroup.rotation.y += 0.001;
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!mountRef.current) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight || 500;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [viewMode, selectedSiteId]);

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
            <span>SITE DIGITAL TWIN</span>
            <span>·</span>
            <span>{site.locationCode}</span>
          </div>
          <h1 className="text-xl font-bold font-display text-white">{site.name}</h1>
        </div>

        <div className="flex items-center gap-3">
          {/* Site Selector */}
          <select
            value={selectedSiteId}
            onChange={(e) => onSelectSite(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-xs font-mono text-white px-3 py-1.5 rounded focus:outline-none focus:border-amber-400"
          >
            {sites.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.locationCode})
              </option>
            ))}
          </select>

          {/* View Mode Toggle Buttons */}
          <div className="flex items-center bg-slate-950 p-1 border border-slate-800 rounded">
            <button
              onClick={() => setViewMode('3D_DIGITAL_TWIN')}
              className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                viewMode === '3D_DIGITAL_TWIN' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              3D Digital Twin
            </button>
            <button
              onClick={() => setViewMode('2D_SCHEMATIC')}
              className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                viewMode === '2D_SCHEMATIC' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              2D P&ID Schematic
            </button>
          </div>
        </div>
      </div>

      {/* Main Viewport Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Visualizer Canvas Area */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col justify-between min-h-[550px]">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-2">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
              <Box className="w-4 h-4 text-amber-400" />
              <span>{viewMode === '3D_DIGITAL_TWIN' ? 'Interactive 3D Physical Spatial Twin' : 'P&ID Engineering Process Flow Diagram'}</span>
            </div>

            <div className="text-xs font-mono text-slate-500">
              {viewMode === '3D_DIGITAL_TWIN' ? 'WebGL THREE.JS RENDERER' : 'SVG VECTOR P&ID'}
            </div>
          </div>

          {/* Canvas Rendering Box */}
          {viewMode === '3D_DIGITAL_TWIN' ? (
            <div ref={mountRef} className="w-full h-[480px] rounded border border-slate-800 relative bg-slate-950 overflow-hidden">
              <div className="absolute top-3 left-3 bg-slate-900/90 border border-slate-800 p-2.5 rounded text-xs font-mono text-slate-300 space-y-1">
                <div className="text-amber-400 font-bold">ASSET SPATIAL INDEX</div>
                <div>· 4x Pressurized Storage Spheres</div>
                <div>· 2x Distillation Fractionators</div>
                <div>· 1x Catalytic Loop Vessel</div>
              </div>
            </div>
          ) : (
            /* 2D P&ID Flow Diagram View */
            <div className="w-full h-[480px] rounded border border-slate-800 bg-slate-950 p-6 flex flex-col justify-between font-mono relative overflow-hidden">
              <div className="absolute top-4 left-4 text-xs font-mono text-amber-400 font-bold">
                P&ID DIAGRAM: CELLROOM LINE 1 & BRINE LOOP
              </div>

              {/* SVG Process Diagram */}
              <svg className="w-full h-full" viewBox="0 0 800 400" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Feedstock Line */}
                <path d="M 50 200 L 200 200" stroke="#38bdf8" strokeWidth="4" strokeDasharray="8 4" className="animate-pulse" />
                <rect x="50" y="175" width="80" height="50" rx="4" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
                <text x="60" y="205" fill="#f8fafc" fontSize="11" fontFamily="JetBrains Mono">SALT BRINE</text>

                {/* Electrolyzer Cellroom */}
                <path d="M 200 200 L 400 200" stroke="#f59e0b" strokeWidth="4" />
                <rect x="200" y="140" width="120" height="120" rx="6" fill="#1e293b" stroke="#f59e0b" strokeWidth="3" />
                <text x="210" y="170" fill="#f59e0b" fontSize="12" fontWeight="bold" fontFamily="JetBrains Mono">MEMBRANE</text>
                <text x="210" y="190" fill="#cbd5e1" fontSize="11" fontFamily="JetBrains Mono">CELLROOM 1</text>
                <text x="210" y="220" fill="#10b981" fontSize="10" fontFamily="JetBrains Mono">88.5°C · 1.15 bar</text>

                {/* Output Lines: Chlorine (Top) & Caustic (Bottom) */}
                <path d="M 320 170 L 550 100 L 700 100" stroke="#ef4444" strokeWidth="4" />
                <rect x="550" y="80" width="120" height="40" rx="4" fill="#0f172a" stroke="#ef4444" strokeWidth="2" />
                <text x="560" y="105" fill="#f8fafc" fontSize="11" fontFamily="JetBrains Mono">CHLORINE GAS</text>

                <path d="M 320 230 L 550 300 L 700 300" stroke="#10b981" strokeWidth="4" />
                <rect x="550" y="280" width="120" height="40" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="2" />
                <text x="560" y="305" fill="#f8fafc" fontSize="11" fontFamily="JetBrains Mono">CAUSTIC 50%</text>
              </svg>
            </div>
          )}
        </div>

        {/* Telemetry Sensor Control Panel */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <Activity className="w-3.5 h-3.5 text-amber-400" />
              <span>LIVE SENSOR TELEMETRY</span>
            </div>
            <h2 className="text-base font-bold font-display text-white mt-0.5">
              Cellroom Line 1 Sensors
            </h2>
          </div>

          <div className="space-y-3">
            <div className="bg-slate-950 p-3 rounded border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Thermometer className="w-4 h-4 text-amber-400" />
                <div>
                  <div className="text-xs font-mono text-slate-400">Cellroom Temp (TT-101)</div>
                  <div className="text-sm font-bold font-mono text-white tabular-nums">88.5 °C</div>
                </div>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded">
                NORMAL
              </span>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Gauge className="w-4 h-4 text-sky-400" />
                <div>
                  <div className="text-xs font-mono text-slate-400">Anode Header Press (PT-202)</div>
                  <div className="text-sm font-bold font-mono text-white tabular-nums">1.15 bar</div>
                </div>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded">
                NORMAL
              </span>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Zap className="w-4 h-4 text-yellow-400" />
                <div>
                  <div className="text-xs font-mono text-slate-400">Rectifier Power (JY-401)</div>
                  <div className="text-sm font-bold font-mono text-white tabular-nums">28.4 MW</div>
                </div>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded">
                EFFICIENT
              </span>
            </div>
          </div>

          <div className="pt-2">
            <div className="text-xs font-mono text-slate-400 mb-2">Process Units at Site:</div>
            <div className="space-y-1.5">
              {site.processAreas.flatMap((a) => a.units).map((u) => (
                <button
                  key={u.id}
                  onClick={() => setActiveUnitId(u.id)}
                  className={`w-full text-left p-2 rounded border text-xs font-mono transition-colors ${
                    activeUnitId === u.id ? 'bg-amber-400 text-slate-950 font-bold border-amber-400' : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {u.code} - {u.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
