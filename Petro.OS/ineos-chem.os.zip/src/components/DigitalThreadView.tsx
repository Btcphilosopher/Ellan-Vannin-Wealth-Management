import React, { useState } from 'react';
import { Batch } from '../types/chem_os';
import {
  GitCommit,
  CheckCircle2,
  Factory,
  FlaskConical,
  Database,
  Truck,
  UserCheck,
  ChevronRight,
  ShieldCheck,
  Layers,
  Search
} from 'lucide-react';

interface DigitalThreadViewProps {
  batches: Batch[];
  selectedBatchId: string;
  onSelectBatch: (batchId: string) => void;
}

export const DigitalThreadView: React.FC<DigitalThreadViewProps> = ({
  batches,
  selectedBatchId,
  onSelectBatch
}) => {
  const [activeStep, setActiveStep] = useState<number>(3); // Default step active

  const batch = batches.find((b) => b.id === selectedBatchId) || batches[0];

  const threadNodes = [
    {
      stepNumber: 1,
      title: 'FEEDSTOCK LOT',
      code: batch.feedstockLotId,
      subtext: 'Purified Vacuum Salt feedstock (Cheshire Brine Wells)',
      details: 'Lot Quality Certified · Purity 99.9% · Received 2026-09-28 00:15 GMT',
      icon: Database
    },
    {
      stepNumber: 2,
      title: 'PRODUCTION SITE & UNIT',
      code: `${batch.siteId} / ${batch.unitId}`,
      subtext: 'INEOS Runcorn Manufacturing Complex · Membrane Cellroom 1',
      details: `Campaign: ${batch.campaignId} · Recipe: ${batch.recipeVersion} · Chief Op: R. Davies`,
      icon: Factory
    },
    {
      stepNumber: 3,
      title: 'PROCESS & REACTION',
      code: batch.batchNumber,
      subtext: `Batch Tonnage: ${batch.quantityTons} tonnes · Status: ${batch.status}`,
      details: `Start: ${batch.startTime} · End: ${batch.completionTime}`,
      icon: GitCommit
    },
    {
      stepNumber: 4,
      title: 'QUALITY LAB SAMPLE',
      code: 'SAMPLE S-55120',
      subtext: 'Q-Lab 1 Analytical Certificate (Purity 99.82%)',
      details: 'Analyst: Dr. E. Vance · Certificate of Analysis CoA-8812 Signed',
      icon: FlaskConical
    },
    {
      stepNumber: 5,
      title: 'QUALITY RELEASE',
      code: 'APPROVED / UNRESTRICTED',
      subtext: 'Q-Lab Automated Quality Clearance Granted',
      details: 'Compliance: ISO 9001 · Reach Registered · Unrestricted Inventory Status',
      icon: ShieldCheck
    },
    {
      stepNumber: 6,
      title: 'STORAGE TANK',
      code: batch.storageTankId || 'TANK-RUN-T204',
      subtext: 'Pressurized Refrigerated Storage Vessel T-204',
      details: 'Temp: -33.8°C · Press: 2.1 bar · Current Level: 1,850 tonnes',
      icon: Database
    },
    {
      stepNumber: 7,
      title: 'LOGISTICS SHIPMENT',
      code: 'SHP-UK-8821',
      subtext: 'Bulk Road Tanker TRUCK 7812 / INEOS Intermodal Logistics',
      details: 'In Transit · Dispatched 2026-09-29 07:40 GMT · ETA: 15:20 GMT',
      icon: Truck
    },
    {
      stepNumber: 8,
      title: 'CUSTOMER & ORDER',
      code: 'CUST-UK-044 / ORD-2026-8812',
      subtext: 'UK Infrastructure & Fenestration PLC (Birmingham Hub)',
      details: 'Order Value: £1,147,500 · Promised Delivery: 2026-09-29',
      icon: UserCheck
    }
  ];

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1700px] mx-auto">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 uppercase tracking-wider">
            <span>INEOS DIGITAL THREAD PROVENANCE ENGINE</span>
            <span>·</span>
            <span>END-TO-END TRACEABILITY</span>
          </div>
          <h1 className="text-2xl font-bold font-display text-white">The Chemical Digital Thread</h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Complete backward and forward traceability graph for every batch manufactured across the UK network.
          </p>
        </div>

        {/* Batch Selector */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-slate-400">SELECT BATCH:</span>
          <select
            value={selectedBatchId}
            onChange={(e) => onSelectBatch(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-xs font-mono text-white px-3 py-2 rounded focus:outline-none focus:border-amber-400"
          >
            {batches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.batchNumber} ({b.quantityTons}t) - {b.status}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Visualizer: Node Graph Trail */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-6">
        <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-mono text-slate-500 uppercase">INSPECTING BATCH:</span>
            <h2 className="text-lg font-bold font-mono text-amber-400">{batch.batchNumber}</h2>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-950/80 border border-emerald-800 px-3 py-1 rounded">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>PROVENANCE CHAIN VERIFIED & LOCKED</span>
          </div>
        </div>

        {/* Horizontal Visual Thread Node Stream */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {threadNodes.map((node) => {
            const Icon = node.icon;
            const isActive = activeStep === node.stepNumber;
            return (
              <div
                key={node.stepNumber}
                onClick={() => setActiveStep(node.stepNumber)}
                className={`p-4 rounded border transition-all cursor-pointer relative flex flex-col justify-between ${
                  isActive
                    ? 'bg-amber-500/15 border-amber-400 text-white shadow-md'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 bg-slate-900 border border-slate-800 rounded text-slate-400">
                      STEP 0{node.stepNumber}
                    </span>
                    <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                  </div>

                  <div className="text-xs font-mono font-bold text-amber-400 uppercase">{node.title}</div>
                  <div className="text-sm font-bold text-white font-mono mt-1">{node.code}</div>
                  <div className="text-xs text-slate-400 mt-1 font-sans">{node.subtext}</div>
                </div>

                <div className="mt-4 pt-2 border-t border-slate-800 text-[11px] font-mono text-slate-400 leading-tight">
                  {node.details}
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Step Deep Dive Inspector */}
        <div className="bg-slate-950 p-5 rounded border border-slate-800 space-y-3 font-mono text-xs">
          <div className="flex items-center gap-2 text-amber-400 font-bold uppercase">
            <Layers className="w-4 h-4" />
            <span>NODE PROVENANCE INSPECTOR — STEP 0{activeStep}: {threadNodes[activeStep - 1].title}</span>
          </div>

          <p className="text-slate-300 text-sm font-sans">
            {threadNodes[activeStep - 1].details}. Verified through INEOS CHEM.OS immutable event stream ledger.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-[11px] text-slate-400">
            <div>EVENT SIGNATURE: <span className="text-white">SIG-091823-A</span></div>
            <div>VERIFICATION: <span className="text-emerald-400 font-bold">100% INTACT</span></div>
            <div>ACTOR: <span className="text-white">SYSTEM AUTO-LOGGER</span></div>
            <div>LATENCY: <span className="text-white">0.42 ms</span></div>
          </div>
        </div>
      </div>
    </div>
  );
};
