/**
 * INEOS CHEM.OS - Chemical Industrial Operating System
 * Domain Types Definition
 */

export type NavigationTab =
  | 'OVERVIEW'
  | 'SITES'
  | 'MATERIALS'
  | 'CAMPAIGN'
  | 'BLENDING'
  | 'SIMULATOR'
  | 'QUALITY'
  | 'DIGITAL_THREAD'
  | 'TANKS'
  | 'LOGISTICS'
  | 'ORDERS'
  | 'ENERGY'
  | 'COST_MARKET'
  | 'CONTROL_ROOM'
  | 'INTELLIGENCE'
  | 'DEMOS'
  | 'EVENTS';

export type SiteLocation = 'RUNCORN' | 'GRANGEMOUTH' | 'TEESSIDE' | 'HULL' | 'STANLOW_LINK' | 'SALT_END' | 'FAWLEY_LINK' | 'IMMINGHAM';

export interface Site {
  id: string;
  name: string;
  locationCode: SiteLocation;
  region: string;
  country: string;
  coordinates: [number, number]; // [lat, lng]
  primaryOutputs: string[];
  capacityTonsPerYear: number;
  currentUtilizationPercent: number;
  activeCampaignsCount: number;
  energyPerTonneMWh: number;
  co2ePerTonneKg: number;
  status: 'OPTIMAL' | 'DEGRADED' | 'MAINTENANCE' | 'OUTAGE';
  processAreas: ProcessArea[];
  laboratoriesCount: number;
  tanksCount: number;
}

export interface ProcessArea {
  id: string;
  siteId: string;
  name: string;
  description: string;
  units: ProcessUnit[];
}

export interface ProcessUnit {
  id: string;
  areaId: string;
  code: string;
  name: string;
  type: 'ELECTROLYZER' | 'REACTOR' | 'DISTILLATION_COLUMN' | 'CRACKER' | 'SEPARATOR' | 'HEAT_EXCHANGER' | 'BLENDER' | 'PURIFIER';
  status: 'RUNNING' | 'STANDBY' | 'DEGRADED' | 'OFFLINE' | 'ALERT';
  throughputTonsPerHour: number;
  targetThroughputTonsPerHour: number;
  temperatureCelsius: number;
  pressureBar: number;
  powerUsageMW: number;
  lastMaintenance: string;
}

export type MaterialFamily = 'BASE_CHEMICALS' | 'SOLVENTS' | 'INTERMEDIATES' | 'POLYMERS' | 'SPECIALTY';
export type PhysicalState = 'LIQUID' | 'GAS' | 'SOLID_PELLET' | 'SOLID_POWDER' | 'SLURRY';
export type HazardClass = 'CLASS_8_CORROSIVE' | 'CLASS_3_FLAMMABLE' | 'CLASS_2.2_COMPRESSED_GAS' | 'CLASS_9_MISC' | 'NON_HAZARDOUS';

export interface ChemicalMaterial {
  id: string;
  code: string;
  chemicalName: string;
  commonName: string;
  casNumber: string;
  family: MaterialFamily;
  physicalState: PhysicalState;
  hazardClass: HazardClass;
  densityGcm3: number;
  boilingPointC: number;
  flashPointC: number | null;
  viscosityCp: number;
  purityPercentTarget: number;
  standardShelfLifeDays: number;
  defaultPackaging: string;
  storageRequirements: string;
  currentInventoryTons: number;
  targetMinInventoryTons: number;
  costPerTonneGBP: number;
  co2ePerTonneKg: number;
}

export interface ChemicalGrade {
  id: string;
  gradeCode: string;
  materialId: string;
  gradeName: string;
  application: string;
  targetPurityPercent: number;
  minPurityPercent: number;
  maxPurityPercent: number;
  targetDensityGcm3: number;
  targetViscosityCp: number;
  maxMoisturePpm: number;
  qualityStatus: 'APPROVED' | 'PROVISIONAL' | 'RESTRICTED';
  pricePerTonneGBP: number;
  customerNameTarget?: string;
  packagingOptions: string[];
}

export interface Batch {
  id: string;
  batchNumber: string;
  materialId: string;
  gradeId: string;
  campaignId: string;
  siteId: string;
  unitId: string;
  feedstockLotId: string;
  quantityTons: number;
  startTime: string;
  completionTime: string | null;
  status: 'PREPARATION' | 'IN_REACTION' | 'PURIFICATION' | 'SAMPLING' | 'QUALITY_HOLD' | 'RELEASED' | 'TRANSFERRED' | 'REJECTED';
  qualityReleaseStatus: 'PENDING' | 'PASSED' | 'FAILED' | 'CONDITIONAL';
  storageTankId?: string;
  operatorShift: string;
  recipeVersion: string;
}

export interface LabSample {
  id: string;
  sampleCode: string;
  batchId: string;
  materialId: string;
  gradeId: string;
  samplingLocation: string;
  timestamp: string;
  analyst: string;
  measuredPurityPercent: number;
  measuredDensityGcm3: number;
  measuredViscosityCp: number;
  measuredMoisturePpm: number;
  measuredColorIndex: number;
  status: 'PENDING' | 'PASS' | 'FAIL' | 'HOLD';
  notes?: string;
}

export interface Tank {
  id: string;
  siteId: string;
  tankCode: string;
  materialId: string;
  materialName: string;
  currentLevelTons: number;
  capacityTons: number;
  fillPercentage: number;
  temperatureCelsius: number;
  pressureBar: number;
  status: 'IN_SERVICE' | 'RECEIVING' | 'DISPATCHING' | 'ISOLATED' | 'MAINTENANCE';
  qualityStatus: 'RELEASED' | 'QUARANTINE' | 'BLENDING_IN_PROGRESS';
  lastInspectionDate: string;
}

export interface BlendingComponentRequirement {
  materialId: string;
  materialName: string;
  targetPercentage: number;
  proposedMassTons: number;
  availableMassTons: number;
  lotId: string;
  qualityStatus: 'RELEASED' | 'QUARANTINE';
  costPerTonneGBP: number;
  isCompatible: boolean;
}

export interface BlendingProposal {
  targetGradeId: string;
  targetGradeCode: string;
  targetGradeName: string;
  targetMassTons: number;
  totalCalculatedMassTons: number;
  massBalanceValid: boolean;
  components: BlendingComponentRequirement[];
  totalCostGBP: number;
  averageCostPerTonneGBP: number;
  projectedPurityPercent: number;
  warnings: string[];
}

export interface ProductionCampaign {
  id: string;
  campaignCode: string;
  siteId: string;
  unitId: string;
  materialId: string;
  gradeId: string;
  startDate: string;
  endDate: string;
  targetTonnage: number;
  actualYieldTons: number;
  expectedYieldTons: number;
  status: 'SCHEDULED' | 'ACTIVE' | 'PAUSED' | 'COMPLETED';
  feedstockRequiredTons: number;
  energyRequirementMWh: number;
  timelineSteps: CampaignStep[];
}

export interface CampaignStep {
  stepNumber: number;
  timeOffsetHours: number;
  title: string;
  description: string;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING';
}

export interface ProcessSimulatorState {
  feedRateTonsPerHour: number;
  temperatureCelsius: number;
  pressureBar: number;
  catalystAgePercent: number;
  productOutputTonsPerHour: number;
  byproductOutputTonsPerHour: number;
  processLossesTonsPerHour: number;
  unaccountedDeltaTonsPerHour: number;
  massBalanceClosed: boolean;
  energyConsumptionKW: number;
}

export interface LogisticsShipment {
  id: string;
  shipmentNumber: string;
  orderId: string;
  customerName: string;
  materialName: string;
  gradeCode: string;
  batchId: string;
  quantityTons: number;
  originSiteId: string;
  originName: string;
  destinationName: string;
  mode: 'PIPELINE' | 'ROAD_TANKER' | 'RAIL_FREIGHT' | 'SEA_VESSEL';
  carrier: string;
  vehicleVesselId: string;
  status: 'PLANNED' | 'LOADING' | 'DISPATCHED' | 'IN_TRANSIT' | 'AT_TERMINAL' | 'DELIVERED';
  departureTime: string;
  estimatedTimeArrival: string;
  driverVesselMaster: string;
  qualityCertificateAttached: boolean;
  gpsCoordinates?: [number, number];
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerLocation: string;
  materialId: string;
  gradeId: string;
  gradeCode: string;
  quantityTons: number;
  unitPriceGBP: number;
  totalValueGBP: number;
  orderDate: string;
  requiredDeliveryDate: string;
  promisedDeliveryDate: string;
  fulfillmentType: 'MAKE_TO_STOCK' | 'MAKE_TO_ORDER';
  status: 'NEW' | 'ALLOCATED' | 'IN_PRODUCTION' | 'QUALITY_HOLD' | 'READY_TO_SHIP' | 'SHIPPED' | 'FULFILLED';
  assignedBatchId?: string;
}

export interface EnvironmentalRecord {
  id: string;
  siteId: string;
  siteName: string;
  period: string;
  electricityMWh: number;
  naturalGasMWh: number;
  steamTons: number;
  hydrogenFuelTons: number;
  totalEnergyMWh: number;
  co2eTonsTotal: number;
  co2eKgPerTonneProduct: number;
  waterUsageM3: number;
  wasteRecycledPercent: number;
}

export interface CommodityMarketPrice {
  id: string;
  materialCode: string;
  materialName: string;
  region: 'UK_DOMESTIC' | 'NORTH_WEST_EUROPE' | 'US_GULF' | 'GLOBAL_BENCHMARK';
  referencePriceGBP: number;
  internalCostGBP: number;
  marginPercent: number;
  basisDescription: string;
  priceChange24hPercent: number;
}

export interface IndustrialEvent {
  id: string;
  timestamp: string;
  eventType:
    | 'MaterialReceived'
    | 'BatchStarted'
    | 'ProcessUpdated'
    | 'BatchCompleted'
    | 'SampleCreated'
    | 'QualityResultRecorded'
    | 'BatchReleased'
    | 'InventoryMoved'
    | 'OrderCreated'
    | 'ShipmentCreated'
    | 'ShipmentDispatched'
    | 'ShipmentDelivered'
    | 'ProcessDeviation';
  siteId: string;
  objectId: string;
  objectType: 'BATCH' | 'TANK' | 'SHIPMENT' | 'ORDER' | 'SAMPLE';
  actor: string;
  details: string;
  severity: 'INFO' | 'WARNING' | 'ALERT' | 'CRITICAL';
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  type: 'PLANT_OUTAGE' | 'FEEDSTOCK_SHORTAGE' | 'ENERGY_PRICE_SPIKE' | 'PORT_CONGESTION' | 'QUALITY_HOLD_CASCADE';
  affectedSiteId: string;
  capacityReductionPercent: number;
  durationDays: number;
}

export interface ScenarioResult {
  scenarioId: string;
  capacityLossTons: number;
  productionShortfallTons: number;
  inventoryDrawTons: number;
  ordersAtRiskCount: number;
  revenueRiskGBP: number;
  mitigationRecommendation: string;
  affectedShipments: string[];
}
