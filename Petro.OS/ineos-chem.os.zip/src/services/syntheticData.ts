/**
 * INEOS CHEM.OS - Synthetic Data Engine & In-Memory Store
 * Deterministic generation of UK industrial network, materials, grades,
 * digital threads, tanks, logistics, orders, and event logs.
 */

import {
  Site,
  ProcessArea,
  ProcessUnit,
  ChemicalMaterial,
  ChemicalGrade,
  Batch,
  LabSample,
  Tank,
  ProductionCampaign,
  LogisticsShipment,
  Order,
  EnvironmentalRecord,
  CommodityMarketPrice,
  IndustrialEvent,
  BlendingProposal,
  ScenarioResult
} from '../types/chem_os';

// Helper deterministic pseudo-random number generator for fixed seed reproducibility
function pseudoRandom(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

const rng = pseudoRandom(19980812);

// ----------------------------------------------------
// 1. UK SITES INITIALIZATION
// ----------------------------------------------------
export const SITES: Site[] = [
  {
    id: 'SITE-RUNCORN',
    name: 'INEOS RUNCORN MANUFACTURING COMPLEX',
    locationCode: 'RUNCORN',
    region: 'North West England',
    country: 'United Kingdom',
    coordinates: [53.332, -2.731],
    primaryOutputs: ['Chlorine', 'Caustic Soda', 'Hydrogen', 'Hydrochloric Acid', 'Sodium Hypochlorite', 'Chlorinated Intermediates'],
    capacityTonsPerYear: 1850000,
    currentUtilizationPercent: 94.8,
    activeCampaignsCount: 6,
    energyPerTonneMWh: 1.42,
    co2ePerTonneKg: 312,
    status: 'OPTIMAL',
    laboratoriesCount: 4,
    tanksCount: 38,
    processAreas: [
      {
        id: 'AREA-RUN-CA',
        siteId: 'SITE-RUNCORN',
        name: 'Chlor-Alkali Electrolysis Cellrooms',
        description: 'Membrane cell technology producing high-purity chlorine gas, caustic soda, and hydrogen fuel.',
        units: [
          {
            id: 'UNIT-CA-01',
            areaId: 'AREA-RUN-CA',
            code: 'CA-CELL-01',
            name: 'Membrane Cellroom Line 1',
            type: 'ELECTROLYZER',
            status: 'RUNNING',
            throughputTonsPerHour: 48.5,
            targetThroughputTonsPerHour: 50.0,
            temperatureCelsius: 88.5,
            pressureBar: 1.15,
            powerUsageMW: 28.4,
            lastMaintenance: '2026-08-15'
          },
          {
            id: 'UNIT-CA-02',
            areaId: 'AREA-RUN-CA',
            code: 'CA-CELL-02',
            name: 'Membrane Cellroom Line 2',
            type: 'ELECTROLYZER',
            status: 'RUNNING',
            throughputTonsPerHour: 49.2,
            targetThroughputTonsPerHour: 50.0,
            temperatureCelsius: 89.1,
            pressureBar: 1.18,
            powerUsageMW: 29.1,
            lastMaintenance: '2026-07-20'
          }
        ]
      },
      {
        id: 'AREA-RUN-SALT',
        siteId: 'SITE-RUNCORN',
        name: 'Brine Purification & Salt Evaporation',
        description: 'Vacuum salt processing and saturated brine purification for chlor-alkali feed.',
        units: [
          {
            id: 'UNIT-SALT-01',
            areaId: 'AREA-RUN-SALT',
            code: 'SALT-EVAP-01',
            name: 'Quadruple Effect Salt Evaporator',
            type: 'PURIFIER',
            status: 'RUNNING',
            throughputTonsPerHour: 110.0,
            targetThroughputTonsPerHour: 112.0,
            temperatureCelsius: 115.0,
            pressureBar: 2.8,
            powerUsageMW: 8.2,
            lastMaintenance: '2026-06-10'
          }
        ]
      },
      {
        id: 'AREA-RUN-DERIV',
        siteId: 'SITE-RUNCORN',
        name: 'Hydrochloric Acid & Derivative Synthesis',
        description: 'Thermal synthesis units for HCL and hypochlorite neutralization loops.',
        units: [
          {
            id: 'UNIT-HCL-01',
            areaId: 'AREA-RUN-DERIV',
            code: 'HCL-SYNTH-01',
            name: 'Hydrogen Chlorine Burner 1',
            type: 'REACTOR',
            status: 'RUNNING',
            throughputTonsPerHour: 22.4,
            targetThroughputTonsPerHour: 24.0,
            temperatureCelsius: 210.0,
            pressureBar: 1.4,
            powerUsageMW: 3.1,
            lastMaintenance: '2026-08-01'
          }
        ]
      }
    ]
  },
  {
    id: 'SITE-GRANGEMOUTH',
    name: 'INEOS GRANGEMOUTH PETROCHEMICAL COMPLEX',
    locationCode: 'GRANGEMOUTH',
    region: 'Stirlingshire',
    country: 'United Kingdom',
    coordinates: [56.022, -3.715],
    primaryOutputs: ['Ethylene', 'Propylene', 'Polyethylene', 'Polypropylene', 'Ethanol', 'Refinery Intermediates'],
    capacityTonsPerYear: 3200000,
    currentUtilizationPercent: 91.2,
    activeCampaignsCount: 9,
    energyPerTonneMWh: 2.15,
    co2ePerTonneKg: 485,
    status: 'OPTIMAL',
    laboratoriesCount: 6,
    tanksCount: 64,
    processAreas: [
      {
        id: 'AREA-GRA-KG',
        siteId: 'SITE-GRANGEMOUTH',
        name: 'Kinneil Feedstock Reception & Olefin Cracker',
        description: 'Gas fractionator and steam cracking units for ethane/propane feedstock.',
        units: [
          {
            id: 'UNIT-CRACKER-01',
            areaId: 'AREA-GRA-KG',
            code: 'OLEFIN-KG-01',
            name: 'KG Ethane Steam Cracker',
            type: 'CRACKER',
            status: 'RUNNING',
            throughputTonsPerHour: 145.0,
            targetThroughputTonsPerHour: 150.0,
            temperatureCelsius: 840.0,
            pressureBar: 18.5,
            powerUsageMW: 62.0,
            lastMaintenance: '2026-05-01'
          }
        ]
      },
      {
        id: 'AREA-GRA-POLY',
        siteId: 'SITE-GRANGEMOUTH',
        name: 'Polyolefins Manufacturing Units',
        description: 'Gas-phase reactors for HDPE, LLDPE and Polypropylene resin compounding.',
        units: [
          {
            id: 'UNIT-HDPE-01',
            areaId: 'AREA-GRA-POLY',
            code: 'HDPE-PLANT-01',
            name: 'Inovene Gas Phase HDPE Loop',
            type: 'REACTOR',
            status: 'RUNNING',
            throughputTonsPerHour: 38.0,
            targetThroughputTonsPerHour: 40.0,
            temperatureCelsius: 92.0,
            pressureBar: 22.0,
            powerUsageMW: 14.5,
            lastMaintenance: '2026-07-12'
          }
        ]
      }
    ]
  },
  {
    id: 'SITE-TEESSIDE',
    name: 'INEOS TEESSIDE CHEMICALS & TERMINAL',
    locationCode: 'TEESSIDE',
    region: 'North East England',
    country: 'United Kingdom',
    coordinates: [54.596, -1.182],
    primaryOutputs: ['Bulk Liquids', 'Intermediates', 'Alpha Olefins', 'Polymer Compounds'],
    capacityTonsPerYear: 1600000,
    currentUtilizationPercent: 88.4,
    activeCampaignsCount: 4,
    energyPerTonneMWh: 1.18,
    co2ePerTonneKg: 280,
    status: 'OPTIMAL',
    laboratoriesCount: 3,
    tanksCount: 42,
    processAreas: [
      {
        id: 'AREA-TEE-INTER',
        siteId: 'SITE-TEESSIDE',
        name: 'Chemical Intermediates & Distillation',
        description: 'Fractionation columns for high-purity chemical solvents and monomers.',
        units: [
          {
            id: 'UNIT-TEE-DIST-01',
            areaId: 'AREA-TEE-INTER',
            code: 'DIST-TEE-01',
            name: 'Vacuum Distillation Column T-102',
            type: 'DISTILLATION_COLUMN',
            status: 'RUNNING',
            throughputTonsPerHour: 52.0,
            targetThroughputTonsPerHour: 55.0,
            temperatureCelsius: 165.0,
            pressureBar: 0.85,
            powerUsageMW: 9.8,
            lastMaintenance: '2026-08-02'
          }
        ]
      }
    ]
  },
  {
    id: 'SITE-HULL',
    name: 'INEOS HULL ACETYLS & POLYMERS PLANT',
    locationCode: 'HULL',
    region: 'East Yorkshire',
    country: 'United Kingdom',
    coordinates: [53.744, -0.278],
    primaryOutputs: ['Acetic Acid', 'Acetic Anhydride', 'Solvent Blends', 'Polymer Compounds'],
    capacityTonsPerYear: 1250000,
    currentUtilizationPercent: 96.1,
    activeCampaignsCount: 5,
    energyPerTonneMWh: 1.35,
    co2ePerTonneKg: 320,
    status: 'OPTIMAL',
    laboratoriesCount: 3,
    tanksCount: 30,
    processAreas: [
      {
        id: 'AREA-HULL-ACET',
        siteId: 'SITE-HULL',
        name: 'Acetyls Synthesis & Catalytic Loop',
        description: 'Carbonylation reactors producing high-purity industrial acetyl compounds.',
        units: [
          {
            id: 'UNIT-HULL-CARB-01',
            areaId: 'AREA-HULL-ACET',
            code: 'CARB-HULL-01',
            name: 'Methanol Carbonylation Reactor A',
            type: 'REACTOR',
            status: 'RUNNING',
            throughputTonsPerHour: 42.0,
            targetThroughputTonsPerHour: 42.0,
            temperatureCelsius: 195.0,
            pressureBar: 32.0,
            powerUsageMW: 11.2,
            lastMaintenance: '2026-07-28'
          }
        ]
      }
    ]
  },
  {
    id: 'SITE-STANLOW',
    name: 'INEOS STANLOW LINK TERMINAL',
    locationCode: 'STANLOW_LINK',
    region: 'Cheshire',
    country: 'United Kingdom',
    coordinates: [53.275, -2.855],
    primaryOutputs: ['Feedstock Intermediates', 'Liquid Energy Transfer'],
    capacityTonsPerYear: 900000,
    currentUtilizationPercent: 85.0,
    activeCampaignsCount: 2,
    energyPerTonneMWh: 0.85,
    co2ePerTonneKg: 190,
    status: 'OPTIMAL',
    laboratoriesCount: 2,
    tanksCount: 24,
    processAreas: []
  },
  {
    id: 'SITE-SALTEND',
    name: 'INEOS SALT END LOGISTICS DEPOT',
    locationCode: 'SALT_END',
    region: 'East Yorkshire',
    country: 'United Kingdom',
    coordinates: [53.738, -0.241],
    primaryOutputs: ['Bulk Chemical Storage', 'Marine Export'],
    capacityTonsPerYear: 750000,
    currentUtilizationPercent: 82.5,
    activeCampaignsCount: 2,
    energyPerTonneMWh: 0.65,
    co2ePerTonneKg: 140,
    status: 'OPTIMAL',
    laboratoriesCount: 2,
    tanksCount: 18,
    processAreas: []
  },
  {
    id: 'SITE-IMMINGHAM',
    name: 'INEOS IMMINGHAM BULK TERMINAL',
    locationCode: 'IMMINGHAM',
    region: 'Lincolnshire',
    country: 'United Kingdom',
    coordinates: [53.626, -0.188],
    primaryOutputs: ['Caustic Soda Import/Export', 'Liquefied Gas Transfer'],
    capacityTonsPerYear: 1100000,
    currentUtilizationPercent: 89.0,
    activeCampaignsCount: 3,
    energyPerTonneMWh: 0.72,
    co2ePerTonneKg: 160,
    status: 'OPTIMAL',
    laboratoriesCount: 2,
    tanksCount: 28,
    processAreas: []
  },
  {
    id: 'SITE-FAWLEY',
    name: 'INEOS FAWLEY PIPELINE NODE',
    locationCode: 'FAWLEY_LINK',
    region: 'Hampshire',
    country: 'United Kingdom',
    coordinates: [50.835, -1.332],
    primaryOutputs: ['Ethylene Pipeline Junction', 'Specialty Feedstocks'],
    capacityTonsPerYear: 650000,
    currentUtilizationPercent: 91.5,
    activeCampaignsCount: 1,
    energyPerTonneMWh: 0.55,
    co2ePerTonneKg: 120,
    status: 'OPTIMAL',
    laboratoriesCount: 1,
    tanksCount: 12,
    processAreas: []
  }
];

// Additional synthetic sites to total 20 sites across the UK
const EXTRA_SITE_NAMES = [
  'INEOS CARRINGTON POLYMER SITE',
  'INEOS AVONMOUTH STORAGE TERMINAL',
  'INEOS WILTON INTERMEDIATES HUB',
  'INEOS BARRY SPECIALTY RESINS',
  'INEOS NEWPORT FORMULATIONS',
  'INEOS SEAL SANDS OLEFIN DEPOT',
  'INEOS LEVENMOUTH LOGISTICS PORT',
  'INEOS HUMBER MARINE TERMINAL',
  'INEOS MOUSEHOLE CHEMICAL DEPOT',
  'INEOS NORTH TEES PIPELINE JUNCTION',
  'INEOS SELLAFIELD PIPELINE HUB',
  'INEOS SEVERN ESTUARY BULK DEPOT'
];

EXTRA_SITE_NAMES.forEach((name, idx) => {
  SITES.push({
    id: `SITE-UK-${idx + 9}`,
    name,
    locationCode: 'TEESSIDE',
    region: 'United Kingdom Industrial Zone',
    country: 'United Kingdom',
    coordinates: [51.5 + (idx * 0.4), -3.5 + (idx * 0.3)],
    primaryOutputs: ['Specialty Solvents', 'Polymer Resins', 'Intermediates'],
    capacityTonsPerYear: 500000 + (idx * 50000),
    currentUtilizationPercent: 85 + (idx % 10),
    activeCampaignsCount: 2 + (idx % 3),
    energyPerTonneMWh: 1.1,
    co2ePerTonneKg: 240,
    status: 'OPTIMAL',
    laboratoriesCount: 2,
    tanksCount: 15 + idx,
    processAreas: []
  });
});

// ----------------------------------------------------
// 2. MATERIALS & GRADES
// ----------------------------------------------------
export const MATERIALS: ChemicalMaterial[] = [
  {
    id: 'MAT-CHLORINE',
    code: 'CHLORINE-LIQ',
    chemicalName: 'Liquefied Chlorine Gas',
    commonName: 'Chlorine',
    casNumber: '7782-50-5',
    family: 'BASE_CHEMICALS',
    physicalState: 'GAS',
    hazardClass: 'CLASS_8_CORROSIVE',
    densityGcm3: 1.56,
    boilingPointC: -34.04,
    flashPointC: null,
    viscosityCp: 0.35,
    purityPercentTarget: 99.9,
    standardShelfLifeDays: 365,
    defaultPackaging: 'Bulk Pipeline / Rail Tanker',
    storageRequirements: 'Pressurized Refrigerated Tank (-35°C, Dry Inconel)',
    currentInventoryTons: 14200,
    targetMinInventoryTons: 8000,
    costPerTonneGBP: 340,
    co2ePerTonneKg: 280
  },
  {
    id: 'MAT-CAUSTIC',
    code: 'CAUSTIC-50-UK',
    chemicalName: 'Sodium Hydroxide 50% Aqueous Solution',
    commonName: 'Caustic Soda',
    casNumber: '1310-73-2',
    family: 'BASE_CHEMICALS',
    physicalState: 'LIQUID',
    hazardClass: 'CLASS_8_CORROSIVE',
    densityGcm3: 1.52,
    boilingPointC: 142.0,
    flashPointC: null,
    viscosityCp: 78.0,
    purityPercentTarget: 50.0,
    standardShelfLifeDays: 730,
    defaultPackaging: 'Bulk Road Tanker / ISO Tank',
    storageRequirements: 'Thermally Trace-Heated Stainless Steel Tanks (25°C)',
    currentInventoryTons: 38500,
    targetMinInventoryTons: 20000,
    costPerTonneGBP: 480,
    co2ePerTonneKg: 310
  },
  {
    id: 'MAT-HCL',
    code: 'HCL-36-PURE',
    chemicalName: 'Hydrochloric Acid 36% Solution',
    commonName: 'Muriatic Acid / HCL',
    casNumber: '7647-01-0',
    family: 'BASE_CHEMICALS',
    physicalState: 'LIQUID',
    hazardClass: 'CLASS_8_CORROSIVE',
    densityGcm3: 1.18,
    boilingPointC: 108.5,
    flashPointC: null,
    viscosityCp: 1.9,
    purityPercentTarget: 36.0,
    standardShelfLifeDays: 365,
    defaultPackaging: 'IBC / Rubber-Lined Tanker',
    storageRequirements: 'FRP / Rubber-Lined Atmospheric Tanks',
    currentInventoryTons: 9400,
    targetMinInventoryTons: 5000,
    costPerTonneGBP: 220,
    co2ePerTonneKg: 180
  },
  {
    id: 'MAT-HYDROGEN',
    code: 'H2-GREEN-FUEL',
    chemicalName: 'Compressed Hydrogen Gas',
    commonName: 'Hydrogen',
    casNumber: '1333-74-0',
    family: 'BASE_CHEMICALS',
    physicalState: 'GAS',
    hazardClass: 'CLASS_3_FLAMMABLE',
    densityGcm3: 0.000089,
    boilingPointC: -252.87,
    flashPointC: null,
    viscosityCp: 0.008,
    purityPercentTarget: 99.999,
    standardShelfLifeDays: 9999,
    defaultPackaging: 'High Pressure Tube Trailer / Pipeline',
    storageRequirements: '350 Bar High-Pressure Storage Vessel',
    currentInventoryTons: 1250,
    targetMinInventoryTons: 400,
    costPerTonneGBP: 2100,
    co2ePerTonneKg: 45
  },
  {
    id: 'MAT-VCM',
    code: 'VCM-MONOMER',
    chemicalName: 'Vinyl Chloride Monomer',
    commonName: 'VCM Intermediate',
    casNumber: '75-01-4',
    family: 'INTERMEDIATES',
    physicalState: 'LIQUID',
    hazardClass: 'CLASS_2.2_COMPRESSED_GAS',
    densityGcm3: 0.91,
    boilingPointC: -13.4,
    flashPointC: -78.0,
    viscosityCp: 0.28,
    purityPercentTarget: 99.8,
    standardShelfLifeDays: 180,
    defaultPackaging: 'Pressurized Spherical Tank / Pipeline',
    storageRequirements: 'Chilled Pressurized Spheres (-10°C under Nitrogen)',
    currentInventoryTons: 18200,
    targetMinInventoryTons: 10000,
    costPerTonneGBP: 890,
    co2ePerTonneKg: 420
  },
  {
    id: 'MAT-PVC-RIGID',
    code: 'PVC-UK-042',
    chemicalName: 'Polyvinyl Chloride Polymer Compound',
    commonName: 'Rigid PVC Compound',
    casNumber: '9002-86-2',
    family: 'POLYMERS',
    physicalState: 'SOLID_PELLET',
    hazardClass: 'NON_HAZARDOUS',
    densityGcm3: 1.38,
    boilingPointC: 210.0,
    flashPointC: null,
    viscosityCp: 1.12,
    purityPercentTarget: 99.7,
    standardShelfLifeDays: 1095,
    defaultPackaging: 'Bulk Silo Truck / 1,000kg Octabin',
    storageRequirements: 'Dry Aerated Aluminum Silos',
    currentInventoryTons: 28400,
    targetMinInventoryTons: 12000,
    costPerTonneGBP: 1240,
    co2ePerTonneKg: 510
  },
  {
    id: 'MAT-HDPE',
    code: 'HDPE-RIGID-INOVENE',
    chemicalName: 'High Density Polyethylene Resin',
    commonName: 'HDPE Inovene Grade',
    casNumber: '9002-88-4',
    family: 'POLYMERS',
    physicalState: 'SOLID_PELLET',
    hazardClass: 'NON_HAZARDOUS',
    densityGcm3: 0.955,
    boilingPointC: 130.0,
    flashPointC: null,
    viscosityCp: 0.9,
    purityPercentTarget: 99.8,
    standardShelfLifeDays: 1095,
    defaultPackaging: '25kg Bags / Bulk Rail Car',
    storageRequirements: 'Ambient Clean Silo Storage',
    currentInventoryTons: 34100,
    targetMinInventoryTons: 15000,
    costPerTonneGBP: 1380,
    co2ePerTonneKg: 580
  },
  {
    id: 'MAT-ETHANOL',
    code: 'SOLVENT-ETOH-SYNTH',
    chemicalName: 'Synthetic Ethanol Pure',
    commonName: 'Industrial Ethanol',
    casNumber: '64-17-5',
    family: 'SOLVENTS',
    physicalState: 'LIQUID',
    hazardClass: 'CLASS_3_FLAMMABLE',
    densityGcm3: 0.789,
    boilingPointC: 78.37,
    flashPointC: 13.0,
    viscosityCp: 1.2,
    purityPercentTarget: 99.9,
    standardShelfLifeDays: 730,
    defaultPackaging: 'ISO Tank / Drums / Road Tanker',
    storageRequirements: 'Flameproof Stainless Steel Storage Tanks',
    currentInventoryTons: 11200,
    targetMinInventoryTons: 6000,
    costPerTonneGBP: 720,
    co2ePerTonneKg: 290
  }
];

export const GRADES: ChemicalGrade[] = [
  {
    id: 'GRADE-PVC-042',
    gradeCode: 'PVC-UK-042',
    materialId: 'MAT-PVC-RIGID',
    gradeName: 'Rigid Construction PVC Compound',
    application: 'UK Pipe & Fenestration Extrusion',
    targetPurityPercent: 99.7,
    minPurityPercent: 99.4,
    maxPurityPercent: 100.0,
    targetDensityGcm3: 1.38,
    targetViscosityCp: 1.12,
    maxMoisturePpm: 300,
    qualityStatus: 'APPROVED',
    pricePerTonneGBP: 1350,
    customerNameTarget: 'UK Infrastructure & Construction Customers',
    packagingOptions: ['Bulk Silo Truck', '1000kg Octabin', '25kg Bags']
  },
  {
    id: 'GRADE-CAUSTIC-RAYON',
    gradeCode: 'CAUSTIC-50-RAYON',
    materialId: 'MAT-CAUSTIC',
    gradeName: 'Rayon-Grade Ultra Pure Caustic 50%',
    application: 'Chemical Synthesis & Paper Pulping',
    targetPurityPercent: 50.1,
    minPurityPercent: 49.8,
    maxPurityPercent: 50.5,
    targetDensityGcm3: 1.52,
    targetViscosityCp: 78.0,
    maxMoisturePpm: 500000,
    qualityStatus: 'APPROVED',
    pricePerTonneGBP: 520,
    customerNameTarget: 'North West Paper & Chemicals PLC',
    packagingOptions: ['Bulk Road Tanker', 'ISO Tank']
  },
  {
    id: 'GRADE-HDPE-PIPE',
    gradeCode: 'HDPE-PE100-BLACK',
    materialId: 'MAT-HDPE',
    gradeName: 'PE100 Pressure Pipe Grade HDPE',
    application: 'Gas & Potable Water Distribution Mains',
    targetPurityPercent: 99.8,
    minPurityPercent: 99.5,
    maxPurityPercent: 100.0,
    targetDensityGcm3: 0.959,
    targetViscosityCp: 0.95,
    maxMoisturePpm: 200,
    qualityStatus: 'APPROVED',
    pricePerTonneGBP: 1480,
    customerNameTarget: 'British Utilities & Infrastructure Corp',
    packagingOptions: ['Bulk Silo Truck', '1000kg Octabin']
  }
];

// ----------------------------------------------------
// 3. TANKS & INVENTORY
// ----------------------------------------------------
export const TANKS: Tank[] = [
  {
    id: 'TANK-RUN-T204',
    siteId: 'SITE-RUNCORN',
    tankCode: 'T-204-CHLORINE',
    materialId: 'MAT-CHLORINE',
    materialName: 'Liquefied Chlorine Gas',
    currentLevelTons: 1850,
    capacityTons: 2500,
    fillPercentage: 74.0,
    temperatureCelsius: -33.8,
    pressureBar: 2.1,
    status: 'IN_SERVICE',
    qualityStatus: 'RELEASED',
    lastInspectionDate: '2026-08-10'
  },
  {
    id: 'TANK-RUN-T301',
    siteId: 'SITE-RUNCORN',
    tankCode: 'T-301-CAUSTIC',
    materialId: 'MAT-CAUSTIC',
    materialName: 'Caustic Soda 50%',
    currentLevelTons: 8200,
    capacityTons: 10000,
    fillPercentage: 82.0,
    temperatureCelsius: 24.5,
    pressureBar: 1.0,
    status: 'RECEIVING',
    qualityStatus: 'RELEASED',
    lastInspectionDate: '2026-07-15'
  },
  {
    id: 'TANK-GRA-SILO-01',
    siteId: 'SITE-GRANGEMOUTH',
    tankCode: 'SILO-GRA-401',
    materialId: 'MAT-HDPE',
    materialName: 'HDPE Resin Pellets',
    currentLevelTons: 4100,
    capacityTons: 5000,
    fillPercentage: 82.0,
    temperatureCelsius: 21.0,
    pressureBar: 1.02,
    status: 'DISPATCHING',
    qualityStatus: 'RELEASED',
    lastInspectionDate: '2026-08-01'
  },
  {
    id: 'TANK-TEE-T102',
    siteId: 'SITE-TEESSIDE',
    tankCode: 'T-102-VCM',
    materialId: 'MAT-VCM',
    materialName: 'Vinyl Chloride Monomer',
    currentLevelTons: 6400,
    capacityTons: 8000,
    fillPercentage: 80.0,
    temperatureCelsius: -8.5,
    pressureBar: 4.2,
    status: 'IN_SERVICE',
    qualityStatus: 'RELEASED',
    lastInspectionDate: '2026-06-20'
  },
  {
    id: 'TANK-HULL-T501',
    siteId: 'SITE-HULL',
    tankCode: 'T-501-ETOH',
    materialId: 'MAT-ETHANOL',
    materialName: 'Synthetic Ethanol Pure',
    currentLevelTons: 3100,
    capacityTons: 4500,
    fillPercentage: 68.8,
    temperatureCelsius: 18.2,
    pressureBar: 1.01,
    status: 'IN_SERVICE',
    qualityStatus: 'RELEASED',
    lastInspectionDate: '2026-08-14'
  }
];

// Add 15 extra tanks for realistic density
for (let i = 1; i <= 15; i++) {
  const mat = MATERIALS[i % MATERIALS.length];
  const cap = 2000 + (i * 500);
  const lvl = Math.floor(cap * (0.5 + (i % 4) * 0.1));
  TANKS.push({
    id: `TANK-GEN-${i}`,
    siteId: SITES[i % SITES.length].id,
    tankCode: `TK-${100 + i}`,
    materialId: mat.id,
    materialName: mat.commonName,
    currentLevelTons: lvl,
    capacityTons: cap,
    fillPercentage: Math.round((lvl / cap) * 100),
    temperatureCelsius: 15 + i,
    pressureBar: 1.0 + (i * 0.1),
    status: 'IN_SERVICE',
    qualityStatus: 'RELEASED',
    lastInspectionDate: '2026-08-01'
  });
}

// ----------------------------------------------------
// 4. BATCHES & DIGITAL THREAD PROVENANCE
// ----------------------------------------------------
export const BATCHES: Batch[] = [
  {
    id: 'BATCH-B26-09142',
    batchNumber: 'B26-09142',
    materialId: 'MAT-PVC-RIGID',
    gradeId: 'GRADE-PVC-042',
    campaignId: 'CAMP-RUN-091',
    siteId: 'SITE-RUNCORN',
    unitId: 'UNIT-CA-01',
    feedstockLotId: 'LOT-SALT-F-11920',
    quantityTons: 850,
    startTime: '2026-09-28T02:00:00Z',
    completionTime: '2026-09-28T20:00:00Z',
    status: 'RELEASED',
    qualityReleaseStatus: 'PASSED',
    storageTankId: 'TANK-RUN-T204',
    operatorShift: 'Shift Alpha (Chief Op: R. Davies)',
    recipeVersion: 'RECIPE-PVC-V4.2'
  },
  {
    id: 'BATCH-B26-09143',
    batchNumber: 'B26-09143',
    materialId: 'MAT-CAUSTIC',
    gradeId: 'GRADE-CAUSTIC-RAYON',
    campaignId: 'CAMP-RUN-092',
    siteId: 'SITE-RUNCORN',
    unitId: 'UNIT-CA-02',
    feedstockLotId: 'LOT-SALT-F-11922',
    quantityTons: 1200,
    startTime: '2026-09-28T06:00:00Z',
    completionTime: '2026-09-28T22:00:00Z',
    status: 'RELEASED',
    qualityReleaseStatus: 'PASSED',
    storageTankId: 'TANK-RUN-T301',
    operatorShift: 'Shift Beta (Chief Op: M. Jenkins)',
    recipeVersion: 'RECIPE-CAUSTIC-V3.1'
  },
  {
    id: 'BATCH-B26-09144',
    batchNumber: 'B26-09144',
    materialId: 'MAT-HDPE',
    gradeId: 'GRADE-HDPE-PIPE',
    campaignId: 'CAMP-GRA-104',
    siteId: 'SITE-GRANGEMOUTH',
    unitId: 'UNIT-HDPE-01',
    feedstockLotId: 'LOT-ETHANE-KG-881',
    quantityTons: 1500,
    startTime: '2026-09-27T12:00:00Z',
    completionTime: '2026-09-28T14:00:00Z',
    status: 'RELEASED',
    qualityReleaseStatus: 'PASSED',
    storageTankId: 'TANK-GRA-SILO-01',
    operatorShift: 'Shift Gamma (Chief Op: S. MacLeod)',
    recipeVersion: 'RECIPE-HDPE-PE100'
  }
];

// Generate synthetic batches to reach 40+ active records
for (let i = 1; i <= 35; i++) {
  const site = SITES[i % SITES.length];
  const mat = MATERIALS[i % MATERIALS.length];
  const grade = GRADES[i % GRADES.length];
  BATCHES.push({
    id: `BATCH-GEN-${i}`,
    batchNumber: `B26-09${150 + i}`,
    materialId: mat.id,
    gradeId: grade.id,
    campaignId: `CAMP-GEN-${i}`,
    siteId: site.id,
    unitId: `UNIT-GEN-${i}`,
    feedstockLotId: `LOT-FEED-${8800 + i}`,
    quantityTons: 400 + (i * 30),
    startTime: `2026-09-27T08:00:00Z`,
    completionTime: `2026-09-28T10:00:00Z`,
    status: i % 7 === 0 ? 'QUALITY_HOLD' : 'RELEASED',
    qualityReleaseStatus: i % 7 === 0 ? 'CONDITIONAL' : 'PASSED',
    storageTankId: TANKS[i % TANKS.length].id,
    operatorShift: `Shift ${['Alpha', 'Beta', 'Gamma'][i % 3]}`,
    recipeVersion: `RECIPE-${mat.code}-V1.0`
  });
}

// ----------------------------------------------------
// 5. LAB SAMPLES (LIMS)
// ----------------------------------------------------
export const SAMPLES: LabSample[] = [
  {
    id: 'SAMPLE-S-55120',
    sampleCode: 'S-55120',
    batchId: 'BATCH-B26-09142',
    materialId: 'MAT-PVC-RIGID',
    gradeId: 'GRADE-PVC-042',
    samplingLocation: 'Runcorn Unit CA-04 Dryer Outlet',
    timestamp: '2026-09-28T18:10:00Z',
    analyst: 'Dr. Evelyn Vance (Senior Quality Chemist)',
    measuredPurityPercent: 99.82,
    measuredDensityGcm3: 1.381,
    measuredViscosityCp: 1.122,
    measuredMoisturePpm: 180,
    measuredColorIndex: 0.12,
    status: 'PASS',
    notes: 'Exceeds target purity spec for fenestration extrusion.'
  },
  {
    id: 'SAMPLE-S-55121',
    sampleCode: 'S-55121',
    batchId: 'BATCH-B26-09143',
    materialId: 'MAT-CAUSTIC',
    gradeId: 'GRADE-CAUSTIC-RAYON',
    samplingLocation: 'Runcorn Cellroom 2 Header Pipe',
    timestamp: '2026-09-28T19:30:00Z',
    analyst: 'G. Thorne (Lab Analyst)',
    measuredPurityPercent: 50.12,
    measuredDensityGcm3: 1.522,
    measuredViscosityCp: 78.1,
    measuredMoisturePpm: 498000,
    measuredColorIndex: 0.05,
    status: 'PASS',
    notes: 'Rayon grade trace metals within safe thresholds.'
  }
];

// ----------------------------------------------------
// 6. ORDERS & LOGISTICS SHIPMENTS
// ----------------------------------------------------
export const ORDERS: Order[] = [
  {
    id: 'ORDER-UK-044',
    orderNumber: 'ORD-2026-8812',
    customerId: 'CUST-UK-044',
    customerName: 'UK Infrastructure & Fenestration PLC',
    customerLocation: 'Birmingham Distribution Centre, UK',
    materialId: 'MAT-PVC-RIGID',
    gradeId: 'GRADE-PVC-042',
    gradeCode: 'PVC-UK-042',
    quantityTons: 850,
    unitPriceGBP: 1350,
    totalValueGBP: 1147500,
    orderDate: '2026-09-25T10:00:00Z',
    requiredDeliveryDate: '2026-09-30T16:00:00Z',
    promisedDeliveryDate: '2026-09-29T18:00:00Z',
    fulfillmentType: 'MAKE_TO_STOCK',
    status: 'READY_TO_SHIP',
    assignedBatchId: 'BATCH-B26-09142'
  },
  {
    id: 'ORDER-UK-089',
    orderNumber: 'ORD-2026-8815',
    customerId: 'CUST-UK-089',
    customerName: 'Scottish Water & Utilities Authority',
    customerLocation: 'Glasgow Terminal, Scotland',
    materialId: 'MAT-HDPE',
    gradeId: 'GRADE-HDPE-PIPE',
    gradeCode: 'HDPE-PE100-BLACK',
    quantityTons: 1500,
    unitPriceGBP: 1480,
    totalValueGBP: 2220000,
    orderDate: '2026-09-26T08:30:00Z',
    requiredDeliveryDate: '2026-10-02T12:00:00Z',
    promisedDeliveryDate: '2026-10-01T15:00:00Z',
    fulfillmentType: 'MAKE_TO_ORDER',
    status: 'ALLOCATED',
    assignedBatchId: 'BATCH-B26-09144'
  }
];

export const SHIPMENTS: LogisticsShipment[] = [
  {
    id: 'SHIP-8821',
    shipmentNumber: 'SHP-UK-8821',
    orderId: 'ORDER-UK-044',
    customerName: 'UK Infrastructure & Fenestration PLC',
    materialName: 'Rigid PVC Compound',
    gradeCode: 'PVC-UK-042',
    batchId: 'BATCH-B26-09142',
    quantityTons: 850,
    originSiteId: 'SITE-RUNCORN',
    originName: 'INEOS RUNCORN SITE',
    destinationName: 'Birmingham Distribution Hub, UK',
    mode: 'ROAD_TANKER',
    carrier: 'INEOS Intermodal UK Logistics',
    vehicleVesselId: 'TRUCK 7812 / TANK-TRAILER T-88',
    status: 'IN_TRANSIT',
    departureTime: '2026-09-29T07:40:00Z',
    estimatedTimeArrival: '2026-09-29T15:20:00Z',
    driverVesselMaster: 'Capt. A. Miller',
    qualityCertificateAttached: true,
    gpsCoordinates: [52.486, -1.890]
  },
  {
    id: 'SHIP-8822',
    shipmentNumber: 'SHP-UK-8822',
    orderId: 'ORDER-UK-089',
    customerName: 'Scottish Water & Utilities Authority',
    materialName: 'PE100 Pressure Pipe Grade HDPE',
    gradeCode: 'HDPE-PE100-BLACK',
    batchId: 'BATCH-B26-09144',
    quantityTons: 1500,
    originSiteId: 'SITE-GRANGEMOUTH',
    originName: 'INEOS GRANGEMOUTH SITE',
    destinationName: 'Glasgow Rail Freight Depot',
    mode: 'RAIL_FREIGHT',
    carrier: 'GB Rail Freight Industrial',
    vehicleVesselId: 'LOCO-66102 / 24 WAGON BLOCK TRAIN',
    status: 'LOADING',
    departureTime: '2026-09-29T11:00:00Z',
    estimatedTimeArrival: '2026-09-29T20:00:00Z',
    driverVesselMaster: 'Driver J. Fraser',
    qualityCertificateAttached: true,
    gpsCoordinates: [55.953, -3.188]
  }
];

// ----------------------------------------------------
// 7. INDUSTRIAL EVENTS (IMMUTABLE EVENT STREAM)
// ----------------------------------------------------
export const EVENT_STREAM: IndustrialEvent[] = [
  {
    id: 'EVT-1001',
    timestamp: '2026-09-28T00:15:00Z',
    eventType: 'MaterialReceived',
    siteId: 'SITE-RUNCORN',
    objectId: 'LOT-SALT-F-11920',
    objectType: 'BATCH',
    actor: 'Logistics Intake Automated Pipeline',
    details: 'Received 2,400 tonnes of purified vacuum salt feedstock from Cheshire Salt Deposits.',
    severity: 'INFO'
  },
  {
    id: 'EVT-1002',
    timestamp: '2026-09-28T02:00:00Z',
    eventType: 'BatchStarted',
    siteId: 'SITE-RUNCORN',
    objectId: 'BATCH-B26-09142',
    objectType: 'BATCH',
    actor: 'Shift Lead R. Davies',
    details: 'Initiated Batch B26-09142 for PVC-UK-042 on Cellroom Line 1 under Recipe V4.2.',
    severity: 'INFO'
  },
  {
    id: 'EVT-1003',
    timestamp: '2026-09-28T18:10:00Z',
    eventType: 'SampleCreated',
    siteId: 'SITE-RUNCORN',
    objectId: 'SAMPLE-S-55120',
    objectType: 'SAMPLE',
    actor: 'AutoSampler Robot RUN-04',
    details: 'Extracted sample S-55120 at dryer exit and routed via pneumatic tube to Q-Lab 1.',
    severity: 'INFO'
  },
  {
    id: 'EVT-1004',
    timestamp: '2026-09-28T19:30:00Z',
    eventType: 'QualityResultRecorded',
    siteId: 'SITE-RUNCORN',
    objectId: 'SAMPLE-S-55120',
    objectType: 'SAMPLE',
    actor: 'Dr. Evelyn Vance',
    details: 'Recorded Purity 99.82%, Density 1.381g/cm3. Passed target specification.',
    severity: 'INFO'
  },
  {
    id: 'EVT-1005',
    timestamp: '2026-09-28T20:05:00Z',
    eventType: 'BatchReleased',
    siteId: 'SITE-RUNCORN',
    objectId: 'BATCH-B26-09142',
    objectType: 'BATCH',
    actor: 'Q-Lab Automated Release System',
    details: 'Quality clearance granted. Certificate of Analysis CoA-8812 signed digitally.',
    severity: 'INFO'
  },
  {
    id: 'EVT-1006',
    timestamp: '2026-09-28T22:15:00Z',
    eventType: 'InventoryMoved',
    siteId: 'SITE-RUNCORN',
    objectId: 'TANK-RUN-T204',
    objectType: 'TANK',
    actor: 'Pipeline Transfer Pump P-102',
    details: 'Transferred 850 tonnes from campaign run into pressurized holding tank T-204.',
    severity: 'INFO'
  },
  {
    id: 'EVT-1007',
    timestamp: '2026-09-29T07:40:00Z',
    eventType: 'ShipmentDispatched',
    siteId: 'SITE-RUNCORN',
    objectId: 'SHIP-8821',
    objectType: 'SHIPMENT',
    actor: 'Terminal Dispatch Operator H. Wright',
    details: 'Loaded TRUCK 7812 with 850t PVC-UK-042 bound for Birmingham Distribution Hub.',
    severity: 'INFO'
  }
];

// ----------------------------------------------------
// 8. COMMODITY MARKET PRICES
// ----------------------------------------------------
export const MARKET_PRICES: CommodityMarketPrice[] = [
  {
    id: 'MKT-01',
    materialCode: 'PVC-UK-042',
    materialName: 'Rigid PVC Compound',
    region: 'UK_DOMESTIC',
    referencePriceGBP: 1350,
    internalCostGBP: 940,
    marginPercent: 30.3,
    basisDescription: 'FD NW Europe Spot + UK Logistics Basis',
    priceChange24hPercent: 1.4
  },
  {
    id: 'MKT-02',
    materialCode: 'CAUSTIC-50-UK',
    materialName: 'Caustic Soda 50%',
    region: 'NORTH_WEST_EUROPE',
    referencePriceGBP: 480,
    internalCostGBP: 310,
    marginPercent: 35.4,
    basisDescription: 'NWE Liquid Spot Contract Index',
    priceChange24hPercent: -0.8
  },
  {
    id: 'MKT-03',
    materialCode: 'CHLORINE-LIQ',
    materialName: 'Liquefied Chlorine',
    region: 'UK_DOMESTIC',
    referencePriceGBP: 340,
    internalCostGBP: 220,
    marginPercent: 35.2,
    basisDescription: 'UK Integrated Chlor-Alkali Transfer Price',
    priceChange24hPercent: 0.0
  },
  {
    id: 'MKT-04',
    materialCode: 'HDPE-RIGID-INOVENE',
    materialName: 'HDPE Inovene Grade',
    region: 'GLOBAL_BENCHMARK',
    referencePriceGBP: 1380,
    internalCostGBP: 980,
    marginPercent: 28.9,
    basisDescription: 'ICIS NWE Polyethylene Marker',
    priceChange24hPercent: 2.1
  }
];

// ----------------------------------------------------
// 9. CORE BLENDING CALCULATION ENGINE
// ----------------------------------------------------
export function calculateBlendingProposal(
  targetGradeId: string,
  targetMassTons: number
): BlendingProposal {
  const grade = GRADES.find((g) => g.id === targetGradeId) || GRADES[0];
  const mat = MATERIALS.find((m) => m.id === grade.materialId) || MATERIALS[0];

  // Synthetic 4-component formulation blend balance
  const compA: number = Math.round(targetMassTons * 0.62);
  const compB: number = Math.round(targetMassTons * 0.24);
  const compC: number = Math.round(targetMassTons * 0.09);
  const compD: number = targetMassTons - compA - compB - compC;

  const totalCalc = compA + compB + compC + compD;

  const warnings: string[] = [];
  if (targetMassTons > 10000) {
    warnings.push('High tonnage blend request exceeds single batch blender vessel capacity. Multi-stage campaign required.');
  }

  const components = [
    {
      materialId: 'MAT-VCM',
      materialName: 'Vinyl Chloride Monomer Base Lot',
      targetPercentage: 62.0,
      proposedMassTons: compA,
      availableMassTons: 18200,
      lotId: 'LOT-VCM-F-991',
      qualityStatus: 'RELEASED' as const,
      costPerTonneGBP: 890,
      isCompatible: true
    },
    {
      materialId: 'MAT-CHLORINE',
      materialName: 'Chlorine Intermediate Liquid Lot',
      targetPercentage: 24.0,
      proposedMassTons: compB,
      availableMassTons: 14200,
      lotId: 'LOT-CHL-F-402',
      qualityStatus: 'RELEASED' as const,
      costPerTonneGBP: 340,
      isCompatible: true
    },
    {
      materialId: 'MAT-ETHANOL',
      materialName: 'Synthetic Ethanol Polymerization Aid',
      targetPercentage: 9.0,
      proposedMassTons: compC,
      availableMassTons: 11200,
      lotId: 'LOT-ETOH-F-112',
      qualityStatus: 'RELEASED' as const,
      costPerTonneGBP: 720,
      isCompatible: true
    },
    {
      materialId: 'MAT-SPEC-ADDITIVE',
      materialName: 'Impact Modifier & Thermal Stabilizer D',
      targetPercentage: 5.0,
      proposedMassTons: compD,
      availableMassTons: 3500,
      lotId: 'LOT-ADD-F-004',
      qualityStatus: 'RELEASED' as const,
      costPerTonneGBP: 2400,
      isCompatible: true
    }
  ];

  const totalCost = components.reduce((sum, c) => sum + (c.proposedMassTons * c.costPerTonneGBP), 0);

  return {
    targetGradeId: grade.id,
    targetGradeCode: grade.gradeCode,
    targetGradeName: grade.gradeName,
    targetMassTons,
    totalCalculatedMassTons: totalCalc,
    massBalanceValid: totalCalc === targetMassTons,
    components,
    totalCostGBP: totalCost,
    averageCostPerTonneGBP: Math.round(totalCost / targetMassTons),
    projectedPurityPercent: 99.78,
    warnings
  };
}

// ----------------------------------------------------
// 10. SCENARIO PROPAGATION ENGINE
// ----------------------------------------------------
export function runScenarioSimulation(
  affectedSiteId: string,
  capacityReductionPercent: number
): ScenarioResult {
  const site = SITES.find((s) => s.id === affectedSiteId) || SITES[0];
  const capacityLoss = Math.round((site.capacityTonsPerYear / 365) * (capacityReductionPercent / 100) * 14); // 14-day window impact
  const shortfall = Math.round(capacityLoss * 0.85);
  const inventoryDraw = Math.round(capacityLoss * 0.45);
  const ordersAtRisk = Math.ceil(capacityLoss / 650);
  const revenueRisk = Math.round(shortfall * 1350);

  return {
    scenarioId: `SCEN-OUTAGE-${Date.now()}`,
    capacityLossTons: capacityLoss,
    productionShortfallTons: shortfall,
    inventoryDrawTons: inventoryDraw,
    ordersAtRiskCount: ordersAtRisk,
    revenueRiskGBP: revenueRisk,
    mitigationRecommendation: `Reroute 35% feedstock to Grangemouth Olefin Line 2 and draw down 12,000t from Teesside Terminal buffer. Advance Campaign C-094 by 72 hours.`,
    affectedShipments: ['SHP-UK-8821', 'SHP-UK-8822', 'SHP-UK-8825']
  };
}
