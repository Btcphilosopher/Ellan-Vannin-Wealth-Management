import React, { useState, useEffect } from 'react';
import { NavigationTab, Site, Batch, ChemicalMaterial, ChemicalGrade, Tank, LogisticsShipment, Order } from './types/chem_os';
import { SITES, BATCHES, MATERIALS, GRADES, TANKS, SHIPMENTS, ORDERS } from './services/syntheticData';

import { Header } from './components/Header';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { OverviewView } from './components/OverviewView';
import { SitesDigitalTwinView } from './components/SitesDigitalTwinView';
import { MaterialMasterView } from './components/MaterialMasterView';
import { ProductionCampaignView } from './components/ProductionCampaignView';
import { BlendingEngineView } from './components/BlendingEngineView';
import { ProcessSimulatorView } from './components/ProcessSimulatorView';
import { QualityLabView } from './components/QualityLabView';
import { DigitalThreadView } from './components/DigitalThreadView';
import { TankFarmView } from './components/TankFarmView';
import { LogisticsTerminalView } from './components/LogisticsTerminalView';
import { OrdersSupplyDemandView } from './components/OrdersSupplyDemandView';
import { EnergyEnvironmentalView } from './components/EnergyEnvironmentalView';
import { CostMarketView } from './components/CostMarketView';
import { ControlRoomView } from './components/ControlRoomView';
import { ChemOsIntelligenceView } from './components/ChemOsIntelligenceView';
import { SignatureDemosView } from './components/SignatureDemosView';
import { EventStreamReplayView } from './components/EventStreamReplayView';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('OVERVIEW');
  const [selectedSiteId, setSelectedSiteId] = useState<string>('SITE-RUNCORN');
  const [selectedBatchId, setSelectedBatchId] = useState<string>('BATCH-B26-09142');

  const [sitesList, setSitesList] = useState<Site[]>(SITES);
  const [batchesList, setBatchesList] = useState<Batch[]>(BATCHES);
  const [isLiveStreaming, setIsLiveStreaming] = useState<boolean>(false);

  // SSE Telemetry Stream Listener
  useEffect(() => {
    let eventSource: EventSource | null = null;
    try {
      eventSource = new EventSource('/api/telemetry/stream');
      eventSource.onopen = () => setIsLiveStreaming(true);
      eventSource.onmessage = (e) => {
        // SSE live telemetry tick received
        setIsLiveStreaming(true);
      };
      eventSource.onerror = () => setIsLiveStreaming(false);
    } catch (err) {
      setIsLiveStreaming(false);
    }

    return () => {
      if (eventSource) eventSource.close();
    };
  }, []);

  const handleResetData = () => {
    setSitesList(SITES);
    setBatchesList(BATCHES);
    setSelectedSiteId('SITE-RUNCORN');
    setSelectedBatchId('BATCH-B26-09142');
  };

  const handleLaunchDemo = (tab: NavigationTab, demoId: number) => {
    if (demoId === 1) setSelectedSiteId('SITE-RUNCORN');
    if (demoId === 2) setSelectedBatchId('BATCH-B26-09142');
    if (demoId === 5) setSelectedBatchId('BATCH-B26-09142');
    setActiveTab(tab);
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans antialiased">
      {/* Disclaimer Banner */}
      <DisclaimerBanner />

      {/* Main Header Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isLiveStreaming={isLiveStreaming}
        onResetData={handleResetData}
        onOpenDemo={() => setActiveTab('DEMOS')}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'OVERVIEW' && (
          <OverviewView
            sites={sitesList}
            batches={batchesList}
            onSelectSite={(id) => {
              setSelectedSiteId(id);
              setActiveTab('SITES');
            }}
            onSelectBatch={(id) => {
              setSelectedBatchId(id);
              setActiveTab('DIGITAL_THREAD');
            }}
          />
        )}

        {activeTab === 'SITES' && (
          <SitesDigitalTwinView
            sites={sitesList}
            selectedSiteId={selectedSiteId}
            onSelectSite={setSelectedSiteId}
          />
        )}

        {activeTab === 'MATERIALS' && (
          <MaterialMasterView materials={MATERIALS} grades={GRADES} />
        )}

        {activeTab === 'CAMPAIGN' && <ProductionCampaignView />}

        {activeTab === 'BLENDING' && <BlendingEngineView grades={GRADES} />}

        {activeTab === 'SIMULATOR' && <ProcessSimulatorView />}

        {activeTab === 'QUALITY' && <QualityLabView />}

        {activeTab === 'DIGITAL_THREAD' && (
          <DigitalThreadView
            batches={batchesList}
            selectedBatchId={selectedBatchId}
            onSelectBatch={setSelectedBatchId}
          />
        )}

        {activeTab === 'TANKS' && <TankFarmView tanks={TANKS} />}

        {activeTab === 'LOGISTICS' && <LogisticsTerminalView shipments={SHIPMENTS} />}

        {activeTab === 'ORDERS' && <OrdersSupplyDemandView orders={ORDERS} />}

        {activeTab === 'ENERGY' && <EnergyEnvironmentalView />}

        {activeTab === 'COST_MARKET' && <CostMarketView />}

        {activeTab === 'CONTROL_ROOM' && <ControlRoomView />}

        {activeTab === 'INTELLIGENCE' && <ChemOsIntelligenceView />}

        {activeTab === 'DEMOS' && <SignatureDemosView onLaunchDemo={handleLaunchDemo} />}

        {activeTab === 'EVENTS' && <EventStreamReplayView />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800/80 px-4 py-3 text-xs font-mono text-slate-500 mt-12">
        <div className="max-w-[1700px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>INEOS CHEM.OS · Synthetic Industrial Operating System Prototype</div>
          <div>FEEDSTOCK → PROCESS → QUALITY → INVENTORY → LOGISTICS → CUSTOMER</div>
        </div>
      </footer>
    </div>
  );
}
