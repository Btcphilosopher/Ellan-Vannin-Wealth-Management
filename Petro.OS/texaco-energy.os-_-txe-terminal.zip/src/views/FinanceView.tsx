/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Finance.OS & Capital Allocation View
 */

import React from 'react';
import { DataProvenance } from '../types';
import {
  SYNTHETIC_FINANCIALS,
  SYNTHETIC_CAPITAL_PROJECTS,
} from '../data/syntheticData';
import { getMetricProvenance } from '../services/simulationEngine';
import { DollarSign, Briefcase, Layers, Clock, TrendingUp } from 'lucide-react';

interface FinanceViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
}

export const FinanceView: React.FC<FinanceViewProps> = ({ onInspectDataLineage }) => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-amber-400" /> FINANCE.OS & CAPITAL ALLOCATION
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            General Ledger, Working Capital & 13-Week Cash Forecast
          </h1>
          <p className="text-xs text-slate-400">
            Cash Conversion Cycle (CCC) · Inventory Valuation · Capital Project NPV/IRR Engine
          </p>
        </div>
      </div>

      {/* 1. WORKING CAPITAL & CASH CONVERSION CYCLE */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-emerald-400" />
            WORKING CAPITAL & CASH CONVERSION CYCLE (CCC)
          </h3>
          <span className="text-xs font-mono text-emerald-400">CCC = DSO + DIO - DPO</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 font-mono text-xs">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">DSO (DAYS SALES OUTSTANDING)</span>
            <div className="text-2xl font-bold text-slate-200 mt-1">
              {SYNTHETIC_FINANCIALS.dsoDays} Days
            </div>
            <span className="text-[10px] text-slate-400">Accounts Receivable</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">DIO (DAYS INVENTORY OUTSTANDING)</span>
            <div className="text-2xl font-bold text-amber-400 mt-1">
              {SYNTHETIC_FINANCIALS.dioDays} Days
            </div>
            <span className="text-[10px] text-slate-400">Crude & Finished Goods</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">DPO (DAYS PAYABLE OUTSTANDING)</span>
            <div className="text-2xl font-bold text-cyan-400 mt-1">
              {SYNTHETIC_FINANCIALS.dpoDays} Days
            </div>
            <span className="text-[10px] text-slate-400">Supplier Payables</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">CASH CONVERSION CYCLE</span>
            <div className="text-2xl font-bold text-emerald-400 mt-1">
              {SYNTHETIC_FINANCIALS.cashConversionCycleDays} Days
            </div>
            <span className="text-[10px] text-slate-400">Net Working Capital Efficiency</span>
          </div>
        </div>
      </div>

      {/* 2. 13-WEEK CASH FORECAST VISUAL STREAM */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Clock className="w-4 h-4 text-purple-400" />
            13-WEEK CASH LIQUIDITY FORECAST (£ MILLIONS)
          </h3>
          <span className="text-xs font-mono text-purple-400">SAP S/4HANA TREASURY SYNC</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-7 lg:grid-cols-13 gap-2 font-mono text-xs text-center">
          {SYNTHETIC_FINANCIALS.thirteenWeekCashForecastGbp.map((cashVal, idx) => (
            <div key={idx} className="p-2.5 bg-slate-950 rounded border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-500 uppercase">WK {idx + 1}</span>
              <div className="font-bold text-emerald-400">£{cashVal}M</div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. CAPITAL ALLOCATION & PROJECT ECONOMICS */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Layers className="w-4 h-4 text-amber-400" />
            MAJOR CAPITAL PROJECTS ECONOMICS (CAPITAL.OS)
          </h3>
          <span className="text-xs font-mono text-amber-400">NPV / IRR DISCOUNTED CASH FLOW ENGINE</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          {SYNTHETIC_CAPITAL_PROJECTS.map((prj) => (
            <div key={prj.id} className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <div className="flex justify-between items-start border-b border-slate-800 pb-2">
                <div>
                  <div className="font-bold text-white text-sm">{prj.name}</div>
                  <div className="text-slate-500 text-[11px]">{prj.category}</div>
                </div>
                <span className="px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded font-bold">
                  {prj.status}
                </span>
              </div>

              <div className="space-y-1.5 text-slate-300">
                <div className="flex justify-between">
                  <span>CAPEX Budget:</span>
                  <strong className="text-white">£{(prj.capexBudgetGbp / 1e6).toFixed(0)}M</strong>
                </div>
                <div className="flex justify-between">
                  <span>Spent to Date:</span>
                  <strong className="text-slate-400">£{(prj.spentToDateGbp / 1e6).toFixed(0)}M</strong>
                </div>
                <div className="flex justify-between">
                  <span>Project NPV:</span>
                  <strong className="text-emerald-400">£{(prj.npvGbp / 1e6).toFixed(0)}M</strong>
                </div>
                <div className="flex justify-between">
                  <span>IRR / Payback:</span>
                  <strong className="text-amber-400">{prj.irrPercent}% / {prj.paybackYears} yrs</strong>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
