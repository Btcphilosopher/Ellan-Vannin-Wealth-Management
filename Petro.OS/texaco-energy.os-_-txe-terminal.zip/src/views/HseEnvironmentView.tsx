/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * HSE.OS, Environment.OS & Cyber.OS View
 */

import React from 'react';
import { DataProvenance } from '../types';
import { SYNTHETIC_HSE_EVENTS } from '../data/syntheticData';
import { ShieldAlert, Leaf, Lock, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';

interface HseEnvironmentViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
}

export const HseEnvironmentView: React.FC<HseEnvironmentViewProps> = () => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400" /> HSE.OS, ENVIRONMENT.OS & CYBER.OS
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Process Safety Systems, Carbon Cost Integration & OT Security
          </h1>
          <p className="text-xs text-slate-400">
            Safety Instrumented Systems (SIS/ESD) · Emissions Intensity per Barrel · Cyber OT Gateways
          </p>
        </div>
      </div>

      {/* 1. PROCESS SAFETY & HSE INCIDENT TRACKER */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-emerald-400" />
            PROCESS SAFETY & INCIDENT LOG (HSE.OS)
          </h3>
          <span className="text-xs font-mono text-emerald-400">SAFETY OUTRANKS PRODUCTION OPTIMISATION</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
          {SYNTHETIC_HSE_EVENTS.map((evt) => (
            <div key={evt.id} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <span className="font-bold text-white">{evt.facility}</span>
                <span
                  className={`px-2 py-0.5 rounded font-bold ${
                    evt.severity === 'NEAR_MISS'
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  }`}
                >
                  {evt.severity}
                </span>
              </div>
              <div className="text-slate-300">{evt.description}</div>
              <div className="text-slate-400">Action: <strong className="text-slate-200">{evt.actionTaken}</strong></div>
              <div className="flex justify-between items-center text-[10px] text-slate-500 pt-1">
                <span>Type: {evt.type}</span>
                <span>Time: {new Date(evt.timestamp).toLocaleTimeString()}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. ENVIRONMENT.OS CARBON ECONOMICS */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Leaf className="w-4 h-4 text-emerald-400" />
            ENVIRONMENT.OS — CARBON ECONOMICS & EMISSIONS INTENSITY
          </h3>
          <span className="text-xs font-mono text-emerald-400">EUA €85/TON CARBON PRICE INTEGRATED IN LP</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 font-mono text-xs">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">DAILY CO2 EMISSIONS</span>
            <div className="text-2xl font-bold text-slate-100 mt-1">4,820 Tonnes</div>
            <span className="text-[10px] text-slate-400">Pembroke Refinery Complex</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">CARBON COST / DAY</span>
            <div className="text-2xl font-bold text-amber-400 mt-1">$385,000 / day</div>
            <span className="text-[10px] text-slate-400">Incorporated into Net Margin</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">EMISSIONS / BARREL</span>
            <div className="text-2xl font-bold text-emerald-400 mt-1">19.4 kg CO2 / bbl</div>
            <span className="text-[10px] text-slate-400">Top Quartile European Efficiency</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">FLARE ACTIVITY</span>
            <div className="text-2xl font-bold text-cyan-400 mt-1">0.02 % of Run</div>
            <span className="text-[10px] text-slate-400">Closed Flare Recovery Active</span>
          </div>
        </div>
      </div>

      {/* 3. CYBER.OS OT / IT ARCHITECTURE */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Lock className="w-4 h-4 text-purple-400" />
            CYBER.OS — INDUSTRIAL OT / IT NETWORK SECURITY
          </h3>
          <span className="text-xs text-purple-400">AIR-GAPPED CONTROLLED GATEWAY</span>
        </div>

        <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-slate-300">
          <div>• <strong>Network Segmentation:</strong> Enterprise IT → Air-Gapped Gateway → Industrial Data Platform → OT Network (DCS / PLC / SCADA).</div>
          <div>• <strong>Anomalies Status:</strong> 0 Unauthorized privilege escalations detected in last 24h.</div>
          <div>• <strong>Safety Instrumented System (SIS):</strong> Independent physical relay logic isolated from digital network layers.</div>
        </div>
      </div>
    </div>
  );
};
