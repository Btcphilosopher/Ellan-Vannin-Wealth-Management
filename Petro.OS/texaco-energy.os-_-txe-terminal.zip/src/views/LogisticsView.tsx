/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Terminal.OS & Pipeline.OS Logistics View
 */

import React from 'react';
import { DataProvenance } from '../types';
import {
  SYNTHETIC_STORAGE_TANKS,
  SYNTHETIC_PIPELINES,
  SYNTHETIC_BATCHES,
} from '../data/syntheticData';
import { getMetricProvenance } from '../services/simulationEngine';
import { Warehouse, GitMerge, ShieldCheck, Clock, CheckCircle2 } from 'lucide-react';

interface LogisticsViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
}

export const LogisticsView: React.FC<LogisticsViewProps> = ({ onInspectDataLineage }) => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Header Banner with Pipeline & Terminal Image Asset */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900">
        <img
          src="/src/assets/images/pipeline_terminal_hub_1793028983782.jpg"
          alt="Pipeline & Terminal Hub"
          referrerPolicy="no-referrer"
          className="w-full h-44 object-cover opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent p-6 flex flex-col justify-end">
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <Warehouse className="w-4 h-4 text-amber-400" />
            TERMINAL.OS & PIPELINE.OS LOGISTICS NETWORK
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Storage Tank Farms, Mainline Pipelines & Batch Chain-of-Custody
          </h1>
          <p className="text-xs text-slate-300">
            Thames, Manchester & Dublin Import Terminals · Midlands Pipeline Trunk · Batch QC Certification
          </p>
        </div>
      </div>

      {/* 1. TANK FARM STORAGE MONITORING */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Warehouse className="w-4 h-4 text-amber-400" />
            STORAGE TANK FARM MONITORING & ULLAGE
          </h3>
          <span className="text-xs font-mono text-slate-400">TELEMETRY: RADAR LEVEL GAUGES</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          {SYNTHETIC_STORAGE_TANKS.map((tank) => {
            const fillPct = ((tank.currentLevelBbl / tank.capacityBbl) * 100).toFixed(1);
            return (
              <div
                key={tank.id}
                onClick={() =>
                  onInspectDataLineage(
                    `Tank ${tank.tankNumber}`,
                    `${tank.currentLevelBbl.toLocaleString()} bbl`,
                    getMetricProvenance('refineryThroughput')
                  )
                }
                className="p-4 bg-slate-950 rounded-xl border border-slate-800 hover:border-slate-700 cursor-pointer space-y-3 transition-colors"
              >
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <span className="font-bold text-white">{tank.tankNumber}</span>
                  <span className="text-amber-400 font-bold">{tank.product}</span>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>FILL LEVEL: {fillPct}%</span>
                    <span>ULLAGE: {tank.ullageBbl.toLocaleString()} bbl</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-amber-500 h-2 rounded-full"
                      style={{ width: `${fillPct}%` }}
                    ></div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400 pt-1">
                  <div>
                    TEMP / DENSITY: <span className="text-slate-200">{tank.temperatureC}°C / {tank.densityKgM3}</span>
                  </div>
                  <div>
                    DAYS COVER: <span className="text-emerald-400 font-bold">{tank.daysOfCover} Days</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. PIPELINE SEGMENTS & BATCH TRACKING */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* PIPELINE SEGMENTS */}
        <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2 border-b border-slate-800 pb-3">
            <GitMerge className="w-4 h-4 text-purple-400" />
            PIPELINE TRUNK SEGMENTS (PIPELINE.OS)
          </h3>

          <div className="space-y-3 font-mono text-xs">
            {SYNTHETIC_PIPELINES.map((pipe) => (
              <div key={pipe.id} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <span className="font-bold text-white">{pipe.name}</span>
                  <span className="text-emerald-400 font-bold">{pipe.currentFlowBph} BPH</span>
                </div>
                <div className="text-slate-400">Route: {pipe.origin} → {pipe.destination} ({pipe.lengthMiles} miles)</div>
                <div className="text-slate-400">Active Batch: <strong className="text-amber-400">{pipe.activeBatchProduct} ({pipe.activeBatchId})</strong></div>
                <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1">
                  <span>Pressure: {pipe.operatingPressurePsi} PSI</span>
                  <span>Transmix Interface: {pipe.interfaceTransmixBbl} bbl</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* BATCH CHAIN OF CUSTODY */}
        <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2 border-b border-slate-800 pb-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            BATCH CHAIN-OF-CUSTODY RECORDS
          </h3>

          <div className="space-y-3 font-mono text-xs">
            {SYNTHETIC_BATCHES.map((batch) => (
              <div key={batch.batchId} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <span className="font-bold text-amber-400">{batch.batchId}</span>
                  <span className="text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded">
                    {batch.status}
                  </span>
                </div>
                <div className="text-slate-200 font-bold">{batch.product} ({batch.volumeBbl.toLocaleString()} bbl)</div>
                <div className="text-slate-400">Custody Owner: {batch.custodyOwner}</div>
                <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1">
                  <span>QC Cert: <strong className="text-slate-300">{batch.qualityCertificateNo}</strong></span>
                  <span>Time: {new Date(batch.timestamp).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
