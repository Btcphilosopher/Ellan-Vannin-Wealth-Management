/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Maintenance.OS & Turnaround.OS View
 */

import React from 'react';
import { DataProvenance } from '../types';
import { SYNTHETIC_REFINERY_UNITS } from '../data/syntheticData';
import { getMetricProvenance } from '../services/simulationEngine';
import { Wrench, Calendar, Activity, CheckCircle2, AlertTriangle } from 'lucide-react';

interface MaintenanceViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
}

export const MaintenanceView: React.FC<MaintenanceViewProps> = () => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <Wrench className="w-4 h-4 text-amber-400" /> MAINTENANCE.OS & TURNAROUND.OS
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Asset Lifecycle, Turnaround Management & Predictive Telemetry
          </h1>
          <p className="text-xs text-slate-400">
            Pembroke CDU Unit #2 Planned Shutdown · Vibration & Corrosion Predictive Engineering
          </p>
        </div>
      </div>

      {/* 1. TURNAROUND MANAGEMENT DASHBOARD */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Calendar className="w-4 h-4 text-amber-400" />
            TURNAROUND PROGRESS: DAY 43 OF 71 (PEMBROKE COMPLEX)
          </h3>
          <span className="text-xs font-mono text-amber-400">ON SCHEDULE & WITHIN BUDGET</span>
        </div>

        <div className="space-y-2 font-mono text-xs">
          <div className="flex justify-between text-slate-400">
            <span>TURNAROUND COMPLETION PROGRESS: 60.5%</span>
            <span>CRITICAL PATH: CDU #2 COLUMN DESCALING</span>
          </div>
          <div className="w-full bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-800">
            <div className="bg-amber-500 h-3 rounded-full" style={{ width: '60.5%' }}></div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 font-mono text-xs pt-2">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">CONTRACTORS ON SITE</span>
            <div className="text-2xl font-bold text-white mt-1">420 Technicians</div>
            <span className="text-[10px] text-slate-400">Zero LTI Incidents</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">WORK ORDERS COMPLETED</span>
            <div className="text-2xl font-bold text-emerald-400 mt-1">1,840 / 2,980</div>
            <span className="text-[10px] text-slate-400">61.7% Executed</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">TURNAROUND BUDGET</span>
            <div className="text-2xl font-bold text-slate-200 mt-1">£42.5M Spent</div>
            <span className="text-[10px] text-slate-400">Out of £68.0M Total Budget</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">RESTART TARGET DATE</span>
            <div className="text-2xl font-bold text-amber-400 mt-1">24 NOV 2026</div>
            <span className="text-[10px] text-slate-400">Commissioning Sequence Ready</span>
          </div>
        </div>
      </div>

      {/* 2. PREDICTIVE MAINTENANCE TELEMETRY */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            PREDICTIVE MAINTENANCE ENGINEERING TELEMETRY
          </h3>
          <span className="text-xs font-mono text-emerald-400">AI PROBABILITY OF FAILURE ESTIMATES</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs">
          {SYNTHETIC_REFINERY_UNITS.map((unit) => (
            <div key={unit.id} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <span className="font-bold text-white">{unit.name}</span>
                <span className="text-amber-400 font-bold">{unit.code}</span>
              </div>
              <div className="text-slate-400">Vibration: <strong className="text-slate-200">{unit.vibrationMmS} mm/s</strong> (Limit: 4.5 mm/s)</div>
              <div className="text-slate-400">Corrosion Rate: <strong className="text-slate-200">{unit.corrosionRateMmYr} mm/yr</strong></div>
              <div className="text-slate-400">Catalyst Health: <strong className="text-emerald-400">{unit.catalystHealthPercent}%</strong></div>
              <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-800 flex justify-between">
                <span>Estimated Failure Prob:</span>
                <strong className="text-emerald-400">0.08 % / 30d</strong>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
