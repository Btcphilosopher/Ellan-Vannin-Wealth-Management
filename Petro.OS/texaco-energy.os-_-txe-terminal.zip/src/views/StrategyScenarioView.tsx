/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Strategy.OS, Scenario Engine & Monte Carlo Simulation View
 */

import React, { useState } from 'react';
import { DataProvenance, ScenarioInput } from '../types';
import { runMonteCarloSimulation } from '../services/simulationEngine';
import { Sliders, Play, TrendingUp, Layers, RefreshCw } from 'lucide-react';

interface StrategyScenarioViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
}

export const StrategyScenarioView: React.FC<StrategyScenarioViewProps> = () => {
  const [scenario, setScenario] = useState<ScenarioInput>({
    brentPriceDeltaUsd: 20,
    gasolineCrackDeltaUsd: 0,
    dieselCrackDeltaUsd: -10,
    refineryOutageDays: 0,
    evAdoptionSpeedMultiplier: 1.5,
    carbonPriceEurTon: 170,
    fxGbpUsdRate: 1.28,
  });

  const [monteCarlo, setMonteCarlo] = useState(() =>
    runMonteCarloSimulation(100000, scenario)
  );

  const handleRunSimulation = () => {
    const updated = runMonteCarloSimulation(100000, scenario);
    setMonteCarlo(updated);
  };

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" /> STRATEGY.OS & MONTE CARLO SCENARIO ENGINE
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            5–20 Year Strategic Energy Transition & 100,000 Monte Carlo Simulations
          </h1>
          <p className="text-xs text-slate-400">
            Compare KEEP vs OPTIMISE vs TRANSFORM Strategies · Carbon Doubling & EV Acceleration Stress Testing
          </p>
        </div>
      </div>

      {/* 1. SCENARIO CONTROLS */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            STRESS TEST SCENARIO PARAMETERS
          </h3>
          <button
            onClick={handleRunSimulation}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold font-mono rounded-lg transition-colors flex items-center gap-2 shadow-lg shadow-amber-500/20"
          >
            <RefreshCw className="w-3.5 h-3.5" /> RUN 100,000 MONTE CARLO SIMULATIONS
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs">
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>BRENT PRICE SHIFT</span>
              <span className="text-amber-400 font-bold">+${scenario.brentPriceDeltaUsd}/bbl</span>
            </div>
            <input
              type="range"
              min="-40"
              max="60"
              step="5"
              value={scenario.brentPriceDeltaUsd}
              onChange={(e) => setScenario({ ...scenario, brentPriceDeltaUsd: parseFloat(e.target.value) })}
              className="w-full accent-amber-500"
            />
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>DIESEL CRACK SHIFT</span>
              <span className="text-cyan-400 font-bold">${scenario.dieselCrackDeltaUsd}/bbl</span>
            </div>
            <input
              type="range"
              min="-20"
              max="20"
              step="2"
              value={scenario.dieselCrackDeltaUsd}
              onChange={(e) => setScenario({ ...scenario, dieselCrackDeltaUsd: parseFloat(e.target.value) })}
              className="w-full accent-cyan-500"
            />
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>CARBON PRICE (EUA)</span>
              <span className="text-purple-400 font-bold">€{scenario.carbonPriceEurTon}/ton</span>
            </div>
            <input
              type="range"
              min="85"
              max="250"
              step="5"
              value={scenario.carbonPriceEurTon}
              onChange={(e) => setScenario({ ...scenario, carbonPriceEurTon: parseFloat(e.target.value) })}
              className="w-full accent-purple-500"
            />
          </div>
        </div>
      </div>

      {/* 2. MONTE CARLO RESULTS DISTRIBUTION */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            100,000 MONTE CARLO PROBABILITY RESULTS
          </h3>
          <span className="text-xs font-mono text-emerald-400">RUST SIMULATION ACCELERATION</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 font-mono text-xs">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">SIMULATION COUNT</span>
            <div className="text-2xl font-bold text-white mt-1">100,000</div>
            <span className="text-[10px] text-slate-400">Full Variance Sampling</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">MEAN GROUP EBITDA</span>
            <div className="text-2xl font-bold text-amber-400 mt-1">
              £{(monteCarlo.ebitdaMeanGbp / 1e9).toFixed(2)}B
            </div>
            <span className="text-[10px] text-slate-400">Scenario Mean</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">5TH PERCENTILE (DOWNSIDE)</span>
            <div className="text-2xl font-bold text-red-400 mt-1">
              £{(monteCarlo.ebitda5thPercentileGbp / 1e9).toFixed(2)}B
            </div>
            <span className="text-[10px] text-slate-400">Stress Tail Risk</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">95TH PERCENTILE (UPSIDE)</span>
            <div className="text-2xl font-bold text-emerald-400 mt-1">
              £{(monteCarlo.ebitda95thPercentileGbp / 1e9).toFixed(2)}B
            </div>
            <span className="text-[10px] text-slate-400">Market Rally Upper Limit</span>
          </div>
        </div>
      </div>

      {/* 3. STRATEGIC TRANSITION PATHWAY COMPARISON */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white font-mono flex items-center gap-2 border-b border-slate-800 pb-3">
          <Layers className="w-4 h-4 text-cyan-400" />
          STRATEGIC TRANSITION PATHWAY COMPARISON (KEEP VS OPTIMISE VS TRANSFORM)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <span className="font-bold text-slate-400 text-sm">1. KEEP (BASELINE)</span>
            <div className="text-slate-300">Maintain legacy hydrocarbon refining asset mix.</div>
            <div className="pt-2 text-slate-400">10-Yr Expected ROIC: <strong className="text-white">12.1%</strong></div>
            <div className="text-slate-400">Carbon Liability Risk: <strong className="text-red-400">HIGH</strong></div>
          </div>

          <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-2 border-amber-500/30">
            <span className="font-bold text-amber-400 text-sm">2. OPTIMISE (RECOMMENDED)</span>
            <div className="text-slate-300">Energy efficiency, co-processing SAF & EV forecourt hubs.</div>
            <div className="pt-2 text-slate-400">10-Yr Expected ROIC: <strong className="text-amber-400">16.4%</strong></div>
            <div className="text-slate-400">Carbon Liability Risk: <strong className="text-emerald-400">BALANCED</strong></div>
          </div>

          <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <span className="font-bold text-cyan-400 text-sm">3. TRANSFORM</span>
            <div className="text-slate-300">Rapid conversion to green hydrogen & full electric mobility.</div>
            <div className="pt-2 text-slate-400">10-Yr Expected ROIC: <strong className="text-white">14.2%</strong></div>
            <div className="text-slate-400">Capex Intensity: <strong className="text-amber-400">VERY HIGH</strong></div>
          </div>
        </div>
      </div>
    </div>
  );
};
