/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Fleet.OS & Aviation.OS Commercial View
 */

import React from 'react';
import { DataProvenance } from '../types';
import {
  SYNTHETIC_FLEET_ACCOUNTS,
  SYNTHETIC_AVIATION_DELIVERIES,
} from '../data/syntheticData';
import { CreditCard, Plane, ShieldCheck, CheckCircle2, AlertTriangle } from 'lucide-react';

interface FleetAviationViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
}

export const FleetAviationView: React.FC<FleetAviationViewProps> = () => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Top Banner */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-amber-400" /> FLEET.OS & AVIATION.OS COMMERCIAL OPERATIONS
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Corporate Fuel Cards & Airport Aviation Supply Chains
          </h1>
          <p className="text-xs text-slate-400">
            4,000 Corporate Fleets · Heathrow / Gatwick Jet A-1 Quality Certification Engine
          </p>
        </div>
      </div>

      {/* 1. FLEET.OS CORPORATE FUEL CARDS */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-amber-400" />
            FLEET FUEL CARDS & CREDIT MANAGEMENT (FLEET.OS)
          </h3>
          <span className="text-xs font-mono text-slate-400">4,000 ACTIVE CORPORATE ACCOUNTS</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
          {SYNTHETIC_FLEET_ACCOUNTS.map((flt) => (
            <div key={flt.accountId} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <span className="font-bold text-white text-sm">{flt.companyName}</span>
                <span className="text-amber-400 font-bold">{flt.activeCards} Active Cards</span>
              </div>
              <div className="text-slate-400">Credit Limit: <strong className="text-slate-200">£{flt.monthlyCreditLimitGbp.toLocaleString()} / mo</strong></div>
              <div className="text-slate-400">Current Spend: <strong className="text-emerald-400">£{flt.currentSpendGbp.toLocaleString()}</strong></div>
              <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1">
                <span>Monthly Volume: {flt.volumeLitresMonth.toLocaleString()} L</span>
                <span>Fraud Alerts: <strong className={flt.fraudAlertsCount > 0 ? 'text-amber-400' : 'text-emerald-400'}>{flt.fraudAlertsCount} Alerts</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. AVIATION.OS JET A-1 AIRPORT SUPPLY */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Plane className="w-4 h-4 text-cyan-400" />
            AVIATION FUELS & AIRPORT LOGISTICS (AVIATION.OS)
          </h3>
          <span className="text-xs font-mono text-cyan-400">DEF STAN 91-091 JET A-1 COMPLIANT</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
          {SYNTHETIC_AVIATION_DELIVERIES.map((del) => (
            <div key={del.deliveryId} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <span className="font-bold text-white">{del.airport}</span>
                <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded font-bold">
                  {del.status}
                </span>
              </div>
              <div className="text-slate-200 font-bold">{del.airlineCustomer}</div>
              <div className="text-slate-400">Volume Pumped: {del.volumeLitres.toLocaleString()} Litres</div>
              <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1 border-t border-slate-800">
                <span>QC Cert: <strong className="text-amber-400">{del.batchCertificateNo}</strong></span>
                <span>Flash/Freeze: {del.flashPointC}°C / {del.freezePointC}°C</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
