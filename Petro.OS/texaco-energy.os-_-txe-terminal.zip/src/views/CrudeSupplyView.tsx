/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Crude.OS & Cargo Procurement Optimisation View
 */

import React, { useState } from 'react';
import { DataProvenance } from '../types';
import {
  SYNTHETIC_CRUDE_GRADES,
  SYNTHETIC_CRUDE_CARGOES,
  SYNTHETIC_MARINE_VOYAGES,
} from '../data/syntheticData';
import { getMetricProvenance, calculateCargoNetback } from '../services/simulationEngine';
import { Droplet, Ship, Award, ArrowRight, ShieldCheck, Filter } from 'lucide-react';

interface CrudeSupplyViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
}

export const CrudeSupplyView: React.FC<CrudeSupplyViewProps> = ({ onInspectDataLineage }) => {
  const [selectedGradeId, setSelectedGradeId] = useState<string>('CRD-WTI');

  const selectedGrade =
    SYNTHETIC_CRUDE_GRADES.find((g) => g.id === selectedGradeId) || SYNTHETIC_CRUDE_GRADES[0];

  const processedCargoes = SYNTHETIC_CRUDE_CARGOES.map(calculateCargoNetback).sort(
    (a, b) => b.expectedMarginPerBbl - a.expectedMarginPerBbl
  );

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <Droplet className="w-4 h-4 text-amber-400" /> CRUDE.OS & PROCUREMENT OPTIMISATION
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Crude Assay Analysis & Cargo Netback Ranking
          </h1>
          <p className="text-xs text-slate-400">
            Landed Cost Calculation & Expected Refining Value (ERV) Engine
          </p>
        </div>
      </div>

      {/* 1. CRUDE ASSAY INSPECTOR */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Award className="w-4 h-4 text-cyan-400" />
            CRUDE GRADE ASSAY INSPECTOR
          </h3>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-500">SELECT GRADE:</span>
            <select
              value={selectedGradeId}
              onChange={(e) => setSelectedGradeId(e.target.value)}
              className="bg-slate-950 text-amber-400 text-xs font-mono px-3 py-1.5 rounded-lg border border-slate-700 focus:outline-none"
            >
              {SYNTHETIC_CRUDE_GRADES.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name} ({g.origin})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Assay Specifications Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span className="text-slate-500">API GRAVITY</span>
            <div className="text-xl font-bold text-white mt-1">{selectedGrade.apiGravity}°</div>
            <span className="text-[10px] text-slate-500">
              {selectedGrade.apiGravity > 35 ? 'Light Crude' : 'Medium/Heavy Crude'}
            </span>
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span className="text-slate-500">SULPHUR CONTENT</span>
            <div className="text-xl font-bold text-amber-400 mt-1">{selectedGrade.sulphurPercent}%</div>
            <span className="text-[10px] text-slate-500">
              {selectedGrade.sulphurPercent < 0.5 ? 'Sweet Crude' : 'Sour Crude'}
            </span>
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span className="text-slate-500">TAN (ACIDITY)</span>
            <div className="text-xl font-bold text-slate-200 mt-1">{selectedGrade.tanMgKohG}</div>
            <span className="text-[10px] text-slate-500">mg KOH/g</span>
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span className="text-slate-500">PRICING DIFFERENTIAL</span>
            <div className="text-xl font-bold text-emerald-400 mt-1">
              ${selectedGrade.currentDiffUsd}/bbl
            </div>
            <span className="text-[10px] text-slate-500">vs {selectedGrade.pricingBasis}</span>
          </div>
        </div>

        {/* Distillation Yield Curve */}
        <div className="space-y-2 font-mono text-xs">
          <span className="text-slate-400 font-bold">DISTILLATION YIELD BREAKDOWN</span>
          <div className="grid grid-cols-2 sm:grid-cols-7 gap-2">
            {Object.entries(selectedGrade.distillationYields).map(([yieldKey, pct]) => (
              <div key={yieldKey} className="p-2.5 bg-slate-950 rounded border border-slate-800 text-center">
                <span className="text-[10px] text-slate-500 uppercase">{yieldKey}</span>
                <div className="text-sm font-bold text-amber-400 mt-0.5">{(pct * 100).toFixed(1)}%</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 2. CARGO OPPORTUNITY RANKING TABLE */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Ship className="w-4 h-4 text-amber-400" />
            CRUDE CARGO LANDED COST & EXPECTED REFINING VALUE (ERV) RANKING
          </h3>
          <span className="text-xs font-mono text-emerald-400">RANKED BY NETBACK MARGIN</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="p-3">Rank</th>
                <th className="p-3">Cargo Grade</th>
                <th className="p-3">Supplier</th>
                <th className="p-3">Volume</th>
                <th className="p-3 text-right">FOB Price</th>
                <th className="p-3 text-right">Freight & Costs</th>
                <th className="p-3 text-right">Landed Cost</th>
                <th className="p-3 text-right">Expected Margin/bbl</th>
                <th className="p-3 text-right">Total Net Margin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {processedCargoes.map((cargo, i) => (
                <tr
                  key={cargo.id}
                  onClick={() =>
                    onInspectDataLineage(
                      `Cargo Opportunity ${cargo.gradeName}`,
                      `$${cargo.expectedMarginPerBbl}/bbl`,
                      getMetricProvenance('grossRefiningMargin')
                    )
                  }
                  className="hover:bg-slate-800/80 cursor-pointer transition-colors"
                >
                  <td className="p-3 font-bold text-amber-400">#{i + 1}</td>
                  <td className="p-3 font-bold text-white">{cargo.gradeName}</td>
                  <td className="p-3 text-slate-400">{cargo.supplier}</td>
                  <td className="p-3">{cargo.volumeBbl.toLocaleString()} bbl</td>
                  <td className="p-3 text-right">${cargo.purchasePriceUsd.toFixed(2)}</td>
                  <td className="p-3 text-right text-slate-400">
                    +${(cargo.landedCostUsd - cargo.purchasePriceUsd).toFixed(2)}
                  </td>
                  <td className="p-3 text-right font-bold text-slate-200">${cargo.landedCostUsd.toFixed(2)}</td>
                  <td className="p-3 text-right font-bold text-emerald-400">
                    +${cargo.expectedMarginPerBbl.toFixed(2)}
                  </td>
                  <td className="p-3 text-right font-bold text-amber-400">
                    £{((cargo.expectedMarginUsd * 0.78) / 1e6).toFixed(2)}M
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. MARINE VOYAGES STREAM */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
          <Ship className="w-4 h-4 text-purple-400" />
          ACTIVE MARINE TANKER VOYAGES (MARINE.OS)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
          {SYNTHETIC_MARINE_VOYAGES.map((v) => (
            <div key={v.id} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <span className="font-bold text-white">{v.vesselName}</span>
                <span className="text-amber-400 font-bold">{v.vesselType}</span>
              </div>
              <div className="text-slate-400">Cargo: <strong className="text-slate-200">{v.cargoGrade} ({v.cargoVolumeBbl.toLocaleString()} bbl)</strong></div>
              <div className="text-slate-400">Route: {v.originPort} → {v.destinationFacility}</div>
              <div className="flex justify-between items-center text-slate-400 pt-1 text-[11px]">
                <span>ETA: <strong className="text-emerald-400">{new Date(v.eta).toLocaleDateString()}</strong></span>
                <span>Demurrage: <strong className="text-amber-400">${v.demurrageAccruedUsd}</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
