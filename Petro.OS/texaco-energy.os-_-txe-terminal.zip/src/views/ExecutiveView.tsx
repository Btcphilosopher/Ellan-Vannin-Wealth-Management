/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Executive View (TXE Executive) - Group Physical & Economic Control
 */

import React, { useState } from 'react';
import { DataProvenance } from '../types';
import { getMetricProvenance } from '../services/simulationEngine';
import {
  SYNTHETIC_FINANCIALS,
  SYNTHETIC_PHYSICAL_ASSETS,
  SYNTHETIC_MARKETS,
  SYNTHETIC_REFINERY_ECONOMICS,
} from '../data/syntheticData';
import {
  TrendingUp,
  Activity,
  BarChart3,
  DollarSign,
  Droplet,
  Info,
  Calendar,
  Layers,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';

interface ExecutiveViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
  isBoardRoomMode: boolean;
}

export const ExecutiveView: React.FC<ExecutiveViewProps> = ({
  onInspectDataLineage,
  isBoardRoomMode,
}) => {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'WATERFALL' | 'DOR'>('OVERVIEW');

  const brentQuote = SYNTHETIC_MARKETS.find((m) => m.symbol === 'LCO')?.last || 82.4;
  const gasCrack = 16.5;
  const dieselCrack = 24.8;

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Top Section Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            TXE EXECUTIVE COMMAND CENTRE
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Group Operations & Economic Performance
          </h1>
          <p className="text-xs text-slate-400">
            Simultaneous Physical & Financial Truth Engine · Pembroke Refinery & UK/EU Downstream Network
          </p>
        </div>

        {/* View Segment Switcher */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 shrink-0">
          <button
            onClick={() => setActiveTab('OVERVIEW')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'OVERVIEW' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Overview KPI
          </button>
          <button
            onClick={() => setActiveTab('WATERFALL')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'WATERFALL' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Margin Waterfall
          </button>
          <button
            onClick={() => setActiveTab('DOR')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'DOR' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            06:00 Daily Operating Review
          </button>
        </div>
      </div>

      {/* 1. OVERVIEW KPI TAB */}
      {activeTab === 'OVERVIEW' && (
        <div className="space-y-6">
          {/* Group Economic KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Revenue */}
            <div
              onClick={() =>
                onInspectDataLineage(
                  'Group Annualized Revenue',
                  `£${(SYNTHETIC_FINANCIALS.revenueGbp / 1e9).toFixed(2)}B`,
                  getMetricProvenance('revenueGbp')
                )
              }
              className="bg-slate-900 hover:bg-slate-850 p-4 rounded-xl border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group"
            >
              <div className="flex justify-between items-center text-xs font-mono text-slate-400">
                <span>GROUP REVENUE</span>
                <Info className="w-3.5 h-3.5 text-slate-600 group-hover:text-amber-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-white mt-2">
                £{(SYNTHETIC_FINANCIALS.revenueGbp / 1e9).toFixed(2)}B
              </div>
              <div className="text-[11px] text-emerald-400 font-mono mt-1 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> +4.2% YoY
              </div>
            </div>

            {/* EBITDA */}
            <div
              onClick={() =>
                onInspectDataLineage(
                  'Group Annualized EBITDA',
                  `£${(SYNTHETIC_FINANCIALS.ebitdaGbp / 1e9).toFixed(2)}B`,
                  getMetricProvenance('ebitdaGbp')
                )
              }
              className="bg-slate-900 hover:bg-slate-850 p-4 rounded-xl border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group"
            >
              <div className="flex justify-between items-center text-xs font-mono text-slate-400">
                <span>GROUP EBITDA</span>
                <Info className="w-3.5 h-3.5 text-slate-600 group-hover:text-amber-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-2">
                £{(SYNTHETIC_FINANCIALS.ebitdaGbp / 1e9).toFixed(2)}B
              </div>
              <div className="text-[11px] text-slate-400 font-mono mt-1">
                Margin: 10.03% · ROIC: {SYNTHETIC_FINANCIALS.roicPercent}%
              </div>
            </div>

            {/* Free Cash Flow */}
            <div
              onClick={() =>
                onInspectDataLineage(
                  'Free Cash Flow',
                  `£${(SYNTHETIC_FINANCIALS.freeCashFlowGbp / 1e6).toFixed(0)}M`,
                  getMetricProvenance('ebitdaGbp')
                )
              }
              className="bg-slate-900 hover:bg-slate-850 p-4 rounded-xl border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group"
            >
              <div className="flex justify-between items-center text-xs font-mono text-slate-400">
                <span>FREE CASH FLOW</span>
                <Info className="w-3.5 h-3.5 text-slate-600 group-hover:text-amber-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-2">
                £{(SYNTHETIC_FINANCIALS.freeCashFlowGbp / 1e6).toFixed(0)}M
              </div>
              <div className="text-[11px] text-slate-400 font-mono mt-1">
                Conversion: 48.1% of EBITDA
              </div>
            </div>

            {/* Net Refining Margin */}
            <div
              onClick={() =>
                onInspectDataLineage(
                  'Net Refining Margin',
                  `$${SYNTHETIC_REFINERY_ECONOMICS.netMarginUsdPerBbl}/bbl`,
                  getMetricProvenance('grossRefiningMargin')
                )
              }
              className="bg-slate-900 hover:bg-slate-850 p-4 rounded-xl border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group"
            >
              <div className="flex justify-between items-center text-xs font-mono text-slate-400">
                <span>NET REFINING MARGIN</span>
                <Info className="w-3.5 h-3.5 text-slate-600 group-hover:text-amber-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-cyan-400 mt-2">
                ${SYNTHETIC_REFINERY_ECONOMICS.netMarginUsdPerBbl}
                <span className="text-xs font-normal text-slate-400">/bbl</span>
              </div>
              <div className="text-[11px] text-slate-400 font-mono mt-1">
                Gross: ${SYNTHETIC_REFINERY_ECONOMICS.grossMarginUsdPerBbl} · Opex: ${SYNTHETIC_REFINERY_ECONOMICS.operatingCostUsdPerBbl}
              </div>
            </div>
          </div>

          {/* Physical Company vs Economic Company Twin View */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* PHYSICAL COMPANY */}
            <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="font-semibold text-slate-100 text-sm font-mono flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  PHYSICAL OPERATIONS TWIN
                </h3>
                <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  REAL-TIME SIMULATION
                </span>
              </div>

              <div className="space-y-3 font-mono text-xs">
                <div
                  onClick={() =>
                    onInspectDataLineage(
                      'Pembroke Refinery Throughput',
                      '247,590 bbl/day',
                      getMetricProvenance('refineryThroughput')
                    )
                  }
                  className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center cursor-pointer hover:border-slate-700"
                >
                  <div>
                    <div className="font-semibold text-slate-200">Pembroke Refinery Run</div>
                    <div className="text-slate-500 text-[11px]">Utilization: 91.7% of 270,000 bbl/d</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-amber-400">247,590 bbl/d</div>
                    <div className="text-[10px] text-slate-400">[SCADA-CDU-101]</div>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center">
                  <div>
                    <div className="font-semibold text-slate-200">Terminal Fuel Inventory</div>
                    <div className="text-slate-500 text-[11px]">Thames, Manchester & Dublin Tanks</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-slate-200">3,050,000 bbl</div>
                    <div className="text-[10px] text-slate-400">Days Cover: 14.2d</div>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center">
                  <div>
                    <div className="font-semibold text-slate-200">Retail Forecourt Volume</div>
                    <div className="text-slate-500 text-[11px]">850 UK Branded Forecourts</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-slate-200">15.2M Litres/day</div>
                    <div className="text-[10px] text-emerald-400">+3.2% vs 30d avg</div>
                  </div>
                </div>
              </div>
            </div>

            {/* ECONOMIC COMPANY */}
            <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="font-semibold text-slate-100 text-sm font-mono flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-amber-400" />
                  ECONOMIC FINANCIAL TWIN
                </h3>
                <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  IFRS CONSOLIDATED
                </span>
              </div>

              <div className="space-y-3 font-mono text-xs">
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center">
                  <div>
                    <div className="font-semibold text-slate-200">Working Capital Buffer</div>
                    <div className="text-slate-500 text-[11px]">CCC: {SYNTHETIC_FINANCIALS.cashConversionCycleDays} Days (DSO: 24.5 / DIO: 32.1 / DPO: 41.2)</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-amber-400">£1.40 Billion</div>
                    <div className="text-[10px] text-slate-400">[SAP-GL-1020]</div>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center">
                  <div>
                    <div className="font-semibold text-slate-200">Net Debt Position</div>
                    <div className="text-slate-500 text-[11px]">Net Debt / EBITDA: 0.65x</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-slate-200">£1.20 Billion</div>
                    <div className="text-[10px] text-emerald-400">Investment Grade A-</div>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center">
                  <div>
                    <div className="font-semibold text-slate-200">1-Day VaR (95% Confidence)</div>
                    <div className="text-slate-500 text-[11px]">Commodity & Crack Spread Exposure</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-purple-400">£8.45 Million</div>
                    <div className="text-[10px] text-slate-400">[RISK-ENGINE-VAR]</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. MARGIN WATERFALL TAB */}
      {activeTab === 'WATERFALL' && (
        <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-6">
          <div className="border-b border-slate-800 pb-4">
            <h3 className="text-lg font-bold text-white font-mono">
              EXECUTIVE P&L MARGIN WATERFALL (Per Barrel Economics)
            </h3>
            <p className="text-xs text-slate-400">
              Barrels → Pembroke Refinery → Terminal Logistics → Wholesale → Retail → Cash
            </p>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {[
              { step: 'Gross Market Product Basket Value', val: '+ $94.65', color: 'text-emerald-400' },
              { step: '- Crude Landed Cost (Landed WTI/Forties Blend)', val: '- $82.80', color: 'text-red-400' },
              { step: '= Gross Refining Margin (GRM)', val: '= $11.85', color: 'text-amber-400', highlight: true },
              { step: '- Refinery Variable Energy & Catalysts', val: '- $2.75', color: 'text-red-400' },
              { step: '- Carbon Cost (EUA €85/t impact)', val: '- $0.90', color: 'text-red-400' },
              { step: '= Net Refining Margin (NRM)', val: '= $8.20', color: 'text-cyan-400', highlight: true },
              { step: '- Pipeline & Marine Logistics', val: '- $1.40', color: 'text-red-400' },
              { step: '+ Downstream Wholesale & Retail Premium', val: '+ $3.80', color: 'text-emerald-400' },
              { step: '= Group Integrated Margin per Barrel', val: '= $10.60 / bbl', color: 'text-emerald-400', highlight: true },
            ].map((row, i) => (
              <div
                key={i}
                className={`p-3 rounded-lg flex justify-between items-center ${
                  row.highlight ? 'bg-slate-800 border border-slate-700 font-bold' : 'bg-slate-950/60'
                }`}
              >
                <span className="text-slate-300">{row.step}</span>
                <span className={`text-sm ${row.color}`}>{row.val}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. DAILY OPERATING REVIEW (DOR) TAB */}
      {activeTab === 'DOR' && (
        <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5" /> DAILY OPERATING REVIEW (DOR) — 06:00 GMT BRIEFING
              </div>
              <h3 className="text-xl font-bold text-white mt-1">Executive Morning Summary</h3>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              0 MAJOR HSE INCIDENTS
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <span className="text-slate-500 font-bold">1. MARKETS MORNING</span>
              <div className="text-slate-300">Brent: <strong className="text-white">${brentQuote}</strong> (+1.48%)</div>
              <div className="text-slate-300">Diesel Crack: <strong className="text-emerald-400">${dieselCrack}/bbl</strong></div>
              <div className="text-slate-300">Gasoline Crack: <strong className="text-amber-400">${gasCrack}/bbl</strong></div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <span className="text-slate-500 font-bold">2. REFINERY & LOGISTICS</span>
              <div className="text-slate-300">Run: <strong className="text-white">247,590 bbl/d</strong> (91.7%)</div>
              <div className="text-slate-300">Turnaround: <strong className="text-amber-400">Day 43 of 71</strong></div>
              <div className="text-slate-300">Terminal Stock: <strong className="text-slate-200">14.2 Days Cover</strong></div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <span className="text-slate-500 font-bold">3. RETAIL & CASH</span>
              <div className="text-slate-300">Forecourt Vol: <strong className="text-white">+3.2% vs avg</strong></div>
              <div className="text-slate-300">Loyalty Active: <strong className="text-slate-200">8,540 Users</strong></div>
              <div className="text-slate-300">Daily Cash Flow: <strong className="text-emerald-400">+£3.4M</strong></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
