/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Texaco Retail.OS & Forecourt Economics View
 */

import React, { useState } from 'react';
import { DataProvenance } from '../types';
import { SYNTHETIC_RETAIL_STATIONS } from '../data/syntheticData';
import { getMetricProvenance } from '../services/simulationEngine';
import { Fuel, Award, ShoppingBag, Zap, DollarSign, Calculator } from 'lucide-react';

interface RetailViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
}

export const RetailView: React.FC<RetailViewProps> = ({ onInspectDataLineage }) => {
  // Star Rewards Points Calculator Simulator
  const [purchaseLitres, setPurchaseLitres] = useState(45);
  const pointsEarned = purchaseLitres * 1; // 1 point per qualifying litre
  const rewardVoucherValueGbp = (pointsEarned / 500) * 5.0; // 500 points = £5.00 reward voucher

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Header Banner with Generated Retail Forecourt Image */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900">
        <img
          src="/src/assets/images/retail_forecourt_texaco_1793028983190.jpg"
          alt="Texaco Retail Forecourt"
          referrerPolicy="no-referrer"
          className="w-full h-44 object-cover opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent p-6 flex flex-col justify-end">
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <Fuel className="w-4 h-4 text-amber-400" />
            TEXACO RETAIL.OS — UK BRANDED FORECOURT NETWORK
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            850 Branded Stations · Independent Dealer Model & Star Rewards Loyalty
          </h1>
          <p className="text-xs text-slate-300">
            Licensor / Independent Dealer Structure (800 Independent + 50 Corporate) · Forecourt EBITDA & EV Ultra-Fast Hubs
          </p>
        </div>
      </div>

      {/* 1. NETWORK STRUCTURAL SUMMARY */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 font-mono text-xs">
        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
          <span className="text-slate-500">TOTAL BRANDED NETWORK</span>
          <div className="text-2xl font-bold text-white mt-1">850 Stations</div>
          <span className="text-[10px] text-slate-400">UK & Ireland Coverage</span>
        </div>

        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
          <span className="text-slate-500">INDEPENDENT DEALER NETWORK</span>
          <div className="text-2xl font-bold text-amber-400 mt-1">800 Sites (94%)</div>
          <span className="text-[10px] text-slate-400">Brand License & Fuel Supply</span>
        </div>

        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
          <span className="text-slate-500">COMPANY OWNED SITES</span>
          <div className="text-2xl font-bold text-slate-200 mt-1">50 Sites (6%)</div>
          <span className="text-[10px] text-slate-400">Flagship Highway Hubs</span>
        </div>

        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
          <span className="text-slate-500">STAR REWARDS MEMBERS</span>
          <div className="text-2xl font-bold text-emerald-400 mt-1">1.24 Million</div>
          <span className="text-[10px] text-slate-400">1 Point / Litre Earn Rate</span>
        </div>
      </div>

      {/* 2. STAR REWARDS LOYALTY ENGINE MECHANICS */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            TEXACO STAR REWARDS LOYALTY ENGINE (MECHANICS)
          </h3>
          <span className="text-xs font-mono text-amber-400">QUALIFYING FUEL & SHOP REWARDS</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
          {/* Points Rules Explanation */}
          <div className="space-y-3 p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-400 font-bold text-sm">LOYALTY ARCHITECTURE</span>
            <div className="space-y-2 text-slate-300">
              <div>• <strong>Point Accrual:</strong> 1 Star Point awarded per 1 qualifying litre of Supreme / Regular fuel purchased.</div>
              <div>• <strong>Redemption Threshold:</strong> 500 Star Points = £5.00 voucher value against fuel, c-shop goods, or partner rewards.</div>
              <div>• <strong>Customer Segmentation:</strong> High-frequency commuters, local fleets, weekend travelers.</div>
            </div>
          </div>

          {/* Interactive Calculator */}
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <span className="text-slate-400 font-bold text-sm flex items-center gap-2">
              <Calculator className="w-4 h-4 text-emerald-400" /> REWARD CALCULATOR SIMULATOR
            </span>
            <div className="space-y-1">
              <label className="text-slate-500">Fuel Purchase Volume (Litres):</label>
              <input
                type="number"
                value={purchaseLitres}
                onChange={(e) => setPurchaseLitres(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 text-amber-400 font-bold px-3 py-1.5 rounded border border-slate-700"
              />
            </div>
            <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-sm">
              <span>Points Earned: <strong className="text-amber-400">{pointsEarned} Points</strong></span>
              <span>Voucher Value: <strong className="text-emerald-400">£{rewardVoucherValueGbp.toFixed(2)}</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. FORECOURT ECONOMICS SAMPLE SITES */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            FORECOURT SITE ECONOMICS (SAMPLE STATIONS)
          </h3>
          <span className="text-xs font-mono text-slate-400">STATION EBITDA CALCULATOR</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
          {SYNTHETIC_RETAIL_STATIONS.map((stn) => (
            <div key={stn.id} className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <div className="flex justify-between items-start border-b border-slate-800 pb-2">
                <div>
                  <div className="font-bold text-white text-sm">{stn.siteName}</div>
                  <div className="text-slate-500 text-[11px]">{stn.region} ({stn.postcode}) · {stn.ownershipType}</div>
                </div>
                <span className="px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded font-bold">
                  {stn.brandLicensor}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-slate-300">
                <div>Fuel Sales: <strong>{stn.fuelSalesLitresDay.toLocaleString()} L/day</strong></div>
                <div>Shop Revenue: <strong>£{stn.cShopRevenueGbpDay.toLocaleString()}/day</strong></div>
                <div>EV Charging: <strong>{stn.evChargingKwhDay} kWh/day</strong></div>
                <div>Pumps / EV: <strong>{stn.pumpsCount} Pumps / {stn.evChargersCount} EV</strong></div>
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 flex justify-between items-center text-sm">
                <span className="text-slate-400">STATION DAILY EBITDA:</span>
                <strong className="text-emerald-400">£{stn.dailyEbitdaGbp.toLocaleString()} / day</strong>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
