/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Refinery.OS & Digital Twin View
 */

import React, { useState } from 'react';
import { DataProvenance } from '../types';
import {
  SYNTHETIC_REFINERY_UNITS,
  SYNTHETIC_REFINERY_ECONOMICS,
} from '../data/syntheticData';
import { getMetricProvenance, runRefineryLpOptimizer } from '../services/simulationEngine';
import { Factory, Cpu, Flame, Sliders, Play, CheckCircle2, AlertTriangle, Info } from 'lucide-react';

interface RefineryViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
}

export const RefineryView: React.FC<RefineryViewProps> = ({ onInspectDataLineage }) => {
  const [brentPrice, setBrentPrice] = useState(82.4);
  const [gasolineCrack, setGasolineCrack] = useState(16.5);
  const [dieselCrack, setDieselCrack] = useState(24.8);
  const [carbonPrice, setCarbonPrice] = useState(85.0);

  const [lpResult, setLpResult] = useState(() =>
    runRefineryLpOptimizer(brentPrice, gasolineCrack, dieselCrack, 22.1, carbonPrice)
  );

  const handleRunLp = () => {
    const updated = runRefineryLpOptimizer(
      brentPrice,
      gasolineCrack,
      dieselCrack,
      22.1,
      carbonPrice
    );
    setLpResult(updated);
  };

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Header Banner with Generated Refinery Digital Twin Image */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900">
        <img
          src="/src/assets/images/refinery_digital_twin_hero_1793028983444.jpg"
          alt="Pembroke Refinery Digital Twin"
          referrerPolicy="no-referrer"
          className="w-full h-48 object-cover opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent p-6 flex flex-col justify-end">
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <Factory className="w-4 h-4 text-amber-400" />
            REFINERY.OS — PEMBROKE COASTAL REFINERY COMPLEX (DIGITAL TWIN)
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            270,000 bbl/day Processing Capacity & LP Optimization Engine
          </h1>
          <p className="text-xs text-slate-300">
            Real-Time DCS Telemetry · CDU Distillation · FCC Cracking · Hydrotreating · LP Yield Vector
          </p>
        </div>
      </div>

      {/* 1. LP REFINERY YIELD OPTIMIZER CONTROLS */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            LINEAR PROGRAMMING (LP) REFINERY YIELD OPTIMISER
          </h3>
          <button
            onClick={handleRunLp}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold font-mono rounded-lg transition-colors flex items-center gap-2 shadow-lg shadow-amber-500/20"
          >
            <Play className="w-3.5 h-3.5 fill-current" /> RUN LP SOLVER
          </button>
        </div>

        {/* Input Sliders */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>BRENT CRUDE</span>
              <span className="text-amber-400 font-bold">${brentPrice.toFixed(1)}/bbl</span>
            </div>
            <input
              type="range"
              min="50"
              max="130"
              step="0.5"
              value={brentPrice}
              onChange={(e) => setBrentPrice(parseFloat(e.target.value))}
              className="w-full accent-amber-500"
            />
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>GASOLINE CRACK</span>
              <span className="text-emerald-400 font-bold">${gasolineCrack.toFixed(1)}/bbl</span>
            </div>
            <input
              type="range"
              min="0"
              max="40"
              step="0.5"
              value={gasolineCrack}
              onChange={(e) => setGasolineCrack(parseFloat(e.target.value))}
              className="w-full accent-emerald-500"
            />
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>DIESEL CRACK</span>
              <span className="text-cyan-400 font-bold">${dieselCrack.toFixed(1)}/bbl</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="0.5"
              value={dieselCrack}
              onChange={(e) => setDieselCrack(parseFloat(e.target.value))}
              className="w-full accent-cyan-500"
            />
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>CARBON PRICE (EUA)</span>
              <span className="text-purple-400 font-bold">€{carbonPrice.toFixed(0)}/ton</span>
            </div>
            <input
              type="range"
              min="40"
              max="180"
              step="1"
              value={carbonPrice}
              onChange={(e) => setCarbonPrice(parseFloat(e.target.value))}
              className="w-full accent-purple-500"
            />
          </div>
        </div>

        {/* LP Solved Economics Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 font-mono text-xs pt-2">
          <div
            onClick={() =>
              onInspectDataLineage(
                'LP Optimal Gross Refining Margin',
                `$${lpResult.economicSummary.grossMarginUsdPerBbl}/bbl`,
                getMetricProvenance('grossRefiningMargin')
              )
            }
            className="p-3 bg-slate-950 rounded-lg border border-slate-800 cursor-pointer hover:border-slate-700"
          >
            <span className="text-slate-500">OPTIMAL GROSS MARGIN</span>
            <div className="text-xl font-bold text-emerald-400 mt-1">
              ${lpResult.economicSummary.grossMarginUsdPerBbl}/bbl
            </div>
            <span className="text-[10px] text-slate-500">Gross Margin per Crude Run</span>
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span className="text-slate-500">OPTIMAL NET MARGIN</span>
            <div className="text-xl font-bold text-cyan-400 mt-1">
              ${lpResult.economicSummary.netMarginUsdPerBbl}/bbl
            </div>
            <span className="text-[10px] text-slate-500">After Opex & Carbon Costs</span>
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span className="text-slate-500">DAILY REFINERY EBITDA</span>
            <div className="text-xl font-bold text-amber-400 mt-1">
              ${(lpResult.economicSummary.dailyEbitdaUsd / 1e6).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-500">At 247,590 bbl/d Run Rate</span>
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
            <span className="text-slate-500">SYNTHETIC 3:2:1 CRACK</span>
            <div className="text-xl font-bold text-purple-400 mt-1">
              ${lpResult.economicSummary.crack321Usd}/bbl
            </div>
            <span className="text-[10px] text-slate-500">Custom Yield Basket Benchmark</span>
          </div>
        </div>
      </div>

      {/* 2. REFINERY PROCESSING UNITS DIGITAL TWIN */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-400" />
            PEMBROKE PROCESSING UNITS — LIVE DCS TELEMETRY
          </h3>
          <span className="text-xs font-mono text-slate-400">HONEYWELL EXPERION DCS TELEMETRY</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs">
          {SYNTHETIC_REFINERY_UNITS.map((unit) => (
            <div
              key={unit.id}
              onClick={() =>
                onInspectDataLineage(
                  `Unit ${unit.name}`,
                  `${unit.currentThroughputBblDay.toLocaleString()} bbl/day`,
                  getMetricProvenance('refineryThroughput')
                )
              }
              className="p-4 bg-slate-950 rounded-xl border border-slate-800 hover:border-slate-700 cursor-pointer space-y-2 transition-colors"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <span className="font-bold text-white">{unit.name}</span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    unit.status === 'ONLINE'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  }`}
                >
                  {unit.status}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                <div>
                  <span className="text-slate-500">THROUGHPUT:</span>
                  <div className="font-bold text-slate-200">
                    {unit.currentThroughputBblDay.toLocaleString()} bbl/d
                  </div>
                </div>
                <div>
                  <span className="text-slate-500">UTILISATION:</span>
                  <div className="font-bold text-amber-400">
                    {((unit.currentThroughputBblDay / unit.capacityBblDay) * 100).toFixed(1)}%
                  </div>
                </div>
                <div>
                  <span className="text-slate-500">TEMP / PRESS:</span>
                  <div className="text-slate-300">
                    {unit.operatingTempC}°C / {unit.operatingPressureBar} bar
                  </div>
                </div>
                <div>
                  <span className="text-slate-500">CATALYST / VIB:</span>
                  <div className="text-slate-300">
                    {unit.catalystHealthPercent}% / {unit.vibrationMmS} mm/s
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
