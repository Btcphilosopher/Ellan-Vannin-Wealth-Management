/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * TXE Trading & Market Risk View
 */

import React from 'react';
import { DataProvenance } from '../types';
import {
  SYNTHETIC_MARKETS,
  SYNTHETIC_HEDGE_POSITIONS,
  SYNTHETIC_RISK_METRICS,
} from '../data/syntheticData';
import { getMetricProvenance } from '../services/simulationEngine';
import { TrendingUp, Lock, ShieldCheck, BarChart2, Activity } from 'lucide-react';

interface TradingRiskViewProps {
  onInspectDataLineage: (name: string, value: string, prov: DataProvenance) => void;
}

export const TradingRiskView: React.FC<TradingRiskViewProps> = ({ onInspectDataLineage }) => {
  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-amber-400" /> TXE TRADING FLOOR & MARKET RISK
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Physical & Financial Commodity Markets, Hedge Books & VaR
          </h1>
          <p className="text-xs text-slate-400">
            Crude, Products, Carbon EUA & FX Terminals · Forward Curve Matrix
          </p>
        </div>
      </div>

      {/* 1. LIVE MARKET TICKER TERMINAL */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-emerald-400" />
            COMMODITY & DERIVATIVE MARKET TERMINAL
          </h3>
          <span className="text-xs font-mono text-emerald-400">LIVE ICE / NYMEX TELEMETRY FEED</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
          {SYNTHETIC_MARKETS.map((m) => (
            <div
              key={m.symbol}
              onClick={() =>
                onInspectDataLineage(
                  `Market Quote ${m.name}`,
                  `${m.last} ${m.unit}`,
                  getMetricProvenance('brentPrice')
                )
              }
              className="p-4 bg-slate-950 rounded-xl border border-slate-800 hover:border-slate-700 cursor-pointer space-y-1 transition-colors"
            >
              <div className="flex justify-between text-slate-400">
                <span className="font-bold text-amber-400">{m.symbol}</span>
                <span className={m.change24h >= 0 ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                  {m.change24h >= 0 ? '+' : ''}{m.change24h} ({m.changePercent}%)
                </span>
              </div>
              <div className="text-xl font-bold text-white pt-1">
                {m.last} <span className="text-xs font-normal text-slate-500">{m.unit}</span>
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 pt-1">
                <span>BID: {m.bid}</span>
                <span>ASK: {m.ask}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. PHYSICAL VS FINANCIAL HEDGE BOOK */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <Lock className="w-4 h-4 text-amber-400" />
            PHYSICAL EXPOSURE VS FINANCIAL HEDGE BOOK (HEDGE.OS)
          </h3>
          <span className="text-xs font-mono text-amber-400">NET COMMODITY DELTA EXPOSURE</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="p-3">Commodity</th>
                <th className="p-3 text-right">Physical Exposure</th>
                <th className="p-3 text-right">Paper Hedge</th>
                <th className="p-3 text-right">Net Exposure</th>
                <th className="p-3 text-right">Hedge Ratio</th>
                <th className="p-3 text-right">Unrealized PnL</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {SYNTHETIC_HEDGE_POSITIONS.map((h) => (
                <tr key={h.id} className="hover:bg-slate-800/80 transition-colors">
                  <td className="p-3 font-bold text-white">{h.commodity}</td>
                  <td className="p-3 text-right text-slate-300">{h.physicalExposureBbl.toLocaleString()} bbl</td>
                  <td className="p-3 text-right text-amber-400">{h.paperHedgeBbl.toLocaleString()} bbl</td>
                  <td className="p-3 text-right font-bold text-slate-100">{h.netExposureBbl.toLocaleString()} bbl</td>
                  <td className="p-3 text-right font-bold text-emerald-400">{h.hedgeRatioPercent}%</td>
                  <td className={`p-3 text-right font-bold ${h.unrealizedPnlGbp >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    £{(h.unrealizedPnlGbp / 1e6).toFixed(2)}M
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. VALUE-AT-RISK (VaR) METRICS */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-purple-400" />
            ENTERPRISE MARKET RISK & VALUE-AT-RISK (RISK.OS)
          </h3>
          <span className="text-xs font-mono text-purple-400">MONTE CARLO 1-DAY HORIZON</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 font-mono text-xs">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">1-DAY 95% VaR</span>
            <div className="text-2xl font-bold text-amber-400 mt-1">
              £{(SYNTHETIC_RISK_METRICS.var951dGbp / 1e6).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400">95% Confidence Limit</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">1-DAY 99% VaR</span>
            <div className="text-2xl font-bold text-purple-400 mt-1">
              £{(SYNTHETIC_RISK_METRICS.var991dGbp / 1e6).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400">99% Tail Risk</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">EXPECTED SHORTFALL</span>
            <div className="text-2xl font-bold text-red-400 mt-1">
              £{(SYNTHETIC_RISK_METRICS.expectedShortfallGbp / 1e6).toFixed(2)}M
            </div>
            <span className="text-[10px] text-slate-400">Conditional VaR</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500">CREDIT EXPOSURE</span>
            <div className="text-2xl font-bold text-emerald-400 mt-1">
              £{(SYNTHETIC_RISK_METRICS.creditExposureTotalGbp / 1e6).toFixed(0)}M
            </div>
            <span className="text-[10px] text-slate-400">Counterparty Exposure</span>
          </div>
        </div>
      </div>
    </div>
  );
};
