/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * TXE Mobile - Android Executive Application Preview
 */

import React, { useState } from 'react';
import {
  SYNTHETIC_FINANCIALS,
  SYNTHETIC_PHYSICAL_ASSETS,
  SYNTHETIC_MARKETS,
  SYNTHETIC_REFINERY_ECONOMICS,
} from '../data/syntheticData';
import {
  Smartphone,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Activity,
  DollarSign,
  ShieldAlert,
  Fuel,
  Bell,
  Lock,
} from 'lucide-react';

export const MobileAppView: React.FC = () => {
  const [mobileTab, setMobileTab] = useState<
    'COMPANY' | 'OPERATIONS' | 'MARKETS' | 'REFINERY' | 'INVENTORY' | 'RETAIL' | 'FINANCE' | 'RISK' | 'HSE' | 'ALERTS' | 'APPROVALS'
  >('COMPANY');

  return (
    <div className="p-6 space-y-6 text-slate-200">
      {/* Header */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-mono text-amber-400 flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-amber-400" /> TXE MOBILE (ANDROID EXECUTIVE INTERFACE)
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
            Mobile Control & Information System
          </h1>
          <p className="text-xs text-slate-400">
            Native Android Executive Suite · Information & Executive Approvals Engine
          </p>
        </div>
      </div>

      {/* Android Device Mockup Container */}
      <div className="flex justify-center">
        <div className="w-full max-w-sm bg-slate-950 border-4 border-slate-800 rounded-[2.5rem] p-4 shadow-2xl space-y-4 text-slate-200 font-mono">
          {/* Phone Speaker & Status Header */}
          <div className="flex justify-between items-center px-2 pt-1 text-[10px] text-slate-500">
            <span>08:35 GMT</span>
            <div className="w-16 h-2 bg-slate-800 rounded-full"></div>
            <span>TXE 5G</span>
          </div>

          {/* Mobile App Title Bar */}
          <div className="flex items-center justify-between px-2 border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              <span className="font-bold text-xs text-white">TXE MOBILE</span>
            </div>
            <Bell className="w-4 h-4 text-slate-400" />
          </div>

          {/* Mobile Screen Selector Horizontal Tab */}
          <div className="flex gap-1 overflow-x-auto pb-1 text-[10px] border-b border-slate-800 no-scrollbar">
            {(
              [
                'COMPANY',
                'OPERATIONS',
                'MARKETS',
                'REFINERY',
                'INVENTORY',
                'RETAIL',
                'FINANCE',
                'RISK',
                'HSE',
                'ALERTS',
                'APPROVALS',
              ] as const
            ).map((tab) => (
              <button
                key={tab}
                onClick={() => setMobileTab(tab)}
                className={`px-2 py-1 rounded whitespace-nowrap ${
                  mobileTab === tab ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 bg-slate-900'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Screen Content */}
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-3 min-h-[360px] text-xs">
            {mobileTab === 'COMPANY' && (
              <div className="space-y-2">
                <span className="text-[10px] text-slate-500 uppercase font-bold">GROUP POSITION</span>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="text-slate-400">Revenue (Annualised)</div>
                  <div className="text-lg font-bold text-white">£{(SYNTHETIC_FINANCIALS.revenueGbp / 1e9).toFixed(2)}B</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="text-slate-400">EBITDA</div>
                  <div className="text-lg font-bold text-amber-400">£{(SYNTHETIC_FINANCIALS.ebitdaGbp / 1e9).toFixed(2)}B</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="text-slate-400">Free Cash Flow</div>
                  <div className="text-lg font-bold text-emerald-400">£{(SYNTHETIC_FINANCIALS.freeCashFlowGbp / 1e6).toFixed(0)}M</div>
                </div>
              </div>
            )}

            {mobileTab === 'OPERATIONS' && (
              <div className="space-y-2">
                <span className="text-[10px] text-slate-500 uppercase font-bold">PEMBROKE REFINERY RUN</span>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="text-slate-400">Crude Run Rate</div>
                  <div className="text-lg font-bold text-amber-400">247,590 bbl/d</div>
                  <div className="text-[10px] text-slate-500">Utilization: 91.7%</div>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="text-slate-400">Net Refining Margin</div>
                  <div className="text-lg font-bold text-cyan-400">${SYNTHETIC_REFINERY_ECONOMICS.netMarginUsdPerBbl}/bbl</div>
                </div>
              </div>
            )}

            {mobileTab === 'MARKETS' && (
              <div className="space-y-2">
                <span className="text-[10px] text-slate-500 uppercase font-bold">ICE & NYMEX QUOTES</span>
                {SYNTHETIC_MARKETS.slice(0, 3).map((m) => (
                  <div key={m.symbol} className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                    <span>{m.symbol}</span>
                    <strong className="text-amber-400">${m.last}</strong>
                  </div>
                ))}
              </div>
            )}

            {mobileTab === 'APPROVALS' && (
              <div className="space-y-2">
                <span className="text-[10px] text-slate-500 uppercase font-bold">MANAGEMENT APPROVALS</span>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                  <div className="font-bold text-white text-[11px]">WTI Cargo Purchase (1.0M bbl)</div>
                  <div className="text-[10px] text-slate-400">Landed Cost: $82.22/bbl · Netback: +$8.33/bbl</div>
                  <button className="w-full mt-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-[10px]">
                    APPROVE EXECUTION
                  </button>
                </div>
              </div>
            )}

            {!['COMPANY', 'OPERATIONS', 'MARKETS', 'APPROVALS'].includes(mobileTab) && (
              <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 text-center text-slate-400 font-sans text-xs">
                Displaying TXE Mobile preview for <strong>{mobileTab}</strong> module.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
