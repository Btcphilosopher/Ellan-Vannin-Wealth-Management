/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Enterprise Data Types & Schemas
 */

export type NavigationModule = 
  | 'EXEC'
  | 'CRUDE'
  | 'SUPPLY'
  | 'REFINERY'
  | 'TERMINALS'
  | 'PIPELINES'
  | 'RETAIL'
  | 'FLEET'
  | 'AVIATION'
  | 'TRADING'
  | 'MARKETS'
  | 'HEDGE'
  | 'RISK'
  | 'FINANCE'
  | 'CASH'
  | 'CAPEX'
  | 'HSE'
  | 'ENV'
  | 'MAINT'
  | 'SCENARIO'
  | 'OPT'
  | 'BOARD'
  | 'MOBILE';

export interface DataProvenance {
  sourceSystem: string;
  ingestionPipeline: string;
  validationRule: string;
  transformationModel: string;
  timestamp: string;
  confidenceScore: number;
  dataCategory: 'PHYSICAL' | 'FINANCIAL' | 'MARKET' | 'MODELLED' | 'SCENARIO';
}

export interface MetricWithProvenance {
  label: string;
  value: number | string;
  unit?: string;
  change24h?: number;
  status?: 'nominal' | 'warning' | 'critical' | 'simulated';
  provenance: DataProvenance;
}

// Physical Asset Digital Twin
export interface PhysicalAsset {
  id: string;
  name: string;
  type: 'Refinery' | 'Terminal' | 'Pipeline' | 'Port' | 'RetailStation' | 'AviationHub' | 'LubeDistribution' | 'Vessel';
  region: 'UK' | 'Ireland' | 'US' | 'Canada' | 'Latin America' | 'Europe';
  location: {
    lat: number;
    lng: number;
    city: string;
    country: string;
  };
  owner: string;
  operator: string;
  status: 'OPERATIONAL' | 'REDUCED_RATE' | 'MAINTENANCE' | 'SHUTDOWN';
  capacityBblDay: number;
  throughputBblDay: number;
  efficiencyPercent: number;
  maintenanceState: string;
  energyUseMW: number;
  emissionsCo2eDay: number;
  inventoryBbl: number;
  financialValueGBP: number;
}

// Crude Supply & Cargo
export interface CrudeGrade {
  id: string;
  name: string;
  origin: string;
  apiGravity: number;
  sulphurPercent: number;
  metalsPpm: { nickel: number; vanadium: number };
  tanMgKohG: number;
  distillationYields: {
    lpg: number;
    naphtha: number;
    gasoline: number;
    keroseneJet: number;
    dieselGasOil: number;
    vacuumGasOil: number;
    residue: number;
  };
  pricingBasis: 'BRENT_DIFF' | 'WTI_DIFF' | 'FLAT';
  currentDiffUsd: number;
}

export interface CrudeCargoOpportunity {
  id: string;
  gradeId: string;
  gradeName: string;
  supplier: string;
  volumeBbl: number;
  purchasePriceUsd: number;
  freightUsd: number;
  insuranceUsd: number;
  portCostUsd: number;
  qualityAdjustmentUsd: number;
  financingUsd: number;
  demurrageRiskUsd: number;
  landedCostUsd: number;
  expectedProductValueUsd: number;
  refiningCostUsd: number;
  expectedMarginUsd: number;
  expectedMarginPerBbl: number;
  rank: number;
  deliveryDate: string;
  originPort: string;
  destinationFacility: string;
}

// Marine Logistics
export interface MarineVoyage {
  id: string;
  vesselName: string;
  vesselType: 'VLCC' | 'Suezmax' | 'Aframax' | 'Product Tanker';
  capacityBbl: number;
  cargoGrade: string;
  cargoVolumeBbl: number;
  originPort: string;
  destinationFacility: string;
  status: 'LOADING' | 'IN_TRANSIT' | 'QUEUED' | 'DISCHARGING';
  eta: string;
  currentLat: number;
  currentLng: number;
  freightRateUsdDay: number;
  demurrageAccruedUsd: number;
  weatherRisk: 'LOW' | 'MODERATE' | 'HIGH';
}

// Refinery Unit
export interface RefineryProcessingUnit {
  id: string;
  name: string;
  code: 'CDU' | 'VDU' | 'FCC' | 'HYDROCRACKER' | 'REFORMER' | 'HYDROTREATER' | 'ALKYLATION' | 'SRU' | 'HYDROGEN';
  capacityBblDay: number;
  currentThroughputBblDay: number;
  operatingTempC: number;
  operatingPressureBar: number;
  energyConsumptionMW: number;
  catalystHealthPercent: number;
  vibrationMmS: number;
  corrosionRateMmYr: number;
  status: 'ONLINE' | 'THROTTLED' | 'TRIPPED' | 'MAINTENANCE';
}

export interface RefineryEconomics {
  crudeThroughputBblDay: number;
  grossMarginUsdPerBbl: number;
  operatingCostUsdPerBbl: number;
  netMarginUsdPerBbl: number;
  dailyEbitdaUsd: number;
  crack321Usd: number;
  crack532Usd: number;
  energyCostPerDayUsd: number;
  carbonCostPerDayUsd: number;
}

// Terminal & Tank
export interface StorageTank {
  id: string;
  terminalId: string;
  terminalName: string;
  tankNumber: string;
  product: 'Crude' | 'Gasoline Premium' | 'Gasoline Regular' | 'Diesel B7' | 'Jet A-1' | 'Heating Oil' | 'Ethanol';
  capacityBbl: number;
  currentLevelBbl: number;
  ullageBbl: number;
  temperatureC: number;
  densityKgM3: number;
  waterBottomCm: number;
  qualityCertified: boolean;
  daysOfCover: number;
}

export interface PipelineSegment {
  id: string;
  name: string;
  origin: string;
  destination: string;
  lengthMiles: number;
  capacityBph: number;
  currentFlowBph: number;
  operatingPressurePsi: number;
  activeBatchId: string;
  activeBatchProduct: string;
  activeBatchVolumeBbl: number;
  interfaceTransmixBbl: number;
}

export interface BatchRecord {
  batchId: string;
  origin: string;
  destination: string;
  product: string;
  volumeBbl: number;
  qualityCertificateNo: string;
  timestamp: string;
  custodyOwner: string;
  status: 'IN_TRANSIT' | 'DELIVERED' | 'TESTING';
}

// Retail Network
export interface RetailStation {
  id: string;
  siteName: string;
  postcode: string;
  region: string;
  ownershipType: 'INDEPENDENT_DEALER' | 'COMPANY_OWNED';
  brandLicensor: 'TEXACO';
  fuelSalesLitresDay: number;
  cShopRevenueGbpDay: number;
  carWashRevenueGbpDay: number;
  evChargingKwhDay: number;
  fuelCostGbpDay: number;
  shopCogsGbpDay: number;
  operatingExpensesGbpDay: number;
  dailyEbitdaGbp: number;
  starRewardsActiveUsers: number;
  pumpsCount: number;
  fuelTanksCount: number;
  evChargersCount: number;
  competitorPriceDeltaGbp: number;
}

// Fleet & Aviation & Lubes
export interface FleetAccount {
  accountId: string;
  companyName: string;
  activeCards: number;
  monthlyCreditLimitGbp: number;
  currentSpendGbp: number;
  riskScore: number;
  fraudAlertsCount: number;
  volumeLitresMonth: number;
}

export interface AviationDelivery {
  deliveryId: string;
  airport: 'Heathrow (LHR)' | 'Gatwick (LGW)' | 'Manchester (MAN)';
  airlineCustomer: string;
  volumeLitres: number;
  batchCertificateNo: string;
  flashPointC: number;
  freezePointC: number;
  status: 'CERTIFIED' | 'IN_PUMPING' | 'COMPLETED';
}

// Trading & Risk
export interface MarketQuote {
  symbol: string;
  name: string;
  bid: number;
  ask: number;
  last: number;
  change24h: number;
  changePercent: number;
  volume: number;
  unit: string;
}

export interface HedgePosition {
  id: string;
  commodity: 'Crude Brent' | 'Gasoline 10ppm' | 'Diesel ULSD' | 'Jet A1' | 'Carbon EUA';
  physicalExposureBbl: number;
  paperHedgeBbl: number;
  netExposureBbl: number;
  unrealizedPnlGbp: number;
  hedgeRatioPercent: number;
}

export interface RiskMetrics {
  var951dGbp: number;
  var991dGbp: number;
  expectedShortfallGbp: number;
  stressLossMaxGbp: number;
  creditExposureTotalGbp: number;
  liquidityBufferGbp: number;
}

// Finance & Capital
export interface FinancialSummary {
  revenueGbp: number;
  ebitdaGbp: number;
  operatingCashFlowGbp: number;
  freeCashFlowGbp: number;
  netDebtGbp: number;
  roicPercent: number;
  workingCapitalGbp: number;
  dsoDays: number;
  dioDays: number;
  dpoDays: number;
  cashConversionCycleDays: number;
  thirteenWeekCashForecastGbp: number[];
}

export interface CapitalProject {
  id: string;
  name: string;
  category: 'REFINERY_UPGRADE' | 'EV_CHARGING' | 'HYDROGEN_SAF' | 'TERMINAL_EXPANSION' | 'DECARBONISATION';
  capexBudgetGbp: number;
  spentToDateGbp: number;
  npvGbp: number;
  irrPercent: number;
  paybackYears: number;
  status: 'PROPOSED' | 'APPROVED' | 'IN_CONSTRUCTION' | 'OPERATIONAL';
}

// Scenario & Monte Carlo
export interface ScenarioInput {
  brentPriceDeltaUsd: number;
  gasolineCrackDeltaUsd: number;
  dieselCrackDeltaUsd: number;
  refineryOutageDays: number;
  evAdoptionSpeedMultiplier: number;
  carbonPriceEurTon: number;
  fxGbpUsdRate: number;
}

export interface MonteCarloResult {
  simulationsCount: number;
  ebitdaMeanGbp: number;
  ebitda5thPercentileGbp: number;
  ebitda95thPercentileGbp: number;
  freeCashFlowMeanGbp: number;
  varProbabilityDistribution: number[];
}

// HSE & Process Safety
export interface HseEvent {
  id: string;
  timestamp: string;
  facility: string;
  severity: 'NEAR_MISS' | 'MINOR' | 'MODERATE' | 'SERIOUS' | 'CRITICAL';
  type: 'ENVIRONMENTAL' | 'PROCESS_SAFETY' | 'PERSONAL_SAFETY' | 'CYBER_ALERT';
  description: string;
  actionTaken: string;
  status: 'INVESTIGATING' | 'CONTAINED' | 'CLOSED';
}

// Copilot Query Response
export interface CopilotResponse {
  answer: string;
  dataSources: string[];
  underlyingModel: string;
  assumptions: string[];
  timestamp: string;
  confidenceScore: number;
  recommendedActions?: string[];
  safetyGuardrailActive: boolean;
}
