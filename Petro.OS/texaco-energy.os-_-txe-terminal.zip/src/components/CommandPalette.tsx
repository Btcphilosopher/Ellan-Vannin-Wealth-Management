/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Command Palette - TXE <GO> Terminal Shortcuts
 */

import React, { useState } from 'react';
import { NavigationModule } from '../types';
import { Terminal, Search, X, ArrowRight } from 'lucide-react';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectModule: (mod: NavigationModule) => void;
}

const COMMAND_LIST: { code: NavigationModule; name: string; desc: string }[] = [
  { code: 'EXEC', name: 'EXEC <GO>', desc: 'Executive Command Centre - CEO/CFO/COO Dashboard' },
  { code: 'CRUDE', name: 'CRUDE <GO>', desc: 'Crude.OS - Assays, Yield Vectors & Netbacks' },
  { code: 'SUPPLY', name: 'SUPPLY <GO>', desc: 'Cargo Procurement & Supply Chain Control Tower' },
  { code: 'REFINERY', name: 'REFINERY <GO>', desc: 'Refinery.OS - Digital Twin, Crack Spreads & LP Optimiser' },
  { code: 'TERMINALS', name: 'TERMINALS <GO>', desc: 'Terminal.OS - Tank Farm Monitoring & Ullage' },
  { code: 'PIPELINES', name: 'PIPELINES <GO>', desc: 'Pipeline.OS - Segments & Batch Chain-of-Custody' },
  { code: 'RETAIL', name: 'RETAIL <GO>', desc: 'Texaco Retail.OS - Forecourt Economics & Star Rewards' },
  { code: 'FLEET', name: 'FLEET <GO>', desc: 'Fleet.OS - Corporate Fuel Cards & Fraud Rules' },
  { code: 'AVIATION', name: 'AVIATION <GO>', desc: 'Aviation.OS - Jet A-1 Quality Certs & Airport Logistics' },
  { code: 'TRADING', name: 'TRADING <GO>', desc: 'TXE Trading - Physical & Financial Markets' },
  { code: 'MARKETS', name: 'MARKETS <GO>', desc: 'Morning Market Screen - Crude, Cracks, Carbon & FX' },
  { code: 'HEDGE', name: 'HEDGE <GO>', desc: 'Hedge.OS - Physical vs Financial Risk Books' },
  { code: 'RISK', name: 'RISK <GO>', desc: 'Risk.OS - Value-at-Risk (VaR) & Stress Loss' },
  { code: 'FINANCE', name: 'FINANCE <GO>', desc: 'Finance.OS - General Ledger & Working Capital' },
  { code: 'CASH', name: 'CASH <GO>', desc: 'Cash.OS - 13-Week Cash Flow Forecast' },
  { code: 'CAPEX', name: 'CAPEX <GO>', desc: 'Capital.OS - Project Economics (NPV, IRR)' },
  { code: 'HSE', name: 'HSE <GO>', desc: 'HSE.OS - Process Safety Alarms & Incident Tracking' },
  { code: 'ENV', name: 'ENV <GO>', desc: 'Environment.OS - Carbon Cost & Emissions Intensity' },
  { code: 'MAINT', name: 'MAINT <GO>', desc: 'Maintenance.OS - Turnaround Day 43/71 & Telemetry' },
  { code: 'SCENARIO', name: 'SCENARIO <GO>', desc: 'Strategy.OS - What-If Stress Testing Engine' },
  { code: 'OPT', name: 'OPT <GO>', desc: 'Global Supply Optimisation & Monte Carlo' },
  { code: 'BOARD', name: 'BOARD <GO>', desc: 'Board Room Meeting Mode' },
  { code: 'MOBILE', name: 'MOBILE <GO>', desc: 'TXE Mobile Android Executive Interface' },
];

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onSelectModule,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const filteredCommands = COMMAND_LIST.filter(
    (c) =>
      c.code.toLowerCase().includes(query.toLowerCase()) ||
      c.name.toLowerCase().includes(query.toLowerCase()) ||
      c.desc.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-black/80 backdrop-blur-md p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-amber-500/40 rounded-xl shadow-2xl overflow-hidden text-slate-200">
        {/* Command Bar Header */}
        <div className="flex items-center px-4 py-3 bg-slate-950 border-b border-slate-800 gap-3">
          <Terminal className="w-5 h-5 text-amber-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type TXE command (e.g. EXEC <GO>, REFINERY <GO>, TRADING <GO>)..."
            className="w-full bg-transparent text-amber-400 font-mono text-base focus:outline-none placeholder:text-slate-600 uppercase"
            autoFocus
          />
          <button onClick={onClose} className="p-1 text-slate-500 hover:text-slate-300">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Command Options List */}
        <div className="max-h-96 overflow-y-auto divide-y divide-slate-800/60 p-2">
          {filteredCommands.length === 0 ? (
            <div className="p-6 text-center text-slate-500 font-mono text-sm">
              No matching TXE terminal commands found for "{query}".
            </div>
          ) : (
            filteredCommands.map((cmd) => (
              <button
                key={cmd.code}
                onClick={() => {
                  onSelectModule(cmd.code);
                  onClose();
                }}
                className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-slate-800/80 text-left transition-colors group"
              >
                <div>
                  <div className="font-mono text-sm font-bold text-amber-400 group-hover:text-amber-300">
                    {cmd.name}
                  </div>
                  <div className="text-xs text-slate-400 font-sans">{cmd.desc}</div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-amber-400 transition-colors" />
              </button>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2 bg-slate-950 border-t border-slate-800 flex justify-between items-center text-xs font-mono text-slate-500">
          <span>TXE TERMINAL COMMAND MODE</span>
          <span>PRESS ESC TO CLOSE</span>
        </div>
      </div>
    </div>
  );
};
