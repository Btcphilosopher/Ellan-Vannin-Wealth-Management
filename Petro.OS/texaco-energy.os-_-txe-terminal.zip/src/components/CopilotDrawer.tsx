/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * TXE Copilot Side Drawer - Gemini 3.8 Server Proxy
 */

import React, { useState } from 'react';
import { CopilotResponse, NavigationModule } from '../types';
import { Bot, Send, ShieldAlert, Cpu, Database, CheckCircle2, X, Sparkles } from 'lucide-react';

interface CopilotDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeModule: NavigationModule;
}

const SAMPLE_PROMPTS = [
  'Which refinery or facility has the highest net margin?',
  'Where is our diesel inventory located and what is the days of cover?',
  'What happens to EBITDA if refining margins fall by $5/bbl?',
  'Which crude cargo opportunity yields the highest netback refining value?',
  'What is our largest operational and commodity risk exposure right now?',
];

export const CopilotDrawer: React.FC<CopilotDrawerProps> = ({
  isOpen,
  onClose,
  activeModule,
}) => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<CopilotResponse | null>(null);

  if (!isOpen) return null;

  const handleSend = async (textToSend?: string) => {
    const queryText = textToSend || prompt;
    if (!queryText.trim()) return;

    setLoading(true);
    setResponse(null);

    try {
      const res = await fetch('/api/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: queryText, moduleContext: activeModule }),
      });
      const data = await res.json();
      setResponse(data);
    } catch (err) {
      console.error('Copilot request failed:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-lg bg-slate-900 border-l border-slate-700 shadow-2xl flex flex-col text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/20 text-purple-400 rounded-lg border border-purple-500/30">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-100 text-lg flex items-center gap-2">
              TXE COPILOT <Sparkles className="w-4 h-4 text-amber-400" />
            </h3>
            <p className="text-xs text-slate-400">Enterprise AI Operational Advisor</p>
          </div>
        </div>
        <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Content View */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Safety Boundary Banner */}
        <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg text-xs font-mono text-amber-300 flex items-start gap-2">
          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
          <div>
            <strong>SAFETY BOUNDARY ACTIVE:</strong> Copilot provides advisory, predictive, and netback analysis. Physical control remains restricted to physical PLC/DCS systems and authorized human operators.
          </div>
        </div>

        {/* Quick Sample Prompts */}
        <div className="space-y-2">
          <span className="text-xs font-mono text-slate-500 uppercase tracking-wider">RECOMMENDED QUERIES</span>
          <div className="space-y-1.5">
            {SAMPLE_PROMPTS.map((sample, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setPrompt(sample);
                  handleSend(sample);
                }}
                className="w-full text-left p-2.5 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 rounded-lg text-xs text-slate-300 transition-colors"
              >
                {sample}
              </button>
            ))}
          </div>
        </div>

        {/* Loading Spinner */}
        {loading && (
          <div className="p-6 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-center gap-3 text-slate-400 font-mono text-xs">
            <div className="w-4 h-4 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
            Analyzing enterprise Digital Twin & LP matrices...
          </div>
        )}

        {/* Response View */}
        {response && (
          <div className="space-y-4 bg-slate-950 p-5 rounded-xl border border-purple-500/30">
            <div>
              <span className="text-xs font-mono text-purple-400 font-bold uppercase tracking-wider">COPILOT ANALYSIS</span>
              <p className="mt-2 text-sm text-slate-200 leading-relaxed font-sans">{response.answer}</p>
            </div>

            {/* Recommended Actions */}
            {response.recommendedActions && response.recommendedActions.length > 0 && (
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-1">
                <span className="text-xs font-mono text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> RECOMMENDED ACTIONS
                </span>
                <ul className="text-xs text-slate-300 list-disc list-inside space-y-1 font-sans">
                  {response.recommendedActions.map((action, i) => (
                    <li key={i}>{action}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Metadata Provenance Breakdown */}
            <div className="pt-3 border-t border-slate-800 space-y-2 text-xs font-mono">
              <div className="flex items-center gap-2 text-slate-400">
                <Database className="w-3.5 h-3.5 text-blue-400" />
                <span className="text-slate-500">DATA SOURCES:</span>
                <span className="text-slate-300">{response.dataSources.join(', ')}</span>
              </div>

              <div className="flex items-center gap-2 text-slate-400">
                <Cpu className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-slate-500">MODEL:</span>
                <span className="text-slate-300">{response.underlyingModel}</span>
              </div>

              <div className="text-slate-400">
                <span className="text-slate-500">ASSUMPTIONS:</span>
                <div className="text-slate-300">{response.assumptions.join(' · ')}</div>
              </div>

              <div className="flex justify-between items-center text-slate-500 pt-1">
                <span>Confidence: <strong className="text-emerald-400">{response.confidenceScore}%</strong></span>
                <span>Guardrail: <strong className="text-emerald-400">ENFORCED</strong></span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Query Input Bar */}
      <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask TXE Copilot about refinery margin, cargoes, risk..."
          className="flex-1 bg-slate-900 text-slate-100 text-xs px-3 py-2.5 rounded-lg border border-slate-700 focus:outline-none focus:border-purple-500 font-sans"
        />
        <button
          onClick={() => handleSend()}
          disabled={loading}
          className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
        >
          <Send className="w-3.5 h-3.5" /> Ask
        </button>
      </div>
    </div>
  );
};
