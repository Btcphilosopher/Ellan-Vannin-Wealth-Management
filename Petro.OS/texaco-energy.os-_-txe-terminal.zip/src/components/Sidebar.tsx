/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Sidebar - Enterprise Navigation Taxonomy
 */

import React from 'react';
import { NavigationModule } from '../types';
import {
  LayoutDashboard,
  Droplet,
  Ship,
  Factory,
  Warehouse,
  GitMerge,
  Fuel,
  CreditCard,
  Plane,
  TrendingUp,
  BarChart2,
  Lock,
  ShieldCheck,
  DollarSign,
  Briefcase,
  Layers,
  ShieldAlert,
  Leaf,
  Wrench,
  Compass,
  Sliders,
  Smartphone,
} from 'lucide-react';

interface SidebarProps {
  activeModule: NavigationModule;
  onSelectModule: (mod: NavigationModule) => void;
}

interface NavGroup {
  label: string;
  items: { code: NavigationModule; name: string; icon: React.ReactNode }[];
}

export const Sidebar: React.FC<SidebarProps> = ({ activeModule, onSelectModule }) => {
  const navGroups: NavGroup[] = [
    {
      label: 'EXECUTIVE & COMMAND',
      items: [
        { code: 'EXEC', name: 'Executive Command', icon: <LayoutDashboard className="w-4 h-4" /> },
        { code: 'BOARD', name: 'Board Room', icon: <Compass className="w-4 h-4" /> },
      ],
    },
    {
      label: 'SUPPLY & REFINING',
      items: [
        { code: 'CRUDE', name: 'Crude.OS Assays', icon: <Droplet className="w-4 h-4" /> },
        { code: 'SUPPLY', name: 'Cargo & Supply Tower', icon: <Ship className="w-4 h-4" /> },
        { code: 'REFINERY', name: 'Refinery.OS Twin', icon: <Factory className="w-4 h-4" /> },
        { code: 'MAINT', name: 'Maintenance & Turnaround', icon: <Wrench className="w-4 h-4" /> },
      ],
    },
    {
      label: 'LOGISTICS & TERMINALS',
      items: [
        { code: 'TERMINALS', name: 'Terminal Tank Farm', icon: <Warehouse className="w-4 h-4" /> },
        { code: 'PIPELINES', name: 'Pipeline Batches', icon: <GitMerge className="w-4 h-4" /> },
      ],
    },
    {
      label: 'DOWNSTREAM MARKETS',
      items: [
        { code: 'RETAIL', name: 'Texaco Retail Forecourts', icon: <Fuel className="w-4 h-4" /> },
        { code: 'FLEET', name: 'Fleet Fuel Cards', icon: <CreditCard className="w-4 h-4" /> },
        { code: 'AVIATION', name: 'Aviation Fuels', icon: <Plane className="w-4 h-4" /> },
      ],
    },
    {
      label: 'TRADING & RISK',
      items: [
        { code: 'TRADING', name: 'TXE Trading Floor', icon: <TrendingUp className="w-4 h-4" /> },
        { code: 'MARKETS', name: 'Market Screen', icon: <BarChart2 className="w-4 h-4" /> },
        { code: 'HEDGE', name: 'Hedge Book', icon: <Lock className="w-4 h-4" /> },
        { code: 'RISK', name: 'Market Risk & VaR', icon: <ShieldCheck className="w-4 h-4" /> },
      ],
    },
    {
      label: 'FINANCE & CAPITAL',
      items: [
        { code: 'FINANCE', name: 'Finance.OS Ledger', icon: <DollarSign className="w-4 h-4" /> },
        { code: 'CASH', name: '13-Wk Cash Forecast', icon: <Briefcase className="w-4 h-4" /> },
        { code: 'CAPEX', name: 'Capital Allocation', icon: <Layers className="w-4 h-4" /> },
      ],
    },
    {
      label: 'HSE & STRATEGY',
      items: [
        { code: 'HSE', name: 'HSE & Process Safety', icon: <ShieldAlert className="w-4 h-4" /> },
        { code: 'ENV', name: 'Carbon Economics', icon: <Leaf className="w-4 h-4" /> },
        { code: 'SCENARIO', name: 'Strategy Scenarios', icon: <Sliders className="w-4 h-4" /> },
        { code: 'MOBILE', name: 'TXE Mobile App', icon: <Smartphone className="w-4 h-4" /> },
      ],
    },
  ];

  return (
    <aside className="w-60 bg-slate-950 border-r border-slate-800 flex flex-col justify-between select-none shrink-0 overflow-y-auto">
      <div className="p-3 space-y-6">
        {navGroups.map((group, idx) => (
          <div key={idx} className="space-y-1">
            <div className="px-3 text-[10px] font-mono text-slate-500 uppercase tracking-widest">
              {group.label}
            </div>
            {group.items.map((item) => {
              const isActive = activeModule === item.code;
              return (
                <button
                  key={item.code}
                  onClick={() => onSelectModule(item.code)}
                  className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    isActive
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className={isActive ? 'text-amber-400' : 'text-slate-500'}>
                      {item.icon}
                    </span>
                    <span>{item.name}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-600">
                    {item.code}
                  </span>
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Footer Disclaimer & System Mode */}
      <div className="p-3 bg-slate-900/60 border-t border-slate-800 text-[10px] font-mono text-slate-500 space-y-1">
        <div className="flex justify-between items-center text-slate-400">
          <span>TXE TERMINAL</span>
          <span className="text-emerald-400">ONLINE</span>
        </div>
        <div className="truncate">DEMO OPERATIONAL MODEL</div>
      </div>
    </aside>
  );
};
