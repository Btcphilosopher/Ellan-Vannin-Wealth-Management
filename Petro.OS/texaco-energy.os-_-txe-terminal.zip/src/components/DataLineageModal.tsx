/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Data Lineage Modal - "Where Did This Number Come From?"
 */

import React from 'react';
import { DataProvenance } from '../types';
import { ShieldCheck, Database, GitCommit, Cpu, Clock, X } from 'lucide-react';

interface DataLineageModalProps {
  metricName: string;
  metricValue: string | number;
  provenance: DataProvenance | null;
  onClose: () => void;
}

export const DataLineageModal: React.FC<DataLineageModalProps> = ({
  metricName,
  metricValue,
  provenance,
  onClose,
}) => {
  if (!provenance) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-800/80 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg border border-amber-500/30">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100 text-lg">DATA PROVENANCE & AUDIT TRAIL</h3>
              <p className="text-xs text-slate-400">TEXACO ENERGY.OS Lineage Verification Engine</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Value Display */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-wider text-slate-500 font-mono">SELECTED KPI</span>
            <div className="text-xl font-bold text-amber-400 tracking-tight font-mono">{metricName}</div>
          </div>
          <div className="text-right">
            <span className="text-xs uppercase tracking-wider text-slate-500 font-mono">REPORTED VALUE</span>
            <div className="text-2xl font-bold text-emerald-400 font-mono">{metricValue}</div>
          </div>
        </div>

        {/* Provenance Pipeline */}
        <div className="p-6 space-y-4 text-xs font-mono">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-3 bg-slate-800/50 rounded-lg border border-slate-700/60">
              <div className="flex items-center gap-2 text-slate-400 mb-1">
                <Database className="w-4 h-4 text-blue-400" />
                <span className="font-semibold text-slate-300">1. SOURCE SYSTEM</span>
              </div>
              <div className="text-slate-200 font-semibold">{provenance.sourceSystem}</div>
            </div>

            <div className="p-3 bg-slate-800/50 rounded-lg border border-slate-700/60">
              <div className="flex items-center gap-2 text-slate-400 mb-1">
                <GitCommit className="w-4 h-4 text-purple-400" />
                <span className="font-semibold text-slate-300">2. INGESTION PIPELINE</span>
              </div>
              <div className="text-slate-200">{provenance.ingestionPipeline}</div>
            </div>

            <div className="p-3 bg-slate-800/50 rounded-lg border border-slate-700/60">
              <div className="flex items-center gap-2 text-slate-400 mb-1">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="font-semibold text-slate-300">3. VALIDATION RULE</span>
              </div>
              <div className="text-slate-200">{provenance.validationRule}</div>
            </div>

            <div className="p-3 bg-slate-800/50 rounded-lg border border-slate-700/60">
              <div className="flex items-center gap-2 text-slate-400 mb-1">
                <Cpu className="w-4 h-4 text-amber-400" />
                <span className="font-semibold text-slate-300">4. TRANSFORMATION MODEL</span>
              </div>
              <div className="text-slate-200">{provenance.transformationModel}</div>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-950 rounded-lg border border-slate-800 text-slate-400">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500" />
              <span>Timestamp: {provenance.timestamp}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500">Confidence Score:</span>
              <span className="font-bold text-emerald-400">{provenance.confidenceScore}%</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-800/60 border-t border-slate-700 flex justify-between items-center text-xs">
          <span className="text-slate-400">
            Category: <strong className="text-amber-400">{provenance.dataCategory}</strong>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-700 hover:bg-slate-600 text-white font-medium rounded-lg transition-colors"
          >
            Close Provenance Trace
          </button>
        </div>
      </div>
    </div>
  );
};
