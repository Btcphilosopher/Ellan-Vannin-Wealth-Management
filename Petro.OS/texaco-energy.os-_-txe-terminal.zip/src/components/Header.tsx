/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Header - Top Navigation & Command Bar
 */

import React, { useState, useEffect } from 'react';
import { NavigationModule } from '../types';
import { Terminal, Bot, Smartphone, LayoutDashboard, Clock } from 'lucide-react';

interface HeaderProps {
  activeModule: NavigationModule;
  onSelectModule: (mod: NavigationModule) => void;
  onOpenCommandPalette: () => void;
  onOpenCopilot: () => void;
  isBoardRoomMode: boolean;
  onToggleBoardRoom: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeModule,
  onSelectModule,
  onOpenCommandPalette,
  onOpenCopilot,
  isBoardRoomMode,
  onToggleBoardRoom,
}) => {
  const [timeString, setTimeString] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeString(
        now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' GMT'
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="h-14 bg-slate-950 border-b border-slate-800 px-4 flex items-center justify-between gap-6 select-none shrink-0">
      {/* Zone 1: Brand Wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onSelectModule('EXEC');
          }}
          className="text-base font-bold tracking-tight text-white flex items-center gap-2 whitespace-nowrap"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
          TEXACO ENERGY.OS
          <span className="text-xs px-1.5 py-0.5 bg-slate-800 text-amber-400 font-mono rounded">
            TXE
          </span>
        </a>
      </div>

      {/* Zone 2: Command Search Bar (TXE <GO>) */}
      <div className="flex-1 max-w-xl">
        <button
          onClick={onOpenCommandPalette}
          className="w-full h-8 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 rounded-lg px-3 flex items-center justify-between text-xs font-mono text-slate-400 transition-colors group"
        >
          <div className="flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-amber-400" />
            <span>COMMAND: <strong className="text-amber-400">{activeModule} &lt;GO&gt;</strong></span>
          </div>
          <span className="text-slate-500 group-hover:text-slate-300">PRESS CTRL+K OR CLICK TO SEARCH</span>
        </button>
      </div>

      {/* Zone 3: Live Clock & Executive Actions */}
      <div className="flex items-center gap-3 shrink-0">
        {/* System Clock */}
        <div className="hidden lg:flex items-center gap-1.5 text-xs font-mono text-slate-400 px-2.5 py-1 bg-slate-900 rounded border border-slate-800">
          <Clock className="w-3.5 h-3.5 text-slate-500" />
          <span>{timeString}</span>
        </div>

        {/* Board Room Toggle */}
        <button
          onClick={onToggleBoardRoom}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors flex items-center gap-1.5 ${
            isBoardRoomMode
              ? 'bg-amber-500 text-slate-950 border-amber-400 font-semibold shadow-lg shadow-amber-500/20'
              : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800'
          }`}
        >
          <LayoutDashboard className="w-3.5 h-3.5" />
          <span>Board Room</span>
        </button>

        {/* Mobile View Toggle */}
        <button
          onClick={() => onSelectModule('MOBILE')}
          className={`p-1.5 text-xs font-medium rounded-lg border transition-colors ${
            activeModule === 'MOBILE'
              ? 'bg-slate-800 text-amber-400 border-amber-500/40'
              : 'bg-slate-900 hover:bg-slate-800 text-slate-400 border-slate-800'
          }`}
          title="TXE Mobile Executive Preview"
        >
          <Smartphone className="w-4 h-4" />
        </button>

        {/* Copilot Launcher */}
        <button
          onClick={onOpenCopilot}
          className="px-3 py-1.5 bg-purple-600/90 hover:bg-purple-500 text-white text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 shadow-md shadow-purple-600/20"
        >
          <Bot className="w-3.5 h-3.5" />
          <span>TXE Copilot</span>
        </button>
      </div>
    </header>
  );
};
