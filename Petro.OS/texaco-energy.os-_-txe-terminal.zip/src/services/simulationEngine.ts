/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Energy Operating System Engine
 * Linear Programming Optimization, Monte Carlo Risk & Data Provenance
 */

import {
  CrudeCargoOpportunity,
  RefineryEconomics,
  ScenarioInput,
  MonteCarloResult,
  DataProvenance,
} from '../types';
import {
  SYNTHETIC_CRUDE_CARGOES,
  SYNTHETIC_MARKETS,
  SYNTHETIC_FINANCIALS,
} from '../data/syntheticData';

/**
 * Data Lineage Inspector - Returns detailed provenance for any clicked KPI or metric
 */
export function getMetricProvenance(
  metricKey: string,
  category: 'PHYSICAL' | 'FINANCIAL' | 'MARKET' | 'MODELLED' | 'SCENARIO' = 'PHYSICAL'
): DataProvenance {
  const provenanceMap: Record<string, DataProvenance> = {
    revenueGbp: {
      sourceSystem: 'SAP S/4HANA Finance [GL-4010]',
      ingestionPipeline: 'Apache Kafka Event Stream -> TXE Finance Pipeline',
      validationRule: 'IFRS-15 Revenue Recognition & Currency Translation',
      transformationModel: 'Consolidated Group Revenue Aggregator (1.284 GBP/USD)',
      timestamp: new Date().toISOString(),
      confidenceScore: 99.8,
      dataCategory: 'FINANCIAL',
    },
    ebitdaGbp: {
      sourceSystem: 'TXE Finance OS Consolidated Ledger',
      ingestionPipeline: 'Daily Operating Review (DOR) Financial Pipeline',
      validationRule: 'EBITDA = Gross Margin - Opex - Logistics - G&A',
      transformationModel: 'Segmental EBITDA Waterfall Matrix',
      timestamp: new Date().toISOString(),
      confidenceScore: 99.5,
      dataCategory: 'FINANCIAL',
    },
    refineryThroughput: {
      sourceSystem: 'Honeywell Experion DCS / SCADA Pembroke CDU-101 & CDU-102',
      ingestionPipeline: 'Modbus TCP / OPC-UA -> OSIsoft PI Asset Framework',
      validationRule: 'Physical Mass Flow Measurement +/- 0.15% Volumetric',
      transformationModel: 'Standard Density Temperature Correction (API MPMS Ch. 11.1)',
      timestamp: new Date().toISOString(),
      confidenceScore: 99.9,
      dataCategory: 'PHYSICAL',
    },
    grossRefiningMargin: {
      sourceSystem: 'TXE LP Optimiser & Market Price Engine',
      ingestionPipeline: 'ICE Futures & Platts Spot Feed -> Netback Calculator',
      validationRule: 'Yield Product Revenue - Crude Landed Cost - Variable Energy',
      transformationModel: 'Refinery Linear Programming (LP) Blend Model',
      timestamp: new Date().toISOString(),
      confidenceScore: 98.2,
      dataCategory: 'MODELLED',
    },
    brentPrice: {
      sourceSystem: 'ICE Futures Europe Terminal Feed [LCO]',
      ingestionPipeline: 'Fix Protocol Market Telemetry Gateway',
      validationRule: 'Tick-by-tick VWAP Verification',
      transformationModel: 'Spot & Front-Month Forward Curve Interpolation',
      timestamp: new Date().toISOString(),
      confidenceScore: 100.0,
      dataCategory: 'MARKET',
    },
  };

  if (provenanceMap[metricKey]) {
    return provenanceMap[metricKey];
  }

  return {
    sourceSystem: 'TXE Enterprise Digital Twin Engine',
    ingestionPipeline: 'Synthetic Real-time Operational Telemetry Stream',
    validationRule: 'Mass Balance & Thermodynamic Conservation Invariant',
    transformationModel: 'Vertically Integrated Energy Matrix (Crude->Refinery->Market)',
    timestamp: new Date().toISOString(),
    confidenceScore: 98.5,
    dataCategory: category,
  };
}

/**
 * Cargo Netback & Refining Opportunity Ranking Engine
 */
export function calculateCargoNetback(
  opportunity: CrudeCargoOpportunity
): CrudeCargoOpportunity {
  const landedCostUsd =
    opportunity.purchasePriceUsd +
    opportunity.freightUsd +
    opportunity.insuranceUsd +
    opportunity.portCostUsd +
    opportunity.qualityAdjustmentUsd +
    opportunity.financingUsd +
    opportunity.demurrageRiskUsd;

  const expectedMarginPerBbl =
    opportunity.expectedProductValueUsd - landedCostUsd - opportunity.refiningCostUsd;

  const expectedMarginUsd = expectedMarginPerBbl * opportunity.volumeBbl;

  return {
    ...opportunity,
    landedCostUsd: Number(landedCostUsd.toFixed(2)),
    expectedMarginPerBbl: Number(expectedMarginPerBbl.toFixed(2)),
    expectedMarginUsd: Math.round(expectedMarginUsd),
  };
}

/**
 * Linear Programming (LP) Refinery Yield Optimizer
 */
export interface LpOptimizationResult {
  crudeRunsBblDay: { brent: number; forties: number; wti: number; johan: number };
  unitThroughputsBblDay: { cdu: number; vdu: number; fcc: number; hydrocracker: number; hydrotreater: number };
  productYieldsBblDay: {
    gasoline: number;
    diesel: number;
    jetFuel: number;
    lpg: number;
    fuelOil: number;
  };
  economicSummary: RefineryEconomics;
  constraintsMet: boolean;
  shadowPricesUsd: { cduCapacity: number; fccCapacity: number; hydrogenConstraint: number };
}

export function runRefineryLpOptimizer(
  brentPrice: number = 82.4,
  gasolineCrack: number = 16.5,
  dieselCrack: number = 24.8,
  jetCrack: number = 22.1,
  carbonPriceEur: number = 85.0
): LpOptimizationResult {
  // LP Decision Variables (Simulated LP Solver using Simplex / Gradient Descent)
  const brentRun = 60000;
  const fortiesRun = 75000;
  const wtiRun = 85000;
  const johanRun = 27590;

  const totalCrudeRun = brentRun + fortiesRun + wtiRun + johanRun; // 247,590 bbl/day

  // Product Yield Matrix
  const gasolineYield = totalCrudeRun * 0.38; // ~94,084 bbl/d
  const dieselYield = totalCrudeRun * 0.34; // ~84,180 bbl/d
  const jetYield = totalCrudeRun * 0.12; // ~29,710 bbl/d
  const lpgYield = totalCrudeRun * 0.05; // ~12,379 bbl/d
  const fuelOilYield = totalCrudeRun * 0.08; // ~19,807 bbl/d

  // Revenue calculation from product cracks
  const gasolineRevenue = gasolineYield * (brentPrice + gasolineCrack);
  const dieselRevenue = dieselYield * (brentPrice + dieselCrack);
  const jetRevenue = jetYield * (brentPrice + jetCrack);
  const lpgRevenue = lpgYield * (brentPrice - 18.0);
  const fuelOilRevenue = fuelOilYield * (brentPrice - 22.0);

  const totalProductRevenueUsd =
    gasolineRevenue + dieselRevenue + jetRevenue + lpgRevenue + fuelOilRevenue;

  const totalCrudeCostUsd =
    brentRun * brentPrice +
    fortiesRun * (brentPrice - 0.45) +
    wtiRun * (brentPrice - 4.5 + 3.45) + // WTI landed
    johanRun * (brentPrice - 2.85);

  const energyCostUsd = 685000;
  const carbonCostUsd = (carbonPriceEur * 1.08 * 4820) / 1.0; // Carbon price impact

  const grossMarginTotalUsd = totalProductRevenueUsd - totalCrudeCostUsd;
  const grossMarginPerBbl = grossMarginTotalUsd / totalCrudeRun;
  const operatingCostPerBbl = (energyCostUsd + carbonCostUsd + 180000) / totalCrudeRun;
  const netMarginPerBbl = grossMarginPerBbl - operatingCostPerBbl;

  const crack321 = (2 * gasolineCrack + 1 * dieselCrack) / 3;
  const crack532 = (3 * gasolineCrack + 2 * dieselCrack) / 5;

  return {
    crudeRunsBblDay: { brent: brentRun, forties: fortiesRun, wti: wtiRun, johan: johanRun },
    unitThroughputsBblDay: {
      cdu: totalCrudeRun,
      vdu: 98000,
      fcc: 62500,
      hydrocracker: 42800,
      hydrotreater: 81200,
    },
    productYieldsBblDay: {
      gasoline: Math.round(gasolineYield),
      diesel: Math.round(dieselYield),
      jetFuel: Math.round(jetYield),
      lpg: Math.round(lpgYield),
      fuelOil: Math.round(fuelOilYield),
    },
    economicSummary: {
      crudeThroughputBblDay: totalCrudeRun,
      grossMarginUsdPerBbl: Number(grossMarginPerBbl.toFixed(2)),
      operatingCostUsdPerBbl: Number(operatingCostPerBbl.toFixed(2)),
      netMarginUsdPerBbl: Number(netMarginPerBbl.toFixed(2)),
      dailyEbitdaUsd: Math.round(netMarginPerBbl * totalCrudeRun),
      crack321Usd: Number(crack321.toFixed(2)),
      crack532Usd: Number(crack532.toFixed(2)),
      energyCostPerDayUsd: energyCostUsd,
      carbonCostPerDayUsd: Math.round(carbonCostUsd),
    },
    constraintsMet: true,
    shadowPricesUsd: {
      cduCapacity: 4.85,
      fccCapacity: 12.4,
      hydrogenConstraint: 8.2,
    },
  };
}

/**
 * Monte Carlo Risk Engine (Runs 1,000 to 100,000 simulations)
 */
export function runMonteCarloSimulation(
  iterations: number = 10000,
  scenario?: ScenarioInput
): MonteCarloResult {
  const baseEbitda = SYNTHETIC_FINANCIALS.ebitdaGbp;
  const baseFcf = SYNTHETIC_FINANCIALS.freeCashFlowGbp;

  let ebitdaShift = 0;
  if (scenario) {
    ebitdaShift += scenario.brentPriceDeltaUsd * 8500000;
    ebitdaShift += scenario.gasolineCrackDeltaUsd * 12000000;
    ebitdaShift += scenario.dieselCrackDeltaUsd * 15000000;
    ebitdaShift -= scenario.refineryOutageDays * 2030000;
    ebitdaShift -= (scenario.carbonPriceEurTon - 85.0) * 1200000;
  }

  const resultsEbitda: number[] = [];
  const varDistribution: number[] = [];

  // Seeded pseudo-random Monte Carlo sampling
  const stdDevEbitda = 120000000; // £120m standard deviation

  for (let i = 0; i < iterations; i++) {
    // Box-Muller transform for normal distribution
    const u1 = Math.random() || 0.0001;
    const u2 = Math.random() || 0.0001;
    const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);

    const simulatedVal = baseEbitda + ebitdaShift + z * stdDevEbitda;
    resultsEbitda.push(simulatedVal);

    if (i < 50) {
      varDistribution.push(Number((simulatedVal / 1e6).toFixed(1)));
    }
  }

  resultsEbitda.sort((a, b) => a - b);

  const ebitda5th = resultsEbitda[Math.floor(iterations * 0.05)];
  const ebitda95th = resultsEbitda[Math.floor(iterations * 0.95)];
  const ebitdaMean = resultsEbitda.reduce((acc, v) => acc + v, 0) / iterations;

  return {
    simulationsCount: iterations,
    ebitdaMeanGbp: Math.round(ebitdaMean),
    ebitda5thPercentileGbp: Math.round(ebitda5th),
    ebitda95thPercentileGbp: Math.round(ebitda95th),
    freeCashFlowMeanGbp: Math.round(ebitdaMean - 960000000),
    varProbabilityDistribution: varDistribution,
  };
}
