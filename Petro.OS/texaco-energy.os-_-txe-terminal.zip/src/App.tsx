/**
 * TEXACO ENERGY.OS (TXE Terminal)
 * Main Application Hub & State Orchestrator
 */

import React, { useState, useEffect } from 'react';
import { NavigationModule, DataProvenance } from './types';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DataLineageModal } from './components/DataLineageModal';
import { CommandPalette } from './components/CommandPalette';
import { CopilotDrawer } from './components/CopilotDrawer';

import { ExecutiveView } from './views/ExecutiveView';
import { CrudeSupplyView } from './views/CrudeSupplyView';
import { RefineryView } from './views/RefineryView';
import { LogisticsView } from './views/LogisticsView';
import { RetailView } from './views/RetailView';
import { FleetAviationView } from './views/FleetAviationView';
import { TradingRiskView } from './views/TradingRiskView';
import { FinanceView } from './views/FinanceView';
import { HseEnvironmentView } from './views/HseEnvironmentView';
import { MaintenanceView } from './views/MaintenanceView';
import { StrategyScenarioView } from './views/StrategyScenarioView';
import { MobileAppView } from './views/MobileAppView';

export default function App() {
  const [activeModule, setActiveModule] = useState<NavigationModule>('EXEC');
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);
  const [isBoardRoomMode, setIsBoardRoomMode] = useState(false);

  // Data Lineage Modal state
  const [lineageModal, setLineageModal] = useState<{
    metricName: string;
    metricValue: string | number;
    provenance: DataProvenance;
  } | null>(null);

  // Global Ctrl+K keyboard shortcut for Command Palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleInspectDataLineage = (
    metricName: string,
    metricValue: string | number,
    provenance: DataProvenance
  ) => {
    setLineageModal({ metricName, metricValue, provenance });
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-950 text-slate-100 font-sans overflow-hidden select-none">
      {/* Header Bar */}
      <Header
        activeModule={activeModule}
        onSelectModule={(mod) => setActiveModule(mod)}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenCopilot={() => setIsCopilotOpen(true)}
        isBoardRoomMode={isBoardRoomMode}
        onToggleBoardRoom={() => setIsBoardRoomMode((prev) => !prev)}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          activeModule={activeModule}
          onSelectModule={(mod) => setActiveModule(mod)}
        />

        {/* Central Viewport */}
        <main className={`flex-1 overflow-y-auto bg-slate-950 ${isBoardRoomMode ? 'p-2 ring-2 ring-amber-500/40' : ''}`}>
          {/* Board Room Header Banner if active */}
          {isBoardRoomMode && (
            <div className="m-6 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg text-xs font-mono text-amber-300 flex justify-between items-center">
              <span>
                <strong>BOARD ROOM MEETING MODE ACTIVE:</strong> High-density executive scenario analysis & strategic planning view.
              </span>
              <button
                onClick={() => setIsBoardRoomMode(false)}
                className="px-2 py-0.5 bg-amber-500 text-slate-950 font-bold rounded hover:bg-amber-400"
              >
                Exit Board Room
              </button>
            </div>
          )}

          {/* Module Routing */}
          {activeModule === 'EXEC' && (
            <ExecutiveView
              onInspectDataLineage={handleInspectDataLineage}
              isBoardRoomMode={isBoardRoomMode}
            />
          )}

          {(activeModule === 'CRUDE' || activeModule === 'SUPPLY') && (
            <CrudeSupplyView onInspectDataLineage={handleInspectDataLineage} />
          )}

          {activeModule === 'REFINERY' && (
            <RefineryView onInspectDataLineage={handleInspectDataLineage} />
          )}

          {(activeModule === 'TERMINALS' || activeModule === 'PIPELINES') && (
            <LogisticsView onInspectDataLineage={handleInspectDataLineage} />
          )}

          {activeModule === 'RETAIL' && (
            <RetailView onInspectDataLineage={handleInspectDataLineage} />
          )}

          {(activeModule === 'FLEET' || activeModule === 'AVIATION') && (
            <FleetAviationView onInspectDataLineage={handleInspectDataLineage} />
          )}

          {(activeModule === 'TRADING' ||
            activeModule === 'MARKETS' ||
            activeModule === 'HEDGE' ||
            activeModule === 'RISK') && (
            <TradingRiskView onInspectDataLineage={handleInspectDataLineage} />
          )}

          {(activeModule === 'FINANCE' ||
            activeModule === 'CASH' ||
            activeModule === 'CAPEX') && (
            <FinanceView onInspectDataLineage={handleInspectDataLineage} />
          )}

          {activeModule === 'MAINT' && (
            <MaintenanceView onInspectDataLineage={handleInspectDataLineage} />
          )}

          {(activeModule === 'HSE' || activeModule === 'ENV') && (
            <HseEnvironmentView onInspectDataLineage={handleInspectDataLineage} />
          )}

          {(activeModule === 'SCENARIO' ||
            activeModule === 'OPT' ||
            activeModule === 'BOARD') && (
            <StrategyScenarioView onInspectDataLineage={handleInspectDataLineage} />
          )}

          {activeModule === 'MOBILE' && <MobileAppView />}
        </main>
      </div>

      {/* Interactive Overlay Modals */}
      <DataLineageModal
        metricName={lineageModal?.metricName || ''}
        metricValue={lineageModal?.metricValue || ''}
        provenance={lineageModal?.provenance || null}
        onClose={() => setLineageModal(null)}
      />

      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onSelectModule={(mod) => setActiveModule(mod)}
      />

      <CopilotDrawer
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        activeModule={activeModule}
      />
    </div>
  );
}
