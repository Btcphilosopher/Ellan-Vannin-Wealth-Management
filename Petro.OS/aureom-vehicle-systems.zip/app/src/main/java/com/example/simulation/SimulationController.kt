package com.example.simulation

import com.example.domain.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SimulationController(
    private val physicsEngine: VehiclePhysicsEngine = VehiclePhysicsEngine()
) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    val defaultVehicle = Vehicle(
        id = "aureom-ev-01",
        vin = "VF3AUR2026X908123",
        name = "Aureom E-Segment GT",
        variant = "800V Dual Motor Long Range",
        architecture = PowertrainArchitecture.BEV,
        config = VehicleConfig(
            batteryCapacityKwh = 82.0,
            usableBatteryKwh = 77.0,
            maxMotorPowerKw = 280.0,
            chargingMaxKw = 170.0
        )
    )

    private val _selectedVehicle = MutableStateFlow(defaultVehicle)
    val selectedVehicle: StateFlow<Vehicle> = _selectedVehicle.asStateFlow()

    private val _currentTelemetry = MutableStateFlow(
        TelemetrySample(vehicleId = defaultVehicle.id)
    )
    val currentTelemetry: StateFlow<TelemetrySample> = _currentTelemetry.asStateFlow()

    private val _activeScenario = MutableStateFlow(DrivingScenarios.URBAN_COMMUTE)
    val activeScenario: StateFlow<DrivingScenario> = _activeScenario.asStateFlow()

    private val _isRunning = MutableStateFlow(true)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _speedMultiplier = MutableStateFlow(1.0)
    val speedMultiplier: StateFlow<Double> = _speedMultiplier.asStateFlow()

    private val _activeFaults = MutableStateFlow<Set<FaultType>>(emptySet())
    val activeFaults: StateFlow<Set<FaultType>> = _activeFaults.asStateFlow()

    private val _dtcList = MutableStateFlow<List<DiagnosticTroubleCode>>(emptyList())
    val dtcList: StateFlow<List<DiagnosticTroubleCode>> = _dtcList.asStateFlow()

    private var simulationJob: Job? = null
    private var scenarioStepIndex = 0
    private var scenarioStepTimerSec = 0.0

    init {
        startSimulationLoop()
    }

    fun setVehicle(vehicle: Vehicle) {
        _selectedVehicle.value = vehicle
        _currentTelemetry.value = TelemetrySample(vehicleId = vehicle.id)
    }

    fun setScenario(scenario: DrivingScenario) {
        _activeScenario.value = scenario
        scenarioStepIndex = 0
        scenarioStepTimerSec = 0.0
    }

    fun setDriveMode(mode: DriveMode) {
        _currentTelemetry.value = _currentTelemetry.value.copy(driveMode = mode)
    }

    fun toggleSimulation() {
        _isRunning.value = !_isRunning.value
    }

    fun setSpeedMultiplier(multiplier: Double) {
        _speedMultiplier.value = multiplier
    }

    fun injectFault(fault: FaultType) {
        val current = _activeFaults.value.toMutableSet()
        current.add(fault)
        _activeFaults.value = current
        updateDiagnosticsForFault(fault, active = true)
    }

    fun resolveFault(fault: FaultType) {
        val current = _activeFaults.value.toMutableSet()
        current.remove(fault)
        _activeFaults.value = current
        updateDiagnosticsForFault(fault, active = false)
    }

    fun resetFaults() {
        _activeFaults.value = emptySet()
        _dtcList.value = emptyList()
    }

    fun resetTrip() {
        _currentTelemetry.value = _currentTelemetry.value.copy(
            tripDistanceKm = 0.0,
            powerKw = 0.0,
            speedKmh = 0.0
        )
    }

    private fun updateDiagnosticsForFault(fault: FaultType, active: Boolean) {
        val dtcMap = mapOf(
            FaultType.BATTERY_OVERHEAT to DiagnosticTroubleCode(
                code = "P0A7F",
                description = "Hybrid/EV Battery Pack Temperature Cell Overheat State",
                severity = DiagnosticSeverity.CRITICAL,
                subsystem = "BATTERY_MANAGEMENT",
                inspectionRecommendation = "Inspect high-voltage battery coolant circuit and thermal expansion valve."
            ),
            FaultType.SPEED_SENSOR_DROPOUT to DiagnosticTroubleCode(
                code = "C0035",
                description = "Wheel Speed Sensor Signal Circuit Dropout Fault",
                severity = DiagnosticSeverity.WARNING,
                subsystem = "BRAKE_CONTROL",
                inspectionRecommendation = "Verify tone ring integrity and wheel speed sensor connector continuity."
            ),
            FaultType.WHEEL_SPEED_DISAGREEMENT to DiagnosticTroubleCode(
                code = "C003B",
                description = "Wheel Speed Plausibility Disagreement Across Axle",
                severity = DiagnosticSeverity.WARNING,
                subsystem = "ABS_ESP",
                inspectionRecommendation = "Check tire rolling circumference and tone wheel tooth count."
            ),
            FaultType.BRAKE_OVERHEAT to DiagnosticTroubleCode(
                code = "C1095",
                description = "Brake Friction Temperature High Thermal Stress Warning",
                severity = DiagnosticSeverity.WARNING,
                subsystem = "BRAKES",
                inspectionRecommendation = "Allow friction pads to cool down. Inspect brake fluid boiling point."
            ),
            FaultType.TIRE_PRESSURE_LOSS to DiagnosticTroubleCode(
                code = "C0750",
                description = "TPMS Rear-Left Tire Low Pressure Alert (1.1 Bar)",
                severity = DiagnosticSeverity.ADVISORY,
                subsystem = "CHASSIS",
                inspectionRecommendation = "Check tire for puncture and re-inflate to nominal 2.4 Bar."
            ),
            FaultType.ECU_COMM_TIMEOUT to DiagnosticTroubleCode(
                code = "U0100",
                description = "Lost Communication With Powertrain Control Module (PCM)",
                severity = DiagnosticSeverity.CRITICAL,
                subsystem = "NETWORK",
                inspectionRecommendation = "Inspect CAN/FD high-speed bus termination resistors and power relays."
            ),
            FaultType.DOOR_AJAR to DiagnosticTroubleCode(
                code = "B1000",
                description = "Driver Front Door Latch Ajar Switch Circuit Open",
                severity = DiagnosticSeverity.INFO,
                subsystem = "BODY_CONTROL",
                inspectionRecommendation = "Ensure door is firmly closed before shifting out of Park."
            ),
            FaultType.SUDDEN_POWER_DERATING to DiagnosticTroubleCode(
                code = "P0A81",
                description = "Propulsion System Power Derating Active Due To Thermal Safeguard",
                severity = DiagnosticSeverity.WARNING,
                subsystem = "POWERTRAIN",
                inspectionRecommendation = "Limit heavy acceleration until drivetrain temperature stabilizes."
            ),
            FaultType.CHARGING_INTERRUPTION to DiagnosticTroubleCode(
                code = "P0D57",
                description = "High Power DC Charger Pilot Signal Interrupted",
                severity = DiagnosticSeverity.WARNING,
                subsystem = "CHARGING",
                inspectionRecommendation = "Inspect EVSE charging connector lock latch and pilot line contact."
            )
        )

        val targetDtc = dtcMap[fault] ?: return
        val currentList = _dtcList.value.toMutableList()
        currentList.removeAll { it.code == targetDtc.code }
        if (active) {
            currentList.add(0, targetDtc)
        }
        _dtcList.value = currentList
    }

    private fun startSimulationLoop() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            while (isActive) {
                delay(100) // 10Hz simulation update frequency
                if (_isRunning.value) {
                    val dt = 0.1 * _speedMultiplier.value
                    val scenario = _activeScenario.value
                    val currentStep = scenario.steps.getOrElse(scenarioStepIndex) { scenario.steps.last() }

                    scenarioStepTimerSec += dt
                    if (scenarioStepTimerSec >= currentStep.durationSec) {
                        scenarioStepTimerSec = 0.0
                        scenarioStepIndex = (scenarioStepIndex + 1) % scenario.steps.size
                    }

                    val updatedSample = physicsEngine.step(
                        currentTelemetry = _currentTelemetry.value,
                        config = _selectedVehicle.value.config,
                        architecture = _selectedVehicle.value.architecture,
                        targetSpeedKmh = currentStep.targetSpeedKmh,
                        gradientPct = currentStep.roadGradientPct,
                        throttleInputPct = currentStep.throttleDemandPct,
                        brakeInputBar = currentStep.brakeDemandBar,
                        activeFaults = _activeFaults.value,
                        deltaTimeSec = dt
                    )

                    _currentTelemetry.value = updatedSample
                }
            }
        }
    }
}
