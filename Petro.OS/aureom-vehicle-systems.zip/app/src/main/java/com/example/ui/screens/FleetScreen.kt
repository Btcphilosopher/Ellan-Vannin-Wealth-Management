package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.FleetVehicle
import com.example.domain.model.PowertrainArchitecture
import com.example.domain.model.TelemetrySample
import com.example.ui.theme.*

@Composable
fun FleetScreen(
    telemetry: TelemetrySample,
    modifier: Modifier = Modifier
) {
    val fleetList = remember {
        listOf(
            FleetVehicle("aureom-ev-01", "VF3AUR2026X908123", "Aureom E-Segment GT", PowertrainArchitecture.BEV, 82.0, "ACTIVE", 48.8566, 2.3522, 54.0, 0, "M. Schumacher", 14250.0),
            FleetVehicle("stellantis-phev-02", "VR7AUR2026P801456", "Aureom Hybrid Executive", PowertrainArchitecture.PHEV, 94.0, "ACTIVE", 48.8600, 2.3400, 32.0, 0, "C. Sainz", 8900.0),
            FleetVehicle("stellantis-ice-03", "ZFAAUR2026I700982", "Aureom V6 Sport Concept", PowertrainArchitecture.ICE, 65.0, "MAINTENANCE", 48.8450, 2.3600, 0.0, 2, "L. Hamilton", 22400.0)
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CockpitBackground)
            .padding(12.dp)
    ) {
        // Fleet Radar & GPS Map Simulation
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = CockpitSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2, size.height / 2)

                    drawCircle(color = CockpitBorder, radius = 60.dp.toPx(), style = Stroke(width = 1.dp.toPx()))
                    drawCircle(color = CockpitBorder, radius = 110.dp.toPx(), style = Stroke(width = 1.dp.toPx()))

                    // Radar sweep line
                    drawLine(
                        color = ElectricCyan.copy(alpha = 0.4f),
                        start = center,
                        end = Offset(center.x + 100.dp.toPx(), center.y - 60.dp.toPx()),
                        strokeWidth = 2.dp.toPx()
                    )

                    // Fleet dots
                    drawCircle(color = ElectricCyan, radius = 6.dp.toPx(), center = Offset(center.x + 20.dp.toPx(), center.y - 15.dp.toPx()))
                    drawCircle(color = PhosphorBlue, radius = 6.dp.toPx(), center = Offset(center.x - 40.dp.toPx(), center.y + 30.dp.toPx()))
                    drawCircle(color = CriticalRed, radius = 6.dp.toPx(), center = Offset(center.x + 50.dp.toPx(), center.y + 40.dp.toPx()))
                }

                Row(
                    modifier = Modifier.align(Alignment.TopStart),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Radar, contentDescription = "Radar", tint = ElectricCyan, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "EUROPEAN FLEET SYNTHETIC RADAR MAP", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }

        Text(text = "REGISTERED FLEET VEHICLES (${fleetList.size})", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(fleetList) { fv ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CockpitSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = fv.modelName, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Text(text = "VIN: ${fv.vin} | Driver: ${fv.driverName}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            BadgeChip(text = "${fv.socOrFuelPct.toInt()}%", color = PhosphorBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            BadgeChip(text = fv.status, color = if (fv.status == "ACTIVE") EcoGreen else CriticalRed)
                        }
                    }
                }
            }
        }
    }
}
