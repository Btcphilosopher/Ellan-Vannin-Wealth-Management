package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.api.AureomApiGateway
import com.example.api.FibredashCliEngine
import com.example.data.AureomDatabase
import com.example.data.VehicleRepository
import com.example.simulation.SimulationController
import com.example.ui.CockpitMainScreen
import com.example.ui.theme.AureomTheme
import com.example.ui.theme.CockpitBackground

class MainActivity : ComponentActivity() {

    private lateinit var simulationController: SimulationController
    private lateinit var apiGateway: AureomApiGateway
    private lateinit var cliEngine: FibredashCliEngine
    private lateinit var repository: VehicleRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = AureomDatabase.getDatabase(applicationContext)
        repository = VehicleRepository(db)

        simulationController = SimulationController()
        apiGateway = AureomApiGateway(simulationController)
        cliEngine = FibredashCliEngine(simulationController, apiGateway)

        setContent {
            AureomTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CockpitBackground
                ) {
                    CockpitMainScreen(
                        controller = simulationController,
                        apiGateway = apiGateway,
                        cliEngine = cliEngine,
                        repository = repository
                    )
                }
            }
        }
    }
}
