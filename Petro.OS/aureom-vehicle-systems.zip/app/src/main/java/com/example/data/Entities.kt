package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vehicles")
data class VehicleEntity(
    @PrimaryKey val id: String,
    val vin: String,
    val name: String,
    val variant: String,
    val architecture: String,
    val massKg: Double,
    val batteryCapacityKwh: Double,
    val maxMotorPowerKw: Double,
    val odometerKm: Double
)

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey val id: String,
    val vehicleId: String,
    val title: String,
    val startTime: Long,
    val endTime: Long,
    val distanceKm: Double,
    val durationSec: Long,
    val avgSpeedKmh: Double,
    val maxSpeedKmh: Double,
    val energyConsumedKwh: Double,
    val avgConsumptionWhKm: Double,
    val fuelConsumedL: Double,
    val regenRecoveredKwh: Double,
    val costEur: Double,
    val co2Kg: Double
)

@Entity(tableName = "diagnostics")
data class DiagnosticEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val vehicleId: String,
    val code: String,
    val description: String,
    val severity: String,
    val subsystem: String,
    val timestamp: Long,
    val active: Boolean
)
