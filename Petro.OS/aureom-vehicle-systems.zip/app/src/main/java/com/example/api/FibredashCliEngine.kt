package com.example.api

import com.example.domain.model.FaultType
import com.example.simulation.DrivingScenarios
import com.example.simulation.SimulationController

class FibredashCliEngine(
    private val controller: SimulationController,
    private val apiGateway: AureomApiGateway
) {
    fun executeCommand(commandLine: String): String {
        val trimmed = commandLine.trim()
        if (trimmed.isEmpty()) return ""

        val parts = trimmed.split("\\s+".toRegex())
        val root = parts[0].lowercase()

        if (root != "fibredash") {
            return "Error: Unknown command root '${parts[0]}'. Use 'fibredash help' for commands."
        }

        if (parts.size == 1 || parts[1].lowercase() == "help") {
            return getHelpText()
        }

        val sub1 = parts[1].lowercase()

        return when (sub1) {
            "init" -> {
                "fibredash v1.4.2 [Aureom Vehicle Systems CLI]\nInitializing synthetic telemetry gateway engine...\nVehicle: ${controller.selectedVehicle.value.name} [${controller.selectedVehicle.value.id}]\nStatus: READY"
            }

            "vehicles" -> {
                if (parts.size > 2 && parts[2].lowercase() == "list") {
                    val res = apiGateway.getVehicles()
                    val sb = StringBuilder("=== VEHICLE FLEET DIRECTORY ===\n")
                    res.data.forEach { v ->
                        sb.append("• ID: ${v["vehicle_id"]}\n  Name: ${v["name"]} [${v["architecture"]}]\n  VIN: ${v["vin"]}\n  Battery: ${v["usable_battery_kwh"]} kWh | Max Power: ${v["max_motor_power_kw"]} kW\n\n")
                    }
                    sb.toString().trim()
                } else if (parts.size > 3 && parts[2].lowercase() == "inspect") {
                    val id = parts[3]
                    val t = controller.currentTelemetry.value
                    """
                    === VEHICLE INSPECTION RECORD ===
                    ID: $id
                    VIN: ${controller.selectedVehicle.value.vin}
                    Model: ${controller.selectedVehicle.value.name} (${controller.selectedVehicle.value.variant})
                    Architecture: ${controller.selectedVehicle.value.architecture}
                    Odometer: ${String.format("%.1f", t.odometerKm)} km
                    Battery SOC: ${String.format("%.1f", t.socPct)}% (${String.format("%.1f", t.batteryVoltageV)} V)
                    Drive Mode: ${t.driveMode}
                    Telemetry Provenance: ${t.provenance}
                    Quality Status: ${t.qualityFlags}
                    """.trimIndent()
                } else {
                    "Usage: fibredash vehicles list | fibredash vehicles inspect <id>"
                }
            }

            "simulate" -> {
                if (parts.size > 2) {
                    when (parts[2].lowercase()) {
                        "start" -> {
                            val scenarioArg = if (parts.size > 4 && parts[3] == "--scenario") parts[4] else "urban"
                            apiGateway.executeScenario(scenarioArg)
                            "Scenario '${scenarioArg}' initiated. Physics telemetry streaming active at 10Hz."
                        }
                        "pause" -> {
                            if (controller.isRunning.value) controller.toggleSimulation()
                            "Simulation execution PAUSED."
                        }
                        "resume" -> {
                            if (!controller.isRunning.value) controller.toggleSimulation()
                            "Simulation execution RESUMED."
                        }
                        "reset" -> {
                            controller.resetTrip()
                            controller.resetFaults()
                            "Simulation trip telemetry and fault state RESET to zero."
                        }
                        else -> "Usage: fibredash simulate [start|pause|resume|reset]"
                    }
                } else {
                    "Usage: fibredash simulate [start|pause|resume|reset]"
                }
            }

            "faults" -> {
                if (parts.size > 3 && parts[2].lowercase() == "inject") {
                    val faultName = parts[3].uppercase()
                    val f = try { FaultType.valueOf(faultName) } catch (e: Exception) { FaultType.BATTERY_OVERHEAT }
                    controller.injectFault(f)
                    "FAULT INJECTED: [${f.name}]. Diagnostic trouble code generated & active on telemetry bus."
                } else if (parts.size > 2 && parts[2].lowercase() == "reset") {
                    controller.resetFaults()
                    "All injected vehicle faults cleared. DTCs cleared."
                } else {
                    "Usage: fibredash faults inject <BATTERY_OVERHEAT|SPEED_SENSOR_DROPOUT|WHEEL_SPEED_DISAGREEMENT|BRAKE_OVERHEAT|TIRE_PRESSURE_LOSS|ECU_COMM_TIMEOUT|DOOR_AJAR|SUDDEN_POWER_DERATING> | fibredash faults reset"
                }
            }

            "telemetry" -> {
                val t = controller.currentTelemetry.value
                """
                === LIVE TELEMETRY SAMPLE STREAM ===
                Timestamp: ${t.timestamp}
                Speed: ${String.format("%.1f", t.speedKmh)} km/h | Accel: ${String.format("%.2f", t.longitudinalAccelG)} g
                Power Demand: ${String.format("%.1f", t.powerKw)} kW | Torque: ${String.format("%.1f", t.torqueNm)} Nm
                Battery: ${String.format("%.1f", t.socPct)}% SOC | ${String.format("%.1f", t.batteryTempC)} °C
                Coolant Temp: ${String.format("%.1f", t.coolantTempC)} °C | Gear: ${t.gear}
                Active Warnings: ${if (t.warnings.isEmpty()) "NONE" else t.warnings.joinToString("; ")}
                Data Quality: ${t.qualityFlags}
                """.trimIndent()
            }

            "diagnostics" -> {
                val dtcs = controller.dtcList.value
                if (dtcs.isEmpty()) {
                    "=== VEHICLE DIAGNOSTICS LOG ===\nNo active Diagnostic Trouble Codes (DTCs). All vehicle subsystems nominal."
                } else {
                    val sb = StringBuilder("=== VEHICLE DIAGNOSTICS LOG (${dtcs.size} ACTIVE DTCs) ===\n")
                    dtcs.forEach { d ->
                        sb.append("• [${d.code}] [${d.severity}] ${d.subsystem}\n  Desc: ${d.description}\n  Rec: ${d.inspectionRecommendation}\n\n")
                    }
                    sb.toString().trim()
                }
            }

            "report" -> {
                val t = controller.currentTelemetry.value
                val v = controller.selectedVehicle.value
                """
                ==========================================================
                AUREOM VEHICLE DIGITAL TWIN HEALTH & TELEMETRY REPORT
                ==========================================================
                Vehicle ID: ${v.id}
                VIN: ${v.vin}
                Name: ${v.name} (${v.variant})
                Architecture: ${v.architecture}
                ----------------------------------------------------------
                Total Odometer: ${String.format("%.1f", t.odometerKm)} km
                Current Trip Distance: ${String.format("%.2f", t.tripDistanceKm)} km
                Battery Health (SOH): ${t.sohPct}%
                Battery Pack Temp: ${String.format("%.1f", t.batteryTempC)} °C (Spread: ${t.cellTempSpreadC} °C)
                Active Faults Count: ${controller.activeFaults.value.size}
                Subsystem Integrity: ${if (controller.activeFaults.value.isEmpty()) "100% HEALTHY" else "DEGRADED"}
                ==========================================================
                """.trimIndent()
            }

            else -> "Unknown command 'fibredash $sub1'. Type 'fibredash help' for command catalog."
        }
    }

    private fun getHelpText(): String {
        return """
        ====================================================
        FIBREDASH AUTOMOTIVE CLI - AUREOM VEHICLE SYSTEMS
        ====================================================
        Available Commands:
        • fibredash init
          Initialize vehicle gateway and connection status.

        • fibredash vehicles list
          List all registered vehicles in the synthetic fleet.

        • fibredash vehicles inspect <vehicle_id>
          Inspect digital twin state for a vehicle.

        • fibredash simulate start --scenario <urban|motorway|mountain|track>
          Execute a deterministic driving scenario simulation.

        • fibredash simulate pause / resume / reset
          Control physics engine simulation tick execution.

        • fibredash telemetry stream
          Stream latest 10Hz vehicle telemetry channel sample.

        • fibredash diagnostics list
          List active Diagnostic Trouble Codes (DTCs).

        • fibredash faults inject <FAULT_NAME>
          Inject hardware/sensor faults (e.g. BATTERY_OVERHEAT, TIRE_PRESSURE_LOSS).

        • fibredash faults reset
          Clear all active simulated faults & DTCs.

        • fibredash report vehicle
          Generate comprehensive vehicle digital twin summary report.
        ====================================================
        """.trimIndent()
    }
}
