package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CockpitBackground = Color(0xFF0B111A)
val CockpitSurface = Color(0xFF131C2E)
val CockpitSurfaceVariant = Color(0xFF1A263D)
val CockpitBorder = Color(0xFF263752)

val ElectricCyan = Color(0xFF00E5FF)
val PhosphorBlue = Color(0xFF38BDF8)
val AccentBlue = Color(0xFF1D4ED8)

val AmberWarning = Color(0xFFF59E0B)
val CriticalRed = Color(0xFFEF4444)
val EcoGreen = Color(0xFF10B981)

val BrushedChrome = Color(0xFF94A3B8)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

