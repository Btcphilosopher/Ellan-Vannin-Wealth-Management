package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.api.AureomApiGateway
import com.example.api.FibredashCliEngine
import com.example.domain.model.TelemetrySample
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ApiConsoleScreen(
    apiGateway: AureomApiGateway,
    cliEngine: FibredashCliEngine,
    telemetry: TelemetrySample,
    modifier: Modifier = Modifier
) {
    var commandInput by remember { mutableStateOf("") }
    val consoleLogs = remember { mutableStateListOf(
        "Aureom Vehicle Systems Fibredash Terminal [v1.4.2]",
        "Type 'fibredash help' or 'fibredash init' to inspect commands.",
        "----------------------------------------------------------"
    ) }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CockpitBackground)
            .padding(12.dp)
    ) {
        // Terminal Window Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                .background(CockpitSurfaceVariant)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Terminal, contentDescription = "CLI", tint = ElectricCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "FIBREDASH CLI CONSOLE & OPENAPI GATEWAY", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }

            Text(text = "REST / WebSocket 10Hz", style = MaterialTheme.typography.labelSmall, color = EcoGreen, fontSize = 9.sp)
        }

        // Terminal Output Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF070B10))
                .border(1.dp, CockpitBorder)
                .padding(12.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(consoleLogs.size) { index ->
                    Text(
                        text = consoleLogs[index],
                        style = MaterialTheme.typography.bodySmall,
                        color = if (consoleLogs[index].startsWith(">")) ElectricCyan else TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Terminal Input Line
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(CockpitSurface)
                .border(1.dp, CockpitBorder, RoundedCornerShape(bottomStart = 10.dp, bottomEnd = 10.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "$ ", style = MaterialTheme.typography.bodyMedium, color = ElectricCyan, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(text = "e.g. fibredash simulate start --scenario track", style = MaterialTheme.typography.bodySmall, color = TextMuted) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (commandInput.isNotBlank()) {
                        val cmd = commandInput
                        consoleLogs.add("> $cmd")
                        val result = cliEngine.executeCommand(cmd)
                        consoleLogs.addAll(result.split("\n"))
                        commandInput = ""
                        coroutineScope.launch {
                            listState.animateScrollToItem(consoleLogs.size - 1)
                        }
                    }
                })
            )

            IconButton(onClick = {
                if (commandInput.isNotBlank()) {
                    val cmd = commandInput
                    consoleLogs.add("> $cmd")
                    val result = cliEngine.executeCommand(cmd)
                    consoleLogs.addAll(result.split("\n"))
                    commandInput = ""
                    coroutineScope.launch {
                        listState.animateScrollToItem(consoleLogs.size - 1)
                    }
                }
            }) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Execute", tint = ElectricCyan)
            }
        }
    }
}
