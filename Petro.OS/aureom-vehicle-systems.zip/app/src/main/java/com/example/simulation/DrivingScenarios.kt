package com.example.simulation

import com.example.domain.model.DriveMode

enum class ScenarioType {
    URBAN_COMMUTE,
    MOTORWAY_CRUISE,
    MOUNTAIN_PASS,
    COLD_ALPINE_WINTER,
    HOT_SUMMER_HIGHWAY,
    TRACK_SPRINT,
    CHARGING_STATION
}

data class DrivingStep(
    val targetSpeedKmh: Double,
    val roadGradientPct: Double,
    val throttleDemandPct: Double,
    val brakeDemandBar: Double,
    val durationSec: Double
)

data class DrivingScenario(
    val type: ScenarioType,
    val name: String,
    val description: String,
    val ambientTempC: Double,
    val recommendedDriveMode: DriveMode,
    val steps: List<DrivingStep>
)

object DrivingScenarios {
    val URBAN_COMMUTE = DrivingScenario(
        type = ScenarioType.URBAN_COMMUTE,
        name = "Urban Traffic Commute",
        description = "Stop-and-go city transit with frequent regenerative braking and idle periods.",
        ambientTempC = 18.0,
        recommendedDriveMode = DriveMode.ECO,
        steps = listOf(
            DrivingStep(0.0, 0.0, 0.0, 0.0, 5.0),
            DrivingStep(35.0, 0.0, 0.25, 0.0, 10.0),
            DrivingStep(50.0, 0.5, 0.35, 0.0, 15.0),
            DrivingStep(0.0, 0.0, 0.0, 1.2, 8.0),
            DrivingStep(0.0, 0.0, 0.0, 0.0, 6.0),
            DrivingStep(45.0, -0.5, 0.30, 0.0, 12.0),
            DrivingStep(20.0, 0.0, 0.10, 0.8, 6.0),
            DrivingStep(60.0, 0.0, 0.45, 0.0, 18.0),
            DrivingStep(0.0, 0.0, 0.0, 1.5, 10.0)
        )
    )

    val MOTORWAY_CRUISE = DrivingScenario(
        type = ScenarioType.MOTORWAY_CRUISE,
        name = "Motorway High-Speed Cruise",
        description = "Sustained high-speed aerodynamic load testing on European highways.",
        ambientTempC = 20.0,
        recommendedDriveMode = DriveMode.COMFORT,
        steps = listOf(
            DrivingStep(0.0, 0.0, 0.0, 0.0, 3.0),
            DrivingStep(70.0, 0.0, 0.50, 0.0, 10.0),
            DrivingStep(110.0, 0.2, 0.65, 0.0, 15.0),
            DrivingStep(130.0, 0.0, 0.75, 0.0, 40.0),
            DrivingStep(120.0, -0.8, 0.40, 0.0, 20.0),
            DrivingStep(135.0, 0.5, 0.80, 0.0, 30.0)
        )
    )

    val MOUNTAIN_PASS = DrivingScenario(
        type = ScenarioType.MOUNTAIN_PASS,
        name = "Alpine Mountain Pass",
        description = "Steep incline uphill torque demand followed by downhill heavy regen energy recovery.",
        ambientTempC = 12.0,
        recommendedDriveMode = DriveMode.SPORT,
        steps = listOf(
            DrivingStep(30.0, 3.5, 0.60, 0.0, 10.0),
            DrivingStep(55.0, 6.0, 0.85, 0.0, 25.0),
            DrivingStep(40.0, 7.5, 0.70, 0.0, 20.0),
            DrivingStep(25.0, 2.0, 0.20, 1.0, 5.0),
            DrivingStep(50.0, -5.0, 0.0, 0.5, 20.0),
            DrivingStep(65.0, -7.0, 0.0, 0.8, 25.0)
        )
    )

    val COLD_ALPINE_WINTER = DrivingScenario(
        type = ScenarioType.COLD_ALPINE_WINTER,
        name = "Cold Winter (-10°C) Precondition",
        description = "Sub-zero conditions testing battery internal resistance and cabin PTC heating load.",
        ambientTempC = -10.0,
        recommendedDriveMode = DriveMode.ECO,
        steps = listOf(
            DrivingStep(0.0, 0.0, 0.0, 0.0, 10.0),
            DrivingStep(40.0, 0.0, 0.30, 0.0, 15.0),
            DrivingStep(70.0, 1.0, 0.50, 0.0, 25.0),
            DrivingStep(50.0, 0.0, 0.25, 0.0, 20.0)
        )
    )

    val HOT_SUMMER_HIGHWAY = DrivingScenario(
        type = ScenarioType.HOT_SUMMER_HIGHWAY,
        name = "Hot Summer Highway (40°C)",
        description = "Extreme ambient heat scenario stress-testing battery pack thermal cooling circuit.",
        ambientTempC = 40.0,
        recommendedDriveMode = DriveMode.COMFORT,
        steps = listOf(
            DrivingStep(0.0, 0.0, 0.0, 0.0, 5.0),
            DrivingStep(90.0, 0.0, 0.65, 0.0, 20.0),
            DrivingStep(125.0, 1.2, 0.85, 0.0, 35.0),
            DrivingStep(110.0, 0.0, 0.60, 0.0, 20.0)
        )
    )

    val TRACK_SPRINT = DrivingScenario(
        type = ScenarioType.TRACK_SPRINT,
        name = "Dynamic Track Sprint",
        description = "Max-torque acceleration, lateral G-force cornering and heavy carbon-friction braking.",
        ambientTempC = 22.0,
        recommendedDriveMode = DriveMode.TRACK,
        steps = listOf(
            DrivingStep(0.0, 0.0, 0.0, 0.0, 3.0),
            DrivingStep(100.0, 0.0, 1.00, 0.0, 6.0),
            DrivingStep(160.0, 0.0, 0.95, 0.0, 10.0),
            DrivingStep(60.0, 0.0, 0.0, 2.8, 4.0),
            DrivingStep(120.0, 0.0, 0.90, 0.0, 8.0),
            DrivingStep(0.0, 0.0, 0.0, 3.2, 5.0)
        )
    )

    val CHARGING_STATION = DrivingScenario(
        type = ScenarioType.CHARGING_STATION,
        name = "HPC Fast Charging Session",
        description = "High-power 800V DC fast charging curve with thermal battery preconditioning.",
        ambientTempC = 22.0,
        recommendedDriveMode = DriveMode.ECO,
        steps = listOf(
            DrivingStep(0.0, 0.0, 0.0, 0.0, 60.0)
        )
    )

    val ALL = listOf(
        URBAN_COMMUTE,
        MOTORWAY_CRUISE,
        MOUNTAIN_PASS,
        COLD_ALPINE_WINTER,
        HOT_SUMMER_HIGHWAY,
        TRACK_SPRINT,
        CHARGING_STATION
    )
}
