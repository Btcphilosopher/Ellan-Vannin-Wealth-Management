package com.example.domain.model

enum class PowertrainArchitecture {
    BEV,
    PHEV,
    ICE,
    HEV,
    DUAL_MOTOR_BEV,
    HYDROGEN_FCV
}

enum class DriveMode {
    ECO,
    COMFORT,
    SPORT,
    INDIVIDUAL,
    TRACK
}

enum class DiagnosticSeverity {
    INFO,
    ADVISORY,
    WARNING,
    CRITICAL,
    SIMULATION_FAULT
}

enum class DataSyncState {
    SYNCHRONISED,
    DELAYED,
    STALE,
    DEGRADED,
    SIMULATION_ONLY
}

data class VehicleConfig(
    val massKg: Double = 1950.0,
    val wheelRadiusM: Double = 0.35,
    val dragCoeffCd: Double = 0.24,
    val frontalAreaM2: Double = 2.35,
    val rollingCoeff: Double = 0.012,
    val batteryCapacityKwh: Double = 82.0,
    val usableBatteryKwh: Double = 77.0,
    val maxMotorPowerKw: Double = 210.0,
    val maxEnginePowerKw: Double = 132.0,
    val maxEngineTorqueNm: Double = 300.0,
    val fuelTankLiters: Double = 52.0,
    val maxSpeedKmh: Double = 210.0,
    val gearRatios: List<Double> = listOf(3.50, 2.15, 1.48, 1.12, 0.89, 0.72),
    val chargingMaxKw: Double = 170.0,
    val regenMaxKw: Double = 90.0,
    val thermalCoolingCapacityKw: Double = 12.0
)

data class Vehicle(
    val id: String,
    val vin: String,
    val name: String,
    val variant: String,
    val architecture: PowertrainArchitecture,
    val config: VehicleConfig = VehicleConfig()
)

data class TelemetrySample(
    val vehicleId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val speedKmh: Double = 0.0,
    val longitudinalAccelG: Double = 0.0,
    val lateralAccelG: Double = 0.0,
    val yawRateDegS: Double = 0.0,
    val steeringAngleDeg: Double = 0.0,
    val wheelSpeedsKmh: List<Double> = listOf(0.0, 0.0, 0.0, 0.0),
    val odometerKm: Double = 14250.0,
    val tripDistanceKm: Double = 0.0,
    val powerKw: Double = 0.0,
    val torqueNm: Double = 0.0,
    val engineRpm: Double = 0.0,
    val gear: String = "P",
    val throttlePct: Double = 0.0,
    val brakeBar: Double = 0.0,
    val driveMode: DriveMode = DriveMode.COMFORT,
    val socPct: Double = 82.0,
    val batteryVoltageV: Double = 398.0,
    val batteryCurrentA: Double = 0.0,
    val batteryTempC: Double = 26.5,
    val cellTempSpreadC: Double = 1.2,
    val sohPct: Double = 98.4,
    val chargingPowerKw: Double = 0.0,
    val fuelLevelPct: Double = 100.0,
    val fuelFlowLPerH: Double = 0.0,
    val coolantTempC: Double = 22.0,
    val oilTempC: Double = 22.0,
    val tirePressuresBar: List<Double> = listOf(2.4, 2.4, 2.4, 2.4),
    val tireTempsC: List<Double> = listOf(22.0, 22.0, 22.0, 22.0),
    val cabinTempC: Double = 21.5,
    val ambientTempC: Double = 19.0,
    val hvacLoadKw: Double = 0.8,
    val warnings: List<String> = emptyList(),
    val qualityFlags: String = "VALID",
    val provenance: String = "AUREOM_PHYSICS_SIMULATION"
)

data class DiagnosticTroubleCode(
    val code: String,
    val description: String,
    val severity: DiagnosticSeverity,
    val subsystem: String,
    val inspectionRecommendation: String,
    val active: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

enum class FaultType {
    BATTERY_OVERHEAT,
    SPEED_SENSOR_DROPOUT,
    WHEEL_SPEED_DISAGREEMENT,
    BRAKE_OVERHEAT,
    TIRE_PRESSURE_LOSS,
    ECU_COMM_TIMEOUT,
    DOOR_AJAR,
    SUDDEN_POWER_DERATING,
    CHARGING_INTERRUPTION
}

data class TripRecord(
    val id: String,
    val vehicleId: String,
    val title: String,
    val startTime: Long,
    val endTime: Long,
    val distanceKm: Double,
    val durationSec: Long,
    val avgSpeedKmh: Double,
    val maxSpeedKmh: Double,
    val energyConsumedKwh: Double,
    val avgConsumptionWhKm: Double,
    val fuelConsumedL: Double,
    val avgFuelLPer100Km: Double,
    val regenRecoveredKwh: Double,
    val costEur: Double,
    val co2Kg: Double
)

data class DigitalTwinNode(
    val id: String,
    val name: String,
    val category: String,
    val healthPct: Double,
    val status: String,
    val temperatureC: Double,
    val metrics: Map<String, String>,
    val syncState: DataSyncState = DataSyncState.SYNCHRONISED
)

data class FleetVehicle(
    val vehicleId: String,
    val vin: String,
    val modelName: String,
    val architecture: PowertrainArchitecture,
    val socOrFuelPct: Double,
    val status: String,
    val lat: Double,
    val lng: Double,
    val speedKmh: Double,
    val activeFaultsCount: Int,
    val driverName: String,
    val odometerKm: Double
)
