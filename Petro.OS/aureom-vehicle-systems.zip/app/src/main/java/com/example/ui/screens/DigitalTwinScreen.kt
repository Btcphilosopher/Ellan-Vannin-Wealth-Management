package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.api.AureomApiGateway
import com.example.domain.model.DigitalTwinNode
import com.example.domain.model.TelemetrySample
import com.example.ui.theme.*

@Composable
fun DigitalTwinScreen(
    apiGateway: AureomApiGateway,
    telemetry: TelemetrySample,
    modifier: Modifier = Modifier
) {
    val twinNodes = remember(telemetry) {
        apiGateway.getDigitalTwin(telemetry.vehicleId).data
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CockpitBackground)
            .padding(12.dp)
    ) {
        // Digital Twin Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = CockpitSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccountTree,
                        contentDescription = "Digital Twin",
                        tint = ElectricCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "VEHICLE DIGITAL TWIN MODEL",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Real-time edge state representation & telemetry provenance tracking.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }

                BadgeChip(
                    text = "SYNCED @ 10Hz",
                    color = EcoGreen
                )
            }
        }

        // Subsystems Node Tree
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(twinNodes) { node ->
                DigitalTwinNodeCard(node = node)
            }
        }
    }
}

@Composable
fun DigitalTwinNodeCard(node: DigitalTwinNode) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CockpitSurface),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (node.healthPct < 90) CriticalRed else CockpitBorder
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = node.name,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Category: ${node.category} | Node ID: ${node.id}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }

                BadgeChip(
                    text = node.status,
                    color = if (node.healthPct < 90) CriticalRed else PhosphorBlue
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Metrics Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CockpitSurfaceVariant)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "HEALTH", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(
                        text = "${node.healthPct}%",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (node.healthPct < 90) CriticalRed else EcoGreen,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Column {
                    Text(text = "TEMPERATURE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(
                        text = "${String.format("%.1f", node.temperatureC)} °C",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                node.metrics.forEach { (k, v) ->
                    Column {
                        Text(text = k.uppercase(), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text(
                            text = v,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
