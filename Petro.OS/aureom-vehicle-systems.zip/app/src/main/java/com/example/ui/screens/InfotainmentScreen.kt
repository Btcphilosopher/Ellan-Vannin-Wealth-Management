package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.TelemetrySample
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun InfotainmentScreen(
    telemetry: TelemetrySample,
    modifier: Modifier = Modifier
) {
    var activeModule by remember { mutableStateOf("ENERGY") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CockpitBackground)
            .padding(12.dp)
    ) {
        // Module Navigation Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(CockpitSurface)
                .border(1.dp, CockpitBorder, RoundedCornerShape(10.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            val modules = listOf("ENERGY", "BATTERY MATRIX", "CHARGING", "CLIMATE", "VEHICLE STATUS")
            modules.forEach { mod ->
                val isSelected = activeModule == mod
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) ElectricCyan else Color.Transparent)
                        .clickable { activeModule = mod }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = mod,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) Color.Black else TextSecondary,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Active Content Box
        when (activeModule) {
            "ENERGY" -> EnergyCenterModule(telemetry)
            "BATTERY MATRIX" -> BatteryMatrixModule(telemetry)
            "CHARGING" -> ChargingSimulatorModule(telemetry)
            "CLIMATE" -> ClimateControlModule(telemetry)
            "VEHICLE STATUS" -> VehicleStatusModule(telemetry)
        }
    }
}

@Composable
fun EnergyCenterModule(telemetry: TelemetrySample) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CockpitSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "POWERTRAIN ENERGY FLOW",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        BadgeChip(
                            text = if (telemetry.powerKw < 0) "REGENERATIVE RECOVERY" else "DISCHARGING",
                            color = if (telemetry.powerKw < 0) EcoGreen else ElectricCyan
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Animated Energy Flow Diagram Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(CockpitSurfaceVariant)
                            .border(1.dp, CockpitBorder, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw Connecting Bus Lines
                            drawLine(
                                color = ElectricCyan,
                                start = Offset(w * 0.25f, h * 0.5f),
                                end = Offset(w * 0.75f, h * 0.5f),
                                strokeWidth = 4.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 15f), (System.currentTimeMillis() % 1000) / 10f)
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Battery Node
                            EnergyNodeCard(
                                title = "82 kWh BATTERY",
                                subtitle = "${telemetry.socPct.toInt()}% SOC",
                                icon = Icons.Default.BatteryChargingFull,
                                color = PhosphorBlue
                            )

                            // Inverter Node
                            EnergyNodeCard(
                                title = "DUAL INVERTER",
                                subtitle = "${String.format("%.1f", telemetry.powerKw)} kW",
                                icon = Icons.Default.ElectricBolt,
                                color = ElectricCyan
                            )

                            // Motor / Wheels Node
                            EnergyNodeCard(
                                title = "TRACTION MOTORS",
                                subtitle = "${telemetry.speedKmh.toInt()} KM/H",
                                icon = Icons.Default.DirectionsCar,
                                color = EcoGreen
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = CockpitSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "CONSUMPTION RATE", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (telemetry.speedKmh > 5) "${(telemetry.powerKw * 1000 / telemetry.speedKmh).toInt()} Wh/km" else "-- Wh/km",
                            style = MaterialTheme.typography.headlineSmall,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = CockpitSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "REGEN EFFICIENCY", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "88.4%",
                            style = MaterialTheme.typography.headlineSmall,
                            color = EcoGreen,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EnergyNodeCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CockpitSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text(text = subtitle, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun BatteryMatrixModule(telemetry: TelemetrySample) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = CockpitSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "BATTERY CELL TEMPERATURE MATRIX", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
            Text(text = "Real-time thermal cell distribution across 96 battery module blocks.", style = MaterialTheme.typography.bodySmall, color = TextMuted)

            Spacer(modifier = Modifier.height(16.dp))

            // 8x4 Grid of Battery Modules
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(4) { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        repeat(6) { col ->
                            val cellId = row * 6 + col + 1
                            val tempOffset: Double = sin(cellId * 0.7) * telemetry.cellTempSpreadC
                            val baseTemp: Double = telemetry.batteryTempC + tempOffset
                            val isHot: Boolean = baseTemp > 45.0

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(55.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isHot) CriticalRed.copy(alpha = 0.25f) else CockpitSurfaceVariant)
                                    .border(1.dp, if (isHot) CriticalRed else CockpitBorder, RoundedCornerShape(6.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "M#$cellId", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
                                    Text(
                                        text = "${String.format("%.1f", baseTemp)}°C",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isHot) CriticalRed else TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricCard("PACK VOLTAGE", "${String.format("%.1f", telemetry.batteryVoltageV)} V", PhosphorBlue)
                MetricCard("PACK CURRENT", "${String.format("%.1f", telemetry.batteryCurrentA)} A", ElectricCyan)
                MetricCard("CELL SPREAD", "${String.format("%.1f", telemetry.cellTempSpreadC)} °C", if (telemetry.cellTempSpreadC > 3.0) CriticalRed else EcoGreen)
                MetricCard("STATE OF HEALTH", "${telemetry.sohPct}%", EcoGreen)
            }
        }
    }
}

@Composable
fun ChargingSimulatorModule(telemetry: TelemetrySample) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = CockpitSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "HIGH POWER DC CHARGING GATEWAY", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text(text = "800V Architecture Ultra-Fast Charging Session Controls.", style = MaterialTheme.typography.bodySmall, color = TextMuted)

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.EvStation,
                        contentDescription = "Station",
                        tint = ElectricCyan,
                        modifier = Modifier.size(64.dp)
                    )

                    Column {
                        Text(text = "CHARGING RATE", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                        Text(
                            text = "${telemetry.chargingPowerKw.toInt()} kW",
                            style = MaterialTheme.typography.displaySmall,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(text = "MAX PEAK: 170 kW DC", style = MaterialTheme.typography.labelSmall, color = EcoGreen)
                    }

                    Column {
                        Text(text = "TIME TO 80%", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                        Text(
                            text = if (telemetry.socPct < 80) "${((80 - telemetry.socPct) * 0.45).toInt()} MIN" else "COMPLETED",
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Charging Progress Bar
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "BATTERY CHARGE LEVEL", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(text = "${telemetry.socPct.toInt()}%", style = MaterialTheme.typography.labelSmall, color = ElectricCyan, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { (telemetry.socPct / 100f).toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp)),
                    color = ElectricCyan,
                    trackColor = CockpitSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun ClimateControlModule(telemetry: TelemetrySample) {
    var setTemp by remember { mutableStateOf(21.5f) }

    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = CockpitSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceAround
        ) {
            Text(text = "HVAC CABIN THERMAL SYSTEM", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)

            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { setTemp = (setTemp - 0.5f).coerceAtLeast(16f) },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(CockpitSurfaceVariant)
                ) {
                    Icon(imageVector = Icons.Default.Remove, contentDescription = "Cooler", tint = PhosphorBlue)
                }

                Spacer(modifier = Modifier.width(24.dp))

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${String.format("%.1f", setTemp)}°C",
                        style = MaterialTheme.typography.displayMedium,
                        color = ElectricCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = "CABIN SETPOINT", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }

                Spacer(modifier = Modifier.width(24.dp))

                IconButton(
                    onClick = { setTemp = (setTemp + 0.5f).coerceAtMost(28f) },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(CockpitSurfaceVariant)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Warmer", tint = CriticalRed)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                MetricCard("AMBIENT TEMP", "${telemetry.ambientTempC.toInt()} °C", TextSecondary)
                MetricCard("CABIN ACTUAL", "${String.format("%.1f", telemetry.cabinTempC)} °C", TextPrimary)
                MetricCard("COMPRESSOR LOAD", "${String.format("%.1f", telemetry.hvacLoadKw)} kW", AmberWarning)
            }
        }
    }
}

@Composable
fun VehicleStatusModule(telemetry: TelemetrySample) {
    Card(
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = CockpitSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "SUB-SYSTEM INTEGRITY STATUS", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(14.dp))

            StatusRow("PROPULSION E-MOTORS", "NOMINAL", EcoGreen)
            StatusRow("HIGH VOLTAGE BATTERY", if (telemetry.batteryTempC > 50) "WARNING" else "NOMINAL", if (telemetry.batteryTempC > 50) CriticalRed else EcoGreen)
            StatusRow("ELECTRONIC BRAKE SYSTEM", "NOMINAL", EcoGreen)
            StatusRow("TIRE PRESSURE SYSTEM", if (telemetry.tirePressuresBar.any { it < 1.8 }) "LOW PRESSURE" else "NOMINAL", if (telemetry.tirePressuresBar.any { it < 1.8 }) CriticalRed else EcoGreen)
            StatusRow("5G EDGE TELEMATICS", telemetry.qualityFlags, if (telemetry.qualityFlags == "VALID") EcoGreen else AmberWarning)
        }
    }
}

@Composable
fun StatusRow(title: String, status: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(CockpitSurfaceVariant)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
        BadgeChip(text = status, color = color)
    }
}
