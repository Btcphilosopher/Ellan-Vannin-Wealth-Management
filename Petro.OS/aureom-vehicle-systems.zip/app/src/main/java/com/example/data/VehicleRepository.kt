package com.example.data

import com.example.domain.model.TripRecord
import com.example.domain.model.Vehicle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class VehicleRepository(
    private val database: AureomDatabase
) {
    val allTrips: Flow<List<TripRecord>> = database.tripDao().getAllTrips().map { entities ->
        entities.map { it.toDomainModel() }
    }

    suspend fun saveTrip(trip: TripRecord) {
        database.tripDao().insertTrip(trip.toEntity())
    }

    suspend fun deleteTrip(id: String) {
        database.tripDao().deleteTrip(id)
    }

    private fun TripEntity.toDomainModel() = TripRecord(
        id = id,
        vehicleId = vehicleId,
        title = title,
        startTime = startTime,
        endTime = endTime,
        distanceKm = distanceKm,
        durationSec = durationSec,
        avgSpeedKmh = avgSpeedKmh,
        maxSpeedKmh = maxSpeedKmh,
        energyConsumedKwh = energyConsumedKwh,
        avgConsumptionWhKm = avgConsumptionWhKm,
        fuelConsumedL = fuelConsumedL,
        avgFuelLPer100Km = if (distanceKm > 0) (fuelConsumedL / distanceKm) * 100.0 else 0.0,
        regenRecoveredKwh = regenRecoveredKwh,
        costEur = costEur,
        co2Kg = co2Kg
    )

    private fun TripRecord.toEntity() = TripEntity(
        id = id,
        vehicleId = vehicleId,
        title = title,
        startTime = startTime,
        endTime = endTime,
        distanceKm = distanceKm,
        durationSec = durationSec,
        avgSpeedKmh = avgSpeedKmh,
        maxSpeedKmh = maxSpeedKmh,
        energyConsumedKwh = energyConsumedKwh,
        avgConsumptionWhKm = avgConsumptionWhKm,
        fuelConsumedL = fuelConsumedL,
        regenRecoveredKwh = regenRecoveredKwh,
        costEur = costEur,
        co2Kg = co2Kg
    )
}
