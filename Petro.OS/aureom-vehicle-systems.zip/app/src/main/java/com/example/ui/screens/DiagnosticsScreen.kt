package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.DiagnosticTroubleCode
import com.example.domain.model.FaultType
import com.example.simulation.SimulationController
import com.example.ui.theme.*

@Composable
fun DiagnosticsScreen(
    controller: SimulationController,
    modifier: Modifier = Modifier
) {
    val dtcs by controller.dtcList.collectAsState()
    val activeFaults by controller.activeFaults.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CockpitBackground)
            .padding(12.dp)
    ) {
        // Fault Injection Test Bench Toolbar
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = CockpitSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.BugReport, contentDescription = "Fault Bench", tint = AmberWarning, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "FAULT INJECTION WORKBENCH",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { controller.resetFaults() },
                        colors = ButtonDefaults.buttonColors(containerColor = CockpitSurfaceVariant),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(text = "CLEAR ALL FAULTS", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Fault Buttons Flow Row
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val faultOptions = FaultType.values()
                    val chunkSize = 3
                    faultOptions.toList().chunked(chunkSize).forEach { rowFaults ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowFaults.forEach { fault ->
                                val isActive = activeFaults.contains(fault)
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isActive) CriticalRed else CockpitSurfaceVariant)
                                        .border(1.dp, if (isActive) CriticalRed else CockpitBorder, RoundedCornerShape(8.dp))
                                        .clickable {
                                            if (isActive) controller.resolveFault(fault) else controller.injectFault(fault)
                                        }
                                        .padding(vertical = 8.dp, horizontal = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = fault.name.replace("_", " "),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isActive) Color.White else TextSecondary,
                                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Diagnostic Trouble Codes Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ISO/SAE DIAGNOSTIC TROUBLE CODES (${dtcs.size} ACTIVE)",
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        }

        if (dtcs.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CockpitSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "OK", tint = EcoGreen, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "ALL SUBSYSTEMS NOMINAL", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                        Text(text = "No active Diagnostic Trouble Codes detected on vehicle CAN/FD bus.", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(dtcs) { dtc ->
                    DtcCard(dtc = dtc)
                }
            }
        }
    }
}

@Composable
fun DtcCard(dtc: DiagnosticTroubleCode) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CockpitSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CriticalRed)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(CriticalRed.copy(alpha = 0.2f))
                            .border(1.dp, CriticalRed, RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = dtc.code,
                            style = MaterialTheme.typography.titleSmall,
                            color = CriticalRed,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = dtc.subsystem, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }

                BadgeChip(text = dtc.severity.name, color = CriticalRed)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(text = dtc.description, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(CockpitSurfaceVariant)
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.Build, contentDescription = "Inspection", tint = PhosphorBlue, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = dtc.inspectionRecommendation, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
        }
    }
}
