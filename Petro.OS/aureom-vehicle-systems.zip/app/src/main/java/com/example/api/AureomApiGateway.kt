package com.example.api

import com.example.domain.model.*
import com.example.simulation.DrivingScenarios
import com.example.simulation.SimulationController

data class ApiResponse<T>(
    val status: String = "success",
    val apiVersion: String = "v1.4.2",
    val timestamp: Long = System.currentTimeMillis(),
    val data: T
)

class AureomApiGateway(
    private val controller: SimulationController
) {
    fun getVehicles(): ApiResponse<List<Map<String, Any>>> {
        val v = controller.selectedVehicle.value
        return ApiResponse(
            data = listOf(
                mapOf(
                    "vehicle_id" to v.id,
                    "vin" to v.vin,
                    "name" to v.name,
                    "variant" to v.variant,
                    "architecture" to v.architecture.name,
                    "battery_capacity_kwh" to v.config.batteryCapacityKwh,
                    "usable_battery_kwh" to v.config.usableBatteryKwh,
                    "max_motor_power_kw" to v.config.maxMotorPowerKw
                ),
                mapOf(
                    "vehicle_id" to "stellantis-phev-02",
                    "vin" to "VR7AUR2026P801456",
                    "name" to "Aureom Hybrid Executive",
                    "variant" to "1.6T Plug-in Hybrid AWD",
                    "architecture" to "PHEV",
                    "battery_capacity_kwh" to 17.8,
                    "usable_battery_kwh" to 15.2,
                    "max_motor_power_kw" to 165.0
                ),
                mapOf(
                    "vehicle_id" to "stellantis-ice-03",
                    "vin" to "ZFAAUR2026I700982",
                    "name" to "Aureom V6 Sport Concept",
                    "variant" to "3.0 Twin-Turbo V6 Euro7",
                    "architecture" to "ICE",
                    "battery_capacity_kwh" to 0.0,
                    "usable_battery_kwh" to 0.0,
                    "max_motor_power_kw" to 380.0
                )
            )
        )
    }

    fun getTelemetryLatest(vehicleId: String): ApiResponse<TelemetrySample> {
        return ApiResponse(data = controller.currentTelemetry.value)
    }

    fun getPowertrainState(vehicleId: String): ApiResponse<Map<String, Any>> {
        val t = controller.currentTelemetry.value
        val v = controller.selectedVehicle.value
        return ApiResponse(
            data = mapOf(
                "architecture" to v.architecture.name,
                "power_kw" to t.powerKw,
                "torque_nm" to t.torqueNm,
                "engine_rpm" to t.engineRpm,
                "gear" to t.gear,
                "throttle_pct" to t.throttlePct,
                "brake_bar" to t.brakeBar,
                "drive_mode" to t.driveMode.name,
                "coolant_temp_c" to t.coolantTempC
            )
        )
    }

    fun getBatteryEnergyState(vehicleId: String): ApiResponse<Map<String, Any>> {
        val t = controller.currentTelemetry.value
        return ApiResponse(
            data = mapOf(
                "soc_pct" to t.socPct,
                "battery_voltage_v" to t.batteryVoltageV,
                "battery_current_a" to t.batteryCurrentA,
                "battery_temp_c" to t.batteryTempC,
                "cell_temp_spread_c" to t.cellTempSpreadC,
                "soh_pct" to t.sohPct,
                "charging_power_kw" to t.chargingPowerKw,
                "estimated_range_km" to (t.socPct * 5.2)
            )
        )
    }

    fun getDiagnostics(vehicleId: String): ApiResponse<List<DiagnosticTroubleCode>> {
        return ApiResponse(data = controller.dtcList.value)
    }

    fun injectFault(vehicleId: String, faultName: String): ApiResponse<Map<String, String>> {
        val fault = try {
            FaultType.valueOf(faultName.uppercase())
        } catch (e: Exception) {
            FaultType.BATTERY_OVERHEAT
        }
        controller.injectFault(fault)
        return ApiResponse(
            data = mapOf(
                "action" to "FAULT_INJECTED",
                "fault" to fault.name,
                "vehicle_id" to vehicleId,
                "status" to "ACTIVE"
            )
        )
    }

    fun getDigitalTwin(vehicleId: String): ApiResponse<List<DigitalTwinNode>> {
        val t = controller.currentTelemetry.value
        val isFaulted = controller.activeFaults.value.isNotEmpty()

        return ApiResponse(
            data = listOf(
                DigitalTwinNode(
                    id = "node-battery-pack",
                    name = "800V High Voltage Battery Pack",
                    category = "ENERGY_STORAGE",
                    healthPct = if (t.batteryTempC > 55) 78.0 else 98.4,
                    status = if (t.batteryTempC > 55) "THERMAL_WARNING" else "NOMINAL",
                    temperatureC = t.batteryTempC,
                    metrics = mapOf(
                        "SOC" to "${String.format("%.1f", t.socPct)}%",
                        "Voltage" to "${String.format("%.1f", t.batteryVoltageV)} V",
                        "Cell Spread" to "${String.format("%.1f", t.cellTempSpreadC)} °C"
                    )
                ),
                DigitalTwinNode(
                    id = "node-inverter-front",
                    name = "SiC Dual Traction Inverter",
                    category = "POWER_ELECTRONICS",
                    healthPct = 99.1,
                    status = "NOMINAL",
                    temperatureC = t.batteryTempC - 4.0,
                    metrics = mapOf(
                        "Switching Freq" to "16 kHz",
                        "Efficiency" to "98.2%",
                        "Bus Voltage" to "${String.format("%.1f", t.batteryVoltageV)} V"
                    )
                ),
                DigitalTwinNode(
                    id = "node-traction-motors",
                    name = "Front & Rear Hairpin E-Motors",
                    category = "PROPULSION",
                    healthPct = 97.8,
                    status = if (t.powerKw > 150) "HIGH_LOAD" else "NOMINAL",
                    temperatureC = t.batteryTempC + 8.0,
                    metrics = mapOf(
                        "Power" to "${String.format("%.1f", t.powerKw)} kW",
                        "Torque" to "${String.format("%.1f", t.torqueNm)} Nm",
                        "Rpm" to "${t.engineRpm.toInt()} RPM"
                    )
                ),
                DigitalTwinNode(
                    id = "node-ebs-brakes",
                    name = "Electronic Brake System (EBS)",
                    category = "CHASSIS_SAFETY",
                    healthPct = if (t.tireTempsC[0] > 200) 82.0 else 99.5,
                    status = if (t.tireTempsC[0] > 200) "HIGH_TEMP" else "NOMINAL",
                    temperatureC = t.tireTempsC[0],
                    metrics = mapOf(
                        "Brake Pressure" to "${String.format("%.1f", t.brakeBar)} Bar",
                        "Regen Blend" to if (t.brakeBar > 0) "82%" else "0%"
                    )
                ),
                DigitalTwinNode(
                    id = "node-telematics-gateway",
                    name = "5G Telematics Gateway & Edge API",
                    category = "CONNECTIVITY",
                    healthPct = 100.0,
                    status = if (t.qualityFlags == "VALID") "SYNCHRONISED" else "DEGRADED",
                    temperatureC = 28.0,
                    metrics = mapOf(
                        "Latency" to "12 ms",
                        "Protocol" to "gRPC / WebSocket",
                        "Quality" to t.qualityFlags
                    ),
                    syncState = if (t.qualityFlags == "VALID") DataSyncState.SYNCHRONISED else DataSyncState.DEGRADED
                )
            )
        )
    }

    fun executeScenario(scenarioName: String): ApiResponse<Map<String, String>> {
        val scenario = DrivingScenarios.ALL.find { it.name.lowercase().contains(scenarioName.lowercase()) || it.type.name.lowercase() == scenarioName.lowercase() }
            ?: DrivingScenarios.URBAN_COMMUTE
        controller.setScenario(scenario)
        return ApiResponse(
            data = mapOf(
                "action" to "SCENARIO_STARTED",
                "scenario" to scenario.name,
                "status" to "RUNNING"
            )
        )
    }
}
