package com.example.simulation

import com.example.domain.model.*
import kotlin.math.*

class VehiclePhysicsEngine {

    private val AIR_DENSITY = 1.225 // kg/m^3
    private val GRAVITY = 9.81 // m/s^2

    fun step(
        currentTelemetry: TelemetrySample,
        config: VehicleConfig,
        architecture: PowertrainArchitecture,
        targetSpeedKmh: Double,
        gradientPct: Double,
        throttleInputPct: Double,
        brakeInputBar: Double,
        activeFaults: Set<FaultType>,
        deltaTimeSec: Double
    ): TelemetrySample {
        var speedMs = currentTelemetry.speedKmh / 3.6
        val targetSpeedMs = targetSpeedKmh / 3.6

        // Drive Mode multiplier
        val modeMultiplier = when (currentTelemetry.driveMode) {
            DriveMode.ECO -> 0.75
            DriveMode.COMFORT -> 1.0
            DriveMode.SPORT -> 1.25
            DriveMode.TRACK -> 1.5
            DriveMode.INDIVIDUAL -> 1.0
        }

        // Check fault power derating
        val powerDerated = activeFaults.contains(FaultType.BATTERY_OVERHEAT) ||
                activeFaults.contains(FaultType.SUDDEN_POWER_DERATING)
        val maxAvailablePowerKw = if (powerDerated) 35.0 else (config.maxMotorPowerKw * modeMultiplier)

        // Forces calculation (Longitudinal Dynamics Model)
        // F_drag = 0.5 * rho * Cd * FrontalArea * speed^2
        val fDrag = 0.5 * AIR_DENSITY * config.dragCoeffCd * config.frontalAreaM2 * (speedMs * speedMs)

        // F_roll = Crr * m * g
        val fRoll = config.rollingCoeff * config.massKg * GRAVITY

        // F_grade = m * g * sin(theta)
        val thetaRad = atan(gradientPct / 100.0)
        val fGrade = config.massKg * GRAVITY * sin(thetaRad)

        // Acceleration/Traction Force
        val rawThrottle = if (targetSpeedMs > speedMs + 0.1) max(throttleInputPct, 0.35) else throttleInputPct
        val effectiveThrottle = if (powerDerated) min(rawThrottle, 0.3) else rawThrottle
        val fTractionMax = (maxAvailablePowerKw * 1000.0) / max(speedMs, 3.0)
        val fTraction = fTractionMax * effectiveThrottle

        // Braking Force
        val rawBrake = if (speedMs > targetSpeedMs + 0.5 && throttleInputPct == 0.0) max(brakeInputBar, 0.6) else brakeInputBar
        val fBrakeMechanical = rawBrake * 3200.0

        // Regenerative Braking (for EV/PHEV/HEV)
        val isEvOrHybrid = architecture != PowertrainArchitecture.ICE
        val maxRegenForce = if (isEvOrHybrid && currentTelemetry.socPct < 98.0 && !powerDerated) {
            (config.regenMaxKw * 1000.0) / max(speedMs, 2.5)
        } else 0.0
        val fRegen = if (rawBrake > 0.0) min(maxRegenForce, rawBrake * 2100.0) else min(maxRegenForce, fDrag * 0.3)

        // F_net = F_traction - F_drag - F_roll - F_grade - F_brake
        val fNet = fTraction - fDrag - fRoll - fGrade - fBrakeMechanical - fRegen
        val accelMs2 = fNet / config.massKg

        // Update Speed
        var newSpeedMs = max(0.0, speedMs + accelMs2 * deltaTimeSec)
        if (targetSpeedKmh == 0.0 && newSpeedMs < 0.2) {
            newSpeedMs = 0.0
        }
        val newSpeedKmh = min(newSpeedMs * 3.6, config.maxSpeedKmh)

        // Power consumption (kW)
        val mechanicalPowerKw = (fTraction * newSpeedMs) / 1000.0
        val regenPowerKw = if (fRegen > 0.0) (fRegen * newSpeedMs * 0.88) / 1000.0 else 0.0
        val netPowerKw = mechanicalPowerKw - regenPowerKw + currentTelemetry.hvacLoadKw

        // Energy & Battery Model (SOC calculation)
        var newSocPct = currentTelemetry.socPct
        var newBatteryVoltageV = currentTelemetry.batteryVoltageV
        var newBatteryCurrentA = currentTelemetry.batteryCurrentA
        var newBatteryTempC = currentTelemetry.batteryTempC
        var newCellTempSpread = currentTelemetry.cellTempSpreadC
        var newChargingPowerKw = 0.0

        if (isEvOrHybrid) {
            val usableKwh = config.usableBatteryKwh
            // SOC delta
            val energyDeltaKwh = (netPowerKw * deltaTimeSec) / 3600.0
            newSocPct = max(0.0, min(100.0, currentTelemetry.socPct - (energyDeltaKwh / usableKwh) * 100.0))

            // Battery Electricals
            newBatteryVoltageV = 360.0 + (newSocPct / 100.0) * 45.0
            newBatteryCurrentA = if (newBatteryVoltageV > 0) (netPowerKw * 1000.0) / newBatteryVoltageV else 0.0

            // Battery Thermal Model
            val thermalDissipation = (abs(newBatteryCurrentA) * abs(newBatteryCurrentA) * 0.04) / 1000.0
            val coolingKw = if (newBatteryTempC > 30.0) config.thermalCoolingCapacityKw else 1.0
            val deltaTemp = (thermalDissipation - coolingKw) * (deltaTimeSec / 300.0)

            if (activeFaults.contains(FaultType.BATTERY_OVERHEAT)) {
                newBatteryTempC = min(68.0, currentTelemetry.batteryTempC + 0.45 * deltaTimeSec)
                newCellTempSpread = 4.8
            } else {
                newBatteryTempC = max(currentTelemetry.ambientTempC, min(50.0, currentTelemetry.batteryTempC + deltaTemp))
                newCellTempSpread = if (newBatteryTempC > 40) 2.4 else 1.1
            }

            if (targetSpeedKmh == 0.0 && effectiveThrottle == 0.0 && currentTelemetry.socPct < 90.0 && activeFaults.contains(FaultType.CHARGING_INTERRUPTION).not()) {
                // Charging mode when stationary
                newChargingPowerKw = min(config.chargingMaxKw, 120.0)
                val chargeDeltaKwh = (newChargingPowerKw * deltaTimeSec) / 3600.0
                newSocPct = min(100.0, newSocPct + (chargeDeltaKwh / usableKwh) * 100.0)
            }
        }

        // Engine & Transmission Model (ICE / Hybrid)
        var newEngineRpm = 0.0
        var newGear = "P"
        var newFuelLevelPct = currentTelemetry.fuelLevelPct
        var newFuelFlowLPerH = 0.0
        var newCoolantTempC = currentTelemetry.coolantTempC

        if (architecture == PowertrainArchitecture.ICE || architecture == PowertrainArchitecture.PHEV || architecture == PowertrainArchitecture.HEV) {
            if (newSpeedKmh == 0.0) {
                newGear = "P"
                newEngineRpm = 850.0 // Idle
            } else {
                // Gear selection logic
                val gearIdx = when {
                    newSpeedKmh < 20 -> 0
                    newSpeedKmh < 40 -> 1
                    newSpeedKmh < 65 -> 2
                    newSpeedKmh < 90 -> 3
                    newSpeedKmh < 120 -> 4
                    else -> 5
                }
                newGear = "D${gearIdx + 1}"
                val ratio = config.gearRatios.getOrElse(gearIdx) { 1.0 }
                val wheelRpm = (newSpeedMs / (2 * PI * config.wheelRadiusM)) * 60.0
                newEngineRpm = min(6800.0, max(1100.0, wheelRpm * ratio * 3.8))
            }

            // Engine fuel flow
            val enginePowerKw = (netPowerKw * 0.85).coerceAtLeast(0.0)
            newFuelFlowLPerH = if (newEngineRpm > 0) (enginePowerKw * 0.23) / 0.75 + 0.8 else 0.0
            val fuelUsedL = (newFuelFlowLPerH * deltaTimeSec) / 3600.0
            newFuelLevelPct = max(0.0, currentTelemetry.fuelLevelPct - (fuelUsedL / config.fuelTankLiters) * 100.0)

            // Coolant Warm-up
            val targetCoolant = if (newEngineRpm > 900) 90.0 else currentTelemetry.ambientTempC
            newCoolantTempC = currentTelemetry.coolantTempC + (targetCoolant - currentTelemetry.coolantTempC) * (deltaTimeSec / 200.0)
        } else {
            // EV Gear
            newGear = if (newSpeedKmh == 0.0) "P" else "D"
            newEngineRpm = (newSpeedMs / (2 * PI * config.wheelRadiusM)) * 60.0 * 9.52
        }

        // Tyre dynamics & Fault handling
        var newPressures = currentTelemetry.tirePressuresBar.toMutableList()
        var newTireTemps = currentTelemetry.tireTempsC.toMutableList()
        val wheelSpeeds = mutableListOf(newSpeedKmh, newSpeedKmh, newSpeedKmh, newSpeedKmh)

        if (activeFaults.contains(FaultType.TIRE_PRESSURE_LOSS)) {
            newPressures[2] = 1.1 // Rear left pressure drop
        }

        if (activeFaults.contains(FaultType.WHEEL_SPEED_DISAGREEMENT)) {
            wheelSpeeds[1] = 0.0 // Front right speed sensor failure
        }

        if (activeFaults.contains(FaultType.SPEED_SENSOR_DROPOUT)) {
            wheelSpeeds[0] = 0.0
            wheelSpeeds[1] = 0.0
        }

        // Brake Temperatures
        val brakeTempRise = if (rawBrake > 0) rawBrake * 12.0 * deltaTimeSec else -2.0 * deltaTimeSec
        val targetBrakeTemp = if (activeFaults.contains(FaultType.BRAKE_OVERHEAT)) 385.0 else 35.0
        val newBrakeTemp = max(currentTelemetry.ambientTempC, min(450.0, currentTelemetry.tireTempsC[0] + brakeTempRise + (targetBrakeTemp - currentTelemetry.tireTempsC[0]) * 0.05))
        newTireTemps = mutableListOf(newBrakeTemp, newBrakeTemp, newBrakeTemp - 5, newBrakeTemp - 5)

        // Warnings Generation
        val warnings = mutableListOf<String>()
        if (activeFaults.contains(FaultType.BATTERY_OVERHEAT)) warnings.add("CRITICAL: Battery Cell Temperature High (>60°C)")
        if (activeFaults.contains(FaultType.TIRE_PRESSURE_LOSS)) warnings.add("WARNING: TPMS Pressure Low Rear-Left (1.1 Bar)")
        if (activeFaults.contains(FaultType.BRAKE_OVERHEAT)) warnings.add("WARNING: Brake System Thermal Overload (385°C)")
        if (activeFaults.contains(FaultType.WHEEL_SPEED_DISAGREEMENT)) warnings.add("WARNING: ABS/ESP Wheel Speed Disagreement")
        if (activeFaults.contains(FaultType.SPEED_SENSOR_DROPOUT)) warnings.add("ADVISORY: Speedometer Sensor Signal Dropout")
        if (activeFaults.contains(FaultType.ECU_COMM_TIMEOUT)) warnings.add("CRITICAL: ECU Bus Communication Timeout")
        if (activeFaults.contains(FaultType.DOOR_AJAR)) warnings.add("INFO: Driver Door Ajar")
        if (activeFaults.contains(FaultType.SUDDEN_POWER_DERATING)) warnings.add("WARNING: Propulsion Power Limited - Thermal Derating")
        if (newSocPct < 15.0 && isEvOrHybrid) warnings.add("INFO: Low Traction Battery Charge (<15%)")

        val newTripDistanceKm = currentTelemetry.tripDistanceKm + (newSpeedMs * deltaTimeSec) / 1000.0
        val newOdometerKm = currentTelemetry.odometerKm + (newSpeedMs * deltaTimeSec) / 1000.0

        val qualityFlags = if (activeFaults.contains(FaultType.SPEED_SENSOR_DROPOUT) || activeFaults.contains(FaultType.ECU_COMM_TIMEOUT)) {
            "DEGRADED"
        } else "VALID"

        return currentTelemetry.copy(
            timestamp = System.currentTimeMillis(),
            speedKmh = if (activeFaults.contains(FaultType.SPEED_SENSOR_DROPOUT)) 0.0 else newSpeedKmh,
            longitudinalAccelG = (accelMs2 / GRAVITY).coerceIn(-1.5, 1.5),
            lateralAccelG = if (newSpeedKmh > 20) (sin(System.currentTimeMillis() / 1000.0) * 0.25) else 0.0,
            wheelSpeedsKmh = wheelSpeeds,
            odometerKm = newOdometerKm,
            tripDistanceKm = newTripDistanceKm,
            powerKw = netPowerKw,
            torqueNm = if (newEngineRpm > 0) (netPowerKw * 9549.0 / max(newEngineRpm, 100.0)).coerceIn(-350.0, 650.0) else 0.0,
            engineRpm = newEngineRpm,
            gear = newGear,
            throttlePct = effectiveThrottle * 100.0,
            brakeBar = rawBrake,
            socPct = newSocPct,
            batteryVoltageV = newBatteryVoltageV,
            batteryCurrentA = newBatteryCurrentA,
            batteryTempC = newBatteryTempC,
            cellTempSpreadC = newCellTempSpread,
            chargingPowerKw = newChargingPowerKw,
            fuelLevelPct = newFuelLevelPct,
            fuelFlowLPerH = newFuelFlowLPerH,
            coolantTempC = newCoolantTempC,
            tirePressuresBar = newPressures,
            tireTempsC = newTireTemps,
            warnings = warnings,
            qualityFlags = qualityFlags
        )
    }
}
