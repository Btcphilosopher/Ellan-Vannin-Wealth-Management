package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.VehicleRepository
import com.example.domain.model.TelemetrySample
import com.example.domain.model.TripRecord
import com.example.simulation.SimulationController
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun TripComputerScreen(
    controller: SimulationController,
    repository: VehicleRepository,
    telemetry: TelemetrySample,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val savedTrips by repository.allTrips.collectAsState(initial = emptyList())

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CockpitBackground)
            .padding(12.dp)
    ) {
        // Active Trip Dashboard Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = CockpitSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LIVE TRIP COMPUTER",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )

                    Button(
                        onClick = {
                            val newTrip = TripRecord(
                                id = "trip-${System.currentTimeMillis()}",
                                vehicleId = telemetry.vehicleId,
                                title = "Urban Drive Session",
                                startTime = System.currentTimeMillis() - 1200000,
                                endTime = System.currentTimeMillis(),
                                distanceKm = telemetry.tripDistanceKm.coerceAtLeast(1.2),
                                durationSec = 1200,
                                avgSpeedKmh = 42.5,
                                maxSpeedKmh = telemetry.speedKmh.coerceAtLeast(65.0),
                                energyConsumedKwh = (telemetry.tripDistanceKm * 0.18),
                                avgConsumptionWhKm = 180.0,
                                fuelConsumedL = 0.0,
                                avgFuelLPer100Km = 0.0,
                                regenRecoveredKwh = 0.42,
                                costEur = (telemetry.tripDistanceKm * 0.18 * 0.32),
                                co2Kg = 0.0
                            )
                            coroutineScope.launch { repository.saveTrip(newTrip) }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(text = "RECORD TRIP", color = androidx.compose.ui.graphics.Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricCard("DISTANCE", "${String.format("%.2f", telemetry.tripDistanceKm)} km", ElectricCyan)
                    MetricCard("POWER DEMAND", "${String.format("%.1f", telemetry.powerKw)} kW", PhosphorBlue)
                    MetricCard("TOTAL ODOMETER", "${String.format("%.1f", telemetry.odometerKm)} km", TextPrimary)
                }
            }
        }

        // Saved Trip History
        Text(
            text = "PERSISTED HISTORICAL TRIPS (${savedTrips.size})",
            style = MaterialTheme.typography.titleSmall,
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (savedTrips.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CockpitSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
            ) {
                Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(text = "No saved trips yet. Tap 'RECORD TRIP' above to save active session.", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(savedTrips) { trip ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CockpitSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = trip.title, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${String.format("%.1f", trip.distanceKm)} km | ${trip.durationSec / 60} mins | Avg ${trip.avgSpeedKmh.toInt()} km/h",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${String.format("%.2f", trip.energyConsumedKwh)} kWh",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ElectricCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "€${String.format("%.2f", trip.costEur)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EcoGreen
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
