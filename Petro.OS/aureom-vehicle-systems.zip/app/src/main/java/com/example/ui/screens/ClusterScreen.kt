package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.PowertrainArchitecture
import com.example.domain.model.TelemetrySample
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

enum class ClusterLayout {
    ELECTRIC,
    CLASSIC,
    PERFORMANCE,
    FLEET
}

@Composable
fun ClusterScreen(
    telemetry: TelemetrySample,
    architecture: PowertrainArchitecture,
    modifier: Modifier = Modifier
) {
    var activeLayout by remember { mutableStateOf(ClusterLayout.ELECTRIC) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CockpitBackground)
            .padding(12.dp)
    ) {
        // Layout Selector Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Speed,
                    contentDescription = "Cluster",
                    tint = ElectricCyan,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "DIGITAL INSTRUMENT COCKPIT",
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CockpitSurface)
                    .border(1.dp, CockpitBorder, RoundedCornerShape(8.dp))
                    .padding(4.dp)
            ) {
                ClusterLayout.values().forEach { layout ->
                    val isSelected = activeLayout == layout
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) ElectricCyan else Color.Transparent)
                            .clickable { activeLayout = layout }
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = layout.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) Color.Black else TextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        // Active Warnings Banner Bar
        if (telemetry.warnings.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CriticalRed.copy(alpha = 0.18f))
                    .border(1.dp, CriticalRed.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Warning",
                    tint = CriticalRed,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = telemetry.warnings.first(),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Main Cluster Layout
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = CockpitSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CockpitBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                when (activeLayout) {
                    ClusterLayout.ELECTRIC -> ElectricClusterView(telemetry)
                    ClusterLayout.CLASSIC -> ClassicClusterView(telemetry)
                    ClusterLayout.PERFORMANCE -> PerformanceClusterView(telemetry)
                    ClusterLayout.FLEET -> FleetClusterView(telemetry)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Warning Lamps Strip at Bottom
        WarningLampsStrip(telemetry)
    }
}

@Composable
fun ElectricClusterView(telemetry: TelemetrySample) {
    val animatedSpeed by animateFloatAsState(
        targetValue = telemetry.speedKmh.toFloat(),
        animationSpec = tween(durationMillis = 200),
        label = "speed"
    )
    val animatedPower by animateFloatAsState(
        targetValue = telemetry.powerKw.toFloat(),
        animationSpec = tween(durationMillis = 200),
        label = "power"
    )

    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Power/Regen Meter (Left Gauge)
        Box(
            modifier = Modifier.size(210.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2, size.height / 2)
                val radius = size.width / 2 - 16.dp.toPx()

                // Background Arc
                drawArc(
                    color = CockpitBorder,
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                )

                // Power Arc
                val powerPct = (animatedPower / 280f).coerceIn(-0.3f, 1f)
                val sweep = powerPct * 200f
                val arcColor = if (animatedPower < 0) EcoGreen else ElectricCyan

                drawArc(
                    color = arcColor,
                    startAngle = 225f,
                    sweepAngle = sweep,
                    useCenter = false,
                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (telemetry.powerKw < 0) "REGEN" else "POWER",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                Text(
                    text = "${animatedPower.toInt()}",
                    style = MaterialTheme.typography.headlineMedium,
                    color = if (telemetry.powerKw < 0) EcoGreen else ElectricCyan,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "kW",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
            }
        }

        // Central Speedometer & Drive Mode
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Gear Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(ElectricCyan.copy(alpha = 0.15f))
                    .border(1.dp, ElectricCyan, RoundedCornerShape(8.dp))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = telemetry.gear,
                    style = MaterialTheme.typography.headlineSmall,
                    color = ElectricCyan,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "${animatedSpeed.toInt()}",
                style = MaterialTheme.typography.displayLarge,
                color = TextPrimary,
                fontWeight = FontWeight.Black,
                fontSize = 76.sp,
                fontFamily = FontFamily.Monospace
            )

            Text(
                text = "km/h",
                style = MaterialTheme.typography.titleMedium,
                color = TextSecondary,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                BadgeChip("MODE: ${telemetry.driveMode}", PhosphorBlue)
                Spacer(modifier = Modifier.width(8.dp))
                BadgeChip("SOC: ${telemetry.socPct.toInt()}%", if (telemetry.socPct < 20) CriticalRed else EcoGreen)
            }
        }

        // Battery State & Range (Right Gauge)
        Box(
            modifier = Modifier.size(210.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val radius = size.width / 2 - 16.dp.toPx()

                drawArc(
                    color = CockpitBorder,
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                )

                val socSweep = (telemetry.socPct / 100f).toFloat() * 270f
                drawArc(
                    color = if (telemetry.socPct < 20) CriticalRed else PhosphorBlue,
                    startAngle = 135f,
                    sweepAngle = socSweep,
                    useCenter = false,
                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.BatteryChargingFull,
                    contentDescription = "Battery",
                    tint = PhosphorBlue,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${(telemetry.socPct * 5.2).toInt()}",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "EST. RANGE (KM)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }
        }
    }
}

@Composable
fun ClassicClusterView(telemetry: TelemetrySample) {
    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Speedometer Dial
        GaugeDial(
            value = telemetry.speedKmh.toFloat(),
            maxValue = 260f,
            title = "SPEED",
            unit = "KM/H",
            accentColor = ElectricCyan
        )

        // Center Info Stack
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = telemetry.gear,
                style = MaterialTheme.typography.displayMedium,
                color = ElectricCyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "GEAR",
                style = MaterialTheme.typography.labelMedium,
                color = TextMuted
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "${String.format("%.1f", telemetry.tripDistanceKm)} km",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "TRIP A",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }

        // Tachometer (RPM / Power Dial)
        GaugeDial(
            value = telemetry.engineRpm.toFloat(),
            maxValue = 7000f,
            title = "TACHOMETER",
            unit = "RPM",
            accentColor = PhosphorBlue
        )
    }
}

@Composable
fun PerformanceClusterView(telemetry: TelemetrySample) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            MetricCard("TORQUE", "${telemetry.torqueNm.toInt()} Nm", PhosphorBlue)
            MetricCard("POWER", "${telemetry.powerKw.toInt()} kW", ElectricCyan)
            MetricCard("G-FORCE", "${String.format("%.2f", telemetry.longitudinalAccelG)} G", AmberWarning)
            MetricCard("COOLANT", "${telemetry.coolantTempC.toInt()} °C", if (telemetry.coolantTempC > 105) CriticalRed else EcoGreen)
        }

        // Giant Speed Readout
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "${telemetry.speedKmh.toInt()}",
                style = MaterialTheme.typography.displayLarge,
                color = ElectricCyan,
                fontSize = 84.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "TRACK SPRINT MODE",
                style = MaterialTheme.typography.titleSmall,
                color = TextSecondary,
                letterSpacing = 3.sp
            )
        }

        // TPMS Grid
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CockpitSurfaceVariant)
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            telemetry.tirePressuresBar.forEachIndexed { idx, press ->
                val name = listOf("FL", "FR", "RL", "RR")[idx]
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = name, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(
                        text = "${String.format("%.1f", press)} Bar",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (press < 1.8) CriticalRed else TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun FleetClusterView(telemetry: TelemetrySample) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceAround
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            InfoTile("VEHICLE ID", telemetry.vehicleId)
            InfoTile("ODOMETER", "${String.format("%.1f", telemetry.odometerKm)} km")
            InfoTile("QUALITY", telemetry.qualityFlags)
            InfoTile("PROVENANCE", "SIMULATION")
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            GaugeDial(value = telemetry.speedKmh.toFloat(), maxValue = 220f, title = "FLEET SPEED", unit = "KM/H", accentColor = ElectricCyan)
            GaugeDial(value = telemetry.socPct.toFloat(), maxValue = 100f, title = "ENERGY LEVEL", unit = "%", accentColor = EcoGreen)
        }
    }
}

@Composable
fun GaugeDial(
    value: Float,
    maxValue: Float,
    title: String,
    unit: String,
    accentColor: Color
) {
    Box(
        modifier = Modifier.size(190.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val radius = size.width / 2 - 14.dp.toPx()

            drawArc(
                color = CockpitBorder,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
            )

            val sweep = (value / maxValue).coerceIn(0f, 1f) * 270f
            drawArc(
                color = accentColor,
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Text(
                text = "${value.toInt()}",
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(text = unit, style = MaterialTheme.typography.labelSmall, color = accentColor)
        }
    }
}

@Composable
fun WarningLampsStrip(telemetry: TelemetrySample) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CockpitSurface)
            .border(1.dp, CockpitBorder, RoundedCornerShape(12.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        WarningLamp(icon = Icons.Default.BatteryAlert, label = "HV", active = telemetry.socPct < 15 || telemetry.batteryTempC > 50, alertColor = CriticalRed)
        WarningLamp(icon = Icons.Default.Thermostat, label = "TEMP", active = telemetry.batteryTempC > 50 || telemetry.coolantTempC > 100, alertColor = CriticalRed)
        WarningLamp(icon = Icons.Default.TireRepair, label = "TPMS", active = telemetry.tirePressuresBar.any { it < 1.8 }, alertColor = AmberWarning)
        WarningLamp(icon = Icons.Default.ElectricCar, label = "READY", active = true, alertColor = EcoGreen)
        WarningLamp(icon = Icons.Default.Shield, label = "ABS", active = telemetry.warnings.any { it.contains("ABS") }, alertColor = AmberWarning)
    }
}

@Composable
fun WarningLamp(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, alertColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (active) alertColor else TextMuted.copy(alpha = 0.4f),
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) alertColor else TextMuted.copy(alpha = 0.4f),
            fontSize = 9.sp
        )
    }
}

@Composable
fun BadgeChip(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelSmall, color = color, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MetricCard(label: String, value: String, color: Color) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(CockpitSurfaceVariant)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Text(text = value, style = MaterialTheme.typography.titleMedium, color = color, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun InfoTile(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
    }
}
