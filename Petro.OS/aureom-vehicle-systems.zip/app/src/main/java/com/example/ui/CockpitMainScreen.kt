package com.example.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.api.AureomApiGateway
import com.example.api.FibredashCliEngine
import com.example.data.VehicleRepository
import com.example.domain.model.DriveMode
import com.example.domain.model.PowertrainArchitecture
import com.example.domain.model.Vehicle
import com.example.domain.model.VehicleConfig
import com.example.simulation.DrivingScenarios
import com.example.simulation.SimulationController
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class CockpitTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    CLUSTER("CLUSTER", Icons.Default.Speed),
    INFOTAINMENT("INFOTAINMENT", Icons.Default.ElectricCar),
    TWIN("DIGITAL TWIN", Icons.Default.AccountTree),
    DIAGNOSTICS("DIAGNOSTICS", Icons.Default.BugReport),
    TRIPS("TRIPS", Icons.Default.Map),
    FLEET("FLEET Radar", Icons.Default.Radar),
    API_CLI("API & CLI", Icons.Default.Terminal)
}

@Composable
fun CockpitMainScreen(
    controller: SimulationController,
    apiGateway: AureomApiGateway,
    cliEngine: FibredashCliEngine,
    repository: VehicleRepository
) {
    val telemetry by controller.currentTelemetry.collectAsState()
    val selectedVehicle by controller.selectedVehicle.collectAsState()
    val isRunning by controller.isRunning.collectAsState()
    val speedMultiplier by controller.speedMultiplier.collectAsState()
    val activeScenario by controller.activeScenario.collectAsState()

    var currentTab by remember { mutableStateOf(CockpitTab.CLUSTER) }
    var vehicleMenuExpanded by remember { mutableStateOf(false) }
    var scenarioMenuExpanded by remember { mutableStateOf(false) }

    val vehicleOptions = remember {
        listOf(
            controller.defaultVehicle,
            Vehicle(
                id = "stellantis-phev-02",
                vin = "VR7AUR2026P801456",
                name = "Aureom Hybrid Executive",
                variant = "1.6T Plug-in Hybrid AWD",
                architecture = PowertrainArchitecture.PHEV,
                config = VehicleConfig(batteryCapacityKwh = 17.8, usableBatteryKwh = 15.2, maxMotorPowerKw = 165.0)
            ),
            Vehicle(
                id = "stellantis-ice-03",
                vin = "ZFAAUR2026I700982",
                name = "Aureom V6 Sport Concept",
                variant = "3.0 Twin-Turbo V6 Euro7",
                architecture = PowertrainArchitecture.ICE,
                config = VehicleConfig(batteryCapacityKwh = 0.0, usableBatteryKwh = 0.0, maxMotorPowerKw = 380.0)
            )
        )
    }

    Scaffold(
        topBar = {
            // Automotive Cockpit Top Bar
            Surface(
                color = CockpitSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CockpitBorder)
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Vehicle Selector & Brand Title
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AUREOM",
                                style = MaterialTheme.typography.titleMedium,
                                color = ElectricCyan,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "AUTO",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Light,
                                letterSpacing = 2.sp
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Box {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(CockpitSurfaceVariant)
                                        .border(1.dp, CockpitBorder, RoundedCornerShape(6.dp))
                                        .clickable { vehicleMenuExpanded = true }
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${selectedVehicle.name} [${selectedVehicle.architecture}]",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Select", tint = TextMuted)
                                    }
                                }

                                DropdownMenu(
                                    expanded = vehicleMenuExpanded,
                                    onDismissRequest = { vehicleMenuExpanded = false }
                                ) {
                                    vehicleOptions.forEach { v ->
                                        DropdownMenuItem(
                                            text = { Text("${v.name} (${v.architecture})", color = TextPrimary) },
                                            onClick = {
                                                controller.setVehicle(v)
                                                vehicleMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Simulation Transport & Playback Controls
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Scenario Dropdown
                            Box {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(CockpitSurfaceVariant)
                                        .border(1.dp, CockpitBorder, RoundedCornerShape(6.dp))
                                        .clickable { scenarioMenuExpanded = true }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "Scenario: ${activeScenario.name}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PhosphorBlue
                                        )
                                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Scenario", tint = TextMuted)
                                    }
                                }

                                DropdownMenu(
                                    expanded = scenarioMenuExpanded,
                                    onDismissRequest = { scenarioMenuExpanded = false }
                                ) {
                                    DrivingScenarios.ALL.forEach { sc ->
                                        DropdownMenuItem(
                                            text = { Text(sc.name, color = TextPrimary) },
                                            onClick = {
                                                controller.setScenario(sc)
                                                scenarioMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // Play/Pause Button
                            IconButton(
                                onClick = { controller.toggleSimulation() },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isRunning) EcoGreen.copy(alpha = 0.2f) else CriticalRed.copy(alpha = 0.2f))
                            ) {
                                Icon(
                                    imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Toggle",
                                    tint = if (isRunning) EcoGreen else CriticalRed,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            // Speed Multiplier Toggle
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CockpitSurfaceVariant)
                                    .clickable {
                                        val nextMult = when (speedMultiplier) {
                                            1.0 -> 2.0
                                            2.0 -> 5.0
                                            else -> 1.0
                                        }
                                        controller.setSpeedMultiplier(nextMult)
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${speedMultiplier.toInt()}x",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Drive Mode Selectors Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            DriveMode.values().forEach { mode ->
                                val isSelected = telemetry.driveMode == mode
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSelected) ElectricCyan else CockpitSurfaceVariant)
                                        .clickable { controller.setDriveMode(mode) }
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = mode.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) Color.Black else TextMuted,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }

                        Text(
                            text = "VIN: ${selectedVehicle.vin}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        },
        bottomBar = {
            // M3 Cockpit Bottom Navigation Bar
            NavigationBar(
                containerColor = CockpitSurface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .border(1.dp, CockpitBorder)
            ) {
                CockpitTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                tint = if (isSelected) ElectricCyan else TextMuted
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) ElectricCyan else TextMuted,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = ElectricCyan.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Crossfade(
            targetState = currentTab,
            modifier = Modifier.padding(innerPadding),
            label = "tab_crossfade"
        ) { tab ->
            when (tab) {
                CockpitTab.CLUSTER -> ClusterScreen(telemetry = telemetry, architecture = selectedVehicle.architecture)
                CockpitTab.INFOTAINMENT -> InfotainmentScreen(telemetry = telemetry)
                CockpitTab.TWIN -> DigitalTwinScreen(apiGateway = apiGateway, telemetry = telemetry)
                CockpitTab.DIAGNOSTICS -> DiagnosticsScreen(controller = controller)
                CockpitTab.TRIPS -> TripComputerScreen(controller = controller, repository = repository, telemetry = telemetry)
                CockpitTab.FLEET -> FleetScreen(telemetry = telemetry)
                CockpitTab.API_CLI -> ApiConsoleScreen(apiGateway = apiGateway, cliEngine = cliEngine, telemetry = telemetry)
            }
        }
    }
}
