package com.example.model

import java.io.Serializable

data class Vehicle(
  val id: String,
  val make: String,
  val model: String,
  val trim: String,
  val year: Int,
  val askingPrice: Double,
  val mileage: Int,
  val condition: String, // "New", "Used - Certified", "Used"
  val bodyType: String, // "SUV", "Sedan", "Electric", "Truck"
  val powertrain: String, // "Gasoline", "EV", "Hybrid"
  val distance: String,
  val dealerName: String,
  val location: String,
  val imageUrls: List<String>,
  val features: List<String>,
  val specifications: Map<String, String>,
  val isRental: Boolean = false,
  val rentalRatePerDay: Double? = null,
  val category: String, // "SUVs", "Electric", "Sedans", "Used"
  val sellerStatement: String,
  val verifiedInspection: Boolean = true
) : Serializable

data class VehicleQuote(
  val vehicleId: String,
  val vehiclePrice: Double,
  val dealerFee: Double = 400.0,
  val taxes: Double,
  val registrationFee: Double = 350.0,
  val deliveryFee: Double = 150.0,
  val optionalProducts: Double = 0.0,
  val deposit: Double = 500.0,
  val subtotalBeforeTax: Double,
  val remainingBalance: Double,
  val totalQuoted: Double,
  val timestamp: Long = System.currentTimeMillis()
) : Serializable

data class TestDriveAppointment(
  val id: String,
  val vehicleId: String,
  val vehicleName: String,
  val date: String,
  val time: String,
  val status: String, // "Requested", "Confirmed", "Rescheduled", "Cancelled"
  val dealerName: String
) : Serializable

data class RentalBooking(
  val id: String,
  val vehicleCategory: String,
  val pickupLocation: String,
  val returnLocation: String,
  val startDate: String,
  val endDate: String,
  val driverAgeBand: String, // "25+"
  val transmission: String, // "Automatic"
  val mileageAllowance: String, // "Unlimited"
  val fuelPolicy: String, // "Full to Full"
  val billableDays: Int,
  val dailyRate: Double,
  val mandatoryFees: Double,
  val estimatedTotal: Double,
  val status: String // "Confirmed", "Completed", "Cancelled"
) : Serializable

data class Reservation(
  val id: String,
  val vehicleId: String,
  val vehicleName: String,
  val depositAmount: Double,
  val status: String, // "Hold Active", "Pending Dealer Acceptance", "Accepted", "Completed", "Expired"
  val timestamp: Long = System.currentTimeMillis(),
  val dealerName: String
) : Serializable

data class Receipt(
  val id: String,
  val transactionType: String, // "Deposit", "Full Payment", "Rental Pre-authorization"
  val referenceId: String,
  val amount: Double,
  val paymentMethod: String, // "Local Simulator Sandbox (Card ending in 4242)"
  val status: String, // "Verified", "Refunded"
  val timestamp: Long = System.currentTimeMillis()
) : Serializable
