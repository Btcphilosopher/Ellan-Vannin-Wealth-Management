package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmazonYellow

@Composable
fun AccountScreen(
  location: String,
  isOfflineMode: Boolean,
  onLocationChange: (String) -> Unit,
  onToggleOffline: () -> Unit,
  onOpenAdmin: () -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingValues(16.dp)
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            modifier = Modifier.size(56.dp),
            shape = RoundedCornerShape(50),
            color = AmazonYellow
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(32.dp))
            }
          }
          Spacer(modifier = Modifier.width(16.dp))
          Column {
            Text("Amazon Autos Customer", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("buyer@amazonautos-demo.com", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
      Text("Preferences & Settings", fontWeight = FontWeight.Bold, fontSize = 16.sp)
      Spacer(modifier = Modifier.height(8.dp))

      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.LocationOn, contentDescription = null, tint = AmazonYellow)
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("Default Shopping Location", fontWeight = FontWeight.SemiBold)
                Text(location, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
              }
            }
            TextButton(onClick = { onLocationChange("Portland, OR") }) {
              Text("Change")
            }
          }

          Divider(modifier = Modifier.padding(vertical = 12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.CloudOff, contentDescription = null, tint = if (isOfflineMode) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("Simulate Offline Mode", fontWeight = FontWeight.SemiBold)
                Text("Test offline cached browsing", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
              }
            }
            Switch(
              checked = isOfflineMode,
              onCheckedChange = { onToggleOffline() },
              colors = SwitchDefaults.colors(checkedThumbColor = AmazonYellow)
            )
          }

          Divider(modifier = Modifier.padding(vertical = 12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = AmazonYellow)
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("Dealer & Rental Admin", fontWeight = FontWeight.SemiBold)
                Text("Manage inventory, quotes & fleet", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
              }
            }
            Button(
              onClick = onOpenAdmin,
              colors = ButtonDefaults.buttonColors(containerColor = AmazonYellow, contentColor = MaterialTheme.colorScheme.onPrimary)
            ) {
              Text("Open Dashboard")
            }
          }
        }
      }
    }
  }
}
