package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Vehicle
import com.example.ui.theme.AmazonYellow

@Composable
fun CompareScreen(
  comparedVehicles: List<Vehicle>,
  onBackClick: () -> Unit,
  onRemoveCompare: (String) -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surface)
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBackClick) {
        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
      }
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "Vehicle Comparison (${comparedVehicles.size}/3)",
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold
      )
    }

    if (comparedVehicles.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("No vehicles selected for comparison.", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
          Spacer(modifier = Modifier.height(8.dp))
          Text("Tap '+ Compare' on any vehicle card in search or home to compare up to 3 cars.", fontSize = 13.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
        }
      }
    } else {
      Row(
        modifier = Modifier
          .fillMaxSize()
          .horizontalScroll(rememberScrollState())
          .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        comparedVehicles.forEach { vehicle ->
          Card(
            modifier = Modifier
              .width(260.dp)
              .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(
              modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
            ) {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(140.dp)
              ) {
                AsyncImage(
                  model = vehicle.imageUrls.firstOrNull(),
                  contentDescription = vehicle.model,
                  contentScale = ContentScale.Crop,
                  modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(8.dp))
                )
                IconButton(
                  onClick = { onRemoveCompare(vehicle.id) },
                  modifier = Modifier
                    .align(Alignment.TopEnd)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f), RoundedCornerShape(50))
                    .size(32.dp)
                ) {
                  Icon(Icons.Default.Close, contentDescription = "Remove", modifier = Modifier.size(16.dp))
                }
              }

              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "${vehicle.year} ${vehicle.make} ${vehicle.model}",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Text(
                text = vehicle.trim,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
              )

              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "$${String.format("%,d", vehicle.askingPrice.toInt())}",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = AmazonYellow
              )

              Divider(modifier = Modifier.padding(vertical = 12.dp))

              ComparisonSpecRow("Condition", vehicle.condition)
              ComparisonSpecRow("Mileage", "${vehicle.mileage} miles")
              ComparisonSpecRow("Body Type", vehicle.bodyType)
              ComparisonSpecRow("Powertrain", vehicle.powertrain)
              ComparisonSpecRow("Distance", vehicle.distance)
              ComparisonSpecRow("Dealer", vehicle.dealerName)

              Spacer(modifier = Modifier.height(8.dp))
              Text("Key Features:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
              vehicle.features.take(3).forEach { feature ->
                Text("• $feature", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ComparisonSpecRow(label: String, value: String) {
  Column(modifier = Modifier.padding(vertical = 4.dp)) {
    Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
    Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
  }
}
