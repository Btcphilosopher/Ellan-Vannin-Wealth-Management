package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Vehicle
import com.example.ui.components.VehicleCard

@Composable
fun SavedScreen(
  vehicles: List<Vehicle>,
  savedVehicleIds: Set<String>,
  comparedVehicleIds: List<String>,
  onVehicleClick: (String) -> Unit,
  onSaveClick: (String) -> Unit,
  onCompareToggle: (String) -> Unit
) {
  val savedVehicles = vehicles.filter { savedVehicleIds.contains(it.id) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Surface(
      modifier = Modifier.fillMaxWidth(),
      color = MaterialTheme.colorScheme.surface
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text("Saved Vehicles", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Your bookmarked cars and saved search drafts", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
      }
    }

    if (savedVehicles.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("No saved vehicles yet.", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
          Spacer(modifier = Modifier.height(4.dp))
          Text("Tap the heart icon on any vehicle card to save it for quick access.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp)
      ) {
        items(savedVehicles) { vehicle ->
          VehicleCard(
            vehicle = vehicle,
            isSaved = true,
            isCompared = comparedVehicleIds.contains(vehicle.id),
            onCardClick = { onVehicleClick(vehicle.id) },
            onSaveClick = { onSaveClick(vehicle.id) },
            onCompareToggle = { onCompareToggle(vehicle.id) }
          )
        }
      }
    }
  }
}
