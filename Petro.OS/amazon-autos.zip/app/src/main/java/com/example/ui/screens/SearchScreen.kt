package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.model.Vehicle
import com.example.ui.components.VehicleCard
import com.example.ui.theme.AmazonYellow

@Composable
fun SearchScreen(
  vehicles: List<Vehicle>,
  savedVehicleIds: Set<String>,
  comparedVehicleIds: List<String>,
  onVehicleClick: (String) -> Unit,
  onSaveClick: (String) -> Unit,
  onCompareToggle: (String) -> Unit,
  onCompareClick: () -> Unit
) {
  var query by remember { mutableStateOf("") }
  var selectedMake by remember { mutableStateOf("All") }
  var selectedBody by remember { mutableStateOf("All") }

  val makes = listOf("All", "Hyundai", "Tesla", "Toyota")
  val bodyTypes = listOf("All", "SUV", "Sedan", "Electric")

  val filtered = remember(vehicles, query, selectedMake, selectedBody) {
    vehicles.filter { v ->
      val matchesQuery = query.isBlank() ||
        v.make.contains(query, ignoreCase = true) ||
        v.model.contains(query, ignoreCase = true) ||
        v.trim.contains(query, ignoreCase = true) ||
        v.dealerName.contains(query, ignoreCase = true)

      val matchesMake = selectedMake == "All" || v.make.equals(selectedMake, ignoreCase = true)
      val matchesBody = selectedBody == "All" || v.bodyType.equals(selectedBody, ignoreCase = true)

      matchesQuery && matchesMake && matchesBody
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
    ) {
      // Search Input
      OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        placeholder = { Text("Search cars by make, model or keyword...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
          if (query.isNotBlank()) {
            IconButton(onClick = { query = "" }) {
              Icon(Icons.Default.Clear, contentDescription = "Clear")
            }
          }
        },
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surface
        )
      )

      // Filters
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Make dropdown/filter
        ScrollableTabRow(
          selectedTabIndex = makes.indexOf(selectedMake).coerceAtLeast(0),
          edgePadding = 0.dp,
          containerColor = MaterialTheme.colorScheme.background,
          indicator = {},
          divider = {}
        ) {
          makes.forEach { make ->
            FilterChip(
              selected = selectedMake == make,
              onClick = { selectedMake = make },
              label = { Text(make) },
              modifier = Modifier.padding(end = 6.dp),
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = AmazonYellow,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
              )
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
      ) {
        item {
          Text(
            text = "${filtered.size} vehicles found",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
            modifier = Modifier.padding(bottom = 8.dp)
          )
        }

        items(filtered) { vehicle ->
          VehicleCard(
            vehicle = vehicle,
            isSaved = savedVehicleIds.contains(vehicle.id),
            isCompared = comparedVehicleIds.contains(vehicle.id),
            onCardClick = { onVehicleClick(vehicle.id) },
            onSaveClick = { onSaveClick(vehicle.id) },
            onCompareToggle = { onCompareToggle(vehicle.id) }
          )
        }
      }
    }

    // Compare floating bar
    if (comparedVehicleIds.isNotEmpty()) {
      Surface(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .padding(16.dp),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        shadowElevation = 8.dp
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CompareArrows, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Comparing ${comparedVehicleIds.size}/3 vehicles",
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onPrimaryContainer
            )
          }

          Button(
            onClick = onCompareClick,
            colors = ButtonDefaults.buttonColors(containerColor = AmazonYellow, contentColor = MaterialTheme.colorScheme.onPrimary)
          ) {
            Text("Compare Now")
          }
        }
      }
    }
  }
}
