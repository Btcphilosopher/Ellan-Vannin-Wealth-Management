package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmazonYellow
import com.example.ui.theme.SuccessGreen

@Composable
fun AdminScreen(onBackClick: () -> Unit) {
  val context = LocalContext.current
  var selectedTab by remember { mutableStateOf(0) }
  val adminTabs = listOf("Inventory", "Test Drives", "Reservations", "Fleet Maintenance")

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surface)
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBackClick) {
        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
      }
      Spacer(modifier = Modifier.width(8.dp))
      Column {
        Text("Dealer & Rental Admin Portal", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Amazon Certified Motors - Seattle Organisation", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
      }
    }

    ScrollableTabRow(selectedTabIndex = selectedTab) {
      adminTabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedTab == index,
          onClick = { selectedTab = index },
          text = { Text(title) }
        )
      }
    }

    when (selectedTab) {
      0 -> AdminInventoryTab()
      1 -> AdminTestDrivesTab()
      2 -> AdminReservationsTab()
      3 -> AdminFleetTab()
    }
  }
}

@Composable
fun AdminInventoryTab() {
  val context = LocalContext.current
  LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Organisation Catalogue", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Button(
          onClick = { Toast.makeText(context, "New listing form opened", Toast.LENGTH_SHORT).show() },
          colors = ButtonDefaults.buttonColors(containerColor = AmazonYellow)
        ) {
          Text("+ Add Listing")
        }
      }
      Spacer(modifier = Modifier.height(12.dp))
    }

    items(4) { index ->
      val models = listOf("2026 Tucson SEL", "2026 IONIQ 5 SE", "2026 Sonata SEL", "2026 Santa Fe SE")
      val prices = listOf("$32,900", "$43,500", "$29,900", "$35,900")
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(models[index], fontWeight = FontWeight.Bold)
            Text("Asking Price: ${prices[index]} · Status: Active", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
          }
          OutlinedButton(onClick = { Toast.makeText(context, "Listing updated", Toast.LENGTH_SHORT).show() }) {
            Text("Edit")
          }
        }
      }
    }
  }
}

@Composable
fun AdminTestDrivesTab() {
  val context = LocalContext.current
  LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
    item {
      Text("Scheduled Test Drive Appointments", fontWeight = FontWeight.Bold, fontSize = 16.sp)
      Spacer(modifier = Modifier.height(12.dp))
    }
    items(2) { index ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("2026 Tucson SEL - Customer Test Drive", fontWeight = FontWeight.Bold)
          Text("Time: Tomorrow, 2:00 PM · Status: Confirmed", fontSize = 12.sp, color = SuccessGreen)
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { Toast.makeText(context, "Appointment marked complete", Toast.LENGTH_SHORT).show() }) {
              Text("Complete")
            }
            OutlinedButton(onClick = { Toast.makeText(context, "Rescheduled", Toast.LENGTH_SHORT).show() }) {
              Text("Reschedule")
            }
          }
        }
      }
    }
  }
}

@Composable
fun AdminReservationsTab() {
  val context = LocalContext.current
  LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
    item {
      Text("Purchase Reservations & Deposit Holds", fontWeight = FontWeight.Bold, fontSize = 16.sp)
      Spacer(modifier = Modifier.height(12.dp))
    }
    items(1) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("2026 IONIQ 5 SE - Hold Active ($500 Deposit)", fontWeight = FontWeight.Bold)
          Text("Expires in 18 hours. Awaiting dealer handover confirmation.", fontSize = 12.sp, color = AmazonYellow)
          Spacer(modifier = Modifier.height(8.dp))
          Button(
            onClick = { Toast.makeText(context, "Reservation accepted and handover initiated!", Toast.LENGTH_LONG).show() },
            colors = ButtonDefaults.buttonColors(containerColor = AmazonYellow)
          ) {
            Text("Accept & Schedule Handover")
          }
        }
      }
    }
  }
}

@Composable
fun AdminFleetTab() {
  val context = LocalContext.current
  LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
    item {
      Text("Rental Fleet & Maintenance Turnaround", fontWeight = FontWeight.Bold, fontSize = 16.sp)
      Spacer(modifier = Modifier.height(12.dp))
    }
    items(2) { index ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(if (index == 0) "Midsize SUV Fleet - Unit #402" else "Electric Crossover Fleet - Unit #108", fontWeight = FontWeight.Bold)
          Text("Status: Ready for Pickup · Turnaround Buffer: Cleaned & Inspected", fontSize = 12.sp, color = SuccessGreen)
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedButton(onClick = { Toast.makeText(context, "Marked for maintenance block", Toast.LENGTH_SHORT).show() }) {
            Text("Block for Maintenance")
          }
        }
      }
    }
  }
}
