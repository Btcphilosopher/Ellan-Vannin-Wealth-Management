package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmazonNavy
import com.example.ui.theme.AmazonYellow
import com.example.ui.theme.TextLight

@Composable
fun TopHeader(
  location: String,
  onLocationClick: () -> Unit,
  isOffline: Boolean,
  onAdminClick: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(AmazonNavy)
      .windowInsetsPadding(WindowInsets.statusBars)
  ) {
    if (isOffline) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.error)
          .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Default.CloudOff, contentDescription = "Offline", tint = TextLight, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Offline Mode: Viewing cached listings. Authoritative availability requires connection.",
          color = TextLight,
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "amazon",
          color = TextLight,
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = " autos",
          color = AmazonYellow,
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(
          onClick = onAdminClick,
          colors = ButtonDefaults.outlinedButtonColors(contentColor = AmazonYellow),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.height(32.dp)
        ) {
          Text("Admin", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.width(8.dp))

        IconButton(onClick = {}, modifier = Modifier.size(36.dp)) {
          Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = TextLight)
        }
      }
    }

    // Location bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(AmazonNavy.copy(alpha = 0.9f))
        .clickable(onClick = onLocationClick)
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = AmazonYellow, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = "Deliver to / Shopping near: ",
        color = TextLight.copy(alpha = 0.7f),
        fontSize = 13.sp
      )
      Text(
        text = location,
        color = TextLight,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold
      )
    }
  }
}
