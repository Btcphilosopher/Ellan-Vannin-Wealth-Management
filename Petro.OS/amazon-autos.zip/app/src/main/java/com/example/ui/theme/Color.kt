package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AmazonNavy = Color(0xFF131A22)
val AmazonNavyDark = Color(0xFF0B1015)
val AmazonCharcoal = Color(0xFF232F3E)
val AmazonCharcoalLight = Color(0xFF374151)
val AmazonYellow = Color(0xFFFF9900)
val AmazonYellowDark = Color(0xFFE88B00)
val AmazonLightBg = Color(0xFFF3F4F6)
val SurfaceWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF111827)
val TextSecondary = Color(0xFF4B5563)
val TextLight = Color(0xFFF9FAFB)
val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
val BorderGray = Color(0xFFE5E7EB)
