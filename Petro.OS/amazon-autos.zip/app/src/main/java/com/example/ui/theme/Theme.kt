package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val AmazonDarkColorScheme =
  darkColorScheme(
    primary = AmazonYellow,
    onPrimary = AmazonNavyDark,
    primaryContainer = AmazonCharcoal,
    onPrimaryContainer = TextLight,
    secondary = AmazonYellowDark,
    onSecondary = SurfaceWhite,
    background = AmazonNavyDark,
    onBackground = TextLight,
    surface = AmazonCharcoal,
    onSurface = TextLight,
    surfaceVariant = AmazonNavy,
    onSurfaceVariant = TextLight,
    error = ErrorRed,
    onError = SurfaceWhite
  )

private val AmazonLightColorScheme =
  lightColorScheme(
    primary = AmazonNavy,
    onPrimary = SurfaceWhite,
    primaryContainer = AmazonYellow,
    onPrimaryContainer = TextPrimary,
    secondary = AmazonYellow,
    onSecondary = TextPrimary,
    background = AmazonLightBg,
    onBackground = TextPrimary,
    surface = SurfaceWhite,
    onSurface = TextPrimary,
    surfaceVariant = AmazonCharcoal,
    onSurfaceVariant = TextLight,
    error = ErrorRed,
    onError = SurfaceWhite
  )

@Composable
fun AmazonAutosTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Default to custom brand colors for authentic Amazon Autos look
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> AmazonDarkColorScheme
      else -> AmazonLightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
