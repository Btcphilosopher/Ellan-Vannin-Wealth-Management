package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Vehicle
import com.example.model.VehicleQuote
import com.example.ui.theme.AmazonYellow
import com.example.ui.theme.SuccessGreen

@Composable
fun VehicleDetailScreen(
  vehicle: Vehicle,
  isSaved: Boolean,
  quote: VehicleQuote?,
  onBackClick: () -> Unit,
  onSaveClick: () -> Unit,
  onGenerateQuote: () -> Unit,
  onBookTestDrive: (date: String, time: String) -> Unit,
  onReserveVehicle: (deposit: Double) -> Unit
) {
  val context = LocalContext.current
  var showTestDriveDialog by remember { mutableStateOf(false) }
  var showReserveDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingValues(bottom = 100.dp)
  ) {
    // Image Header
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(260.dp)
      ) {
        AsyncImage(
          model = vehicle.imageUrls.firstOrNull(),
          contentDescription = vehicle.model,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          IconButton(
            onClick = onBackClick,
            modifier = Modifier
              .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f), RoundedCornerShape(50))
              .size(40.dp)
          ) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }

          IconButton(
            onClick = onSaveClick,
            modifier = Modifier
              .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f), RoundedCornerShape(50))
              .size(40.dp)
          ) {
            Icon(
              imageVector = if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
              contentDescription = "Save",
              tint = if (isSaved) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }
    }

    // Title & Price Header
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surface)
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "${vehicle.year} ${vehicle.make} ${vehicle.model}",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
          )
          if (vehicle.verifiedInspection) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Verified, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Amazon Certified", fontSize = 12.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(text = vehicle.trim, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "$${String.format("%,d", vehicle.askingPrice.toInt())}",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )

          Text(
            text = "${vehicle.distance} · ${vehicle.mileage} miles",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
          )
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Sold & serviced by ${vehicle.dealerName}",
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
        )
      }
    }

    // Seller Statement
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Seller Statement & Inspection", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Spacer(modifier = Modifier.height(6.dp))
          Text(vehicle.sellerStatement, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
        }
      }
    }

    // Itemized Pricing Breakdown Calculator
    item {
      Spacer(modifier = Modifier.height(12.dp))
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Itemized Pricing Breakdown", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
              onClick = onGenerateQuote,
              colors = ButtonDefaults.buttonColors(containerColor = AmazonYellow, contentColor = MaterialTheme.colorScheme.onPrimary)
            ) {
              Text(if (quote == null) "Calculate Quote" else "Recalculate")
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          PricingRow("Vehicle Price", "$${String.format("%,.2f", vehicle.askingPrice)}")
          PricingRow("Mandatory Dealer Fee", "$400.00")
          PricingRow("Registration & Title", "$350.00")
          PricingRow("Delivery Fee", "$150.00")

          if (quote != null) {
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            PricingRow("Subtotal (Before Tax)", "$${String.format("%,.2f", quote.subtotalBeforeTax)}", isBold = true)
            PricingRow("Estimated Sales Tax (8.5%)", "$${String.format("%,.2f", quote.taxes)}")
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            PricingRow("Total Quoted Price", "$${String.format("%,.2f", quote.totalQuoted)}", isBold = true, color = AmazonYellow)
            PricingRow("Required Deposit (Hold)", "$${String.format("%,.2f", quote.deposit)}")
          } else {
            Text(
              text = "Tap Calculate Quote to generate full itemized totals including taxes and delivery.",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
          }
        }
      }
    }

    // Specifications
    item {
      Spacer(modifier = Modifier.height(12.dp))
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Vehicle Specifications", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Spacer(modifier = Modifier.height(8.dp))
          vehicle.specifications.forEach { (key, value) ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(key, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), fontSize = 13.sp)
              Text(value, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
          }
        }
      }
    }

    // Features
    item {
      Spacer(modifier = Modifier.height(12.dp))
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Key Features", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Spacer(modifier = Modifier.height(8.dp))
          vehicle.features.forEach { feature ->
            Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Check, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(feature, fontSize = 13.sp)
            }
          }
        }
      }
    }
  }

  // Bottom Action Bar
  Box(
    modifier = Modifier
      .fillMaxSize()
      .imePadding(),
    contentAlignment = Alignment.BottomCenter
  ) {
    Surface(
      modifier = Modifier.fillMaxWidth(),
      color = MaterialTheme.colorScheme.surface,
      shadowElevation = 16.dp
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedButton(
          onClick = { showTestDriveDialog = true },
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Test Drive")
        }

        Button(
          onClick = {
            if (quote == null) {
              onGenerateQuote()
            }
            showReserveDialog = true
          },
          modifier = Modifier.weight(1f),
          colors = ButtonDefaults.buttonColors(containerColor = AmazonYellow, contentColor = MaterialTheme.colorScheme.onPrimary)
        ) {
          Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Reserve ($500)")
        }
      }
    }
  }

  // Test Drive Booking Dialog
  if (showTestDriveDialog) {
    var selectedDate by remember { mutableStateOf("Tomorrow, 2:00 PM") }
    AlertDialog(
      onDismissRequest = { showTestDriveDialog = false },
      title = { Text("Book Test Drive") },
      text = {
        Column {
          Text("Select appointment slot for ${vehicle.year} ${vehicle.make} ${vehicle.model}:")
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = selectedDate,
            onValueChange = { selectedDate = it },
            label = { Text("Date & Time") }
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onBookTestDrive(selectedDate, "14:00")
            showTestDriveDialog = false
            Toast.makeText(context, "Test drive appointment requested successfully!", Toast.LENGTH_SHORT).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = AmazonYellow)
        ) {
          Text("Confirm Booking")
        }
      },
      dismissButton = {
        TextButton(onClick = { showTestDriveDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }

  // Reserve Vehicle Dialog (Deposit & Hold)
  if (showReserveDialog) {
    AlertDialog(
      onDismissRequest = { showReserveDialog = false },
      title = { Text("Reserve Vehicle (Expiring Hold)") },
      text = {
        Column {
          Text("Secure ${vehicle.year} ${vehicle.make} ${vehicle.model} with a fully refundable $500 deposit.")
          Spacer(modifier = Modifier.height(8.dp))
          Text("This places a 24-hour temporary hold while dealer accepts and schedules handover.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onReserveVehicle(500.0)
            showReserveDialog = false
            Toast.makeText(context, "Deposit paid! Vehicle reserved with 24-hr hold.", Toast.LENGTH_LONG).show()
          },
          colors = ButtonDefaults.buttonColors(containerColor = AmazonYellow)
        ) {
          Text("Pay $500 Deposit")
        }
      },
      dismissButton = {
        TextButton(onClick = { showReserveDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}

@Composable
fun PricingRow(label: String, value: String, isBold: Boolean = false, color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurfaceVariant) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = label,
      fontSize = 13.sp,
      fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
      color = color
    )
    Text(
      text = value,
      fontSize = 13.sp,
      fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
      color = color
    )
  }
}
