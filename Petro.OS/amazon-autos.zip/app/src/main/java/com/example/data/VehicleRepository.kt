package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object VehicleRepository {

  private val _vehicles = MutableStateFlow(
    listOf(
      Vehicle(
        id = "veh_001",
        make = "Hyundai",
        model = "Tucson SEL",
        trim = "AWD Sport Utility",
        year = 2026,
        askingPrice = 32900.0,
        mileage = 15,
        condition = "New",
        bodyType = "SUV",
        powertrain = "Gasoline",
        distance = "12 miles away",
        dealerName = "Amazon Certified Motors - Seattle",
        location = "Seattle, WA",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=800&q=80",
          "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80"
        ),
        features = listOf("Smart Cruise Control", "Apple CarPlay / Android Auto", "Bluelink Connected Car", "Heated Front Seats", "LED Headlights"),
        specifications = mapOf(
          "Engine" to "2.5L GDI 4-Cylinder",
          "Transmission" to "8-speed Automatic w/ SHIFTRONIC",
          "Drivetrain" to "HTRAC All-Wheel Drive",
          "Fuel Economy" to "25 City / 32 Hwy MPG",
          "Exterior Color" to "Shimmering Silver",
          "Interior Color" to "Black H-Tex",
          "VIN" to "KM8R33AG3GU992811"
        ),
        category = "SUVs",
        sellerStatement = "Factory fresh 2026 Tucson SEL with HTRAC AWD and comprehensive Amazon Certified 150-point inspection.",
        verifiedInspection = true
      ),
      Vehicle(
        id = "veh_002",
        make = "Hyundai",
        model = "IONIQ 5 SE",
        trim = "Long Range RWD",
        year = 2026,
        askingPrice = 43500.0,
        mileage = 5,
        condition = "New",
        bodyType = "Electric",
        powertrain = "EV",
        distance = "8 miles away",
        dealerName = "Amazon EV Showcase - Bellevue",
        location = "Bellevue, WA",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=800&q=80",
          "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=800&q=80"
        ),
        features = listOf("Ultra-Fast 800V Charging", "Vehicle-to-Load (V2L)", "Augmented Reality HUD", "12.3-inch Touchscreen", "Eco-friendly Interior"),
        specifications = mapOf(
          "Battery" to "77.4 kWh Lithium-ion",
          "Range" to "303 miles (EPA estimated)",
          "Charging" to "10-80% in 18 mins (350kW DC)",
          "Drivetrain" to "Rear-Wheel Drive (RWD)",
          "Exterior Color" to "Digital Teal Green",
          "Interior Color" to "Gray Sustainable Cloth",
          "VIN" to "KM8K33AEXGU102938"
        ),
        isRental = true,
        rentalRatePerDay = 68.0,
        category = "Electric",
        sellerStatement = "Next-gen electric crossover with ultra-fast charging capability and expansive cabin space.",
        verifiedInspection = true
      ),
      Vehicle(
        id = "veh_003",
        make = "Hyundai",
        model = "Sonata SEL",
        trim = "Sedan",
        year = 2026,
        askingPrice = 29900.0,
        mileage = 10,
        condition = "New",
        bodyType = "Sedan",
        powertrain = "Gasoline",
        distance = "15 miles away",
        dealerName = "Amazon Certified Motors - Seattle",
        location = "Seattle, WA",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=800&q=80",
          "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80"
        ),
        features = listOf("Panoramic Curved Display", "Digital Key 2", "Highway Driving Assist", "Wireless Device Charging", "Smart Trunk"),
        specifications = mapOf(
          "Engine" to "2.5L MPI 4-Cylinder",
          "Transmission" to "8-speed Automatic",
          "Drivetrain" to "Front-Wheel Drive",
          "Fuel Economy" to "28 City / 38 Hwy MPG",
          "Exterior Color" to "Aero Silver",
          "Interior Color" to "Obsidian Black",
          "VIN" to "5NPE44AF3GH481920"
        ),
        category = "Sedans",
        sellerStatement = "Sleek coupe-inspired sedan combining athletic styling with benchmark fuel efficiency.",
        verifiedInspection = true
      ),
      Vehicle(
        id = "veh_004",
        make = "Hyundai",
        model = "Santa Fe SE",
        trim = "Bold SUV",
        year = 2026,
        askingPrice = 35900.0,
        mileage = 22,
        condition = "New",
        bodyType = "SUV",
        powertrain = "Gasoline",
        distance = "19 miles away",
        dealerName = "Amazon Certified Motors - Tacoma",
        location = "Tacoma, WA",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=800&q=80",
          "https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=800&q=80"
        ),
        features = listOf("3rd Row Seating", "Dual Wireless Charging", "Open-Concept Interior", "Remote Smart Parking Assist", "Blind-Spot View Monitor"),
        specifications = mapOf(
          "Engine" to "2.5L Turbocharged 4-Cyl",
          "Transmission" to "8-speed Wet Dual-Clutch",
          "Drivetrain" to "HTRAC All-Wheel Drive",
          "Fuel Economy" to "20 City / 29 Hwy MPG",
          "Exterior Color" to "Earthy Brass Matte",
          "Interior Color" to "Forest Green",
          "VIN" to "5NMS53AL1GH901283"
        ),
        category = "SUVs",
        sellerStatement = "Radically redesigned midsize adventure SUV built for family road trips and rugged excursions.",
        verifiedInspection = true
      ),
      Vehicle(
        id = "veh_005",
        make = "Tesla",
        model = "Model Y Long Range",
        trim = "Dual Motor AWD",
        year = 2025,
        askingPrice = 41200.0,
        mileage = 4500,
        condition = "Used - Certified",
        bodyType = "SUV",
        powertrain = "EV",
        distance = "5 miles away",
        dealerName = "Amazon Pre-Owned Hub - Seattle",
        location = "Seattle, WA",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=800&q=80"
        ),
        features = listOf("Autopilot Included", "Glass Roof", "Premium Audio", "Supercharger Access", "All-Glass Roof"),
        specifications = mapOf(
          "Range" to "310 miles",
          "0-60 mph" to "4.8 seconds",
          "Drivetrain" to "Dual Motor AWD",
          "Exterior Color" to "Pearl White Multi-Coat"
        ),
        isRental = true,
        rentalRatePerDay = 75.0,
        category = "Electric",
        sellerStatement = "Inspected and certified pre-owned Model Y with pristine battery health and fresh software update.",
        verifiedInspection = true
      ),
      Vehicle(
        id = "veh_006",
        make = "Toyota",
        model = "RAV4 Hybrid",
        trim = "XSE AWD",
        year = 2025,
        askingPrice = 34500.0,
        mileage = 8200,
        condition = "Used - Certified",
        bodyType = "SUV",
        powertrain = "Hybrid",
        distance = "14 miles away",
        dealerName = "Amazon Certified Motors - Seattle",
        location = "Seattle, WA",
        imageUrls = listOf(
          "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80"
        ),
        features = listOf("Electronic AWD", "Sport-tuned suspension", "SofTex Trim", "JBL Audio System"),
        specifications = mapOf(
          "Engine" to "2.5L 4-Cylinder Hybrid",
          "Fuel Economy" to "41 City / 38 Hwy MPG",
          "Drivetrain" to "Electronic AWD"
        ),
        isRental = true,
        rentalRatePerDay = 54.0,
        category = "Used",
        sellerStatement = "Legendary reliability combined with exceptional hybrid fuel economy.",
        verifiedInspection = true
      )
    )
  )
  val vehicles: StateFlow<List<Vehicle>> = _vehicles.asStateFlow()

  private val _savedVehicleIds = MutableStateFlow(setOf<String>())
  val savedVehicleIds: StateFlow<Set<String>> = _savedVehicleIds.asStateFlow()

  private val _comparedVehicleIds = MutableStateFlow(listOf<String>())
  val comparedVehicleIds: StateFlow<List<String>> = _comparedVehicleIds.asStateFlow()

  private val _quotes = MutableStateFlow<Map<String, VehicleQuote>>(emptyMap())
  val quotes: StateFlow<Map<String, VehicleQuote>> = _quotes.asStateFlow()

  private val _testDrives = MutableStateFlow<List<TestDriveAppointment>>(emptyList())
  val testDrives: StateFlow<List<TestDriveAppointment>> = _testDrives.asStateFlow()

  private val _reservations = MutableStateFlow<List<Reservation>>(emptyList())
  val reservations: StateFlow<List<Reservation>> = _reservations.asStateFlow()

  private val _rentalBookings = MutableStateFlow<List<RentalBooking>>(emptyList())
  val rentalBookings: StateFlow<List<RentalBooking>> = _rentalBookings.asStateFlow()

  private val _receipts = MutableStateFlow<List<Receipt>>(emptyList())
  val receipts: StateFlow<List<Receipt>> = _receipts.asStateFlow()

  fun toggleSaveVehicle(vehicleId: String) {
    val current = _savedVehicleIds.value.toMutableSet()
    if (current.contains(vehicleId)) {
      current.remove(vehicleId)
    } else {
      current.add(vehicleId)
    }
    _savedVehicleIds.value = current
  }

  fun toggleCompareVehicle(vehicleId: String): Boolean {
    val current = _comparedVehicleIds.value.toMutableList()
    if (current.contains(vehicleId)) {
      current.remove(vehicleId)
      _comparedVehicleIds.value = current
      return true
    } else {
      if (current.size >= 3) {
        return false // Max 3
      }
      current.add(vehicleId)
      _comparedVehicleIds.value = current
      return true
    }
  }

  fun generateQuote(vehicle: Vehicle): VehicleQuote {
    val dealerFee = 400.0
    val taxes = vehicle.askingPrice * 0.085 // 8.5% sales tax
    val registration = 350.0
    val delivery = 150.0
    val subtotalBeforeTax = vehicle.askingPrice + dealerFee + registration + delivery
    val totalQuoted = subtotalBeforeTax + taxes
    val deposit = 500.0
    val remainingBalance = totalQuoted - deposit

    val quote = VehicleQuote(
      vehicleId = vehicle.id,
      vehiclePrice = vehicle.askingPrice,
      dealerFee = dealerFee,
      taxes = taxes,
      registrationFee = registration,
      deliveryFee = delivery,
      subtotalBeforeTax = subtotalBeforeTax,
      remainingBalance = remainingBalance,
      totalQuoted = totalQuoted
    )
    val updated = _quotes.value.toMutableMap()
    updated[vehicle.id] = quote
    _quotes.value = updated
    return quote
  }

  fun bookTestDrive(vehicleId: String, vehicleName: String, date: String, time: String, dealerName: String): TestDriveAppointment {
    val appointment = TestDriveAppointment(
      id = "td_${System.currentTimeMillis()}",
      vehicleId = vehicleId,
      vehicleName = vehicleName,
      date = date,
      time = time,
      status = "Confirmed",
      dealerName = dealerName
    )
    _testDrives.value = _testDrives.value + appointment
    return appointment
  }

  fun reserveVehicle(vehicleId: String, vehicleName: String, depositAmount: Double, dealerName: String): Reservation {
    val reservation = Reservation(
      id = "res_${System.currentTimeMillis()}",
      vehicleId = vehicleId,
      vehicleName = vehicleName,
      depositAmount = depositAmount,
      status = "Hold Active",
      dealerName = dealerName
    )
    _reservations.value = _reservations.value + reservation

    // Also record receipt
    val receipt = Receipt(
      id = "rcpt_${System.currentTimeMillis()}",
      transactionType = "Deposit",
      referenceId = reservation.id,
      amount = depositAmount,
      paymentMethod = "Local Simulator Sandbox (Card ending in 4242)",
      status = "Verified"
    )
    _receipts.value = _receipts.value + receipt
    return reservation
  }

  fun bookRental(
    category: String,
    pickup: String,
    returnLoc: String,
    start: String,
    end: String,
    days: Int,
    dailyRate: Double
  ): RentalBooking {
    val mandatoryFees = 36.0
    val total = (days * dailyRate) + mandatoryFees
    val booking = RentalBooking(
      id = "rent_${System.currentTimeMillis()}",
      vehicleCategory = category,
      pickupLocation = pickup,
      returnLocation = returnLoc,
      startDate = start,
      endDate = end,
      driverAgeBand = "25+",
      transmission = "Automatic",
      mileageAllowance = "Unlimited",
      fuelPolicy = "Full to Full",
      billableDays = days,
      dailyRate = dailyRate,
      mandatoryFees = mandatoryFees,
      estimatedTotal = total,
      status = "Confirmed"
    )
    _rentalBookings.value = _rentalBookings.value + booking

    val receipt = Receipt(
      id = "rcpt_rent_${System.currentTimeMillis()}",
      transactionType = "Rental Pre-authorization",
      referenceId = booking.id,
      amount = total,
      paymentMethod = "Local Simulator Sandbox (Card ending in 4242)",
      status = "Verified"
    )
    _receipts.value = _receipts.value + receipt
    return booking
  }
}
