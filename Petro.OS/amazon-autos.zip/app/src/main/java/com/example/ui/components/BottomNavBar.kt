package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.theme.AmazonYellow

sealed class BottomNavScreen(val route: String, val title: String, val icon: ImageVector) {
  object Home : BottomNavScreen("home", "Home", Icons.Default.Home)
  object Search : BottomNavScreen("search", "Search", Icons.Default.Search)
  object Saved : BottomNavScreen("saved", "Saved", Icons.Default.Favorite)
  object Bookings : BottomNavScreen("bookings", "Bookings", Icons.Default.EventNote)
  object Account : BottomNavScreen("account", "Account", Icons.Default.Person)
}

@Composable
fun BottomNavBar(
  currentScreen: String,
  onScreenSelected: (String) -> Unit
) {
  val items = listOf(
    BottomNavScreen.Home,
    BottomNavScreen.Search,
    BottomNavScreen.Saved,
    BottomNavScreen.Bookings,
    BottomNavScreen.Account
  )

  NavigationBar(
    containerColor = MaterialTheme.colorScheme.surfaceVariant,
    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
  ) {
    items.forEach { screen ->
      val selected = currentScreen == screen.route
      NavigationBarItem(
        icon = { Icon(screen.icon, contentDescription = screen.title) },
        label = { Text(screen.title) },
        selected = selected,
        onClick = { onScreenSelected(screen.route) },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = AmazonYellow,
          selectedTextColor = AmazonYellow,
          unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
          unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
          indicatorColor = MaterialTheme.colorScheme.surface
        )
      )
    }
  }
}
