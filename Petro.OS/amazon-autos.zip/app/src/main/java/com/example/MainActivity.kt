package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.BottomNavBar
import com.example.ui.components.TopHeader
import com.example.ui.screens.*
import com.example.ui.theme.AmazonAutosTheme
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      AmazonAutosTheme {
        val viewModel: MainViewModel = viewModel()
        val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
        val vehicles by viewModel.vehicles.collectAsStateWithLifecycle()
        val savedIds by viewModel.savedVehicleIds.collectAsStateWithLifecycle()
        val comparedIds by viewModel.comparedVehicleIds.collectAsStateWithLifecycle()
        val selectedVehicleId by viewModel.selectedVehicleId.collectAsStateWithLifecycle()
        val isBuyMode by viewModel.isBuyMode.collectAsStateWithLifecycle()
        val location by viewModel.location.collectAsStateWithLifecycle()
        val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
        val isOffline by viewModel.isOfflineMode.collectAsStateWithLifecycle()

        val quotes by viewModel.quotes.collectAsStateWithLifecycle()
        val testDrives by viewModel.testDrives.collectAsStateWithLifecycle()
        val reservations by viewModel.reservations.collectAsStateWithLifecycle()
        val rentalBookings by viewModel.rentalBookings.collectAsStateWithLifecycle()
        val receipts by viewModel.receipts.collectAsStateWithLifecycle()

        // Handle hardware back button for sub-screens
        if (currentScreen != "home" && currentScreen != "search" && currentScreen != "saved" && currentScreen != "bookings" && currentScreen != "account") {
          BackHandler {
            viewModel.navigateTo("home")
          }
        }

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          topBar = {
            if (currentScreen != "admin") {
              TopHeader(
                location = location,
                onLocationClick = { viewModel.navigateTo("account") },
                isOffline = isOffline,
                onAdminClick = { viewModel.navigateTo("admin") }
              )
            }
          },
          bottomBar = {
            if (currentScreen != "detail" && currentScreen != "compare" && currentScreen != "admin") {
              BottomNavBar(
                currentScreen = currentScreen,
                onScreenSelected = { route -> viewModel.navigateTo(route) }
              )
            }
          }
        ) { innerPadding ->
          Box(modifier = Modifier.padding(innerPadding)) {
            when (currentScreen) {
              "home" -> HomeScreen(
                vehicles = vehicles,
                isBuyMode = isBuyMode,
                savedVehicleIds = savedIds,
                comparedVehicleIds = comparedIds,
                selectedCategory = selectedCategory,
                onModeChanged = { viewModel.setBuyMode(it) },
                onCategorySelected = { viewModel.setSelectedCategory(it) },
                onVehicleClick = { viewModel.selectVehicle(it) },
                onSaveClick = { viewModel.toggleSave(it) },
                onCompareToggle = { viewModel.toggleCompare(it) },
                onSearchClick = { viewModel.navigateTo("search") },
                onRentalTabClick = { viewModel.navigateTo("rental") }
              )
              "search" -> SearchScreen(
                vehicles = vehicles,
                savedVehicleIds = savedIds,
                comparedVehicleIds = comparedIds,
                onVehicleClick = { viewModel.selectVehicle(it) },
                onSaveClick = { viewModel.toggleSave(it) },
                onCompareToggle = { viewModel.toggleCompare(it) },
                onCompareClick = { viewModel.navigateTo("compare") }
              )
              "saved" -> SavedScreen(
                vehicles = vehicles,
                savedVehicleIds = savedIds,
                comparedVehicleIds = comparedIds,
                onVehicleClick = { viewModel.selectVehicle(it) },
                onSaveClick = { viewModel.toggleSave(it) },
                onCompareToggle = { viewModel.toggleCompare(it) }
              )
              "bookings" -> BookingsScreen(
                testDrives = testDrives,
                reservations = reservations,
                rentalBookings = rentalBookings,
                receipts = receipts
              )
              "account" -> AccountScreen(
                location = location,
                isOfflineMode = isOffline,
                onLocationChange = { viewModel.setLocation(it) },
                onToggleOffline = { viewModel.toggleOfflineMode() },
                onOpenAdmin = { viewModel.navigateTo("admin") }
              )
              "detail" -> {
                val vehicle = vehicles.find { it.id == selectedVehicleId } ?: vehicles.first()
                VehicleDetailScreen(
                  vehicle = vehicle,
                  isSaved = savedIds.contains(vehicle.id),
                  quote = quotes[vehicle.id],
                  onBackClick = { viewModel.navigateTo("home") },
                  onSaveClick = { viewModel.toggleSave(vehicle.id) },
                  onGenerateQuote = { viewModel.generateQuote(vehicle) },
                  onBookTestDrive = { date, time -> viewModel.bookTestDrive(vehicle.id, "${vehicle.year} ${vehicle.make} ${vehicle.model}", date, time, vehicle.dealerName) },
                  onReserveVehicle = { deposit -> viewModel.reserveVehicle(vehicle.id, "${vehicle.year} ${vehicle.make} ${vehicle.model}", deposit, vehicle.dealerName) }
                )
              }
              "compare" -> {
                val comparedVehicles = vehicles.filter { comparedIds.contains(it.id) }
                CompareScreen(
                  comparedVehicles = comparedVehicles,
                  onBackClick = { viewModel.navigateTo("search") },
                  onRemoveCompare = { viewModel.toggleCompare(it) }
                )
              }
              "rental" -> RentalScreen(
                onBookRental = { cat, pickup, ret, start, end, days, rate ->
                  viewModel.bookRental(cat, pickup, ret, start, end, days, rate)
                }
              )
              "admin" -> AdminScreen(
                onBackClick = { viewModel.navigateTo("home") }
              )
            }
          }
        }
      }
    }
  }
}
