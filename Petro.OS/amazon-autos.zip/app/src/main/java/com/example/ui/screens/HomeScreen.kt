package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Vehicle
import com.example.ui.components.VehicleCard
import com.example.ui.theme.AmazonYellow
import com.example.ui.theme.TextLight

@Composable
fun HomeScreen(
  vehicles: List<Vehicle>,
  isBuyMode: Boolean,
  savedVehicleIds: Set<String>,
  comparedVehicleIds: List<String>,
  selectedCategory: String,
  onModeChanged: (Boolean) -> Unit,
  onCategorySelected: (String) -> Unit,
  onVehicleClick: (String) -> Unit,
  onSaveClick: (String) -> Unit,
  onCompareToggle: (String) -> Unit,
  onSearchClick: () -> Unit,
  onRentalTabClick: () -> Unit
) {
  val categories = listOf("All", "SUVs", "Electric", "Sedans", "Used")

  val filteredVehicles = remember(vehicles, isBuyMode, selectedCategory) {
    vehicles.filter { v ->
      val modeMatch = if (isBuyMode) !v.isRental || v.askingPrice > 0 else v.isRental
      val categoryMatch = selectedCategory == "All" || v.category.equals(selectedCategory, ignoreCase = true)
      modeMatch && categoryMatch
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingValues(bottom = 80.dp)
  ) {
    // Buy / Rent segmented switch banner
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
              .padding(4.dp)
          ) {
            Button(
              onClick = { onModeChanged(true) },
              modifier = Modifier.weight(1f),
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isBuyMode) AmazonYellow else MaterialTheme.colorScheme.surface,
                contentColor = if (isBuyMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
              ),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(Icons.Default.DirectionsCar, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Buy a Car", fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = {
                onModeChanged(false)
                onRentalTabClick()
              },
              modifier = Modifier.weight(1f),
              colors = ButtonDefaults.buttonColors(
                containerColor = if (!isBuyMode) AmazonYellow else MaterialTheme.colorScheme.surface,
                contentColor = if (!isBuyMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
              ),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Rent a Car", fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          Text(
            text = if (isBuyMode) "Your next car. All in one place." else "Flexible car rentals with transparent pricing.",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = TextLight
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (isBuyMode) "Discover certified vehicles with verified inspection & itemized quotes." else "Daily & weekly rentals starting from $54/day with insurance included.",
            fontSize = 13.sp,
            color = TextLight.copy(alpha = 0.8f)
          )

          Spacer(modifier = Modifier.height(16.dp))

          OutlinedButton(
            onClick = onSearchClick,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextLight),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = AmazonYellow)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Search cars by make, model or keyword...")
          }
        }
      }
    }

    // Category chips
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        Text(
          text = "Browse Categories",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          categories.forEach { cat ->
            FilterChip(
              selected = selectedCategory == cat,
              onClick = { onCategorySelected(cat) },
              label = { Text(cat) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = AmazonYellow,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
              )
            )
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isBuyMode) "Featured Amazon Autos Listings" else "Featured Rental Fleet",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onBackground
        )
        TextButton(onClick = onSearchClick) {
          Text("View All", color = AmazonYellow)
        }
      }
    }

    items(filteredVehicles) { vehicle ->
      Box(modifier = Modifier.padding(horizontal = 16.dp)) {
        VehicleCard(
          vehicle = vehicle,
          isSaved = savedVehicleIds.contains(vehicle.id),
          isCompared = comparedVehicleIds.contains(vehicle.id),
          onCardClick = { onVehicleClick(vehicle.id) },
          onSaveClick = { onSaveClick(vehicle.id) },
          onCompareToggle = { onCompareToggle(vehicle.id) }
        )
      }
    }
  }
}
