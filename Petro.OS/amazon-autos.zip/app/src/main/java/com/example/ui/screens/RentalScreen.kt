package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmazonYellow
import com.example.ui.theme.SuccessGreen

@Composable
fun RentalScreen(
  onBookRental: (category: String, pickup: String, returnLoc: String, start: String, end: String, days: Int, rate: Double) -> Unit
) {
  val context = LocalContext.current
  var selectedCategory by remember { mutableStateOf("Midsize SUV (or similar)") }
  var pickupLocation by remember { mutableStateOf("Seattle-Tacoma International Airport (SEA)") }
  var returnLocation by remember { mutableStateOf("Seattle-Tacoma International Airport (SEA)") }
  var startDate by remember { mutableStateOf("Nov 28, 2026 - 10:00 AM") }
  var endDate by remember { mutableStateOf("Dec 1, 2026 - 10:00 AM") }

  val days = 3
  val dailyRate = 54.0
  val mandatoryFees = 36.0
  val estimatedTotal = (days * dailyRate) + mandatoryFees

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background),
    contentPadding = PaddingValues(16.dp)
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Key, contentDescription = null, tint = AmazonYellow)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Amazon Autos Car Rentals", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text("Book your trip with flexible dates and guaranteed vehicles or similar.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Rental Configuration", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = selectedCategory,
            onValueChange = { selectedCategory = it },
            label = { Text("Vehicle Category (or similar)") },
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = pickupLocation,
            onValueChange = { pickupLocation = it },
            label = { Text("Pickup Location") },
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = returnLocation,
            onValueChange = { returnLocation = it },
            label = { Text("Return Location") },
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = startDate,
              onValueChange = { startDate = it },
              label = { Text("Pickup Date") },
              modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
              value = endDate,
              onValueChange = { endDate = it },
              label = { Text("Return Date") },
              modifier = Modifier.weight(1f)
            )
          }

          Spacer(modifier = Modifier.height(12.dp))
          Text("Driver Age: 25+ · Transmission: Automatic · Fuel Policy: Full to Full", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Itemized Rental Pricing", fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Spacer(modifier = Modifier.height(8.dp))

          RentalPriceRow("$3 billable days × $54", "$162.00")
          RentalPriceRow("Mandatory Taxes & Fees", "$36.00")
          Divider(modifier = Modifier.padding(vertical = 8.dp))
          RentalPriceRow("Estimated Total", "$${String.format("%,.2f", estimatedTotal)}", isBold = true, color = AmazonYellow)
          Text("Applicable taxes & collision damage waiver included in estimate.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))

          Spacer(modifier = Modifier.height(16.dp))

          Button(
            onClick = {
              onBookRental(selectedCategory, pickupLocation, returnLocation, startDate, endDate, days, dailyRate)
              Toast.makeText(context, "Rental booked successfully! Confirmation sent to Bookings.", Toast.LENGTH_LONG).show()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = AmazonYellow, contentColor = MaterialTheme.colorScheme.onPrimary)
          ) {
            Text("Book Rental Now ($198.00)", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun RentalPriceRow(label: String, value: String, isBold: Boolean = false, color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(label, fontSize = 13.sp, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal, color = color)
    Text(value, fontSize = 13.sp, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal, color = color)
  }
}
