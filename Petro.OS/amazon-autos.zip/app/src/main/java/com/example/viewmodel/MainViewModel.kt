package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.VehicleRepository
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MainViewModel : ViewModel() {

  val vehicles = VehicleRepository.vehicles
  val savedVehicleIds = VehicleRepository.savedVehicleIds
  val comparedVehicleIds = VehicleRepository.comparedVehicleIds
  val quotes = VehicleRepository.quotes
  val testDrives = VehicleRepository.testDrives
  val reservations = VehicleRepository.reservations
  val rentalBookings = VehicleRepository.rentalBookings
  val receipts = VehicleRepository.receipts

  private val _currentScreen = MutableStateFlow("home") // home, search, saved, bookings, account, detail, compare, rental, admin
  val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

  private val _selectedVehicleId = MutableStateFlow<String?>(null)
  val selectedVehicleId: StateFlow<String?> = _selectedVehicleId.asStateFlow()

  private val _isBuyMode = MutableStateFlow(true) // true = Buy, false = Rent
  val isBuyMode: StateFlow<Boolean> = _isBuyMode.asStateFlow()

  private val _location = MutableStateFlow("Seattle, WA")
  val location: StateFlow<String> = _location.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _selectedCategory = MutableStateFlow("All")
  val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

  private val _isOfflineMode = MutableStateFlow(false)
  val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

  fun navigateTo(screen: String) {
    _currentScreen.value = screen
  }

  fun selectVehicle(vehicleId: String) {
    _selectedVehicleId.value = vehicleId
    _currentScreen.value = "detail"
  }

  fun setBuyMode(buy: Boolean) {
    _isBuyMode.value = buy
  }

  fun setLocation(loc: String) {
    _location.value = loc
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setSelectedCategory(category: String) {
    _selectedCategory.value = category
  }

  fun toggleOfflineMode() {
    _isOfflineMode.value = !_isOfflineMode.value
  }

  fun toggleSave(vehicleId: String) {
    VehicleRepository.toggleSaveVehicle(vehicleId)
  }

  fun toggleCompare(vehicleId: String): Boolean {
    return VehicleRepository.toggleCompareVehicle(vehicleId)
  }

  fun generateQuote(vehicle: Vehicle): VehicleQuote {
    return VehicleRepository.generateQuote(vehicle)
  }

  fun bookTestDrive(vehicleId: String, vehicleName: String, date: String, time: String, dealerName: String) {
    VehicleRepository.bookTestDrive(vehicleId, vehicleName, date, time, dealerName)
  }

  fun reserveVehicle(vehicleId: String, vehicleName: String, depositAmount: Double, dealerName: String): Reservation {
    return VehicleRepository.reserveVehicle(vehicleId, vehicleName, depositAmount, dealerName)
  }

  fun bookRental(
    category: String,
    pickup: String,
    returnLoc: String,
    start: String,
    end: String,
    days: Int,
    dailyRate: Double
  ) {
    VehicleRepository.bookRental(category, pickup, returnLoc, start, end, days, dailyRate)
  }
}
