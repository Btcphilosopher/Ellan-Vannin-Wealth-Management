package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.model.RentalBooking
import com.example.model.Reservation
import com.example.model.TestDriveAppointment
import com.example.model.Receipt
import com.example.ui.theme.AmazonYellow
import com.example.ui.theme.SuccessGreen

@Composable
fun BookingsScreen(
  testDrives: List<TestDriveAppointment>,
  reservations: List<Reservation>,
  rentalBookings: List<RentalBooking>,
  receipts: List<Receipt>
) {
  var selectedTab by remember { mutableStateOf(0) }
  val tabs = listOf("Test Drives", "Reservations", "Rentals", "Receipts")

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Surface(
      modifier = Modifier.fillMaxWidth(),
      color = MaterialTheme.colorScheme.surface
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text("My Bookings & Orders", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Manage test drives, vehicle holds, rental bookings, and receipts", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
      }
    }

    TabRow(selectedTabIndex = selectedTab) {
      tabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedTab == index,
          onClick = { selectedTab = index },
          text = { Text(title, fontSize = 12.sp) }
        )
      }
    }

    when (selectedTab) {
      0 -> TestDrivesTab(testDrives)
      1 -> ReservationsTab(reservations)
      2 -> RentalsTab(rentalBookings)
      3 -> ReceiptsTab(receipts)
    }
  }
}

@Composable
fun TestDrivesTab(list: List<TestDriveAppointment>) {
  if (list.isEmpty()) {
    EmptyBookingsState("No test drive appointments scheduled.")
  } else {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
      items(list) { item ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(item.vehicleName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Surface(color = AmazonYellow, shape = RoundedCornerShape(4.dp)) {
                Text(item.status, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
              }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("Dealer: ${item.dealerName}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            Text("Appointment: ${item.date} at ${item.time}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
          }
        }
      }
    }
  }
}

@Composable
fun ReservationsTab(list: List<Reservation>) {
  if (list.isEmpty()) {
    EmptyBookingsState("No vehicle purchase reservations or holds.")
  } else {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
      items(list) { item ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(item.vehicleName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Surface(color = SuccessGreen, shape = RoundedCornerShape(4.dp)) {
                Text(item.status, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
              }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("Dealer: ${item.dealerName}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            Text("Deposit Paid: $${String.format("%,.2f", item.depositAmount)}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AmazonYellow)
          }
        }
      }
    }
  }
}

@Composable
fun RentalsTab(list: List<RentalBooking>) {
  if (list.isEmpty()) {
    EmptyBookingsState("No active rental bookings.")
  } else {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
      items(list) { item ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(item.vehicleCategory, fontWeight = FontWeight.Bold, fontSize = 16.sp)
              Surface(color = AmazonYellow, shape = RoundedCornerShape(4.dp)) {
                Text(item.status, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
              }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("Pickup: ${item.pickupLocation} (${item.startDate})", fontSize = 13.sp)
            Text("Return: ${item.returnLocation} (${item.endDate})", fontSize = 13.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Total: $${String.format("%,.2f", item.estimatedTotal)} (${item.billableDays} days + fees, taxes included)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AmazonYellow)
          }
        }
      }
    }
  }
}

@Composable
fun ReceiptsTab(list: List<Receipt>) {
  if (list.isEmpty()) {
    EmptyBookingsState("No receipts recorded.")
  } else {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
      items(list) { item ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(item.transactionType, fontWeight = FontWeight.Bold, fontSize = 15.sp)
              Text("$${String.format("%,.2f", item.amount)}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = AmazonYellow)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("Method: ${item.paymentMethod}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
            Text("Status: ${item.status}", fontSize = 12.sp, color = SuccessGreen, fontWeight = FontWeight.SemiBold)
          }
        }
      }
    }
  }
}

@Composable
fun EmptyBookingsState(message: String) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(message, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
  }
}
