package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.models.*

@Database(
    entities = [
        VehicleEntity::class,
        PartEntity::class,
        FitmentEntity::class,
        StoreEntity::class,
        InventoryEntity::class,
        OrderEntity::class,
        ServiceRecordEntity::class,
        MaintenanceEntity::class,
        ToolEntity::class,
        ToolLoanEntity::class,
        ShoppingListEntity::class,
        ShoppingListItemEntity::class,
        RewardAccountEntity::class,
        WarrantyEntity::class,
        RepairGuideEntity::class,
        CommercialAccountEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AutoZoneDatabase : RoomDatabase() {
    abstract fun autoZoneDao(): AutoZoneDao

    companion object {
        @Volatile
        private var INSTANCE: AutoZoneDatabase? = null

        fun getDatabase(context: Context): AutoZoneDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AutoZoneDatabase::class.java,
                    "autozone_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
