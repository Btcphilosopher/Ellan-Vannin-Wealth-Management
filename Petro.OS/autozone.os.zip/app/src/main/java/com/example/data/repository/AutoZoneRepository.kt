package com.example.data.repository

import android.content.Context
import com.example.data.db.AutoZoneDao
import com.example.data.db.AutoZoneDatabase
import com.example.data.models.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class FitmentStatus {
    EXACT_FIT,
    MAY_NOT_FIT,
    UNIVERSAL_FIT,
    UNKNOWN
}

data class FitmentResult(
    val status: FitmentStatus,
    val note: String,
    val position: String = "Front & Rear"
)

enum class SimulationScenario(val displayName: String, val description: String) {
    NORMAL("Normal Operations", "Standard retail traffic and stock levels"),
    RUSH_HOUR("Rush Hour Peak", "High in-store customer pickup volume and counter traffic"),
    HIGH_DEMAND("Extreme Weather Surge", "Surge in Duralast Battery & Alternator sales"),
    LOW_STOCK("Supply Chain Alert", "Critical stock warning on Duralast Gold Pads & Rotors"),
    DELIVERY_DELAY("Logistics Delay", "Regional delivery hub experiencing 45-min transit delay"),
    STORE_PICKUP_SURGE("Store Pickup Surge", "18+ orders waiting at Store #4821 counter")
}

class AutoZoneRepository private constructor(private val dao: AutoZoneDao) {

    // InMemory Cart State
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    // Simulation Scenario
    private val _currentScenario = MutableStateFlow(SimulationScenario.NORMAL)
    val currentScenario: StateFlow<SimulationScenario> = _currentScenario.asStateFlow()

    // Active Store Selected in App
    private val _selectedStore = MutableStateFlow<StoreEntity?>(null)
    val selectedStore: StateFlow<StoreEntity?> = _selectedStore.asStateFlow()

    val selectedVehicle: Flow<VehicleEntity?> = dao.getSelectedVehicleFlow()
    val allVehicles: Flow<List<VehicleEntity>> = dao.getAllVehicles()
    val allParts: Flow<List<PartEntity>> = dao.getAllParts()
    val allStores: Flow<List<StoreEntity>> = dao.getAllStores()
    val allOrders: Flow<List<OrderEntity>> = dao.getAllOrders()
    val rewardAccount: Flow<RewardAccountEntity?> = dao.getRewardAccountFlow()
    val allWarranties: Flow<List<WarrantyEntity>> = dao.getAllWarranties()
    val allRepairGuides: Flow<List<RepairGuideEntity>> = dao.getAllRepairGuides()
    val allCommercialAccounts: Flow<List<CommercialAccountEntity>> = dao.getAllCommercialAccounts()
    val allAuditLogs: Flow<List<AuditLogEntity>> = dao.getAllAuditLogs()
    val allTools: Flow<List<ToolEntity>> = dao.getAllTools()
    val allInventory: Flow<List<InventoryEntity>> = dao.getAllInventory()
    val allFitments: Flow<List<FitmentEntity>> = dao.getAllFitments()

    fun getServiceRecordsForVehicle(vehicleId: String): Flow<List<ServiceRecordEntity>> = dao.getServiceRecordsForVehicle(vehicleId)
    fun getMaintenanceForVehicle(vehicleId: String): Flow<List<MaintenanceEntity>> = dao.getMaintenanceForVehicle(vehicleId)
    suspend fun getPartByBarcode(barcode: String): PartEntity? = dao.getPartByBarcode(barcode)

    init {
        CoroutineScope(Dispatchers.IO).launch {
            seedDatabaseIfEmpty()
            // Set initial selected store
            val stores = dao.getAllStores().firstOrNull()
            if (!stores.isNullOrEmpty()) {
                _selectedStore.value = stores.first()
            }
        }
    }

    suspend fun setScenario(scenario: SimulationScenario) {
        _currentScenario.value = scenario
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        dao.insertAuditLog(
            AuditLogEntity(
                timestamp = timestamp,
                userRole = "OPERATIONS_HQ",
                action = "SCENARIO_CHANGE",
                objectName = "SimulationEngine",
                previousValue = currentScenario.value.displayName,
                newValue = scenario.displayName
            )
        )
    }

    fun searchParts(query: String): Flow<List<PartEntity>> = dao.searchParts(query)

    fun getPartsByCategory(category: String): Flow<List<PartEntity>> = dao.getPartsByCategory(category)

    suspend fun checkFitment(vehicle: VehicleEntity?, part: PartEntity): FitmentResult {
        if (vehicle == null) {
            return FitmentResult(FitmentStatus.UNKNOWN, "Select a vehicle to verify fitment")
        }

        val fitments = dao.getFitmentsForPart(part.partNumber)
        if (fitments.isEmpty()) {
            return FitmentResult(FitmentStatus.UNIVERSAL_FIT, "Universal fit product")
        }

        val matching = fitments.find { fit ->
            vehicle.year in fit.yearStart..fit.yearEnd &&
                    fit.make.equals(vehicle.make, ignoreCase = true) &&
                    fit.model.equals(vehicle.model, ignoreCase = true) &&
                    (fit.engine.contains("ALL", ignoreCase = true) || vehicle.engine.contains(fit.engine, ignoreCase = true) || fit.engine.contains(vehicle.engine, ignoreCase = true))
        }

        return if (matching != null) {
            FitmentResult(
                status = FitmentStatus.EXACT_FIT,
                note = "Guaranteed exact fit for ${vehicle.year} ${vehicle.make} ${vehicle.model} (${matching.fitmentRules})",
                position = matching.position
            )
        } else {
            FitmentResult(
                status = FitmentStatus.MAY_NOT_FIT,
                note = "Does not fit ${vehicle.year} ${vehicle.make} ${vehicle.model} (${vehicle.engine})"
            )
        }
    }

    // Cart Management
    fun addToCart(part: PartEntity, quantity: Int = 1, fulfillmentType: String = "PICKUP") {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.part.partNumber == part.partNumber }
        if (index >= 0) {
            current[index].quantity += quantity
        } else {
            current.add(CartItem(part, quantity, fulfillmentType))
        }
        _cartItems.value = current
    }

    fun updateCartItemQuantity(partNumber: String, qty: Int) {
        val current = _cartItems.value.toMutableList()
        if (qty <= 0) {
            current.removeAll { it.part.partNumber == partNumber }
        } else {
            val index = current.indexOfFirst { it.part.partNumber == partNumber }
            if (index >= 0) {
                current[index].quantity = qty
            }
        }
        _cartItems.value = current
    }

    fun clearCart() {
        _cartItems.value = emptyList()
    }

    // Order Placement & HQ Vertical Slice Integration
    suspend fun placeOrder(
        customerName: String,
        storeId: String,
        fulfillmentType: String,
        vehicleInfo: String
    ): OrderEntity {
        val cart = _cartItems.value
        val total = cart.sumOf { it.part.price * it.quantity }
        val orderNum = "#${(48000..49999).random()}"
        val summary = cart.joinToString(", ") { "${it.part.name} x${it.quantity}" }

        val order = OrderEntity(
            orderNumber = orderNum,
            customerName = customerName,
            storeId = storeId,
            fulfillmentType = fulfillmentType,
            status = "PICKING", // Starts in picking, HQ turns it to READY!
            totalAmount = total,
            timestamp = System.currentTimeMillis(),
            itemsSummary = summary,
            vehicleInfo = vehicleInfo,
            arrivalNotified = false
        )

        dao.insertOrder(order)
        clearCart()

        // Audit Log
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        dao.insertAuditLog(
            AuditLogEntity(
                timestamp = timestamp,
                userRole = "CUSTOMER_APP",
                action = "PLACE_ORDER",
                objectName = "Order $orderNum",
                previousValue = "NONE",
                newValue = "PICKING ($fulfillmentType)"
            )
        )

        // Increment rewards purchase count
        val reward = dao.getRewardAccountFlow().firstOrNull()
        if (reward != null) {
            val nextCount = reward.qualifyingPurchasesCount + 1
            val (finalCount, newRewards) = if (nextCount >= 5) {
                0 to (reward.rewardsAvailable + 1)
            } else {
                nextCount to reward.rewardsAvailable
            }
            dao.insertRewardAccount(
                reward.copy(
                    qualifyingPurchasesCount = finalCount,
                    rewardsAvailable = newRewards,
                    totalSpent = reward.totalSpent + total
                )
            )
        }

        return order
    }

    suspend fun updateOrderStatus(orderNumber: String, newStatus: String) {
        val existing = dao.getOrderByNumber(orderNumber)
        val oldStatus = existing?.status ?: "UNKNOWN"
        dao.updateOrderStatus(orderNumber, newStatus)

        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        dao.insertAuditLog(
            AuditLogEntity(
                timestamp = timestamp,
                userRole = "HQ_OPERATIONS",
                action = "ORDER_STATUS_CHANGE",
                objectName = "Order $orderNumber",
                previousValue = oldStatus,
                newValue = newStatus
            )
        )
    }

    suspend fun notifyStoreArrival(orderNumber: String) {
        dao.updateOrderArrival(orderNumber, true)
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        dao.insertAuditLog(
            AuditLogEntity(
                timestamp = timestamp,
                userRole = "CUSTOMER_APP",
                action = "DRIVE_UP_ARRIVAL",
                objectName = "Order $orderNumber",
                previousValue = "ARRIVING",
                newValue = "CUSTOMER_AT_STORE_COUNTER"
            )
        )
    }

    suspend fun updatePartPrice(partNumber: String, newPrice: Double) {
        val part = dao.getPartByNumber(partNumber)
        if (part != null) {
            val oldPrice = part.price
            dao.updatePart(part.copy(price = newPrice))
            val timestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            dao.insertAuditLog(
                AuditLogEntity(
                    timestamp = timestamp,
                    userRole = "MERCHANDISING_HQ",
                    action = "PRICE_UPDATE",
                    objectName = "Part $partNumber (${part.name})",
                    previousValue = "\$$oldPrice",
                    newValue = "\$$newPrice"
                )
            )
        }
    }

    suspend fun setSelectedVehicle(id: String) {
        dao.clearSelectedVehicles()
        dao.setSelectedVehicle(id)
    }

    suspend fun addVehicle(
        year: Int,
        make: String,
        model: String,
        engine: String,
        trim: String,
        vin: String
    ): VehicleEntity {
        val id = "veh_${System.currentTimeMillis()}"
        val vehicle = VehicleEntity(
            id = id,
            year = year,
            make = make,
            model = model,
            engine = engine,
            trim = trim,
            vin = vin,
            isSelected = true
        )
        dao.clearSelectedVehicles()
        dao.insertVehicle(vehicle)
        return vehicle
    }

    fun setSelectedStore(store: StoreEntity) {
        _selectedStore.value = store
    }

    // Initial Data Seeding
    private suspend fun seedDatabaseIfEmpty() {
        val existingParts = dao.getAllParts().firstOrNull()
        if (!existingParts.isNullOrEmpty()) return

        // 1. VEHICLES
        val vehicles = listOf(
            VehicleEntity(
                id = "v1",
                year = 2021,
                make = "Ford",
                model = "F-150",
                engine = "3.5L V6 EcoBoost",
                trim = "XLT SuperCrew",
                vin = "1FTFW1E84MF102839",
                isSelected = true,
                nickname = "My F-150 Truck"
            ),
            VehicleEntity(
                id = "v2",
                year = 2018,
                make = "Honda",
                model = "Civic",
                engine = "2.0L 4-Cyl i-VTEC",
                trim = "EX Sedan",
                vin = "1HGFC2F59JH201948",
                isSelected = false,
                nickname = "Daily Commuter"
            ),
            VehicleEntity(
                id = "v3",
                year = 2020,
                make = "Chevrolet",
                model = "Silverado 1500",
                engine = "5.3L V8 EcoTec3",
                trim = "LT Z71",
                vin = "1GCPC9E38L108472",
                isSelected = false,
                nickname = "Work Truck"
            )
        )

        vehicles.forEach { dao.insertVehicle(it) }

        // 2. PARTS
        val parts = listOf(
            PartEntity(
                partNumber = "DLG-4921",
                brand = "Duralast Gold",
                name = "Duralast Gold Ceramic Brake Pads",
                category = "BRAKES",
                price = 74.99,
                cost = 32.50,
                warranty = "Limited Lifetime Warranty",
                description = "Ultra-quiet ceramic formulation with superior stopping power and low dust technology.",
                barcode = "76829102401",
                stockHQ = 8241,
                position = "Front"
            ),
            PartEntity(
                partNumber = "DLG-4922",
                brand = "Duralast Gold",
                name = "Duralast Gold Ceramic Rear Brake Pads",
                category = "BRAKES",
                price = 68.99,
                cost = 28.00,
                warranty = "Limited Lifetime Warranty",
                description = "Engineered for maximum thermal dissipation and quiet rear braking.",
                barcode = "76829102402",
                stockHQ = 5120,
                position = "Rear"
            ),
            PartEntity(
                partNumber = "BT-8421",
                brand = "Duralast Gold",
                name = "Duralast Gold Battery H6-DLG",
                category = "BATTERIES",
                price = 189.99,
                cost = 95.00,
                warranty = "3-Year Free Replacement",
                description = "730 Cold Cranking Amps (CCA), high vibration resistance for reliable heavy-duty start.",
                barcode = "76829108421",
                stockHQ = 2841,
                position = "Universal"
            ),
            PartEntity(
                partNumber = "STP-S10590",
                brand = "STP",
                name = "STP Extended Life Oil Filter",
                category = "FILTERS",
                price = 12.99,
                cost = 4.20,
                warranty = "1-Year Warranty",
                description = "Advanced synthetic fibers hold 99% of engine contaminants up to 10,000 miles.",
                barcode = "76829101059",
                stockHQ = 14200,
                position = "Universal"
            ),
            PartEntity(
                partNumber = "MOB-5W30-5QT",
                brand = "Mobil 1",
                name = "Mobil 1 Advanced Full Synthetic Oil 5W-30 (5 Qt)",
                category = "OIL & FLUIDS",
                price = 37.99,
                cost = 21.00,
                warranty = "Guaranteed 10,000 Mile Protection",
                description = "Outstanding wear protection and thermal stability under extreme temperatures.",
                barcode = "76829105305",
                stockHQ = 19200,
                position = "Universal"
            ),
            PartEntity(
                partNumber = "NGK-9620",
                brand = "NGK",
                name = "NGK Laser Iridium Spark Plug",
                category = "IGNITION",
                price = 14.49,
                cost = 6.10,
                warranty = "60,000 Mile Service Interval",
                description = "Laser-welded iridium center electrode tip ensures high durability and stable spark.",
                barcode = "76829109620",
                stockHQ = 32000,
                position = "Universal"
            ),
            PartEntity(
                partNumber = "BOS-BE22",
                brand = "Bosch",
                name = "Bosch ICON 22 Inch Beam Wiper Blade",
                category = "WIPERS",
                price = 27.99,
                cost = 11.50,
                warranty = "1-Year Satisfaction Guarantee",
                description = "Exclusive fx dual rubber resists heat and ozone deterioration up to 40% longer.",
                barcode = "76829102201",
                stockHQ = 9800,
                position = "Front Left"
            ),
            PartEntity(
                partNumber = "DUR-RAD4082",
                brand = "Duralast",
                name = "Duralast Radiator Assembly",
                category = "COOLING",
                price = 214.99,
                cost = 110.00,
                warranty = "Limited Lifetime Warranty",
                description = "High-density folded aluminum fins maximize heat dissipation for heavy engine loads.",
                barcode = "76829104082",
                stockHQ = 1200,
                position = "Front"
            )
        )

        dao.insertParts(parts)

        // 3. FITMENTS
        val fitments = listOf(
            FitmentEntity(
                partNumber = "DLG-4921",
                yearStart = 2015,
                yearEnd = 2024,
                make = "Ford",
                model = "F-150",
                engine = "3.5L V6 EcoBoost",
                position = "Front",
                fitmentRules = "Front Axle - Dual Piston Caliper"
            ),
            FitmentEntity(
                partNumber = "DLG-4922",
                yearStart = 2015,
                yearEnd = 2024,
                make = "Ford",
                model = "F-150",
                engine = "3.5L V6 EcoBoost",
                position = "Rear",
                fitmentRules = "Rear Axle - Electric Parking Brake"
            ),
            FitmentEntity(
                partNumber = "BT-8421",
                yearStart = 2015,
                yearEnd = 2024,
                make = "Ford",
                model = "F-150",
                engine = "3.5L V6 EcoBoost",
                position = "Universal",
                fitmentRules = "AGM Battery Tray Fit"
            ),
            FitmentEntity(
                partNumber = "STP-S10590",
                yearStart = 2015,
                yearEnd = 2024,
                make = "Ford",
                model = "F-150",
                engine = "3.5L V6 EcoBoost",
                position = "Universal",
                fitmentRules = "Spin-On Filter 22mm x 1.5 Threads"
            )
        )

        dao.insertFitments(fitments)

        // 4. STORES
        val stores = listOf(
            StoreEntity(
                id = "store_4821",
                storeNumber = "4821",
                name = "AutoZone Memphis Central",
                address = "1280 Union Ave",
                city = "Memphis",
                state = "TN",
                zip = "38104",
                distanceMiles = 2.4,
                phone = "(901) 555-0192",
                hours = "8:00 AM – 10:00 PM"
            ),
            StoreEntity(
                id = "store_1932",
                storeNumber = "1932",
                name = "AutoZone Chicago Loop",
                address = "412 S Michigan Ave",
                city = "Chicago",
                state = "IL",
                zip = "60605",
                distanceMiles = 5.8,
                phone = "(312) 555-0382",
                hours = "7:30 AM – 9:30 PM"
            )
        )

        dao.insertStores(stores)

        // 5. INVENTORY
        val inventory = listOf(
            InventoryEntity(storeId = "store_4821", partNumber = "DLG-4921", onHand = 8, reserved = 1),
            InventoryEntity(storeId = "store_4821", partNumber = "DLG-4922", onHand = 6, reserved = 0),
            InventoryEntity(storeId = "store_4821", partNumber = "BT-8421", onHand = 12, reserved = 2),
            InventoryEntity(storeId = "store_4821", partNumber = "STP-S10590", onHand = 24, reserved = 0),
            InventoryEntity(storeId = "store_4821", partNumber = "MOB-5W30-5QT", onHand = 30, reserved = 3),
            InventoryEntity(storeId = "store_1932", partNumber = "DLG-4921", onHand = 3, reserved = 0),
            InventoryEntity(storeId = "store_1932", partNumber = "BT-8421", onHand = 5, reserved = 1)
        )

        dao.insertInventory(inventory)

        // 6. INITIAL DEMO ORDERS
        val orders = listOf(
            OrderEntity(
                orderNumber = "#48291",
                customerName = "Tom Williams",
                storeId = "store_4821",
                fulfillmentType = "PICKUP",
                status = "READY",
                totalAmount = 74.99,
                timestamp = System.currentTimeMillis() - 1800000,
                itemsSummary = "Duralast Gold Front Brake Pads x1",
                vehicleInfo = "2021 Ford F-150 3.5L V6"
            ),
            OrderEntity(
                orderNumber = "#48288",
                customerName = "ABC Auto Repair",
                storeId = "store_4821",
                fulfillmentType = "DELIVERY",
                status = "PICKING",
                totalAmount = 379.98,
                timestamp = System.currentTimeMillis() - 3600000,
                itemsSummary = "Duralast Battery H6-DLG x2",
                vehicleInfo = "Commercial Bulk Fleet"
            )
        )

        orders.forEach { dao.insertOrder(it) }

        // 7. REWARD ACCOUNT
        dao.insertRewardAccount(
            RewardAccountEntity(
                memberId = "AZ-881920",
                memberName = "Tom Williams",
                qualifyingPurchasesCount = 3,
                rewardsAvailable = 1,
                totalSpent = 412.50
            )
        )

        // 8. SERVICE HISTORY
        dao.insertServiceRecord(
            ServiceRecordEntity(
                vehicleId = "v1",
                serviceType = "Oil & Filter Change",
                date = "2026-09-12",
                mileage = 42100,
                notes = "Mobil 1 5W-30 + STP Filter",
                cost = 50.98,
                storeLocation = "AutoZone Store #4821"
            )
        )
        dao.insertServiceRecord(
            ServiceRecordEntity(
                vehicleId = "v1",
                serviceType = "Battery Replacement",
                date = "2026-07-03",
                mileage = 39800,
                notes = "Duralast Gold AGM Battery",
                cost = 189.99,
                storeLocation = "AutoZone Store #4821"
            )
        )

        // 9. MAINTENANCE ITEMS
        dao.insertMaintenanceItems(
            listOf(
                MaintenanceEntity(vehicleId = "v1", componentName = "Oil & Filter", status = "COMPLETED", dueDetail = "Done at 42,100 mi"),
                MaintenanceEntity(vehicleId = "v1", componentName = "Front Brake Pads", status = "DUE", dueDetail = "Inspect/Replace at 45,000 mi"),
                MaintenanceEntity(vehicleId = "v1", componentName = "Engine Air Filter", status = "UPCOMING", dueDetail = "Due in 3,000 mi"),
                MaintenanceEntity(vehicleId = "v1", componentName = "Battery", status = "COMPLETED", dueDetail = "Replaced July 2026")
            )
        )

        // 10. REPAIR GUIDES WITH AUTOMOTIVE DIAGRAMS
        dao.insertRepairGuides(
            listOf(
                RepairGuideEntity(
                    id = "rg_brake_01",
                    title = "Replace Front Brake Pads",
                    category = "BRAKES",
                    difficulty = "MODERATE",
                    estimatedTime = "1–2 Hours",
                    toolsRequired = "Socket set (13mm, 15mm), Torque Wrench, C-Clamp / Caliper Press, Floor Jack, Jack Stands, Wire Brush",
                    partsRequired = "Duralast Gold Front Brake Pads, Brake Cleaner Spray, Caliper Grease",
                    stepsJson = """[
                        {"step": 1, "title": "Prepare & Secure Vehicle", "desc": "Park on a level surface, engage parking brake, and loosen lug nuts before jacking up the front axle onto jack stands."},
                        {"step": 2, "title": "Remove Caliper & Old Pads", "desc": "Unbolt the top and bottom caliper guide pins with a 13mm socket. Slide caliper off rotor and hang with a bungee cord."},
                        {"step": 3, "title": "Compress Caliper Piston & Install New Pads", "desc": "Use a caliper compressor or C-clamp with the old pad to compress pistons flush into the housing. Apply anti-squeal lube to metal backing clips and insert new Duralast Gold pads."},
                        {"step": 4, "title": "Reinstall Caliper & Torque", "desc": "Reinstall caliper over new pads. Torque caliper guide pins to 28 ft-lbs and wheel lug nuts to 150 ft-lbs."}
                    ]""",
                    diagramType = "BRAKE"
                ),
                RepairGuideEntity(
                    id = "rg_batt_01",
                    title = "Replace Car Battery & Clean Terminals",
                    category = "BATTERIES",
                    difficulty = "EASY",
                    estimatedTime = "20–30 Minutes",
                    toolsRequired = "10mm Wrench, Battery Terminal Cleaner Brush, Safety Glasses",
                    partsRequired = "Duralast Gold Battery, Terminal Protection Washers, Dielectric Lube",
                    stepsJson = """[
                        {"step": 1, "title": "Disconnect Negative Terminal First", "desc": "Turn off engine. Loosen black negative (-) terminal cable with 10mm wrench and isolate away from battery post."},
                        {"step": 2, "title": "Disconnect Positive & Unbolt Hold-Down", "desc": "Unbolt red positive (+) cable, then remove bottom battery hold-down clamp."},
                        {"step": 3, "title": "Install New Battery & Reconnect", "desc": "Lift heavy old battery out. Clean tray. Lower new Duralast Gold battery in. Connect Positive (+) first, then Negative (-). Tighten snug."}
                    ]""",
                    diagramType = "BATTERY"
                )
            )
        )

        // 11. TOOLS FOR LOAN-A-TOOL
        dao.insertTools(
            listOf(
                ToolEntity(
                    id = "tl_01",
                    name = "Disc Brake Caliper Tool Set",
                    category = "BRAKE TOOLS",
                    brand = "OEMTOOLS",
                    partNumber = "OEM-27111",
                    depositAmount = 65.00,
                    isAvailable = true,
                    storeId = "store_4821"
                ),
                ToolEntity(
                    id = "tl_02",
                    name = "Torque Wrench 1/2 in. Drive",
                    category = "HAND TOOLS",
                    brand = "OEMTOOLS",
                    partNumber = "OEM-25687",
                    depositAmount = 80.00,
                    isAvailable = true,
                    storeId = "store_4821"
                ),
                ToolEntity(
                    id = "tl_03",
                    name = "OBD2 Fix Finder Scanner Pro",
                    category = "DIAGNOSTICS",
                    brand = "Innova / AutoZone",
                    partNumber = "AZ-FF300",
                    depositAmount = 120.00,
                    isAvailable = true,
                    storeId = "store_4821"
                )
            )
        )

        // 12. COMMERCIAL ACCOUNTS
        dao.insertCommercialAccounts(
            listOf(
                CommercialAccountEntity(
                    id = "com_01",
                    companyName = "ABC Auto Repair & Service Center",
                    accountNumber = "COM-90821",
                    creditLimit = 25000.00,
                    openBalance = 3840.50,
                    accountManager = "Jim Vance",
                    topPurchasedCategory = "Brake Pads & Rotors"
                ),
                CommercialAccountEntity(
                    id = "com_02",
                    companyName = "Memphis Fleet Solutions",
                    accountNumber = "COM-88204",
                    creditLimit = 50000.00,
                    openBalance = 12400.00,
                    accountManager = "Sarah Connor",
                    topPurchasedCategory = "Batteries & Fluids"
                )
            )
        )

        // 13. WARRANTIES
        dao.insertWarranties(
            listOf(
                WarrantyEntity(
                    id = "war_01",
                    productName = "Duralast Gold Battery H6-DLG",
                    partNumber = "BT-8421",
                    purchaseDate = "2026-07-03",
                    warrantyType = "3-Year Free Replacement",
                    expiryDate = "2029-07-03",
                    orderNumber = "#41082"
                )
            )
        )

        // 14. INITIAL AUDIT LOG
        dao.insertAuditLog(
            AuditLogEntity(
                timestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()),
                userRole = "SYSTEM_INIT",
                action = "BOOTSTRAP_DATABASE",
                objectName = "AutoZone.OS Core Engine",
                previousValue = "EMPTY",
                newValue = "INITIALIZED_WITH_SYNTHETIC_DATA"
            )
        )
    }

    companion object {
        @Volatile
        private var INSTANCE: AutoZoneRepository? = null

        fun getInstance(context: Context): AutoZoneRepository {
            return INSTANCE ?: synchronized(this) {
                val db = AutoZoneDatabase.getDatabase(context)
                val instance = AutoZoneRepository(db.autoZoneDao())
                INSTANCE = instance
                instance
            }
        }
    }
}
