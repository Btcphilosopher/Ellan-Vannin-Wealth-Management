package com.example.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vehicles")
data class VehicleEntity(
    @PrimaryKey val id: String,
    val year: Int,
    val make: String,
    val model: String,
    val engine: String,
    val trim: String,
    val vin: String,
    val isSelected: Boolean = false,
    val nickname: String = ""
)

@Entity(tableName = "parts")
data class PartEntity(
    @PrimaryKey val partNumber: String,
    val brand: String,
    val name: String,
    val category: String,
    val price: Double,
    val cost: Double,
    val warranty: String,
    val description: String,
    val barcode: String,
    val stockHQ: Int,
    val coreCharge: Double = 0.0,
    val position: String = "Universal", // e.g., Front, Rear, Universal
    val imageUrl: String = ""
)

@Entity(tableName = "fitments")
data class FitmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val partNumber: String,
    val yearStart: Int,
    val yearEnd: Int,
    val make: String,
    val model: String,
    val engine: String,
    val trim: String = "ALL",
    val position: String = "Universal",
    val fitmentRules: String = "Direct OEM Replacement",
    val confidenceScore: Int = 99,
    val provenance: String = "AutoZone OEM Catalog"
)

@Entity(tableName = "stores")
data class StoreEntity(
    @PrimaryKey val id: String,
    val storeNumber: String,
    val name: String,
    val address: String,
    val city: String,
    val state: String,
    val zip: String,
    val distanceMiles: Double,
    val isOpen: Boolean = true,
    val phone: String,
    val hours: String,
    val supportsPickup: Boolean = true,
    val supportsDelivery: Boolean = true,
    val supportsBatteryTest: Boolean = true,
    val supportsDiagnostics: Boolean = true,
    val supportsLoanTool: Boolean = true
)

@Entity(tableName = "inventory")
data class InventoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val storeId: String,
    val partNumber: String,
    val onHand: Int,
    val reserved: Int = 0,
    val inTransit: Int = 0,
    val damaged: Int = 0
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val orderNumber: String,
    val customerName: String,
    val storeId: String,
    val fulfillmentType: String, // "PICKUP" or "DELIVERY"
    val status: String, // "PROCESSING", "PICKING", "READY", "PICKED_UP", "SHIPPED", "DELIVERED"
    val totalAmount: Double,
    val timestamp: Long,
    val itemsSummary: String, // e.g. "Duralast Gold Brake Pads x1"
    val vehicleInfo: String,
    val arrivalNotified: Boolean = false
)

@Entity(tableName = "service_records")
data class ServiceRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val vehicleId: String,
    val serviceType: String,
    val date: String,
    val mileage: Int,
    val notes: String,
    val cost: Double,
    val storeLocation: String
)

@Entity(tableName = "maintenance_items")
data class MaintenanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val vehicleId: String,
    val componentName: String,
    val status: String, // "DUE", "UPCOMING", "COMPLETED"
    val dueDetail: String
)

@Entity(tableName = "tools")
data class ToolEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val brand: String,
    val partNumber: String,
    val depositAmount: Double,
    val isAvailable: Boolean = true,
    val storeId: String
)

@Entity(tableName = "tool_loans")
data class ToolLoanEntity(
    @PrimaryKey val id: String,
    val toolId: String,
    val toolName: String,
    val customerName: String,
    val storeId: String,
    val startDate: String,
    val returnDueDate: String,
    val status: String // "ACTIVE", "RETURNED"
)

@Entity(tableName = "shopping_lists")
data class ShoppingListEntity(
    @PrimaryKey val id: String,
    val listName: String,
    val itemCount: Int,
    val dateCreated: String,
    val sentToStoreId: String = ""
)

@Entity(tableName = "shopping_list_items")
data class ShoppingListItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val listId: String,
    val partNumber: String,
    val name: String,
    val quantity: Int,
    val price: Double,
    val isChecked: Boolean = false
)

@Entity(tableName = "reward_accounts")
data class RewardAccountEntity(
    @PrimaryKey val memberId: String,
    val memberName: String,
    val qualifyingPurchasesCount: Int, // 0 to 5
    val rewardsAvailable: Int, // $20 rewards
    val totalSpent: Double
)

@Entity(tableName = "warranties")
data class WarrantyEntity(
    @PrimaryKey val id: String,
    val productName: String,
    val partNumber: String,
    val purchaseDate: String,
    val warrantyType: String, // e.g. "Limited Lifetime", "3-Year Replacement"
    val expiryDate: String,
    val orderNumber: String,
    val isClaimed: Boolean = false
)

@Entity(tableName = "repair_guides")
data class RepairGuideEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String,
    val difficulty: String, // "EASY", "MODERATE", "ADVANCED"
    val estimatedTime: String,
    val toolsRequired: String,
    val partsRequired: String,
    val stepsJson: String,
    val publishStatus: String = "PUBLISHED",
    val diagramType: String = "BRAKE" // "BRAKE", "BATTERY", "ENGINE", "COOLING", "SUSPENSION", "ELECTRICAL"
)

@Entity(tableName = "commercial_accounts")
data class CommercialAccountEntity(
    @PrimaryKey val id: String,
    val companyName: String,
    val accountNumber: String,
    val creditLimit: Double,
    val openBalance: Double,
    val accountManager: String,
    val topPurchasedCategory: String
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: String,
    val userRole: String,
    val action: String,
    val objectName: String,
    val previousValue: String,
    val newValue: String
)

data class CartItem(
    val part: PartEntity,
    var quantity: Int = 1,
    var fulfillmentType: String = "PICKUP"
)
