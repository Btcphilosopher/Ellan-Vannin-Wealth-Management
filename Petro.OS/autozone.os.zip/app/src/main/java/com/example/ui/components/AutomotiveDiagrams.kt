package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AutomotiveDiagram(
    type: String,
    modifier: Modifier = Modifier.fillMaxWidth().height(180.dp)
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1A1A1A),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333))
    ) {
        Box(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            when (type.uppercase()) {
                "BATTERY" -> BatteryDiagramCanvas()
                "BRAKE" -> BrakeDiagramCanvas()
                "ENGINE" -> EngineDiagramCanvas()
                "COOLING" -> CoolingDiagramCanvas()
                "SUSPENSION" -> SuspensionDiagramCanvas()
                "ELECTRICAL" -> ElectricalDiagramCanvas()
                else -> BrakeDiagramCanvas()
            }

            Text(
                text = "${type.uppercase()} COMPONENT DIAGRAM",
                color = Color(0xFF888888),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart)
            )
        }
    }
}

@Composable
private fun BatteryDiagramCanvas() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val red = Color(0xFFD52B1E)
        val black = Color(0xFF333333)
        val silver = Color(0xFFCCCCCC)

        // Main Battery Box Body
        drawRoundRect(
            color = black,
            topLeft = Offset(w * 0.2f, h * 0.35f),
            size = Size(w * 0.6f, h * 0.5f),
            cornerRadius = CornerRadius(12f, 12f)
        )

        // Border outline
        drawRoundRect(
            color = red,
            topLeft = Offset(w * 0.2f, h * 0.35f),
            size = Size(w * 0.6f, h * 0.5f),
            cornerRadius = CornerRadius(12f, 12f),
            style = Stroke(width = 4f)
        )

        // Positive Terminal (+)
        drawRect(
            color = red,
            topLeft = Offset(w * 0.28f, h * 0.22f),
            size = Size(w * 0.08f, h * 0.13f)
        )

        // Negative Terminal (-)
        drawRect(
            color = silver,
            topLeft = Offset(w * 0.64f, h * 0.22f),
            size = Size(w * 0.08f, h * 0.13f)
        )

        // Handles / Grips
        drawLine(
            color = red,
            start = Offset(w * 0.3f, h * 0.5f),
            end = Offset(w * 0.7f, h * 0.5f),
            strokeWidth = 3f
        )
    }
}

@Composable
private fun BrakeDiagramCanvas() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width * 0.5f, size.height * 0.5f)
        val red = Color(0xFFD52B1E)
        val silver = Color(0xFFAAAAAA)
        val darkSilver = Color(0xFF666666)

        // Brake Rotor Outer Circle
        drawCircle(
            color = silver,
            radius = size.height * 0.38f,
            center = center,
            style = Stroke(width = 24f)
        )

        // Ventilated Slots / Holes on Rotor
        for (i in 0 until 8) {
            val angle = i * (Math.PI / 4)
            val dx = (Math.cos(angle) * size.height * 0.28f).toFloat()
            val dy = (Math.sin(angle) * size.height * 0.28f).toFloat()
            drawCircle(
                color = darkSilver,
                radius = 6f,
                center = Offset(center.x + dx, center.y + dy)
            )
        }

        // Hub Center
        drawCircle(
            color = darkSilver,
            radius = size.height * 0.15f,
            center = center
        )

        // Brake Caliper
        val path = Path().apply {
            moveTo(center.x - size.height * 0.45f, center.y - size.height * 0.2f)
            lineTo(center.x - size.height * 0.1f, center.y - size.height * 0.45f)
            lineTo(center.x + size.height * 0.1f, center.y - size.height * 0.45f)
            lineTo(center.x - size.height * 0.25f, center.y)
            close()
        }
        drawPath(path = path, color = red)
    }
}

@Composable
private fun EngineDiagramCanvas() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val orange = Color(0xFFFF6B00)
        val silver = Color(0xFFBBBBBB)

        // Engine Block
        drawRoundRect(
            color = Color(0xFF2D2D2D),
            topLeft = Offset(w * 0.25f, h * 0.25f),
            size = Size(w * 0.5f, h * 0.55f),
            cornerRadius = CornerRadius(8f, 8f)
        )

        // Pistons (4 Pistons)
        val pistonW = w * 0.08f
        val pistonH = h * 0.2f
        for (i in 0 until 3) {
            val x = w * (0.32f + i * 0.14f)
            drawRect(
                color = silver,
                topLeft = Offset(x, h * 0.35f),
                size = Size(pistonW, pistonH)
            )
            // Connecting rod line
            drawLine(
                color = orange,
                start = Offset(x + pistonW / 2, h * 0.55f),
                end = Offset(x + pistonW / 2, h * 0.72f),
                strokeWidth = 6f
            )
        }
    }
}

@Composable
private fun CoolingDiagramCanvas() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val blue = Color(0xFF0099FF)
        val red = Color(0xFFD52B1E)

        // Radiator Frame
        drawRect(
            color = Color(0xFF333333),
            topLeft = Offset(w * 0.2f, h * 0.2f),
            size = Size(w * 0.6f, h * 0.6f),
            style = Stroke(width = 8f)
        )

        // Cooling Fins Grid Lines
        for (i in 1..8) {
            val y = h * (0.2f + i * 0.06f)
            drawLine(
                color = if (i % 2 == 0) blue else red,
                start = Offset(w * 0.22f, y),
                end = Offset(w * 0.78f, y),
                strokeWidth = 3f
            )
        }

        // Fan blades
        drawCircle(
            color = Color.White,
            radius = h * 0.12f,
            center = Offset(w * 0.5f, h * 0.5f),
            style = Stroke(width = 4f)
        )
    }
}

@Composable
private fun SuspensionDiagramCanvas() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val red = Color(0xFFD52B1E)

        // Strut Shock Absorber Tube
        drawRect(
            color = Color(0xFF888888),
            topLeft = Offset(w * 0.46f, h * 0.15f),
            size = Size(w * 0.08f, h * 0.7f)
        )

        // Coil Spring Spiral
        val path = Path()
        val startY = h * 0.25f
        val endY = h * 0.65f
        val coils = 6
        val stepY = (endY - startY) / coils

        path.moveTo(w * 0.38f, startY)
        for (i in 0 until coils) {
            val y = startY + i * stepY
            path.lineTo(w * 0.62f, y + stepY / 2)
            path.lineTo(w * 0.38f, y + stepY)
        }

        drawPath(path = path, color = red, style = Stroke(width = 8f))
    }
}

@Composable
private fun ElectricalDiagramCanvas() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val yellow = Color(0xFFFFD700)

        // Alternator Housing
        drawCircle(
            color = Color(0xFF444444),
            radius = h * 0.3f,
            center = Offset(w * 0.5f, h * 0.5f)
        )

        // Copper Coils
        drawCircle(
            color = yellow,
            radius = h * 0.2f,
            center = Offset(w * 0.5f, h * 0.5f),
            style = Stroke(width = 12f)
        )

        // Spark / Pulse lines
        drawLine(
            color = Color.White,
            start = Offset(w * 0.15f, h * 0.5f),
            end = Offset(w * 0.35f, h * 0.5f),
            strokeWidth = 6f
        )
        drawLine(
            color = Color.White,
            start = Offset(w * 0.65f, h * 0.5f),
            end = Offset(w * 0.85f, h * 0.5f),
            strokeWidth = 6f
        )
    }
}
