package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AutoZoneRed = Color(0xFFD52B1E)
val AutoZoneDarkCharcoal = Color(0xFF121212)
val AutoZoneSurfaceDark = Color(0xFF1E1E1E)
val AutoZoneOrange = Color(0xFFFF6B00)
val AutoZoneGreen = Color(0xFF00CC66)
val AutoZoneGray = Color(0xFF888888)
