package com.example.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.CartItem
import com.example.ui.viewmodel.AutoZoneViewModel
import com.example.ui.viewmodel.CustomerScreen

@Composable
fun CartScreen(viewModel: AutoZoneViewModel) {
    val cartItems by viewModel.cartItems.collectAsState()
    val selectedStore by viewModel.selectedStore.collectAsState()
    val selectedVehicle by viewModel.selectedVehicle.collectAsState()
    var fulfillmentType by remember { mutableStateOf("PICKUP") }

    val subtotal = cartItems.sumOf { it.part.price * it.quantity }
    val tax = subtotal * 0.0825
    val grandTotal = subtotal + tax

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("SHOPPING CART", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)

        if (cartItems.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(64.dp))
                    Text("Your cart is empty", color = Color.Gray, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Button(
                        onClick = { viewModel.navigateCustomer(CustomerScreen.SHOP_PARTS) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E))
                    ) {
                        Text("SHOP PARTS NOW")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(cartItems) { item ->
                    CartItemCard(item = item, viewModel = viewModel)
                }

                item {
                    // Fulfillment Segmented Selector
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("FULFILLMENT LOCATION", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Storefront, contentDescription = null, tint = Color(0xFFD52B1E))
                                    Column {
                                        Text(selectedStore?.name ?: "AutoZone Memphis #4821", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Text("Pickup Counter • Ready in ~30 Mins", color = Color(0xFF00CC66), fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    // Order Summary Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ORDER SUMMARY", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Items Subtotal", color = Color.Gray, fontSize = 13.sp)
                                Text("\$${String.format("%.2f", subtotal)}", color = Color.White, fontSize = 13.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Estimated Tax (8.25%)", color = Color.Gray, fontSize = 13.sp)
                                Text("\$${String.format("%.2f", tax)}", color = Color.White, fontSize = 13.sp)
                            }
                            Divider(color = Color(0xFF2E2E2E))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                                Text("\$${String.format("%.2f", grandTotal)}", color = Color(0xFF00CC66), fontSize = 20.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }

            // Checkout Button
            Button(
                onClick = {
                    viewModel.placeOrder(fulfillmentType)
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text("PLACE STORE PICKUP ORDER • \$${String.format("%.2f", grandTotal)}", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun CartItemCard(item: CartItem, viewModel: AutoZoneViewModel) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(item.part.brand.uppercase(), color = Color(0xFFD52B1E), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(item.part.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Part #${item.part.partNumber} • \$${item.part.price} each", color = Color.Gray, fontSize = 11.sp)
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = { viewModel.updateCartQty(item.part.partNumber, item.quantity - 1) }) {
                    Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease", tint = Color.Gray)
                }
                Text("${item.quantity}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = { viewModel.updateCartQty(item.part.partNumber, item.quantity + 1) }) {
                    Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase", tint = Color(0xFFD52B1E))
                }
            }
        }
    }
}

@Composable
fun OrderTrackerScreen(viewModel: AutoZoneViewModel) {
    val trackedOrder by viewModel.trackedOrder.collectAsState()
    val selectedStore by viewModel.selectedStore.collectAsState()

    if (trackedOrder == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No active order tracked", color = Color.Gray)
        }
        return
    }

    val order = trackedOrder!!
    val isReady = order.status == "READY" || order.status == "PICKED_UP"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Status Ribbon
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = if (isReady) Color(0xFF00CC66) else Color(0xFFFF6B00)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("ORDER ${order.orderNumber}", color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    Surface(color = Color.Black, shape = RoundedCornerShape(4.dp)) {
                        Text(order.status, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                    }
                }

                Text(
                    text = if (isReady) "READY FOR PICKUP AT COUNTER!" else "STORE STAFF IS PICKING YOUR PARTS...",
                    color = Color.Black,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
                Text("AutoZone ${selectedStore?.name ?: "Store #4821"}", color = Color.Black.copy(alpha = 0.8f), fontSize = 13.sp)
            }
        }

        // Live Progress Tracker
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("ORDER STATUS TIMELINE", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                TimelineStep("ORDER PLACED", "Received by Store #4821", isDone = true)
                TimelineStep("PICKING PARTS", "Store Associate preparing items", isDone = true)
                TimelineStep("READY FOR PICKUP", "Staged at Pickup Counter #1", isDone = isReady)
                TimelineStep("COMPLETED", "Picked up by Customer", isDone = order.status == "PICKED_UP")
            }
        }

        // Order Details Summary
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ITEMS IN ORDER", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(order.itemsSummary, color = Color.LightGray, fontSize = 13.sp)
                Text("Vehicle: ${order.vehicleInfo}", color = Color.Gray, fontSize = 12.sp)
                Divider(color = Color(0xFF2E2E2E))
                Text("Total Paid: \$${order.totalAmount}", color = Color(0xFF00CC66), fontSize = 16.sp, fontWeight = FontWeight.Black)
            }
        }

        // "I'M HERE" Drive-Up Arrival Button
        if (isReady && order.status != "PICKED_UP") {
            Button(
                onClick = { viewModel.notifyArrivalForOrder(order.orderNumber) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (order.arrivalNotified) Color(0xFF00CC66) else Color(0xFFD52B1E)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (order.arrivalNotified) "ARRIVAL NOTIFIED • COUNTER STAFF READY" else "I'M HERE AT STORE FOR PICKUP",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun TimelineStep(title: String, desc: String, isDone: Boolean) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (isDone) Color(0xFF00CC66) else Color.Gray,
            modifier = Modifier.size(20.dp)
        )
        Column {
            Text(title, color = if (isDone) Color.White else Color.Gray, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = Color.Gray, fontSize = 11.sp)
        }
    }
}
