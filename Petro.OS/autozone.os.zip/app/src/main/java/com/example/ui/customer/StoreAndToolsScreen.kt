package com.example.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AutoZoneViewModel

@Composable
fun StoreFinderScreen(viewModel: AutoZoneViewModel) {
    val stores by viewModel.repository.allStores.collectAsState(initial = emptyList())
    val selectedStore by viewModel.selectedStore.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("FIND AN AUTOZONE STORE", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(stores) { store ->
                val isSel = store.id == selectedStore?.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.repository.setSelectedStore(store) },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSel) 2.dp else 1.dp,
                        color = if (isSel) Color(0xFFD52B1E) else Color(0xFF333333)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(store.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("${store.distanceMiles} mi", color = Color(0xFF00CC66), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        Text("${store.address}, ${store.city}, ${store.state} ${store.zip}", color = Color.Gray, fontSize = 12.sp)
                        Text("Hours: ${store.hours} • Phone: ${store.phone}", color = Color.LightGray, fontSize = 11.sp)

                        Divider(color = Color(0xFF2E2E2E))

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (store.supportsBatteryTest) ServiceChip("BATTERY TEST")
                            if (store.supportsDiagnostics) ServiceChip("DIAGNOSTICS")
                            if (store.supportsLoanTool) ServiceChip("LOAN-A-TOOL")
                            if (store.supportsPickup) ServiceChip("STORE PICKUP")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ServiceChip(name: String) {
    Surface(color = Color(0xFF282828), shape = RoundedCornerShape(4.dp)) {
        Text(name, color = Color.LightGray, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
    }
}

@Composable
fun LoanAToolScreen(viewModel: AutoZoneViewModel) {
    val tools by viewModel.allTools.collectAsState()
    var reservedToolName by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("LOAN-A-TOOL® PROGRAM", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text("Borrow specialized automotive repair tools with a fully refundable deposit", color = Color.Gray, fontSize = 12.sp)

        if (reservedToolName != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF00CC66).copy(alpha = 0.2f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF00CC66))
                    Text("RESERVED: $reservedToolName at Store Pickup Counter", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(tools) { tool ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(tool.brand, color = Color(0xFFD52B1E), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(tool.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text("Refundable Deposit: \$${tool.depositAmount}", color = Color(0xFF00CC66), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { reservedToolName = tool.name },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("RESERVE", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
