package com.example.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AutoZoneViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleGarageScreen(viewModel: AutoZoneViewModel) {
    val vehicles by viewModel.repository.allVehicles.collectAsState(initial = emptyList())
    val selectedVehicle by viewModel.selectedVehicle.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var showVinScannerModal by remember { mutableStateOf(false) }

    // Form states
    var inputYear by remember { mutableStateOf("2021") }
    var inputMake by remember { mutableStateOf("Ford") }
    var inputModel by remember { mutableStateOf("F-150") }
    var inputEngine by remember { mutableStateOf("3.5L V6 EcoBoost") }
    var inputTrim by remember { mutableStateOf("XLT") }
    var inputVin by remember { mutableStateOf("1FTFW1E84MF102839") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("MY GARAGE", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("Manage vehicles & maintenance records", color = Color.Gray, fontSize = 12.sp)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { showVinScannerModal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282828)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan VIN", tint = Color(0xFFD52B1E), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("SCAN VIN", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("ADD", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // List of Vehicles
        Text("SAVED VEHICLES", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(vehicles) { vehicle ->
                val isSelected = vehicle.isSelected
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectVehicle(vehicle.id) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF1E1E1E) else Color(0xFF181818)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) Color(0xFFD52B1E) else Color(0xFF333333)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = if (isSelected) Color(0xFFD52B1E) else Color.Gray)
                                Text(
                                    "${vehicle.year} ${vehicle.make} ${vehicle.model}",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (isSelected) {
                                Surface(color = Color(0xFFD52B1E), shape = RoundedCornerShape(4.dp)) {
                                    Text("ACTIVE VEHICLE", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                                }
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Engine: ${vehicle.engine}", color = Color.Gray, fontSize = 12.sp)
                            Text("Trim: ${vehicle.trim}", color = Color.Gray, fontSize = 12.sp)
                        }

                        if (vehicle.vin.isNotBlank()) {
                            Text("VIN: ${vehicle.vin}", color = Color(0xFF888888), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            // Service History & Maintenance Details for Active Vehicle
            if (selectedVehicle != null) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Text("SERVICE HISTORY & MAINTENANCE", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }

                item {
                    val serviceRecords by viewModel.getServiceRecordsForVehicle(selectedVehicle!!.id).collectAsState(initial = emptyList())
                    val maintenanceItems by viewModel.getMaintenanceForVehicle(selectedVehicle!!.id).collectAsState(initial = emptyList())

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("MAINTENANCE SCHEDULE", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)

                            maintenanceItems.forEach { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(item.componentName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(item.dueDetail, color = Color.Gray, fontSize = 11.sp)
                                    }

                                    val statusColor = when (item.status) {
                                        "DUE" -> Color(0xFFD52B1E)
                                        "UPCOMING" -> Color(0xFFFF6B00)
                                        else -> Color(0xFF00CC66)
                                    }
                                    Surface(color = statusColor.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                                        Text(item.status, color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                                Divider(color = Color(0xFF2E2E2E))
                            }

                            Spacer(Modifier.height(8.dp))
                            Text("RECENT SERVICE LOGS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)

                            serviceRecords.forEach { rec ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(rec.serviceType, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text("${rec.date} • ${rec.mileage} mi", color = Color.Gray, fontSize = 11.sp)
                                        Text(rec.notes, color = Color.LightGray, fontSize = 11.sp)
                                    }
                                    Text("\$${rec.cost}", color = Color(0xFF00CC66), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                                Divider(color = Color(0xFF2E2E2E))
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Vehicle Modal
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Vehicle", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = inputYear, onValueChange = { inputYear = it }, label = { Text("Year") })
                    OutlinedTextField(value = inputMake, onValueChange = { inputMake = it }, label = { Text("Make") })
                    OutlinedTextField(value = inputModel, onValueChange = { inputModel = it }, label = { Text("Model") })
                    OutlinedTextField(value = inputEngine, onValueChange = { inputEngine = it }, label = { Text("Engine") })
                    OutlinedTextField(value = inputTrim, onValueChange = { inputTrim = it }, label = { Text("Trim") })
                    OutlinedTextField(value = inputVin, onValueChange = { inputVin = it }, label = { Text("VIN") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val yearInt = inputYear.toIntOrNull() ?: 2021
                        viewModel.addVehicle(yearInt, inputMake, inputModel, inputEngine, inputTrim, inputVin)
                        showAddDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E))
                ) {
                    Text("SAVE VEHICLE")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF1E1E1E)
        )
    }

    // Simulated VIN Scanner Modal
    if (showVinScannerModal) {
        var scanningPhase by remember { mutableStateOf("SCANNING") } // SCANNING -> IDENTIFYING -> ADDED
        LaunchedEffect(Unit) {
            delay(1200)
            scanningPhase = "IDENTIFYING"
            delay(1200)
            scanningPhase = "ADDED"
            viewModel.addVehicle(2021, "Ford", "F-150", "3.5L V6 EcoBoost", "XLT SuperCrew", "1FTFW1E84MF102839")
        }

        AlertDialog(
            onDismissRequest = { showVinScannerModal = false },
            title = { Text("VIN CAMERA SCANNER", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(Color.Black, shape = RoundedCornerShape(12.dp))
                            .border(2.dp, Color(0xFFD52B1E), shape = RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = Color(0xFFD52B1E), modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("Align barcode inside frame", color = Color.Gray, fontSize = 11.sp)
                        }
                    }

                    Text(
                        text = when (scanningPhase) {
                            "SCANNING" -> "SCANNING VIN BARCODE..."
                            "IDENTIFYING" -> "IDENTIFYING: 2021 FORD F-150 3.5L EcoBoost"
                            else -> "VEHICLE ADDED TO GARAGE!"
                        },
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Surface(color = Color(0xFF282828), shape = RoundedCornerShape(4.dp)) {
                        Text("SIMULATED DEMO SCANNER", color = Color(0xFFFF6B00), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showVinScannerModal = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E))
                ) {
                    Text(if (scanningPhase == "ADDED") "DONE" else "CANCEL")
                }
            },
            containerColor = Color(0xFF1E1E1E)
        )
    }
}
