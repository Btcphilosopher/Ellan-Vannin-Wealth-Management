package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AutoZoneColorScheme = darkColorScheme(
    primary = AutoZoneRed,
    secondary = AutoZoneOrange,
    tertiary = AutoZoneGreen,
    background = AutoZoneDarkCharcoal,
    surface = AutoZoneSurfaceDark,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AutoZoneColorScheme,
        typography = Typography,
        content = content
    )
}
