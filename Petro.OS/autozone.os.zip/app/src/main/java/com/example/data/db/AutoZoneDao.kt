package com.example.data.db

import androidx.room.*
import com.example.data.models.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AutoZoneDao {

    // VEHICLES
    @Query("SELECT * FROM vehicles")
    fun getAllVehicles(): Flow<List<VehicleEntity>>

    @Query("SELECT * FROM vehicles WHERE isSelected = 1 LIMIT 1")
    fun getSelectedVehicleFlow(): Flow<VehicleEntity?>

    @Query("SELECT * FROM vehicles WHERE isSelected = 1 LIMIT 1")
    suspend fun getSelectedVehicle(): VehicleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicle(vehicle: VehicleEntity)

    @Query("UPDATE vehicles SET isSelected = 0")
    suspend fun clearSelectedVehicles()

    @Query("UPDATE vehicles SET isSelected = 1 WHERE id = :id")
    suspend fun setSelectedVehicle(id: String)

    @Delete
    suspend fun deleteVehicle(vehicle: VehicleEntity)

    // PARTS
    @Query("SELECT * FROM parts")
    fun getAllParts(): Flow<List<PartEntity>>

    @Query("SELECT * FROM parts WHERE partNumber = :partNumber LIMIT 1")
    suspend fun getPartByNumber(partNumber: String): PartEntity?

    @Query("SELECT * FROM parts WHERE partNumber LIKE '%' || :query || '%' OR name LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' OR brand LIKE '%' || :query || '%'")
    fun searchParts(query: String): Flow<List<PartEntity>>

    @Query("SELECT * FROM parts WHERE category = :category")
    fun getPartsByCategory(category: String): Flow<List<PartEntity>>

    @Query("SELECT * FROM parts WHERE barcode = :barcode LIMIT 1")
    suspend fun getPartByBarcode(barcode: String): PartEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParts(parts: List<PartEntity>)

    @Update
    suspend fun updatePart(part: PartEntity)

    // FITMENTS
    @Query("SELECT * FROM fitments")
    fun getAllFitments(): Flow<List<FitmentEntity>>

    @Query("SELECT * FROM fitments WHERE partNumber = :partNumber")
    suspend fun getFitmentsForPart(partNumber: String): List<FitmentEntity>

    @Query("SELECT * FROM fitments WHERE yearStart <= :year AND yearEnd >= :year AND make = :make AND model = :model")
    suspend fun getFitmentsForVehicle(year: Int, make: String, model: String): List<FitmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFitments(fitments: List<FitmentEntity>)

    // STORES
    @Query("SELECT * FROM stores")
    fun getAllStores(): Flow<List<StoreEntity>>

    @Query("SELECT * FROM stores WHERE id = :storeId LIMIT 1")
    suspend fun getStoreById(storeId: String): StoreEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStores(stores: List<StoreEntity>)

    // INVENTORY
    @Query("SELECT * FROM inventory")
    fun getAllInventory(): Flow<List<InventoryEntity>>

    @Query("SELECT * FROM inventory WHERE storeId = :storeId AND partNumber = :partNumber LIMIT 1")
    suspend fun getInventory(storeId: String, partNumber: String): InventoryEntity?

    @Query("SELECT * FROM inventory WHERE storeId = :storeId")
    fun getInventoryForStore(storeId: String): Flow<List<InventoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventory(inventory: List<InventoryEntity>)

    @Query("UPDATE inventory SET onHand = :onHand, reserved = :reserved WHERE storeId = :storeId AND partNumber = :partNumber")
    suspend fun updateInventoryStock(storeId: String, partNumber: String, onHand: Int, reserved: Int)

    // ORDERS
    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE orderNumber = :orderNumber LIMIT 1")
    fun getOrderByNumberFlow(orderNumber: String): Flow<OrderEntity?>

    @Query("SELECT * FROM orders WHERE orderNumber = :orderNumber LIMIT 1")
    suspend fun getOrderByNumber(orderNumber: String): OrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Query("UPDATE orders SET status = :status WHERE orderNumber = :orderNumber")
    suspend fun updateOrderStatus(orderNumber: String, status: String)

    @Query("UPDATE orders SET arrivalNotified = :notified WHERE orderNumber = :orderNumber")
    suspend fun updateOrderArrival(orderNumber: String, notified: Boolean)

    // SERVICE RECORDS
    @Query("SELECT * FROM service_records WHERE vehicleId = :vehicleId ORDER BY date DESC")
    fun getServiceRecordsForVehicle(vehicleId: String): Flow<List<ServiceRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServiceRecord(record: ServiceRecordEntity)

    // MAINTENANCE
    @Query("SELECT * FROM maintenance_items WHERE vehicleId = :vehicleId")
    fun getMaintenanceForVehicle(vehicleId: String): Flow<List<MaintenanceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaintenanceItems(items: List<MaintenanceEntity>)

    // TOOLS & LOANS
    @Query("SELECT * FROM tools")
    fun getAllTools(): Flow<List<ToolEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTools(tools: List<ToolEntity>)

    @Query("SELECT * FROM tool_loans ORDER BY startDate DESC")
    fun getAllToolLoans(): Flow<List<ToolLoanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertToolLoan(loan: ToolLoanEntity)

    // SHOPPING LISTS
    @Query("SELECT * FROM shopping_lists")
    fun getAllShoppingLists(): Flow<List<ShoppingListEntity>>

    @Query("SELECT * FROM shopping_list_items WHERE listId = :listId")
    fun getShoppingListItems(listId: String): Flow<List<ShoppingListItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShoppingList(list: ShoppingListEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShoppingListItems(items: List<ShoppingListItemEntity>)

    // REWARDS
    @Query("SELECT * FROM reward_accounts LIMIT 1")
    fun getRewardAccountFlow(): Flow<RewardAccountEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRewardAccount(account: RewardAccountEntity)

    // WARRANTIES
    @Query("SELECT * FROM warranties ORDER BY purchaseDate DESC")
    fun getAllWarranties(): Flow<List<WarrantyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWarranties(warranties: List<WarrantyEntity>)

    // REPAIR GUIDES
    @Query("SELECT * FROM repair_guides")
    fun getAllRepairGuides(): Flow<List<RepairGuideEntity>>

    @Query("SELECT * FROM repair_guides WHERE category = :category")
    fun getRepairGuidesByCategory(category: String): Flow<List<RepairGuideEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepairGuides(guides: List<RepairGuideEntity>)

    @Update
    suspend fun updateRepairGuide(guide: RepairGuideEntity)

    // COMMERCIAL ACCOUNTS
    @Query("SELECT * FROM commercial_accounts")
    fun getAllCommercialAccounts(): Flow<List<CommercialAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommercialAccounts(accounts: List<CommercialAccountEntity>)

    // AUDIT LOGS
    @Query("SELECT * FROM audit_logs ORDER BY id DESC")
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)
}
