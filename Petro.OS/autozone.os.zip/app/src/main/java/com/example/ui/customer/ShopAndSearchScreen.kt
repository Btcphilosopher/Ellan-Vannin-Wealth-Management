package com.example.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.PartEntity
import com.example.data.repository.FitmentStatus
import com.example.ui.viewmodel.AutoZoneViewModel
import com.example.ui.viewmodel.CustomerScreen
import kotlinx.coroutines.delay

val CATEGORIES = listOf(
    "ALL", "BATTERIES", "BRAKES", "OIL & FLUIDS", "FILTERS", "IGNITION",
    "LIGHTING", "ENGINE", "SUSPENSION", "ELECTRICAL", "TOOLS",
    "ACCESSORIES", "WIPERS", "COOLING", "BELTS", "HOSES"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopAndSearchScreen(viewModel: AutoZoneViewModel) {
    val selectedVehicle by viewModel.selectedVehicle.collectAsState()
    val filteredParts by viewModel.filteredParts.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCat by viewModel.selectedCategory.collectAsState()

    var showBarcodeModal by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Search & Barcode Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.searchQuery.value = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Search parts, part # (e.g. DLG-4921)...", color = Color.Gray, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFFD52B1E)) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF1E1E1E),
                    unfocusedContainerColor = Color(0xFF1E1E1E),
                    focusedBorderColor = Color(0xFFD52B1E),
                    unfocusedBorderColor = Color(0xFF333333),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            IconButton(
                onClick = { showBarcodeModal = true },
                modifier = Modifier
                    .size(52.dp)
                    .background(Color(0xFF1E1E1E), shape = RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFD52B1E), shape = RoundedCornerShape(12.dp))
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan Barcode", tint = Color(0xFFD52B1E))
            }
        }

        // Active Vehicle Fitment Info Banner
        if (selectedVehicle != null) {
            Surface(
                color = Color(0xFF1E1E1E),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF00CC66), modifier = Modifier.size(16.dp))
                        Text(
                            "Filtering for: ${selectedVehicle!!.year} ${selectedVehicle!!.make} ${selectedVehicle!!.model}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(selectedVehicle!!.engine, color = Color.Gray, fontSize = 11.sp)
                }
            }
        }

        // Category Filter Row
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(CATEGORIES) { cat ->
                val isSelected = cat == selectedCat
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectedCategory.value = cat },
                    label = { Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFD52B1E),
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF1E1E1E),
                        labelColor = Color.Gray
                    )
                )
            }
        }

        // Product Cards List
        if (filteredParts.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.SearchOff, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                    Text("No parts match '$searchQuery'", color = Color.Gray, fontSize = 14.sp)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredParts) { part ->
                    PartCard(part = part, viewModel = viewModel)
                }
            }
        }
    }

    // Barcode Scanner Modal
    if (showBarcodeModal) {
        var scanResult by remember { mutableStateOf<PartEntity?>(null) }
        var isScanning by remember { mutableStateOf(true) }

        LaunchedEffect(Unit) {
            delay(1500)
            scanResult = viewModel.getPartByBarcode("76829102401")
            isScanning = false
        }

        AlertDialog(
            onDismissRequest = { showBarcodeModal = false },
            title = { Text("BARCODE SCANNER", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(12.dp)
                ) {
                    if (isScanning) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .background(Color.Black, shape = RoundedCornerShape(12.dp))
                                .border(2.dp, Color(0xFFD52B1E), shape = RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("SCANNING IN-STORE BARCODE...", color = Color.Gray, fontSize = 12.sp)
                        }
                    } else if (scanResult != null) {
                        val part = scanResult!!
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF282828)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(part.brand, color = Color(0xFFD52B1E), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(part.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Part #${part.partNumber} • Barcode: ${part.barcode}", color = Color.Gray, fontSize = 11.sp)
                                Text("\$${part.price}", color = Color(0xFF00CC66), fontSize = 16.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                    Surface(color = Color(0xFF282828), shape = RoundedCornerShape(4.dp)) {
                        Text("SIMULATED IN-STORE SCANNER", color = Color(0xFFFF6B00), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (scanResult != null) {
                            viewModel.setPartAndOpenDetail(scanResult!!)
                        }
                        showBarcodeModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E))
                ) {
                    Text(if (scanResult != null) "VIEW PRODUCT" else "CANCEL")
                }
            },
            containerColor = Color(0xFF1E1E1E)
        )
    }
}

@Composable
fun PartCard(part: PartEntity, viewModel: AutoZoneViewModel) {
    var fitmentResult by remember { mutableStateOf<com.example.data.repository.FitmentResult?>(null) }

    LaunchedEffect(part, viewModel.selectedVehicle.value) {
        fitmentResult = viewModel.getFitmentResult(part)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { viewModel.setPartAndOpenDetail(part) },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Fitment Badge Bar
            if (fitmentResult != null) {
                val isFit = fitmentResult!!.status == FitmentStatus.EXACT_FIT || fitmentResult!!.status == FitmentStatus.UNIVERSAL_FIT
                val badgeBg = if (isFit) Color(0xFF00CC66).copy(alpha = 0.15f) else Color(0xFFD52B1E).copy(alpha = 0.15f)
                val badgeText = if (isFit) Color(0xFF00CC66) else Color(0xFFD52B1E)

                Surface(color = badgeBg, shape = RoundedCornerShape(6.dp)) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isFit) Icons.Default.CheckCircle else Icons.Default.Cancel,
                            contentDescription = null,
                            tint = badgeText,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (isFit) "FITS YOUR VEHICLE" else "DOES NOT FIT",
                            color = badgeText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text("• ${fitmentResult!!.position}", color = Color.LightGray, fontSize = 11.sp)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(part.brand.uppercase(), color = Color(0xFFD52B1E), fontSize = 11.sp, fontWeight = FontWeight.Black)
                    Text(part.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Part #${part.partNumber}", color = Color.Gray, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }

                Text(
                    "\$${part.price}",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Divider(color = Color(0xFF2E2E2E))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Storefront, contentDescription = null, tint = Color(0xFF00CC66), modifier = Modifier.size(16.dp))
                    Text("IN STOCK at Memphis #4821", color = Color.LightGray, fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        viewModel.addToCart(part)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("ADD TO CART", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
