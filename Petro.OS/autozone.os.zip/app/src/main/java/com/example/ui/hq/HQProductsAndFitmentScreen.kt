package com.example.ui.hq

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AutoZoneViewModel

@Composable
fun HQProductsScreen(viewModel: AutoZoneViewModel) {
    val parts by viewModel.filteredParts.collectAsState()
    var editingPartNum by remember { mutableStateOf<String?>(null) }
    var newPriceText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF141414))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("PARTS CATALOGUE HQ", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(parts) { part ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(part.brand.uppercase(), color = Color(0xFFD52B1E), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(part.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Text("Part #${part.partNumber} • Category: ${part.category}", color = Color.Gray, fontSize = 11.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("\$${part.price}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                                Text("Cost: \$${part.cost}", color = Color.Gray, fontSize = 11.sp)
                            }
                        }

                        Divider(color = Color(0xFF2E2E2E))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("HQ Stock: ${part.stockHQ} units", color = Color.LightGray, fontSize = 12.sp)

                            Button(
                                onClick = {
                                    editingPartNum = part.partNumber
                                    newPriceText = part.price.toString()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282828)),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFFFF6B00), modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("EDIT PRICE", color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (editingPartNum != null) {
        AlertDialog(
            onDismissRequest = { editingPartNum = null },
            title = { Text("Update Retail Price", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPriceText,
                    onValueChange = { newPriceText = it },
                    label = { Text("New Retail Price ($)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val priceVal = newPriceText.toDoubleOrNull()
                        if (priceVal != null) {
                            viewModel.updatePriceInHQ(editingPartNum!!, priceVal)
                        }
                        editingPartNum = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E))
                ) {
                    Text("SAVE & RECORD AUDIT LOG")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingPartNum = null }) { Text("Cancel", color = Color.Gray) }
            },
            containerColor = Color(0xFF1E1E1E)
        )
    }
}

@Composable
fun HQFitmentScreen(viewModel: AutoZoneViewModel) {
    val fitments by viewModel.allFitments.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF141414))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("FITMENT RULES DATABASE", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(fitments) { fit ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Part #${fit.partNumber}", color = Color(0xFFD52B1E), fontSize = 14.sp, fontWeight = FontWeight.Black)
                            Surface(color = Color(0xFF00CC66).copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                                Text("CONFIDENCE ${fit.confidenceScore}%", color = Color(0xFF00CC66), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }

                        Text("Fits: ${fit.yearStart}-${fit.yearEnd} ${fit.make} ${fit.model} (${fit.engine})", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Rule: ${fit.fitmentRules} • Position: ${fit.position}", color = Color.Gray, fontSize = 11.sp)
                        Text("Provenance: ${fit.provenance}", color = Color.DarkGray, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}
