package com.example.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AutoZoneViewModel
import com.example.ui.viewmodel.CustomerScreen

@Composable
fun CustomerHomeScreen(viewModel: AutoZoneViewModel) {
    val selectedVehicle by viewModel.selectedVehicle.collectAsState()
    val selectedStore by viewModel.selectedStore.collectAsState()
    var searchInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Question Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "WHAT ARE YOU WORKING ON?",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )

                // Search Bar
                OutlinedTextField(
                    value = searchInput,
                    onValueChange = { searchInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search parts, products or repair info...", color = Color.Gray) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFFD52B1E)) },
                    trailingIcon = {
                        if (searchInput.isNotEmpty()) {
                            IconButton(onClick = {
                                viewModel.searchQuery.value = searchInput
                                viewModel.navigateCustomer(CustomerScreen.PART_SEARCH)
                            }) {
                                Icon(Icons.Default.ArrowForward, contentDescription = "Go", tint = Color.White)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF282828),
                        unfocusedContainerColor = Color(0xFF282828),
                        focusedBorderColor = Color(0xFFD52B1E),
                        unfocusedBorderColor = Color(0xFF444444),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }
        }

        // Selected Vehicle Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateCustomer(CustomerScreen.MY_VEHICLE) },
            colors = CardDefaults.cardColors(containerColor = Color(0xFFD52B1E)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.DirectionsCar, contentDescription = "Vehicle", tint = Color.White, modifier = Modifier.size(32.dp))
                    Column {
                        Text("MY VEHICLE", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        if (selectedVehicle != null) {
                            Text(
                                "${selectedVehicle!!.year} ${selectedVehicle!!.make} ${selectedVehicle!!.model}",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(selectedVehicle!!.engine, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                        } else {
                            Text("NO VEHICLE SELECTED", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Button(
                    onClick = { viewModel.navigateCustomer(CustomerScreen.MY_VEHICLE) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("CHANGE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 4 Large Actions Grid
        Text("QUICK ACTIONS", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionTile(
                title = "SHOP PARTS",
                subtitle = "Categories & Search",
                icon = Icons.Default.Build,
                color = Color(0xFF1E1E1E),
                accentColor = Color(0xFFD52B1E),
                modifier = Modifier.weight(1f),
                onClick = { viewModel.navigateCustomer(CustomerScreen.SHOP_PARTS) }
            )
            ActionTile(
                title = "MY GARAGE",
                subtitle = "Vehicles & Records",
                icon = Icons.Default.DirectionsCar,
                color = Color(0xFF1E1E1E),
                accentColor = Color(0xFFFF6B00),
                modifier = Modifier.weight(1f),
                onClick = { viewModel.navigateCustomer(CustomerScreen.MY_VEHICLE) }
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionTile(
                title = "REPAIR HELP",
                subtitle = "Guides & Fix Finder",
                icon = Icons.Default.MenuBook,
                color = Color(0xFF1E1E1E),
                accentColor = Color(0xFF0099FF),
                modifier = Modifier.weight(1f),
                onClick = { viewModel.navigateCustomer(CustomerScreen.REPAIR_HELP) }
            )
            ActionTile(
                title = "FIND A STORE",
                subtitle = "Stock & Tool Loan",
                icon = Icons.Default.Storefront,
                color = Color(0xFF1E1E1E),
                accentColor = Color(0xFF00CC66),
                modifier = Modifier.weight(1f),
                onClick = { viewModel.navigateCustomer(CustomerScreen.STORE_FINDER) }
            )
        }

        // Fix Finder & Battery Banner Row
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.navigateCustomer(CustomerScreen.FIX_FINDER) },
                colors = CardDefaults.cardColors(containerColor = Color(0xFF252525)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Warning, contentDescription = "Engine Light", tint = Color(0xFFFFD700), modifier = Modifier.size(20.dp))
                        Text("FIX FINDER", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Text("Check Engine Light DTC Report", color = Color.Gray, fontSize = 11.sp)
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.navigateCustomer(CustomerScreen.BATTERY_CHECK) },
                colors = CardDefaults.cardColors(containerColor = Color(0xFF252525)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.FlashOn, contentDescription = "Battery", tint = Color(0xFF0099FF), modifier = Modifier.size(20.dp))
                        Text("BATTERY TEST", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Text("Free Battery Testing & Charge", color = Color.Gray, fontSize = 11.sp)
                }
            }
        }

        // Local Store Information Widget
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateCustomer(CustomerScreen.STORE_FINDER) },
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("YOUR LOCAL STORE", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(selectedStore?.name ?: "AutoZone Memphis #4821", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Color(0xFF00CC66), shape = RoundedCornerShape(4.dp)) {
                            Text("OPEN", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                        Text("${selectedStore?.distanceMiles ?: 2.4} mi • ${selectedStore?.hours ?: "Until 10 PM"}", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
                Icon(Icons.Default.ChevronRight, contentDescription = "View Store", tint = Color.Gray)
            }
        }
    }
}

@Composable
private fun ActionTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(100.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = color),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(icon, contentDescription = title, tint = accentColor, modifier = Modifier.size(28.dp))
            Column {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                Text(subtitle, color = Color.Gray, fontSize = 10.sp)
            }
        }
    }
}
