package com.example.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AutoZoneViewModel
import com.example.ui.viewmodel.CustomerScreen
import kotlinx.coroutines.delay

@Composable
fun FixFinderScreen(viewModel: AutoZoneViewModel) {
    val selectedVehicle by viewModel.selectedVehicle.collectAsState()
    var selectedWarningLight by remember { mutableStateOf("CHECK ENGINE") }
    var scanPhase by remember { mutableStateOf("IDLE") } // IDLE -> CONNECT -> READ -> ANALYZE -> REPORT

    LaunchedEffect(selectedWarningLight) {
        scanPhase = "CONNECT"
        delay(800)
        scanPhase = "READ"
        delay(800)
        scanPhase = "ANALYZE"
        delay(800)
        scanPhase = "REPORT"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("AUTOZONE FIX FINDER®", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("Technician-verified diagnostic report", color = Color.Gray, fontSize = 12.sp)
            }
            Surface(color = Color(0xFF282828), shape = RoundedCornerShape(4.dp)) {
                Text("SIMULATED DIAGNOSTICS", color = Color(0xFFFF6B00), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
            }
        }

        // Warning Light Selection Row
        Text("SELECT DASH WARNING LIGHT", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("CHECK ENGINE", "ABS LIGHT", "MAINTENANCE").forEach { light ->
                val isSel = light == selectedWarningLight
                Card(
                    modifier = Modifier.weight(1f).border(
                        width = if (isSel) 2.dp else 1.dp,
                        color = if (isSel) Color(0xFFFFD700) else Color(0xFF333333),
                        shape = RoundedCornerShape(8.dp)
                    ),
                    colors = CardDefaults.cardColors(containerColor = if (isSel) Color(0xFF282828) else Color(0xFF181818))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(light, color = if (isSel) Color(0xFFFFD700) else Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Diagnostic Workflow Progress / Report Card
        if (scanPhase != "REPORT") {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(180.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(color = Color(0xFFD52B1E))
                        Text(
                            text = when (scanPhase) {
                                "CONNECT" -> "CONNECTING TO OBD-II SCANNER PORT..."
                                "READ" -> "READING TROUBLE CODES (DTCs)..."
                                else -> "ANALYZING AUTOZONE FIX FINDER DATABASE..."
                            },
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else {
            // Diagnostic Report
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("DIAGNOSTIC REPORT", color = Color(0xFFD52B1E), fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Text(selectedVehicle?.let { "${it.year} ${it.make} ${it.model}" } ?: "2021 Ford F-150", color = Color.Gray, fontSize = 12.sp)
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(color = Color(0xFFD52B1E), shape = RoundedCornerShape(8.dp)) {
                            Text("P0420", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                        }
                        Column {
                            Text("Catalyst System Efficiency Below Threshold", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text("Severity: Moderate • Driveability: Safe for short distance", color = Color.Gray, fontSize = 11.sp)
                        }
                    }

                    Divider(color = Color(0xFF2E2E2E))

                    Text("WHAT THIS MAY INDICATE", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("The engine computer detected that the catalytic converter oxygen sensors are reporting sub-optimal exhaust gas conversion.", color = Color.LightGray, fontSize = 12.sp)

                    Text("POSSIBLE CAUSES", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("• Faulty Upstream / Downstream O2 Oxygen Sensor", color = Color.Gray, fontSize = 12.sp)
                        Text("• Exhaust leak near catalytic converter", color = Color.Gray, fontSize = 12.sp)
                        Text("• Misfiring spark plugs polluting catalyst core", color = Color.Gray, fontSize = 12.sp)
                    }

                    Divider(color = Color(0xFF2E2E2E))

                    Text("RECOMMENDED PARTS TO FIX", color = Color(0xFF00CC66), fontSize = 13.sp, fontWeight = FontWeight.Bold)

                    Button(
                        onClick = { viewModel.navigateCustomer(CustomerScreen.SHOP_PARTS) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("VIEW OXYGEN SENSORS & SPARK PLUGS")
                    }
                }
            }
        }
    }
}

@Composable
fun BatteryTesterScreen(viewModel: AutoZoneViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("FREE BATTERY TESTING", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("BATTERY HEALTH CHECK", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Surface(color = Color(0xFF00CC66), shape = RoundedCornerShape(4.dp)) {
                        Text("HEALTH: GOOD (94%)", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Measured Voltage", color = Color.Gray, fontSize = 12.sp)
                        Text("12.65 V", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    }
                    Column {
                        Text("Cranking Amps", color = Color.Gray, fontSize = 12.sp)
                        Text("730 CCA", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    }
                }

                Surface(color = Color(0xFF282828), shape = RoundedCornerShape(4.dp)) {
                    Text("SIMULATED BATTERY TESTER", color = Color(0xFFFF6B00), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                }
            }
        }

        Button(
            onClick = { viewModel.navigateCustomer(CustomerScreen.STORE_FINDER) },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Storefront, contentDescription = null, tint = Color.White)
            Spacer(Modifier.width(8.dp))
            Text("FIND NEARBY AUTOZONE FOR FREE CHARGE & TEST")
        }
    }
}
