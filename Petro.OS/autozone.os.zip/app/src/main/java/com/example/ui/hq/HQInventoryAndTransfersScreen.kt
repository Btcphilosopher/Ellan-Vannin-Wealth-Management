package com.example.ui.hq

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AutoZoneViewModel

@Composable
fun HQInventoryScreen(viewModel: AutoZoneViewModel) {
    val inventory by viewModel.allInventory.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF141414))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("ENTERPRISE INVENTORY MATRIX", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(inventory) { inv ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Store ID: ${inv.storeId.uppercase()}", color = Color(0xFFD52B1E), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Part #${inv.partNumber}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("ON HAND", color = Color.Gray, fontSize = 10.sp)
                                Text("${inv.onHand}", color = Color(0xFF00CC66), fontSize = 18.sp, fontWeight = FontWeight.Black)
                            }
                            Column {
                                Text("RESERVED", color = Color.Gray, fontSize = 10.sp)
                                Text("${inv.reserved}", color = Color(0xFFFF6B00), fontSize = 18.sp, fontWeight = FontWeight.Black)
                            }
                            Column {
                                Text("AVAILABLE", color = Color.Gray, fontSize = 10.sp)
                                Text("${inv.onHand - inv.reserved}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HQTransfersScreen(viewModel: AutoZoneViewModel) {
    var transferCreated by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF141414))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("INVENTORY TRANSFERS HQ", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("CREATE STORE-TO-STORE TRANSFER", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)

                Text("Source: AutoZone Store #4821 (Memphis) • Stock Available: 8", color = Color.Gray, fontSize = 12.sp)
                Text("Destination: AutoZone Store #1932 (Chicago) • Current Stock: 3", color = Color.Gray, fontSize = 12.sp)
                Text("Item: Duralast Gold Front Brake Pads (DLG-4921)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                Button(
                    onClick = { transferCreated = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("TRANSFER 5 UNITS")
                }

                if (transferCreated) {
                    Surface(color = Color(0xFF00CC66).copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp)) {
                        Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF00CC66))
                            Text("TRANSFER #TRF-9021 CREATED • STATUS: IN TRANSIT", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
