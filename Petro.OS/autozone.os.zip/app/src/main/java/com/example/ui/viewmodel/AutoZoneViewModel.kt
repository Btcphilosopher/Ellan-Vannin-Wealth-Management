package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.models.*
import com.example.data.repository.AutoZoneRepository
import com.example.data.repository.FitmentResult
import com.example.data.repository.SimulationScenario
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppMode {
    CUSTOMER_APP,
    AUTOZONE_HQ
}

enum class CustomerScreen {
    HOME,
    MY_VEHICLE,
    SHOP_PARTS,
    PART_SEARCH,
    PRODUCT_DETAIL,
    BARCODE_SCANNER,
    VIN_SCANNER,
    CART,
    ORDER_TRACKER,
    FIX_FINDER,
    BATTERY_CHECK,
    STORE_FINDER,
    LOAN_TOOL,
    SHOPPING_LIST,
    REPAIR_HELP,
    REPAIR_GUIDE_DETAIL,
    REWARDS,
    WARRANTIES
}

enum class HQScreen {
    DASHBOARD,
    PRODUCTS,
    FITMENT,
    INVENTORY,
    TRANSFERS,
    STORES,
    ORDERS,
    COMMERCIAL,
    PRICING,
    REWARDS_WARRANTIES,
    REPAIR_CONTENT,
    AUDIT_LOG
}

class AutoZoneViewModel(application: Application) : AndroidViewModel(application) {

    val repository = AutoZoneRepository.getInstance(application)

    // Current Mode: Customer App vs HQ
    private val _currentMode = MutableStateFlow(AppMode.CUSTOMER_APP)
    val currentMode: StateFlow<AppMode> = _currentMode.asStateFlow()

    // Navigation state
    private val _customerScreen = MutableStateFlow(CustomerScreen.HOME)
    val customerScreen: StateFlow<CustomerScreen> = _customerScreen.asStateFlow()

    private val _hqScreen = MutableStateFlow(HQScreen.DASHBOARD)
    val hqScreen: StateFlow<HQScreen> = _hqScreen.asStateFlow()

    // Active Selection State
    val selectedVehicle: StateFlow<VehicleEntity?> = repository.selectedVehicle
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedStore: StateFlow<StoreEntity?> = repository.selectedStore
    val cartItems: StateFlow<List<CartItem>> = repository.cartItems
    val currentScenario: StateFlow<SimulationScenario> = repository.currentScenario

    // Active Part / Repair Guide Selection
    private val _selectedPart = MutableStateFlow<PartEntity?>(null)
    val selectedPart: StateFlow<PartEntity?> = _selectedPart.asStateFlow()

    private val _selectedGuide = MutableStateFlow<RepairGuideEntity?>(null)
    val selectedGuide: StateFlow<RepairGuideEntity?> = _selectedGuide.asStateFlow()

    // Search text & category filter
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("ALL")

    // Repository Flows exposed
    val allOrders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRepairGuides: StateFlow<List<RepairGuideEntity>> = repository.allRepairGuides
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allWarranties: StateFlow<List<WarrantyEntity>> = repository.allWarranties
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val rewardAccount: StateFlow<RewardAccountEntity?> = repository.rewardAccount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allTools: StateFlow<List<ToolEntity>> = repository.allTools
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCommercialAccounts: StateFlow<List<CommercialAccountEntity>> = repository.allCommercialAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAuditLogs: StateFlow<List<AuditLogEntity>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allInventory: StateFlow<List<InventoryEntity>> = repository.allInventory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFitments: StateFlow<List<FitmentEntity>> = repository.allFitments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active tracked order for Customer
    private val _activeTrackedOrderNum = MutableStateFlow<String?>(null)
    val activeTrackedOrderNum: StateFlow<String?> = _activeTrackedOrderNum.asStateFlow()

    val trackedOrder: StateFlow<OrderEntity?> = combine(allOrders, _activeTrackedOrderNum) { orders, num ->
        if (num == null) orders.firstOrNull() else orders.find { it.orderNumber == num }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Reactive parts list filtered by search query & category
    val filteredParts: StateFlow<List<PartEntity>> = combine(
        repository.allParts,
        searchQuery,
        selectedCategory
    ) { parts, query, cat ->
        parts.filter { part ->
            val matchesCat = if (cat == "ALL") true else part.category.equals(cat, ignoreCase = true)
            val matchesQuery = if (query.isBlank()) true else {
                part.name.contains(query, ignoreCase = true) ||
                        part.partNumber.contains(query, ignoreCase = true) ||
                        part.brand.contains(query, ignoreCase = true) ||
                        part.category.contains(query, ignoreCase = true)
            }
            matchesCat && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setAppMode(mode: AppMode) {
        _currentMode.value = mode
    }

    fun navigateCustomer(screen: CustomerScreen) {
        _customerScreen.value = screen
    }

    fun navigateHQ(screen: HQScreen) {
        _hqScreen.value = screen
    }

    fun setPartAndOpenDetail(part: PartEntity) {
        _selectedPart.value = part
        _customerScreen.value = CustomerScreen.PRODUCT_DETAIL
    }

    fun setGuideAndOpenDetail(guide: RepairGuideEntity) {
        _selectedGuide.value = guide
        _customerScreen.value = CustomerScreen.REPAIR_GUIDE_DETAIL
    }

    fun setScenario(scenario: SimulationScenario) {
        viewModelScope.launch {
            repository.setScenario(scenario)
        }
    }

    fun selectVehicle(vehicleId: String) {
        viewModelScope.launch {
            repository.setSelectedVehicle(vehicleId)
        }
    }

    fun addVehicle(year: Int, make: String, model: String, engine: String, trim: String, vin: String) {
        viewModelScope.launch {
            repository.addVehicle(year, make, model, engine, trim, vin)
        }
    }

    fun addToCart(part: PartEntity, qty: Int = 1, fulfillmentType: String = "PICKUP") {
        repository.addToCart(part, qty, fulfillmentType)
    }

    fun updateCartQty(partNumber: String, qty: Int) {
        repository.updateCartItemQuantity(partNumber, qty)
    }

    fun placeOrder(fulfillmentType: String) {
        viewModelScope.launch {
            val veh = selectedVehicle.value
            val vehInfo = if (veh != null) "${veh.year} ${veh.make} ${veh.model}" else "Standard Vehicle"
            val store = selectedStore.value
            val storeId = store?.id ?: "store_4821"

            val order = repository.placeOrder(
                customerName = "Tom Williams",
                storeId = storeId,
                fulfillmentType = fulfillmentType,
                vehicleInfo = vehInfo
            )
            _activeTrackedOrderNum.value = order.orderNumber
            _customerScreen.value = CustomerScreen.ORDER_TRACKER
        }
    }

    fun markOrderReadyInHQ(orderNumber: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderNumber, "READY")
        }
    }

    fun markOrderPickedUpInHQ(orderNumber: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderNumber, "PICKED_UP")
        }
    }

    fun notifyArrivalForOrder(orderNumber: String) {
        viewModelScope.launch {
            repository.notifyStoreArrival(orderNumber)
        }
    }

    fun updatePriceInHQ(partNumber: String, newPrice: Double) {
        viewModelScope.launch {
            repository.updatePartPrice(partNumber, newPrice)
        }
    }

    suspend fun getFitmentResult(part: PartEntity): FitmentResult {
        return repository.checkFitment(selectedVehicle.value, part)
    }

    fun getServiceRecordsForVehicle(vehicleId: String): Flow<List<ServiceRecordEntity>> {
        return repository.getServiceRecordsForVehicle(vehicleId)
    }

    fun getMaintenanceForVehicle(vehicleId: String): Flow<List<MaintenanceEntity>> {
        return repository.getMaintenanceForVehicle(vehicleId)
    }

    suspend fun getPartByBarcode(barcode: String): PartEntity? {
        return repository.getPartByBarcode(barcode)
    }
}
