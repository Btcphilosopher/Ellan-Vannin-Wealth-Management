package com.example.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.RepairGuideEntity
import com.example.ui.components.AutomotiveDiagram
import com.example.ui.viewmodel.AutoZoneViewModel

@Composable
fun RepairHelpScreen(viewModel: AutoZoneViewModel) {
    val guides by viewModel.allRepairGuides.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("REPAIR HELP & HOW-TO GUIDES", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(guides) { guide ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.setGuideAndOpenDetail(guide) },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(guide.category, color = Color(0xFFD52B1E), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Surface(color = Color(0xFF282828), shape = RoundedCornerShape(4.dp)) {
                                Text(guide.difficulty, color = Color(0xFFFF6B00), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }

                        Text(guide.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("Est. Time: ${guide.estimatedTime}", color = Color.Gray, fontSize = 12.sp)

                        Divider(color = Color(0xFF2E2E2E))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("View step-by-step guide & diagram", color = Color.LightGray, fontSize = 12.sp)
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color(0xFFD52B1E))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RepairGuideDetailScreen(viewModel: AutoZoneViewModel) {
    val guide by viewModel.selectedGuide.collectAsState()

    if (guide == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No guide selected", color = Color.Gray)
        }
        return
    }

    val currentGuide = guide!!

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(currentGuide.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)

        // Automotive SVG Diagram
        AutomotiveDiagram(type = currentGuide.diagramType)

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("REQUIRED TOOLS", color = Color(0xFFD52B1E), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(currentGuide.toolsRequired, color = Color.LightGray, fontSize = 12.sp)
                Divider(color = Color(0xFF2E2E2E))
                Text("REQUIRED PARTS", color = Color(0xFF00CC66), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(currentGuide.partsRequired, color = Color.LightGray, fontSize = 12.sp)
            }
        }

        Text("INSTRUCTIONAL STEPS", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("STEP 1: Prepare & Secure Vehicle", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Park on level ground, set parking brake, jack up vehicle safely onto jack stands.", color = Color.Gray, fontSize = 12.sp)
                Divider(color = Color(0xFF2E2E2E))

                Text("STEP 2: Unbolt Caliper & Remove Pads", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Remove top and bottom guide pin bolts, slide caliper off rotor, and extract worn pads.", color = Color.Gray, fontSize = 12.sp)
                Divider(color = Color(0xFF2E2E2E))

                Text("STEP 3: Compress Pistons & Install Duralast Pads", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Use caliper press tool to push pistons flush, insert new pads with anti-squeal clips, and torque to spec.", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun RewardsScreen(viewModel: AutoZoneViewModel) {
    val rewardAccount by viewModel.rewardAccount.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("AUTOZONE REWARDS®", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFD52B1E)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("MEMBER CARD", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(rewardAccount?.memberId ?: "AZ-881920", color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }

                Text(rewardAccount?.memberName ?: "Tom Williams", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)

                LinearProgressIndicator(
                    progress = { (rewardAccount?.qualifyingPurchasesCount ?: 3) / 5f },
                    modifier = Modifier.fillMaxWidth().height(10.dp),
                    color = Color.White,
                    trackColor = Color.Black.copy(alpha = 0.3f)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${rewardAccount?.qualifyingPurchasesCount ?: 3} / 5 Purchases Towards Reward", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("\$20 REWARD", color = Color.Yellow, fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun WarrantiesScreen(viewModel: AutoZoneViewModel) {
    val warranties by viewModel.allWarranties.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("MY DIGITAL WARRANTIES", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(warranties) { war ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(war.productName, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Surface(color = Color(0xFF00CC66), shape = RoundedCornerShape(4.dp)) {
                                Text("ACTIVE WARRANTY", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }

                        Text("Type: ${war.warrantyType}", color = Color(0xFF00CC66), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Purchased: ${war.purchaseDate} • Order: ${war.orderNumber}", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
