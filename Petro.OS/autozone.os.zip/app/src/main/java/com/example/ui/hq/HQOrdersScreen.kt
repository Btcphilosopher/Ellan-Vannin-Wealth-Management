package com.example.ui.hq

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AutoZoneViewModel

@Composable
fun HQOrdersScreen(viewModel: AutoZoneViewModel) {
    val orders by viewModel.allOrders.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF141414))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("ORDERS HQ MANAGEMENT", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("Live store pickup & delivery queue", color = Color.Gray, fontSize = 12.sp)
            }
            Surface(color = Color(0xFF0099FF), shape = RoundedCornerShape(4.dp)) {
                Text("LIVE SYNC ACTIVE", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(orders) { order ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("ORDER ${order.orderNumber}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                                if (order.arrivalNotified) {
                                    Surface(color = Color(0xFFD52B1E), shape = RoundedCornerShape(4.dp)) {
                                        Text("CUSTOMER AT COUNTER", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                            }

                            val statusColor = when (order.status) {
                                "READY" -> Color(0xFF00CC66)
                                "PICKED_UP" -> Color.Gray
                                else -> Color(0xFFFF6B00)
                            }
                            Surface(color = statusColor.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                                Text(order.status, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                            }
                        }

                        Text("Customer: ${order.customerName} • Store: ${order.storeId.uppercase()}", color = Color.LightGray, fontSize = 12.sp)
                        Text("Items: ${order.itemsSummary}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Vehicle: ${order.vehicleInfo} • Type: ${order.fulfillmentType}", color = Color.Gray, fontSize = 11.sp)

                        Divider(color = Color(0xFF2E2E2E))

                        // HQ Operational Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total: \$${order.totalAmount}", color = Color(0xFF00CC66), fontSize = 15.sp, fontWeight = FontWeight.Black)

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (order.status == "PICKING") {
                                    Button(
                                        onClick = { viewModel.markOrderReadyInHQ(order.orderNumber) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00CC66)),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("MARK READY FOR PICKUP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                } else if (order.status == "READY") {
                                    Button(
                                        onClick = { viewModel.markOrderPickedUpInHQ(order.orderNumber) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0099FF)),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("COMPLETE PICKUP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
