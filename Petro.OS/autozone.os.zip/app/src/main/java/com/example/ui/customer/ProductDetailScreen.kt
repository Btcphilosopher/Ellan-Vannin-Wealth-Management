package com.example.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.FitmentStatus
import com.example.ui.components.AutomotiveDiagram
import com.example.ui.viewmodel.AutoZoneViewModel
import com.example.ui.viewmodel.CustomerScreen

@Composable
fun ProductDetailScreen(viewModel: AutoZoneViewModel) {
    val part by viewModel.selectedPart.collectAsState()
    val selectedVehicle by viewModel.selectedVehicle.collectAsState()
    val selectedStore by viewModel.selectedStore.collectAsState()

    if (part == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No product selected", color = Color.Gray)
        }
        return
    }

    val currentPart = part!!
    var fitmentResult by remember { mutableStateOf<com.example.data.repository.FitmentResult?>(null) }
    var selectedFulfillment by remember { mutableStateOf("PICKUP") }

    LaunchedEffect(currentPart, selectedVehicle) {
        fitmentResult = viewModel.getFitmentResult(currentPart)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Back Button Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateCustomer(CustomerScreen.PART_SEARCH) }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("PART DETAILS", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.width(48.dp))
        }

        // Fitment Guarantee Ribbon Banner
        if (fitmentResult != null) {
            val isFit = fitmentResult!!.status == FitmentStatus.EXACT_FIT || fitmentResult!!.status == FitmentStatus.UNIVERSAL_FIT
            val bg = if (isFit) Color(0xFF00CC66) else Color(0xFFD52B1E)

            Card(
                colors = CardDefaults.cardColors(containerColor = bg),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isFit) Icons.Default.VerifiedUser else Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = if (isFit) "GUARANTEED FIT" else "INCOMPATIBLE VEHICLE",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = fitmentResult!!.note,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Custom Automotive Diagram Visual Asset
        AutomotiveDiagram(
            type = currentPart.category,
            modifier = Modifier.fillMaxWidth().height(200.dp)
        )

        // Title & Price Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(currentPart.brand.uppercase(), color = Color(0xFFD52B1E), fontSize = 12.sp, fontWeight = FontWeight.Black)
                Text(currentPart.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Part #${currentPart.partNumber}", color = Color.Gray, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        if (currentPart.coreCharge > 0) {
                            Text("+\$${currentPart.coreCharge} Core Charge (Refundable)", color = Color(0xFFFF6B00), fontSize = 11.sp)
                        }
                    }

                    Text("\$${currentPart.price}", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                }

                Divider(color = Color(0xFF2E2E2E))

                Text(currentPart.description, color = Color.LightGray, fontSize = 13.sp, lineHeight = 18.sp)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF00CC66), modifier = Modifier.size(16.dp))
                    Text(currentPart.warranty, color = Color(0xFF00CC66), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Fulfillment Selection Card (Pickup vs Delivery)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("FULFILLMENT OPTIONS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Store Pickup Tile
                    val isPickupSelected = selectedFulfillment == "PICKUP"
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                width = if (isPickupSelected) 2.dp else 1.dp,
                                color = if (isPickupSelected) Color(0xFFD52B1E) else Color(0xFF333333),
                                shape = RoundedCornerShape(10.dp)
                            ),
                        colors = CardDefaults.cardColors(containerColor = if (isPickupSelected) Color(0xFF282828) else Color(0xFF181818))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                RadioButton(selected = isPickupSelected, onClick = { selectedFulfillment = "PICKUP" }, colors = RadioButtonDefaults.colors(selectedColor = Color(0xFFD52B1E)))
                                Text("STORE PICKUP", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Text("FREE Same Day Pickup", color = Color(0xFF00CC66), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${selectedStore?.name ?: "Store #4821"}", color = Color.Gray, fontSize = 10.sp)
                        }
                    }

                    // Delivery Tile
                    val isDeliverySelected = selectedFulfillment == "DELIVERY"
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                width = if (isDeliverySelected) 2.dp else 1.dp,
                                color = if (isDeliverySelected) Color(0xFFD52B1E) else Color(0xFF333333),
                                shape = RoundedCornerShape(10.dp)
                            ),
                        colors = CardDefaults.cardColors(containerColor = if (isDeliverySelected) Color(0xFF282828) else Color(0xFF181818))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                RadioButton(selected = isDeliverySelected, onClick = { selectedFulfillment = "DELIVERY" }, colors = RadioButtonDefaults.colors(selectedColor = Color(0xFFD52B1E)))
                                Text("HOME DELIVERY", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Text("Same Day or Tomorrow", color = Color(0xFFFF6B00), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Direct to your garage", color = Color.Gray, fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // Add to Cart Primary Action Button
        Button(
            onClick = {
                viewModel.addToCart(currentPart, qty = 1, fulfillmentType = selectedFulfillment)
                viewModel.navigateCustomer(CustomerScreen.CART)
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD52B1E)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.White)
            Spacer(Modifier.width(8.dp))
            Text("ADD TO CART • \$${currentPart.price}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
        }
    }
}
