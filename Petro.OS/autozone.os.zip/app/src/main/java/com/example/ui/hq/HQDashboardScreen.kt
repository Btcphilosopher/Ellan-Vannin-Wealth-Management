package com.example.ui.hq

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.SimulationScenario
import com.example.ui.viewmodel.AutoZoneViewModel

@Composable
fun HQDashboardScreen(viewModel: AutoZoneViewModel) {
    val currentScenario by viewModel.currentScenario.collectAsState()
    val orders by viewModel.allOrders.collectAsState()
    val auditLogs by viewModel.allAuditLogs.collectAsState()

    val totalSales = orders.sumOf { it.totalAmount }
    val readyOrdersCount = orders.count { it.status == "READY" }
    val pickingOrdersCount = orders.count { it.status == "PICKING" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF141414))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("AUTOZONE HQ OPERATING SYSTEM", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("Enterprise Retail & Inventory Operations", color = Color.Gray, fontSize = 12.sp)
            }
            Surface(color = Color(0xFFD52B1E), shape = RoundedCornerShape(4.dp)) {
                Text("HQ SYSTEM ONLINE", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
            }
        }

        // SIMULATION SCENARIO CONTROL BAR
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("SIMULATION SCENARIO ENGINE", color = Color(0xFFFF6B00), fontSize = 11.sp, fontWeight = FontWeight.Black)
                    Text("Active: ${currentScenario.displayName}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(SimulationScenario.values()) { sc ->
                        val isSel = sc == currentScenario
                        FilterChip(
                            selected = isSel,
                            onClick = { viewModel.setScenario(sc) },
                            label = { Text(sc.displayName, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFFF6B00),
                                selectedLabelColor = Color.Black,
                                containerColor = Color(0xFF282828),
                                labelColor = Color.Gray
                            )
                        )
                    }
                }
            }
        }

        // Top Metric Grid
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("TODAY SALES", "\$${String.format("%.2f", totalSales + 128450.0)}", "↑ 12.4% vs prev week", Color(0xFF00CC66), Modifier.weight(1f))
            MetricCard("ACTIVE ORDERS", "${orders.size + 142}", "$pickingOrdersCount Picking • $readyOrdersCount Ready", Color(0xFF0099FF), Modifier.weight(1f))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard("PARTS SOLD", "1,840 Units", "Brakes & Batteries top category", Color.White, Modifier.weight(1f))
            MetricCard("STORES ONLINE", "50 / 50", "Store #4821 Active", Color(0xFF00CC66), Modifier.weight(1f))
        }

        // HQ Live Alerts
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("REAL-TIME SYSTEM ALERTS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFD52B1E), modifier = Modifier.size(18.dp))
                    Text("LOW STOCK: Duralast Gold Battery BT-8421 at Store #1932 (3 units remaining)", color = Color.LightGray, fontSize = 12.sp)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccessTime, contentDescription = null, tint = Color(0xFFFF6B00), modifier = Modifier.size(18.dp))
                    Text("PICKUP SURGE: Store #4821 counter has $readyOrdersCount orders awaiting customer arrival", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }

        // Recent Audit Log Entries
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("RECENT AUDIT LOG ACTIONS", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                auditLogs.take(3).forEach { log ->
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${log.userRole}: ${log.action}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(log.timestamp, color = Color.DarkGray, fontSize = 11.sp)
                        }
                        Text("${log.objectName} (${log.previousValue} → ${log.newValue})", color = Color.Gray, fontSize = 11.sp)
                    }
                    Divider(color = Color(0xFF2E2E2E))
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String, valueColor: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = valueColor, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(subtitle, color = Color.LightGray, fontSize = 10.sp)
        }
    }
}
