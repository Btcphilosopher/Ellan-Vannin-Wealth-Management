package com.example.ui.hq

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AutoZoneViewModel

@Composable
fun HQCommercialScreen(viewModel: AutoZoneViewModel) {
    val commercialAccounts by viewModel.allCommercialAccounts.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF141414))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("COMMERCIAL B2B PROGRAM", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(commercialAccounts) { acc ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(acc.companyName, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Acc #${acc.accountNumber}", color = Color(0xFFD52B1E), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Credit Limit", color = Color.Gray, fontSize = 11.sp)
                                Text("\$${acc.creditLimit}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Open Balance", color = Color.Gray, fontSize = 11.sp)
                                Text("\$${acc.openBalance}", color = Color(0xFFFF6B00), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Text("Account Manager: ${acc.accountManager} • Top Category: ${acc.topPurchasedCategory}", color = Color.LightGray, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun HQAuditLogScreen(viewModel: AutoZoneViewModel) {
    val logs by viewModel.allAuditLogs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF141414))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("SYSTEM AUDIT LOG TRAIL", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(logs) { log ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${log.timestamp} • ${log.userRole}", color = Color(0xFFD52B1E), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(log.action, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(log.objectName, color = Color.LightGray, fontSize = 12.sp)
                        Text("Prev: ${log.previousValue} → New: ${log.newValue}", color = Color.Gray, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
