package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.customer.*
import com.example.ui.hq.*
import com.example.ui.viewmodel.*

@Composable
fun MainAppContainer(viewModel: AutoZoneViewModel) {
    val currentMode by viewModel.currentMode.collectAsState()
    val customerScreen by viewModel.customerScreen.collectAsState()
    val hqScreen by viewModel.hqScreen.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()
    val activeVehicle by viewModel.selectedVehicle.collectAsState()

    Scaffold(
        topBar = {
            AutoZoneTopHeader(
                currentMode = currentMode,
                activeVehicle = activeVehicle,
                cartCount = cartItems.sumOf { it.quantity },
                onModeChange = { viewModel.setAppMode(it) },
                onCartClick = {
                    viewModel.setAppMode(AppMode.CUSTOMER_APP)
                    viewModel.navigateCustomer(CustomerScreen.CART)
                }
            )
        },
        bottomBar = {
            if (currentMode == AppMode.CUSTOMER_APP) {
                CustomerBottomNavigation(
                    currentScreen = customerScreen,
                    cartCount = cartItems.sumOf { it.quantity },
                    onNavigate = { viewModel.navigateCustomer(it) }
                )
            } else {
                HQBottomNavigation(
                    currentScreen = hqScreen,
                    onNavigate = { viewModel.navigateHQ(it) }
                )
            }
        },
        containerColor = Color(0xFF121212)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (currentMode == AppMode.CUSTOMER_APP) {
                when (customerScreen) {
                    CustomerScreen.HOME -> CustomerHomeScreen(viewModel)
                    CustomerScreen.MY_VEHICLE -> VehicleGarageScreen(viewModel)
                    CustomerScreen.SHOP_PARTS, CustomerScreen.PART_SEARCH -> ShopAndSearchScreen(viewModel)
                    CustomerScreen.PRODUCT_DETAIL -> ProductDetailScreen(viewModel)
                    CustomerScreen.CART -> CartScreen(viewModel)
                    CustomerScreen.ORDER_TRACKER -> OrderTrackerScreen(viewModel)
                    CustomerScreen.FIX_FINDER -> FixFinderScreen(viewModel)
                    CustomerScreen.BATTERY_CHECK -> BatteryTesterScreen(viewModel)
                    CustomerScreen.STORE_FINDER -> StoreFinderScreen(viewModel)
                    CustomerScreen.LOAN_TOOL -> LoanAToolScreen(viewModel)
                    CustomerScreen.REPAIR_HELP -> RepairHelpScreen(viewModel)
                    CustomerScreen.REPAIR_GUIDE_DETAIL -> RepairGuideDetailScreen(viewModel)
                    CustomerScreen.REWARDS -> RewardsScreen(viewModel)
                    CustomerScreen.WARRANTIES -> WarrantiesScreen(viewModel)
                    else -> CustomerHomeScreen(viewModel)
                }
            } else {
                when (hqScreen) {
                    HQScreen.DASHBOARD -> HQDashboardScreen(viewModel)
                    HQScreen.ORDERS -> HQOrdersScreen(viewModel)
                    HQScreen.PRODUCTS -> HQProductsScreen(viewModel)
                    HQScreen.FITMENT -> HQFitmentScreen(viewModel)
                    HQScreen.INVENTORY -> HQInventoryScreen(viewModel)
                    HQScreen.TRANSFERS -> HQTransfersScreen(viewModel)
                    HQScreen.COMMERCIAL -> HQCommercialScreen(viewModel)
                    HQScreen.AUDIT_LOG -> HQAuditLogScreen(viewModel)
                    else -> HQDashboardScreen(viewModel)
                }
            }
        }
    }
}

@Composable
private fun AutoZoneTopHeader(
    currentMode: AppMode,
    activeVehicle: com.example.data.models.VehicleEntity?,
    cartCount: Int,
    onModeChange: (AppMode) -> Unit,
    onCartClick: () -> Unit
) {
    Surface(
        color = Color(0xFF1A1A1A),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333333))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Logo & Primary Mode Switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // AutoZone Logo Brand Badge
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(color = Color(0xFFD52B1E), shape = RoundedCornerShape(4.dp)) {
                        Text(
                            text = "AUTOZONE",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Text(".OS", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                }

                // App Switcher Segmented Button: CUSTOMER vs HQ
                Row(
                    modifier = Modifier
                        .background(Color(0xFF282828), shape = RoundedCornerShape(20.dp))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    val isCust = currentMode == AppMode.CUSTOMER_APP
                    Surface(
                        color = if (isCust) Color(0xFFD52B1E) else Color.Transparent,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.clickable { onModeChange(AppMode.CUSTOMER_APP) }
                    ) {
                        Text("CUSTOMER", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }

                    val isHq = currentMode == AppMode.AUTOZONE_HQ
                    Surface(
                        color = if (isHq) Color(0xFFFF6B00) else Color.Transparent,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.clickable { onModeChange(AppMode.AUTOZONE_HQ) }
                    ) {
                        Text("HQ OS", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
            }

            // Sub-header Info Chip Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentMode == AppMode.CUSTOMER_APP) {
                    if (activeVehicle != null) {
                        Surface(color = Color(0xFF282828), shape = RoundedCornerShape(12.dp)) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = Color(0xFFD52B1E), modifier = Modifier.size(14.dp))
                                Text("${activeVehicle.year} ${activeVehicle.make} ${activeVehicle.model}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Text("No vehicle selected", color = Color.Gray, fontSize = 11.sp)
                    }

                    // Cart Icon
                    IconButton(onClick = onCartClick, modifier = Modifier.size(36.dp)) {
                        BadgedBox(badge = {
                            if (cartCount > 0) {
                                Badge(containerColor = Color(0xFFD52B1E)) { Text("$cartCount", color = Color.White) }
                            }
                        }) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = "Cart", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                } else {
                    Text("AutoZone Enterprise Retail & Inventory Network", color = Color.Gray, fontSize = 11.sp)
                    Surface(color = Color(0xFF00CC66).copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                        Text("MEMPHIS DC #4821", color = Color(0xFF00CC66), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerBottomNavigation(
    currentScreen: CustomerScreen,
    cartCount: Int,
    onNavigate: (CustomerScreen) -> Unit
) {
    NavigationBar(
        containerColor = Color(0xFF1A1A1A),
        contentColor = Color.White,
        modifier = Modifier.navigationBarsPadding()
    ) {
        NavigationBarItem(
            selected = currentScreen == CustomerScreen.HOME,
            onClick = { onNavigate(CustomerScreen.HOME) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Home", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFD52B1E), indicatorColor = Color(0xFF282828))
        )
        NavigationBarItem(
            selected = currentScreen == CustomerScreen.MY_VEHICLE,
            onClick = { onNavigate(CustomerScreen.MY_VEHICLE) },
            icon = { Icon(Icons.Default.DirectionsCar, contentDescription = "Garage") },
            label = { Text("Garage", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFD52B1E), indicatorColor = Color(0xFF282828))
        )
        NavigationBarItem(
            selected = currentScreen == CustomerScreen.SHOP_PARTS || currentScreen == CustomerScreen.PART_SEARCH,
            onClick = { onNavigate(CustomerScreen.SHOP_PARTS) },
            icon = { Icon(Icons.Default.Build, contentDescription = "Shop") },
            label = { Text("Shop", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFD52B1E), indicatorColor = Color(0xFF282828))
        )
        NavigationBarItem(
            selected = currentScreen == CustomerScreen.REPAIR_HELP,
            onClick = { onNavigate(CustomerScreen.REPAIR_HELP) },
            icon = { Icon(Icons.Default.MenuBook, contentDescription = "Repair") },
            label = { Text("Repair", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFD52B1E), indicatorColor = Color(0xFF282828))
        )
        NavigationBarItem(
            selected = currentScreen == CustomerScreen.CART,
            onClick = { onNavigate(CustomerScreen.CART) },
            icon = {
                BadgedBox(badge = {
                    if (cartCount > 0) Badge(containerColor = Color(0xFFD52B1E)) { Text("$cartCount") }
                }) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = "Cart")
                }
            },
            label = { Text("Cart", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFD52B1E), indicatorColor = Color(0xFF282828))
        )
    }
}

@Composable
private fun HQBottomNavigation(
    currentScreen: HQScreen,
    onNavigate: (HQScreen) -> Unit
) {
    NavigationBar(
        containerColor = Color(0xFF141414),
        contentColor = Color.White,
        modifier = Modifier.navigationBarsPadding()
    ) {
        NavigationBarItem(
            selected = currentScreen == HQScreen.DASHBOARD,
            onClick = { onNavigate(HQScreen.DASHBOARD) },
            icon = { Icon(Icons.Default.Dashboard, contentDescription = "Overview") },
            label = { Text("Overview", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFFF6B00), indicatorColor = Color(0xFF282828))
        )
        NavigationBarItem(
            selected = currentScreen == HQScreen.ORDERS,
            onClick = { onNavigate(HQScreen.ORDERS) },
            icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Orders") },
            label = { Text("Orders", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFFF6B00), indicatorColor = Color(0xFF282828))
        )
        NavigationBarItem(
            selected = currentScreen == HQScreen.PRODUCTS,
            onClick = { onNavigate(HQScreen.PRODUCTS) },
            icon = { Icon(Icons.Default.Inventory2, contentDescription = "Catalog") },
            label = { Text("Catalog", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFFF6B00), indicatorColor = Color(0xFF282828))
        )
        NavigationBarItem(
            selected = currentScreen == HQScreen.FITMENT,
            onClick = { onNavigate(HQScreen.FITMENT) },
            icon = { Icon(Icons.Default.Engineering, contentDescription = "Fitment") },
            label = { Text("Fitment", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFFF6B00), indicatorColor = Color(0xFF282828))
        )
        NavigationBarItem(
            selected = currentScreen == HQScreen.COMMERCIAL,
            onClick = { onNavigate(HQScreen.COMMERCIAL) },
            icon = { Icon(Icons.Default.Business, contentDescription = "B2B") },
            label = { Text("Commercial", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFFF6B00), indicatorColor = Color(0xFF282828))
        )
        NavigationBarItem(
            selected = currentScreen == HQScreen.AUDIT_LOG,
            onClick = { onNavigate(HQScreen.AUDIT_LOG) },
            icon = { Icon(Icons.Default.History, contentDescription = "Audit") },
            label = { Text("Audit Log", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color(0xFFFF6B00), indicatorColor = Color(0xFF282828))
        )
    }
}
