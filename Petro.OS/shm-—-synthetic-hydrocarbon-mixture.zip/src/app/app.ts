import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
  computed,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ShmService } from './services/shm.service';
import {
  ComponentData,
  CompositionBasis,
  MixtureState,
  PropertyConstraint,
  OptimisationResult,
  MonteCarloResult,
  TornadoItem,
  ChemicalFamily,
} from './models/shm.models';

type TabId =
  | 'overview'
  | 'components'
  | 'streams'
  | 'mixture'
  | 'thermo'
  | 'phase'
  | 'properties'
  | 'pseudo'
  | 'optimisation'
  | 'economics'
  | 'sensitivity'
  | 'uncertainty'
  | 'lab'
  | 'registry'
  | 'scenarios'
  | 'reports'
  | 'cli';

@Component({
  selector: 'app-root',
  imports: [CommonModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class App {
  readonly shm = inject(ShmService);

  // Active navigation tab
  readonly activeTab = signal<TabId>('overview');

  // Component library filters
  readonly componentSearch = signal<string>('');
  readonly selectedFamilyFilter = signal<string>('ALL');

  // Filtered components
  readonly filteredComponents = computed(() => {
    const list = this.shm.components();
    const q = this.componentSearch().toLowerCase();
    const fam = this.selectedFamilyFilter();

    return list.filter((c) => {
      const matchQ =
        !q ||
        c.component_id.toLowerCase().includes(q) ||
        c.component_name.toLowerCase().includes(q) ||
        c.chemical_formula.toLowerCase().includes(q);
      const matchFam = fam === 'ALL' || c.chemical_family === fam;
      return matchQ && matchFam;
    });
  });

  // Selected component in details inspector
  readonly inspectedComponent = signal<ComponentData | null>(null);

  // Mixture Workspace form signals
  readonly mixNameInput = signal<string>('Stabilised Light Condensate Blend');
  readonly mixBasisInput = signal<CompositionBasis>('mass');
  readonly mixTempInput = signal<number>(298.15); // K
  readonly mixPressInput = signal<number>(1.01325); // bar
  readonly mixQtyInput = signal<number>(10000); // kg

  // Selected components in the mixture builder
  readonly builderRows = signal<{ component_id: string; fraction: number }[]>([
    { component_id: 'iC5', fraction: 0.22 },
    { component_id: 'nC5', fraction: 0.26 },
    { component_id: 'nC6', fraction: 0.32 },
    { component_id: 'BENZ', fraction: 0.08 },
    { component_id: 'TOL', fraction: 0.12 },
  ]);

  // Pseudo-component characterisation form
  readonly pseudoId = signal<string>('PSEUDO_HVY');
  readonly pseudoName = signal<string>('Heavy Gas Oil Cut (580-640 K)');
  readonly pseudoTbK = signal<number>(610.0);
  readonly pseudoSG = signal<number>(0.845);
  readonly pseudoSuccessMsg = signal<string | null>(null);

  // Optimisation Engine State
  readonly optObjective = signal<'MIN_COST' | 'TARGET_COMPOSITION' | 'MAX_MARGIN'>('MIN_COST');
  readonly optTargetQty = signal<number>(5000);
  readonly optCandidates = signal<string[]>([
    'H2',
    'iC5',
    'nC5',
    'nC6',
    '2MP',
    'nC7',
    'BENZ',
    'TOL',
    'COND_CUT',
  ]);
  readonly optResult = signal<OptimisationResult | null>(null);
  readonly optRunning = signal<boolean>(false);

  // Monte Carlo simulation state
  readonly mcSamplesCount = signal<number>(300);
  readonly mcCompNoise = signal<number>(0.04);
  readonly mcTempNoise = signal<number>(1.5);
  readonly mcResult = signal<MonteCarloResult | null>(null);
  readonly mcRunning = signal<boolean>(false);

  // Sensitivity State
  readonly sensitivityPerturbation = signal<number>(0.15);
  readonly tornadoData = computed<TornadoItem[]>(() => {
    return this.shm.calculateTornado(this.shm.activeMixture(), this.sensitivityPerturbation());
  });

  // CLI Terminal state
  readonly cliInput = signal<string>('shm properties calculate');
  readonly cliHistory = signal<{ command: string; output: string }[]>([
    {
      command: 'shm components list',
      output: this.shm.executeCLICommand('shm components list'),
    },
    {
      command: 'shm properties calculate',
      output: this.shm.executeCLICommand('shm properties calculate'),
    },
  ]);

  // Notification Toast message
  readonly notification = signal<{ text: string; type: 'success' | 'info' | 'warn' } | null>(null);

  constructor() {
    // Select first component as default inspected
    const first = this.shm.components()[0];
    if (first) this.inspectedComponent.set(first);

    // Run initial optimization and Monte Carlo results
    this.runOptimization();
    this.runMonteCarloSim();
  }

  showNotification(text: string, type: 'success' | 'info' | 'warn' = 'info') {
    this.notification.set({ text, type });
    setTimeout(() => {
      this.notification.set(null);
    }, 4000);
  }

  setTab(tab: TabId) {
    this.activeTab.set(tab);
  }

  inspectComponent(c: ComponentData) {
    this.inspectedComponent.set(c);
  }

  selectModel(modelId: string) {
    this.shm.selectedModelId.set(modelId);
    this.showNotification(`Active thermodynamic model switched to ${modelId}`, 'info');
  }

  selectScenario(scenarioId: string) {
    this.shm.activeScenarioId.set(scenarioId);
    const scn = this.shm.scenarios().find((s) => s.scenario_id === scenarioId);
    if (scn) {
      this.shm.selectedModelId.set(scn.model_id);
      this.showNotification(`Scenario activated: ${scn.name}`, 'info');
    }
  }

  // Preset mixture archetypes
  loadArchetype(type: string) {
    if (type === 'associated_gas') {
      this.mixNameInput.set('Associated Natural Gas Stream');
      this.mixBasisInput.set('mole');
      this.mixTempInput.set(300.15);
      this.mixPressInput.set(22.0);
      this.mixQtyInput.set(15000);
      this.builderRows.set([
        { component_id: 'C1', fraction: 0.72 },
        { component_id: 'C2', fraction: 0.145 },
        { component_id: 'C3', fraction: 0.085 },
        { component_id: 'iC4', fraction: 0.022 },
        { component_id: 'nC4', fraction: 0.028 },
      ]);
    } else if (type === 'light_naphtha') {
      this.mixNameInput.set('Hydrotreated Light Naphtha');
      this.mixBasisInput.set('mass');
      this.mixTempInput.set(298.15);
      this.mixPressInput.set(1.01325);
      this.mixQtyInput.set(10000);
      this.builderRows.set([
        { component_id: 'iC5', fraction: 0.12 },
        { component_id: 'nC5', fraction: 0.14 },
        { component_id: 'nC6', fraction: 0.26 },
        { component_id: '2MP', fraction: 0.22 },
        { component_id: 'CP', fraction: 0.08 },
        { component_id: 'CH', fraction: 0.15 },
        { component_id: 'BENZ', fraction: 0.03 },
      ]);
    } else if (type === 'condensate') {
      this.mixNameInput.set('Stabilised Light Condensate Blend');
      this.mixBasisInput.set('mass');
      this.mixTempInput.set(303.15);
      this.mixPressInput.set(2.0);
      this.mixQtyInput.set(12000);
      this.builderRows.set([
        { component_id: 'iC5', fraction: 0.22 },
        { component_id: 'nC5', fraction: 0.26 },
        { component_id: 'nC6', fraction: 0.32 },
        { component_id: 'BENZ', fraction: 0.08 },
        { component_id: 'TOL', fraction: 0.12 },
      ]);
    } else if (type === 'olefins') {
      this.mixNameInput.set('Light Olefin Polymerization Feed');
      this.mixBasisInput.set('mole');
      this.mixTempInput.set(275.15);
      this.mixPressInput.set(16.5);
      this.mixQtyInput.set(8000);
      this.builderRows.set([
        { component_id: 'C2=', fraction: 0.45 },
        { component_id: 'C3=', fraction: 0.35 },
        { component_id: '1C4=', fraction: 0.12 },
        { component_id: 'iC4=', fraction: 0.08 },
      ]);
    } else if (type === 'middle_distillate') {
      this.mixNameInput.set('Synthetic Gas-to-Liquids Middle Distillate');
      this.mixBasisInput.set('mass');
      this.mixTempInput.set(325.15);
      this.mixPressInput.set(1.5);
      this.mixQtyInput.set(20000);
      this.builderRows.set([
        { component_id: 'nC7', fraction: 0.1 },
        { component_id: 'nC8', fraction: 0.3 },
        { component_id: 'nC9', fraction: 0.25 },
        { component_id: 'nC10', fraction: 0.15 },
        { component_id: 'HEAVY_NAPH', fraction: 0.12 },
        { component_id: 'KERO_CUT', fraction: 0.08 },
      ]);
    } else if (type === 'hydrotreater_gas') {
      this.mixNameInput.set('Hydrotreater Recycle Gas (H2-Rich)');
      this.mixBasisInput.set('mole');
      this.mixTempInput.set(318.15);
      this.mixPressInput.set(45.0);
      this.mixQtyInput.set(5000);
      this.builderRows.set([
        { component_id: 'H2', fraction: 0.85 },
        { component_id: 'C1', fraction: 0.09 },
        { component_id: 'C2', fraction: 0.04 },
        { component_id: 'C3', fraction: 0.02 },
      ]);
    }
    this.rebuildMixture();
    this.showNotification(`Loaded archetype: ${this.mixNameInput()}`, 'info');
  }

  // Builder row management
  addBuilderRow(componentId: string) {
    const curr = this.builderRows();
    if (curr.some((r) => r.component_id === componentId)) {
      this.showNotification(`Component ${componentId} is already in the mixture.`, 'warn');
      return;
    }
    this.builderRows.set([...curr, { component_id: componentId, fraction: 0.05 }]);
    this.normaliseBuilderFractions();
  }

  removeBuilderRow(index: number) {
    const curr = this.builderRows();
    if (curr.length <= 1) {
      this.showNotification('Mixture must contain at least one component.', 'warn');
      return;
    }
    const updated = curr.filter((_, i) => i !== index);
    this.builderRows.set(updated);
    this.normaliseBuilderFractions();
  }

  updateBuilderFraction(index: number, valStr: string) {
    const val = parseFloat(valStr) || 0;
    const curr = [...this.builderRows()];
    curr[index] = { ...curr[index], fraction: Math.max(0, val) };
    this.builderRows.set(curr);
  }

  normaliseBuilderFractions() {
    const curr = this.builderRows();
    const sum = curr.reduce((acc, r) => acc + r.fraction, 0);
    if (sum <= 0) return;
    const norm = curr.map((r) => ({
      ...r,
      fraction: Math.round((r.fraction / sum) * 10000) / 10000,
    }));
    this.builderRows.set(norm);
    this.rebuildMixture();
  }

  rebuildMixture() {
    const compIds = this.builderRows().map((r) => r.component_id);
    const fracs = this.builderRows().map((r) => r.fraction);

    const mix = this.shm.constructMixture(
      this.mixNameInput(),
      compIds,
      fracs,
      this.mixBasisInput(),
      this.mixTempInput(),
      this.mixPressInput(),
      this.mixQtyInput(),
      'kg'
    );
    this.shm.activeMixture.set(mix);
    this.showNotification('Mixture updated & recalculated across all property models.', 'success');
  }

  // Pseudo fraction characterisation
  characteriseNewFraction() {
    const id = this.pseudoId().trim().toUpperCase();
    const name = this.pseudoName().trim();
    const tb = this.pseudoTbK();
    const sg = this.pseudoSG();

    if (!id || !name) {
      this.showNotification('Please provide a valid ID and Name for the cut.', 'warn');
      return;
    }

    const created = this.shm.characterisePetroleumFraction(id, name, tb, sg);
    this.inspectedComponent.set(created);
    this.pseudoSuccessMsg.set(
      `Pseudo-component ${created.component_id} successfully characterized via Lee-Kesler & Riazi-Daubert! Mw = ${created.molecular_weight} g/mol, Tc = ${created.critical_temperature} K, Pc = ${created.critical_pressure} bar, omega = ${created.acentric_factor}.`
    );
    this.showNotification(`Characterized and registered pseudo-component ${id}`, 'success');
  }

  // Toggle optimization candidate
  toggleOptCandidate(cid: string) {
    const curr = this.optCandidates();
    if (curr.includes(cid)) {
      if (curr.length <= 2) {
        this.showNotification('Keep at least 2 candidate components for optimization.', 'warn');
        return;
      }
      this.optCandidates.set(curr.filter((c) => c !== cid));
    } else {
      this.optCandidates.set([...curr, cid]);
    }
  }

  runOptimization() {
    this.optRunning.set(true);
    setTimeout(() => {
      const res = this.shm.optimiseFormulation(
        this.optCandidates(),
        this.optTargetQty(),
        this.optObjective(),
        this.shm.constraints()
      );
      this.optResult.set(res);
      this.optRunning.set(false);
      this.showNotification('Formulation optimization completed successfully.', 'success');
    }, 250);
  }

  applyOptResultToMixture() {
    const opt = this.optResult();
    if (!opt) return;

    const compIds = opt.components.map((c) => c.component_id);
    const fracs = opt.components.map((c) => c.mass_fraction);

    this.mixNameInput.set(`Optimised Formulation (${opt.objective_type})`);
    this.mixBasisInput.set('mass');
    this.mixQtyInput.set(opt.total_mass_kg);
    this.builderRows.set(
      opt.components.map((c) => ({
        component_id: c.component_id,
        fraction: c.mass_fraction,
      }))
    );
    this.rebuildMixture();
    this.setTab('mixture');
    this.showNotification('Optimal formulation loaded into Mixture Workspace.', 'success');
  }

  runMonteCarloSim() {
    this.mcRunning.set(true);
    setTimeout(() => {
      const res = this.shm.runMonteCarlo(
        this.shm.activeMixture(),
        this.mcSamplesCount(),
        this.mcCompNoise(),
        this.mcTempNoise()
      );
      this.mcResult.set(res);
      this.mcRunning.set(false);
      this.showNotification(`Monte Carlo simulation completed (${this.mcSamplesCount()} iterations).`, 'success');
    }, 200);
  }

  // CLI execution
  runCLI(cmd?: string) {
    const toExec = cmd || this.cliInput();
    if (!toExec.trim()) return;

    const out = this.shm.executeCLICommand(toExec);
    this.cliHistory.update((h) => [...h, { command: toExec, output: out }]);
    this.cliInput.set('');
  }

  clearCLI() {
    this.cliHistory.set([]);
  }

  // Format helpers
  formatNum(num: number | undefined | null, decimals = 2): string {
    if (num === undefined || num === null || isNaN(num)) return '—';
    return Number(num).toLocaleString(undefined, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
  }

  // Download Quarto document
  downloadQuartoReport() {
    const mix = this.shm.activeMixture();
    const props = this.shm.activeProperties();
    const econ = this.shm.activeEconomics();

    const reportContent = `---
title: "SHM Hydrocarbon Mixture Characterisation & Thermodynamic Report"
subtitle: "R-Native Hydrocarbon Formulation, Property Modelling, Optimisation & Economics Platform"
format:
  html:
    toc: true
    theme: cosmo
    embed-resources: true
date: "${new Date().toISOString().split('T')[0]}"
author: "SHM Computational Hydrocarbon System"
---

# 1. Executive Summary & Provenance
- Mixture: **${mix.mixture_name}** (${mix.mixture_id})
- Thermodynamic Model: **${props.thermodynamic_model}**
- Temperature: **${mix.temperature_K} K** (${(mix.temperature_K - 273.15).toFixed(1)} °C)
- Pressure: **${mix.pressure_bar} bar**
- Total Mass: **${mix.total_mass_kg} kg**
- Mixture Molecular Weight: **${props.molecular_weight_g_mol.toFixed(3)} g/mol**
- Liquid Density (Rackett): **${props.liquid_density_kg_m3.toFixed(2)} kg/m³**
- True Vapour Pressure (TVP): **${props.true_vapour_pressure_bar.toFixed(4)} bar**
- Phase State: **${props.phase_state}** (Vapour fraction β = ${props.vapour_fraction_beta.toFixed(4)})
- Data Status: **${props.data_status}**

# 2. Compositional Accounting
| Component ID | Name | Formula | Family | Mole % | Mass % | Mass (kg) | Cost ($/kg) | Provenance |
|---|---|---|---|---|---|---|---|---|
${mix.components.map((c) => `| ${c.component_id} | ${c.component_name} | ${c.chemical_formula} | ${c.chemical_family} | ${(c.mole_fraction * 100).toFixed(2)}% | ${(c.mass_fraction * 100).toFixed(2)}% | ${c.mass_kg.toFixed(1)} | $${c.cost_per_kg.toFixed(2)} | [${c.data_status}] |`).join('\n')}

# 3. Thermophysical Properties
- Gas Density (Real EOS): **${props.vapour_density_kg_m3.toFixed(3)} kg/m³**
- Compressibility Factor (Z_vap): **${props.compressibility_Z_vap.toFixed(4)}**
- Compressibility Factor (Z_liq): **${props.compressibility_Z_liq.toFixed(4)}**
- Specific Gravity (60°F): **${props.specific_gravity_60F.toFixed(4)}**
- Bubble Point Pressure: **${props.bubble_pressure_bar.toFixed(4)} bar**
- Dew Point Pressure: **${props.dew_pressure_bar.toFixed(4)} bar**
- Liquid Heat Capacity (Cp): **${props.heat_capacity_liquid_kJ_kg_K.toFixed(3)} kJ/(kg·K)**
- Dynamic Viscosity: **${props.viscosity_liquid_mPa_s.toFixed(3)} mPa·s**
- Thermal Conductivity: **${props.thermal_conductivity_W_m_K.toFixed(4)} W/(m·K)**
- Material Balance Residual: **${props.material_balance_residual.toExponential(3)}**

# 4. Economic Statement & Margin Analysis
- Total Material Cost: **$${econ.total_material_cost.toFixed(2)} USD**
- Material Cost per kg: **$${econ.material_cost_per_kg.toFixed(4)} USD/kg**
- Operating & Blending Cost: **$${(econ.processing_cost + econ.transport_cost + econ.storage_cost).toFixed(2)} USD**
- Total Production Cost: **$${econ.total_production_cost.toFixed(2)} USD**
- Gross Revenue: **$${econ.gross_revenue.toFixed(2)} USD**
- Contribution Margin: **$${econ.contribution_margin.toFixed(2)} USD** (${econ.margin_percentage.toFixed(2)}%)
`;

    const blob = new Blob([reportContent], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SHM_Report_${mix.mixture_id}.qmd`;
    a.click();
    URL.revokeObjectURL(url);
    this.showNotification('Quarto reproducible report downloaded.', 'success');
  }

  // Export R Package source archive reference
  downloadRCodeSnippet() {
    const mix = this.shm.activeMixture();
    const compStr = mix.components.map((c) => `"${c.component_id}"`).join(', ');
    const fracStr = mix.components.map((c) => c.mass_fraction.toFixed(4)).join(', ');

    const rCode = `# ==============================================================================
# SHM — Synthetic Hydrocarbon Mixture Platform (R Script)
# Generated automatically from SHM Web Workbench
# ==============================================================================

library(shm)

# 1. Define Mixture
mix <- shm_create_mixture(
  name = "${mix.mixture_name}",
  component_ids = c(${compStr}),
  fractions = c(${fracStr}),
  basis = "${mix.basis_specified}",
  temperature = ${mix.temperature_K},
  pressure = ${mix.pressure_bar},
  total_quantity = ${mix.total_mass_kg},
  quantity_unit = "kg"
)

# 2. Predict Physical Properties with Peng-Robinson EOS
props <- shm_predict_properties(mix, model_id = "${this.shm.selectedModelId()}")
print(props)

# 3. Two-Phase Isothermal/Isobaric Flash Equilibrium
flash <- shm_rachford_rice_flash(mix, T = ${mix.temperature_K}, P = ${mix.pressure_bar})
print(flash)

# 4. Economic Statement
econ <- shm_economic_analysis(mix)
print(econ)

# 5. Monte Carlo Robustness Assessment
mc <- shm_monte_carlo_uncertainty(mix, n_samples = 500)
print(mc)
`;

    const blob = new Blob([rCode], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `shm_simulation_${mix.mixture_id}.R`;
    a.click();
    URL.revokeObjectURL(url);
    this.showNotification('R script exported successfully.', 'success');
  }
}
