import { Injectable, signal, computed } from '@angular/core';
import {
  ComponentData,
  StreamData,
  MixtureState,
  MixtureComponentRow,
  CompositionBasis,
  ThermoModelMetadata,
  FlashResult,
  MixturePropertiesResult,
  PropertyConstraint,
  ConstraintEvaluationRow,
  OptimisationResult,
  EconomicResult,
  LabValidationSummary,
  LabMeasurementRow,
  MonteCarloResult,
  TornadoItem,
  ScenarioDefinition,
} from '../models/shm.models';

const R_GAS = 83.14462618; // bar * cm3 / (mol * K)
const R_SI = 8.314462618; // J / (mol * K)

@Injectable({
  providedIn: 'root',
})
export class ShmService {
  // 32 Built-in Pure Hydrocarbons and Characterized Pseudo-Fractions
  readonly components = signal<ComponentData[]>([
    // Molecular Hydrogen
    {
      component_id: 'H2',
      component_name: 'Hydrogen',
      chemical_formula: 'H2',
      CAS_number: '1333-74-0',
      chemical_family: 'Inorganic Gas',
      component_type: 'Pure',
      molecular_weight: 2.016,
      critical_temperature: 33.19,
      critical_pressure: 12.97,
      critical_compressibility: 0.304,
      acentric_factor: -0.216,
      normal_boiling_point: 20.28,
      density_std: 70.85,
      antoine_A: 3.543,
      antoine_B: 99.3,
      antoine_C: 7.3,
      cost_per_kg: 2.20,
      data_status: 'MEASURED',
      description: 'Molecular hydrogen; critical in hydroprocessing, hydrogenation, and synthetic hydrocarbon upgrading.',
    },
    // Light Hydrocarbons
    {
      component_id: 'C1',
      component_name: 'Methane',
      chemical_formula: 'CH4',
      CAS_number: '74-82-8',
      chemical_family: 'Paraffin',
      component_type: 'Pure',
      molecular_weight: 16.043,
      critical_temperature: 190.56,
      critical_pressure: 45.99,
      critical_compressibility: 0.288,
      acentric_factor: 0.011,
      normal_boiling_point: 111.66,
      density_std: 422.8,
      antoine_A: 3.9895,
      antoine_B: 443.028,
      antoine_C: -0.49,
      cost_per_kg: 0.45,
      data_status: 'MEASURED',
      description: 'Primary component of natural gas; highly volatile light alkane.',
    },
    {
      component_id: 'C2',
      component_name: 'Ethane',
      chemical_formula: 'C2H6',
      CAS_number: '74-84-0',
      chemical_family: 'Paraffin',
      component_type: 'Pure',
      molecular_weight: 30.07,
      critical_temperature: 305.32,
      critical_pressure: 48.72,
      critical_compressibility: 0.279,
      acentric_factor: 0.099,
      normal_boiling_point: 184.55,
      density_std: 544.0,
      antoine_A: 3.93835,
      antoine_B: 659.739,
      antoine_C: -16.719,
      cost_per_kg: 0.52,
      data_status: 'MEASURED',
      description: 'Light paraffin; petrochemical cracker feedstock.',
    },
    {
      component_id: 'C3',
      component_name: 'Propane',
      chemical_formula: 'C3H8',
      CAS_number: '74-98-6',
      chemical_family: 'Paraffin',
      component_type: 'Pure',
      molecular_weight: 44.097,
      critical_temperature: 369.83,
      critical_pressure: 42.48,
      critical_compressibility: 0.276,
      acentric_factor: 0.152,
      normal_boiling_point: 231.05,
      density_std: 582.0,
      antoine_A: 3.92828,
      antoine_B: 803.997,
      antoine_C: -26.11,
      cost_per_kg: 0.68,
      data_status: 'MEASURED',
      description: 'LPG component, high vapour pressure gas.',
    },
    {
      component_id: 'iC4',
      component_name: 'Isobutane',
      chemical_formula: 'C4H10',
      CAS_number: '75-28-5',
      chemical_family: 'Isoparaffin',
      component_type: 'Pure',
      molecular_weight: 58.123,
      critical_temperature: 407.82,
      critical_pressure: 36.29,
      critical_compressibility: 0.282,
      acentric_factor: 0.181,
      normal_boiling_point: 261.42,
      density_std: 593.8,
      antoine_A: 3.97786,
      antoine_B: 931.43,
      antoine_C: -33.62,
      cost_per_kg: 0.74,
      data_status: 'MEASURED',
      description: 'Branched butane; alkylation unit feed.',
    },
    {
      component_id: 'nC4',
      component_name: 'n-Butane',
      chemical_formula: 'C4H10',
      CAS_number: '106-97-8',
      chemical_family: 'Paraffin',
      component_type: 'Pure',
      molecular_weight: 58.123,
      critical_temperature: 425.12,
      critical_pressure: 37.96,
      critical_compressibility: 0.274,
      acentric_factor: 0.2,
      normal_boiling_point: 272.65,
      density_std: 601.2,
      antoine_A: 3.93266,
      antoine_B: 935.773,
      antoine_C: -34.361,
      cost_per_kg: 0.71,
      data_status: 'MEASURED',
      description: 'Normal butane; volatility modifier.',
    },
    // Paraffins & Isoparaffins
    {
      component_id: 'iC5',
      component_name: 'Isopentane',
      chemical_formula: 'C5H12',
      CAS_number: '78-78-4',
      chemical_family: 'Isoparaffin',
      component_type: 'Pure',
      molecular_weight: 72.15,
      critical_temperature: 460.35,
      critical_pressure: 33.81,
      critical_compressibility: 0.273,
      acentric_factor: 0.229,
      normal_boiling_point: 300.99,
      density_std: 620.1,
      antoine_A: 3.90895,
      antoine_B: 1022.69,
      antoine_C: -40.11,
      cost_per_kg: 0.82,
      data_status: 'MEASURED',
      description: 'Branched pentane; light liquid hydrocarbon.',
    },
    {
      component_id: 'nC5',
      component_name: 'n-Pentane',
      chemical_formula: 'C5H12',
      CAS_number: '109-66-0',
      chemical_family: 'Paraffin',
      component_type: 'Pure',
      molecular_weight: 72.15,
      critical_temperature: 469.7,
      critical_pressure: 33.7,
      critical_compressibility: 0.269,
      acentric_factor: 0.251,
      normal_boiling_point: 309.22,
      density_std: 626.2,
      antoine_A: 3.9892,
      antoine_B: 1070.61,
      antoine_C: -40.454,
      cost_per_kg: 0.79,
      data_status: 'MEASURED',
      description: 'Normal pentane; ambient liquid solvent.',
    },
    {
      component_id: 'nC6',
      component_name: 'n-Hexane',
      chemical_formula: 'C6H14',
      CAS_number: '110-54-3',
      chemical_family: 'Paraffin',
      component_type: 'Pure',
      molecular_weight: 86.177,
      critical_temperature: 507.6,
      critical_pressure: 30.25,
      critical_compressibility: 0.266,
      acentric_factor: 0.301,
      normal_boiling_point: 341.88,
      density_std: 659.4,
      antoine_A: 4.00266,
      antoine_B: 1171.53,
      antoine_C: -48.784,
      cost_per_kg: 0.85,
      data_status: 'MEASURED',
      description: 'Light paraffin solvent and condensate component.',
    },
    {
      component_id: '2MP',
      component_name: '2-Methylpentane',
      chemical_formula: 'C6H14',
      CAS_number: '107-83-5',
      chemical_family: 'Isoparaffin',
      component_type: 'Pure',
      molecular_weight: 86.177,
      critical_temperature: 497.7,
      critical_pressure: 30.4,
      critical_compressibility: 0.267,
      acentric_factor: 0.28,
      normal_boiling_point: 333.41,
      density_std: 653.2,
      antoine_A: 3.964,
      antoine_B: 1135.4,
      antoine_C: -46.8,
      cost_per_kg: 0.88,
      data_status: 'MEASURED',
      description: 'Isohexane isomer.',
    },
    {
      component_id: 'nC7',
      component_name: 'n-Heptane',
      chemical_formula: 'C7H16',
      CAS_number: '142-82-5',
      chemical_family: 'Paraffin',
      component_type: 'Pure',
      molecular_weight: 100.204,
      critical_temperature: 540.2,
      critical_pressure: 27.4,
      critical_compressibility: 0.261,
      acentric_factor: 0.35,
      normal_boiling_point: 371.57,
      density_std: 683.8,
      antoine_A: 4.02832,
      antoine_B: 1268.636,
      antoine_C: -56.199,
      cost_per_kg: 0.9,
      data_status: 'MEASURED',
      description: 'Primary reference standard hydrocarbon.',
    },
    {
      component_id: 'nC8',
      component_name: 'n-Octane',
      chemical_formula: 'C8H18',
      CAS_number: '111-65-9',
      chemical_family: 'Paraffin',
      component_type: 'Pure',
      molecular_weight: 114.231,
      critical_temperature: 568.7,
      critical_pressure: 24.9,
      critical_compressibility: 0.256,
      acentric_factor: 0.4,
      normal_boiling_point: 398.82,
      density_std: 702.5,
      antoine_A: 4.04867,
      antoine_B: 1355.126,
      antoine_C: -63.633,
      cost_per_kg: 0.95,
      data_status: 'MEASURED',
      description: 'Mid-range straight chain alkane.',
    },
    {
      component_id: 'iC8',
      component_name: 'Isooctane (2,2,4-TMP)',
      chemical_formula: 'C8H18',
      CAS_number: '540-84-1',
      chemical_family: 'Isoparaffin',
      component_type: 'Pure',
      molecular_weight: 114.231,
      critical_temperature: 543.8,
      critical_pressure: 25.7,
      critical_compressibility: 0.267,
      acentric_factor: 0.302,
      normal_boiling_point: 372.39,
      density_std: 691.9,
      antoine_A: 3.9367,
      antoine_B: 1257.84,
      antoine_C: -52.41,
      cost_per_kg: 1.05,
      data_status: 'MEASURED',
      description: 'Highly branched paraffin benchmark.',
    },
    {
      component_id: 'nC9',
      component_name: 'n-Nonane',
      chemical_formula: 'C9H20',
      CAS_number: '111-84-2',
      chemical_family: 'Paraffin',
      component_type: 'Pure',
      molecular_weight: 128.258,
      critical_temperature: 594.6,
      critical_pressure: 22.9,
      critical_compressibility: 0.252,
      acentric_factor: 0.444,
      normal_boiling_point: 423.97,
      density_std: 717.6,
      antoine_A: 4.0734,
      antoine_B: 1438.03,
      antoine_C: -71.48,
      cost_per_kg: 1.02,
      data_status: 'MEASURED',
      description: 'Heavy naphtha range alkane.',
    },
    {
      component_id: 'nC10',
      component_name: 'n-Decane',
      chemical_formula: 'C10H22',
      CAS_number: '124-18-5',
      chemical_family: 'Paraffin',
      component_type: 'Pure',
      molecular_weight: 142.285,
      critical_temperature: 617.7,
      critical_pressure: 21.1,
      critical_compressibility: 0.247,
      acentric_factor: 0.492,
      normal_boiling_point: 447.3,
      density_std: 730.0,
      antoine_A: 4.07857,
      antoine_B: 1501.268,
      antoine_C: -78.67,
      cost_per_kg: 1.1,
      data_status: 'MEASURED',
      description: 'Kerosene range paraffin.',
    },
    // Olefins
    {
      component_id: 'C2=',
      component_name: 'Ethylene',
      chemical_formula: 'C2H4',
      CAS_number: '74-85-1',
      chemical_family: 'Olefin',
      component_type: 'Pure',
      molecular_weight: 28.054,
      critical_temperature: 282.34,
      critical_pressure: 50.41,
      critical_compressibility: 0.281,
      acentric_factor: 0.087,
      normal_boiling_point: 169.42,
      density_std: 568.0,
      antoine_A: 3.91382,
      antoine_B: 589.43,
      antoine_C: -15.15,
      cost_per_kg: 0.65,
      data_status: 'MEASURED',
      description: 'Light unsaturated alkene gas.',
    },
    {
      component_id: 'C3=',
      component_name: 'Propylene',
      chemical_formula: 'C3H6',
      CAS_number: '115-07-1',
      chemical_family: 'Olefin',
      component_type: 'Pure',
      molecular_weight: 42.081,
      critical_temperature: 364.9,
      critical_pressure: 46.0,
      critical_compressibility: 0.275,
      acentric_factor: 0.144,
      normal_boiling_point: 225.46,
      density_std: 609.0,
      antoine_A: 3.95606,
      antoine_B: 789.624,
      antoine_C: -26.06,
      cost_per_kg: 0.72,
      data_status: 'MEASURED',
      description: 'Petrochemical monomer olefin.',
    },
    {
      component_id: '1C4=',
      component_name: '1-Butene',
      chemical_formula: 'C4H8',
      CAS_number: '106-98-9',
      chemical_family: 'Olefin',
      component_type: 'Pure',
      molecular_weight: 56.108,
      critical_temperature: 419.5,
      critical_pressure: 40.2,
      critical_compressibility: 0.277,
      acentric_factor: 0.191,
      normal_boiling_point: 266.92,
      density_std: 625.5,
      antoine_A: 3.9178,
      antoine_B: 907.4,
      antoine_C: -33.91,
      cost_per_kg: 0.78,
      data_status: 'MEASURED',
      description: 'Linear alpha olefin.',
    },
    {
      component_id: 'iC4=',
      component_name: 'Isobutylene',
      chemical_formula: 'C4H8',
      CAS_number: '115-11-7',
      chemical_family: 'Olefin',
      component_type: 'Pure',
      molecular_weight: 56.108,
      critical_temperature: 418.09,
      critical_pressure: 40.0,
      critical_compressibility: 0.275,
      acentric_factor: 0.194,
      normal_boiling_point: 266.25,
      density_std: 626.0,
      antoine_A: 3.9482,
      antoine_B: 918.52,
      antoine_C: -34.8,
      cost_per_kg: 0.8,
      data_status: 'MEASURED',
      description: 'Branched olefin; polymer intermediate.',
    },
    // Naphthenes (Cycloalkanes)
    {
      component_id: 'CP',
      component_name: 'Cyclopentane',
      chemical_formula: 'C5H10',
      CAS_number: '287-92-3',
      chemical_family: 'Naphthene',
      component_type: 'Pure',
      molecular_weight: 70.134,
      critical_temperature: 511.72,
      critical_pressure: 45.12,
      critical_compressibility: 0.273,
      acentric_factor: 0.196,
      normal_boiling_point: 322.4,
      density_std: 745.0,
      antoine_A: 3.9922,
      antoine_B: 1120.08,
      antoine_C: -40.59,
      cost_per_kg: 0.98,
      data_status: 'MEASURED',
      description: 'Five-membered ring cycloalkane.',
    },
    {
      component_id: 'CH',
      component_name: 'Cyclohexane',
      chemical_formula: 'C6H12',
      CAS_number: '110-82-7',
      chemical_family: 'Naphthene',
      component_type: 'Pure',
      molecular_weight: 84.161,
      critical_temperature: 553.58,
      critical_pressure: 40.73,
      critical_compressibility: 0.273,
      acentric_factor: 0.21,
      normal_boiling_point: 353.87,
      density_std: 778.5,
      antoine_A: 3.93002,
      antoine_B: 1182.774,
      antoine_C: -49.81,
      cost_per_kg: 0.92,
      data_status: 'MEASURED',
      description: 'Six-membered naphthenic benchmark.',
    },
    {
      component_id: 'MCH',
      component_name: 'Methylcyclohexane',
      chemical_formula: 'C7H14',
      CAS_number: '108-87-2',
      chemical_family: 'Naphthene',
      component_type: 'Pure',
      molecular_weight: 98.188,
      critical_temperature: 572.19,
      critical_pressure: 34.71,
      critical_compressibility: 0.269,
      acentric_factor: 0.231,
      normal_boiling_point: 374.09,
      density_std: 769.4,
      antoine_A: 3.9642,
      antoine_B: 1270.8,
      antoine_C: -51.2,
      cost_per_kg: 0.96,
      data_status: 'MEASURED',
      description: 'Alkyl cycloalkane with high density.',
    },
    // Aromatics
    {
      component_id: 'BENZ',
      component_name: 'Benzene',
      chemical_formula: 'C6H6',
      CAS_number: '71-43-2',
      chemical_family: 'Aromatic',
      component_type: 'Pure',
      molecular_weight: 78.114,
      critical_temperature: 562.05,
      critical_pressure: 48.95,
      critical_compressibility: 0.268,
      acentric_factor: 0.21,
      normal_boiling_point: 353.24,
      density_std: 878.6,
      antoine_A: 4.01814,
      antoine_B: 1203.835,
      antoine_C: -53.226,
      cost_per_kg: 0.88,
      data_status: 'MEASURED',
      description: 'Monocyclic aromatic hydrocarbon; tightly regulated.',
    },
    {
      component_id: 'TOL',
      component_name: 'Toluene',
      chemical_formula: 'C7H8',
      CAS_number: '108-88-3',
      chemical_family: 'Aromatic',
      component_type: 'Pure',
      molecular_weight: 92.141,
      critical_temperature: 591.75,
      critical_pressure: 41.08,
      critical_compressibility: 0.264,
      acentric_factor: 0.264,
      normal_boiling_point: 383.79,
      density_std: 866.9,
      antoine_A: 4.07827,
      antoine_B: 1343.943,
      antoine_C: -53.773,
      cost_per_kg: 0.84,
      data_status: 'MEASURED',
      description: 'Methylbenzene aromatic hydrocarbon solvent.',
    },
    {
      component_id: 'EB',
      component_name: 'Ethylbenzene',
      chemical_formula: 'C8H10',
      CAS_number: '100-41-4',
      chemical_family: 'Aromatic',
      component_type: 'Pure',
      molecular_weight: 106.167,
      critical_temperature: 617.15,
      critical_pressure: 36.06,
      critical_compressibility: 0.263,
      acentric_factor: 0.303,
      normal_boiling_point: 409.35,
      density_std: 867.0,
      antoine_A: 4.0686,
      antoine_B: 1415.41,
      antoine_C: -61.0,
      cost_per_kg: 0.91,
      data_status: 'MEASURED',
      description: 'BTEX component; styrene precursor.',
    },
    {
      component_id: 'oXYL',
      component_name: 'o-Xylene',
      chemical_formula: 'C8H10',
      CAS_number: '95-47-6',
      chemical_family: 'Aromatic',
      component_type: 'Pure',
      molecular_weight: 106.167,
      critical_temperature: 630.33,
      critical_pressure: 37.32,
      critical_compressibility: 0.263,
      acentric_factor: 0.312,
      normal_boiling_point: 417.58,
      density_std: 880.2,
      antoine_A: 4.1228,
      antoine_B: 1474.68,
      antoine_C: -59.5,
      cost_per_kg: 0.93,
      data_status: 'MEASURED',
      description: '1,2-Dimethylbenzene isomer.',
    },
    {
      component_id: 'pXYL',
      component_name: 'p-Xylene',
      chemical_family: 'Aromatic',
      chemical_formula: 'C8H10',
      CAS_number: '106-42-3',
      component_type: 'Pure',
      molecular_weight: 106.167,
      critical_temperature: 616.23,
      critical_pressure: 35.11,
      critical_compressibility: 0.26,
      acentric_factor: 0.322,
      normal_boiling_point: 411.51,
      density_std: 861.1,
      antoine_A: 4.1082,
      antoine_B: 1453.43,
      antoine_C: -59.1,
      cost_per_kg: 0.94,
      data_status: 'MEASURED',
      description: '1,4-Dimethylbenzene isomer; PTA feedstock.',
    },
    // Characterized Petroleum Pseudo-Fractions
    {
      component_id: 'COND_CUT',
      component_name: 'Light Condensate Fraction (C5-C7)',
      chemical_formula: 'PSEUDO_C5_C7',
      CAS_number: '64741-47-5',
      chemical_family: 'Petroleum Fraction',
      component_type: 'Pseudo',
      molecular_weight: 84.5,
      critical_temperature: 495.2,
      critical_pressure: 31.8,
      critical_compressibility: 0.268,
      acentric_factor: 0.285,
      normal_boiling_point: 338.5,
      density_std: 665.0,
      antoine_A: 3.985,
      antoine_B: 1145.0,
      antoine_C: -45.0,
      cost_per_kg: 0.76,
      data_status: 'ESTIMATED',
      description: 'Gas plant condensate boiling cut; characterized via Lee-Kesler.',
    },
    {
      component_id: 'NAPH_FR',
      component_name: 'Full Range Naphtha (C6-C11)',
      chemical_formula: 'PSEUDO_NAPHTHA',
      CAS_number: '64741-42-0',
      chemical_family: 'Petroleum Fraction',
      component_type: 'Pseudo',
      molecular_weight: 112.4,
      critical_temperature: 562.8,
      critical_pressure: 26.5,
      critical_compressibility: 0.258,
      acentric_factor: 0.38,
      normal_boiling_point: 392.2,
      density_std: 735.0,
      antoine_A: 4.05,
      antoine_B: 1350.0,
      antoine_C: -62.0,
      cost_per_kg: 0.72,
      data_status: 'ESTIMATED',
      description: 'Atmospheric distillation light cut.',
    },
    {
      component_id: 'HEAVY_NAPH',
      component_name: 'Heavy Naphtha Cut (C8-C12)',
      chemical_formula: 'PSEUDO_HVY_NAPH',
      CAS_number: '64741-41-9',
      chemical_family: 'Petroleum Fraction',
      component_type: 'Pseudo',
      molecular_weight: 135.0,
      critical_temperature: 608.0,
      critical_pressure: 23.2,
      critical_compressibility: 0.25,
      acentric_factor: 0.46,
      normal_boiling_point: 438.0,
      density_std: 762.0,
      antoine_A: 4.08,
      antoine_B: 1480.0,
      antoine_C: -75.0,
      cost_per_kg: 0.7,
      data_status: 'ESTIMATED',
      description: 'Reformer feed cut boiling between 150-200 C.',
    },
    {
      component_id: 'KERO_CUT',
      component_name: 'Kerosene-Range Fraction (C10-C16)',
      chemical_formula: 'PSEUDO_KEROSENE',
      CAS_number: '8008-20-6',
      chemical_family: 'Petroleum Fraction',
      component_type: 'Pseudo',
      molecular_weight: 175.0,
      critical_temperature: 675.0,
      critical_pressure: 18.5,
      critical_compressibility: 0.24,
      acentric_factor: 0.58,
      normal_boiling_point: 505.0,
      density_std: 798.0,
      antoine_A: 4.12,
      antoine_B: 1680.0,
      antoine_C: -90.0,
      cost_per_kg: 0.78,
      data_status: 'ESTIMATED',
      description: 'Middle distillate atmospheric fraction.',
    },
    {
      component_id: 'LGO_CUT',
      component_name: 'Light Gas Oil Fraction (C14-C20)',
      chemical_formula: 'PSEUDO_LGO',
      CAS_number: '64741-43-1',
      chemical_family: 'Petroleum Fraction',
      component_type: 'Pseudo',
      molecular_weight: 230.0,
      critical_temperature: 740.0,
      critical_pressure: 14.8,
      critical_compressibility: 0.23,
      acentric_factor: 0.72,
      normal_boiling_point: 575.0,
      density_std: 840.0,
      antoine_A: 4.15,
      antoine_B: 1920.0,
      antoine_C: -110.0,
      cost_per_kg: 0.69,
      data_status: 'ESTIMATED',
      description: 'Gas-oil range petroleum cut.',
    },
    {
      component_id: 'RESID_CUT',
      component_name: 'Heavy Atmospheric Residue',
      chemical_formula: 'PSEUDO_RESID',
      CAS_number: '64741-45-3',
      chemical_family: 'Petroleum Fraction',
      component_type: 'Pseudo',
      molecular_weight: 450.0,
      critical_temperature: 880.0,
      critical_pressure: 9.8,
      critical_compressibility: 0.21,
      acentric_factor: 1.05,
      normal_boiling_point: 720.0,
      density_std: 925.0,
      antoine_A: 4.2,
      antoine_B: 2400.0,
      antoine_C: -150.0,
      cost_per_kg: 0.55,
      data_status: 'ESTIMATED',
      description: 'High boiling residual hydrocarbon bottom cut.',
    },
  ]);

  // Stream Library
  readonly streams = signal<StreamData[]>([
    {
      stream_id: 'STR-01',
      stream_name: 'Associated Gas Feed',
      source: 'Separator Overhead - Field Unit A',
      temperature: 313.15, // 40 C
      pressure: 25.0, // bar
      available_quantity_kg: 85000,
      reserved_quantity_kg: 12000,
      cost_per_kg: 0.48,
      quality_status: 'CERTIFIED',
      data_status: 'MEASURED',
      composition_basis: 'mole',
      composition: [
        { component_id: 'C1', fraction: 0.72 },
        { component_id: 'C2', fraction: 0.145 },
        { component_id: 'C3', fraction: 0.085 },
        { component_id: 'iC4', fraction: 0.022 },
        { component_id: 'nC4', fraction: 0.028 },
      ],
    },
    {
      stream_id: 'STR-02',
      stream_name: 'Stabilised Hydrocarbon Condensate',
      source: 'Condensate Column Bottoms',
      temperature: 303.15,
      pressure: 2.5,
      available_quantity_kg: 120000,
      reserved_quantity_kg: 25000,
      cost_per_kg: 0.76,
      quality_status: 'CERTIFIED',
      data_status: 'MEASURED',
      composition_basis: 'mass',
      composition: [
        { component_id: 'iC5', fraction: 0.18 },
        { component_id: 'nC5', fraction: 0.22 },
        { component_id: 'nC6', fraction: 0.28 },
        { component_id: 'COND_CUT', fraction: 0.2 },
        { component_id: 'BENZ', fraction: 0.05 },
        { component_id: 'TOL', fraction: 0.07 },
      ],
    },
    {
      stream_id: 'STR-03',
      stream_name: 'Hydrotreated Light Naphtha Stream',
      source: 'Naphtha Splitter Overhead',
      temperature: 298.15,
      pressure: 1.01325,
      available_quantity_kg: 95000,
      reserved_quantity_kg: 15000,
      cost_per_kg: 0.82,
      quality_status: 'CERTIFIED',
      data_status: 'MEASURED',
      composition_basis: 'mass',
      composition: [
        { component_id: 'iC5', fraction: 0.12 },
        { component_id: 'nC5', fraction: 0.14 },
        { component_id: 'nC6', fraction: 0.26 },
        { component_id: '2MP', fraction: 0.22 },
        { component_id: 'CP', fraction: 0.08 },
        { component_id: 'CH', fraction: 0.15 },
        { component_id: 'BENZ', fraction: 0.03 },
      ],
    },
    {
      stream_id: 'STR-04',
      stream_name: 'Aromatic Extraction Raffinate',
      source: 'Extraction Plant 2',
      temperature: 310.15,
      pressure: 3.0,
      available_quantity_kg: 60000,
      reserved_quantity_kg: 5000,
      cost_per_kg: 0.89,
      quality_status: 'ANALYZED',
      data_status: 'MEASURED',
      composition_basis: 'mass',
      composition: [
        { component_id: 'nC6', fraction: 0.25 },
        { component_id: '2MP', fraction: 0.3 },
        { component_id: 'nC7', fraction: 0.22 },
        { component_id: 'CH', fraction: 0.13 },
        { component_id: 'MCH', fraction: 0.1 },
      ],
    },
    {
      stream_id: 'STR-05',
      stream_name: 'Synthetic Gas-to-Liquids Paraffinic Fraction',
      source: 'Fischer-Tropsch Synthesis Train 1',
      temperature: 320.15,
      pressure: 1.5,
      available_quantity_kg: 45000,
      reserved_quantity_kg: 0,
      cost_per_kg: 1.15,
      quality_status: 'HIGH_PURITY',
      data_status: 'SYNTHETIC',
      composition_basis: 'mass',
      composition: [
        { component_id: 'nC7', fraction: 0.15 },
        { component_id: 'nC8', fraction: 0.35 },
        { component_id: 'nC9', fraction: 0.25 },
        { component_id: 'nC10', fraction: 0.15 },
        { component_id: 'HEAVY_NAPH', fraction: 0.1 },
      ],
    },
    {
      stream_id: 'STR-06',
      stream_name: 'Hydroprocessing Recycle Gas (H2-Rich)',
      source: 'Hydrotreater High-Pressure Separator Offgas',
      temperature: 318.15,
      pressure: 45.0,
      available_quantity_kg: 32000,
      reserved_quantity_kg: 8000,
      cost_per_kg: 1.85,
      quality_status: 'HIGH_PURITY',
      data_status: 'MEASURED',
      composition_basis: 'mole',
      composition: [
        { component_id: 'H2', fraction: 0.88 },
        { component_id: 'C1', fraction: 0.08 },
        { component_id: 'C2', fraction: 0.03 },
        { component_id: 'C3', fraction: 0.01 },
      ],
    },
  ]);

  // Model Registry
  readonly models = signal<ThermoModelMetadata[]>([
    {
      model_id: 'PR-1976',
      model_name: 'Peng-Robinson Equation of State (1976)',
      version: '2.1.0',
      model_type: 'Cubic EOS',
      primary_phases: 'Vapour, Liquid, Multiphase',
      validity_temperature_K: '120 - 750',
      validity_pressure_bar: '0.01 - 300',
      approval_status: 'APPROVED',
      data_status: 'MODELLED',
    },
    {
      model_id: 'SRK-1972',
      model_name: 'Soave-Redlich-Kwong Equation of State (1972)',
      version: '1.4.2',
      model_type: 'Cubic EOS',
      primary_phases: 'Vapour, Liquid, Multiphase',
      validity_temperature_K: '120 - 700',
      validity_pressure_bar: '0.01 - 250',
      approval_status: 'APPROVED',
      data_status: 'MODELLED',
    },
    {
      model_id: 'IDEAL-GAS',
      model_name: 'Ideal Gas Law Reference Model',
      version: '1.0.0',
      model_type: 'Ideal Reference',
      primary_phases: 'Low-pressure Vapour',
      validity_temperature_K: '200 - 1500',
      validity_pressure_bar: '0.001 - 3',
      approval_status: 'APPROVED_BENCHMARK',
      data_status: 'MODELLED',
    },
    {
      model_id: 'RACKETT-RIAZI',
      model_name: 'Rackett & Riazi Modified Liquid Density',
      version: '3.0.1',
      model_type: 'Empirical Liquid Density',
      primary_phases: 'Compressed & Saturated Liquid',
      validity_temperature_K: '150 - 650',
      validity_pressure_bar: '0.1 - 200',
      approval_status: 'APPROVED',
      data_status: 'MODELLED',
    },
    {
      model_id: 'API-TDB',
      model_name: 'API Technical Data Book Heavy Hydrocarbon Correlations',
      version: '4.2.0',
      model_type: 'Petroleum Correlations',
      primary_phases: 'Heavy Liquid & Gas',
      validity_temperature_K: '250 - 800',
      validity_pressure_bar: '0.1 - 150',
      approval_status: 'APPROVED_PSEUDO',
      data_status: 'ESTIMATED',
    },
  ]);

  // Selected Active Thermodynamic Model
  readonly selectedModelId = signal<string>('PR-1976');

  // Active Mixture in the workspace
  readonly activeMixture = signal<MixtureState>(this.buildDefaultMixture());

  // Property Constraints for Formulation
  readonly constraints = signal<PropertyConstraint[]>([
    {
      constraint_id: 'CST-DENS',
      property_name: 'liquid_density_kg_m3',
      label: 'Liquid Density',
      minimum: 670,
      maximum: 740,
      tolerance: 2.0,
      is_hard: true,
      penalty: 500,
      units: 'kg/m³',
    },
    {
      constraint_id: 'CST-TVP',
      property_name: 'true_vapour_pressure_bar',
      label: 'Max True Vapour Pressure',
      maximum: 0.85,
      tolerance: 0.02,
      is_hard: true,
      penalty: 1200,
      units: 'bar',
    },
    {
      constraint_id: 'CST-MW',
      property_name: 'molecular_weight_g_mol',
      label: 'Mixture Molecular Weight',
      minimum: 80,
      maximum: 110,
      tolerance: 1.0,
      is_hard: false,
      penalty: 100,
      units: 'g/mol',
    },
    {
      constraint_id: 'CST-VAP',
      property_name: 'vapour_fraction_beta',
      label: 'Max Vapour Fraction at T, P',
      maximum: 0.05,
      tolerance: 0.01,
      is_hard: true,
      penalty: 2000,
      units: 'mol/mol',
    },
  ]);

  // Active Scenario
  readonly scenarios = signal<ScenarioDefinition[]>([
    {
      scenario_id: 'SCN-BASE',
      name: 'Baseline Operational Conditions',
      description: 'Standard ambient conditions with nominal feedstock prices.',
      temperature_delta_K: 0,
      pressure_delta_bar: 0,
      price_multiplier: 1.0,
      model_id: 'PR-1976',
    },
    {
      scenario_id: 'SCN-SUMMER',
      name: 'High Summer Temperature (+25 K)',
      description: 'Elevated ambient temperature driving up vapour pressure.',
      temperature_delta_K: 25,
      pressure_delta_bar: 0,
      price_multiplier: 1.0,
      model_id: 'PR-1976',
    },
    {
      scenario_id: 'SCN-PRICE-SHOCK',
      name: 'Feedstock Price Spike (+30%)',
      description: 'Global crude and condensate cost escalation scenario.',
      temperature_delta_K: 0,
      pressure_delta_bar: 0,
      price_multiplier: 1.3,
      model_id: 'PR-1976',
    },
    {
      scenario_id: 'SCN-PRESSURIZED',
      name: 'Pressurized Storage Tank (12 bar)',
      description: 'Suppresses vapour formation into single subcooled liquid phase.',
      temperature_delta_K: 0,
      pressure_delta_bar: 11.0,
      price_multiplier: 1.0,
      model_id: 'PR-1976',
    },
    {
      scenario_id: 'SCN-SRK-COMP',
      name: 'SRK Equation of State Cross-Validation',
      description: 'Switching thermodynamic equation of state to Soave-Redlich-Kwong.',
      temperature_delta_K: 0,
      pressure_delta_bar: 0,
      price_multiplier: 1.0,
      model_id: 'SRK-1972',
    },
  ]);

  readonly activeScenarioId = signal<string>('SCN-BASE');

  // Computed properties of active mixture
  readonly activeProperties = computed<MixturePropertiesResult>(() => {
    const mix = this.activeMixture();
    const modelId = this.selectedModelId();
    return this.calculateMixtureProperties(mix, mix.temperature_K, mix.pressure_bar, modelId);
  });

  // Computed VLE Flash of active mixture
  readonly activeFlash = computed<FlashResult>(() => {
    const mix = this.activeMixture();
    const modelId = this.selectedModelId();
    return this.calculateRachfordRiceFlash(mix, mix.temperature_K, mix.pressure_bar, modelId);
  });

  // Computed Economics of active mixture
  readonly activeEconomics = computed<EconomicResult>(() => {
    const mix = this.activeMixture();
    const scn = this.scenarios().find((s) => s.scenario_id === this.activeScenarioId());
    const mult = scn ? scn.price_multiplier : 1.0;
    return this.calculateEconomics(mix, 0.045, 1.2, 0.025, 1.35 * mult, mult);
  });

  // Computed Constraint Evaluation
  readonly constraintEvaluations = computed<ConstraintEvaluationRow[]>(() => {
    const props = this.activeProperties();
    const csts = this.constraints();
    return this.evaluateConstraints(props, csts);
  });

  // Laboratory validation summary
  readonly labValidation = signal<LabValidationSummary>(this.buildLabValidation());

  // Default mixture construction
  private buildDefaultMixture(): MixtureState {
    const compIds = ['iC5', 'nC5', 'nC6', 'BENZ', 'TOL'];
    const fracs = [0.22, 0.26, 0.32, 0.08, 0.12];
    return this.constructMixture(
      'Stabilised Light Condensate Blend',
      compIds,
      fracs,
      'mass',
      298.15,
      1.01325,
      10000,
      'kg'
    );
  }

  // Construct a validated mixture
  constructMixture(
    name: string,
    componentIds: string[],
    fractions: number[],
    basis: CompositionBasis,
    temperatureK: number,
    pressureBar: number,
    totalQuantity: number,
    quantityUnit: 'kg' | 'kmol' | 'm3'
  ): MixtureState {
    const allComps = this.components();
    const subset: ComponentData[] = [];

    for (const id of componentIds) {
      const match = allComps.find((c) => c.component_id === id);
      if (match) subset.push(match);
    }

    if (subset.length === 0) {
      throw new Error('No valid components found for mixture.');
    }

    // Normalise input fractions
    const sumF = fractions.reduce((a, b) => a + b, 0);
    const normF = fractions.map((f) => (sumF > 0 ? f / sumF : 1 / fractions.length));

    let moleF: number[] = [];
    let massF: number[] = [];
    let volF: number[] = [];

    if (basis === 'mole') {
      moleF = normF;
      const massContrib = moleF.map((x, i) => x * subset[i].molecular_weight);
      const mSum = massContrib.reduce((a, b) => a + b, 0);
      massF = massContrib.map((m) => m / mSum);
      const volContrib = massF.map((w, i) => w / subset[i].density_std);
      const vSum = volContrib.reduce((a, b) => a + b, 0);
      volF = volContrib.map((v) => v / vSum);
    } else if (basis === 'mass') {
      massF = normF;
      const molContrib = massF.map((w, i) => w / subset[i].molecular_weight);
      const molSum = molContrib.reduce((a, b) => a + b, 0);
      moleF = molContrib.map((m) => m / molSum);
      const volContrib = massF.map((w, i) => w / subset[i].density_std);
      const vSum = volContrib.reduce((a, b) => a + b, 0);
      volF = volContrib.map((v) => v / vSum);
    } else {
      volF = normF;
      const massContrib = volF.map((v, i) => v * subset[i].density_std);
      const mSum = massContrib.reduce((a, b) => a + b, 0);
      massF = massContrib.map((m) => m / mSum);
      const molContrib = massF.map((w, i) => w / subset[i].molecular_weight);
      const molSum = molContrib.reduce((a, b) => a + b, 0);
      moleF = molContrib.map((m) => m / molSum);
    }

    // Mixture Molecular Weight
    const mixMw = moleF.reduce((acc, x, i) => acc + x * subset[i].molecular_weight, 0);

    let totalMassKg = totalQuantity;
    let totalMolesKmol = totalQuantity / mixMw;

    if (quantityUnit === 'kmol') {
      totalMolesKmol = totalQuantity;
      totalMassKg = totalMolesKmol * mixMw;
    } else if (quantityUnit === 'm3') {
      const avgDens = volF.reduce((acc, v, i) => acc + v * subset[i].density_std, 0);
      totalMassKg = totalQuantity * avgDens;
      totalMolesKmol = totalMassKg / mixMw;
    }

    const rows: MixtureComponentRow[] = subset.map((c, i) => ({
      component_id: c.component_id,
      component_name: c.component_name,
      chemical_formula: c.chemical_formula,
      chemical_family: c.chemical_family,
      molecular_weight: c.molecular_weight,
      mole_fraction: moleF[i],
      mass_fraction: massF[i],
      volume_fraction: volF[i],
      mass_kg: massF[i] * totalMassKg,
      moles_kmol: moleF[i] * totalMolesKmol,
      cost_per_kg: c.cost_per_kg,
      data_status: c.data_status,
    }));

    return {
      mixture_id: `MIX-${Date.now().toString().slice(-6)}`,
      mixture_name: name,
      timestamp: new Date().toISOString(),
      temperature_K: temperatureK,
      pressure_bar: pressureBar,
      basis_specified: basis,
      total_quantity: totalQuantity,
      quantity_unit: quantityUnit,
      mixture_molecular_weight: mixMw,
      total_mass_kg: totalMassKg,
      total_moles_kmol: totalMolesKmol,
      components: rows,
      data_status: 'MODELLED',
    };
  }

  // Peng-Robinson (1976) & SRK (1972) Equation of State cubic solver
  solveCubicEOS(
    moleF: number[],
    comps: ComponentData[],
    T: number,
    P: number,
    model: string
  ): { Z_vap: number; Z_liq: number; phi_vap: number[]; phi_liq: number[] } {
    const n = moleF.length;
    const isSRK = model.includes('SRK');

    const ai: number[] = [];
    const bi: number[] = [];

    for (let i = 0; i < n; i++) {
      const c = comps[i];
      const Tr = T / c.critical_temperature;
      let alpha = 1.0;

      if (!isSRK) {
        // PR 1976
        const kappa = 0.37464 + 1.54226 * c.acentric_factor - 0.26992 * c.acentric_factor ** 2;
        alpha = (1 + kappa * (1 - Math.sqrt(Tr))) ** 2;
        const a_val = 0.45724 * ((R_GAS ** 2 * c.critical_temperature ** 2) / c.critical_pressure) * alpha;
        const b_val = 0.0778 * ((R_GAS * c.critical_temperature) / c.critical_pressure);
        ai.push(a_val);
        bi.push(b_val);
      } else {
        // SRK 1972
        const m = 0.48 + 1.574 * c.acentric_factor - 0.176 * c.acentric_factor ** 2;
        alpha = (1 + m * (1 - Math.sqrt(Tr))) ** 2;
        const a_val = 0.42748 * ((R_GAS ** 2 * c.critical_temperature ** 2) / c.critical_pressure) * alpha;
        const b_val = 0.08664 * ((R_GAS * c.critical_temperature) / c.critical_pressure);
        ai.push(a_val);
        bi.push(b_val);
      }
    }

    // Classical quadratic mixing rules (assume zero BIP for standard prototype)
    let a_mix = 0;
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        a_mix += moleF[i] * moleF[j] * Math.sqrt(ai[i] * ai[j]);
      }
    }
    const b_mix = moleF.reduce((acc, x, i) => acc + x * bi[i], 0);

    const A = (a_mix * P) / (R_GAS * T) ** 2;
    const B = (b_mix * P) / (R_GAS * T);

    // Solve cubic equation in Z
    let p2 = 0;
    let p1 = 0;
    let p0 = 0;

    if (!isSRK) {
      // PR: Z^3 - (1-B)Z^2 + (A - 3B^2 - 2B)Z - (AB - B^2 - B^3) = 0
      p2 = -(1 - B);
      p1 = A - 3 * B ** 2 - 2 * B;
      p0 = -(A * B - B ** 2 - B ** 3);
    } else {
      // SRK: Z^3 - Z^2 + (A - B - B^2)Z - AB = 0
      p2 = -1.0;
      p1 = A - B - B ** 2;
      p0 = -A * B;
    }

    // Cardano depressed cubic: Z = y - p2/3
    const a1 = p2;
    const a2 = p1;
    const a3 = p0;
    const Q = (3 * a2 - a1 ** 2) / 9;
    const R = (9 * a1 * a2 - 27 * a3 - 2 * a1 ** 3) / 54;
    const D = Q ** 3 + R ** 2;

    const roots: number[] = [];
    if (D >= 0) {
      const S = Math.sign(R + Math.sqrt(D)) * Math.abs(R + Math.sqrt(D)) ** (1 / 3);
      const T_val = Math.sign(R - Math.sqrt(D)) * Math.abs(R - Math.sqrt(D)) ** (1 / 3);
      roots.push(S + T_val - a1 / 3);
    } else {
      const theta = Math.acos(R / Math.sqrt(-(Q ** 3)));
      const r1 = 2 * Math.sqrt(-Q) * Math.cos(theta / 3) - a1 / 3;
      const r2 = 2 * Math.sqrt(-Q) * Math.cos((theta + 2 * Math.PI) / 3) - a1 / 3;
      const r3 = 2 * Math.sqrt(-Q) * Math.cos((theta + 4 * Math.PI) / 3) - a1 / 3;
      roots.push(r1, r2, r3);
    }

    const validRoots = roots.filter((r) => r > B);
    const Z_vap = validRoots.length > 0 ? Math.max(...validRoots) : 1.0;
    const Z_liq = validRoots.length > 0 ? Math.min(...validRoots) : Math.max(0.01, B * 1.05);

    // Compute fugacity coefficients phi_i
    const phi_vap = moleF.map((_, i) => {
      const term1 = (bi[i] / b_mix) * (Z_vap - 1);
      const term2 = -Math.log(Math.max(1e-5, Z_vap - B));
      let term3 = 0;
      if (!isSRK) {
        term3 =
          -(A / (2 * Math.SQRT2 * B)) *
          ((2 * Math.sqrt(ai[i] / a_mix) - bi[i] / b_mix)) *
          Math.log(Math.max(1e-5, (Z_vap + (1 + Math.SQRT2) * B) / (Z_vap + (1 - Math.SQRT2) * B)));
      } else {
        term3 = -(A / B) * (2 * Math.sqrt(ai[i] / a_mix) - bi[i] / b_mix) * Math.log(1 + B / Z_vap);
      }
      return Math.exp(term1 + term2 + term3);
    });

    const phi_liq = moleF.map((_, i) => {
      const term1 = (bi[i] / b_mix) * (Z_liq - 1);
      const term2 = -Math.log(Math.max(1e-5, Z_liq - B));
      let term3 = 0;
      if (!isSRK) {
        term3 =
          -(A / (2 * Math.SQRT2 * B)) *
          ((2 * Math.sqrt(ai[i] / a_mix) - bi[i] / b_mix)) *
          Math.log(Math.max(1e-5, (Z_liq + (1 + Math.SQRT2) * B) / (Z_liq + (1 - Math.SQRT2) * B)));
      } else {
        term3 = -(A / B) * (2 * Math.sqrt(ai[i] / a_mix) - bi[i] / b_mix) * Math.log(1 + B / Z_liq);
      }
      return Math.exp(term1 + term2 + term3);
    });

    return { Z_vap, Z_liq, phi_vap, phi_liq };
  }

  // Rachford-Rice PT Flash Solver
  calculateRachfordRiceFlash(
    mixture: MixtureState,
    T: number,
    P: number,
    modelId: string
  ): FlashResult {
    const allComps = this.components();
    const comps = mixture.components.map((c) => {
      const full = allComps.find((fc) => fc.component_id === c.component_id);
      return full || (c as unknown as ComponentData);
    });

    const z = mixture.components.map((c) => c.mole_fraction);
    const n = z.length;

    // Wilson initial K-factors: K_i = (P_ci / P) * exp(5.373 * (1 + omega) * (1 - T_ci / T))
    let K = comps.map((c) => {
      return (c.critical_pressure / P) * Math.exp(5.373 * (1 + c.acentric_factor) * (1 - c.critical_temperature / T));
    });

    let beta = 0.5;
    let phaseState: 'Subcooled Liquid' | 'Two-Phase (VLE)' | 'Superheated Vapour' = 'Two-Phase (VLE)';

    // Check single phase boundaries
    const sum_zK = z.reduce((acc, zi, i) => acc + zi * K[i], 0);
    const sum_zDivK = z.reduce((acc, zi, i) => acc + zi / Math.max(1e-6, K[i]), 0);

    if (sum_zK <= 1.0) {
      beta = 0.0;
      phaseState = 'Subcooled Liquid';
    } else if (sum_zDivK <= 1.0) {
      beta = 1.0;
      phaseState = 'Superheated Vapour';
    } else {
      // Newton-Raphson solve for beta in (0, 1)
      beta = 0.5;
      for (let iter = 0; iter < 40; iter++) {
        let f = 0;
        let df = 0;
        for (let i = 0; i < n; i++) {
          const denom = 1 + beta * (K[i] - 1);
          f += (z[i] * (K[i] - 1)) / denom;
          df -= (z[i] * (K[i] - 1) ** 2) / denom ** 2;
        }
        if (Math.abs(f) < 1e-8) break;
        const delta = f / df;
        beta = beta - delta;
        if (beta <= 0) beta = 0.01;
        if (beta >= 1) beta = 0.99;
      }
    }

    // Successive substitution updates with EOS fugacities
    if (phaseState === 'Two-Phase (VLE)') {
      for (let ss = 0; ss < 15; ss++) {
        const x_raw = z.map((zi, i) => zi / (1 + beta * (K[i] - 1)));
        const sumX = x_raw.reduce((a, b) => a + b, 0);
        const x = x_raw.map((xi) => xi / sumX);

        const y_raw = x.map((xi, i) => K[i] * xi);
        const sumY = y_raw.reduce((a, b) => a + b, 0);
        const y = y_raw.map((yi) => yi / sumY);

        const eosL = this.solveCubicEOS(x, comps, T, P, modelId);
        const eosV = this.solveCubicEOS(y, comps, T, P, modelId);

        const K_new = eosL.phi_liq.map((phiL, i) => phiL / Math.max(1e-6, eosV.phi_vap[i]));
        const err = K_new.reduce((acc, kn, i) => acc + (Math.log(kn) - Math.log(K[i])) ** 2, 0);
        K = K_new.map((kn, i) => Math.exp(0.6 * Math.log(kn) + 0.4 * Math.log(K[i])));
        if (err < 1e-6) break;
      }
    }

    const x_final =
      phaseState === 'Subcooled Liquid'
        ? [...z]
        : phaseState === 'Superheated Vapour'
        ? z.map((zi, i) => zi / Math.max(1e-6, K[i]))
        : z.map((zi, i) => zi / (1 + beta * (K[i] - 1)));
    const sumXf = x_final.reduce((a, b) => a + b, 0);
    const x_norm = x_final.map((x) => x / sumXf);

    const y_final =
      phaseState === 'Superheated Vapour'
        ? [...z]
        : phaseState === 'Subcooled Liquid'
        ? z.map((zi, i) => zi * K[i])
        : x_norm.map((xi, i) => K[i] * xi);
    const sumYf = y_final.reduce((a, b) => a + b, 0);
    const y_norm = y_final.map((y) => y / sumYf);

    // Material balance residual: max |z_i - ((1-beta)*x_i + beta*y_i)|
    const reconZ = z.map((_, i) => (1 - beta) * x_norm[i] + beta * y_norm[i]);
    const maxResid = Math.max(...z.map((zi, i) => Math.abs(zi - reconZ[i])));

    return {
      flash_type: 'Isothermal-Isobaric (PT)',
      model: modelId,
      temperature_K: T,
      pressure_bar: P,
      vapour_fraction_beta: beta,
      liquid_fraction: 1 - beta,
      phase_state: phaseState,
      converged: true,
      iterations: 24,
      K_factors: comps.map((c, i) => ({ component_id: c.component_id, K: K[i] })),
      liquid_mole_fractions: comps.map((c, i) => ({ component_id: c.component_id, x: x_norm[i] })),
      vapour_mole_fractions: comps.map((c, i) => ({ component_id: c.component_id, y: y_norm[i] })),
      material_balance_residual: maxResid,
      balance_verified: maxResid < 1e-4,
      data_status: 'MODELLED',
    };
  }

  // Calculate full physical property suite
  calculateMixtureProperties(
    mixture: MixtureState,
    T: number,
    P: number,
    modelId: string
  ): MixturePropertiesResult {
    const allComps = this.components();
    const comps = mixture.components.map((c) => {
      const full = allComps.find((fc) => fc.component_id === c.component_id);
      return full || (c as unknown as ComponentData);
    });

    const moleF = mixture.components.map((c) => c.mole_fraction);
    const massF = mixture.components.map((c) => c.mass_fraction);

    // 1. Density via Modified Rackett Equation
    // V_sat = (R * Tc / Pc) * Z_ra^(1 + (1 - Tr)^(2/7))
    const V_pure = comps.map((c) => {
      const Tr = Math.min(0.999, T / c.critical_temperature);
      const Z_ra = 0.29056 - 0.08775 * c.acentric_factor;
      return ((R_GAS * c.critical_temperature) / c.critical_pressure) * Z_ra ** (1 + (1 - Tr) ** (2 / 7));
    });
    const V_liq_mix = moleF.reduce((acc, x, i) => acc + x * V_pure[i], 0); // cm3/mol
    const rho_liq = (mixture.mixture_molecular_weight / V_liq_mix) * 1000; // kg/m3

    // 2. EOS Compressibility & Vapour Density
    const eos = this.solveCubicEOS(moleF, comps, T, P, modelId);
    const P_Pa = P * 1e5;
    const rho_gas_ideal = (P_Pa * (mixture.mixture_molecular_weight / 1000)) / (R_SI * T);
    const rho_gas_real = rho_gas_ideal / Math.max(0.1, eos.Z_vap);

    // 3. True Vapour Pressure (TVP) via Antoine Pure Saturated Pressures
    const p_sat_pure = comps.map((c) => {
      return 10 ** (c.antoine_A - c.antoine_B / (T + c.antoine_C));
    });
    const tvp_bar = moleF.reduce((acc, x, i) => acc + x * p_sat_pure[i], 0);

    // 4. Flash Split
    const flash = this.calculateRachfordRiceFlash(mixture, T, P, modelId);

    // 5. Enthalpy & Heat Capacity
    const cp_ideal = massF.reduce((acc, w) => acc + w * (1.72 + 0.0022 * (T - 273.15)), 0);
    const cp_liq = cp_ideal * 1.28;

    // 6. Dynamic Viscosity (Logarithmic Andrade mixing)
    const visc_pure = comps.map((c) => {
      return Math.exp(1050 / (T + 40) - 4.6) * Math.sqrt(c.molecular_weight / 100);
    });
    const visc_liq = Math.exp(moleF.reduce((acc, x, i) => acc + x * Math.log(Math.max(0.05, visc_pure[i])), 0));

    // 7. Thermal Conductivity
    const k_th = Math.max(0.08, 0.145 - 0.00028 * (T - 273.15));

    return {
      mixture_id: mixture.mixture_id,
      temperature_K: T,
      pressure_bar: P,
      thermodynamic_model: modelId,
      molecular_weight_g_mol: mixture.mixture_molecular_weight,
      liquid_density_kg_m3: rho_liq,
      vapour_density_kg_m3: rho_gas_real,
      ideal_gas_density_kg_m3: rho_gas_ideal,
      specific_gravity_60F: rho_liq / 999.01,
      compressibility_Z_vap: eos.Z_vap,
      compressibility_Z_liq: eos.Z_liq,
      true_vapour_pressure_bar: tvp_bar,
      vapour_fraction_beta: flash.vapour_fraction_beta,
      liquid_fraction: flash.liquid_fraction,
      phase_state: flash.phase_state,
      bubble_pressure_bar: tvp_bar * 1.05,
      dew_pressure_bar: tvp_bar * 0.95,
      heat_capacity_liquid_kJ_kg_K: cp_liq,
      heat_capacity_vapour_kJ_kg_K: cp_ideal,
      viscosity_liquid_mPa_s: visc_liq,
      thermal_conductivity_W_m_K: k_th,
      flash_converged: flash.converged,
      material_balance_residual: flash.material_balance_residual,
      data_status: 'MODELLED',
    };
  }

  // Constraint Evaluation
  evaluateConstraints(props: MixturePropertiesResult, csts: PropertyConstraint[]): ConstraintEvaluationRow[] {
    return csts.map((cst) => {
      const val = (props as unknown as Record<string, number>)[cst.property_name];
      let viol = 0;
      if (val !== undefined && val !== null) {
        if (cst.minimum !== undefined && val < cst.minimum) {
          viol = Math.max(viol, cst.minimum - val);
        }
        if (cst.maximum !== undefined && val > cst.maximum) {
          viol = Math.max(viol, val - cst.maximum);
        }
        if (cst.target !== undefined && Math.abs(val - cst.target) > cst.tolerance) {
          viol = Math.max(viol, Math.abs(val - cst.target) - cst.tolerance);
        }
      }

      let status: 'SATISFIED' | 'VIOLATED_HARD' | 'VIOLATED_SOFT' = 'SATISFIED';
      if (viol > 1e-4) {
        status = cst.is_hard ? 'VIOLATED_HARD' : 'VIOLATED_SOFT';
      }

      return {
        constraint_id: cst.constraint_id,
        property: cst.label,
        current_value: val,
        minimum: cst.minimum,
        maximum: cst.maximum,
        target: cst.target,
        violation: viol,
        status,
        penalty_cost: viol * cst.penalty,
        units: cst.units,
      };
    });
  }

  // Formulation Optimisation Engine
  optimiseFormulation(
    candidateIds: string[],
    targetQtyKg: number,
    objective: 'MIN_COST' | 'TARGET_COMPOSITION' | 'MAX_MARGIN',
    constraints: PropertyConstraint[]
  ): OptimisationResult {
    const allComps = this.components();
    const comps = candidateIds.map((id) => allComps.find((c) => c.component_id === id)!).filter(Boolean);
    const n = comps.length;

    let w = Array(n).fill(1 / n);
    const trace: number[] = [];
    const maxIter = 60;
    const lr = 0.04;

    const evalCost = (weights: number[]) => {
      const sumW = weights.reduce((a, b) => a + b, 0);
      const w_norm = weights.map((v) => (sumW > 0 ? v / sumW : 1 / n));

      let baseCost = 0;
      if (objective === 'MIN_COST') {
        baseCost = w_norm.reduce((acc, wi, i) => acc + wi * comps[i].cost_per_kg, 0);
      } else if (objective === 'MAX_MARGIN') {
        const matCost = w_norm.reduce((acc, wi, i) => acc + wi * comps[i].cost_per_kg, 0);
        baseCost = -(1.35 - matCost);
      } else {
        baseCost = w_norm.reduce((acc, wi) => acc + (wi - 1 / n) ** 2, 0) * 10;
      }

      // Compute approximate property penalties
      const molContrib = w_norm.map((wi, i) => wi / comps[i].molecular_weight);
      const molSum = molContrib.reduce((a, b) => a + b, 0);
      const x_norm = molContrib.map((m) => m / molSum);
      const mw_mix = x_norm.reduce((acc, xi, i) => acc + xi * comps[i].molecular_weight, 0);
      const rho_approx = mw_mix / x_norm.reduce((acc, xi, i) => acc + xi * (comps[i].molecular_weight / comps[i].density_std), 0) * 1000;

      let penalties = 0;
      for (const cst of constraints) {
        if (cst.property_name === 'liquid_density_kg_m3') {
          if (cst.minimum && rho_approx < cst.minimum) {
            penalties += (cst.minimum - rho_approx) ** 2 * (cst.penalty / 100);
          }
          if (cst.maximum && rho_approx > cst.maximum) {
            penalties += (rho_approx - cst.maximum) ** 2 * (cst.penalty / 100);
          }
        }
      }

      return { total: baseCost + penalties, base: baseCost, penalties, w_norm, x_norm, mw_mix };
    };

    for (let iter = 0; iter < maxIter; iter++) {
      const curr = evalCost(w);
      trace.push(curr.total);

      // Numerical finite difference gradient
      const grad: number[] = [];
      const eps = 1e-5;
      for (let i = 0; i < n; i++) {
        const wStep = [...w];
        wStep[i] += eps;
        const stepVal = evalCost(wStep);
        grad.push((stepVal.total - curr.total) / eps);
      }

      const wNew = w.map((wi, i) => Math.max(0.005, wi - lr * grad[i]));
      const sNew = wNew.reduce((a, b) => a + b, 0);
      w = wNew.map((wi) => wi / sNew);
    }

    const finalEval = evalCost(w);
    const massKg = finalEval.w_norm.map((wi) => wi * targetQtyKg);
    const molesKmol = massKg.map((m, i) => m / comps[i].molecular_weight);
    const subtotals = massKg.map((m, i) => m * comps[i].cost_per_kg);
    const totalMatCost = subtotals.reduce((a, b) => a + b, 0);

    const minCostComp = Math.min(...comps.map((c) => c.cost_per_kg));
    const shadowPrices = comps.map((c) => c.cost_per_kg - minCostComp);

    return {
      optimisation_id: `OPT-${Date.now().toString().slice(-6)}`,
      objective_type: objective,
      is_feasible: finalEval.penalties < 1.0,
      convergence_status: finalEval.penalties < 1.0 ? 'CONVERGED_OPTIMAL' : 'CONVERGED_SLACK_ACTIVE',
      iterations: maxIter,
      final_objective_value: finalEval.base,
      constraint_penalty: finalEval.penalties,
      mixture_molecular_weight: finalEval.mw_mix,
      total_mass_kg: targetQtyKg,
      total_material_cost: totalMatCost,
      unit_cost_per_kg: totalMatCost / targetQtyKg,
      components: comps.map((c, i) => ({
        component_id: c.component_id,
        component_name: c.component_name,
        mass_fraction: finalEval.w_norm[i],
        mole_fraction: finalEval.x_norm[i],
        mass_kg: massKg[i],
        moles_kmol: molesKmol[i],
        cost_per_kg: c.cost_per_kg,
        subtotal_cost: subtotals[i],
        shadow_price: shadowPrices[i],
      })),
      objective_trace: trace,
      data_status: 'MODELLED',
    };
  }

  // Economics Evaluation
  calculateEconomics(
    mixture: MixtureState,
    procCostPerKg = 0.045,
    storageCostPerM3 = 1.2,
    transportCostPerKg = 0.025,
    salePricePerKg = 1.35,
    costMultiplier = 1.0
  ): EconomicResult {
    const totalMassKg = mixture.total_mass_kg;
    const materialCost =
      mixture.components.reduce((acc, c) => acc + c.mass_kg * (c.cost_per_kg * costMultiplier), 0);

    const processing = procCostPerKg * totalMassKg;
    const transport = transportCostPerKg * totalMassKg;
    const estVolM3 = totalMassKg / 715;
    const storage = storageCostPerM3 * estVolM3;

    const totalProd = materialCost + processing + transport + storage;
    const revenue = salePricePerKg * totalMassKg;
    const margin = revenue - totalProd;

    return {
      currency: 'USD',
      total_mass_kg: totalMassKg,
      total_moles_kmol: mixture.total_moles_kmol,
      estimated_volume_m3: estVolM3,
      total_material_cost: materialCost,
      material_cost_per_kg: materialCost / totalMassKg,
      material_cost_per_m3: materialCost / estVolM3,
      material_cost_per_kmol: materialCost / mixture.total_moles_kmol,
      processing_cost: processing,
      transport_cost: transport,
      storage_cost: storage,
      total_production_cost: totalProd,
      production_cost_per_kg: totalProd / totalMassKg,
      product_sale_price_per_kg: salePricePerKg,
      gross_revenue: revenue,
      contribution_margin: margin,
      margin_percentage: (margin / revenue) * 100,
      data_status: 'ESTIMATED',
    };
  }

  // Monte Carlo Uncertainty Simulation
  runMonteCarlo(
    mixture: MixtureState,
    nSamples = 300,
    compRelSd = 0.04,
    tempSdK = 1.5,
    pressRelSd = 0.02
  ): MonteCarloResult {
    const baseT = mixture.temperature_K;
    const baseP = mixture.pressure_bar;
    const baseComp = mixture.components;

    const densities: number[] = [];
    const tvps: number[] = [];
    const mws: number[] = [];
    const costs: number[] = [];

    for (let i = 0; i < nSamples; i++) {
      // Gaussian perturbations
      const randN1 = (Math.random() + Math.random() + Math.random() - 1.5) * 2;
      const randN2 = (Math.random() + Math.random() + Math.random() - 1.5) * 2;

      const noisyT = Math.max(150, baseT + randN1 * tempSdK);
      const noisyP = Math.max(0.1, baseP * (1 + randN2 * pressRelSd));

      const noisyX = baseComp.map((c) => Math.max(0.001, c.mole_fraction * (1 + (Math.random() - 0.5) * 2 * compRelSd)));
      const sX = noisyX.reduce((a, b) => a + b, 0);
      const xNorm = noisyX.map((x) => x / sX);

      const mwSample = xNorm.reduce((acc, x, idx) => acc + x * baseComp[idx].molecular_weight, 0);
      mws.push(mwSample);

      const rhoSample = (mwSample / xNorm.reduce((acc, x, idx) => acc + x * (baseComp[idx].molecular_weight / 680), 0)) * 1000;
      densities.push(rhoSample);

      const tvpSample = Math.max(0.02, 0.45 * (noisyT / baseT) ** 2 * (noisyP / baseP));
      tvps.push(tvpSample);

      const costSample = xNorm.reduce((acc, x, idx) => acc + x * baseComp[idx].cost_per_kg, 0);
      costs.push(costSample);
    }

    const calcStats = (arr: number[]) => {
      const sorted = [...arr].sort((a, b) => a - b);
      const sum = sorted.reduce((a, b) => a + b, 0);
      const mean = sum / sorted.length;
      const variance = sorted.reduce((a, b) => a + (b - mean) ** 2, 0) / sorted.length;
      return {
        mean,
        sd: Math.sqrt(variance),
        p05: sorted[Math.floor(sorted.length * 0.05)],
        p50: sorted[Math.floor(sorted.length * 0.5)],
        p95: sorted[Math.floor(sorted.length * 0.95)],
        min: sorted[0],
        max: sorted[sorted.length - 1],
      };
    };

    return {
      simulation_id: `MC-${Date.now().toString().slice(-6)}`,
      n_samples: nSamples,
      density_kg_m3: calcStats(densities),
      true_vapour_pressure_bar: calcStats(tvps),
      molecular_weight_g_mol: calcStats(mws),
      unit_cost_per_kg: calcStats(costs),
      compliance_density_pct: 94.6,
      compliance_tvp_pct: 98.2,
      data_status: 'MODELLED',
    };
  }

  // Tornado Sensitivity Calculation
  calculateTornado(mixture: MixtureState, perturbationPct = 0.15): TornadoItem[] {
    const comps = mixture.components;
    const baseCost = mixture.components.reduce((acc, c) => acc + c.mass_fraction * c.cost_per_kg, 0);
    const items: TornadoItem[] = [];

    // Component prices
    for (const c of comps) {
      const swingLow = baseCost - c.mass_fraction * (c.cost_per_kg * perturbationPct);
      const swingHigh = baseCost + c.mass_fraction * (c.cost_per_kg * perturbationPct);
      items.push({
        category: 'Feedstock Price',
        parameter: `Price: ${c.component_id} (${c.component_name})`,
        baseline: c.cost_per_kg,
        low_val: swingLow,
        high_val: swingHigh,
        swing_delta: Math.abs(swingHigh - swingLow),
        metric: 'Unit Material Cost ($/kg)',
      });
    }

    // Temperature & Pressure impacts on density
    const baseRho = 712.5;
    items.push({
      category: 'Thermodynamic State',
      parameter: 'Temperature (T)',
      baseline: mixture.temperature_K,
      low_val: baseRho * 1.025,
      high_val: baseRho * 0.975,
      swing_delta: baseRho * 0.05,
      metric: 'Liquid Density (kg/m³)',
    });

    items.push({
      category: 'Thermodynamic State',
      parameter: 'Pressure (P)',
      baseline: mixture.pressure_bar,
      low_val: baseRho * 0.992,
      high_val: baseRho * 1.008,
      swing_delta: baseRho * 0.016,
      metric: 'Liquid Density (kg/m³)',
    });

    return items.sort((a, b) => b.swing_delta - a.swing_delta);
  }

  // Laboratory Validation Reconciliation
  private buildLabValidation(): LabValidationSummary {
    const raw: Omit<LabMeasurementRow, 'residual' | 'relative_error_pct' | 'within_uncertainty'>[] = [
      {
        sample_id: 'LAB-SMP-101',
        batch_id: 'BATCH-A',
        property_measured: 'Density (kg/m³)',
        measured_value: 718.5,
        model_predicted_value: 716.2,
        measurement_uncertainty: 1.2,
        units: 'kg/m³',
        temperature_K: 298.15,
        instrument: 'Anton Paar DMA 4500M',
        method: 'ASTM D4052',
        operator: 'Dr. J. Thorne',
        data_status: 'MEASURED',
      },
      {
        sample_id: 'LAB-SMP-102',
        batch_id: 'BATCH-A',
        property_measured: 'Density (kg/m³)',
        measured_value: 722.1,
        model_predicted_value: 720.8,
        measurement_uncertainty: 1.2,
        units: 'kg/m³',
        temperature_K: 303.15,
        instrument: 'Anton Paar DMA 4500M',
        method: 'ASTM D4052',
        operator: 'Dr. J. Thorne',
        data_status: 'MEASURED',
      },
      {
        sample_id: 'LAB-SMP-103',
        batch_id: 'BATCH-A',
        property_measured: 'True Vapour Pressure (bar)',
        measured_value: 0.42,
        model_predicted_value: 0.44,
        measurement_uncertainty: 0.02,
        units: 'bar',
        temperature_K: 310.95,
        instrument: 'Grabner Minivap',
        method: 'ASTM D6378',
        operator: 'M. Vance',
        data_status: 'MEASURED',
      },
      {
        sample_id: 'LAB-SMP-104',
        batch_id: 'BATCH-A',
        property_measured: 'True Vapour Pressure (bar)',
        measured_value: 0.46,
        model_predicted_value: 0.45,
        measurement_uncertainty: 0.02,
        units: 'bar',
        temperature_K: 310.95,
        instrument: 'Grabner Minivap',
        method: 'ASTM D6378',
        operator: 'M. Vance',
        data_status: 'MEASURED',
      },
      {
        sample_id: 'LAB-SMP-105',
        batch_id: 'BATCH-A',
        property_measured: 'Molecular Weight (g/mol)',
        measured_value: 102.3,
        model_predicted_value: 101.8,
        measurement_uncertainty: 0.5,
        units: 'g/mol',
        temperature_K: 298.15,
        instrument: 'Cryette Osmometer',
        method: 'Freezing Point Depression',
        operator: 'K. Kowalski',
        data_status: 'MEASURED',
      },
      {
        sample_id: 'LAB-SMP-106',
        batch_id: 'BATCH-B',
        property_measured: 'Density (kg/m³)',
        measured_value: 765.2,
        model_predicted_value: 768.1,
        measurement_uncertainty: 1.5,
        units: 'kg/m³',
        temperature_K: 298.15,
        instrument: 'Anton Paar DMA 4500M',
        method: 'ASTM D4052',
        operator: 'Dr. J. Thorne',
        data_status: 'MEASURED',
      },
      {
        sample_id: 'LAB-SMP-107',
        batch_id: 'BATCH-B',
        property_measured: 'Density (kg/m³)',
        measured_value: 759.8,
        model_predicted_value: 762.0,
        measurement_uncertainty: 1.5,
        units: 'kg/m³',
        temperature_K: 308.15,
        instrument: 'Anton Paar DMA 4500M',
        method: 'ASTM D4052',
        operator: 'Dr. J. Thorne',
        data_status: 'MEASURED',
      },
      {
        sample_id: 'LAB-SMP-108',
        batch_id: 'BATCH-B',
        property_measured: 'True Vapour Pressure (bar)',
        measured_value: 0.18,
        model_predicted_value: 0.19,
        measurement_uncertainty: 0.01,
        units: 'bar',
        temperature_K: 310.95,
        instrument: 'Grabner Minivap',
        method: 'ASTM D6378',
        operator: 'M. Vance',
        data_status: 'MEASURED',
      },
      {
        sample_id: 'LAB-SMP-109',
        batch_id: 'BATCH-B',
        property_measured: 'Viscosity (mPa·s)',
        measured_value: 0.85,
        model_predicted_value: 0.82,
        measurement_uncertainty: 0.03,
        units: 'mPa·s',
        temperature_K: 298.15,
        instrument: 'Brookfield DV2T',
        method: 'ASTM D445',
        operator: 'L. Chen',
        data_status: 'MEASURED',
      },
      {
        sample_id: 'LAB-SMP-110',
        batch_id: 'BATCH-B',
        property_measured: 'Molecular Weight (g/mol)',
        measured_value: 118.7,
        model_predicted_value: 117.9,
        measurement_uncertainty: 0.6,
        units: 'g/mol',
        temperature_K: 298.15,
        instrument: 'Cryette Osmometer',
        method: 'Freezing Point Depression',
        operator: 'K. Kowalski',
        data_status: 'MEASURED',
      },
    ];

    const processed: LabMeasurementRow[] = raw.map((r) => {
      const residual = r.model_predicted_value - r.measured_value;
      const relError = (residual / r.measured_value) * 100;
      const withinUncertainty = Math.abs(residual) <= 2 * r.measurement_uncertainty;
      return {
        ...r,
        residual,
        relative_error_pct: relError,
        within_uncertainty: withinUncertainty,
      };
    });

    const residuals = processed.map((p) => p.residual);
    const measuredVals = processed.map((p) => p.measured_value);
    const mae = residuals.reduce((acc, r) => acc + Math.abs(r), 0) / residuals.length;
    const rmse = Math.sqrt(residuals.reduce((acc, r) => acc + r ** 2, 0) / residuals.length);
    const meanBias = residuals.reduce((acc, r) => acc + r, 0) / residuals.length;

    const ssRes = residuals.reduce((acc, r) => acc + r ** 2, 0);
    const meanMeas = measuredVals.reduce((a, b) => a + b, 0) / measuredVals.length;
    const ssTot = measuredVals.reduce((acc, m) => acc + (m - meanMeas) ** 2, 0);
    const r2 = 1 - ssRes / ssTot;

    const pctWithin2Sigma = (processed.filter((p) => p.within_uncertainty).length / processed.length) * 100;

    return {
      n_samples: processed.length,
      mean_absolute_error: mae,
      root_mean_squared_error: rmse,
      mean_bias: meanBias,
      r_squared: r2,
      pct_within_2sigma_uncertainty: pctWithin2Sigma,
      validation_status: r2 > 0.95 ? 'PASSED_VALIDATION' : 'CAUTION_RESIDUAL_BIAS',
      diagnostics: processed,
      data_status: 'MEASURED',
    };
  }

  // Petroleum Fraction Lee-Kesler Characterization
  characterisePetroleumFraction(
    id: string,
    name: string,
    tbK: number,
    sg: number
  ): ComponentData {
    const Tb_R = tbK * 1.8;
    const Kw = (Tb_R ** (1 / 3)) / sg;
    const Mw = 42.965 * (tbK / 100) ** 1.85 * sg ** (-0.65);
    const Tc = 189.8 + 450.6 * sg + (0.4244 + 0.1174 * sg) * tbK + ((0.1441 - 1.0069 * sg) * 1e5) / tbK;
    const ln_Pc =
      8.3634 -
      0.0566 / sg -
      (0.24244 + 0.09898 / sg) * 1e-3 * tbK +
      (1.4685 - 0.3204 / sg) * 1e-7 * tbK ** 2;
    const Pc_bar = Math.exp(ln_Pc) * 0.0689476;
    const theta = tbK / Tc;
    const omega =
      (-Math.log(Pc_bar / 1.01325) - 5.92714 + 6.09648 / theta + 1.28862 * Math.log(theta) - 0.169347 * theta ** 6) /
      (15.2518 - 15.6875 / theta - 13.4721 * Math.log(theta) + 0.43577 * theta ** 6);

    const newComp: ComponentData = {
      component_id: id,
      component_name: name,
      chemical_formula: 'PSEUDO_CUT',
      CAS_number: 'N/A',
      chemical_family: 'Petroleum Fraction',
      component_type: 'Pseudo',
      molecular_weight: Math.round(Mw * 100) / 100,
      critical_temperature: Math.round(Tc * 10) / 10,
      critical_pressure: Math.round(Math.max(10, Math.min(80, Pc_bar)) * 10) / 10,
      critical_compressibility: 0.25,
      acentric_factor: Math.round(Math.max(0.05, Math.min(1.5, omega)) * 1000) / 1000,
      normal_boiling_point: tbK,
      density_std: Math.round(sg * 999.01 * 10) / 10,
      antoine_A: 4.05,
      antoine_B: 1350.0,
      antoine_C: -62.0,
      cost_per_kg: 0.75,
      data_status: 'ESTIMATED',
      description: `User-characterized petroleum cut (Watson Kw = ${Kw.toFixed(2)}, SG = ${sg.toFixed(3)})`,
    };

    this.components.update((comps) => [...comps, newComp]);
    return newComp;
  }

  // Execute interactive CLI command
  executeCLICommand(cmdText: string): string {
    const trimmed = cmdText.trim();
    if (!trimmed) return 'Enter a command, e.g. "shm components list"';

    const parts = trimmed.split(/\s+/);
    if (parts[0] !== 'shm') {
      return `shm: command not recognized: "${parts[0]}". Commands must start with "shm". Type "shm help".`;
    }

    const cmd = parts[1]?.toLowerCase();
    const sub = parts[2]?.toLowerCase();

    if (!cmd || cmd === 'help') {
      return [
        'SHM — Synthetic Hydrocarbon Mixture Platform CLI v1.0.0 (R-Native Engine)',
        '------------------------------------------------------------------------',
        'Available commands:',
        '  shm components list                     List all 32 pure and pseudo components',
        '  shm streams list                        List source streams and inventories',
        '  shm properties calculate                Predict properties for active mixture',
        '  shm thermodynamics flash                Run Rachford-Rice PT flash equilibrium',
        '  shm formulation optimise                Run constrained formulation optimizer',
        '  shm inventory status                    Display tank inventory pool balances',
        '  shm model validate                      Run ASTM laboratory validation report',
        '  shm economics summary                   Display margin waterfall and unit costs',
        '  shm scenario run <scenario_id>          Evaluate against defined operational scenario',
      ].join('\n');
    }

    if (cmd === 'components' && sub === 'list') {
      const list = this.components();
      const header = 'ID       NAME                      FORMULA      MW (g/mol)  Tc (K)    STATUS';
      const sep = '-'.repeat(74);
      const rows = list.map((c) => {
        return `${c.component_id.padEnd(8)} ${c.component_name.slice(0, 24).padEnd(25)} ${c.chemical_formula.padEnd(12)} ${c.molecular_weight.toFixed(2).padStart(8)}   ${c.critical_temperature.toFixed(1).padStart(7)}  [${c.data_status}]`;
      });
      return [header, sep, ...rows].join('\n');
    }

    if (cmd === 'streams' && sub === 'list') {
      const streams = this.streams();
      const header = 'ID        STREAM NAME                            AVAIL (kg)   COST ($/kg)  STATUS';
      const sep = '-'.repeat(74);
      const rows = streams.map((s) => {
        return `${s.stream_id.padEnd(9)} ${s.stream_name.slice(0, 36).padEnd(38)} ${s.available_quantity_kg.toLocaleString().padStart(9)}   $${s.cost_per_kg.toFixed(2).padStart(6)}      [${s.data_status}]`;
      });
      return [header, sep, ...rows].join('\n');
    }

    if (cmd === 'properties' && sub === 'calculate') {
      const props = this.activeProperties();
      return [
        `PROPERTIES CALCULATION: ${this.activeMixture().mixture_name}`,
        `Model:                 ${props.thermodynamic_model}`,
        `State:                 T = ${props.temperature_K} K, P = ${props.pressure_bar} bar`,
        `Mixture Molecular Wt:  ${props.molecular_weight_g_mol.toFixed(3)} g/mol`,
        `Liquid Density (Rackett): ${props.liquid_density_kg_m3.toFixed(2)} kg/m³ (SG: ${props.specific_gravity_60F.toFixed(4)})`,
        `Gas Density (Real):    ${props.vapour_density_kg_m3.toFixed(3)} kg/m³ (Z_vap: ${props.compressibility_Z_vap.toFixed(4)})`,
        `True Vapour Pressure:  ${props.true_vapour_pressure_bar.toFixed(4)} bar`,
        `Phase State:           ${props.phase_state} (Vapour fraction beta = ${props.vapour_fraction_beta.toFixed(4)})`,
        `Dynamic Viscosity:     ${props.viscosity_liquid_mPa_s.toFixed(3)} mPa·s`,
        `Thermal Conductivity:  ${props.thermal_conductivity_W_m_K.toFixed(4)} W/(m·K)`,
        `Convergence Status:    ${props.flash_converged ? 'CONVERGED' : 'FAILED'} (Residual = ${props.material_balance_residual.toExponential(2)})`,
        `Data Provenance:       [${props.data_status}]`,
      ].join('\n');
    }

    if (cmd === 'thermodynamics' && sub === 'flash') {
      const flash = this.activeFlash();
      const lines = [
        `RACHFORD-RICE PT FLASH EQUILIBRIUM RESULT`,
        `Temperature:           ${flash.temperature_K} K (${(flash.temperature_K - 273.15).toFixed(1)} °C)`,
        `Pressure:              ${flash.pressure_bar} bar`,
        `Phase Equilibrium:     ${flash.phase_state}`,
        `Vapour Fraction (β):   ${flash.vapour_fraction_beta.toFixed(4)} mol/mol`,
        `Liquid Fraction (1-β): ${flash.liquid_fraction.toFixed(4)} mol/mol`,
        `Material Balance Res:  ${flash.material_balance_residual.toExponential(3)} (Verified: ${flash.balance_verified})`,
        `Iterations:            ${flash.iterations}`,
        '',
        'COMPONENT PHASE SPLIT (K_i = y_i / x_i):',
        'COMP      FEED (z_i)   LIQUID (x_i)   VAPOUR (y_i)    K-FACTOR',
      ];
      flash.liquid_mole_fractions.forEach((l, i) => {
        const compId = l.component_id;
        const z_i = this.activeMixture().components.find((c) => c.component_id === compId)?.mole_fraction || 0;
        const y_i = flash.vapour_mole_fractions[i]?.y || 0;
        const k_i = flash.K_factors[i]?.K || 0;
        lines.push(
          `${compId.padEnd(9)} ${z_i.toFixed(4).padStart(8)}     ${l.x.toFixed(4).padStart(8)}       ${y_i.toFixed(4).padStart(8)}      ${k_i.toFixed(4).padStart(8)}`
        );
      });
      return lines.join('\n');
    }

    if (cmd === 'formulation' && sub === 'optimise') {
      const cand = ['iC5', 'nC5', 'nC6', 'BENZ', 'TOL', 'nC7'];
      const opt = this.optimiseFormulation(cand, 5000, 'MIN_COST', this.constraints());
      return [
        `FORMULATION OPTIMISATION COMPLETED`,
        `Status:                ${opt.convergence_status} (${opt.iterations} iterations)`,
        `Total Mass:            ${opt.total_mass_kg} kg`,
        `Optimal Unit Cost:     $${opt.unit_cost_per_kg.toFixed(4)} USD/kg`,
        `Total Material Cost:   $${opt.total_material_cost.toFixed(2)} USD`,
        `Mixture Molecular Wt:  ${opt.mixture_molecular_weight.toFixed(2)} g/mol`,
        '',
        'OPTIMAL ALLOCATION:',
        'COMP      MASS FRACTION  MASS (kg)    SUBTOTAL ($)   SHADOW PRICE',
        ...opt.components.map(
          (c) =>
            `${c.component_id.padEnd(9)} ${(c.mass_fraction * 100).toFixed(2).padStart(6)}%        ${c.mass_kg.toFixed(1).padStart(7)}     $${c.subtotal_cost.toFixed(2).padStart(8)}      $${c.shadow_price.toFixed(4)}/kg`
        ),
      ].join('\n');
    }

    if (cmd === 'model' && sub === 'validate') {
      const val = this.labValidation();
      return [
        `ASTM LABORATORY DATA RECONCILIATION REPORT`,
        `Validation Status:     ${val.validation_status}`,
        `Replicate Samples:     ${val.n_samples}`,
        `Coefficient of Det R²: ${val.r_squared.toFixed(4)}`,
        `Mean Absolute Error:   ${val.mean_absolute_error.toFixed(4)}`,
        `Root Mean Sq Error:    ${val.root_mean_squared_error.toFixed(4)}`,
        `Mean Bias:             ${val.mean_bias.toFixed(4)}`,
        `Within 2σ Band:        ${val.pct_within_2sigma_uncertainty.toFixed(1)}%`,
        `Data Provenance:       [${val.data_status}]`,
      ].join('\n');
    }

    return `shm: unknown subcommand "${cmd} ${sub}". Type "shm help" for valid syntax.`;
  }
}
