// Synthetic Hydrocarbon Mixture (SHM) - Core Domain Models

export type DataStatus =
  | 'MEASURED'
  | 'SYNTHETIC'
  | 'HISTORICAL'
  | 'MODELLED'
  | 'ESTIMATED'
  | 'IMPORTED'
  | 'STALE'
  | 'UNAVAILABLE';

export type CompositionBasis = 'mole' | 'mass' | 'volume';

export type ChemicalFamily =
  | 'Paraffin'
  | 'Isoparaffin'
  | 'Olefin'
  | 'Naphthene'
  | 'Aromatic'
  | 'Petroleum Fraction'
  | 'Inorganic Gas'
  | 'Other';

export interface ComponentData {
  component_id: string;
  component_name: string;
  chemical_formula: string;
  CAS_number: string;
  chemical_family: ChemicalFamily;
  component_type: 'Pure' | 'Pseudo';
  molecular_weight: number; // g/mol
  critical_temperature: number; // K
  critical_pressure: number; // bar
  critical_compressibility: number;
  acentric_factor: number;
  normal_boiling_point: number; // K
  density_std: number; // kg/m3 at standard reference
  antoine_A: number; // log10(P/bar) = A - B/(T+C)
  antoine_B: number;
  antoine_C: number;
  cost_per_kg: number; // USD/kg
  data_status: DataStatus;
  description?: string;
}

export interface StreamData {
  stream_id: string;
  stream_name: string;
  source: string;
  temperature: number; // K
  pressure: number; // bar
  available_quantity_kg: number;
  reserved_quantity_kg: number;
  cost_per_kg: number;
  quality_status: 'CERTIFIED' | 'ANALYZED' | 'HIGH_PURITY' | 'RAW';
  data_status: DataStatus;
  composition_basis: CompositionBasis;
  composition: { component_id: string; fraction: number }[];
}

export interface MixtureComponentRow {
  component_id: string;
  component_name: string;
  chemical_formula: string;
  chemical_family: ChemicalFamily;
  molecular_weight: number;
  mole_fraction: number;
  mass_fraction: number;
  volume_fraction: number;
  mass_kg: number;
  moles_kmol: number;
  cost_per_kg: number;
  data_status: DataStatus;
}

export interface MixtureState {
  mixture_id: string;
  mixture_name: string;
  timestamp: string;
  temperature_K: number;
  pressure_bar: number;
  basis_specified: CompositionBasis;
  total_quantity: number;
  quantity_unit: 'kg' | 'kmol' | 'm3';
  mixture_molecular_weight: number;
  total_mass_kg: number;
  total_moles_kmol: number;
  components: MixtureComponentRow[];
  data_status: DataStatus;
}

export interface ThermoModelMetadata {
  model_id: string;
  model_name: string;
  version: string;
  model_type: string;
  primary_phases: string;
  validity_temperature_K: string;
  validity_pressure_bar: string;
  approval_status: 'APPROVED' | 'APPROVED_BENCHMARK' | 'APPROVED_PSEUDO';
  data_status: DataStatus;
}

export interface FlashResult {
  flash_type: string;
  model: string;
  temperature_K: number;
  pressure_bar: number;
  vapour_fraction_beta: number;
  liquid_fraction: number;
  phase_state: 'Subcooled Liquid' | 'Two-Phase (VLE)' | 'Superheated Vapour';
  converged: boolean;
  iterations: number;
  K_factors: { component_id: string; K: number }[];
  liquid_mole_fractions: { component_id: string; x: number }[];
  vapour_mole_fractions: { component_id: string; y: number }[];
  material_balance_residual: number;
  balance_verified: boolean;
  data_status: DataStatus;
}

export interface MixturePropertiesResult {
  mixture_id: string;
  temperature_K: number;
  pressure_bar: number;
  thermodynamic_model: string;
  molecular_weight_g_mol: number;
  liquid_density_kg_m3: number;
  vapour_density_kg_m3: number;
  ideal_gas_density_kg_m3: number;
  specific_gravity_60F: number;
  compressibility_Z_vap: number;
  compressibility_Z_liq: number;
  true_vapour_pressure_bar: number;
  vapour_fraction_beta: number;
  liquid_fraction: number;
  phase_state: string;
  bubble_pressure_bar: number;
  dew_pressure_bar: number;
  heat_capacity_liquid_kJ_kg_K: number;
  heat_capacity_vapour_kJ_kg_K: number;
  viscosity_liquid_mPa_s: number;
  thermal_conductivity_W_m_K: number;
  watson_K_factor?: number;
  flash_converged: boolean;
  material_balance_residual: number;
  data_status: DataStatus;
}

export interface PropertyConstraint {
  constraint_id: string;
  property_name: string;
  label: string;
  minimum?: number;
  maximum?: number;
  target?: number;
  tolerance: number;
  is_hard: boolean;
  penalty: number;
  units: string;
}

export interface ConstraintEvaluationRow {
  constraint_id: string;
  property: string;
  current_value: number;
  minimum?: number;
  maximum?: number;
  target?: number;
  violation: number;
  status: 'SATISFIED' | 'VIOLATED_HARD' | 'VIOLATED_SOFT';
  penalty_cost: number;
  units: string;
}

export interface OptimisationResult {
  optimisation_id: string;
  objective_type: 'MIN_COST' | 'TARGET_COMPOSITION' | 'MAX_MARGIN';
  is_feasible: boolean;
  convergence_status: string;
  iterations: number;
  final_objective_value: number;
  constraint_penalty: number;
  mixture_molecular_weight: number;
  total_mass_kg: number;
  total_material_cost: number;
  unit_cost_per_kg: number;
  components: {
    component_id: string;
    component_name: string;
    mass_fraction: number;
    mole_fraction: number;
    mass_kg: number;
    moles_kmol: number;
    cost_per_kg: number;
    subtotal_cost: number;
    shadow_price: number;
  }[];
  objective_trace: number[];
  data_status: DataStatus;
}

export interface EconomicResult {
  currency: string;
  total_mass_kg: number;
  total_moles_kmol: number;
  estimated_volume_m3: number;
  total_material_cost: number;
  material_cost_per_kg: number;
  material_cost_per_m3: number;
  material_cost_per_kmol: number;
  processing_cost: number;
  transport_cost: number;
  storage_cost: number;
  total_production_cost: number;
  production_cost_per_kg: number;
  product_sale_price_per_kg: number;
  gross_revenue: number;
  contribution_margin: number;
  margin_percentage: number;
  data_status: DataStatus;
}

export interface LabMeasurementRow {
  sample_id: string;
  batch_id: string;
  property_measured: string;
  measured_value: number;
  model_predicted_value: number;
  measurement_uncertainty: number;
  units: string;
  temperature_K: number;
  instrument: string;
  method: string;
  operator: string;
  data_status: DataStatus;
  residual: number;
  relative_error_pct: number;
  within_uncertainty: boolean;
}

export interface LabValidationSummary {
  n_samples: number;
  mean_absolute_error: number;
  root_mean_squared_error: number;
  mean_bias: number;
  r_squared: number;
  pct_within_2sigma_uncertainty: number;
  validation_status: 'PASSED_VALIDATION' | 'CAUTION_RESIDUAL_BIAS';
  diagnostics: LabMeasurementRow[];
  data_status: DataStatus;
}

export interface MonteCarloResult {
  simulation_id: string;
  n_samples: number;
  density_kg_m3: { mean: number; sd: number; p05: number; p50: number; p95: number; min: number; max: number };
  true_vapour_pressure_bar: { mean: number; sd: number; p05: number; p50: number; p95: number; min: number; max: number };
  molecular_weight_g_mol: { mean: number; sd: number; p05: number; p50: number; p95: number; min: number; max: number };
  unit_cost_per_kg: { mean: number; sd: number; p05: number; p50: number; p95: number; min: number; max: number };
  compliance_density_pct: number;
  compliance_tvp_pct: number;
  data_status: DataStatus;
}

export interface TornadoItem {
  category: string;
  parameter: string;
  baseline: number;
  low_val: number;
  high_val: number;
  swing_delta: number;
  metric: string;
}

export interface ScenarioDefinition {
  scenario_id: string;
  name: string;
  description: string;
  temperature_delta_K: number;
  pressure_delta_bar: number;
  price_multiplier: number;
  model_id: string;
}
