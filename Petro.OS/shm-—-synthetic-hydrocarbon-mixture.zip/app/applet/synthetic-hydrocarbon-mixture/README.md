# SHM — Synthetic Hydrocarbon Mixture Platform

An R-Native Hydrocarbon Formulation, Thermodynamic Property Modelling, Constrained Optimisation & Economics Platform.

## System Architecture

```text
COMPONENT DATABASE (Pure species & Characterised petroleum fractions)
        ↓
STREAM AND FRACTION LIBRARY (Compositions, inventories, conditions)
        ↓
COMPOSITION ENGINE (Mole / Mass / Volume conversion, Mw calculation)
        ↓
THERMODYNAMIC MODEL REGISTRY (PR-1976, SRK-1972, Ideal Gas, Rackett)
        ↓
STATE AND PHASE CALCULATION (Rachford-Rice VLE Flash, Bubble / Dew Points)
        ↓
MIXTURE PROPERTY PREDICTION (Densities, TVP, Enthalpy, Heat Capacity, Viscosity)
        ↓
CONSTRAINT ENGINE (Hard & Soft specifications, penalties, tolerances)
        ↓
FORMULATION AND OPTIMISATION (Projected Gradient / Simplex Constrained Solver)
        ↓
ECONOMIC ANALYSIS (Material costs, Operating, Netback, Margin waterfall)
        ↓
UNCERTAINTY AND SENSITIVITY (Monte Carlo distributions, Tornado rankings)
        ↓
VALIDATION AND RECONCILIATION (ASTM Laboratory comparison, MAE, RMSE, R²)
        ↓
REPORTING & API (Quarto reproducible documents, Plumber OpenAPI REST API)
```

## Data Status Classification

Every calculation, dataset, and output explicitly records its provenance:
- `MEASURED`: Physical laboratory analytical determination.
- `SYNTHETIC`: Generated test dataset preserving physical relationships.
- `HISTORICAL`: Archived stream/batch records.
- `MODELLED`: Derived strictly from thermodynamic equations of state.
- `ESTIMATED`: Empirical correlation for undefined fractions (e.g. Lee-Kesler / Watson Kw).
- `IMPORTED`: Third-party external feed.
- `STALE`: Out-of-date inventory or calibration data.
- `UNAVAILABLE`: Missing required physical properties (never fabricated).

## R Package Structure

- `R/00_provenance_and_units.R`: SI units conversion and strict status tagging.
- `R/01_components.R`: 30+ pure components and pseudo-components library.
- `R/02_streams.R`: Characterized industrial feed and stream library.
- `R/03_composition_engine.R`: Mass, mole, and volume fraction reconciliations.
- `R/04_thermo_registry.R`: Versioned thermodynamic model metadata registry.
- `R/05_thermo_eos.R`: Peng-Robinson & SRK cubic equation of state solvers.
- `R/06_phase_equilibrium.R`: Rachford-Rice PT flash, bubble point, dew point.
- `R/07_density_volumetric.R`: Rackett saturated liquid density and EOS gas densities.
- `R/08_properties.R`: Enthalpy, heat capacities, dynamic viscosity, Antoine vapour pressures.
- `R/09_petroleum_fractions.R`: Riazi-Daubert, Lee-Kesler, and Watson K-factor pseudo-components.
- `R/10_constraints.R`: Property interval specification and penalty evaluator.
- `R/11_optimisation.R`: Constrained formulation optimization solver.
- `R/12_economics.R`: Processing, storage, logistics, unit costs, and margins.
- `R/13_inventory.R`: Stream tanks and component reservations.
- `R/14_uncertainty.R`: Monte Carlo simulation with empirical confidence intervals.
- `R/15_sensitivity.R`: Tornado chart parameter impact rankings.
- `R/16_lab_validation.R`: Laboratory reconciliation metrics (MAE, RMSE, R²).
- `R/18_synthetic_generator.R`: Coherent synthetic demonstration generator.
- `R/19_api_plumber.R`: OpenAPI v1 Plumber REST API service.
- `R/20_cli.R`: CLI parser for `shm`.
- `inst/shiny/app.R`: Interactive Shiny dashboard with bslib.
- `inst/reports/mixture_report.qmd`: Quarto document template.
- `tests/testthat/`: Comprehensive unit test suites.
