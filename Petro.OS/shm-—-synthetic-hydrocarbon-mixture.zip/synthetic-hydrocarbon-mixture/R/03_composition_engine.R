#' Composition Engine for Hydrocarbon Mixtures
#' @description
#' Handles conversions between mole, mass, and volume bases.
#' Calculates mixture molecular weight, normalises compositions, and reconciles balances.

#' Normalise Composition Vector
#' @param fractions Numeric vector of fractions.
#' @param tolerance Tolerance for normalisation check.
#' @return Normalised numeric vector summing to 1.
#' @export
shm_normalise_composition <- function(fractions, tolerance = 1e-6) {
  if (any(fractions < 0, na.rm = TRUE)) {
    stop("Composition fractions cannot be negative.")
  }
  s <- sum(fractions)
  if (s <= 0) {
    stop("Sum of composition fractions must be positive.")
  }
  if (abs(s - 1.0) > tolerance) {
    message(sprintf("Composition normalised from sum = %.6f to 1.0", s))
  }
  fractions / s
}

#' Convert Mole Fractions to Mass Fractions
#' @param mole_fractions Numeric vector of mole fractions x_i.
#' @param molecular_weights Numeric vector of component molecular weights M_i.
#' @return Numeric vector of mass fractions w_i.
#' @export
shm_mole_to_mass <- function(mole_fractions, molecular_weights) {
  x <- shm_normalise_composition(mole_fractions)
  m_contrib <- x * molecular_weights
  m_mix <- sum(m_contrib)
  if (m_mix <= 0) stop("Mixture molecular weight must be positive.")
  m_contrib / m_mix
}

#' Convert Mass Fractions to Mole Fractions
#' @param mass_fractions Numeric vector of mass fractions w_i.
#' @param molecular_weights Numeric vector of component molecular weights M_i.
#' @return Numeric vector of mole fractions x_i.
#' @export
shm_mass_to_mole <- function(mass_fractions, molecular_weights) {
  w <- shm_normalise_composition(mass_fractions)
  mol_contrib <- w / molecular_weights
  s <- sum(mol_contrib)
  if (s <= 0) stop("Sum of molar contributions must be positive.")
  mol_contrib / s
}

#' Convert Volume Fractions to Mole Fractions at Reference Conditions (15 C, 1 atm)
#' @param vol_fractions Numeric vector of volume fractions.
#' @param densities Numeric vector of liquid densities (kg/m3).
#' @param molecular_weights Numeric vector of molecular weights (g/mol).
#' @return Numeric vector of mole fractions.
#' @export
shm_volume_to_mole <- function(vol_fractions, densities, molecular_weights) {
  v <- shm_normalise_composition(vol_fractions)
  mass_contrib <- v * densities
  w <- mass_contrib / sum(mass_contrib)
  shm_mass_to_mole(w, molecular_weights)
}

#' Calculate Mixture Molecular Weight
#' @param mole_fractions Numeric vector of mole fractions x_i.
#' @param molecular_weights Numeric vector of molecular weights M_i.
#' @return Numeric mixture molecular weight M_mix in g/mol.
#' @export
shm_mixture_molecular_weight <- function(mole_fractions, molecular_weights) {
  x <- shm_normalise_composition(mole_fractions)
  sum(x * molecular_weights)
}

#' Create Hydrocarbon Mixture Object
#' @param name String name of the mixture.
#' @param component_ids Vector of component IDs.
#' @param fractions Vector of fractions.
#' @param basis 'mole', 'mass', or 'volume'.
#' @param temperature Temperature in Kelvin (default 298.15).
#' @param pressure Pressure in bar (default 1.01325).
#' @param total_quantity Total quantity (default 1000).
#' @param quantity_unit Unit of total quantity ('kg', 'kmol', 'm3').
#' @return A validated SHM mixture list.
#' @export
shm_create_mixture <- function(name = "Synthetic Test Mixture",
                               component_ids,
                               fractions,
                               basis = c("mole", "mass", "volume"),
                               temperature = 298.15,
                               pressure = 1.01325,
                               total_quantity = 1000,
                               quantity_unit = "kg") {
  basis <- match.arg(basis)
  lib <- shm_component_library()

  missing_ids <- setdiff(component_ids, lib$component_id)
  if (length(missing_ids) > 0) {
    stop(sprintf("Unknown components: %s", paste(missing_ids, collapse = ", ")))
  }

  match_rows <- match(component_ids, lib$component_id)
  comp_subset <- lib[match_rows, ]

  # Normalise input fractions
  norm_fracs <- shm_normalise_composition(fractions)

  # Compute all three fractional representations
  if (basis == "mole") {
    x_i <- norm_fracs
    w_i <- shm_mole_to_mass(x_i, comp_subset$molecular_weight)
    v_unnorm <- w_i / comp_subset$density_std
    v_i <- v_unnorm / sum(v_unnorm)
  } else if (basis == "mass") {
    w_i <- norm_fracs
    x_i <- shm_mass_to_mole(w_i, comp_subset$molecular_weight)
    v_unnorm <- w_i / comp_subset$density_std
    v_i <- v_unnorm / sum(v_unnorm)
  } else { # volume
    v_i <- norm_fracs
    x_i <- shm_volume_to_mole(v_i, comp_subset$density_std, comp_subset$molecular_weight)
    w_i <- shm_mole_to_mass(x_i, comp_subset$molecular_weight)
  }

  m_mix <- shm_mixture_molecular_weight(x_i, comp_subset$molecular_weight)

  # Material balance accounting
  if (quantity_unit == "kg") {
    mass_total_kg <- total_quantity
    moles_total_kmol <- mass_total_kg / m_mix
  } else if (quantity_unit == "kmol") {
    moles_total_kmol <- total_quantity
    mass_total_kg <- moles_total_kmol * m_mix
  } else { # m3
    avg_density <- sum(v_i * comp_subset$density_std)
    mass_total_kg <- total_quantity * avg_density
    moles_total_kmol <- mass_total_kg / m_mix
  }

  component_table <- data.frame(
    component_id = comp_subset$component_id,
    component_name = comp_subset$component_name,
    chemical_formula = comp_subset$chemical_formula,
    chemical_family = comp_subset$chemical_family,
    molecular_weight = comp_subset$molecular_weight,
    critical_temperature = comp_subset$critical_temperature,
    critical_pressure = comp_subset$critical_pressure,
    acentric_factor = comp_subset$acentric_factor,
    mole_fraction = x_i,
    mass_fraction = w_i,
    volume_fraction = v_i,
    mass_kg = w_i * mass_total_kg,
    moles_kmol = x_i * moles_total_kmol,
    cost_per_kg = comp_subset$cost_per_kg,
    data_status = comp_subset$data_status,
    stringsAsFactors = FALSE
  )

  list(
    mixture_id = paste0("MIX-", format(Sys.time(), "%Y%m%d%H%M%S")),
    mixture_name = name,
    creation_timestamp = Sys.time(),
    temperature_K = temperature,
    pressure_bar = pressure,
    basis_specified = basis,
    mixture_molecular_weight = m_mix,
    total_mass_kg = mass_total_kg,
    total_moles_kmol = moles_total_kmol,
    components = component_table,
    data_status = "MODELLED"
  )
}
