#' Phase Equilibrium and Rachford-Rice Flash Solver
#' @description
#' Implements rigorous VLE calculations: Rachford-Rice flash, bubble point, dew point,
#' and component material balance verification.

#' Wilson K-factor Initial Estimate
#' @param Tc Critical temperature (K)
#' @param Pc Critical pressure (bar)
#' @param omega Acentric factor
#' @param T Temperature (K)
#' @param P Pressure (bar)
#' @return Vector of initial K-factors
shm_wilson_k_factors <- function(Tc, Pc, omega, T, P) {
  (Pc / P) * exp(5.373 * (1 + omega) * (1 - Tc / T))
}

#' Solve Rachford-Rice Equation for Vapor Fraction Beta
#' @param z Vector of feed mole fractions
#' @param K Vector of equilibrium ratios K_i = y_i / x_i
#' @param tol Tolerance for convergence
#' @param max_iter Maximum Newton iterations
#' @return Estimated beta in [0, 1] or diagnostic indicator
shm_solve_rachford_rice <- function(z, K, tol = 1e-8, max_iter = 100) {
  # Check single phase boundaries
  # Bubble point check: if sum(z * K) <= 1, mixture is subcooled liquid (beta = 0)
  if (sum(z * K) <= 1.0) {
    return(list(beta = 0.0, phase = "Liquid", converged = TRUE, iterations = 0))
  }
  # Dew point check: if sum(z / K) <= 1, mixture is superheated vapor (beta = 1)
  if (sum(z / K) <= 1.0) {
    return(list(beta = 1.0, phase = "Vapour", converged = TRUE, iterations = 0))
  }

  # Bounds for beta
  beta_min <- max(0, max((K * z - 1) / (K - 1))[K > 1])
  beta_max <- min(1, min((1 - z) / (1 - K))[K < 1])
  beta <- (beta_min + beta_max) / 2

  for (iter in seq_len(max_iter)) {
    denom <- 1 + beta * (K - 1)
    f <- sum(z * (K - 1) / denom)
    f_prime <- -sum(z * (K - 1)^2 / denom^2)

    delta <- f / f_prime
    beta_new <- beta - delta

    # Damping / bracket constraint
    if (beta_new <= 0 || beta_new >= 1) {
      beta_new <- (beta + ifelse(delta > 0, 0, 1)) / 2
    }

    if (abs(f) < tol || abs(beta_new - beta) < tol) {
      return(list(beta = beta_new, phase = "Two-Phase", converged = TRUE, iterations = iter))
    }
    beta <- beta_new
  }

  list(beta = beta, phase = "Two-Phase", converged = FALSE, iterations = max_iter)
}

#' Two-Phase PT Flash Calculation
#' @param mixture SHM mixture object
#' @param T Temperature in K (optional, defaults to mixture T)
#' @param P Pressure in bar (optional, defaults to mixture P)
#' @param eos "PR" or "SRK"
#' @param max_iter Maximum successive substitution iterations
#' @param tol Tolerance for fugacity convergence
#' @return Detailed phase equilibrium result
#' @export
shm_rachford_rice_flash <- function(mixture, T = NULL, P = NULL, eos = "PR", max_iter = 50, tol = 1e-6) {
  if (is.null(T)) T <- mixture$temperature_K
  if (is.null(P)) P <- mixture$pressure_bar

  comps <- mixture$components
  z <- comps$mole_fraction
  Tc <- comps$critical_temperature
  Pc <- comps$critical_pressure
  omega <- comps$acentric_factor
  n <- length(z)

  # Initial K-factor estimate
  K <- shm_wilson_k_factors(Tc, Pc, omega, T, P)

  converged <- FALSE
  rr_res <- list(beta = 0.5, phase = "Two-Phase")

  for (ss_iter in seq_len(max_iter)) {
    rr_res <- shm_solve_rachford_rice(z, K)

    if (rr_res$phase == "Liquid") {
      beta <- 0.0
      x <- z
      y <- z * K / sum(z * K)
      converged <- TRUE
      break
    } else if (rr_res$phase == "Vapour") {
      beta <- 1.0
      y <- z
      x <- (z / K) / sum(z / K)
      converged <- TRUE
      break
    }

    beta <- rr_res$beta
    x <- z / (1 + beta * (K - 1))
    x <- x / sum(x)
    y <- K * x
    y <- y / sum(y)

    # Compute fugacity coefficients for both phases
    if (eos == "PR") {
      eos_l <- shm_eos_peng_robinson(x, Tc, Pc, omega, T, P)
      eos_v <- shm_eos_peng_robinson(y, Tc, Pc, omega, T, P)
    } else {
      eos_l <- shm_eos_srk(x, Tc, Pc, omega, T, P)
      eos_v <- shm_eos_srk(y, Tc, Pc, omega, T, P)
    }

    phi_l <- eos_l$phi_liq
    phi_v <- eos_v$phi_vap

    K_new <- phi_l / pmax(phi_v, 1e-10)

    # Convergence criterion: sum of squared relative log difference
    err <- sum((log(K_new) - log(K))^2)
    if (err < tol) {
      converged <- TRUE
      K <- K_new
      break
    }

    # Successive substitution update with mild damping
    K <- exp(0.7 * log(K_new) + 0.3 * log(K))
  }

  # Material balance verification
  beta_val <- rr_res$beta
  recon_z <- (1 - beta_val) * x + beta_val * y
  residual <- max(abs(z - recon_z))

  list(
    flash_type = "Isothermal-Isobaric (PT)",
    model = ifelse(eos == "PR", "Peng-Robinson (1976)", "Soave-Redlich-Kwong (1972)"),
    temperature_K = T,
    pressure_bar = P,
    vapour_fraction_beta = beta_val,
    liquid_fraction = 1 - beta_val,
    phase_state = rr_res$phase,
    converged = converged,
    iterations = ss_iter,
    K_factors = K,
    liquid_mole_fractions = x,
    vapour_mole_fractions = y,
    material_balance_residual = residual,
    balance_verified = residual < 1e-4,
    data_status = "MODELLED"
  )
}

#' Calculate Bubble Point (Pressure or Temperature)
#' @export
shm_bubble_point <- function(mixture, T = NULL, P = NULL) {
  if (is.null(T)) T <- mixture$temperature_K
  comps <- mixture$components
  Tc <- comps$critical_temperature
  Pc <- comps$critical_pressure
  omega <- comps$acentric_factor
  z <- comps$mole_fraction

  # Estimate bubble pressure at T using Raoult/Wilson: sum(z_i * P_sat_i)
  K_est <- shm_wilson_k_factors(Tc, Pc, omega, T, 1.0)
  P_bub_est <- sum(z * K_est * 1.0)

  list(
    type = "Bubble Point",
    temperature_K = T,
    bubble_pressure_bar = P_bub_est,
    is_saturated_liquid = TRUE,
    data_status = "MODELLED"
  )
}

#' Calculate Dew Point (Pressure or Temperature)
#' @export
shm_dew_point <- function(mixture, T = NULL, P = NULL) {
  if (is.null(T)) T <- mixture$temperature_K
  comps <- mixture$components
  Tc <- comps$critical_temperature
  Pc <- comps$critical_pressure
  omega <- comps$acentric_factor
  z <- comps$mole_fraction

  # Dew point pressure: 1 / sum(z_i / P_sat_i)
  K_est <- shm_wilson_k_factors(Tc, Pc, omega, T, 1.0)
  P_dew_est <- 1.0 / sum(z / (K_est * 1.0))

  list(
    type = "Dew Point",
    temperature_K = T,
    dew_pressure_bar = P_dew_est,
    is_saturated_vapour = TRUE,
    data_status = "MODELLED"
  )
}
