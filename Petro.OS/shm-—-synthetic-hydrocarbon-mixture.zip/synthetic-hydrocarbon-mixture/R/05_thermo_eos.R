#' Thermodynamic Equations of State (Peng-Robinson, SRK, Ideal Gas)
#' @description
#' Rigorous cubic EOS solvers for compressibility factors (Z) and fugacity coefficients (phi_i).
#' Universal gas constant R = 83.1446 bar*cm3 / (mol*K)

R_GAS <- 83.14462618 # bar * cm3 / (mol * K)

#' Solve Cubic Equation for Compressibility Factor Z
#' @param A Dimensionless EOS parameter A
#' @param B Dimensionless EOS parameter B
#' @param eos "PR" or "SRK"
#' @return A list containing all real roots, Z_vap (max root) and Z_liq (min positive root > B)
shm_solve_cubic_Z <- function(A, B, eos = "PR") {
  # Cubic equation: Z^3 + p2*Z^2 + p1*Z + p0 = 0
  if (eos == "PR") {
    p2 <- -(1 - B)
    p1 <- A - 3 * B^2 - 2 * B
    p0 <- -(A * B - B^2 - B^3)
  } else if (eos == "SRK") {
    p2 <- -1.0
    p1 <- A - B - B^2
    p0 <- -A * B
  } else {
    return(list(roots = 1.0, Z_vap = 1.0, Z_liq = 1.0))
  }

  # Depressed cubic substitution: Z = y - p2/3
  a1 <- p2
  a2 <- p1
  a3 <- p0

  Q <- (3 * a2 - a1^2) / 9
  R <- (9 * a1 * a2 - 27 * a3 - 2 * a1^3) / 54
  D <- Q^3 + R^2 # Discriminant

  roots <- numeric(0)
  if (D >= 0) {
    # 1 real root
    S <- sign(R + sqrt(D)) * (abs(R + sqrt(D)))^(1/3)
    T <- sign(R - sqrt(D)) * (abs(R - sqrt(D)))^(1/3)
    roots <- c(S + T - a1 / 3)
  } else {
    # 3 real roots
    theta <- acos(R / sqrt(-Q^3))
    r1 <- 2 * sqrt(-Q) * cos(theta / 3) - a1 / 3
    r2 <- 2 * sqrt(-Q) * cos((theta + 2 * pi) / 3) - a1 / 3
    r3 <- 2 * sqrt(-Q) * cos((theta + 4 * pi) / 3) - a1 / 3
    roots <- sort(c(r1, r2, r3))
  }

  valid_roots <- roots[roots > B]
  if (length(valid_roots) == 0) {
    valid_roots <- roots[roots > 0]
    if (length(valid_roots) == 0) valid_roots <- c(1.0)
  }

  z_vap <- max(valid_roots)
  z_liq <- min(valid_roots)

  list(
    all_roots = roots,
    valid_roots = valid_roots,
    Z_vap = z_vap,
    Z_liq = z_liq
  )
}

#' Peng-Robinson Equation of State Properties
#' @param mole_fractions Vector of mole fractions
#' @param Tc Vector of critical temperatures in K
#' @param Pc Vector of critical pressures in bar
#' @param omega Vector of acentric factors
#' @param T Temperature in K
#' @param P Pressure in bar
#' @param kij Binary interaction parameter matrix (default zeros)
#' @return List of EOS results including Z_vap, Z_liq, fugacity coefficients
#' @export
shm_eos_peng_robinson <- function(mole_fractions, Tc, Pc, omega, T, P, kij = NULL) {
  n <- length(mole_fractions)
  x <- mole_fractions / sum(mole_fractions)
  if (is.null(kij)) kij <- matrix(0, nrow = n, ncol = n)

  Tr <- T / Tc
  # PR 1976 kappa
  kappa <- 0.37464 + 1.54226 * omega - 0.26992 * omega^2
  alpha <- (1 + kappa * (1 - sqrt(Tr)))^2

  ai <- 0.45724 * (R_GAS^2 * Tc^2 / Pc) * alpha
  bi <- 0.07780 * (R_GAS * Tc / Pc)

  # Quadratic mixing rules
  aij <- matrix(0, nrow = n, ncol = n)
  for (i in seq_len(n)) {
    for (j in seq_len(n)) {
      aij[i, j] <- sqrt(ai[i] * ai[j]) * (1 - kij[i, j])
    }
  }

  a_mix <- sum(outer(x, x, "*") * aij)
  b_mix <- sum(x * bi)

  A <- a_mix * P / (R_GAS * T)^2
  B <- b_mix * P / (R_GAS * T)

  cubic_res <- shm_solve_cubic_Z(A, B, eos = "PR")
  Zv <- cubic_res$Z_vap
  Zl <- cubic_res$Z_liq

  # Fugacity coefficients for vapor and liquid
  calc_ln_phi <- function(Z) {
    if (Z <= B) return(rep(0, n))
    term1 <- (bi / b_mix) * (Z - 1)
    term2 <- -log(Z - B)
    sum_x_aij <- as.vector(aij %*% x)
    term3 <- -(A / (2 * sqrt(2) * B)) * (2 * sum_x_aij / a_mix - bi / b_mix) *
      log((Z + (1 + sqrt(2)) * B) / (Z + (1 - sqrt(2)) * B))
    exp(term1 + term2 + term3)
  }

  phi_vap <- calc_ln_phi(Zv)
  phi_liq <- calc_ln_phi(Zl)

  list(
    model = "Peng-Robinson (1976)",
    A = A,
    B = B,
    a_mix = a_mix,
    b_mix = b_mix,
    Z_vap = Zv,
    Z_liq = Zl,
    phi_vap = phi_vap,
    phi_liq = phi_liq,
    is_two_phase_possible = length(cubic_res$valid_roots) > 1
  )
}

#' Soave-Redlich-Kwong Equation of State
#' @export
shm_eos_srk <- function(mole_fractions, Tc, Pc, omega, T, P, kij = NULL) {
  n <- length(mole_fractions)
  x <- mole_fractions / sum(mole_fractions)
  if (is.null(kij)) kij <- matrix(0, nrow = n, ncol = n)

  Tr <- T / Tc
  # SRK 1972 alpha
  m <- 0.480 + 1.574 * omega - 0.176 * omega^2
  alpha <- (1 + m * (1 - sqrt(Tr)))^2

  ai <- 0.42748 * (R_GAS^2 * Tc^2 / Pc) * alpha
  bi <- 0.08664 * (R_GAS * Tc / Pc)

  aij <- matrix(0, nrow = n, ncol = n)
  for (i in seq_len(n)) {
    for (j in seq_len(n)) {
      aij[i, j] <- sqrt(ai[i] * ai[j]) * (1 - kij[i, j])
    }
  }

  a_mix <- sum(outer(x, x, "*") * aij)
  b_mix <- sum(x * bi)

  A <- a_mix * P / (R_GAS * T)^2
  B <- b_mix * P / (R_GAS * T)

  cubic_res <- shm_solve_cubic_Z(A, B, eos = "SRK")
  Zv <- cubic_res$Z_vap
  Zl <- cubic_res$Z_liq

  calc_ln_phi_srk <- function(Z) {
    if (Z <= B) return(rep(0, n))
    term1 <- (bi / b_mix) * (Z - 1)
    term2 <- -log(Z - B)
    sum_x_aij <- as.vector(aij %*% x)
    term3 <- -(A / B) * (2 * sum_x_aij / a_mix - bi / b_mix) * log(1 + B / Z)
    exp(term1 + term2 + term3)
  }

  list(
    model = "Soave-Redlich-Kwong (1972)",
    A = A,
    B = B,
    Z_vap = Zv,
    Z_liq = Zl,
    phi_vap = calc_ln_phi_srk(Zv),
    phi_liq = calc_ln_phi_srk(Zl),
    is_two_phase_possible = length(cubic_res$valid_roots) > 1
  )
}

#' Ideal Gas Equation of State Reference
#' @export
shm_eos_ideal <- function(mole_fractions) {
  n <- length(mole_fractions)
  list(
    model = "Ideal Gas Reference",
    Z_vap = 1.0,
    Z_liq = 1.0,
    phi_vap = rep(1.0, n),
    phi_liq = rep(1.0, n),
    is_two_phase_possible = FALSE
  )
}
