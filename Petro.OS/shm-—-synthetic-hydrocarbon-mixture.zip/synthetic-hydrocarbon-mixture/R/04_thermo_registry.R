#' Thermodynamic Model Registry
#' @description
#' Provides a versioned catalog of supported thermodynamic and property models.

#' List Registered Thermodynamic Models
#' @return A data.frame of models with equations, validity domains, and approval status.
#' @export
shm_model_registry <- function() {
  data.frame(
    model_id = c("PR-1976", "SRK-1972", "IDEAL-GAS", "RACKETT-RIAZI", "API-TDB"),
    model_name = c(
      "Peng-Robinson Equation of State (1976)",
      "Soave-Redlich-Kwong Equation of State (1972)",
      "Ideal Gas Law Reference Model",
      "Rackett & Riazi Modified Liquid Density",
      "API Technical Data Book Heavy Hydrocarbon Correlations"
    ),
    version = c("2.1.0", "1.4.2", "1.0.0", "3.0.1", "4.2.0"),
    model_type = c("Cubic EOS", "Cubic EOS", "Ideal Reference", "Empirical Liquid Density", "Petroleum Correlations"),
    primary_phases = c("Vapour, Liquid, Multiphase", "Vapour, Liquid, Multiphase", "Low-pressure Vapour", "Compressed & Saturated Liquid", "Heavy Liquid & Gas"),
    validity_temperature_K = c("120 - 750", "120 - 700", "200 - 1500", "150 - 650", "250 - 800"),
    validity_pressure_bar = c("0.01 - 300", "0.01 - 250", "0.001 - 3", "0.1 - 200", "0.1 - 150"),
    approval_status = c("APPROVED", "APPROVED", "APPROVED_BENCHMARK", "APPROVED", "APPROVED_PSEUDO"),
    data_status = c("MODELLED", "MODELLED", "MODELLED", "MODELLED", "ESTIMATED"),
    stringsAsFactors = FALSE
  )
}
