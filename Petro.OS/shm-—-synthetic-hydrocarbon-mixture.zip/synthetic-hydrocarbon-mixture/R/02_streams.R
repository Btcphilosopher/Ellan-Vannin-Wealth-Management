#' Stream and Fraction Library
#' @description
#' Models hydrocarbon source streams with composition, inventory, temperature,
#' pressure, quality and cost records.

#' Build Default Stream Library
#' @return A list of streams with their compositional breakdowns and physical inventory.
#' @export
shm_stream_library <- function() {
  list(
    list(
      stream_id = "STR-01",
      stream_name = "Associated Gas Feed",
      source = "Separator Overhead - Field Unit A",
      temperature = 313.15, # 40 C
      pressure = 25.0, # bar
      available_quantity_kg = 85000,
      reserved_quantity_kg = 12000,
      cost_per_kg = 0.48,
      quality_status = "CERTIFIED",
      data_status = "MEASURED",
      composition_basis = "mole",
      composition = data.frame(
        component_id = c("C1", "C2", "C3", "iC4", "nC4"),
        fraction = c(0.720, 0.145, 0.085, 0.022, 0.028),
        stringsAsFactors = FALSE
      )
    ),
    list(
      stream_id = "STR-02",
      stream_name = "Stabilised Hydrocarbon Condensate",
      source = "Condensate Stabilization Column Bottoms",
      temperature = 303.15, # 30 C
      pressure = 2.5, # bar
      available_quantity_kg = 120000,
      reserved_quantity_kg = 25000,
      cost_per_kg = 0.76,
      quality_status = "CERTIFIED",
      data_status = "MEASURED",
      composition_basis = "mass",
      composition = data.frame(
        component_id = c("iC5", "nC5", "nC6", "COND_CUT", "BENZ", "TOL"),
        fraction = c(0.18, 0.22, 0.28, 0.20, 0.05, 0.07),
        stringsAsFactors = FALSE
      )
    ),
    list(
      stream_id = "STR-03",
      stream_name = "Hydrotreated Light Naphtha Stream",
      source = "Naphtha Splitter Overhead",
      temperature = 298.15, # 25 C
      pressure = 1.01325, # 1 atm
      available_quantity_kg = 95000,
      reserved_quantity_kg = 15000,
      cost_per_kg = 0.82,
      quality_status = "CERTIFIED",
      data_status = "MEASURED",
      composition_basis = "mass",
      composition = data.frame(
        component_id = c("iC5", "nC5", "nC6", "2MP", "CP", "CH", "BENZ"),
        fraction = c(0.12, 0.14, 0.26, 0.22, 0.08, 0.15, 0.03),
        stringsAsFactors = FALSE
      )
    ),
    list(
      stream_id = "STR-04",
      stream_name = "Aromatic Extraction Raffinate",
      source = "Extraction Plant 2",
      temperature = 310.15, # 37 C
      pressure = 3.0,
      available_quantity_kg = 60000,
      reserved_quantity_kg = 5000,
      cost_per_kg = 0.89,
      quality_status = "ANALYZED",
      data_status = "MEASURED",
      composition_basis = "mass",
      composition = data.frame(
        component_id = c("nC6", "2MP", "nC7", "CH", "MCH"),
        fraction = c(0.25, 0.30, 0.22, 0.13, 0.10),
        stringsAsFactors = FALSE
      )
    ),
    list(
      stream_id = "STR-05",
      stream_name = "Synthetic Gas-to-Liquids Paraffinic Fraction",
      source = "Fischer-Tropsch Synthesis Train 1",
      temperature = 320.15,
      pressure = 1.5,
      available_quantity_kg = 45000,
      reserved_quantity_kg = 0,
      cost_per_kg = 1.15,
      quality_status = "HIGH_PURITY",
      data_status = "SYNTHETIC",
      composition_basis = "mass",
      composition = data.frame(
        component_id = c("nC7", "nC8", "nC9", "nC10", "HEAVY_NAPH"),
        fraction = c(0.15, 0.35, 0.25, 0.15, 0.10),
        stringsAsFactors = FALSE
      )
    )
  )
}
