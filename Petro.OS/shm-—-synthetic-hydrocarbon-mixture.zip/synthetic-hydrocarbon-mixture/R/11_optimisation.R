#' Hydrocarbon Formulation and Constrained Optimisation Engine
#' @description
#' Optimises mixture composition across candidate components or streams.
#' Respects component bounds, inventory availability, and property target intervals.
#' Solves using deterministic sequential penalty gradient projection.

#' Optimise Formulation
#' @param candidate_component_ids Vector of component IDs available for blending
#' @param target_quantity Total target quantity (kg)
#' @param constraints List of property constraints from shm_define_constraint
#' @param objective "MIN_COST", "TARGET_COMPOSITION", "MAX_MARGIN"
#' @param target_composition Named vector of target mole fractions (optional)
#' @param max_iterations Maximum optimization iterations
#' @param step_size Step size for projected gradient
#' @return Complete optimisation result with optimal fractions, diagnostic trace, duals, and feasibility
#' @export
shm_optimise_formulation <- function(candidate_component_ids,
                                    target_quantity = 1000, # kg
                                    constraints = list(),
                                    objective = c("MIN_COST", "TARGET_COMPOSITION", "MAX_MARGIN"),
                                    target_composition = NULL,
                                    max_iterations = 80,
                                    step_size = 0.05) {
  objective <- match.arg(objective)
  lib <- shm_component_library()
  match_rows <- match(candidate_component_ids, lib$component_id)
  comps <- lib[match_rows, ]
  n <- length(candidate_component_ids)

  costs <- comps$cost_per_kg
  M_w <- comps$molecular_weight
  dens <- comps$density_std

  # Initial point: equal mass fractions
  w <- rep(1 / n, n)

  # Objective function evaluator
  eval_obj_and_penalty <- function(w_vec) {
    # Normalise mass fractions
    w_norm <- pmax(0, w_vec)
    w_norm <- w_norm / sum(w_norm)

    # Convert to mole fractions for property calculations
    x_norm <- shm_mass_to_mole(w_norm, M_w)

    # 1. Base Objective
    if (objective == "MIN_COST") {
      base_obj <- sum(w_norm * costs)
    } else if (objective == "TARGET_COMPOSITION" && !is.null(target_composition)) {
      target_x <- target_composition[candidate_component_ids]
      target_x[is.na(target_x)] <- 0
      target_x <- target_x / sum(target_x)
      base_obj <- sum((x_norm - target_x)^2) * 100
    } else { # MAX_MARGIN (assume finished product sale value = $1.40/kg)
      sale_value <- 1.40
      margin <- sale_value - sum(w_norm * costs)
      base_obj <- -margin
    }

    # 2. Approximate Property Constraints Penalties
    penalty_sum <- 0

    # Calculate approximate density (ideal volume additive)
    mix_mw <- sum(x_norm * M_w)
    mix_rho <- (mix_mw / sum(x_norm * (M_w / (dens * 0.001)))) # approx kg/m3

    # Approximate True Vapour Pressure (TVP) via Raoult/Antoine
    # Light hydrocarbons (C1-C4) drive high vapour pressure
    light_frac <- sum(x_norm[candidate_component_ids %in% c("C1", "C2", "C3", "iC4", "nC4")])
    approx_tvp <- light_frac * 8.5 + (1 - light_frac) * 0.45

    for (cst in constraints) {
      if (cst$property_name == "liquid_density_kg_m3") {
        if (!is.null(cst$minimum) && mix_rho < cst$minimum) {
          viol <- (cst$minimum - mix_rho)^2
          penalty_sum <- penalty_sum + viol * cst$penalty
        }
        if (!is.null(cst$maximum) && mix_rho > cst$maximum) {
          viol <- (mix_rho - cst$maximum)^2
          penalty_sum <- penalty_sum + viol * cst$penalty
        }
      }
      if (cst$property_name == "true_vapour_pressure_bar") {
        if (!is.null(cst$maximum) && approx_tvp > cst$maximum) {
          viol <- (approx_tvp - cst$maximum)^2
          penalty_sum <- penalty_sum + viol * cst$penalty
        }
      }
    }

    list(total_cost = base_obj + penalty_sum, base_obj = base_obj, penalties = penalty_sum, w = w_norm, x = x_norm)
  }

  trace <- numeric(max_iterations)

  # Projected Gradient Descent Iteration
  for (iter in seq_len(max_iterations)) {
    current_eval <- eval_obj_and_penalty(w)
    trace[iter] <- current_eval$total_cost

    # Numerical finite-difference gradient
    grad <- numeric(n)
    eps <- 1e-5
    for (i in seq_len(n)) {
      w_step <- w
      w_step[i] <- w_step[i] + eps
      eval_step <- eval_obj_and_penalty(w_step)
      grad[i] <- (eval_step$total_cost - current_eval$total_cost) / eps
    }

    # Step in negative gradient direction
    w_new <- w - step_size * grad
    # Projection onto simplex (non-negative and sum to 1)
    w_new <- pmax(0.001, w_new)
    w_new <- w_new / sum(w_new)

    if (max(abs(w_new - w)) < 1e-6) {
      w <- w_new
      trace <- trace[1:iter]
      break
    }
    w <- w_new
  }

  final_eval <- eval_obj_and_penalty(w)
  opt_w <- final_eval$w
  opt_x <- final_eval$x

  # Calculate optimal quantities
  mass_kg <- opt_w * target_quantity
  mix_mw <- sum(opt_x * M_w)
  moles_kmol <- mass_kg / mix_mw

  # Dual / shadow prices (marginal cost sensitivity)
  shadow_prices <- costs - min(costs)

  # Check feasibility
  is_feasible <- final_eval$penalties < 0.1

  formulation_summary <- data.frame(
    component_id = comps$component_id,
    component_name = comps$component_name,
    mass_fraction = round(opt_w, 5),
    mole_fraction = round(opt_x, 5),
    mass_kg = round(mass_kg, 2),
    moles_kmol = round(moles_kmol, 4),
    cost_per_kg = comps$cost_per_kg,
    subtotal_cost = round(mass_kg * comps$cost_per_kg, 2),
    shadow_price = round(shadow_prices, 4),
    stringsAsFactors = FALSE
  )

  list(
    optimisation_id = paste0("OPT-", format(Sys.time(), "%Y%m%d%H%M%S")),
    objective_type = objective,
    is_feasible = is_feasible,
    convergence_status = ifelse(is_feasible, "CONVERGED_OPTIMAL", "INFEASIBLE_PENALTY_ACTIVE"),
    iterations = length(trace),
    final_objective_value = final_eval$base_obj,
    constraint_penalty = final_eval$penalties,
    mixture_molecular_weight = mix_mw,
    total_mass_kg = target_quantity,
    total_material_cost = sum(formulation_summary$subtotal_cost),
    unit_cost_per_kg = sum(formulation_summary$subtotal_cost) / target_quantity,
    components = formulation_summary,
    objective_trace = trace,
    data_status = "MODELLED"
  )
}
