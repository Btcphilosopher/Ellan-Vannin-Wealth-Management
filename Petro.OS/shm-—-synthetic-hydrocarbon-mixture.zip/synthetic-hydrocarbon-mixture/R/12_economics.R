#' Economics and Margin Evaluation Engine
#' @description
#' Evaluates total material cost, processing/blending cost, storage, transport,
#' unit mass/volume/mole costs, commercial revenue, contribution margin, and netback.

#' Perform Economic Analysis on a Formulation or Mixture
#' @param mixture SHM mixture object or optimisation result
#' @param processing_cost_per_kg Blending and utility processing cost ($/kg)
#' @param storage_cost_per_m3 Storage and holding cost ($/m3)
#' @param transport_cost_per_kg Logistics cost ($/kg)
#' @param product_sale_price_per_kg Commercial finished value ($/kg)
#' @param currency Currency code (default 'USD')
#' @return Detailed economic statement
#' @export
shm_economic_analysis <- function(mixture,
                                  processing_cost_per_kg = 0.045,
                                  storage_cost_per_m3 = 1.20,
                                  transport_cost_per_kg = 0.025,
                                  product_sale_price_per_kg = 1.25,
                                  currency = "USD") {
  comps <- mixture$components
  total_mass_kg <- mixture$total_mass_kg

  # Material cost breakdown
  if ("mass_kg" %in% names(comps)) {
    material_subtotals <- comps$mass_kg * comps$cost_per_kg
  } else {
    material_subtotals <- (comps$mass_fraction * total_mass_kg) * comps$cost_per_kg
  }

  total_material_cost <- sum(material_subtotals)
  avg_material_cost_per_kg <- total_material_cost / total_mass_kg

  # Associated operating and logistics costs
  total_processing_cost <- processing_cost_per_kg * total_mass_kg
  total_transport_cost <- transport_cost_per_kg * total_mass_kg

  # Approximate volume in m3 (density ~ 700 kg/m3)
  est_volume_m3 <- total_mass_kg / 700
  total_storage_cost <- storage_cost_per_m3 * est_volume_m3

  total_operating_cost <- total_processing_cost + total_transport_cost + total_storage_cost
  total_production_cost <- total_material_cost + total_operating_cost

  # Revenue & Margin
  total_gross_revenue <- product_sale_price_per_kg * total_mass_kg
  contribution_margin <- total_gross_revenue - total_production_cost
  margin_percentage <- (contribution_margin / total_gross_revenue) * 100

  # Unit costs
  m_mix <- mixture$mixture_molecular_weight
  total_moles_kmol <- total_mass_kg / m_mix

  list(
    currency = currency,
    total_mass_kg = total_mass_kg,
    total_moles_kmol = total_moles_kmol,
    estimated_volume_m3 = est_volume_m3,
    total_material_cost = round(total_material_cost, 2),
    material_cost_per_kg = round(avg_material_cost_per_kg, 4),
    material_cost_per_m3 = round(total_material_cost / est_volume_m3, 2),
    material_cost_per_kmol = round(total_material_cost / total_moles_kmol, 2),
    processing_cost = round(total_processing_cost, 2),
    transport_cost = round(total_transport_cost, 2),
    storage_cost = round(total_storage_cost, 2),
    total_production_cost = round(total_production_cost, 2),
    production_cost_per_kg = round(total_production_cost / total_mass_kg, 4),
    product_sale_price_per_kg = product_sale_price_per_kg,
    gross_revenue = round(total_gross_revenue, 2),
    contribution_margin = round(contribution_margin, 2),
    margin_percentage = round(margin_percentage, 2),
    data_status = "ESTIMATED"
  )
}
