#' Density and Volumetric Properties Engine
#' @description
#' Calculates liquid density via Rackett equation, real-gas density via EOS,
#' specific gravity, compressibility factor, and volumetric expansion.

#' Modified Rackett Liquid Molar Volume for Hydrocarbons
#' @param Tc Critical temperature (K)
#' @param Pc Critical pressure (bar)
#' @param Z_ra Rackett parameter (approx 0.29056 - 0.08775 * omega)
#' @param T Temperature (K)
#' @return Saturated liquid molar volume in cm3/mol
shm_rackett_volume_pure <- function(Tc, Pc, Z_ra, T) {
  Tr <- pmin(0.999, T / Tc)
  R <- 83.144626 # bar * cm3 / (mol * K)
  (R * Tc / Pc) * (Z_ra^(1 + (1 - Tr)^(2/7)))
}

#' Calculate Liquid and Vapour Densities of Mixture
#' @param mixture SHM mixture object
#' @param T Temperature (K)
#' @param P Pressure (bar)
#' @param eos "PR" or "SRK"
#' @return Detailed volumetric properties list
#' @export
shm_density_rackett <- function(mixture, T = NULL, P = NULL, eos = "PR") {
  if (is.null(T)) T <- mixture$temperature_K
  if (is.null(P)) P <- mixture$pressure_bar

  comps <- mixture$components
  x <- comps$mole_fraction
  w <- comps$mass_fraction
  M <- comps$molecular_weight
  Tc <- comps$critical_temperature
  Pc <- comps$critical_pressure
  omega <- comps$acentric_factor
  m_mix <- mixture$mixture_molecular_weight

  # Rackett parameter Z_ra estimation
  Z_ra <- 0.29056 - 0.08775 * omega
  V_sat_pure <- mapply(shm_rackett_volume_pure, Tc, Pc, Z_ra, MoreArgs = list(T = T))

  # Liquid mixture molar volume (cm3/mol)
  # Mixing rule: V_mix = sum(x_i * V_sat_i)
  V_liq_mix <- sum(x * V_sat_pure) # cm3 / mol
  # Mass density: (g/mol) / (cm3/mol) = g/cm3 -> * 1000 = kg/m3
  rho_liq_kg_m3 <- (m_mix / V_liq_mix) * 1000

  # Gas density via EOS Z-factor
  if (eos == "PR") {
    eos_res <- shm_eos_peng_robinson(x, Tc, Pc, omega, T, P)
  } else {
    eos_res <- shm_eos_srk(x, Tc, Pc, omega, T, P)
  }

  R_SI <- 8.314462 # J / (mol * K)
  P_Pa <- P * 1e5
  # Ideal gas density: P * M / (R * T) where M is kg/mol
  rho_gas_ideal <- (P_Pa * (m_mix / 1000)) / (R_SI * T)
  rho_gas_real <- rho_gas_ideal / eos_res$Z_vap

  # Specific gravity at 15.56 C (approx relative to water 999.0 kg/m3)
  sg_liquid <- rho_liq_kg_m3 / 999.01

  list(
    temperature_K = T,
    pressure_bar = P,
    liquid_density_kg_m3 = rho_liq_kg_m3,
    vapour_density_kg_m3 = rho_gas_real,
    ideal_gas_density_kg_m3 = rho_gas_ideal,
    liquid_molar_volume_cm3_mol = V_liq_mix,
    compressibility_factor_Z = eos_res$Z_vap,
    liquid_compressibility_factor_Z = eos_res$Z_liq,
    specific_gravity_60F = sg_liquid,
    density_model = "Modified Rackett + Cubic EOS",
    is_additive_volume_approximation = FALSE,
    data_status = "MODELLED"
  )
}
