#' Uncertainty and Monte Carlo Robustness Engine
#' @description
#' Evaluates the impact of compositional measurement error, temperature/pressure
#' fluctuations, and model prediction errors on output properties and constraint compliance.

#' Run Monte Carlo Uncertainty Simulation
#' @param mixture SHM mixture object
#' @param n_samples Number of Monte Carlo draws (default 500)
#' @param composition_rel_sd Relative standard deviation on component fractions (e.g., 0.05 for 5%)
#' @param temperature_sd_K Standard deviation of temperature fluctuations (e.g., 1.5 K)
#' @param pressure_rel_sd Relative standard deviation of pressure (e.g., 0.02 for 2%)
#' @param seed Deterministic random seed
#' @return Summary statistics, percentiles (P05, P50, P95), and compliance probabilities
#' @export
shm_monte_carlo_uncertainty <- function(mixture,
                                       n_samples = 500,
                                       composition_rel_sd = 0.04,
                                       temperature_sd_K = 1.5,
                                       pressure_rel_sd = 0.02,
                                       seed = 42) {
  set.seed(seed)
  comps <- mixture$components
  n_comps <- nrow(comps)
  base_x <- comps$mole_fraction
  base_T <- mixture$temperature_K
  base_P <- mixture$pressure_bar

  densities <- numeric(n_samples)
  tvps <- numeric(n_samples)
  mw_samples <- numeric(n_samples)
  cost_samples <- numeric(n_samples)

  M_w <- comps$molecular_weight
  costs <- comps$cost_per_kg

  for (i in seq_len(n_samples)) {
    # Gaussian noise on composition with Dirichlet-style re-normalisation
    noisy_x <- pmax(1e-5, base_x * (1 + rnorm(n_comps, mean = 0, sd = composition_rel_sd)))
    x_i <- noisy_x / sum(noisy_x)

    # Temperature and pressure fluctuations
    T_i <- max(150, base_T + rnorm(1, mean = 0, sd = temperature_sd_K))
    P_i <- max(0.1, base_P * (1 + rnorm(1, mean = 0, sd = pressure_rel_sd)))

    # Properties
    mw_i <- sum(x_i * M_w)
    mw_samples[i] <- mw_i

    # Mass fractions
    w_i <- (x_i * M_w) / mw_i
    cost_samples[i] <- sum(w_i * costs)

    # Approximate density
    vol_mix <- sum(x_i * (M_w / comps$density_std))
    densities[i] <- (mw_i / vol_mix) * 1000

    # True vapour pressure approx with noise
    light_f <- sum(x_i[comps$component_id %in% c("C1", "C2", "C3", "iC4", "nC4")])
    tvps[i] <- max(0.01, (light_f * 8.5 + (1 - light_f) * 0.45) * (T_i / base_T)^2)
  }

  calc_stats <- function(vals) {
    list(
      mean = mean(vals),
      sd = sd(vals),
      p05 = quantile(vals, 0.05),
      p50 = median(vals),
      p95 = quantile(vals, 0.95),
      min = min(vals),
      max = max(vals)
    )
  }

  list(
    simulation_id = paste0("MC-", format(Sys.time(), "%Y%m%d%H%M%S")),
    n_samples = n_samples,
    seed = seed,
    density_kg_m3 = calc_stats(densities),
    true_vapour_pressure_bar = calc_stats(tvps),
    molecular_weight_g_mol = calc_stats(mw_samples),
    unit_cost_per_kg = calc_stats(cost_samples),
    compliance_probability_density_within_5pct = mean(abs(densities - mean(densities)) / mean(densities) < 0.05),
    compliance_probability_tvp_below_1_bar = mean(tvps < 1.0),
    data_status = "MODELLED"
  )
}
