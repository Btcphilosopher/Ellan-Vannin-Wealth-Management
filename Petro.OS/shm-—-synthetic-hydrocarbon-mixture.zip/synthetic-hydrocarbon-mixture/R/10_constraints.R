#' Target-Property Constraint Engine
#' @description
#' Defines arbitrary user property specifications, tolerance limits,
#' and checks compliance of formulations against target intervals.

#' Define a Property Constraint
#' @param property_name Name of the property (e.g., 'liquid_density_kg_m3', 'true_vapour_pressure_bar')
#' @param minimum Lower bound (or NULL)
#' @param maximum Upper bound (or NULL)
#' @param target Target point value (or NULL)
#' @param tolerance Allowed tolerance around target
#' @param is_hard Logical, TRUE if hard constraint
#' @param penalty Penalty weight for soft violations
#' @param units Unit string
#' @return A constraint specification list
#' @export
shm_define_constraint <- function(property_name,
                                  minimum = NULL,
                                  maximum = NULL,
                                  target = NULL,
                                  tolerance = 0.01,
                                  is_hard = TRUE,
                                  penalty = 1000,
                                  units = "") {
  list(
    constraint_id = paste0("CST-", toupper(property_name)),
    property_name = property_name,
    minimum = minimum,
    maximum = maximum,
    target = target,
    tolerance = tolerance,
    is_hard = is_hard,
    penalty = penalty,
    units = units
  )
}

#' Evaluate Constraints Against Calculated Mixture Properties
#' @param properties Calculated property list from shm_predict_properties
#' @param constraints List of constraints defined by shm_define_constraint
#' @return Data frame of compliance status, residuals, and penalties
#' @export
shm_evaluate_constraints <- function(properties, constraints) {
  results <- list()

  for (cst in constraints) {
    prop_val <- properties[[cst$property_name]]

    if (is.null(prop_val)) {
      status <- "UNAVAILABLE"
      viol <- 0
    } else {
      viol_low <- if (!is.null(cst$minimum)) max(0, cst$minimum - prop_val) else 0
      viol_high <- if (!is.null(cst$maximum)) max(0, prop_val - cst$maximum) else 0
      viol_target <- if (!is.null(cst$target)) max(0, abs(prop_val - cst$target) - cst$tolerance) else 0

      viol <- max(viol_low, viol_high, viol_target)
      status <- if (viol <= 1e-6) "SATISFIED" else if (cst$is_hard) "VIOLATED_HARD" else "VIOLATED_SOFT"
    }

    results[[length(results) + 1]] <- data.frame(
      constraint_id = cst$constraint_id,
      property = cst$property_name,
      current_value = ifelse(is.null(prop_val), NA, prop_val),
      minimum = ifelse(is.null(cst$minimum), NA, cst$minimum),
      maximum = ifelse(is.null(cst$maximum), NA, cst$maximum),
      target = ifelse(is.null(cst$target), NA, cst$target),
      violation = viol,
      status = status,
      penalty_cost = viol * cst$penalty,
      units = cst$units,
      stringsAsFactors = FALSE
    )
  }

  do.call(rbind, results)
}
