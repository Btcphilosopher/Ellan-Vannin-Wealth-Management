#' Petroleum Fractions and Pseudo-Component Characterisation
#' @description
#' Provides correlation models (Riazi-Daubert, Lee-Kesler, Watson K) for
#' characterizing boiling cuts and petroleum fractions that cannot be represented
#' as pure chemical species.

#' Characterise a Petroleum Cut
#' @param fraction_id Identifier for the fraction
#' @param fraction_name Name of the cut
#' @param mean_boiling_point_K Mean average boiling point (K)
#' @param specific_gravity Specific gravity (60/60 F)
#' @return Complete pseudo-component record with estimated critical properties
#' @export
shm_characterise_petroleum_fraction <- function(fraction_id = "PSEUDO_CUT",
                                               fraction_name = "Characterized Naphtha Fraction",
                                               mean_boiling_point_K = 410.0,
                                               specific_gravity = 0.745) {
  Tb <- mean_boiling_point_K
  SG <- specific_gravity

  if (Tb < 280 || Tb > 900) {
    warning("Mean boiling point is outside recommended correlation range (280 - 900 K).")
  }
  if (SG < 0.60 || SG > 1.15) {
    warning("Specific gravity is outside typical hydrocarbon range (0.60 - 1.15).")
  }

  # 1. Watson Characterisation Factor Kw
  # Kw = (Tb_Rankine)^(1/3) / SG where Tb_Rankine = Tb_Kelvin * 1.8
  Tb_R <- Tb * 1.8
  Kw <- (Tb_R^(1/3)) / SG

  # 2. Riazi-Daubert Correlation for Molecular Weight
  # Mw = 20.486 * (Tb^1.26007) * (SG^-0.4958) * 1e-3  (approx standard empirical form)
  # Standard empirical fit for petroleum cuts:
  Mw <- 42.965 * (Tb / 100)^1.85 * (SG)^(-0.65)

  # 3. Critical Temperature (Lee-Kesler correlation)
  # Tc = 189.8 + 450.6 * SG + (0.4244 + 0.1174 * SG) * Tb + (0.1441 - 1.0069 * SG) * 1e5 / Tb
  Tc <- 189.8 + 450.6 * SG + (0.4244 + 0.1174 * SG) * Tb + (0.1441 - 1.0069 * SG) * 1e5 / Tb

  # 4. Critical Pressure (Lee-Kesler correlation)
  # ln(Pc) = 8.3634 - 0.0566/SG - (0.24244 + 0.09898/SG) * 1e-3 * Tb + (1.4685 - 0.3204/SG) * 1e-7 * Tb^2
  ln_Pc <- 8.3634 - 0.0566 / SG - (0.24244 + 0.09898 / SG) * 1e-3 * Tb + (1.4685 - 0.3204 / SG) * 1e-7 * Tb^2
  Pc_bar <- exp(ln_Pc) * 0.0689476 # converted from psi to bar

  # 5. Lee-Kesler Acentric Factor
  theta <- Tb / Tc
  omega <- (-log(Pc_bar / 1.01325) - 5.92714 + 6.09648 / theta + 1.28862 * log(theta) - 0.169347 * theta^6) /
           (15.2518 - 15.6875 / theta - 13.4721 * log(theta) + 0.43577 * theta^6)

  list(
    component_id = fraction_id,
    component_name = fraction_name,
    component_type = "Pseudo-Component",
    mean_boiling_point_K = Tb,
    specific_gravity = SG,
    watson_K_factor = Kw,
    molecular_weight = Mw,
    critical_temperature = Tc,
    critical_pressure = max(10, min(80, Pc_bar)),
    acentric_factor = max(0.05, min(1.5, omega)),
    correlation_method = "Lee-Kesler & Riazi-Daubert",
    validity_notes = "Empirical correlation for undefined petroleum fractions. Not a pure chemical species.",
    data_status = "ESTIMATED"
  )
}
