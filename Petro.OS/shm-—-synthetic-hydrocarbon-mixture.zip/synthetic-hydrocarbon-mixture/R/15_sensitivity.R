#' Sensitivity Analysis Laboratory and Tornado Metrics
#' @description
#' Evaluates the sensitivity of mixture properties and economics to variations
#' in feedstock prices, temperature, pressure, and component fractions.

#' Compute Tornado Sensitivity Rankings
#' @param mixture SHM mixture object
#' @param perturbation_pct Relative swing to test (+/- percentage, default 10%)
#' @return Data frame of parameters ranked by their impact on unit cost and density
#' @export
shm_sensitivity_tornado <- function(mixture, perturbation_pct = 0.10) {
  comps <- mixture$components
  base_cost <- sum(comps$mass_fraction * comps$cost_per_kg)
  base_mw <- mixture$mixture_molecular_weight

  results <- list()

  # 1. Sensitivity to component prices
  for (i in seq_len(nrow(comps))) {
    cid <- comps$component_id[i]
    p_orig <- comps$cost_per_kg[i]
    w_i <- comps$mass_fraction[i]

    cost_low <- base_cost - w_i * (p_orig * perturbation_pct)
    cost_high <- base_cost + w_i * (p_orig * perturbation_pct)

    results[[length(results) + 1]] <- data.frame(
      parameter_category = "Component Price",
      parameter_name = paste("Price:", cid),
      baseline_value = p_orig,
      swing_low = cost_low,
      swing_high = cost_high,
      swing_delta = abs(cost_high - cost_low),
      impact_metric = "Unit Cost ($/kg)",
      stringsAsFactors = FALSE
    )
  }

  # 2. Sensitivity to Temperature and Pressure
  t_orig <- mixture$temperature_K
  # Approx density change with temperature ~ -0.1% per K
  dens_base <- (base_mw / sum(comps$mole_fraction * (comps$molecular_weight / comps$density_std))) * 1000
  dens_low_t <- dens_base * (1 + 0.001 * (t_orig * perturbation_pct))
  dens_high_t <- dens_base * (1 - 0.001 * (t_orig * perturbation_pct))

  results[[length(results) + 1]] <- data.frame(
    parameter_category = "Thermodynamic State",
    parameter_name = "Temperature (K)",
    baseline_value = t_orig,
    swing_low = dens_low_t,
    swing_high = dens_high_t,
    swing_delta = abs(dens_high_t - dens_low_t),
    impact_metric = "Density (kg/m3)",
    stringsAsFactors = FALSE
  )

  df <- do.call(rbind, results)
  # Sort by swing_delta descending
  df[order(df$swing_delta, decreasing = TRUE), ]
}
