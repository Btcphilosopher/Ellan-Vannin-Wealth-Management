#' Data Provenance and Units Handling for SHM
#' @description
#' Enforces explicit SI internal units and standard data status flags:
#' MEASURED, SYNTHETIC, HISTORICAL, MODELLED, ESTIMATED, IMPORTED, STALE, UNAVAILABLE.

DATA_STATUSES <- c(
  "MEASURED",
  "SYNTHETIC",
  "HISTORICAL",
  "MODELLED",
  "ESTIMATED",
  "IMPORTED",
  "STALE",
  "UNAVAILABLE"
)

#' Validate Data Status
#' @param status String representing the data provenance status.
#' @return Logical TRUE if valid, throws error otherwise.
#' @export
shm_validate_data_status <- function(status) {
  if (!status %in% DATA_STATUSES) {
    stop(sprintf(
      "Invalid data status: '%s'. Must be one of: %s",
      status, paste(DATA_STATUSES, collapse = ", ")
    ))
  }
  invisible(TRUE)
}

#' Convert Temperature
#' @param value Numeric temperature value.
#' @param from Unit string ('K', 'C', 'F', 'R').
#' @param to Target unit string ('K', 'C', 'F', 'R').
#' @return Converted numeric temperature.
#' @export
shm_convert_temperature <- function(value, from = "C", to = "K") {
  # Convert to Kelvin first
  k <- switch(from,
    "K" = value,
    "C" = value + 273.15,
    "F" = (value - 32) * 5 / 9 + 273.15,
    "R" = value * 5 / 9,
    stop(paste("Unknown temperature unit:", from))
  )
  if (any(k < 0, na.rm = TRUE)) {
    warning("Temperature below absolute zero detected!")
  }
  # Convert from Kelvin to target
  switch(to,
    "K" = k,
    "C" = k - 273.15,
    "F" = (k - 273.15) * 9 / 5 + 32,
    "R" = k * 9 / 5,
    stop(paste("Unknown target temperature unit:", to))
  )
}

#' Convert Pressure
#' @param value Numeric pressure value.
#' @param from Unit string ('Pa', 'kPa', 'bar', 'MPa', 'psi', 'atm').
#' @param to Target unit string ('Pa', 'kPa', 'bar', 'MPa', 'psi', 'atm').
#' @return Converted numeric pressure.
#' @export
shm_convert_pressure <- function(value, from = "bar", to = "Pa") {
  # Base SI: Pascal
  pa <- switch(from,
    "Pa"  = value,
    "kPa" = value * 1e3,
    "bar" = value * 1e5,
    "MPa" = value * 1e6,
    "psi" = value * 6894.757,
    "atm" = value * 101325,
    stop(paste("Unknown pressure unit:", from))
  )
  switch(to,
    "Pa"  = pa,
    "kPa" = pa / 1e3,
    "bar" = pa / 1e5,
    "MPa" = pa / 1e6,
    "psi" = pa / 6894.757,
    "atm" = pa / 101325,
    stop(paste("Unknown target pressure unit:", to))
  )
}
