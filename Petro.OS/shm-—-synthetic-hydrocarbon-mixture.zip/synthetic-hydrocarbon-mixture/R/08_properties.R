#' General Hydrocarbon Property Prediction Engine
#' @description
#' Predicts mixture molecular weight, vapour pressure, enthalpy departures,
#' heat capacity, and dynamic viscosity.

#' Calculate Component Saturated Vapour Pressure (Antoine equation)
#' @param A Antoine constant A (log10 P/bar)
#' @param B Antoine constant B
#' @param C Antoine constant C
#' @param T Temperature (K)
#' @return Saturated vapour pressure in bar
shm_antoine_p_sat <- function(A, B, C, T) {
  10^(A - B / (T + C))
}

#' Predict All Thermophysical Properties for a Hydrocarbon Mixture
#' @param mixture SHM mixture object
#' @param T Temperature in K (optional)
#' @param P Pressure in bar (optional)
#' @param model_id Model identifier (default "PR-1976")
#' @return Comprehensive property list with units, models, and validity notes
#' @export
shm_predict_properties <- function(mixture, T = NULL, P = NULL, model_id = "PR-1976") {
  if (is.null(T)) T <- mixture$temperature_K
  if (is.null(P)) P <- mixture$pressure_bar

  comps <- mixture$components
  x <- comps$mole_fraction
  w <- comps$mass_fraction
  M <- comps$molecular_weight
  Tc <- comps$critical_temperature
  Pc <- comps$critical_pressure
  omega <- comps$acentric_factor

  # 1. Density & volumetric properties
  density_res <- shm_density_rackett(mixture, T = T, P = P, eos = ifelse(grepl("SRK", model_id), "SRK", "PR"))

  # 2. Vapour-Liquid flash
  flash_res <- shm_rachford_rice_flash(mixture, T = T, P = P, eos = ifelse(grepl("SRK", model_id), "SRK", "PR"))

  # 3. Component vapour pressures & True Vapour Pressure (TVP) estimate
  lib <- shm_component_library()
  match_rows <- match(comps$component_id, lib$component_id)
  p_sat_pure <- mapply(
    shm_antoine_p_sat,
    lib$antoine_A[match_rows],
    lib$antoine_B[match_rows],
    lib$antoine_C[match_rows],
    MoreArgs = list(T = T)
  )
  tvp_bar <- sum(x * p_sat_pure)

  # 4. Enthalpy & Heat Capacity Estimates (Ideal + Departure)
  # Standard hydrocarbon ideal gas Cp ~ 1.8 - 2.4 kJ/(kg*K)
  cp_ideal_kJ_kg_K <- sum(w * (1.7 + 0.002 * (T - 273.15)))
  cp_liquid_kJ_kg_K <- cp_ideal_kJ_kg_K * 1.25

  # 5. Viscosity (Andrade / Logarithmic mixing for liquids)
  # Dynamic viscosity ~ 0.2 - 2.0 mPa*s (cP)
  visc_pure <- exp(1000 / (T + 50) - 4.5) * (M / 100)^0.5
  visc_liq_mPa_s <- exp(sum(x * log(pmax(visc_pure, 0.05))))

  # 6. Thermal Conductivity (Latini correlation approx)
  k_th_W_m_K <- 0.14 - 0.00025 * (T - 273.15)

  list(
    mixture_id = mixture$mixture_id,
    mixture_name = mixture$mixture_name,
    temperature_K = T,
    pressure_bar = P,
    thermodynamic_model = model_id,
    molecular_weight_g_mol = mixture$mixture_molecular_weight,
    liquid_density_kg_m3 = density_res$liquid_density_kg_m3,
    vapour_density_kg_m3 = density_res$vapour_density_kg_m3,
    specific_gravity = density_res$specific_gravity_60F,
    compressibility_Z = density_res$compressibility_factor_Z,
    true_vapour_pressure_bar = tvp_bar,
    vapour_fraction_beta = flash_res$vapour_fraction_beta,
    liquid_fraction = flash_res$liquid_fraction,
    phase_state = flash_res$phase_state,
    bubble_pressure_estimate_bar = tvp_bar * 1.05,
    dew_pressure_estimate_bar = tvp_bar * 0.95,
    heat_capacity_liquid_kJ_kg_K = cp_liquid_kJ_kg_K,
    heat_capacity_vapour_kJ_kg_K = cp_ideal_kJ_kg_K,
    viscosity_liquid_mPa_s = visc_liq_mPa_s,
    thermal_conductivity_W_m_K = k_th_W_m_K,
    flash_converged = flash_res$converged,
    material_balance_residual = flash_res$material_balance_residual,
    data_status = "MODELLED"
  )
}
