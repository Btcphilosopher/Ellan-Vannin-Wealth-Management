#' Component and Stream Inventory Management
#' @description
#' Tracks real physical and storage tank inventories, reservations, minimum limits,
#' and multi-batch allocation locks.

#' Get Current Inventory Status
#' @return Data frame of all inventory assets with available, reserved, and net quantities
#' @export
shm_inventory_status <- function() {
  streams <- shm_stream_library()

  rows <- lapply(streams, function(s) {
    data.frame(
      asset_id = s$stream_id,
      asset_name = s$stream_name,
      total_quantity_kg = s$available_quantity_kg + s$reserved_quantity_kg,
      reserved_kg = s$reserved_quantity_kg,
      available_kg = s$available_quantity_kg,
      cost_per_kg = s$cost_per_kg,
      quality = s$quality_status,
      data_status = s$data_status,
      stringsAsFactors = FALSE
    )
  })

  do.call(rbind, rows)
}

#' Reserve Inventory for a Batch
#' @param asset_id Identifier of stream or component
#' @param quantity_kg Quantity to reserve
#' @return Updated inventory record or error if insufficient inventory
#' @export
shm_reserve_inventory <- function(asset_id, quantity_kg) {
  inv <- shm_inventory_status()
  idx <- which(inv$asset_id == asset_id)
  if (length(idx) == 0) stop(sprintf("Asset %s not found in inventory.", asset_id))

  curr <- inv[idx, ]
  if (curr$available_kg < quantity_kg) {
    stop(sprintf(
      "Insufficient inventory for %s: requested %.1f kg, but only %.1f kg available.",
      asset_id, quantity_kg, curr$available_kg
    ))
  }

  list(
    asset_id = asset_id,
    reservation_id = paste0("RES-", format(Sys.time(), "%Y%m%d%H%M%S")),
    quantity_reserved_kg = quantity_kg,
    remaining_available_kg = curr$available_kg - quantity_kg,
    timestamp = Sys.time(),
    status = "RESERVED"
  )
}
