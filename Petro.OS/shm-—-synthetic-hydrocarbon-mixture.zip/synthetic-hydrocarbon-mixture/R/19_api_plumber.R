#' Plumber REST API Router for SHM Platform
#' @description
#' Implements the OpenAPI v1 REST API for hydrocarbon mixtures,
#' property predictions, PT flash, formulation optimisation, and reports.

#* @apiTitle SHM — Synthetic Hydrocarbon Mixture API
#* @apiDescription R-Native Hydrocarbon Formulation, Property Modelling, and Optimisation Service
#* @apiVersion 1.0.0

#* Get list of pure components and characterized fractions
#* @get /api/v1/components
function() {
  lib <- shm_component_library()
  as.list(as.data.frame(t(lib)))
}

#* Get list of characterized source streams
#* @get /api/v1/streams
function() {
  shm_stream_library()
}

#* Create and validate a hydrocarbon mixture
#* @post /api/v1/mixtures
#* @param req Request body with component_ids, fractions, basis, temperature, pressure
function(req) {
  body <- jsonlite::fromJSON(req$postBody)
  shm_create_mixture(
    name = ifelse(is.null(body$name), "API Mixture", body$name),
    component_ids = body$component_ids,
    fractions = body$fractions,
    basis = ifelse(is.null(body$basis), "mole", body$basis),
    temperature = ifelse(is.null(body$temperature), 298.15, body$temperature),
    pressure = ifelse(is.null(body$pressure), 1.01325, body$pressure)
  )
}

#* Calculate physical properties
#* @post /api/v1/properties/calculate
function(req) {
  body <- jsonlite::fromJSON(req$postBody)
  mix <- shm_create_mixture(
    name = "Calc Mix",
    component_ids = body$component_ids,
    fractions = body$fractions,
    basis = body$basis,
    temperature = body$temperature,
    pressure = body$pressure
  )
  shm_predict_properties(mix, model_id = ifelse(is.null(body$model_id), "PR-1976", body$model_id))
}

#* Perform isothermal/isobaric Rachford-Rice flash
#* @post /api/v1/thermodynamics/flash
function(req) {
  body <- jsonlite::fromJSON(req$postBody)
  mix <- shm_create_mixture(
    name = "Flash Mix",
    component_ids = body$component_ids,
    fractions = body$fractions,
    basis = "mole",
    temperature = body$temperature,
    pressure = body$pressure
  )
  shm_rachford_rice_flash(mix, T = body$temperature, P = body$pressure, eos = body$eos)
}

#* Optimise formulation
#* @post /api/v1/optimisations
function(req) {
  body <- jsonlite::fromJSON(req$postBody)
  csts <- list()
  if (!is.null(body$min_density)) {
    csts[[length(csts) + 1]] <- shm_define_constraint("liquid_density_kg_m3", minimum = body$min_density)
  }
  if (!is.null(body$max_tvp)) {
    csts[[length(csts) + 1]] <- shm_define_constraint("true_vapour_pressure_bar", maximum = body$max_tvp)
  }

  shm_optimise_formulation(
    candidate_component_ids = body$candidate_components,
    target_quantity = ifelse(is.null(body$target_quantity), 1000, body$target_quantity),
    constraints = csts,
    objective = ifelse(is.null(body$objective), "MIN_COST", body$objective)
  )
}
