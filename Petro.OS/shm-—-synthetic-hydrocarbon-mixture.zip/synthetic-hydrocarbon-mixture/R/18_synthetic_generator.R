#' Synthetic Data Generator for Hydrocarbon Research and Testing
#' @description
#' Generates coherent, physically consistent test components, mixtures,
#' and scenarios with deterministic seeds.
#' All records are explicitly tagged as SYNTHETIC DEMONSTRATION DATA.

#' Generate Synthetic Hydrocarbon Dataset
#' @param n_mixtures Number of sample mixtures to generate
#' @param seed Deterministic random seed
#' @return Comprehensive synthetic dataset bundle
#' @export
shm_generate_synthetic_dataset <- function(n_mixtures = 5, seed = 2026) {
  set.seed(seed)
  lib <- shm_component_library()
  streams <- shm_stream_library()

  mixtures_list <- list()

  # Archetypes: Light Gas, Rich Gas, Light Condensate, Naphtha Blend, Heavy Fraction
  archetypes <- list(
    list(name = "Synthetic Associated Gas", comps = c("C1", "C2", "C3", "iC4", "nC4"), T = 300, P = 20),
    list(name = "Synthetic Field Condensate", comps = c("iC4", "nC4", "iC5", "nC5", "nC6", "COND_CUT"), T = 310, P = 4),
    list(name = "Synthetic Reformate Stream", comps = c("nC6", "2MP", "nC7", "BENZ", "TOL", "pXYL"), T = 298.15, P = 1.01325),
    list(name = "Synthetic Olefin-Rich Blend", comps = c("C2=", "C3=", "1C4=", "iC4=", "nC5"), T = 280, P = 15),
    list(name = "Synthetic Middle Distillate", comps = c("nC8", "nC9", "nC10", "HEAVY_NAPH", "KERO_CUT"), T = 325, P = 1.2)
  )

  for (i in seq_len(min(n_mixtures, length(archetypes)))) {
    arc <- archetypes[[i]]
    k <- length(arc$comps)
    # Generate random Dirichlet-style positive fractions
    raw_w <- runif(k, 0.05, 0.8)
    w <- raw_w / sum(raw_w)

    mix <- shm_create_mixture(
      name = paste0("[SYNTHETIC] ", arc$name),
      component_ids = arc$comps,
      fractions = w,
      basis = "mass",
      temperature = arc$T,
      pressure = arc$P,
      total_quantity = round(runif(1, 500, 15000), 0),
      quantity_unit = "kg"
    )
    mix$data_status <- "SYNTHETIC"
    mixtures_list[[i]] <- mix
  }

  list(
    dataset_metadata = list(
      title = "SYNTHETIC DEMONSTRATION DATASET",
      generator = "SHM Synthetic Generator v1.0",
      seed = seed,
      generated_at = Sys.time(),
      disclaimer = "Preserves empirical physical bounds. Explicitly synthetic demonstration data."
    ),
    available_pure_components_count = nrow(lib),
    available_streams_count = length(streams),
    generated_mixtures = mixtures_list
  )
}
