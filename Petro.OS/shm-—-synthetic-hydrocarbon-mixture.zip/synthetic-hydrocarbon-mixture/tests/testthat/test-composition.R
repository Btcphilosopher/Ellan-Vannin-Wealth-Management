test_that("Composition normalisation preserves sum to 1", {
  raw <- c(0.2, 0.3, 0.5)
  res <- shm_normalise_composition(raw)
  expect_equal(sum(res), 1.0, tolerance = 1e-7)

  # Check non-normalised input warning/adjustment
  raw2 <- c(10, 20, 70)
  res2 <- shm_normalise_composition(raw2)
  expect_equal(res2, c(0.1, 0.2, 0.7), tolerance = 1e-7)
})

test_that("Mole to mass conversion is mathematically reversible", {
  mw <- c(16.043, 30.070, 44.097) # C1, C2, C3
  x <- c(0.70, 0.20, 0.10)

  w <- shm_mole_to_mass(x, mw)
  expect_equal(sum(w), 1.0, tolerance = 1e-7)

  x_recon <- shm_mass_to_mole(w, mw)
  expect_equal(x_recon, x, tolerance = 1e-6)
})

test_that("Mixture creation calculates correct molecular weight", {
  mix <- shm_create_mixture(
    name = "Test Binary",
    component_ids = c("nC6", "nC7"),
    fractions = c(0.5, 0.5),
    basis = "mole"
  )
  expect_equal(mix$mixture_molecular_weight, (86.177 + 100.204) / 2, tolerance = 1e-3)
  expect_equal(sum(mix$components$mass_fraction), 1.0, tolerance = 1e-6)
})
