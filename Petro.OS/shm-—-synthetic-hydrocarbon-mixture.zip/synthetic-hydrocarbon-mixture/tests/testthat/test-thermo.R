test_that("Peng-Robinson EOS computes reasonable Z factors", {
  # Pure methane at 298.15 K and 10 bar
  eos_res <- shm_eos_peng_robinson(
    mole_fractions = c(1.0),
    Tc = c(190.56),
    Pc = c(45.99),
    omega = c(0.011),
    T = 298.15,
    P = 10.0
  )

  expect_true(eos_res$Z_vap > 0.95 && eos_res$Z_vap <= 1.0)
  expect_true(eos_res$phi_vap > 0.95 && eos_res$phi_vap <= 1.0)
})

test_that("Rachford-Rice flash verifies component material balance", {
  mix <- shm_create_mixture(
    name = "Condensate Mix",
    component_ids = c("C3", "iC4", "nC4", "nC5", "nC6"),
    fractions = c(0.15, 0.20, 0.25, 0.25, 0.15),
    basis = "mole",
    temperature = 310.15,
    pressure = 3.5
  )

  flash_res <- shm_rachford_rice_flash(mix, T = 310.15, P = 3.5)
  expect_true(flash_res$converged)
  expect_true(flash_res$balance_verified)
  expect_true(flash_res$material_balance_residual < 1e-4)
})

test_that("Liquid density via Rackett is within realistic hydrocarbon boundaries", {
  mix <- shm_create_mixture(
    name = "Liquid Naphtha",
    component_ids = c("nC6", "nC7", "nC8"),
    fractions = c(0.33, 0.33, 0.34),
    basis = "mass",
    temperature = 298.15,
    pressure = 1.01325
  )

  dens <- shm_density_rackett(mix)
  expect_true(dens$liquid_density_kg_m3 > 640 && dens$liquid_density_kg_m3 < 730)
})
