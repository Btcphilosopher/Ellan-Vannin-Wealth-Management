test_that("Optimiser converges and produces valid mass fractions summing to 1", {
  opt_res <- shm_optimise_formulation(
    candidate_component_ids = c("iC5", "nC5", "nC6", "BENZ", "TOL"),
    target_quantity = 5000,
    objective = "MIN_COST"
  )

  expect_true(opt_res$is_feasible)
  expect_equal(sum(opt_res$components$mass_fraction), 1.0, tolerance = 1e-4)
  expect_equal(opt_res$total_mass_kg, 5000, tolerance = 1e-2)
  expect_true(opt_res$unit_cost_per_kg > 0)
})

test_that("Laboratory data validation accurately computes metrics", {
  val_res <- shm_validate_laboratory_data()
  expect_true(val_res$metric_summary$r_squared > 0.90)
  expect_true(val_res$metric_summary$mean_absolute_error > 0)
})
