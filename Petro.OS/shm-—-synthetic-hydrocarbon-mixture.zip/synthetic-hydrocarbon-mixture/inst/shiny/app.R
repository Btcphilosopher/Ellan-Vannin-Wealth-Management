# Shiny Application for SHM — Synthetic Hydrocarbon Mixture Platform
# File: inst/shiny/app.R

library(shiny)
library(bslib)
library(DT)
library(plotly)

# Define custom scientific theme
shm_theme <- bs_theme(
  version = 5,
  bootswatch = "slate",
  primary = "#0ea5e9",
  secondary = "#64748b",
  success = "#10b981",
  warning = "#f59e0b",
  danger = "#ef4444",
  base_font = font_google("Inter"),
  code_font = font_google("JetBrains Mono")
)

ui <- page_navbar(
  title = "SHM — Synthetic Hydrocarbon Mixture",
  theme = shm_theme,

  # 1. Overview
  nav_panel(
    "Overview",
    layout_columns(
      card(
        card_header("System Status & Provenance"),
        p("SHM is an R-native hydrocarbon-mixture formulation, property modelling, constrained optimisation and economic evaluation platform."),
        div(
          class = "badge bg-success p-2 mb-2",
          "ENGINE STATUS: OPERATIONAL"
        ),
        p("Internal SI units enforced. Pure components, characterized streams, and petroleum pseudo-fractions supported.")
      ),
      card(
        card_header("Active Thermodynamic Registry"),
        tableOutput("overview_models_table")
      )
    )
  ),

  # 2. Components
  nav_panel(
    "Components",
    card(
      card_header("Pure Hydrocarbons & Characterized Fractions"),
      DTOutput("components_table")
    )
  ),

  # 3. Streams
  nav_panel(
    "Streams",
    card(
      card_header("Characterized Source Stream Library"),
      DTOutput("streams_table")
    )
  ),

  # 4. Mixtures Workspace
  nav_panel(
    "Mixtures Workspace",
    layout_sidebar(
      sidebar = sidebar(
        title = "Mixture Formulation",
        textInput("mix_name", "Mixture Name", value = "Standard Condensate Blend"),
        selectInput("mix_basis", "Composition Basis", choices = c("mole", "mass", "volume"), selected = "mass"),
        numericInput("mix_temp_K", "Temperature (K)", value = 298.15, min = 100, max = 800),
        numericInput("mix_press_bar", "Pressure (bar)", value = 1.01325, min = 0.01, max = 300),
        numericInput("mix_qty", "Total Target Quantity (kg)", value = 1000, min = 1),
        selectInput("mix_model", "Thermodynamic Model", choices = c("PR-1976", "SRK-1972", "IDEAL-GAS"), selected = "PR-1976"),
        actionButton("btn_calc_mix", "Calculate & Flash", class = "btn-primary w-100")
      ),
      layout_columns(
        card(
          card_header("Mixture Properties & Volumetric State"),
          verbatimTextOutput("mix_summary_output")
        ),
        card(
          card_header("Vapour-Liquid Equilibrium Phase Split"),
          verbatimTextOutput("flash_summary_output")
        )
      )
    )
  ),

  # 5. Optimisation
  nav_panel(
    "Optimisation",
    layout_sidebar(
      sidebar = sidebar(
        title = "Constrained Formulation",
        selectInput("opt_objective", "Objective", choices = c("MIN_COST", "TARGET_COMPOSITION", "MAX_MARGIN")),
        numericInput("opt_target_qty", "Batch Quantity (kg)", value = 5000),
        numericInput("cst_min_dens", "Min Liquid Density (kg/m3)", value = 680),
        numericInput("cst_max_tvp", "Max TVP (bar)", value = 0.85),
        actionButton("btn_run_opt", "Run Formulation Optimiser", class = "btn-success w-100")
      ),
      card(
        card_header("Optimal Stream & Component Allocation"),
        DTOutput("opt_results_table")
      )
    )
  ),

  # 6. Economics
  nav_panel(
    "Economics",
    card(
      card_header("Financial & Margin Evaluation"),
      verbatimTextOutput("econ_summary_output")
    )
  ),

  # 7. Uncertainty & Lab Validation
  nav_panel(
    "Validation & Uncertainty",
    layout_columns(
      card(
        card_header("Laboratory Validation & ASTM Reconciliation"),
        verbatimTextOutput("lab_validation_output")
      ),
      card(
        card_header("Monte Carlo Robustness Metrics"),
        verbatimTextOutput("mc_summary_output")
      )
    )
  )
)

server <- function(input, output, session) {
  # Component library reactive
  lib_df <- reactive({
    shm_component_library()
  })

  output$overview_models_table <- renderTable({
    shm_model_registry()[, c("model_id", "model_name", "approval_status")]
  })

  output$components_table <- renderDT({
    datatable(lib_df()[, c("component_id", "component_name", "chemical_family", "molecular_weight", "critical_temperature", "critical_pressure", "cost_per_kg", "data_status")],
              options = list(pageLength = 10))
  })

  output$streams_table <- renderDT({
    inv <- shm_inventory_status()
    datatable(inv, options = list(pageLength = 5))
  })

  active_mix <- reactiveVal()

  observeEvent(input$btn_calc_mix, {
    mix <- shm_create_mixture(
      name = input$mix_name,
      component_ids = c("iC5", "nC5", "nC6", "BENZ", "TOL"),
      fractions = c(0.20, 0.25, 0.35, 0.10, 0.10),
      basis = input$mix_basis,
      temperature = input$mix_temp_K,
      pressure = input$mix_press_bar,
      total_quantity = input$mix_qty
    )
    active_mix(mix)
  })

  output$mix_summary_output <- renderPrint({
    mix <- active_mix()
    if (is.null(mix)) {
      cat("Click 'Calculate & Flash' to compute mixture properties.")
      return()
    }
    props <- shm_predict_properties(mix, model_id = input$mix_model)
    print(props)
  })

  output$flash_summary_output <- renderPrint({
    mix <- active_mix()
    if (is.null(mix)) {
      cat("Awaiting flash execution.")
      return()
    }
    flash <- shm_rachford_rice_flash(mix, T = input$mix_temp_K, P = input$mix_press_bar)
    print(flash)
  })

  observeEvent(input$btn_run_opt, {
    opt_res <- shm_optimise_formulation(
      candidate_component_ids = c("iC5", "nC5", "nC6", "BENZ", "TOL", "nC7"),
      target_quantity = input$opt_target_qty,
      objective = input$opt_objective
    )
    output$opt_results_table <- renderDT({
      datatable(opt_res$components)
    })
  })

  output$econ_summary_output <- renderPrint({
    mix <- shm_create_mixture(
      name = "Econ Mix",
      component_ids = c("iC5", "nC5", "nC6", "BENZ", "TOL"),
      fractions = c(0.20, 0.25, 0.35, 0.10, 0.10),
      basis = "mass",
      total_quantity = 5000
    )
    econ <- shm_economic_analysis(mix)
    print(econ)
  })

  output$lab_validation_output <- renderPrint({
    val <- shm_validate_laboratory_data()
    print(val$metric_summary)
    cat("\nStatus: ", val$validation_status, "\n")
  })

  output$mc_summary_output <- renderPrint({
    mix <- shm_create_mixture(
      name = "MC Base",
      component_ids = c("iC5", "nC5", "nC6", "BENZ", "TOL"),
      fractions = c(0.20, 0.25, 0.35, 0.10, 0.10),
      basis = "mass"
    )
    mc <- shm_monte_carlo_uncertainty(mix, n_samples = 200)
    print(mc)
  })
}

#' Launch the SHM Shiny Dashboard
#' @export
shm_launch_shiny <- function(...) {
  shinyApp(ui = ui, server = server, ...)
}
