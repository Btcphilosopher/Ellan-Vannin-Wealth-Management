import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { KonzernStateService } from './services/konzern-state';
import { HeaderComponent } from './components/header/header';
import { NavigationComponent } from './components/nav/navigation';
import { CommandPaletteComponent } from './components/command-palette/command-palette';
import { ExecutiveViewComponent } from './components/views/executive-view/executive-view';
import { FactoryViewComponent } from './components/views/factory-view/factory-view';
import { SupplyChainViewComponent } from './components/views/supply-chain-view/supply-chain-view';
import { EngineeringViewComponent } from './components/views/engineering-view/engineering-view';
import { BatteryViewComponent } from './components/views/battery-view/battery-view';
import { SoftwareViewComponent } from './components/views/software-view/software-view';
import { FinanceViewComponent } from './components/views/finance-view/finance-view';
import { QualityViewComponent } from './components/views/quality-view/quality-view';
import { SustainabilityViewComponent } from './components/views/sustainability-view/sustainability-view';
import { GraphViewComponent } from './components/views/graph-view/graph-view';
import { DemosViewComponent } from './components/views/demos-view/demos-view';
import { CopilotViewComponent } from './components/views/copilot-view/copilot-view';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    NavigationComponent,
    CommandPaletteComponent,
    ExecutiveViewComponent,
    FactoryViewComponent,
    SupplyChainViewComponent,
    EngineeringViewComponent,
    BatteryViewComponent,
    SoftwareViewComponent,
    FinanceViewComponent,
    QualityViewComponent,
    SustainabilityViewComponent,
    GraphViewComponent,
    DemosViewComponent,
    CopilotViewComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html'
})
export class App {
  readonly state = inject(KonzernStateService);
}
