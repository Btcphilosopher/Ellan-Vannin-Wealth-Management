import { Component, ChangeDetectionStrategy, inject, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService, KonzernTab } from '../../services/konzern-state';
import { MockKonzernDataService } from '../../services/mock-konzern-data';

import { BrandId } from '../../models/konzern-domain';

@Component({
  selector: 'app-command-palette',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './command-palette.html'
})
export class CommandPaletteComponent {
  readonly state = inject(KonzernStateService);
  readonly data = inject(MockKonzernDataService);

  query = '';

  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent) {
    if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
      event.preventDefault();
      this.state.toggleCommandPalette();
    }
    if (event.key === 'Escape' && this.state.commandPaletteOpen()) {
      this.state.toggleCommandPalette();
    }
  }

  close() {
    this.state.commandPaletteOpen.set(false);
  }

  goToTab(tab: KonzernTab) {
    this.state.setTab(tab);
    this.close();
  }

  runDemo(demoId: number) {
    this.state.runMasterDemo(demoId);
    this.close();
  }

  selectBrand(brandId: BrandId) {
    this.state.setBrand(brandId);
    this.state.setTab('engineering');
    this.close();
  }
}
