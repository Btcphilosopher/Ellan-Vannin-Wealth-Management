import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService, KonzernTab } from '../../services/konzern-state';

interface NavItem {
  id: KonzernTab;
  label: string;
  icon: string;
  badge?: string;
}

@Component({
  selector: 'app-navigation',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './navigation.html'
})
export class NavigationComponent {
  readonly state = inject(KonzernStateService);

  readonly navItems: NavItem[] = [
    { id: 'executive', label: 'Executive Control', icon: 'dashboard' },
    { id: 'factory', label: 'Fabrik OS', icon: 'precision_manufacturing', badge: 'TWIN' },
    { id: 'supply-chain', label: 'Supply Chain', icon: 'local_shipping' },
    { id: 'engineering', label: 'PLM & Fahrzeug', icon: 'directions_car' },
    { id: 'battery', label: 'Battery OS', icon: 'battery_charging_full', badge: 'PowerCo' },
    { id: 'software', label: 'Software & OTA', icon: 'terminal', badge: 'CARIAD' },
    { id: 'finance', label: 'CFO & Szenario', icon: 'account_balance' },
    { id: 'quality', label: 'Qualität & Garantie', icon: 'verified' },
    { id: 'sustainability', label: 'Energie & CO₂', icon: 'eco' },
    { id: 'graph', label: 'Konzernfaden', icon: 'hub' },
    { id: 'demos', label: 'Master-Demos', icon: 'slideshow', badge: '1-8' },
    { id: 'copilot', label: 'VW AI Copilot', icon: 'psychology', badge: 'AI' }
  ];

  selectTab(tab: KonzernTab) {
    this.state.setTab(tab);
  }
}
