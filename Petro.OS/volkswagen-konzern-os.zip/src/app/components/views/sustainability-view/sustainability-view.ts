import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';

@Component({
  selector: 'app-sustainability-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './sustainability-view.html'
})
export class SustainabilityViewComponent {
  readonly state = inject(KonzernStateService);
}
