import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';
import { MockKonzernDataService } from '../../../services/mock-konzern-data';
import { FactoryModel } from '../../../models/konzern-domain';

@Component({
  selector: 'app-factory-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './factory-view.html'
})
export class FactoryViewComponent {
  readonly state = inject(KonzernStateService);
  readonly data = inject(MockKonzernDataService);

  readonly selectedFactoryId = signal<string>('FAC-WOB-01');
  readonly anomalyActive = signal<boolean>(false);

  selectedFactory(): FactoryModel {
    return this.data.factories.find(f => f.id === this.selectedFactoryId()) || this.data.factories[0];
  }

  selectFactory(id: string) {
    this.selectedFactoryId.set(id);
    this.anomalyActive.set(false);
  }

  triggerMachineFault() {
    this.anomalyActive.set(true);
    this.state.addNotification(
      'error',
      'MASCHINENAUSFALL: Stanzpresse 42 (Halle 50 Wolfsburg)',
      'Hydraulikdruckverlust. Taktzeit verlangsamt von 54s auf 98s. OEE sinkt auf 52.4%. Impact: -180 Einheiten/Schicht.'
    );
    this.state.addAuditEvent(
      'Fabrik OS Agent',
      'FABRIK',
      'MASCHINEN_STÖRUNG',
      'MASCHINE',
      'MCH-WOB-42',
      'Automatische Anomalieneinstufung. Wartungsteam getriggert & Re-Routing initiiert.'
    );
  }

  resolveMachineFault() {
    this.anomalyActive.set(false);
    this.state.addNotification(
      'info',
      'MASCHINE REPARIERT: Stanzpresse 42 wieder im Optimalbetrieb',
      'Ventiltausch abgeschlossen. Taktzeit normalisiert auf 54s. OEE stellt sich bei 86.4% wieder ein.'
    );
  }

  runDemo2() {
    this.state.runMasterDemo(2);
  }
}
