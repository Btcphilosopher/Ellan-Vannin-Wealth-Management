import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';
import { MockKonzernDataService } from '../../../services/mock-konzern-data';

export interface FinancialProjection {
  projectedRevenueBnEUR: number;
  projectedEbitMarginPercent: number;
  projectedFreeCashflowBnEUR: number;
  capexEffectBnEUR: number;
  npvBnEUR: number;
  irrPercent: number;
  riskRating: string;
}

@Component({
  selector: 'app-finance-view',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './finance-view.html'
})
export class FinanceViewComponent {
  readonly state = inject(KonzernStateService);
  readonly data = inject(MockKonzernDataService);

  // Live Scenario State
  batteryCost = 95;
  evGrowth = 25;
  supplierRisk = 24;
  electricityPrice = 110;

  readonly calculationResult = signal<FinancialProjection>({
    projectedRevenueBnEUR: 322.3,
    projectedEbitMarginPercent: 7.0,
    projectedFreeCashflowBnEUR: 10.7,
    capexEffectBnEUR: 3.5,
    npvBnEUR: 14.2,
    irrPercent: 18.5,
    riskRating: 'GERING'
  });

  async runScenarioCalculation() {
    try {
      const res = await fetch('/api/scenarios/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          batteryCostEUR: this.batteryCost,
          evDemandGrowth: this.evGrowth,
          supplierRisk: this.supplierRisk,
          electricityPrice: this.electricityPrice
        })
      });
      const data = await res.json();
      this.calculationResult.set(data);
      this.state.addAuditEvent(
        'CFO Risk Engine',
        'FINANZEN',
        'SZENARIO_BERECHNET',
        'KAPITALALLOKATION',
        'SCEN-CUSTOM',
        `Simulierte Variablen: Akkukosten ${this.batteryCost}€/kWh, EV-Wachstum ${this.evGrowth}%. EBIT-Effekt: ${data.projectedEbitMarginPercent}%.`
      );
    } catch (e) {
      console.error(e);
    }
  }

  runDemo5() {
    this.state.runMasterDemo(5);
  }

  runDemo6() {
    this.state.runMasterDemo(6);
  }
}
