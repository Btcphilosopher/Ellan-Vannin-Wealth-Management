import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';

@Component({
  selector: 'app-quality-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './quality-view.html'
})
export class QualityViewComponent {
  readonly state = inject(KonzernStateService);
}
