import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';
import { MockKonzernDataService } from '../../../services/mock-konzern-data';

@Component({
  selector: 'app-supply-chain-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './supply-chain-view.html'
})
export class SupplyChainViewComponent {
  readonly state = inject(KonzernStateService);
  readonly data = inject(MockKonzernDataService);

  readonly supplierCrisisActive = signal<boolean>(false);

  triggerSupplierCrisis() {
    this.supplierCrisisActive.set(true);
    this.state.addNotification(
      'error',
      'LIEFERKETTEN-ALARM: LG Energy Solution Poland (-30% Kapazität)',
      'Akkuzelllieferung für ID.7 & Audi Q6 gefährdet. Automatische Re-Routing-Pipeline auf PowerCo Salzgitter SE eingeleitet.'
    );
    this.state.addAuditEvent(
      'Supply Chain Control',
      'SUPPLY_CHAIN',
      'KRISE_REROUTING',
      'LIEFERANT',
      'SUP-LGE-04',
      'Bestandsumverteilung + 1.200 Packs/Tag ab Salzgitter aktiviert. Produktionsstopp abgewendet.'
    );
  }

  resolveSupplierCrisis() {
    this.supplierCrisisActive.set(false);
    this.state.addNotification(
      'info',
      'LIEFERKETTE NORMALISIERT: Kapazität LG Poland wiederhergestellt',
      'Produktion läuft wieder mit 100% Sollmenge.'
    );
  }

  runDemo3() {
    this.state.runMasterDemo(3);
  }
}
