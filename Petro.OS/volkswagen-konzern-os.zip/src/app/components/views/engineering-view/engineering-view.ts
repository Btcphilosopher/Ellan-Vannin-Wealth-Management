import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';
import { MockKonzernDataService } from '../../../services/mock-konzern-data';
import { VehicleProgram } from '../../../models/konzern-domain';

@Component({
  selector: 'app-engineering-view',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './engineering-view.html'
})
export class EngineeringViewComponent {
  readonly state = inject(KonzernStateService);
  readonly data = inject(MockKonzernDataService);

  readonly selectedVehicleId = signal<string>('VEH-ID7');
  readonly bomTab = signal<'eBOM' | 'mBOM' | 'sBOM' | 'swBOM'>('eBOM');

  // Configurator options for live validation engine
  selectedBattery = '86kWh';
  selectedMotor = 'APP550 (210kW)';
  selectedHeatPump = true;
  selectedSoftwareVersion = 'v12.4.1';

  selectedVehicle(): VehicleProgram {
    return this.data.vehiclePrograms.find(v => v.id === this.selectedVehicleId()) || this.data.vehiclePrograms[0];
  }

  selectVehicle(id: string) {
    this.selectedVehicleId.set(id);
  }

  runDemo1() {
    this.state.runMasterDemo(1);
  }
}
