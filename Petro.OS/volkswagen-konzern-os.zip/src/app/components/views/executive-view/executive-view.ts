import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';
import { MockKonzernDataService } from '../../../services/mock-konzern-data';
import { BrandId } from '../../../models/konzern-domain';

@Component({
  selector: 'app-executive-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './executive-view.html'
})
export class ExecutiveViewComponent {
  readonly state = inject(KonzernStateService);
  readonly data = inject(MockKonzernDataService);

  selectBrand(brandId: BrandId) {
    this.state.setBrand(brandId);
    this.state.setTab('engineering');
  }

  runDemo(demoId: number) {
    this.state.runMasterDemo(demoId);
  }
}
