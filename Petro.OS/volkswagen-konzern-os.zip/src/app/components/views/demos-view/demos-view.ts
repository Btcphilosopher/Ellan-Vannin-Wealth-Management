import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';

export interface DemoDefinition {
  id: number;
  title: string;
  subtitle: string;
  reqNumber: string;
  icon: string;
  color: string;
  steps: {
    title: string;
    description: string;
    action: string;
    impact: string;
  }[];
}

@Component({
  selector: 'app-demos-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './demos-view.html'
})
export class DemosViewComponent {
  readonly state = inject(KonzernStateService);

  readonly activeDemo = signal<number>(1);
  readonly currentStep = signal<number>(0);
  readonly demoLogs = signal<string[]>([]);
  readonly demoCompleted = signal<boolean>(false);

  readonly demos: DemoDefinition[] = [
    {
      id: 1,
      title: 'Fahrzeug Digital Twin (VW ID.7 Lifecycle)',
      subtitle: 'Durchgängige Rückverfolgbarkeit von Bestellung bis Batterierecycling',
      reqNumber: '#103',
      icon: 'directions_car',
      color: 'text-blue-400',
      steps: [
        {
          title: 'Step 1: Kundenbestellung & eBOM Zuordnung',
          description: 'Kunde konfiguriert VW ID.7 Pro S in Wolfsburg. Digital Thread erzeugt eindeutige VIN & eBOM Struktur.',
          action: 'FIN-AUDIT CREATED: VIN WVWZZZ3CZRE902148',
          impact: 'eBOM gekoppelt mit MES Halle 50'
        },
        {
          title: 'Step 2: Fertigung in Halle 50 & Batteriefügung',
          description: 'Einheirat des PowerCo 86kWh Cell Packs (Seriennummer #PWR-86-9041) bei Station 3.',
          action: 'MES TELEMETRY: 54s Taktzeit gehalten',
          impact: 'Qualitätszertifikat ISO-26262 signiert'
        },
        {
          title: 'Step 3: High-Speed Software Flash & Flotten-Onboarding',
          description: 'CARIAD OS v12.4.1 wird in 180s über 10Gbit Ethernet geflasht.',
          action: 'CARIAD OTA: Flotten-Onboarding abgeschlossen',
          impact: 'Fahrzeug sendet Live-Telemetrie an Konzern OS'
        }
      ]
    },
    {
      id: 2,
      title: 'Fabrik Anomalieneinsatz (Stanzpresse 42)',
      subtitle: 'Prädiktive Erkennung eines Maschinenausfalls mit OEE-Anpassung',
      reqNumber: '#104',
      icon: 'warning',
      color: 'text-amber-400',
      steps: [
        {
          title: 'Step 1: Schwingungssensor schlägt Alarm',
          description: 'Stanzpresse 42 meldet Anstieg der Vibration von 1.8mm/s auf 8.4mm/s.',
          action: 'FABRIK ALARM: MCH-WOB-42 HYDRAULIKDRUCK',
          impact: 'Taktzeit steigt von 54s auf 98s'
        },
        {
          title: 'Step 2: Automatische OEE-Reberechnung',
          description: 'Werk-OEE Wolfsburg sinkt von 86.4% auf 52.4%. Engpass-Detektor schlägt Alarm.',
          action: 'ENGINE RE-CALCULATE: -180 Stk / Schicht',
          impact: 'Wartungsteam automatisch alarmiert'
        },
        {
          title: 'Step 3: Ersatzteil-Lieferung & KI-Pufferaktivierung',
          description: 'Ersatzventil aus Zentrallager Kassel geliefert. Puffer aus Halle 52 aktiviert.',
          action: 'REPARATUR ABGESCHLOSSEN: OEE 86.4% RESTORED',
          impact: 'Keine Beeinträchtigung der Kundenauslieferung'
        }
      ]
    },
    {
      id: 3,
      title: 'Lieferantenkrise & Re-Routing (LG Poland -> PowerCo)',
      subtitle: 'Kompensation eines 30%-igen Zellkapazitätsverlusts im Live-Betrieb',
      reqNumber: '#105',
      icon: 'local_shipping',
      color: 'text-red-400',
      steps: [
        {
          title: 'Step 1: Kapazitätsverlust-Meldung',
          description: 'LG Energy Solution Poland meldet 30% Ausfall wegen Rohstoffengpass.',
          action: 'SUPPLY CHAIN ALARM: SUP-LGE-04 KRITICAL',
          impact: 'Drohender Produktionsstopp in Zwickau'
        },
        {
          title: 'Step 2: KI-Re-Routing Pipeline schlägt an',
          description: 'Digitaler Konzernfaden berechnet Ausgleich über PowerCo Gigafactory Salzgitter.',
          action: 'POWERCO REROUTING: +1.200 Packs / Tag',
          impact: 'Salzgitter schaltet Zusatzschicht'
        },
        {
          title: 'Step 3: Logistik-Gleisverbindung umgeleitet',
          description: 'Güterzugverkehr direkt von Salzgitter nach Wolfsburg & Zwickau terminiert.',
          action: 'BESTAND STABILISIERT: 0 FAHRZEUGE AUSFALL',
          impact: '380 Mio. € Umsatz gerettet'
        }
      ]
    },
    {
      id: 4,
      title: 'Software Release v12.4 & OTA Emergency Rollback',
      subtitle: 'Incident Management bei 4.85% Infotainment Display-Flicker',
      reqNumber: '#106',
      icon: 'terminal',
      color: 'text-purple-400',
      steps: [
        {
          title: 'Step 1: Staged Rollout in Ring 2 (10% Flotte)',
          description: 'CARIAD rollt Software v12.4.0 an 50.000 Fahrzeuge aus.',
          action: 'OTA TELEMETRY: 12.400 Downloads abgeschlossen',
          impact: 'Telemetrie-Monitor schaltet live'
        },
        {
          title: 'Step 2: Anomalienerkennung im Feld',
          description: 'Telemetrie verzeichnet 4.85% Display-Flicker bei Beifahrer-Displays.',
          action: 'AUTOMATED INCIDENT #402: FLEET STOP',
          impact: 'Schwellenwert 0.5% überschritten'
        },
        {
          title: 'Step 3: Vier-Augen Rollback Befehl',
          description: 'Peter Bosch (CARIAD) autorisiert automatischen Rollback auf v12.3.8.',
          action: 'OTA ROLLBACK EXECUTED: 12.400 VEHICLES RESTORED',
          impact: 'Flotte in 42 Minuten wieder stabil'
        }
      ]
    },
    {
      id: 5,
      title: 'CFO Executive Margin Deep Dive',
      subtitle: 'Ursachenanalyse der EBIT-Margen-Abweichung von 8.0% auf 7.0%',
      reqNumber: '#107',
      icon: 'analytics',
      color: 'text-emerald-400',
      steps: [
        {
          title: 'Step 1: Konzern-Margen-Aufschlüsselung',
          description: 'CFO analysiert EBIT-Marge: 7.0% (Soll 8.0%). Abweichung = -1.0%-Punkte.',
          action: 'CFO ENGINE: MARGIN DRIFT DETECTED',
          impact: 'Drei Hauptursachen identifiziert'
        },
        {
          title: 'Step 2: Ursachen-Drilldown im Digital Thread',
          description: '1. Zellkosten (+420M€) | 2. Modellmix EV (+210M€) | 3. CARIAD F&E (+310M€).',
          action: 'THREAD TRACEBACK: COMPONENT TO P&L',
          impact: 'Präzise Zuordnung auf Bauteilebene'
        },
        {
          title: 'Step 3: Gegenmaßnahmen-Katalog',
          description: 'Hochlauf PowerCo Einheitszelle reduziert Zellkosten ab Q4 um 12%.',
          action: 'VORSTANDS-FREIGABE: CAPEX ZELLWERK 2',
          impact: 'Marge kehrt auf 7.8% zurück'
        }
      ]
    },
    {
      id: 6,
      title: 'Strategie & Kapitalallokation (Szenario A vs B)',
      subtitle: 'Gegenüberstellung von EV-Boom vs. Flexibler Antriebsmatrix',
      reqNumber: '#108',
      icon: 'insights',
      color: 'text-cyan-400',
      steps: [
        {
          title: 'Step 1: Szenario A (EV Boom +35%) Laden',
          description: 'CAPEX: 4.2 Mrd. € | EBIT Δ: +1.4% | NPV: 12.4 Mrd. €.',
          action: 'SCENARIO A COMPUTED',
          impact: 'Hohes Wachstum, hohe Investitionen'
        },
        {
          title: 'Step 2: Szenario B (Flexible Matrix) Laden',
          description: 'CAPEX: 1.5 Mrd. € | EBIT Δ: +0.4% | NPV: 5.6 Mrd. €.',
          action: 'SCENARIO B COMPUTED',
          impact: 'Risikoarm, geringeres Potenzial'
        },
        {
          title: 'Step 3: Vorstandsentscheidung & Kapitalfreigabe',
          description: 'Oliver Blume (CEO) gibt hybrides Investitionspaket frei.',
          action: 'AUDIT LOG: CAPEX ALLOCATION APPROVED',
          impact: 'Kapitalgraph aktualisiert'
        }
      ]
    },
    {
      id: 7,
      title: 'PowerCo Einheitszelle Battery Deep Dive',
      subtitle: 'Standardisierung von 80% aller Akkus über alle Konzernmarken',
      reqNumber: '#109',
      icon: 'battery_charging_full',
      color: 'text-emerald-400',
      steps: [
        {
          title: 'Step 1: Zellchemie NMC-811 Auswahl',
          description: 'Energiedichte 260 Wh/kg, 800V Ladefähigkeit.',
          action: 'POWERCO SPEC: UNIFIED CELL PACK 86kWh',
          impact: '-30% Zellkosten realisiert'
        },
        {
          title: 'Step 2: Gigafactory Salzgitter Skalierung',
          description: '40 GWh Kapazität online. 100% Traceability aller Rohstoffe.',
          action: 'FACTORY STATUS: 92% AUSLASTUNG',
          impact: 'Versorgung von ID.7, Q6 & Macan gesichert'
        }
      ]
    },
    {
      id: 8,
      title: 'Konzern Digital Twin Network Graph',
      subtitle: 'Live-Visualisierung der Abhängigkeiten im Konzernfaden',
      reqNumber: '#110',
      icon: 'hub',
      color: 'text-indigo-400',
      steps: [
        {
          title: 'Step 1: Graph-Topologie laden',
          description: '15 Kern-Knoten und 15 Kanten (Relations) im Memory-Mesh verknüpft.',
          action: 'ENTERPRISE MESH: 100% KOHÄRENT',
          impact: 'Visualisierung im Digital Thread'
        },
        {
          title: 'Step 2: Impact-Analyse von Vorstand bis Schraube',
          description: 'Wirkung einer Entscheidung auf alle Unterentitäten berechnet.',
          action: 'GRAPH DYNAMICS VALIDATED',
          impact: 'Konzern OS Betriebsbereit'
        }
      ]
    }
  ];

  currentDemoObj(): DemoDefinition {
    return this.demos.find(d => d.id === this.activeDemo()) || this.demos[0];
  }

  selectDemo(id: number) {
    this.activeDemo.set(id);
    this.currentStep.set(0);
    this.demoLogs.set([`▶ Demo ${id} geladen: ${this.currentDemoObj().title}`]);
    this.demoCompleted.set(false);
  }

  runNextStep() {
    const demo = this.currentDemoObj();
    const nextIndex = this.currentStep() + 1;
    
    if (nextIndex < demo.steps.length) {
      this.currentStep.set(nextIndex);
      const step = demo.steps[nextIndex];
      this.demoLogs.update(l => [`[${step.action}] ${step.title}: ${step.impact}`, ...l]);
    } else {
      this.demoCompleted.set(true);
      this.demoLogs.update(l => [`✓ DEMO ${demo.id} ERFOLGREICH ABGESCHLOSSEN`, ...l]);
      this.state.addAuditEvent(
        'Master Demo Runner',
        'DEMO_ENGINE',
        'DEMO_ABGESCHLOSSEN',
        'MASTER_DEMO',
        `DEMO-${demo.id}`,
        `Demo "${demo.title}" vollständig mit allen Schritten ausgeführt.`
      );
    }
  }

  resetDemo() {
    this.currentStep.set(0);
    this.demoLogs.set([`▶ Demo ${this.activeDemo()} zurückgesetzt.`]);
    this.demoCompleted.set(false);
  }
}
