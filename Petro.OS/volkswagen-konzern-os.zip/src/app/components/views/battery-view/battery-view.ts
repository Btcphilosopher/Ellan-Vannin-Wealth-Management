import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';
import { MockKonzernDataService } from '../../../services/mock-konzern-data';

@Component({
  selector: 'app-battery-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './battery-view.html'
})
export class BatteryViewComponent {
  readonly state = inject(KonzernStateService);
  readonly data = inject(MockKonzernDataService);

  readonly selectedChemistry = signal<'NMC-811' | 'LFP' | 'SolidState'>('NMC-811');
  readonly fastChargeCycles = signal<number>(450);

  // Computed health status from fast charge cycles
  calculatedSohPercent(): number {
    const cycles = this.fastChargeCycles();
    if (cycles < 500) return 96.4;
    if (cycles < 1000) return 91.2;
    return 84.8;
  }

  runDemo7() {
    this.state.runMasterDemo(7);
  }
}
