import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';
import { MockKonzernDataService } from '../../../services/mock-konzern-data';

@Component({
  selector: 'app-software-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './software-view.html'
})
export class SoftwareViewComponent {
  readonly state = inject(KonzernStateService);
  readonly data = inject(MockKonzernDataService);

  readonly rollbackTriggered = signal<boolean>(false);

  triggerEmergencyRollback() {
    this.rollbackTriggered.set(true);
    this.state.addNotification(
      'error',
      'OTA ROLLBACK EXECUTED: Release v12.4.0 gestoppt',
      '12.400 betroffene Fahrzeuge automatisch auf stable v12.3.8 zurückgerollt. Incident #402 geschlossen.'
    );
    this.state.addAuditEvent(
      'CARIAD OTA Manager',
      'SOFTWARE',
      'OTA_ROLLBACK',
      'SOFTWARE_RELEASE',
      'SW-12.4.0-FAIL',
      'Notfall-Rollback aufgrund von Display-Anomalien. Fleet Stopp für Welle 1 aktiviert.'
    );
  }

  runDemo4() {
    this.state.runMasterDemo(4);
  }
}
