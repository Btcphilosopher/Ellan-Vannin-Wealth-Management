import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';
import { MockKonzernDataService } from '../../../services/mock-konzern-data';

export interface ChatMessage {
  sender: 'user' | 'assistant';
  text: string;
  source?: string;
  timestamp: string;
}

@Component({
  selector: 'app-copilot-view',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './copilot-view.html'
})
export class CopilotViewComponent {
  readonly state = inject(KonzernStateService);
  readonly data = inject(MockKonzernDataService);

  userInput = '';
  readonly isLoading = signal<boolean>(false);

  readonly messages = signal<ChatMessage[]>([
    {
      sender: 'assistant',
      text: 'Guten Tag. Ich bin VW GROUP AI, der autoritative KI-Copilot von VOLKSWAGEN KONZERN OS 2026.\n\nIch habe direkten Lese-Zugriff auf den kanonischen Digital Thread über alle 10 Marken, 100 Fabriken, PowerCo Batteriezellen, CARIAD Software & Finanzmodelle.\n\nWie kann ich Sie bei Ihrer Vorstands-Analyse oder operativen Entscheidung unterstützen?',
      source: 'GEMINI_3_8_FLASH',
      timestamp: '09:00:00'
    }
  ]);

  readonly promptChips = [
    'Analysiere die Ursachen der EBIT-Margenabweichung von 8,0% auf 7,0%.',
    'Wie reagiert der Konzern auf den 30% Kapazitätsverlust bei LG Poland?',
    'Zeige den Status der PowerCo Salzgitter Einheitszellen-Fertigung.',
    'Prüfe den Rollout-Status von CARIAD OS v12.4.1.'
  ];

  async sendMessage(customText?: string) {
    const textToSend = customText || this.userInput.trim();
    if (!textToSend || this.isLoading()) return;

    const userMsg: ChatMessage = {
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toTimeString().split(' ')[0]
    };

    this.messages.update(m => [...m, userMsg]);
    if (!customText) this.userInput = '';
    this.isLoading.set(true);

    try {
      const res = await fetch('/api/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          context: {
            kpi: this.data.kpiSummary,
            brandsCount: this.data.brands.length,
            factoriesCount: this.data.factories.length
          }
        })
      });

      const data = await res.json();
      
      const assistantMsg: ChatMessage = {
        sender: 'assistant',
        text: data.reply || 'Antwort von KI erhalten.',
        source: data.source || 'GEMINI_3_8_FLASH',
        timestamp: new Date().toTimeString().split(' ')[0]
      };

      this.messages.update(m => [...m, assistantMsg]);
      this.state.addAuditEvent(
        'VW GROUP AI',
        'COPILOT',
        'KI_ANFRAGE',
        'KNOWLEDGE_BASE',
        'GEMINI-3.8-FLASH',
        `Anfrage verarbeitet: "${textToSend.substring(0, 40)}..."`
      );
    } catch (e: unknown) {
      const errMessage = e instanceof Error ? e.message : String(e);
      this.messages.update(m => [...m, {
        sender: 'assistant',
        text: `Fehler bei der Anfrage: ${errMessage}`,
        timestamp: new Date().toTimeString().split(' ')[0]
      }]);
    } finally {
      this.isLoading.set(false);
    }
  }
}
