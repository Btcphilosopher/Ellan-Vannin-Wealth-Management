import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../../services/konzern-state';
import { MockKonzernDataService } from '../../../services/mock-konzern-data';
import { GraphNode } from '../../../models/konzern-domain';

@Component({
  selector: 'app-graph-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './graph-view.html'
})
export class GraphViewComponent {
  readonly state = inject(KonzernStateService);
  readonly data = inject(MockKonzernDataService);

  readonly selectedNode = signal<GraphNode | null>(this.data.graphNodes[0]);

  selectNode(n: GraphNode) {
    this.selectedNode.set(n);
  }

  runDemo8() {
    this.state.runMasterDemo(8);
  }
}
