import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KonzernStateService } from '../../services/konzern-state';
import { BrandId } from '../../models/konzern-domain';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './header.html'
})
export class HeaderComponent {
  readonly state = inject(KonzernStateService);

  onBrandChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value as BrandId | 'ALL';
    this.state.setBrand(val);
  }

  onRegionChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value;
    this.state.setRegion(val);
  }
}
