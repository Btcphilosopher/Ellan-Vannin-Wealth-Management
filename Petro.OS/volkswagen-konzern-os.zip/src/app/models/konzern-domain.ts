export type BrandId = 
  | 'volkswagen' 
  | 'audi' 
  | 'porsche' 
  | 'skoda' 
  | 'cupra' 
  | 'seat' 
  | 'vw-nutzfahrzeuge' 
  | 'bentley' 
  | 'lamborghini' 
  | 'ducati' 
  | 'powerco' 
  | 'cariad';

export type BrandGroup = 'Core' | 'Progressive' | 'Sport Luxury' | 'Trucks & Mobility' | 'Technology & Components';

export interface BrandInfo {
  id: BrandId;
  name: string;
  group: BrandGroup;
  headquarters: string;
  ceo: string;
  modelsCount: number;
  revenueBnEUR: number;
  ebitMarginPercent: number;
  evSharePercent: number;
  color: string;
}

export interface KonzernKpiSummary {
  revenueBnEUR: number;
  revenueGrowthPercent: number;
  ebitBnEUR: number;
  ebitMarginPercent: number;
  freeCashflowBnEUR: number;
  netLiquidityBnEUR: number;
  vehicleDeliveriesMillions: number;
  orderBankCount: number;
  factoryCapacityUtilizationPercent: number;
  evSharePercent: number;
  batteryProductionGWh: number;
  softwareReleasesCount: number;
  supplyChainRiskIndex: number; // 0 - 100
  capexBnEUR: number;
  rdExpenditureBnEUR: number;
  co2AverageGramsPerKm: number;
}

export interface FactoryModel {
  id: string;
  name: string;
  location: string;
  country: string;
  region: 'Europa' | 'Nordamerika' | 'Südamerika' | 'China' | 'Asien-Pazifik';
  brand: BrandId;
  type: 'Fahrzeugwerk' | 'Zellfabrik' | 'Komponentenwerk' | 'Motorenwerk';
  employees: number;
  annualCapacityUnits: number;
  currentOutputRate: number; // units/day
  oeePercent: number;
  availabilityPercent: number;
  performancePercent: number;
  qualityPercent: number;
  status: 'OPTIMAL' | 'ANOMALIE' | 'WARNUNG' | 'TEILSTILLSTAND';
  energyConsumptionMWhDay: number;
  greenEnergyPercent: number;
  activeLines: ProductionLine[];
}

export interface ProductionLine {
  id: string;
  name: string;
  taktTimeSeconds: number;
  targetOutputPerShift: number;
  actualOutputPerShift: number;
  stationsCount: number;
  status: 'RUNNING' | 'DEGRADED' | 'STOPPED';
  currentVehicleVin?: string;
  machines: FactoryMachine[];
}

export interface FactoryMachine {
  id: string;
  name: string;
  type: 'Stanzpresse' | 'Schweißroboter' | 'Lackierroboter' | 'High-Speed Flash Station' | 'Batterie-Fügeanlage' | 'Prüfstand';
  healthScore: number; // 0 - 100
  temperatureCelsius: number;
  vibrationMms: number;
  status: 'OK' | 'WARTUNG_ERFORDERLICH' | 'KRITISCH' | 'AUSFALL';
  lastMaintenance: string;
}

export interface VehicleProgram {
  id: string;
  name: string;
  brand: BrandId;
  platform: 'MEB' | 'PPE' | 'SSP' | 'MQB' | 'J1';
  powertrain: 'BEV' | 'PHEV' | 'ICE';
  sopDate: string;
  priceStartEUR: number;
  batteryCapacitykWh?: number;
  rangeKm?: number;
  weightKg: number;
  softwareVersion: string;
  status: 'KONZEPT' | 'ENTWICKLUNG' | 'PROTOTYP' | 'PRODUKTION' | 'FACELIFT';
  bomItemsCount: number;
}

export interface ComponentPart {
  id: string;
  partNumber: string;
  name: string;
  category: 'Batterie' | 'Inverter' | 'Elektromotor' | 'Steuergerät' | 'Sensor' | 'Karosserie' | 'Fahrwerk' | 'Software ECU';
  supplierId: string;
  supplierName: string;
  costEUR: number;
  weightKg: number;
  cobaltContentKg?: number;
  lithiumContentKg?: number;
  leadTimeDays: number;
  stockLevelUnits: number;
  reorderPointUnits: number;
  status: 'VERFÜGBAR' | 'ENGPASS' | 'QUALITÄTSSTOPP';
}

export interface SupplierModel {
  id: string;
  name: string;
  country: string;
  city: string;
  tier: 1 | 2;
  category: string;
  qualityScorePercent: number;
  deliveryOnTimePercent: number;
  riskIndex: number; // 0 - 100
  sustainabilityRating: 'A' | 'B' | 'C' | 'D';
  capacityUtilizationPercent: number;
  status: 'NORMAL' | 'KRITISCH' | 'KAPAZITÄTSVERLUST';
  affectedPartsCount: number;
}

export interface SoftwareRelease {
  id: string;
  version: string;
  domain: 'Infotainment' | 'ADAS / Autonomous' | 'Chassis & Battery OS' | 'Gateways & Telematics';
  buildNumber: string;
  releaseDate: string;
  status: 'IN_ENTWICKLUNG' | 'VALIDIERUNG' | 'FREIGEGEBEN' | 'ROLLOUT' | 'ZURÜCKGEROLLT';
  targetVehiclesCount: number;
  installedCount: number;
  failureRatePercent: number;
  changelog: string[];
}

export interface TelemetryPacket {
  vin: string;
  timestamp: string;
  speedKmh: number;
  batterySocPercent: number;
  batteryTempCelsius: number;
  motorTempCelsius: number;
  energyConsumptionKwh100km: number;
  adasStatus: 'ACTIVE' | 'STANDBY' | 'FAULT';
  softwareVersion: string;
  latitude: number;
  longitude: number;
  activeFaultCodes: string[];
}

export interface FinancialScenario {
  id: string;
  name: string;
  description: string;
  shockType: 'EV_BOOM' | 'EV_SLUMP' | 'BATTERY_COST_DROP' | 'SUPPLIER_CRISIS' | 'ENERGY_SHOCK';
  capexEffectBnEUR: number;
  opexEffectBnEUR: number;
  revenueEffectBnEUR: number;
  ebitMarginDeltaPercent: number;
  freeCashflowDeltaBnEUR: number;
  npvBnEUR: number;
  irrPercent: number;
  paybackYears: number;
}

export interface GraphNode {
  id: string;
  label: string;
  type: 'KONZERN' | 'MARKE' | 'FABRIK' | 'FAHRZEUG' | 'KOMPONENTE' | 'LIEFERANT' | 'SOFTWARE' | 'KUNDE' | 'FINANZEN';
  subText?: string;
  status?: 'ok' | 'warning' | 'error';
  metric?: string;
}

export interface GraphEdge {
  source: string;
  target: string;
  relation: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actor: string;
  role: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
  fourEyeStatus: 'N/A' | 'GENEHMIGT' | 'AUSSTEHEND';
}
