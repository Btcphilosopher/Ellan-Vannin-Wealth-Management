import { Injectable, signal, computed, inject } from '@angular/core';
import { BrandId, AuditEvent } from '../models/konzern-domain';
import { MockKonzernDataService } from './mock-konzern-data';

export type KonzernTab = 
  | 'executive' 
  | 'factory' 
  | 'supply-chain' 
  | 'engineering' 
  | 'battery' 
  | 'software' 
  | 'finance' 
  | 'quality' 
  | 'sustainability' 
  | 'graph' 
  | 'demos' 
  | 'copilot';

export interface DemoStepStatus {
  stepNumber: number;
  title: string;
  description: string;
  systemAction: string;
  impactMetric: string;
  status: 'PENDING' | 'EXECUTING' | 'COMPLETED' | 'ALERT';
}

@Injectable({
  providedIn: 'root'
})
export class KonzernStateService {
  private dataService = inject(MockKonzernDataService);

  // Active view tab
  readonly activeTab = signal<KonzernTab>('executive');
  
  // Brand & Region Filters
  readonly activeBrand = signal<BrandId | 'ALL'>('ALL');
  readonly activeRegion = signal<string>('ALL');
  
  // Search & Navigation
  readonly searchQuery = signal<string>('');
  readonly commandPaletteOpen = signal<boolean>(false);
  
  // Master Demo Engine
  readonly activeDemoId = signal<number | null>(null);
  readonly isDemoExecuting = signal<boolean>(false);
  readonly currentDemoStepIndex = signal<number>(0);
  readonly demoLogs = signal<string[]>([]);

  // Simulation parameters (interactive sliders)
  readonly batteryCostPerKwhEUR = signal<number>(95);
  readonly evDemandGrowthPercent = signal<number>(25);
  readonly supplierRiskThreshold = signal<number>(30);
  readonly electricityPriceEurPerMwh = signal<number>(110);

  // Audit and System Events
  readonly auditEvents = signal<AuditEvent[]>(this.dataService.auditEvents);
  readonly systemNotifications = signal<{id: string; time: string; type: 'info' | 'warn' | 'error'; title: string; detail: string}[]>([
    {
      id: 'N-1',
      time: '08:45:10',
      type: 'warn',
      title: 'FABRIK ANALYSE: Taktzeitabweichung Zwickau',
      detail: 'Station 42 meldet 3.2 Sek. Taktzeitverlängerung bei ID.7 Karosseriefügung.'
    },
    {
      id: 'N-2',
      time: '09:12:00',
      type: 'error',
      title: 'OTA MONITORING: Software Rollout v12.4.0 gestoppt',
      detail: 'Automatische Incident-Erstellung wegen Display-Anomalien. Rollback initiiert.'
    },
    {
      id: 'N-3',
      time: '09:30:15',
      type: 'info',
      title: 'POWERCO OS: Zellcharge Salzgitter #408 freigegeben',
      detail: 'Qualitätszertifikat ISO-26262 erfolgreich mit ev. Evidenz validiert.'
    }
  ]);

  // Derived filtered brands
  readonly filteredBrands = computed(() => {
    const brand = this.activeBrand();
    if (brand === 'ALL') return this.dataService.brands;
    return this.dataService.brands.filter(b => b.id === brand);
  });

  // Action methods
  setTab(tab: KonzernTab) {
    this.activeTab.set(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  setBrand(brand: BrandId | 'ALL') {
    this.activeBrand.set(brand);
  }

  setRegion(region: string) {
    this.activeRegion.set(region);
  }

  toggleCommandPalette() {
    this.commandPaletteOpen.update(v => !v);
  }

  addAuditEvent(actor: string, role: string, action: string, entityType: string, entityId: string, details: string) {
    const newEvent: AuditEvent = {
      id: `AUD-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      actor,
      role,
      action,
      entityType,
      entityId,
      details,
      fourEyeStatus: 'GENEHMIGT'
    };
    this.auditEvents.update(list => [newEvent, ...list]);
  }

  addNotification(type: 'info' | 'warn' | 'error', title: string, detail: string) {
    const notif = {
      id: `N-${Date.now()}`,
      time: new Date().toTimeString().split(' ')[0],
      type,
      title,
      detail
    };
    this.systemNotifications.update(list => [notif, ...list.slice(0, 15)]);
  }

  // Master Demo Launcher
  runMasterDemo(demoId: number) {
    this.activeDemoId.set(demoId);
    this.isDemoExecuting.set(true);
    this.currentDemoStepIndex.set(0);
    this.demoLogs.set([`▶ Master-Demo ${demoId} gestartet...`]);
    this.setTab('demos');
  }

  nextDemoStep() {
    this.currentDemoStepIndex.update(i => i + 1);
  }

  stopDemo() {
    this.activeDemoId.set(null);
    this.isDemoExecuting.set(false);
    this.currentDemoStepIndex.set(0);
  }
}
