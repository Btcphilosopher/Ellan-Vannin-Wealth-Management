import { Injectable } from '@angular/core';
import { 
  BrandInfo, 
  KonzernKpiSummary, 
  FactoryModel, 
  VehicleProgram, 
  ComponentPart, 
  SupplierModel, 
  SoftwareRelease,
  FinancialScenario,
  GraphNode,
  GraphEdge,
  AuditEvent
} from '../models/konzern-domain';

@Injectable({
  providedIn: 'root'
})
export class MockKonzernDataService {

  readonly kpiSummary: KonzernKpiSummary = {
    revenueBnEUR: 322.3,
    revenueGrowthPercent: 4.8,
    ebitBnEUR: 22.6,
    ebitMarginPercent: 7.0,
    freeCashflowBnEUR: 10.7,
    netLiquidityBnEUR: 41.2,
    vehicleDeliveriesMillions: 9.24,
    orderBankCount: 1140000,
    factoryCapacityUtilizationPercent: 88.4,
    evSharePercent: 18.5,
    batteryProductionGWh: 42.0,
    softwareReleasesCount: 124,
    supplyChainRiskIndex: 24,
    capexBnEUR: 14.8,
    rdExpenditureBnEUR: 18.9,
    co2AverageGramsPerKm: 98.4
  };

  readonly brands: BrandInfo[] = [
    {
      id: 'volkswagen',
      name: 'Volkswagen PKW',
      group: 'Core',
      headquarters: 'Wolfsburg, Deutschland',
      ceo: 'Thomas Schäfer',
      modelsCount: 28,
      revenueBnEUR: 88.5,
      ebitMarginPercent: 5.2,
      evSharePercent: 21.4,
      color: '#001E50'
    },
    {
      id: 'audi',
      name: 'Audi',
      group: 'Progressive',
      headquarters: 'Ingolstadt, Deutschland',
      ceo: 'Gernot Döllner',
      modelsCount: 22,
      revenueBnEUR: 69.8,
      ebitMarginPercent: 8.6,
      evSharePercent: 24.1,
      color: '#000000'
    },
    {
      id: 'porsche',
      name: 'Porsche',
      group: 'Sport Luxury',
      headquarters: 'Stuttgart-Zuffenhausen, Deutschland',
      ceo: 'Oliver Blume',
      modelsCount: 14,
      revenueBnEUR: 40.5,
      ebitMarginPercent: 17.8,
      evSharePercent: 32.8,
      color: '#800000'
    },
    {
      id: 'skoda',
      name: 'ŠKODA Auto',
      group: 'Core',
      headquarters: 'Mladá Boleslav, Tschechien',
      ceo: 'Klaus Zellmer',
      modelsCount: 12,
      revenueBnEUR: 26.5,
      ebitMarginPercent: 7.4,
      evSharePercent: 16.2,
      color: '#138038'
    },
    {
      id: 'cupra',
      name: 'CUPRA & SEAT',
      group: 'Core',
      headquarters: 'Martorell, Spanien',
      ceo: 'Wayne Griffiths',
      modelsCount: 9,
      revenueBnEUR: 14.2,
      ebitMarginPercent: 4.8,
      evSharePercent: 22.0,
      color: '#C76A28'
    },
    {
      id: 'vw-nutzfahrzeuge',
      name: 'VW Nutzfahrzeuge',
      group: 'Trucks & Mobility',
      headquarters: 'Hannover, Deutschland',
      ceo: 'Carsten Intra',
      modelsCount: 8,
      revenueBnEUR: 15.3,
      ebitMarginPercent: 6.1,
      evSharePercent: 19.8,
      color: '#1A365D'
    },
    {
      id: 'bentley',
      name: 'Bentley Motors',
      group: 'Sport Luxury',
      headquarters: 'Crewe, Vereinigtes Königreich',
      ceo: 'Frank-Steffen Walliser',
      modelsCount: 4,
      revenueBnEUR: 3.4,
      ebitMarginPercent: 20.1,
      evSharePercent: 14.0,
      color: '#004225'
    },
    {
      id: 'lamborghini',
      name: 'Automobili Lamborghini',
      group: 'Sport Luxury',
      headquarters: 'Sant\'Agata Bolognese, Italien',
      ceo: 'Stephan Winkelmann',
      modelsCount: 3,
      revenueBnEUR: 2.7,
      ebitMarginPercent: 27.2,
      evSharePercent: 100.0, // All hybrid/electric lineup 2026
      color: '#D4AF37'
    },
    {
      id: 'ducati',
      name: 'Ducati Motor Holding',
      group: 'Sport Luxury',
      headquarters: 'Bologna, Italien',
      ceo: 'Claudio Domenicali',
      modelsCount: 11,
      revenueBnEUR: 1.1,
      ebitMarginPercent: 10.5,
      evSharePercent: 8.5,
      color: '#CC0000'
    },
    {
      id: 'powerco',
      name: 'PowerCo SE (Battery OS)',
      group: 'Technology & Components',
      headquarters: 'Salzgitter, Deutschland',
      ceo: 'Thomas Schmall',
      modelsCount: 3,
      revenueBnEUR: 4.8,
      ebitMarginPercent: 6.8,
      evSharePercent: 100.0,
      color: '#00A86B'
    },
    {
      id: 'cariad',
      name: 'CARIAD SE (Software OS)',
      group: 'Technology & Components',
      headquarters: 'Wolfsburg, Deutschland',
      ceo: 'Peter Bosch',
      modelsCount: 5,
      revenueBnEUR: 3.2,
      ebitMarginPercent: 4.2,
      evSharePercent: 100.0,
      color: '#4A5568'
    }
  ];

  readonly factories: FactoryModel[] = [
    {
      id: 'FAC-WOB-01',
      name: 'Stammwerk Wolfsburg',
      location: 'Wolfsburg',
      country: 'Deutschland',
      region: 'Europa',
      brand: 'volkswagen',
      type: 'Fahrzeugwerk',
      employees: 60500,
      annualCapacityUnits: 800000,
      currentOutputRate: 2450,
      oeePercent: 86.4,
      availabilityPercent: 92.1,
      performancePercent: 95.2,
      qualityPercent: 98.5,
      status: 'OPTIMAL',
      energyConsumptionMWhDay: 1420,
      greenEnergyPercent: 89.5,
      activeLines: [
        {
          id: 'LINE-WOB-HALLE50',
          name: 'Montagelinie 1 (Halle 50 - ID.7 / Golf)',
          taktTimeSeconds: 54,
          targetOutputPerShift: 420,
          actualOutputPerShift: 412,
          stationsCount: 84,
          status: 'RUNNING',
          currentVehicleVin: 'WVWZZZ3CZRE902148',
          machines: [
            {
              id: 'MCH-WOB-42',
              name: 'Stanzpresse 42 (Schule 8000T)',
              type: 'Stanzpresse',
              healthScore: 94,
              temperatureCelsius: 68,
              vibrationMms: 1.8,
              status: 'OK',
              lastMaintenance: '2026-08-28'
            },
            {
              id: 'MCH-WOB-108',
              name: 'Kuka Schweißzelle B-Säule',
              type: 'Schweißroboter',
              healthScore: 98,
              temperatureCelsius: 42,
              vibrationMms: 0.6,
              status: 'OK',
              lastMaintenance: '2026-09-02'
            }
          ]
        }
      ]
    },
    {
      id: 'FAC-ZWI-02',
      name: 'Elektro-Werk Zwickau',
      location: 'Zwickau',
      country: 'Deutschland',
      region: 'Europa',
      brand: 'volkswagen',
      type: 'Fahrzeugwerk',
      employees: 10200,
      annualCapacityUnits: 330000,
      currentOutputRate: 1120,
      oeePercent: 91.2,
      availabilityPercent: 94.5,
      performancePercent: 97.0,
      qualityPercent: 99.1,
      status: 'OPTIMAL',
      energyConsumptionMWhDay: 840,
      greenEnergyPercent: 100.0,
      activeLines: []
    },
    {
      id: 'FAC-ING-03',
      name: 'Audi Werk Ingolstadt',
      location: 'Ingolstadt',
      country: 'Deutschland',
      region: 'Europa',
      brand: 'audi',
      type: 'Fahrzeugwerk',
      employees: 41000,
      annualCapacityUnits: 450000,
      currentOutputRate: 1480,
      oeePercent: 88.9,
      availabilityPercent: 93.0,
      performancePercent: 96.1,
      qualityPercent: 99.4,
      status: 'OPTIMAL',
      energyConsumptionMWhDay: 1100,
      greenEnergyPercent: 94.2,
      activeLines: []
    },
    {
      id: 'FAC-SAL-04',
      name: 'PowerCo Gigafactory Salzgitter',
      location: 'Salzgitter',
      country: 'Deutschland',
      region: 'Europa',
      brand: 'powerco',
      type: 'Zellfabrik',
      employees: 4500,
      annualCapacityUnits: 400000, // equivalent cell packs
      currentOutputRate: 1200,
      oeePercent: 84.5,
      availabilityPercent: 89.0,
      performancePercent: 96.0,
      qualityPercent: 99.0,
      status: 'OPTIMAL',
      energyConsumptionMWhDay: 2100,
      greenEnergyPercent: 98.0,
      activeLines: []
    },
    {
      id: 'FAC-CHA-05',
      name: 'Volkswagen Chattanooga Plant',
      location: 'Chattanooga, TN',
      country: 'USA',
      region: 'Nordamerika',
      brand: 'volkswagen',
      type: 'Fahrzeugwerk',
      employees: 4800,
      annualCapacityUnits: 250000,
      currentOutputRate: 780,
      oeePercent: 85.0,
      availabilityPercent: 90.0,
      performancePercent: 95.0,
      qualityPercent: 98.8,
      status: 'OPTIMAL',
      energyConsumptionMWhDay: 620,
      greenEnergyPercent: 85.0,
      activeLines: []
    },
    {
      id: 'FAC-SHA-06',
      name: 'SAIC-VW Gigafactory Anting',
      location: 'Shanghai',
      country: 'China',
      region: 'China',
      brand: 'volkswagen',
      type: 'Fahrzeugwerk',
      employees: 28000,
      annualCapacityUnits: 600000,
      currentOutputRate: 1950,
      oeePercent: 92.8,
      availabilityPercent: 96.0,
      performancePercent: 97.5,
      qualityPercent: 99.2,
      status: 'OPTIMAL',
      energyConsumptionMWhDay: 1350,
      greenEnergyPercent: 78.0,
      activeLines: []
    }
  ];

  readonly vehiclePrograms: VehicleProgram[] = [
    {
      id: 'VEH-ID7',
      name: 'Volkswagen ID.7 Pro S',
      brand: 'volkswagen',
      platform: 'MEB',
      powertrain: 'BEV',
      sopDate: '2024-03-15',
      priceStartEUR: 56990,
      batteryCapacitykWh: 86,
      rangeKm: 709,
      weightKg: 2172,
      softwareVersion: 'v12.4.1',
      status: 'PRODUKTION',
      bomItemsCount: 4820
    },
    {
      id: 'VEH-Q6',
      name: 'Audi Q6 e-tron quattro',
      brand: 'audi',
      platform: 'PPE',
      powertrain: 'BEV',
      sopDate: '2024-06-01',
      priceStartEUR: 74700,
      batteryCapacitykWh: 100,
      rangeKm: 625,
      weightKg: 2350,
      softwareVersion: 'v12.4.1',
      status: 'PRODUKTION',
      bomItemsCount: 5410
    },
    {
      id: 'VEH-MAC',
      name: 'Porsche Macan Turbo Electric',
      brand: 'porsche',
      platform: 'PPE',
      powertrain: 'BEV',
      sopDate: '2024-07-10',
      priceStartEUR: 114600,
      batteryCapacitykWh: 100,
      rangeKm: 591,
      weightKg: 2405,
      softwareVersion: 'v12.4.1',
      status: 'PRODUKTION',
      bomItemsCount: 6120
    },
    {
      id: 'VEH-ELR',
      name: 'ŠKODA Elroq 85',
      brand: 'skoda',
      platform: 'MEB',
      powertrain: 'BEV',
      sopDate: '2025-01-20',
      priceStartEUR: 33900,
      batteryCapacitykWh: 82,
      rangeKm: 560,
      weightKg: 1980,
      softwareVersion: 'v12.3.8',
      status: 'PRODUKTION',
      bomItemsCount: 4210
    },
    {
      id: 'VEH-BUZZ',
      name: 'VW ID. Buzz LWB GTX',
      brand: 'vw-nutzfahrzeuge',
      platform: 'MEB',
      powertrain: 'BEV',
      sopDate: '2024-09-01',
      priceStartEUR: 69900,
      batteryCapacitykWh: 91,
      rangeKm: 487,
      weightKg: 2580,
      softwareVersion: 'v12.4.1',
      status: 'PRODUKTION',
      bomItemsCount: 4980
    }
  ];

  readonly componentParts: ComponentPart[] = [
    {
      id: 'PART-BAT-86',
      partNumber: '1EA-915-104-D',
      name: 'PowerCo Unified Cell Pack 86kWh',
      category: 'Batterie',
      supplierId: 'SUP-PWR-01',
      supplierName: 'PowerCo Salzgitter SE',
      costEUR: 8400,
      weightKg: 495,
      cobaltContentKg: 4.2,
      lithiumContentKg: 7.8,
      leadTimeDays: 3,
      stockLevelUnits: 4850,
      reorderPointUnits: 2000,
      status: 'VERFÜGBAR'
    },
    {
      id: 'PART-INV-800V',
      partNumber: '8E0-907-555-K',
      name: 'Silicon Carbide (SiC) 800V Inverter',
      category: 'Inverter',
      supplierId: 'SUP-BOS-02',
      supplierName: 'Bosch Automotive Synthetic',
      costEUR: 1450,
      weightKg: 14.2,
      leadTimeDays: 7,
      stockLevelUnits: 1200,
      reorderPointUnits: 1500,
      status: 'VERFÜGBAR'
    },
    {
      id: 'PART-ECU-CARIAD',
      partNumber: '4N0-907-064-S',
      name: 'HPC High Performance Computer Domain Server',
      category: 'Steuergerät',
      supplierId: 'SUP-CAR-03',
      supplierName: 'CARIAD Embedded Platform',
      costEUR: 980,
      weightKg: 3.8,
      leadTimeDays: 5,
      stockLevelUnits: 6200,
      reorderPointUnits: 3000,
      status: 'VERFÜGBAR'
    },
    {
      id: 'PART-MOT-APP550',
      partNumber: '0EA-901-012-A',
      name: 'APP550 Permanent Magnet Synchronous Motor 210kW',
      category: 'Elektromotor',
      supplierId: 'SUP-VWK-04',
      supplierName: 'VW Komponentenwerk Kassel',
      costEUR: 2100,
      weightKg: 96.0,
      leadTimeDays: 2,
      stockLevelUnits: 3400,
      reorderPointUnits: 1800,
      status: 'VERFÜGBAR'
    }
  ];

  readonly suppliers: SupplierModel[] = [
    {
      id: 'SUP-PWR-01',
      name: 'PowerCo Salzgitter SE',
      country: 'Deutschland',
      city: 'Salzgitter',
      tier: 1,
      category: 'Batteriezellen & Packs',
      qualityScorePercent: 99.4,
      deliveryOnTimePercent: 98.8,
      riskIndex: 12,
      sustainabilityRating: 'A',
      capacityUtilizationPercent: 92,
      status: 'NORMAL',
      affectedPartsCount: 8
    },
    {
      id: 'SUP-BOS-02',
      name: 'Bosch Mobility Technologies',
      country: 'Deutschland',
      city: 'Stuttgart',
      tier: 1,
      category: 'Leistungselektronik & Sensoren',
      qualityScorePercent: 98.9,
      deliveryOnTimePercent: 97.5,
      riskIndex: 18,
      sustainabilityRating: 'A',
      capacityUtilizationPercent: 88,
      status: 'NORMAL',
      affectedPartsCount: 24
    },
    {
      id: 'SUP-CON-03',
      name: 'Continental Automotive',
      country: 'Deutschland',
      city: 'Hannover',
      tier: 1,
      category: 'Bremssysteme & Radar',
      qualityScorePercent: 97.8,
      deliveryOnTimePercent: 94.2,
      riskIndex: 28,
      sustainabilityRating: 'B',
      capacityUtilizationPercent: 95,
      status: 'NORMAL',
      affectedPartsCount: 16
    },
    {
      id: 'SUP-LGE-04',
      name: 'LG Energy Solution Poland',
      country: 'Polen',
      city: 'Wrocław',
      tier: 1,
      category: 'Lithium-Ionen Zellpakete',
      qualityScorePercent: 94.1,
      deliveryOnTimePercent: 88.0,
      riskIndex: 48,
      sustainabilityRating: 'B',
      capacityUtilizationPercent: 98,
      status: 'KAPAZITÄTSVERLUST', // Target for Demo 3
      affectedPartsCount: 12
    }
  ];

  readonly softwareReleases: SoftwareRelease[] = [
    {
      id: 'SW-12.4.1',
      version: 'v12.4.1',
      domain: 'Chassis & Battery OS',
      buildNumber: 'VW-OS-2026.38.2',
      releaseDate: '2026-09-01',
      status: 'ROLLOUT',
      targetVehiclesCount: 420000,
      installedCount: 284000,
      failureRatePercent: 0.12,
      changelog: [
        'Optimierte Vorkonditionierung für 800V Schnellladung',
        'Effizienzsteigerung Wärmepumpe (+4% Reichweite bei <0°C)',
        'CARIAD OS Patch v4.2 Sicherheitserweiterung'
      ]
    },
    {
      id: 'SW-12.4.0-FAIL',
      version: 'v12.4.0 (Incident #402)',
      domain: 'Infotainment',
      buildNumber: 'VW-OS-2026.37.9',
      releaseDate: '2026-08-15',
      status: 'ZURÜCKGEROLLT',
      targetVehiclesCount: 50000,
      installedCount: 12400,
      failureRatePercent: 4.85,
      changelog: [
        'Neuer Widget-Manager für Beifahrerdisplay',
        'Bluetooth 5.3 Low Energy Profil'
      ]
    }
  ];

  readonly scenarios: FinancialScenario[] = [
    {
      id: 'SCEN-EV-BOOM',
      name: 'Szenario A: Beschleunigte EV-Skalierung (+35% EV-Nachfrage)',
      description: 'Starke Verschiebung des Kundeninteresses hin zu reinen Elektrofahrzeugen (BEV) auf allen Hauptmärkten.',
      shockType: 'EV_BOOM',
      capexEffectBnEUR: 4.2,
      opexEffectBnEUR: 1.8,
      revenueEffectBnEUR: 18.5,
      ebitMarginDeltaPercent: +1.4,
      freeCashflowDeltaBnEUR: +3.8,
      npvBnEUR: 12.4,
      irrPercent: 19.5,
      paybackYears: 3.2
    },
    {
      id: 'SCEN-FLEX-DRIVE',
      name: 'Szenario B: Flexible Antriebsmatrix (ICE + PHEV + BEV Parallellauf)',
      description: 'Verlangsamter EV-Hochlauf bei gleichzeitiger Verlängerung hocheffizienter Mild- und Plug-in-Hybride.',
      shockType: 'EV_SLUMP',
      capexEffectBnEUR: 1.5,
      opexEffectBnEUR: 2.9,
      revenueEffectBnEUR: 8.2,
      ebitMarginDeltaPercent: +0.4,
      freeCashflowDeltaBnEUR: +1.2,
      npvBnEUR: 5.6,
      irrPercent: 14.1,
      paybackYears: 4.5
    }
  ];

  readonly graphNodes: GraphNode[] = [
    { id: 'root', label: 'VOLKSWAGEN KONZERN', type: 'KONZERN', metric: '322.3 Mrd. € Ums.' },
    { id: 'b-vw', label: 'Volkswagen PKW', type: 'MARKE', metric: 'Core Group' },
    { id: 'b-audi', label: 'Audi AG', type: 'MARKE', metric: 'Progressive' },
    { id: 'b-por', label: 'Porsche AG', type: 'MARKE', metric: 'Sport Luxury' },
    { id: 'b-pwr', label: 'PowerCo SE', type: 'MARKE', metric: 'Battery OS' },
    { id: 'f-wob', label: 'Werk Wolfsburg', type: 'FABRIK', metric: '800k Einheiten/J' },
    { id: 'f-ing', label: 'Werk Ingolstadt', type: 'FABRIK', metric: '450k Einheiten/J' },
    { id: 'f-sal', label: 'Gigafactory Salzgitter', type: 'FABRIK', metric: '40 GWh Zellkapaz.' },
    { id: 'v-id7', label: 'VW ID.7 Pro S', type: 'FAHRZEUG', metric: 'MEB Platform' },
    { id: 'v-q6', label: 'Audi Q6 e-tron', type: 'FAHRZEUG', metric: 'PPE Platform' },
    { id: 'p-bat', label: 'PowerCo Cell Pack 86kWh', type: 'KOMPONENTE', metric: '8.400 € / Einz.' },
    { id: 'p-inv', label: '800V SiC Inverter', type: 'KOMPONENTE', metric: 'Bosch Tech' },
    { id: 's-pwr', label: 'PowerCo SE Salzgitter', type: 'LIEFERANT', metric: 'Tier 1' },
    { id: 's-bos', label: 'Bosch Mobility', type: 'LIEFERANT', metric: 'Tier 1' },
    { id: 'sw-12', label: 'CARIAD OS v12.4.1', type: 'SOFTWARE', metric: '284k Ausgerollt' }
  ];

  readonly graphEdges: GraphEdge[] = [
    { source: 'root', target: 'b-vw', relation: 'EIGENTUM' },
    { source: 'root', target: 'b-audi', relation: 'EIGENTUM' },
    { source: 'root', target: 'b-por', relation: 'EIGENTUM' },
    { source: 'root', target: 'b-pwr', relation: 'EIGENTUM' },
    { source: 'b-vw', target: 'f-wob', relation: 'BETREIBT' },
    { source: 'b-audi', target: 'f-ing', relation: 'BETREIBT' },
    { source: 'b-pwr', target: 'f-sal', relation: 'BETREIBT' },
    { source: 'f-wob', target: 'v-id7', relation: 'PRODUZIERT' },
    { source: 'f-ing', target: 'v-q6', relation: 'PRODUZIERT' },
    { source: 'v-id7', target: 'p-bat', relation: 'ENTHÄLT' },
    { source: 'v-q6', target: 'p-inv', relation: 'ENTHÄLT' },
    { source: 's-pwr', target: 'p-bat', relation: 'LIEFERT' },
    { source: 's-bos', target: 'p-inv', relation: 'LIEFERT' },
    { source: 'sw-12', target: 'v-id7', relation: 'STEUERT' },
    { source: 'sw-12', target: 'v-q6', relation: 'STEUERT' }
  ];

  readonly auditEvents: AuditEvent[] = [
    {
      id: 'AUD-901',
      timestamp: '2026-09-15 08:30:12',
      actor: 'Oliver Blume (CEO)',
      role: 'VORSTAND',
      action: 'SZENARIO_FREIGABE',
      entityType: 'KAPITALALLOKATION',
      entityId: 'SCEN-EV-BOOM',
      details: 'Freigabe von 4.2 Mrd. € CAPEX für Werkserweiterung Salzgitter Gigafactory 2.',
      fourEyeStatus: 'GENEHMIGT'
    },
    {
      id: 'AUD-902',
      timestamp: '2026-09-15 09:14:05',
      actor: 'Peter Bosch (CARIAD CEO)',
      role: 'SOFTWARE',
      action: 'OTA_ROLLOUT_STOPP',
      entityType: 'SOFTWARE_RELEASE',
      entityId: 'SW-12.4.0-FAIL',
      details: 'Notfall-Stopp von Software Release v12.4.0 aufgrund von 4.85% Infotainment-Display-Flicker.',
      fourEyeStatus: 'GENEHMIGT'
    },
    {
      id: 'AUD-903',
      timestamp: '2026-09-15 10:02:44',
      actor: 'Thomas Schmall (Technik)',
      role: 'SUPPLY_CHAIN',
      action: 'LIEFERANTEN_REUMLEITUNG',
      entityType: 'SUPPLY_CHAIN',
      entityId: 'SUP-LGE-04',
      details: 'Kompensation von 30% Kapazitätsengpass LG Poland durch Hochlauf PowerCo Salzgitter.',
      fourEyeStatus: 'GENEHMIGT'
    }
  ];

}
