import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Lazy initialization for GoogleGenAI
let aiClient: GoogleGenAI | null = null;
function getGenAIClient(): GoogleGenAI | null {
  if (!aiClient && process.env['GEMINI_API_KEY']) {
    aiClient = new GoogleGenAI({
      apiKey: process.env['GEMINI_API_KEY'],
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// REST API Endpoints for Volkswagen Konzern OS

/**
 * AI Copilot Endpoint - Uses Gemini 3.8 Flash for authoritative Enterprise Answers
 */
app.post('/api/copilot', async (req, res) => {
  try {
    const { prompt, context } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt ist erforderlich.' });
    }

    const ai = getGenAIClient();
    if (ai) {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction: `Du bist VW GROUP AI, der autoritative KI-Copilot von VOLKSWAGEN KONZERN OS 2026.
Du antwortest präzise, professionell auf Deutsch im Ton deutscher Ingenieurskunst und Vorstands-Analytik.
Verwende exakte synthetische Daten und Zahlen des Volkswagen Konzerns (z.B. Umsatz 322,3 Mrd. €, EBIT-Marge 7,0%, Marken Core/Progressive/Sport Luxury/PowerCo/CARIAD, Werke Wolfsburg, Zwickau, Ingolstadt, Salzgitter).
Gib strukturierte Empfehlungen inklusive Evidenz, finanziellen Auswirkungen (OPEX/CAPEX) und operativer Umsetzung.
Kontextdaten: ${JSON.stringify(context || {})}`,
        },
      });

      return res.json({
        reply: response.text || 'Keine Antwort von KI erhalten.',
        source: 'GEMINI_3_8_FLASH',
        timestamp: new Date().toISOString()
      });
    } else {
      // Fallback synthetic response engine if GEMINI_API_KEY is not configured
      let fallbackText = `[VW GROUP AI - SYNTHETISCHE ANALYSE SERVERSIDE]\n\n`;
      const pLower = prompt.toLowerCase();
      
      if (pLower.includes('marge') || pLower.includes('ebit') || pLower.includes('cfo')) {
        fallbackText += `Analysierte EBIT-Marge (Q3 2026): 7,0% (Ziel: 8,0%).\n\nHaupttreiber der Abweichung (-1,0%-Punkte):\n1. Materialpreisaufschlag Batteriezellen (+420 Mio. € OPEX)\n2. Modellmix-Verschiebung hin zu Einstiegs-EVs (EV-Anteil 18,5%)\n3. CARIAD Software-Investitionen (+310 Mio. € F&E)\n\nEmpfohlene Gegenmaßnahmen:\n- Hochlauf PowerCo Einheitszelle Salzgitter (-12% Zellkosten ab Q4)\n- Kapazitätsoptimierung Halle 50 Wolfsburg (OEE +2.4%)`;
      } else if (pLower.includes('lieferant') || pLower.includes('krise') || pLower.includes('engpass')) {
        fallbackText += `Lieferketten-Risikoanalyse:\n- Lieferant LG Energy Solution Poland (Risiko-Index 48/100, Kapazitätsverlust 30%)\n- Betroffene Fahrzeugprogramme: VW ID.7 Pro, Audi Q6 e-tron\n- Vorhandene Sicherheitsbestände: 14 Produktionstage\n\nAutomatisierter Ausgleichsplan:\n1. Hochstufung Umleitung auf PowerCo Salzgitter SE (Re-Routing +1.200 Packs/Tag)\n2. Produktionsumstellung Zwickau auf Zweischicht-Puffer`;
      } else if (pLower.includes('fabrik') || pLower.includes('ausfall') || pLower.includes('wolfsburg')) {
        fallbackText += `Werk-Status Wolfsburg Stammwerk (OEE 86.4%):\n- Stanzpresse 42 (Halle 50) meldet optimalen Schwingungsindex (1.8 mm/s).\n- Taktzeit Montagelinie 1: 54 Sekunden.\n- Aktueller Tagesausstoß: 2.450 Fahrzeuge/Tag.\n- Grüner Energieanteil: 89.5%`;
      } else {
        fallbackText += `Systemanalyse für Ihre Anfrage "${prompt}":\nDas kanonische Digital-Thread-Modell des Volkswagen Konzerns bestätigt Kohärenz über alle 10 Marken und 100 Fabriken.\nAlle Datenpunkte sind mit dem Enterprise-Graphen verknüpft (Konzern → Marke → Werk → Fahrzeug → Komponente → Finanzen).`;
      }

      return res.json({
        reply: fallbackText,
        source: 'SYNTHETIC_RULE_ENGINE',
        timestamp: new Date().toISOString()
      });
    }
  } catch (err: unknown) {
    const details = err instanceof Error ? err.message : String(err);
    console.error('Error in /api/copilot:', err);
    return res.status(500).json({ error: 'Fehler bei der KI-Anfrage.', details });
  }
});

/**
 * Scenario Engine Endpoint
 */
app.post('/api/scenarios/run', (req, res) => {
  const { batteryCostEUR, evDemandGrowth, supplierRisk, electricityPrice } = req.body;
  
  const baseRevenue = 322.3;
  const baseEbitMargin = 7.0;
  
  // Calculate impacts
  const batteryDelta = (95 - (batteryCostEUR || 95)) * 0.12; // EUR bn savings
  const evDemandDelta = ((evDemandGrowth || 25) - 25) * 0.15; // EUR bn revenue change
  const energyCostDelta = ((electricityPrice || 110) - 110) * 0.03; // OPEX increase
  
  const projectedRevenue = Math.round((baseRevenue + evDemandDelta) * 10) / 10;
  const projectedEbitMargin = Math.round((baseEbitMargin + (batteryDelta / 10) - (energyCostDelta / 10)) * 10) / 10;
  const projectedCashflow = Math.round((10.7 + batteryDelta * 0.8) * 10) / 10;
  
  res.json({
    projectedRevenueBnEUR: projectedRevenue,
    projectedEbitMarginPercent: projectedEbitMargin,
    projectedFreeCashflowBnEUR: projectedCashflow,
    capexEffectBnEUR: Math.round((3.5 + (evDemandGrowth > 30 ? 1.5 : 0)) * 10) / 10,
    npvBnEUR: Math.round((14.2 + batteryDelta * 1.5) * 10) / 10,
    irrPercent: Math.round((18.5 + (batteryDelta * 0.5)) * 10) / 10,
    riskRating: supplierRisk > 50 ? 'HOCH' : supplierRisk > 30 ? 'MITTEL' : 'GERING',
    timestamp: new Date().toISOString()
  });
});

/**
 * Static file serving from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle Angular SSR rendering
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 3000;
  app.listen(port, () => {
    console.log(`Volkswagen Konzern OS Server running on port ${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
