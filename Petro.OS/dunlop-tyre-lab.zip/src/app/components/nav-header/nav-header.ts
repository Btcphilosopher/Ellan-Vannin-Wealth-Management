import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TyreLabService, ViewMode } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-nav-header',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-[#111313] border-b border-[#202424] text-[#EEECE5] sticky top-0 z-40 px-4 py-2.5 flex items-center justify-between gap-4">
      <!-- Zone 1: Brand Wordmark -->
      <div class="flex items-center gap-3 shrink-0">
        <div class="bg-[#D9B62F] text-[#111313] font-extrabold px-2 py-0.5 tracking-tighter text-sm flex items-center gap-1 font-mono">
          <span class="w-2 h-2 bg-[#111313]"></span>
          DUNLOP
        </div>
        <div class="flex flex-col">
          <span class="text-xs font-bold tracking-widest text-[#EEECE5] font-mono">TYRE LAB</span>
          <span class="text-[10px] text-[#858C8B] tracking-tight">DIGITAL TWIN R&D</span>
        </div>
      </div>

      <!-- Zone 2: Navigation Links / Views (Single-line) -->
      <nav class="hidden lg:flex items-center gap-1 overflow-x-auto no-scrollbar text-xs font-mono">
        @for (item of navItems; track item.mode) {
          <button
            (click)="labService.setView(item.mode)"
            class="px-2.5 py-1.5 transition-colors whitespace-nowrap flex items-center gap-1.5 border-b-2"
            [class.border-[#D9B62F]]="labService.currentView() === item.mode"
            [class.text-[#D9B62F]]="labService.currentView() === item.mode"
            [class.border-transparent]="labService.currentView() !== item.mode"
            [class.text-[#858C8B]]="labService.currentView() !== item.mode"
            [class.hover:text-[#EEECE5]]="labService.currentView() !== item.mode">
            <mat-icon class="text-base leading-none">{{ item.icon }}</mat-icon>
            <span>{{ item.label }}</span>
          </button>
        }
      </nav>

      <!-- Zone 3: Actions (Search ⌘K, Copilot, Project Status) -->
      <div class="flex items-center gap-2 shrink-0">
        <!-- Search Trigger -->
        <button
          (click)="labService.toggleCommandPalette()"
          class="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-[#191A19] border border-[#313636] text-[#858C8B] hover:text-[#EEECE5] hover:border-[#5F6666] text-xs font-mono transition-colors">
          <mat-icon class="text-sm">search</mat-icon>
          <span>SEARCH DATA</span>
          <kbd class="px-1.5 py-0.5 bg-[#111313] border border-[#313636] text-[10px] text-[#B8BCB8]">⌘K</kbd>
        </button>

        <!-- Dunlop Copilot AI Toggle -->
        <button
          (click)="labService.toggleCopilot()"
          class="px-3 py-1.5 bg-[#203B32] border border-[#315343] text-[#EEECE5] hover:bg-[#315343] text-xs font-mono transition-colors flex items-center gap-1.5">
          <mat-icon class="text-sm text-[#D9B62F]">smart_toy</mat-icon>
          <span class="hidden md:inline">COPILOT</span>
        </button>

        <!-- Project Badge -->
        <div class="hidden xl:flex items-center gap-2 bg-[#191A19] border border-[#202424] px-2.5 py-1 text-xs font-mono">
          <span class="w-1.5 h-1.5 bg-[#315343] animate-pulse"></span>
          <span class="text-[#858C8B]">PROJ:</span>
          <span class="text-[#D9B62F] font-bold">{{ labService.activeProject().code }}</span>
        </div>
      </div>
    </header>

    <!-- Mobile Sub-Nav Row -->
    <div class="lg:hidden flex items-center gap-1 bg-[#191A19] border-b border-[#202424] px-2 py-1.5 overflow-x-auto text-xs font-mono">
      @for (item of navItems; track item.mode) {
        <button
          (click)="labService.setView(item.mode)"
          class="px-2 py-1 whitespace-nowrap text-[11px] transition-colors shrink-0 flex items-center gap-1"
          [class.bg-[#294A5A]]="labService.currentView() === item.mode"
          [class.text-[#EEECE5]]="labService.currentView() === item.mode"
          [class.text-[#858C8B]]="labService.currentView() !== item.mode">
          <mat-icon class="text-xs">{{ item.icon }}</mat-icon>
          <span>{{ item.label }}</span>
        </button>
      }
    </div>
  `
})
export class NavHeader {
  readonly labService = inject(TyreLabService);

  readonly navItems: { mode: ViewMode; label: string; icon: string }[] = [
    { mode: 'lab', label: 'LAB', icon: 'precision_manufacturing' },
    { mode: 'designer', label: 'DESIGN', icon: 'aspect_ratio' },
    { mode: 'tread', label: 'TREAD', icon: 'texture' },
    { mode: 'compound', label: 'COMPOUND', icon: 'science' },
    { mode: 'structure', label: 'STRUCTURE', icon: 'layers' },
    { mode: 'simulation', label: 'SIMULATION', icon: 'grid_on' },
    { mode: 'vehicle', label: 'VEHICLE', icon: 'directions_car' },
    { mode: 'test', label: 'TEST LAB', icon: 'speed' },
    { mode: 'wear', label: 'WEAR TWIN', icon: 'tire_repair' },
    { mode: 'factory', label: 'FACTORY', icon: 'factory' },
    { mode: 'quality', label: 'QUALITY', icon: 'verified' },
    { mode: 'passport', label: 'PASSPORT', icon: 'qr_code_2' },
    { mode: 'comparison', label: 'COMPARE', icon: 'compare_arrows' },
    { mode: 'drawing', label: 'DRAWING', icon: 'architecture' },
    { mode: 'notebook', label: 'NOTEBOOK', icon: 'menu_book' }
  ];
}
