import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  inject, 
  OnInit, 
  ViewChild, 
  effect 
} from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-contact-patch-canvas',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-[#191A19] border border-[#202424] p-4 font-mono text-[#EEECE5] space-y-4">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-[#202424] pb-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-[#D9B62F]">grid_on</mat-icon>
          <div>
            <div class="font-bold text-xs uppercase tracking-wider">CONTACT PATCH PRESSURE DISTRIBUTION</div>
            <div class="text-[10px] text-[#858C8B]">DEFORMABLE FOOTPRINT & SHEAR VECTOR TWIN</div>
          </div>
        </div>
        <div class="text-right">
          <div class="text-xs font-bold text-[#D9B62F]">{{ sim().contactPatchAreaCm2 }} cm²</div>
          <div class="text-[10px] text-[#858C8B]">PEAK: {{ sim().peakPressureMpa }} MPa</div>
        </div>
      </div>

      <!-- Main Footprint Canvas -->
      <div class="relative flex items-center justify-center bg-[#111313] border border-[#313636] p-4 min-h-[260px]">
        <canvas #heatmapCanvas width="320" height="240" class="border border-[#202424] shadow-inner"></canvas>

        <!-- Dynamic Force Vector Badge Overlay -->
        <div class="absolute top-2 right-2 bg-[#191A19]/90 border border-[#313636] p-2 text-[10px] space-y-1">
          <div class="text-[#858C8B]">LONGITUDINAL FORCE: <span class="text-[#EEECE5] font-bold">{{ sim().longitudinalGripForceN }} N</span></div>
          <div class="text-[#858C8B]">LATERAL CORNERING: <span class="text-[#EEECE5] font-bold">{{ sim().lateralGripForceN }} N</span></div>
          <div class="text-[#858C8B]">FRICTION COEFF (μ): <span class="text-[#315343] font-bold">{{ sim().frictionCoeffMu }}</span></div>
        </div>

        <!-- Heatmap Color Scale Legend -->
        <div class="absolute bottom-2 left-2 flex items-center gap-1.5 text-[9px] text-[#858C8B]">
          <span>0.1 MPa</span>
          <div class="w-20 h-2 bg-gradient-to-r from-blue-600 via-green-500 via-yellow-400 to-red-600 border border-[#313636]"></div>
          <span>1.2 MPa</span>
        </div>
      </div>

      <!-- Interactive Parameter Sliders -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2 border-t border-[#202424] text-xs">
        <!-- Load -->
        <div class="space-y-1">
          <div class="flex justify-between text-[11px]">
            <span class="text-[#858C8B]">RADIAL LOAD:</span>
            <span class="font-bold text-[#D9B62F]">{{ sim().loadKg }} kg</span>
          </div>
          <input
            type="range"
            min="300"
            max="1100"
            step="10"
            [value]="sim().loadKg"
            (input)="onParamChange('loadKg', $event)"
            class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
        </div>

        <!-- Inflation Pressure -->
        <div class="space-y-1">
          <div class="flex justify-between text-[11px]">
            <span class="text-[#858C8B]">INFLATION PRESS:</span>
            <span class="font-bold text-[#D9B62F]">{{ sim().pressureBar }} bar</span>
          </div>
          <input
            type="range"
            min="1.5"
            max="3.5"
            step="0.05"
            [value]="sim().pressureBar"
            (input)="onParamChange('pressureBar', $event)"
            class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
        </div>

        <!-- Camber Angle -->
        <div class="space-y-1">
          <div class="flex justify-between text-[11px]">
            <span class="text-[#858C8B]">CAMBER ANGLE:</span>
            <span class="font-bold text-[#D9B62F]">{{ sim().camberDeg }}°</span>
          </div>
          <input
            type="range"
            min="-4.0"
            max="2.0"
            step="0.1"
            [value]="sim().camberDeg"
            (input)="onParamChange('camberDeg', $event)"
            class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
        </div>

        <!-- Slip Angle -->
        <div class="space-y-1">
          <div class="flex justify-between text-[11px]">
            <span class="text-[#858C8B]">SLIP ANGLE:</span>
            <span class="font-bold text-[#D9B62F]">{{ sim().slipAngleDeg }}°</span>
          </div>
          <input
            type="range"
            min="0"
            max="10.0"
            step="0.1"
            [value]="sim().slipAngleDeg"
            (input)="onParamChange('slipAngleDeg', $event)"
            class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
        </div>
      </div>
    </div>
  `
})
export class ContactPatchCanvas implements OnInit {
  @ViewChild('heatmapCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  readonly labService = inject(TyreLabService);

  get sim() {
    return () => this.labService.activeProject().simulation;
  }

  constructor() {
    effect(() => {
      // Re-draw footprint whenever simulation state updates
      const metrics = this.labService.activeProject().simulation;
      if (this.canvasRef) {
        this.drawHeatmap(metrics);
      }
    });
  }

  ngOnInit() {
    this.drawHeatmap(this.labService.activeProject().simulation);
  }

  onParamChange(paramName: string, event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.labService.updateSimulationParams({ [paramName]: val });
  }

  private drawHeatmap(sim: any) {
    const canvas = this.canvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Background Grid
    ctx.strokeStyle = '#202424';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 20) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 20) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Footprint Geometry Calculations
    const centerX = canvas.width / 2 + sim.camberDeg * 8; // Offset by camber
    const centerY = canvas.height / 2;

    // Radius scaling proportional to load and inverse pressure
    const radiusX = Math.min(120, Math.max(40, (sim.loadKg / 650) * 80));
    const radiusY = Math.min(100, Math.max(30, (sim.loadKg / 650) * (2.4 / sim.pressureBar) * 60));

    // Radial Pressure Gradient
    const gradient = ctx.createRadialGradient(
      centerX - sim.slipAngleDeg * 3, 
      centerY, 
      10, 
      centerX, 
      centerY, 
      radiusX
    );

    gradient.addColorStop(0, '#dc2626'); // Peak red center
    gradient.addColorStop(0.3, '#f59e0b'); // Yellow
    gradient.addColorStop(0.6, '#10b981'); // Green
    gradient.addColorStop(0.9, '#2563eb'); // Blue outer ring
    gradient.addColorStop(1, 'rgba(17, 19, 19, 0)'); // Fade out

    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate((sim.slipAngleDeg * Math.PI) / 180);

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.ellipse(0, 0, radiusX, radiusY, 0, 0, 2 * Math.PI);
    ctx.fill();

    // Tread Blocks Pattern Lines Overlay
    ctx.strokeStyle = 'rgba(17, 19, 19, 0.4)';
    ctx.lineWidth = 3;
    for (let x = -radiusX + 15; x < radiusX; x += 25) {
      ctx.beginPath();
      ctx.moveTo(x, -radiusY);
      ctx.lineTo(x, radiusY);
      ctx.stroke();
    }

    // Shear Force Vector Arrow
    ctx.restore();
    ctx.strokeStyle = '#D9B62F';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    const arrowX = centerX + sim.slipAngleDeg * 8;
    const arrowY = centerY - (sim.longitudinalGripForceN / 100);
    ctx.lineTo(arrowX, arrowY);
    ctx.stroke();

    // Arrow Head
    ctx.fillStyle = '#D9B62F';
    ctx.beginPath();
    ctx.arc(arrowX, arrowY, 4, 0, Math.PI * 2);
    ctx.fill();
  }
}
