import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  inject, 
  OnDestroy, 
  OnInit, 
  ViewChild,
  signal,
  effect
} from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';

@Component({
  selector: 'app-3d-tyre-viewport',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-[450px] lg:h-[550px] bg-[#111313] border border-[#202424] overflow-hidden font-mono select-none">
      <!-- WebGL Canvas Container -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Viewport Overlay Controls (Top Left) -->
      <div class="absolute top-3 left-3 bg-[#191A19]/90 border border-[#313636] p-2.5 backdrop-blur-xs text-xs space-y-2 max-w-xs">
        <div class="flex items-center justify-between text-[10px] text-[#858C8B] border-b border-[#202424] pb-1">
          <span>3D DIGITAL TWIN VIEWPORT</span>
          <span class="text-[#D9B62F] font-bold">REALTIME WebGL</span>
        </div>

        <div class="grid grid-cols-2 gap-1 text-[11px]">
          <button
            (click)="setPreset('PERSPECTIVE')"
            class="px-2 py-1 border text-left transition-colors"
            [class.bg-[#315343]]="cameraPreset() === 'PERSPECTIVE'"
            [class.border-[#315343]]="cameraPreset() === 'PERSPECTIVE'"
            [class.text-[#EEECE5]]="cameraPreset() === 'PERSPECTIVE'"
            [class.border-[#202424]]="cameraPreset() !== 'PERSPECTIVE'"
            [class.text-[#858C8B]]="cameraPreset() !== 'PERSPECTIVE'">
            Perspective
          </button>
          <button
            (click)="setPreset('SECTION_CUT')"
            class="px-2 py-1 border text-left transition-colors"
            [class.bg-[#315343]]="cameraPreset() === 'SECTION_CUT'"
            [class.border-[#315343]]="cameraPreset() === 'SECTION_CUT'"
            [class.text-[#EEECE5]]="cameraPreset() === 'SECTION_CUT'"
            [class.border-[#202424]]="cameraPreset() !== 'SECTION_CUT'"
            [class.text-[#858C8B]]="cameraPreset() !== 'SECTION_CUT'">
            Section Cut
          </button>
          <button
            (click)="setPreset('CONTACT_PATCH')"
            class="px-2 py-1 border text-left transition-colors"
            [class.bg-[#315343]]="cameraPreset() === 'CONTACT_PATCH'"
            [class.border-[#315343]]="cameraPreset() === 'CONTACT_PATCH'"
            [class.text-[#EEECE5]]="cameraPreset() === 'CONTACT_PATCH'"
            [class.border-[#202424]]="cameraPreset() !== 'CONTACT_PATCH'"
            [class.text-[#858C8B]]="cameraPreset() !== 'CONTACT_PATCH'">
            Contact Patch
          </button>
          <button
            (click)="setPreset('EXPLODED')"
            class="px-2 py-1 border text-left transition-colors"
            [class.bg-[#315343]]="cameraPreset() === 'EXPLODED'"
            [class.border-[#315343]]="cameraPreset() === 'EXPLODED'"
            [class.text-[#EEECE5]]="cameraPreset() === 'EXPLODED'"
            [class.border-[#202424]]="cameraPreset() !== 'EXPLODED'"
            [class.text-[#858C8B]]="cameraPreset() !== 'EXPLODED'">
            Exploded View
          </button>
        </div>

        <!-- Overlays Toggle Buttons -->
        <div class="pt-1 border-t border-[#202424] flex flex-wrap gap-1 text-[10px]">
          <button
            (click)="toggleOverlay('stress')"
            class="px-1.5 py-0.5 border"
            [class.bg-[#A8443D]]="showStress()"
            [class.text-[#EEECE5]]="showStress()"
            [class.border-[#202424]]="!showStress()"
            [class.text-[#858C8B]]="!showStress()">
            STRESS MAP
          </button>
          <button
            (click)="toggleOverlay('wireframe')"
            class="px-1.5 py-0.5 border"
            [class.bg-[#294A5A]]="showWireframe()"
            [class.text-[#EEECE5]]="showWireframe()"
            [class.border-[#202424]]="!showWireframe()"
            [class.text-[#858C8B]]="!showWireframe()">
            MESH WIREFRAME
          </button>
          <button
            (click)="toggleOverlay('rotation')"
            class="px-1.5 py-0.5 border"
            [class.bg-[#315343]]="isRotating()"
            [class.text-[#EEECE5]]="isRotating()"
            [class.border-[#202424]]="!isRotating()"
            [class.text-[#858C8B]]="!isRotating()">
            ROTATE
          </button>
        </div>
      </div>

      <!-- Telemetry Watermark (Bottom Right) -->
      <div class="absolute bottom-3 right-3 bg-[#191A19]/90 border border-[#313636] p-2 text-[10px] text-[#858C8B] font-mono space-y-0.5 pointer-events-none">
        <div>MODEL: <span class="text-[#EEECE5] font-bold">{{ labService.activeProject().code }}</span></div>
        <div>DIM: <span class="text-[#D9B62F]">{{ labService.activeProject().geometry.sectionWidth }}/{{ labService.activeProject().geometry.aspectRatio }} R{{ labService.activeProject().geometry.rimDiameter }}</span></div>
        <div>PRESS: <span class="text-[#EEECE5]">{{ labService.activeProject().geometry.targetPressure }} BAR</span></div>
        <div>GRIP μ: <span class="text-[#315343] font-bold">{{ labService.activeProject().simulation.frictionCoeffMu }}</span></div>
      </div>
    </div>
  `
})
export class ThreeTyreViewport implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  readonly labService = inject(TyreLabService);

  readonly cameraPreset = signal<'PERSPECTIVE' | 'SECTION_CUT' | 'CONTACT_PATCH' | 'EXPLODED'>('PERSPECTIVE');
  readonly showStress = signal<boolean>(false);
  readonly showWireframe = signal<boolean>(false);
  readonly isRotating = signal<boolean>(true);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number = 0;

  private tyreGroup!: THREE.Group;
  private treadMesh!: THREE.Mesh;
  private sidewallMesh!: THREE.Mesh;
  private rimMesh!: THREE.Mesh;
  private beltMesh!: THREE.Mesh;
  private wireframeMesh!: THREE.LineSegments;

  private isDragging = false;
  private previousMousePosition = { x: 0, y: 0 };

  constructor() {
    // React to signal changes in project geometry or replay
    effect(() => {
      const geo = this.labService.activeProject().geometry;
      if (this.tyreGroup) {
        this.updateMeshGeometry(geo);
      }
    });
  }

  ngOnInit() {
    this.initThree();
    this.createTyreMesh();
    this.setupEventListeners();
    this.animate();
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 600;
    const height = container.clientHeight || 500;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x111313);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(0, 2, 5);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    container.appendChild(this.renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xfff5ea, 1.2);
    dirLight1.position.set(5, 8, 5);
    this.scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xd9b62f, 0.5); // Dunlop yellow accent fill
    dirLight2.position.set(-5, -2, -5);
    this.scene.add(dirLight2);

    // Floor Grid
    const grid = new THREE.GridHelper(10, 20, 0x315343, 0x202424);
    grid.position.y = -1.5;
    this.scene.add(grid);
  }

  private createTyreMesh() {
    this.tyreGroup = new THREE.Group();

    // Rubber Material
    const rubberMaterial = new THREE.MeshStandardMaterial({
      color: 0x191A19,
      roughness: 0.85,
      metalness: 0.1
    });

    // Dunlop Yellow Accent Rim / Steel Material
    const steelMaterial = new THREE.MeshStandardMaterial({
      color: 0x858C8B,
      roughness: 0.3,
      metalness: 0.8
    });

    const beltMaterial = new THREE.MeshStandardMaterial({
      color: 0xD9B62F,
      roughness: 0.4,
      wireframe: true
    });

    // 1. Tyre Outer Rubber Torus
    const geo = this.labService.activeProject().geometry;
    const outerRadius = 1.2;
    const tubeRadius = (geo.sectionWidth / 305) * 0.45;

    const torusGeo = new THREE.TorusGeometry(outerRadius, tubeRadius, 32, 64);
    this.treadMesh = new THREE.Mesh(torusGeo, rubberMaterial);
    this.tyreGroup.add(this.treadMesh);

    // 2. Wheel Rim Disc
    const rimGeo = new THREE.CylinderGeometry(outerRadius - tubeRadius + 0.05, outerRadius - tubeRadius + 0.05, 0.5, 32);
    this.rimMesh = new THREE.Mesh(rimGeo, steelMaterial);
    this.rimMesh.rotation.x = Math.PI / 2;
    this.tyreGroup.add(this.rimMesh);

    // 3. Steel Belt Mesh (Inner)
    const beltGeo = new THREE.TorusGeometry(outerRadius, tubeRadius * 0.82, 16, 32);
    this.beltMesh = new THREE.Mesh(beltGeo, beltMaterial);
    this.beltMesh.visible = false;
    this.tyreGroup.add(this.beltMesh);

    // 4. Wireframe Overlay
    const wireframeGeo = new THREE.WireframeGeometry(torusGeo);
    const wireframeMat = new THREE.LineBasicMaterial({ color: 0x4A7287, transparent: true, opacity: 0.4 });
    this.wireframeMesh = new THREE.LineSegments(wireframeGeo, wireframeMat);
    this.wireframeMesh.visible = false;
    this.tyreGroup.add(this.wireframeMesh);

    this.scene.add(this.tyreGroup);
  }

  private updateMeshGeometry(geo: any) {
    if (!this.treadMesh) return;
    const outerRadius = 1.2;
    const tubeRadius = (geo.sectionWidth / 305) * 0.45;
    
    // Scale mesh proportional to parameters
    this.tyreGroup.scale.set(1, (geo.overallDiameter / 676), (geo.overallDiameter / 676));
  }

  private animate = () => {
    this.animationFrameId = requestAnimationFrame(this.animate);

    if (this.isRotating() && this.cameraPreset() === 'PERSPECTIVE') {
      this.tyreGroup.rotation.y += 0.008;
    }

    this.renderer.render(this.scene, this.camera);
  };

  private setupEventListeners() {
    const container = this.canvasContainer.nativeElement;

    container.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    container.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const deltaX = e.clientX - this.previousMousePosition.x;
      const deltaY = e.clientY - this.previousMousePosition.y;

      this.tyreGroup.rotation.y += deltaX * 0.01;
      this.tyreGroup.rotation.x += deltaY * 0.01;

      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('resize', () => {
      if (!container) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      this.camera.aspect = width / height;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(width, height);
    });
  }

  setPreset(preset: 'PERSPECTIVE' | 'SECTION_CUT' | 'CONTACT_PATCH' | 'EXPLODED') {
    this.cameraPreset.set(preset);
    if (preset === 'PERSPECTIVE') {
      this.camera.position.set(0, 2, 5);
      this.tyreGroup.position.set(0, 0, 0);
      this.beltMesh.visible = false;
    } else if (preset === 'SECTION_CUT') {
      this.camera.position.set(0, 0, 3.5);
      this.tyreGroup.position.set(0, 0, 0);
      this.tyreGroup.rotation.set(0, Math.PI / 4, 0);
      this.beltMesh.visible = true;
    } else if (preset === 'CONTACT_PATCH') {
      this.camera.position.set(0, -3.2, 0.5);
      this.camera.lookAt(0, 0, 0);
      this.tyreGroup.rotation.set(-Math.PI / 2, 0, 0);
    } else if (preset === 'EXPLODED') {
      this.camera.position.set(2, 3, 4);
      this.camera.lookAt(0, 0, 0);
      this.beltMesh.visible = true;
      this.beltMesh.scale.set(1.2, 1.2, 1.2);
    }
  }

  toggleOverlay(type: 'stress' | 'wireframe' | 'rotation') {
    if (type === 'stress') {
      this.showStress.update(v => !v);
      const mat = this.treadMesh.material as THREE.MeshStandardMaterial;
      mat.color.setHex(this.showStress() ? 0xA8443D : 0x191A19);
    } else if (type === 'wireframe') {
      this.showWireframe.update(v => !v);
      this.wireframeMesh.visible = this.showWireframe();
    } else if (type === 'rotation') {
      this.isRotating.update(v => !v);
    }
  }
}
