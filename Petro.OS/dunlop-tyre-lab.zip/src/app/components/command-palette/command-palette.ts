import { ChangeDetectionStrategy, Component, inject, HostListener } from '@angular/core';
import { TyreLabService, ViewMode } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormControl } from '@angular/forms';

@Component({
  selector: 'app-command-palette',
  imports: [MatIconModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (labService.isCommandPaletteOpen()) {
      <div class="fixed inset-0 z-50 bg-[#111313]/80 backdrop-blur-xs flex items-start justify-center pt-20 p-4">
        <div class="bg-[#191A19] border border-[#313636] w-full max-w-2xl shadow-2xl overflow-hidden font-mono text-[#EEECE5]">
          <!-- Input Bar -->
          <div class="flex items-center px-4 py-3 border-b border-[#202424] gap-3">
            <mat-icon class="text-[#D9B62F]">search</mat-icon>
            <input
              [formControl]="queryControl"
              type="text"
              placeholder="SEARCH ENGINEERING DATA (Tyres, Compounds, Factory, Tests, Passports...)"
              class="bg-transparent border-none outline-hidden text-sm w-full text-[#EEECE5] placeholder-[#5F6666]"
              autofocus />
            <button (click)="labService.toggleCommandPalette()" class="text-[#858C8B] hover:text-[#EEECE5]">
              <mat-icon>close</mat-icon>
            </button>
          </div>

          <!-- Quick Navigation Shortcuts -->
          <div class="p-4 max-h-96 overflow-y-auto space-y-4">
            <div>
              <div class="text-[10px] text-[#5F6666] tracking-wider uppercase mb-2">Modules & Workstations</div>
              <div class="grid grid-cols-2 gap-2 text-xs">
                @for (item of modules; track item.mode) {
                  <button
                    (click)="navigateTo(item.mode)"
                    class="p-2 bg-[#111313] hover:bg-[#203B32] border border-[#202424] hover:border-[#315343] text-left transition-colors flex items-center gap-2">
                    <mat-icon class="text-sm text-[#D9B62F]">{{ item.icon }}</mat-icon>
                    <div>
                      <div class="font-bold text-[#EEECE5]">{{ item.title }}</div>
                      <div class="text-[10px] text-[#858C8B] truncate">{{ item.desc }}</div>
                    </div>
                  </button>
                }
              </div>
            </div>

            <!-- Active Records Quick Access -->
            <div>
              <div class="text-[10px] text-[#5F6666] tracking-wider uppercase mb-2">Active Engineering Assets</div>
              <div class="space-y-1.5 text-xs">
                <button (click)="navigateTo('designer')" class="w-full text-left p-2 bg-[#111313] border border-[#202424] hover:border-[#D9B62F] flex items-center justify-between">
                  <span class="text-[#EEECE5]">TYRE PROJECT: {{ labService.activeProject().code }}</span>
                  <span class="text-[#858C8B] text-[10px]">305/30 R20 103Y</span>
                </button>
                <button (click)="navigateTo('compound')" class="w-full text-left p-2 bg-[#111313] border border-[#202424] hover:border-[#D9B62F] flex items-center justify-between">
                  <span class="text-[#EEECE5]">COMPOUND: {{ labService.activeProject().compound.code }}</span>
                  <span class="text-[#315343] font-bold text-[10px]">Silica Matrix</span>
                </button>
                <button (click)="navigateTo('passport')" class="w-full text-left p-2 bg-[#111313] border border-[#202424] hover:border-[#D9B62F] flex items-center justify-between">
                  <span class="text-[#EEECE5]">PASSPORT: DNL-2026-004281</span>
                  <span class="text-[#315343] font-bold text-[10px]">VERIFIED PASS</span>
                </button>
              </div>
            </div>
          </div>

          <!-- Footer -->
          <div class="p-3 bg-[#111313] border-t border-[#202424] text-[10px] text-[#858C8B] flex items-center justify-between">
            <span>Press ESC or click outside to dismiss</span>
            <span>DUNLOP TYRE LAB SYSTEM v2026.4</span>
          </div>
        </div>
      </div>
    }
  `
})
export class CommandPalette {
  readonly labService = inject(TyreLabService);
  readonly queryControl = new FormControl('');

  readonly modules: { mode: ViewMode; title: string; desc: string; icon: string }[] = [
    { mode: 'lab', title: 'Engineering Lab', desc: 'Main 3D tyre workstation & R&D dashboard', icon: 'precision_manufacturing' },
    { mode: 'designer', title: 'Parametric Designer', desc: 'Apect ratio, section width, rim size', icon: 'aspect_ratio' },
    { mode: 'tread', title: 'Tread Laboratory', desc: 'Groove channels, void ratio, hydroplaning', icon: 'texture' },
    { mode: 'compound', title: 'Compound Twin', desc: 'Silica/carbon black, DMA Tan Delta curves', icon: 'science' },
    { mode: 'structure', title: '3D Layer Exploder', desc: 'Steel belts, Rayon carcass, inner liner', icon: 'layers' },
    { mode: 'simulation', title: 'Contact Patch', desc: '2D/3D pressure heatmap & shear force', icon: 'grid_on' },
    { mode: 'vehicle', title: 'Vehicle Dynamics', desc: 'GT car braking, cornering g-force', icon: 'directions_car' },
    { mode: 'factory', title: 'Factory Digital Twin', desc: 'Banbury mixers, Extruders, Curing presses', icon: 'factory' }
  ];

  @HostListener('window:keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.labService.toggleCommandPalette();
    } else if (event.key === 'Escape' && this.labService.isCommandPaletteOpen()) {
      this.labService.toggleCommandPalette();
    }
  }

  navigateTo(mode: ViewMode) {
    this.labService.setView(mode);
    this.labService.isCommandPaletteOpen.set(false);
  }
}
