import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { CopilotService } from '../../services/copilot.service';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormControl } from '@angular/forms';

@Component({
  selector: 'app-copilot-drawer',
  imports: [MatIconModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (labService.isCopilotOpen()) {
      <div class="fixed inset-y-0 right-0 z-50 w-full sm:w-96 bg-[#191A19] border-l border-[#313636] shadow-2xl flex flex-col font-mono text-[#EEECE5]">
        <!-- Header -->
        <div class="p-4 bg-[#111313] border-b border-[#202424] flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-[#D9B62F]">smart_toy</mat-icon>
            <div>
              <div class="font-bold text-xs">DUNLOP COPILOT</div>
              <div class="text-[10px] text-[#858C8B]">BRITISH R&D ASSISTANT</div>
            </div>
          </div>
          <button (click)="labService.toggleCopilot()" class="text-[#858C8B] hover:text-[#EEECE5]">
            <mat-icon>close</mat-icon>
          </button>
        </div>

        <!-- Quick Prompts Bar -->
        <div class="p-2 bg-[#111313] border-b border-[#202424] overflow-x-auto whitespace-nowrap flex gap-1.5 text-[10px]">
          <button (click)="askQuick('Compare tread 18 and tread 19 wet drainage.')" class="px-2 py-1 bg-[#191A19] border border-[#313636] hover:border-[#D9B62F] text-[#858C8B] hover:text-[#EEECE5]">
            Tread Evacuation
          </button>
          <button (click)="askQuick('Explain contact patch pressure distribution under 650kg load.')" class="px-2 py-1 bg-[#191A19] border border-[#313636] hover:border-[#D9B62F] text-[#858C8B] hover:text-[#EEECE5]">
            Footprint Mechanics
          </button>
          <button (click)="askQuick('Show compound DL-RB-047 silica hysteresis Tan Delta peak.')" class="px-2 py-1 bg-[#191A19] border border-[#313636] hover:border-[#D9B62F] text-[#858C8B] hover:text-[#EEECE5]">
            Silica Hysteresis
          </button>
        </div>

        <!-- Messages Area -->
        <div class="flex-1 p-4 overflow-y-auto space-y-4 text-xs">
          @for (msg of copilotService.messages(); track msg.id) {
            <div
              class="flex flex-col gap-1"
              [class.items-end]="msg.sender === 'user'"
              [class.items-start]="msg.sender === 'copilot'">
              
              <div class="flex items-center gap-1.5 text-[10px] text-[#5F6666]">
                <span>{{ msg.sender === 'user' ? 'ENGINEER' : 'DUNLOP COPILOT' }}</span>
                <span>·</span>
                <span>{{ msg.timestamp }}</span>
                @if (msg.sourceType) {
                  <span class="px-1 py-0.2 text-[9px] border"
                    [class.border-[#315343]]="msg.sourceType === 'OBSERVED DATA'"
                    [class.text-[#315343]]="msg.sourceType === 'OBSERVED DATA'"
                    [class.border-[#4A7287]]="msg.sourceType === 'SIMULATED RESULT'"
                    [class.text-[#4A7287]]="msg.sourceType === 'SIMULATED RESULT'"
                    [class.border-[#C18B35]]="msg.sourceType === 'ENGINEERING ASSUMPTION'"
                    [class.text-[#C18B35]]="msg.sourceType === 'ENGINEERING ASSUMPTION'">
                    {{ msg.sourceType }}
                  </span>
                }
              </div>

              <div
                class="p-3 max-w-[90%] leading-relaxed"
                [class.bg-[#294A5A]]="msg.sender === 'user'"
                [class.text-[#EEECE5]]="msg.sender === 'user'"
                [class.bg-[#111313]]="msg.sender === 'copilot'"
                [class.border]="msg.sender === 'copilot'"
                [class.border-[#202424]]="msg.sender === 'copilot'">
                {{ msg.text }}
              </div>
            </div>
          }

          @if (copilotService.isLoading()) {
            <div class="flex items-center gap-2 text-[#D9B62F] text-xs">
              <mat-icon class="animate-spin text-sm">sync</mat-icon>
              <span>Querying synthetic R&D database & computational model...</span>
            </div>
          }
        </div>

        <!-- Input Bar -->
        <div class="p-3 bg-[#111313] border-t border-[#202424] flex items-center gap-2">
          <input
            [formControl]="inputControl"
            (keydown.enter)="send()"
            type="text"
            placeholder="Ask engineering copilot..."
            class="flex-1 bg-[#191A19] border border-[#313636] px-3 py-2 text-xs text-[#EEECE5] placeholder-[#5F6666] outline-hidden focus:border-[#D9B62F]" />
          <button
            (click)="send()"
            class="p-2 bg-[#D9B62F] text-[#111313] hover:bg-[#b89a24] transition-colors flex items-center justify-center font-bold">
            <mat-icon class="text-sm">send</mat-icon>
          </button>
        </div>
      </div>
    }
  `
})
export class CopilotDrawer {
  readonly labService = inject(TyreLabService);
  readonly copilotService = inject(CopilotService);
  readonly inputControl = new FormControl('');

  send() {
    const val = this.inputControl.value;
    if (val && val.trim()) {
      this.copilotService.sendMessage(val, this.labService.activeProject());
      this.inputControl.setValue('');
    }
  }

  askQuick(prompt: string) {
    this.copilotService.sendMessage(prompt, this.labService.activeProject());
  }
}
