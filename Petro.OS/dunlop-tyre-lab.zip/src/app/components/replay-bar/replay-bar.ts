import { ChangeDetectionStrategy, Component, inject, OnDestroy, OnInit } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-replay-bar',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-[#191A19] border-t border-[#202424] px-4 py-2 text-[#EEECE5] font-mono text-xs flex flex-wrap items-center justify-between gap-3">
      <!-- Playback Status -->
      <div class="flex items-center gap-3 shrink-0">
        <button
          (click)="labService.toggleReplay()"
          class="p-1.5 bg-[#203B32] border border-[#315343] hover:bg-[#315343] text-[#D9B62F] flex items-center justify-center transition-colors">
          <mat-icon class="text-base">{{ labService.replay().isPlaying ? 'pause' : 'play_arrow' }}</mat-icon>
        </button>

        <div class="flex items-center gap-2">
          <span class="text-[10px] text-[#858C8B]">SIM REPLAY:</span>
          <span class="font-bold text-[#EEECE5]">T+00:00:{{ formatFrame(labService.replay().currentFrame) }}</span>
          @if (labService.replay().isPlaying) {
            <span class="px-1.5 py-0.2 bg-[#315343] text-[#EEECE5] text-[9px] animate-pulse">LIVE STREAM</span>
          }
        </div>
      </div>

      <!-- Scrubber Timeline -->
      <div class="flex-1 min-w-[200px] flex items-center gap-3">
        <span class="text-[10px] text-[#5F6666]">0.0s</span>
        <input
          type="range"
          min="0"
          [max]="labService.replay().maxFrames"
          [value]="labService.replay().currentFrame"
          (input)="onScrub($event)"
          class="w-full h-1.5 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
        <span class="text-[10px] text-[#5F6666]">10.0s</span>
      </div>

      <!-- Speed Selector -->
      <div class="flex items-center gap-1.5 shrink-0">
        <span class="text-[10px] text-[#858C8B] hidden sm:inline">SPEED:</span>
        @for (spd of speeds; track spd) {
          <button
            (click)="labService.setReplaySpeed(spd)"
            class="px-2 py-0.5 border text-[10px] transition-colors"
            [class.bg-[#294A5A]]="labService.replay().playbackSpeed === spd"
            [class.border-[#4A7287]]="labService.replay().playbackSpeed === spd"
            [class.text-[#EEECE5]]="labService.replay().playbackSpeed === spd"
            [class.border-[#202424]]="labService.replay().playbackSpeed !== spd"
            [class.text-[#858C8B]]="labService.replay().playbackSpeed !== spd">
            {{ spd }}×
          </button>
        }
      </div>
    </div>
  `
})
export class ReplayBar implements OnInit, OnDestroy {
  readonly labService = inject(TyreLabService);
  readonly speeds = [1, 5, 10, 50];
  private intervalId: any;

  ngOnInit() {
    this.intervalId = setInterval(() => {
      if (this.labService.replay().isPlaying) {
        const next = (this.labService.replay().currentFrame + 1) % (this.labService.replay().maxFrames + 1);
        this.labService.setReplayFrame(next);
      }
    }, 100);
  }

  ngOnDestroy() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  onScrub(event: Event) {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.labService.setReplayFrame(val);
  }

  formatFrame(frame: number): string {
    const sec = Math.floor(frame / 10);
    const ms = (frame % 10) * 10;
    return `${sec < 10 ? '0' : ''}${sec}.${ms < 10 ? '0' : ''}${ms}`;
  }
}
