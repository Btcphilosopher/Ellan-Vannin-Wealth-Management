export interface TyreProject {
  id: string;
  name: string;
  code: string; // e.g. DNL-GT-27
  version: string; // e.g. Iteration 18
  application: TyreApplication;
  vehicleTarget: string; // GT Development Car 07
  status: 'DESIGN' | 'SIMULATION' | 'TESTING' | 'FACTORY_BUILD' | 'APPROVED';
  createdAt: string;
  author: string;
  
  // Dimensions
  geometry: TyreGeometry;
  
  // Tread
  tread: TreadDesign;
  
  // Compound
  compound: CompoundFormula;
  
  // Structure
  layers: TyreLayer[];
  
  // Simulation Metrics
  simulation: SimulationMetrics;
}

export type TyreApplication = 
  | 'Passenger GT'
  | 'Motorsport / Track'
  | 'Wet Weather High Performance'
  | 'EV Quiet Tourer'
  | 'Commercial Truck'
  | 'Winter Ice & Snow'
  | 'All-Terrain SUV';

export interface TyreGeometry {
  sectionWidth: number; // mm e.g. 305
  aspectRatio: number; // % e.g. 30
  rimDiameter: number; // inches e.g. 20
  overallDiameter: number; // mm calculated
  treadWidth: number; // mm e.g. 280
  shoulderRadius: number; // mm e.g. 32
  sidewallThickness: number; // mm e.g. 12
  grooveDepth: number; // mm e.g. 8.2
  beltAngle: number; // degrees e.g. 24
  targetLoadRating: number; // kg e.g. 710
  targetSpeedRating: string; // e.g. (300+ km/h / (Y))
  targetPressure: number; // bar e.g. 2.40
}

export interface TreadDesign {
  id: string;
  name: string;
  type: 'Asymmetric GT' | 'Directional Rain' | 'Semi-Slick Track' | 'Winter Siped' | 'Heavy Commercial';
  longitudinalGrooves: number; // e.g. 4
  grooveWidth: number; // mm e.g. 6.5
  voidRatio: number; // % e.g. 28.5
  sipeDensity: number; // 0 - 100
  shoulderBlockStiffness: number; // MPa e.g. 45
  channelAngle: number; // deg e.g. 18
  
  // Predicted metrics
  aquaplaningSpeedKmH: number; // e.g. 98.4
  treadNoiseDb: number; // e.g. 68.2
  dryCorneringStiffness: number; // N/deg e.g. 1820
  wearRateMmPer10kKm: number; // mm/10,000km e.g. 1.35
}

export interface CompoundFormula {
  id: string;
  code: string; // DL-RB-047
  name: string;
  naturalRubberPct: number; // % e.g. 35
  syntheticSbrPct: number; // % e.g. 25
  silicaPct: number; // % e.g. 25
  carbonBlackPct: number; // % e.g. 10
  oilsResinsPct: number; // % e.g. 5
  
  // Synthetic lab performance indexes
  wetGripIndex: number; // e.g. 0.86 (0-1)
  rollingResistanceIndex: number; // e.g. 0.72 (lower better)
  abrasionIndex: number; // e.g. 0.81 (higher = more durable)
  thermalStability: number; // e.g. 0.88
  tgGlassTransitionTemp: number; // °C e.g. -22
  tanDeltaPeak: number; // e.g. 0.48
}

export interface TyreLayer {
  id: string;
  name: string; // e.g. Tread Cap, Steel Belt 1, Carcass
  material: string;
  thicknessMm: number;
  orientationDeg: number; // orientation angle
  stressStateMpa: number;
  temperatureC: number;
  manufacturingProcess: string;
  description: string;
}

export interface SimulationMetrics {
  loadKg: number; // e.g. 650
  pressureBar: number; // e.g. 2.35
  speedKmH: number; // e.g. 120
  camberDeg: number; // e.g. -1.5
  slipAngleDeg: number; // e.g. 3.2
  roadSurface: 'Dry Asphalt' | 'Wet Asphalt' | 'Polished Concrete' | 'Snow / Ice' | 'Track Surface';
  
  // Results
  contactPatchAreaCm2: number; // e.g. 184.2
  peakPressureMpa: number; // e.g. 0.88
  longitudinalGripForceN: number; // N
  lateralGripForceN: number; // N
  frictionCoeffMu: number; // e.g. 0.94
  carcassTempC: number; // e.g. 78.4
  treadDisplacementMm: number; // e.g. 3.4
  stoppingDistance100to0M: number; // m
}

export interface FactoryMachine {
  id: string;
  lineId: string; // LINE 01 .. LINE 04
  name: string;
  stage: 'MIXING' | 'CALENDERING' | 'EXTRUSION' | 'BEAD_BUILD' | 'TYRE_BUILDING' | 'CURING' | 'QUALITY_INSPECTION';
  status: 'OPERATIONAL' | 'WARNING' | 'MAINTENANCE' | 'OFFLINE';
  temperatureC: number;
  pressureBar: number;
  energyKwhPerUnit: number;
  cycleProgressPct: number;
  throughputUnitsPerHr: number;
  bearingConditionPct: number;
  expectedServiceWindowCycles: number;
}

export interface TyrePassport {
  serialId: string; // e.g. DNL-2026-004281
  modelCode: string; // DNL-GT-27
  sizeLabel: string; // 305/30 R20
  compoundBatch: string; // DL-RB-047-B92
  factoryLocation: string; // UK-SYNTHETIC-04 (Birmingham R&D)
  buildTimestamp: string;
  cureCycleId: string;
  inspectionStatus: 'PASS' | 'REVIEW' | 'QUARANTINE';
  uniformityRunoutMm: number; // e.g. 0.12 mm
  dynamicBalanceGrams: number; // e.g. 4.2g
  provenanceHash: string;
}

export interface QualityDefect {
  id: string;
  scanTimestamp: string;
  tyreSerial: string;
  location: 'TREAD' | 'SIDEWALL' | 'BEAD' | 'INNER_LINER' | 'SHOULDER';
  defectType: 'MOULDING_FLASH' | 'VOID_ANOMALY' | 'BELT_MISALIGNMENT' | 'SURFACE_CONTAMINATION' | 'NONE';
  confidencePct: number;
  status: 'PASS' | 'REVIEW' | 'REJECT';
  xRatio: number; // 0-1 location
  yRatio: number;
}

export interface EngineeringNote {
  id: string;
  date: string;
  author: string;
  title: string;
  content: string;
  projectCode: string;
  tags: string[];
}
