import { Injectable, signal, computed } from '@angular/core';
import { 
  TyreProject, 
  TyreGeometry, 
  TreadDesign, 
  CompoundFormula, 
  TyreLayer, 
  SimulationMetrics, 
  FactoryMachine, 
  TyrePassport, 
  QualityDefect, 
  EngineeringNote 
} from '../models/tyre.models';

export type ViewMode = 
  | 'lab' 
  | 'designer' 
  | 'tread' 
  | 'compound' 
  | 'structure' 
  | 'simulation' 
  | 'vehicle' 
  | 'test' 
  | 'wear' 
  | 'factory' 
  | 'quality' 
  | 'passport' 
  | 'comparison' 
  | 'drawing' 
  | 'notebook';

@Injectable({
  providedIn: 'root'
})
export class TyreLabService {
  // Navigation View
  readonly currentView = signal<ViewMode>('lab');
  readonly isCommandPaletteOpen = signal<boolean>(false);
  readonly isCopilotOpen = signal<boolean>(false);
  readonly searchQuery = signal<string>('');

  // Primary Tyre Project (DNL-GT-27)
  readonly activeProject = signal<TyreProject>({
    id: 'proj-001',
    name: 'DUNLOP GT DEVELOPMENT TYRE',
    code: 'DNL-GT-27',
    version: 'Iteration 18',
    application: 'Passenger GT',
    vehicleTarget: 'GT Development Car 07',
    status: 'SIMULATION',
    createdAt: '2026-09-21',
    author: 'Lead Tyre Engineer (Dunlop R&D Birmingham)',
    geometry: {
      sectionWidth: 305,
      aspectRatio: 30,
      rimDiameter: 20,
      overallDiameter: 676,
      treadWidth: 280,
      shoulderRadius: 32,
      sidewallThickness: 12.5,
      grooveDepth: 8.2,
      beltAngle: 24,
      targetLoadRating: 710,
      targetSpeedRating: 'Y (300 km/h)',
      targetPressure: 2.35
    },
    tread: {
      id: 'trd-018',
      name: 'ASYS-GT ULTRA DRAIN',
      type: 'Asymmetric GT',
      longitudinalGrooves: 4,
      grooveWidth: 6.5,
      voidRatio: 28.5,
      sipeDensity: 42,
      shoulderBlockStiffness: 48,
      channelAngle: 18,
      aquaplaningSpeedKmH: 98.4,
      treadNoiseDb: 68.2,
      dryCorneringStiffness: 1820,
      wearRateMmPer10kKm: 1.35
    },
    compound: {
      id: 'cmp-047',
      code: 'DL-RB-047',
      name: 'SILICA-HYBRID RACING MATRIX',
      naturalRubberPct: 35,
      syntheticSbrPct: 25,
      silicaPct: 25,
      carbonBlackPct: 10,
      oilsResinsPct: 5,
      wetGripIndex: 0.86,
      rollingResistanceIndex: 0.72,
      abrasionIndex: 0.81,
      thermalStability: 0.88,
      tgGlassTransitionTemp: -22,
      tanDeltaPeak: 0.48
    },
    layers: [
      {
        id: 'lay-1',
        name: 'TREAD CAP COMPOUND',
        material: 'DL-RB-047 High-Silica Rubber Matrix',
        thicknessMm: 8.2,
        orientationDeg: 0,
        stressStateMpa: 1.2,
        temperatureC: 86.4,
        manufacturingProcess: 'Dual-Durometer Co-Extrusion',
        description: 'Primary contact surface engineering for wet grip, thermal resistance & dry cornering'
      },
      {
        id: 'lay-2',
        name: 'UNDER-TREAD BASE',
        material: 'DL-RB-012 Low Hysteresis Sub-Layer',
        thicknessMm: 2.1,
        orientationDeg: 0,
        stressStateMpa: 2.4,
        temperatureC: 78.1,
        manufacturingProcess: 'Precision Extrusion Sheet',
        description: 'Reduces rolling resistance heat buildup and buffers tread block shearing forces'
      },
      {
        id: 'lay-3',
        name: 'SPIRAL REINFORCEMENT (JOINTLESS NYLON)',
        material: 'Aramid-Nylon Hybrid Cord (0° Wrap)',
        thicknessMm: 1.4,
        orientationDeg: 0,
        stressStateMpa: 14.8,
        temperatureC: 72.0,
        manufacturingProcess: 'Automated 0° Filament Winding',
        description: 'Restrains centrifugal growth at high speeds (>300 km/h) for uniform contact patch'
      },
      {
        id: 'lay-4',
        name: 'STEEL BELT 1 (+24°)',
        material: 'High-Tensile Brass-Coated Steel Wire (2+2x0.28)',
        thicknessMm: 1.8,
        orientationDeg: 24,
        stressStateMpa: 38.5,
        temperatureC: 68.5,
        manufacturingProcess: 'Steel Cord Calendering',
        description: 'Provides structural rigidity and lateral cornering force response'
      },
      {
        id: 'lay-5',
        name: 'STEEL BELT 2 (-24°)',
        material: 'High-Tensile Brass-Coated Steel Wire (2+2x0.28)',
        thicknessMm: 1.8,
        orientationDeg: -24,
        stressStateMpa: 36.2,
        temperatureC: 67.2,
        manufacturingProcess: 'Steel Cord Calendering',
        description: 'Cross-angled belt layer balancing torsional stiffness and impact compliance'
      },
      {
        id: 'lay-6',
        name: 'CARCASS PLIES (RAYON)',
        material: 'Rayon 1840 dtex/2 Woven Fabric',
        thicknessMm: 2.2,
        orientationDeg: 90,
        stressStateMpa: 12.1,
        temperatureC: 58.0,
        manufacturingProcess: 'Textile Rubber Calendering',
        description: 'Radial carcass body structure holding inflation pressure and absorbing vertical loads'
      },
      {
        id: 'lay-7',
        name: 'SIDEWALL PROTECTIVE LAYER',
        material: 'DL-SW-008 Ozone & Flex Resistant Rubber',
        thicknessMm: 4.5,
        orientationDeg: 0,
        stressStateMpa: 0.8,
        temperatureC: 45.0,
        manufacturingProcess: 'Side Profile Extrusion',
        description: 'Flex-fatigue resistant rubber guarding against kerb abrasion and weather degradation'
      },
      {
        id: 'lay-8',
        name: 'BEAD CORE & HIGH-MODULUS APEX',
        material: 'High-Carbon Steel Bead Ring + Hard Apex Filler',
        thicknessMm: 14.0,
        orientationDeg: 0,
        stressStateMpa: 82.0,
        temperatureC: 42.0,
        manufacturingProcess: 'Automatic Wire Extrusion & Winding',
        description: 'Anchors tyre securely onto wheel rim flange and transfers steering torque'
      },
      {
        id: 'lay-9',
        name: 'INNER LINER',
        material: 'Halobutyl Rubber Compound (98% Impermeable)',
        thicknessMm: 1.2,
        orientationDeg: 0,
        stressStateMpa: 0.1,
        temperatureC: 38.0,
        manufacturingProcess: 'Calendered Thin Sheet',
        description: 'Airtight internal membrane maintaining inflation pressure stability over time'
      }
    ],
    simulation: {
      loadKg: 650,
      pressureBar: 2.35,
      speedKmH: 120,
      camberDeg: -1.5,
      slipAngleDeg: 3.2,
      roadSurface: 'Dry Asphalt',
      contactPatchAreaCm2: 184.2,
      peakPressureMpa: 0.88,
      longitudinalGripForceN: 4820,
      lateralGripForceN: 5210,
      frictionCoeffMu: 0.94,
      carcassTempC: 86.4,
      treadDisplacementMm: 3.4,
      stoppingDistance100to0M: 32.4
    }
  });

  // Comparison Candidates
  readonly comparisonProjects = signal<TyreProject[]>([
    {
      id: 'proj-002',
      name: 'DESIGN A — STANDARD GT BASELINE',
      code: 'DNL-GT-27-A',
      version: 'Rev 12',
      application: 'Passenger GT',
      vehicleTarget: 'GT Dev Car 01',
      status: 'APPROVED',
      createdAt: '2026-08-15',
      author: 'Dunlop Engineering Team',
      geometry: {
        sectionWidth: 305,
        aspectRatio: 30,
        rimDiameter: 20,
        overallDiameter: 676,
        treadWidth: 275,
        shoulderRadius: 28,
        sidewallThickness: 12.0,
        grooveDepth: 8.0,
        beltAngle: 26,
        targetLoadRating: 700,
        targetSpeedRating: 'Y',
        targetPressure: 2.40
      },
      tread: {
        id: 'trd-012',
        name: 'GT BASELINE RIB',
        type: 'Asymmetric GT',
        longitudinalGrooves: 3,
        grooveWidth: 5.5,
        voidRatio: 24.2,
        sipeDensity: 25,
        shoulderBlockStiffness: 42,
        channelAngle: 15,
        aquaplaningSpeedKmH: 91.2,
        treadNoiseDb: 70.1,
        dryCorneringStiffness: 1710,
        wearRateMmPer10kKm: 1.20
      },
      compound: {
        id: 'cmp-041',
        code: 'DL-RB-041',
        name: 'BALANCED TOURING COMPOUND',
        naturalRubberPct: 40,
        syntheticSbrPct: 30,
        silicaPct: 15,
        carbonBlackPct: 10,
        oilsResinsPct: 5,
        wetGripIndex: 0.76,
        rollingResistanceIndex: 0.68,
        abrasionIndex: 0.88,
        thermalStability: 0.82,
        tgGlassTransitionTemp: -28,
        tanDeltaPeak: 0.38
      },
      layers: [],
      simulation: {
        loadKg: 650,
        pressureBar: 2.40,
        speedKmH: 120,
        camberDeg: -1.5,
        slipAngleDeg: 3.2,
        roadSurface: 'Dry Asphalt',
        contactPatchAreaCm2: 172.0,
        peakPressureMpa: 0.95,
        longitudinalGripForceN: 4200,
        lateralGripForceN: 4650,
        frictionCoeffMu: 0.86,
        carcassTempC: 81.0,
        treadDisplacementMm: 3.1,
        stoppingDistance100to0M: 35.2
      }
    },
    {
      id: 'proj-003',
      name: 'DESIGN B — WET TRACK OPTIMIZED',
      code: 'DNL-GT-27-WET',
      version: 'Rev 19',
      application: 'Wet Weather High Performance',
      vehicleTarget: 'GT Dev Car 07',
      status: 'TESTING',
      createdAt: '2026-09-24',
      author: 'Dunlop Hydrodynamics Lab',
      geometry: {
        sectionWidth: 305,
        aspectRatio: 30,
        rimDiameter: 20,
        overallDiameter: 676,
        treadWidth: 282,
        shoulderRadius: 35,
        sidewallThickness: 12.8,
        grooveDepth: 8.8,
        beltAngle: 22,
        targetLoadRating: 710,
        targetSpeedRating: 'Y',
        targetPressure: 2.30
      },
      tread: {
        id: 'trd-022',
        name: 'AQUA-CHANNEL EVAC 3000',
        type: 'Directional Rain',
        longitudinalGrooves: 5,
        grooveWidth: 7.2,
        voidRatio: 32.8,
        sipeDensity: 65,
        shoulderBlockStiffness: 38,
        channelAngle: 26,
        aquaplaningSpeedKmH: 106.8,
        treadNoiseDb: 71.4,
        dryCorneringStiffness: 1640,
        wearRateMmPer10kKm: 1.55
      },
      compound: {
        id: 'cmp-052',
        code: 'DL-RB-052',
        name: 'ULTRA-SILICA AQUA COMPOUND',
        naturalRubberPct: 25,
        syntheticSbrPct: 30,
        silicaPct: 35,
        carbonBlackPct: 5,
        oilsResinsPct: 5,
        wetGripIndex: 0.94,
        rollingResistanceIndex: 0.78,
        abrasionIndex: 0.72,
        thermalStability: 0.84,
        tgGlassTransitionTemp: -18,
        tanDeltaPeak: 0.56
      },
      layers: [],
      simulation: {
        loadKg: 650,
        pressureBar: 2.30,
        speedKmH: 120,
        camberDeg: -1.5,
        slipAngleDeg: 3.2,
        roadSurface: 'Wet Asphalt',
        contactPatchAreaCm2: 195.0,
        peakPressureMpa: 0.78,
        longitudinalGripForceN: 4950,
        lateralGripForceN: 4800,
        frictionCoeffMu: 0.91,
        carcassTempC: 72.5,
        treadDisplacementMm: 3.8,
        stoppingDistance100to0M: 30.8
      }
    }
  ]);

  // Replay State
  readonly replay = signal<{
    isPlaying: boolean;
    playbackSpeed: number; // 1, 5, 10, 50
    currentFrame: number; // 0..100
    maxFrames: number;
  }>({
    isPlaying: false,
    playbackSpeed: 1,
    currentFrame: 35,
    maxFrames: 100
  });

  // Factory Machines Digital Twin
  readonly factoryMachines = signal<FactoryMachine[]>([
    {
      id: 'mch-mix-01',
      lineId: 'LINE 01',
      name: 'BANBURY HIGH-SHEAR MIXER 01',
      stage: 'MIXING',
      status: 'OPERATIONAL',
      temperatureC: 154.2,
      pressureBar: 8.4,
      energyKwhPerUnit: 12.4,
      cycleProgressPct: 82,
      throughputUnitsPerHr: 140,
      bearingConditionPct: 94,
      expectedServiceWindowCycles: 1240
    },
    {
      id: 'mch-cal-02',
      lineId: 'LINE 01',
      name: '4-ROLL STEEL CORD CALENDER 02',
      stage: 'CALENDERING',
      status: 'OPERATIONAL',
      temperatureC: 92.0,
      pressureBar: 14.2,
      energyKwhPerUnit: 8.1,
      cycleProgressPct: 65,
      throughputUnitsPerHr: 120,
      bearingConditionPct: 88,
      expectedServiceWindowCycles: 850
    },
    {
      id: 'mch-ext-01',
      lineId: 'LINE 02',
      name: 'QUAD-EXTRUDER TREAD LINE 01',
      stage: 'EXTRUSION',
      status: 'OPERATIONAL',
      temperatureC: 118.5,
      pressureBar: 22.0,
      energyKwhPerUnit: 15.6,
      cycleProgressPct: 44,
      throughputUnitsPerHr: 110,
      bearingConditionPct: 91,
      expectedServiceWindowCycles: 980
    },
    {
      id: 'mch-tbm-04',
      lineId: 'LINE 04',
      name: 'AUTOMATED TYRE BUILDING MACHINE (TBM-04)',
      stage: 'TYRE_BUILDING',
      status: 'OPERATIONAL',
      temperatureC: 24.5,
      pressureBar: 6.2,
      energyKwhPerUnit: 4.8,
      cycleProgressPct: 92,
      throughputUnitsPerHr: 45,
      bearingConditionPct: 96,
      expectedServiceWindowCycles: 1420
    },
    {
      id: 'mch-cur-04',
      lineId: 'LINE 04',
      name: 'HYDRAULIC CURING PRESS CP-0482',
      stage: 'CURING',
      status: 'OPERATIONAL',
      temperatureC: 168.0,
      pressureBar: 18.5,
      energyKwhPerUnit: 24.2,
      cycleProgressPct: 78,
      throughputUnitsPerHr: 22,
      bearingConditionPct: 82,
      expectedServiceWindowCycles: 430
    },
    {
      id: 'mch-qc-01',
      lineId: 'LINE 04',
      name: 'LASER UNIFORMITY & X-RAY SCANNER QC-1',
      stage: 'QUALITY_INSPECTION',
      status: 'OPERATIONAL',
      temperatureC: 22.0,
      pressureBar: 1.0,
      energyKwhPerUnit: 2.1,
      cycleProgressPct: 100,
      throughputUnitsPerHr: 95,
      bearingConditionPct: 98,
      expectedServiceWindowCycles: 2100
    }
  ]);

  // Tyre Passports Database
  readonly passports = signal<TyrePassport[]>([
    {
      serialId: 'DNL-2026-004281',
      modelCode: 'DNL-GT-27',
      sizeLabel: '305/30 R20 103Y',
      compoundBatch: 'DL-RB-047-B92',
      factoryLocation: 'UK-SYNTHETIC-04 (Birmingham R&D)',
      buildTimestamp: '2026-09-28 09:41:12',
      cureCycleId: 'C-048281-LINE4',
      inspectionStatus: 'PASS',
      uniformityRunoutMm: 0.12,
      dynamicBalanceGrams: 3.8,
      provenanceHash: '0x8f2a9c41d08e7b39f104'
    },
    {
      serialId: 'DNL-2026-004282',
      modelCode: 'DNL-GT-27',
      sizeLabel: '305/30 R20 103Y',
      compoundBatch: 'DL-RB-047-B92',
      factoryLocation: 'UK-SYNTHETIC-04 (Birmingham R&D)',
      buildTimestamp: '2026-09-28 09:58:04',
      cureCycleId: 'C-048282-LINE4',
      inspectionStatus: 'PASS',
      uniformityRunoutMm: 0.14,
      dynamicBalanceGrams: 4.2,
      provenanceHash: '0x3b1e7c99a405d218e821'
    },
    {
      serialId: 'DNL-2026-004283',
      modelCode: 'DNL-GT-27',
      sizeLabel: '305/30 R20 103Y',
      compoundBatch: 'DL-RB-047-B93',
      factoryLocation: 'UK-SYNTHETIC-04 (Birmingham R&D)',
      buildTimestamp: '2026-09-28 10:14:32',
      cureCycleId: 'C-048283-LINE4',
      inspectionStatus: 'REVIEW',
      uniformityRunoutMm: 0.28,
      dynamicBalanceGrams: 8.4,
      provenanceHash: '0x94f1c082e71d3a4921b7'
    }
  ]);

  // Quality Defect Records
  readonly defects = signal<QualityDefect[]>([
    {
      id: 'def-901',
      scanTimestamp: '2026-09-28 10:14:35',
      tyreSerial: 'DNL-2026-004283',
      location: 'SHOULDER',
      defectType: 'MOULDING_FLASH',
      confidencePct: 98.4,
      status: 'REVIEW',
      xRatio: 0.72,
      yRatio: 0.35
    },
    {
      id: 'def-902',
      scanTimestamp: '2026-09-28 08:30:11',
      tyreSerial: 'DNL-2026-004260',
      location: 'TREAD',
      defectType: 'VOID_ANOMALY',
      confidencePct: 94.1,
      status: 'REJECT',
      xRatio: 0.45,
      yRatio: 0.62
    }
  ]);

  // Engineering Notes
  readonly notes = signal<EngineeringNote[]>([
    {
      id: 'note-01',
      date: '21 September 2026',
      author: 'Dr. Arthur Pendelton (Principal Tyre Engineer)',
      title: 'Tread Revision 18 — Shoulder Groove Optimization',
      content: 'Reduced shoulder groove width from 7.0 mm to 6.5 mm while increasing channel evacuation draft angle to 18°. Simulated wet drainage increased by 4.2% while lateral shoulder block stiffness improved by 140 N/deg. Recommending track testing on GT Dev Car 07.',
      projectCode: 'DNL-GT-27',
      tags: ['Tread Design', 'Wet Evacuation', 'Track Test']
    },
    {
      id: 'note-02',
      date: '18 September 2026',
      author: 'Marcus Vance (Compound Specialist)',
      title: 'DL-RB-047 Silica Coupling Reaction Profile',
      content: 'Silane coupling agent reaction temperature optimized to 154°C in Banbury Mixer 01. Dynamic mechanical analysis shows Tan Delta peak shifting to -22°C with 12% lower rolling resistance index at 60°C.',
      projectCode: 'DNL-GT-27',
      tags: ['Compound', 'Silica Matrix', 'DMA']
    }
  ]);

  // Derived Calculations
  readonly calculatedDiameter = computed(() => {
    const geo = this.activeProject().geometry;
    // Outside diameter = Rim (in * 25.4) + 2 * (SectionWidth * AspectRatio / 100)
    return Math.round(geo.rimDiameter * 25.4 + 2 * (geo.sectionWidth * (geo.aspectRatio / 100)));
  });

  // State Mutators
  setView(mode: ViewMode) {
    this.currentView.set(mode);
  }

  toggleCommandPalette() {
    this.isCommandPaletteOpen.update(v => !v);
  }

  toggleCopilot() {
    this.isCopilotOpen.update(v => !v);
  }

  updateGeometry(updates: Partial<TyreGeometry>) {
    this.activeProject.update(proj => {
      const updatedGeo = { ...proj.geometry, ...updates };
      updatedGeo.overallDiameter = Math.round(
        updatedGeo.rimDiameter * 25.4 + 2 * (updatedGeo.sectionWidth * (updatedGeo.aspectRatio / 100))
      );
      return {
        ...proj,
        geometry: updatedGeo
      };
    });
  }

  updateTread(updates: Partial<TreadDesign>) {
    this.activeProject.update(proj => {
      const updatedTread = { ...proj.tread, ...updates };
      // Recalculate synthetic performance estimates based on formulas
      updatedTread.voidRatio = Math.round((updatedTread.longitudinalGrooves * updatedTread.grooveWidth / proj.geometry.treadWidth * 100 + 12) * 10) / 10;
      updatedTread.aquaplaningSpeedKmH = Math.round((85 + updatedTread.voidRatio * 0.45 + updatedTread.channelAngle * 0.2) * 10) / 10;
      updatedTread.treadNoiseDb = Math.round((64 + updatedTread.longitudinalGrooves * 0.8 + updatedTread.shoulderBlockStiffness * 0.05) * 10) / 10;
      return {
        ...proj,
        tread: updatedTread
      };
    });
  }

  updateCompound(updates: Partial<CompoundFormula>) {
    this.activeProject.update(proj => {
      const updatedCmp = { ...proj.compound, ...updates };
      // Recalculate synthetic grip & rolling resistance
      updatedCmp.wetGripIndex = Math.round((0.4 + updatedCmp.silicaPct * 0.012 + updatedCmp.syntheticSbrPct * 0.005) * 100) / 100;
      updatedCmp.rollingResistanceIndex = Math.round((0.95 - updatedCmp.silicaPct * 0.008 + updatedCmp.carbonBlackPct * 0.004) * 100) / 100;
      return {
        ...proj,
        compound: updatedCmp
      };
    });
  }

  updateSimulationParams(params: Partial<SimulationMetrics>) {
    this.activeProject.update(proj => {
      const updatedSim = { ...proj.simulation, ...params };
      // Physics formulas for contact patch area and grip force
      const pressureMpa = updatedSim.pressureBar * 0.1;
      updatedSim.contactPatchAreaCm2 = Math.round((updatedSim.loadKg / (pressureMpa * 10)) * 10) / 10;
      updatedSim.peakPressureMpa = Math.round((pressureMpa * 2.8 + updatedSim.loadKg / 800) * 100) / 100;
      updatedSim.longitudinalGripForceN = Math.round(updatedSim.loadKg * 9.81 * updatedSim.frictionCoeffMu);
      updatedSim.lateralGripForceN = Math.round(updatedSim.loadKg * 9.81 * updatedSim.frictionCoeffMu * (1 - Math.abs(updatedSim.slipAngleDeg - 4) * 0.04));
      return {
        ...proj,
        simulation: updatedSim
      };
    });
  }

  toggleReplay() {
    this.replay.update(r => ({ ...r, isPlaying: !r.isPlaying }));
  }

  setReplayFrame(frame: number) {
    this.replay.update(r => ({ ...r, currentFrame: frame }));
  }

  setReplaySpeed(speed: number) {
    this.replay.update(r => ({ ...r, playbackSpeed: speed }));
  }

  generateNewPassport(): TyrePassport {
    const nextSeq = this.passports().length + 4284;
    const newPassport: TyrePassport = {
      serialId: `DNL-2026-00${nextSeq}`,
      modelCode: this.activeProject().code,
      sizeLabel: `${this.activeProject().geometry.sectionWidth}/${this.activeProject().geometry.aspectRatio} R${this.activeProject().geometry.rimDiameter}`,
      compoundBatch: `${this.activeProject().compound.code}-B99`,
      factoryLocation: 'UK-SYNTHETIC-04 (Birmingham R&D)',
      buildTimestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      cureCycleId: `C-0${nextSeq}-LINE4`,
      inspectionStatus: 'PASS',
      uniformityRunoutMm: 0.11,
      dynamicBalanceGrams: 3.5,
      provenanceHash: '0x' + Math.random().toString(16).substring(2, 12)
    };
    this.passports.update(list => [newPassport, ...list]);
    return newPassport;
  }

  addNote(title: string, content: string, tags: string[]) {
    const newNote: EngineeringNote = {
      id: 'note-' + Date.now(),
      date: '28 September 2026',
      author: 'Lead Engineer',
      title,
      content,
      projectCode: this.activeProject().code,
      tags
    };
    this.notes.update(n => [newNote, ...n]);
  }
}
