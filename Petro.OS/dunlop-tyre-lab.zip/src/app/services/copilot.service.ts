import { Injectable, signal } from '@angular/core';

export interface CopilotMessage {
  id: string;
  sender: 'user' | 'copilot';
  text: string;
  timestamp: string;
  sourceType?: 'OBSERVED DATA' | 'SIMULATED RESULT' | 'ENGINEERING ASSUMPTION' | 'MODEL PREDICTION';
}

@Injectable({
  providedIn: 'root'
})
export class CopilotService {
  readonly messages = signal<CopilotMessage[]>([
    {
      id: 'm1',
      sender: 'copilot',
      text: 'Good day. I am the Dunlop Engineering Copilot. I have indexed active project DNL-GT-27, tread iteration 18, compound DL-RB-047, and factory line telemetry. How may I assist your engineering evaluation today?',
      timestamp: '08:42',
      sourceType: 'OBSERVED DATA'
    }
  ]);

  readonly isLoading = signal<boolean>(false);

  async sendMessage(userText: string, projectContext: any) {
    if (!userText.trim()) return;

    const userMsg: CopilotMessage = {
      id: 'u-' + Date.now(),
      sender: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    this.messages.update(msgs => [...msgs, userMsg]);
    this.isLoading.set(true);

    try {
      const response = await fetch('/api/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userText,
          context: projectContext
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      const data = await response.json();

      const copilotMsg: CopilotMessage = {
        id: 'c-' + Date.now(),
        sender: 'copilot',
        text: data.reply || 'Analysis complete.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sourceType: data.sourceType || 'SIMULATED RESULT'
      };

      this.messages.update(msgs => [...msgs, copilotMsg]);
    } catch (err: any) {
      const errorMsg: CopilotMessage = {
        id: 'e-' + Date.now(),
        sender: 'copilot',
        text: `[ENGINEERING SYSTEM WARNING]: Unable to query copilot backend (${err.message}). Using local analytical fallback rules.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sourceType: 'ENGINEERING ASSUMPTION'
      };
      this.messages.update(msgs => [...msgs, errorMsg]);
    } finally {
      this.isLoading.set(false);
    }
  }
}
