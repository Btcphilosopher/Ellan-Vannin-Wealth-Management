import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { TyreLayer } from '../../models/tyre.models';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-structure-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP STRUCTURE MODULE</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            INTERNAL TYRE COMPOSITE STRUCTURE & LAYER EXPLODER
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Inspect individual steel belts, zero-degree nylon wraps, carcass plies & bead apex fillers
          </div>
        </div>

        <div class="flex items-center gap-3">
          <span class="text-xs text-[#858C8B]">EXPLODE DISPLACEMENT:</span>
          <input
            type="range"
            min="0"
            max="100"
            [value]="explodeOffset()"
            (input)="onExplodeChange($event)"
            class="w-32 h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
          <span class="text-xs font-bold text-[#D9B62F]">{{ explodeOffset() }}%</span>
        </div>
      </div>

      <!-- Main Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Layer Selector List Left -->
        <div class="lg:col-span-5 bg-[#191A19] border border-[#202424] p-4 space-y-2">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider">
            STRUCTURAL LAYER ARCHITECTURE (9 LAYERS)
          </div>

          <div class="space-y-1.5 text-xs max-h-[480px] overflow-y-auto">
            @for (layer of layers(); track layer.id; let idx = $index) {
              <button
                (click)="selectedLayerIndex.set(idx)"
                class="w-full p-3 text-left border transition-colors flex items-center justify-between"
                [class.bg-[#203B32]]="selectedLayerIndex() === idx"
                [class.border-[#315343]]="selectedLayerIndex() === idx"
                [class.text-[#EEECE5]]="selectedLayerIndex() === idx"
                [class.bg-[#111313]]="selectedLayerIndex() !== idx"
                [class.border-[#202424]]="selectedLayerIndex() !== idx"
                [class.text-[#858C8B]]="selectedLayerIndex() !== idx"
                [class.hover:border-[#5F6666]]="selectedLayerIndex() !== idx">
                <div class="flex items-center gap-2">
                  <span class="text-[10px] font-mono text-[#D9B62F]">L-0{{ idx + 1 }}</span>
                  <span class="font-bold truncate max-w-[180px]">{{ layer.name }}</span>
                </div>
                <div class="text-[10px] text-right font-mono">
                  <div>{{ layer.thicknessMm }} mm</div>
                  <div class="text-[#315343] font-bold">{{ layer.orientationDeg }}°</div>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Layer Detailed Inspector Panel Right -->
        <div class="lg:col-span-7 bg-[#191A19] border border-[#202424] p-5 space-y-5 flex flex-col justify-between">
          <div>
            <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
              <span>LAYER SPECIFICATION & STRESS INSPECTOR</span>
              <span class="text-[#858C8B] font-mono text-[10px]">LAYER 0{{ selectedLayerIndex() + 1 }} OF 9</span>
            </div>

            <!-- Active Layer Header -->
            <div class="my-4 p-4 bg-[#111313] border border-[#313636] space-y-2">
              <div class="text-lg font-extrabold text-[#EEECE5] font-sans">
                {{ activeLayer().name }}
              </div>
              <div class="text-xs text-[#D9B62F] font-mono">
                MATERIAL: {{ activeLayer().material }}
              </div>
              <div class="text-xs text-[#858C8B] leading-relaxed">
                {{ activeLayer().description }}
              </div>
            </div>

            <!-- Technical Properties Grid -->
            <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              <div class="bg-[#111313] border border-[#202424] p-3">
                <div class="text-[10px] text-[#858C8B]">NOMINAL THICKNESS</div>
                <div class="text-sm font-bold text-[#EEECE5]">{{ activeLayer().thicknessMm }} mm</div>
              </div>

              <div class="bg-[#111313] border border-[#202424] p-3">
                <div class="text-[10px] text-[#858C8B]">CORD ORIENTATION</div>
                <div class="text-sm font-bold text-[#315343]">{{ activeLayer().orientationDeg }}°</div>
              </div>

              <div class="bg-[#111313] border border-[#202424] p-3">
                <div class="text-[10px] text-[#858C8B]">STRESS STATE</div>
                <div class="text-sm font-bold text-[#A8443D]">{{ activeLayer().stressStateMpa }} MPa</div>
              </div>

              <div class="bg-[#111313] border border-[#202424] p-3">
                <div class="text-[10px] text-[#858C8B]">OPERATIONAL TEMP</div>
                <div class="text-sm font-bold text-[#C18B35]">{{ activeLayer().temperatureC }} °C</div>
              </div>

              <div class="bg-[#111313] border border-[#202424] p-3 col-span-2">
                <div class="text-[10px] text-[#858C8B]">MANUFACTURING METHOD</div>
                <div class="text-xs font-bold text-[#4A7287]">{{ activeLayer().manufacturingProcess }}</div>
              </div>
            </div>
          </div>

          <!-- Composite Summary Footer -->
          <div class="bg-[#111313] border border-[#202424] p-3 text-[10px] text-[#858C8B] flex items-center justify-between">
            <span>TOTAL CARCASS THICKNESS: 28.3 mm</span>
            <span class="text-[#D9B62F]">COMPOSITE INTEGRITY: 100% PASS</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class StructureView {
  readonly labService = inject(TyreLabService);
  readonly selectedLayerIndex = signal<number>(0);
  readonly explodeOffset = signal<number>(40);

  get layers() {
    return () => this.labService.activeProject().layers;
  }

  get activeLayer(): () => TyreLayer {
    return () => this.layers()[this.selectedLayerIndex()] || this.layers()[0];
  }

  onExplodeChange(event: Event) {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.explodeOffset.set(val);
  }
}
