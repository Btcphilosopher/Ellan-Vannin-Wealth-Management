import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-notebook-view',
  imports: [MatIconModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP RESEARCH NOTEBOOK</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            ENGINEERING NOTEBOOK & R QUANTITATIVE ENGINE
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Statistical R analysis notebooks, decision logbook records & peer review notes
          </div>
        </div>

        <button (click)="isAddingNote.set(true)" class="px-3 py-1.5 bg-[#203B32] border border-[#315343] hover:bg-[#315343] text-xs font-bold transition-colors flex items-center gap-1.5">
          <mat-icon class="text-sm">add_comment</mat-icon>
          <span>NEW LOGBOOK NOTE</span>
        </button>
      </div>

      <!-- Add Note Form Modal -->
      @if (isAddingNote()) {
        <div class="bg-[#191A19] border border-[#313636] p-5 space-y-4">
          <div class="text-xs font-bold text-[#D9B62F] uppercase border-b border-[#202424] pb-2">
            ATTACH NEW ENGINEERING NOTE TO PROJECT {{ labService.activeProject().code }}
          </div>

          <form [formGroup]="noteForm" (ngSubmit)="saveNote()" class="space-y-3 text-xs">
            <div>
              <label class="block text-[#858C8B] mb-1">NOTE TITLE</label>
              <input
                formControlName="title"
                type="text"
                placeholder="e.g. Tread Revision 19 - Lateral Groove Angle Study"
                class="w-full bg-[#111313] border border-[#313636] p-2 text-[#EEECE5] outline-hidden focus:border-[#D9B62F]" />
            </div>

            <div>
              <label class="block text-[#858C8B] mb-1">CONTENT & OBSERVATIONS</label>
              <textarea
                formControlName="content"
                rows="4"
                placeholder="Document experimental observations, simulation results, or decision rationale..."
                class="w-full bg-[#111313] border border-[#313636] p-2 text-[#EEECE5] outline-hidden focus:border-[#D9B62F]"></textarea>
            </div>

            <div class="flex items-center gap-2 pt-2">
              <button type="submit" class="px-4 py-2 bg-[#203B32] border border-[#315343] text-[#EEECE5] font-bold">
                SAVE NOTE
              </button>
              <button (click)="isAddingNote.set(false)" type="button" class="px-4 py-2 bg-[#111313] border border-[#313636] text-[#858C8B]">
                CANCEL
              </button>
            </div>
          </form>
        </div>
      }

      <!-- Main Notebook Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Logbook Notes Entries Left -->
        <div class="lg:col-span-7 space-y-4">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider">
            PROJECT LOGBOOK ENTRIES ({{ notes().length }})
          </div>

          <div class="space-y-4">
            @for (note of notes(); track note.id) {
              <div class="bg-[#191A19] border border-[#202424] p-4 space-y-2">
                <div class="flex items-center justify-between text-[10px] text-[#858C8B] border-b border-[#202424] pb-1">
                  <span>{{ note.date }} · {{ note.author }}</span>
                  <span class="text-[#D9B62F] font-bold">{{ note.projectCode }}</span>
                </div>

                <div class="text-sm font-bold text-[#EEECE5] font-sans">
                  {{ note.title }}
                </div>

                <div class="text-xs text-[#858C8B] leading-relaxed">
                  {{ note.content }}
                </div>

                <div class="flex flex-wrap gap-1 pt-1 text-[9px]">
                  @for (tag of note.tags; track tag) {
                    <span class="px-1.5 py-0.5 bg-[#111313] border border-[#313636] text-[#4A7287]">
                      #{{ tag }}
                    </span>
                  }
                </div>
              </div>
            }
          </div>
        </div>

        <!-- R Quantitative Script Modules Right -->
        <div class="lg:col-span-5 bg-[#191A19] border border-[#202424] p-5 space-y-4">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
            <span>R STATISTICAL MODULES</span>
            <span class="text-[#315343] font-bold text-[10px]">tidyverse v2.0</span>
          </div>

          <div class="space-y-3 text-xs">
            <div class="bg-[#111313] border border-[#313636] p-3 space-y-1">
              <div class="font-bold text-[#4A7287]">tyre_performance(project_id)</div>
              <div class="text-[10px] text-[#858C8B]">Calculates multi-variate non-linear regression for wet grip vs rolling resistance trade-off.</div>
            </div>

            <div class="bg-[#111313] border border-[#313636] p-3 space-y-1">
              <div class="font-bold text-[#4A7287]">contact_patch_pressure(load, press)</div>
              <div class="text-[10px] text-[#858C8B]">Computes 2D spatial stress integration and peak footprint pressure gradient.</div>
            </div>

            <div class="bg-[#111313] border border-[#313636] p-3 space-y-1">
              <div class="font-bold text-[#4A7287]">wear_model_decay(mileage)</div>
              <div class="text-[10px] text-[#858C8B]">Survival analysis and tread depth depletion curve fitting over 40,000 km.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class NotebookView {
  readonly labService = inject(TyreLabService);
  readonly isAddingNote = signal<boolean>(false);

  readonly noteForm = new FormGroup({
    title: new FormControl('', [Validators.required]),
    content: new FormControl('', [Validators.required])
  });

  get notes() {
    return () => this.labService.notes();
  }

  saveNote() {
    if (this.noteForm.valid) {
      const title = this.noteForm.value.title || '';
      const content = this.noteForm.value.content || '';
      this.labService.addNote(title, content, ['Experimental', 'R&D Log']);
      this.noteForm.reset();
      this.isAddingNote.set(false);
    }
  }
}
