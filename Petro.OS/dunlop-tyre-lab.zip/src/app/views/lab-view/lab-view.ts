import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TyreLabService, ViewMode } from '../../services/tyre-lab.service';
import { ThreeTyreViewport } from '../../components/3d-tyre-viewport/3d-tyre-viewport';
import { ContactPatchCanvas } from '../../components/contact-patch-canvas/contact-patch-canvas';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-lab-view',
  imports: [ThreeTyreViewport, ContactPatchCanvas, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Workstation Header Status Bar -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">ACTIVE ENGINEERING WORKSTATION</div>
          <div class="text-lg font-extrabold text-[#EEECE5] tracking-tight font-sans">
            {{ labService.activeProject().name }}
          </div>
          <div class="text-xs text-[#D9B62F] flex items-center gap-2 mt-0.5">
            <span>CODE: {{ labService.activeProject().code }}</span>
            <span>·</span>
            <span>STATUS: {{ labService.activeProject().status }}</span>
            <span>·</span>
            <span>{{ labService.activeProject().version }}</span>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button (click)="labService.setView('designer')" class="px-3 py-1.5 bg-[#203B32] border border-[#315343] hover:bg-[#315343] text-xs font-bold transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">edit</mat-icon>
            <span>EDIT GEOMETRY</span>
          </button>
          <button (click)="labService.setView('factory')" class="px-3 py-1.5 bg-[#294A5A] border border-[#4A7287] hover:bg-[#4A7287] text-xs font-bold transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">factory</mat-icon>
            <span>SEND TO FACTORY</span>
          </button>
        </div>
      </div>

      <!-- Quick Telemetry Metric Cards -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
        <div class="bg-[#191A19] border border-[#202424] p-3 space-y-1">
          <div class="text-[10px] text-[#858C8B]">TYRE DIMENSION</div>
          <div class="text-sm font-extrabold text-[#D9B62F] font-sans">
            {{ labService.activeProject().geometry.sectionWidth }}/{{ labService.activeProject().geometry.aspectRatio }} R{{ labService.activeProject().geometry.rimDiameter }}
          </div>
          <div class="text-[10px] text-[#5F6666]">OD: {{ labService.calculatedDiameter() }} mm</div>
        </div>

        <div class="bg-[#191A19] border border-[#202424] p-3 space-y-1">
          <div class="text-[10px] text-[#858C8B]">TREAD VOID RATIO</div>
          <div class="text-sm font-extrabold text-[#EEECE5] font-sans">
            {{ labService.activeProject().tread.voidRatio }}%
          </div>
          <div class="text-[10px] text-[#315343]">EVAC: {{ labService.activeProject().tread.aquaplaningSpeedKmH }} km/h</div>
        </div>

        <div class="bg-[#191A19] border border-[#202424] p-3 space-y-1">
          <div class="text-[10px] text-[#858C8B]">COMPOUND MATRIX</div>
          <div class="text-sm font-extrabold text-[#EEECE5] font-sans">
            {{ labService.activeProject().compound.code }}
          </div>
          <div class="text-[10px] text-[#4A7287]">WET GRIP μ: {{ labService.activeProject().compound.wetGripIndex }}</div>
        </div>

        <div class="bg-[#191A19] border border-[#202424] p-3 space-y-1">
          <div class="text-[10px] text-[#858C8B]">CONTACT AREA</div>
          <div class="text-sm font-extrabold text-[#D9B62F] font-sans">
            {{ labService.activeProject().simulation.contactPatchAreaCm2 }} cm²
          </div>
          <div class="text-[10px] text-[#858C8B]">LOAD: {{ labService.activeProject().simulation.loadKg }} kg</div>
        </div>

        <div class="bg-[#191A19] border border-[#202424] p-3 space-y-1">
          <div class="text-[10px] text-[#858C8B]">100-0 BRAKING</div>
          <div class="text-sm font-extrabold text-[#EEECE5] font-sans">
            {{ labService.activeProject().simulation.stoppingDistance100to0M }} m
          </div>
          <div class="text-[10px] text-[#315343]">DRY ASPHALT</div>
        </div>

        <div class="bg-[#191A19] border border-[#202424] p-3 space-y-1">
          <div class="text-[10px] text-[#858C8B]">FACTORY LINE</div>
          <div class="text-sm font-extrabold text-[#315343] font-sans">
            LINE 04 ACTIVE
          </div>
          <div class="text-[10px] text-[#858C8B]">CURING CP-0482</div>
        </div>
      </div>

      <!-- Main Visual Grid: 3D Tyre Viewport & Contact Patch Heatmap -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <app-3d-tyre-viewport></app-3d-tyre-viewport>
        <app-contact-patch-canvas></app-contact-patch-canvas>
      </div>

      <!-- Signature 16-Step Closed Loop R&D Workflow Bar -->
      <div class="bg-[#191A19] border border-[#202424] p-4 space-y-3">
        <div class="flex items-center justify-between text-xs">
          <span class="font-bold text-[#EEECE5] flex items-center gap-2">
            <mat-icon class="text-[#D9B62F] text-sm">loop</mat-icon>
            SIGNATURE END-TO-END R&D CONTINUITY LOOP
          </span>
          <span class="text-[10px] text-[#858C8B]">16 INTEGRATED STAGES</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 text-[10px]">
          @for (step of loopSteps; track step.num) {
            <button
              (click)="labService.setView(step.targetView)"
              class="p-2 bg-[#111313] border border-[#202424] hover:border-[#D9B62F] text-left transition-colors space-y-1 group">
              <div class="flex justify-between text-[#858C8B] group-hover:text-[#D9B62F]">
                <span>S-{{ step.num }}</span>
                <mat-icon class="text-xs">{{ step.icon }}</mat-icon>
              </div>
              <div class="font-bold text-[#EEECE5] truncate">{{ step.title }}</div>
            </button>
          }
        </div>
      </div>
    </div>
  `
})
export class LabView {
  readonly labService = inject(TyreLabService);

  readonly loopSteps: { num: string; title: string; targetView: ViewMode; icon: string }[] = [
    { num: '01', title: 'Dimensions', targetView: 'designer', icon: 'aspect_ratio' },
    { num: '02', title: 'Tread Design', targetView: 'tread', icon: 'texture' },
    { num: '03', title: 'Compound', targetView: 'compound', icon: 'science' },
    { num: '04', title: 'Structure', targetView: 'structure', icon: 'layers' },
    { num: '05', title: 'Footprint', targetView: 'simulation', icon: 'grid_on' },
    { num: '06', title: 'Vehicle Fit', targetView: 'vehicle', icon: 'directions_car' },
    { num: '07', title: 'Wet Test', targetView: 'test', icon: 'speed' },
    { num: '08', title: 'Compare', targetView: 'comparison', icon: 'compare_arrows' },
    { num: '09', title: 'Approval', targetView: 'lab', icon: 'verified' },
    { num: '10', title: 'Factory Line', targetView: 'factory', icon: 'factory' },
    { num: '11', title: 'Extrusion', targetView: 'factory', icon: 'settings' },
    { num: '12', title: 'Curing Press', targetView: 'factory', icon: 'local_fire_department' },
    { num: '13', title: 'Vision QC', targetView: 'quality', icon: 'center_focus_strong' },
    { num: '14', title: 'Passport', targetView: 'passport', icon: 'qr_code_2' },
    { num: '15', title: 'Wear Life', targetView: 'wear', icon: 'tire_repair' },
    { num: '16', title: 'Closed Loop', targetView: 'notebook', icon: 'replay' }
  ];
}
