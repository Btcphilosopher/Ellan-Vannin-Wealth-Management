import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-drawing-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#111313]">
      <!-- Drawing Header Control Bar -->
      <div class="bg-[#EEECE5] border border-[#B8BCB8] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#5F6666] tracking-widest uppercase">DUNLOP TECHNICAL DRAWING OFFICE</div>
          <div class="text-xl font-extrabold text-[#111313] tracking-tight font-sans">
            ISO ENGINEERING BLUEPRINT — {{ active().code }}
          </div>
          <div class="text-xs text-[#5F6666] mt-0.5">
            DRAWING NO: DWG-DNL-2026-0418 · SCALE 1:1 · ISO 128 TECHNICAL STANDARDS
          </div>
        </div>

        <!-- Revision Control -->
        <div class="flex items-center gap-2">
          @for (rev of ['REV A', 'REV B', 'REV C (ACTIVE)']; track rev) {
            <button
              (click)="selectedRev.set(rev)"
              class="px-2.5 py-1 border text-xs font-bold transition-colors"
              [class.bg-[#111313]]="selectedRev() === rev"
              [class.text-[#EEECE5]]="selectedRev() === rev"
              [class.border-[#111313]]="selectedRev() === rev"
              [class.bg-transparent]="selectedRev() !== rev"
              [class.text-[#5F6666]]="selectedRev() !== rev"
              [class.border-[#B8BCB8]]="selectedRev() !== rev">
              {{ rev }}
            </button>
          }
        </div>
      </div>

      <!-- Main Blueprint Paper Area -->
      <div class="bg-[#F3F0E8] border-2 border-[#111313] p-8 space-y-6 shadow-md">
        <!-- ISO Blueprint SVG Frame -->
        <div class="border-2 border-[#111313] p-6 relative bg-white">
          <div class="flex justify-between text-xs font-bold border-b border-[#111313] pb-2 mb-4">
            <span>DUNLOP TYRE LAB — BIRMINGHAM R&D</span>
            <span>PROJECTION: FIRST ANGLE</span>
          </div>

          <!-- Technical Drawing SVG -->
          <div class="my-6 flex justify-center">
            <svg width="600" height="300" viewBox="0 0 600 300" class="border border-[#B8BCB8] bg-[#FAF8F5]">
              <!-- Center Axis Line -->
              <line x1="300" y1="20" x2="300" y2="280" stroke="#294A5A" stroke-width="1" stroke-dasharray="8 4" />
              <line x1="20" y1="150" x2="580" y2="150" stroke="#294A5A" stroke-width="1" stroke-dasharray="8 4" />

              <!-- Cross Section Outline Left & Right -->
              <path d="M 200 240 C 150 180, 160 60, 300 60 C 440 60, 450 180, 400 240 Z" fill="none" stroke="#111313" stroke-width="2.5" />
              
              <!-- Belt Hatching -->
              <path d="M 220 75 L 380 75" stroke="#315343" stroke-width="2" stroke-dasharray="3" />
              <path d="M 225 80 L 375 80" stroke="#315343" stroke-width="2" stroke-dasharray="3" />

              <!-- ISO Dimension Lines & Arrows -->
              <!-- Width Callout -->
              <line x1="160" y1="30" x2="440" y2="30" stroke="#111313" stroke-width="1" />
              <text x="300" y="25" text-anchor="middle" fill="#111313" font-size="10" font-family="monospace" font-weight="bold">SECTION WIDTH {{ active().geometry.sectionWidth }} ± 1.0 mm</text>

              <!-- Height Callout -->
              <line x1="470" y1="60" x2="470" y2="240" stroke="#111313" stroke-width="1" />
              <text x="480" y="150" text-anchor="start" fill="#111313" font-size="9" font-family="monospace">OD {{ active().geometry.overallDiameter }} mm</text>
            </svg>
          </div>

          <!-- ISO Title Block (Bottom Right) -->
          <div class="mt-6 border-2 border-[#111313] grid grid-cols-4 text-[10px] font-mono">
            <div class="p-2 border-r border-[#111313]">
              <div class="text-[#5F6666]">DESIGNER</div>
              <div class="font-bold">DR. A. PENDELTON</div>
            </div>
            <div class="p-2 border-r border-[#111313]">
              <div class="text-[#5F6666]">APPROVED</div>
              <div class="font-bold">CHIEF ENGINEER</div>
            </div>
            <div class="p-2 border-r border-[#111313]">
              <div class="text-[#5F6666]">DATE</div>
              <div class="font-bold">2026-09-28</div>
            </div>
            <div class="p-2 bg-[#EEECE5]">
              <div class="text-[#5F6666]">DRAWING REV</div>
              <div class="font-bold text-[#111313]">{{ selectedRev() }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DrawingView {
  readonly labService = inject(TyreLabService);
  readonly selectedRev = signal<string>('REV C (ACTIVE)');

  get active() {
    return () => this.labService.activeProject();
  }
}
