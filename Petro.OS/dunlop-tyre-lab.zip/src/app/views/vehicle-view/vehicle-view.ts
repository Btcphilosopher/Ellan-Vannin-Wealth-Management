import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-vehicle-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP PERFORMANCE MODULE</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            VEHICLE DYNAMICS & ROAD SURFACE DIGITAL TWIN
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Integrate four-wheel tyre dynamics onto vehicle suspension, weight transfer & road surface friction
          </div>
        </div>

        <!-- Active Vehicle Badge -->
        <div class="px-3 py-1 bg-[#203B32] border border-[#315343] text-xs text-[#D9B62F] font-bold">
          TEST CAR: {{ selectedVehicle().name }}
        </div>
      </div>

      <!-- Main Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Vehicle & Surface Selection Left -->
        <div class="lg:col-span-5 space-y-4">
          <!-- Vehicle Selector Card -->
          <div class="bg-[#191A19] border border-[#202424] p-4 space-y-3">
            <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider">
              SELECT VEHICLE MODEL
            </div>

            <div class="space-y-2 text-xs">
              @for (v of vehicles; track v.id) {
                <button
                  (click)="selectedVehicle.set(v)"
                  class="w-full p-3 text-left border transition-colors flex items-center justify-between"
                  [class.bg-[#203B32]]="selectedVehicle().id === v.id"
                  [class.border-[#315343]]="selectedVehicle().id === v.id"
                  [class.text-[#EEECE5]]="selectedVehicle().id === v.id"
                  [class.bg-[#111313]]="selectedVehicle().id !== v.id"
                  [class.border-[#202424]]="selectedVehicle().id !== v.id"
                  [class.text-[#858C8B]]="selectedVehicle().id !== v.id">
                  <div>
                    <div class="font-bold text-[#EEECE5]">{{ v.name }}</div>
                    <div class="text-[10px] text-[#858C8B]">{{ v.massKg }} kg | {{ v.powerBhp }} BHP | {{ v.drive }}</div>
                  </div>
                  <mat-icon class="text-sm text-[#D9B62F]">directions_car</mat-icon>
                </button>
              }
            </div>
          </div>

          <!-- Road Surface Selector Card -->
          <div class="bg-[#191A19] border border-[#202424] p-4 space-y-3">
            <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider">
              SELECT ROAD SURFACE
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs">
              @for (s of surfaces; track s.id) {
                <button
                  (click)="selectedSurface.set(s)"
                  class="p-2.5 text-left border transition-colors space-y-1"
                  [class.bg-[#294A5A]]="selectedSurface().id === s.id"
                  [class.border-[#4A7287]]="selectedSurface().id === s.id"
                  [class.text-[#EEECE5]]="selectedSurface().id === s.id"
                  [class.bg-[#111313]]="selectedSurface().id !== s.id"
                  [class.border-[#202424]]="selectedSurface().id !== s.id"
                  [class.text-[#858C8B]]="selectedSurface().id !== s.id">
                  <div class="font-bold truncate">{{ s.name }}</div>
                  <div class="text-[10px] text-[#D9B62F]">FRICTION μ: {{ s.frictionMu }}</div>
                </button>
              }
            </div>
          </div>
        </div>

        <!-- 4-Wheel Vehicle Telemetry Map Right -->
        <div class="lg:col-span-7 bg-[#191A19] border border-[#202424] p-5 space-y-5 flex flex-col justify-between">
          <div>
            <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
              <span>FOUR-WHEEL TELEMETRY & TYRE TEMPERATURES</span>
              <span class="text-[#315343] font-bold text-[10px]">DYNAMIC LOAD SHIFT</span>
            </div>

            <!-- Vehicle 4-Wheel Top View Diagram -->
            <div class="my-6 flex justify-center">
              <div class="w-72 h-80 bg-[#111313] border border-[#313636] relative flex items-center justify-center">
                <!-- Vehicle Body Outline -->
                <div class="w-36 h-64 border-2 border-[#5F6666] rounded-2xl relative flex items-center justify-center">
                  <span class="text-[10px] text-[#858C8B] font-mono">GT DEV CAR</span>

                  <!-- Front Left Wheel -->
                  <div class="absolute -top-3 -left-6 w-8 h-16 bg-[#191A19] border-2 border-[#315343] flex flex-col items-center justify-center text-[8px] text-[#D9B62F]">
                    <span>FL</span>
                    <span class="font-bold">88.4°C</span>
                  </div>

                  <!-- Front Right Wheel -->
                  <div class="absolute -top-3 -right-6 w-8 h-16 bg-[#191A19] border-2 border-[#315343] flex flex-col items-center justify-center text-[8px] text-[#D9B62F]">
                    <span>FR</span>
                    <span class="font-bold">91.2°C</span>
                  </div>

                  <!-- Rear Left Wheel -->
                  <div class="absolute -bottom-3 -left-6 w-8 h-16 bg-[#191A19] border-2 border-[#315343] flex flex-col items-center justify-center text-[8px] text-[#D9B62F]">
                    <span>RL</span>
                    <span class="font-bold">84.1°C</span>
                  </div>

                  <!-- Rear Right Wheel -->
                  <div class="absolute -bottom-3 -right-6 w-8 h-16 bg-[#191A19] border-2 border-[#315343] flex flex-col items-center justify-center text-[8px] text-[#D9B62F]">
                    <span>RR</span>
                    <span class="font-bold">86.0°C</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Dynamic Output Metrics -->
          <div class="grid grid-cols-3 gap-3 text-xs">
            <div class="bg-[#111313] border border-[#202424] p-3">
              <div class="text-[10px] text-[#858C8B]">100-0 BRAKING</div>
              <div class="text-base font-extrabold text-[#315343]">{{ calcBrakingDistance() }} m</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3">
              <div class="text-[10px] text-[#858C8B]">LATERAL CORNERING</div>
              <div class="text-base font-extrabold text-[#D9B62F]">{{ calcLateralG() }} g</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3">
              <div class="text-[10px] text-[#858C8B]">SURFACE FRICTION</div>
              <div class="text-base font-extrabold text-[#4A7287]">μ = {{ selectedSurface().frictionMu }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class VehicleView {
  readonly labService = inject(TyreLabService);

  readonly vehicles = [
    { id: 'v1', name: 'GT Development Car 07', massKg: 1580, powerBhp: 620, drive: 'RWD (51/49 Balance)' },
    { id: 'v2', name: 'Sports Saloon Prototype', massKg: 1820, powerBhp: 480, drive: 'AWD (53/47 Balance)' },
    { id: 'v3', name: 'Supercar Challenge', massKg: 1350, powerBhp: 750, drive: 'RWD (42/58 Balance)' },
    { id: 'v4', name: 'Performance Tourer SUV', massKg: 2250, powerBhp: 550, drive: 'AWD (54/46 Balance)' }
  ];

  readonly surfaces = [
    { id: 's1', name: 'Dry Asphalt', frictionMu: 0.95 },
    { id: 's2', name: 'Wet Asphalt (3mm Water)', frictionMu: 0.68 },
    { id: 's3', name: 'Polished Concrete', frictionMu: 0.52 },
    { id: 's4', name: 'Race Track Surface', frictionMu: 1.05 },
    { id: 's5', name: 'Packed Snow', frictionMu: 0.28 }
  ];

  readonly selectedVehicle = signal(this.vehicles[0]);
  readonly selectedSurface = signal(this.surfaces[0]);

  calcBrakingDistance(): number {
    // Distance = v^2 / (2 * g * mu)
    const mu = this.selectedSurface().frictionMu;
    const mass = this.selectedVehicle().massKg;
    const baseDist = (27.78 * 27.78) / (2 * 9.81 * mu);
    return Math.round(baseDist * (1 + (mass - 1500) * 0.0002) * 10) / 10;
  }

  calcLateralG(): number {
    const mu = this.selectedSurface().frictionMu;
    return Math.round((mu * 1.15) * 100) / 100;
  }
}
