import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-wear-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP LIFECYCLE MODULE</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            TYRE LIFECYCLE & TREAD WEAR DIGITAL TWIN
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Simulate tread depth abrasion, shoulder wear, braking decay & acoustic degradation over 40,000 km
          </div>
        </div>

        <div class="text-right">
          <div class="text-xs text-[#858C8B]">SIMULATED MILEAGE</div>
          <div class="text-lg font-bold text-[#D9B62F]">{{ mileageKm().toLocaleString() }} KM</div>
        </div>
      </div>

      <!-- Scrubber Control -->
      <div class="bg-[#191A19] border border-[#202424] p-4 space-y-2">
        <div class="flex justify-between text-xs">
          <span class="text-[#858C8B]">SCRUB TYRE LIFECYCLE:</span>
          <span class="font-bold text-[#EEECE5]">{{ mileageKm().toLocaleString() }} KM / 40,000 KM</span>
        </div>
        <input
          type="range"
          min="0"
          max="40000"
          step="1000"
          [value]="mileageKm()"
          (input)="onMileageChange($event)"
          class="w-full h-2 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
      </div>

      <!-- Main Layout: Wear Metrics -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        <div class="bg-[#191A19] border border-[#202424] p-4 space-y-2">
          <div class="text-[10px] text-[#858C8B]">REMAINING TREAD DEPTH</div>
          <div class="text-2xl font-extrabold" [class.text-[#315343]]="calcTreadDepth() > 3" [class.text-[#A8443D]]="calcTreadDepth() <= 2">
            {{ calcTreadDepth() }} mm
          </div>
          <div class="text-[10px] text-[#5F6666]">Legal Minimum Limit: 1.6 mm</div>
        </div>

        <div class="bg-[#191A19] border border-[#202424] p-4 space-y-2">
          <div class="text-[10px] text-[#858C8B]">WET AQUAPLANING THRESHOLD</div>
          <div class="text-2xl font-extrabold text-[#D9B62F]">
            {{ calcAquaplaningSpeed() }} km/h
          </div>
          <div class="text-[10px] text-[#5F6666]">New State: 98.4 km/h</div>
        </div>

        <div class="bg-[#191A19] border border-[#202424] p-4 space-y-2">
          <div class="text-[10px] text-[#858C8B]">WET BRAKING DISTANCE (100-0)</div>
          <div class="text-2xl font-extrabold text-[#EEECE5]">
            {{ calcWetBraking() }} m
          </div>
          <div class="text-[10px] text-[#5F6666]">New State: 32.4 m</div>
        </div>

        <div class="bg-[#191A19] border border-[#202424] p-4 space-y-2">
          <div class="text-[10px] text-[#858C8B]">PASS-BY NOISE</div>
          <div class="text-2xl font-extrabold text-[#4A7287]">
            {{ calcNoise() }} dBA
          </div>
          <div class="text-[10px] text-[#5F6666]">New State: 68.2 dBA</div>
        </div>
      </div>
    </div>
  `
})
export class WearView {
  readonly labService = inject(TyreLabService);
  readonly mileageKm = signal<number>(5000);

  onMileageChange(event: Event) {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.mileageKm.set(val);
  }

  calcTreadDepth(): number {
    const depth = 8.2 - (this.mileageKm() / 40000) * 6.6;
    return Math.max(1.6, Math.round(depth * 10) / 10);
  }

  calcAquaplaningSpeed(): number {
    const speed = 98.4 - (this.mileageKm() / 40000) * 26.3;
    return Math.round(speed * 10) / 10;
  }

  calcWetBraking(): number {
    const dist = 32.4 + (this.mileageKm() / 40000) * 12.4;
    return Math.round(dist * 10) / 10;
  }

  calcNoise(): number {
    const noise = 68.2 + (this.mileageKm() / 40000) * 5.9;
    return Math.round(noise * 10) / 10;
  }
}
