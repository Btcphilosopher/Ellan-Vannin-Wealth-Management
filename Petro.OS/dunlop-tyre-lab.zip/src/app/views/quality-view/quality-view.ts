import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-quality-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP QUALITY MODULE</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            COMPUTER VISION & X-RAY INSPECTION TWIN
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Automated optical defect detection, belt alignment tomography & laser uniformity runout
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button (click)="runScan()" class="px-3 py-1.5 bg-[#203B32] border border-[#315343] hover:bg-[#315343] text-xs font-bold transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">center_focus_strong</mat-icon>
            <span>TRIGGER NEW VISION SCAN</span>
          </button>
        </div>
      </div>

      <!-- Main Vision Scan Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Scan Canvas Frame Left -->
        <div class="lg:col-span-7 bg-[#191A19] border border-[#202424] p-5 space-y-4">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
            <span>HIGH-RESOLUTION OPTICAL SURFACE SCANNER</span>
            <span class="text-[#315343] font-bold text-[10px]">SCANNER ONLINE</span>
          </div>

          <!-- Vision Viewport Frame -->
          <div class="relative w-full h-72 bg-[#111313] border border-[#313636] flex items-center justify-center overflow-hidden">
            <!-- Simulated Tread Surface Pattern Background -->
            <div class="w-full h-full opacity-20 bg-[radial-gradient(#858C8B_1px,transparent_1px)] [background-size:12px_12px]"></div>

            <!-- Scanning Line Animation -->
            <div class="absolute inset-x-0 h-0.5 bg-[#D9B62F] shadow-[0_0_12px_#D9B62F] animate-pulse top-1/2"></div>

            <!-- Bounding Box ML Overlay -->
            @if (activeDefect()) {
              <div
                class="absolute border-2 border-[#A8443D] bg-[#A8443D]/20 p-2 text-[10px] space-y-1 font-mono"
                [style.top.%]="activeDefect()!.yRatio * 100"
                [style.left.%]="activeDefect()!.xRatio * 100">
                <div class="bg-[#A8443D] text-[#EEECE5] px-1 font-bold">{{ activeDefect()!.defectType }}</div>
                <div class="text-[#EEECE5]">CONFIDENCE: {{ activeDefect()!.confidencePct }}%</div>
              </div>
            }

            <div class="absolute bottom-2 left-2 bg-[#191A19]/80 border border-[#313636] px-2 py-1 text-[10px] text-[#858C8B]">
              TYRE SERIAL: DNL-2026-004283 | BATCH: DL-RB-047
            </div>
          </div>
        </div>

        <!-- Scan Findings & Quarantine Workflow Right -->
        <div class="lg:col-span-5 bg-[#191A19] border border-[#202424] p-5 space-y-4">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
            <span>ML INSPECTION DECISION REPORT</span>
            <span class="text-[#A8443D] font-bold text-[10px]">REVIEW REQUIRED</span>
          </div>

          <div class="space-y-3 text-xs">
            <div class="bg-[#111313] border border-[#202424] p-3">
              <div class="text-[10px] text-[#858C8B]">DEFECT CLASSIFICATION</div>
              <div class="text-base font-bold text-[#A8443D]">MOULDING FLASH ANOMALY</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3">
              <div class="text-[10px] text-[#858C8B]">LOCATION</div>
              <div class="text-sm font-bold text-[#EEECE5]">SHOULDER ZONE (SECTOR 4)</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3">
              <div class="text-[10px] text-[#858C8B]">X-RAY BELT ALIGNMENT</div>
              <div class="text-sm font-bold text-[#315343]">SYMMETRIC (0.12 mm DEV)</div>
            </div>
          </div>

          <!-- Actions -->
          <div class="pt-2 border-t border-[#202424] grid grid-cols-3 gap-2 text-xs">
            <button (click)="decision.set('PASS')" class="p-2 bg-[#203B32] border border-[#315343] hover:bg-[#315343] text-[#EEECE5] font-bold text-center">
              PASS
            </button>
            <button (click)="decision.set('REVIEW')" class="p-2 bg-[#294A5A] border border-[#4A7287] hover:bg-[#4A7287] text-[#EEECE5] font-bold text-center">
              REVIEW
            </button>
            <button (click)="decision.set('REJECT')" class="p-2 bg-[#A8443D] border border-[#A8443D] hover:bg-red-800 text-[#EEECE5] font-bold text-center">
              QUARANTINE
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class QualityView {
  readonly labService = inject(TyreLabService);
  readonly decision = signal<'PASS' | 'REVIEW' | 'REJECT'>('REVIEW');

  get defects() {
    return () => this.labService.defects();
  }

  get activeDefect() {
    return () => this.defects()[0] || null;
  }

  runScan() {
    this.decision.set('PASS');
  }
}
