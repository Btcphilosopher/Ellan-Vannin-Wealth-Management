import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { ContactPatchCanvas } from '../../components/contact-patch-canvas/contact-patch-canvas';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-simulation-view',
  imports: [ContactPatchCanvas, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP SIMULATION LAB</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            COMPUTATIONAL MECHANICS & FOOTPRINT DEFORMATION
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            DETERMINISTIC COMPUTATIONAL SIMULATION SEED: DUNLOP-TYRE-LAB-2026
          </div>
        </div>

        <!-- Scenario Presets -->
        <div class="flex items-center gap-2">
          <button (click)="applyScenario('DRY_HIGH_G')" class="px-2.5 py-1 bg-[#111313] border border-[#313636] hover:border-[#D9B62F] text-xs">
            Dry High-G
          </button>
          <button (click)="applyScenario('WET_BRAKING')" class="px-2.5 py-1 bg-[#111313] border border-[#313636] hover:border-[#D9B62F] text-xs">
            Wet Braking
          </button>
          <button (click)="applyScenario('LOW_PRESSURE')" class="px-2.5 py-1 bg-[#111313] border border-[#313636] hover:border-[#D9B62F] text-xs">
            Low Pressure
          </button>
        </div>
      </div>

      <!-- Main Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Contact Patch Heatmap Canvas -->
        <div class="lg:col-span-7">
          <app-contact-patch-canvas></app-contact-patch-canvas>
        </div>

        <!-- Simulation Results Dashboard Right -->
        <div class="lg:col-span-5 bg-[#191A19] border border-[#202424] p-5 space-y-4 font-mono">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
            <span>SIMULATION TELEMETRY OUTPUTS</span>
            <span class="text-[#315343] font-bold text-[10px]">VERIFIED MODEL</span>
          </div>

          <div class="space-y-3 text-xs">
            <div class="bg-[#111313] border border-[#202424] p-3 flex justify-between items-center">
              <div>
                <div class="text-[10px] text-[#858C8B]">FOOTPRINT CONTACT AREA</div>
                <div class="text-base font-bold text-[#D9B62F]">{{ sim().contactPatchAreaCm2 }} cm²</div>
              </div>
              <mat-icon class="text-[#D9B62F]">aspect_ratio</mat-icon>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3 flex justify-between items-center">
              <div>
                <div class="text-[10px] text-[#858C8B]">PEAK TREAD PRESSURE</div>
                <div class="text-base font-bold text-[#A8443D]">{{ sim().peakPressureMpa }} MPa</div>
              </div>
              <mat-icon class="text-[#A8443D]">compress</mat-icon>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3 flex justify-between items-center">
              <div>
                <div class="text-[10px] text-[#858C8B]">100-0 KM/H STOPPING DISTANCE</div>
                <div class="text-base font-bold text-[#315343]">{{ sim().stoppingDistance100to0M }} meters</div>
              </div>
              <mat-icon class="text-[#315343]">speed</mat-icon>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3 flex justify-between items-center">
              <div>
                <div class="text-[10px] text-[#858C8B]">CARCASS CORE TEMPERATURE</div>
                <div class="text-base font-bold text-[#C18B35]">{{ sim().carcassTempC }} °C</div>
              </div>
              <mat-icon class="text-[#C18B35]">device_thermostat</mat-icon>
            </div>
          </div>

          <!-- Synthetic Validation Note -->
          <div class="bg-[#111313] border border-[#202424] p-3 text-[10px] text-[#858C8B] leading-relaxed">
            <div class="text-[#EEECE5] font-bold">SYNTHETIC MODEL DISCLAIMER:</div>
            <div>All stress distributions and friction vectors are produced by simplified deterministic engineering models for digital-twin research.</div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class SimulationView {
  readonly labService = inject(TyreLabService);

  get sim() {
    return () => this.labService.activeProject().simulation;
  }

  applyScenario(scenario: 'DRY_HIGH_G' | 'WET_BRAKING' | 'LOW_PRESSURE') {
    if (scenario === 'DRY_HIGH_G') {
      this.labService.updateSimulationParams({
        loadKg: 850,
        pressureBar: 2.50,
        slipAngleDeg: 6.5,
        camberDeg: -2.5,
        roadSurface: 'Dry Asphalt'
      });
    } else if (scenario === 'WET_BRAKING') {
      this.labService.updateSimulationParams({
        loadKg: 650,
        pressureBar: 2.30,
        slipAngleDeg: 1.2,
        camberDeg: -1.0,
        roadSurface: 'Wet Asphalt'
      });
    } else if (scenario === 'LOW_PRESSURE') {
      this.labService.updateSimulationParams({
        loadKg: 700,
        pressureBar: 1.60,
        slipAngleDeg: 2.0,
        camberDeg: -0.5,
        roadSurface: 'Dry Asphalt'
      });
    }
  }
}
