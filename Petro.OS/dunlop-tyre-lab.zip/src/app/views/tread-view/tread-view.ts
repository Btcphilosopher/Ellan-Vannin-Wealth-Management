import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-tread-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP TREAD LAB</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            COMPUTATIONAL TREAD DESIGN & HYDROPLANING LAB
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Engineered water evacuation channels, sipes, shoulder stiffness & acoustic pitch sequence
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button (click)="isFolding.set(!isFolding())" class="px-3 py-1.5 bg-[#203B32] border border-[#315343] hover:bg-[#315343] text-xs font-bold transition-colors flex items-center gap-1.5">
            <mat-icon class="text-sm">3d_rotation</mat-icon>
            <span>{{ isFolding() ? 'FLAT DRAWING' : 'FOLD TO 3D CYLINDER' }}</span>
          </button>
        </div>
      </div>

      <!-- Main Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Tread Controls Left -->
        <div class="lg:col-span-7 bg-[#191A19] border border-[#202424] p-5 space-y-5">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
            <span>TREAD PATTERN PARAMETERS</span>
            <span class="text-[#858C8B]">{{ tread().name }}</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
            <!-- Longitudinal Grooves -->
            <div class="space-y-1.5">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">LONGITUDINAL GROOVES:</span>
                <span class="font-bold text-[#EEECE5]">{{ tread().longitudinalGrooves }} channels</span>
              </div>
              <input
                type="range"
                min="2"
                max="6"
                step="1"
                [value]="tread().longitudinalGrooves"
                (input)="update('longitudinalGrooves', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Groove Width -->
            <div class="space-y-1.5">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">GROOVE WIDTH (mm):</span>
                <span class="font-bold text-[#EEECE5]">{{ tread().grooveWidth }} mm</span>
              </div>
              <input
                type="range"
                min="3.5"
                max="10.0"
                step="0.5"
                [value]="tread().grooveWidth"
                (input)="update('grooveWidth', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Sipe Density -->
            <div class="space-y-1.5">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">SIPE DENSITY:</span>
                <span class="font-bold text-[#EEECE5]">{{ tread().sipeDensity }}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                [value]="tread().sipeDensity"
                (input)="update('sipeDensity', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Channel Angle -->
            <div class="space-y-1.5">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">DRAINAGE ANGLE (°):</span>
                <span class="font-bold text-[#EEECE5]">{{ tread().channelAngle }}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="45"
                step="2"
                [value]="tread().channelAngle"
                (input)="update('channelAngle', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Shoulder Block Stiffness -->
            <div class="space-y-1.5 md:col-span-2">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">SHOULDER BLOCK STIFFNESS (MPa):</span>
                <span class="font-bold text-[#EEECE5]">{{ tread().shoulderBlockStiffness }} MPa</span>
              </div>
              <input
                type="range"
                min="20"
                max="80"
                step="2"
                [value]="tread().shoulderBlockStiffness"
                (input)="update('shoulderBlockStiffness', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>
          </div>

          <!-- Synthetic Performance Predictions -->
          <div class="pt-3 border-t border-[#202424] grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div class="bg-[#111313] border border-[#202424] p-2.5">
              <div class="text-[10px] text-[#858C8B]">VOID RATIO</div>
              <div class="text-sm font-bold text-[#D9B62F]">{{ tread().voidRatio }}%</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-2.5">
              <div class="text-[10px] text-[#858C8B]">AQUAPLANING LIMIT</div>
              <div class="text-sm font-bold text-[#315343]">{{ tread().aquaplaningSpeedKmH }} km/h</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-2.5">
              <div class="text-[10px] text-[#858C8B]">PASS-BY NOISE</div>
              <div class="text-sm font-bold text-[#EEECE5]">{{ tread().treadNoiseDb }} dBA</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-2.5">
              <div class="text-[10px] text-[#858C8B]">CORNERING STIFFNESS</div>
              <div class="text-sm font-bold text-[#4A7287]">{{ tread().dryCorneringStiffness }} N/deg</div>
            </div>
          </div>
        </div>

        <!-- Flat Drawing vs Folded 3D Animation Right -->
        <div class="lg:col-span-5 bg-[#191A19] border border-[#202424] p-5 flex flex-col justify-between">
          <div>
            <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
              <span>COMPUTATIONAL PATTERN CANVAS</span>
              <span class="text-[#315343] font-bold text-[10px]">{{ isFolding() ? 'CYLINDER WRAP' : '2D PATTERN' }}</span>
            </div>

            <!-- Tread Drawing Canvas / SVG -->
            <div class="my-6 flex items-center justify-center">
              <div
                class="w-full h-60 bg-[#111313] border border-[#313636] relative overflow-hidden flex items-center justify-center transition-all duration-700"
                [class.rounded-full]="isFolding()"
                [class.w-52]="isFolding()">
                
                <!-- SVG Tread Channel Pattern -->
                <svg width="100%" height="100%" viewBox="0 0 300 200" preserveAspectRatio="none">
                  <!-- Background Rubber Matrix -->
                  <rect width="300" height="200" fill="#191A19" />

                  <!-- Longitudinal Main Channels -->
                  @for (i of channelArray(); track $index) {
                    <rect
                      [attr.x]="40 + $index * (220 / (tread().longitudinalGrooves + 1))"
                      y="0"
                      [attr.width]="tread().grooveWidth * 1.5"
                      height="200"
                      fill="#111313"
                      stroke="#202424" />
                  }

                  <!-- Lateral Evacuation Channels -->
                  @for (y of [30, 80, 130, 180]; track $index) {
                    <line
                      x1="10"
                      [attr.y1]="y"
                      x2="290"
                      [attr.y2]="y + tread().channelAngle"
                      stroke="#111313"
                      stroke-width="4" />
                  }

                  <!-- Water Vector Animation Dots -->
                  <circle cx="150" cy="100" r="3" fill="#4A7287" class="animate-ping" />
                </svg>

                <div class="absolute bottom-2 right-2 bg-[#191A19]/80 border border-[#313636] px-2 py-0.5 text-[9px] text-[#858C8B]">
                  GROOVES: {{ tread().longitudinalGrooves }} | ANGLE: {{ tread().channelAngle }}°
                </div>
              </div>
            </div>
          </div>

          <!-- Hydraulic Flow Vector Legend -->
          <div class="bg-[#111313] border border-[#202424] p-3 text-[10px] space-y-1">
            <div class="text-[#D9B62F] font-bold">HYDRODYNAMIC SIMULATION:</div>
            <div class="text-[#858C8B]">Water film depth 3.0 mm @ 100 km/h: Channel evacuation capacity = 28.4 Liters/sec per tyre.</div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TreadView {
  readonly labService = inject(TyreLabService);
  readonly isFolding = signal<boolean>(false);

  get tread() {
    return () => this.labService.activeProject().tread;
  }

  get channelArray() {
    return () => Array.from({ length: this.tread().longitudinalGrooves });
  }

  update(key: string, event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.labService.updateTread({ [key]: val });
  }
}
