import { ChangeDetectionStrategy, Component, ElementRef, inject, OnInit, ViewChild, effect } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-compound-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP COMPOUND LAB</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            RUBBER COMPOUND & VISCOELASTIC DIGITAL TWIN
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Polymer matrix, silica coupling silane agents, glass transition & Tan Delta hysteresis curves
          </div>
        </div>

        <div class="flex items-center gap-2">
          <div class="px-3 py-1 bg-[#203B32] border border-[#315343] text-xs text-[#D9B62F] font-bold">
            FORMULA: {{ cmp().code }}
          </div>
        </div>
      </div>

      <!-- Main Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Formulation Controls Left -->
        <div class="lg:col-span-6 bg-[#191A19] border border-[#202424] p-5 space-y-5">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
            <span>RUBBER MATRIX FORMULATION</span>
            <span class="text-[#858C8B]">{{ cmp().name }}</span>
          </div>

          <div class="space-y-4 text-xs">
            <!-- Natural Rubber -->
            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">NATURAL RUBBER (NR):</span>
                <span class="font-bold text-[#EEECE5]">{{ cmp().naturalRubberPct }}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="60"
                step="5"
                [value]="cmp().naturalRubberPct"
                (input)="update('naturalRubberPct', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Synthetic SBR -->
            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">SYNTHETIC SBR / BR:</span>
                <span class="font-bold text-[#EEECE5]">{{ cmp().syntheticSbrPct }}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="50"
                step="5"
                [value]="cmp().syntheticSbrPct"
                (input)="update('syntheticSbrPct', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Silica -->
            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">FUNCTIONALIZED SILICA:</span>
                <span class="font-bold text-[#315343]">{{ cmp().silicaPct }}%</span>
              </div>
              <input
                type="range"
                min="5"
                max="45"
                step="5"
                [value]="cmp().silicaPct"
                (input)="update('silicaPct', $event)"
                class="w-full h-1 bg-[#111313] accent-[#315343] cursor-pointer" />
            </div>

            <!-- Carbon Black -->
            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">CARBON BLACK (N234):</span>
                <span class="font-bold text-[#EEECE5]">{{ cmp().carbonBlackPct }}%</span>
              </div>
              <input
                type="range"
                min="5"
                max="30"
                step="5"
                [value]="cmp().carbonBlackPct"
                (input)="update('carbonBlackPct', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>
          </div>

          <!-- Synthetic Index Output Cards -->
          <div class="pt-3 border-t border-[#202424] grid grid-cols-2 gap-3 text-xs">
            <div class="bg-[#111313] border border-[#202424] p-3">
              <div class="text-[10px] text-[#858C8B]">WET GRIP INDEX</div>
              <div class="text-base font-extrabold text-[#315343]">{{ cmp().wetGripIndex }}</div>
              <div class="text-[9px] text-[#5F6666]">Target >= 0.85</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3">
              <div class="text-[10px] text-[#858C8B]">ROLLING RESISTANCE INDEX</div>
              <div class="text-base font-extrabold text-[#D9B62F]">{{ cmp().rollingResistanceIndex }}</div>
              <div class="text-[9px] text-[#5F6666]">Lower = More Efficient</div>
            </div>
          </div>
        </div>

        <!-- Dynamic Mechanical Analysis (DMA) Tan Delta Curve Canvas Right -->
        <div class="lg:col-span-6 bg-[#191A19] border border-[#202424] p-5 flex flex-col justify-between">
          <div>
            <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
              <span>VISCOELASTIC DMA HYSTERESIS CURVE</span>
              <span class="text-[#858C8B] text-[10px]">Tan δ vs TEMP (°C)</span>
            </div>

            <!-- Canvas for Tan Delta Curve -->
            <div class="my-4 bg-[#111313] border border-[#313636] p-3 flex justify-center">
              <canvas #dmaCanvas width="380" height="200" class="border border-[#202424]"></canvas>
            </div>
          </div>

          <!-- Curve Annotations -->
          <div class="bg-[#111313] border border-[#202424] p-3 text-[10px] space-y-1">
            <div class="flex justify-between">
              <span class="text-[#315343] font-bold">PEAK Tan δ @ 0°C (WET GRIP):</span>
              <span class="text-[#EEECE5]">0.48 (High Hysteresis Friction)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#D9B62F] font-bold">VALLEY Tan δ @ 60°C (ROLLING RESIST):</span>
              <span class="text-[#EEECE5]">0.12 (Low Energy Loss)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CompoundView implements OnInit {
  @ViewChild('dmaCanvas', { static: true }) dmaCanvasRef!: ElementRef<HTMLCanvasElement>;

  readonly labService = inject(TyreLabService);

  get cmp() {
    return () => this.labService.activeProject().compound;
  }

  constructor() {
    effect(() => {
      const c = this.labService.activeProject().compound;
      if (this.dmaCanvasRef) {
        this.drawCurve(c);
      }
    });
  }

  ngOnInit() {
    this.drawCurve(this.labService.activeProject().compound);
  }

  update(key: string, event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.labService.updateCompound({ [key]: val });
  }

  private drawCurve(cmp: any) {
    const canvas = this.dmaCanvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Axes & Grid
    ctx.strokeStyle = '#202424';
    ctx.lineWidth = 1;
    for (let x = 40; x < canvas.width; x += 60) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height - 20);
      ctx.stroke();
    }

    // Baseline
    ctx.strokeStyle = '#5F6666';
    ctx.beginPath();
    ctx.moveTo(30, canvas.height - 20);
    ctx.lineTo(canvas.width - 10, canvas.height - 20);
    ctx.stroke();

    // Temperature Axis Labels (-40, 0, 60, 100 °C)
    ctx.fillStyle = '#858C8B';
    ctx.font = '9px monospace';
    ctx.fillText('-40°C', 35, canvas.height - 5);
    ctx.fillText('0°C (Wet)', 120, canvas.height - 5);
    ctx.fillText('60°C (Rolling)', 240, canvas.height - 5);
    ctx.fillText('100°C', 330, canvas.height - 5);

    // Draw Tan Delta Curve
    ctx.strokeStyle = '#D9B62F';
    ctx.lineWidth = 2.5;
    ctx.beginPath();

    const wetPeakY = canvas.height - 20 - cmp.wetGripIndex * 150;
    const rollingY = canvas.height - 20 - (cmp.rollingResistanceIndex * 40);

    ctx.moveTo(30, canvas.height - 30);
    ctx.bezierCurveTo(80, canvas.height - 40, 110, wetPeakY, 140, wetPeakY);
    ctx.bezierCurveTo(180, wetPeakY + 40, 230, rollingY, 280, rollingY);
    ctx.bezierCurveTo(320, rollingY, 350, canvas.height - 25, 370, canvas.height - 25);
    ctx.stroke();

    // High Hysteresis Wet Peak Marker Dot
    ctx.fillStyle = '#315343';
    ctx.beginPath();
    ctx.arc(140, wetPeakY, 5, 0, Math.PI * 2);
    ctx.fill();

    // Low Hysteresis Rolling Resistance Marker Dot
    ctx.fillStyle = '#D9B62F';
    ctx.beginPath();
    ctx.arc(280, rollingY, 5, 0, Math.PI * 2);
    ctx.fill();
  }
}
