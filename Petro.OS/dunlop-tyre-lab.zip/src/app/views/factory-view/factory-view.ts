import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-factory-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header Bar -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP FACTORY DIGITAL TWIN</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            DUNLOP UK MANUFACTURING FACILITY — BIRMINGHAM
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            4 ACTIVE LINES · 52 CURING PRESSES · 8,412 TYRES / DAY THROUGHPUT
          </div>
        </div>

        <div class="flex items-center gap-3 text-xs">
          <div class="px-3 py-1 bg-[#203B32] border border-[#315343] text-[#EEECE5] font-bold">
            QUALITY: 98.7% PASS
          </div>
          <div class="px-3 py-1 bg-[#294A5A] border border-[#4A7287] text-[#EEECE5] font-bold">
            ENERGY: 3.82 MWh
          </div>
        </div>
      </div>

      <!-- Factory Floor Flow Banner -->
      <div class="bg-[#191A19] border border-[#202424] p-4 space-y-3">
        <div class="text-xs font-bold text-[#D9B62F] uppercase tracking-wider">
          TYRE MANUFACTURING CONTINUITY FLOW
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 text-[10px]">
          <div class="p-2 bg-[#111313] border border-[#315343]">
            <div class="text-[#858C8B]">01. MIXING</div>
            <div class="font-bold text-[#EEECE5]">154.2°C</div>
          </div>
          <div class="p-2 bg-[#111313] border border-[#315343]">
            <div class="text-[#858C8B]">02. CALENDER</div>
            <div class="font-bold text-[#EEECE5]">14.2 BAR</div>
          </div>
          <div class="p-2 bg-[#111313] border border-[#315343]">
            <div class="text-[#858C8B]">03. EXTRUSION</div>
            <div class="font-bold text-[#EEECE5]">118.5°C</div>
          </div>
          <div class="p-2 bg-[#111313] border border-[#315343]">
            <div class="text-[#858C8B]">04. BEAD BUILD</div>
            <div class="font-bold text-[#EEECE5]">READY</div>
          </div>
          <div class="p-2 bg-[#111313] border border-[#315343]">
            <div class="text-[#858C8B]">05. TBM BUILD</div>
            <div class="font-bold text-[#EEECE5]">GREEN TYRE</div>
          </div>
          <div class="p-2 bg-[#111313] border border-[#D9B62F]">
            <div class="text-[#858C8B]">06. CURING</div>
            <div class="font-bold text-[#D9B62F]">168.0°C / 14m</div>
          </div>
          <div class="p-2 bg-[#111313] border border-[#315343]">
            <div class="text-[#858C8B]">07. VISION QC</div>
            <div class="font-bold text-[#315343]">PASS</div>
          </div>
          <div class="p-2 bg-[#111313] border border-[#315343]">
            <div class="text-[#858C8B]">08. PASSPORT</div>
            <div class="font-bold text-[#EEECE5]">VERIFIED</div>
          </div>
        </div>
      </div>

      <!-- Factory Machines Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
        @for (m of machines(); track m.id) {
          <div class="bg-[#191A19] border border-[#202424] p-4 space-y-3">
            <div class="flex items-center justify-between border-b border-[#202424] pb-2">
              <div>
                <div class="text-[10px] text-[#858C8B] font-mono">{{ m.lineId }} · {{ m.stage }}</div>
                <div class="font-bold text-[#EEECE5] font-sans truncate max-w-[180px]">{{ m.name }}</div>
              </div>
              <span class="px-2 py-0.5 text-[9px] bg-[#203B32] text-[#EEECE5] border border-[#315343] font-bold">
                {{ m.status }}
              </span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <span class="text-[#858C8B]">TEMP:</span>
                <span class="font-bold text-[#EEECE5] ml-1">{{ m.temperatureC }} °C</span>
              </div>
              <div>
                <span class="text-[#858C8B]">PRESS:</span>
                <span class="font-bold text-[#EEECE5] ml-1">{{ m.pressureBar }} bar</span>
              </div>
              <div>
                <span class="text-[#858C8B]">UNITS/HR:</span>
                <span class="font-bold text-[#D9B62F] ml-1">{{ m.throughputUnitsPerHr }}</span>
              </div>
              <div>
                <span class="text-[#858C8B]">BEARING:</span>
                <span class="font-bold text-[#315343] ml-1">{{ m.bearingConditionPct }}%</span>
              </div>
            </div>

            <!-- Progress Bar -->
            <div class="space-y-1">
              <div class="flex justify-between text-[10px] text-[#858C8B]">
                <span>CYCLE PROGRESS:</span>
                <span class="font-bold text-[#EEECE5]">{{ m.cycleProgressPct }}%</span>
              </div>
              <div class="w-full h-1.5 bg-[#111313] border border-[#202424]">
                <div class="h-full bg-[#D9B62F]" [style.width.%]="m.cycleProgressPct"></div>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class FactoryView {
  readonly labService = inject(TyreLabService);

  get machines() {
    return () => this.labService.factoryMachines();
  }
}
