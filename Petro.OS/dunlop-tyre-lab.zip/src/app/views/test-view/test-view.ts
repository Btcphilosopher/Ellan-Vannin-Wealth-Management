import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-test-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP TEST LAB</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            PROVING GROUND TEST RECORDS & MODEL CALIBRATION
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Physical telemetry stream import, sensor alignment & simulation vs test error calibration
          </div>
        </div>

        <button (click)="runCalibration()" class="px-3 py-1.5 bg-[#315343] border border-[#315343] hover:bg-[#203B32] text-xs font-bold transition-colors flex items-center gap-1.5">
          <mat-icon class="text-sm">tune</mat-icon>
          <span>CALIBRATE SIMULATOR (ERROR {{ modelError() }}%)</span>
        </button>
      </div>

      <!-- Main Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Test Records Table Left -->
        <div class="lg:col-span-7 bg-[#191A19] border border-[#202424] p-5 space-y-4">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
            <span>PROVING GROUND TEST LOGS</span>
            <span class="text-[#858C8B] text-[10px]">3 RECENT RUNS</span>
          </div>

          <div class="space-y-2 text-xs">
            @for (t of testLogs; track t.id) {
              <div
                (click)="selectedTest.set(t)"
                class="p-3 border transition-colors cursor-pointer flex items-center justify-between"
                [class.bg-[#203B32]]="selectedTest().id === t.id"
                [class.border-[#315343]]="selectedTest().id === t.id"
                [class.bg-[#111313]]="selectedTest().id !== t.id"
                [class.border-[#202424]]="selectedTest().id !== t.id">
                <div>
                  <div class="font-bold text-[#EEECE5]">{{ t.id }} — {{ t.title }}</div>
                  <div class="text-[10px] text-[#858C8B]">{{ t.track }} | {{ t.date }} | VEHICLE: {{ t.car }}</div>
                </div>
                <div class="text-right">
                  <div class="text-xs font-bold text-[#D9B62F]">{{ t.resultGrip }} μ</div>
                  <div class="text-[10px] text-[#315343] font-bold">STATUS: COMPLETED</div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Simulation vs Test Error Alignment Right -->
        <div class="lg:col-span-5 bg-[#191A19] border border-[#202424] p-5 space-y-4 font-mono">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
            <span>MODEL VALIDATION & CALIBRATION</span>
            <span class="text-[#315343] font-bold text-[10px]">ACCURACY 98.25%</span>
          </div>

          <div class="space-y-3 text-xs">
            <div class="bg-[#111313] border border-[#202424] p-3 flex justify-between">
              <span class="text-[#858C8B]">SIMULATED GRIP COEFFICIENT:</span>
              <span class="font-bold text-[#4A7287]">0.812 μ</span>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3 flex justify-between">
              <span class="text-[#858C8B]">MEASURED TRACK GRIP:</span>
              <span class="font-bold text-[#D9B62F]">0.798 μ</span>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3 flex justify-between">
              <span class="text-[#858C8B]">MODEL RESIDUAL ERROR:</span>
              <span class="font-bold text-[#315343]">{{ modelError() }}%</span>
            </div>
          </div>

          <div class="bg-[#111313] border border-[#202424] p-3 text-[10px] text-[#858C8B] leading-relaxed">
            <div class="text-[#EEECE5] font-bold">CALIBRATION PIPELINE:</div>
            <div>Test Data Import → Outlier Removal → Time Alignment → Coefficient Optimization → Re-Run Model.</div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TestView {
  readonly labService = inject(TyreLabService);
  readonly modelError = signal<number>(1.75);

  readonly testLogs = [
    { id: 'DNL-WET-00281', title: 'High-Speed Aquaplaning Test', track: 'MIRA Proving Ground Wet Straight', date: '2026-09-22', car: 'GT Dev Car 07', resultGrip: 0.798 },
    { id: 'DNL-DRY-00104', title: 'Dry Cornering Shear Stiffness', track: 'Silverstone National Circuit', date: '2026-09-18', car: 'GT Dev Car 01', resultGrip: 0.942 },
    { id: 'DNL-AQUA-00052', title: 'Water Film Evacuation Limit', track: 'Idada Proving Ground Wet Circle', date: '2026-09-10', car: 'GT Dev Car 07', resultGrip: 0.715 }
  ];

  readonly selectedTest = signal(this.testLogs[0]);

  runCalibration() {
    this.modelError.set(0.42);
  }
}
