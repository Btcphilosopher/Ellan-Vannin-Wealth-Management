import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { TyrePassport } from '../../models/tyre.models';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-passport-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP DIGITAL PASSPORT</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            TYRE DIGITAL PASSPORT & PROVENANCE RECORD
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Cryptographic batch lineage tracking raw materials, curing cycle, uniformity & quality certificates
          </div>
        </div>

        <button (click)="issuePassport()" class="px-3 py-1.5 bg-[#203B32] border border-[#315343] hover:bg-[#315343] text-xs font-bold transition-colors flex items-center gap-1.5">
          <mat-icon class="text-sm">qr_code_2</mat-icon>
          <span>ISSUE NEW TYRE PASSPORT</span>
        </button>
      </div>

      <!-- Main Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Passport List Left -->
        <div class="lg:col-span-5 bg-[#191A19] border border-[#202424] p-4 space-y-2">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider">
            REGISTERED TYRE PASSPORTS
          </div>

          <div class="space-y-1.5 text-xs max-h-[480px] overflow-y-auto">
            @for (p of passports(); track p.serialId; let idx = $index) {
              <button
                (click)="selectedPassportIndex.set(idx)"
                class="w-full p-3 text-left border transition-colors flex items-center justify-between"
                [class.bg-[#203B32]]="selectedPassportIndex() === idx"
                [class.border-[#315343]]="selectedPassportIndex() === idx"
                [class.bg-[#111313]]="selectedPassportIndex() !== idx"
                [class.border-[#202424]]="selectedPassportIndex() !== idx">
                <div>
                  <div class="font-bold text-[#EEECE5]">{{ p.serialId }}</div>
                  <div class="text-[10px] text-[#858C8B]">{{ p.modelCode }} | {{ p.sizeLabel }}</div>
                </div>
                <span class="px-2 py-0.5 text-[9px] font-bold border"
                  [class.border-[#315343]]="p.inspectionStatus === 'PASS'"
                  [class.text-[#315343]]="p.inspectionStatus === 'PASS'"
                  [class.border-[#C18B35]]="p.inspectionStatus === 'REVIEW'"
                  [class.text-[#C18B35]]="p.inspectionStatus === 'REVIEW'">
                  {{ p.inspectionStatus }}
                </span>
              </button>
            }
          </div>
        </div>

        <!-- Passport Card Inspector Right -->
        <div class="lg:col-span-7 bg-[#191A19] border border-[#202424] p-5 space-y-5">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
            <span>OFFICIAL DIGITAL PASSPORT CERTIFICATE</span>
            <span class="text-[#315343] font-bold text-[10px]">PROVENANCE VERIFIED</span>
          </div>

          <!-- Digital Certificate Header -->
          <div class="bg-[#111313] border border-[#313636] p-4 flex items-center justify-between">
            <div class="space-y-1">
              <div class="text-[10px] text-[#858C8B]">TYRE SERIAL IDENTITY</div>
              <div class="text-xl font-extrabold text-[#D9B62F] font-mono">{{ activePassport().serialId }}</div>
              <div class="text-xs text-[#EEECE5]">{{ activePassport().modelCode }} — {{ activePassport().sizeLabel }}</div>
            </div>

            <!-- QR Code Graphic Placeholder -->
            <div class="w-16 h-16 bg-[#EEECE5] p-1 flex items-center justify-center">
              <div class="w-full h-full border-2 border-[#111313] flex items-center justify-center font-bold text-[#111313] text-[9px]">
                DUNLOP
              </div>
            </div>
          </div>

          <!-- Lineage Details Grid -->
          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="bg-[#111313] border border-[#202424] p-3 space-y-0.5">
              <div class="text-[10px] text-[#858C8B]">COMPOUND BATCH</div>
              <div class="font-bold text-[#EEECE5]">{{ activePassport().compoundBatch }}</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3 space-y-0.5">
              <div class="text-[10px] text-[#858C8B]">MANUFACTURING LOCATION</div>
              <div class="font-bold text-[#EEECE5]">{{ activePassport().factoryLocation }}</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3 space-y-0.5">
              <div class="text-[10px] text-[#858C8B]">BUILD TIMESTAMP</div>
              <div class="font-bold text-[#EEECE5]">{{ activePassport().buildTimestamp }}</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3 space-y-0.5">
              <div class="text-[10px] text-[#858C8B]">CURE CYCLE ID</div>
              <div class="font-bold text-[#D9B62F]">{{ activePassport().cureCycleId }}</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3 space-y-0.5">
              <div class="text-[10px] text-[#858C8B]">UNIFORMITY RUNOUT</div>
              <div class="font-bold text-[#315343]">{{ activePassport().uniformityRunoutMm }} mm</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-3 space-y-0.5">
              <div class="text-[10px] text-[#858C8B]">DYNAMIC BALANCE</div>
              <div class="font-bold text-[#315343]">{{ activePassport().dynamicBalanceGrams }} g</div>
            </div>
          </div>

          <!-- Hash Verification -->
          <div class="bg-[#111313] border border-[#202424] p-3 text-[10px] flex justify-between items-center text-[#858C8B]">
            <span>PROVENANCE HASH:</span>
            <span class="font-mono text-[#D9B62F]">{{ activePassport().provenanceHash }}</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class PassportView {
  readonly labService = inject(TyreLabService);
  readonly selectedPassportIndex = signal<number>(0);

  get passports() {
    return () => this.labService.passports();
  }

  get activePassport(): () => TyrePassport {
    return () => this.passports()[this.selectedPassportIndex()] || this.passports()[0];
  }

  issuePassport() {
    this.labService.generateNewPassport();
    this.selectedPassportIndex.set(0);
  }
}
