import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-comparison-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP COMPARISON MODULE</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            ENGINEERING CANDIDATE TRADE-OFF COMPARISON
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Side-by-side analysis of wet grip, rolling resistance, cornering stiffness, mass, energy & production cost
          </div>
        </div>

        <div class="text-xs text-[#315343] font-bold">
          COMPARING 3 CANDIDATE DESIGN ITERATIONS
        </div>
      </div>

      <!-- Main Comparison Table -->
      <div class="bg-[#191A19] border border-[#202424] p-5 overflow-x-auto">
        <table class="w-full text-left text-xs border-collapse font-mono">
          <thead>
            <tr class="border-b border-[#313636] text-[#858C8B]">
              <th class="p-3">ENGINEERING PARAMETER</th>
              <th class="p-3 bg-[#111313] text-[#D9B62F] font-bold">ACTIVE: {{ active().code }}</th>
              <th class="p-3">{{ candidates()[0].code }}</th>
              <th class="p-3">{{ candidates()[1].code }}</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-[#202424]">
            <tr>
              <td class="p-3 text-[#858C8B]">TYRE APPLICATION</td>
              <td class="p-3 bg-[#111313] font-bold text-[#EEECE5]">{{ active().application }}</td>
              <td class="p-3">{{ candidates()[0].application }}</td>
              <td class="p-3">{{ candidates()[1].application }}</td>
            </tr>
            <tr>
              <td class="p-3 text-[#858C8B]">COMPOUND CODE</td>
              <td class="p-3 bg-[#111313] font-bold text-[#315343]">{{ active().compound.code }}</td>
              <td class="p-3">{{ candidates()[0].compound.code }}</td>
              <td class="p-3">{{ candidates()[1].compound.code }}</td>
            </tr>
            <tr>
              <td class="p-3 text-[#858C8B]">TREAD VOID RATIO (%)</td>
              <td class="p-3 bg-[#111313] font-bold text-[#EEECE5]">{{ active().tread.voidRatio }}%</td>
              <td class="p-3">{{ candidates()[0].tread.voidRatio }}%</td>
              <td class="p-3">{{ candidates()[1].tread.voidRatio }}%</td>
            </tr>
            <tr>
              <td class="p-3 text-[#858C8B]">AQUAPLANING LIMIT (km/h)</td>
              <td class="p-3 bg-[#111313] font-bold text-[#315343]">{{ active().tread.aquaplaningSpeedKmH }} km/h</td>
              <td class="p-3">{{ candidates()[0].tread.aquaplaningSpeedKmH }} km/h</td>
              <td class="p-3 font-bold text-[#315343]">{{ candidates()[1].tread.aquaplaningSpeedKmH }} km/h</td>
            </tr>
            <tr>
              <td class="p-3 text-[#858C8B]">WET GRIP INDEX (0-1)</td>
              <td class="p-3 bg-[#111313] font-bold text-[#315343]">{{ active().compound.wetGripIndex }}</td>
              <td class="p-3">{{ candidates()[0].compound.wetGripIndex }}</td>
              <td class="p-3 font-bold text-[#315343]">{{ candidates()[1].compound.wetGripIndex }}</td>
            </tr>
            <tr>
              <td class="p-3 text-[#858C8B]">ROLLING RESISTANCE INDEX</td>
              <td class="p-3 bg-[#111313] font-bold text-[#D9B62F]">{{ active().compound.rollingResistanceIndex }}</td>
              <td class="p-3 font-bold text-[#315343]">{{ candidates()[0].compound.rollingResistanceIndex }}</td>
              <td class="p-3">{{ candidates()[1].compound.rollingResistanceIndex }}</td>
            </tr>
            <tr>
              <td class="p-3 text-[#858C8B]">100-0 KM/H STOPPING (m)</td>
              <td class="p-3 bg-[#111313] font-bold text-[#315343]">{{ active().simulation.stoppingDistance100to0M }} m</td>
              <td class="p-3">{{ candidates()[0].simulation.stoppingDistance100to0M }} m</td>
              <td class="p-3 font-bold text-[#315343]">{{ candidates()[1].simulation.stoppingDistance100to0M }} m</td>
            </tr>
            <tr>
              <td class="p-3 text-[#858C8B]">PASS-BY NOISE (dBA)</td>
              <td class="p-3 bg-[#111313] font-bold text-[#EEECE5]">{{ active().tread.treadNoiseDb }} dBA</td>
              <td class="p-3">{{ candidates()[0].tread.treadNoiseDb }} dBA</td>
              <td class="p-3">{{ candidates()[1].tread.treadNoiseDb }} dBA</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class ComparisonView {
  readonly labService = inject(TyreLabService);

  get active() {
    return () => this.labService.activeProject();
  }

  get candidates() {
    return () => this.labService.comparisonProjects();
  }
}
