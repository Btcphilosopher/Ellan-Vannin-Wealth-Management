import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TyreLabService } from '../../services/tyre-lab.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-designer-view',
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 font-mono text-[#EEECE5]">
      <!-- Header -->
      <div class="bg-[#191A19] border border-[#202424] p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="text-[10px] text-[#858C8B] tracking-widest uppercase">DUNLOP DESIGN MODULE</div>
          <div class="text-xl font-extrabold text-[#EEECE5] tracking-tight font-sans">
            PARAMETRIC TYRE GEOMETRY ENGINE
          </div>
          <div class="text-xs text-[#858C8B] mt-0.5">
            Construct structural dimensions, cross-section profiles, and belt angles
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button (click)="applyPreset('305/30 R20')" class="px-2.5 py-1 bg-[#111313] border border-[#313636] hover:border-[#D9B62F] text-xs">
            305/30 R20
          </button>
          <button (click)="applyPreset('245/40 R19')" class="px-2.5 py-1 bg-[#111313] border border-[#313636] hover:border-[#D9B62F] text-xs">
            245/40 R19
          </button>
          <button (click)="applyPreset('295/35 R21')" class="px-2.5 py-1 bg-[#111313] border border-[#313636] hover:border-[#D9B62F] text-xs">
            295/35 R21
          </button>
        </div>
      </div>

      <!-- Main Layout: Controls Left, 2D Section View Right -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Controls Column -->
        <div class="lg:col-span-7 bg-[#191A19] border border-[#202424] p-5 space-y-5">
          <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider">
            PRIMARY GEOMETRY PARAMETERS
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
            <!-- Section Width -->
            <div class="space-y-1.5">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">SECTION WIDTH (mm):</span>
                <span class="font-bold text-[#EEECE5]">{{ geo().sectionWidth }} mm</span>
              </div>
              <input
                type="range"
                min="205"
                max="335"
                step="5"
                [value]="geo().sectionWidth"
                (input)="update('sectionWidth', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Aspect Ratio -->
            <div class="space-y-1.5">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">ASPECT RATIO (%):</span>
                <span class="font-bold text-[#EEECE5]">{{ geo().aspectRatio }}</span>
              </div>
              <input
                type="range"
                min="25"
                max="60"
                step="5"
                [value]="geo().aspectRatio"
                (input)="update('aspectRatio', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Rim Diameter -->
            <div class="space-y-1.5">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">RIM DIAMETER (inch):</span>
                <span class="font-bold text-[#EEECE5]">{{ geo().rimDiameter }}"</span>
              </div>
              <input
                type="range"
                min="17"
                max="23"
                step="1"
                [value]="geo().rimDiameter"
                (input)="update('rimDiameter', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Tread Width -->
            <div class="space-y-1.5">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">TREAD WIDTH (mm):</span>
                <span class="font-bold text-[#EEECE5]">{{ geo().treadWidth }} mm</span>
              </div>
              <input
                type="range"
                min="180"
                max="310"
                step="2"
                [value]="geo().treadWidth"
                (input)="update('treadWidth', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Belt Angle -->
            <div class="space-y-1.5">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">STEEL BELT ANGLE (°):</span>
                <span class="font-bold text-[#EEECE5]">{{ geo().beltAngle }}°</span>
              </div>
              <input
                type="range"
                min="18"
                max="32"
                step="1"
                [value]="geo().beltAngle"
                (input)="update('beltAngle', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>

            <!-- Shoulder Radius -->
            <div class="space-y-1.5">
              <div class="flex justify-between">
                <span class="text-[#858C8B]">SHOULDER RADIUS (mm):</span>
                <span class="font-bold text-[#EEECE5]">{{ geo().shoulderRadius }} mm</span>
              </div>
              <input
                type="range"
                min="18"
                max="45"
                step="1"
                [value]="geo().shoulderRadius"
                (input)="update('shoulderRadius', $event)"
                class="w-full h-1 bg-[#111313] accent-[#D9B62F] cursor-pointer" />
            </div>
          </div>

          <!-- Synthetic Physics Outputs Card -->
          <div class="pt-3 border-t border-[#202424] grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div class="bg-[#111313] border border-[#202424] p-2.5">
              <div class="text-[10px] text-[#858C8B]">OUTSIDE DIAMETER</div>
              <div class="text-sm font-bold text-[#D9B62F]">{{ labService.calculatedDiameter() }} mm</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-2.5">
              <div class="text-[10px] text-[#858C8B]">SECTION HEIGHT</div>
              <div class="text-sm font-bold text-[#EEECE5]">{{ calcSectionHeight() }} mm</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-2.5">
              <div class="text-[10px] text-[#858C8B]">TARGET LOAD</div>
              <div class="text-sm font-bold text-[#315343]">{{ geo().targetLoadRating }} kg (103)</div>
            </div>

            <div class="bg-[#111313] border border-[#202424] p-2.5">
              <div class="text-[10px] text-[#858C8B]">SPEED INDEX</div>
              <div class="text-sm font-bold text-[#4A7287]">{{ geo().targetSpeedRating }}</div>
            </div>
          </div>
        </div>

        <!-- 2D Cross-Section Blueprint Canvas Right -->
        <div class="lg:col-span-5 bg-[#191A19] border border-[#202424] p-5 flex flex-col justify-between">
          <div>
            <div class="text-xs font-bold text-[#D9B62F] border-b border-[#202424] pb-2 uppercase tracking-wider flex justify-between">
              <span>ORTHOGRAPHIC SECTION BLUEPRINT</span>
              <span class="text-[#858C8B] font-mono text-[10px]">SYNTHETIC CAD</span>
            </div>

            <!-- SVG Cross Section Schematic -->
            <div class="my-6 flex items-center justify-center">
              <svg width="280" height="220" viewBox="0 0 280 220" class="border border-[#313636] bg-[#111313]">
                <!-- Rim Outline -->
                <rect x="70" y="160" width="140" height="40" fill="none" stroke="#858C8B" stroke-width="2" stroke-dasharray="4" />
                <text x="140" y="184" text-anchor="middle" fill="#858C8B" font-size="9" font-family="monospace">RIM {{ geo().rimDiameter }}"</text>

                <!-- Tyre Crown & Sidewall Contour -->
                <path d="M 50 160 C 30 110, 45 40, 140 40 C 235 40, 250 110, 230 160 Z" fill="none" stroke="#D9B62F" stroke-width="3" />
                
                <!-- Steel Belts Cross Layer -->
                <path d="M 70 50 L 210 50" stroke="#315343" stroke-width="2" stroke-dasharray="2" />
                <path d="M 75 54 L 205 54" stroke="#4A7287" stroke-width="2" stroke-dasharray="2" />

                <!-- Bead Rings -->
                <circle cx="50" cy="160" r="6" fill="#D9B62F" />
                <circle cx="230" cy="160" r="6" fill="#D9B62F" />

                <!-- Dimension Callouts -->
                <line x1="20" y1="40" x2="20" y2="160" stroke="#5F6666" stroke-width="1" />
                <text x="15" y="100" text-anchor="middle" fill="#858C8B" font-size="8" font-family="monospace" transform="rotate(-90 15 100)">{{ calcSectionHeight() }} mm</text>

                <line x1="50" y1="20" x2="230" y2="20" stroke="#5F6666" stroke-width="1" />
                <text x="140" y="15" text-anchor="middle" fill="#D9B62F" font-size="9" font-family="monospace">WIDTH {{ geo().sectionWidth }} mm</text>
              </svg>
            </div>
          </div>

          <div class="bg-[#111313] border border-[#202424] p-3 text-[10px] text-[#858C8B] space-y-1">
            <div class="text-[#EEECE5] font-bold">ENGINEERING NOTE:</div>
            <div>Aspect ratio {{ geo().aspectRatio }} reduces sidewall deflection during high lateral g cornering by 14.2% while increasing radial impact stiffness.</div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DesignerView {
  readonly labService = inject(TyreLabService);

  get geo() {
    return () => this.labService.activeProject().geometry;
  }

  calcSectionHeight(): number {
    return Math.round(this.geo().sectionWidth * (this.geo().aspectRatio / 100));
  }

  update(key: string, event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.labService.updateGeometry({ [key]: val });
  }

  applyPreset(size: string) {
    if (size === '305/30 R20') {
      this.labService.updateGeometry({ sectionWidth: 305, aspectRatio: 30, rimDiameter: 20, treadWidth: 280 });
    } else if (size === '245/40 R19') {
      this.labService.updateGeometry({ sectionWidth: 245, aspectRatio: 40, rimDiameter: 19, treadWidth: 220 });
    } else if (size === '295/35 R21') {
      this.labService.updateGeometry({ sectionWidth: 295, aspectRatio: 35, rimDiameter: 21, treadWidth: 270 });
    }
  }
}
