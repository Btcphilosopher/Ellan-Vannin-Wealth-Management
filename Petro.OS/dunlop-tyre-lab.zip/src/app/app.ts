import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TyreLabService } from './services/tyre-lab.service';
import { NavHeader } from './components/nav-header/nav-header';
import { CommandPalette } from './components/command-palette/command-palette';
import { ReplayBar } from './components/replay-bar/replay-bar';
import { CopilotDrawer } from './components/copilot-drawer/copilot-drawer';

// Views
import { LabView } from './views/lab-view/lab-view';
import { DesignerView } from './views/designer-view/designer-view';
import { TreadView } from './views/tread-view/tread-view';
import { CompoundView } from './views/compound-view/compound-view';
import { StructureView } from './views/structure-view/structure-view';
import { SimulationView } from './views/simulation-view/simulation-view';
import { VehicleView } from './views/vehicle-view/vehicle-view';
import { TestView } from './views/test-view/test-view';
import { WearView } from './views/wear-view/wear-view';
import { FactoryView } from './views/factory-view/factory-view';
import { QualityView } from './views/quality-view/quality-view';
import { PassportView } from './views/passport-view/passport-view';
import { ComparisonView } from './views/comparison-view/comparison-view';
import { DrawingView } from './views/drawing-view/drawing-view';
import { NotebookView } from './views/notebook-view/notebook-view';

@Component({
  selector: 'app-root',
  imports: [
    NavHeader,
    CommandPalette,
    ReplayBar,
    CopilotDrawer,
    LabView,
    DesignerView,
    TreadView,
    CompoundView,
    StructureView,
    SimulationView,
    VehicleView,
    TestView,
    WearView,
    FactoryView,
    QualityView,
    PassportView,
    ComparisonView,
    DrawingView,
    NotebookView
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly labService = inject(TyreLabService);
}
