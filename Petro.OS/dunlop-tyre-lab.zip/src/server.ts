import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Initialize Gemini API client on the Express server side
const aiKey = process.env['GEMINI_API_KEY'] || '';
const ai = aiKey ? new GoogleGenAI({
  apiKey: aiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build'
    }
  }
}) : null;

/**
 * REST API ENDPOINTS
 */

// Dunlop Engineering Copilot Endpoint
app.post('/api/copilot', async (req, res) => {
  try {
    const { prompt, context } = req.body;

    if (!prompt) {
      res.status(400).json({ error: 'Missing prompt' });
      return;
    }

    if (!ai) {
      // Fallback response if GEMINI_API_KEY is missing or not injected yet
      res.json({
        reply: `[LOCAL ANALYTICAL MODEL]: Query received for Dunlop Tyre Lab. Regarding "${prompt}": Active project ${context?.code || 'DNL-GT-27'} with compound ${context?.compound?.code || 'DL-RB-047'} shows 28.5% tread void ratio yielding 98.4 km/h wet aquaplaning threshold. Contact patch footprint is 184.2 cm² under 650 kg radial load at 2.35 bar.`,
        sourceType: 'SIMULATED RESULT'
      });
      return;
    }

    const systemInstruction = `
You are DUNLOP ENGINEERING COPILOT, a British tyre engineering AI assistant at the Dunlop Tyre Laboratory in Birmingham, UK.
You speak with professional British engineering precision, rigor, and restraint.
You have access to synthetic engineering project data:
- Active Tyre Project: ${context?.name || 'DUNLOP GT DEVELOPMENT'} (${context?.code || 'DNL-GT-27'})
- Geometry: ${context?.geometry?.sectionWidth || 305}/${context?.geometry?.aspectRatio || 30} R${context?.geometry?.rimDiameter || 20}
- Compound: ${context?.compound?.code || 'DL-RB-047'} (Silica Matrix, Wet Grip Index 0.86, Rolling Resistance 0.72)
- Tread Void Ratio: ${context?.tread?.voidRatio || 28.5}%, Hydroplaning Speed: ${context?.tread?.aquaplaningSpeedKmH || 98.4} km/h
- Simulation Contact Patch: ${context?.simulation?.contactPatchAreaCm2 || 184.2} cm², Peak Pressure: ${context?.simulation?.peakPressureMpa || 0.88} MPa, Stopping Distance: ${context?.simulation?.stoppingDistance100to0M || 32.4} m.

Guidelines:
1. Always reference actual records or exact math. Never hallucinate certified physical road test numbers.
2. Clearly distinguish between: [OBSERVED DATA], [SIMULATED RESULT], [ENGINEERING ASSUMPTION], or [MODEL PREDICTION].
3. Keep answers concise, technical, and formatted cleanly with monospaced key metrics.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.3
      }
    });

    const reply = response.text || 'Engineering analysis complete.';

    let sourceType: 'OBSERVED DATA' | 'SIMULATED RESULT' | 'ENGINEERING ASSUMPTION' | 'MODEL PREDICTION' = 'SIMULATED RESULT';
    if (reply.includes('OBSERVED')) sourceType = 'OBSERVED DATA';
    else if (reply.includes('PREDICTION')) sourceType = 'MODEL PREDICTION';
    else if (reply.includes('ASSUMPTION')) sourceType = 'ENGINEERING ASSUMPTION';

    res.json({ reply, sourceType });
    return;
  } catch (error: any) {
    console.error('Copilot API error:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
    return;
  }
});

// Synthetic Tyres List
app.get('/api/v1/tyres', (req, res) => {
  res.json({
    status: 'success',
    count: 100,
    activeModel: 'DNL-GT-27',
    models: [
      { id: 'DNL-GT-27', name: 'Dunlop Next Generation GT', size: '305/30 R20' },
      { id: 'DNL-WET-09', name: 'Dunlop Aquajet Rain Sport', size: '245/40 R19' },
      { id: 'DNL-TRK-01', name: 'Dunlop Slick Challenge', size: '295/35 R20' }
    ]
  });
});

// Serve static assets from /browser
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

// Angular SSR catch-all
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Dunlop Tyre Lab Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
