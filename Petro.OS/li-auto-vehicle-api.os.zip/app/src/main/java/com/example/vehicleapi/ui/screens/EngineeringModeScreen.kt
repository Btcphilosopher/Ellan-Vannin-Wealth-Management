package com.example.vehicleapi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LiCardBg
import com.example.ui.theme.LiCardBorder
import com.example.ui.theme.LiDarkBg
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.ui.components.MetricCard
import com.example.vehicleapi.ui.viewmodel.MainViewModel

@Composable
fun EngineeringModeScreen(viewModel: MainViewModel) {
    val locale by viewModel.currentLocale.collectAsState()
    val events by viewModel.recentEvents.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()
    val gateway = viewModel.haloGateway

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "专业工程工作台 & 安全审计日志" else "Engineering Mode Workspace & Security Audit",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MetallicGold
                )
                Text(
                    text = if (locale == AppLocale.ZH_CN) "网关抽象层: ${gateway.getGatewayName()}" else "Gateway Layer: ${gateway.getGatewayName()}",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Security Audit Log Card
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "安全审计日志 (Security Audit Log)" else "Security Audit Log",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyan
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (auditLogs.isEmpty()) {
                    Text(text = "No security audit records logged yet.", fontSize = 11.sp, color = TextMuted)
                } else {
                    auditLogs.take(15).forEach { audit ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (locale == AppLocale.ZH_CN) audit.actionZh else audit.actionEn,
                                    fontSize = 12.sp,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = audit.result,
                                    fontSize = 10.sp,
                                    color = EmeraldSuccess,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Actor: ${audit.actor} | Vehicle: ${audit.vehicleId} | IP: ${audit.clientIp}",
                                fontSize = 10.sp,
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Event Bus Stream
        Card(
            colors = CardDefaults.cardColors(containerColor = LiDarkBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "强类型车辆事件总线 (Vehicle Event Bus)" else "Typed Vehicle Event Bus Stream",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldSuccess
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (events.isEmpty()) {
                    Text(text = "Awaiting vehicle events...", fontSize = 11.sp, color = TextMuted, fontFamily = FontFamily.Monospace)
                } else {
                    events.take(15).forEach { evt ->
                        Text(
                            text = "[${evt.eventType}] vehicle=${evt.vehicleId} payload=${evt.payload}",
                            fontSize = 10.sp,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
