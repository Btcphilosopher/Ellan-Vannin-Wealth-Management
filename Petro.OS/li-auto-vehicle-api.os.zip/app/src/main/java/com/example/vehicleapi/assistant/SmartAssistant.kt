package com.example.vehicleapi.assistant

import com.example.vehicleapi.domain.VehicleState
import com.example.vehicleapi.simulation.SmartChargingOptimizer
import com.example.vehicleapi.simulation.TelemetrySimulatorEngine

data class AssistantToolResult(
    val toolName: String,
    val success: Boolean,
    val summaryZh: String,
    val summaryEn: String,
    val rawDataJson: String
)

interface SmartAssistant {
    suspend fun processIntent(userQuery: String, currentState: VehicleState): AssistantToolResult
}

class LiSmartAssistant(private val telemetryEngine: TelemetrySimulatorEngine) : SmartAssistant {
    override suspend fun processIntent(userQuery: String, currentState: VehicleState): AssistantToolResult {
        val queryLower = userQuery.lowercase()
        return when {
            queryLower.contains("battery") || queryLower.contains("soc") || queryLower.contains("电量") || queryLower.contains("电池") -> {
                AssistantToolResult(
                    toolName = "GetBatteryState",
                    success = true,
                    summaryZh = "当前电池电量为 ${String.format("%.1f", currentState.batterySOC)}%，可续航 ${currentState.estimatedRangeKm} 公里。",
                    summaryEn = "Current battery state of charge is ${String.format("%.1f", currentState.batterySOC)}%, range is ${currentState.estimatedRangeKm} km.",
                    rawDataJson = """{"soc": ${currentState.batterySOC}, "range_km": ${currentState.estimatedRangeKm}}"""
                )
            }
            queryLower.contains("climate") || queryLower.contains("ac") || queryLower.contains("空调") || queryLower.contains("温度") -> {
                AssistantToolResult(
                    toolName = "StartClimate",
                    success = true,
                    summaryZh = "已为您调整座舱空调至 22.0°C 舒享温度，开启三区净化。",
                    summaryEn = "Cabin climate adjusted to 22.0°C comfort setting with 3-zone air purification active.",
                    rawDataJson = """{"target_temp": 22.0, "status": "ACTIVE"}"""
                )
            }
            queryLower.contains("charging") || queryLower.contains("charge") || queryLower.contains("充电") -> {
                val opt = SmartChargingOptimizer.calculateOptimization(currentState.batterySOC, 80.0)
                AssistantToolResult(
                    toolName = "GetChargingState",
                    success = true,
                    summaryZh = "智能充电规划：将于 ${opt.optimalStartTimestamp} 开始谷段充电，预计 ${opt.estimatedCompletionTimestamp} 完成，节省 ${opt.offPeakSavingsPercent}% 电费。",
                    summaryEn = "Smart charging plan: Off-peak charging starts at ${opt.optimalStartTimestamp}, completing by ${opt.estimatedCompletionTimestamp}, saving ${opt.offPeakSavingsPercent}% on electricity cost.",
                    rawDataJson = """{"target_soc": 80.0, "duration_min": ${opt.chargingDurationMinutes}, "cost_cny": ${opt.totalCostCny}}"""
                )
            }
            queryLower.contains("lock") || queryLower.contains("door") || queryLower.contains("锁车") || queryLower.contains("解锁") -> {
                val isLocked = telemetryEngine.toggleLock()
                val (zh, en) = if (isLocked) "车门已成功锁止，防盗监测已开启。" to "Vehicle doors locked, anti-theft monitoring enabled."
                else "车门已解锁，座舱迎宾灯光已开启。" to "Vehicle unlocked, cabin welcome light activated."
                AssistantToolResult(
                    toolName = "LockUnlockVehicle",
                    success = true,
                    summaryZh = zh,
                    summaryEn = en,
                    rawDataJson = """{"locked": $isLocked}"""
                )
            }
            else -> {
                AssistantToolResult(
                    toolName = "GetVehicleOverview",
                    success = true,
                    summaryZh = "理想 L9 状态良好。系统：Li OS 8.2.0，电量：${currentState.batterySOC.toInt()}%，续航：${currentState.estimatedRangeKm}km，座舱：${currentState.climate.currentCabinTemperature}°C。",
                    summaryEn = "Li L9 in nominal state. System: Li OS 8.2.0, SOC: ${currentState.batterySOC.toInt()}%, Range: ${currentState.estimatedRangeKm}km, Cabin: ${currentState.climate.currentCabinTemperature}°C.",
                    rawDataJson = """{"vehicle_id": "${currentState.vehicleId}", "status": "READY"}"""
                )
            }
        }
    }
}
