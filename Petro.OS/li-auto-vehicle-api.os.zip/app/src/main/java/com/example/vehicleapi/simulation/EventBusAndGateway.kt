package com.example.vehicleapi.simulation

import com.example.vehicleapi.domain.CommandRequest
import com.example.vehicleapi.domain.CommandResponse
import com.example.vehicleapi.domain.CommandType
import com.example.vehicleapi.domain.SecurityAuditEntry
import com.example.vehicleapi.domain.VehicleEvent
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

object VehicleEventBus {
    private val _events = MutableSharedFlow<VehicleEvent>(replay = 50, extraBufferCapacity = 100)
    val events: SharedFlow<VehicleEvent> = _events.asSharedFlow()

    private val _auditLogs = MutableSharedFlow<SecurityAuditEntry>(replay = 50, extraBufferCapacity = 100)
    val auditLogs: SharedFlow<SecurityAuditEntry> = _auditLogs.asSharedFlow()

    suspend fun publishEvent(event: VehicleEvent) {
        _events.emit(event)
    }

    suspend fun publishAudit(audit: SecurityAuditEntry) {
        _auditLogs.emit(audit)
    }
}

interface HaloGateway {
    fun getGatewayName(): String
    fun isConnected(): Boolean
    suspend fun sendCommand(request: CommandRequest): CommandResponse
}

class SimulatedHaloGateway : HaloGateway {
    override fun getGatewayName(): String = "Simulated Halo OS V2 Gateway Layer (模拟 Halo OS Gateway)"
    override fun isConnected(): Boolean = true

    override suspend fun sendCommand(request: CommandRequest): CommandResponse {
        val (msgZh, msgEn) = when (request.commandType) {
            CommandType.LOCK -> "车门已锁定，防盗系统就绪" to "Vehicle locked, security armed"
            CommandType.UNLOCK -> "车门已解锁，座舱迎宾开启" to "Vehicle unlocked, welcome mode active"
            CommandType.START_CLIMATE -> "三区空调预热开启，目标温度 22.0°C" to "3-Zone climate preconditioning active at 22.0°C"
            CommandType.STOP_CLIMATE -> "空调系统已关闭" to "Climate system powered off"
            CommandType.SET_TEMPERATURE -> "座舱温度已调整至 ${request.parameters["temperature"] ?: "22.0"}°C" to "Cabin temperature adjusted to ${request.parameters["temperature"] ?: "22.0"}°C"
            CommandType.LOCATE -> "寻车指令已下发 (双闪鸣笛)" to "Locate signal triggered (horn and flash)"
            CommandType.START_CHARGING -> "充电会话开启，功率最高 100kW" to "Charging session started, up to 100kW"
            CommandType.STOP_CHARGING -> "充电已暂停" to "Charging paused"
        }

        // Publish audit
        VehicleEventBus.publishAudit(
            SecurityAuditEntry(
                actionZh = "执行车辆指令: ${request.commandType}",
                actionEn = "Executed Vehicle Command: ${request.commandType}",
                actor = request.userId,
                vehicleId = request.vehicleId,
                result = "SUCCESS"
            )
        )

        return CommandResponse(
            commandId = request.commandId,
            vehicleId = request.vehicleId,
            success = true,
            messageZh = msgZh,
            messageEn = msgEn
        )
    }
}

class DevelopmentHaloGateway : HaloGateway {
    override fun getGatewayName(): String = "Development Sandbox Halo Bridge (开发沙盒)"
    override fun isConnected(): Boolean = true
    override suspend fun sendCommand(request: CommandRequest): CommandResponse {
        return SimulatedHaloGateway().sendCommand(request)
    }
}

class FutureProductionGateway : HaloGateway {
    override fun getGatewayName(): String = "Future Production Gateway Abstraction (未来生产线抽象)"
    override fun isConnected(): Boolean = false
    override suspend fun sendCommand(request: CommandRequest): CommandResponse {
        return CommandResponse(
            commandId = request.commandId,
            vehicleId = request.vehicleId,
            success = false,
            messageZh = "生产网关需授权硬件证书 (Require Auth Cert)",
            messageEn = "Production gateway requires authorised hardware credentials"
        )
    }
}
