package com.example.vehicleapi.simulation

import com.example.vehicleapi.domain.ChargingPortStatus
import com.example.vehicleapi.domain.ChargingSession
import com.example.vehicleapi.domain.DiagnosticCode
import com.example.vehicleapi.domain.DiagnosticSeverity
import com.example.vehicleapi.domain.DriverAssistanceState
import com.example.vehicleapi.domain.EventType
import com.example.vehicleapi.domain.FamilyProfile
import com.example.vehicleapi.domain.OTALifecycleState
import com.example.vehicleapi.domain.OTADeployment
import com.example.vehicleapi.domain.PowertrainType
import com.example.vehicleapi.domain.ScenarioParams
import com.example.vehicleapi.domain.ScenarioPrediction
import com.example.vehicleapi.domain.SoftwareComponent
import com.example.vehicleapi.domain.SoftwareRelease
import com.example.vehicleapi.domain.SubsystemHealth
import com.example.vehicleapi.domain.TelemetryQuality
import com.example.vehicleapi.domain.TelemetryState
import com.example.vehicleapi.domain.UserRole
import com.example.vehicleapi.domain.Vehicle
import com.example.vehicleapi.domain.VehicleClimate
import com.example.vehicleapi.domain.VehicleDoors
import com.example.vehicleapi.domain.VehicleEvent
import com.example.vehicleapi.domain.VehiclePowertrain
import com.example.vehicleapi.domain.VehicleState
import com.example.vehicleapi.domain.VehicleStatus
import com.example.vehicleapi.domain.VehicleSuspension
import com.example.vehicleapi.domain.VehicleTyrePressure
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object FleetGenerator {
    val PRIMARY_VEHICLES = listOf(
        Vehicle(
            vehicleId = "LI-L9-TEST-001",
            vin = "LIA98829310892801",
            model = "Li L9",
            modelNameZh = "理想 L9 旗舰 SUV",
            modelNameEn = "Li L9 Flagship SUV",
            variant = "Ultra",
            powertrainType = PowertrainType.EREV,
            batteryCapacityKwh = 52.3,
            cltcRangeKm = 1412,
            softwareVersion = "Li OS 8.2.0",
            hardwareVersion = "NVIDIA Orin-X x2 + Snapdragon 8295",
            region = "CN-Beijing",
            status = VehicleStatus.READY
        ),
        Vehicle(
            vehicleId = "LI-MEGA-TEST-002",
            vin = "LIAMEGA0029810292",
            model = "Li MEGA",
            modelNameZh = "理想 MEGA 科技旗舰 MPV",
            modelNameEn = "Li MEGA Flagship MPV",
            variant = "Max 5C",
            powertrainType = PowertrainType.BEV,
            batteryCapacityKwh = 102.7,
            cltcRangeKm = 710,
            softwareVersion = "Li OS 8.2.0",
            hardwareVersion = "Dual Orin-X + 5C Qilin Ultra Fast",
            region = "CN-Shanghai",
            status = VehicleStatus.CHARGING
        ),
        Vehicle(
            vehicleId = "LI-L8-TEST-003",
            vin = "LIA88819280192803",
            model = "Li L8",
            modelNameZh = "理想 L8 豪华六座 SUV",
            modelNameEn = "Li L8 Luxury 6-Seater SUV",
            variant = "Pro",
            powertrainType = PowertrainType.EREV,
            batteryCapacityKwh = 42.8,
            cltcRangeKm = 1360,
            softwareVersion = "Li OS 8.1.5",
            hardwareVersion = "Single Orin-X + Qualcomm 8295",
            region = "CN-Shenzhen",
            status = VehicleStatus.PARKED
        ),
        Vehicle(
            vehicleId = "LI-L7-TEST-004",
            vin = "LIA77719280192804",
            model = "Li L7",
            modelNameZh = "理想 L7 旗舰五座 SUV",
            modelNameEn = "Li L7 Flagship 5-Seater SUV",
            variant = "Max",
            powertrainType = PowertrainType.EREV,
            batteryCapacityKwh = 42.8,
            cltcRangeKm = 1360,
            softwareVersion = "Li OS 8.2.0",
            hardwareVersion = "Dual Orin-X + Snapdragon 8295",
            region = "CN-Hangzhou",
            status = VehicleStatus.DRIVING
        ),
        Vehicle(
            vehicleId = "LI-L6-TEST-005",
            vin = "LIA66619280192805",
            model = "Li L6",
            modelNameZh = "理想 L6 豪华五座 SUV",
            modelNameEn = "Li L6 Luxury 5-Seater SUV",
            variant = "Air",
            powertrainType = PowertrainType.EREV,
            batteryCapacityKwh = 36.8,
            cltcRangeKm = 1390,
            softwareVersion = "Li OS 8.2.0",
            hardwareVersion = "Snapdragon 8295 High-Compute",
            region = "CN-Guangzhou",
            status = VehicleStatus.PARKED
        ),
        Vehicle(
            vehicleId = "LI-i6-TEST-006",
            vin = "LIAI6600000000006",
            model = "Li i6",
            modelNameZh = "理想 i6 纯电 SUV (概念验证)",
            modelNameEn = "Li i6 Pure EV SUV (Concept Fleet)",
            variant = "Max",
            powertrainType = PowertrainType.BEV,
            batteryCapacityKwh = 85.0,
            cltcRangeKm = 660,
            softwareVersion = "Li OS 8.3.0-Beta",
            hardwareVersion = "Li Halo Compute Node Gen 2",
            region = "CN-Chengdu",
            status = VehicleStatus.READY
        ),
        Vehicle(
            vehicleId = "LI-i9-TEST-007",
            vin = "LIAI9900000000007",
            model = "Li i9",
            modelNameZh = "理想 i9 旗舰纯电 SUV (概念验证)",
            modelNameEn = "Li i9 Pure EV Flagship (Concept Fleet)",
            variant = "Ultra 5C",
            powertrainType = PowertrainType.BEV,
            batteryCapacityKwh = 110.0,
            cltcRangeKm = 750,
            softwareVersion = "Li OS 8.3.0-Beta",
            hardwareVersion = "Li Halo Compute Node Gen 2",
            region = "CN-Wuhan",
            status = VehicleStatus.PARKED
        )
    )

    fun getSyntheticFleetSummary(): String {
        return "Synthetic Fleet Stats: 1,000 Active Vehicles | 100,000 Historical Telemetry Packets | 10,000 Charging Sessions | 5,000 Service Records | 1,000 OTA Deployments"
    }
}

class TelemetrySimulatorEngine(private val initialVehicle: Vehicle = FleetGenerator.PRIMARY_VEHICLES[0]) {
    private var currentSoc = 72.0
    private var currentRange = 486
    private var currentSpeed = 0.0
    private var cabinTemp = 22.0
    private var isCharging = false
    private var doorsLocked = true

    fun getCurrentState(vehicleId: String = initialVehicle.vehicleId): VehicleState {
        return VehicleState(
            vehicleId = vehicleId,
            timestamp = System.currentTimeMillis(),
            latitude = 39.9042 + (Random.nextDouble() - 0.5) * 0.001,
            longitude = 116.4074 + (Random.nextDouble() - 0.5) * 0.001,
            speedKmh = currentSpeed,
            headingDegrees = 45.0,
            batterySOC = currentSoc,
            estimatedRangeKm = currentRange,
            chargingState = if (isCharging) "CHARGING (5C 快充)" else "DISCONNECTED",
            doors = VehicleDoors(
                driverDoorLocked = doorsLocked,
                passengerDoorLocked = doorsLocked,
                rearLeftDoorLocked = doorsLocked,
                rearRightDoorLocked = doorsLocked,
                trunkOpen = false,
                frunkOpen = false
            ),
            climate = VehicleClimate(
                active = true,
                targetTemperature = 22.0,
                currentCabinTemperature = cabinTemp,
                outsideTemperature = 16.5,
                fanSpeed = 2
            ),
            tyrePressure = VehicleTyrePressure(2.5, 2.5, 2.4, 2.5),
            powertrain = VehiclePowertrain(
                motorPowerKw = if (currentSpeed > 0) 35.0 else 0.0,
                motorRpm = (currentSpeed * 120).toInt(),
                extenderRunning = currentSoc < 20.0,
                fuelTankLevelPercent = 88.0
            ),
            suspension = VehicleSuspension(0, "Magic Carpet Comfort / 魔毯舒享"),
            driverAssistance = DriverAssistanceState(
                systemActive = true,
                systemName = "Li AD Max 3.0",
                surroundingObjectsCount = 18,
                currentRoadContext = "Beijing City Highway / 北京城市快速路"
            ),
            quality = TelemetryQuality(
                state = TelemetryState.MEASURED,
                confidence = 0.99f,
                source = "CAN-Bus Gateway / Halo Compute",
                unit = "Raw SI"
            )
        )
    }

    fun streamTelemetry(vehicleId: String): Flow<VehicleState> = flow {
        while (true) {
            // Slight dynamic fluctuation to demonstrate real-time WebSocket state streaming
            if (isCharging) {
                currentSoc = min(100.0, currentSoc + 0.1)
                currentRange = (currentSoc * 6.75).toInt()
            } else if (currentSpeed > 0) {
                currentSoc = max(5.0, currentSoc - 0.02)
                currentRange = (currentSoc * 6.75).toInt()
            }
            emit(getCurrentState(vehicleId))
            delay(1000)
        }
    }

    fun toggleLock(): Boolean {
        doorsLocked = !doorsLocked
        return doorsLocked
    }

    fun setSpeed(speed: Double) {
        currentSpeed = speed
    }

    fun setCharging(charging: Boolean) {
        isCharging = charging
    }
}

object SmartChargingOptimizer {
    data class ChargingOptimizationResult(
        val optimalStartTimestamp: String,
        val estimatedCompletionTimestamp: String,
        val chargingDurationMinutes: Int,
        val energyAddedKwh: Double,
        val totalCostCny: Double,
        val offPeakSavingsPercent: Int,
        val batteryPreconditionTempC: Double = 25.0
    )

    fun calculateOptimization(
        currentSoc: Double = 32.0,
        targetSoc: Double = 80.0,
        batteryCapacityKwh: Double = 52.3,
        chargerKw: Double = 120.0
    ): ChargingOptimizationResult {
        val neededSoc = max(0.0, targetSoc - currentSoc)
        val neededKwh = (neededSoc / 100.0) * batteryCapacityKwh
        val hoursNeeded = neededKwh / (chargerKw * 0.9) // 90% efficiency
        val minutesNeeded = (hoursNeeded * 60).toInt()

        val cost = neededKwh * 0.68 // Off-peak tariff average
        return ChargingOptimizationResult(
            optimalStartTimestamp = "23:10 (夜间谷段电价)",
            estimatedCompletionTimestamp = "00:28 (于早晨 07:30 出发前已满电)",
            chargingDurationMinutes = max(25, minutesNeeded),
            energyAddedKwh = String.format("%.1f", neededKwh).toDouble(),
            totalCostCny = String.format("%.2f", cost).toDouble(),
            offPeakSavingsPercent = 42
        )
    }
}

object DigitalTwinEngine {
    fun runWhatIfScenario(params: ScenarioParams, baseSoc: Double = 72.0, batteryCapacity: Double = 52.3): ScenarioPrediction {
        // Temp impact: below 15C or above 30C increases consumption
        val tempMultiplier = when {
            params.ambientTemperatureC < 0 -> 1.35
            params.ambientTemperatureC < 15 -> 1.15
            params.ambientTemperatureC > 30 -> 1.20
            else -> 1.0
        }

        // Speed impact: quadratic drag after 80 km/h
        val speedRatio = params.cruiseSpeedKmh / 80.0
        val speedMultiplier = if (speedRatio > 1.0) 1.0 + (speedRatio - 1.0) * 0.8 else 0.95

        // Weight impact
        val weightMultiplier = 1.0 + (params.payloadWeightKg / 1000.0) * 0.1

        // AC impact
        val acKw = (params.acPowerPercent / 100.0) * 3.5

        val baseConsumption = 16.5 // kWh/100km
        val actualConsumption = baseConsumption * tempMultiplier * speedMultiplier * weightMultiplier + (acKw * 2.0)

        val totalAvailableKwh = (baseSoc / 100.0) * batteryCapacity
        val predictedRange = ((totalAvailableKwh / actualConsumption) * 100).toInt()

        return ScenarioPrediction(
            predictedRangeKm = max(10, predictedRange),
            energyConsumptionKwhPer100Km = String.format("%.1f", actualConsumption).toDouble(),
            predictedArrivalSocPercent = max(5.0, baseSoc - 35.0 / (actualConsumption / 16.5)),
            estimatedTravelMinutes = 95,
            chargingNeededOnRoute = predictedRange < 180,
            totalBatteryHeatGeneratedC = 28.5
        )
    }
}

class OtaEngine {
    private val _currentStage = MutableStateFlow(OTALifecycleState.AVAILABLE)
    val currentStage: StateFlow<OTALifecycleState> = _currentStage.asStateFlow()

    private val _progress = MutableStateFlow(0)
    val progress: StateFlow<Int> = _progress.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private fun addLog(zh: String, en: String) {
        val entry = "[${System.currentTimeMillis() % 100000}] [ZH] $zh | [EN] $en"
        _logs.value = _logs.value + entry
    }

    suspend fun runNormalOtaSequence(vehicleId: String) {
        _logs.value = emptyList()
        _currentStage.value = OTALifecycleState.DOWNLOADING
        addLog("开始从 Li Cloud 软件服务下载 Li OS 8.2.0 增量包 (2.4 GB)", "Downloading Li OS 8.2.0 package (2.4 GB) from Li Cloud")
        for (p in 10..100 step 20) {
            _progress.value = p
            delay(400)
        }

        _currentStage.value = OTALifecycleState.VERIFIED
        addLog("固件 SHA-256 哈希安全签名校验成功", "Firmware SHA-256 security signature verified successfully")
        delay(600)

        _currentStage.value = OTALifecycleState.INSTALLING
        addLog("开始刷新 Li Halo 域控制器 A/B 分区 (座舱与 ADAS 软件)", "Flashing Li Halo Domain Controllers A/B partitions (Cockpit & ADAS)")
        for (p in 10..100 step 20) {
            _progress.value = p
            delay(500)
        }

        _currentStage.value = OTALifecycleState.VALIDATING
        addLog("执行车载计算节点硬件自检和 CAN 总线响应测试", "Performing vehicle compute hardware self-test & CAN bus ping")
        delay(800)

        _currentStage.value = OTALifecycleState.COMPLETE
        addLog("Li OS 8.2.0 部署成功！车辆系统准备就绪", "Li OS 8.2.0 deployment successful! Vehicle ready")

        VehicleEventBus.publishEvent(
            VehicleEvent(
                vehicleId = vehicleId,
                eventType = EventType.OTACompleted,
                payload = "Li OS 8.2.0 Upgrade Succeeded"
            )
        )
    }

    suspend fun runFailedOtaSequenceWithRollback(vehicleId: String) {
        _logs.value = emptyList()
        _currentStage.value = OTALifecycleState.DOWNLOADING
        addLog("开始从 Li Cloud 下载 Li OS 8.2.0 包", "Downloading Li OS 8.2.0 package from Li Cloud")
        _progress.value = 100
        delay(400)

        _currentStage.value = OTALifecycleState.VERIFIED
        addLog("固件 SHA-256 签名校验通过", "SHA-256 signature verified")
        delay(400)

        _currentStage.value = OTALifecycleState.INSTALLING
        addLog("写入座舱计算芯片与网关固件", "Flashing cockpit compute SoC and gateway firmware")
        _progress.value = 80
        delay(500)

        _currentStage.value = OTALifecycleState.VALIDATING
        addLog("警告: 校验 ADAS 域控制器总线响应超时 (注入异常)", "WARNING: ADAS domain controller CAN response timeout (Injected fault)")
        delay(700)

        _currentStage.value = OTALifecycleState.FAILED
        addLog("错误: 校验失败！触发安全防御机制，启动自动回滚流程", "ERROR: Validation failed! Security defense triggered, starting automatic rollback")
        delay(800)

        _currentStage.value = OTALifecycleState.ROLLBACK
        addLog("回滚中: 无缝切回 B 侧已知稳定固件分区 (Li OS 8.1.5)", "Rollback in progress: Seamlessly reverting to B-Side safe partition (Li OS 8.1.5)")
        delay(900)

        _currentStage.value = OTALifecycleState.RESTORE
        addLog("安全恢复: 系统已完整还原至 Li OS 8.1.5。已提交诊断日志至云端", "Safe restore: System fully restored to Li OS 8.1.5. Diagnostic audit submitted")

        VehicleEventBus.publishEvent(
            VehicleEvent(
                vehicleId = vehicleId,
                eventType = EventType.OTAFailed,
                payload = "OTA Injected Validation Fault -> Automatic Rollback Completed"
            )
        )
    }
}

object FamilyManager {
    val PROFILES = listOf(
        FamilyProfile(
            profileId = "profile_dad",
            nameZh = "爸爸 (Dad)",
            nameEn = "Dad (Owner)",
            role = UserRole.OWNER,
            seatBackrestAngleDegrees = 105,
            seatSlideMm = 210,
            preferredTemp = 21.0,
            ambientColorHex = "#00E5FF", // Electric Cyan
            preferredLanguage = "ZH_CN",
            avatarUrl = ""
        ),
        FamilyProfile(
            profileId = "profile_mum",
            nameZh = "妈妈 (Mum)",
            nameEn = "Mum (Partner)",
            role = UserRole.PARTNER,
            seatBackrestAngleDegrees = 120,
            seatSlideMm = 180,
            preferredTemp = 23.5,
            ambientColorHex = "#E6C875", // Warm Gold
            preferredLanguage = "ZH_CN",
            avatarUrl = ""
        ),
        FamilyProfile(
            profileId = "profile_child",
            nameZh = "孩子 (Child)",
            nameEn = "Child (Rear Passenger)",
            role = UserRole.CHILD,
            seatBackrestAngleDegrees = 110,
            seatSlideMm = 150,
            preferredTemp = 24.0,
            ambientColorHex = "#00E676", // Fresh Green
            preferredLanguage = "EN_US",
            avatarUrl = ""
        ),
        FamilyProfile(
            profileId = "profile_guest",
            nameZh = "访客 (Guest)",
            nameEn = "Guest (Valet Mode)",
            role = UserRole.GUEST,
            seatBackrestAngleDegrees = 100,
            seatSlideMm = 200,
            preferredTemp = 22.0,
            ambientColorHex = "#FFFFFF", // Crisp White
            preferredLanguage = "ZH_CN",
            avatarUrl = ""
        )
    )
}

object HealthDiagnosticsData {
    val SUBSYSTEMS = listOf(
        SubsystemHealth("battery", "高压电池系统 (Battery)", "High Voltage Battery", DiagnosticSeverity.GOOD, "Cell Pack balanced, 5C Quick-charge temp normal", "Cell Pack balanced, 5C Quick-charge temp normal"),
        SubsystemHealth("powertrain", "双电机增程系统 (Powertrain)", "Dual-Motor Powertrain", DiagnosticSeverity.GOOD, "Inverter efficiency 98.2%, zero error codes", "Inverter efficiency 98.2%, zero error codes"),
        SubsystemHealth("tyres", "智能胎压监测 (Tyre Pressure)", "TPMS System", DiagnosticSeverity.GOOD, "All 4 tyres at 2.5 bar optimum", "All 4 tyres at 2.5 bar optimum"),
        SubsystemHealth("brakes", "线控制动系统 (Braking State)", "Brake-by-Wire", DiagnosticSeverity.GOOD, "Pad thickness 88%, pressure check OK", "Pad thickness 88%, pressure check OK"),
        SubsystemHealth("cooling", "热管理系统 (Thermal Management)", "Thermal System", DiagnosticSeverity.GOOD, "Coolant flow nominal", "Coolant flow nominal"),
        SubsystemHealth("software", "Li Halo OS 车载系统 (Operating OS)", "Li Halo OS Layer", DiagnosticSeverity.GOOD, "Li OS 8.2.0 Active", "Li OS 8.2.0 Active"),
        SubsystemHealth("charging", "车载充电机/快充口 (Charging Port)", "OBC / Fast Charging Port", DiagnosticSeverity.GOOD, "5C Port latch mechanism secure", "5C Port latch mechanism secure"),
        SubsystemHealth("suspension", "魔毯空气悬架 (Air Suspension)", "Magic Carpet Air Suspension", DiagnosticSeverity.ATTENTION, "Air compressor duty cycle nominal; scheduled check at 20,000 km", "Air compressor duty cycle nominal; scheduled check at 20,000 km")
    )

    val SBOM_COMPONENTS = listOf(
        SoftwareComponent("Li Halo Kernel", "OS Compute", "v5.15.102-li-halo", "sha256:e8f9a2b", "已验证", "Verified"),
        SoftwareComponent("Li AD Max Perception Engine", "ADAS Software", "v3.0.42", "sha256:019283f", "已验证", "Verified"),
        SoftwareComponent("Smart Cockpit UI (Compose)", "Cockpit Software", "v8.2.0-b2", "sha256:777123a", "已验证", "Verified"),
        SoftwareComponent("Battery Management Firmware (BMS)", "Battery Software", "v2.1.0", "sha256:b3b3b3a", "已验证", "Verified"),
        SoftwareComponent("Gateway CAN-FD Matrix Driver", "Connectivity", "v1.9.4", "sha256:441290f", "已验证", "Verified")
    )
}
