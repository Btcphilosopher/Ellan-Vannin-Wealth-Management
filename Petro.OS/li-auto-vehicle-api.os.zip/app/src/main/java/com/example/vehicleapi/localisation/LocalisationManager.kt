package com.example.vehicleapi.localisation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppLocale(val code: String, val displayNameZh: String, val displayNameEn: String) {
    ZH_CN("zh-CN", "中文", "Chinese"),
    EN_US("en-US", "English", "English")
}

object LocalisationManager {
    private val _currentLocale = MutableStateFlow(AppLocale.ZH_CN)
    val currentLocale: StateFlow<AppLocale> = _currentLocale.asStateFlow()

    fun setLocale(locale: AppLocale) {
        _currentLocale.value = locale
    }

    fun toggleLocale() {
        _currentLocale.value = if (_currentLocale.value == AppLocale.ZH_CN) AppLocale.EN_US else AppLocale.ZH_CN
    }

    private val dictionary: Map<String, Map<AppLocale, String>> = mapOf(
        "app_title" to mapOf(AppLocale.ZH_CN to "理想汽车智能汽车 API 平台", AppLocale.EN_US to "Li Auto Vehicle API.OS Platform"),
        "app_subtitle" to mapOf(AppLocale.ZH_CN to "分布式车载计算与 API 操作层", AppLocale.EN_US to "Distributed Vehicle Compute & API Operating Layer"),
        "simulated_tag" to mapOf(AppLocale.ZH_CN to "模拟环境 · SYNTHETIC FLEET", AppLocale.EN_US to "SIMULATED ENVIRONMENT · SYNTHETIC FLEET"),
        
        // Navigation Tabs
        "tab_live_vehicle" to mapOf(AppLocale.ZH_CN to "实时车辆", AppLocale.EN_US to "Live Vehicle"),
        "tab_charging" to mapOf(AppLocale.ZH_CN to "智能充电", AppLocale.EN_US to "Smart Charging"),
        "tab_ota" to mapOf(AppLocale.ZH_CN to "OTA 升级", AppLocale.EN_US to "OTA Rollout"),
        "tab_digital_twin" to mapOf(AppLocale.ZH_CN to "数字孪生", AppLocale.EN_US to "Digital Twin"),
        "tab_family" to mapOf(AppLocale.ZH_CN to "家庭账户", AppLocale.EN_US to "Family Account"),
        "tab_adas" to mapOf(AppLocale.ZH_CN to "驾驶辅助", AppLocale.EN_US to "Driver Assistance"),
        "tab_diagnostics" to mapOf(AppLocale.ZH_CN to "服务与诊断", AppLocale.EN_US to "Service & Health"),
        "tab_api_explorer" to mapOf(AppLocale.ZH_CN to "API 探索器", AppLocale.EN_US to "API Explorer"),
        "tab_engineering" to mapOf(AppLocale.ZH_CN to "工程工作台", AppLocale.EN_US to "Engineering Mode"),

        // Signature Demos
        "demo_1_title" to mapOf(AppLocale.ZH_CN to "标志性 Demo 1: 实时车辆", AppLocale.EN_US to "Signature Demo 1: Live Vehicle Stream"),
        "demo_2_title" to mapOf(AppLocale.ZH_CN to "标志性 Demo 2: 智能充电优化", AppLocale.EN_US to "Signature Demo 2: Smart Charging Optimizer"),
        "demo_3_title" to mapOf(AppLocale.ZH_CN to "标志性 Demo 3: OTA 发布与异常回滚", AppLocale.EN_US to "Signature Demo 3: OTA Rollout & Failure Rollback"),
        "demo_4_title" to mapOf(AppLocale.ZH_CN to "标志性 Demo 4: 数字孪生场景预测", AppLocale.EN_US to "Signature Demo 4: Digital Twin Scenario Prediction"),
        "demo_5_title" to mapOf(AppLocale.ZH_CN to "标志性 Demo 5: 家庭多账号座舱切态", AppLocale.EN_US to "Signature Demo 5: Family Multi-Account Cabin State"),

        // Vehicle Metrics
        "vehicle_status" to mapOf(AppLocale.ZH_CN to "车辆状态", AppLocale.EN_US to "Vehicle Status"),
        "battery_soc" to mapOf(AppLocale.ZH_CN to "电池电量 (SOC)", AppLocale.EN_US to "Battery SOC"),
        "estimated_range" to mapOf(AppLocale.ZH_CN to "预计续航", AppLocale.EN_US to "Estimated Range"),
        "cabin_temp" to mapOf(AppLocale.ZH_CN to "座舱温度", AppLocale.EN_US to "Cabin Temperature"),
        "outside_temp" to mapOf(AppLocale.ZH_CN to "车外温度", AppLocale.EN_US to "Outside Temperature"),
        "vehicle_speed" to mapOf(AppLocale.ZH_CN to "当前车速", AppLocale.EN_US to "Current Speed"),
        "charging_state" to mapOf(AppLocale.ZH_CN to "充电状态", AppLocale.EN_US to "Charging State"),
        "software_version" to mapOf(AppLocale.ZH_CN to "软件版本", AppLocale.EN_US to "Software Version"),
        "hardware_version" to mapOf(AppLocale.ZH_CN to "硬件架构", AppLocale.EN_US to "Hardware Version"),
        "vin_code" to mapOf(AppLocale.ZH_CN to "车架号 (VIN)", AppLocale.EN_US to "VIN Code"),
        "powertrain_type" to mapOf(AppLocale.ZH_CN to "动力架构", AppLocale.EN_US to "Powertrain Type"),

        // Status values
        "status_ready" to mapOf(AppLocale.ZH_CN to "车辆就绪", AppLocale.EN_US to "READY"),
        "status_driving" to mapOf(AppLocale.ZH_CN to "行驶中", AppLocale.EN_US to "DRIVING"),
        "status_charging" to mapOf(AppLocale.ZH_CN to "充电中", AppLocale.EN_US to "CHARGING"),
        "status_parked" to mapOf(AppLocale.ZH_CN to "已泊车", AppLocale.EN_US to "PARKED"),
        "status_locked" to mapOf(AppLocale.ZH_CN to "车门已锁", AppLocale.EN_US to "Locked"),
        "status_unlocked" to mapOf(AppLocale.ZH_CN to "车门已解锁", AppLocale.EN_US to "Unlocked"),

        // Commands
        "cmd_lock" to mapOf(AppLocale.ZH_CN to "远程锁车", AppLocale.EN_US to "Lock Vehicle"),
        "cmd_unlock" to mapOf(AppLocale.ZH_CN to "远程解锁", AppLocale.EN_US to "Unlock Vehicle"),
        "cmd_start_climate" to mapOf(AppLocale.ZH_CN to "启动空调预热", AppLocale.EN_US to "Start Climate"),
        "cmd_stop_climate" to mapOf(AppLocale.ZH_CN to "关闭空调", AppLocale.EN_US to "Stop Climate"),
        "cmd_locate" to mapOf(AppLocale.ZH_CN to "寻车(闪灯鸣笛)", AppLocale.EN_US to "Locate Vehicle"),
        "cmd_start_charging" to mapOf(AppLocale.ZH_CN to "开启智能充电", AppLocale.EN_US to "Start Charging"),
        "cmd_stop_charging" to mapOf(AppLocale.ZH_CN to "停止充电", AppLocale.EN_US to "Stop Charging"),

        // Smart Charging
        "charging_target_soc" to mapOf(AppLocale.ZH_CN to "目标电量 (Target SOC)", AppLocale.EN_US to "Target SOC"),
        "departure_time" to mapOf(AppLocale.ZH_CN to "计划出发时间", AppLocale.EN_US to "Departure Time"),
        "charger_power" to mapOf(AppLocale.ZH_CN to "充电桩功率", AppLocale.EN_US to "Charger Power"),
        "estimated_completion" to mapOf(AppLocale.ZH_CN to "预计充电完成时间", AppLocale.EN_US to "Estimated Completion"),
        "energy_consumed" to mapOf(AppLocale.ZH_CN to "预计消耗电量", AppLocale.EN_US to "Energy Consumed"),
        "optimized_start_time" to mapOf(AppLocale.ZH_CN to "最佳充电起始时间", AppLocale.EN_US to "Optimal Start Time"),
        "off_peak_savings" to mapOf(AppLocale.ZH_CN to "谷段电价节省额", AppLocale.EN_US to "Off-Peak Savings"),

        // OTA
        "ota_release_notes" to mapOf(AppLocale.ZH_CN to "Li OS 8.2.0 系统更新说明", AppLocale.EN_US to "Li OS 8.2.0 Release Notes"),
        "ota_stage_available" to mapOf(AppLocale.ZH_CN to "版本可用", AppLocale.EN_US to "AVAILABLE"),
        "ota_stage_downloading" to mapOf(AppLocale.ZH_CN to "固件下载中", AppLocale.EN_US to "DOWNLOADING"),
        "ota_stage_verified" to mapOf(AppLocale.ZH_CN to "哈希校验通过", AppLocale.EN_US to "VERIFIED"),
        "ota_stage_installing" to mapOf(AppLocale.ZH_CN to "底层模块写入中", AppLocale.EN_US to "INSTALLING"),
        "ota_stage_validating" to mapOf(AppLocale.ZH_CN to "系统自检验证中", AppLocale.EN_US to "VALIDATING"),
        "ota_stage_complete" to mapOf(AppLocale.ZH_CN to "更新完成", AppLocale.EN_US to "COMPLETE"),
        "ota_stage_failed" to mapOf(AppLocale.ZH_CN to "自检失败", AppLocale.EN_US to "VALIDATION FAILED"),
        "ota_stage_rollback" to mapOf(AppLocale.ZH_CN to "自动回滚至 A/B 备用分区", AppLocale.EN_US to "ROLLBACK TO B-SIDE"),
        "btn_trigger_ota" to mapOf(AppLocale.ZH_CN to "模拟正常 OTA 部署", AppLocale.EN_US to "Simulate Normal OTA"),
        "btn_inject_ota_fault" to mapOf(AppLocale.ZH_CN to "注入自检校验故障并回滚", AppLocale.EN_US to "Inject Fault & Rollback"),

        // Digital Twin
        "dt_what_if" to mapOf(AppLocale.ZH_CN to "数字孪生预测实验室 (What-If)", AppLocale.EN_US to "Digital Twin What-If Lab"),
        "slider_ambient_temp" to mapOf(AppLocale.ZH_CN to "环境气温 (°C)", AppLocale.EN_US to "Ambient Temp (°C)"),
        "slider_speed" to mapOf(AppLocale.ZH_CN to "巡航巡速 (km/h)", AppLocale.EN_US to "Cruise Speed (km/h)"),
        "slider_payload" to mapOf(AppLocale.ZH_CN to "乘员与行李负载 (kg)", AppLocale.EN_US to "Payload Weight (kg)"),
        "slider_ac_load" to mapOf(AppLocale.ZH_CN to "座舱空调负荷 (%)", AppLocale.EN_US to "AC Power Load (%)"),
        "predicted_consumption" to mapOf(AppLocale.ZH_CN to "预测百公里能耗", AppLocale.EN_US to "Predicted Consumption"),
        "predicted_range" to mapOf(AppLocale.ZH_CN to "预测真实可达续航", AppLocale.EN_US to "Predicted Real-world Range"),
        "predicted_arrival_soc" to mapOf(AppLocale.ZH_CN to "到达目的地电量 (SOC)", AppLocale.EN_US to "SOC at Destination"),

        // Family Accounts
        "profile_dad" to mapOf(AppLocale.ZH_CN to "爸爸 (主驾驶·车主)", AppLocale.EN_US to "Dad (Owner · Primary Driver)"),
        "profile_mum" to mapOf(AppLocale.ZH_CN to "妈妈 (副驾驶·伴侣)", AppLocale.EN_US to "Mum (Co-pilot · Partner)"),
        "profile_child" to mapOf(AppLocale.ZH_CN to "孩子 (后排·二排娱乐)", AppLocale.EN_US to "Child (Rear Passenger)"),
        "profile_guest" to mapOf(AppLocale.ZH_CN to "访客 (限制驾驶模式)", AppLocale.EN_US to "Guest (Restricted Mode)"),
        "seat_position" to mapOf(AppLocale.ZH_CN to "座椅靠背与滑轨记忆", AppLocale.EN_US to "Seat & Backrest Memory"),
        "climate_preference" to mapOf(AppLocale.ZH_CN to "专属三区空调偏好", AppLocale.EN_US to "3-Zone Climate Preference"),
        "ambient_color" to mapOf(AppLocale.ZH_CN to "256色氛围灯主题", AppLocale.EN_US to "256-Color Ambient Light"),

        // Safety Boundary
        "safety_boundary_notice" to mapOf(AppLocale.ZH_CN to "安全边界提示：平台严禁公开转向、加速、制动等直接执行器控制 API。仅提供经授权的安全管理接口。", AppLocale.EN_US to "Safety Boundary Notice: Safety-critical actuators (steering, throttle, brakes) are strictly isolated. Only authorised high-level APIs are exposed."),

        // Common
        "unit_km" to mapOf(AppLocale.ZH_CN to "公里", AppLocale.EN_US to "km"),
        "unit_kwh" to mapOf(AppLocale.ZH_CN to "度电", AppLocale.EN_US to "kWh"),
        "unit_bar" to mapOf(AppLocale.ZH_CN to "巴", AppLocale.EN_US to "bar"),
        "unit_degree" to mapOf(AppLocale.ZH_CN to "℃", AppLocale.EN_US to "℃"),
        "unit_kmh" to mapOf(AppLocale.ZH_CN to "公里/小时", AppLocale.EN_US to "km/h")
    )

    fun getString(key: String, locale: AppLocale = _currentLocale.value): String {
        val map = dictionary[key]
        return map?.get(locale) ?: map?.get(AppLocale.EN_US) ?: key
    }
}

val LocalAppLocale = staticCompositionLocalOf { AppLocale.ZH_CN }

@Composable
fun tr(key: String): String {
    val locale = LocalAppLocale.current
    return LocalisationManager.getString(key, locale)
}
