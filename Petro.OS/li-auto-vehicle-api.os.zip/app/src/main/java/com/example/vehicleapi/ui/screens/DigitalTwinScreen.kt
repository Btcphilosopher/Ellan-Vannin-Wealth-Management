package com.example.vehicleapi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LiCardBg
import com.example.ui.theme.LiCardBorder
import com.example.ui.theme.LiDarkBg
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.localisation.tr
import com.example.vehicleapi.ui.components.MetricCard
import com.example.vehicleapi.ui.viewmodel.MainViewModel

@Composable
fun DigitalTwinScreen(viewModel: MainViewModel) {
    val vehicle by viewModel.selectedVehicle.collectAsState()
    val locale by viewModel.currentLocale.collectAsState()
    val params by viewModel.scenarioParams.collectAsState()
    val prediction by viewModel.scenarioPrediction.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Demo 4 Header
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = tr("demo_4_title"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MetallicGold
                )
                Text(
                    text = if (locale == AppLocale.ZH_CN)
                        "真实车辆 → 遥测数据 → 状态估计 → 数字孪生 → 场景模拟 → 物理能耗精准预测"
                    else
                        "Real Vehicle → Telemetry → State Estimation → Digital Twin → Scenario → Prediction",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // What-If Sliders Card
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = tr("dt_what_if"),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Ambient Temp Slider
                Text(
                    text = "${tr("slider_ambient_temp")}: ${params.ambientTemperatureC.toInt()}°C",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Slider(
                    value = params.ambientTemperatureC.toFloat(),
                    onValueChange = {
                        viewModel.updateScenarioParams(it.toDouble(), params.cruiseSpeedKmh, params.payloadWeightKg, params.acPowerPercent)
                    },
                    valueRange = -20f..40f,
                    colors = SliderDefaults.colors(thumbColor = MetallicGold, activeTrackColor = MetallicGold)
                )

                // Speed Slider
                Text(
                    text = "${tr("slider_speed")}: ${params.cruiseSpeedKmh.toInt()} km/h",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Slider(
                    value = params.cruiseSpeedKmh.toFloat(),
                    onValueChange = {
                        viewModel.updateScenarioParams(params.ambientTemperatureC, it.toDouble(), params.payloadWeightKg, params.acPowerPercent)
                    },
                    valueRange = 40f..150f,
                    colors = SliderDefaults.colors(thumbColor = ElectricCyan, activeTrackColor = ElectricCyan)
                )

                // Payload Slider
                Text(
                    text = "${tr("slider_payload")}: ${params.payloadWeightKg.toInt()} kg",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Slider(
                    value = params.payloadWeightKg.toFloat(),
                    onValueChange = {
                        viewModel.updateScenarioParams(params.ambientTemperatureC, params.cruiseSpeedKmh, it.toDouble(), params.acPowerPercent)
                    },
                    valueRange = 0f..400f,
                    colors = SliderDefaults.colors(thumbColor = EmeraldSuccess, activeTrackColor = EmeraldSuccess)
                )

                // AC Load Slider
                Text(
                    text = "${tr("slider_ac_load")}: ${params.acPowerPercent.toInt()}%",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Slider(
                    value = params.acPowerPercent.toFloat(),
                    onValueChange = {
                        viewModel.updateScenarioParams(params.ambientTemperatureC, params.cruiseSpeedKmh, params.payloadWeightKg, it.toDouble())
                    },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(thumbColor = MetallicGold, activeTrackColor = MetallicGold)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Predictive Outputs
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard(
                titleZh = "预测百公里能耗",
                titleEn = "Predicted kWh/100km",
                value = "${prediction.energyConsumptionKwhPer100Km}",
                unit = "kWh/100km",
                accentColor = MetallicGold,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleZh = "预测真实可达续航",
                titleEn = "Predicted Real Range",
                value = "${prediction.predictedRangeKm}",
                unit = "km",
                accentColor = EmeraldSuccess,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard(
                titleZh = "到达目的地 SOC",
                titleEn = "Arrival SOC",
                value = "${prediction.predictedArrivalSocPercent.toInt()}%",
                accentColor = ElectricCyan,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleZh = "沿途是否需充电",
                titleEn = "Charging Required",
                value = if (prediction.chargingNeededOnRoute) "YES (需中途快充)" else "NO (直达无忧)",
                accentColor = if (prediction.chargingNeededOnRoute) Color(0xFFFFB300) else EmeraldSuccess,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
