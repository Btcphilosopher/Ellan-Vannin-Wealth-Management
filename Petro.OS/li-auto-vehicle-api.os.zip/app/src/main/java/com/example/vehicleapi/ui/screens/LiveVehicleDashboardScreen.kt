package com.example.vehicleapi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LiCardBg
import com.example.ui.theme.LiCardBorder
import com.example.ui.theme.LiDarkBg
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vehicleapi.domain.CommandType
import com.example.vehicleapi.domain.Vehicle
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.localisation.LocalisationManager
import com.example.vehicleapi.localisation.tr
import com.example.vehicleapi.ui.components.CustomSocGauge
import com.example.vehicleapi.ui.components.MetricCard
import com.example.vehicleapi.ui.components.SafetyBoundaryBanner
import com.example.vehicleapi.ui.viewmodel.MainViewModel

@Composable
fun LiveVehicleDashboardScreen(viewModel: MainViewModel) {
    val vehicle by viewModel.selectedVehicle.collectAsState()
    val state by viewModel.vehicleState.collectAsState()
    val locale by viewModel.currentLocale.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Signature Demo Header Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = tr("demo_1_title"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyan
                )
                Text(
                    text = if (locale == AppLocale.ZH_CN)
                        "理想 ${vehicle.model} 实时车辆总线 WebSocket 模拟计算流"
                    else
                        "Li ${vehicle.model} Live Vehicle Bus WebSocket Simulation Stream",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Center Gauge & High Level Readouts
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (locale == AppLocale.ZH_CN) vehicle.modelNameZh else vehicle.modelNameEn,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    
                    Surface(
                        color = EmeraldSuccess.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (locale == AppLocale.ZH_CN) state.chargingState else "LIVE STREAM ACTIVE",
                            fontSize = 10.sp,
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                CustomSocGauge(
                    socPercent = state.batterySOC,
                    estimatedRangeKm = state.estimatedRangeKm,
                    isCharging = state.chargingState.contains("CHARGING")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // High-level quick action buttons (Lock, Climate, Locate)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val cmd = if (state.doors.driverDoorLocked) CommandType.UNLOCK else CommandType.LOCK
                            viewModel.executeCommand(cmd)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_lock_unlock")
                    ) {
                        Icon(
                            imageVector = if (state.doors.driverDoorLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = "Lock Unlock",
                            tint = ElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (state.doors.driverDoorLocked) tr("cmd_unlock") else tr("cmd_lock"),
                            fontSize = 12.sp,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { viewModel.executeCommand(CommandType.START_CLIMATE) },
                        colors = ButtonDefaults.buttonColors(containerColor = MetallicGold.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_climate")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AcUnit,
                            contentDescription = "Climate",
                            tint = MetallicGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tr("cmd_start_climate"),
                            fontSize = 12.sp,
                            color = MetallicGold,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { viewModel.executeCommand(CommandType.LOCATE) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_locate")
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Locate",
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tr("cmd_locate"),
                            fontSize = 12.sp,
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Grid of Real-Time Metrics
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard(
                titleZh = "座舱温度",
                titleEn = "Cabin Temp",
                value = "${state.climate.currentCabinTemperature}",
                unit = "℃",
                accentColor = MetallicGold,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleZh = "车外气温",
                titleEn = "Outside Temp",
                value = "${state.climate.outsideTemperature}",
                unit = "℃",
                accentColor = ElectricCyan,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard(
                titleZh = "平均胎压",
                titleEn = "Tyre Pressure",
                value = "${state.tyrePressure.frontLeftBar}",
                unit = "bar",
                accentColor = EmeraldSuccess,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleZh = "空气悬架",
                titleEn = "Air Suspension",
                value = "${state.suspension.airSuspensionHeightMm}",
                unit = "mm",
                accentColor = ElectricCyan,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        SafetyBoundaryBanner()
    }
}
