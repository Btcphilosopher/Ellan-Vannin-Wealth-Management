package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Li Auto Premium Automotive Tech Palette
val LiDarkBg = Color(0xFF0F1215)
val LiCardBg = Color(0xFF1B1F26)
val LiCardBorder = Color(0xFF2C323E)

val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDark = Color(0xFF0097A7)
val MetallicGold = Color(0xFFE6C875)
val EmeraldSuccess = Color(0xFF00E676)
val AmberWarning = Color(0xFFFFB300)
val CrimsonAlert = Color(0xFFFF5252)

val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF9EA8B6)
val TextMuted = Color(0xFF626E7E)

val PrimaryGradientStart = Color(0xFF141921)
val PrimaryGradientEnd = Color(0xFF0A0D11)
