package com.example.vehicleapi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LiCardBg
import com.example.ui.theme.LiCardBorder
import com.example.ui.theme.LiDarkBg
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vehicleapi.domain.DiagnosticSeverity
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.simulation.HealthDiagnosticsData
import com.example.vehicleapi.ui.viewmodel.MainViewModel

@Composable
fun ServiceDiagnosticsScreen(viewModel: MainViewModel) {
    val locale by viewModel.currentLocale.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "车辆八大核心子系统健康诊断" else "8-Subsystem Vehicle Health Dashboard",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldSuccess
                )
                Text(
                    text = if (locale == AppLocale.ZH_CN) "电池、动力、轮胎、线控、热管理、软件、充电与悬架实时监控" else "Battery, Powertrain, TPMS, Braking, Thermal, OS, Charging & Suspension",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 8 Subsystem list
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            HealthDiagnosticsData.SUBSYSTEMS.forEach { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = LiCardBg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (locale == AppLocale.ZH_CN) item.nameZh else item.nameEn,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = if (locale == AppLocale.ZH_CN) item.statusMessageZh else item.statusMessageEn,
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }

                        val (color, tag) = when (item.severity) {
                            DiagnosticSeverity.GOOD -> EmeraldSuccess to "GOOD / 良好"
                            DiagnosticSeverity.ATTENTION -> MetallicGold to "ATTENTION / 关注"
                            DiagnosticSeverity.WARNING -> Color(0xFFFFB300) to "WARNING / 警告"
                            DiagnosticSeverity.SERVICE_REQUIRED -> Color(0xFFFF5252) to "SERVICE REQ"
                        }

                        Surface(
                            color = color.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = tag,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = color,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Software Bill of Materials (SBOM) Card
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "软件物料清单 (SBOM) 与安全签名" else "Software Bill of Materials (SBOM)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyan
                )
                Spacer(modifier = Modifier.height(8.dp))

                HealthDiagnosticsData.SBOM_COMPONENTS.forEach { sbom ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = sbom.name, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                            Text(text = "Build: ${sbom.buildHash}", fontSize = 10.sp, color = TextMuted, fontFamily = FontFamily.Monospace)
                        }
                        Text(
                            text = sbom.version,
                            fontSize = 11.sp,
                            color = ElectricCyan,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
