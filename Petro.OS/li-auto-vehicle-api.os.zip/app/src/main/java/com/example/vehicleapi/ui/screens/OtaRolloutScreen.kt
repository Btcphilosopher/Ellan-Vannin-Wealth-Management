package com.example.vehicleapi.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LiCardBg
import com.example.ui.theme.LiCardBorder
import com.example.ui.theme.LiDarkBg
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vehicleapi.domain.OTALifecycleState
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.localisation.tr
import com.example.vehicleapi.ui.viewmodel.MainViewModel

@Composable
fun OtaRolloutScreen(viewModel: MainViewModel) {
    val vehicle by viewModel.selectedVehicle.collectAsState()
    val locale by viewModel.currentLocale.collectAsState()
    val stage by viewModel.otaEngine.currentStage.collectAsState()
    val progress by viewModel.otaEngine.progress.collectAsState()
    val logs by viewModel.otaEngine.logs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Demo 3 Header
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = tr("demo_3_title"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyan
                )
                Text(
                    text = if (locale == AppLocale.ZH_CN)
                        "完整分阶段 OTA 部署生命周期与 A/B 分区故障安全自动回滚演练"
                    else
                        "Complete staged OTA deployment lifecycle & A/B partition fault rollback exercise",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // OTA Status Card
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = tr("ota_release_notes"),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    val (color, label) = when (stage) {
                        OTALifecycleState.AVAILABLE -> ElectricCyan to "AVAILABLE"
                        OTALifecycleState.DOWNLOADING -> ElectricCyan to "DOWNLOADING ($progress%)"
                        OTALifecycleState.VERIFIED -> MetallicGold to "VERIFIED"
                        OTALifecycleState.INSTALLING -> MetallicGold to "FLASHING ($progress%)"
                        OTALifecycleState.VALIDATING -> ElectricCyan to "VALIDATING"
                        OTALifecycleState.COMPLETE -> EmeraldSuccess to "COMPLETE"
                        OTALifecycleState.FAILED -> Color(0xFFFF5252) to "FAILED"
                        OTALifecycleState.ROLLBACK -> Color(0xFFFFB300) to "ROLLBACK A/B"
                        OTALifecycleState.RESTORE -> EmeraldSuccess to "RESTORED"
                        else -> TextMuted to "IDLE"
                    }

                    Surface(
                        color = color.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = color,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (stage == OTALifecycleState.DOWNLOADING || stage == OTALifecycleState.INSTALLING) {
                    LinearProgressIndicator(
                        progress = { progress / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = ElectricCyan,
                        trackColor = LiCardBorder
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Text(
                    text = if (locale == AppLocale.ZH_CN)
                        "• 包含理想 Mind GPT 座舱大模型升级\n• 5C 快充预冷算法与魔毯悬架 3.0\n• 激光雷达点云识别算法优化"
                    else
                        "• Mind GPT Cockpit AI Upgrade\n• 5C Fast Charge Thermal Pre-Cooling & Magic Carpet 3.0\n• LiDAR Point Cloud ADAS Enhancements",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.triggerNormalOta() },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_trigger_normal_ota")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SystemUpdate,
                            contentDescription = "Trigger OTA",
                            tint = LiDarkBg,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tr("btn_trigger_ota"),
                            color = LiDarkBg,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    Button(
                        onClick = { viewModel.triggerInjectedOtaFault() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_inject_ota_fault")
                    ) {
                        Icon(
                            imageVector = Icons.Default.BugReport,
                            contentDescription = "Inject Fault",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tr("btn_inject_ota_fault"),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // OTA Audit Log Output
        Card(
            colors = CardDefaults.cardColors(containerColor = LiDarkBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "OTA 双语部署审计日志" else "OTA Bilingual Audit Trail",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (logs.isEmpty()) {
                    Text(
                        text = if (locale == AppLocale.ZH_CN) "点击上方按钮开始演练 OTA 部署流程" else "Click buttons above to simulate OTA rollout sequence",
                        fontSize = 11.sp,
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                } else {
                    logs.forEach { log ->
                        Text(
                            text = log,
                            fontSize = 11.sp,
                            color = if (log.contains("ERROR") || log.contains("错误")) Color(0xFFFF5252) else TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
