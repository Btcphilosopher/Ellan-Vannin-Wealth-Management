package com.example.vehicleapi.domain

import com.example.vehicleapi.localisation.AppLocale

enum class PowertrainType(val labelZh: String, val labelEn: String) {
    EREV("增程式电动 (EREV)", "Extended-Range EV (EREV)"),
    BEV("纯电动 (BEV)", "Battery Electric (BEV)")
}

enum class VehicleStatus(val labelZh: String, val labelEn: String) {
    PARKED("已泊车", "PARKED"),
    READY("车辆就绪", "READY"),
    DRIVING("行驶中", "DRIVING"),
    CHARGING("正在充电", "CHARGING"),
    MAINTENANCE("维保诊断", "IN SERVICE")
}

data class Vehicle(
    val vehicleId: String,
    val vin: String,
    val model: String, // e.g. "Li L9"
    val modelNameZh: String,
    val modelNameEn: String,
    val variant: String, // e.g. "Ultra", "Max", "Pro"
    val powertrainType: PowertrainType,
    val batteryCapacityKwh: Double,
    val cltcRangeKm: Int,
    val softwareVersion: String,
    val hardwareVersion: String,
    val region: String,
    val status: VehicleStatus
)

enum class TelemetryState(val labelZh: String, val labelEn: String) {
    MEASURED("实测", "MEASURED"),
    ESTIMATED("估算", "ESTIMATED"),
    MODELLED("模型计算", "MODELLED"),
    SIMULATED("模拟", "SIMULATED")
}

data class TelemetryQuality(
    val state: TelemetryState,
    val confidence: Float, // 0.0 to 1.0
    val source: String,
    val unit: String
)

data class VehicleDoors(
    val driverDoorLocked: Boolean = true,
    val passengerDoorLocked: Boolean = true,
    val rearLeftDoorLocked: Boolean = true,
    val rearRightDoorLocked: Boolean = true,
    val trunkOpen: Boolean = false,
    val frunkOpen: Boolean = false
)

data class VehicleClimate(
    val active: Boolean = true,
    val targetTemperature: Double = 22.0,
    val currentCabinTemperature: Double = 22.0,
    val outsideTemperature: Double = 18.0,
    val fanSpeed: Int = 3,
    val seatHeatingDriver: Int = 1, // 0..3
    val seatVentilationDriver: Int = 0
)

data class VehicleTyrePressure(
    val frontLeftBar: Double = 2.5,
    val frontRightBar: Double = 2.5,
    val rearLeftBar: Double = 2.5,
    val rearRightBar: Double = 2.5
)

data class VehiclePowertrain(
    val motorPowerKw: Double = 0.0,
    val motorRpm: Int = 0,
    val extenderRunning: Boolean = false,
    val extenderRpm: Int = 0,
    val fuelTankLevelPercent: Double = 85.0
)

data class VehicleSuspension(
    val airSuspensionHeightMm: Int = 0, // -40mm to +40mm
    val dampingMode: String = "Comfort" // Comfort, Sport, Standard
)

data class DriverAssistanceState(
    val systemActive: Boolean = true,
    val systemName: String = "Li AD Max 3.0",
    val cameraOperational: Boolean = true,
    val radarOperational: Boolean = true,
    val lidarOperational: Boolean = true,
    val surroundingObjectsCount: Int = 14,
    val currentRoadContext: String = "Urban Express / 城市快速路"
)

data class VehicleState(
    val vehicleId: String,
    val timestamp: Long,
    val latitude: Double,
    val longitude: Double,
    val speedKmh: Double,
    val headingDegrees: Double,
    val batterySOC: Double, // 0.0 to 100.0
    val estimatedRangeKm: Int,
    val chargingState: String, // "DISCONNECTED", "CHARGING", "COMPLETE"
    val doors: VehicleDoors,
    val climate: VehicleClimate,
    val tyrePressure: VehicleTyrePressure,
    val powertrain: VehiclePowertrain,
    val suspension: VehicleSuspension,
    val driverAssistance: DriverAssistanceState,
    val quality: TelemetryQuality
)
