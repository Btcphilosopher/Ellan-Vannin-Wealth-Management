package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val LiDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = LiDarkBg,
    primaryContainer = LiCardBg,
    onPrimaryContainer = ElectricCyan,
    secondary = MetallicGold,
    onSecondary = LiDarkBg,
    background = LiDarkBg,
    onBackground = TextPrimary,
    surface = LiCardBg,
    onSurface = TextPrimary,
    surfaceVariant = LiCardBorder,
    onSurfaceVariant = TextSecondary,
    error = CrimsonAlert,
    onError = TextPrimary
)

@Composable
fun LiAutoVehicleAPITheme(
    darkTheme: Boolean = true, // Default to dark automotive theme
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = LiDarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
