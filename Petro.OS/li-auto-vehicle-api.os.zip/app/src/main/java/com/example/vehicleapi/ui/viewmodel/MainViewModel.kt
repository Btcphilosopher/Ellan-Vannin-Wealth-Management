package com.example.vehicleapi.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.vehicleapi.assistant.AssistantToolResult
import com.example.vehicleapi.assistant.LiSmartAssistant
import com.example.vehicleapi.domain.CommandRequest
import com.example.vehicleapi.domain.CommandResponse
import com.example.vehicleapi.domain.CommandType
import com.example.vehicleapi.domain.FamilyProfile
import com.example.vehicleapi.domain.ScenarioParams
import com.example.vehicleapi.domain.ScenarioPrediction
import com.example.vehicleapi.domain.SecurityAuditEntry
import com.example.vehicleapi.domain.Vehicle
import com.example.vehicleapi.domain.VehicleEvent
import com.example.vehicleapi.domain.VehicleState
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.localisation.LocalisationManager
import com.example.vehicleapi.simulation.DigitalTwinEngine
import com.example.vehicleapi.simulation.FamilyManager
import com.example.vehicleapi.simulation.FleetGenerator
import com.example.vehicleapi.simulation.HaloGateway
import com.example.vehicleapi.simulation.OtaEngine
import com.example.vehicleapi.simulation.SimulatedHaloGateway
import com.example.vehicleapi.simulation.SmartChargingOptimizer
import com.example.vehicleapi.simulation.TelemetrySimulatorEngine
import com.example.vehicleapi.simulation.VehicleEventBus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class NavigationTab {
    LIVE_VEHICLE,
    CHARGING,
    OTA,
    DIGITAL_TWIN,
    FAMILY,
    ADAS,
    DIAGNOSTICS,
    API_EXPLORER,
    ENGINEERING
}

class MainViewModel : ViewModel() {
    val vehicles: List<Vehicle> = FleetGenerator.PRIMARY_VEHICLES

    private val _selectedVehicle = MutableStateFlow<Vehicle>(vehicles[0])
    val selectedVehicle: StateFlow<Vehicle> = _selectedVehicle.asStateFlow()

    private val telemetryEngine = TelemetrySimulatorEngine(_selectedVehicle.value)
    private val assistant = LiSmartAssistant(telemetryEngine)

    private val _vehicleState = MutableStateFlow<VehicleState>(telemetryEngine.getCurrentState())
    val vehicleState: StateFlow<VehicleState> = _vehicleState.asStateFlow()

    private val _activeTab = MutableStateFlow(NavigationTab.LIVE_VEHICLE)
    val activeTab: StateFlow<NavigationTab> = _activeTab.asStateFlow()

    val currentLocale: StateFlow<AppLocale> = LocalisationManager.currentLocale

    val haloGateway: HaloGateway = SimulatedHaloGateway()
    val otaEngine = OtaEngine()

    // Family Profile active
    private val _activeProfile = MutableStateFlow<FamilyProfile>(FamilyManager.PROFILES[0])
    val activeProfile: StateFlow<FamilyProfile> = _activeProfile.asStateFlow()

    // Digital Twin Scenario Lab
    private val _scenarioParams = MutableStateFlow(ScenarioParams())
    val scenarioParams: StateFlow<ScenarioParams> = _scenarioParams.asStateFlow()

    private val _scenarioPrediction = MutableStateFlow(
        DigitalTwinEngine.runWhatIfScenario(_scenarioParams.value, _vehicleState.value.batterySOC, _selectedVehicle.value.batteryCapacityKwh)
    )
    val scenarioPrediction: StateFlow<ScenarioPrediction> = _scenarioPrediction.asStateFlow()

    // Assistant interaction history
    private val _assistantHistory = MutableStateFlow<List<AssistantToolResult>>(emptyList())
    val assistantHistory: StateFlow<List<AssistantToolResult>> = _assistantHistory.asStateFlow()

    // Event Bus feed & Security Audit feed
    private val _recentEvents = MutableStateFlow<List<VehicleEvent>>(emptyList())
    val recentEvents: StateFlow<List<VehicleEvent>> = _recentEvents.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<SecurityAuditEntry>>(emptyList())
    val auditLogs: StateFlow<List<SecurityAuditEntry>> = _auditLogs.asStateFlow()

    init {
        // Collect telemetry ticker
        viewModelScope.launch {
            telemetryEngine.streamTelemetry(_selectedVehicle.value.vehicleId).collectLatest { state ->
                _vehicleState.value = state
            }
        }

        // Collect EventBus
        viewModelScope.launch {
            VehicleEventBus.events.collect { event ->
                _recentEvents.value = (listOf(event) + _recentEvents.value).take(50)
            }
        }

        // Collect Audit
        viewModelScope.launch {
            VehicleEventBus.auditLogs.collect { audit ->
                _auditLogs.value = (listOf(audit) + _auditLogs.value).take(50)
            }
        }

        // Initialize initial audit entry
        viewModelScope.launch {
            VehicleEventBus.publishAudit(
                SecurityAuditEntry(
                    actionZh = "系统平台初始化完成，连接模拟车队节点",
                    actionEn = "System platform initialized, connected to synthetic fleet nodes",
                    actor = "SYSTEM_HALO_OS",
                    vehicleId = _selectedVehicle.value.vehicleId,
                    result = "SUCCESS"
                )
            )
        }
    }

    fun selectVehicle(vehicle: Vehicle) {
        _selectedVehicle.value = vehicle
        _vehicleState.value = telemetryEngine.getCurrentState(vehicle.vehicleId)
        recalculateScenario()
    }

    fun setActiveTab(tab: NavigationTab) {
        _activeTab.value = tab
    }

    fun toggleLocale() {
        LocalisationManager.toggleLocale()
    }

    fun executeCommand(commandType: CommandType) {
        viewModelScope.launch {
            val request = CommandRequest(
                vehicleId = _selectedVehicle.value.vehicleId,
                commandType = commandType,
                userId = _activeProfile.value.nameEn
            )
            val response = haloGateway.sendCommand(request)
            _vehicleState.value = telemetryEngine.getCurrentState(_selectedVehicle.value.vehicleId)
        }
    }

    fun selectFamilyProfile(profile: FamilyProfile) {
        _activeProfile.value = profile
        viewModelScope.launch {
            VehicleEventBus.publishAudit(
                SecurityAuditEntry(
                    actionZh = "切换座舱账户档案: ${profile.nameZh} (座椅 ${profile.seatBackrestAngleDegrees}° / 空调 ${profile.preferredTemp}°C)",
                    actionEn = "Switched Cabin Profile: ${profile.nameEn} (Seat ${profile.seatBackrestAngleDegrees}° / Temp ${profile.preferredTemp}°C)",
                    actor = profile.nameEn,
                    vehicleId = _selectedVehicle.value.vehicleId
                )
            )
        }
    }

    fun updateScenarioParams(temp: Double, speed: Double, payload: Double, acLoad: Double) {
        val updated = ScenarioParams(
            ambientTemperatureC = temp,
            cruiseSpeedKmh = speed,
            payloadWeightKg = payload,
            acPowerPercent = acLoad
        )
        _scenarioParams.value = updated
        recalculateScenario()
    }

    private fun recalculateScenario() {
        _scenarioPrediction.value = DigitalTwinEngine.runWhatIfScenario(
            _scenarioParams.value,
            _vehicleState.value.batterySOC,
            _selectedVehicle.value.batteryCapacityKwh
        )
    }

    fun triggerNormalOta() {
        viewModelScope.launch {
            otaEngine.runNormalOtaSequence(_selectedVehicle.value.vehicleId)
        }
    }

    fun triggerInjectedOtaFault() {
        viewModelScope.launch {
            otaEngine.runFailedOtaSequenceWithRollback(_selectedVehicle.value.vehicleId)
        }
    }

    fun querySmartAssistant(query: String) {
        viewModelScope.launch {
            val result = assistant.processIntent(query, _vehicleState.value)
            _assistantHistory.value = listOf(result) + _assistantHistory.value
        }
    }
}
