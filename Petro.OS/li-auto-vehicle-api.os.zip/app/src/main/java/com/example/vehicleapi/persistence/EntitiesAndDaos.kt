package com.example.vehicleapi.persistence

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "vehicles")
data class VehicleEntity(
    @PrimaryKey val vehicleId: String,
    val vin: String,
    val model: String,
    val modelNameZh: String,
    val modelNameEn: String,
    val variant: String,
    val powertrainType: String,
    val batteryCapacityKwh: Double,
    val cltcRangeKm: Int,
    val softwareVersion: String,
    val hardwareVersion: String,
    val region: String,
    val status: String
)

@Entity(tableName = "vehicle_events")
data class VehicleEventEntity(
    @PrimaryKey val eventId: String,
    val vehicleId: String,
    val timestamp: Long,
    val eventType: String,
    val payload: String,
    val source: String
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val auditId: String,
    val timestamp: Long,
    val actionZh: String,
    val actionEn: String,
    val actor: String,
    val vehicleId: String,
    val result: String,
    val clientIp: String
)

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles")
    fun getAllVehicles(): Flow<List<VehicleEntity>>

    @Query("SELECT * FROM vehicles WHERE vehicleId = :id LIMIT 1")
    suspend fun getVehicleById(id: String): VehicleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicles(vehicles: List<VehicleEntity>)
}

@Dao
interface EventDao {
    @Query("SELECT * FROM vehicle_events WHERE vehicleId = :vehicleId ORDER BY timestamp DESC LIMIT 50")
    fun getRecentEvents(vehicleId: String): Flow<List<VehicleEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: VehicleEventEntity)
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudit(audit: AuditLogEntity)
}

@Database(
    entities = [VehicleEntity::class, VehicleEventEntity::class, AuditLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao
    abstract fun eventDao(): EventDao
    abstract fun auditDao(): AuditDao
}
