package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.LiAutoVehicleAPITheme
import com.example.ui.theme.LiCardBg
import com.example.ui.theme.LiCardBorder
import com.example.ui.theme.LiDarkBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.localisation.LocalAppLocale
import com.example.vehicleapi.localisation.tr
import com.example.vehicleapi.ui.components.PlatformTopHeader
import com.example.vehicleapi.ui.screens.ApiExplorerScreen
import com.example.vehicleapi.ui.screens.DigitalTwinScreen
import com.example.vehicleapi.ui.screens.DriverAssistanceScreen
import com.example.vehicleapi.ui.screens.EngineeringModeScreen
import com.example.vehicleapi.ui.screens.FamilyAccountScreen
import com.example.vehicleapi.ui.screens.LiveVehicleDashboardScreen
import com.example.vehicleapi.ui.screens.OtaRolloutScreen
import com.example.vehicleapi.ui.screens.ServiceDiagnosticsScreen
import com.example.vehicleapi.ui.screens.SmartChargingScreen
import com.example.vehicleapi.ui.viewmodel.MainViewModel
import com.example.vehicleapi.ui.viewmodel.NavigationTab

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LiAutoVehicleAPITheme {
                MainAppScreen()
            }
        }
    }
}

@Composable
fun MainAppScreen(mainViewModel: MainViewModel = viewModel()) {
    val selectedVehicle by mainViewModel.selectedVehicle.collectAsState()
    val activeTab by mainViewModel.activeTab.collectAsState()
    val currentLocale by mainViewModel.currentLocale.collectAsState()

    CompositionLocalProvider(LocalAppLocale provides currentLocale) {
        Scaffold(
            topBar = {
                PlatformTopHeader(
                    currentVehicle = selectedVehicle,
                    vehicles = mainViewModel.vehicles,
                    currentLocale = currentLocale,
                    onSelectVehicle = { mainViewModel.selectVehicle(it) },
                    onToggleLocale = { mainViewModel.toggleLocale() }
                )
            },
            bottomBar = {
                ScrollableTabRow(
                    selectedTabIndex = activeTab.ordinal,
                    containerColor = LiCardBg,
                    contentColor = ElectricCyan,
                    edgePadding = 8.dp,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[activeTab.ordinal]),
                            color = ElectricCyan
                        )
                    },
                    divider = {},
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    NavigationTab.entries.forEach { tab ->
                        val isSelected = activeTab == tab
                        val (icon, key) = when (tab) {
                            NavigationTab.LIVE_VEHICLE -> Icons.Default.ElectricCar to "tab_live_vehicle"
                            NavigationTab.CHARGING -> Icons.Default.EvStation to "tab_charging"
                            NavigationTab.OTA -> Icons.Default.SystemUpdate to "tab_ota"
                            NavigationTab.DIGITAL_TWIN -> Icons.Default.AccountTree to "tab_digital_twin"
                            NavigationTab.FAMILY -> Icons.Default.FamilyRestroom to "tab_family"
                            NavigationTab.ADAS -> Icons.Default.CompassCalibration to "tab_adas"
                            NavigationTab.DIAGNOSTICS -> Icons.Default.HealthAndSafety to "tab_diagnostics"
                            NavigationTab.API_EXPLORER -> Icons.Default.Code to "tab_api_explorer"
                            NavigationTab.ENGINEERING -> Icons.Default.Build to "tab_engineering"
                        }

                        Tab(
                            selected = isSelected,
                            onClick = { mainViewModel.setActiveTab(tab) },
                            modifier = Modifier.testTag("tab_${tab.name.lowercase()}"),
                            text = {
                                Text(
                                    text = tr(key),
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) ElectricCyan else TextMuted
                                )
                            },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = tr(key),
                                    tint = if (isSelected) ElectricCyan else TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        )
                    }
                }
            },
            containerColor = LiDarkBg
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (activeTab) {
                    NavigationTab.LIVE_VEHICLE -> LiveVehicleDashboardScreen(mainViewModel)
                    NavigationTab.CHARGING -> SmartChargingScreen(mainViewModel)
                    NavigationTab.OTA -> OtaRolloutScreen(mainViewModel)
                    NavigationTab.DIGITAL_TWIN -> DigitalTwinScreen(mainViewModel)
                    NavigationTab.FAMILY -> FamilyAccountScreen(mainViewModel)
                    NavigationTab.ADAS -> DriverAssistanceScreen(mainViewModel)
                    NavigationTab.DIAGNOSTICS -> ServiceDiagnosticsScreen(mainViewModel)
                    NavigationTab.API_EXPLORER -> ApiExplorerScreen(mainViewModel)
                    NavigationTab.ENGINEERING -> EngineeringModeScreen(mainViewModel)
                }
            }
        }
    }
}
