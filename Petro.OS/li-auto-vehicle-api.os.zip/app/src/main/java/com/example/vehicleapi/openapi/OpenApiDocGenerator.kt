package com.example.vehicleapi.openapi

object OpenApiDocGenerator {
    fun generateBilingualOpenApiJson(): String {
        return """
{
  "openapi": "3.0.3",
  "info": {
    "title": "LI AUTO VEHICLE API.OS / 理想汽车智能汽车 API 平台",
    "description": "Bilingual Chinese/English REST & WebSocket Vehicle Compute Platform API based on Li Auto Halo OS architecture. (双语智能汽车 API 平台与分布式计算操作层)",
    "version": "1.0.0",
    "contact": {
      "name": "Li Auto Vehicle Engineering Platform Team",
      "url": "https://www.lixiang.com"
    }
  },
  "servers": [
    {
      "url": "https://api.vehicle.li-auto.sim/api/v1",
      "description": "Simulated Gateway / 模拟网关环境"
    }
  ],
  "paths": {
    "/vehicles": {
      "get": {
        "summary": "获取车辆列表 / List Vehicles",
        "description": "返回当前家庭与授权账号下的所有智能车辆列表。 Returns all vehicles accessible under the authorized account.",
        "responses": {
          "200": {
            "description": "成功 / Successful response"
          }
        }
      }
    },
    "/vehicles/{id}/state": {
      "get": {
        "summary": "获取实时车辆状态 / Get Vehicle State",
        "description": "获取指定车辆的实时 GPS、电池 SOC、续航、车门与空调状态。 Retrieves real-time vehicle status including SOC, range, doors and climate.",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "description": "车辆唯一标识符 / Vehicle ID (e.g. LI-L9-TEST-001)"
          }
        ],
        "responses": {
          "200": {
            "description": "车辆实时状态 / Vehicle Real-Time State"
          }
        }
      }
    },
    "/vehicles/{id}/commands/lock": {
      "post": {
        "summary": "锁车指令 / Lock Vehicle Command",
        "description": "安全授权高层指令：锁定全车车门。 Safe authorized command to lock all vehicle doors.",
        "responses": {
          "200": {
            "description": "指令执行结果 / Command Execution Result"
          }
        }
      }
    },
    "/vehicles/{id}/commands/climate": {
      "post": {
        "summary": "空调控制 / Climate Control Command",
        "description": "设置三区座舱空调目标温度与预热状态。 Set 3-zone cabin target temperature and preconditioning status.",
        "responses": {
          "200": {
            "description": "指令执行结果 / Command Execution Result"
          }
        }
      }
    },
    "/vehicles/{id}/digitaltwin/predict": {
      "post": {
        "summary": "数字孪生预测 (What-If) / Digital Twin What-If Prediction",
        "description": "根据温度、车速、负载与空调负荷进行路线能耗与到达 SOC 精准预测。 Predictive modeling for range and energy under custom driving scenarios.",
        "responses": {
          "200": {
            "description": "数字孪生预测结果 / Digital Twin Scenario Output"
          }
        }
      }
    }
  }
}
        """.trimIndent()
    }
}
