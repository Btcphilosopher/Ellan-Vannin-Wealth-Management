package com.example.vehicleapi.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LiCardBg
import com.example.ui.theme.LiCardBorder
import com.example.ui.theme.LiDarkBg
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.localisation.tr
import com.example.vehicleapi.ui.components.MetricCard
import com.example.vehicleapi.ui.components.SafetyBoundaryBanner
import com.example.vehicleapi.ui.viewmodel.MainViewModel

@Composable
fun DriverAssistanceScreen(viewModel: MainViewModel) {
    val state by viewModel.vehicleState.collectAsState()
    val locale by viewModel.currentLocale.collectAsState()
    val adas = state.driverAssistance

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "Li AD Max 3.0 智能驾驶辅助感知与环境建模" else "Li AD Max 3.0 Perception & Road Context",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyan
                )
                Text(
                    text = if (locale == AppLocale.ZH_CN) "激光雷达 + 毫米波雷达 + 11高清摄像头点云融合感知" else "LiDAR + Millimeter Radar + 11 HD Cameras Cloud Fusion",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Radar Point Cloud Map Canvas Simulation
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "感知目标三维点云雷达阵列" else "3D Point Cloud Perception Array",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                Canvas(modifier = Modifier.fillMaxWidth().height(160.dp)) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f

                    // Concentric radar rings
                    for (r in listOf(30f, 60f, 90f)) {
                        drawCircle(
                            color = ElectricCyan.copy(alpha = 0.2f),
                            radius = r * 1.5f,
                            center = Offset(cx, cy),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx())
                        )
                    }

                    // Ego vehicle center dot
                    drawCircle(color = MetallicGold, radius = 8.dp.toPx(), center = Offset(cx, cy))

                    // Surrounding obstacles simulated
                    val obstacles = listOf(
                        Offset(cx - 50f, cy - 80f),
                        Offset(cx + 70f, cy - 40f),
                        Offset(cx - 30f, cy + 60f),
                        Offset(cx + 80f, cy + 70f)
                    )

                    obstacles.forEach { pos ->
                        drawCircle(color = EmeraldSuccess, radius = 5.dp.toPx(), center = pos)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Tracked Dynamic Obstacles: ${adas.surroundingObjectsCount} | Context: ${adas.currentRoadContext}",
                    fontSize = 11.sp,
                    color = ElectricCyan,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard(
                titleZh = "128线激光雷达",
                titleEn = "128-Line LiDAR",
                value = if (adas.lidarOperational) "ONLINE (正常)" else "OFFLINE",
                accentColor = EmeraldSuccess,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleZh = "双 NVIDIA Orin-X",
                titleEn = "Dual Orin-X Compute",
                value = "508 TOPS",
                accentColor = ElectricCyan,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        SafetyBoundaryBanner()
    }
}
