package com.example.vehicleapi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LiCardBg
import com.example.ui.theme.LiCardBorder
import com.example.ui.theme.LiDarkBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.openapi.OpenApiDocGenerator
import com.example.vehicleapi.ui.viewmodel.MainViewModel

@Composable
fun ApiExplorerScreen(viewModel: MainViewModel) {
    val locale by viewModel.currentLocale.collectAsState()
    val openApiJson = remember { OpenApiDocGenerator.generateBilingualOpenApiJson() }
    var selectedEndpointResponse by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "OpenAPI 3.0.3 规范与 REST / WS 交互测试" else "OpenAPI 3.0.3 Spec & Live API Explorer",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyan
                )
                Text(
                    text = if (locale == AppLocale.ZH_CN) "自动生成双语 API 描述、示例 Payload 与 WebSocket 端点" else "Automatically generated bilingual OpenAPI schema and payloads",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Endpoint Execution Buttons
        Text(
            text = if (locale == AppLocale.ZH_CN) "常用 REST API 端点模拟调用" else "Sample REST Endpoints",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    selectedEndpointResponse = """
{
  "status": 200,
  "endpoint": "GET /api/v1/vehicles/LI-L9-TEST-001/state",
  "data": {
    "vehicle_id": "LI-L9-TEST-001",
    "soc": 72.0,
    "range_km": 486,
    "cabin_temp": 22.0,
    "charging": false,
    "quality": "MEASURED"
  }
}
                    """.trimIndent()
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f).testTag("btn_api_get_state")
            ) {
                Text(text = "GET /state", color = ElectricCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }

            Button(
                onClick = {
                    selectedEndpointResponse = """
{
  "status": 200,
  "endpoint": "POST /api/v1/vehicles/LI-L9-TEST-001/commands/lock",
  "result": "SUCCESS",
  "audit_id": "aud_019283019",
  "execution_ms": 38
}
                    """.trimIndent()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f).testTag("btn_api_post_lock")
            ) {
                Text(text = "POST /lock", color = EmeraldSuccess, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }

        if (selectedEndpointResponse.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = LiDarkBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldSuccess),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = "Response Output:", fontSize = 11.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = selectedEndpointResponse, fontSize = 11.sp, color = TextPrimary, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // OpenAPI JSON Viewer Card
        Card(
            colors = CardDefaults.cardColors(containerColor = LiDarkBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "OpenAPI JSON Schema:", fontSize = 12.sp, color = TextMuted, fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = openApiJson,
                    fontSize = 10.sp,
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
