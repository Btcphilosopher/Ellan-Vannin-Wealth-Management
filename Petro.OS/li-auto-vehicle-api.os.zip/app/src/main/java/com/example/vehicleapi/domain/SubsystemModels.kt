package com.example.vehicleapi.domain

import java.util.UUID

// Events
enum class EventType {
    VehicleStarted, VehicleStopped, VehicleLocked, VehicleUnlocked,
    ChargingStarted, ChargingPaused, ChargingCompleted, ChargingFault,
    NavigationStarted, NavigationCompleted,
    OTAAvailable, OTAStarted, OTACompleted, OTAFailed, OTARollback,
    DiagnosticWarning, ServiceRequired
}

data class VehicleEvent(
    val eventId: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: EventType,
    val payload: String,
    val source: String = "Li Halo OS / Vehicle Compute",
    val schemaVersion: String = "1.0",
    val correlationId: String = UUID.randomUUID().toString()
)

// Commands
enum class CommandType {
    LOCK, UNLOCK, START_CLIMATE, STOP_CLIMATE, SET_TEMPERATURE, LOCATE, START_CHARGING, STOP_CHARGING
}

data class CommandRequest(
    val commandId: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val commandType: CommandType,
    val parameters: Map<String, String> = emptyMap(),
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String = "user_owner_01"
)

data class CommandResponse(
    val commandId: String,
    val vehicleId: String,
    val success: Boolean,
    val messageZh: String,
    val messageEn: String,
    val timestamp: Long = System.currentTimeMillis(),
    val executionTimeMs: Long = 42L
)

// Charging
enum class ChargingPortStatus {
    DISCONNECTED, AUTHENTICATING, CONNECTED, SCHEDULED, CHARGING, PAUSED, COMPLETE, FAULT
}

data class ChargingSession(
    val sessionId: String,
    val vehicleId: String,
    val stationName: String,
    val chargerPowerKw: Double,
    val initialSoc: Double,
    val targetSoc: Double,
    val currentSoc: Double,
    val startTime: Long,
    val estimatedCompletionTime: Long,
    val departureTime: Long,
    val totalEnergyKwh: Double,
    val estimatedCostCny: Double,
    val status: ChargingPortStatus
)

// OTA
enum class OTALifecycleState {
    AVAILABLE, DOWNLOADING, VERIFIED, SCHEDULED, INSTALLING, VALIDATING, COMPLETE, FAILED, ROLLBACK, RESTORE, RETRY
}

data class SoftwareRelease(
    val releaseId: String,
    val version: String, // e.g., "Li OS 8.2.0"
    val releaseNotesZh: String,
    val releaseNotesEn: String,
    val packageSizeMb: Double,
    val hashSha256: String,
    val targetModels: List<String>
)

data class OTADeployment(
    val jobId: String,
    val vehicleId: String,
    val version: String,
    val stage: OTALifecycleState,
    val progressPercent: Int,
    val logHistory: List<String>,
    val startTime: Long,
    val updateTime: Long
)

// Family Profiles
enum class UserRole(val labelZh: String, val labelEn: String) {
    OWNER("车主", "Owner"),
    PARTNER("伴侣", "Partner"),
    PARENT("父母", "Parent"),
    CHILD("子女", "Child"),
    GUEST("访客", "Guest")
}

data class FamilyProfile(
    val profileId: String,
    val nameZh: String,
    val nameEn: String,
    val role: UserRole,
    val seatBackrestAngleDegrees: Int,
    val seatSlideMm: Int,
    val preferredTemp: Double,
    val ambientColorHex: String,
    val preferredLanguage: String,
    val avatarUrl: String
)

// Diagnostics & SBOM
enum class DiagnosticSeverity { GOOD, ATTENTION, WARNING, SERVICE_REQUIRED }

data class DiagnosticCode(
    val code: String, // e.g. "DTC-BATT-042"
    val subsystemZh: String,
    val subsystemEn: String,
    val descriptionZh: String,
    val descriptionEn: String,
    val severity: DiagnosticSeverity,
    val timestamp: Long
)

data class SubsystemHealth(
    val subsystemKey: String,
    val nameZh: String,
    val nameEn: String,
    val severity: DiagnosticSeverity,
    val statusMessageZh: String,
    val statusMessageEn: String
)

data class SoftwareComponent(
    val name: String,
    val category: String, // Cockpit, ADAS, Powertrain, Gateway, Battery
    val version: String,
    val buildHash: String,
    val statusZh: String,
    val statusEn: String
)

// Digital Twin Scenario
data class ScenarioParams(
    val ambientTemperatureC: Double = 22.0,
    val cruiseSpeedKmh: Double = 100.0,
    val payloadWeightKg: Double = 150.0,
    val acPowerPercent: Double = 30.0,
    val batteryDegradationPercent: Double = 2.0
)

data class ScenarioPrediction(
    val predictedRangeKm: Int,
    val energyConsumptionKwhPer100Km: Double,
    val predictedArrivalSocPercent: Double,
    val estimatedTravelMinutes: Int,
    val chargingNeededOnRoute: Boolean,
    val totalBatteryHeatGeneratedC: Double
)

// Audit Log
data class SecurityAuditEntry(
    val auditId: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val actionZh: String,
    val actionEn: String,
    val actor: String,
    val vehicleId: String,
    val result: String = "SUCCESS",
    val clientIp: String = "192.168.1.108"
)
