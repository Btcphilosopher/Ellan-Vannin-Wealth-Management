package com.example.vehicleapi.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LiCardBg
import com.example.ui.theme.LiCardBorder
import com.example.ui.theme.LiDarkBg
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vehicleapi.domain.CommandType
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.localisation.tr
import com.example.vehicleapi.simulation.SmartChargingOptimizer
import com.example.vehicleapi.ui.components.MetricCard
import com.example.vehicleapi.ui.viewmodel.MainViewModel

@Composable
fun SmartChargingScreen(viewModel: MainViewModel) {
    val vehicle by viewModel.selectedVehicle.collectAsState()
    val locale by viewModel.currentLocale.collectAsState()

    var currentSocInput by remember { mutableDoubleStateOf(32.0) }
    var targetSocInput by remember { mutableDoubleStateOf(80.0) }

    val result = remember(currentSocInput, targetSocInput, vehicle.batteryCapacityKwh) {
        SmartChargingOptimizer.calculateOptimization(
            currentSoc = currentSocInput,
            targetSoc = targetSocInput,
            batteryCapacityKwh = vehicle.batteryCapacityKwh,
            chargerKw = 120.0
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Signature Demo Header
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = tr("demo_2_title"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldSuccess
                )
                Text(
                    text = if (locale == AppLocale.ZH_CN)
                        "根据出发时间与谷段电价自动计算最优充电策略"
                    else
                        "Automatic charging strategy optimizer based on departure time and TOU tariff",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Preset Signature Scenario Parameters Box
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (locale == AppLocale.ZH_CN) "智能充电演算参数" else "Smart Charging Parameters",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Surface(
                        color = MetallicGold.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "5C 800V Ultra Fast Charging",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MetallicGold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Current SOC slider
                Text(
                    text = "${tr("battery_soc")} (${currentSocInput.toInt()}%)",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Slider(
                    value = currentSocInput.toFloat(),
                    onValueChange = { currentSocInput = it.toDouble() },
                    valueRange = 10f..80f,
                    colors = SliderDefaults.colors(
                        thumbColor = ElectricCyan,
                        activeTrackColor = ElectricCyan
                    )
                )

                // Target SOC slider
                Text(
                    text = "${tr("charging_target_soc")} (${targetSocInput.toInt()}%)",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Slider(
                    value = targetSocInput.toFloat(),
                    onValueChange = { targetSocInput = it.toDouble() },
                    valueRange = 50f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = EmeraldSuccess,
                        activeTrackColor = EmeraldSuccess
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Optimization Results
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard(
                titleZh = "充电起始时间",
                titleEn = "Start Time",
                value = result.optimalStartTimestamp,
                accentColor = EmeraldSuccess,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleZh = "完成充电时间",
                titleEn = "Completion",
                value = result.estimatedCompletionTimestamp,
                accentColor = ElectricCyan,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard(
                titleZh = "预计补充电量",
                titleEn = "Energy Added",
                value = "${result.energyAddedKwh}",
                unit = "kWh",
                accentColor = MetallicGold,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                titleZh = "预估谷段电费",
                titleEn = "Estimated Cost",
                value = "￥${result.totalCostCny}",
                accentColor = EmeraldSuccess,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Charging Curve Visualizer Canvas
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "5C 麒麟电池 SOC 充电功率曲线" else "5C Qilin Battery SOC & Power Curve",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                ) {
                    val w = size.width
                    val h = size.height

                    // Grid lines
                    for (i in 1..3) {
                        val y = h * (i / 4f)
                        drawLine(
                            color = LiCardBorder,
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f
                        )
                    }

                    // Curve path
                    val path = Path().apply {
                        moveTo(0f, h * 0.8f)
                        cubicTo(w * 0.2f, h * 0.2f, w * 0.6f, h * 0.3f, w, h * 0.7f)
                    }

                    drawPath(
                        path = path,
                        color = EmeraldSuccess,
                        style = Stroke(width = 3.dp.toPx())
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { viewModel.executeCommand(CommandType.START_CHARGING) },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_start_smart_charging")
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Start Charging",
                        tint = LiDarkBg
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = tr("cmd_start_charging"),
                        color = LiDarkBg,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
