package com.example.vehicleapi.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LiCardBg
import com.example.ui.theme.LiCardBorder
import com.example.ui.theme.LiDarkBg
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.localisation.tr
import com.example.vehicleapi.simulation.FamilyManager
import com.example.vehicleapi.ui.components.MetricCard
import com.example.vehicleapi.ui.viewmodel.MainViewModel

@Composable
fun FamilyAccountScreen(viewModel: MainViewModel) {
    val activeProfile by viewModel.activeProfile.collectAsState()
    val locale by viewModel.currentLocale.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LiDarkBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Demo 5 Header
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = tr("demo_5_title"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyan
                )
                Text(
                    text = if (locale == AppLocale.ZH_CN)
                        "爸爸、妈妈、孩子、访客四大家庭角色偏好无缝切换与智能座舱空间复位"
                    else
                        "Dad, Mum, Child, Guest family profile switching & cabin preference memory",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Profile Selector Cards
        Text(
            text = if (locale == AppLocale.ZH_CN) "家庭成员档案 (点击切换)" else "Family Profiles (Click to Activate)",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FamilyManager.PROFILES.forEach { profile ->
                val isSelected = activeProfile.profileId == profile.profileId
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) ElectricCyan.copy(alpha = 0.12f) else LiCardBg
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) ElectricCyan else LiCardBorder
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_${profile.profileId}")
                        .clickable { viewModel.selectFamilyProfile(profile) }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(Color(android.graphics.Color.parseColor(profile.ambientColorHex)))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (locale == AppLocale.ZH_CN) profile.nameZh else profile.nameEn,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Role: ${profile.role.labelEn} | Temp: ${profile.preferredTemp}°C",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Active Profile",
                                tint = ElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active Cabin Preference Summary
        Card(
            colors = CardDefaults.cardColors(containerColor = LiCardBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, LiCardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (locale == AppLocale.ZH_CN) "当前座舱物理偏好同步状态" else "Active Cabin Physical Sync State",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard(
                        titleZh = "零重力座椅靠背角度",
                        titleEn = "Seat Backrest Angle",
                        value = "${activeProfile.seatBackrestAngleDegrees}°",
                        accentColor = ElectricCyan,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        titleZh = "滑轨位置记忆",
                        titleEn = "Slide Position",
                        value = "${activeProfile.seatSlideMm} mm",
                        accentColor = MetallicGold,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard(
                        titleZh = "专属预热温度",
                        titleEn = "Target Temperature",
                        value = "${activeProfile.preferredTemp} ℃",
                        accentColor = EmeraldSuccess,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        titleZh = "256色氛围灯",
                        titleEn = "Ambient Light Hex",
                        value = activeProfile.ambientColorHex,
                        accentColor = ElectricCyan,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
