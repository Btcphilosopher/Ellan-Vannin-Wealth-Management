package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.vehicleapi.domain.OTALifecycleState
import com.example.vehicleapi.domain.ScenarioParams
import com.example.vehicleapi.localisation.AppLocale
import com.example.vehicleapi.localisation.LocalisationManager
import com.example.vehicleapi.simulation.DigitalTwinEngine
import com.example.vehicleapi.simulation.FleetGenerator
import com.example.vehicleapi.simulation.OtaEngine
import com.example.vehicleapi.simulation.SmartChargingOptimizer
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context app_name`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Li Auto API.OS", appName)
  }

  @Test
  fun `bilingual localisation dictionary returns expected Chinese and English values`() {
    val titleZh = LocalisationManager.getString("app_title", AppLocale.ZH_CN)
    val titleEn = LocalisationManager.getString("app_title", AppLocale.EN_US)

    assertEquals("理想汽车智能汽车 API 平台", titleZh)
    assertEquals("Li Auto Vehicle API.OS Platform", titleEn)
  }

  @Test
  fun `synthetic fleet contains primary vehicles including Li L9 and Li MEGA`() {
    val fleet = FleetGenerator.PRIMARY_VEHICLES
    assertTrue(fleet.size >= 7)

    val l9 = fleet.find { it.vehicleId == "LI-L9-TEST-001" }
    assertNotNull(l9)
    assertEquals("Li L9", l9?.model)

    val mega = fleet.find { it.vehicleId == "LI-MEGA-TEST-002" }
    assertNotNull(mega)
    assertEquals("Li MEGA", mega?.model)
  }

  @Test
  fun `smart charging optimizer calculates duration and cost accurately`() {
    val result = SmartChargingOptimizer.calculateOptimization(
      currentSoc = 32.0,
      targetSoc = 80.0,
      batteryCapacityKwh = 52.3,
      chargerKw = 120.0
    )

    assertTrue(result.energyAddedKwh > 20.0)
    assertTrue(result.totalCostCny > 0.0)
    assertEquals(42, result.offPeakSavingsPercent)
  }

  @Test
  fun `digital twin physics engine calculates range under cold climate scenario`() {
    val normalScenario = ScenarioParams(ambientTemperatureC = 22.0, cruiseSpeedKmh = 100.0)
    val coldScenario = ScenarioParams(ambientTemperatureC = -15.0, cruiseSpeedKmh = 100.0)

    val predNormal = DigitalTwinEngine.runWhatIfScenario(normalScenario, baseSoc = 80.0)
    val predCold = DigitalTwinEngine.runWhatIfScenario(coldScenario, baseSoc = 80.0)

    assertTrue(predCold.energyConsumptionKwhPer100Km > predNormal.energyConsumptionKwhPer100Km)
    assertTrue(predCold.predictedRangeKm < predNormal.predictedRangeKm)
  }

  @Test
  fun `ota engine injected fault triggers automatic rollback and restore`() = runBlocking {
    val ota = OtaEngine()
    ota.runFailedOtaSequenceWithRollback("LI-L9-TEST-001")

    assertEquals(OTALifecycleState.RESTORE, ota.currentStage.value)
    assertTrue(ota.logs.value.any { it.contains("ROLLBACK") || it.contains("回滚") })
  }
}
