import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// API Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'HEALTHY',
    system: 'BEETLE DIGITAL TWIN ENGINE',
    version: '3.2.0-PROD',
    timestamp: new Date().toISOString()
  });
});

// Gemini AI Engineering Assistant Server Endpoint
app.post('/api/ai/engineering-assistant', async (req, res) => {
  try {
    const { query, context } = req.body;
    const apiKey = process.env['GEMINI_API_KEY'];

    if (!apiKey) {
      res.json({
        answer: `[VIRTUAL AI TWIN ANALYZER]: Analyse basierend auf den aktuellen Fahrzeugparametern:\n\n- Gesamtmasse: ${context?.mass?.total_mass_kg ?? 745} kg\n- Schwerpunkt (CG): [${context?.mass?.cg_x_mm ?? 0}, ${context?.mass?.cg_y_mm ?? 0}, ${context?.mass?.cg_z_mm ?? 510}] mm\n- Aerodynamik cw: ${context?.aero?.drag_coefficient_cd ?? 0.28}\n- Produktionsengpass: ${context?.factory?.bottleneck ?? 'ST-03-PAINT'} (Taktzeit: ${context?.factory?.taktzeit ?? 65}s)\n\n(Hinweis: GEMINI_API_KEY nicht im Backend konfiguriert; synthesebasierte Echtzeit-Berechnung ausgegeben.)`,
        suggestedActions: [
          { label: 'Massenanalyse vertiefen', actionType: 'QUERY_MASS' },
          { label: 'Taktzeit & Engpass prüfen', actionType: 'QUERY_BOTTLENECK' }
        ]
      });
      return;
    }

    const ai = new GoogleGenAI({ apiKey });
    const prompt = `User Query: ${query}\n\nLive Vehicle Digital Twin Context:\n${JSON.stringify(context, null, 2)}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: `You are "Beetle Engineering AI", the highly specialized automotive computational digital twin AI assistant for the synthetic Beetle vehicle platform.
You analyze real-time vehicle geometry, mass & center-of-gravity rollups, aerodynamic drag (Cd, frontal area, power demand), ergonomics (H-point, headroom, legroom), manufacturing production line metrics (11 stations, taktzeit, JPH, OEE, robot bottlenecks, Robot 17 failure state), quality assurance (gap and flush Spaltmaß, bolt torque-angle, paint layer microns, defects), and unit cost BOM breakdowns.
Always answer in the language requested by the user (prefer German if asked in German, English if asked in English).
Be precise, technically sound, and format responses with clean markdown lists and key metrics.
Always treat this vehicle strictly as a synthetic computational engineering twin model.`
      }
    });

    res.json({
      answer: response.text ?? 'Analyse abgeschlossen.',
      suggestedActions: [
        { label: 'Dachgeometrie prüfen', actionType: 'QUERY_ROOF_DELTA' },
        { label: 'Engpass-Simulation', actionType: 'QUERY_BOTTLENECK' }
      ]
    });
    return;
  } catch (error: unknown) {
    console.error('AI Assistant Error:', error);
    const msg = error instanceof Error ? error.message : 'Internal AI Error';
    res.status(500).json({ error: msg });
    return;
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
