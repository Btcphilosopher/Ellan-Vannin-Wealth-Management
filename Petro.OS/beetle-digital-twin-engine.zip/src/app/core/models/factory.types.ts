// Beetle Virtual Factory & Production Types

export type StationId = 
  | 'ST-01-BODY'
  | 'ST-02-WELDING'
  | 'ST-03-PAINT'
  | 'ST-04-UNDERBODY'
  | 'ST-05-ELECTRICAL'
  | 'ST-06-INTERIOR'
  | 'ST-07-WINDOWS'
  | 'ST-08-SEATS'
  | 'ST-09-WHEELS'
  | 'ST-10-SOFTWARE'
  | 'ST-11-ENDTEST';

export interface RobotUnit {
  robot_id: string;
  name: string;
  type: 'Spot Welding' | 'Laser Brazing' | 'Electrostatic Spray' | 'Heavy Marriage Lift' | 'Vision Screwdriver' | 'Glass Placement' | 'Wheel Torquer';
  station_id: StationId;
  payload_kg: number;
  reach_mm: number;
  cycle_time_s: number;
  status: 'OPERATIONAL' | 'BUSY' | 'MAINTENANCE_REQUIRED' | 'FAULT_STOPPED';
  kinematic_joint_angles_deg: number[];
  efficiency_oee_percent: number;
  fault_history_count: number;
  position_coords: [number, number, number]; // [X, Y, Z] on factory floor
}

export interface ProductionStation {
  station_id: StationId;
  station_number: number;
  name: string;
  german_name: string;
  description: string;
  cycle_time_target_s: number;
  cycle_time_actual_s: number;
  operators_count: number;
  robots: RobotUnit[];
  buffer_capacity: number;
  buffer_current: number;
  oee_percent: number;
  is_bottleneck: boolean;
  status: 'NORMAL' | 'SLOWDOWN' | 'BLOCKED' | 'STARVED';
  tools: string[];
  consumed_components: string[];
  energy_consumption_kw: number;
}

export interface ManufacturingBOMItem {
  bom_id: string;
  component_id: string;
  part_number: string;
  name: string;
  quantity: number;
  station_id: StationId;
  operation_name: string;
  tool_id: string;
  assigned_worker_role: string;
  machine_id: string;
  quality_check_type: string;
  duration_seconds: number;
}

export interface VehicleProductionInstance {
  vin: string;
  vehicle_name: string;
  current_station_id: StationId;
  progress_percent: number; // 0 - 100
  started_at: string;
  state: 'BODY_IN_WHITE' | 'PAINTED' | 'TRIMMED' | 'MARRIED' | 'ASSEMBLED' | 'TESTING' | 'PASSED' | 'QUALITY_HOLD';
  quality_gate_passed: boolean;
  defect_count: number;
  position_progress_m: number; // conveyor position
}

export interface FactoryPlantMetrics {
  total_units_produced_today: number;
  target_units_today: number;
  line_speed_jph: number; // Jobs Per Hour
  taktzeit_s: number;
  overall_line_oee: number;
  active_bottleneck_station: StationId;
  active_vehicles_on_line: VehicleProductionInstance[];
  total_energy_kwh: number;
  co2_intensity_kg: number;
}
