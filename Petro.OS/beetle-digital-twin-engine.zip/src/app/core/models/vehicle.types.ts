// Beetle Digital Twin - Canonical Types & Data Models

export interface VehicleParameters {
  vehicle_length: number;       // mm (e.g. 4080)
  vehicle_width: number;        // mm (e.g. 1720)
  vehicle_height: number;       // mm (e.g. 1500)
  wheelbase: number;            // mm (e.g. 2540)
  front_overhang: number;       // mm (e.g. 740)
  rear_overhang: number;        // mm (e.g. 800)
  track_front: number;          // mm (e.g. 1510)
  track_rear: number;           // mm (e.g. 1500)
  roof_height: number;          // mm (e.g. 1500)
  windshield_angle: number;     // deg (e.g. 54)
  rear_glass_angle: number;     // deg (e.g. 48)
  hood_length: number;          // mm (e.g. 1020)
  door_length: number;          // mm (e.g. 1120)
  fender_radius: number;        // mm (e.g. 380)
  wheel_arch_radius: number;    // mm (e.g. 360)
  ground_clearance: number;     // mm (e.g. 145)
  // Structural Thicknesses (mm)
  roof_thickness: number;       // mm
  hood_thickness: number;       // mm
  door_skin_thickness: number;  // mm
  floorpan_thickness: number;   // mm
  a_pillar_thickness: number;   // mm
  b_pillar_thickness: number;   // mm
  side_sill_thickness: number;  // mm
}

export type ManufacturingMethod = 
  | 'Deep Drawing / Stamping'
  | 'Hot Stamping & Laser Trim'
  | 'Robotic Spot Welding'
  | 'Laser Beam Brazing'
  | 'Plastic Injection Molding'
  | 'High-Pressure Die Casting'
  | 'Glass Lamination & Tempering'
  | 'Automated Wire Harness Looming'
  | 'Modular Cockpit Assembly'
  | 'Automated Adhesive Bonding'
  | 'Robotic Torque Screwing'
  | 'Additive Manufacturing SLM';

export interface MaterialSpec {
  material_id: string;
  name: string;
  category: 'Steel' | 'Aluminum' | 'Polymer' | 'Composite' | 'Glass' | 'Textile' | 'Chemical / Paint' | 'Battery / Active';
  density: number;             // g/cm3
  cost_per_kg: number;         // EUR/kg
  thermal_conductivity: number;// W/(m*K)
  roughness: number;           // 0-1
  friction_coeff: number;      // 0-1
  elastic_modulus_GPa: number; // GPa
  yield_strength_MPa: number;  // MPa
  recyclability_percent: number;// %
  co2_kg_per_kg: number;       // kg CO2 eq / kg
  color_hex: string;
  metallic: number;
  roughness_pbr: number;
}

export interface VehicleComponent {
  component_id: string;
  name: string;
  assembly: 'Body' | 'Chassis' | 'Powertrain' | 'Interior' | 'Electrical' | 'Glass' | 'Thermal';
  material_id: string;
  thickness_mm: number;
  mass_kg: number;
  position_offset: [number, number, number]; // [X longitudinal, Y lateral, Z vertical] in meters from vehicle origin
  bounding_box: { width: number; height: number; depth: number };
  parent_id?: string;
  children_ids: string[];
  manufacturing_method: ManufacturingMethod;
  supplier: string;
  unit_cost_eur: {
    material: number;
    labour: number;
    machine: number;
    energy: number;
    logistics: number;
    total: number;
  };
  version: string;
  status: 'DESIGNED' | 'ENGINEERED' | 'RELEASED' | 'IN_PRODUCTION' | 'QUALITY_PASSED';
  mesh_geometry_type: string;
}

export interface ErgonomicsMetrics {
  h_point: [number, number, number]; // [x, y, z] mm
  headroom_front_mm: number;
  headroom_rear_mm: number;
  legroom_front_mm: number;
  legroom_rear_mm: number;
  knee_clearance_mm: number;
  shoulder_width_mm: number;
  sight_angle_up_deg: number;
  sight_angle_down_deg: number;
  steering_reach_mm: number;
  pedal_reach_mm: number;
  ingress_height_mm: number;
  driver_percentile: '50th-Female' | '50th-Male' | '95th-Male';
}

export interface AerodynamicsMetrics {
  drag_coefficient_cd: number;
  frontal_area_m2: number;
  air_density_kg_m3: number;
  velocity_kmh: number;
  drag_force_n: number;
  power_demand_kw: number;
  energy_consumption_kwh_100km: number;
  electric_range_km: number;
}

export interface ThermalMetrics {
  ambient_temp_c: number;
  cabin_temp_c: number;
  battery_temp_c: number;
  motor_temp_c: number;
  solar_radiation_w_m2: number;
  hvac_power_kw: number;
  defrost_state_percent: number;
  zone_temps: {
    driver: number;
    passenger: number;
    rear: number;
    dashboard: number;
    roof: number;
  };
}

export interface MassInertiaMetrics {
  total_mass_kg: number;
  curb_weight_kg: number;
  gross_vehicle_weight_kg: number;
  cg_x_mm: number; // Center of Gravity X (longitudinal)
  cg_y_mm: number; // Lateral
  cg_z_mm: number; // Height from ground
  mass_distribution_front_percent: number;
  mass_distribution_rear_percent: number;
  inertia_ixx_kg_m2: number;
  inertia_iyy_kg_m2: number;
  inertia_izz_kg_m2: number;
}

export interface VehicleRevision {
  revision_id: string;
  name: string;
  timestamp: string;
  author: string;
  frozen: boolean;
  notes: string;
  parameters: VehicleParameters;
  metrics: {
    mass: number;
    cost: number;
    cd: number;
    headroom: number;
  };
}

export type ActiveStudio = 
  | 'DESIGN'
  | 'INTERIOR'
  | 'ENGINEERING'
  | 'BOM'
  | 'PRODUCTION'
  | 'FACTORY'
  | 'QUALITY'
  | 'SIMULATION'
  | 'DIGITAL_TWIN';

export type CameraViewPreset = 
  | 'ORBIT'
  | 'TOP'
  | 'FRONT'
  | 'SIDE'
  | 'REAR'
  | 'COCKPIT'
  | 'INTERIOR'
  | 'ISOMETRIC';

export type SectionMode = 'NONE' | 'HORIZONTAL' | 'VERTICAL' | 'LONGITUDINAL' | 'TRANSVERSAL';
