// Beetle Simulation & Scenario Types

import { VehicleParameters } from './vehicle.types';

export interface WhatIfScenario {
  id: string;
  name: string;
  description: string;
  category: 'Geometric' | 'Manufacturing' | 'Material' | 'Disruption';
  parameter_delta: Partial<VehicleParameters>;
  station_disruptions?: {
    station_id: string;
    cycle_time_multiplier: number;
    machine_failure?: boolean;
  }[];
  predicted_impact: {
    mass_delta_kg: number;
    cost_delta_eur: number;
    taktzeit_impact_s: number;
    cd_delta: number;
    headroom_delta_mm: number;
    bottleneck_station?: string;
  };
}

export interface ParetoOptPoint {
  iteration: number;
  roof_height_mm: number;
  mass_kg: number;
  cost_eur: number;
  cd_drag: number;
  cabin_volume_l: number;
  production_time_s: number;
  is_pareto_optimal: boolean;
}

export interface ProductionReplayFrame {
  time_label: string; // "09:00", "09:05", "09:10", etc.
  conveyor_speed_m_min: number;
  active_vins: { vin: string; station_id: string; progress_percent: number }[];
  station_loads: { station_id: string; load_percent: number; status: string }[];
  throughput_rate_jph: number;
  cumulative_energy_kwh: number;
}

export interface VehicleVariantPreset {
  variant_id: 'BASE' | 'COMFORT' | 'SPORT' | 'PREMIUM_EV';
  name: string;
  tagline: string;
  body_color_hex: string;
  interior_material_id: string;
  wheel_radius_mm: number;
  battery_kwh: number;
  power_kw: number;
  top_speed_kmh: number;
  seat_type: string;
  dashboard_display_type: string;
  target_price_eur: number;
}
