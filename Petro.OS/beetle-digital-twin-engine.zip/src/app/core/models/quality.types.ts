// Beetle Quality Twin & Traceability Models

export interface GapFlushMeasurement {
  id: string;
  location_name: string; // e.g. "Hood to Left Fender", "Door to B-Pillar", "Trunk to Quarter Panel"
  panel_a: string;
  panel_b: string;
  gap_target_mm: number;
  gap_actual_mm: number;
  flush_target_mm: number;
  flush_actual_mm: number;
  tolerance_mm: number;
  status: 'GREEN' | 'YELLOW' | 'RED';
  measured_at_station: string;
}

export interface BoltTorqueMeasurement {
  bolt_id: string;
  joint_name: string; // e.g. "Front Subframe M14x1.5", "Suspension Strut Top Nut", "Seat Rail Anchor M10"
  target_torque_nm: number;
  actual_torque_nm: number;
  tolerance_nm: number;
  target_angle_deg: number;
  actual_angle_deg: number;
  status: 'OK' | 'NOK';
  tool_id: string;
  worker_id: string;
  curve_points: { angle: number; torque: number }[];
}

export interface PaintLayerInspection {
  layer_type: 'E-Coat (KTL)' | 'Primer Filler' | 'Basecoat Metallic' | '2K Clearcoat';
  target_thickness_um: number;
  actual_thickness_um: number;
  tolerance_um: number;
  curing_temp_c: number;
  gloss_units_20deg: number;
  status: 'PASS' | 'WARNING' | 'FAIL';
}

export interface QualityDefectRecord {
  defect_id: string;
  timestamp: string;
  vin: string;
  station_id: string;
  category: 'Gap Tolerance' | 'Bolt Torque' | 'Paint Surface' | 'ECU CAN Bus' | 'Sensor Calibration' | 'Trim Alignment';
  description: string;
  severity: 'MINOR' | 'CRITICAL' | 'BLOCKER';
  root_cause: string;
  remedy_action: string;
  resolved: boolean;
}

export interface VehicleTraceabilityRecord {
  vin: string;
  model_variant: string;
  production_date: string;
  batch_number: string;
  stations_traversed: {
    station_id: string;
    completed_at: string;
    cycle_time_s: number;
    operator: string;
    machine_id: string;
    quality_status: 'PASS' | 'REWORK';
  }[];
  critical_components: {
    part_id: string;
    name: string;
    batch_lot: string;
    supplier: string;
    inspection_pass: boolean;
  }[];
}

export interface EndOfLineTestResult {
  electrical_can_diagnostic_pass: boolean;
  lighting_lux_alignment_pass: boolean;
  brake_force_balance_pass: boolean;
  wheel_alignment_camber_toe_pass: boolean;
  water_ingress_rain_chamber_pass: boolean;
  adas_radar_camera_calibration_pass: boolean;
  hvac_cabin_airflow_pass: boolean;
  overall_readiness_score: number; // 0-100%
}
