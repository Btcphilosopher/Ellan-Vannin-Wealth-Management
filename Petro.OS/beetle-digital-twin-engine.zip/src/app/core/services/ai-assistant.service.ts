import { Injectable, inject, signal } from '@angular/core';
import { CanonicalVehicleService } from './canonical-vehicle.service';
import { FactorySimulationService } from './factory-simulation.service';
import { QualityTwinService } from './quality-twin.service';

export interface AIChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  suggestedActions?: { label: string; actionType: string; payload?: Record<string, unknown> }[];
}

@Injectable({
  providedIn: 'root'
})
export class AIAssistantService {
  private vehicleService = inject(CanonicalVehicleService);
  private factoryService = inject(FactorySimulationService);
  private qualityService = inject(QualityTwinService);

  readonly isOpen = signal<boolean>(false);
  readonly isLoading = signal<boolean>(false);
  readonly messages = signal<AIChatMessage[]>([
    {
      id: 'msg-0',
      sender: 'system',
      text: 'Beetle Engineering AI initialisiert. Verbunden mit Canonical Vehicle Model v3.2, MES Produktionslinie und Qualitäts-Twin.',
      timestamp: '09:00:00'
    },
    {
      id: 'msg-1',
      sender: 'assistant',
      text: 'Guten Tag. Ich bin Ihr virtueller Automotive Engineering Assistent für den Beetle Digital Twin. Ich kann Live-Daten zu Geometrie, Massenbilanz, Schwerpunkt, Aerodynamik, Fertigungsengpässen, Qualitätsmessungen und Kosten analysieren. Wie kann ich unterstützen?',
      timestamp: '09:00:01',
      suggestedActions: [
        { label: 'Welche Komponenten erhöhen das Gewicht am stärksten?', actionType: 'QUERY_MASS' },
        { label: 'Wo liegt der aktuelle Produktionsengpass?', actionType: 'QUERY_BOTTLENECK' },
        { label: 'Wie wirkt sich eine Dachanhebung um +25 mm aus?', actionType: 'QUERY_ROOF_DELTA' },
        { label: 'Qualitätsstatus & Spaltmaß prüfen', actionType: 'QUERY_QUALITY' }
      ]
    }
  ]);

  toggleOpen() {
    this.isOpen.update(v => !v);
  }

  async askQuestion(questionText: string) {
    if (!questionText.trim() || this.isLoading()) return;

    const userMsg: AIChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: questionText,
      timestamp: new Date().toLocaleTimeString()
    };

    this.messages.update(msgs => [...msgs, userMsg]);
    this.isLoading.set(true);

    try {
      // Gather live canonical digital twin context
      const payloadContext = {
        parameters: this.vehicleService.parameters(),
        mass: this.vehicleService.massInertiaMetrics(),
        aero: this.vehicleService.aerodynamicsMetrics(),
        ergo: this.vehicleService.ergonomicsMetrics(),
        costs: this.vehicleService.vehicleCostModel(),
        factory: {
          taktzeit: this.factoryService.plantMetrics().taktzeit_s,
          jph: this.factoryService.plantMetrics().line_speed_jph,
          bottleneck: this.factoryService.plantMetrics().active_bottleneck_station,
          oee: this.factoryService.plantMetrics().overall_line_oee,
          robot17Fault: this.factoryService.robot17FaultActive()
        },
        quality: {
          gapIssues: this.qualityService.gapFlushData().filter(g => g.status !== 'GREEN').length,
          activeDefects: this.qualityService.defectLog().filter(d => !d.resolved).length
        },
        selectedComponent: this.vehicleService.selectedComponent()
      };

      const response = await fetch('/api/ai/engineering-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: questionText,
          context: payloadContext
        })
      });

      if (response.ok) {
        const data = await response.json();
        const aiMsg: AIChatMessage = {
          id: `msg-${Date.now() + 1}`,
          sender: 'assistant',
          text: data.answer || 'Analyse abgeschlossen.',
          timestamp: new Date().toLocaleTimeString(),
          suggestedActions: data.suggestedActions || []
        };
        this.messages.update(msgs => [...msgs, aiMsg]);
      } else {
        throw new Error('API request failed');
      }
    } catch {
      // Deterministic engineering fallback if server unavailable
      const fallbackAnswer = this.generateFallbackAnswer(questionText);
      const aiMsg: AIChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: fallbackAnswer,
        timestamp: new Date().toLocaleTimeString()
      };
      this.messages.update(msgs => [...msgs, aiMsg]);
    } finally {
      this.isLoading.set(false);
    }
  }

  private generateFallbackAnswer(q: string): string {
    const qLower = q.toLowerCase();
    const mass = this.vehicleService.massInertiaMetrics();
    const plant = this.factoryService.plantMetrics();
    const aero = this.vehicleService.aerodynamicsMetrics();
    const ergo = this.vehicleService.ergonomicsMetrics();

    if (qLower.includes('gewicht') || qLower.includes('masse')) {
      return `📊 **Massenanalyse des Canonical Digital Twin:**\n\n- **Gesamtmasse:** ${mass.total_mass_kg} kg (Leergewicht: ${mass.curb_weight_kg} kg)\n- **Schwerpunkt (CG):** X = ${mass.cg_x_mm} mm, Y = ${mass.cg_y_mm} mm, Z = ${mass.cg_z_mm} mm\n- **Haupttreiber:**\n  1. 60 kWh Batteriepack: **345.0 kg** (~36% der Gesamtmasse)\n  2. E-Motor & Antrieb: **78.5 kg**\n  3. Bodenstruktur Monocoque: **58.0 kg**\n  4. 4x 18" Aero-Räder: **79.2 kg**\n\n💡 *Optimierungspotenzial:* Eine Umstellung der Monocoque-Querträger auf AlSi9Cu3 Aluminiumguss würde ca. 18 kg einsparen.`;
    }

    if (qLower.includes('engpass') || qLower.includes('bottleneck') || qLower.includes('station')) {
      return `🏭 **Produktionslinien- & Taktzeitanalyse:**\n\n- **Aktiver Engpass:** **${plant.active_bottleneck_station}**\n- **Linien-Taktzeit:** **${plant.taktzeit_s} Sekunden**\n- **Ausstoß (JPH):** **${plant.line_speed_jph} Fahrzeuge / Stunde**\n- **Gesamtanlageneffektivität (OEE):** **${plant.overall_line_oee}%**\n\n${this.factoryService.robot17FaultActive() ? '⚠️ **Kritische Störung:** Roboter #17 (Laserbrazer) an Station 2 ist ausgefallen! Zykluszeit dort auf 138s gestiegen.' : 'Die Station 03 (Lackierung) bestimmt derzeit mit 65s Zykluszeit den maximalen Linientakt.'}`;
    }

    if (qLower.includes('dach') || qLower.includes('roof') || qLower.includes('+25') || qLower.includes('+30')) {
      return `📐 **Ripple-Through Analyse bei Dachanhebung:**\n\n- **Kopffreiheit Vorn:** ${ergo.headroom_front_mm} mm (optimiert für 95. Perzentil)\n- **Kopffreiheit Fond:** ${ergo.headroom_rear_mm} mm\n- **Aerodynamischer cw-Wert:** ${aero.drag_coefficient_cd} (Stirnfläche: ${aero.frontal_area_m2} m²)\n- **Verbrauch @ 130 km/h:** ${aero.energy_consumption_kwh_100km} kWh/100km (Reichweite: ~${aero.electric_range_km} km)\n\n*Hinweis:* Bei +25 mm Dachhöhe erhöht sich die Blechfläche um ca. 0.08 m² (+1.4 kg Stahl DP600), während die Kopffreiheit im Fond um 21 mm steigt.`;
    }

    if (qLower.includes('qualität') || qLower.includes('spalt') || qLower.includes('fehler')) {
      return `🔍 **Qualitäts- & Spaltmaßaudit:**\n\n- **Spaltmaßmessungen:** 5 aktive Messstellen erfasst.\n- **Audit-Status:** ${this.qualityService.gapFlushData().some(g => g.status === 'RED') ? '⚠️ Kritische Abweichung an B-Säulenschweller (4.88mm > 4.5mm Limit)!' : 'Alle Spaltmaße liegen innerhalb der definierten 0.5mm Toleranzbandbreite.'}\n- **Drehmomentprüfungen:** 100% OK (Batteriebefestigung 146.2 Nm bei 145 Nm Soll).\n- **EOL-Gesamtprüfquote:** **${this.qualityService.endOfLineAudit().overall_readiness_score}%**`;
    }

    return `🤖 **Beetle Engineering AI Status:**\n\nDas Fahrzeugmodell befindet sich im Zustand: **${this.vehicleService.activeVariant()}** (${this.vehicleService.currentRevision()}).\n- Gesamtmasse: ${mass.total_mass_kg} kg\n- Fertigungskosten: €${this.vehicleService.vehicleCostModel().total_direct_manufacturing_cost_eur.toLocaleString()}\n- cw-Wert: ${aero.drag_coefficient_cd}\n- Taktzeit: ${plant.taktzeit_s}s\n\nStellen Sie spezifische Fragen zur Geometrie, BOM, Fertigungssimulation oder Qualitätsüberwachung.`;
  }
}
