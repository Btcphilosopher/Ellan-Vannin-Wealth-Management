import { Injectable, computed, signal } from '@angular/core';
import { 
  VehicleParameters, 
  VehicleComponent, 
  MaterialSpec, 
  ErgonomicsMetrics, 
  AerodynamicsMetrics, 
  MassInertiaMetrics, 
  ActiveStudio,
  CameraViewPreset
} from '../models/vehicle.types';
import { AUTOMOTIVE_MATERIALS } from '../models/materials.data';

@Injectable({
  providedIn: 'root'
})
export class CanonicalVehicleService {
  // Active UI Navigation Studio
  readonly activeStudio = signal<ActiveStudio>('DESIGN');
  readonly cameraPreset = signal<CameraViewPreset>('ORBIT');
  
  // 3D Viewport Modes
  readonly explodedFactor = signal<number>(0); // 0.0 (assembled) to 1.0 (exploded)
  readonly sectionMode = signal<'NONE' | 'HORIZONTAL' | 'VERTICAL' | 'LONGITUDINAL' | 'TRANSVERSAL'>('NONE');
  readonly sectionPlaneOffset = signal<number>(0); // -1.0 to 1.0
  readonly selectedComponentId = signal<string | null>('COMP-ROOF-01');
  readonly highlightedComponentId = signal<string | null>(null);
  readonly wireframeMode = signal<boolean>(false);
  readonly showCenterOfGravity = signal<boolean>(true);
  readonly showErgoMannequin = signal<boolean>(true);

  // Exterior & Interior Visual Customization
  readonly exteriorColorHex = signal<string>('#0284c7'); // Electric Ocean Blue
  readonly interiorColorHex = signal<string>('#1e293b'); // Dark Slate
  readonly paintFinish = signal<'METALLIC' | 'MATTE' | 'GLOSS' | 'PEARL'>('METALLIC');

  // Engineering Governance & Revision Status
  readonly engineeringFrozen = signal<boolean>(false);
  readonly activeVariant = signal<'BASE' | 'COMFORT' | 'SPORT' | 'PREMIUM_EV'>('PREMIUM_EV');
  readonly currentRevision = signal<string>('Rev C.4 (Optimized Aero)');
  
  // Parametric Vehicle Dimensions (in millimeters / degrees)
  readonly parameters = signal<VehicleParameters>({
    vehicle_length: 4080,
    vehicle_width: 1720,
    vehicle_height: 1500,
    wheelbase: 2540,
    front_overhang: 740,
    rear_overhang: 800,
    track_front: 1510,
    track_rear: 1500,
    roof_height: 1500,
    windshield_angle: 54,
    rear_glass_angle: 48,
    hood_length: 1020,
    door_length: 1120,
    fender_radius: 380,
    wheel_arch_radius: 360,
    ground_clearance: 145,
    roof_thickness: 0.9,
    hood_thickness: 0.8,
    door_skin_thickness: 0.8,
    floorpan_thickness: 1.2,
    a_pillar_thickness: 1.8,
    b_pillar_thickness: 2.2,
    side_sill_thickness: 2.0
  });

  // Material Library State
  readonly materials = signal<MaterialSpec[]>(AUTOMOTIVE_MATERIALS);

  // Interior Seating & Ergonomic Specific Params
  readonly seatPositionX = signal<number>(0); // -50mm to +50mm fore/aft
  readonly seatHeightOffset = signal<number>(0); // -30mm to +30mm
  readonly seatBackrestAngle = signal<number>(24); // degrees (default 24 deg)
  readonly driverPercentile = signal<'50th-Female' | '50th-Male' | '95th-Male'>('50th-Male');

  // Canonical Components List (Single Source of Truth)
  readonly components = signal<VehicleComponent[]>([
    // Body Exterior
    {
      component_id: 'COMP-ROOF-01',
      name: 'Curved Beetle Roof Shell Panel',
      assembly: 'Body',
      material_id: 'MAT-STEEL-DP600',
      thickness_mm: 0.9,
      mass_kg: 24.5,
      position_offset: [0.1, 0, 1.45],
      bounding_box: { width: 1.4, height: 0.35, depth: 1.8 },
      children_ids: [],
      manufacturing_method: 'Deep Drawing / Stamping',
      supplier: 'Salzgitter Automotive Steel',
      unit_cost_eur: { material: 45.3, labour: 22.0, machine: 18.5, energy: 6.2, logistics: 5.0, total: 97.0 },
      version: 'v3.2',
      status: 'RELEASED',
      mesh_geometry_type: 'roof'
    },
    {
      component_id: 'COMP-HOOD-01',
      name: 'Front Curved Aerodynamic Hood',
      assembly: 'Body',
      material_id: 'MAT-ALU-6016',
      thickness_mm: 0.8,
      mass_kg: 11.2,
      position_offset: [1.45, 0, 0.85],
      bounding_box: { width: 1.35, height: 0.25, depth: 1.05 },
      children_ids: [],
      manufacturing_method: 'Deep Drawing / Stamping',
      supplier: 'Novelis Aluminum Automotive',
      unit_cost_eur: { material: 53.7, labour: 18.0, machine: 15.0, energy: 4.8, logistics: 4.5, total: 96.0 },
      version: 'v2.1',
      status: 'RELEASED',
      mesh_geometry_type: 'hood'
    },
    {
      component_id: 'COMP-FENDER-FL',
      name: 'Iconic Flared Front Left Fender',
      assembly: 'Body',
      material_id: 'MAT-STEEL-DC04',
      thickness_mm: 0.8,
      mass_kg: 8.4,
      position_offset: [1.35, 0.76, 0.65],
      bounding_box: { width: 0.3, height: 0.65, depth: 0.95 },
      children_ids: [],
      manufacturing_method: 'Deep Drawing / Stamping',
      supplier: 'Voestalpine Metal Forming',
      unit_cost_eur: { material: 12.2, labour: 14.0, machine: 11.0, energy: 3.5, logistics: 3.0, total: 43.7 },
      version: 'v4.0',
      status: 'RELEASED',
      mesh_geometry_type: 'fender_fl'
    },
    {
      component_id: 'COMP-FENDER-FR',
      name: 'Iconic Flared Front Right Fender',
      assembly: 'Body',
      material_id: 'MAT-STEEL-DC04',
      thickness_mm: 0.8,
      mass_kg: 8.4,
      position_offset: [1.35, -0.76, 0.65],
      bounding_box: { width: 0.3, height: 0.65, depth: 0.95 },
      children_ids: [],
      manufacturing_method: 'Deep Drawing / Stamping',
      supplier: 'Voestalpine Metal Forming',
      unit_cost_eur: { material: 12.2, labour: 14.0, machine: 11.0, energy: 3.5, logistics: 3.0, total: 43.7 },
      version: 'v4.0',
      status: 'RELEASED',
      mesh_geometry_type: 'fender_fr'
    },
    {
      component_id: 'COMP-FENDER-RL',
      name: 'Iconic Flared Rear Left Quarter Fender',
      assembly: 'Body',
      material_id: 'MAT-STEEL-DC04',
      thickness_mm: 0.8,
      mass_kg: 9.8,
      position_offset: [-1.25, 0.76, 0.7],
      bounding_box: { width: 0.32, height: 0.7, depth: 1.1 },
      children_ids: [],
      manufacturing_method: 'Deep Drawing / Stamping',
      supplier: 'Voestalpine Metal Forming',
      unit_cost_eur: { material: 14.2, labour: 15.0, machine: 12.0, energy: 4.0, logistics: 3.5, total: 48.7 },
      version: 'v3.1',
      status: 'RELEASED',
      mesh_geometry_type: 'fender_rl'
    },
    {
      component_id: 'COMP-FENDER-RR',
      name: 'Iconic Flared Rear Right Quarter Fender',
      assembly: 'Body',
      material_id: 'MAT-STEEL-DC04',
      thickness_mm: 0.8,
      mass_kg: 9.8,
      position_offset: [-1.25, -0.76, 0.7],
      bounding_box: { width: 0.32, height: 0.7, depth: 1.1 },
      children_ids: [],
      manufacturing_method: 'Deep Drawing / Stamping',
      supplier: 'Voestalpine Metal Forming',
      unit_cost_eur: { material: 14.2, labour: 15.0, machine: 12.0, energy: 4.0, logistics: 3.5, total: 48.7 },
      version: 'v3.1',
      status: 'RELEASED',
      mesh_geometry_type: 'fender_rr'
    },
    {
      component_id: 'COMP-DOOR-L',
      name: 'Left Driver Side Door Assembly',
      assembly: 'Body',
      material_id: 'MAT-STEEL-DP600',
      thickness_mm: 0.8,
      mass_kg: 21.5,
      position_offset: [0.15, 0.82, 0.75],
      bounding_box: { width: 0.18, height: 0.95, depth: 1.2 },
      children_ids: [],
      manufacturing_method: 'Robotic Spot Welding',
      supplier: 'Brose Fahrzeugteile',
      unit_cost_eur: { material: 39.8, labour: 34.0, machine: 28.0, energy: 8.5, logistics: 6.0, total: 116.3 },
      version: 'v2.8',
      status: 'RELEASED',
      mesh_geometry_type: 'door_l'
    },
    {
      component_id: 'COMP-DOOR-R',
      name: 'Right Passenger Side Door Assembly',
      assembly: 'Body',
      material_id: 'MAT-STEEL-DP600',
      thickness_mm: 0.8,
      mass_kg: 21.5,
      position_offset: [0.15, -0.82, 0.75],
      bounding_box: { width: 0.18, height: 0.95, depth: 1.2 },
      children_ids: [],
      manufacturing_method: 'Robotic Spot Welding',
      supplier: 'Brose Fahrzeugteile',
      unit_cost_eur: { material: 39.8, labour: 34.0, machine: 28.0, energy: 8.5, logistics: 6.0, total: 116.3 },
      version: 'v2.8',
      status: 'RELEASED',
      mesh_geometry_type: 'door_r'
    },
    // Structural Safety & Body-in-White
    {
      component_id: 'COMP-STRUC-BPILLAR',
      name: 'Reinforced B-Pillar Safety Cage',
      assembly: 'Body',
      material_id: 'MAT-STEEL-22MNB5',
      thickness_mm: 2.2,
      mass_kg: 18.2,
      position_offset: [-0.05, 0.75, 1.05],
      bounding_box: { width: 0.12, height: 1.0, depth: 0.15 },
      children_ids: [],
      manufacturing_method: 'Hot Stamping & Laser Trim',
      supplier: 'Gestamp Automoción',
      unit_cost_eur: { material: 52.8, labour: 28.0, machine: 35.0, energy: 12.0, logistics: 4.5, total: 132.3 },
      version: 'v5.0',
      status: 'RELEASED',
      mesh_geometry_type: 'b_pillar'
    },
    {
      component_id: 'COMP-STRUC-FLOOR',
      name: 'Monocoque Integrated Floorpan & Tunnel',
      assembly: 'Body',
      material_id: 'MAT-STEEL-DP600',
      thickness_mm: 1.2,
      mass_kg: 58.0,
      position_offset: [0.0, 0.0, 0.32],
      bounding_box: { width: 1.5, height: 0.15, depth: 2.8 },
      children_ids: [],
      manufacturing_method: 'Deep Drawing / Stamping',
      supplier: 'Salzgitter Automotive Steel',
      unit_cost_eur: { material: 107.3, labour: 45.0, machine: 40.0, energy: 15.0, logistics: 12.0, total: 219.3 },
      version: 'v3.0',
      status: 'RELEASED',
      mesh_geometry_type: 'floorpan'
    },
    // Glazing
    {
      component_id: 'COMP-GLASS-WINDSHIELD',
      name: 'Acoustic Heated Curved Windshield',
      assembly: 'Glass',
      material_id: 'MAT-GLASS-LAM',
      thickness_mm: 4.5,
      mass_kg: 14.8,
      position_offset: [0.95, 0, 1.15],
      bounding_box: { width: 1.35, height: 0.75, depth: 0.8 },
      children_ids: [],
      manufacturing_method: 'Glass Lamination & Tempering',
      supplier: 'Saint-Gobain Sekurit',
      unit_cost_eur: { material: 56.2, labour: 24.0, machine: 18.0, energy: 6.0, logistics: 8.5, total: 112.7 },
      version: 'v2.4',
      status: 'RELEASED',
      mesh_geometry_type: 'windshield'
    },
    {
      component_id: 'COMP-GLASS-REAR',
      name: 'Iconic Oval Rear Window with Defroster',
      assembly: 'Glass',
      material_id: 'MAT-GLASS-TEMP',
      thickness_mm: 3.8,
      mass_kg: 9.6,
      position_offset: [-0.95, 0, 1.18],
      bounding_box: { width: 1.15, height: 0.65, depth: 0.6 },
      children_ids: [],
      manufacturing_method: 'Glass Lamination & Tempering',
      supplier: 'Saint-Gobain Sekurit',
      unit_cost_eur: { material: 27.8, labour: 16.0, machine: 12.0, energy: 4.2, logistics: 5.0, total: 65.0 },
      version: 'v2.0',
      status: 'RELEASED',
      mesh_geometry_type: 'rear_glass'
    },
    // Powertrain & Battery Twin
    {
      component_id: 'COMP-BAT-PACK-60',
      name: '60 kWh Structural High-Voltage Battery Pack',
      assembly: 'Powertrain',
      material_id: 'MAT-BAT-NMC811',
      thickness_mm: 110.0,
      mass_kg: 345.0,
      position_offset: [0.05, 0.0, 0.22],
      bounding_box: { width: 1.35, height: 0.14, depth: 2.1 },
      children_ids: [],
      manufacturing_method: 'High-Pressure Die Casting',
      supplier: 'PowerCo Battery Cell Plant',
      unit_cost_eur: { material: 8280.0, labour: 320.0, machine: 450.0, energy: 95.0, logistics: 85.0, total: 9230.0 },
      version: 'v4.2',
      status: 'RELEASED',
      mesh_geometry_type: 'battery_pack'
    },
    {
      component_id: 'COMP-MOTOR-REAR',
      name: 'Permanent Magnet Synchronous Motor (150 kW)',
      assembly: 'Powertrain',
      material_id: 'MAT-ALU-CAST-A380',
      thickness_mm: 25.0,
      mass_kg: 78.5,
      position_offset: [-1.28, 0.0, 0.38],
      bounding_box: { width: 0.55, height: 0.45, depth: 0.5 },
      children_ids: [],
      manufacturing_method: 'High-Pressure Die Casting',
      supplier: 'Continental Vitesco Powertrain',
      unit_cost_eur: { material: 620.0, labour: 180.0, machine: 220.0, energy: 35.0, logistics: 25.0, total: 1080.0 },
      version: 'v3.0',
      status: 'RELEASED',
      mesh_geometry_type: 'electric_motor'
    },
    // Chassis & Wheels
    {
      component_id: 'COMP-CHASSIS-FRONT',
      name: 'MacPherson Front Subframe & Steering Rack',
      assembly: 'Chassis',
      material_id: 'MAT-ALU-CAST-A380',
      thickness_mm: 4.5,
      mass_kg: 42.0,
      position_offset: [1.27, 0.0, 0.35],
      bounding_box: { width: 1.45, height: 0.3, depth: 0.6 },
      children_ids: [],
      manufacturing_method: 'High-Pressure Die Casting',
      supplier: 'ZF Friedrichshafen Chassis',
      unit_cost_eur: { material: 172.2, labour: 65.0, machine: 75.0, energy: 18.0, logistics: 14.0, total: 344.2 },
      version: 'v2.5',
      status: 'RELEASED',
      mesh_geometry_type: 'front_subframe'
    },
    {
      component_id: 'COMP-WHEEL-FL',
      name: 'Aero-Turbine 18-inch Alloy Wheel FL',
      assembly: 'Chassis',
      material_id: 'MAT-ALU-6016',
      thickness_mm: 12.0,
      mass_kg: 19.8,
      position_offset: [1.27, 0.75, 0.34],
      bounding_box: { width: 0.23, height: 0.68, depth: 0.68 },
      children_ids: [],
      manufacturing_method: 'High-Pressure Die Casting',
      supplier: 'Ronal Group Wheels',
      unit_cost_eur: { material: 95.0, labour: 28.0, machine: 32.0, energy: 8.0, logistics: 6.0, total: 169.0 },
      version: 'v3.0',
      status: 'RELEASED',
      mesh_geometry_type: 'wheel_fl'
    },
    {
      component_id: 'COMP-WHEEL-FR',
      name: 'Aero-Turbine 18-inch Alloy Wheel FR',
      assembly: 'Chassis',
      material_id: 'MAT-ALU-6016',
      thickness_mm: 12.0,
      mass_kg: 19.8,
      position_offset: [1.27, -0.75, 0.34],
      bounding_box: { width: 0.23, height: 0.68, depth: 0.68 },
      children_ids: [],
      manufacturing_method: 'High-Pressure Die Casting',
      supplier: 'Ronal Group Wheels',
      unit_cost_eur: { material: 95.0, labour: 28.0, machine: 32.0, energy: 8.0, logistics: 6.0, total: 169.0 },
      version: 'v3.0',
      status: 'RELEASED',
      mesh_geometry_type: 'wheel_fr'
    },
    {
      component_id: 'COMP-WHEEL-RL',
      name: 'Aero-Turbine 18-inch Alloy Wheel RL',
      assembly: 'Chassis',
      material_id: 'MAT-ALU-6016',
      thickness_mm: 12.0,
      mass_kg: 19.8,
      position_offset: [-1.27, 0.75, 0.34],
      bounding_box: { width: 0.23, height: 0.68, depth: 0.68 },
      children_ids: [],
      manufacturing_method: 'High-Pressure Die Casting',
      supplier: 'Ronal Group Wheels',
      unit_cost_eur: { material: 95.0, labour: 28.0, machine: 32.0, energy: 8.0, logistics: 6.0, total: 169.0 },
      version: 'v3.0',
      status: 'RELEASED',
      mesh_geometry_type: 'wheel_rl'
    },
    {
      component_id: 'COMP-WHEEL-RR',
      name: 'Aero-Turbine 18-inch Alloy Wheel RR',
      assembly: 'Chassis',
      material_id: 'MAT-ALU-6016',
      thickness_mm: 12.0,
      mass_kg: 19.8,
      position_offset: [-1.27, -0.75, 0.34],
      bounding_box: { width: 0.23, height: 0.68, depth: 0.68 },
      children_ids: [],
      manufacturing_method: 'High-Pressure Die Casting',
      supplier: 'Ronal Group Wheels',
      unit_cost_eur: { material: 95.0, labour: 28.0, machine: 32.0, energy: 8.0, logistics: 6.0, total: 169.0 },
      version: 'v3.0',
      status: 'RELEASED',
      mesh_geometry_type: 'wheel_rr'
    },
    // Interior Digital Twin
    {
      component_id: 'COMP-INT-DASHBOARD',
      name: 'Beetle Modernist Sculpted Dashboard & HUD',
      assembly: 'Interior',
      material_id: 'MAT-POLY-PC-ABS',
      thickness_mm: 3.2,
      mass_kg: 16.5,
      position_offset: [0.65, 0.0, 0.88],
      bounding_box: { width: 1.38, height: 0.45, depth: 0.55 },
      children_ids: [],
      manufacturing_method: 'Modular Cockpit Assembly',
      supplier: 'Faurecia Interior Systems',
      unit_cost_eur: { material: 56.1, labour: 65.0, machine: 45.0, energy: 12.0, logistics: 10.0, total: 188.1 },
      version: 'v4.1',
      status: 'RELEASED',
      mesh_geometry_type: 'dashboard'
    },
    {
      component_id: 'COMP-INT-STEERING',
      name: '3-Spoke Heritage Multifunction Steering Wheel',
      assembly: 'Interior',
      material_id: 'MAT-TEX-VEGAN',
      thickness_mm: 22.0,
      mass_kg: 3.8,
      position_offset: [0.48, 0.38, 0.88],
      bounding_box: { width: 0.38, height: 0.38, depth: 0.15 },
      children_ids: [],
      manufacturing_method: 'Plastic Injection Molding',
      supplier: 'Autoliv Steering Systems',
      unit_cost_eur: { material: 53.2, labour: 35.0, machine: 22.0, energy: 5.5, logistics: 4.0, total: 119.7 },
      version: 'v3.0',
      status: 'RELEASED',
      mesh_geometry_type: 'steering_wheel'
    },
    {
      component_id: 'COMP-SEAT-DRIVER',
      name: 'Ergonomic 12-Way Adjustable Driver Seat',
      assembly: 'Interior',
      material_id: 'MAT-TEX-VEGAN',
      thickness_mm: 45.0,
      mass_kg: 22.4,
      position_offset: [0.1, 0.38, 0.65],
      bounding_box: { width: 0.55, height: 0.88, depth: 0.65 },
      children_ids: [],
      manufacturing_method: 'Robotic Torque Screwing',
      supplier: 'Recaro Automotive Seating',
      unit_cost_eur: { material: 145.0, labour: 58.0, machine: 42.0, energy: 9.0, logistics: 8.0, total: 262.0 },
      version: 'v3.5',
      status: 'RELEASED',
      mesh_geometry_type: 'seat_driver'
    },
    {
      component_id: 'COMP-SEAT-PASSENGER',
      name: 'Ergonomic Comfort Passenger Seat',
      assembly: 'Interior',
      material_id: 'MAT-TEX-VEGAN',
      thickness_mm: 45.0,
      mass_kg: 21.0,
      position_offset: [0.1, -0.38, 0.65],
      bounding_box: { width: 0.55, height: 0.88, depth: 0.65 },
      children_ids: [],
      manufacturing_method: 'Robotic Torque Screwing',
      supplier: 'Recaro Automotive Seating',
      unit_cost_eur: { material: 136.0, labour: 52.0, machine: 38.0, energy: 8.5, logistics: 8.0, total: 242.5 },
      version: 'v3.5',
      status: 'RELEASED',
      mesh_geometry_type: 'seat_passenger'
    },
    {
      component_id: 'COMP-SEAT-REAR',
      name: '60/40 Split Folding Rear Bench Seat',
      assembly: 'Interior',
      material_id: 'MAT-TEX-VEGAN',
      thickness_mm: 50.0,
      mass_kg: 28.5,
      position_offset: [-0.65, 0.0, 0.68],
      bounding_box: { width: 1.25, height: 0.85, depth: 0.65 },
      children_ids: [],
      manufacturing_method: 'Robotic Torque Screwing',
      supplier: 'Adient Automotive',
      unit_cost_eur: { material: 185.0, labour: 65.0, machine: 44.0, energy: 11.0, logistics: 12.0, total: 317.0 },
      version: 'v2.8',
      status: 'RELEASED',
      mesh_geometry_type: 'seat_rear'
    },
    // Electrical & Wire Harness
    {
      component_id: 'COMP-ELEC-HARNESS',
      name: 'Zonal High & Low Voltage Vehicle Wire Loom',
      assembly: 'Electrical',
      material_id: 'MAT-CU-HARNESS',
      thickness_mm: 18.0,
      mass_kg: 29.5,
      position_offset: [0.2, 0.0, 0.45],
      bounding_box: { width: 1.2, height: 0.2, depth: 3.2 },
      children_ids: [],
      manufacturing_method: 'Automated Wire Harness Looming',
      supplier: 'Leoni Wiring Systems',
      unit_cost_eur: { material: 289.1, labour: 145.0, machine: 85.0, energy: 16.0, logistics: 14.0, total: 549.1 },
      version: 'v4.0',
      status: 'RELEASED',
      mesh_geometry_type: 'wire_harness'
    },
    {
      component_id: 'COMP-LIGHT-HEADLIGHT-L',
      name: 'Circular Matrix LED Headlight Unit Left',
      assembly: 'Electrical',
      material_id: 'MAT-GLASS-LAM',
      thickness_mm: 3.0,
      mass_kg: 3.2,
      position_offset: [1.88, 0.65, 0.72],
      bounding_box: { width: 0.26, height: 0.26, depth: 0.28 },
      children_ids: [],
      manufacturing_method: 'Plastic Injection Molding',
      supplier: 'Hella Automotive Lighting',
      unit_cost_eur: { material: 65.0, labour: 35.0, machine: 28.0, energy: 5.0, logistics: 4.0, total: 137.0 },
      version: 'v3.2',
      status: 'RELEASED',
      mesh_geometry_type: 'headlight_l'
    },
    {
      component_id: 'COMP-LIGHT-HEADLIGHT-R',
      name: 'Circular Matrix LED Headlight Unit Right',
      assembly: 'Electrical',
      material_id: 'MAT-GLASS-LAM',
      thickness_mm: 3.0,
      mass_kg: 3.2,
      position_offset: [1.88, -0.65, 0.72],
      bounding_box: { width: 0.26, height: 0.26, depth: 0.28 },
      children_ids: [],
      manufacturing_method: 'Plastic Injection Molding',
      supplier: 'Hella Automotive Lighting',
      unit_cost_eur: { material: 65.0, labour: 35.0, machine: 28.0, energy: 5.0, logistics: 4.0, total: 137.0 },
      version: 'v3.2',
      status: 'RELEASED',
      mesh_geometry_type: 'headlight_r'
    }
  ]);

  // Reactive Derived Calculation: Mass Rollup & Center of Gravity & Inertia
  readonly massInertiaMetrics = computed<MassInertiaMetrics>(() => {
    const p = this.parameters();
    const comps = this.components();
    let totalMass = 0;
    let sumMx = 0;
    let sumMy = 0;
    let sumMz = 0;

    for (const c of comps) {
      // Scale mass dynamically if thickness was adjusted
      let effectiveMass = c.mass_kg;
      if (c.component_id === 'COMP-ROOF-01') {
        effectiveMass = c.mass_kg * (p.roof_thickness / 0.9) * (p.vehicle_length / 4080) * (p.vehicle_width / 1720);
      } else if (c.component_id === 'COMP-HOOD-01') {
        effectiveMass = c.mass_kg * (p.hood_thickness / 0.8) * (p.hood_length / 1020);
      } else if (c.component_id === 'COMP-DOOR-L' || c.component_id === 'COMP-DOOR-R') {
        effectiveMass = c.mass_kg * (p.door_skin_thickness / 0.8) * (p.door_length / 1120);
      } else if (c.component_id === 'COMP-STRUC-FLOOR') {
        effectiveMass = c.mass_kg * (p.floorpan_thickness / 1.2) * (p.wheelbase / 2540);
      }

      totalMass += effectiveMass;
      sumMx += effectiveMass * (c.position_offset[0] * 1000); // in mm
      sumMy += effectiveMass * (c.position_offset[1] * 1000);
      sumMz += effectiveMass * (c.position_offset[2] * 1000);
    }

    const cg_x = totalMass > 0 ? Math.round(sumMx / totalMass) : 0;
    const cg_y = totalMass > 0 ? Math.round(sumMy / totalMass) : 0;
    const cg_z = totalMass > 0 ? Math.round(sumMz / totalMass) : 510;

    // Weight distribution based on CG relative to wheelbase (center between axles is ~0)
    const frontAxleX = p.wheelbase / 2; // mm
    const rearAxleX = -p.wheelbase / 2;
    const distTotal = frontAxleX - rearAxleX;
    const frontPercent = Math.min(65, Math.max(35, Math.round(((frontAxleX - cg_x) / distTotal) * 100)));
    const rearPercent = 100 - frontPercent;

    // Numerical calculation of Moment of Inertia (kg*m^2)
    let ixx = 0;
    let iyy = 0;
    let izz = 0;
    for (const c of comps) {
      const x = (c.position_offset[0] * 1000 - cg_x) / 1000;
      const y = (c.position_offset[1] * 1000 - cg_y) / 1000;
      const z = (c.position_offset[2] * 1000 - cg_z) / 1000;
      const m = c.mass_kg;
      ixx += m * (y * y + z * z);
      iyy += m * (x * x + z * z);
      izz += m * (x * x + y * y);
    }

    return {
      total_mass_kg: Math.round(totalMass * 10) / 10,
      curb_weight_kg: Math.round(totalMass + 75), // driver standard
      gross_vehicle_weight_kg: Math.round(totalMass + 420),
      cg_x_mm: cg_x,
      cg_y_mm: cg_y,
      cg_z_mm: cg_z,
      mass_distribution_front_percent: frontPercent,
      mass_distribution_rear_percent: rearPercent,
      inertia_ixx_kg_m2: Math.round(ixx),
      inertia_iyy_kg_m2: Math.round(iyy),
      inertia_izz_kg_m2: Math.round(izz)
    };
  });

  // Reactive Derived Calculation: Aerodynamics
  readonly aerodynamicsMetrics = computed<AerodynamicsMetrics>(() => {
    const p = this.parameters();
    // Frontal Area A = width * height * shape_factor (0.81 for compact beetle silhouette)
    const frontalArea = Math.round((p.vehicle_width / 1000) * (p.vehicle_height / 1000) * 0.815 * 100) / 100;
    
    // Cd derivation: standard 0.285 adjusted by windshield angle, roof height delta, ground clearance
    const angleFactor = (p.windshield_angle - 54) * -0.002;
    const heightFactor = ((p.roof_height - 1500) / 100) * 0.008;
    const clearanceFactor = ((p.ground_clearance - 145) / 50) * 0.005;
    const cd = Math.max(0.24, Math.min(0.38, Math.round((0.278 + angleFactor + heightFactor + clearanceFactor) * 1000) / 1000));

    const airDensity = 1.204; // kg/m3 at 20 deg C
    const velocity_kmh = 130; // 130 km/h highway cruise standard
    const velocity_ms = velocity_kmh / 3.6;

    // F_drag = 0.5 * rho * Cd * A * v^2
    const dragForce = 0.5 * airDensity * cd * frontalArea * (velocity_ms * velocity_ms);
    const powerAeroKw = (dragForce * velocity_ms) / 1000;
    
    // Rolling resistance + Auxiliary HVAC load
    const rollingForce = this.massInertiaMetrics().total_mass_kg * 9.81 * 0.009;
    const powerRollKw = (rollingForce * velocity_ms) / 1000;
    const totalPowerDemand = Math.round((powerAeroKw + powerRollKw + 1.8) * 10) / 10;

    // Consumption in kWh/100km at 130 km/h
    const timeHoursFor100km = 100 / velocity_kmh;
    const consumptionKwh100km = Math.round(totalPowerDemand * timeHoursFor100km * 10) / 10;
    
    // Battery 60 kWh usable
    const rangeKm = Math.round((58.0 / consumptionKwh100km) * 100);

    return {
      drag_coefficient_cd: cd,
      frontal_area_m2: frontalArea,
      air_density_kg_m3: airDensity,
      velocity_kmh: velocity_kmh,
      drag_force_n: Math.round(dragForce),
      power_demand_kw: totalPowerDemand,
      energy_consumption_kwh_100km: consumptionKwh100km,
      electric_range_km: rangeKm
    };
  });

  // Reactive Derived Calculation: Ergonomics & Human Package
  readonly ergonomicsMetrics = computed<ErgonomicsMetrics>(() => {
    const p = this.parameters();
    const seatZOffset = this.seatHeightOffset();
    const seatXOffset = this.seatPositionX();
    const backAngle = this.seatBackrestAngle();

    // H-Point (Hip pivot location in car coordinate system)
    const hPointX = Math.round(150 + seatXOffset);
    const hPointY = 380;
    const hPointZ = Math.round(p.ground_clearance + 220 + seatZOffset);

    // Front Headroom calculation: Roof height minus floorpan, seat cushion, and sitting torso height
    const baseFrontHeadroom = 1015; // mm standard
    const roofDelta = p.roof_height - 1500;
    const frontHeadroom = Math.round(baseFrontHeadroom + roofDelta - seatZOffset + (backAngle - 24) * 2.2);

    // Rear Headroom (Beetle curved roof slope affects rear passengers significantly)
    const rearRoofDelta = roofDelta * 0.85 - (p.rear_glass_angle - 48) * 3.5;
    const rearHeadroom = Math.round(920 + rearRoofDelta);

    // Legroom and clearances
    const frontLegroom = Math.round(1060 + (p.wheelbase - 2540) * 0.4 - seatXOffset);
    const rearLegroom = Math.round(840 + (p.wheelbase - 2540) * 0.6 + seatXOffset);
    const kneeClearance = Math.round(75 + (p.wheelbase - 2540) * 0.35 + seatXOffset * 0.5);
    const shoulderWidth = Math.round(p.vehicle_width - 320);

    return {
      h_point: [hPointX, hPointY, hPointZ],
      headroom_front_mm: frontHeadroom,
      headroom_rear_mm: rearHeadroom,
      legroom_front_mm: frontLegroom,
      legroom_rear_mm: rearLegroom,
      knee_clearance_mm: kneeClearance,
      shoulder_width_mm: shoulderWidth,
      sight_angle_up_deg: Math.round(16.5 + (p.windshield_angle - 54) * 0.3),
      sight_angle_down_deg: Math.round(12.0 - (p.hood_length - 1020) * 0.015),
      steering_reach_mm: Math.round(480 - seatXOffset),
      pedal_reach_mm: Math.round(620 - seatXOffset),
      ingress_height_mm: Math.round(p.ground_clearance + 380),
      driver_percentile: this.driverPercentile()
    };
  });

  // Reactive Derived Calculation: Total Vehicle Production & Material Cost
  readonly vehicleCostModel = computed(() => {
    const comps = this.components();
    let matCost = 0;
    let labCost = 0;
    let macCost = 0;
    let engCost = 0;
    let logCost = 0;

    for (const c of comps) {
      matCost += c.unit_cost_eur.material;
      labCost += c.unit_cost_eur.labour;
      macCost += c.unit_cost_eur.machine;
      engCost += c.unit_cost_eur.energy;
      logCost += c.unit_cost_eur.logistics;
    }

    const totalManufacturingCost = Math.round((matCost + labCost + macCost + engCost + logCost) * 100) / 100;
    const targetMSRP = Math.round(totalManufacturingCost * 1.38); // 38% Gross Margin & Retail

    return {
      material_cost_eur: Math.round(matCost),
      labour_cost_eur: Math.round(labCost),
      machine_cost_eur: Math.round(macCost),
      energy_cost_eur: Math.round(engCost),
      logistics_cost_eur: Math.round(logCost),
      total_direct_manufacturing_cost_eur: totalManufacturingCost,
      estimated_msrp_eur: targetMSRP
    };
  });

  // Selected Component object
  readonly selectedComponent = computed<VehicleComponent | null>(() => {
    const id = this.selectedComponentId();
    if (!id) return null;
    return this.components().find(c => c.component_id === id) || null;
  });

  // Update a single geometric parameter with ripple-through validation
  updateParameter<K extends keyof VehicleParameters>(key: K, value: VehicleParameters[K]) {
    if (this.engineeringFrozen()) {
      console.warn('Engineering change blocked: Design is under Engineering Freeze.');
      return;
    }
    this.parameters.update(prev => ({
      ...prev,
      [key]: value
    }));
  }

  // Update component material
  updateComponentMaterial(componentId: string, newMaterialId: string) {
    if (this.engineeringFrozen()) return;
    const material = this.materials().find(m => m.material_id === newMaterialId);
    if (!material) return;

    this.components.update(comps => {
      return comps.map(c => {
        if (c.component_id === componentId) {
          // Recalculate mass based on density ratio
          const oldMat = this.materials().find(m => m.material_id === c.material_id);
          const densityRatio = oldMat ? material.density / oldMat.density : 1.0;
          const newMass = Math.round(c.mass_kg * densityRatio * 10) / 10;
          const newMatCost = Math.round(newMass * material.cost_per_kg * 10) / 10;
          
          return {
            ...c,
            material_id: newMaterialId,
            mass_kg: newMass,
            unit_cost_eur: {
              ...c.unit_cost_eur,
              material: newMatCost,
              total: Math.round((newMatCost + c.unit_cost_eur.labour + c.unit_cost_eur.machine + c.unit_cost_eur.energy + c.unit_cost_eur.logistics) * 10) / 10
            }
          };
        }
        return c;
      });
    });
  }

  // Update component thickness (mm)
  updateComponentThickness(componentId: string, newThicknessMm: number) {
    if (this.engineeringFrozen()) return;
    this.components.update(comps => {
      return comps.map(c => {
        if (c.component_id === componentId) {
          const ratio = newThicknessMm / c.thickness_mm;
          const newMass = Math.round(c.mass_kg * ratio * 10) / 10;
          const mat = this.materials().find(m => m.material_id === c.material_id);
          const matCost = mat ? Math.round(newMass * mat.cost_per_kg * 10) / 10 : c.unit_cost_eur.material;

          return {
            ...c,
            thickness_mm: newThicknessMm,
            mass_kg: newMass,
            unit_cost_eur: {
              ...c.unit_cost_eur,
              material: matCost,
              total: Math.round((matCost + c.unit_cost_eur.labour + c.unit_cost_eur.machine + c.unit_cost_eur.energy + c.unit_cost_eur.logistics) * 10) / 10
            }
          };
        }
        return c;
      });
    });
  }

  // Toggle Engineering Freeze
  toggleEngineeringFreeze() {
    this.engineeringFrozen.update(v => !v);
  }

  // Apply Variant Presets (Base, Comfort, Sport, Premium EV)
  applyVariant(variant: 'BASE' | 'COMFORT' | 'SPORT' | 'PREMIUM_EV') {
    this.activeVariant.set(variant);
    if (variant === 'SPORT') {
      this.exteriorColorHex.set('#dc2626'); // Tornado Red
      this.updateParameter('roof_height', 1470);
      this.updateParameter('ground_clearance', 130);
      this.updateParameter('windshield_angle', 56);
      this.updateComponentMaterial('COMP-SEAT-DRIVER', 'MAT-TEX-NAPPA');
      this.updateComponentMaterial('COMP-SEAT-PASSENGER', 'MAT-TEX-NAPPA');
      this.updateComponentMaterial('COMP-HOOD-01', 'MAT-ALU-6016');
    } else if (variant === 'COMFORT') {
      this.exteriorColorHex.set('#d97706'); // Habanero Orange Metallic
      this.updateParameter('roof_height', 1520);
      this.updateParameter('ground_clearance', 150);
      this.updateComponentMaterial('COMP-SEAT-DRIVER', 'MAT-TEX-PET-OCEAN');
      this.updateComponentMaterial('COMP-SEAT-PASSENGER', 'MAT-TEX-PET-OCEAN');
    } else if (variant === 'BASE') {
      this.exteriorColorHex.set('#475569'); // Pure Grey
      this.updateParameter('roof_height', 1500);
      this.updateParameter('ground_clearance', 145);
      this.updateComponentMaterial('COMP-SEAT-DRIVER', 'MAT-TEX-PET-OCEAN');
    } else {
      // PREMIUM_EV
      this.exteriorColorHex.set('#0284c7'); // Electric Ocean Blue
      this.updateParameter('roof_height', 1500);
      this.updateParameter('ground_clearance', 145);
      this.updateComponentMaterial('COMP-SEAT-DRIVER', 'MAT-TEX-VEGAN');
      this.updateComponentMaterial('COMP-SEAT-PASSENGER', 'MAT-TEX-VEGAN');
    }
  }

  // Reset to default baseline
  resetToDefaults() {
    this.parameters.set({
      vehicle_length: 4080,
      vehicle_width: 1720,
      vehicle_height: 1500,
      wheelbase: 2540,
      front_overhang: 740,
      rear_overhang: 800,
      track_front: 1510,
      track_rear: 1500,
      roof_height: 1500,
      windshield_angle: 54,
      rear_glass_angle: 48,
      hood_length: 1020,
      door_length: 1120,
      fender_radius: 380,
      wheel_arch_radius: 360,
      ground_clearance: 145,
      roof_thickness: 0.9,
      hood_thickness: 0.8,
      door_skin_thickness: 0.8,
      floorpan_thickness: 1.2,
      a_pillar_thickness: 1.8,
      b_pillar_thickness: 2.2,
      side_sill_thickness: 2.0
    });
    this.explodedFactor.set(0);
    this.sectionMode.set('NONE');
    this.seatPositionX.set(0);
    this.seatHeightOffset.set(0);
  }
}
