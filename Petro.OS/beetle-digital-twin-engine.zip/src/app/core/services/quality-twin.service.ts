import { Injectable, signal, computed } from '@angular/core';
import { 
  GapFlushMeasurement, 
  BoltTorqueMeasurement, 
  PaintLayerInspection, 
  QualityDefectRecord,
  VehicleTraceabilityRecord,
  EndOfLineTestResult 
} from '../models/quality.types';

@Injectable({
  providedIn: 'root'
})
export class QualityTwinService {
  readonly activeVin = signal<string>('WVW-BTL-2026-004128');

  // Gap & Flush Measurements (Spaltmaß)
  readonly gapFlushData = signal<GapFlushMeasurement[]>([
    {
      id: 'GAP-01',
      location_name: 'Hood to Left Front Fender (Haube / Kotflügel Links)',
      panel_a: 'COMP-HOOD-01',
      panel_b: 'COMP-FENDER-FL',
      gap_target_mm: 3.5,
      gap_actual_mm: 3.48,
      flush_target_mm: 0.0,
      flush_actual_mm: 0.12,
      tolerance_mm: 0.5,
      status: 'GREEN',
      measured_at_station: 'ST-01-BODY'
    },
    {
      id: 'GAP-02',
      location_name: 'Hood to Right Front Fender (Haube / Kotflügel Rechts)',
      panel_a: 'COMP-HOOD-01',
      panel_b: 'COMP-FENDER-FR',
      gap_target_mm: 3.5,
      gap_actual_mm: 3.52,
      flush_target_mm: 0.0,
      flush_actual_mm: -0.08,
      tolerance_mm: 0.5,
      status: 'GREEN',
      measured_at_station: 'ST-01-BODY'
    },
    {
      id: 'GAP-03',
      location_name: 'Driver Door to A-Pillar (Fahrertür / A-Säule)',
      panel_a: 'COMP-DOOR-L',
      panel_b: 'COMP-FENDER-FL',
      gap_target_mm: 3.8,
      gap_actual_mm: 3.84,
      flush_target_mm: 0.0,
      flush_actual_mm: 0.15,
      tolerance_mm: 0.5,
      status: 'GREEN',
      measured_at_station: 'ST-01-BODY'
    },
    {
      id: 'GAP-04',
      location_name: 'Driver Door to B-Pillar Sill (Fahrertür / Schweller)',
      panel_a: 'COMP-DOOR-L',
      panel_b: 'COMP-STRUC-BPILLAR',
      gap_target_mm: 4.0,
      gap_actual_mm: 4.42,
      flush_target_mm: 0.2,
      flush_actual_mm: 0.58,
      tolerance_mm: 0.5,
      status: 'YELLOW',
      measured_at_station: 'ST-01-BODY'
    },
    {
      id: 'GAP-05',
      location_name: 'Rear Glass to Roof Seam (Heckscheibe / Dachrahmen)',
      panel_a: 'COMP-GLASS-REAR',
      panel_b: 'COMP-ROOF-01',
      gap_target_mm: 2.5,
      gap_actual_mm: 2.45,
      flush_target_mm: 0.0,
      flush_actual_mm: 0.05,
      tolerance_mm: 0.4,
      status: 'GREEN',
      measured_at_station: 'ST-07-WINDOWS'
    }
  ]);

  // Bolt Torque-Angle Quality Curves
  readonly torqueMeasurements = signal<BoltTorqueMeasurement[]>([
    {
      bolt_id: 'TORQ-01-HV-BAT',
      joint_name: 'HV Battery Pack Main Structural Anchor M14x1.5 (Pos 1-4)',
      target_torque_nm: 145.0,
      actual_torque_nm: 146.2,
      tolerance_nm: 5.0,
      target_angle_deg: 90.0,
      actual_angle_deg: 91.4,
      status: 'OK',
      tool_id: 'ATLAS-COPCO-ST-400-01',
      worker_id: 'EMP-7841 (Automated Multi-Spindle)',
      curve_points: [
        { angle: 0, torque: 5 },
        { angle: 30, torque: 35 },
        { angle: 60, torque: 95 },
        { angle: 80, torque: 130 },
        { angle: 91.4, torque: 146.2 }
      ]
    },
    {
      bolt_id: 'TORQ-02-SEAT-L',
      joint_name: 'Front Driver Seat Floor Rail M10 Grade 10.9 (Pos Front-Left)',
      target_torque_nm: 42.0,
      actual_torque_nm: 42.8,
      tolerance_nm: 2.5,
      target_angle_deg: 45.0,
      actual_angle_deg: 46.1,
      status: 'OK',
      tool_id: 'DESOUTTER-ERGO-EC8',
      worker_id: 'EMP-4109 (M. Schmidt)',
      curve_points: [
        { angle: 0, torque: 2 },
        { angle: 15, torque: 14 },
        { angle: 30, torque: 28 },
        { angle: 46.1, torque: 42.8 }
      ]
    },
    {
      bolt_id: 'TORQ-03-WHEEL-5X',
      joint_name: 'Wheel Hub 5-Bolt Lug Studs M14x1.5 (FL)',
      target_torque_nm: 140.0,
      actual_torque_nm: 139.5,
      tolerance_nm: 4.0,
      target_angle_deg: 60.0,
      actual_angle_deg: 60.5,
      status: 'OK',
      tool_id: 'NUTRUNNER-ROB-09',
      worker_id: 'ROB-09-WHEEL-L',
      curve_points: [
        { angle: 0, torque: 10 },
        { angle: 25, torque: 55 },
        { angle: 50, torque: 115 },
        { angle: 60.5, torque: 139.5 }
      ]
    }
  ]);

  // Paint Layer Thicknesses (Microns / µm)
  readonly paintInspections = signal<PaintLayerInspection[]>([
    {
      layer_type: 'E-Coat (KTL)',
      target_thickness_um: 22.0,
      actual_thickness_um: 22.8,
      tolerance_um: 3.0,
      curing_temp_c: 185,
      gloss_units_20deg: 18,
      status: 'PASS'
    },
    {
      layer_type: 'Primer Filler',
      target_thickness_um: 35.0,
      actual_thickness_um: 36.1,
      tolerance_um: 4.0,
      curing_temp_c: 160,
      gloss_units_20deg: 45,
      status: 'PASS'
    },
    {
      layer_type: 'Basecoat Metallic',
      target_thickness_um: 16.0,
      actual_thickness_um: 15.7,
      tolerance_um: 2.5,
      curing_temp_c: 80,
      gloss_units_20deg: 78,
      status: 'PASS'
    },
    {
      layer_type: '2K Clearcoat',
      target_thickness_um: 45.0,
      actual_thickness_um: 46.4,
      tolerance_um: 5.0,
      curing_temp_c: 140,
      gloss_units_20deg: 92,
      status: 'PASS'
    }
  ]);

  // Quality Defect Log
  readonly defectLog = signal<QualityDefectRecord[]>([
    {
      defect_id: 'DEF-2026-0819',
      timestamp: '08:42:10',
      vin: 'WVW-BTL-2026-004128',
      station_id: 'ST-01-BODY',
      category: 'Gap Tolerance',
      description: 'Right B-pillar door sill gap measured 4.42mm (upper warning threshold 4.5mm).',
      severity: 'MINOR',
      root_cause: 'Fixture clamp #3 wear detected; shimming requested.',
      remedy_action: 'Automated optical feedback re-zeroed clamp position.',
      resolved: true
    },
    {
      defect_id: 'DEF-2026-0818',
      timestamp: '08:15:33',
      vin: 'WVW-BTL-2026-004122',
      station_id: 'ST-03-PAINT',
      category: 'Paint Surface',
      description: 'Micro dust inclusion detected on rear roof contour (diameter 0.18mm).',
      severity: 'MINOR',
      root_cause: 'Cleanroom ionization grid airflow turbulence.',
      remedy_action: 'Polished at Station 3 Rework Bay; clearcoat re-scanned PASS.',
      resolved: true
    }
  ]);

  // End of Line Dynamic Audit Result
  readonly endOfLineAudit = signal<EndOfLineTestResult>({
    electrical_can_diagnostic_pass: true,
    lighting_lux_alignment_pass: true,
    brake_force_balance_pass: true,
    wheel_alignment_camber_toe_pass: true,
    water_ingress_rain_chamber_pass: true,
    adas_radar_camera_calibration_pass: true,
    hvac_cabin_airflow_pass: true,
    overall_readiness_score: 99.4
  });

  // Traceability Record for the Active Vehicle
  readonly activeTraceability = computed<VehicleTraceabilityRecord>(() => {
    return {
      vin: this.activeVin(),
      model_variant: 'Synthetic Beetle Modernist EV (150 kW / 60 kWh)',
      production_date: '2026-09-15',
      batch_number: 'BATCH-2026-W38-EV',
      stations_traversed: [
        { station_id: 'ST-01-BODY', completed_at: '08:12:00', cycle_time_s: 58, operator: 'Auto-Framing Line A', machine_id: 'ROB-01-GEO', quality_status: 'PASS' },
        { station_id: 'ST-02-WELDING', completed_at: '08:18:20', cycle_time_s: 62, operator: 'K. Weber', machine_id: 'ROB-17-LASER', quality_status: 'PASS' },
        { station_id: 'ST-03-PAINT', completed_at: '08:34:10', cycle_time_s: 65, operator: 'Automated Dürr Booth', machine_id: 'ROB-03-PAINT-L', quality_status: 'PASS' },
        { station_id: 'ST-04-UNDERBODY', completed_at: '08:44:00', cycle_time_s: 60, operator: 'HV Team 4', machine_id: 'ROB-04-LIFT', quality_status: 'PASS' },
        { station_id: 'ST-05-ELECTRICAL', completed_at: '08:52:15', cycle_time_s: 55, operator: 'T. Hoffmann', machine_id: 'JIG-ELEC-05', quality_status: 'PASS' },
        { station_id: 'ST-06-INTERIOR', completed_at: '09:01:40', cycle_time_s: 57, operator: 'Interior Trim Cell', machine_id: 'ROB-06-COCKPIT', quality_status: 'PASS' }
      ],
      critical_components: [
        { part_id: 'COMP-BAT-PACK-60', name: '60kWh Battery Pack', batch_lot: 'PWRCO-CELL-811-9941', supplier: 'PowerCo Plant Salzgitter', inspection_pass: true },
        { part_id: 'COMP-MOTOR-REAR', name: '150kW PSM Electric Drive', batch_lot: 'VITESCO-EMOT-4102', supplier: 'Continental Vitesco', inspection_pass: true },
        { part_id: 'COMP-STRUC-BPILLAR', name: 'Hot-Stamped Boron B-Pillar', batch_lot: 'GEST-22MNB5-0914', supplier: 'Gestamp Automoción', inspection_pass: true }
      ]
    };
  });

  // Inject a synthetic quality deviation for demo
  injectGapDefect() {
    this.gapFlushData.update(items => {
      return items.map(item => {
        if (item.id === 'GAP-04') {
          return {
            ...item,
            gap_actual_mm: 4.88,
            flush_actual_mm: 0.72,
            status: 'RED'
          };
        }
        return item;
      });
    });

    this.defectLog.update(logs => [
      {
        defect_id: `DEF-${Date.now().toString().slice(-4)}`,
        timestamp: new Date().toLocaleTimeString(),
        vin: this.activeVin(),
        station_id: 'ST-01-BODY',
        category: 'Gap Tolerance',
        description: 'Critical Gap Deviation: B-Pillar door sill gap at 4.88mm exceeds +0.5mm tolerance band.',
        severity: 'CRITICAL',
        root_cause: 'Side sill locator clamp shifted +0.4mm during spot welding.',
        remedy_action: 'Robot inspection halted vehicle; manual rework jig required.',
        resolved: false
      },
      ...logs
    ]);
  }

  // Clear defects
  resolveAllDefects() {
    this.gapFlushData.update(items => {
      return items.map(item => ({
        ...item,
        status: item.id === 'GAP-04' ? 'GREEN' : item.status,
        gap_actual_mm: item.id === 'GAP-04' ? 3.95 : item.gap_actual_mm
      }));
    });
    this.defectLog.update(logs => logs.map(l => ({ ...l, resolved: true })));
  }
}
