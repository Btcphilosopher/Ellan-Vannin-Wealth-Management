import { Injectable, computed, signal } from '@angular/core';
import { 
  ProductionStation, 
  VehicleProductionInstance, 
  StationId, 
  FactoryPlantMetrics,
  ManufacturingBOMItem 
} from '../models/factory.types';

@Injectable({
  providedIn: 'root'
})
export class FactorySimulationService {
  // Playback State
  readonly isPlaying = signal<boolean>(true);
  readonly simulationSpeed = signal<number>(1); // 1x, 2x, 5x, 10x
  readonly simulationTimeSeconds = signal<number>(32400); // 09:00:00 AM (in seconds from midnight)
  readonly activeReplayTime = signal<string>('09:15');

  // Disruption Simulation Flags
  readonly robot17FaultActive = signal<boolean>(false);
  readonly paintSlowdownActive = signal<boolean>(false);
  readonly supplyShortageActive = signal<boolean>(false);

  // 11 Canonical Production Stations
  readonly stations = signal<ProductionStation[]>([
    {
      station_id: 'ST-01-BODY',
      station_number: 1,
      name: 'Body-in-White Framing',
      german_name: '01 KAROSSERIEBAU',
      description: 'Automated floorpan and side frame jig clamping & dimensional positioning.',
      cycle_time_target_s: 58,
      cycle_time_actual_s: 58,
      operators_count: 2,
      buffer_capacity: 5,
      buffer_current: 3,
      oee_percent: 94.2,
      is_bottleneck: false,
      status: 'NORMAL',
      tools: ['Hydraulic Geo-Clamps', 'Laser Tracker FARO', 'Pneumatic Lift Jigs'],
      consumed_components: ['COMP-STRUC-FLOOR', 'COMP-STRUC-BPILLAR'],
      energy_consumption_kw: 42.5,
      robots: [
        {
          robot_id: 'ROB-01-GEO',
          name: 'KUKA Quantec KR210 Geo-Framing Arm',
          type: 'Heavy Marriage Lift',
          station_id: 'ST-01-BODY',
          payload_kg: 210,
          reach_mm: 2700,
          cycle_time_s: 56,
          status: 'OPERATIONAL',
          kinematic_joint_angles_deg: [15, -45, 90, 0, 45, 0],
          efficiency_oee_percent: 96.5,
          fault_history_count: 0,
          position_coords: [-20, 3, 0]
        }
      ]
    },
    {
      station_id: 'ST-02-WELDING',
      station_number: 2,
      name: 'Robotic Spot & Laser Welding',
      german_name: '02 SCHWEISSEN & FÜGEN',
      description: '4,280 spot welds and laser roof brazing for structural rigidity.',
      cycle_time_target_s: 62,
      cycle_time_actual_s: 62,
      operators_count: 1,
      buffer_capacity: 4,
      buffer_current: 2,
      oee_percent: 92.8,
      is_bottleneck: false,
      status: 'NORMAL',
      tools: ['Servo Spot Guns', 'Trumpf TruDisk Laser Optic', 'Ultrasonic NDT Weld Tester'],
      consumed_components: ['COMP-ROOF-01', 'COMP-FENDER-FL', 'COMP-FENDER-FR'],
      energy_consumption_kw: 88.0,
      robots: [
        {
          robot_id: 'ROB-02-WELD-A',
          name: 'FANUC R-2000iC Spot Weld Master',
          type: 'Spot Welding',
          station_id: 'ST-02-WELDING',
          payload_kg: 165,
          reach_mm: 2655,
          cycle_time_s: 60,
          status: 'OPERATIONAL',
          kinematic_joint_angles_deg: [-30, 20, 60, 45, -20, 10],
          efficiency_oee_percent: 94.0,
          fault_history_count: 1,
          position_coords: [-16, 3, 0]
        },
        {
          robot_id: 'ROB-17-LASER', // MASTER DEMO TARGET
          name: 'ABB IRB 6700 Laser Roof Brazer #17',
          type: 'Laser Brazing',
          station_id: 'ST-02-WELDING',
          payload_kg: 150,
          reach_mm: 3200,
          cycle_time_s: 62,
          status: 'OPERATIONAL',
          kinematic_joint_angles_deg: [45, -15, 80, 0, 30, -45],
          efficiency_oee_percent: 91.5,
          fault_history_count: 0,
          position_coords: [-16, -3, 0]
        }
      ]
    },
    {
      station_id: 'ST-03-PAINT',
      station_number: 3,
      name: 'E-Coat & Automated Paint',
      german_name: '03 LACKIERUNG & KTL',
      description: 'Cathodic dip coating (KTL), robotic primer, basecoat and 2K clearcoat bake.',
      cycle_time_target_s: 65,
      cycle_time_actual_s: 65,
      operators_count: 2,
      buffer_capacity: 6,
      buffer_current: 4,
      oee_percent: 89.5,
      is_bottleneck: true, // Normal initial bottleneck
      status: 'NORMAL',
      tools: ['Dürr EcoBell3 High-Rotation Atomizer', 'Cleanroom Air Flow HVAC', 'IR Curing Oven'],
      consumed_components: ['COMP-DOOR-L', 'COMP-DOOR-R', 'COMP-HOOD-01'],
      energy_consumption_kw: 145.0,
      robots: [
        {
          robot_id: 'ROB-03-PAINT-L',
          name: 'Dürr EcoRP E043i Bell Atomizer L',
          type: 'Electrostatic Spray',
          station_id: 'ST-03-PAINT',
          payload_kg: 50,
          reach_mm: 2800,
          cycle_time_s: 65,
          status: 'OPERATIONAL',
          kinematic_joint_angles_deg: [0, 45, 45, 90, 0, 0],
          efficiency_oee_percent: 93.2,
          fault_history_count: 0,
          position_coords: [-12, 3.5, 0]
        }
      ]
    },
    {
      station_id: 'ST-04-UNDERBODY',
      station_number: 4,
      name: 'Chassis & Battery Marriage',
      german_name: '04 UNTERBODEN & HOCHVOLT',
      description: 'Hydraulic lift bolting of 60kWh battery pack and front/rear subframes.',
      cycle_time_target_s: 60,
      cycle_time_actual_s: 60,
      operators_count: 4,
      buffer_capacity: 4,
      buffer_current: 2,
      oee_percent: 95.0,
      is_bottleneck: false,
      status: 'NORMAL',
      tools: ['Atlas Copco Multi-Spindle Torquer', 'AGV Automated Marriage Table', 'HV Insulation Tester'],
      consumed_components: ['COMP-BAT-PACK-60', 'COMP-CHASSIS-FRONT', 'COMP-MOTOR-REAR'],
      energy_consumption_kw: 52.0,
      robots: [
        {
          robot_id: 'ROB-04-LIFT',
          name: 'KUKA Titan Heavy Marriage Table',
          type: 'Heavy Marriage Lift',
          station_id: 'ST-04-UNDERBODY',
          payload_kg: 1000,
          reach_mm: 3200,
          cycle_time_s: 58,
          status: 'OPERATIONAL',
          kinematic_joint_angles_deg: [0, 0, 90, 0, 0, 0],
          efficiency_oee_percent: 97.0,
          fault_history_count: 0,
          position_coords: [-8, 0, 0]
        }
      ]
    },
    {
      station_id: 'ST-05-ELECTRICAL',
      station_number: 5,
      name: 'High & Low Voltage Wire Harness',
      german_name: '05 ELEKTRIK & KABELBAUM',
      description: 'Zonal body harness routing, fuse boxes, and ECU gateway installation.',
      cycle_time_target_s: 55,
      cycle_time_actual_s: 55,
      operators_count: 6,
      buffer_capacity: 4,
      buffer_current: 3,
      oee_percent: 96.0,
      is_bottleneck: false,
      status: 'NORMAL',
      tools: ['Automated Cable Feed Jigs', 'Barcode Continuity Checker', 'Torque Screwdrivers'],
      consumed_components: ['COMP-ELEC-HARNESS'],
      energy_consumption_kw: 18.5,
      robots: []
    },
    {
      station_id: 'ST-06-INTERIOR',
      station_number: 6,
      name: 'Cockpit & Dashboard Installation',
      german_name: '06 INTERIEUR & COCKPIT',
      description: 'Robotic cockpit manipulation through door aperture & center console lock.',
      cycle_time_target_s: 57,
      cycle_time_actual_s: 57,
      operators_count: 3,
      buffer_capacity: 4,
      buffer_current: 2,
      oee_percent: 93.5,
      is_bottleneck: false,
      status: 'NORMAL',
      tools: ['Cockpit Inserter Manipulator', 'Steering Column Torque Nutrunner', 'Clip Verifier Sensor'],
      consumed_components: ['COMP-INT-DASHBOARD', 'COMP-INT-STEERING'],
      energy_consumption_kw: 24.0,
      robots: [
        {
          robot_id: 'ROB-06-COCKPIT',
          name: 'ABB IRB 6640 Cockpit Inserter',
          type: 'Heavy Marriage Lift',
          station_id: 'ST-06-INTERIOR',
          payload_kg: 185,
          reach_mm: 2750,
          cycle_time_s: 54,
          status: 'OPERATIONAL',
          kinematic_joint_angles_deg: [-45, 30, 45, 0, 45, 0],
          efficiency_oee_percent: 95.0,
          fault_history_count: 0,
          position_coords: [0, 3, 0]
        }
      ]
    },
    {
      station_id: 'ST-07-WINDOWS',
      station_number: 7,
      name: 'Windshield & Glazing Bonding',
      german_name: '07 SCHEIBEN & KLEBEN',
      description: 'Polyurethane bead adhesive extrusion and vision-guided glass placement.',
      cycle_time_target_s: 54,
      cycle_time_actual_s: 54,
      operators_count: 2,
      buffer_capacity: 4,
      buffer_current: 3,
      oee_percent: 96.5,
      is_bottleneck: false,
      status: 'NORMAL',
      tools: ['Sika Automated Dispenser', 'Cognex 3D Vision Alignment', 'Suction Cup Gripper'],
      consumed_components: ['COMP-GLASS-WINDSHIELD', 'COMP-GLASS-REAR'],
      energy_consumption_kw: 28.0,
      robots: [
        {
          robot_id: 'ROB-07-GLASS',
          name: 'FANUC M-710iC Glass Placement System',
          type: 'Glass Placement',
          station_id: 'ST-07-WINDOWS',
          payload_kg: 70,
          reach_mm: 2050,
          cycle_time_s: 52,
          status: 'OPERATIONAL',
          kinematic_joint_angles_deg: [0, -30, 60, 0, 90, 0],
          efficiency_oee_percent: 98.0,
          fault_history_count: 0,
          position_coords: [4, -3, 0]
        }
      ]
    },
    {
      station_id: 'ST-08-SEATS',
      station_number: 8,
      name: 'Ergonomic Seat Installation',
      german_name: '08 SITZE & GURTE',
      description: 'Front and rear seat mounting, floor rail torquing & airbag sensor mating.',
      cycle_time_target_s: 56,
      cycle_time_actual_s: 56,
      operators_count: 4,
      buffer_capacity: 4,
      buffer_current: 2,
      oee_percent: 95.2,
      is_bottleneck: false,
      status: 'NORMAL',
      tools: ['Seat Assist Zero-G Manipulator', 'Angle-Controlled M10 Torquer', 'Airbag Connector Click Sensor'],
      consumed_components: ['COMP-SEAT-DRIVER', 'COMP-SEAT-PASSENGER', 'COMP-SEAT-REAR'],
      energy_consumption_kw: 16.0,
      robots: []
    },
    {
      station_id: 'ST-09-WHEELS',
      station_number: 9,
      name: 'Wheel & Tire Assembly',
      german_name: '09 RÄDER & BREMSEN',
      description: 'Automated 5-bolt simultaneous wheel mounting and tire pressure sync.',
      cycle_time_target_s: 52,
      cycle_time_actual_s: 52,
      operators_count: 2,
      buffer_capacity: 4,
      buffer_current: 3,
      oee_percent: 97.5,
      is_bottleneck: false,
      status: 'NORMAL',
      tools: ['Desoutter 5-Spindle Wheel Nutrunner', 'Tire Barcode Scanner', 'Laser Hub Centering'],
      consumed_components: ['COMP-WHEEL-FL', 'COMP-WHEEL-FR', 'COMP-WHEEL-RL', 'COMP-WHEEL-RR'],
      energy_consumption_kw: 32.0,
      robots: [
        {
          robot_id: 'ROB-09-WHEEL-L',
          name: 'KUKA Cybertech Wheel Nutrunner Left',
          type: 'Wheel Torquer',
          station_id: 'ST-09-WHEELS',
          payload_kg: 60,
          reach_mm: 1800,
          cycle_time_s: 48,
          status: 'OPERATIONAL',
          kinematic_joint_angles_deg: [-90, 0, 45, 0, 45, 0],
          efficiency_oee_percent: 98.5,
          fault_history_count: 0,
          position_coords: [12, 3, 0]
        }
      ]
    },
    {
      station_id: 'ST-10-SOFTWARE',
      station_number: 10,
      name: 'ECU Flashing & Calibration',
      german_name: '10 SOFTWARE FLASH & ADAS',
      description: 'High-speed Ethernet flashing of 48 ECUs, radar alignment and digital twin sync.',
      cycle_time_target_s: 59,
      cycle_time_actual_s: 59,
      operators_count: 2,
      buffer_capacity: 4,
      buffer_current: 2,
      oee_percent: 98.0,
      is_bottleneck: false,
      status: 'NORMAL',
      tools: ['DoIP GigE Flashing Tool', 'Optical Target Calibration Board', 'OBD-III Telemetry Dock'],
      consumed_components: ['COMP-LIGHT-HEADLIGHT-L', 'COMP-LIGHT-HEADLIGHT-R'],
      energy_consumption_kw: 22.0,
      robots: []
    },
    {
      station_id: 'ST-11-ENDTEST',
      station_number: 11,
      name: 'End-of-Line Dynamic Audit',
      german_name: '11 ENDPRÜFUNG & ROLLENPRÜFSTAND',
      description: '140 km/h rolls dyno test, ABS brake balance, rain chamber and laser gap audit.',
      cycle_time_target_s: 60,
      cycle_time_actual_s: 60,
      operators_count: 3,
      buffer_capacity: 6,
      buffer_current: 1,
      oee_percent: 96.0,
      is_bottleneck: false,
      status: 'NORMAL',
      tools: ['Maha 4WD Roller Dynamometer', 'High-Pressure Rain Tunnel', 'Perceptron 3D Gap Audit Tunnel'],
      consumed_components: [],
      energy_consumption_kw: 95.0,
      robots: []
    }
  ]);

  // Active Vehicles Moving on Conveyor Line
  readonly activeVehicles = signal<VehicleProductionInstance[]>([
    {
      vin: 'WVW-BTL-2026-004128',
      vehicle_name: 'Synthetic Beetle EV #128',
      current_station_id: 'ST-01-BODY',
      progress_percent: 75,
      started_at: '09:02:15',
      state: 'BODY_IN_WHITE',
      quality_gate_passed: true,
      defect_count: 0,
      position_progress_m: 2.5
    },
    {
      vin: 'WVW-BTL-2026-004127',
      vehicle_name: 'Synthetic Beetle EV #127',
      current_station_id: 'ST-03-PAINT',
      progress_percent: 45,
      started_at: '08:58:30',
      state: 'PAINTED',
      quality_gate_passed: true,
      defect_count: 0,
      position_progress_m: 11.2
    },
    {
      vin: 'WVW-BTL-2026-004126',
      vehicle_name: 'Synthetic Beetle EV #126',
      current_station_id: 'ST-04-UNDERBODY',
      progress_percent: 88,
      started_at: '08:54:10',
      state: 'MARRIED',
      quality_gate_passed: true,
      defect_count: 0,
      position_progress_m: 16.8
    },
    {
      vin: 'WVW-BTL-2026-004125',
      vehicle_name: 'Synthetic Beetle EV #125',
      current_station_id: 'ST-06-INTERIOR',
      progress_percent: 60,
      started_at: '08:50:00',
      state: 'TRIMMED',
      quality_gate_passed: true,
      defect_count: 0,
      position_progress_m: 24.5
    },
    {
      vin: 'WVW-BTL-2026-004124',
      vehicle_name: 'Synthetic Beetle EV #124',
      current_station_id: 'ST-08-SEATS',
      progress_percent: 92,
      started_at: '08:45:45',
      state: 'ASSEMBLED',
      quality_gate_passed: true,
      defect_count: 0,
      position_progress_m: 32.0
    },
    {
      vin: 'WVW-BTL-2026-004123',
      vehicle_name: 'Synthetic Beetle EV #123',
      current_station_id: 'ST-11-ENDTEST',
      progress_percent: 30,
      started_at: '08:40:10',
      state: 'TESTING',
      quality_gate_passed: true,
      defect_count: 0,
      position_progress_m: 44.0
    }
  ]);

  // Overall Plant Calculation: Bottleneck, Taktzeit, JPH (Jobs Per Hour), OEE
  readonly plantMetrics = computed<FactoryPlantMetrics>(() => {
    const stationList = this.stations();
    let maxCycleTime = 0;
    let bottleneckId: StationId = 'ST-03-PAINT';
    let sumOEE = 0;
    let sumEnergy = 0;

    for (const s of stationList) {
      // If robot 17 fault is active, Station 2 cycle time spikes to 140s!
      let actualCycle = s.cycle_time_actual_s;
      if (this.robot17FaultActive() && s.station_id === 'ST-02-WELDING') {
        actualCycle = 138;
      }
      if (this.paintSlowdownActive() && s.station_id === 'ST-03-PAINT') {
        actualCycle = Math.round(s.cycle_time_actual_s * 1.15);
      }

      if (actualCycle > maxCycleTime) {
        maxCycleTime = actualCycle;
        bottleneckId = s.station_id;
      }
      sumOEE += s.oee_percent;
      sumEnergy += s.energy_consumption_kw;
    }

    const taktzeit_s = maxCycleTime;
    const jph = taktzeit_s > 0 ? Math.round((3600 / taktzeit_s) * 10) / 10 : 0;
    const avgOEE = Math.round((sumOEE / stationList.length) * 10) / 10;

    return {
      total_units_produced_today: 418,
      target_units_today: 500,
      line_speed_jph: jph,
      taktzeit_s: taktzeit_s,
      overall_line_oee: this.robot17FaultActive() ? Math.round(avgOEE * 0.72) : avgOEE,
      active_bottleneck_station: bottleneckId,
      active_vehicles_on_line: this.activeVehicles(),
      total_energy_kwh: Math.round(sumEnergy * 7.5),
      co2_intensity_kg: Math.round(sumEnergy * 0.38)
    };
  });

  // Manufacturing BOM Generation from components
  readonly manufacturingBOM = computed<ManufacturingBOMItem[]>(() => {
    return [
      {
        bom_id: 'MBOM-01-FLR',
        component_id: 'COMP-STRUC-FLOOR',
        part_number: '111-801-001-C',
        name: 'Monocoque Integrated Floorpan & Tunnel',
        quantity: 1,
        station_id: 'ST-01-BODY',
        operation_name: 'OP-1010 Floorpan Clamping & Locator Pin Lock',
        tool_id: 'TOOL-HYD-JIG-01',
        assigned_worker_role: 'Framing Specialist',
        machine_id: 'ROB-01-GEO',
        quality_check_type: 'Laser Datum Alignment (±0.2mm)',
        duration_seconds: 48
      },
      {
        bom_id: 'MBOM-02-ROOF',
        component_id: 'COMP-ROOF-01',
        part_number: '113-817-105-D',
        name: 'Curved Beetle Roof Shell Panel',
        quantity: 1,
        station_id: 'ST-02-WELDING',
        operation_name: 'OP-2040 Laser Brazing Roof Seam L/R',
        tool_id: 'TOOL-LASER-TRUMPF-02',
        assigned_worker_role: 'Laser Automation Tech',
        machine_id: 'ROB-17-LASER',
        quality_check_type: 'Visual Seam Inspection & Ultrasonic Check',
        duration_seconds: 62
      },
      {
        bom_id: 'MBOM-03-DOORS',
        component_id: 'COMP-DOOR-L',
        part_number: '113-831-011-B',
        name: 'Left Driver Side Door Assembly',
        quantity: 1,
        station_id: 'ST-03-PAINT',
        operation_name: 'OP-3015 Door Gap Hinge Hang & E-Coat Dip',
        tool_id: 'TOOL-DOOR-JIG-03',
        assigned_worker_role: 'Paint Preparation Worker',
        machine_id: 'ROB-03-PAINT-L',
        quality_check_type: 'Elcometer Paint Thickness (115-130 µm)',
        duration_seconds: 65
      },
      {
        bom_id: 'MBOM-04-BAT',
        component_id: 'COMP-BAT-PACK-60',
        part_number: '119-915-101-EV',
        name: '60 kWh Structural High-Voltage Battery Pack',
        quantity: 1,
        station_id: 'ST-04-UNDERBODY',
        operation_name: 'OP-4020 Automated AGV Marriage & 16x M14 Bolt Torque',
        tool_id: 'TOOL-ATLAS-MULTISPIN-04',
        assigned_worker_role: 'High-Voltage Certified Assembler',
        machine_id: 'ROB-04-LIFT',
        quality_check_type: 'Torque-Angle Logging (145 Nm ± 5%)',
        duration_seconds: 58
      },
      {
        bom_id: 'MBOM-05-DASH',
        component_id: 'COMP-INT-DASHBOARD',
        part_number: '113-857-021-M',
        name: 'Beetle Modernist Sculpted Dashboard & HUD',
        quantity: 1,
        station_id: 'ST-06-INTERIOR',
        operation_name: 'OP-6010 Robotic Cockpit Insertion & Wire Plug Mating',
        tool_id: 'TOOL-MANIP-COCKPIT-06',
        assigned_worker_role: 'Trim Specialist',
        machine_id: 'ROB-06-COCKPIT',
        quality_check_type: 'CAN-Bus Handshake & Clip Lock Acoustic Sensor',
        duration_seconds: 54
      },
      {
        bom_id: 'MBOM-06-SEATS',
        component_id: 'COMP-SEAT-DRIVER',
        part_number: '113-881-025-ERG',
        name: 'Ergonomic 12-Way Adjustable Driver Seat',
        quantity: 1,
        station_id: 'ST-08-SEATS',
        operation_name: 'OP-8010 4x Floor Rail M10 Torquing & Airbag Plug',
        tool_id: 'TOOL-NUTRUNNER-SEAT-08',
        assigned_worker_role: 'Seating Technician',
        machine_id: 'MANUAL-ASSIST-08',
        quality_check_type: 'Airbag Squib Resistance & 42 Nm Torque Verify',
        duration_seconds: 52
      }
    ];
  });

  // Toggle Simulation Play/Pause
  togglePlayPause() {
    this.isPlaying.update(p => !p);
  }

  setSpeed(speed: number) {
    this.simulationSpeed.set(speed);
  }

  // Master Demo 84: Robot 17 Failure Simulation
  triggerRobot17Fault() {
    this.robot17FaultActive.update(v => !v);
    this.stations.update(sts => sts.map(s => {
      if (s.station_id === 'ST-02-WELDING') {
        const isFault = this.robot17FaultActive();
        return {
          ...s,
          is_bottleneck: isFault,
          cycle_time_actual_s: isFault ? 138 : 62,
          status: isFault ? 'BLOCKED' : 'NORMAL',
          robots: s.robots.map(r => r.robot_id === 'ROB-17-LASER' ? {
            ...r,
            status: isFault ? 'FAULT_STOPPED' : 'OPERATIONAL',
            fault_history_count: r.fault_history_count + (isFault ? 1 : 0)
          } : r)
        };
      }
      return s;
    }));
  }

  // Master Demo 85: Paint Slowdown +15%
  triggerPaintSlowdown() {
    this.paintSlowdownActive.update(v => !v);
    this.stations.update(sts => sts.map(s => {
      if (s.station_id === 'ST-03-PAINT') {
        const isSlow = this.paintSlowdownActive();
        return {
          ...s,
          cycle_time_actual_s: isSlow ? 75 : 65,
          status: isSlow ? 'SLOWDOWN' : 'NORMAL'
        };
      }
      return s;
    }));
  }

  // Advance simulation time & conveyor animation step
  tickConveyor(deltaMs: number) {
    if (!this.isPlaying()) return;
    const speed = this.simulationSpeed();
    const effectiveSecs = (deltaMs / 1000) * speed;

    this.simulationTimeSeconds.update(t => t + effectiveSecs);

    // Update active vehicles progress along the virtual track
    this.activeVehicles.update(vehicles => {
      return vehicles.map(v => {
        let newProgress = v.progress_percent + (effectiveSecs * 1.5);
        if (newProgress > 100) {
          newProgress = 0; // wrap around to next station
        }
        return {
          ...v,
          progress_percent: Math.min(100, Math.round(newProgress * 10) / 10)
        };
      });
    });
  }

  // Time Machine Scrubber Jump
  setTimeMachineReplay(timeLabel: string) {
    this.activeReplayTime.set(timeLabel);
    if (timeLabel === '09:00') {
      this.simulationTimeSeconds.set(32400);
      this.robot17FaultActive.set(false);
    } else if (timeLabel === '09:05') {
      this.simulationTimeSeconds.set(32700);
    } else if (timeLabel === '09:10') {
      this.simulationTimeSeconds.set(33000);
      this.robot17FaultActive.set(true); // Robot 17 tripped at 09:10
    } else if (timeLabel === '09:15') {
      this.simulationTimeSeconds.set(33300);
      this.robot17FaultActive.set(true);
    } else if (timeLabel === '09:20') {
      this.simulationTimeSeconds.set(33600);
      this.robot17FaultActive.set(false); // Maintenance team cleared fault
    }
  }
}
